package com.photogallery.messaging

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.provider.MediaStore
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.photogallery.utils.Preferences
import java.io.File


class EngagementWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {



    override suspend fun doWork(): Result {

        val ctx = applicationContext

        val prefs = Preferences(ctx)

//        if (prefs.notificationSentToday(ctx)) {
//            return Result.success()
//        }

        Notifier.scheduleNow(ctx)

        prefs.setLastNotificationTime(ctx)

        return Result.success()
    }
}

//class EngagementWorker(
//    val context: Context,
//    params: WorkerParameters
//) : CoroutineWorker(context, params) {
//
//
//    override suspend fun doWork(): Result {
//
//        val ctx = applicationContext
//        val preferences = Preferences(ctx)
//
//        // Cooldown: avoid spam
//        if (preferences.notificationSentToday(ctx)) return Result.success()
//
//        val now = System.currentTimeMillis()
//        val lastOpen = preferences.lastAppOpen(ctx)
//
//        val hoursSinceOpen = (now - lastOpen) / (1000 * 60 * 60)
//        val image = getRandomImage(context)
//
//        val (title, message) = when {
//            image.isPortrait -> {
//                Notifier.portraitTitles.random() to Notifier.portraitMessages.random()
//            }
//
//            image.isHd -> {
//                Notifier.hdTitles.random() to Notifier.hdMessages.random()
//            }
//
//            else -> {
//                Notifier.randomTitles.random() to Notifier.randomMessages.random()
//            }
//        }
//
//
//        // 1. Inactivity trigger (48h)
//        if (hoursSinceOpen >= 48) {
//            Notifier.show(
//                ctx,
//                title,
//                message,
//                image.path
//            )
//            return Result.success()
//        }
//
//        // 2. Media burst trigger
//        val recentCount = getRecentPhotoCount(ctx)
//        if (recentCount > 15) {
//            Notifier.show(
//                ctx,
//                title,
//                message,
//                image.path
//            )
//            return Result.success()
//        }
//
//        // 3. Default → memory notification
//        Notifier.show(
//            ctx,
//            title,
//            message,
//            image.path
//        )
//
//        return Result.success()
//    }
//
//    // Query MediaStore for last 48h images
//    private fun getRecentPhotoCount(context: Context): Int {
//
//        val uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
//
//        val projection = arrayOf(MediaStore.Images.Media.DATE_ADDED)
//
//        val cutoff = (System.currentTimeMillis() / 1000) - (48 * 60 * 60)
//
//        val selection = "${MediaStore.Images.Media.DATE_ADDED} > ?"
//        val selectionArgs = arrayOf(cutoff.toString())
//
//        var count = 0
//
//        context.contentResolver.query(
//            uri,
//            projection,
//            selection,
//            selectionArgs,
//            null
//        )?.use {
//            count = it.count
//        }
//
//        return count
//    }
//
//    @SuppressLint("Range")
//    private fun getRandomImage(context: Context): ImageResult {
//
//        val matchedImages = mutableListOf<ImageResult>()
//
//        val projection = arrayOf(
//            MediaStore.Images.Media.DATA,
//            MediaStore.Images.Media.WIDTH,
//            MediaStore.Images.Media.HEIGHT
//        )
//
//        val queryUri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
//
//            MediaStore.Images.Media.EXTERNAL_CONTENT_URI.buildUpon()
//                .appendQueryParameter("limit", "100")
//                .build()
//
//        } else {
//            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
//        }
//
//        val sortOrder =
//            "${MediaStore.Images.Media.DATE_ADDED} DESC LIMIT 100"
//
//        try {
//
//            context.contentResolver.query(
//                queryUri,
//                projection,
//                null,
//                null,
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
//                    "${MediaStore.Images.Media.DATE_ADDED} DESC"
//                } else {
//                    sortOrder
//                }
//            )?.use { cursor ->
//
//                while (cursor.moveToNext()) {
//
//                    val path = cursor.getString(
//                        cursor.getColumnIndex(MediaStore.Images.Media.DATA)
//                    ) ?: continue
//
//                    if (!File(path).exists()) continue
//
//                    val width = cursor.getInt(
//                        cursor.getColumnIndex(MediaStore.Images.Media.WIDTH)
//                    )
//
//                    val height = cursor.getInt(
//                        cursor.getColumnIndex(MediaStore.Images.Media.HEIGHT)
//                    )
//
//                    val isHd = width >= 1920 || height >= 1920
//                    val isPortrait = height > width
//
//                    if (isHd || isPortrait) {
//
//                        matchedImages.add(
//                            ImageResult(
//                                path = path,
//                                isPortrait = isPortrait,
//                                isHd = isHd
//                            )
//                        )
//                    }
//                }
//            }
//
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
//
//        return matchedImages.randomOrNull()
//            ?: ImageResult(
//                path = "",
//                isPortrait = false,
//                isHd = false
//            )
//    }
//
//    data class ImageResult(
//        val path: String,
//        val isPortrait: Boolean,
//        val isHd: Boolean
//    )
//}