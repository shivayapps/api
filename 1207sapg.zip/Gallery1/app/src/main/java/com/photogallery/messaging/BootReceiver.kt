package com.photogallery.messaging

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
//        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
        Notifier.scheduleNow(context)
        Notifier.scheduleDailyWorker(context)
        Notifier.scheduleRandom(context)
//        }
    }
}