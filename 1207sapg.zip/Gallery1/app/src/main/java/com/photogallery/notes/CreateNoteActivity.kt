package com.photogallery.notes

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.util.Patterns
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.photogallery.R
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.adconfig.AdsConfig
import com.photogallery.notes.database.NotesDataBase
import com.photogallery.databinding.ActivityCreateNoteBinding
import com.photogallery.extension.beVisible
import com.photogallery.extension.notificationManager
import com.photogallery.notes.dao.NoteDao
import com.photogallery.notes.entities.Notes
import com.photogallery.notes.util.NoteBottomSheetFragment
import com.photogallery.utils.sendEvent
import com.google.android.material.snackbar.Snackbar
import com.photogallery.base.BaseActivity
import com.photogallery.secret.activity.SelectImageActivity
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences
import com.photogallery.utils.Utils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.lang.Exception
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.time.Duration.Companion.milliseconds

class CreateNoteActivity : BaseActivity() {
    var selectedColor = "#3e434e"
    var currentTime: Long = 0L

    // Permission Private Read & Write
    private var READ_STORAGE_PERM = 123
    private var REQUEST_CODE_IMAGE = 456

    private var webLink = ""
    private var selectedImagePath = ""
    lateinit var notesDataBase: NotesDataBase
    lateinit var noteDao: NoteDao
    lateinit var preferences: Preferences

    private var noteId = -1

    private lateinit var binding: ActivityCreateNoteBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreateNoteBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        noteId = intent.getIntExtra("noteId", -1)
        notesDataBase = NotesDataBase.getDataBase(this@CreateNoteActivity)
        noteDao = notesDataBase.noteDao()
        preferences = Preferences(this)

        if (noteId != -1) {
//            CoroutineScope(Dispatchers.IO).launch {

            val notes = notesDataBase.noteDao().getSpecificNote(noteId)

//                binding.colorView.setBackgroundColor(Color.parseColor(notes.color))
            binding.colorView.backgroundTintList = ColorStateList.valueOf(Color.parseColor(notes.color))

            binding.etNoteTitle.setText(notes.title)
            binding.etNoteDesc.setText(notes.noteText)
            binding.ivDelete.beVisible()

            if (notes.imgPath != "") {
                selectedImagePath = notes.imgPath!!
                binding.imgNote.setImageBitmap(BitmapFactory.decodeFile(notes.imgPath))
                binding.layoutImage.visibility = View.VISIBLE
                binding.imgNote.visibility = View.VISIBLE
                binding.imgDelete.visibility = View.VISIBLE
            } else {
                binding.layoutImage.visibility = View.GONE
                binding.imgNote.visibility = View.GONE
                binding.imgDelete.visibility = View.GONE
            }

            if (notes.webLink != "") {
                webLink = notes.webLink
                binding.tvWebLink.text = notes.webLink
//                    binding.layoutWebUrl.visibility = View.VISIBLE
                binding.tvWebLink.visibility = View.VISIBLE
                binding.imgUrlDelete.visibility = View.VISIBLE
//                    binding.etWebLink.setText(notes.webLink)
            } else {
                binding.tvWebLink.visibility = View.GONE
                binding.imgUrlDelete.visibility = View.GONE
//                    binding.layoutWebUrl.visibility = View.GONE
            }
            currentTime=notes.dateTime
//            }
        }

        // Register & Unregister broadcast receiver
//        LocalBroadcastManager.getInstance(this).registerReceiver(
//            BroadcastReceiver, IntentFilter("bottom_sheet_action")
//        )

        // Find View By ID
//        val tvDateTime = view.findViewById<TextView>(R.id.tvDateTime)
//        val imgDone = view.findViewById<ImageView>(R.id.imgDone)
//        val imgBack = view.findViewById<ImageView>(R.id.imgBack)

//        binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
        binding.colorView.backgroundTintList = ColorStateList.valueOf(Color.parseColor(selectedColor))

        // Date & Time
//        val sdf = SimpleDateFormat("dd-MM-yyyy")
        val format = SimpleDateFormat("dd-MM-yyyy, hh:mm aa", Locale.ENGLISH)

        val calendar = Calendar.getInstance()
        if(currentTime!=0L){
            currentTime = calendar.timeInMillis
        }
        //currentTime = format.format(Date())
        binding.txtTitle.text = format.format(currentTime)

        // Done
        binding.ivDone.setOnClickListener {

            if (noteId != -1) {
                updateNote()
            } else {
                saveNote()
            }
        }

        // Back Button
        binding.icBack.setOnClickListener {
            onBackPressed()
        }

        // Show More Button
        setMoreListener()
//        binding.imgMore.setOnClickListener {
//            val noteBottomSheetFragment = NoteBottomSheetFragment.newInstance(noteId)
//            noteBottomSheetFragment.show(supportFragmentManager, noteBottomSheetFragment.tag)
//        }

        // Delete Image
        binding.imgDelete.setOnClickListener {
            selectedImagePath = ""
            binding.layoutImage.visibility = View.GONE
        }

//        binding.btnOk.setOnClickListener {
//            if (binding.etWebLink.text.toString().trim().isNotEmpty()) {
//                checkWebUrl()
//            } else {
//                Toast.makeText(this, "Url is Required", Toast.LENGTH_SHORT).show()
//            }
//        }
//
//        binding.btnCancel.setOnClickListener {
//            if (noteId != -1) {
//                binding.tvWebLink.visibility = View.VISIBLE
//                binding.layoutWebUrl.visibility = View.GONE
//            } else {
//                binding.layoutWebUrl.visibility = View.GONE
//            }
//        }

        binding.imgUrlDelete.setOnClickListener {
            webLink = ""
            binding.tvWebLink.visibility = View.GONE
            binding.imgUrlDelete.visibility = View.GONE
        }

        binding.tvWebLink.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(binding.tvWebLink.text.toString()))
            startActivity(intent)
        }
    }


    override fun onBackPressed() {
        if (preferences.isNeedInterAd) {
            AdsConfig.showInterstitialAd(this) {
                if (it) preferences.isNeedInterAd = false
                finish()
            }
        } else {
            finish()
        }
    }

    private fun changeColor(seletedView: ImageView, actionColor: String) {

        binding.imgNoteBlue.setImageResource(0)
        binding.imgNoteCyan.setImageResource(0)
        binding.imgNoteGreen.setImageResource(0)
        binding.imgNoteOrange.setImageResource(0)
        binding.imgNotePurple.setImageResource(0)
        binding.imgNoteRed.setImageResource(0)
        binding.imgNoteYellow.setImageResource(0)
        binding.imgNoteBrown.setImageResource(0)
        binding.imgNoteIndigo.setImageResource(0)

        seletedView.setImageResource(R.drawable.donecheck)

        when (actionColor) {

            "Blue" -> {
                //selectedColor = p1.getStringExtra("selectedColor")!!
//                binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
                binding.colorView.backgroundTintList = ColorStateList.valueOf(Color.parseColor(selectedColor))
            }

            "Cyan" -> {
                //selectedColor = p1.getStringExtra("selectedColor")!!
//                binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
                binding.colorView.backgroundTintList = ColorStateList.valueOf(Color.parseColor(selectedColor))
            }

            "Green" -> {
                //selectedColor = p1.getStringExtra("selectedColor")!!
//                binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
                binding.colorView.backgroundTintList = ColorStateList.valueOf(Color.parseColor(selectedColor))
            }

            "Orange" -> {
                //selectedColor = p1.getStringExtra("selectedColor")!!
//                binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
                binding.colorView.backgroundTintList = ColorStateList.valueOf(Color.parseColor(selectedColor))
            }

            "Purple" -> {
                //selectedColor = p1.getStringExtra("selectedColor")!!
//                binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
                binding.colorView.backgroundTintList = ColorStateList.valueOf(Color.parseColor(selectedColor))
            }

            "Red" -> {
                //selectedColor = p1.getStringExtra("selectedColor")!!
//                binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
                binding.colorView.backgroundTintList = ColorStateList.valueOf(Color.parseColor(selectedColor))
            }

            "Yellow" -> {
                //selectedColor = p1.getStringExtra("selectedColor")!!
//                binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
                binding.colorView.backgroundTintList = ColorStateList.valueOf(Color.parseColor(selectedColor))
            }

            "Brown" -> {
                //selectedColor = p1.getStringExtra("selectedColor")!!
//                binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
                binding.colorView.backgroundTintList = ColorStateList.valueOf(Color.parseColor(selectedColor))
            }

            "Indigo" -> {
                //selectedColor = p1.getStringExtra("selectedColor")!!
//                binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
                binding.colorView.backgroundTintList = ColorStateList.valueOf(Color.parseColor(selectedColor))
            }

//            "Image" -> {
//                pickImageFromGallery()
//                binding.layoutWebUrl.visibility = View.GONE
//            }
//
//            "WebUrl" -> {
//                binding.layoutWebUrl.visibility = View.VISIBLE
//            }
//
//            "DeleteNote" -> {
//                deleteNote()
//            }

            else -> {
                binding.layoutImage.visibility = View.GONE
                binding.imgNote.visibility = View.GONE
                //binding.layoutWebUrl.visibility = View.GONE
                //selectedColor = p1.getStringExtra("selectedColor")!!
                //binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
                binding.colorView.backgroundTintList = ColorStateList.valueOf(Color.parseColor(selectedColor))
            }

        }
    }

    private fun setMoreListener() {

        binding.fNoteBlue.setOnClickListener {
            selectedColor = "#2196f3"
            changeColor(binding.imgNoteBlue, "Blue")

//            binding.imgNoteBlue.setImageResource(R.drawable.donecheck)
//            binding.imgNoteCyan.setImageResource(0)
//            binding.imgNoteGreen.setImageResource(0)
//            binding.imgNoteOrange.setImageResource(0)
//            binding.imgNotePurple.setImageResource(0)
//            binding.imgNoteRed.setImageResource(0)
//            binding.imgNoteYellow.setImageResource(0)
//            binding.imgNoteBrown.setImageResource(0)
//            binding.imgNoteIndigo.setImageResource(0)
//
//            val intent = Intent("bottom_sheet_action")
//            intent.putExtra("action", "Blue")
//            intent.putExtra("selectedColor", selectedColor)
//            LocalBroadcastManager.getInstance(this).sendBroadcast(intent)

        }

        binding.fNoteCyan.setOnClickListener {
            selectedColor = "#00e5ff"
            changeColor(binding.imgNoteCyan, "Cyan")
        }

        binding.fNoteGreen.setOnClickListener {
            selectedColor = "#00c853"
            changeColor(binding.imgNoteGreen, "Green")
        }

        binding.fNoteOrange.setOnClickListener {
            selectedColor = "#ff6d00"
            changeColor(binding.imgNoteOrange, "Orange")
        }

        binding.fNotePurple.setOnClickListener {
            selectedColor = "#aa00ff"
            changeColor(binding.imgNotePurple, "Purple")
        }

        binding.fNoteRed.setOnClickListener {
            selectedColor = "#d50000"
            changeColor(binding.imgNoteRed, "Red")
        }

        binding.fNoteYellow.setOnClickListener {
            selectedColor = "#ffeb3b"
            changeColor(binding.imgNoteYellow, "Yellow")
        }

        binding.fNoteBrown.setOnClickListener {
            selectedColor = "#5D4037"
            changeColor(binding.imgNoteBrown, "Brown")
        }

        binding.fNoteIndigo.setOnClickListener {
            selectedColor = "#303F9F"
            changeColor(binding.imgNoteIndigo, "Indigo")
        }
        // FINISH COLORS

        // ADD IMAGE
        binding.llAddImage.setOnClickListener {
            pickImageFromGallery()
        }

        // ADD URL
        binding.llAddUrl.setOnClickListener {

//            val intent = Intent("bottom_sheet_action")
//            intent.putExtra("action", "WebUrl")
//            LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
//            dismiss()
//            binding.layoutWebUrl.visibility = View.VISIBLE

            EditTextDialog(this, { str ->
                webLink = str
                binding.tvWebLink.text = webLink
                binding.tvWebLink.visibility = View.VISIBLE
                binding.imgUrlDelete.visibility = View.VISIBLE
            }).show()
        }

        // Delete Notes
        binding.ivDelete.setOnClickListener {

//            val intent = Intent("bottom_sheet_action")
//            intent.putExtra("action", "DeleteNote")
//            LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
//            dismiss()
            deleteNote()

        }


    }


    private fun updateNote() {

//        CoroutineScope(Dispatchers.IO).launch {

        if (binding.etNoteTitle.text.isNullOrEmpty()) {
            Snackbar.make(binding.root, "Title is Required", Snackbar.LENGTH_LONG).setAction(getString(R.string.ok), View.OnClickListener { null }).show()
        } else if (binding.etNoteDesc.text.isNullOrEmpty()) {
            Snackbar.make(binding.root, "Notes Description Must Not Be Empty", Snackbar.LENGTH_LONG).setAction(getString(R.string.ok), View.OnClickListener { null }).show()
        } else {
            val notes = noteDao.getSpecificNote(noteId)
            notes.title = binding.etNoteTitle?.text.toString()
            notes.noteText = binding.etNoteDesc?.text.toString()
            notes.dateTime = currentTime
            notes.color = selectedColor
            notes.imgPath = selectedImagePath
            notes.webLink = webLink

            noteDao.updateNotes(notes)
        }
//            binding.etNoteTitle?.setText("")
//            binding.etNoteDesc?.setText("")
//            binding.layoutImage.visibility = View.GONE
//            binding.imgNote.visibility = View.GONE
//            binding.tvWebLink.visibility = View.GONE

        sendEvent("refresh_note")
        finish()
//        }
    }

    private fun saveNote() {
        if (binding.etNoteTitle.text.isNullOrEmpty()) {
            Snackbar.make(binding.root, "Title is Required", Snackbar.LENGTH_LONG).setAction(getString(R.string.ok), View.OnClickListener { null }).show()
        } else if (binding.etNoteDesc.text.isNullOrEmpty()) {
            Snackbar.make(binding.root, "Notes Description Must Not Be Empty", Snackbar.LENGTH_LONG).setAction(getString(R.string.ok), View.OnClickListener { null }).show()
        } else {
//            CoroutineScope(Dispatchers.IO).launch {
            val newNotes = Notes()
            newNotes.title = binding.etNoteTitle.text.toString()
            newNotes.noteText = binding.etNoteDesc.text.toString()
            newNotes.dateTime = currentTime
            newNotes.color = selectedColor
            newNotes.imgPath = selectedImagePath
            newNotes.webLink = webLink

            noteDao.insertNotes(newNotes)
//                binding.etNoteTitle?.setText("")
//                binding.etNoteDesc?.setText("")
//                binding.layoutImage.visibility = View.GONE
//                binding.imgNote.visibility = View.GONE
//                binding.tvWebLink.visibility = View.GONE
            sendEvent("refresh_note")
            finish()
//            }
        }

    }

    private fun deleteNote() {
        CoroutineScope(Dispatchers.IO).launch {
            noteDao.deleteSpecificNote(noteId)
            finish()
        }
    }

//    private fun checkWebUrl() {
//        if (Patterns.WEB_URL.matcher(binding.etWebLink.text.toString()).matches()) {
//            binding.layoutWebUrl.visibility = View.GONE
//            binding.etWebLink.isEnabled = false
//            webLink = binding.etWebLink.text.toString()
//            binding.tvWebLink.visibility = View.VISIBLE
//            binding.tvWebLink.text = binding.etWebLink.text.toString()
//        } else {
//            Toast.makeText(this, "Url is not Valid", Toast.LENGTH_SHORT).show()
//        }
//    }

//    private val BroadcastReceiver : BroadcastReceiver = object :  BroadcastReceiver() {
//        override fun onReceive(p0: Context?, p1: Intent?) {
//
//            val actionColor = p1!!.getStringExtra("action")
//            when(actionColor!!){
//
//                "Blue" -> {
//                    selectedColor = p1.getStringExtra("selectedColor")!!
//                    binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
//                }
//
//                "Cyan" -> {
//                    selectedColor = p1.getStringExtra("selectedColor")!!
//                    binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
//                }
//
//                "Green" -> {
//                    selectedColor = p1.getStringExtra("selectedColor")!!
//                    binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
//                }
//
//                "Orange" -> {
//                    selectedColor = p1.getStringExtra("selectedColor")!!
//                    binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
//                }
//
//                "Purple" -> {
//                    selectedColor = p1.getStringExtra("selectedColor")!!
//                    binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
//                }
//
//                "Red" -> {
//                    selectedColor = p1.getStringExtra("selectedColor")!!
//                    binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
//                }
//
//                "Yellow" -> {
//                    selectedColor = p1.getStringExtra("selectedColor")!!
//                    binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
//                }
//
//                "Brown" -> {
//                    selectedColor = p1.getStringExtra("selectedColor")!!
//                    binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
//                }
//
//                "Indigo" -> {
//                    selectedColor = p1.getStringExtra("selectedColor")!!
//                    binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
//                }
//
//                "Image" -> {
//                    pickImageFromGallery()
//                    binding.layoutWebUrl.visibility = View.GONE
//                }
//
//                "WebUrl" -> {
//                    binding.layoutWebUrl.visibility = View.VISIBLE
//                }
//
//                "DeleteNote" -> {
//                    deleteNote()
//                }
//
//                else -> {
//                    binding.layoutImage.visibility = View.GONE
//                    binding.imgNote.visibility = View.GONE
//                    binding.layoutWebUrl.visibility = View.GONE
//                    selectedColor = p1.getStringExtra("selectedColor")!!
//                    binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
//                }
//
//            }
//
//        }
//    }


    private fun pickImageFromGallery() {
        val intent = Intent(this, SelectImageActivity::class.java)
        intent.putExtra(Constant.EXTRA_SELECT_TYPE, Constant.SELECT_TYPE_NOTE)
        selectImageActivityResultLauncher.launch(intent)
//
//        var intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
//        if (intent.resolveActivity(packageManager) != null) {
//            startActivityForResult(intent, REQUEST_CODE_IMAGE)
//        }
    }

    var selectImageActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
//            val selectedImageUrl=Constant.selectedImageList[0].filePath
            selectedImagePath=Constant.selectedImageList[0].filePath
            val options = BitmapFactory.Options().apply {
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            val bitmap = BitmapFactory.decodeFile(selectedImagePath, options)
            binding.imgNote.setImageBitmap(bitmap)
            binding.imgNote.visibility = View.VISIBLE
            binding.layoutImage.visibility = View.VISIBLE
        }
    }

    override fun onDestroy() {
//        LocalBroadcastManager.getInstance(this).unregisterReceiver(BroadcastReceiver)
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

}