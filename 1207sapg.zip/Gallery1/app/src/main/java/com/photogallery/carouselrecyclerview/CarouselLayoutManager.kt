package com.photogallery.carouselrecyclerview

import android.animation.Animator
import android.animation.ValueAnimator
import android.graphics.Rect
import android.os.Parcel
import android.os.Parcelable
import android.util.SparseArray
import android.util.SparseBooleanArray
import android.view.View
import android.view.animation.DecelerateInterpolator
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sqrt

class CarouselLayoutManager constructor(
    isLoop: Boolean,
    isItem3D: Boolean,
    ratio: Float,
    flat: Boolean,
    alpha: Boolean,
    isScrollingEnabled: Boolean,
    @RecyclerView.Orientation orientation: Int
) : RecyclerView.LayoutManager() {

    private var mItemDecoratedWidth: Int = 0
    private var mItemDecoratedHeight: Int = 0
    private var mStartX = 0
    private var mStartY = 0
    private var mOffsetAll = 0
    private var intervalRatio = 0.5f
    private val mAllItemsFrames = SparseArray<Rect>()
    private val mHasAttachedItems = SparseBooleanArray()
    private var animator: ValueAnimator? = null
    private lateinit var recycler: RecyclerView.Recycler
    private lateinit var state: RecyclerView.State
    private var mInfinite = false
    private var is3DItem = false
    private var isFlat = false
    private var isAlpha = false
    private var mSelectedListener: OnSelected? = null
    private var selectedPosition: Int = 0
    private var mLastSelectedPosition: Int = 0
    private var isOrientationChange = false
    private var isScrollingEnabled = true

    @RecyclerView.Orientation
    private var orientation: Int = RecyclerView.HORIZONTAL
        set(value) {
            when (value) {
                RecyclerView.HORIZONTAL -> mStartY = 0
                RecyclerView.VERTICAL -> mStartX = 0
            }
            field = value
        }

    init {
        this.mInfinite = isLoop
        this.is3DItem = isItem3D
        this.isAlpha = alpha
        this.isScrollingEnabled = isScrollingEnabled
        this.orientation = orientation
        if (ratio in 0f..1f) this.intervalRatio = ratio
        isFlat = flat
        if (isFlat) intervalRatio = 1.1f
    }

    companion object {
        private const val SCROLL_TO_RIGHT = 1
        private const val SCROLL_TO_LEFT = 2
        private const val SCROLL_TO_TOP = 3
        private const val SCROLL_TO_BOTTOM = 4
        private const val MAX_RECT_COUNT = 100

    }

    override fun generateDefaultLayoutParams(): RecyclerView.LayoutParams {
        return RecyclerView.LayoutParams(
            RecyclerView.LayoutParams.WRAP_CONTENT,
            RecyclerView.LayoutParams.WRAP_CONTENT
        )
    }

    override fun onLayoutChildren(recycler: RecyclerView.Recycler?, state: RecyclerView.State?) {
        if (state == null || recycler == null)
            return

        /** check item count and pre layout state of the layout manager*/
        if (state.itemCount <= 0 || state.isPreLayout) {
            mOffsetAll = 0
            return
        }

        mAllItemsFrames.clear()
        mHasAttachedItems.clear()

        val scrap = recycler.getViewForPosition(0)
        addView(scrap)
        measureChildWithMargins(scrap, 0, 0)

        mItemDecoratedWidth = getDecoratedMeasuredWidth(scrap)
        mItemDecoratedHeight = getDecoratedMeasuredHeight(scrap)

        when (orientation) {
            RecyclerView.HORIZONTAL -> {
                mStartX = ((getHorizontalSpace() - mItemDecoratedWidth) * 1.0f / 2).roundToInt()
            }

            RecyclerView.VERTICAL -> {
                mStartY = ((getVerticalSpace() - mItemDecoratedHeight) * 1.0f / 2).roundToInt()
            }
        }

        var offset = getStartXOrY()

        var i = 0
        while (i < itemCount && i < MAX_RECT_COUNT) {
            var frame = mAllItemsFrames[i]
            if (frame == null) {
                frame = Rect()
            }
            setFrameCoordinates(frame, offset)
            mAllItemsFrames.put(i, frame)
            mHasAttachedItems.put(i, false)
            offset += getIntervalDistance()
            i++
        }

        detachAndScrapAttachedViews(recycler)

        if (isOrientationChange && selectedPosition != 0) {
            isOrientationChange = false
            mOffsetAll = calculatePositionOffset(selectedPosition)
            onSelectedCallback()
        }

        layoutItems(recycler, state, getScrollToLeftOrTopDirection())
        this.recycler = recycler
        this.state = state
    }

    override fun canScrollHorizontally(): Boolean {

        return isScrollingEnabled && (orientation == RecyclerView.HORIZONTAL)
    }

    override fun canScrollVertically(): Boolean {

        return isScrollingEnabled && (orientation == RecyclerView.VERTICAL)
    }

    override fun scrollHorizontallyBy(
        dx: Int,
        recycler: RecyclerView.Recycler?,
        state: RecyclerView.State?
    ): Int = handleScrollBy(dx, recycler, state)

    override fun scrollVerticallyBy(
        dy: Int,
        recycler: RecyclerView.Recycler?,
        state: RecyclerView.State?
    ): Int = handleScrollBy(dy, recycler, state)

    private fun handleScrollBy(
        dxy: Int,
        recycler: RecyclerView.Recycler?,
        state: RecyclerView.State?
    ): Int {
        if (animator != null && animator!!.isRunning) {
            animator?.cancel()
        }

        if (recycler == null || state == null) return 0

        var travel = dxy

        if (!mInfinite) {
            if (dxy + mOffsetAll < 0) {
                travel = -mOffsetAll
            } else if (dxy + mOffsetAll > maxOffset()) {
                travel = (maxOffset() - mOffsetAll)
            }
        }
        mOffsetAll += travel
        layoutItems(
            recycler,
            state,
            if (dxy > 0) getScrollToLeftOrTopDirection() else getScrollToRightOrBottomDirection()
        )
        return travel
    }

    private fun layoutItems(
        recycler: RecyclerView.Recycler,
        state: RecyclerView.State,
        scrollToDirection: Int
    ) {

        if (state.isPreLayout) return
        //calculate current display area for showing views

        val displayFrames = createRect()
        var position = 0
        for (index in 0 until childCount) {
            val child = getChildAt(index) ?: break
            position = if (child.tag != null) {
                //get position from tag class define later
                val tag = checkTAG(child.tag)
                tag!!.pos
            } else {
                getPosition(child)
            }

            val rect = getFrame(position)

            //Now check item is in the display area, if not recycle that item
            if (!Rect.intersects(displayFrames, rect)) {
                removeAndRecycleView(child, recycler)
                mHasAttachedItems.delete(position)
            } else {
                //Shift the item which has still in the screen
                layoutItem(child, rect)
                mHasAttachedItems.put(position, true)
            }
        }

        if (position == 0) position = centerPosition()

        //For making infinite loop for the layout manager
        var min = position - 20
        var max = position + 20

        if (!mInfinite) {
            if (min < 0) min = 0
            if (max > itemCount) max = itemCount
        }

        for (index in min until max) {
            val rect = getFrame(index)
            //layout items area of a view if it's first inside the display area
            // and also not already on the screen
            if (Rect.intersects(displayFrames, rect) && !mHasAttachedItems.get(
                    index
                )
            ) {
                var actualPos = index % itemCount
                if (actualPos < 0) actualPos += itemCount

                val scrap = recycler.getViewForPosition(actualPos)
                checkTAG(scrap.tag)
                scrap.tag = TAG(index)
                measureChildWithMargins(scrap, 0, 0)

                if (scrollToDirection == getScrollToRightOrBottomDirection()) {
                    addView(scrap, 0)
                } else addView(scrap)

                layoutItem(scrap, rect)
                mHasAttachedItems.put(index, true)
            }
        }

    }

    private fun layoutItem(child: View, rect: Rect) {
        when (orientation) {
            RecyclerView.HORIZONTAL -> {
                layoutDecorated(
                    child,
                    rect.left - mOffsetAll,
                    rect.top,
                    rect.right - mOffsetAll,
                    rect.bottom
                )
            }

            RecyclerView.VERTICAL -> {
                layoutDecorated(
                    child,
                    rect.left,
                    rect.top - mOffsetAll,
                    rect.right,
                    rect.bottom - mOffsetAll
                )
            }
        }

        if (!isFlat) {
            child.scaleX = computeScale(getRectLeftOrTop(rect) - mOffsetAll)
            child.scaleY = computeScale(getRectLeftOrTop(rect) - mOffsetAll)
        }

        if (is3DItem) itemRotate(child, rect)

        if (isAlpha) child.alpha = computeAlpha(getRectLeftOrTop(rect) - mOffsetAll)

    }

    private fun itemRotate1(child: View, frame: Rect) {
        val itemCenter =
            (getRectLeftOrTop(frame) + getRectRightOrBottom(frame) - 2 * mOffsetAll) / 2f
        var value =
            (itemCenter - (getStartXOrY() + getItemDecoratedWidthOrHeight() / 2f)) * 1f / (itemCount * getIntervalDistance())
        value = sqrt(abs(value).toDouble()).toFloat()
        val symbol =
            if (itemCenter > getStartXOrY() + getItemDecoratedWidthOrHeight() / 2f) (-1).toFloat() else 1.toFloat()

        when (orientation) {
            RecyclerView.HORIZONTAL -> {
                child.rotationY = symbol * 50 * abs(value)
            }

            RecyclerView.VERTICAL -> {
                child.rotationX = symbol * 50 * abs(value)
            }
        }
    }

    private fun itemRotate(child: View, frame: Rect) {

        val itemCenter =
            (getRectLeftOrTop(frame) + getRectRightOrBottom(frame) - 2 * mOffsetAll) / 2f

        val center = getStartXOrY() + getItemDecoratedWidthOrHeight() / 2f

        val distance = (itemCenter - center) / getIntervalDistance()

        val absDistance = abs(distance)

        // Fan rotation
        val rotation = distance * 18f
        child.rotation = rotation

        // Small translation for overlapping
        child.translationX = -distance * 40f

        // Slight scale for depth
        val scale = 1f - (absDistance * 0.15f)
        child.scaleX = scale
        child.scaleY = scale

        // Improve perspective
        child.cameraDistance = 12000f
    }

    override fun onScrollStateChanged(state: Int) {
        super.onScrollStateChanged(state)
        if (state == RecyclerView.SCROLL_STATE_IDLE) {
            //When scrolling stops
            fixOffsetWhenFinishOffset()
        }
    }

    private fun fixOffsetWhenFinishOffset() {
        if (getIntervalDistance() != 0) {
            var scrollPosition = (mOffsetAll * 1.0f / getIntervalDistance()).toInt()
            val moreDxy: Float = (mOffsetAll % getIntervalDistance()).toFloat()
            if (abs(moreDxy) > getIntervalDistance() * 0.5f) {
                if (moreDxy > 0) scrollPosition++
                else scrollPosition--
            }
            val finalOffset = scrollPosition * getIntervalDistance()
            startScroll(mOffsetAll, finalOffset)
        }
    }

    private fun startScroll(from: Int, to: Int) {
        //Start animation
        if (animator != null && animator!!.isRunning) {
            animator?.cancel()
        }
        val direction =
            if (from < to) getScrollToLeftOrTopDirection() else getScrollToRightOrBottomDirection()

        animator = ValueAnimator.ofFloat(from * 1.0f, to * 1.0f)
        animator?.duration = 500
        animator?.interpolator = DecelerateInterpolator()

        animator?.addUpdateListener { animation ->
            mOffsetAll = (animation.animatedValue as Float).roundToInt()
            layoutItems(recycler, state, direction)
        }
        animator?.addListener(object : Animator.AnimatorListener {
            override fun onAnimationStart(animation: Animator) {
                //do nothing
            }

            override fun onAnimationEnd(animation: Animator) {
                onSelectedCallback()
            }

            override fun onAnimationCancel(animation: Animator) {
                //do nothing
            }

            override fun onAnimationRepeat(animation: Animator) {
                //do nothing
            }

        })
        animator?.start()
    }

    override fun scrollToPosition(position: Int) {
        if (position < 0 || position > itemCount - 1) return
        if (!this::recycler.isInitialized || !this::state.isInitialized) {
            isOrientationChange = true
            selectedPosition = position
            requestLayout()
            return
        }
        mOffsetAll = calculatePositionOffset(position)
        layoutItems(
            recycler,
            state,
            if (position > selectedPosition) getScrollToLeftOrTopDirection()
            else getScrollToRightOrBottomDirection()
        )
        onSelectedCallback()

    }

    override fun smoothScrollToPosition(
        recyclerView: RecyclerView?,
        state: RecyclerView.State?,
        position: Int
    ) {
        //Loop does not support for smooth scrolling
        if (mInfinite || !this::recycler.isInitialized || !this::state.isInitialized) return
        val finalOffset = calculatePositionOffset(position)
        startScroll(mOffsetAll, finalOffset)
    }

    fun centerPosition(): Int {
        val intervalPosition = getIntervalDistance()
        if (intervalPosition == 0) return intervalPosition

        var pos = mOffsetAll / intervalPosition
        val more = mOffsetAll % intervalPosition
        if (abs(more) >= intervalPosition * 0.5f) {
            if (more >= 0) pos++
            else pos--
        }
        return pos
    }

    fun getChildActualPos(index: Int): Int {
        val child = getChildAt(index) ?: return Int.MIN_VALUE

        if (child.tag != null) {
            val tag = checkTAG(child.tag)
            if (tag != null)
                return tag.pos
        }
        return getPosition(child)
    }

    private fun checkTAG(tag: Any?): TAG? {
        return if (tag != null) {
            if (tag is TAG) {
                tag as TAG
            } else {
                throw IllegalArgumentException("You should use the set tag with the position")
            }
        } else {
            null
        }

    }

    override fun onAdapterChanged(
        oldAdapter: RecyclerView.Adapter<*>?,
        newAdapter: RecyclerView.Adapter<*>?
    ) {
        removeAllViews()
        mOffsetAll = 0
        mHasAttachedItems.clear()
        mAllItemsFrames.clear()
        mInfinite = false
        is3DItem = false
        isFlat = false
        isAlpha = false
        intervalRatio = 0.5f
    }

    fun getFirstVisiblePosition(): Int {
        val displayFrame = createRect()
        val cur: Int = centerPosition()
        var i = cur - 1
        while (true) {
            val rect = getFrame(i)
            if (getRectLeftOrTop(rect) <= getRectLeftOrTop(displayFrame)) {
                return abs(i) % itemCount
            }
            i--
        }
    }

    fun getLastVisiblePosition(): Int {
        val displayFrame = createRect()
        val cur: Int = centerPosition()
        var i = cur - 1
        while (true) {
            val rect = getFrame(i)
            if (getRectLeftOrTop(rect) <= getRectLeftOrTop(displayFrame)) {
                return abs(i) % itemCount
            }
            i++
        }
    }

    private fun onSelectedCallback() {
        //Some time interval distance is returns 0 that makes [ArithmeticException]
        val intervalDistance = getIntervalDistance()
        if (intervalDistance == 0) return

        selectedPosition = ((mOffsetAll / intervalDistance).toFloat()).roundToInt()

        // Fix for -> https://github.com/sparrow007/CarouselRecyclerview/issues/46
        // if (selectedPosition < 0) selectedPosition += itemCount
        // selectedPosition = abs(selectedPosition % itemCount)
        selectedPosition = selectedPosition % itemCount
        if (selectedPosition < 0) selectedPosition += itemCount

        //check if the listener is implemented
        //mLastSelectedPosition keeps track of last position which will prevent simple slide and same position
        if (mSelectedListener != null && selectedPosition != mLastSelectedPosition) {
            mSelectedListener!!.onItemSelected(selectedPosition)
        }
        mLastSelectedPosition = selectedPosition
    }

    private fun getFrame(position: Int): Rect {
        var frame = mAllItemsFrames[position]
        if (frame == null) {
            frame = Rect()
            val offset = getStartXOrY() + getIntervalDistance() * position
            setFrameCoordinates(frame, offset)
            return frame
        }
        return frame
    }

    private fun computeScale(x: Int): Float {
        val startXOrY = getStartXOrY()
        var scale: Float =
            1 - abs(x - startXOrY) * 1.0f / abs(startXOrY + getItemDecoratedWidthOrHeight() / intervalRatio)

        if (scale < 0) scale = 0f
        if (scale > 1) scale = 1f
        return scale
    }

    private fun computeAlpha(x: Int): Float {
        val startXOrY = getStartXOrY()
        var alpha: Float =
            1 - abs(x - startXOrY) * 1.0f / abs(startXOrY + getItemDecoratedWidthOrHeight() / intervalRatio)

        if (alpha < 0.3f) alpha = 0f
        if (alpha > 1) alpha = 1f
        return alpha
    }

    private fun calculatePositionOffset(position: Int): Int {
        return ((getIntervalDistance() * position).toFloat()).roundToInt()
    }

    private fun getIntervalDistance(): Int {
        return (getItemDecoratedWidthOrHeight() * intervalRatio).roundToInt()
    }

    private fun getHorizontalSpace(): Int {
        return width - paddingLeft - paddingRight
    }

    private fun getVerticalSpace(): Int {
        return height - paddingBottom - paddingTop
    }

    private fun maxOffset(): Int {
        return ((itemCount - 1) * getIntervalDistance())
    }

    fun setOnSelectedListener(l: OnSelected) {
        this.mSelectedListener = l
    }

    internal fun getSelectedPosition() = selectedPosition

    private fun getScrollToLeftOrTopDirection(): Int = when (orientation) {
        RecyclerView.HORIZONTAL -> SCROLL_TO_LEFT
        RecyclerView.VERTICAL -> SCROLL_TO_TOP
        else -> SCROLL_TO_LEFT
    }

    private fun getScrollToRightOrBottomDirection(): Int = when (orientation) {
        RecyclerView.HORIZONTAL -> SCROLL_TO_RIGHT
        RecyclerView.VERTICAL -> SCROLL_TO_BOTTOM
        else -> SCROLL_TO_RIGHT
    }

    private fun getStartXOrY(): Int = when (orientation) {
        RecyclerView.HORIZONTAL -> mStartX
        RecyclerView.VERTICAL -> mStartY
        else -> mStartX
    }

    private fun getItemDecoratedWidthOrHeight(): Int = when (orientation) {
        RecyclerView.HORIZONTAL -> mItemDecoratedWidth
        RecyclerView.VERTICAL -> mItemDecoratedHeight
        else -> mItemDecoratedWidth
    }

    private fun createRect(): Rect = when (orientation) {
        RecyclerView.HORIZONTAL -> {
            Rect(mOffsetAll, 0, mOffsetAll + getHorizontalSpace(), getVerticalSpace())
        }

        RecyclerView.VERTICAL -> {
            Rect(0, mOffsetAll, getHorizontalSpace(), mOffsetAll + getVerticalSpace())
        }

        else -> {
            Rect(mOffsetAll, 0, mOffsetAll + getHorizontalSpace(), getVerticalSpace())
        }
    }

    //    private fun setFrameCoordinates(frame: Rect, offset: Int) {
//        when (orientation) {
//            RecyclerView.HORIZONTAL -> {
//                frame.set(offset, 0, (offset + mItemDecoratedWidth), mItemDecoratedHeight)
//            }
//
//            RecyclerView.VERTICAL -> {
//                frame.set(0, offset, mItemDecoratedWidth, (offset + mItemDecoratedHeight))
//            }
//        }
//    }
    private fun setFrameCoordinates(frame: Rect, offset: Int) {

        when (orientation) {

            RecyclerView.HORIZONTAL -> {

                val top = (getVerticalSpace() - mItemDecoratedHeight) / 2

                frame.set(
                    offset,
                    top,
                    offset + mItemDecoratedWidth,
                    top + mItemDecoratedHeight
                )
            }

            RecyclerView.VERTICAL -> {

                val left = (getHorizontalSpace() - mItemDecoratedWidth) / 2

                frame.set(
                    left,
                    offset,
                    left + mItemDecoratedWidth,
                    offset + mItemDecoratedHeight
                )
            }
        }
    }

    private fun getRectLeftOrTop(rect: Rect): Int = when (orientation) {
        RecyclerView.HORIZONTAL -> rect.left
        RecyclerView.VERTICAL -> rect.top
        else -> rect.left
    }

    private fun getRectRightOrBottom(rect: Rect): Int = when (orientation) {
        RecyclerView.HORIZONTAL -> rect.right
        RecyclerView.VERTICAL -> rect.bottom
        else -> rect.right
    }

    class Builder {
        private var isInfinite = false
        private var is3DItem = false
        private var intervalRation: Float = 0.5f
        private var isFlat = false
        private var isAlpha = false
        private var isScrollingEnabled = true

        @RecyclerView.Orientation
        private var orientation = RecyclerView.HORIZONTAL

        fun setIsInfinite(isInfinite: Boolean): Builder {
            this.isInfinite = isInfinite
            return this
        }

        fun set3DItem(is3DItem: Boolean): Builder {
            this.is3DItem = is3DItem
            return this
        }

        fun setIntervalRatio(intervalRatio: Float): Builder {
            this.intervalRation = intervalRatio
            return this
        }

        fun setIsFlat(isFlat: Boolean): Builder {
            this.isFlat = isFlat
            return this
        }

        fun setIsAlpha(isAlpha: Boolean): Builder {
            this.isAlpha = isAlpha
            return this
        }

        fun setIsScrollingEnabled(isScrollingEnabled: Boolean): Builder {
            this.isScrollingEnabled = isScrollingEnabled
            return this
        }

        fun setOrientation(@RecyclerView.Orientation orientation: Int): Builder {
            this.orientation = orientation
            return this
        }

        fun build(): CarouselLayoutManager {
            return CarouselLayoutManager(
                isInfinite,
                is3DItem,
                intervalRation,
                isFlat,
                isAlpha,
                isScrollingEnabled,
                orientation
            )
        }
    }

    /**
     * Store the child position for laying out the view
     */
    internal data class TAG(var pos: Int = 0)

    override fun isAutoMeasureEnabled() = true

    interface OnSelected {
        fun onItemSelected(position: Int)
    }

    override fun onSaveInstanceState(): Parcelable? {
        return SaveState(selectedPosition)
    }

    override fun onRestoreInstanceState(state: Parcelable?) {
        super.onRestoreInstanceState(state)
        if (state is SaveState) {
            isOrientationChange = true
            this.selectedPosition = state.scrollPosition
        }
    }

    class SaveState constructor(var scrollPosition: Int = 0) : Parcelable {

        constructor(parcel: Parcel) : this() {
            scrollPosition = parcel.readInt()
        }

        override fun describeContents(): Int {
            return 0
        }

        override fun writeToParcel(dest: Parcel, flags: Int) {
            dest?.writeInt(scrollPosition)
        }

        companion object CREATOR : Parcelable.Creator<SaveState> {
            override fun createFromParcel(parcel: Parcel): SaveState {
                return SaveState(parcel)
            }

            override fun newArray(size: Int): Array<SaveState?> {
                return arrayOfNulls(size)
            }
        }

    }

}
