package com.photogallery.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "location")
data class LocationEntity(
    @PrimaryKey(autoGenerate = true)
    var locationId: Long = 0,
    var title: String,
    var path: String,
    var uri: String,
    var latitude: Float,
    var longitude: Float

)
