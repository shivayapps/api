package com.photogallery.dialog

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.TextUtils
import android.util.Patterns
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.photogallery.R
import com.photogallery.databinding.DialogSecurityMailBinding
import com.photogallery.extension.toast
import com.photogallery.utils.DIALOG_DIM_AMOUNT
import com.photogallery.utils.Preferences

class SecurityMailDialog(
    var mActivity: Activity,
    val updateListener: (isSuccess: Boolean) -> Unit
) : Dialog(mActivity) {

    lateinit var bindingDialog: DialogSecurityMailBinding
    var preferences: Preferences = Preferences(mActivity)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        window?.setDimAmount(DIALOG_DIM_AMOUNT)
        window?.attributes?.windowAnimations = android.R.style.Animation_Dialog

        bindingDialog = DialogSecurityMailBinding.inflate(layoutInflater)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
        intListener()
    }

    private fun intView() {

    }

    private fun intListener() {

        bindingDialog.btnCancel.setOnClickListener {
            updateListener.invoke(false)
            dismiss()
        }
        bindingDialog.btnOK.setOnClickListener {
            val strInput=bindingDialog.securityMail.text.toString()
            if (strInput.isNotEmpty() && isValidEmail(strInput)) {
                preferences.securityEmail = strInput
                updateListener.invoke(true)
                dismiss()
            } else {
                bindingDialog.securityMail.error = "Please enter valid email."
            }
        }

    }

    fun isValidEmail(target: String): Boolean {
        val emailPattern = Patterns.EMAIL_ADDRESS
        return !TextUtils.isEmpty(target) && emailPattern.matcher(target).matches()
    }

    fun hideSoftKeyboard() {
        val inputMethodManager = mActivity.getSystemService(AppCompatActivity.INPUT_METHOD_SERVICE) as InputMethodManager
        inputMethodManager.hideSoftInputFromWindow(bindingDialog.securityMail.windowToken, 0)
    }


    class SpinnerQueAdapter(
        private val context: Context,
        private val itemList: Array<String>
    ) :
        BaseAdapter() {
        override fun getCount(): Int {
            return itemList.size
        }

        override fun getItem(position: Int): Any {
            return itemList[position]
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val view: View
            val viewHolder: ViewHolder

            if (convertView == null) {
                view = LayoutInflater.from(context).inflate(R.layout.item_spinner_que, parent, false)
                viewHolder = ViewHolder(view)
                view.tag = viewHolder
            } else {
                view = convertView
                viewHolder = view.tag as ViewHolder
            }

            val item = itemList[position]
            viewHolder.itemTextView.text = item
            viewHolder.itemTextView.setTextColor(
                ContextCompat.getColor(
                    context,
                    R.color.black
                )
            )

            viewHolder.itemTextView.visibility = if (position == 0) View.GONE else View.VISIBLE

            return view
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val view: View
            val viewHolder: ViewHolder

            if (convertView == null) {
                view = LayoutInflater.from(context).inflate(R.layout.item_spinner_que, parent, false)
                viewHolder = ViewHolder(view)
                view.tag = viewHolder
            } else {
                view = convertView
                viewHolder = view.tag as ViewHolder
            }

            val item = itemList[position]
            viewHolder.itemTextView.text = item
            if (position == 0) {
                viewHolder.itemTextView.setTextColor(
                    ContextCompat.getColor(
                        context,
                        R.color.gray
                    )
                )
            }
            else {
//            viewHolder.itemTextView.setTextColor(ContextCompat.getColor(context, R.color.black_text))
                viewHolder.itemTextView.setTextColor(Color.WHITE)
            }

            return view
        }


        private class ViewHolder(view: View) {
            val itemTextView: TextView = view.findViewById(R.id.txtItem)
        }
    }


}

