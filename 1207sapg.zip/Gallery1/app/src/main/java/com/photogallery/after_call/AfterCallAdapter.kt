package com.photogallery.after_call

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.graphics.PorterDuff
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.AnimationUtils
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.photogallery.R
import com.photogallery.databinding.ItemAfterCallBinding
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible

class AfterCallAdapter(
    private val imageList: ArrayList<String>,
    private val clickListener: (pos: Int) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        const val TYPE_SIDE = 1

        //        const val TYPE_MOVIE = 2
        const val TYPE_NORMAL = 3
    }

    private val animatedPosition = HashSet<Int>()

    // avatar_head layout
    class CenterViewHolder(
        val binding: ItemAfterCallBinding
    ) : RecyclerView.ViewHolder(binding.root)

    // userviewholder layout
    class SideViewHolder(
        val binding: ItemAfterCallBinding
    ) : RecyclerView.ViewHolder(binding.root)



    override fun getItemViewType(position: Int): Int {

        return when (position) {
            1 -> TYPE_SIDE
            else -> TYPE_NORMAL
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecyclerView.ViewHolder {

        val inflater = LayoutInflater.from(parent.context)

        return when (viewType) {

            TYPE_SIDE -> {

                val binding = ItemAfterCallBinding.inflate(
                    inflater,
                    parent,
                    false
                )

                SideViewHolder(binding)
            }

            else -> {

                val binding = ItemAfterCallBinding.inflate(
                    inflater,
                    parent,
                    false
                )

                CenterViewHolder(binding)
            }
        }
    }

    override fun getItemCount(): Int = imageList.size

    override fun onBindViewHolder(
        holder: RecyclerView.ViewHolder,
        position: Int
    ) {

        when (holder) {

            is SideViewHolder -> {
                val item = imageList[position] ?: return
                holder.binding.apply {
                    viewSpace.beVisible()
                    Glide.with(movieImage)
                        .load(item)
                        .placeholder(R.drawable.ic_image_placeholder)
                        .circleCrop()
                        .into(movieImage)

                    movieImage.setOnClickListener {
                        clickListener.invoke(position)
                    }

                    movieImage.setOnTouchListener { v, event ->

                        val imageView = v as ImageView

                        when (event.action) {

                            MotionEvent.ACTION_DOWN -> {
                                imageView.drawable?.setColorFilter(
                                    0x77FF4081,
                                    PorterDuff.Mode.SRC_ATOP
                                )
                                imageView.invalidate()
                            }

                            MotionEvent.ACTION_UP,
                            MotionEvent.ACTION_CANCEL -> {
                                imageView.drawable?.clearColorFilter()
                                imageView.invalidate()
                            }
                        }

                        false
                    }
                }
            }

            is CenterViewHolder -> {

                val item = imageList[position] ?: return

                holder.binding.apply {

                    viewSpace.beGone()

//                    user.text = item.name

                    Glide.with(movieImage)
                        .load(item)
                        .placeholder(R.drawable.ic_image_placeholder)
                        .circleCrop()
                        .into(movieImage)

                    movieImage.setOnClickListener {
                        clickListener.invoke(position)
                    }

                    movieImage.setOnTouchListener { v, event ->

                        val imageView = v as ImageView

                        when (event.action) {

                            MotionEvent.ACTION_DOWN -> {
                                imageView.drawable?.setColorFilter(
                                    0x77FF4081,
                                    PorterDuff.Mode.SRC_ATOP
                                )
                                imageView.invalidate()
                            }

                            MotionEvent.ACTION_UP,
                            MotionEvent.ACTION_CANCEL -> {
                                imageView.drawable?.clearColorFilter()
                                imageView.invalidate()
                            }
                        }

                        false
                    }
                }
            }
        }

    }

}