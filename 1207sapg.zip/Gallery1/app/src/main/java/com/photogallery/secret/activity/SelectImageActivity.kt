package com.photogallery.secret.activity

import android.app.Activity
import android.media.MediaScannerConnection
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.AdapterView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.photogallery.R
import com.photogallery.databinding.ActivitySelectImageBinding
import com.photogallery.dialog.ActionConfirmationDialog
import com.photogallery.dialog.CopyMoveDialog
import com.photogallery.jobs.MediaLoaderX
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.secret.adapter.SelectAlbumAdapter
import com.photogallery.secret.adapter.SelectImageAdapter
import com.photogallery.secret.adapter.SelectImageListAdapter
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences
import com.photogallery.utils.Utils
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale

class SelectImageActivity : AppCompatActivity() {

    lateinit var binding: ActivitySelectImageBinding
    lateinit var preferences: Preferences
    var albumList: ArrayList<AlbumData> = ArrayList()
    val allImages: ArrayList<MediaData> = ArrayList()
    val selectedImageList: ArrayList<MediaData> = ArrayList()
    var spinnerAdapter: SelectAlbumAdapter? = null
    var pictures = ArrayList<Any>()
    var pictureAdapter: SelectImageAdapter? = null
    var selectImageAdapter: SelectImageListAdapter? = null
    var selectAlbumPath: String = ""
    var spinnerPos = -1
    var openType = 0
    lateinit var dropdownAnimation: Animation

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySelectImageBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        intView()
        intListener()
        setRvLayoutManager()
        loadBanner()
    }

    private fun intView() {

        binding.loutBottomSelect.visibility = View.GONE
        openType = intent.getIntExtra(Constant.EXTRA_SELECT_TYPE, 0)

        if (openType == Constant.SELECT_TYPE_CRATE_ALBUM) {
            selectAlbumPath = intent.getStringExtra(Constant.EXTRA_ALBUM_PATH) ?: ""
        }

        if (openType == Constant.SELECT_TYPE_HIDE) {
            binding.btDone.text = getString(R.string.hide)
        }
//        else if (openType == Constant.SELECT_TYPE_FAVORITE) {
//            binding.btDone.text = getString(R.string.done)
//        }

        preferences = Preferences(this)
        dropdownAnimation = AnimationUtils.loadAnimation(this, R.anim.dropdown_animation)
        getData()
        setSelectAdapter()
    }

    private fun loadBanner() {

    }

    private fun setSelectAdapter() {
        selectImageAdapter = SelectImageListAdapter(this, selectedImageList, deleteListener = {
            selectedImageList.removeAt(it)
            selectImageAdapter?.notifyDataSetChanged()
            pictureAdapter?.notifyDataSetChanged()
            checkSelectionEmpty()
        })
        binding.rvSelect.adapter = selectImageAdapter
    }

    private fun checkSelectionEmpty() {
        binding.loutBottomSelect.visibility =
            if (selectedImageList.isEmpty()) View.GONE else View.VISIBLE
        binding.tvImageSelect.text =
            "${selectedImageList.size} ${getString(R.string.items_selected)}"
    }

    var isSpinnerOpen = false
    var rotationAngle = 0f

    private fun intListener() {
        binding.icBack.setOnClickListener { finish() }
        binding.icDelete.setOnClickListener {
            val confirmationDialog = ActionConfirmationDialog(
                this,
                getString(R.string.clear_all),
                getString(R.string.clear_all_msg),
                getString(R.string.yes),
                positiveBtnClickListener = {
                    selectedImageList.clear()
                    selectImageAdapter?.notifyDataSetChanged()
                    pictureAdapter?.notifyDataSetChanged()
                    checkSelectionEmpty()
                },
                false,
                getString(R.string.no)
            )
            confirmationDialog.show()
        }

        binding.btDone.setOnClickListener {
            if (selectedImageList.isNotEmpty()) {
                if (openType == Constant.SELECT_TYPE_CRATE_ALBUM) {
                    CopyMoveDialog(this, { option ->
                        val file = File(selectAlbumPath)
                        if (!file.exists())
                            file.mkdirs()
                        if (option == 0) {
                            Utils.moveFiles(
                                this,
                                selectAlbumPath,
                                selectedImageList,
                                selectedImageList.size,
                                moveListener = {
                                    preferences.refreshMedia = true
                                    Toast.makeText(
                                        this,
                                        getString(R.string.import_successfully),
                                        Toast.LENGTH_SHORT
                                    ).show()
                                    finish()
                                }
                            )
                        } else if (option == 1) {

                            Utils.copyFiles(
                                this,
                                selectAlbumPath,
                                selectedImageList,
                                selectedImageList.size,
                                copyListener = {
                                    preferences.refreshMedia = true
                                    Toast.makeText(
                                        this,
                                        getString(R.string.import_successfully),
                                        Toast.LENGTH_SHORT
                                    ).show()
                                    finish()
                                }
                            )
                        }
                    }).show()

                } else if (openType == Constant.SELECT_TYPE_CRATE_PDF) {
                    submitPhoto()
                } else if (openType == Constant.SELECT_TYPE_HIDE) {
                    submitPhoto()
                } else if (openType == Constant.SELECT_TYPE_NOTE) {
                    submitPhoto()
                }
            }

//            if (selectedImageList.isNotEmpty()) {
//                if (openType == Constant.SELECT_TYPE_CRATE_ALBUM) {
//                    val file = File(selectAlbumPath)
//                    if (!file.exists())
//                        file.mkdirs()
//
//                    Utils.copyFiles(this, selectedImageList, selectAlbumPath, {
//                        preferences.refreshMedia = true
//                        Toast.makeText(
//                            this,
//                            getString(R.string.import_successfully),
//                            Toast.LENGTH_SHORT
//                        ).show()
//                        MediaScannerConnection.scanFile(
//                            this,
//                            arrayOf<String>(selectAlbumPath),
//                            null
//                        ) { path, uri -> }
//                        finish()
//                        sendEvent("refresh")
//                    })
////                    Utils.copyFiles(
////                        this,
////                        selectAlbumPath,
////                        selectedImageList,
////                        selectedImageList.size,
////                        copyListener = {
////
////                        }
////                    )
//                } else if (openType == Constant.SELECT_TYPE_HIDE) {
//                    submitPhoto()
//                } else if (openType == Constant.SELECT_TYPE_FAVORITE) {
//                    submitPhoto()
//                }
//            }
        }
        binding.spinner.viewTreeObserver?.addOnWindowFocusChangeListener { hasFocus -> //This updates the arrow icon up/down depending on Spinner opening/closing
            Log.e("spinnerTag", "addOnWindowFocusChangeListener $hasFocus ")
            if (hasFocus) {
                // spinner close
                rotationAngle = if (rotationAngle == 0f) 180f else 0f
                binding.ivDropDown.animate().rotation(rotationAngle).setDuration(500).start()
            } else {
                // spinner open
                rotationAngle = if (rotationAngle == 0f) 180f else 0f
                binding.ivDropDown.animate().rotation(rotationAngle).setDuration(500).start()
            }
        }
        binding.spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                Log.e("spinnerTag", "onItemSelected")
                if (position != -1)
                    binding.txtItemSpinner.text = albumList[position].title

                if (spinnerPos != position)
                    setImageAdapter(position)
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                Log.e("spinnerTag", "onNothingSelected")
            }

        }
    }

    private fun submitPhoto() {
        Constant.selectedImageList = ArrayList()
        Constant.selectedImageList.addAll(selectedImageList)
        setResult(Activity.RESULT_OK)
        finish()
    }

    private fun setImageAdapter(position: Int) {
        pictures.clear()
        pictures.addAll(albumList[position].folderImageList)
        Log.e("SelectImageActivity", "setImageAdapter:$position,pictures:${pictures.size}")
        pictureAdapter = SelectImageAdapter(
            this, pictures,
            selectedImageList,
            clickListener = {
//                val pictureData = pictures[it] as PictureData
//                if (pictureData.isCheckboxVisible) {
//                    pictureData.isSelected = !pictureData.isSelected
//                    pictureAdapter?.notifyItemChanged(it)
////                    setSelectedFile()
//                }

                if (pictures[it] is MediaData) {
                    val mediaData = pictures[it] as MediaData
                    mediaData.isSelected = !mediaData.isSelected
                    if (selectedImageList.contains(mediaData)) {
                        selectedImageList.remove(mediaData)
                    } else {
                        selectedImageList.add(mediaData)
                    }
                    pictureAdapter?.notifyItemChanged(it)
                    selectImageAdapter?.notifyDataSetChanged()
                    checkSelectionEmpty()
                }
            },
            headerSelectListener = {
                if (pictures[it] is AlbumData) {
                    val albumData = pictures[it] as AlbumData
                    val isSelectAll = !albumData.isSelected
                    albumData.isSelected = isSelectAll
                    var pos = it + 1
                    while (pos < pictures.size) {
                        if (pictures[pos] is MediaData) {
                            val model = pictures[pos] as MediaData
                            model.isSelected = isSelectAll
                            pos++
                            if (isSelectAll) {
                                if (!selectedImageList.contains(model)) {
                                    selectedImageList.add(model)
                                }
                            } else {
                                if (selectedImageList.contains(model)) {
                                    selectedImageList.remove(model)
                                }
                            }
                        } else if (pictures[pos] is AlbumData) {
                            break
                        }
                    }
                    selectImageAdapter?.notifyDataSetChanged()
                    pictureAdapter?.notifyDataSetChanged()
                    checkSelectionEmpty()
                }
            })

        binding.pictureRecycler.adapter = pictureAdapter
    }

    fun setSelectedFile() {

    }

    fun setRvLayoutManager() {
        val gridCount = preferences.getGridCount()
        val gridLayoutManager =
            GridLayoutManager(this, gridCount, RecyclerView.VERTICAL, false)
        binding.pictureRecycler.layoutManager = gridLayoutManager
        gridLayoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                if (position >= 0 && position < pictures.size) {
                    return if (pictureAdapter!!.getItemViewType(position) == pictureAdapter!!.ITEM_HEADER_TYPE) {
                        gridCount
                    } else 1
                } else {
                    return 1
                }
            }
        }
    }

    private fun setData() {
        binding.progressBar.visibility = View.GONE
        setEmptyData()
        checkSelectionEmpty()

        Log.e("SelectImageActivity", "setData.albumList:${albumList.size}")
        if (albumList.isNotEmpty()) {
            spinnerAdapter = SelectAlbumAdapter(this, albumList)
            binding.spinner.adapter = spinnerAdapter
            binding.spinner.setSelection(0)
//            setImageAdapter(0)
        }
    }

    private fun setEmptyData() {
        Log.e("SelectImageActivity", "setEmptyData")
        if (albumList != null && albumList.size != 0) {
            binding.pictureRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
        } else {
            binding.pictureRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
        }
    }

    private fun getData() {
        binding.progressBar.visibility = View.VISIBLE

        Log.e("SelectImageActivity", "startMediaLoader")
        MediaLoaderX(
            this,
            addCustomAlbum = false
        ).getAllData(onSuccess = { groupedMediaList, mediaList, mediaFolderList ->
            Log.e(
                "SelectImageActivity",
                "onSuccess.mediaList:${mediaList.size},albumList:${mediaFolderList.size}"
            )

            allImages.clear()
            allImages.addAll(mediaList)

            albumList.clear()
            albumList.addAll(mediaFolderList)

            Log.e("SelectImageActivity", "onSuccess.setData")
            runOnUiThread {
                setDataList()
            }
        }, onFailed = { error ->
            Log.e("SelectImageActivity", "onFailed.error:$error")
        })
//        Observable.fromCallable<Boolean> {
////            albumList.clear()
////            allImages.clear()
//            getImages()
//            true
//        }.subscribeOn(Schedulers.io())
//            .doOnError { throwable: Throwable? ->
//                runOnUiThread {
//                    setFilterData()
//                }
//            }
//            .subscribe { result: Boolean? ->
//                runOnUiThread {
//                    setFilterData()
//                }
//            }
    }

//    fun setFilterData() {
//        binding.progressBar.visibility = View.VISIBLE
//        Observable.fromCallable {
//            sortAlbumMain()
//            sortPhotos()
//            true
//        }.subscribeOn(Schedulers.io())
//            .doOnError { _: Throwable? ->
//                runOnUiThread { setDataList() }
//            }
//            .onErrorReturn { false }
//            .subscribe { _: Boolean? ->
//                runOnUiThread { setDataList() }
//            }
//    }

    private fun setDataList() {
        Observable.fromCallable {
            setList()
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread { setData() }
            }
            .onErrorReturn { false }
            .subscribe { _: Boolean? ->
                runOnUiThread { setData() }
            }
    }

    private fun setList() {

        if (allImages.isNotEmpty()) {
            val albumData = AlbumData()
            albumData.title = getString(R.string.all)
            albumData.mediaData = allImages
            albumList.add(0, albumData)
        }
        val format = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
        if (albumList.isNotEmpty()) {
            for (a in albumList.indices) {

//                val dateWisePictures = LinkedHashMap<String, ArrayList<MediaData>>()
                val dateWisePictures: LinkedHashMap<String, ArrayList<MediaData>> = linkedMapOf()
                val picturesList: ArrayList<Any> = ArrayList()
                for (pictureData in albumList[a].mediaData) {
                    val strDate = format.format(pictureData.date)
                    var imagesData1: ArrayList<MediaData> = ArrayList()
                    if (dateWisePictures.containsKey(strDate)) {
                        val list: ArrayList<MediaData>? = dateWisePictures[strDate]
                        if (!list.isNullOrEmpty())
                            imagesData1.addAll(list)
                    } else {
                        imagesData1 = ArrayList()
                    }
                    imagesData1.add(pictureData)
                    dateWisePictures[strDate] = imagesData1

                }
                val keys: Set<String> = dateWisePictures.keys
                val listKeys = ArrayList(keys)

                for (i in listKeys.indices) {
                    val imagesData = dateWisePictures[listKeys[i]]
                    if (imagesData != null && imagesData.size != 0) {
                        val bucketData = AlbumData(listKeys[i], imagesData)
                        picturesList.add(bucketData)
                        picturesList.addAll(imagesData)
                    }
                }

                albumList[a].folderImageList = picturesList
            }
        }

    }

}