package com.photogallery.activities

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.telephony.TelephonyManager
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.GravityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.doOnPreDraw
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.ViewPager
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.AdmobBanner
import com.adconfig.adsutil.admob.AdmobNative
import com.after.call.extensions.callerCadBaseConfig
import com.after.call.keep.AfterCallGlobal

import com.photogallery.BuildConfig
import com.google.android.material.snackbar.Snackbar
import com.google.android.play.core.install.model.InstallStatus
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import com.photogallery.R
import com.photogallery.adapter.AlbumListAdapter
import com.photogallery.adapter.PhotoAdapter
import com.photogallery.inapp_helper.AppUpdateInstallerListener
import com.photogallery.inapp_helper.AppUpdateInstallerManager
import com.photogallery.inapp_helper.InAppUpdateInstallerManager
import com.photogallery.base.BaseActivity
//import com.photogallery.browser.WebBrowserActivity
import com.photogallery.customview.MyGridLayoutManager
import com.photogallery.customview.MyRecyclerView
import com.photogallery.database.AppDatabase
import com.photogallery.databinding.ActivityHomeBinding
import com.photogallery.databinding.PopBottomMenuBinding
import com.photogallery.dialog.AlbumDetailsDialog
import com.photogallery.dialog.ActionConfirmationDialog

import com.photogallery.dialog.CreateAlbumDialog
import com.photogallery.dialog.DeleteDialog
import com.photogallery.dialog.DetailsDialog
import com.photogallery.dialog.DisplayedColumnsDialog
import com.photogallery.dialog.ExitConfirmationDialog
import com.photogallery.dialog.FilterMediaDialog
import com.photogallery.dialog.GroupDialog
import com.photogallery.dialog.HomeOptionsDialog
import com.photogallery.dialog.ProgressDialog
import com.photogallery.dialog.FileRenameDialog
import com.photogallery.dialog.FolderRenameDialog

import com.photogallery.dialog.SimpleMessageDialog
import com.photogallery.dialog.SimpleProgressDialog
import com.photogallery.dialog.SortingOptionsDialog
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.extension.beVisibleIf
import com.photogallery.extension.delayExecution
import com.photogallery.extension.getFinalUriFromPath
import com.photogallery.extension.getUriMimeType
import com.photogallery.extension.initFirebaseConfig
import com.photogallery.extension.isGif
import com.photogallery.extension.openEditorIntent
import com.photogallery.extension.scanPathRecursively
import com.photogallery.extension.showErrorToast
import com.photogallery.extension.toast
import com.photogallery.jobs.MediaContentObserver
//import com.photogallery.fragment.AlbumFragment
//import com.photogallery.fragment.PhotosFragment
import com.photogallery.jobs.MediaLoaderX
import com.photogallery.jobs.autoclean.startAutoCleanTrashWorker
import com.photogallery.jobs.fetchRecentMedia
import com.photogallery.jobs.startPlacesFetcher
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.notes.NotesActivity
import com.photogallery.secret.activity.PrivateActivity
import com.photogallery.secret.activity.SelectImageActivity
import com.photogallery.utils.Constant
import com.photogallery.utils.FastScroller
import com.photogallery.utils.MessageEvent
import com.photogallery.utils.PopupWindowHelper
import com.photogallery.utils.Preferences
import com.photogallery.utils.TYPE_GIFS
import com.photogallery.utils.TYPE_IMAGES
//import com.photogallery.utils.TYPE_PORTRAITS
//import com.photogallery.utils.TYPE_RAWS
//import com.photogallery.utils.TYPE_SVGS
import com.photogallery.utils.TYPE_VIDEOS
import com.photogallery.utils.Utils
import com.photogallery.utils.ensureBackgroundThread
import com.photogallery.utils.sendEvent
import com.photogallery.viewpager.PhotoVideoActivity
import com.photogallery.views.CommonPagerAdapter

import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.karumi.dexter.listener.PermissionDeniedResponse
import com.karumi.dexter.listener.PermissionGrantedResponse
import com.karumi.dexter.listener.single.PermissionListener
import com.photogallery.dialog.CallerPermissionDialog
import com.photogallery.dialog.RateUsDialog
import com.photogallery.dialog.UpdateDialog
import com.photogallery.extension.beGoneIf
import com.photogallery.extension.sendEmail
import com.photogallery.extension.updateStatusBarColor
import com.photogallery.jobs.PlacesLoader
import com.photogallery.jobs.startCategoryWorker
import com.photogallery.messaging.Notifier
import com.photogallery.model.UpdateModel
import com.photogallery.secret.LockSetActivity
import com.photogallery.utils.AdUtils
import com.photogallery.utils.GridScaleGestureManager
import com.photogallery.views.SwitchButton
import com.photogallery.views.bottomnav.NiceBottomBar
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class HomeActivity : BaseActivity() {

    lateinit var preferences: Preferences

    var selectedPhotosCount = 0
    var selectedAlbumCount = 0
    var allList = ArrayList<MediaData>()
    var pictures = ArrayList<Any>()
    var pictureAdapter: PhotoAdapter? = null
//    var videoAdapter: PhotoAdapter? = null

    var albumList: ArrayList<AlbumData> = ArrayList()
    var albumAdapter: AlbumListAdapter? = null

    var isFromNotification = false
    var mActivityName = ""

    private val dataBase: AppDatabase by lazy { AppDatabase.getInstance(this) }

    val pinList: ArrayList<String> = ArrayList()
    var isEmptyPhoto = false
    var isEmptyVideo = false
    var isEmptyAlbum = false

    var photosLoader: MediaLoaderX? = null

    private var mAlbumDragListener: MyRecyclerView.MyDragListener? = null
    private var mPhotosDragListener: MyRecyclerView.MyDragListener? = null
//    private var mVideoDragListener: MyRecyclerView.MyDragListener? = null

    private var lastLongPressedMedia = -1
    private var lastLongPressedAlbum = -1
    var needRefreshMedia = false
    var isSelectAll = false
    var imageFilePath = ""
    var tabPos = 0

    lateinit var binding: ActivityHomeBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        checkNotification(intent)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        updateStatusBarColor(ContextCompat.getColor(this, R.color.status_bar))
        preferences = Preferences(this)

        initView()
        startNewPhotoFetcher()
        startCleanRecycleBin()

        setRvLayoutDecoration()
        setRvLayoutManager()

        photosLoader = MediaLoaderX(
            this,
            sortOrder = preferences.getSortOrder("frag_1"),
            sortType = preferences.getSortType("frag_1"),
            addCustomAlbum = true,
            loadImage = true,
            loadVideo = true,
            prefKey = "frag_1"
        )
        sendEvent("get_data")

        sendEvent("fetch_places")
        sendEvent("fetch_category")
//        startPlacesFetcher()

    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        if (event.type.equals("get_data")) {
            getData()
        }

        if (event.type.equals("fetch_category")) {
            Log.i("PlacesWorker", "onMessageEvent.fetch_category")
            startCategoryWorker()
        }
        if (event.type.equals("fetch_places")) {
            Log.i("PlacesWorker", "onMessageEvent.fetch_places")
            startPlacesFetcher()
        }
        if (event.type.equals("refresh_map")) {
            initMapData()
        }
        if (event.type.equals("hideCamera")) {
            runOnUiThread {
                toggleCameraVisibility()
            }
        }
        if (event.type.equals("rename")) {
            if (event.data is String) scanPathRecursively(event.data)
        }
        if (event.type.equals("refresh_layoutmanager")) {
            delayExecution(800) {
                setRvLayoutManager()
            }
        }
        if (event.type.equals("refresh")) {
            needRefreshMedia = true
            preferences.refreshMedia = true
//            delayExecution(50) {
//                if (albumFragment != null) albumFragment.refreshData()
//                if (photosFragment != null) photosFragment.refreshData()
//            }
        }
    }

    private fun getData() {
//        albumLoader?.refreshLoader("frag_0")
        photosLoader?.refreshLoader("frag_1")
//        timeLineLoader?.refreshLoader("frag_0")
        getAlbumData()
        getPhotoData()

        //detectRegion()
        binding.drawerContent.tvAppVersion.text = BuildConfig.VERSION_NAME
    }

    private fun detectRegion() {
        val region = Locale.getDefault().country
        Log.d("detectRegion", "Device Region: $region")

        val telephonyManager = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        val simCountry = telephonyManager.simCountryIso?.uppercase(Locale.US)
        val networkCountry = telephonyManager.networkCountryIso?.uppercase(Locale.US)

        Log.d("detectRegion", "SIM Country: $simCountry, Network Country: $networkCountry")
    }

//    private fun initMap(savedInstanceState: Bundle?) {
//        try {
//            binding.exploreTab.map.onCreate(savedInstanceState)
//            binding.exploreTab.map.getMapAsync { map ->
////                map.uiSettings.setAllGesturesEnabled(false)
//                isMapLoaded = true
//                googleMap = map
////            googleMap?.isMyLocationEnabled = true
//                googleMap?.setOnMarkerClickListener { marker ->
//                    val intent = Intent(this@HomeActivity, MapExploreActivity::class.java)
//                    intent.putExtra("pos", 0)
//                    startActivity(intent)
//                    true
//                }
//                getImageOnMap()
//            }
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
//    }

    private fun initMapData() {
        try {
            Log.e("initMap", "initMapData")
            PlacesLoader(this@HomeActivity).preparePlaceModel(onSuccess = { placeModelList ->
                Constant.placeList = placeModelList
//                placeList = placeModelList

//                mapPlaces()
//                CoroutineScope(Dispatchers.Main).launch {
//                    getImageOnMap()
//                }
            }, onFailed = {

            })
        } catch (e: Exception) {
            Log.e("initMap", "initMapData:Exception:$e")
        }
    }


    private fun getAlbumData() {

//        binding.albumTab.albumRecycler.suppressLayout(true)
//        //binding.albumTab.swipeRefreshAlbum.isRefreshing = true
//        binding.albumTab.refreshAlbum.beVisible()
//
//        albumLoader?.destroyLoader()
//        albumLoader?.getAllAlbum({ customAlbumList, allAlbumList, mediaList ->
//            albumList.clear()
//            albumList.addAll(customAlbumList)
//            Constant.deviceAlbumList.clear()
//            Constant.deviceAlbumList.addAll(allAlbumList)
//
//            Log.e("AlbumRenameDialog", "albumList.size:${albumList.size}")
//
//            runOnUiThread {
//                binding.albumTab.albumRecycler.suppressLayout(false)
////                binding.albumTab.swipeRefreshAlbum.isRefreshing = false
//                binding.albumTab.refreshAlbum.beGone()
//                setAlbumData()
//            }
//        })

//        val isGridShow = preferences.getShowGrid() ?: false
//        if (isGridShow) {
////            val layoutManager = binding.albumTab.albumRecycler.layoutManager as MyGridLayoutManager
////            mAlbumZoomListener = object : MyRecyclerView.MyZoomListener {
////                override fun zoomIn() {
////                    if (layoutManager.spanCount > 2) {
////                        reduceAlbumGrid()
//////                        getRecyclerAdapter()?.finishActMode()
////                    }
////                }
////
////                override fun zoomOut() {
////                    if (layoutManager.spanCount < MAX_COLUMN_COUNT_ALBUM) {
////                        increaseAlbumGrid()
//////                        getRecyclerAdapter()?.finishActMode()
////                    }
////                }
////            }
//        } else {
////            mAlbumZoomListener = null
//        }
//        binding.albumTab.albumRecycler.setupZoomListener(mAlbumZoomListener)

        mAlbumDragListener = object : MyRecyclerView.MyDragListener {

            override fun selectItem(position: Int) {
                toggleAlbumSelection(true, position, true)
            }

            override fun selectRange(
                initialSelection: Int, lastDraggedIndex: Int, minReached: Int, maxReached: Int,
            ) {
                selectAlbumRange(
                    initialSelection,
                    Math.max(0, lastDraggedIndex),
                    Math.max(0, minReached),
                    maxReached
                )
                if (minReached != maxReached) {
                    lastLongPressedAlbum = -1
                }
            }

        }
        binding.albumTab.albumRecycler.setupDragListener(mAlbumDragListener)
    }

    private fun getPhotoData() {

        binding.albumTab.albumRecycler.suppressLayout(true)
        binding.albumTab.refreshAlbum.beVisible()

//        binding.videosTab.pictureRecycler.suppressLayout(true)
//        binding.videosTab.refreshPhotos.beVisible()

        binding.photosTab.pictureRecycler.suppressLayout(true)
        binding.photosTab.refreshPhotos.beVisible()

        photosLoader?.destroyLoader()
        photosLoader?.getAllMedia(onSuccess = { customAlbumList,
                                                allAlbumList,
                                                groupedMediaList,
                                                mediaList ->
            allList.clear()
            allList.addAll(mediaList)

            pictures.clear()
            pictures.addAll(groupedMediaList)

            albumList.clear()
            albumList.addAll(customAlbumList)
            Constant.deviceAlbumList.clear()
            Constant.deviceAlbumList.addAll(allAlbumList)

            Log.e("AlbumRenameDialog", "albumList.size:${albumList.size}")

            runOnUiThread {
                binding.albumTab.albumRecycler.suppressLayout(false)
                binding.albumTab.refreshAlbum.beGone()
                setAlbumData()

                binding.photosTab.pictureRecycler.suppressLayout(false)
                binding.photosTab.refreshPhotos.beGone()

                setPhotoData()
            }
        })
    }

    private fun setPhotoGroup() {
        binding.photosTab.refreshPhotos.beVisible()
        val currentGrouping = preferences.getGroupBy()
        val groupOrder = preferences.getGroupOrderBy()

//        val videoOnly: ArrayList<MediaData> = videos
//            .filterIsInstance<MediaData>()
//            .toCollection(ArrayList())
        val photosOnly: ArrayList<MediaData> = pictures
            .filterIsInstance<MediaData>()
            .toCollection(ArrayList())


//        photosLoader?.applyMediaGrouping(
//            videoOnly,
//            currentGrouping = currentGrouping,
//            groupOrder = groupOrder
//        ) { groupedMediaList ->
//            Log.e("PhotosFragment", "groupedMediaList size==>> ${groupedMediaList.size}")
//            videos.clear()
//            videos.addAll(groupedMediaList)
//            setPhotoData()
//        }
        photosLoader?.applyMediaGrouping(
            photosOnly,
            currentGrouping = currentGrouping,
            groupOrder = groupOrder
        ) { groupedMediaList ->
            Log.e("PhotosFragment", "groupedMediaList size==>> ${groupedMediaList.size}")
            pictures.clear()
            pictures.addAll(groupedMediaList)
            binding.photosTab.refreshPhotos.beGone()
            setPhotoData()
        }
    }

    private fun setAlbumData() {
        runOnUiThread {
            //binding.albumTab.swipeRefreshAlbum.isRefreshing = false
            binding.albumTab.refreshAlbum.beGone()

        }

        binding.albumTab.albumRecycler.suppressLayout(false)
        if (albumAdapter != null) {
            binding.albumTab.albumRecycler.post {
                if (albumAdapter != null) {
                    albumAdapter?.submitList(albumList)
                    albumAdapter?.notifyItemRangeChanged(0, albumList.size)
                }
            }
        } else initAlbumAdapter()
        setEmptyAlbum()
    }

    private fun setPhotoData() {
        runOnUiThread {
            binding.photosTab.refreshPhotos.beGone()
        }

        binding.photosTab.pictureRecycler.suppressLayout(false)

        if (pictureAdapter != null) {
            binding.photosTab.pictureRecycler.post {
                if (pictureAdapter != null) {
                    //pictureAdapter?.notifyDataSetChanged()
                    pictureAdapter?.submitList(pictures)
                    pictureAdapter?.notifyItemRangeChanged(0, pictures.size)
                }
            }
        } else initPhotoAdapter()
        setEmptyPhoto()

        mPhotosDragListener = object : MyRecyclerView.MyDragListener {
            override fun selectItem(position: Int) {
                togglePictureSelection(true, position, true)
            }

            override fun selectRange(
                initialSelection: Int,
                lastDraggedIndex: Int,
                minReached: Int,
                maxReached: Int
            ) {
                selectPictureRange(
                    initialSelection,
                    Math.max(0, lastDraggedIndex),
                    Math.max(0, minReached),
                    maxReached
                )
                if (minReached != maxReached) {
                    lastLongPressedMedia = -1
                }
            }

        }
        binding.photosTab.pictureRecycler.setupDragListener(mPhotosDragListener)

    }

//    private fun setVideoData() {
//
//
//        binding.videosTab.pictureRecycler.suppressLayout(false)
//
//        if (videoAdapter != null) {
//            binding.videosTab.pictureRecycler.post {
//                if (videoAdapter != null) {
//                    //pictureAdapter?.notifyDataSetChanged()
//                    videoAdapter?.submitList(videos)
//                    videoAdapter?.notifyItemRangeChanged(0, videos.size)
//                }
//            }
//        } else initVideoAdapter()
//        setEmptyVideo()
//
//        mVideoDragListener = object : MyRecyclerView.MyDragListener {
//            override fun selectItem(position: Int) {
//                togglePictureSelection(true, position, true)
//            }
//
//            override fun selectRange(
//                initialSelection: Int,
//                lastDraggedIndex: Int,
//                minReached: Int,
//                maxReached: Int
//            ) {
//                selectVideoRange(
//                    initialSelection,
//                    Math.max(0, lastDraggedIndex),
//                    Math.max(0, minReached),
//                    maxReached
//                )
//                if (minReached != maxReached) {
//                    lastLongPressedMedia = -1
//                }
//            }
//
//        }
//        binding.videosTab.pictureRecycler.setupDragListener(mVideoDragListener)
//
//    }

    var createPdfLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == AppCompatActivity.RESULT_OK) {
            Utils.generatePdf(this@HomeActivity, Constant.selectedImageList)
        }
    }

    private fun checkNotification(mIntent: Intent) {
        if (mIntent.hasExtra("activity") && mIntent.hasExtra("isFromNotification")) {
            isFromNotification = mIntent.getBooleanExtra("isFromNotification", false)
            mActivityName = mIntent.getStringExtra("activity") ?: ""
            var initialLocationTitle = mIntent.getStringExtra("initialLocationTitle") ?: ""

            val progressDialog = SimpleProgressDialog(
                this@HomeActivity,
                getString(R.string.please_wait),
            )
            progressDialog.setCancelable(false)

            if (!mActivityName.contains("recent")) progressDialog.show()

//            val locationId = intent.getLongExtra("locationId", 0L)
//            val latitude = intent.getFloatExtra("latitude", 0f)
//            val longitude = intent.getFloatExtra("longitude", 0f)
            intent.putExtra("activity", "")
            intent.putExtra("initialLocationTitle", "")
            intent.putExtra("isFromNotification", false)
            intent.data = null
            delayExecution(2500) {
                if (progressDialog != null
                    && progressDialog.isShowing
                    && !isFinishing
                    && !isDestroyed
                ) progressDialog.dismiss()

                if (isFromNotification && mActivityName.isNotEmpty()) {
                    try {
                        val intent = if (mActivityName.contains("setting")) {
                            Intent(
                                this@HomeActivity,
                                SettingActivity::class.java
                            ).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                        } else if (mActivityName.contains("language")) {
                            Intent(
                                this@HomeActivity,
                                LanguageSelectionActivity::class.java
                            ).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                        }
//                        else if (mActivityName.contains("cleaner")) {
//                            Intent(this@HomeActivity, RecoverMediaActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
//                        }
                        else if (mActivityName.contains("map")) {
                            Intent(this@HomeActivity, LocationAlbumActivity::class.java).addFlags(
                                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                            )
                                .putExtra("initialLocationTitle", initialLocationTitle)
//                                .putExtra("locationId", locationId)
//                                .putExtra("latitude", latitude)
//                                .putExtra("longitude", longitude)
                        } else if (mActivityName.contains("favorite")) {
                            Intent(this@HomeActivity, FavoritesListActivity::class.java).addFlags(
                                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                            )
                        } else if (mActivityName.contains("recent")) {
                            val recentList = fetchRecentMedia(this@HomeActivity)
                            val albumData = AlbumData(
                                getString(R.string.recent),
                                recentList as ArrayList<MediaData>
                            )
                            Constant.albumData = AlbumData(
                                albumData.title,
                                albumData.mediaData,
                                albumData.folderPath,
                                albumData.date,
                                albumData.fileSize
                            )
                            Intent(this@HomeActivity, ImageGalleryActivity::class.java).addFlags(
                                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                            )
                                .putExtra("folderPath", "${albumData.folderPath}")
                        } else null

                        isFromNotification = false
                        mActivityName = ""
                        initialLocationTitle = ""
                        if (intent != null) startActivity(intent)
                    } catch (e: Exception) {
                        Log.w("TAG", "Exception.002:$e")
                    }
                }
            }
        }
    }

    public fun openImageList(albumData: AlbumData) {
        Constant.albumData = AlbumData(
            albumData.title,
            albumData.mediaData,
            albumData.folderPath,
            albumData.date,
            albumData.fileSize
        )
        val intent = Intent(this@HomeActivity, ImageGalleryActivity::class.java)
        intent.putExtra("folderPath", "${albumData.folderPath}")
        intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT)
        startActivity(intent)
//        setBackAlbumData()

    }

//    public fun setBackAlbumData() {
//        Constant.albumList.clear()
//        for (albumData in albumList) {
//            Constant.albumList.add(
//                AlbumData(
//                    albumData.title,
//                    albumData.mediaData,
//                    albumData.folderPath,
//                    albumData.date,
//                    albumData.fileSize
//                )
//            )
//        }
//    }

    private fun initView() {
        //adsPref = PrefCalls(this)

//        else {
//            Log.e("native_exit", "preferences.appOpenCounter001:${preferences.appOpenCounter}")
//            var appOpenCounter = preferences.appOpenCounter
//            appOpenCounter += 1
//            preferences.appOpenCounter = appOpenCounter
//            Log.e("native_exit", "preferences.appOpenCounter002:${appOpenCounter}")
//        }

        if (preferences.isFirstTimeInstall) {
            preferences.isFirstTimeInstall = false
        }

        //needDialog = adsPref.firstTimeDialog

//        CoroutineScope(Dispatchers.IO).launch {
        setTab()
        setToolbarSelectionMaintain(false, 0, false)
//        }

        intListener()
        initPhotoListener()
        initAlbumListener()
        initExploreListener()

        val remoteConfig = FirebaseRemoteConfig.getInstance()
        checkForceAppUpdate(remoteConfig)
//        checkInAppUpdate()

        Log.e("native_exit", "delayExecution")
        initFirebaseConfig {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                askNotifications()
            } else {
                Notifier.showHomeNotification(this@HomeActivity)
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    private fun askNotifications() {
        Log.e("POST_NOTIFICATIONS", "askNotifications")
        Dexter.withContext(this@HomeActivity)
            .withPermission(
                Manifest.permission.POST_NOTIFICATIONS
            )
            .withListener(object : PermissionListener {
                override fun onPermissionGranted(p0: PermissionGrantedResponse?) {
                    Log.e("POST_NOTIFICATIONS", "showHomeNotification")
                    Notifier.showHomeNotification(this@HomeActivity)
                    if (callerCadBaseConfig.callerCadEnable) {
                        checkCaller()
                    }
                }

                override fun onPermissionDenied(PermissionDeniedResponse: PermissionDeniedResponse?) {
                    Log.e(
                        "POST_NOTIFICATIONS",
                        "onPermissionDenied:${PermissionDeniedResponse?.isPermanentlyDenied}"
                    )
                    if (PermissionDeniedResponse?.isPermanentlyDenied!!) {
                        //showPermissionDeniedDialog(getString(R.string.permission_Needed), getString(R.string.notification_permission_message))
                        showPermissionDeniedDialog(
                            getString(R.string.permission_needed),
                            "Enable notification permission to stay updated with important alerts and updates."
                        )
                    } else {
//                        if (callerCadBaseConfig.callerCadEnable) {
//                            checkCaller()
//                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    p0: PermissionRequest?,
                    token: PermissionToken?
                ) {
                    token?.continuePermissionRequest()
                    Log.e("POST_NOTIFICATIONS", "onPermissionRationaleShouldBeShown")
                }

            }).check()
    }

    var needDialog = true
    private fun checkCaller() {
        Log.e("checkCaller", "001")
        val readPhoneState =
            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == 0
        val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
        if (readPhoneState && canDrawOverlays && callerCadBaseConfig.isShowCallInfo) {
            binding.libraryTab.llCaller.beGone()
            setCallerImageList()
//            binding.libraryTab.llCallerSettings.beVisible()
//            setAutoStartPermission(this)
            Log.e("checkCaller.icCall", "icCall.beGone")
        } else {

            if (callerCadBaseConfig.callerCadEnable) {
                binding.libraryTab.llCaller.beVisible()
//                binding.libraryTab.llCallerSettings.beGone()
                if (!callerCadBaseConfig.callerCadPermissionDialogDismiss) {
                    showCallPermissionDialog()
                } else if (needDialog) {
                    //adsPref.firstTimeDialog = false
                    showCallPermissionDialog()
                }
            }
        }
    }

    private fun setCallerImageList() {
        preferences.setPortraitList(getPortrait4Caller(this@HomeActivity))
    }

    private fun getPortrait4Caller(mContext: Context): ArrayList<String> {

        val imageList = ArrayList<String>()

        try {

            val uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI

            val projection = arrayOf(
                MediaStore.Images.Media.DATA,
                MediaStore.Images.Media.WIDTH,
                MediaStore.Images.Media.HEIGHT
            )

            val cursor = mContext.contentResolver.query(
                uri,
                projection,
                null,
                null,
                MediaStore.Images.Media.DATE_MODIFIED + " DESC"
            )

            // no data available
            if (cursor == null || cursor.count == 0) {
                return imageList
            }

            cursor.use {

                val pathColumn =
                    it.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)

                val widthColumn =
                    it.getColumnIndexOrThrow(MediaStore.Images.Media.WIDTH)

                val heightColumn =
                    it.getColumnIndexOrThrow(MediaStore.Images.Media.HEIGHT)

                while (it.moveToNext()) {

                    val path = it.getString(pathColumn) ?: continue

                    val width = it.getInt(widthColumn)
                    val height = it.getInt(heightColumn)

                    val isPortrait = height > width

                    if (isPortrait && File(path).exists()) {
                        imageList.add(path)
                    }

                    // stop when enough images collected
                    if (imageList.size >= 50) {
                        break
                    }
                }
            }

        } catch (e: Exception) {
            Log.e("AfterCall", "getPortraitRecentPhotos Exception: $e")
        }

        return imageList
    }

    var callerDialog: CallerPermissionDialog? = null

    private fun showCallPermissionDialog() {
        Log.e("checkCaller", "preferences.showCallPermissionDialog")
        callerDialog = CallerPermissionDialog(
            this, callerCadBaseConfig.callerCadPermissionDialogDismiss,
            {//positiveListener
                AdsConfig.isSystemDialogOpen = true
                Dexter.withContext(this@HomeActivity).withPermission(
                    Manifest.permission.READ_PHONE_STATE
                ).withListener(object : PermissionListener {
                    override fun onPermissionGranted(permissionGrantedResponse: PermissionGrantedResponse) {
                        Log.e("checkCaller", "onPermissionGranted")
                        if (Settings.canDrawOverlays(this@HomeActivity)) {
                            val readPhoneState =
                                ContextCompat.checkSelfPermission(
                                    this@HomeActivity,
                                    Manifest.permission.READ_PHONE_STATE
                                ) == 0
                            val canDrawOverlays =
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                    Settings.canDrawOverlays(this@HomeActivity)
                                } else {
                                    true
                                }
                            binding.libraryTab.llCaller.beGoneIf(canDrawOverlays && readPhoneState && callerCadBaseConfig.isShowCallInfo)
                            Log.e(
                                "checkCaller.icCall",
                                "icCall.beGoneIf.canDrawOverlays>$canDrawOverlays,readPhoneState>$readPhoneState"
                            )
                            callerDialog?.dismiss()
                        } else {
                            callerDialog?.dismiss()
                            requestSystemOverlayPermission()
                        }
//                    requestSystemOverlayPermission()
                    }

                    override fun onPermissionDenied(permissionDeniedResponse: PermissionDeniedResponse) {
                        Log.e("checkCaller", "onPermissionDenied")
                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        val uri = Uri.fromParts("package", packageName, null)
                        intent.data = uri
                        callerLauncher.launch(intent)
                        AdsConfig.isSystemDialogOpen = true
                        toast(
                            "Please allow phone permission to enable feature"
                        )
                        callerDialog?.dismiss()
                    }

                    override fun onPermissionRationaleShouldBeShown(
                        permissionRequest: PermissionRequest,
                        permissionToken: PermissionToken,
                    ) {
                        permissionToken.continuePermissionRequest()
                    }
                }).check()

            }, {//closeListener
//                var closeCounter = preferences.closeCounter
//                closeCounter++
//                preferences.closeCounter = closeCounter
                callerDialog?.dismiss()

                if (!callerCadBaseConfig.callerCadPermissionDialogDismiss) {
                    val calendar = Calendar.getInstance()
                    val format = SimpleDateFormat("dd/mm/yy", Locale.ENGLISH)
                    val today = format.format(calendar.timeInMillis)
                    AdsConfig.isSystemDialogOpen = true
                    //finishAffinity()
                }
            })
        callerDialog?.setOnDismissListener { dialogInterface: DialogInterface? ->
            val readPhoneState =
                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == 0
            val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Settings.canDrawOverlays(this)
            } else {
                true
            }

            if (callerCadBaseConfig.callerCadEnable) {
                binding.libraryTab.llCaller.beGoneIf(canDrawOverlays && readPhoneState && callerCadBaseConfig.isShowCallInfo)
                Log.e(
                    "checkCaller.icCall",
                    "setOnDismissListener.icCall.beGoneIf.canDrawOverlays>$canDrawOverlays,readPhoneState>$readPhoneState"
                )
            }

        }
        if (!isFinishing && !isDestroyed) {
            AdsConfig.isSystemDialogOpen = true
            callerDialog?.show()
        }
    }

    var callerLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { _ ->
            Log.e("checkCaller", "callerLauncher")
            val readPhoneState =
                ContextCompat.checkSelfPermission(
                    this@HomeActivity,
                    Manifest.permission.READ_PHONE_STATE
                ) == 0
            val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Settings.canDrawOverlays(this@HomeActivity)
            } else {
                true
            }

            binding.libraryTab.llCaller.beGoneIf(canDrawOverlays && readPhoneState && !callerCadBaseConfig.callerCadEnable && callerCadBaseConfig.isShowCallInfo)
            if (readPhoneState) {
                if (canDrawOverlays) {
                    callerDialog?.dismiss()
                } else {
                    requestSystemOverlayPermission()
                }
            } else checkCaller()

        }

    private fun requestSystemOverlayPermission() {
        AdsConfig.isSystemDialogOpen = true

        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:" + applicationContext.packageName)
        )

        try {
            startActivityForResult(intent, 101)
        } catch (e: Exception) {
            Log.e("printStackTrace", "printStackTrace:$e")
        }

//        Handler(Looper.getMainLooper()).postDelayed({
//            val intent1 = Intent(this@HomeActivity, SettingPermissionActivity::class.java)
//            intent1.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
//            startActivity(intent1)
//        }, 500)

    }


    private fun startCleanRecycleBin() {
        if (preferences.deleteAfter30Days) {
            CoroutineScope(Dispatchers.IO).launch {
                startAutoCleanTrashWorker()
            }
        }
    }

    private fun startNewPhotoFetcher() {
        if (!EventBus.getDefault().isRegistered(this)) EventBus.getDefault().register(this)
        MediaContentObserver.registerContentObserver(this)
    }

    fun setRvLayoutDecoration() {
        GridScaleGestureManager(
            recyclerView = binding.albumTab.albumRecycler,
            context = this,
            currentSpan = preferences.getAlbumGridCount(),
            minSpan = 2,
            maxSpan = 6
        ) { newSpan ->
            preferences.setAlbumGridCount(newSpan)
            setRvLayoutManager()
            binding.albumTab.albumRecycler.requestLayout()
            binding.albumTab.albumRecycler.invalidateItemDecorations()
        }
        GridScaleGestureManager(
            recyclerView = binding.photosTab.pictureRecycler,
            context = this,
            currentSpan = preferences.getGridCount(),
            minSpan = 2,
            maxSpan = 6
        ) { newSpan ->
            preferences.setGridCount(newSpan)
            setRvLayoutManager()
            binding.photosTab.pictureRecycler.requestLayout()
            binding.photosTab.pictureRecycler.invalidateItemDecorations()
        }
//        GridScaleGestureManager(
//            recyclerView = binding.videosTab.pictureRecycler,
//            context = this,
//            currentSpan = preferences.getGridCount(),
//            minSpan = 2,
//            maxSpan = 8
//        ) { newSpan ->
//            preferences.setGridCount(newSpan)
//            setRvLayoutManager()
//            binding.videosTab.pictureRecycler.requestLayout()
//            binding.videosTab.pictureRecycler.invalidateItemDecorations()
//        }
    }

    private fun setRvLayoutManager() {
        try {
            val gridCount = preferences.getGridCount()
            val layoutManager =
                binding.photosTab.pictureRecycler.layoutManager as MyGridLayoutManager

            layoutManager.spanCount = gridCount
            layoutManager.orientation = RecyclerView.VERTICAL
            layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int): Int {
                    if (position >= 0 && position < pictures.size) {
                        return if (pictureAdapter!!.getItemViewType(position) == pictureAdapter!!.ITEM_HEADER_TYPE) {
                            gridCount
                        } else 1
                    } else {
                        return 1
                    }
                }
            }
        } catch (e: Exception) {
        }
//        try {
//            val gridCount = preferences.getGridCount()
//            val layoutManager =
//                binding.videosTab.pictureRecycler.layoutManager as MyGridLayoutManager
//
//            layoutManager.spanCount = gridCount
//            layoutManager.orientation = RecyclerView.VERTICAL
//            layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
//                override fun getSpanSize(position: Int): Int {
//                    if (position >= 0 && position < videos.size) {
//                        return if (videoAdapter!!.getItemViewType(position) == videoAdapter!!.ITEM_HEADER_TYPE) {
//                            gridCount
//                        } else 1
//                    } else {
//                        return 1
//                    }
//                }
//            }
//        } catch (e: Exception) {
//        }

//        try {
//            binding.videosTab.pictureRecycler.post {
//                FastScroller(binding.videosTab.photosHandle).bind(binding.videosTab.pictureRecycler)
//            }
//        } catch (e: Exception) {
//        }

        try {
            val gridCount = preferences.getAlbumGridCount() ?: 0
            val isGridShow = preferences.getShowGrid() ?: false

            if (isGridShow) {
                val layoutManager =
                    binding.albumTab.albumRecycler.layoutManager as MyGridLayoutManager
                layoutManager.orientation = RecyclerView.VERTICAL
                layoutManager.spanCount = gridCount
                layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                    override fun getSpanSize(position: Int): Int {
                        if (position >= 0 && position < albumList.size) {
//                            if (albumAdapter!!.getItemViewType(position) == albumAdapter!!.ITEM_ALBUM_HEADER_TYPE) {
//                                return gridCount
//                            } else
                            if (albumAdapter!!.getItemViewType(position) == albumAdapter!!.ITEM_ALBUM_UTIL_TYPE) {
                                return gridCount
                            } else return 1
                        } else {
                            return 1
                        }
                    }
                }
            } else {
                val layoutManager =
                    binding.albumTab.albumRecycler.layoutManager as MyGridLayoutManager
                layoutManager.spanCount = 1
                layoutManager.orientation = RecyclerView.VERTICAL
                layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                    override fun getSpanSize(position: Int): Int {
                        return 1
                    }
                }
            }
        } catch (e: Exception) {
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        MediaContentObserver.unregisterContentObserver(this)
//        MediaContentObserver.unbindService()
        if (EventBus.getDefault().isRegistered(this)) EventBus.getDefault().unregister(this)
    }


    private fun setTab() {
        binding.groupToolbarHeader.visibility = View.VISIBLE
        toggleCameraVisibility()

        val commonPagerAdapter = CommonPagerAdapter()
        commonPagerAdapter.insertViewId(R.id.albumTab)
        commonPagerAdapter.insertViewId(R.id.photosTab)
//        commonPagerAdapter.insertViewId(R.id.videosTab)
//        commonPagerAdapter.insertViewId(R.id.storyTab)
        commonPagerAdapter.insertViewId(R.id.libraryTab)
        binding.viewPager.offscreenPageLimit = 3
        binding.viewPager.adapter = commonPagerAdapter

        //binding.bottomNavigation.setActiveItem()
        binding.bottomNavigation.setOnItemSelectedListener(object : NiceBottomBar.OnItemListener {
            override fun onItemLongClick(pos: Int) {
            }

            override fun onItemReselect(pos: Int) {
            }

            override fun onItemSelect(pos: Int) {
                when (pos) {
                    0 -> {
                        binding.viewPager.post {
                            binding.viewPager.currentItem = 0
                        }
                    }

                    1 -> {
                        binding.viewPager.post {
                            binding.viewPager.currentItem = 1
                        }
                    }

//                    2 -> {
//                        binding.viewPager.post {
//                            binding.viewPager.currentItem = 2
//                        }
//                    }

                    2 -> {
                        binding.viewPager.post {
                            binding.viewPager.currentItem = 2
                        }
                    }


                    else -> {
                        binding.viewPager.post {
                            binding.viewPager.currentItem = 0
                        }
                    }
                }
            }
        })

        binding.viewPager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int,
            ) {

            }

            override fun onPageSelected(position: Int) {
                when (position) {
                    0 -> {
                        //binding.bottomNavigation.selectedItemId = R.id.tab1
                        binding.bottomNavigation.setActiveItem(0)
                    }

                    1 -> {
                        //binding.bottomNavigation.selectedItemId = R.id.tab2
                        binding.bottomNavigation.setActiveItem(1)
                    }

                    2 -> {
                        //binding.bottomNavigation.selectedItemId = R.id.tab3
                        binding.bottomNavigation.setActiveItem(2)
                    }

                    3 -> {
                        //binding.bottomNavigation.selectedItemId = R.id.tab4
                        binding.bottomNavigation.setActiveItem(3)
                    }
//                    4 -> {
//                        //binding.bottomNavigation.selectedItemId = R.id.tab5
//                        binding.bottomNavigation.setActiveItem(4)
//                    }

//                    2 -> {
//                        var isEmpty = false
//                        isEmpty = isEmptyAlbum && isEmptyPhoto
//                        setEmptyData(isEmpty)
//
//                        binding.bottomNavigation.selectedItemId = R.id.tab3
//                    }
                }
//                binding.loutTab.onPageSelected(position)
                tabPos = position

//                if (position == 2 || position == 3) {
//                    if (binding.titleSwitcher.displayedChild != 1) {
//                        binding.titleSwitcher.displayedChild = 1
//                    }
//                } else if (position == 0 || position == 1) {
//                    if (binding.titleSwitcher.displayedChild != 0) {
//                        binding.titleSwitcher.displayedChild = 0
//                    }
//                }
//                if ((position == 2 || position == 3) && binding.titleSwitcher.displayedChild != 1) {
//                    binding.titleSwitcher.displayedChild = 1
//                } else if (binding.titleSwitcher.displayedChild == 1) {
//                    binding.titleSwitcher.displayedChild = 0
//                }

                Log.e("HomeActivity", "onPageSelected.refreshMedia:${preferences.refreshMedia}")
                if (preferences.refreshMedia) {
                    preferences.refreshMedia = false
                    getAlbumData()
                    getPhotoData()
                }

            }

            override fun onPageScrollStateChanged(state: Int) {

            }
        })

//        var isEmpty = false
//        isEmpty = isEmptyAlbum && isEmptyPhoto
//        setEmptyData(isEmpty)
    }


    private fun setEmptyPhoto() {
        if (pictures != null && pictures.size != 0) {
            isEmptyPhoto = false
            binding.photosTab.pictureRecycler.visibility = View.VISIBLE
            binding.photosTab.loutNoPhotos.visibility = View.GONE
        } else {
            isEmptyPhoto = true
            binding.photosTab.pictureRecycler.visibility = View.GONE
            binding.photosTab.loutNoPhotos.visibility = View.VISIBLE
        }
    }


    private fun setEmptyAlbum() {
        if (albumList != null && albumList.size != 0) {
            isEmptyAlbum = false
            binding.albumTab.albumRecycler.visibility = View.VISIBLE
            binding.albumTab.loutNoAlbum.visibility = View.GONE

        } else {
            isEmptyAlbum = true
            binding.albumTab.albumRecycler.visibility = View.GONE
            binding.albumTab.loutNoAlbum.visibility = View.VISIBLE
        }
    }

    private fun longClickListener(isShowSelection: Boolean, selected: Int, isAllSelect: Boolean) {
        Log.e("1712MG", "longClickListener.refreshMedia:${preferences.refreshMedia}")

        if (preferences.refreshMedia) {
            preferences.refreshMedia = false
            getAlbumData()
            getPhotoData()
        }

        setToolbarSelectionMaintain(
            isShowSelection,
            selected,
            isAllSelect
        )
    }


    var needToAddPin = false
    var needToRemovePin = false
    var mSelectedItem = 0
    private fun setToolbarSelectionMaintain(
        isShowSelection: Boolean,
        selectedItem: Int,
        isAllSelect: Boolean,
    ) {
        runOnUiThread {

            mSelectedItem = selectedItem
            binding.loutToolbar.visibility = View.VISIBLE
            pinList.clear()
            pinList.addAll(preferences.getPinAlbumList())

            needToAddPin = false
            needToRemovePin = false

            if (isShowSelection) {

//                binding.btnHide.visibility =
//                    if (binding.viewPager.currentItem == 2) View.GONE else View.VISIBLE
//                binding.btnMore.visibility =
//                    if (binding.viewPager.currentItem == 2) View.GONE else View.VISIBLE
                binding.btnPin.visibility =
                    if (binding.viewPager.currentItem == 0) View.VISIBLE else View.GONE
                binding.btnShare.visibility =
                    if (binding.viewPager.currentItem == 0) View.GONE else View.VISIBLE

            }

            if (binding.viewPager.currentItem == 0) {
                val selectedAlbum = getSelectedAlbum()
//            val selectImage: ArrayList<PictureData> = ArrayList()
                for (i in selectedAlbum.indices) {
                    val model: AlbumData = selectedAlbum[i] as AlbumData
                    if (pinList.contains(model.folderPath))
                        needToRemovePin = true
                    else
                        needToAddPin = true
                }
            }

            if (needToAddPin && needToRemovePin) {
                binding.btnPin.alpha = 0.5F
            } else if (needToAddPin) {
                binding.btnPin.alpha = 1.0F
                binding.txtPin.text = getString(R.string.pin)
            } else if (needToRemovePin) {
                binding.btnPin.alpha = 1.0F
                binding.txtPin.text = getString(R.string.unpin)
            }

            binding.groupToolbarSelectHeader.visibility =
                if (isShowSelection) View.VISIBLE else View.GONE

//        binding.viewPager.isUserInputEnabled = !isShowSelection
//        binding.viewPager.isEnabled = !isShowSelection
            binding.viewPager.setPagingEnabled(!isShowSelection)
            isSelectAll = isAllSelect

            binding.loutSelectOption.visibility =
                if (isShowSelection && selectedItem != 0) View.VISIBLE else View.GONE
//            binding.photosTab.llGroup.visibility = if (isShowSelection) View.GONE else View.VISIBLE
//            binding.albumTab.llFilter.visibility = if (isShowSelection) View.GONE else View.VISIBLE

//            if (binding.viewPager.currentItem == 2) {
//                binding.groupToolbarSettingHeader.visibility = View.GONE
//                binding.icCamera.visibility = View.GONE
//                binding.groupToolbarHeaderPrivate.visibility = if (isShowSelection) View.GONE else View.VISIBLE
//            } else {
            if (isShowSelection) {
                binding.groupToolbarHeader.visibility = View.GONE
                binding.icCamera.visibility = View.GONE
                binding.icSearch.visibility = View.GONE
            } else {
                binding.groupToolbarHeader.visibility = View.VISIBLE
                toggleCameraVisibility()
            }
//            }

//        binding.loutTab.visibility = if (isShowSelection) View.GONE else View.VISIBLE
//        binding.cardLoutTab.visibility = if (isShowSelection) View.GONE else View.VISIBLE
            binding.bottomNavigation.visibility = if (isShowSelection) View.GONE else View.VISIBLE
            binding.txtSelectCount.text = "$selectedItem ${getString(R.string.items_selected)}"
            setSelectAllColor()

        }
    }

    private fun toggleCameraVisibility() {
        //binding.icCamera.beGoneIf(preferences.hideCamera)
    }

    private fun setSelectAllColor() {
//        val color = ContextCompat.getColor(this, if (isSelectAll) R.color.black else R.color.un_check_color)
//        binding.icSelect.setColorFilter(color, PorterDuff.Mode.SRC_IN)
        binding.icSelect.setImageResource(if (isSelectAll) R.drawable.ic_select_all else R.drawable.ic_unselect_all)
    }

    private fun getSelectedAlbum(): ArrayList<AlbumData> {
        val selectAlbum: ArrayList<AlbumData> = ArrayList()
        for (i in albumList.indices) {
            if (albumList[i] != null) {
//                if (albumList[i] is PictureData) {
                val model: AlbumData = albumList[i] as AlbumData
                if (model.isSelected) {
                    selectAlbum.add(model)
//                        favList.add(model.filePath)
                }
//                }
            }
        }
        return selectAlbum
    }

    private fun getSelectedPhotos(): ArrayList<MediaData> {
        val selectImage: ArrayList<MediaData> = ArrayList()

        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is MediaData) {
                    val model: MediaData = pictures[i] as MediaData
                    if (model.isSelected) {
                        selectImage.add(model)
//                        favList.add(model.filePath)
                    }
                }
        }
        return selectImage
    }


    private fun getSelectedMedia(): ArrayList<MediaData> {
        val selectImage: ArrayList<MediaData> = ArrayList()
        if (binding.viewPager.currentItem == 0) {
            for (i in albumList.indices) {
                if (albumList[i] != null)
                    if (albumList[i].isSelected) {
                        val pictureList = albumList[i].mediaData
                        selectImage.addAll(pictureList)
                    }
            }

        } else if (binding.viewPager.currentItem == 1) {
            selectImage.addAll(getSelectedPhotos())
        }
//        else if (binding.viewPager.currentItem == 2) {
//            selectImage.addAll(getSelectedVideos())
//        }
        return selectImage
    }

    private fun getAlbumListForSelect() {
        setBackAlbumData()
    }

    public fun setBackAlbumData() {
        Constant.albumList.clear()
        for (albumData in albumList) {
            Constant.albumList.add(
                AlbumData(
                    albumData.title,
                    albumData.mediaData,
                    albumData.folderPath,
                    albumData.date,
                    albumData.fileSize
                )
            )
        }
    }

    override fun onResume() {
        super.onResume()
        setAppTheme()

        val readPhoneState =
            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == 0
        val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }

        Log.e(
            "checkCaller.icCall",
            "onResume.canDrawOverlays>$canDrawOverlays,readPhoneState>$readPhoneState"
        )
        if (callerCadBaseConfig.callerCadEnable) {
            if (canDrawOverlays && readPhoneState && callerCadBaseConfig.isShowCallInfo) {
                binding.libraryTab.llCaller.beGone()
                Log.e("checkCaller.icCall", "onResume.icCall.beGone")
            } else {
                binding.libraryTab.llCaller.beVisible()
                Log.e("checkCaller.icCall", "onResume.icCall.beVisible")
            }
        }

        Log.e("HomeActivity", "onResume.refreshMedia:${preferences.refreshMedia}")
        delayExecution(120) {
            if (preferences.refreshMedia || needRefreshMedia) {
                needRefreshMedia = false
                preferences.refreshMedia = false
                refreshData()
            }
        }

        if (preferences.scanMedia) {
            preferences.scanMedia = false
            try {
                ensureBackgroundThread {
                    scanPathRecursively(Constant.ROOT_PATH)
                }
            } catch (e: Exception) {
            }
        }
        loadPriorityAds()
    }

    private fun loadPriorityAds() {
        if (preferences.bannerPriority == "native") {
            AdmobNative().preLoad(this, AdUtils.getNativeID(this)) { isLoaded ->
                if (isLoaded) {
                    AdmobNative().showNativeAd(this, binding.frameAd)
                } else if (preferences.handleFailed) {
                    loadAdmobBanner()
                } else binding.frameAd.beGone()
            }
        } else if (preferences.bannerPriority == "banner") {
            AdmobBanner().preLoad(this, AdUtils.getBannerID(this)) { isLoaded ->
                if (isLoaded) {
                    AdmobBanner().showBannerAd(this, binding.frameAd)
                } else if (preferences.handleFailed) {
                    loadNativeBanner()
                } else binding.frameAd.beGone()
            }
        } else {
            binding.frameAd.beGone()
        }
    }

    private fun loadNativeBanner() {
        AdmobNative().preLoad(this, AdUtils.getNativeID(this)) { isLoaded ->
            if (isLoaded) {
                AdmobNative().showNativeAd(this, binding.frameAd)
            } else binding.frameAd.beGone()
        }
    }

    private fun loadAdmobBanner() {
        AdmobBanner().preLoad(this, AdUtils.getBannerID(this)) { isLoaded ->
            if (isLoaded) {
                AdmobBanner().showBannerAd(this, binding.frameAd)
            } else binding.frameAd.beGone()
        }
    }

    private fun refreshData() {
        delayExecution(150) {
            preferences.refreshMedia = false
            getData()
//            sendEvent("get_data")
        }
    }


    var isOpenCameraPermission: Boolean = false
    private fun requestPermission() {

        val list: ArrayList<String> = ArrayList()
        if (isOpenCameraPermission) {
            list.add(Manifest.permission.CAMERA)
        } else
            list.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            list.add(Manifest.permission.ACCESS_MEDIA_LOCATION)
        }

        Dexter.withContext(this@HomeActivity)
            .withPermissions(
                list
            )
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport?) {
                    report?.let {
                        if (report.areAllPermissionsGranted()) {
                            openCamera()
                        } else if (report.isAnyPermissionPermanentlyDenied) {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                            val uri = Uri.fromParts("package", packageName, null)
                            intent.data = uri
                            permissionLauncher.launch(intent)
                        } else {
                            toast(
                                if (isOpenCameraPermission) getString(R.string.permission_camera_toast_msg)
                                else getString(R.string.permission_toast_msg)
                            )
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: MutableList<PermissionRequest>?,
                    token: PermissionToken?,
                ) {
                    token?.continuePermissionRequest()
                }
            }).check()

    }

    private fun intListener() {

        binding.icDrawer.setOnClickListener {
            if (binding.drawerLay.isDrawerOpen(GravityCompat.START))
                binding.drawerLay.closeDrawer(GravityCompat.START)
            else binding.drawerLay.openDrawer(GravityCompat.START)
        }

        binding.drawerContent.loutDrawerMain.setOnClickListener {

        }
        intDrawerListener()

        binding.icSearch.setOnClickListener {
            startActivity(Intent(this, SearchActivity::class.java))
            getAlbumListForSelect()
        }
        binding.icCamera.setOnClickListener {
            openCamera()
        }

        var resultAll = 0
        resultAll += TYPE_IMAGES
        resultAll += TYPE_VIDEOS
        resultAll += TYPE_GIFS
//        resultAll += TYPE_RAWS
//        resultAll += TYPE_SVGS
//        resultAll += TYPE_PORTRAITS

        var resultPhoto = 0
        resultPhoto += TYPE_IMAGES
//        resultPhoto += TYPE_RAWS
//        resultPhoto += TYPE_SVGS
//        resultPhoto += TYPE_PORTRAITS

        var resultVideo = 0
        resultVideo += TYPE_VIDEOS

        var resultGif = 0
        resultGif += TYPE_GIFS

//        when (preferences.getFilterMedia()) {
//            resultAll -> {
//                binding.txtTitle.text = getString(R.string.all)
//            }
//
//            resultPhoto -> {
//                binding.txtTitle.text = getString(R.string.photos)
//            }
//
//            resultVideo -> {
//                binding.txtTitle.text = getString(R.string.videos)
//            }
//
//            resultGif -> {
//                binding.txtTitle.text = getString(R.string.gifs)
//            }
//        }

//        binding.txtTitle.setOnClickListener {
//            showHomeMenuFilter(binding.txtTitle)
//        }
        binding.icMenu.setOnClickListener {
            showMenu()
        }
        binding.icClose.setOnClickListener {
//            if (binding.viewPager.currentItem == 2) {
//                setCloseToolbar()
//                //refreshData()
//            } else
            if (binding.viewPager.currentItem == 1) {
                setCloseToolbar()
                //refreshData()
            } else if (binding.viewPager.currentItem == 0) {
                setCloseToolbar()
                //refreshData()
            }
        }
        binding.icSelect.setOnClickListener {
            isSelectAll = !isSelectAll
//            if (binding.viewPager.currentItem == 2) setVideosSelect(isSelectAll)
//            else
            if (binding.viewPager.currentItem == 1) setPhotosSelect(isSelectAll)
            else if (binding.viewPager.currentItem == 0) setAlbumSelect(isSelectAll)
            setSelectAllColor()
        }

        binding.btnShare.setOnClickListener {
            if (
                binding.viewPager.currentItem == 1
//                || binding.viewPager.currentItem == 2
            ) {
                if (selectedPhotosCount == 0) {
                    toast(getString(R.string.please_select_image))
                } else {
                    shareImages()
                }
            }
        }
        binding.btnPin.setOnClickListener {
            if (binding.viewPager.currentItem == 0) {
                if (needToAddPin && needToRemovePin) {
//                    binding.btnPin.alpha=0.5F
                } else if (needToAddPin) {
                    if (selectedAlbumCount == 0) {
                        toast(getString(R.string.please_select_album))
                    } else {
                        pinAlbum()
                    }
//                    binding.btnPin.alpha=1.0F
//                    binding.txtPin.text=getString(R.string.pin)
                } else if (needToRemovePin) {
                    if (selectedAlbumCount == 0) {
                        toast(getString(R.string.please_select_album))
                    } else {
                        unPinAlbum()
                    }
//                    binding.btnPin.alpha=1.0F
//                    binding.txtPin.text=getString(R.string.unpin)
                }
            }
        }

        binding.btnDelete.setOnClickListener {
            if (binding.viewPager.currentItem == 0) {
                if (selectedAlbumCount == 0) {
                    toast(getString(R.string.please_select_album))
                } else {
                    showDeleteDialog(getSelectedMedia())
                }
            } else if (binding.viewPager.currentItem == 1) {
                if (selectedPhotosCount == 0) {
                    toast(getString(R.string.please_select_image))
                } else {
                    showDeleteDialog(getSelectedMedia())
                }
            }
//            else if (binding.viewPager.currentItem == 2) {
//                if (selectedPhotosCount == 0) {
//                    toast(getString(R.string.PleaseSelectImage))
//                } else {
//                    showDeleteDialog(getSelectedMedia())
//                }
//            }
        }
        binding.btnHide.setOnClickListener {
            if (binding.viewPager.currentItem == 0) {
//                val selectedItem = getSelectedAlbum()
                if (selectedAlbumCount == 0) {
                    toast(getString(R.string.please_select_album))
                } else {
                    showHideDialog(getSelectedMedia())
                }
            } else if (binding.viewPager.currentItem == 1) {
//                val selectedItem = getSelectedPhotos()
                if (selectedPhotosCount == 0) {
                    toast(getString(R.string.please_select_image))
                } else {
                    showHideDialog(getSelectedMedia())
                }
            }
//            else if (binding.viewPager.currentItem == 2) {
////                val selectedItem = getSelectedPhotos()
//                if (selectedPhotosCount == 0) {
//                    toast(getString(R.string.PleaseSelectImage))
//                } else {
//                    showHideDialog(getSelectedMedia())
//                }
//            }
        }

        binding.btnMore.setOnClickListener {
            showDropDown(binding.btnMore)
        }

    }


    private fun closeDrawer() {
        if (binding.drawerLay.isDrawerOpen(GravityCompat.START)) {
            binding.drawerLay.closeDrawer(GravityCompat.START)
        }
    }

    private fun intDrawerListener() {
        binding.drawerContent.llDwHome.setOnClickListener {
            closeDrawer()
            binding.viewPager.currentItem = 0
        }
//        binding.drawerContent.llDwTheme.setOnClickListener {
//            val themeDialog = ThemeDialog(updateListener = {
//                val intent = Intent(this, HomeActivity::class.java)
//                finish()
//                overridePendingTransition(0, 0)
//                startActivity(intent)
//                overridePendingTransition(0, 0)
//            })
//            themeDialog.show(supportFragmentManager, themeDialog.tag)
//            closeDrawer()
//        }


        binding.drawerContent.llDwSetting.setOnClickListener {
            settingLauncher.launch(Intent(this, SettingActivity::class.java))
            closeDrawer()
        }
        binding.drawerContent.llDwLanguage.setOnClickListener {
            languageLauncher.launch(Intent(this, LanguageSelectionActivity::class.java))
            closeDrawer()
        }

        binding.drawerContent.llFeedbackSuggestions.setOnClickListener {
            closeDrawer()
            sendEmail("siapps.shivay@gmail.com", "GalleryApp Feedback/Suggestion", "Message:\n")
        }
        binding.drawerContent.llShare.setOnClickListener {
            closeDrawer()
            try {
                val sendIntent = Intent()
                sendIntent.action = Intent.ACTION_SEND
                sendIntent.putExtra(
                    Intent.EXTRA_TEXT,
                    "Check out the App at: https://play.google.com/store/apps/details?id=$packageName"
                )
                sendIntent.type = "text/plain"
                startActivity(sendIntent)
            } catch (e: Exception) {

            }
        }
        binding.drawerContent.llRateUs.setOnClickListener {
            closeDrawer()
            launchAppStore()
        }
        binding.drawerContent.llDwPrivacyPolicy.setOnClickListener {
            openPrivacyPolicy()
            closeDrawer()
        }

//        binding.drawerContent.llDwFavourite.setOnClickListener {
//            closeDrawer()
//            startActivity(Intent(this, FavoritesListActivity::class.java))
//            getAlbumListForSelect()
//        }
        binding.drawerContent.llDwPrivate.setOnClickListener {
            closeDrawer()
            val intent = Intent(this, LockSetActivity::class.java)
            lockActivityResultLauncher.launch(intent)
        }
//        binding.drawerContent.llDwRecentlyDelete.setOnClickListener {
//            startActivity(Intent(this, RecentlyDeleteActivity::class.java))
//            closeDrawer()
//            getAlbumListForSelect()
//        }
//        binding.drawerContent.llMaps.setOnClickListener {
//            startActivity(Intent(this, LocationAlbumActivity::class.java))
//        }
//        binding.drawerContent.llNote.setOnClickListener {
//            startActivity(Intent(this, NotesActivity::class.java))
//        }
//        binding.drawerContent.llTimeLine.setOnClickListener {
//            startActivity(Intent(this, TimeLineActivity::class.java))
//        }
//        binding.drawerContent.llPdfList.setOnClickListener {
//            startActivity(Intent(this@HomeActivity, PdfListActivity::class.java))
//        }
//        binding.drawerContent.llCreatePdf.setOnClickListener {
//            val intent = Intent(this@HomeActivity, SelectImageActivity::class.java)
//            intent.putExtra(Constant.EXTRA_SELECT_TYPE, Constant.SELECT_TYPE_CRATE_PDF)
//            intent.putExtra(Constant.EXTRA_INCLUDE_VIDEO, false)
//            createPdfLauncher.launch(intent)
//        }
//        binding.drawerContent.llDwDuplicate.setOnClickListener {
//            startActivity(Intent(this, StorageScanActivity::class.java))
//            closeDrawer()
//        }
//        binding.drawerContent.llDwSetting.setOnClickListener {
//            settingLauncher.launch(Intent(this, SettingActivity::class.java))
//            closeDrawer()
//        }
//        binding.drawerContent.llDwLanguage.setOnClickListener {
//            languageLauncher.launch(Intent(this, LanguageSelectionActivity::class.java))
//            closeDrawer()
//        }
    }

    private fun launchAppStore() {
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("http://play.google.com/store/apps/details?id=${packageName}")
        )
        startActivity(intent)
    }

    fun openPrivacyPolicy() {
        val url = getPrivacyPolicy()
        if (url != null && url.isNotEmpty()) {
            try {
                val builder: CustomTabsIntent.Builder = CustomTabsIntent.Builder()
                builder.setToolbarColor(ContextCompat.getColor(this, R.color.white))
                val customTabsIntent: CustomTabsIntent = builder.build()
                customTabsIntent.intent.setPackage("com.android.chrome")
                customTabsIntent.launchUrl(this, Uri.parse(url))

            } catch (e: Exception) {
                val i = Intent(Intent.ACTION_VIEW)
                i.data = Uri.parse(url)
                startActivity(i)
            }
        }
    }

    var languageLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val intent = intent
                finish()
                overridePendingTransition(0, 0)
                startActivity(intent)
                overridePendingTransition(0, 0)
            }
        }


    fun showPermissionDeniedDialog(dialogTitle: String, dialogMsg: String) {
        try {
            val simpleMessageDialog =
                SimpleMessageDialog(this@HomeActivity, dialogTitle, dialogMsg, {
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    val uri = Uri.fromParts("package", packageName, null)
                    intent.data = uri
                    startActivity(intent)
                }, {

                })
            simpleMessageDialog.setCancelable(false)
            simpleMessageDialog.show()
        } catch (e: Exception) {
        }
    }

    private fun initPhotoListener() {

        binding.photosTab.ivScrollTopPhotos.setOnClickListener {
//            binding.pictureRecycler.smoothScrollToPosition(0)
            binding.photosTab.pictureRecycler.scrollToPosition(0)
            binding.photosTab.ivScrollTopPhotos.beGone()
//            binding.pictureRecycler.smoothScrollBy()
        }
        binding.photosTab.root.doOnPreDraw {
            binding.photosTab.pictureRecycler.addOnScrollListener(object :
                RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    val firstPositon =
                        (binding.photosTab.pictureRecycler.layoutManager as MyGridLayoutManager).findFirstVisibleItemPosition()
                    binding.photosTab.ivScrollTopPhotos.beVisibleIf(firstPositon > 3)
//                    binding.photosTab.llGroup.beGoneIf(firstPositon >= 3)

//                    if (firstPositon > 0) {
////                        setBubbleText(pictureAdapter?.getBubbleText(firstPositon)!!)
//                        val str = pictureAdapter?.getBubbleText(firstPositon)!!
//                        if (str.isNotEmpty()) binding.photosTab.photosBubbleText.text = str
//                        binding.photosTab.photosBubble.beVisible()
//                    } else {
//                        binding.photosTab.photosBubble.beGone()
//                    }
                }
            })
        }
    }

    private fun initAlbumListener() {
        binding.albumTab.ivScrollTopAlbum.setOnClickListener {
            binding.albumTab.albumRecycler.scrollToPosition(0)
            binding.albumTab.ivScrollTopAlbum.beGone()
        }
        binding.albumTab.root.doOnPreDraw {
            binding.albumTab.albumRecycler.addOnScrollListener(object :
                RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    val firstPositon =
                        (binding.albumTab.albumRecycler.layoutManager as MyGridLayoutManager).findFirstVisibleItemPosition()
                    binding.albumTab.ivScrollTopAlbum.beVisibleIf(firstPositon > 3)
//                    binding.albumTab.llFilter.beGoneIf(firstPositon >= 3)
                }
            })
        }
    }

    private fun initExploreListener() {

        binding.libraryTab.llCaller.setOnClickListener {
            val readPhoneState =
                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == 0
            val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Settings.canDrawOverlays(this)
            } else {
                true
            }
            Log.e("checkCaller", "readPhoneState:$readPhoneState")
            Log.e("checkCaller", "canDrawOverlays:$canDrawOverlays")

            if (readPhoneState && canDrawOverlays) {
                callerCadBaseConfig.isShowCallInfo = true
                binding.libraryTab.cbCall.isChecked = true
                //AfterCallGlobal.openAfterCallSettingScreen(this)
            } else checkCaller()
        }
        binding.libraryTab.ivCaller.setOnClickListener {
            val readPhoneState =
                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == 0
            val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Settings.canDrawOverlays(this)
            } else {
                true
            }
            Log.e("checkCaller", "readPhoneState:$readPhoneState")
            Log.e("checkCaller", "canDrawOverlays:$canDrawOverlays")

            if (readPhoneState && canDrawOverlays) {
                callerCadBaseConfig.isShowCallInfo = true
                binding.libraryTab.cbCall.isChecked = true
                //AfterCallGlobal.openAfterCallSettingScreen(this)
            } else checkCaller()
        }

        binding.libraryTab.llFavourite.setOnClickListener {
            closeDrawer()
            startActivity(Intent(this, FavoritesListActivity::class.java))
            getAlbumListForSelect()
        }
        binding.libraryTab.llVault.setOnClickListener {
            closeDrawer()
            val intent = Intent(this, LockSetActivity::class.java)
            lockActivityResultLauncher.launch(intent)
        }
        binding.libraryTab.llRecentlyDelete.setOnClickListener {
            startActivity(Intent(this, RecentlyDeleteActivity::class.java))
            closeDrawer()
            getAlbumListForSelect()
        }
        binding.libraryTab.llMaps.setOnClickListener {
            startActivity(Intent(this, LocationAlbumActivity::class.java))
        }
        binding.libraryTab.llNotes.setOnClickListener {
            startActivity(Intent(this, NotesActivity::class.java))
        }
        binding.libraryTab.llPdfList.setOnClickListener {
            startActivity(Intent(this@HomeActivity, PdfListActivity::class.java))
        }
        binding.libraryTab.llMoments.setOnClickListener {
            startActivity(Intent(this@HomeActivity, CategoriesListActivity::class.java))
        }
        binding.libraryTab.llCreatePdf.setOnClickListener {
            val intent = Intent(this@HomeActivity, SelectImageActivity::class.java)
            intent.putExtra(Constant.EXTRA_SELECT_TYPE, Constant.SELECT_TYPE_CRATE_PDF)
            intent.putExtra(Constant.EXTRA_INCLUDE_VIDEO, false)
            createPdfLauncher.launch(intent)
        }
        binding.libraryTab.llDuplicate.setOnClickListener {
            startActivity(Intent(this, StorageScanActivity::class.java))
            closeDrawer()
        }

    }

    var lockActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        Log.e("POST_NOTIFICATIONS", "lockActivityResultLauncher:${result.resultCode}")
        if (result.resultCode == AppCompatActivity.RESULT_OK) {
            val intent = Intent(this@HomeActivity, PrivateActivity::class.java)
            privateActivityResultLauncher.launch(intent)
        }
    }
    var privateActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
//        if (result.resultCode == AppCompatActivity.RESULT_OK) {
//            val intent=Intent(getRequireActivity(), PrivateActivity::class.java)
//            startActivity(intent)

//        val intent = getRequireActivity().intent
//        getRequireActivity().finish()
//        getRequireActivity().overridePendingTransition(0, 0)
//        startActivity(intent!!)
//        getRequireActivity().overridePendingTransition(0, 0)
//        Constant.isChangeLanguage = false
//        }
    }

    private fun showHideDialog(selectImage: ArrayList<MediaData>) {
//        requestStoragePermission(app_private_AFA_allow_nf, app_private_AFA_denied_nf, getActivityName()) {
//            if (it) {
        val hideDialog =
            ActionConfirmationDialog(
                this@HomeActivity,
                getString(R.string.label_private),
                getString(R.string.hide_msg),
                getString(R.string.hide),
                positiveBtnClickListener = {
                    hidePhoto(selectImage)
                })
        hideDialog.show()
//            }
//        }
    }

    private fun hidePhoto(selectImage: ArrayList<MediaData>) {


        Utils.hideFiles(
            this@HomeActivity,
            selectImage,
            selectImage.size,
            hideListener = { deleteList ->
                toast(getString(R.string.hide_successfully))
//            for (folder in selectFolder) {
//                val files = File(folder).listFiles()
//                if (files.isNullOrEmpty()) {
//                    File(folder).delete()
//                }
//            }
                MediaScannerConnection.scanFile(
                    this, deleteList.toTypedArray(), null
                ) { path: String?, uri: Uri? -> }

                longClickListener(false, 0, false)
                setCloseToolbar()
                refreshData()
            })
    }

    private fun showDeleteDialog(selectImage: ArrayList<MediaData>) {
        val deleteDialog = DeleteDialog.newInstance(this@HomeActivity, btnClickListener = {
            deletePhoto(selectImage, it)
        })
        deleteDialog.show()
    }

    private fun deletePhoto(selectImage: ArrayList<MediaData>, isPermanent: Boolean) {
        val deleteList = ArrayList<String>()
        val progressDialog = ProgressDialog(
            this,
            R.drawable.ic_drawer_delete,
            selectImage.size,
            getString(R.string.deleting),
            ""
        )
        progressDialog.setCancelable(false)
        progressDialog.show()

        preferences.refreshMedia = true
        preferences.scanMedia = true

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(this)
            selectImage.forEach { model ->
                val isDelete = Utils.deleteFile(this, model.filePath, dataBase, isPermanent)
                MediaScannerConnection.scanFile(
                    this,
                    arrayOf<String>(model.filePath),
                    null
                ) { path: String?, uri: Uri? -> }
                if (isDelete) {
                    deleteList.add(model.filePath)
                    runOnUiThread {
                        progressDialog.setProgress(deleteList.size, selectImage.size)
                    }
                }
            }

            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    try {
                        if (progressDialog != null
                            && progressDialog.isShowing
                            && !isFinishing
                            && !isDestroyed
                        )
                            progressDialog.dismiss()
                    } catch (e: Exception) {
                    }
                    setBeforeDeleteUpdate(deleteList)
                }
            }
            .onErrorReturn { false }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    try {
                        if (progressDialog != null
                            && progressDialog.isShowing
                            && !isFinishing
                            && !isDestroyed
                        )
                            progressDialog.dismiss()
                    } catch (e: Exception) {
                    }
                    setBeforeDeleteUpdate(deleteList)
                }
            }
    }

    private fun deletePhotos(selectImage: ArrayList<MediaData>, isPermanent: Boolean) {
        preferences.refreshMedia = true
        preferences.scanMedia = true

        Utils.deleteFiles(this@HomeActivity, selectImage, isPermanent) { deleteList ->
            setBeforeDeleteUpdate(deleteList)
        }
    }

    private fun setBeforeDeleteUpdate(deleteList: ArrayList<String>) {

        selectedPhotosCount = 0
        selectedAlbumCount = 0
//        enableScroll()
        binding.albumTab.swipeRefreshAlbum.isEnabled = true
        binding.photosTab.swipeRefreshPhotos.isEnabled = true
        setCloseToolbar()
//        longClickListener(false, 0, false)
        toast(getString(R.string.delete_successfully))
        deleteMainList(deleteList)
        notifyAdapter()
        setEmptyAlbum()
        setEmptyPhoto()

//        runOnUiThread {
//            runOnUiThread {
//                val countRecycle = dataBase.dataDao().getCountDelete()
//                binding.exploreTab.txtRecycleCount.text = "$countRecycle"
//            }
//        }
        refreshData()
    }


    private fun deleteMainList(deleteList: ArrayList<String>) {
//        if (deleteList.size > 0) {
//            allList.removeAll {
//                deleteList.contains(it.filePath)
//            }
//        }
//
//        if (deleteList.size != 0) {
//            for (path in deleteList) {
//                for (pictureData in albumList) {
//                    if (pictureData.folderPath == path) {
//                        albumList.remove(pictureData)
//                        break
//                    }
//                }
//            }
//        }
    }

    private fun shareImages() {
        ensureBackgroundThread {
            val uris = ArrayList<Uri>()
            for (i in pictures.indices) {
                if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData
                    if (model.isSelected) {
                        val uri = FileProvider.getUriForFile(
                            this@HomeActivity,
                            packageName + ".provider",
                            File(model.filePath)
                        )
                        uris.add(uri)
                    }
                }
            }
            runOnUiThread {
                Utils.shareFilesList(this@HomeActivity, uris)
            }
        }
    }


    private fun setPhotosSelect(isSelectAll: Boolean) {

        var selected = 0
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    if (!model.isCustomAlbum) {
                        model.isSelected = isSelectAll
                    }
                } else if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData
                    model.isSelected = isSelectAll
                    if (isSelectAll)
                        selected++

                }
        }
        notifyAdapter()
        longClickListener(true, selected, isSelectAll)
        selectedPhotosCount = selected

    }


    private fun pinAlbum() {

        val pinList: ArrayList<String> = ArrayList()
        pinList.addAll(preferences.getPinAlbumList())

        val list = albumList.filter { it.isSelected }
        for (i in list.indices) {
            if (list[i].isSelected) {
                if (!pinList.contains(list[i].folderPath)) {
                    pinList.add(0, list[i].folderPath)
                }
            }
        }
        preferences.setPinAlbumList(pinList)
        preferences.refreshMedia = true
        albumAdapter?.pinList = pinList

        setCloseToolbar()
        refreshData()
    }

    private fun unPinAlbum() {
        val pinList: ArrayList<String> = ArrayList()
        pinList.addAll(preferences.getPinAlbumList())

        val list = albumList.filter { it.isSelected }
        for (i in list.indices) {
            if (list[i].isSelected) {
                if (pinList.contains(list[i].folderPath)) {
                    pinList.remove(list[i].folderPath)
                }
            }
        }
        preferences.setPinAlbumList(pinList)
        preferences.refreshMedia = true
        albumAdapter?.pinList = pinList

        setCloseToolbar()
        refreshData()
    }

    private fun setAlbumSelect(isSelectAll: Boolean) {

        var selected = 0
        for (i in albumList.indices) {
            if (albumList[i] != null)
                if (albumList[i] is AlbumData) {
                    val model = albumList[i] as AlbumData
                    if (!model.isCustomAlbum) {
                        model.isSelected = isSelectAll
                        if (isSelectAll) selected++
                    }
                }
        }
        notifyAdapter()
        longClickListener(true, selected, isSelectAll)
        selectedAlbumCount = selected
    }

    override fun onPause() {
        super.onPause()
    }

    private fun showDropDown(view: View) {

        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopBottomMenuBinding.inflate(layoutInflater)

        val popupWindow = PopupWindowHelper(popUpBinding.root)

//        popUpBinding.menuRename.beVisibleIf(mSelectedItem == 1)
//        popUpBinding.menuCover.beVisibleIf(mSelectedItem == 1 && binding.viewPager.currentItem == 0)
        //popUpBinding.menuExclude.beVisibleIf(binding.viewPager.currentItem == 0)

//        popUpBinding.menuLock.beVisibleIf(binding.viewPager.currentItem == 0)
        popUpBinding.llMain.beVisible()
//        popUpBinding.llCover.beGone()

        var needToAddFav = false
        var needToRemoveFav = false
        var videoSelected = false

        if (
            binding.viewPager.currentItem == 1
//            || binding.viewPager.currentItem == 2
        ) {
            val selectedItem = getSelectedPhotos()
            for (i in selectedItem.indices) {
                val model: MediaData = selectedItem[i] as MediaData
                if (model.isVideo || model.filePath.isGif()) videoSelected = true
                if (model.isFavorite)
                    needToRemoveFav = true
                else
                    needToAddFav = true
            }
        }

        popUpBinding.menuEdit.beVisibleIf(mSelectedItem == 1 && binding.viewPager.currentItem == 1 && !videoSelected)
        popUpBinding.menuSetAs.beVisibleIf(mSelectedItem == 1 && binding.viewPager.currentItem == 1 && !videoSelected)
        popUpBinding.menuRename.beVisibleIf(mSelectedItem == 1)
        popUpBinding.menuPdf.beVisibleIf(binding.viewPager.currentItem == 1 && !videoSelected)

        popUpBinding.menuAddFavourite.beVisibleIf(needToAddFav)
        popUpBinding.menuRemoveFavourite.beVisibleIf(needToRemoveFav)

//        popUpBinding.menuInfo.beVisibleIf(mSelectedItem == 1 && binding.viewPager.currentItem != 2)
        popUpBinding.menuInfo.beVisibleIf(mSelectedItem == 1)

        popUpBinding.loutMain.setOnClickListener {
            popupWindow.dismiss()
        }
        popUpBinding.menuPdf.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 0) {
                if (selectedAlbumCount == 0) {
                    toast(getString(R.string.please_select_album))
                } else {
                    val selectImage = ArrayList<MediaData>()
                    albumList.filter { it.isSelected }.forEach { album ->
                        album.mediaData.forEach { picture ->
                            if (picture is MediaData) {
                                selectImage.add(picture)
                            }
                        }
                    }
                    Utils.generatePdf(this@HomeActivity, selectImage)
                }
            } else if (binding.viewPager.currentItem == 1) {
                if (selectedPhotosCount == 0) {
                    toast(getString(R.string.please_select_image))
                } else {
                    val selectImage = ArrayList<MediaData>() // Use a set to avoid duplicates
                    pictures.filterIsInstance<MediaData>() // Filter only MediaData objects
                        .filter { it.isSelected } // Filter selected MediaData objects
                        .forEach { selectImage.add(it) } // Add to the set

                    Utils.generatePdf(this@HomeActivity, selectImage)
                }
            }

        }

        popUpBinding.menuRename.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 0) {
                if (mSelectedItem == 1) {
                    showAlbumRenameDialog()
                }
            } else if (binding.viewPager.currentItem == 1) {
                if (mSelectedItem == 1) {
                    showMediaRenameDialog()
                }
            }
//            else if (binding.viewPager.currentItem == 2) {
//                if (mSelectedItem == 1) {
//                    showMediaRenameDialog()
//                }
//            }
        }

        popUpBinding.menuEdit.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 1) {
                openEditor()
            }
        }

        popUpBinding.menuSetAs.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 1) setAs()
        }

        popUpBinding.menuAddFavourite.setOnClickListener {
            popupWindow.dismiss()
            if (
                binding.viewPager.currentItem == 1
//                || binding.viewPager.currentItem == 2
            ) setFavorite(true)

        }

        popUpBinding.menuRemoveFavourite.setOnClickListener {
            popupWindow.dismiss()
            if (
                binding.viewPager.currentItem == 1
//                || binding.viewPager.currentItem == 2
            )
                setFavorite(false)
        }

        popUpBinding.menuInfo.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 0) showAlbumDetailDialog()
            if (binding.viewPager.currentItem == 1) showPhotoDetailsDialog()
//            if (binding.viewPager.currentItem == 2) showVideoDetailsDialog()
        }

        popUpBinding.menuCopy.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 0) {
                if (selectedAlbumCount == 0) {
                    toast(getString(R.string.please_select_album))
                } else {
                    val selectedAlbum = ArrayList<String>()
                    val selectImage = ArrayList<MediaData>() // Use a set to avoid duplicates
                    albumList.filter { it.isSelected }.forEach { album ->
                        selectedAlbum.add(album.folderPath) // Add selected album
                        album.mediaData.forEach { picture ->
                            if (picture is MediaData) {
                                selectImage.add(picture) // Add MediaData to the set (duplicates automatically avoided)
                            }
                        }
                    }
                    showAddAlbumDialog(
                        Constant.deviceAlbumList,
                        selectImage,
                        selectedAlbum,
                        true
                    )


                }
            } else if (binding.viewPager.currentItem == 1) {
                if (selectedPhotosCount == 0) {
                    toast(getString(R.string.please_select_image))
                } else {
                    val selectedAlbum = ArrayList<String>()
                    val selectImage = ArrayList<MediaData>() // Use a set to avoid duplicates
                    pictures.filterIsInstance<MediaData>() // Filter only MediaData objects
                        .filter { it.isSelected } // Filter selected MediaData objects
                        .forEach { selectImage.add(it) } // Add to the set
                    showAddAlbumDialog(
                        Constant.deviceAlbumList,
                        selectImage,
                        selectedAlbum,
                        true
                    )
                }
            }
//            else if (binding.viewPager.currentItem == 2) {
//                if (selectedPhotosCount == 0) {
//                    toast(getString(R.string.PleaseSelectImage))
//                } else {
//                    val selectedAlbum = ArrayList<String>()
//                    val selectImage = ArrayList<MediaData>() // Use a set to avoid duplicates
//                    videos.filterIsInstance<MediaData>() // Filter only MediaData objects
//                        .filter { it.isSelected } // Filter selected MediaData objects
//                        .forEach { selectImage.add(it) } // Add to the set
//                    showAddAlbumDialog(
//                        Constant.deviceAlbumList,
//                        selectImage,
//                        selectedAlbum,
//                        true
//                    )
//                }
//            }
        }

        popUpBinding.menuMove.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 0) {
                if (selectedAlbumCount == 0) {
                    toast(getString(R.string.please_select_album))
                } else {
                    val selectedAlbum = ArrayList<String>()
                    val selectImage = ArrayList<MediaData>() // Use a set to avoid duplicates
                    albumList.filter { it.isSelected }.forEach { album ->
                        selectedAlbum.add(album.folderPath) // Add selected album
                        album.mediaData.forEach { picture ->
                            if (picture is MediaData) {
                                selectImage.add(picture) // Add MediaData to the set (duplicates automatically avoided)
                            }
                        }
                    }
                    showAddAlbumDialog(
                        albumList.filter { it.isCustomAlbum == false } as ArrayList<AlbumData>,
                        selectImage,
                        selectedAlbum,
                        false
                    )
                }
            } else if (binding.viewPager.currentItem == 1) {
                if (selectedPhotosCount == 0) {
                    toast(getString(R.string.please_select_image))
                } else {
                    val selectedAlbum = ArrayList<String>()
                    val selectImage = ArrayList<MediaData>() // Use a set to avoid duplicates
                    pictures.filterIsInstance<MediaData>() // Filter only MediaData objects
                        .filter { it.isSelected } // Filter selected MediaData objects
                        .forEach { selectImage.add(it) } // Add to the set
                    showAddAlbumDialog(
                        albumList.filter { it.isCustomAlbum == false } as ArrayList<AlbumData>,
                        selectImage,
                        selectedAlbum,
                        false
                    )
                }
            }
//            else if (binding.viewPager.currentItem == 2) {
//                if (selectedPhotosCount == 0) {
//                    toast(getString(R.string.PleaseSelectImage))
//                } else {
//                    val selectedAlbum = ArrayList<String>()
//                    val selectImage = ArrayList<MediaData>() // Use a set to avoid duplicates
//                    videos.filterIsInstance<MediaData>() // Filter only MediaData objects
//                        .filter { it.isSelected } // Filter selected MediaData objects
//                        .forEach { selectImage.add(it) } // Add to the set
//                    showAddAlbumDialog(
//                        albumList.filter { it.isCustomAlbum == false } as ArrayList<AlbumData>,
//                        selectImage,
//                        selectedAlbum,
//                        false
//                    )
//                }
//            }
        }

        popupWindow.showAsPopUp(view)

    }

    private fun openEditor() {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] is MediaData) {
                val model: MediaData = pictures[i] as MediaData
                if (model.isSelected) {
                    selectImage.add(model)
                }
            }
        }

        if (selectImage.isNotEmpty()) {
            val path = selectImage[0].filePath
            val newPath = path.removePrefix("file://")
            openEditorIntent(newPath)
        } else {
            toast(getString(R.string.please_select_image))
        }
    }

//    private fun setDefaultCoverImage() {
//        try {
//            val albumData = albumList.firstOrNull { it.isSelected }
//            preferences.setCoverImage(albumData!!.folderPath, "")
//            setCloseToolbar()
//            refreshData()
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
//    }

//    private fun setCoverImage() {
//        try {
//            val albumData = albumList.firstOrNull { it.isSelected }
//            albumData?.let {
//                val addAlbumDialog = SelectAlbumImageFullDialog(
//                    this@HomeActivity,
//                    it.mediaData,
//                    selectPathListener = { selectPath ->
//                        preferences.setCoverImage(albumData.folderPath, selectPath)
//                        //setCopyMove(isCopy, selectPath, selectImage)
//                        setCloseToolbar()
//                        refreshData()
//                    },
//                    createAlbumListener = {
//
//                    })
//                addAlbumDialog.show(supportFragmentManager, addAlbumDialog.tag)
//            }
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
//
//    }


    private fun showAddAlbumDialog(
        albums: ArrayList<AlbumData>,
        selectedMedia: ArrayList<MediaData>,
        selectedAlbum: ArrayList<String>,
//        selectedAlbum: ArrayList<AlbumData>,
        isCopy: Boolean
    ) {

        val uniqueSelectImage = ArrayList(selectedMedia.distinctBy { it.filePath })

        for (media in uniqueSelectImage) {
            Log.e("uniqueSelectImage", "uniqueSelectImage-->:${media.filePath}")
        }

//        val addAlbumDialog =
//            SelectAlbumFullDialog(
//                this@HomeActivity,
//                albums,
//                selectedAlbum,
//                isCopy,
//                selectPathListener = { selectPath ->
//                    setCopyMove(isCopy, selectPath, uniqueSelectImage)
//                },
//                createAlbumListener = {
////                    requestStoragePermission(app_create_album_AFA_allow_nf, app_create_album_AFA_denied_nf, getActivityName()) { value ->
////                        if (value) {
//                    val createDialog = CreateAlbumDialog(this@HomeActivity, createPathListener = {
//                        setCopyMove(isCopy, it, uniqueSelectImage)
//                    })
//                    createDialog.show()
////                        }
////                    }
//                })
//        addAlbumDialog.show(supportFragmentManager, addAlbumDialog.tag)

        isCopyForResult = isCopy
        selectImageForResult = uniqueSelectImage
        val selectAlbumIntent = Intent(this, AlbumSelectorActivity::class.java)
        selectAlbumIntent.putExtra("selectedAlbum", selectedAlbum)
        selectAlbumIntent.putExtra("isCopy", isCopy)
        addAlbumLauncher.launch(selectAlbumIntent)

    }

    private var isCopyForResult: Boolean = false
    private lateinit var selectImageForResult: ArrayList<MediaData>
    private val addAlbumLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                val data = result.data
                when (data?.getStringExtra("action")) {
                    "create" -> {
                        val createDialog = CreateAlbumDialog(this, createPathListener = { path ->
                            setCopyMove(isCopyForResult, path, selectImageForResult)
                        })
                        createDialog.show()
                    }

                    else -> {
                        data?.getStringExtra("selectedPath")?.let { path ->
                            setCopyMove(isCopyForResult, path, selectImageForResult)
                        }
                    }
                }
            }
        }

    private fun setCopyMove(
        isCopy: Boolean, selectPath: String, selectImage: java.util.ArrayList<MediaData>,
    ) {
        Log.e("newAlbum", "setCopyMove:$selectPath")
        if (isCopy) {
            Utils.copyFiles(
                this@HomeActivity,
                selectPath,
                selectImage,
                selectImage.size,
                copyListener = {
                    toast(getString(R.string.copy_successfully))
//                        MediaScannerConnection.scanFile(it, arrayOf<String>(selectPath), null) { path, uri -> }
                    selectedAlbumCount = 0
//                getData()
//                longClickListener(false, 0, false)
                    preferences.refreshMedia = true
                    preferences.scanMedia = true
                    refresh()
//                        Handler(Looper.getMainLooper()).postDelayed({
//                        setCloseToolbar()
//                        }, 500)

//                        Handler(Looper.getMainLooper()).postDelayed({
//                            sendEvent("refresh")
//                        }, 500)
                })
        } else {
            Utils.moveFiles(
                this@HomeActivity,
                selectPath,
                selectImage,
                selectImage.size,
                moveListener = {
//                    MediaScannerConnection.scanFile(it, arrayOf<String>(selectPath), null) { path, uri -> }
                    toast(getString(R.string.move_successfully))
                    selectedAlbumCount = 0
//            getData()
//            longClickListener(false, 0, false)
                    preferences.refreshMedia = true
                    preferences.scanMedia = true
//                    Handler(Looper.getMainLooper()).postDelayed({
                    refresh()
//                    }, 500)
                })
        }

    }

    private fun showAlbumDetailDialog() {
        try {
            val albumData = albumList.filter { it.isSelected }
            val detailsDialog = AlbumDetailsDialog(this, albumData[0], false)
            detailsDialog.show()
        } catch (e: IndexOutOfBoundsException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showPhotoDetailsDialog() {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] is MediaData) {
                val model: MediaData = pictures[i] as MediaData
                if (model.isSelected) {
                    selectImage.add(model)
                }
            }
        }

        if (selectImage.isNotEmpty()) {
            val pictureData = selectImage[0]

            val detailsDialog = DetailsDialog(this@HomeActivity, pictureData, false)
            detailsDialog.show()
        } else {
            toast(getString(R.string.please_select_image))
        }

    }


    private fun setFavorite(isFavorite: Boolean) {
        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())

        for (i in pictures.indices) {
            if (pictures[i] is MediaData) {
                val model: MediaData = pictures[i] as MediaData
                if (model.isSelected) {
                    if (isFavorite) {
                        if (!favList.contains(model.filePath)) favList.add(model.filePath)
                    } else {
                        if (favList.contains(model.filePath)) favList.remove(model.filePath)
                    }
                }
            }
        }
        preferences.setFavoriteList(favList)
//        preferences.refreshMedia=true

        runOnUiThread {
            setCloseToolbar()
            refreshData()
//            updateData()
        }
    }

    private fun showAlbumRenameDialog() {
        Log.e("AlbumRenameDialog", "albumList.size:${albumList.size}")
        val albumData = albumList.firstOrNull { it.isSelected }
        if (albumData != null) {
            val renameDialog = FolderRenameDialog(
                this,
                albumData,
                positiveBtnClickListener = { renamePath, oldPath ->
                    Log.e(
                        "AlbumRenameDialog",
                        "albumList.renamePath:${renamePath},oldPath:$oldPath,albumData:${albumData.folderPath}"
                    )
                    try {
                        try {
                            scanPathRecursively(albumData.folderPath) {}
                        } catch (e: Exception) {
                        }
                        albumList.removeAll { it.folderPath == albumData.folderPath }
                        Log.e("AlbumRenameDialog", "albumList.size:${albumList.size}")
                    } catch (e: Exception) {
                        Log.e("AlbumRenameDialog", "albumList.Exception:${e}")
                    }
                    runOnUiThread {
//                        MediaScannerConnection.scanFile(this, arrayOf<String>(oldPath), null) { path, uri -> }
                        setClose()
                        setToolbarSelectionMaintain(false, 0, false)
//                        setCloseToolbar()
                        refreshData()
                    }
                })
            renameDialog.show()
        }
    }

    private fun showMediaRenameDialog() {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] is MediaData) {
                val model: MediaData = pictures[i] as MediaData
                if (model.isSelected) {
                    selectImage.add(model)
                }
            }
        }

        if (selectImage.isNotEmpty()) {
            val pictureData = selectImage[0]
            val renameDialog =
                FileRenameDialog(
                    this,
                    pictureData,
                    positiveBtnClickListener = { renamePath, oldPath ->
//                        sendEvent("rename")
                        MediaScannerConnection.scanFile(
                            this,
                            arrayOf<String>(oldPath),
                            null
                        ) { path, uri -> }
                        MediaScannerConnection.scanFile(
                            this,
                            arrayOf<String>(renamePath),
                            null
                        ) { path, uri -> }
                        runOnUiThread {
                            notifyAdapter()
                        }
                    })

            renameDialog.show()
        } else {
            toast(getString(R.string.please_select_image))
        }
    }

    private fun initAlbumAdapter() {

        albumAdapter = AlbumListAdapter(
            this@HomeActivity,
            clickListener = {
                val albumData = albumList[it]
                if (albumData.isCheckboxVisible) {
                    if (!albumData.isCustomAlbum) {
                        albumData.isSelected = !albumData.isSelected
                        albumAdapter?.notifyItemChanged(it)
                        setSelectedAlbum()
                    }
                } else {
                    if (albumData.isCustomAlbum) {
                        if (albumData.mediaData.size != 0) {
                            if (albumData.title == getString(R.string.all_videos)) {
                                val intent =
                                    Intent(this@HomeActivity, VideoGalleryActivity::class.java)
                                intent.putExtra("title", "${albumData.title}")
                                startActivity(intent)
                            } else if (albumData.title == getString(R.string.favorite)) {
                                val intent =
                                    Intent(this@HomeActivity, FavoritesListActivity::class.java)
                                intent.putExtra("title", "${albumData.title}")
                                startActivity(intent)
                            } else {
                                openImageList(albumData)
                            }
                        } else {
                            //startActivity(Intent(this@HomeActivity, MediaActivity::class.java))
                        }
                    } else {
                        openImageList(albumData)
                    }
                }
            },
            longClickListener = {
                if (!albumList[it].isCustomAlbum) {
                    lastLongPressedAlbum = it
                    binding.albumTab.albumRecycler.setDragSelectActive(it)
                    lastLongPressedAlbum = if (lastLongPressedAlbum == -1) {
                        it
                    } else {
                        val min = min(lastLongPressedAlbum, it)
                        val max = max(lastLongPressedAlbum, it)
                        for (i in min..max) {
                            togglePictureSelection(true, i, false)
                        }
                        it
                    }

                    val pictureData = albumList[it] as AlbumData
                    for (i in albumList.indices) {
                        val model = albumList[i] as AlbumData
                        model.isCheckboxVisible = true
                    }
                    pictureData.isCheckboxVisible = true
                    pictureData.isSelected = true
                    notifyAdapter()
                    setSelectedAlbum()
                }
            },
            utilClickListener = { utilPos ->

                when (utilPos) {
                    0 -> {//llRecent

                        val recentList = fetchRecentMedia(this@HomeActivity)
                        val recentAlbum = AlbumData(
                            getString(R.string.recent),
                            //mediaData = recentList,
                            isCustomAlbum = true
                        )
                        recentAlbum.mediaData.addAll(recentList)
                        openImageList(recentAlbum)
                    }

                    1 -> {
                        //llAllVideo
//                        val recentAlbum=AlbumData(
//                            getString(R.string.Favorite),
//                            pictureData = recentList,
//                            isCustomAlbum = true
//                        )
                        val intent = Intent(this@HomeActivity, VideoGalleryActivity::class.java)
                        intent.putExtra("title", getString(R.string.all_videos))
                        startActivity(intent)
                    }

                    2 -> {//llFavorite
                        val intent = Intent(this@HomeActivity, FavoritesListActivity::class.java)
                        intent.putExtra("title", getString(R.string.favorite))
                        startActivity(intent)
                    }

                    3 -> {//llDuplicate
                        startActivity(Intent(this@HomeActivity, StorageScanActivity::class.java))
                    }

                    4 -> {//llHidden
                        val intent = Intent(this@HomeActivity, LockSetActivity::class.java)
                        lockActivityResultLauncher.launch(intent)
                    }

//                    5 -> {//llTimeLine
//                        startActivity(Intent(this@HomeActivity, TimeLineActivity::class.java))
//                    }

                    6 -> {//llMaps
                        startActivity(Intent(this@HomeActivity, LocationAlbumActivity::class.java))
                    }

                    7 -> {//llNote
                        startActivity(Intent(this@HomeActivity, NotesActivity::class.java))
                    }

//                    8 -> {//llBrowser
//                        startActivity(Intent(this@HomeActivity, WebBrowserActivity::class.java))
//                    }

                    9 -> {//llPdf
                        val intent = Intent(this@HomeActivity, SelectImageActivity::class.java)
                        intent.putExtra(Constant.EXTRA_SELECT_TYPE, Constant.SELECT_TYPE_CRATE_PDF)
                        intent.putExtra(Constant.EXTRA_INCLUDE_VIDEO, false)
                        startActivity(intent)
                    }

                }

            })
        albumAdapter?.submitList(albumList)
        binding.albumTab.albumRecycler.itemAnimator = null
        binding.albumTab.albumRecycler.adapter = albumAdapter

        binding.albumTab.albumRecycler.post {
            FastScroller(binding.albumTab.albumHandle).bind(binding.albumTab.albumRecycler)
        }

    }

    fun setSelectionEnable() {
//        if (binding.viewPager.currentItem == 2) {
//            for (i in videos.indices) {
//                if (videos[i] != null)
//                    if (videos[i] is AlbumData) {
//                        val model = videos[i] as AlbumData
//                        model.isCheckboxVisible = true
//                    } else if (videos[i] is MediaData) {
//                        val model = videos[i] as MediaData
//                        model.isCheckboxVisible = true
//                    }
//            }
//            notifyAdapter()
//            setSelectedVideos()
//        } else
        if (binding.viewPager.currentItem == 1) {
            for (i in pictures.indices) {
                if (pictures[i] != null)
                    if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isCheckboxVisible = true
                    } else if (pictures[i] is MediaData) {
                        val model = pictures[i] as MediaData
                        model.isCheckboxVisible = true
                    }
            }
            notifyAdapter()
            setSelectedPicture()
        } else if (binding.viewPager.currentItem == 0) {
            for (i in albumList.indices) {
                val model = albumList[i] as AlbumData
                model.isCheckboxVisible = true
            }
            notifyAdapter()
            setSelectedAlbum()
        }
    }

    protected fun selectPictureRange(from: Int, to: Int, min: Int, max: Int) {
        if (from == to) {
            (min..max).filter { it != from }.forEach { togglePictureSelection(false, it, true) }
            return
        }

        if (to < from) {
            for (i in to..from) {
                togglePictureSelection(true, i, true)
            }

            if (min > -1 && min < to) {
                (min until to).filter { it != from }
                    .forEach { togglePictureSelection(false, it, true) }
            }

            if (max > -1) {
                for (i in from + 1..max) {
                    togglePictureSelection(false, i, true)
                }
            }
        } else {
            for (i in from..to) {
                togglePictureSelection(true, i, true)
            }

            if (max > -1 && max > to) {
                (to + 1..max).filter { it != from }
                    .forEach { togglePictureSelection(false, it, true) }
            }

            if (min > -1) {
                for (i in min until from) {
                    togglePictureSelection(false, i, true)
                }
            }
        }
    }

    private fun togglePictureSelection(select: Boolean, pos: Int, updateTitle: Boolean = true) {
        try {

            if (select && pictures[pos] is AlbumData) {
                return
            }

            if (pictures[pos] is MediaData) {
                if (select) {
                    (pictures[pos] as MediaData).isSelected = true
                } else {
                    (pictures[pos] as MediaData).isSelected = false
                }
            }
            pictureAdapter?.notifyItemChanged(pos)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        setSelectedPicture()

    }

    private fun selectAlbumRange(from: Int, to: Int, min: Int, max: Int) {
        if (from == to) {
            (min..max).filter { it != from }.forEach { toggleAlbumSelection(false, it, true) }
            return
        }

        if (to < from) {
            for (i in to..from) {
                toggleAlbumSelection(true, i, true)
            }

            if (min > -1 && min < to) {
                (min until to).filter { it != from }
                    .forEach { toggleAlbumSelection(false, it, true) }
            }

            if (max > -1) {
                for (i in from + 1..max) {
                    toggleAlbumSelection(false, i, true)
                }
            }
        } else {
            for (i in from..to) {
                toggleAlbumSelection(true, i, true)
            }

            if (max > -1 && max > to) {
                (to + 1..max).filter { it != from }
                    .forEach { toggleAlbumSelection(false, it, true) }
            }

            if (min > -1) {
                for (i in min until from) {
                    toggleAlbumSelection(false, i, true)
                }
            }
        }
    }

    protected fun toggleAlbumSelection(select: Boolean, pos: Int, updateTitle: Boolean = true) {

        if (albumList[pos] is AlbumData) {
            if (select && !albumList[pos].isCustomAlbum) {
                albumList[pos].isSelected = true
//                albumList[pos].isCheckboxVisible = true
//                selectedKeys.add(itemKey)
            } else {
                albumList[pos].isSelected = false
//                albumList[pos].isCheckboxVisible = true
//                selectedKeys.remove(itemKey)
            }
        }

        albumAdapter?.notifyItemChanged(pos)
        setSelectedAlbum()
    }

    private fun initPhotoAdapter() {
//        binding.mediaFastscroller.attachFastScrollerToRecyclerView(binding.pictureRecycler)
//        preferences.saveObjectList(pictures)
        pictureAdapter = PhotoAdapter(
            this@HomeActivity,
            clickListener = {
                if (pictures[it] is MediaData) {
                    val mediaData = pictures[it] as MediaData
                    if (mediaData.isCheckboxVisible) {
                        mediaData.isSelected = !mediaData.isSelected
                        pictureAdapter?.notifyItemChanged(it)
                        setSelectedPicture()
                    } else {
                        val dataList = ArrayList<MediaData>()
                        var displayPos = 0
                        for (i in pictures.indices) {
                            if (pictures[i] is MediaData) {
                                dataList.add(pictures[i] as MediaData)
                                if (it == i) {
                                    displayPos = dataList.size - 1
                                }
                            }
                        }
                        Constant.displayImageList = ArrayList()
                        Constant.displayImageList.addAll(dataList)
                        Constant.selectedPosition = displayPos
//                        val intent = Intent(activity, ImageViewerActivity::class.java)
                        if (Constant.displayImageList.size > 0) {
                            val intent = Intent(this@HomeActivity, PhotoVideoActivity::class.java)
                            intent.putExtra(Constant.EXTRA_DISPLAY_POS, displayPos)
                            startActivity(intent)
                        }
                        setBackAlbumData()
                    }
                }
            },
            longClickListener = {

                lastLongPressedMedia = it
                binding.photosTab.pictureRecycler.setDragSelectActive(it)
                lastLongPressedMedia = if (lastLongPressedMedia == -1) {
                    it
                } else {
                    val min = min(lastLongPressedMedia, it)
                    val max = max(lastLongPressedMedia, it)
                    for (i in min..max) {
                        togglePictureSelection(true, i, false)
                    }
//                    updateTitle()
                    it
                }

                if (pictures[it] is MediaData) {
                    val mediaData = pictures[it] as MediaData
                    for (i in pictures.indices) {
                        if (pictures[i] != null)
                            if (pictures[i] is AlbumData) {
                                val model = pictures[i] as AlbumData
                                model.isCheckboxVisible = true
                            } else if (pictures[i] is MediaData) {
                                val model = pictures[i] as MediaData
                                model.isCheckboxVisible = true
                            }
                    }
                    mediaData.isCheckboxVisible = true
                    mediaData.isSelected = true
                    notifyAdapter()
                    setSelectedPicture()
                }

            },
            headerSelectListener = {
                if (pictures[it] is AlbumData) {
                    val albumData = pictures[it] as AlbumData
                    val isSelectAll = !albumData.isSelected
                    albumData.isSelected = isSelectAll
                    var pos = it + 1
                    while (pos < pictures.size) {
                        if (pictures[pos] is MediaData) {
                            val model = pictures[pos] as MediaData
                            model.isSelected = isSelectAll
                            pos++
                        } else if (pictures[pos] is AlbumData) {
                            break
                        }
                    }
                    notifyAdapter()
                    setSelectedPicture()
                }
            },
            enableHeaderSelect = true
        )

        pictureAdapter?.submitList(pictures)
        binding.photosTab.pictureRecycler.itemAnimator = null
        binding.photosTab.pictureRecycler.adapter = pictureAdapter

        binding.photosTab.pictureRecycler.post {
            FastScroller(binding.photosTab.photosHandle).bind(binding.photosTab.pictureRecycler)
        }

    }

    private fun setSelectedPicture() {
        var selected = 0
        var allItemCount = 0

        var currentHeaderPos = -1
        var photosCount = 0
        var photosSelectCount = 0

        for (i in pictures.indices) {
            if (pictures[i] is AlbumData) {
                if (i != currentHeaderPos) {
                    if (currentHeaderPos != -1) {
                        val model = pictures[currentHeaderPos] as AlbumData
                        model.isSelected = photosCount == photosSelectCount
                        photosCount = 0
                        photosSelectCount = 0
                        pictureAdapter?.notifyItemChanged(currentHeaderPos)
                    }
                    currentHeaderPos = i
                }
            } else if (pictures[i] is MediaData) {
                val model = pictures[i] as MediaData
                allItemCount++
                photosCount++
                if (model.isSelected) {
                    selected++
                    photosSelectCount++
                }
            }
            if (i == pictures.size - 1) {
                if (currentHeaderPos != -1) {
                    val model = pictures[currentHeaderPos] as AlbumData
                    model.isSelected = photosCount == photosSelectCount
                    photosCount = 0
                    photosSelectCount = 0
                    pictureAdapter?.notifyItemChanged(currentHeaderPos)
                }
            }
        }

        longClickListener(true, selected, allItemCount == selected)
        binding.photosTab.swipeRefreshPhotos.isEnabled = false
        selectedPhotosCount = selected
    }

    private fun setSelectedAlbum() {
        var selected = 0
        var allItemCount = 0
        var currentHeaderPos = -1
        var photosCount = 0
        var photosSelectCount = 0

        for (i in albumList.indices) {
            if (albumList[i] is AlbumData) {
                val model = albumList[i] as AlbumData
                allItemCount++
                photosCount++
                if (model.isSelected) {
                    selected++
                    photosSelectCount++
                }
            }
        }

        longClickListener(true, selected, allItemCount == selected)
        binding.albumTab.swipeRefreshAlbum.isEnabled = false
        selectedAlbumCount = selected
    }


    fun notifyAdapter() {
        binding.albumTab.albumRecycler.post {
            if (albumAdapter != null) {
                albumAdapter?.submitList(albumList)
                albumAdapter?.notifyItemRangeChanged(0, albumList.size)
            }
        }
        binding.photosTab.pictureRecycler.post {
            if (pictureAdapter != null) {
                pictureAdapter?.submitList(pictures)
                pictureAdapter?.notifyItemRangeChanged(0, pictures.size)
            }
        }

    }

    private fun refresh() {
        preferences.refreshMedia = true
        setCloseToolbar()
        refreshData()
//        Handler(Looper.getMainLooper()).postDelayed({
//        sendEvent("refresh")
//        }, 500)
    }

//    private fun addToExclude() {
//        val albumData = albumList.filter { it.isSelected }
//        val excludeList: ArrayList<String> = ArrayList()
//        preferences.getExcludeList().let { excludeList.addAll(it) }
//        for (i in albumData.indices) {
//            if (albumData[i] is AlbumData) {
//                val model = albumData[i] as AlbumData
//                if (model.isSelected && model.folderPath.isNotEmpty()) {
//                    if (!excludeList.contains(model.folderPath)) excludeList.add(model.folderPath)
//                }
//            }
//        }
//        preferences.setExcludeList(excludeList)
//        preferences.refreshMedia = true
//
//        setCloseToolbar()
//        refreshData()
//    }

    private fun setCloseToolbar() {
        setClose()
        longClickListener(false, 0, false)

    }

    private fun setClose() {
        Log.e("", "setClose==>> pictures size ${pictures.size} ")
        albumList.forEach { item ->
            if (item is AlbumData) {
                item.isSelected = false
                item.isCheckboxVisible = false
                Log.e("", "setClose==>> AlbumData selection false")
            }
        }
        pictures.forEach { item ->
            when (item) {
                is AlbumData -> {
                    item.isSelected = false
                    item.isCheckboxVisible = false
                    Log.e("", "setClose==>> AlbumData selection false")
                }

                is MediaData -> {
                    item.isSelected = false
                    item.isCheckboxVisible = false
                    Log.e("", "setClose==>> PictureData selection false")
                }
            }
        }
//        videos.forEach { item ->
//            when (item) {
//                is AlbumData -> {
//                    item.isSelected = false
//                    item.isCheckboxVisible = false
//                    Log.e("", "setClose==>> AlbumData selection false")
//                }
//
//                is MediaData -> {
//                    item.isSelected = false
//                    item.isCheckboxVisible = false
//                    Log.e("", "setClose==>> PictureData selection false")
//                }
//            }
//        }

        binding.photosTab.swipeRefreshPhotos.isEnabled = true
        binding.albumTab.swipeRefreshAlbum.isEnabled = true
        notifyAdapter()
        setRvLayoutManager()
//        getAlbumData()
//        getPhotoData()
        selectedPhotosCount = 0
    }
    private fun setAs() {
        val selectImage = pictures.filterIsInstance<MediaData>()
            .filter { it.isSelected }

        val pictureData = selectImage.firstOrNull()
        val intent = Intent(this@HomeActivity, WallpaperSettingsActivity::class.java)
        intent.putExtra(
            Constant.EXTRA_WALL_PAPER,
            pictureData?.filePath
        )
        startActivity(intent)
    }
    private fun openCamera() {
        try {
            val cameraIntent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            startActivity(cameraIntent)
            preferences.refreshMedia = true
        } catch (e: Exception) {
            Log.e("printStackTrace", "printStackTrace:$e")
            toast(getString(R.string.not_found))
        }
    }

    var permissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { _ ->
            if (checkStoragePermission())
                openCamera()
            else
                requestPermission()
        }


    private fun hideKeyboard(view: EditText) {
        view.clearFocus()
        val methodManager = (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.hideSoftInputFromWindow(view.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
    }

    private fun showKeyboard(view: EditText) {
        view.requestFocus()
        val methodManager = (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun showMenu() {
        val dialog = HomeOptionsDialog(this, binding.viewPager.currentItem, clickListener = {
            when (it) {
                1 -> {
                    showSortDialog()
                }

                2 -> {
                    val filterMediaDialog = FilterMediaDialog(this@HomeActivity, updateListener = {
                        getData()
//                        sendEvent("get_data")
                    })
                    filterMediaDialog.show()
                }

                21 -> {
                    setRvLayoutManager()
                }

                22 -> {
                    setRvLayoutManager()
                }

                3 -> {
//                    requestStoragePermission(app_create_album_AFA_allow_nf, app_create_album_AFA_denied_nf, getActivityName()) {
//                        if (it) {
                    showCreateAlbum()
//                        }
//                    }
                }

                4 -> {
                    // displayed Columns
                    val displayColumnsDialog = DisplayedColumnsDialog(
                        this, "",
                        binding.viewPager.currentItem == 0,
                        updateListener = {
                            setRvLayoutManager()
                        })
                    displayColumnsDialog.show()

                }

                5 -> {
                    //btnRecycleBin
                    val intent = Intent(this, RecentlyDeleteActivity::class.java)
                    recycleLauncher.launch(intent)
                }

                6 -> {
                    //btnCollage
                    toast("Coming Soon..")
                }

                7 -> {
                    //btnFeedback
//                    val intent = Intent(this, FeedbackActivity::class.java)
//                    startActivity(intent)
                }

                8 -> {
                    //btnSetting
                    settingLauncher.launch(Intent(this, SettingActivity::class.java))
                }

                9 -> {
                    //showGroupByDialog
                    showGroupByDialog()
                }

                11 -> {
                    setSelectionEnable()
                }

            }
        })
        dialog.show()
    }

    var recycleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            getData()
//            sendEvent("get_data")
        }

    private fun showCreateAlbum() {
        val createDialog = CreateAlbumDialog(this, createPathListener = { newAlbum ->
            setCloseToolbar()
            refreshData()
            val intent = Intent(this, SelectImageActivity::class.java)
            intent.putExtra(Constant.EXTRA_SELECT_TYPE, Constant.SELECT_TYPE_CRATE_ALBUM)
            intent.putExtra(Constant.EXTRA_ALBUM_PATH, newAlbum)
            startActivity(intent)
        }, true)
        createDialog.show()
    }

    private fun showSortDialog() {
        val key = "frag_${binding.viewPager.currentItem}"
        val sortDialog = SortingOptionsDialog(this, key, updateListener = {
            getData()
        })
        sortDialog.show()
    }

    private fun showGroupByDialog() {
        val groupDialog = GroupDialog(this, updateListener = {
            setPhotoGroup()
        })
        groupDialog.show()
    }


    private fun checkForceAppUpdate(remoteConfig: FirebaseRemoteConfig) {

        Log.e("checkForceAppUpdate", "checkForceAppUpdate")

        remoteConfig.setConfigSettingsAsync(
            FirebaseRemoteConfigSettings.Builder()
                .setMinimumFetchIntervalInSeconds(5)
                .setFetchTimeoutInSeconds(5)
                .build()
        )
        remoteConfig.setDefaultsAsync(R.xml.remote_config_defaults)

        // Fetch the remote config
        remoteConfig.fetchAndActivate().addOnCompleteListener { task ->
            if (task.isSuccessful) {

//                try {
                val forceUpdate = remoteConfig.getString("force_update")
                Log.e("checkForceAppUpdate", "force_update:$forceUpdate")
                if (forceUpdate.isNotEmpty()) {

                    val jsonForceUpdateObj = JSONObject(forceUpdate)
                    val isNeedToShow = jsonForceUpdateObj.getBoolean("isNeedToShow")
                    val isCancelable = jsonForceUpdateObj.getBoolean("isCancelable")
                    val cancelCounter = jsonForceUpdateObj.getInt("cancel_counter")
                    val latestVersion = jsonForceUpdateObj.getString("latest_version")
                    val mainTitle = jsonForceUpdateObj.getString("main_title")
                    val subTitle = jsonForceUpdateObj.getString("sub_title")
                    val displayFromVersion = jsonForceUpdateObj.getInt("display_from_version")
                    val redirectUrl = jsonForceUpdateObj.getString("redirect_url")
                    val btnText = jsonForceUpdateObj.getString("btn_text")

                    val forceUpdateModel = UpdateModel(
                        isNeedToShow = isNeedToShow,
                        isCancelable = isCancelable,
                        latestVersion = latestVersion,
                        cancelCounter = cancelCounter,
                        mainTitle = mainTitle,
                        subTitle = subTitle,
                        displayFromVersion = displayFromVersion,
                        redirectUrl = redirectUrl,
                        btnText = btnText,
                    )

                    if (isNeedToShow
                        && BuildConfig.VERSION_CODE <= forceUpdateModel.displayFromVersion
                        && preferences.updateCancelCounter <= forceUpdateModel.cancelCounter
                    ) {
                        val updateDialog = UpdateDialog(this, forceUpdateModel)
                        updateDialog.setCancelable(forceUpdateModel.isCancelable)
                        updateDialog.show()

                        updateDialog.setOnDismissListener {
                            var updateCancelCounter = preferences.updateCancelCounter
                            updateCancelCounter++
                            preferences.updateCancelCounter = updateCancelCounter
                        }
                    } else {
                        preferences.updateCancelCounter = 0
                        checkInAppUpdate()
                    }
                } else {
                    checkInAppUpdate()
                }

//                } catch (e: Exception) {
//                    Log.d("checkForceAppUpdate", "Exception:${e.message}")
//                    checkInAppUpdate()
//                }
            } else {
                Log.d("checkForceAppUpdate", "Failed:${task.exception}")
                checkInAppUpdate()
            }
        }
    }

    private fun checkInAppUpdate() {
        Log.d("UpdateListener", "checkInAppUpdate")
        try {
            appUpdateInstallerManager.addAppUpdateListener(appUpdateInstallerListener)
            appUpdateInstallerManager.startCheckUpdate()
        } catch (e: Exception) {
            Log.e("UpdateListener", "checkAppUpdate.Exception:$e")
        }
    }

    private val appUpdateInstallerManager: AppUpdateInstallerManager by lazy {
        InAppUpdateInstallerManager(this)
    }

    private val appUpdateInstallerListener by lazy {
        object : AppUpdateInstallerListener() {
            override fun onDownloadedButNotInstalled() {
                Log.e("UpdateListener", "onDownloadedButNotInstalled")
                popupSnackBarForCompleteUpdate()
            }

            override fun onFailure(e: Exception) {
                Log.e("UpdateListener", "onFailure:$e")
            }

            override fun onNotUpdate() {
                Log.e("UpdateListener", "onNotUpdate")
            }

            override fun onCancelled() {
                Log.e("UpdateListener", "onCancelled")
            }

            override fun onStatus(@InstallStatus status: Int) {
                Log.e("UpdateListener", "onStatus:$status")
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        appUpdateInstallerManager.onActivityResult(requestCode, resultCode, data)
    }

    private fun popupSnackBarForCompleteUpdate() {
        val snackBar = Snackbar.make(
            findViewById(android.R.id.content),
            "An update has just been downloaded.",
            Snackbar.LENGTH_INDEFINITE
        )
        snackBar.setAction("RESTART") { appUpdateInstallerManager.completeUpdate() }
        snackBar.setActionTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark))
        snackBar.show()
    }

    //    var exitDialog: ExitDialog? = null
    var isRatingDialogOpened: Boolean = false
    override fun onBackPressed() {
        Log.e(
            "onBackPressed",
            "preferences.appOpenCounter.onBackPressed:${preferences.sessionCounter}"
        )

        Log.e("onBackPressed", "onBackPressed.002")
        if (binding.viewPager.currentItem == 1 && binding.groupToolbarSelectHeader.visibility == View.VISIBLE) {
            setCloseToolbar()
            //refreshData()
        } else if (binding.viewPager.currentItem == 0 && binding.groupToolbarSelectHeader.visibility == View.VISIBLE) {
            setCloseToolbar()
            //refreshData()
        } else if (binding.viewPager.currentItem != 0) {
            binding.viewPager.currentItem = 0
        } else if (!preferences.isRatingDone && !isRatingDialogOpened && listOf(
                1,
                3,
                6,
                9
            ).contains(preferences.sessionCounter)
        ) {
            Log.e("onBackPressed", "onBackPressed.003")
            isRatingDialogOpened = true
            //showExitDialog()

            val rateDialog = RateUsDialog(this) { isExit ->
                if (isExit) {
                    finishAffinity()
                }
            }
            rateDialog.show()
        } else {
            showExitDialog()
        }
//        }
    }

    private fun showExitDialog() {
        val exitDialog = ExitConfirmationDialog(this) { isExit ->
            if (isExit) {
                finishAffinity()
            }
        }

        if (!exitDialog.isShowing) {
            Log.e("onBackPressed", "onBackPressed.006")
            exitDialog.show()
        }
    }


}