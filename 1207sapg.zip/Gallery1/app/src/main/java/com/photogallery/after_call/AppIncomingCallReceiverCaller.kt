package com.photogallery.after_call

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import android.util.Log
import com.after.call.AfterCallUtils
import com.after.call.keep.AfterCallGlobal


class AppIncomingCallReceiverCaller : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == TelephonyManager.ACTION_PHONE_STATE_CHANGED) {
            Log.d(
                "AppIncomingCallReceiverCaller",
                "onReceive called with action: ${intent.action}"
            )
            when (intent.getStringExtra(TelephonyManager.EXTRA_STATE)) {
                TelephonyManager.EXTRA_STATE_IDLE -> {
                }

                TelephonyManager.EXTRA_STATE_RINGING -> {
                    if (AfterCallUtils.mAfterCallContainerFragment == null) {
                        AfterCallGlobal.setAfterCallFragment(context.let { AppContain(it) })
                    }
                }

                TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                    if (AfterCallUtils.mAfterCallContainerFragment == null) {
                        AfterCallGlobal.setAfterCallFragment(context.let { AppContain(it) })
                    }
                }
            }
        }

    }
}