package com.photogallery.utils

import android.content.Context
import android.graphics.*
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.photogallery.R

class GridScaleGestureManager(
    private val recyclerView: RecyclerView,
    context: Context,
    private var currentSpan: Int,
    private val minSpan: Int = 2,
    private val maxSpan: Int = 6,
    private val onSpanUpdated: (Int) -> Unit
) : RecyclerView.ItemDecoration() {

    init {
        recyclerView.addItemDecoration(this)
        recyclerView.setOnTouchListener { _, event ->
            scaleGestureDetector.onTouchEvent(event)
            if (event.action == MotionEvent.ACTION_UP || event.action == MotionEvent.ACTION_CANCEL) {
                if (isScaling) applyTempSpan()
            }
            false
        }
    }

    private var gestureCenterX = -1f
    private var gestureCenterY = -1f

    private var tempSpan = currentSpan
    private var scaleAccumulator = 1f
    private var isScaling = false

    private var overlayVisible = false

    private val scaleGestureDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {

            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                isScaling = true
                overlayVisible = true
//                tempSpan = currentSpan
                tempSpan = currentSpan.coerceIn(minSpan, maxSpan)
                scaleAccumulator = 1f
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                gestureCenterX = detector.focusX
                gestureCenterY = detector.focusY


                scaleAccumulator *= detector.scaleFactor
                val threshold = 1.10f
                val previousSpan = tempSpan

                // Zoom Out → decrease columns = bigger items
                if (scaleAccumulator > threshold) {
                    tempSpan = (tempSpan - 1).coerceAtLeast(minSpan)
                    scaleAccumulator = 1f
                }
                // Zoom In → increase columns = smaller items
                else if (scaleAccumulator < (1f / threshold)) {
                    tempSpan = (tempSpan + 1).coerceAtMost(maxSpan)
                    scaleAccumulator = 1f
                }

                if (tempSpan != previousSpan) {
                    performHaptic()
                }

                tempSpan = tempSpan.coerceIn(minSpan, maxSpan)
                recyclerView.invalidateItemDecorations()
                return true
            }


            override fun onScaleEnd(detector: ScaleGestureDetector) {
                applyTempSpan()
            }
        })

    private fun performHaptic() {
        recyclerView.performHapticFeedback(
            HapticFeedbackConstants.VIRTUAL_KEY,
            HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
        )
    }


    private fun applyTempSpan() {
        isScaling = false
        overlayVisible = false
        currentSpan = tempSpan.coerceIn(minSpan, maxSpan)
        onSpanUpdated(currentSpan)

    }

    private val gridPaint = Paint().apply {
        color = Color.WHITE
        strokeWidth = 4f
        alpha = 140
    }

    private val mainBgPaint = Paint().apply {
        isAntiAlias = true
    }

    var titleSize = context.resources.getDimension(com.intuit.sdp.R.dimen._45sdp)
    private val textPaint = Paint().apply {
        color = Color.WHITE
        textSize = titleSize
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }


    override fun onDrawOver(c: Canvas, parent: RecyclerView, state: RecyclerView.State) {
        if (!overlayVisible) return

        val width = parent.width
        val height = parent.height

        val startX = 0f
        val startY = 0f
        val endX = width.toFloat()
        val endY = height.toFloat()
        val gradient = LinearGradient(
            startX, startY,   // top-left (dark)
            endX, endY,       // bottom-right (light)
            intArrayOf(
                Color.parseColor("#73000000"), // darkest near top-left
                Color.parseColor("#4D000000"),
                Color.parseColor("#08000000")  // lightest bottom-right
            ),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        mainBgPaint.shader = gradient
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), mainBgPaint)

        // ===== CENTER CAPSULE WITH SPAN NUMBER =====
//        val text = tempSpan.toString()
//        val textBounds = Rect()
//        textPaint.getTextBounds(text, 0, text.length, textBounds)
        // top left text
//        val padding = 40f // adjust as needed
//        textPaint.textAlign = Paint.Align.LEFT
//        val textX = padding
//        val textY = padding - textBounds.top // ensures proper baseline
//        c.drawText(text, textX, textY, textPaint)

        // ===== CENTER TEXT =====
        val text = tempSpan.toString()
        textPaint.textAlign = Paint.Align.CENTER

        val centerX = width / 2f
        val centerY = height / 2f

        val fontMetrics = textPaint.fontMetrics
        val textY = centerY - (fontMetrics.ascent + fontMetrics.descent) / 2
        c.drawText(text, centerX, textY, textPaint)

        // ===== GRID (VERTICAL + HORIZONTAL) =====
        val colWidth = width.toFloat() / tempSpan

        // vertical lines
        for (i in 1 until tempSpan) {
            val x = i * colWidth
            c.drawLine(x, 0f, x, height.toFloat(), gridPaint)
        }

        // horizontal lines
        val rowHeight = colWidth
        val rowCount = (height / rowHeight).toInt()
        for (i in 1 until rowCount) {
            val y = i * rowHeight
            c.drawLine(0f, y, width.toFloat(), y, gridPaint)
        }
    }
}
