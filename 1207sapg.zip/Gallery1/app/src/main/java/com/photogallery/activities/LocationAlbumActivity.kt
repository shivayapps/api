package com.photogallery.activities

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.AdmobBanner
import com.adconfig.adsutil.admob.AdmobNative
import com.adconfig.adsutil.admob.BannerAdHelper
import com.adconfig.adsutil.admob.NativeAdHelper
import com.adconfig.adsutil.admob.NativeLayoutType
import com.google.android.gms.ads.AdView
import com.photogallery.R
import com.photogallery.adapter.LocationListAdapter
import com.photogallery.base.BaseActivity
import com.photogallery.customview.MyGridLayoutManager
import com.photogallery.database.AppDatabase
import com.photogallery.database.LocationEntity
import com.photogallery.databinding.ActivityMapAlbumBinding
import com.photogallery.extension.beGone
import com.photogallery.extension.getPreviousActivity
import com.photogallery.jobs.PlacesLoader
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.model.PlaceData
import com.photogallery.utils.AdUtils
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class LocationAlbumActivity : BaseActivity() {

    lateinit var activity: Activity
    lateinit var preferences: Preferences
    lateinit var dataBase: AppDatabase
    var initialLocationTitle: String = ""

    //var albumList: ArrayList<PlaceData> = ArrayList()
    var placeList: ArrayList<PlaceData> = ArrayList()
    var albumAdapter: LocationListAdapter? = null

    lateinit var binding: ActivityMapAlbumBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMapAlbumBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        initialLocationTitle = intent.getStringExtra("initialLocationTitle") ?: ""
//        dataBase = AppDatabase.getInstance(this)
        activity = this@LocationAlbumActivity
        preferences = Preferences(activity)
        loadPriorityAds()

        dataBase = AppDatabase.getInstance(activity)
        initView()
        initData()
//        getAllImagesFromGallery()
    }

    private fun initView() {
        binding.loutToolbar.icMenu.beGone()
        binding.loutToolbar.icMenu.setImageBitmap(null)
        binding.loutToolbar.txtTitle.text = getString(R.string.travel_diary)
        binding.loutToolbar.icBack.setOnClickListener {
            onBackPressed()
        }


        albumAdapter = LocationListAdapter(
            activity, placeList, false,
            clickListener = {
                val albumData = placeList[it]
                openImageList(albumData)
            })

        binding.recyclerViewPlace.adapter = albumAdapter

        val layoutManager = binding.recyclerViewPlace.layoutManager as MyGridLayoutManager
        layoutManager.orientation = RecyclerView.VERTICAL
        layoutManager.spanCount = 2
    }

    override fun onBackPressed() {
//        val previousActivity = getPreviousActivity()
        if (preferences.isNeedInterAd) {
            AdsConfig.showInterstitialAd(this) {
                if (it) preferences.isNeedInterAd = false
                finish()
            }
        } else {
            finish()
        }
    }

    private fun openImageList(placeData: PlaceData) {

        Constant.albumData = AlbumData(
            placeData.place,
            placeData.pictureData,
            "",
            0,
            0,
            isCustomAlbum = true
        )
        val intent = Intent(activity, ImageGalleryActivity::class.java)
        intent.putExtra("isFromMap", true)
        intent.putExtra("lati", placeData.lati)
        intent.putExtra("long", placeData.long)
        startActivity(intent)
    }

    private fun initData() {

        if(Constant.placeList.isNotEmpty()) {
            placeList.addAll(Constant.placeList)
//            val initial = placeList.firstOrNull { it.place == initialLocationTitle }

        }

        PlacesLoader(this@LocationAlbumActivity)
            .preparePlaceModel(onSuccess = { placeModelList ->
                placeList = placeModelList
                placeList.firstOrNull { it.place == initialLocationTitle }
                CoroutineScope(Dispatchers.Main).launch {
//                    mapragment.setData(this@MapExploreActivity, placeList, initial)
//                    gridFragment.setData(this@MapExploreActivity, placeList)

                    withContext(Dispatchers.Main) {
                        setEmptyData()
                        notifyAdapter()
                    }
                }
            }, onFailed = {

            })

//        lifecycleScope.launch(Dispatchers.IO) {
//
//            val places = dataBase.dataDao().getLocationEntityList()
//            Log.i("PlacesWorker", "places:${places.size}")
//
//            val sortedPlaces = places.sortedByDescending { it.locationId }
//
//            val newPlaceList = ArrayList<PlaceData>()
//
//            sortedPlaces.forEach { data ->
//                val file = File(data.path)
//                if (file.exists()) {
//                    val mediaData = MediaData(
//                        file.path,
//                        data.uri,
//                        file.name,
//                        file.parentFile?.name ?: "",
//                        file.lastModified(),
//                        file.lastModified(),
//                        file.length()
//                    )
//                    val existing = newPlaceList.find { it.place == data.title }
//                    if (existing != null) {
//                        existing.pictureData.add(mediaData)
//                    } else {
//                        newPlaceList.add(
//                            PlaceData(
//                                pictureData = arrayListOf(mediaData),
//                                place = data.title,
//                                lati = data.latitude,
//                                long = data.longitude
//                            )
//                        )
//                    }
//                } else {
//                    dataBase.dataDao().deleteLocationEntity(data)
//                }
//            }
//
//            placeList.clear()
//            placeList.addAll(newPlaceList)
//
//            withContext(Dispatchers.Main) {
//                setEmptyData(sortedPlaces)
//                notifyAdapter()
//            }
//        }
    }


    fun sortImage(locationEntity: List<LocationEntity>) {
        Log.e("MapExploreActivity", "sortImage:::placeList.${placeList.size}")

        this.placeList.clear()
        locationEntity.forEach { data ->

            val strKey = data.title

            val imagesData1: ArrayList<MediaData> = ArrayList()

            val file = File(data.path)
            if (file.exists()) {
                val mediaData = MediaData(
                    file.path,
                    data.uri,
                    file.name,
                    file.parentFile.name,
                    file.lastModified(),
                    file.lastModified(),
                    file.length()
                )
                for (i in this.placeList.indices) {
                    if (this.placeList[i].place == strKey) {
                        this.placeList[i].pictureData.add(mediaData)
                    }
                }

                if (this.placeList.filter { it.place == strKey }.isNullOrEmpty()) {
                    imagesData1.add(mediaData)
                    val placeData =
                        PlaceData(imagesData1, data.title, data.latitude, data.longitude)
                    this.placeList.add(placeData)
                }
            } else {
                dataBase.dataDao().deleteLocationEntity(data)
            }
        }

        Log.e("refresh_map", "placeList:${placeList.size}")
        Log.e("refresh_map", "initialLocationTitle:${initialLocationTitle}")
    }

    private fun notifyAdapter() {
        if (albumAdapter != null) {
            binding.recyclerViewPlace.post {
                albumAdapter?.notifyDataSetChanged()
            }
        }
    }

    fun getData(): ArrayList<PlaceData> {
        return placeList
    }

    fun getImageOnMap() {
        Log.e("MapExploreActivity", "getImageOnMap:::albumWisePictures:${placeList.size}")
        activity.runOnUiThread {
            if (albumAdapter != null) {
                albumAdapter?.notifyDataSetChanged()
            }
        }
    }

    private fun setEmptyData() {
        if (placeList != null && placeList.size != 0) {
            binding.recyclerViewPlace.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
        } else {
            binding.recyclerViewPlace.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
        }
    }

    private fun loadPriorityAds() {
        if (preferences.bannerPriority == "native") {
            AdmobNative().preLoad(this, AdUtils.getNativeID(this)) { isLoaded ->
                if (isLoaded) {
                    AdmobNative().showNativeAd(this, binding.frameAd)
                } else if (preferences.handleFailed) {
                    loadAdmobBanner()
                } else binding.frameAd.beGone()
            }
        } else if (preferences.bannerPriority == "banner") {
            AdmobBanner().preLoad(this, AdUtils.getBannerID(this)) { isLoaded ->
                if (isLoaded) {
                    AdmobBanner().showBannerAd(this, binding.frameAd)
                } else if (preferences.handleFailed) {
                    loadNativeBanner()
                } else binding.frameAd.beGone()
            }
        } else {
            binding.frameAd.beGone()
        }
    }

    private fun loadNativeBanner() {
        AdmobNative().preLoad(this, AdUtils.getNativeID(this)) { isLoaded ->
            if (isLoaded) {
                AdmobNative().showNativeAd(this, binding.frameAd)
            } else binding.frameAd.beGone()
        }
    }

    private fun loadAdmobBanner() {
        AdmobBanner().preLoad(this, AdUtils.getBannerID(this)) { isLoaded ->
            if (isLoaded) {
                AdmobBanner().showBannerAd(this, binding.frameAd)
            } else binding.frameAd.beGone()
        }
    }

}