package com.photogallery.secret

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.photogallery.R
import com.photogallery.base.BaseActivity
import com.photogallery.databinding.ActivityLockQuestionBinding
import com.photogallery.utils.Preferences


class LockQuestionActivity : AppCompatActivity() {

    private val TAG = "LockActivity"


    lateinit var preferences: Preferences
    private val lockListener: (Boolean) -> Unit = { isUnlock ->
        if (isUnlock) setSuccess() else finish()
    }


    var type: Int = 0//1-> Reset, 0->Set Question
    var isChangePass: Boolean = false
    private fun setSuccess() {
        setResult(RESULT_OK)
        finish()
    }

    private lateinit var binding: ActivityLockQuestionBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityLockQuestionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        preferences = Preferences(this)
        type=intent.getIntExtra("type",0)
        isChangePass=intent.getBooleanExtra("isChangePass",false)

        //setTheme(getThemeId())
        intView()
        initListeners()
    }

    private fun intView() {


        val adapter = SpinnerQueAdapter(
            this@LockQuestionActivity,
            resources.getStringArray(R.array.security_question)
        )

        binding.questionSpinner.adapter = adapter

        if (type == 1) {
            binding.questionSpinner.setSelection(preferences.securityQuestion)
        }
//        if (isChangePass) {
//            binding.btnOK.text = getString(R.string.cancel)
//        }
    }

    fun hideSoftKeyboard() {
        val inputMethodManager =
            getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        inputMethodManager.hideSoftInputFromWindow(binding.securityAnswer.windowToken, 0)
    }

    class SpinnerQueAdapter(
        private val context: Context,
        private val itemList: Array<String>
    ) : BaseAdapter() {

        override fun getCount(): Int {
            return itemList.size
        }

        override fun getItem(position: Int): Any {
            return itemList[position]
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val view: View
            val viewHolder: ViewHolder


            if (convertView == null) {
                view =
                    LayoutInflater.from(context).inflate(R.layout.item_spinner_que, parent, false)
                viewHolder = ViewHolder(view)
                view.tag = viewHolder
            } else {
                view = convertView
                viewHolder = view.tag as ViewHolder
            }

//            view.setBackgroundColor(accentColor)
            val item = itemList[position]
            viewHolder.itemTextView.text = item
            viewHolder.itemTextView.setTextColor(
                ContextCompat.getColor(
                    context,
                    R.color.black_text
                )
            )

            viewHolder.itemTextView.visibility = if (position == 0) View.GONE else View.VISIBLE

            return view
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val view: View
            val viewHolder: ViewHolder

//            val textColor = context.baseConfig.textColor
            val textColor =  ContextCompat.getColor(
                context,
                R.color.black_text
            )
//            val accentColor = context.baseConfig.backgroundColor

            if (convertView == null) {
                view =
                    LayoutInflater.from(context).inflate(R.layout.item_spinner_que, parent, false)
                viewHolder = ViewHolder(view)
                view.tag = viewHolder
            } else {
                view = convertView
                viewHolder = view.tag as ViewHolder
            }

//            view.setBackgroundColor(accentColor)
            val item = itemList[position]
            viewHolder.itemTextView.text = item
            viewHolder.itemTextView.setTextColor(textColor)
            if (position == 0) {
                viewHolder.itemTextView.setTextColor(
                    ContextCompat.getColor(
                        context,
                        R.color.black_text
                    )
                )
            } else {
                viewHolder.itemTextView.setTextColor( ContextCompat.getColor(
                    context,
                    R.color.black_text
                ))
            }

            return view
        }


        private class ViewHolder(view: View) {
            val itemTextView: TextView = view.findViewById(R.id.txtItem)
        }
    }


    private fun initListeners() {
        binding.btnCancel.setOnClickListener {
            if (isChangePass) {
                lockListener.invoke(false)
                //dismiss()
            } else {
                lockListener.invoke(false)
                //dismiss()
            }
        }

        binding.btnOK.setOnClickListener {
            val answer = binding.securityAnswer.text.toString()
            if (binding.questionSpinner.selectedItemPosition == 0)
                Toast.makeText(
                    this@LockQuestionActivity,
                    getString(R.string.please_select_que),
                    Toast.LENGTH_SHORT
                ).show()
            else if (answer.isEmpty()) {
                Toast.makeText(
                    this@LockQuestionActivity,
                    getString(R.string.please_select_que),
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                hideSoftKeyboard()
                if (isChangePass) {
                    preferences.securityQuestion =
                        binding.questionSpinner.selectedItemPosition
                    preferences.securityAnswer = answer
                    Toast.makeText(
                        this@LockQuestionActivity,
                        getString(R.string.question_change_successfully),
                        Toast.LENGTH_SHORT
                    ).show()

                    lockListener.invoke(true)
                    //dismiss()
                } else if (!preferences.getSetQuestion()) {
                    preferences.putSetQuestion(true)
                    preferences.securityQuestion =
                        binding.questionSpinner.selectedItemPosition
                    preferences.securityAnswer = answer

                    lockListener.invoke(true)
                   // dismiss()

                } else {
                    if (binding.questionSpinner.selectedItemPosition == preferences.securityQuestion) {
                        if (preferences.securityAnswer.equals(answer)) {
                            if (preferences.isPinLock) {
                                preferences.isPasscode = false
                                preferences.pincode = ""
                            } else {
                                preferences.isPatternSet = false
                                preferences.pattern = ""
                            }
                            lockListener.invoke(true)
                            //dismiss()
                        } else {
                            Toast.makeText(
                                this@LockQuestionActivity,
                                R.string.msg_security_ans,
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } else Toast.makeText(
                        this@LockQuestionActivity,
                        R.string.msg_security_que,
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

        }
    }


    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}