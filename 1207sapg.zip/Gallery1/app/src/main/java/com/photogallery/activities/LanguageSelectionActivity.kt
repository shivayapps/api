package com.photogallery.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.flexbox.AlignItems
import com.google.android.flexbox.FlexDirection
import com.google.android.flexbox.FlexboxLayoutManager
import com.adconfig.AdsConfig
import com.adconfig.adsutil.Config.checkReInter
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.NativeAdHelper
import com.adconfig.adsutil.admob.NativeLayoutType
import com.google.android.flexbox.FlexWrap
import com.photogallery.R
import com.photogallery.adapter.LanguageSelectionAdapter
import com.photogallery.base.BaseActivity
import com.photogallery.databinding.ActivityLanguageBinding
import com.photogallery.extension.getLanguageList
import com.photogallery.model.LanguageData
import com.photogallery.utils.Constant
import com.photogallery.utils.LogEvent
import com.photogallery.utils.Preferences
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class LanguageSelectionActivity : BaseActivity() {

    lateinit var binding: ActivityLanguageBinding

    lateinit var adapter: LanguageSelectionAdapter
    var selectedLang = "0"
    var isOpenFromSplash: Boolean = false
    lateinit var preferences: Preferences
    var languageList: ArrayList<LanguageData> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        if (preferences.isNeedInterAd) {
            AdmobIntersAdImpl().load(this, getString(R.string.inter_language))
        } else {
            checkReInter {
                if (it) {
                    AdmobIntersAdImpl().load(this, getString(R.string.inter_language))
                    preferences.isNeedInterAd = true
                }
            }
        }
        binding = ActivityLanguageBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        inti()
        loadAd()
    }

    private fun loadAd() {
        NativeAdHelper(
            this,
            binding.frameNative,
            NativeLayoutType.NativeBig,
            getString(R.string.native_language)
        ).loadAd()
    }

    private fun inti() {
        preferences.isSetLanguage = true
        binding.txtTitle.text = getString(R.string.select_language)
        binding.ivDone.visibility = View.VISIBLE

        if (intent != null)
            isOpenFromSplash = intent.getBooleanExtra(Constant.EXTRA_IS_OPEN_FROM_SPLASH, false)


        val calendar = Calendar.getInstance()
        val format = SimpleDateFormat("dd/mm/yy", Locale.ENGLISH)
        val today = format.format(calendar.timeInMillis)
        LogEvent.logEvent("LanguageActivity", "FromSplash:$today")

        //getLanList()
        languageList = getLanguageList(preferences.systemLocalLanguage)
        intiListener()

        binding.icBack.visibility = if (isOpenFromSplash) View.INVISIBLE else View.VISIBLE

        selectedLang = preferences.selectLanguageCode
        var selectPos = languageList.indexOfFirst { it.languageCode == selectedLang }

//        val defaultLanguage: String = Locale.getDefault().language
//        preferences.systemLocalLanguage = defaultLanguage
        if (selectPos <= 0) selectPos = 0
        if (selectedLang == "0") selectedLang = preferences.systemLocalLanguage

        Log.e("LanguageActivity", "systemLocalLanguage:${preferences.systemLocalLanguage}")
        Log.e("LanguageActivity", "selectedLang:$selectedLang")
        Log.e("LanguageActivity", "selectPos:$selectPos")

        val gridLayoutManager = GridLayoutManager(this, 1, RecyclerView.VERTICAL, false)
        binding.recyclerView.layoutManager = gridLayoutManager

        adapter = LanguageSelectionAdapter(
            this,
            languageList,
            clickListener = {
                //selectPos = it
                selectedLang = it
            })
        adapter.selectPos = selectPos
        adapter.selectLang = selectedLang
        binding.recyclerView.adapter = adapter
        binding.recyclerView.scrollToPosition(selectPos)
        if (selectPos >= 0) {
            binding.recyclerView.scrollToPosition(selectPos)
            enableNext()
        }


    }

    fun enableNext() {
//        binding.loutToolbar.ivDone.beVisible()
//        val myAnim = AnimationUtils.loadAnimation(this, R.anim.bounce);
//        val interpolator = MyBounceInterpolator(0.2, 20.0)
//        myAnim.setInterpolator(interpolator)
//        myAnim.repeatMode = Animation.RESTART
//        binding.loutToolbar.ivDone.startAnimation(myAnim)
    }

    private fun updateViews(languageCode: String) {
        com.photogallery.utils.LocaleHelper.setLocale(
            this,
            languageCode
        )
    }

    private var lastClickTime = 0L
    private fun intiListener() {
        binding.icBack.setOnClickListener {
            finish()
        }
        binding.ivDone.setOnClickListener {
            val currentTime = System.currentTimeMillis()
            if (currentTime - lastClickTime >= 800) {
                lastClickTime = currentTime

                preferences.isSetLanguage = true
                preferences.selectLanguageCode = selectedLang

                if (selectedLang == "0") {
                    updateViews(preferences.systemLocalLanguage)
                } else {
                    updateViews(selectedLang)
                }
                if (isOpenFromSplash) {
                    val intent = if (!checkStoragePermission())
                        Intent(this, PermissionActivity::class.java)
                    else
                        Intent(this, HomeActivity::class.java)

                    if (preferences.isNeedInterAd) {
                        AdsConfig.showInterstitialAd(this@LanguageSelectionActivity) {
                            if (it) preferences.isNeedInterAd = false
                            startActivity(intent)
                            finish()
                        }
                    } else {
                        startActivity(intent)
                        finish()
                    }
                } else {

                    if (preferences.isNeedInterAd) {
                        AdsConfig.showInterstitialAd(this@LanguageSelectionActivity) {
                            if (it) preferences.isNeedInterAd = false
                            setResult(RESULT_OK)
                            finish()
                        }
                    } else {
                        setResult(RESULT_OK)
                        finish()
                    }
                }
            }
        }

    }

}