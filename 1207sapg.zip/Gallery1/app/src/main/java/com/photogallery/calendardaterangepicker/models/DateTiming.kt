package com.photogallery.calendardaterangepicker.models

internal enum class DateTiming {
    NONE,
    START,
    END
}
