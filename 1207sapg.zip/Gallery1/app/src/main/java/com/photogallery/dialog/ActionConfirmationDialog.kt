package com.photogallery.dialog

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import com.photogallery.databinding.DialogConfirmationBinding
import com.photogallery.utils.DIALOG_DIM_AMOUNT

class ActionConfirmationDialog(
    var mContext: Context,
    var title: String,
    var msg: String,
    var actionPositive: String,
    val positiveBtnClickListener: () -> Unit,
    var isPermanentlyDelete: Boolean = false,
    var actionCancel: String = "",
) : Dialog(mContext) {

    lateinit var bindingDialog: DialogConfirmationBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        window?.setDimAmount(DIALOG_DIM_AMOUNT)
        window?.attributes?.windowAnimations = android.R.style.Animation_Dialog
//        window?.decorView!!.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        bindingDialog = DialogConfirmationBinding.inflate(layoutInflater)
//        bindingDialog.root.setPadding(0, 0, 0, mContext.navigationBarHeight)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
    }

//    override fun onCreateView(
//        inflater: LayoutInflater, container: ViewGroup?,
//        savedInstanceState: Bundle?
//    ): View {
//        bindingDialog = DialogConfirmationBinding.inflate(layoutInflater, container, false)
//        intView()
//        return bindingDialog.root
//    }

    private fun intView() {

//        bindingDialog.txtTitle.text = title
        bindingDialog.txtMsg.text = msg
        bindingDialog.btnDelete.text = actionPositive
        if (actionCancel.isNotEmpty())
            bindingDialog.btnCancel.text = actionCancel

        bindingDialog.txtRestoredMsg.visibility =
            if (isPermanentlyDelete) View.VISIBLE else View.GONE

        bindingDialog.btnCancel.setOnClickListener { dismiss() }
        bindingDialog.btnDelete.setOnClickListener {
            dismiss()
            positiveBtnClickListener()
        }
    }

//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)

}