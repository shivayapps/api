package com.photogallery.base

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.AssetManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat

import androidx.appcompat.app.AppCompatActivity
import com.adconfig.AdsConfig
import com.photogallery.R
import com.photogallery.extension.setStatusBarFontColor
import com.photogallery.extension.updateStatusBarColor
import com.photogallery.utils.Constant
import com.photogallery.utils.LocaleHelper
import com.photogallery.utils.Preferences
import com.photogallery.utils.sendEvent
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

open class BaseActivity : AppCompatActivity() {

    var applyStatusBar = true
    var themeType = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation =
            if (Build.VERSION.SDK_INT < 9)
                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT

        themeType = Preferences(this).getThemeValue()

        setAppTheme()
//        hideSystemUI()
    }

    override fun onResume() {
        super.onResume()
        setAppTheme()
    }

    var settingLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val intent = intent
                finish()
                overridePendingTransition(0, 0)
                startActivity(intent)
                overridePendingTransition(0, 0)
                Constant.isChangeLanguage = false
            } else if (Constant.isChangeLanguage) {
                Constant.isChangeLanguage = false
                val intent = intent
                finish()
                overridePendingTransition(0, 0)
                startActivity(intent)
                overridePendingTransition(0, 0)
            }
        }


    var mainBaseContext: Context? = null
    override fun attachBaseContext(base: Context?) {
        mainBaseContext = base
        super.attachBaseContext(LocaleHelper.onAttach(
                base, "en"
            )
        )
    }

    fun getAppVersion(): String? {
        try {
            val packageInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                packageManager.getPackageInfo(packageName, 0)
//                packageManager.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
            } else {
                packageManager.getPackageInfo(packageName, 0)
            }
            return packageInfo.versionName
        } catch (e: PackageManager.NameNotFoundException) {
            Log.e("printStackTrace", "printStackTrace:$e")
        }
        return null
    }

    fun getScreenWidth(): Int {
        val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        return windowManager.defaultDisplay.width
    }

    fun saveEditImage(bitmap: Bitmap, saveImageName: String, quality: Int = 70): String? {
        val dir = File(cacheDir.absolutePath + "/Edit")
        if (!dir.exists()) dir.mkdirs()

        val pictureFile = File(dir.path + "/" + saveImageName)
        if (pictureFile.exists()) {
            pictureFile.delete()
            MediaScannerConnection.scanFile(
                this@BaseActivity, arrayOf(pictureFile.path), null
            ) { path, uri ->

            }
        }

        var out: FileOutputStream? = null
        try {
            out = FileOutputStream(pictureFile.path)
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)
            val mediaScanIntent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
            val contentUri = Uri.fromFile(pictureFile)
            mediaScanIntent.data = contentUri
            sendBroadcast(mediaScanIntent)
            MediaScannerConnection.scanFile(
                this@BaseActivity, arrayOf(pictureFile.path), null
            ) { path, uri ->

            }
            return pictureFile.path
        } catch (e: Exception) {
            Log.e("printStackTrace", "printStackTrace:$e")
        }
        return null
    }

    fun getSaveEditPath(saveImageName: String): String {
        val dir = File(cacheDir.absolutePath)
        if (!dir.exists()) dir.mkdirs()

        val pictureFile = File(dir.path + "/" + saveImageName)
        if (pictureFile.exists()) {
            pictureFile.delete()
            MediaScannerConnection.scanFile(
                this@BaseActivity, arrayOf(pictureFile.path), null
            ) { path, uri ->

            }
        }
        return pictureFile.path
    }

    fun setAppTheme() {
        when (themeType) {
            Constant.THEME_LIGHT -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

                window?.decorView?.post {
//                    if (applyStatusBar) setStatusBarFontColor(Preferences(this).appThemePrimary < 2)
                    if (applyStatusBar) setStatusBarFontColor(true)
                }
            }

            Constant.THEME_DARK -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                window?.decorView?.post {
                    if (applyStatusBar) setStatusBarFontColor(false)
                }
            }
        }
        if (applyStatusBar) {
            updateStatusBarColor(ContextCompat.getColor(this, R.color.status_bar))
        }
//        when (themeType) {
//            Constant.THEME_LIGHT -> {
//                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
//            }
//
//            Constant.THEME_DARK -> {
//                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
//            }
//        }
//        updateStatusBarColor(ContextCompat.getColor(this, R.color.status_bar))
    }

    fun getPrivacyPolicy(): String {
        return "https://sites.google.com/view/shivay-innovations/home?read_current=1"
    }

    fun checkStoragePermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            val result = ContextCompat.checkSelfPermission(
                this, Manifest.permission.READ_EXTERNAL_STORAGE
            )
            val result1 = ContextCompat.checkSelfPermission(
                this, Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
            result == PackageManager.PERMISSION_GRANTED && result1 == PackageManager.PERMISSION_GRANTED
        }
    }



}