package com.photogallery.messaging

import android.Manifest
import android.app.Notification
import android.app.Notification.VISIBILITY_PUBLIC
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Build
import android.provider.MediaStore
import android.service.notification.StatusBarNotification
import android.util.Log
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.bumptech.glide.Glide
import com.photogallery.BuildConfig
import com.photogallery.R
import com.photogallery.activities.HomeActivity
import com.photogallery.extension.notificationManager
import com.photogallery.extension.realScreenSize
import com.photogallery.utils.Preferences
import java.io.File
import java.util.Calendar
import java.util.concurrent.TimeUnit
import kotlin.text.toInt
import kotlin.times

object Notifier {
    private val TAG = "Notifier"
    private val notifierId = 1563


    data class ImageResult(
        val path: String,
        val isPortrait: Boolean,
        val isHd: Boolean
    )

    val portraitTitles = listOf(
        "Portrait perfection 📸",
        "A stunning portrait awaits ✨",
        "Your best portrait moments ❤️",
        "Captured beautifully 🌟"
    )

    val portraitMessages = listOf(
        "Revisit your beautiful portrait shots",
        "Your portrait memories look amazing",
        "A perfect portrait deserves another look",
        "See your favorite portrait moments again"
    )

    val hdTitles = listOf(
        "Crystal clear memories 🖼️",
        "Relive your HD moments ✨",
        "Your gallery looks incredible 📷",
        "High-quality memories await 🌟"
    )

    val hdMessages = listOf(
        "Enjoy your stunning HD photos again",
        "Your high-resolution memories are waiting",
        "Rediscover your sharpest captures",
        "Turn your HD shots into something amazing"
    )

    val randomTitles = listOf(
        "Check your gallery 📸",
        "Come back to your gallery",
        "Create something amazing ✨",
        "We miss you 📸",
        "Relive your memories 📸",
        "A memory worth revisiting ✨",
        "Your gallery misses you ❤️",
        "Moments captured forever 🌟"
    )

    val randomMessages = listOf(
        "You have new moments to explore",
        "Your memories are waiting",
        "Check your latest photos",
        "Turn your recent photos into a video",
        "Rediscover your gallery memories",
        "Take another look at your favorite moments",
        "Your memories are waiting for you",
        "Open your gallery and rediscover moments",
        "Create something special from your photos"
    )


    val memoryTitle = listOf(
        "Relive your memories 📸",
        "Moments from this day",
        "Your memories are waiting"
    )

    val memoryMessages = listOf(
        "See what you captured on this day",
        "Photos from past years are ready",
        "Take a look at your gallery"
    )
    val creationTitle = listOf(
        "Create something amazing ✨",
        "Turn photos into magic"
    )

    val creationMessages = listOf(
        "Make a collage from recent photos",
        "Create a video in seconds"
    )


    private fun getRandomImage(context: Context): ImageResult {

        val matchedImages = mutableListOf<ImageResult>()

        val projection = arrayOf(
            MediaStore.Images.Media.DATA,
            MediaStore.Images.Media.WIDTH,
            MediaStore.Images.Media.HEIGHT
        )

        val queryUri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {

            MediaStore.Images.Media.EXTERNAL_CONTENT_URI.buildUpon()
                .appendQueryParameter("limit", "100")
                .build()

        } else {
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        }

        val sortOrder =
            "${MediaStore.Images.Media.DATE_ADDED} DESC LIMIT 100"

        try {

            context.contentResolver.query(
                queryUri,
                projection,
                null,
                null,
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    "${MediaStore.Images.Media.DATE_ADDED} DESC"
                } else {
                    sortOrder
                }
            )?.use { cursor ->

                val idPath =
                    cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
                val idColumn =
                    cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)

                val widthColumn =
                    cursor.getColumnIndexOrThrow(MediaStore.Images.Media.WIDTH)

                val heightColumn =
                    cursor.getColumnIndexOrThrow(MediaStore.Images.Media.HEIGHT)

                while (cursor.moveToNext()) {

                    val path = cursor.getString(idPath)

                    if (!File(path).exists()) continue
                    val width = cursor.getInt(widthColumn)
                    val height = cursor.getInt(heightColumn)

//                    val width = cursor.getInt(
//                        cursor.getColumnIndex(MediaStore.Images.Media.WIDTH)
//                    )
//
//                    val height = cursor.getInt(
//                        cursor.getColumnIndex(MediaStore.Images.Media.HEIGHT)
//                    )

                    val isHd = width >= 1920 || height >= 1920
                    val isPortrait = height > width

                    if (isHd || isPortrait) {

                        matchedImages.add(
                            ImageResult(
                                path = path,
                                isPortrait = isPortrait,
                                isHd = isHd
                            )
                        )
                    }
                }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }

        return matchedImages.randomOrNull()
            ?: ImageResult(
                path = "",
                isPortrait = false,
                isHd = false
            )
    }


    fun scheduleNow(
        context: Context,
    ) {
        val image =
            getRandomImage(context)

        val content = when {

            image.isPortrait ->
                NotificationContentProvider.portrait()

            image.isHd ->
                NotificationContentProvider.hd()

            isUserInactive(context) ->
                NotificationContentProvider.generic()

            else ->
                NotificationContentProvider.memory()
        }
        show(
            context,
            content.title,
            content.body,
            image.path
        )
    }


    fun showHomeNotification(context: Context) {

    }
    fun showHomeNotificationX(context: Context) {

        Log.e("POST_NOTIFICATIONS", "showHomeNotification")

        val homeIntent = Intent(context, HomeActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val homePendingIntent = PendingIntent.getActivity(
            context, 1,
            homeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )


        NotificationChannels.createHomeNotificationChannel(context)

        val manager =
            NotificationManagerCompat.from(context)

        val remoteViews = RemoteViews(context.packageName, R.layout.custom_notification_big)

        remoteViews.setOnClickPendingIntent(
            R.id.homeButton,
            homePendingIntent
        )

        remoteViews.setOnClickPendingIntent(
            R.id.favoriteButton,
            createHomePendingIntent(context, "favorite")
        )

        remoteViews.setOnClickPendingIntent(
            R.id.travelButton,
            createHomePendingIntent(context, "travel")
        )

        remoteViews.setOnClickPendingIntent(
            R.id.noteButton,
            createHomePendingIntent(context, "notes")
        )

        val builder =
            NotificationCompat.Builder(context, NotificationChannels.DEFAULT_NOTIFICATION)
                .setSmallIcon(R.drawable.ic_notification_logo)
                .setCustomBigContentView(remoteViews)
                .setCustomContentView(remoteViews)
                .setStyle(
                    NotificationCompat.DecoratedCustomViewStyle()
                )
                .setOngoing(true)
                .setSilent(true)
                .setOnlyAlertOnce(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)


        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        notificationManager.notify(448899, builder.build())

    }

    fun createHomePendingIntent(
        context: Context,
        type: String
    ): PendingIntent {

        val intent =
            Intent(context, HomeActivity::class.java).apply {

                putExtra("type", type)

                flags =
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP
            }

        return PendingIntent.getActivity(
            context,
            type.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or
                    PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun show(
        context: Context,
        title: String,
        body: String,
        imagePath: String?
    ) {

        NotificationChannels.create(context)

        val intent = Intent(
            context,
            HomeActivity::class.java
        ).apply {

            flags =
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP
        }

        val pendingIntent =
            PendingIntent.getActivity(
                context,
                1001,
                intent,
                PendingIntent.FLAG_IMMUTABLE or
                        PendingIntent.FLAG_UPDATE_CURRENT
            )

        val builder =
            NotificationCompat.Builder(
                context,
                NotificationChannels.ENGAGEMENT
            )
                .setSmallIcon(R.drawable.ic_notification_logo)
                .setContentTitle(title)
                .setContentText(body)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)


        val bitmap = try {
            if (!imagePath!!.startsWith("http")) {
                BitmapFactory.decodeFile(imagePath)
            } else {
                Glide.with(context).asBitmap().load(imagePath)
                    .override((context.realScreenSize.x * 0.7).toInt()).submit().get()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }

        if (bitmap != null) {
            val style = NotificationCompat.BigPictureStyle().bigPicture(bitmap)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                style.showBigPictureWhenCollapsed(true)
            }
            builder.setStyle(style)
        }


        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        notificationManager.notify(System.currentTimeMillis().toInt(), builder.build())
    }

    private fun loadBitmapSafely(
        path: String
    ): Bitmap? {

        return try {

            BitmapFactory.decodeFile(path)

        } catch (e: Exception) {

            null
        }
    }


    fun showOld(context: Context, title: String, body: String, imagePath: String) {
        val channelId = "gallery_engagement"

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Engagement",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            manager.createNotificationChannel(channel)
        }


        var intent = Intent(context, HomeActivity::class.java)

        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pendingIntent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_IMMUTABLE)
        } else {
            PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_IMMUTABLE)
        }


        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notificationBuilder =
            NotificationCompat.Builder(context, "StoryNotification").setContentTitle(title)
                .setContentText(body).setSmallIcon(R.drawable.ic_notification_logo)
                .setPriority(NotificationCompat.PRIORITY_HIGH).setContentIntent(pendingIntent)
                .setDefaults(NotificationCompat.DEFAULT_ALL).setAutoCancel(true)
                .setOnlyAlertOnce(true)
//        if (bitmap != null) {
//            val style = NotificationCompat.BigPictureStyle().bigPicture(bitmap)
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
//                style.showBigPictureWhenCollapsed(true)
//            }
//            notificationBuilder.setStyle(style)
//        }

        imagePath.takeIf { it.isNotEmpty() }?.let {

            loadBitmapSafely(it)?.let { bitmap ->

                notificationBuilder.setStyle(
                    NotificationCompat.BigPictureStyle()
                        .bigPicture(bitmap)
                )
            }
        }

        notificationBuilder.setVibrate(LongArray(0))

        notificationBuilder.setChannelId("MemoryNotification")
        val mChannel = NotificationChannel(
            "MemoryNotification", "Memory Notification", NotificationManager.IMPORTANCE_HIGH
        )
        mChannel.description = "Notifications are info related."
        mChannel.lockscreenVisibility = VISIBILITY_PUBLIC
        mChannel.enableLights(true)
        mChannel.lightColor = Color.RED
        mChannel.enableVibration(true)
        mChannel.setShowBadge(true)
        mChannel.vibrationPattern = longArrayOf(100, 200, 300, 400, 500, 400, 300, 200, 400)
        notificationBuilder.setBadgeIconType(NotificationCompat.BADGE_ICON_SMALL)
        notificationManager.createNotificationChannel(mChannel)
        //cancelFCMDefaultNotification(context)
        notificationManager.notify(notifierId, notificationBuilder.build())

        Preferences(context).setLastNotificationTime(context)
    }

    private fun cancelFCMDefaultNotification(context: Context) {
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notifications: Array<StatusBarNotification> = notificationManager.activeNotifications

        Log.e(TAG, "notifications Size: " + notifications.size)
        notifications.forEach {
            if ((it.tag != null && it.tag.contains(
                    "fcm", ignoreCase = true
                )) || it.notification.channelId.equals(
                    "silentFirebase", ignoreCase = true
                ) || it.notification.channelId.equals(
                    "fcm_fallback_notification_channel", ignoreCase = true
                ) || it.notification.channelId.equals(
                    "fcm_notification", ignoreCase = true
                )
            ) {
                notificationManager.cancel(it.tag, it.id)
            }
        }


    }

    fun scheduleRandomWorker(context: Context) {
        val type = when {
            isUserInactive(context) -> "INACTIVE"
            hasRecentPhotos(context) -> "CREATION"
            else -> "MEMORY"
        }

        val (title, body) = Notifier.getRandomMessage(type)

        Notifier.show(
            context,
            title,
            body,
            ""
        )
    }


    fun scheduleDailyWorker(context: Context) {
        scheduleWorker(
            context = context,
            uniqueName = "gallery_engagement_morning",
            hour = 7,
            minute = 30
        )

        scheduleWorker(
            context = context,
            uniqueName = "gallery_engagement_evening",
            hour = 19,
            minute = 30
        )
    }


    private fun scheduleWorker(
        context: Context,
        uniqueName: String,
        hour: Int,
        minute: Int
    ) {
        val now = Calendar.getInstance()

        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)

            if (before(now)) {
                add(Calendar.DAY_OF_MONTH, 1)
            }
        }

        val delay = target.timeInMillis - now.timeInMillis

        val request = PeriodicWorkRequestBuilder<EngagementWorker>(
            1,
            TimeUnit.DAYS
        )
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            uniqueName,
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }


    fun scheduleRandom(context: Context) {

        val now = Calendar.getInstance()

        val target = Calendar.getInstance().apply {

            set(Calendar.HOUR_OF_DAY, (0..23).random())

            set(Calendar.MINUTE, (0..59).random())

            set(Calendar.SECOND, 0)

            if (before(now)) {
                add(Calendar.DAY_OF_MONTH, 1)
            }
        }

        val initialDelay =
            target.timeInMillis - now.timeInMillis

        val constraints = Constraints.Builder()
            .setRequiresBatteryNotLow(true)
            .build()

        val request =
            PeriodicWorkRequestBuilder<EngagementWorker>(
                12,
                TimeUnit.HOURS
            )
                .setInitialDelay(initialDelay, TimeUnit.MILLISECONDS)
                .setConstraints(constraints)
                .build()

        WorkManager.getInstance(context)
            .enqueueUniquePeriodicWork(
                "gallery_engagement_work",
                ExistingPeriodicWorkPolicy.UPDATE,
                request
            )
    }

    fun scheduleDailyWorker0(context: Context) {

        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 19)
            set(Calendar.MINUTE, 30)
            set(Calendar.SECOND, 0)
        }

        if (target.before(now)) {
            target.add(Calendar.DAY_OF_MONTH, 1)
        }

        val delay = target.timeInMillis - now.timeInMillis

        val request = PeriodicWorkRequestBuilder<EngagementWorker>(1, TimeUnit.DAYS)
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "gallery_engagement",
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    fun isUserInactive(context: Context): Boolean {
        val lastOpen = Preferences(context).lastAppOpen(context)
        val hours = (System.currentTimeMillis() - lastOpen) / (1000 * 60 * 60)
        return hours > 48
    }

    fun hasRecentPhotos(context: Context): Boolean {

        val uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Images.Media.DATE_ADDED)

        val cutoff = (System.currentTimeMillis() / 1000) - (48 * 60 * 60)

        val selection = "${MediaStore.Images.Media.DATE_ADDED} > ?"
        val selectionArgs = arrayOf(cutoff.toString())

        context.contentResolver.query(
            uri,
            projection,
            selection,
            selectionArgs,
            null
        )?.use {
            return it.count > 15
        }

        return false
    }

    fun getRandomMessage(type: String): Pair<String, String> {

        return when (type) {

            "MEMORY" -> {
                Pair(memoryTitle.random(), memoryMessages.random())
            }

            "CREATION" -> {
                Pair(creationTitle.random(), creationMessages.random())
            }

            "INACTIVE" -> {
                Pair(randomTitles.random(), randomMessages.random())
            }

            else -> Pair(randomTitles.random(), randomMessages.random())
        }
    }
}