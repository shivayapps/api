package com.photogallery.activities

import android.annotation.SuppressLint
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.addTextChangedListener
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.AdsConfig
import com.adconfig.adsutil.Config.checkReInter
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.bumptech.glide.Glide
import com.photogallery.R
import com.photogallery.adapter.PhotoAdapter
import com.photogallery.adapter.TimeLineAdapter
import com.photogallery.base.BaseActivity
import com.photogallery.customview.MyGridLayoutManager
import com.photogallery.database.AppDatabase
import com.photogallery.database.LocationEntity
import com.photogallery.databinding.ActivitySearchBinding
import com.photogallery.dialog.CalendarDialog
import com.photogallery.extension.beGone
import com.photogallery.extension.beGoneIf
import com.photogallery.extension.beVisible
import com.photogallery.extension.getParentFolder
import com.photogallery.extension.onTextChangeListener
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences
import com.photogallery.utils.TYPE_GIFS
import com.photogallery.utils.TYPE_IMAGES
//import com.photogallery.utils.TYPE_PORTRAITS
//import com.photogallery.utils.TYPE_RAWS
//import com.photogallery.utils.TYPE_SVGS
import com.photogallery.utils.TYPE_VIDEOS
import com.photogallery.utils.Utils
import com.photogallery.utils.photoExtensions
import com.photogallery.utils.rawExtensions
import com.photogallery.utils.videoExtensions
import com.photogallery.viewpager.PhotoVideoActivity
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.toString


class SearchActivity : BaseActivity() {

    var allList = ArrayList<Any>()
    var allBackList = ArrayList<MediaData>()
    lateinit var dataBase: AppDatabase

    var searchAdapter: PhotoAdapter? = null

    var placeList: ArrayList<AlbumData> = ArrayList()

    lateinit var preferences: Preferences
    var isSearch: Boolean = false
    var isStopSearch: Boolean = false
    var startDate = 0L
    var endDate = 0L

    lateinit var binding: ActivitySearchBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        if (preferences.isNeedInterAd) {
            AdmobIntersAdImpl().load(this, getString(R.string.inter_all))
        } else {
            checkReInter {
                if (it) {
                    AdmobIntersAdImpl().load(this, getString(R.string.inter_all))
                    preferences.isNeedInterAd = true
                }
            }
        }
        binding = ActivitySearchBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        dataBase = AppDatabase.getInstance(this)
        initView()
    }

    private fun initView() {
        binding.icBack.setOnClickListener {
            onBackPressed()
        }

        binding.icSearchClear.setOnClickListener {
            binding.edtSearch.setText("")
            hideKeyboard(binding.edtSearch)
        }


        binding.edtSearch.onTextChangeListener { str ->
            if (str.isEmpty()) {
                binding.icSearchClear.visibility = View.GONE
                searchHandle.removeCallbacks(searchRunnable)
                search()
            } else {
                binding.icSearchClear.visibility = View.VISIBLE
                searchHandle.removeCallbacks(searchRunnable)
                searchHandle.postDelayed(searchRunnable, 800)
            }

        }

        initAdapters()

        setPlaceData()
        getData()

    }


    private val searchHandle = Handler(Looper.getMainLooper())
    private val searchRunnable = Runnable {
        search()
    }

    private fun search() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val strSearch = binding.edtSearch.text.toString().lowercase()
                Log.e("setSearch", "strSearch:$strSearch")

                val filteredList = if (strSearch.isNotEmpty()) {
                    allBackList.filter {
                        it.fileName.lowercase().contains(strSearch, true) ||
                                it.folderName.lowercase().contains(strSearch, true)
                    }
                } else {
                    emptyList()
                }

                withContext(Dispatchers.Main) {
                    allList.clear()
                    allList.addAll(filteredList)

                    //binding.txtCount.text = "${allList.size} ${getString(R.string.photos)}"

                    chunkAndSubmitList(allList)
                    if (allList.size != 0) {
                        binding.searchRecycler.beVisible()
                        binding.loutNoData.beGone()
                    } else {
                        binding.searchRecycler.beGone()
                        binding.loutNoData.beVisible()
                    }

//                    setEmptyData()

                }
            } catch (e: Exception) {
                Log.e("setSearch", "exception:$e")
            }
        }
    }

    override fun onBackPressed() {
        if (preferences.isNeedInterAd) {

            AdsConfig.showInterstitialAd(this) {
                if (it) preferences.isNeedInterAd = false
                finish()
            }
        } else {
            super.onBackPressed()
        }
    }

    fun hideKeyboard(view: EditText) {
        view.clearFocus()
        val methodManager = (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.hideSoftInputFromWindow(view.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
    }

    private fun showKeyboard(view: EditText) {
        view.requestFocus()
        val methodManager = (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun openImageList(albumData: AlbumData) {
        Constant.albumData = AlbumData(
            albumData.title,
            albumData.mediaData,
            "",
            0,
            0,
            isCustomAlbum = true
        )
        val intent = Intent(this, ImageGalleryActivity::class.java)
        if (albumData.lati > 0 && albumData.long > 0) {
            intent.putExtra("isFromMap", true)
            intent.putExtra("lati", albumData.lati)
            intent.putExtra("long", albumData.long)
        }
        startActivity(intent)
    }

    fun initAdapters() {

        //Init Search Adapter
        allList = ArrayList()
        searchAdapter = PhotoAdapter(
            this, clickListener = {
                if (allList[it] is MediaData) {
                    val pictureData = allList[it] as MediaData
                    if (pictureData.isCheckboxVisible) {
                        pictureData.isSelected = !pictureData.isSelected
                        searchAdapter?.notifyItemChanged(it)
//                        setSelectedFile()
                    } else {
                        val dataList = ArrayList<MediaData>()
                        var displayPos = 0
                        for (i in allList.indices) {
                            if (allList[i] is MediaData) {
                                dataList.add(allList[i] as MediaData)
                                if (it == i) {
                                    displayPos = dataList.size - 1
                                }
                            }
                        }
                        Constant.displayImageList = ArrayList()
                        Constant.displayImageList.addAll(dataList)
                        Constant.selectedPosition = displayPos
//                        val intent = Intent(this@SearchActivity, ImageViewerActivity::class.java)
                        if (Constant.displayImageList.size > 0) {
                            val intent = Intent(this@SearchActivity, PhotoVideoActivity::class.java)
                            intent.putExtra(Constant.EXTRA_DISPLAY_POS, displayPos)
                            startActivity(intent)
                        }
//                        selectAlbum()
                    }
                }
            },
            longClickListener = {

            },
            headerSelectListener = {

            }, true, 100
        )

        chunkAndSubmitList(allList)
//        val gridCount = preferences.getGridCount()
        val layoutManager = binding.searchRecycler.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = 3
        layoutManager.orientation = RecyclerView.VERTICAL
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                if (position >= 0 && position < allList.size) {
                    return if (searchAdapter!!.getItemViewType(position) === searchAdapter!!.ITEM_HEADER_TYPE) {
                        3
                    } else 1
                } else {
                    return 1
                }
            }
        }
        binding.searchRecycler.adapter = searchAdapter
    }

    private fun chunkAndSubmitList(data: List<Any>, chunkSize: Int = 100) {
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val totalSize = data.size
                var start = 0
                while (start < totalSize) {
                    val end = (start + chunkSize).coerceAtMost(totalSize)
                    val chunk = data.subList(start, end)
                    searchAdapter?.submitList(searchAdapter?.currentList.orEmpty() + chunk)
                    start = end
                    delay(50) // Introduce a slight delay to ensure UI responsiveness
                }
            } catch (e: java.lang.IndexOutOfBoundsException) {
                e.printStackTrace()
            } catch (e: IndexOutOfBoundsException) {
                e.printStackTrace()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun setPlaceData() {
        val place = dataBase.dataDao().getLocationEntityList()
        if (place.isNotEmpty()) {
            sortPlace(place)
        }
        //else binding.llPlace.beGone()
    }

    private fun sortPlace(places: List<LocationEntity>) {
        Log.e("MapExploreActivity", "sortImage:::placeList.${placeList.size}")

        places.forEach { data ->
            val strKey = data.title

            var imagesData1: ArrayList<MediaData> = ArrayList()

            val file = File(data.path)
            val pictureData = MediaData(
                file.path,
                Utils.getUriFromPath(this@SearchActivity, file.path).toString(),
                file.name,
                file.parentFile.name,
                file.lastModified(),
                file.lastModified(),
                file.length()
            )
            for (i in placeList.indices) {
                if (placeList[i].title == strKey) {
                    placeList[i].mediaData.add(pictureData)
                }
            }

            if (placeList.filter { it.title == strKey }.isNullOrEmpty()) {
                imagesData1.add(pictureData)
                val placeData = AlbumData(
                    title = data.title,
                    mediaData = imagesData1,
                    lati = data.latitude,
                    long = data.longitude
                )
                placeList.add(placeData)
            }
        }

        setData()
    }

    @SuppressLint("CheckResult")
    fun setSearch(searchText: String) {
        val strSearch = searchText.lowercase()
        if (isSearch) isStopSearch = true

        Observable.fromCallable<Boolean> {
            isSearch = true
            allList.clear()
            if (strSearch.isEmpty()) {
                allList.clear()
            } else {

                val list = allBackList.filter {
                    it.fileName.lowercase().contains(strSearch)
                            || it.folderName.lowercase().contains(strSearch)
                }

                if (!isStopSearch) {
                    if (list.isNotEmpty()) {
                        allList.addAll(list)
                    }
                }
            }
            //if (!isStopSearch) setList()

            true
        }.subscribeOn(Schedulers.io())
            .doOnError { throwable: Throwable? ->
                runOnUiThread {
                    isSearch = false
                    isStopSearch = false
                    setData()
                }
            }
            .subscribe { result: Boolean? ->
                runOnUiThread {
                    isStopSearch = false
                    isSearch = false
                    setData()
                }
            }
    }

    private fun setData() {
        Log.e("gettingListPhoto", "Data is show")
        runOnUiThread {
            notifyAdapter()
            setEmptyData()
        }

    }


    private fun setEmptyData() {
        if (allList != null && allList.size != 0) {
            binding.searchRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
        } else {
            binding.searchRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
        }
    }


    private fun openAlbumList(key: String, albumData: ArrayList<AlbumData>) {
        Constant.albumList = albumData
        val intent = Intent(this, AlbumExplorerActivity::class.java)
        intent.putExtra("title", "$key")
        intent.putExtra("showTimeline", true)
        startActivity(intent)
    }

    fun getData() {

        Glide.get(this).clearMemory()
        Observable.fromCallable {
            Glide.get(this).clearDiskCache()
            allList.clear()
            getImages()
            getVideos()
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { throwable: Throwable? ->
                //setFilterData()
            }
            .subscribe { result: Boolean? ->
                //setFilterData()
            }
    }

    private fun getImages() {
        Log.e("gettingListPhoto", "getImages")
        val mCursor: Cursor?
        val folderList: MutableList<String> = ArrayList<String>()
//        folderList.addAll(preferencesManager.getExcludeFolderList())
        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())
        try {
            val BUCKET_DISPLAY_NAME: String
            BUCKET_DISPLAY_NAME = MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
            val projection = arrayOf(
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DATA,
                BUCKET_DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_MODIFIED,
                MediaStore.MediaColumns.DATE_TAKEN,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.SIZE,
            )
            val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            } else {
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            }

            val filterMedia = preferences.getFilterMedia()
            val selection = getSelectionQuery(filterMedia)
            val selectionArgs = getSelectionArgsQuery(filterMedia).toTypedArray()

            mCursor = contentResolver.query(
                uri,  // Uri
                projection,  // Projection
                selection,
                selectionArgs,
                MediaStore.MediaColumns.DATE_MODIFIED + " DESC"
            )
            if (mCursor != null) {
                mCursor.moveToFirst()
                ArrayList<MediaData>()
                mCursor.moveToFirst()
                while (!mCursor.isAfterLast) {
                    //2sec
                    val path =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))
                    val title =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME))
                    var bucketPath = ""
                    bucketPath = path.substring(0, path.lastIndexOf(title) - 1)

                    var bucketName =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(BUCKET_DISPLAY_NAME))
                    if (bucketName == null) bucketName = path.getParentFolder()

                    val fileSizeLength =
                        mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
                    val idColumn = mCursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                    val id = mCursor.getLong(idColumn)
                    val contentUri = ContentUris.withAppendedId(uri, id)


                    if (!folderList.contains(bucketPath) && !bucketName.isNullOrEmpty()) {
                        var d =
                            mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED))
                        d *= 1000
                        var dt =
                            mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))
                        dt *= 1000
                        if (dt == 0L)
                            dt = d

                        val pictureData =
                            MediaData(
                                path,
                                contentUri.toString(),
                                title, bucketName, d, dt, fileSizeLength, false
                            )
                        pictureData.isFavorite = favList.contains(path)
//                        allList.add(pictureData)
                        allBackList.add(pictureData)

//                        imageCount++
                    }
                    mCursor.moveToNext()
                }
                mCursor.close()
            }
        } catch (e: Exception) {
            Log.e("printStackTrace", "printStackTrace:$e")
        }
    }

    private fun getVideos() {
        Log.e("gettingListPhoto", "getVideos")
        var title: String
        var path: String
        val duration: Int
        val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Video.VideoColumns._ID,
            MediaStore.Video.VideoColumns.DATA,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.VideoColumns.SIZE,
            MediaStore.Video.VideoColumns.DURATION,
            MediaStore.Video.VideoColumns.DATE_MODIFIED,
            MediaStore.Video.VideoColumns.DATE_TAKEN,
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
        )
        val folderList: MutableList<String> = ArrayList<String>()
//        folderList.addAll(preferencesManager.getExcludeFolderList())
        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())
        try {
            val filterMedia = preferences.getFilterMedia()
            val selection = getSelectionQuery(filterMedia)
            val selectionArgs = getSelectionArgsQuery(filterMedia).toTypedArray()

            val cursor = contentResolver.query(
                uri,
                projection,
                selection,
                selectionArgs,
                MediaStore.Video.VideoColumns.DATE_MODIFIED + " DESC"
            )
            if (cursor != null) {
                duration = cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DURATION)
                cursor.moveToFirst()
                while (!cursor.isAfterLast) {
                    path =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA))
                    title =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME))
                    var bucketName =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME))
                    if (bucketName == null) bucketName = path.getParentFolder()
                    val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns._ID)
                    val id = cursor.getLong(idColumn)
                    val contentUri = ContentUris.withAppendedId(uri, id)

                    var bucketPath = ""
                    bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
                    if (!folderList.contains(bucketPath)) {
                        var d =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DATE_MODIFIED))
                        d *= 1000
                        val fileSizeLength =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
                        var dt =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))
                        dt *= 1000
                        if (dt == 0L)
                            dt = d
                        val pictureData = MediaData(
                            path,
                            contentUri.toString(),
                            title,
                            bucketName,
                            d,
                            dt,
                            fileSizeLength,
                            true,
                            cursor.getLong(duration)
                        )
                        pictureData.isFavorite = favList.contains(path)
                        pictureData.isVideo = true
//                        allList.add(pictureData)
                        allBackList.add(pictureData)

//                        videoCount++
                    }
                    cursor.moveToNext()
                }
                cursor.close()
            }
        } catch (exp: java.lang.Exception) {
            exp.printStackTrace()
        }
    }

    private fun notifyAdapter() {

        if (searchAdapter != null) {
//            binding.txtCount.text = "${allList.size} ${getString(R.string.photos)}"
            searchAdapter?.notifyDataSetChanged()
        }

//        if (timeLineAdapter != null)
//            timeLineAdapter?.notifyDataSetChanged()
    }


    private fun getSelectionQuery(filterMedia: Int): String {
        val query = StringBuilder()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")

            rawExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }



        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
        }


        if (filterMedia and TYPE_GIFS != 0) {
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }


        return query.toString().trim().removeSuffix("OR")
    }

    private fun getSelectionArgsQuery(filterMedia: Int): ArrayList<String> {
        val args = ArrayList<String>()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.jpg")
            args.add("%.jpeg")
            rawExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.svg")
        }
        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                args.add("%$it")
            }
        }

        if (filterMedia and TYPE_GIFS != 0) {
            args.add("%.gif")
        }


        return args
    }


}