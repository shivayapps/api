package com.photogallery.model

//data class RadioItem(val id: Int, val title: String, val value: Any = id)

data class UpdateModel(
    val isNeedToShow: Boolean = false,
    val isCancelable: Boolean = false,
    val cancelCounter: Int = 0,
    val latestVersion: String = "",
    val mainTitle: String = "",
    val subTitle: String = "",
    val displayFromVersion: Int = 0,
    val redirectUrl: String = "",
    val btnText: String = "",
)

