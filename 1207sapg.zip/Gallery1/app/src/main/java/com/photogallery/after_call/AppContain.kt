package com.photogallery.after_call

import android.content.Context
import android.util.AttributeSet
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.provider.MediaStore
import androidx.core.splashscreen.SplashScreen
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.after.call.keep.CallerContainer
import com.after.call.utils.CallerOnSingleClickListener
import com.photogallery.SplashActivity
import com.photogallery.databinding.CallerMainViewBinding
import com.photogallery.jobs.cleaner.LoaderUtilMedia
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences
import java.io.File


class AppContain @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null,
) : CallerContainer(context, attrs) {

    override fun getContainer(): View {
        val binding = CallerMainViewBinding.inflate(LayoutInflater.from(context))

        var validList = ArrayList(
            Preferences(context)
                .getPortraitList()
                .filter { path ->
                    File(path).exists()
                }
        )

        if (validList.isEmpty()) {
            validList = getPortraitRecentPhotos(context)
            Preferences(context).setPortraitList(validList)
        } else {

            Preferences(context).setPortraitList(validList)
        }

        Log.e("AfterCall", "validList:${validList.size}")

        Log.e("AfterCall", "validList:${validList.size}")
        Preferences(context).setPortraitList(validList)

        val imageAdapter = AfterCallAdapter(validList, {
            startScreenName(SplashActivity::class.java)
            finish()
        })
//        val zzBeeLayout = findViewById<ZzBeeLayout>(R.id.bee)
//        binding.beeLayout.setImageUrls(
//            validList.toTypedArray()
//        )
        val staggeredGridLayoutManager =
            StaggeredGridLayoutManager(3, StaggeredGridLayoutManager.HORIZONTAL)

        binding.rvPhotos.layoutManager = staggeredGridLayoutManager
        binding.rvPhotos.setHasFixedSize(true)
        binding.rvPhotos.adapter = imageAdapter


        return binding.root
    }

    override fun onFinishInflate() {
        super.onFinishInflate()
    }

    private fun getPortraitRecentPhotos(mContext: Context): ArrayList<String> {

        val imageList = ArrayList<String>()

        try {

            val uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI

            val projection = arrayOf(
                MediaStore.Images.Media.DATA,
                MediaStore.Images.Media.WIDTH,
                MediaStore.Images.Media.HEIGHT
            )

            val selection =
                "${MediaStore.Images.Media.SIZE} > 0"

            val sortOrder =
                "${MediaStore.Images.Media.DATE_ADDED} DESC LIMIT 50"

            val cursor = mContext.contentResolver.query(
                uri,
                projection,
                selection,
                null,
                sortOrder
            )

            cursor?.use {

                val pathColumn =
                    it.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)

                val widthColumn =
                    it.getColumnIndexOrThrow(MediaStore.Images.Media.WIDTH)

                val heightColumn =
                    it.getColumnIndexOrThrow(MediaStore.Images.Media.HEIGHT)

                while (it.moveToNext() && imageList.size < 20) {

                    val path = it.getString(pathColumn)
                    val width = it.getInt(widthColumn)
                    val height = it.getInt(heightColumn)

                    if (!path.isNullOrEmpty()
                        && File(path).exists()
                        && height > width
                    ) {

                        imageList.add(path)
                    }
                }
            }

        } catch (e: Exception) {

            Log.e("AfterCall", "getPortraitRecentPhotos: ${e.message}")
        }

        return imageList
    }


}