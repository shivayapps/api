package com.photogallery.dialog

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.RadioGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.photogallery.databinding.DialogResetStyleBinding
import com.photogallery.extension.beVisibleIf
import com.photogallery.utils.DIALOG_DIM_AMOUNT
import com.photogallery.utils.Preferences


class ResetStyleDialog(
    var mContext: Activity,
    val methodListener: (methodSelected: Int) -> Unit
) : Dialog(mContext) {

    lateinit var bindingDialog: DialogResetStyleBinding
    var preferences: Preferences = Preferences(mContext)
    var securityMail = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        window?.setDimAmount(DIALOG_DIM_AMOUNT)
        window?.attributes?.windowAnimations = android.R.style.Animation_Dialog

        bindingDialog = DialogResetStyleBinding.inflate(layoutInflater)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
        intListener()
    }

    private fun intView() {

        securityMail = preferences.securityEmail
        if (securityMail.isNotEmpty()) {
            bindingDialog.rbEmail.isChecked = true
        }

    }

    private fun intListener() {
        bindingDialog.btnCancel.setOnClickListener {
            dismiss()
        }
        bindingDialog.btnOK.setOnClickListener {
            val selectedRadioButtonId: Int = bindingDialog.grpOption.checkedRadioButtonId
            var typeSelected = when (selectedRadioButtonId) {
                bindingDialog.rbEmail.id -> 1
                bindingDialog.rbSecurityQue.id -> 2
                else -> 1
            }
            methodListener.invoke(typeSelected)
            dismiss()
        }

    }


}

