package com.photogallery.dialog

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.viewbinding.ViewBinding
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.photogallery.R
import com.photogallery.databinding.DialogDeleteBinding
import com.photogallery.utils.DIALOG_DIM_AMOUNT


class DeleteDialog(
    var mContext: Context
) : Dialog(mContext) {

    var btnClickListener: ((isPermanent: Boolean) -> Unit)? = null
    var useDarkMode: Boolean? = false

    companion object {
        fun newInstance(mContext: Context, btnClickListener: ((isPermanent: Boolean) -> Unit)?, darkMode: Boolean? = true): DeleteDialog {
            val deleteDialog = DeleteDialog(mContext)
            deleteDialog.btnClickListener = btnClickListener
            deleteDialog.useDarkMode = darkMode
            return deleteDialog
        }
    }

    lateinit var bindingDialog: DialogDeleteBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        window?.setDimAmount(DIALOG_DIM_AMOUNT)
        window?.attributes?.windowAnimations = android.R.style.Animation_Dialog


        bindingDialog = DialogDeleteBinding.inflate(layoutInflater)

        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
    }


    private fun intView() {
        bindingDialog.root.findViewById<TextView>(R.id.txtRestoredMsg).visibility = View.GONE
        bindingDialog.root.findViewById<TextView>(R.id.btnCancel).setOnClickListener { dismiss() }
        bindingDialog.root.findViewById<TextView>(R.id.btnDelete).setOnClickListener {
            dismiss()
            btnClickListener?.invoke(false)
        }
        bindingDialog.root.findViewById<TextView>(R.id.btnPermanent).setOnClickListener {
            dismiss()
            btnClickListener?.invoke(true)
        }
    }

//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)
}