package com.photogallery.model

import android.graphics.drawable.Drawable
import androidx.annotation.Keep


data class LanguageData(
    var languageTitle: String,
    var languageSubTitle: String,
    var languageCode: String,
    //var icon: Int
)