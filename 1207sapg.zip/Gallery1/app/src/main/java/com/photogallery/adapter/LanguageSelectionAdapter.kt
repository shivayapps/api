package com.photogallery.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.photogallery.R
import com.photogallery.databinding.ItemLanguageBinding
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.model.LanguageData

class LanguageSelectionAdapter(
    var context: Context,
    var list: ArrayList<LanguageData>,
    val clickListener: (selectLang: String) -> Unit
) :
    RecyclerView.Adapter<LanguageSelectionAdapter.ViewHolder>() {

    //var selectPos = -1
    var selectPos = 0
    var selectLang = "en"

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemLanguageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.tvTitle.text = list[position].languageTitle
        holder.binding.tvSubTitle.text = list[position].languageSubTitle

        if (selectPos == position) {
            holder.binding.ivSelect.beVisible()
        } else {
            holder.binding.ivSelect.beGone()
        }

        holder.binding.root.setOnClickListener {
            val p = selectPos
            selectPos = position
            selectLang = list[position].languageCode
            clickListener(selectLang)
            notifyItemChanged(selectPos)
            if (p != -1)
                notifyItemChanged(p)
        }
    }

    class ViewHolder(var binding: ItemLanguageBinding) : RecyclerView.ViewHolder(binding.root)
}