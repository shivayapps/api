package com.photogallery

import android.app.Activity
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Resources
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.telephony.TelephonyManager
import android.util.Log
import androidx.annotation.Keep
import androidx.appcompat.app.AppCompatDelegate
import com.adconfig.AdsConfig
import com.adconfig.adsutil.AdsParameters
import com.adconfig.adsutil.openad.AppOpenApplication
import com.adconfig.adsutil.openad.OpenAdHelper
import com.adconfig.adsutil.openad.OpenAdHelper.isShowOpenAd
import com.after.call.activity.AfterCallHomeActivity
import com.after.call.extensions.callerCadBaseConfig
import com.after.call.extensions.fetchAfterCallRemote
import com.after.call.keep.AfterCallGlobal
import com.after.call.keep.CallerFirebaseEventListener
import com.after.call.utils.AppCategoriesIcon

import com.github.ajalt.reprint.core.Reprint
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseApp
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.crashlytics.FirebaseCrashlytics
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.photogallery.activities.HomeActivity
import com.squareup.picasso.Downloader
import com.squareup.picasso.Picasso
import com.photogallery.activities.PermissionActivity
import com.photogallery.after_call.AppIncomingCallReceiverCaller
import com.photogallery.extension.getValidLanguageCode
import com.photogallery.messaging.Notifier
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences
import com.photogallery.utils.TIME_FORMAT_12
import com.photogallery.utils.TIME_FORMAT_24
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.util.Locale

class GalleryApp : AppOpenApplication(), AppOpenApplication.AppLifecycleListener {

    lateinit var remoteConfig: FirebaseRemoteConfig
    override fun onCreate() {
        super.onCreate()
//        com.photogallery.GalleryApp.Companion.mContext = applicationContext

        Reprint.initialize(this)
        Picasso.setSingletonInstance(Picasso.Builder(this).downloader(object : Downloader {
            override fun load(request: Request) = Response.Builder().build()

            override fun shutdown() {}
        }).build())

        preferences = Preferences(applicationContext)
        FirebaseApp.initializeApp(applicationContext)
        FirebaseCrashlytics.getInstance()
            .setCrashlyticsCollectionEnabled(!BuildConfig.VERSION_NAME.contains("test"))

        MobileAds.initialize(applicationContext)
        remoteConfig = FirebaseRemoteConfig.getInstance()
        remoteConfig.reset()
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(applicationContext)

        val AdmobAppOpenId = getString(R.string.open_all)

        AdsConfig.builder()
            .setTestDeviceId("43D54D26FD5DBC346211511E0DFD64F9")
            .setAdmobAppOpenId(AdmobAppOpenId)
            .build(this)

        setAppLifecycleListener(this)
        initMobileAds()

//        OpenAdHelper.loadOpenAd(this)

        fireBaseConfigGet()

        Constant.themeType = preferences.getThemeValue()
        setAppTheme(Constant.themeType)
        val dateFormat = preferences.dateFormat
        val timeFormat = if (preferences.use24HourFormat) TIME_FORMAT_24 else TIME_FORMAT_12
        Constant.dateFormat = dateFormat
        Constant.timeFormat = timeFormat

        val defaultLanguage = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            getValidLanguageCode(Resources.getSystem().configuration.locale.language)
        } else {
            getValidLanguageCode(Locale.getDefault().language)
        }
        Log.e("LanguageSetup","defaultLanguage.001:${Resources.getSystem().configuration.locale.language}")
        Log.e("LanguageSetup","defaultLanguage.002:${Locale.getDefault().language}")
        Log.e("LanguageSetup","defaultLanguage.003:$defaultLanguage")
        preferences.systemLocalLanguage = defaultLanguage
        Log.e("LanguageSetup","systemLocalLanguage:${preferences.systemLocalLanguage}")
        Log.e("LanguageSetup","selectLanguageCode:${preferences.selectLanguageCode}")


        Notifier.scheduleDailyWorker(this)

        setupAfterCall()
    }

    public fun setupAfterCall() {
        val screenUnlockReceiver = AppIncomingCallReceiverCaller()
        val filter = IntentFilter()

        filter.addAction(Intent.ACTION_BOOT_COMPLETED)
        filter.addAction(Intent.ACTION_MY_PACKAGE_REPLACED)
        filter.addAction(Intent.ACTION_POWER_CONNECTED)
        filter.addAction(Intent.ACTION_SCREEN_OFF)
        filter.addAction(Intent.ACTION_SCREEN_ON)
        filter.addAction(Intent.ACTION_POWER_DISCONNECTED)
        filter.addAction(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
        applicationContext.registerReceiver(screenUnlockReceiver, filter)

        AfterCallGlobal.initializeAfterCall(
            this, AppCategoriesIcon.CALLER_CAD_APP_PHOTOGRAPHY, false, HomeActivity::class.java,
            object : CallerFirebaseEventListener {
                override fun onEventListen(eventName: String) {
                    Log.e("onEventListen", " ---- $eventName")
                }
            }
        )

        AfterCallGlobal.setBackIconInAfterCall(this, R.drawable.ic_back)
        onAfterCallAppConfig()
    }

    @Keep
    private fun onAfterCallAppConfig() {
        Log.i("RemoteConfigData", "lastFetchTime - ${callerCadBaseConfig.lastFetchTime}")
        fetchAfterCallRemote(this, 0) {
            Log.e("RemoteConfigData ---->>>", "Success")
        }
    }

    fun setAppTheme(themeType: Int) {
        Log.d("GalleryApp", "setAppTheme")
//        themeType = Preferences(this).getThemeValue()
        when (themeType) {
            Constant.THEME_LIGHT -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }

            Constant.THEME_DARK -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            }
        }
        Log.d("GalleryApp", "setAppTheme.002")
    }

    private fun fireBaseConfigGet() {
        try {
            remoteConfig.setConfigSettingsAsync(
                FirebaseRemoteConfigSettings.Builder()
                    .setMinimumFetchIntervalInSeconds(5)
                    .setFetchTimeoutInSeconds(5)
                    .build()
            )

            remoteConfig.setDefaultsAsync(R.xml.remote_config_defaults)
            remoteConfig.fetch(0)
                .addOnCompleteListener { task: Task<Void?> ->
                    var errorString = ""
                    if (task.isSuccessful) {
                        Log.e("fireBaseConfigGet", "Successful")
                        remoteConfig.fetchAndActivate()

                        val force_update = remoteConfig.getString("force_update")
                        Log.e("force_update", "force_update:$force_update")

                        try {
                            val ads_parameter = remoteConfig.getString("gallery_ads_pref")
                            Log.e("fireBaseConfigGet", "ads_parameter:$ads_parameter")

                            if (ads_parameter.isNotEmpty()) {
                                val jsonObject = JSONObject(ads_parameter)

                                try {
                                    preferences.bannerPriority =
                                        jsonObject.getString("banner_priority")
                                } catch (e: Exception) {
                                    Log.e("fireBaseConfigGet", "Exception.splash_time_out:$e")
                                }

                                try {
                                    preferences.handleFailed =
                                        jsonObject.getBoolean("handle_failed")
                                } catch (e: Exception) {
                                    Log.e("fireBaseConfigGet", "Exception.enable_consent:$e")
                                }
                            }

                        } catch (e: Exception) {
                            Log.e("fireBaseConfigGet", "home_banner_type.Exception:$e")
                        }

                        errorString = " task is successful  "

                    } else {
                        Log.e("fireBaseConfigGet", "Failed:${task.exception}")
                        errorString = "task is canceled"
                    }
                }
        } catch (e: java.lang.Exception) {
            Log.e("printStackTrace", "printStackTrace:$e")
        }
    }

    companion object {
        lateinit var mFirebaseAnalytics: FirebaseAnalytics
        lateinit var preferences: Preferences

//        fun getContext(): Context {
//            return mContext
//        }

    }

    //    override fun onPauseApp(fCurrentActivity: Activity) {
//
//    }
    override fun onResumeApp(fCurrentActivity: Activity): Boolean {
        if (fCurrentActivity is SplashActivity) {
            return false
        } else if (fCurrentActivity is AfterCallHomeActivity) {
            return false
        } else if (fCurrentActivity is PermissionActivity) {
            return false
        } else if (AdsConfig.isSystemDialogOpen) {
            Handler(Looper.getMainLooper()).postDelayed({
                AdsConfig.isSystemDialogOpen = false
            }, 2000)
            return false
        }
        return true
    }

//    override fun onAppOpenCreatedEvent(fCurrentActivity: Activity) {
//        if (onResumeApp(fCurrentActivity))
//            if (!fCurrentActivity.isDestroyed && !fCurrentActivity.isFinishing) {
//                val intent = Intent(fCurrentActivity, WelcomeBackActivity::class.java)
//                intent.putExtra("isAdLoading", OpenAdHelper.isAdLoading)
//                fCurrentActivity.startActivity(intent)
//            }
//    }

    override fun onAppOpenCreatedEvent(fCurrentActivity: Activity) {
        if (onResumeApp(fCurrentActivity))
            if (!fCurrentActivity.isDestroyed && !fCurrentActivity.isFinishing) {
                if (OpenAdHelper.isAdAvailable()) {
                    fCurrentActivity.isShowOpenAd { success ->
                        //finish()
                    }
                }
            }
    }


}
