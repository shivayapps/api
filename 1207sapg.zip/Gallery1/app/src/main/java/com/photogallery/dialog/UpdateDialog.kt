package com.photogallery.dialog

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.Window
import android.view.WindowManager
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.adconfig.AdsConfig
import com.photogallery.R
import com.photogallery.base.BaseActivity
import com.photogallery.databinding.DialogUpdateBinding
import com.photogallery.model.UpdateModel
import com.photogallery.utils.DIALOG_DIM_AMOUNT

class UpdateDialog(
    var activity: BaseActivity,
    val forceUpdateModel: UpdateModel
) : Dialog(activity) {

    lateinit var bindingDialog: DialogUpdateBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.setDimAmount(DIALOG_DIM_AMOUNT)
        window?.navigationBarColor = ContextCompat.getColor(activity, R.color.dialogBg)
        window?.setGravity(Gravity.BOTTOM)

        bindingDialog = DialogUpdateBinding.inflate(layoutInflater)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT
        )
        setCancelable(forceUpdateModel.isCancelable)
        intView()

    }

    private fun intView() {
        intListener()

        LayoutInflater.from(activity)
        bindingDialog.txtVersion.text = forceUpdateModel.latestVersion
        bindingDialog.txtMsg.text = forceUpdateModel.subTitle

    }

    private fun launchAppStore() {
//        AdsConfig.isNeedAppOpenAd = false
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("http://play.google.com/store/apps/details?id=${activity.packageName}")
        )
        activity.startActivity(intent)
    }

    private fun intListener() {
        bindingDialog.btnOK.setOnClickListener {
            launchAppStore()
        }
    }

//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)
}