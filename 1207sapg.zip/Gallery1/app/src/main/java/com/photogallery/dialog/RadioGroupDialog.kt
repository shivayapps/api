package com.photogallery.dialog

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.fragment.app.DialogFragment
import com.photogallery.R
import com.photogallery.databinding.DialogRadioGroupBinding
import com.photogallery.model.RadioItem
import com.photogallery.utils.DIALOG_DIM_AMOUNT
import com.photogallery.utils.Preferences

class RadioGroupDialog(
    val activity: Activity,
    val items: ArrayList<RadioItem>,
    val checkedItemId: Int = -1,
    val updateListener: (pos: Int) -> Unit
) : Dialog(activity) {

    lateinit var bindingDialog: DialogRadioGroupBinding
    lateinit var preferences: Preferences
    private var wasInit = false
    private var selectedItemId = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        window?.setDimAmount(DIALOG_DIM_AMOUNT)
        window?.attributes?.windowAnimations = android.R.style.Animation_Dialog
//        window?.decorView!!.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        bindingDialog = DialogRadioGroupBinding.inflate(layoutInflater)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
    }


    private fun intView() {
        preferences = Preferences(activity)

        bindingDialog.grpOption.apply {
            for (i in 0 until items.size) {
                val radioButton =
                    (layoutInflater.inflate(R.layout.radio_button, null) as RadioButton).apply {
                        text = items[i].title
                        isChecked = items[i].id == checkedItemId
                        id = i
                        setOnClickListener { itemSelected(i) }
                    }

                if (items[i].id == checkedItemId) {
                    selectedItemId = i
                }

                addView(
                    radioButton,
                    RadioGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                )
            }
        }

        wasInit = true
//        val groupBtn = when (groupBy) {
//            Constant.GROUP_BY_NONE -> bindingDialog.groupingDialogRadioNone
//            else -> bindingDialog.groupingDialogRadioNone
//        }
//        groupBtn.isChecked = true


    }

    private fun itemSelected(checkedId: Int) {
        if (wasInit) {
            dismiss()
            updateListener(items[checkedId].id)

        }
    }

}