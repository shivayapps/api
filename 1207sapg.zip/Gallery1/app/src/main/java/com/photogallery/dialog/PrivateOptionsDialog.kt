package com.photogallery.dialog

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
//import com.google.firebase.analytics.FirebaseAnalytics
import com.photogallery.databinding.DialogPrivateMenuBinding
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.utils.DIALOG_DIM_AMOUNT
import com.photogallery.utils.Preferences

class PrivateOptionsDialog(val mContext: Context, val clickListener: (type: Int) -> Unit) :
    Dialog(mContext) {

    lateinit var preferences: Preferences
    lateinit var binding: DialogPrivateMenuBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        window?.setDimAmount(DIALOG_DIM_AMOUNT)
        window?.attributes?.windowAnimations = android.R.style.Animation_Dialog
//        window?.decorView!!.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        binding = DialogPrivateMenuBinding.inflate(layoutInflater)
//        bindingDialog.root.setPadding(0, 0, 0, mContext.navigationBarHeight)
        setContentView(binding.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
    }

    private fun intView() {
        preferences = Preferences(mContext)
        if (preferences.securityEmail.isNotEmpty()) {
            binding.btnSetMail.beGone()
            binding.btnChangeMail.beVisible()
        } else {
            binding.btnSetMail.beVisible()
            binding.btnChangeMail.beGone()
        }
        intListener()
    }

    private fun intListener() {
        binding.btnChangePass.setOnClickListener {
            dismiss()
            clickListener(1)
        }
        binding.btnSetMail.setOnClickListener {
            dismiss()
            clickListener(2)
        }
        binding.btnChangeMail.setOnClickListener {
            dismiss()
            clickListener(2)
        }
        binding.btnChangeQue.setOnClickListener {
            dismiss()
            clickListener(3)
        }
        binding.btnChangeLockStyle.setOnClickListener {
            dismiss()
            clickListener(4)
        }
//        binding.btnFeedback.setOnClickListener {
////            val intent = Intent(activity, FeedbackActivity::class.java)
////            startActivity(intent)
//            dismiss()
//            clickListener(5)
//        }
        binding.btnSetting.setOnClickListener {
            dismiss()
            clickListener(6)
        }
        binding.btnRecycleBin.setOnClickListener {
            dismiss()
            clickListener(7)
        }
    }

//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)
}