package com.photogallery.activities

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.AdsConfig
import com.adconfig.adsutil.Config.checkReInter
import com.adconfig.adsutil.admob.AdmobBanner
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.AdmobNative
import com.adconfig.adsutil.admob.BannerAdHelper
import com.adconfig.adsutil.admob.NativeAdHelper
import com.adconfig.adsutil.admob.NativeLayoutType
import com.google.android.gms.ads.AdView
import com.photogallery.R
import com.photogallery.adapter.AlbumListAdapter
import com.photogallery.adapter.PhotoAdapter
import com.photogallery.base.BaseActivity
import com.photogallery.customview.MyGridLayoutManager
import com.photogallery.databinding.ActivityExploreAlbumBinding
import com.photogallery.dialog.CalendarDialog
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.utils.AdUtils
import com.photogallery.utils.Constant
import com.photogallery.utils.FastScroller
import com.photogallery.utils.Preferences
//import com.photogallery.utils.TYPE_PORTRAITS
//import com.photogallery.utils.TYPE_RAWS
//import com.photogallery.utils.TYPE_SVGS
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class AlbumExplorerActivity : BaseActivity() {

    var allList = ArrayList<Any>()
    var allBackList = ArrayList<MediaData>()
    var albumList: ArrayList<AlbumData> = ArrayList()

    var albumAdapter: AlbumListAdapter? = null
    lateinit var preferences: Preferences

    lateinit var activity: Activity

    var searchAdapter: PhotoAdapter? = null
    lateinit var binding: ActivityExploreAlbumBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        if (preferences.isNeedInterAd) {
            AdmobIntersAdImpl().load(this, getString(R.string.inter_all))
        } else {
            checkReInter {
                if (it) {
                    AdmobIntersAdImpl().load(this, getString(R.string.inter_all))
                    preferences.isNeedInterAd = true
                }
            }
        }
        binding = ActivityExploreAlbumBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        loadPriorityAds()
        activity = this@AlbumExplorerActivity

        albumList = Constant.albumList

        initView()

    }

    private fun loadPriorityAds() {
        if (preferences.bannerPriority == "native") {
            AdmobNative().preLoad(this, AdUtils.getNativeID(this)) { isLoaded ->
                if (isLoaded) {
                    AdmobNative().showNativeAd(this, binding.frameAd)
                } else if (preferences.handleFailed) {
                    loadAdmobBanner()
                } else binding.frameAd.beGone()
            }
        } else if (preferences.bannerPriority == "banner") {
            AdmobBanner().preLoad(this, AdUtils.getBannerID(this)) { isLoaded ->
                if (isLoaded) {
                    AdmobBanner().showBannerAd(this, binding.frameAd)
                } else if (preferences.handleFailed) {
                    loadNativeBanner()
                } else binding.frameAd.beGone()
            }
        } else {
            binding.frameAd.beGone()
        }
    }

    private fun loadNativeBanner() {
        AdmobNative().preLoad(this, AdUtils.getNativeID(this)) { isLoaded ->
            if (isLoaded) {
                AdmobNative().showNativeAd(this, binding.frameAd)
            } else binding.frameAd.beGone()
        }
    }

    private fun loadAdmobBanner() {
        AdmobBanner().preLoad(this, AdUtils.getBannerID(this)) { isLoaded ->
            if (isLoaded) {
                AdmobBanner().showBannerAd(this, binding.frameAd)
            } else binding.frameAd.beGone()
        }
    }

    private fun initView() {
        if (intent.hasExtra("title")) {
            binding.txtTitle.text = intent.getStringExtra("title")
        }

        intListener()
        initAdapter()
    }

    private fun initAdapter() {
        setRvLayoutManager()

        albumAdapter = AlbumListAdapter(
            activity,
            clickListener = {
                val albumData = albumList[it]
                openImageList(albumData)
            },
            longClickListener = {
            })

        albumAdapter?.submitList(albumList)
        binding.albumRecycler.adapter = albumAdapter


        binding.albumRecycler.post {
            FastScroller(binding.handleView).bind(binding.albumRecycler)
        }
    }

    fun openImageList(albumData: AlbumData) {

        Constant.albumData = AlbumData(
            albumData.title,
            albumData.mediaData,
            albumData.folderPath,
            albumData.date,
            albumData.fileSize
        )

        val intent = Intent(activity, ImageGalleryActivity::class.java)
        if (albumData.lati > 0 && albumData.long > 0) {
            intent.putExtra("isFromMap", true)
            intent.putExtra("lati", albumData.lati)
            intent.putExtra("long", albumData.long)
        }
        startActivity(intent)
//        setBackAlbumData()
    }

    fun setBackAlbumData() {
        Constant.albumList.clear()
        for (albumData in albumList) {
            Constant.albumList.add(
                AlbumData(
                    albumData.title,
                    albumData.mediaData,
                    albumData.folderPath,
                    albumData.date,
                    albumData.fileSize
                )
            )
        }
    }

    fun setRvLayoutManager() {
        val gridCount = preferences.getGridCount()
        val isGridShow = preferences.getShowGrid()
        if (isGridShow) {
            val layoutManager = binding.albumRecycler.layoutManager as MyGridLayoutManager
            layoutManager.orientation = RecyclerView.VERTICAL
            layoutManager.spanCount = gridCount
//            layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
//                override fun getSpanSize(position: Int): Int {
//                    if (position >= 0 && position < albumList.size) {
////                        if (albumAdapter!!.getItemViewType(position) === albumAdapter!!.ITEM_ALBUM_HEADER_TYPE) {
//                        return gridCount
////                        } else return  1
//                    } else {
//                        return 1
//                    }
//                }
//            }
        } else {
            val layoutManager = binding.albumRecycler.layoutManager as MyGridLayoutManager
            layoutManager.spanCount = 1
            layoutManager.orientation = RecyclerView.VERTICAL
//            mZoomListener = null
        }
    }

    private fun setEmptyData() {
        if (albumList != null && albumList.size != 0) {
            binding.albumRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
            binding.llAdPlace.beVisible()
        } else {
            binding.albumRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
            binding.llAdPlace.beGone()
        }
    }

    private fun intListener() {

        binding.icBack.setOnClickListener {
            onBackPressed()
        }

//        binding.icMenu.setOnClickListener {
//            showTimeline()
//        }

    }

    var startDate = 0L
    var endDate = 0L
    private fun showTimeline() {
        val c = Calendar.getInstance()
        if (startDate > 0) c.timeInMillis = startDate

        c.get(Calendar.YEAR)
        c.get(Calendar.MONTH)
        c.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = CalendarDialog(this, updateListener = { startDate, endDate ->

            SimpleDateFormat(
                "dd MMM yyyy",
                Locale.ENGLISH
            ).format(startDate.timeInMillis)

            SimpleDateFormat(
                "dd MMM yyyy", Locale.ENGLISH
            ).format(endDate.timeInMillis)

//            binding.txtStartDate.text = "$strStartDate - $strEndDate"

            setListTimeRange(startDate.timeInMillis, endDate.timeInMillis)

        })
        datePickerDialog.show()
    }

    private fun setListTimeRange(startDate: Long, endDate: Long) {
        Log.e("setList", "setListTimeRange.startDate:$startDate")
        Log.e("setList", "setListTimeRange.endDate:$endDate")
//        timeRangeList.clear()
        allList.clear()
        if (startDate > 0 && endDate > 0) {
//            timeRangeList.addAll(allBackList.filter { it.date in (startDate + 1)..<endDate })
            allList.addAll(allBackList.filter { it.date in (startDate + 1)..<endDate })
        } else if (startDate == 0L) {
//            timeRangeList.addAll(allBackList.filter { it.date > startDate })
            allList.addAll(allBackList.filter { it.date > startDate })
        } else if (endDate == 0L) {
//            timeRangeList.addAll(allBackList.filter { it.date < endDate })
            allList.addAll(allBackList.filter { it.date < endDate })
        } else {
//            timeRangeList.clear()
            allList.clear()
        }

        Log.e("setList", "ListTimeRange.size:${allList.size}")
//        binding.txtAllRange.beGoneIf(timeRangeList.size == 0)
//        binding.txtAllRange.beGoneIf(allList.size == 0)
//        binding.llSearch.beGone()

        setData()

    }

    private fun setData() {
        Log.e("gettingListPhoto", "Data is show")
//        isUpadteList = false
//        enableScroll()

        runOnUiThread {
            //if (searchAdapter != null)
            notifyAdapter()
            setEmptyData()
        }
    }

    private fun notifyAdapter() {

        if (searchAdapter != null) {
//            binding.txtCount.text = "${allList.size} ${getString(R.string.photos)}"
            searchAdapter?.notifyDataSetChanged()
        }

//        if (timeLineAdapter != null)
//            timeLineAdapter?.notifyDataSetChanged()
    }

    override fun onDestroy() {
        super.onDestroy()
//        EventBus.getDefault().unregister(this)
    }


    override fun onBackPressed() {
        if (binding.groupToolbarSelectHeader.visibility == View.VISIBLE) {
//            setCloseToolbar()
        } else {
            if (preferences.isNeedInterAd) {

                AdsConfig.showInterstitialAd(this) {
                    if (it) preferences.isNeedInterAd = false
                    finish()
                }
            } else {
                super.onBackPressed()
            }
        }
    }


}