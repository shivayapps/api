package com.photogallery.model

data class FamilyAppsModel(
    val appName: String,
    val shortDescription: String,
    val appImageLink: String,
    val appFeatureImage: String,
    val appPackageName: String,
    val appPlayStoreLink: String,
    val isNeedToShow: Boolean
)