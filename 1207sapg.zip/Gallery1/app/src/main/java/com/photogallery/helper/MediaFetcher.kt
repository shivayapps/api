package com.photogallery.helper

import android.content.ContentResolver
import android.content.Context
import android.database.Cursor
import android.os.Bundle
import android.os.Environment
import android.provider.BaseColumns
import android.provider.MediaStore
import com.photogallery.extension.getDistinctPath
import com.photogallery.extension.getDoesFilePathExist
import com.photogallery.extension.getLongValue
import com.photogallery.extension.getNoMediaFoldersSync
import com.photogallery.extension.getParentPath
import com.photogallery.extension.getStringValue
import com.photogallery.extension.normalizeString
import com.photogallery.extension.queryCursor
import com.photogallery.extension.shouldFolderBeVisible
import com.photogallery.extension.showErrorToast
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.utils.Constant
import com.photogallery.utils.Constant.GROUP_BY_DATE_DAILY
import com.photogallery.utils.Constant.GROUP_BY_DATE_MONTHLY
//import com.photogallery.utils.Constant.GROUP_BY_LAST_MODIFIED_DAILY
//import com.photogallery.utils.Constant.GROUP_BY_LAST_MODIFIED_MONTHLY
import com.photogallery.utils.Constant.GROUP_BY_NONE
import com.photogallery.utils.Constant.ORDER_DESCENDING
import com.photogallery.utils.NOMEDIA
import com.photogallery.utils.Preferences
import com.photogallery.utils.SHOW_ALL
import com.photogallery.utils.TYPE_GIFS
import com.photogallery.utils.TYPE_IMAGES
//import com.photogallery.utils.TYPE_PORTRAITS
//import com.photogallery.utils.TYPE_RAWS
//import com.photogallery.utils.TYPE_SVGS
import com.photogallery.utils.TYPE_VIDEOS
import com.photogallery.utils.isRPlus
import com.photogallery.utils.photoExtensions
import com.photogallery.utils.rawExtensions
import com.photogallery.utils.videoExtensions
import java.io.File
import java.util.Locale

class MediaFetcher(val context: Context) {

    var shouldStop = false
    val config = Preferences(context)

    fun getFoldersToScan(): ArrayList<String> {
        return try {
//            val OTGPath = context.config.OTGPath
            val folders = getLatestFileFolders()
            folders.addAll(arrayListOf(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)
                    .toString(),
                "${Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)}/Camera",
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                    .toString()
            ).filter { context.getDoesFilePathExist(it) })

            val filterMedia = config.getFilterMedia()
            val uri = MediaStore.Files.getContentUri("external")
            val projection = arrayOf(MediaStore.Images.Media.DATA)
            val selection = getSelectionQuery(filterMedia)
            val selectionArgs = getSelectionArgsQuery(filterMedia).toTypedArray()
            val cursor =
                context.contentResolver.query(uri, projection, selection, selectionArgs, null)
            folders.addAll(parseCursor(cursor!!))

//            val config = context.config
            val shouldShowHidden = config.shouldShowHidden
            val excludedPaths = arrayListOf("")
            val includedPaths = arrayListOf("")
//            val excludedPaths = if (config.temporarilyShowExcluded) {
//                ArrayList()
//            } else {
//                config.getExcludeList()
//            }

//            val includedPaths = config.getIncludeList()


            val folderNoMediaStatuses = HashMap<String, Boolean>()
            val distinctPathsMap = HashMap<String, String>()
            val distinctPaths = folders.distinctBy {
                when {
                    distinctPathsMap.containsKey(it) -> distinctPathsMap[it]
                    else -> {
                        val distinct = it.getDistinctPath()
                        distinctPathsMap[it.getParentPath()] = distinct.getParentPath()
                        distinct
                    }
                }
            }

            val noMediaFolders = context.getNoMediaFoldersSync()
            noMediaFolders.forEach { folder ->
                folderNoMediaStatuses["$folder/$NOMEDIA"] = true
            }

            distinctPaths.filter {
                it.shouldFolderBeVisible(
                    excludedPaths,
                    includedPaths,
                    shouldShowHidden,
                    folderNoMediaStatuses
                ) { path, hasNoMedia ->
                    folderNoMediaStatuses[path] = hasNoMedia
                }
            }.toMutableList() as ArrayList<String>
        } catch (e: Exception) {
            ArrayList()
        }
    }


    private fun parseCursor(cursor: Cursor): LinkedHashSet<String> {
        val foldersToIgnore = arrayListOf("/storage/emulated/legacy")
        //val config = context.config
//        val includedFolders = config.getIncludeList()
        val includedFolders = arrayListOf("")
//        val OTGPath = config.OTGPath

//        val foldersToScan = config.everShownFolders.filter { it == FAVORITES || it == RECYCLE_BIN || context.getDoesFilePathExist(it, OTGPath) }.toHashSet()
        val foldersToScan =
            config.everShownFolders.filter { context.getDoesFilePathExist(it) }.toHashSet()

        cursor.use {
            if (cursor.moveToFirst()) {
                do {
                    val path = cursor.getStringValue(MediaStore.Images.Media.DATA)
                    val parentPath = File(path).parent ?: continue
                    if (!includedFolders.contains(parentPath) && !foldersToIgnore.contains(
                            parentPath
                        )
                    ) {
                        foldersToScan.add(parentPath)
                    }
                } while (cursor.moveToNext())
            }
        }

        includedFolders.forEach {
            addFolder(foldersToScan, it)
        }

        return foldersToScan.toMutableSet() as LinkedHashSet<String>
    }

    private fun addFolder(curFolders: HashSet<String>, folder: String) {
        curFolders.add(folder)
        val files = File(folder).listFiles() ?: return
        for (file in files) {
            if (file.isDirectory) {
                addFolder(curFolders, file.absolutePath)
            }
        }
    }

    private fun getSelectionQuery(filterMedia: Int): String {
        val query = StringBuilder()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")

            rawExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }

//        if (filterMedia and TYPE_RAWS != 0) {
//            rawExtensions.forEach {
//                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//            }
//        }

//        if (filterMedia and TYPE_SVGS != 0) {
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//        }
//        if (filterMedia and TYPE_PORTRAITS != 0) {
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
        }


        if (filterMedia and TYPE_GIFS != 0) {
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }


        return query.toString().trim().removeSuffix("OR")
    }

    private fun getSelectionArgsQuery(filterMedia: Int): ArrayList<String> {
        val args = ArrayList<String>()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.jpg")
            args.add("%.jpeg")
            rawExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.svg")
        }

//        if (filterMedia and TYPE_RAWS != 0) {
//            rawExtensions.forEach {
//                args.add("%$it")
//            }
//        }
//
//        if (filterMedia and TYPE_SVGS != 0) {
//            args.add("%.svg")
//        }
//        if (filterMedia and TYPE_PORTRAITS != 0) {
//            args.add("%.jpg")
//            args.add("%.jpeg")
//        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                args.add("%$it")
            }
        }

        if (filterMedia and TYPE_GIFS != 0) {
            args.add("%.gif")
        }


        return args
    }

    private fun getLatestFileFolders(): LinkedHashSet<String> {
        val uri = MediaStore.Files.getContentUri("external")
        val projection = arrayOf(MediaStore.Images.ImageColumns.DATA)
        val parents = LinkedHashSet<String>()
        var cursor: Cursor? = null
        try {
            if (isRPlus()) {
                val bundle = Bundle().apply {
                    putInt(ContentResolver.QUERY_ARG_LIMIT, 10)
                    putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf(BaseColumns._ID))
                    putInt(
                        ContentResolver.QUERY_ARG_SORT_DIRECTION,
                        ContentResolver.QUERY_SORT_DIRECTION_DESCENDING
                    )
                }

                cursor = context.contentResolver.query(uri, projection, bundle, null)
                if (cursor?.moveToFirst() == true) {
                    do {
                        val path =
                            cursor.getStringValue(MediaStore.Images.ImageColumns.DATA) ?: continue
                        parents.add(path.getParentPath())
                    } while (cursor.moveToNext())
                }
            } else {
                val sorting = "${BaseColumns._ID} DESC LIMIT 10"
                cursor = context.contentResolver.query(uri, projection, null, null, sorting)
                if (cursor?.moveToFirst() == true) {
                    do {
                        val path =
                            cursor.getStringValue(MediaStore.Images.ImageColumns.DATA) ?: continue
                        parents.add(path.getParentPath())
                    } while (cursor.moveToNext())
                }
            }
        } catch (e: Exception) {
            context.showErrorToast(e)
        } finally {
            cursor?.close()
        }

        return parents
    }


    private fun getFolderSizes(folder: String): HashMap<String, Long> {
        val sizes = HashMap<String, Long>()
//        if (folder != FAVORITES) {
        val projection = arrayOf(
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.SIZE
        )

        val uri = MediaStore.Files.getContentUri("external")
        val selection =
            "${MediaStore.Images.Media.DATA} LIKE ? AND ${MediaStore.Images.Media.DATA} NOT LIKE ?"
        val selectionArgs = arrayOf("$folder/%", "$folder/%/%")

        context.queryCursor(uri, projection, selection, selectionArgs) { cursor ->
            try {
                val size = cursor.getLongValue(MediaStore.Images.Media.SIZE)
                if (size != 0L) {
                    val name = cursor.getStringValue(MediaStore.Images.Media.DISPLAY_NAME)
                    sizes["$folder/$name"] = size
                }
            } catch (e: Exception) {
            }
        }
//        }

        return sizes
    }



    fun groupMedia(media: ArrayList<MediaData>, path: String): ArrayList<AlbumData> {
        if (path.isEmpty()) SHOW_ALL else path
        val currentGrouping = config.getSortOrder()
        if (currentGrouping and GROUP_BY_NONE != 0) {
            return media as ArrayList<AlbumData>
        }

        val thumbnailItems = ArrayList<AlbumData>()
//        if (config.scrollHorizontally) {
//            media.mapTo(thumbnailItems) { it }
//            return thumbnailItems
//        }

        val mediumGroups = LinkedHashMap<String, ArrayList<MediaData>>()
        media.forEach {
//            val key = it.getGroupingKey(currentGrouping)
            val key = ""
            if (!mediumGroups.containsKey(key)) {
                mediumGroups[key] = ArrayList()
            }
            mediumGroups[key]!!.add(it)
        }

        val sortDescending = currentGrouping and ORDER_DESCENDING != 0
        val sorted =
            if (currentGrouping and GROUP_BY_DATE_DAILY != 0 || currentGrouping and GROUP_BY_DATE_MONTHLY != 0
//                || currentGrouping and GROUP_BY_DATE_TAKEN_DAILY != 0 || currentGrouping and GROUP_BY_DATE_TAKEN_MONTHLY != 0
            ) {
                mediumGroups.toSortedMap(if (sortDescending) compareByDescending {
                    it.toLongOrNull() ?: 0L
                } else {
                    compareBy { it.toLongOrNull() ?: 0L }
                })
            } else {
                mediumGroups.toSortedMap(if (sortDescending) compareByDescending { it } else compareBy { it })
            }

        mediumGroups.clear()
        for ((key, value) in sorted) {
            mediumGroups[key] = value
        }

//        val today = formatDate(System.currentTimeMillis().toString(), true)
//        val yesterday = formatDate((System.currentTimeMillis() - DAY_SECONDS * 1000).toString(), true)
//        for ((key, value) in mediumGroups) {
//            var currentGridPosition = 0
//            val sectionKey = getFormattedKey(key, currentGrouping, today, yesterday, value.size)
//            thumbnailItems.add(ThumbnailSection(sectionKey))
//
//            value.forEach {
//                it.gridPosition = currentGridPosition++
//            }
//
//            thumbnailItems.addAll(value)
//        }

        return thumbnailItems
    }



    fun getDateTakens(): HashMap<String, Long> {
        val dateTakens = HashMap<String, Long>()
        val projection = arrayOf(
            MediaStore.Images.Media.DATA,
            MediaStore.Images.Media.DATE_TAKEN
        )

        val uri = MediaStore.Files.getContentUri("external")

        try {
            context.queryCursor(uri, projection) { cursor ->
                try {
                    val dateTaken = cursor.getLongValue(MediaStore.Images.Media.DATE_TAKEN)
                    if (dateTaken != 0L) {
                        val path = cursor.getStringValue(MediaStore.Images.Media.DATA)
                        dateTakens[path] = dateTaken
                    }
                } catch (e: Exception) {
                }
            }

//            val dateTakenValues = context.dateTakensDB.getAllDateTakens()
//            dateTakenValues.forEach {
//                dateTakens[it.fullPath] = it.taken
//            }
        } catch (e: Exception) {
        }

        return dateTakens
    }

    fun getLastModifieds(): HashMap<String, Long> {
        val lastModifieds = HashMap<String, Long>()
        val projection = arrayOf(
            MediaStore.Images.Media.DATA,
            MediaStore.Images.Media.DATE_MODIFIED
        )

        val uri = MediaStore.Files.getContentUri("external")

        try {
            context.queryCursor(uri, projection) { cursor ->
                try {
                    val lastModified =
                        cursor.getLongValue(MediaStore.Images.Media.DATE_MODIFIED) * 1000
                    if (lastModified != 0L) {
                        val path = cursor.getStringValue(MediaStore.Images.Media.DATA)
                        lastModifieds[path] = lastModified
                    }
                } catch (e: Exception) {
                }
            }
        } catch (e: Exception) {
        }

        return lastModifieds
    }

}