package com.photogallery.messaging

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.Calendar
import java.util.concurrent.TimeUnit

object NotificationChannels {
    const val ENGAGEMENT = "gallery_engagement"
    const val DEFAULT_NOTIFICATION = "DEFAULT"

    fun create(context: Context) {

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return

        val manager =
            context.getSystemService(NotificationManager::class.java)

        val channel = NotificationChannel(
            ENGAGEMENT,
            "Offers & Notification",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {

            description = "Gallery reminders and memories"

            enableLights(true)
            enableVibration(true)

            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            setShowBadge(true)
        }

        manager.createNotificationChannel(channel)
    }
    fun createHomeNotificationChannel(context: Context) {


        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return

        val manager =
            context.getSystemService(NotificationManager::class.java)

        val existing =
            manager.getNotificationChannel(
                DEFAULT_NOTIFICATION
            )

        if (existing != null) return

        val channel = NotificationChannel(
            DEFAULT_NOTIFICATION,
            "Default Shortcuts",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {

            description = "Default gallery shortcuts"

            setShowBadge(false)

            enableVibration(false)

            enableLights(false)

            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }

        manager.createNotificationChannel(channel)
    }
}

object NotificationContentProvider {
    data class Content(
        val title: String,
        val body: String
    )
    fun portrait(): Content {
        return Content(
            Notifier.portraitTitles.random(),
            Notifier.portraitMessages.random()
        )
    }
    fun hd(): Content {
        return Content(
            Notifier.hdTitles.random(),
            Notifier.hdMessages.random()
        )
    }
    fun generic(): Content {
        return Content(
            Notifier.randomTitles.random(),
            Notifier.randomMessages.random()
        )
    }
    fun memory(): Content {
        return Content(
            Notifier.memoryTitle.random(),
            Notifier.memoryMessages.random()
        )
    }
}
