package com.photogallery.utils

import android.content.Context
import com.photogallery.R

object AdUtils {

    private var bannerCount = 0
    fun getBannerID(context: Context): String {
        val index = bannerCount % 3
        bannerCount++

        return when (index) {
            0 -> context.getString(R.string.common_banner1)
            1 -> context.getString(R.string.common_banner2)
            2 -> context.getString(R.string.common_banner3)
            else -> context.getString(R.string.common_banner1)
        }
    }

    private var nativeCount = 0
    fun getNativeID(context: Context): String {
        val index = nativeCount % 3
        nativeCount++

        return when (index) {
            0 -> context.getString(R.string.common_native1)
            1 -> context.getString(R.string.common_native2)
            2 -> context.getString(R.string.common_native3)
            else -> context.getString(R.string.common_native1)
        }
    }
}

//class AdCache {
//    companion object {
//        var homeAdView:AdView?=null
//        var albumAdView:AdView?=null
//        var exploreAlbumAdView:AdView?=null
//        var imageListAdView:AdView?=null
//        var pdfListAdView:AdView?=null
//        var pdfReaderAdView:AdView?=null
//        var recentlyDeletedAdView:AdView?=null
//        var mapExploreAdView:AdView?=null
//        var privateViewerAdView:AdView?=null
//        var privateAdView:AdView?=null
//        var privateListAdView:AdView?=null
//        var photoVideoAdView:AdView?=null
//        var favoriteListAdView:AdView?=null
//        var cleanerAdView:AdView?=null
//
//
//    }
//}


