package com.photogallery.jobs

import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.util.Log
import com.photogallery.GalleryApp

import com.photogallery.database.AppDatabase
import com.photogallery.database.LocationEntity
import com.photogallery.model.MediaData
import com.photogallery.model.PlaceData
import com.photogallery.utils.Preferences
import com.photogallery.utils.Utils
import kotlinx.coroutines.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class PlacesLoader(
    private val mContext: Context,
) {

    private var TAG = ""

    lateinit var dataBase: AppDatabase

    var placeList: ArrayList<PlaceData> = ArrayList()

    private var mJob: Job = Job()
    private var preferences: Preferences? = null

    fun refreshLoader(prefKey: String) {

    }

    init {
        TAG = "PlacesLoader"
        dataBase = AppDatabase.getInstance(mContext)
        preferences = GalleryApp.preferences
    }

    fun preparePlaceModel(
        onSuccess: ((placeList: ArrayList<PlaceData>) -> Unit)? = null,
        onFailed: ((error: String) -> Unit)? = null,
    ) {
        mJob = CoroutineScope(Dispatchers.IO).launch {

            try {
                val places = dataBase.dataDao().getLocationEntityList()
                val sortedPlaces = places.sortedByDescending { it.locationId }
                applyMediaSorting(sortedPlaces, { sortedPlaces ->
                    placeList.clear()
                    placeList.addAll(sortedPlaces)
                })
                onSuccess?.invoke(placeList)
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    onFailed?.invoke(e.message ?: "Error occurred while loading media.")
                }
            }
        }
    }

    fun applyMediaSorting(
        locationEntity: List<LocationEntity>, onSortingComplete: (List<PlaceData>) -> Unit
    ) {
        var placeList: ArrayList<PlaceData> = ArrayList()
        locationEntity.forEach { data ->

            val strKey = data.title

            val imagesData1: ArrayList<MediaData> = ArrayList()
            val file = File(data.path)
            if (file.exists()) {
                val mediaData = MediaData(
                    file.path,
                    Utils.getUriFromPath(mContext, file.path).toString(),
                    file.name,
                    file.parentFile.name,
                    file.lastModified(),
                    file.lastModified(),
                    file.length()
                )
                for (i in placeList.indices) {
                    if (placeList[i].place == strKey) {
                        placeList[i].pictureData.add(mediaData)
                    }
                }

                if (placeList.filter { it.place == strKey }.isNullOrEmpty()) {
                    imagesData1.add(mediaData)
                    val placeData =
                        PlaceData(imagesData1, data.title, data.latitude, data.longitude)
                    placeList.add(placeData)
                }
            } else {
                dataBase.dataDao().deleteLocationEntity(data)
            }
        }
        onSortingComplete.invoke(placeList)
    }


    fun destroyLoader() {
        mJob.cancel()
    }

}
