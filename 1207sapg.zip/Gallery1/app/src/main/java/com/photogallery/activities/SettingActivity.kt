package com.photogallery.activities

import android.Manifest
import android.app.Activity
import android.content.DialogInterface
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.adconfig.AdsConfig
import com.adconfig.adsutil.Config.checkReInter
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.after.call.extensions.callerCadBaseConfig
import com.karumi.dexter.Dexter
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionDeniedResponse
import com.karumi.dexter.listener.PermissionGrantedResponse
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.single.PermissionListener
import com.photogallery.GalleryApp
//import com.example.mycallstate.preferences.PrefCalls
import com.photogallery.R
import com.photogallery.base.BaseActivity
import com.photogallery.database.AppDatabase
import com.photogallery.databinding.ActivitySettingBinding
import com.photogallery.dialog.BiometricErrorDialog
import com.photogallery.dialog.ChangLockStyleDialog
import com.photogallery.dialog.ActionConfirmationDialog
import com.photogallery.dialog.CallerPermissionDialog
import com.photogallery.dialog.DateTimeDialog
import com.photogallery.dialog.RadioGroupDialog
import com.photogallery.extension.beGone
import com.photogallery.extension.beGoneIf
import com.photogallery.extension.beVisible
import com.photogallery.extension.beVisibleIf
import com.photogallery.extension.getPreviousActivity
import com.photogallery.extension.getValidLanguageCode
import com.photogallery.extension.isVisible
import com.photogallery.extension.isBiometricIdAvailable
import com.photogallery.extension.isSupportWithErrorInfo
import com.photogallery.extension.sendEmail
import com.photogallery.extension.toast
import com.photogallery.model.RadioItem
import com.photogallery.secret.LockSetActivity
import com.photogallery.utils.Constant
import com.photogallery.utils.Constant.ROTATE_BY_ASPECT_RATIO
import com.photogallery.utils.Constant.ROTATE_BY_DEVICE_ROTATION
import com.photogallery.utils.Constant.ROTATE_BY_SYSTEM_SETTING
import com.photogallery.utils.Preferences
import com.photogallery.views.SwitchButton
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class SettingActivity : BaseActivity() {

    //    var themeType = 0
    lateinit var preferences: Preferences
//    lateinit var adsPref: PrefCalls

    lateinit var binding: ActivitySettingBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        if (preferences.isNeedInterAd) {
            AdmobIntersAdImpl().load(this, getString(R.string.inter_all))
        } else {
            checkReInter {
                if (it) {
                    AdmobIntersAdImpl().load(this, getString(R.string.inter_all))
                    preferences.isNeedInterAd = true
                }
            }
        }
        binding = ActivitySettingBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

//        adsPref = PrefCalls(this)
//        themeType = preferences.getThemeValue()

        initView()
        intListener()
    }

    private fun initView() {
        binding.cbTheme.isChecked = preferences.getThemeValue() == Constant.THEME_DARK
        binding.txtTitle.text = getString(R.string.settings)

        val selectLanguage = preferences.selectLanguageCode
        var langStr = getLanguage(selectLanguage)
        if (selectLanguage == "0") {
            langStr = getLanguage(getValidLanguageCode(preferences.systemLocalLanguage))
        }
        binding.tvLanguage.text = langStr
    }


    fun getLanguage(langPos: String): String {
        val langStr: String = when (langPos) {

            "en" -> getString(R.string.english)
            "zh" -> getString(R.string.chinese)
            "es" -> getString(R.string.spanish)
            "ar" -> getString(R.string.arabic)
            "fr" -> getString(R.string.french)
            "pt" -> getString(R.string.portuguese)
            "ru" -> getString(R.string.russian)
            "ja" -> getString(R.string.japanese)
            "ko" -> getString(R.string.korean)
            "de" -> getString(R.string.german)
            "it" -> getString(R.string.italian)
            "hi" -> getString(R.string.hindi)
            "bn" -> getString(R.string.bengali)
            "gu" -> getString(R.string.gujarati)
            "mr" -> getString(R.string.marathi)
            "ta" -> getString(R.string.tamil)
            "te" -> getString(R.string.telugu)
            "kn" -> getString(R.string.kannada)
            "ml" -> getString(R.string.malayalam)
            "pa" -> getString(R.string.punjabi)
            "ur" -> getString(R.string.urdu)
            "id" -> getString(R.string.indonesian)
            "ms" -> getString(R.string.malay)
            "fil" -> getString(R.string.filipino)
            "th" -> getString(R.string.thai)
            "vi" -> getString(R.string.vietnamese)
            "tr" -> getString(R.string.turkish)
            "nl" -> getString(R.string.dutch)
            "pl" -> getString(R.string.polish)
            "uk" -> getString(R.string.ukrainian)
            "fa" -> getString(R.string.persian)
            "sv" -> getString(R.string.swedish)
            else -> getString(R.string._default)
        }
        return langStr
    }

    fun toggleExpand(mainView: View, actionView: View) {
        if (mainView.isVisible()) {
            mainView.beGone()
            actionView.animate()
                .rotation(0f)
                .setDuration(500).start()
        } else {
            mainView.beVisible()
            actionView.animate()
                .rotation(180f)
                .setDuration(500).start()
        }
    }

    var isFingerprintAvailable = Pair(false, "")
    private fun intListener() {

        binding.icBack.setOnClickListener {
            finish()
        }

//        binding.llActionGeneral.setOnClickListener {
//            toggleExpand(binding.llGeneral, binding.ivActionGeneral)
////            binding.llGeneral.beVisibleIf(binding.llGeneral.isGone())
//        }
//        binding.llActionVideo.setOnClickListener {
//            toggleExpand(binding.llVideo, binding.ivActionVideo)
////            binding.llVideo.beVisibleIf(binding.llVideo.isGone())
//        }
//        binding.llActionFullScreen.setOnClickListener {
//            toggleExpand(binding.llFullScreen, binding.ivActionFullScreen)
//            binding.llFullScreen.beVisibleIf(binding.llFullScreen.isGone())
//        }
//        binding.llActionDeepZoom.setOnClickListener {
//            toggleExpand(binding.llDeepZoom, binding.ivActionDeepZoom)
////            binding.llDeepZoom.beVisibleIf(binding.llDeepZoom.isGone())
//        }
//        binding.llActionSecurity.setOnClickListener {
//            toggleExpand(binding.llSecurity, binding.ivActionSecurity)
////            binding.llSecurity.beVisibleIf(binding.llSecurity.isGone())
//        }
//        binding.llActionFileOperation.setOnClickListener {
//            toggleExpand(binding.llFileOperation, binding.ivActionFileOperation)
////            binding.llFileOperation.beVisibleIf(binding.llFileOperation.isGone())
//        }
//        binding.llActionVisibility.setOnClickListener {
//            toggleExpand(binding.llVisibility, binding.ivActionVisibility)
////            binding.llVisibility.beVisibleIf(binding.llVisibility.isGone())
//        }
//        binding.llActionRecycleBin.setOnClickListener {
//            toggleExpand(binding.llRecycleBin, binding.ivActionRecycleBin)
////            binding.llRecycleBin.beVisibleIf(binding.llRecycleBin.isGone())
//        }
//        binding.llActionMore.setOnClickListener {
//            toggleExpand(binding.llMore, binding.ivActionMore)
////            binding.llMore.beVisibleIf(binding.llMore.isGone())
//        }

        binding.cbTheme.setOnCheckedChangeListener(object : SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                themeType = if (isChecked) {
                    Constant.THEME_DARK
                } else {
                    Constant.THEME_LIGHT
                }
                preferences.putTheme(themeType)

                val intent = Intent(this@SettingActivity, SettingActivity::class.java)
                setResult(RESULT_OK)
                finish()
                overridePendingTransition(0, 0)
                startActivity(intent)
                overridePendingTransition(0, 0)
//                ThemeChanger(this@SettingActivity, binding.cbTheme).switchTheme()
//                if(com.anter.library_circular_reveal_theme_changer.utils.ThemeUtilsImpl().isDarkTheme(this@SettingActivity)) {
//                    preferences.putTheme(Constant.THEME_DARK)
//                } else {
//                    preferences.putTheme(Constant.THEME_LIGHT)
//                }
//                val intent = Intent(this@SettingActivity, SettingActivity::class.java)
//                setResult(RESULT_OK)
//                finish()
//                overridePendingTransition(0, 0)
//                startActivity(intent)
//                overridePendingTransition(0, 0)
            }
        })

        binding.cbDeleteAfter30Days.isChecked = preferences.deleteAfter30Days
        binding.cbDeleteAfter30Days.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.deleteAfter30Days = isChecked
            }
        })
        binding.llClearRecycleBin.setOnClickListener {
            val confirmationDialog = ActionConfirmationDialog(
                this,
                getString(R.string.clear_recycle_bin),
                getString(R.string.are_you_sure_you_want_to_clear_recycle_bin),
                getString(R.string.clear),
                positiveBtnClickListener = {
                    AppDatabase.getInstance(this@SettingActivity).dataDao().removeAllRecentDelete()
                })
            confirmationDialog.show()
        }

        val readPhoneState =
            ContextCompat.checkSelfPermission(
                this@SettingActivity,
                Manifest.permission.READ_PHONE_STATE
            ) == 0
        val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this@SettingActivity)
        } else {
            true
        }

        if (canDrawOverlays && readPhoneState && callerCadBaseConfig.callerCadEnable && callerCadBaseConfig.isShowCallInfo) {
            binding.cbCall.isChecked = true
        } else {
            binding.cbCall.isChecked = false
        }

        binding.cbCall.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                if (isChecked) {
                    checkCaller()
                } else {
                    callerCadBaseConfig.isShowCallInfo = isChecked
                }
            }
        })

//        binding.cbRememberLast.isChecked = preferences.rememberLastVideoPosition
//        binding.cbRememberLast.setOnCheckedChangeListener(object :
//            SwitchButton.OnCheckedChangeListener {
//            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
//                preferences.rememberLastVideoPosition = isChecked
//            }
//        })

        binding.cbAutoPlay.isChecked = preferences.autoplayVideos
        binding.cbAutoPlay.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.autoplayVideos = isChecked
            }
        })


        binding.tvRotateFullscreen.text = getScreenRotationText()
        binding.llRotateFullscreen.setOnClickListener {

            val items = arrayListOf(
                RadioItem(
                    ROTATE_BY_SYSTEM_SETTING,
                    getString(R.string.screen_rotation_system_setting)
                ),
                RadioItem(
                    ROTATE_BY_DEVICE_ROTATION,
                    getString(R.string.screen_rotation_device_rotation)
                ),
                RadioItem(ROTATE_BY_ASPECT_RATIO, getString(R.string.screen_rotation_aspect_ratio))
            )

            val radioGroupDialog =
                RadioGroupDialog(this@SettingActivity, items, preferences.screenRotation) {
                    preferences.screenRotation = it
                    binding.tvRotateFullscreen.text = getScreenRotationText()
                }
            radioGroupDialog.show()
        }


//        binding.cbBlackBackground.isChecked = preferences.blackBackground
//        binding.cbBlackBackground.setOnCheckedChangeListener(object :
//            SwitchButton.OnCheckedChangeListener {
//            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
//                preferences.blackBackground = isChecked
//            }
//        })

        binding.cbMaxBrightness.isChecked = preferences.maxBrightness
        binding.cbMaxBrightness.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.maxBrightness = isChecked
            }
        })


        binding.llLanguage.setOnClickListener {
            languageLauncher.launch(Intent(this, LanguageSelectionActivity::class.java))
//                .putExtra(Constant.EXTRA_IS_OPEN_FROM_SPLASH, false)
        }

        binding.llDateTime.setOnClickListener {
            val dateTimeDialog = DateTimeDialog(this, updateListener = {

            })
            dateTimeDialog.show()

        }

//        binding.llIncludedFolder.setOnClickListener {
//            dirsActivityResultLauncher.launch(
//                Intent(this, DirsActivity::class.java)
//                    .putExtra("dirType", Constant.TYPE_INCLUDED)
//            )
//        }


        binding.llRateUs.setOnClickListener {
            launchAppStore()
        }



        binding.llFeedbackSuggestions.setOnClickListener {
            sendEmail("siapps.shivay@gmail.com", "GalleryApp Feedback/Suggestion", "Message:\n")
        }

        binding.llPrivacyPolicy.setOnClickListener {
            openPrivacyPolicy()
        }
        binding.llShareApp.setOnClickListener {

            try {
                val sendIntent = Intent()
                sendIntent.action = Intent.ACTION_SEND
                sendIntent.putExtra(
                    Intent.EXTRA_TEXT,
                    "Check out the App at: https://play.google.com/store/apps/details?id=$packageName"
                )
                sendIntent.type = "text/plain"
                AdsConfig.isDialogOpen = true
                startActivity(sendIntent)
            } catch (e: Exception) {

            }
        }

    }

    private fun checkCaller() {
        Log.e("checkCaller", "001")
        val readPhoneState =
            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == 0
        val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
        if (readPhoneState && canDrawOverlays) {
            binding.cbCall.isChecked = true
//            binding.libraryTab.llCallerSettings.beVisible()
//            setAutoStartPermission(this)
            Log.e("checkCaller.icCall", "icCall.beGone")
        } else {

            if (callerCadBaseConfig.callerCadEnable) {
//                binding.libraryTab.llCaller.beVisible()
//                binding.libraryTab.llCallerSettings.beGone()
//                if (!callerCadBaseConfig.callerCadPermissionDialogDismiss) {
                showCallPermissionDialog()
//                } else if (needDialog) {
//                    //adsPref.firstTimeDialog = false
//                    showCallPermissionDialog()
//                }
            }
        }
    }
    var callerDialog: CallerPermissionDialog? = null
    private fun showCallPermissionDialog() {
        Log.e("checkCaller", "preferences.showCallPermissionDialog")
        callerDialog = CallerPermissionDialog(
            this, callerCadBaseConfig.callerCadPermissionDialogDismiss,
            {//positiveListener
                AdsConfig.isSystemDialogOpen = true
                Dexter.withContext(this@SettingActivity).withPermission(
                    Manifest.permission.READ_PHONE_STATE
                ).withListener(object : PermissionListener {
                    override fun onPermissionGranted(permissionGrantedResponse: PermissionGrantedResponse) {
                        Log.e("checkCaller", "onPermissionGranted")
                        if (Settings.canDrawOverlays(this@SettingActivity)) {
                            val readPhoneState =
                                ContextCompat.checkSelfPermission(
                                    this@SettingActivity,
                                    Manifest.permission.READ_PHONE_STATE
                                ) == 0
                            val canDrawOverlays =
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                    Settings.canDrawOverlays(this@SettingActivity)
                                } else {
                                    true
                                }
//                            binding.libraryTab.llCaller.beGoneIf(canDrawOverlays && readPhoneState)
                            if (canDrawOverlays && readPhoneState) {
                                binding.cbCall.isChecked = true
                            } else {
                                binding.cbCall.isChecked = false
                            }
                            Log.e(
                                "checkCaller.icCall",
                                "icCall.beGoneIf.canDrawOverlays>$canDrawOverlays,readPhoneState>$readPhoneState"
                            )
                            callerDialog?.dismiss()
                        } else {
                            callerDialog?.dismiss()
                            requestSystemOverlayPermission()
                        }
//                    requestSystemOverlayPermission()
                    }

                    override fun onPermissionDenied(permissionDeniedResponse: PermissionDeniedResponse) {
                        Log.e("checkCaller", "onPermissionDenied")
                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        val uri = Uri.fromParts("package", packageName, null)
                        intent.data = uri
                        callerLauncher.launch(intent)
                        AdsConfig.isSystemDialogOpen = true
                        toast(
                            "Please allow phone permission to enable feature"
                        )
                        callerDialog?.dismiss()
                    }

                    override fun onPermissionRationaleShouldBeShown(
                        permissionRequest: PermissionRequest,
                        permissionToken: PermissionToken,
                    ) {
                        permissionToken.continuePermissionRequest()
                    }
                }).check()

            }, {//closeListener
//                var closeCounter = preferences.closeCounter
//                closeCounter++
//                preferences.closeCounter = closeCounter
                callerDialog?.dismiss()

                if (!callerCadBaseConfig.callerCadPermissionDialogDismiss) {
                    val calendar = Calendar.getInstance()
                    val format = SimpleDateFormat("dd/mm/yy", Locale.ENGLISH)
                    val today = format.format(calendar.timeInMillis)
                    AdsConfig.isSystemDialogOpen = true
                    //finishAffinity()
                }
            })
        callerDialog?.setOnDismissListener { dialogInterface: DialogInterface? ->
            val readPhoneState =
                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == 0
            val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Settings.canDrawOverlays(this)
            } else {
                true
            }

            if (callerCadBaseConfig.callerCadEnable) {
//                binding.libraryTab.llCaller.beGoneIf(canDrawOverlays && readPhoneState)
                if (canDrawOverlays && readPhoneState) {
                    binding.cbCall.isChecked = true
                } else {
                    binding.cbCall.isChecked = false
                }
                Log.e(
                    "checkCaller.icCall",
                    "setOnDismissListener.icCall.beGoneIf.canDrawOverlays>$canDrawOverlays,readPhoneState>$readPhoneState"
                )
            }

        }
        if (!isFinishing && !isDestroyed) {
            AdsConfig.isSystemDialogOpen = true
            callerDialog?.show()
        }
    }
    var callerLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { _ ->
            Log.e("checkCaller", "callerLauncher")
            val readPhoneState =
                ContextCompat.checkSelfPermission(
                    this@SettingActivity,
                    Manifest.permission.READ_PHONE_STATE
                ) == 0
            val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Settings.canDrawOverlays(this@SettingActivity)
            } else {
                true
            }


//            binding.libraryTab.llCaller.beGoneIf(canDrawOverlays && readPhoneState && !callerCadBaseConfig.callerCadEnable)
            if (canDrawOverlays && readPhoneState && !callerCadBaseConfig.callerCadEnable) {
                binding.cbCall.isChecked = true
            } else {
                binding.cbCall.isChecked = false
            }
            if (readPhoneState) {
                if (canDrawOverlays) {
                    callerDialog?.dismiss()
                } else {
                    requestSystemOverlayPermission()
                }
            } else checkCaller()

        }
    private fun requestSystemOverlayPermission() {
        AdsConfig.isSystemDialogOpen = true

        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:" + applicationContext.packageName)
        )

        try {
            startActivityForResult(intent, 101)
        } catch (e: Exception) {
            Log.e("printStackTrace", "printStackTrace:$e")
        }

//        Handler(Looper.getMainLooper()).postDelayed({
//            val intent1 = Intent(this@HomeActivity, SettingPermissionActivity::class.java)
//            intent1.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
//            startActivity(intent1)
//        }, 500)

    }

    private fun launchAppStore() {
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("http://play.google.com/store/apps/details?id=${packageName}")
        )
        startActivity(intent)
    }


    var languageLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->

            Log.e("LanguageSetup", "systemLocalLanguage:${preferences.systemLocalLanguage}")
            Log.e("LanguageSetup", "selectLanguageCode:${preferences.selectLanguageCode}")

            if (result.resultCode == RESULT_OK) {
                setResult(RESULT_OK)
                recreate()
                Constant.isChangeLanguage = true
            }
        }


    fun openPrivacyPolicy() {
        val url = getPrivacyPolicy()
        if (url != null && url.isNotEmpty()) {
            try {
                val builder: CustomTabsIntent.Builder = CustomTabsIntent.Builder()
                builder.setToolbarColor(ContextCompat.getColor(this, R.color.color_primary))
                AdsConfig.isDialogOpen = true
                val customTabsIntent: CustomTabsIntent = builder.build()
                customTabsIntent.intent.setPackage("com.android.chrome")
                customTabsIntent.launchUrl(this, Uri.parse(url))

            } catch (e: Exception) {
                val i = Intent(Intent.ACTION_VIEW)
                i.data = Uri.parse(url)
                AdsConfig.isDialogOpen = true
                startActivity(i)
            }
        }
    }

    override fun onBackPressed() {
        if (preferences.isNeedInterAd) {
            AdsConfig.showInterstitialAd(this) {
                if (it) preferences.isNeedInterAd = false
                finish()
            }
        } else {
            finish()
        }
    }

    private fun getScreenRotationText() = getString(
        when (preferences.screenRotation) {
            ROTATE_BY_SYSTEM_SETTING -> R.string.screen_rotation_system_setting
            ROTATE_BY_DEVICE_ROTATION -> R.string.screen_rotation_device_rotation
            else -> R.string.screen_rotation_aspect_ratio
        }
    )

    var dirsActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
//            photosFragment.getData()
//            albumFragment.getData()
        }
    }
}