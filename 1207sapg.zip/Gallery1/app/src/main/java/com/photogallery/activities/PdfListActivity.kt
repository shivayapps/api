package com.photogallery.activities

import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.AdsConfig
import com.adconfig.adsutil.Config.checkReInter
import com.adconfig.adsutil.admob.AdmobBanner
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.AdmobNative
import com.photogallery.R
import com.photogallery.adapter.PdfFolderAdapter
import com.photogallery.adapter.PdfListAdapter
import com.photogallery.base.BaseActivity
import com.photogallery.customview.MyGridLayoutManager
import com.photogallery.databinding.ActivityPdfListBinding
import com.photogallery.dialog.ActionConfirmationDialog
import com.photogallery.extension.beGone
import com.photogallery.extension.getFilenameFromPath
import com.photogallery.extension.getParentFolder
import com.photogallery.extension.toast
import com.photogallery.model.PdfModel
import com.photogallery.utils.AdUtils
import com.photogallery.utils.FastScroller
import com.photogallery.utils.MessageEvent
import com.photogallery.utils.Preferences
import com.photogallery.utils.Utils
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File

class PdfListActivity : BaseActivity() {

    private val allPdfs = mutableListOf<PdfModel>()

    var pdfListAdapter: PdfListAdapter? = null
    var pdfFolderAdapter: PdfFolderAdapter? = null

    lateinit var preferences: Preferences
    lateinit var binding: ActivityPdfListBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityPdfListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        preferences = Preferences(this)
        if (preferences.isNeedInterAd) {
            AdmobIntersAdImpl().load(this, getString(R.string.inter_all))
        } else {
            checkReInter {
                if (it) {
                    AdmobIntersAdImpl().load(this, getString(R.string.inter_all))
                    preferences.isNeedInterAd = true
                }
            }
        }

        loadPriorityAds()
        if (!EventBus.getDefault().isRegistered(this)) EventBus.getDefault().register(this)

        intView()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (EventBus.getDefault().isRegistered(this)) EventBus.getDefault().unregister(this)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        if (event.type.equals("refresh")) {
        }
    }

    private fun loadPriorityAds() {
        if (preferences.bannerPriority == "native") {
            AdmobNative().preLoad(this, AdUtils.getNativeID(this)) { isLoaded ->
                if (isLoaded) {
                    AdmobNative().showNativeAd(this, binding.frameAd)
                } else if (preferences.handleFailed) {
                    loadAdmobBanner()
                } else binding.frameAd.beGone()
            }
        } else if (preferences.bannerPriority == "banner") {
            AdmobBanner().preLoad(this, AdUtils.getBannerID(this)) { isLoaded ->
                if (isLoaded) {
                    AdmobBanner().showBannerAd(this, binding.frameAd)
                } else if (preferences.handleFailed) {
                    loadNativeBanner()
                } else binding.frameAd.beGone()
            }
        } else {
            binding.frameAd.beGone()
        }
    }

    private fun loadNativeBanner() {
        AdmobNative().preLoad(this, AdUtils.getNativeID(this)) { isLoaded ->
            if (isLoaded) {
                AdmobNative().showNativeAd(this, binding.frameAd)
            } else binding.frameAd.beGone()
        }
    }

    private fun loadAdmobBanner() {
        AdmobBanner().preLoad(this, AdUtils.getBannerID(this)) { isLoaded ->
            if (isLoaded) {
                AdmobBanner().showBannerAd(this, binding.frameAd)
            } else binding.frameAd.beGone()
        }
    }


    private fun intView() {
        val folderLayoutManager = MyGridLayoutManager(this, 1, RecyclerView.HORIZONTAL, false)
        binding.pdfFolderRecycler.layoutManager = folderLayoutManager

        val layoutManager = MyGridLayoutManager(this, 1, RecyclerView.VERTICAL, false)
        binding.pdfRecycler.layoutManager = layoutManager

        pdfFolderAdapter = PdfFolderAdapter(this) { pos, selectedFolder ->
            val filteredList = if (selectedFolder == "All Pdf") {
                allPdfs
            } else {
                allPdfs.filter { it.folder == selectedFolder }
            }
            pdfListAdapter?.submitList(filteredList)
        }
        binding.pdfFolderRecycler.adapter = pdfFolderAdapter

        pdfListAdapter = PdfListAdapter(
            this,
            { pos, pdfModel ->
                Utils.openPdf(this@PdfListActivity, pdfModel.filePath)
//                startActivity(Intent(this, PdfReaderActivity::class.java).apply {
//                    putExtra("pdfName", pdfModel.filePath.getFilenameFromPath())
//                    putExtra("pdfPath", pdfModel.filePath)
//                })
            }, { option, pdfModel ->
                when (option) {
                    1 -> {
                        Utils.sharePDF(this@PdfListActivity, pdfModel.filePath)
                    }

                    2 -> {
                        Utils.printFile(mainBaseContext,pdfModel.filePath)
                    }

                    3 -> {
                        val deleteDialog = ActionConfirmationDialog(
                            this,
                            getString(R.string.delete),
                            getString(R.string.delete_msg_file_single),
                            getString(R.string.delete),
                            positiveBtnClickListener = {
                                deletePdfFile(pdfModel)
                            })
                        deleteDialog.show()
                    }
                }
            })
        binding.pdfRecycler.adapter = pdfListAdapter

        loadAllPdfs()

        binding.pdfRecycler.post {
            FastScroller(binding.handleView).bind(binding.pdfRecycler)
        }
        binding.icBack.setOnClickListener {
            onBackPressed()
        }
    }


    override fun onBackPressed() {
        if (preferences.isNeedInterAd) {
            AdsConfig.showInterstitialAd(this) {
                if (it) preferences.isNeedInterAd = false
                finish()
            }
        } else {
            finish()
        }
    }

    private fun deletePdfFile(pdfModel: PdfModel) {
        try {
            File(pdfModel.filePath).delete()
            Utils.deleteFromMediaStore(this, pdfModel.filePath)
            MediaScannerConnection.scanFile(
                this, arrayOf<String>(pdfModel.filePath), null
            ) { path: String?, uri: Uri? -> }

            val deletePos = allPdfs.indexOf(pdfModel)
            allPdfs.removeAt(deletePos)
            allPdfs.remove(pdfModel)
            pdfListAdapter?.notifyItemRemoved(deletePos)
            //pdfListAdapter?.notifyDataSetChanged()
        } catch (e: Exception) {
            toast(getString(R.string.failed))
        }
    }

    private fun loadAllPdfs() {
        allPdfs.clear()

        val projection = arrayOf(
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.DATA,
            MediaStore.Files.FileColumns.DATE_ADDED
        )

        val selection = "${MediaStore.Files.FileColumns.MIME_TYPE}=?"
        val selectionArgs = arrayOf("application/pdf")

        // ✅ Latest first
        val sortOrder = "${MediaStore.Files.FileColumns.DATE_ADDED} DESC"

        val uri = MediaStore.Files.getContentUri("external")

        contentResolver.query(uri, projection, selection, selectionArgs, sortOrder)?.use { cursor ->
            val nameCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME)
            val pathCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DATA)

            while (cursor.moveToNext()) {
                val name = cursor.getString(nameCol)
                val path = cursor.getString(pathCol)
                val folder = path.getParentFolder()
                allPdfs.add(PdfModel(name, path, folder))
            }
        }

        pdfListAdapter?.submitList(allPdfs)

        val folders = allPdfs.map { it.folder }
            .distinct()
            .sorted()
        val folderList = listOf("All Pdf") + folders
        pdfFolderAdapter?.submitList(folderList)
    }


}