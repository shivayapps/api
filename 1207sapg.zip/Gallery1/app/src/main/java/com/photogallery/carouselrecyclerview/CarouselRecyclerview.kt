package com.photogallery.carouselrecyclerview

import android.content.Context
import android.os.Bundle
import android.os.Parcelable
import android.util.AttributeSet
import androidx.recyclerview.widget.RecyclerView
import com.photogallery.carouselrecyclerview.CarouselLayoutManager

class CarouselRecyclerview(context: Context, attributeSet: AttributeSet) : RecyclerView(context, attributeSet) {
    private var carouselLayoutManagerBuilder: CarouselLayoutManager.Builder =
        CarouselLayoutManager.Builder()

    private var layoutManagerState: Parcelable? = null

    companion object {
        private const val SAVE_SUPER_STATE = "super-state"
        private const val SAVE_LAYOUT_MANAGER = "layout-manager-state"
    }

    init {
        layoutManager = carouselLayoutManagerBuilder.build()
        isChildrenDrawingOrderEnabled = true
    }

    fun set3DItem(is3DItem: Boolean) {
        carouselLayoutManagerBuilder.set3DItem(is3DItem)
        layoutManager = carouselLayoutManagerBuilder.build()
    }

    fun setInfinite(isInfinite: Boolean) {
        carouselLayoutManagerBuilder.setIsInfinite(isInfinite)
        layoutManager = carouselLayoutManagerBuilder.build()
    }

    fun setFlat(isFlat: Boolean) {
        carouselLayoutManagerBuilder.setIsFlat(isFlat)
        layoutManager = carouselLayoutManagerBuilder.build()
    }

    fun setAlpha(isAlpha: Boolean) {
        carouselLayoutManagerBuilder.setIsAlpha(isAlpha)
        layoutManager = carouselLayoutManagerBuilder.build()
    }

    fun setIntervalRatio(ratio: Float) {
        carouselLayoutManagerBuilder.setIntervalRatio(ratio)
        layoutManager = carouselLayoutManagerBuilder.build()
    }

    fun setIsScrollingEnabled(isScrollingEnabled: Boolean) {
        carouselLayoutManagerBuilder.setIsScrollingEnabled(isScrollingEnabled)
        layoutManager = carouselLayoutManagerBuilder.build()
    }

    fun setOrientation(@Orientation orientation: Int) {
        carouselLayoutManagerBuilder.setOrientation(orientation)
        layoutManager = carouselLayoutManagerBuilder.build()
    }

    fun getCarouselLayoutManager(): CarouselLayoutManager {
        return layoutManager as CarouselLayoutManager
    }

    override fun getChildDrawingOrder(childCount: Int, i: Int): Int {
        val center: Int = getCarouselLayoutManager().centerPosition()

        // Get the actual position of the i-th child view in RecyclerView
        val actualPos: Int = getCarouselLayoutManager().getChildActualPos(i)
        var order: Int = i

        if (actualPos != Int.MIN_VALUE) {

            // The number of intervals from the middle item
            val dist = actualPos - center
            // [< 0] indicates that the item is located to the left of the middle item and can be drawn in order
            // [< 0] indicates that the item is located to the left of the middle item and can be drawn in order
            order = if (dist < 0) {
                i
            } else {
                //[>= 0] It means that the item is located to the right
                // of the middle item, and the order needs to be reversed.
                childCount - 1 - dist
            }
        }

        if (order < 0) order = 0 else if (order > childCount - 1) order = childCount - 1

        return order
    }


    fun setItemSelectListener(listener: CarouselLayoutManager.OnSelected) {
        getCarouselLayoutManager().setOnSelectedListener(listener)
    }

    override fun onSaveInstanceState(): Parcelable? {
        val bundle = Bundle()
        bundle.putParcelable(SAVE_SUPER_STATE, super.onSaveInstanceState())

        bundle.putParcelable(SAVE_LAYOUT_MANAGER, getCarouselLayoutManager().onSaveInstanceState())
        return bundle
    }

    override fun onRestoreInstanceState(state: Parcelable?) {
        if (state is Bundle) {
            layoutManagerState = state.getParcelable(SAVE_LAYOUT_MANAGER)
            super.onRestoreInstanceState(state.getParcelable(SAVE_SUPER_STATE))

        }else super.onRestoreInstanceState(state)

    }

    fun getSelectedPosition() = getCarouselLayoutManager().getSelectedPosition()

    private fun restorePosition() {
        if(layoutManagerState != null) {
            getCarouselLayoutManager().onRestoreInstanceState(layoutManagerState)
            layoutManagerState = null
        }
    }

    override fun setAdapter(adapter: Adapter<*>?) {
        super.setAdapter(adapter)
        restorePosition()
    }
}
