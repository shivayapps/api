package com.photogallery.dialog

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.AdmobNative
//import com.example.customview.AppOpenManager
//import com.example.customview.adconfig.NativeAdHelper.mMainNative
//import com.example.customview.adconfig.NativeAdHelper.showMainNativeAd
import com.photogallery.databinding.DialogExitBinding
import com.photogallery.utils.DIALOG_DIM_AMOUNT

class ExitConfirmationDialog(
    val activity: Activity,
    val clickListener: (isExit: Boolean) -> Unit
) : Dialog(activity) {

    lateinit var binding: DialogExitBinding
    lateinit var mAdmobNative: AdmobNative
    var isExitDialogOpen = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        window?.setDimAmount(DIALOG_DIM_AMOUNT)
        window?.attributes?.windowAnimations = android.R.style.Animation_Dialog
//        window?.decorView!!.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        binding = DialogExitBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT
        )
        AdsConfig.isDialogOpen = true
        binding.btnCancel.setOnClickListener {
            dismiss()
        }
        binding.btnExit.setOnClickListener {
            dismiss()
            clickListener.invoke(true)
        }
//        isExitDialogOpen = true
        loadNativeAd()
    }

    private fun loadNativeAd() {
        mAdmobNative = AdmobNative()
    }

}