package com.photogallery.secret

import android.app.Activity
import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.photogallery.R
import com.photogallery.databinding.ActivityOtpBinding
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.extension.toast
import com.photogallery.otpview.OTPListener
import com.photogallery.secret.activity.PrivateActivity
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences
import java.util.Calendar
import kotlin.jvm.java

class OtpActivity : AppCompatActivity() {

    lateinit var binding: ActivityOtpBinding
    lateinit var preferences: Preferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOtpBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        intView()
    }

    var veriCode=""
    var codeTimeOut=0L
    lateinit var animation: Animation
    private fun intView() {
        animation = AnimationUtils.loadAnimation(this, R.anim.anim_shake)
        preferences = Preferences(this)
        binding.txtTitle.text = getString(R.string.reset_password)

        veriCode=preferences.getVeriCode()
        codeTimeOut=preferences.getOtpTimeOut()

        binding.txtHint.text =
            getString(R.string.check_otp_message, preferences.securityEmail)


//        cal.add(Calendar.MINUTE,cal.get(Calendar.MINUTE))
//        val timeAfter30=cal.timeInMillis

        intListener()
    }

    private fun startTimer() {
        binding.txtResend.setTextColor(Color.parseColor("#898F9B"))
        binding.txtTimer.beVisible()
        binding.txtTimer.setUnits(null, null, null, "s")
        binding.txtTimer.setCountTime(40)
        binding.txtTimer.startCount()
        binding.txtTimer.setOnCountOverListener {
            binding.txtTimer.beGone()
            binding.txtResend.setTextColor(ColorStateList.valueOf(resources.getColor(R.color.color_primary)))
        }
    }

    private fun setErrorAnimation(view: View) {
        view.startAnimation(animation)
    }

    private fun intListener() {

        binding.icBack.setOnClickListener {
            onBackPressed()
        }
        startTimer()
//        val progressDialog = ProgressDialog(this)
        binding.llResend.setOnClickListener {

            val clientMail = preferences.securityEmail
            val progressDialog = ProgressDialog(this, ProgressDialog.THEME_DEVICE_DEFAULT_DARK)
            progressDialog.show()
//                        MailUtil.requestOtp(activity,clientMail, subject, content, mailListener = {
            MailUtil.requestOtp(this, mailListener = {
                if(!isFinishing && !isDestroyed) {
                    if (progressDialog.isShowing)
                        progressDialog.dismiss()
                }
                if(it) {
                    runOnUiThread { startTimer() }
                    toast(getString(R.string.reset_password_send_to, clientMail))
                } else {
                    toast(getString(R.string.something_went_wrong_please_try_again_latter))
                }
            })
        }

        binding.edtVeriCode.otpListener=object : OTPListener {
            override fun onInteractionListener(otp: String) {
                if(otp.length==4) {
                    binding.btnConfirm.backgroundTintList= ColorStateList.valueOf(resources.getColor(
                        R.color.color_primary))
                } else {
                    binding.btnConfirm.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#1F2337"))
                }
            }

            override fun onOTPComplete(otp: String) {
            }
        }

        binding.btnConfirm.setOnClickListener {

            val cal1= Calendar.getInstance()
            val cal2= Calendar.getInstance()
            cal2.timeInMillis=codeTimeOut

            val diff: Long = cal1.timeInMillis - cal2.timeInMillis
            val seconds = diff / 1000
            val minutes = seconds / 60
            val hours = minutes / 60
            val days = hours / 24
            Log.e("OtpTimeOut","========\nseconds:$seconds,\nminutes:$minutes,\nhours:$hours,\ndays:$days")

            if(minutes<30 && hours<=0 && days<=0) {
                val strInput = binding.edtVeriCode.otp.toString().trim()
                if(strInput==veriCode) {
                    preferences.isPasscode=false
                    preferences.isSetLock=false
                    preferences.isPinLock=true
                    resetLockResultLauncher.launch(
                        Intent(
                            this,
                            LockResetActivity::class.java
                        ).putExtra(Constant.EXTRA_RESET_PASS, true)
                    )
                } else {
                    setErrorAnimation(binding.edtVeriCode)
                    toast(getString(R.string.incorrect_verification_code_please_check_your_email_and_try_again))
                }
            } else {
                toast(getString(R.string.your_verification_code_has_expired_request_a_new_one_and_try_again))
            }
        }

    }

    var resetLockResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
            val intent= Intent(this, PrivateActivity::class.java)
            startActivity(intent)
            (this@OtpActivity).finish()
        } else {
            Log.e("LockFragment", "lockActivityResultLauncher:intView")
        }
    }

}