package com.photogallery.secret

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatImageView
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.addTextChangedListener
import com.andrognito.patternlockview.PatternLockView
import com.andrognito.patternlockview.listener.PatternLockViewListener
import com.andrognito.patternlockview.utils.PatternLockUtils
import com.photogallery.R
import com.photogallery.databinding.ActivityLockBinding
import com.photogallery.dialog.ResetStyleDialog
import com.photogallery.dialog.SimpleProgressDialog
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.extension.toast
import com.photogallery.secret.activity.PrivateActivity
import com.photogallery.utils.Constant.EXTRA_RESET_PASS
import com.photogallery.utils.Preferences

class LockSetActivity : AppCompatActivity() {

    private val TAG = "LockActivity"
    var isShowPinLock = false


    private var tempStep = 0
    var isResetPass = false
    var isChangePass = false
    lateinit var animation: Animation
    lateinit var preferences: Preferences

    var temp = 0
    var passcode = ""
    var isForgotPassOpen = false

    private val lockListener: (Boolean) -> Unit = { isUnlock ->
        if (isUnlock) setSuccess() else finish()
    }

    private fun setSuccess() {
        runOnUiThread {
            preferences.isSetLock = true
            setResult(RESULT_OK)
            (this@LockSetActivity).finish()
        }
    }

    private lateinit var binding: ActivityLockBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityLockBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        preferences = Preferences(this)
        isShowPinLock = preferences.isPinLock
        animation = AnimationUtils.loadAnimation(this, R.anim.anim_shake)

        initView()
        initListeners()
    }

    // ---------------------------------------
    // Initialization
    // ---------------------------------------

    private fun initView() {
        tempStep = 0
        passcode = ""

        binding.pass.setText("")
        binding.patterLockView.clearPattern()

        updateLockView()
        updateTitle()
        if (preferences.isSetLock) {
            binding.llLockView.beVisible()
            binding.btnSwitch.beGone()
        } else {

        }
    }

    override fun onBackPressed() {

        finish()

    }

    private fun updateTitle() {
        when {
            isChangePass -> {
                tempStep = -1
                binding.title.text =
                    if (isShowPinLock)
                        getString(R.string.enter_your_current_pin)
                    else
                        getString(R.string.draw_your_current_pattern)

                binding.forgot.visibility = View.GONE
//                binding.llSwitch.visibility = View.GONE
//                binding.llLockView.visibility = View.VISIBLE
            }

            else -> {
                if (isShowPinLock) {
                    if (preferences.isPasscode) {
                        binding.title.text = getString(R.string.enter_your_pin)
                        binding.forgot.visibility = View.VISIBLE
//                        binding.llSwitch.visibility = View.GONE
//                        binding.llLockView.visibility = View.VISIBLE
                    } else {
                        binding.title.text = getString(R.string.set_your_pin)
//                        binding.llSwitch.visibility = View.VISIBLE
//                        binding.llLockView.visibility = View.GONE
                        binding.forgot.visibility = View.GONE
                    }
                } else {
                    if (preferences.isPatternSet) {
                        binding.title.text = getString(R.string.draw_your_pattern)
                        binding.forgot.visibility = View.VISIBLE
//                        binding.llSwitch.visibility = View.GONE
//                        binding.llLockView.visibility = View.VISIBLE
                    } else {
                        binding.title.text = getString(R.string.draw_an_unlock_pattern)
//                        binding.llSwitch.visibility = View.VISIBLE
//                        binding.llLockView.visibility = View.GONE
                        binding.forgot.visibility = View.GONE
                    }
                }
            }
        }
    }

    private fun updateLockView() {
        if (isShowPinLock) {
            binding.txtSwitch.setText(getString(R.string.switch_to_pattern))
            binding.patterLockView.visibility = View.GONE
            binding.loutPinNumber.visibility = View.VISIBLE
            binding.loutPinDots.visibility = View.VISIBLE
        } else {
            binding.txtSwitch.setText(getString(R.string.switch_to_pin))
            binding.patterLockView.visibility = View.VISIBLE
            binding.loutPinNumber.visibility = View.INVISIBLE
            binding.loutPinDots.visibility = View.GONE
        }
    }

    // ---------------------------------------
    // Listeners
    // ---------------------------------------

    private fun initListeners() {
        setupSwitchListeners()
        setupPinButtons()
        setupPatternListener()
        setupPinWatcher()

        binding.forgot.setOnClickListener {
            isForgotPassOpen = true

            if(preferences.securityEmail.isNotEmpty()){
                val resetStyleDialog =
                    ResetStyleDialog(this, methodListener = {
                        if (it == 1) {
                            val clientMail = preferences.securityEmail
                            val progressDialog = SimpleProgressDialog(
                                this@LockSetActivity,
                                getString(R.string.please_wait),
                            )
                            progressDialog.setCancelable(false)
                            progressDialog.show()
//                        MailUtil.requestOtp(activity,clientMail, subject, content, mailListener = {
                            MailUtil.requestOtp(this@LockSetActivity, mailListener = {
                                progressDialog.dismiss()
                                if (it) {
                                    toast(getString(R.string.reset_password_send_to, clientMail))
                                    val intent = Intent(this@LockSetActivity, OtpActivity::class.java)
                                    startActivity(intent)
                                    lockListener?.invoke(false)
                                } else {
                                    toast(getString(R.string.something_went_wrong_please_try_again_latter))
                                }
                            })

                        } else if (it == 2) {
                            resetWithSecurityQuestion()
                        }
                    })
                resetStyleDialog.show()
            } else resetWithSecurityQuestion()
        }
    }

    private fun setupSwitchListeners() {
        binding.btnSwitch.setOnClickListener {
            isShowPinLock = !isShowPinLock
            initView()
        }

    }

    private fun setupPinButtons() {
        val buttons = listOf(
            binding.btnNo0 to "0",
            binding.btnNo1 to "1",
            binding.btnNo2 to "2",
            binding.btnNo3 to "3",
            binding.btnNo4 to "4",
            binding.btnNo5 to "5",
            binding.btnNo6 to "6",
            binding.btnNo7 to "7",
            binding.btnNo8 to "8",
            binding.btnNo9 to "9"
        )

        buttons.forEach { (btn, value) ->
            btn.setOnClickListener {
                binding.pass.append(value)
            }
        }

        binding.btnNoClear.setOnClickListener {
            val text = binding.pass.text.toString()
            if (text.isNotEmpty()) {
                binding.pass.setText(text.dropLast(1))
                binding.pass.setSelection(binding.pass.text?.length ?: 0)
            }
        }
    }

    private fun setupPatternListener() {
        binding.patterLockView.addPatternLockListener(object : PatternLockViewListener {

            override fun onStarted() {
                binding.tvErrorMsg.visibility = View.INVISIBLE
            }

            override fun onProgress(progressPattern: List<PatternLockView.Dot>) {}

            override fun onComplete(pattern: List<PatternLockView.Dot>) {
                val patternString =
                    PatternLockUtils.patternToString(binding.patterLockView, pattern)

                if (patternString.length < 4)
                    showPatternError(getString(R.string.patter_validation))
                else
                    handlePatternStep(patternString)
            }

            override fun onCleared() {}
        })
    }

    private fun setupPinWatcher() {
        binding.pass.addTextChangedListener {
            val length = it?.length ?: 0
            updateDots(length)

            if (length == 4) handlePinStep()
        }
    }

    // ---------------------------------------
    // PIN Logic
    // ---------------------------------------

    private fun handlePinStep() {
        val input = binding.pass.text.trim().toString()

        if (!preferences.isPasscode || (isChangePass && tempStep != -1)) {

            if (tempStep == 0) {
                passcode = input
                tempStep = 1

                binding.root.postDelayed({
                    binding.title.text =
                        if (isChangePass)
                            getString(R.string.confirm_your_new_pin)
                        else
                            getString(R.string.confirm_your_pin)

                    binding.pass.setText("")
                }, 300)

            } else {
                if (passcode == input) {
                    preferences.pincode = passcode
                    setPasswordSuccess()
                } else {
                    binding.pass.setText("")
                    showToast(getString(R.string.pin_not_match))
                    setErrorAnimation(binding.loutPinDots)
                }
            }

        } else {
            if (preferences.pincode == input) {
                if (isChangePass) {
                    tempStep = 0
                    binding.title.text = getString(R.string.enter_your_new_pin)
                    binding.pass.setText("")
                } else {
                    setPasswordSuccess()
                }
            } else {
                binding.pass.setText("")
                showToast(getString(R.string.wrong_pin))
                setErrorAnimation(binding.loutPinDots)
            }
        }
    }

    // ---------------------------------------
    // Pattern Logic
    // ---------------------------------------

    private fun handlePatternStep(pattern: String) {

        if (!preferences.isPatternSet || (isChangePass && tempStep != -1)) {

            if (tempStep == 0) {
                passcode = pattern
                tempStep = 1

                binding.root.postDelayed({
                    binding.title.text =
                        if (isChangePass)
                            getString(R.string.draw_confirm_new_pattern)
                        else
                            getString(R.string.draw_pattern_again)

                    binding.patterLockView.clearPattern()
                }, 300)

            } else {
                if (passcode == pattern) {
                    preferences.pattern = passcode
                    setPasswordSuccess()
                } else {
                    showPatternError(getString(R.string.pattern_not_match))
                }
            }

        } else {
            if (preferences.pattern == pattern) {
                if (isChangePass) {
                    tempStep = 0
                    binding.title.text = getString(R.string.draw_your_new_pattern)
                    binding.patterLockView.clearPattern()
                } else {
                    setPasswordSuccess()
                }
            } else {
                showPatternError(getString(R.string.pattern_not_match))
            }
        }
    }

    private fun showPatternError(message: String) {
        binding.patterLockView.setViewMode(PatternLockView.PatternViewMode.WRONG)
        binding.tvErrorMsg.visibility = View.VISIBLE
        binding.tvErrorMsg.text = message
        setErrorAnimation(binding.tvErrorMsg)
    }

    // ---------------------------------------
    // Success
    // ---------------------------------------

    private fun setPasswordSuccess() {

        if (isResetPass) {
            preferences.putSetQuestion(true)
        }

        preferences.isPinLock = isShowPinLock
        preferences.isPatternSet = !isShowPinLock
        preferences.isPasscode = isShowPinLock

        if (preferences.getSetQuestion()) {
            lockListener?.invoke(true)
        } else {
            showSecurityQuestion()
        }
    }

    // ---------------------------------------
    // Security Question
    // ---------------------------------------

    private fun showSecurityQuestion() {
        val intent = Intent(this@LockSetActivity, LockQuestionActivity::class.java)
        intent.putExtra("type", 0)
        questionSetLauncher.launch(intent)
    }

    private fun resetWithSecurityQuestion(){
        val intent = Intent(this@LockSetActivity, LockQuestionActivity::class.java)
        intent.putExtra("type", 1)
        questionResetLauncher.launch(intent)
    }

    var questionResetLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
            preferences.isPatternSet = false
            preferences.isPasscode = false
            preferences.isPinLock = true
            resetLockResultLauncher.launch(
                Intent(
                    this,
                    LockResetActivity::class.java
                ).putExtra(EXTRA_RESET_PASS, true)
            )
        }
    }
    var questionSetLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
            if (!isChangePass) {
                Toast.makeText(
                    this,
                    if (isShowPinLock) getString(R.string.pin_set_successfully) else getString(
                        R.string.pattern_set_successfully
                    ),
                    Toast.LENGTH_SHORT
                ).show()
            }
            lockListener?.invoke(true)
        } else {
            preferences.isPatternSet = false
            preferences.isPasscode = false
            preferences.isPinLock = true
            lockListener?.invoke(false)
        }
    }

    var resetLockResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
            val intent = Intent(this, PrivateActivity::class.java)
            startActivity(intent)
            lockListener?.invoke(false)
        } else {
        }
    }

    // ---------------------------------------
    // Utilities
    // ---------------------------------------

    private fun updateDots(length: Int) {
        val dots = listOf(
            binding.dot1,
            binding.dot2,
            binding.dot3,
            binding.dot4
        )

        dots.forEachIndexed { index, image ->
            if (index < length) selectDot(image)
            else unSelectDot(image)
        }
    }

    private fun selectDot(image: AppCompatImageView) {
        image.setImageDrawable(
            ContextCompat.getDrawable(this, R.drawable.ic_pass_dot_fill)
        )
    }

    private fun unSelectDot(image: AppCompatImageView) {
        image.setImageDrawable(
            ContextCompat.getDrawable(this, R.drawable.ic_pass_dot_unfill)
        )
    }

    private fun setErrorAnimation(view: View) {
        view.startAnimation(animation)
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}