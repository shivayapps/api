#-keep class com.photogallery.** { *; }
-dontwarn android.graphics.Canvas
#-dontwarn com.photogallery.**
-dontwarn org.apache.**

# Joda
-dontwarn org.joda.convert.**
-dontwarn org.joda.time.**
-keep class org.joda.time.** { *; }
-keep interface org.joda.time.** { *; }

# Picasso
-dontwarn javax.annotation.**
-keepnames class okhttp3.internal.publicsuffix.PublicSuffixDatabase
-dontwarn org.codehaus.mojo.animal_sniffer.*
-dontwarn okhttp3.internal.platform.ConscryptPlatform

-keepclassmembers class * implements android.os.Parcelable {
    static ** CREATOR;
}

# RenderScript
-keepclasseswithmembernames class * {
native <methods>;
}
-keep class androidx.renderscript.** { *; }

# Reprint
-keep class com.github.ajalt.reprint.module.** { *; }


############################
##   import from common   ##
############################
-renamesourcefileattribute SourceFile
-keepattributes SourceFile, LineNumberTable

-dontwarn com.bumptech.glide.load.engine.bitmap_recycle.LruBitmapPool
-dontwarn com.bumptech.glide.load.resource.bitmap.Downsampler
-dontwarn com.bumptech.glide.load.resource.bitmap.HardwareConfigState
-dontwarn com.bumptech.glide.manager.RequestManagerRetriever

-keep public class * extends java.lang.Exception

-keep class android.support.v7.widget.SearchView { *; }


# Joda
-dontwarn org.joda.convert.**
-dontwarn org.joda.time.**
-keep class org.joda.time.** { *; }
-keep interface org.joda.time.** { *; }

-keep public class * implements com.bumptech.glide.module.GlideModule
-keep public class * extends com.bumptech.glide.module.AppGlideModule
-keep class com.bumptech.glide.GeneratedAppGlideModuleImpl
-keep public enum com.bumptech.glide.load.ImageHeaderParser$** {
  **[] $VALUES;
  public *;
}
-dontwarn java.lang.invoke.StringConcatFactory
-dontwarn javax.swing.tree.TreeNode

#Gson https://github.com/google/gson/blob/main/gson/src/main/resources/META-INF/proguard/gson.pro
-keepattributes Signature
-keepattributes RuntimeVisibleAnnotations,AnnotationDefault

-if class com.google.gson.reflect.TypeToken
-keep,allowobfuscation class com.google.gson.reflect.TypeToken

-keep,allowobfuscation class * extends com.google.gson.reflect.TypeToken
-keep,allowobfuscation,allowoptimization @com.google.gson.annotations.JsonAdapter class *

-keepclassmembers,allowobfuscation class * {
  @com.google.gson.annotations.Expose <fields>;
  @com.google.gson.annotations.JsonAdapter <fields>;
  @com.google.gson.annotations.Since <fields>;
  @com.google.gson.annotations.Until <fields>;
}

-keepclassmembers class * extends com.google.gson.TypeAdapter {
  <init>();
}
-keepclassmembers class * implements com.google.gson.TypeAdapterFactory {
  <init>();
}
-keepclassmembers class * implements com.google.gson.JsonSerializer {
  <init>();
}
-keepclassmembers class * implements com.google.gson.JsonDeserializer {
  <init>();
}

-if class *
-keepclasseswithmembers,allowobfuscation class <1> {
  @com.google.gson.annotations.SerializedName <fields>;
}
-if class * {
  @com.google.gson.annotations.SerializedName <fields>;
}
-keepclassmembers,allowobfuscation,allowoptimization class <1> {
  <init>();
}

# EventBus
-keepattributes *Annotation*
-keepclassmembers class * {
    @org.greenrobot.eventbus.Subscribe <methods>;
}
-keep enum org.greenrobot.eventbus.ThreadMode { *; }

# If using AsyncExecutord, keep required constructor of default event used.
# Adjust the class name if a custom failure event type is used.
-keepclassmembers class org.greenrobot.eventbus.util.ThrowableFailureEvent {
    <init>(java.lang.Throwable);
}

# Accessed via reflection, avoid renaming or removal
-keep class org.greenrobot.eventbus.android.AndroidComponentsImpl
-dontwarn com.smparkworld.parkdatetimepicker.BR

-dontwarn java.awt.datatransfer.DataFlavor
-dontwarn java.awt.datatransfer.Transferable

# Accessed to forget email
-keep class javamail.** {*;}
-keep class javax.mail.** {*;}
-keep class javax.activation.** {*;}

-keep class com.sun.mail.dsn.** {*;}
-keep class com.sun.mail.handlers.** {*;}
-keep class com.sun.mail.smtp.** {*;}
-keep class com.sun.mail.util.** {*;}
-keep class mailcap.** {*;}
-keep class mimetypes.** {*;}
-keep class myjava.awt.datatransfer.** {*;}
-keep class org.apache.harmony.awt.** {*;}
-keep class org.apache.harmony.misc.** {*;}

# This is generated automatically by the Android Gradle plugin.
-dontwarn com.google.android.gms.auth.api.credentials.Credential$Builder
-dontwarn com.google.android.gms.auth.api.credentials.Credential
-dontwarn com.google.android.gms.auth.api.credentials.CredentialRequest$Builder
-dontwarn com.google.android.gms.auth.api.credentials.CredentialRequest
-dontwarn com.google.android.gms.auth.api.credentials.CredentialRequestResponse
-dontwarn com.google.android.gms.auth.api.credentials.Credentials
-dontwarn com.google.android.gms.auth.api.credentials.CredentialsClient
-dontwarn com.google.android.gms.auth.api.credentials.CredentialsOptions$Builder
-dontwarn com.google.android.gms.auth.api.credentials.CredentialsOptions
-dontwarn com.google.android.gms.auth.api.credentials.HintRequest$Builder
-dontwarn com.google.android.gms.auth.api.credentials.HintRequest

# adjust
-keep class org.wysaid.nativePort.** { *; }

-dontwarn org.xmlpull.v1.**
-dontwarn org.kxml2.io.**
-dontwarn android.content.res.**
-dontwarn org.slf4j.impl.StaticLoggerBinder

-keep class org.xmlpull.** { *; }
-keepclassmembers class org.xmlpull.** { *; }

# This is generated automatically by the Android Gradle plugin.
-dontwarn org.bouncycastle.jsse.BCSSLParameters
-dontwarn org.bouncycastle.jsse.BCSSLSocket
-dontwarn org.bouncycastle.jsse.provider.BouncyCastleJsseProvider
-dontwarn org.conscrypt.Conscrypt$Version
-dontwarn org.conscrypt.Conscrypt
-dontwarn org.conscrypt.ConscryptHostnameVerifier
-dontwarn org.openjsse.javax.net.ssl.SSLParameters
-dontwarn org.openjsse.javax.net.ssl.SSLSocket
-dontwarn org.openjsse.net.ssl.OpenJSSE

-keep class com.photogallery.extension.** {*;}
-keep class com.photogallery.utils.LocaleHelper
-keep class com.photogallery.utils.** {*;}
-keep class com.photogallery.model.LanguageData
-keep class com.photogallery.model.** {*;}

-dontwarn com.facebook.infer.annotation.Nullsafe$Mode
-dontwarn com.facebook.infer.annotation.Nullsafe

#-printseeds proguard/seeds.txt
#-printusage proguard/unused.txt
#-printmapping proguard/mapping.txt
-optimizationpasses 5
#-dontusemixedcaseclassnames
#-dontskipnonpubliclibraryclasses
#-dontoptimize
#-dontpreverify
#-verbose
#-optimizations !code/simplification/arithmetic,!field/*,!class/merging/*
#-keepattributes *Annotation*

-dontwarn com.google.android.gms.ads.identifier.**
-keep class com.facebook.** { *; }
-keep class com.applovin.** { *; }
-keep class com.google.android.gms.ads.** { *; }
-keep public class com.google.android.gms.ads.**{
   public *;
}

##########  AdsConfig core ##########
# Keep AdsConfig and its companion object
-keep class com.adconfig.AdsConfig {
    public static final com.adconfig.AdsConfig$Companion Companion;
    *;
}
-keep class com.adconfig.AdsConfig$Companion { *; }

# Keep AdsConfig.Builder
-keep class com.adconfig.AdsConfig$Builder { *; }

# Keep AdmobInitializer if used
-keep class com.adconfig.AdmobInitializer { *; }

##########  adsutil package ##########
-keep class com.adconfig.adsutil.** { *; }

##########  open ad helpers ##########
-keep class com.adconfig.adsutil.openad.AppOpenApplication { *; }
-keep class com.adconfig.adsutil.openad.AppOpenApplication$AppLifecycleListener { *; }
-keep class com.adconfig.adsutil.openad.OpenAdHelper { *; }

##########  admob implementations ##########
-keep class com.adconfig.adsutil.admob.AdmobIntersAdImpl { *; }
-keep class com.adconfig.adsutil.admob.AdmobNative { *; }
-keep class com.adconfig.adsutil.admob.BannerAdHelper { *; }
-keep class com.adconfig.adsutil.admob.NativeAdHelper { *; }
-keep class com.adconfig.adsutil.admob.NativeLayoutType { *; }

##########  utils ##########
-keep class com.adconfig.adsutil.utils.** { *; }

##########  view binding (if used) ##########
-keep class com.adconfig.databinding.LayoutShimmerAdBannerBinding { *; }
-keep class com.adconfig.databinding.LayoutShimmerGoogleNativeAdBigBinding { *; }

##########  Kotlin companion objects (safe rule) ##########
# Generic rule to keep ALL Kotlin companion objects so you don’t have to write each one
-keepclassmembers class * {
    public static final <fields>;
    companion object;
}
-keep class com.adconfig.AdsConfig { *; }
-keep class com.adconfig.AdsConfig$Companion { *; }

# Please add these rules to your existing keep rules in order to suppress warnings.
# This is generated automatically by the Android Gradle plugin.
-dontwarn com.adconfig.AdsConfig$Builder
-dontwarn com.adconfig.AdsConfig$Companion
-dontwarn com.adconfig.adsutil.AdsParameters
-dontwarn com.adconfig.adsutil.Config
-dontwarn com.adconfig.adsutil.abstract.IntersAd
-dontwarn com.adconfig.adsutil.admob.AdmobIntersAdImpl
-dontwarn com.adconfig.adsutil.admob.AdmobNative
-dontwarn com.adconfig.adsutil.admob.BannerAdHelper
-dontwarn com.adconfig.adsutil.admob.NativeAdHelper
-dontwarn com.adconfig.adsutil.admob.NativeLayoutType
-dontwarn com.adconfig.adsutil.openad.OpenAdHelper
-dontwarn com.adconfig.adsutil.utils.ExtContextKt
-dontwarn com.adconfig.adsutil.utils.ExtensionsKt
-dontwarn com.adconfig.databinding.LayoutShimmerAdBannerBinding
-dontwarn com.adconfig.databinding.LayoutShimmerGoogleNativeAdBigBinding