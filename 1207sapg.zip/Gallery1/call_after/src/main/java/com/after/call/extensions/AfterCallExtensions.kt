package com.after.call.extensions

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.RadioButton
import androidx.recyclerview.widget.DiffUtil

object Extensions {
    @SuppressLint("ClickableViewAccessibility")
    fun EditText.setDrawableRightTouch(setClickListener: () -> Unit) {
        this.setOnTouchListener(View.OnTouchListener { _, event ->
            val DRAWABLE_RIGHT = 2
            if (event.action == MotionEvent.ACTION_UP && compoundDrawables[DRAWABLE_RIGHT] != null) {
                if (event.rawX >= this.right - this.compoundDrawables[DRAWABLE_RIGHT].bounds.width()
                ) {
                    setClickListener()
                    return@OnTouchListener true
                }
            }
            false
        })
    }

    @SuppressLint("ClickableViewAccessibility")
    fun RadioButton.setDrawableRightTouch(setClickListener: () -> Unit) {
        this.setOnTouchListener(View.OnTouchListener { _, event ->
            val DRAWABLE_RIGHT = 2
            if (event.action == MotionEvent.ACTION_UP && compoundDrawables[DRAWABLE_RIGHT] != null) {
                if (event.rawX >= this.right - this.compoundDrawables[DRAWABLE_RIGHT].bounds.width()
                ) {
                    setClickListener()
                    return@OnTouchListener true
                }
            }
            false
        })
    }

    val STRING_DIFF_CALLBACK = object : DiffUtil.ItemCallback<String>() {
        override fun areItemsTheSame(oldItemObj: String, newItemObj: String): Boolean =
            oldItemObj == newItemObj

        override fun areContentsTheSame(
            oldItemObj: String,
            newItemObj: String
        ): Boolean =
            oldItemObj == newItemObj
    }

}

val Context.statusBarHeight: Int
    get() {
        var statusBarHeight = 0
        val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
        if (resourceId > 0) {
            statusBarHeight = resources.getDimensionPixelSize(resourceId)
        }
        return statusBarHeight
    }

fun Context.getAdClientConfig() = getSharedPreferences("ad_client_config", Context.MODE_PRIVATE)
fun Context.isInternetConnected(): Boolean {
    val connectivityManager =
        getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val activeNetworkInfo = connectivityManager.activeNetworkInfo
    return activeNetworkInfo != null && activeNetworkInfo.isConnected
}