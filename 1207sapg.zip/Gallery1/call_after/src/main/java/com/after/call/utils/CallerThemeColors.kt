package com.after.call.utils

import androidx.annotation.Keep


@Keep
enum class CallerThemeColors {
    DEFAULT,
    THEME1,
    THEME2,
    THEME3,
    THEME4,
    THEME5,
    THEME6,
    THEME7,
    THEME8,
    THEME9,
    THEME10
}