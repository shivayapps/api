package com.after.call.keep

import androidx.annotation.Keep

@Keep
interface CallerFirebaseEventListener {
    fun onEventListen(eventName : String)
}