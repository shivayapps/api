package com.after.call.adapter

import android.content.Context
import android.view.DragEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.after.call.R
import com.after.call.activity.EditQuickMessagesActivity
import com.after.call.extensions.callerCadBaseConfig

class EditQuickMessageListAdapter(
    private val mQuickMessagesList: MutableList<String>,
    private val context: Context,
    val onClick: (String, Boolean) -> Unit,
    val onSelect: (Boolean) -> Unit,
) : RecyclerView.Adapter<EditQuickMessageListAdapter.MessageViewHolder>() {

    private var dragStartPosition: Int = RecyclerView.NO_POSITION
    private var dragEndPosition: Int = RecyclerView.NO_POSITION
    val selectedItems = mutableSetOf<Int>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.after_call_quick_message_list_item, parent, false)
        return MessageViewHolder(view)
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        val message = mQuickMessagesList[position]
        holder.messageTextView.text = message

        // Update the visibility and state of quickSelect based on selection
        if (selectedItems.contains(position)) {
            holder.quickSelect.visibility = View.VISIBLE
            holder.moveButton.visibility = View.GONE
            holder.quickSelect.setImageDrawable(context.resources.getDrawable(R.drawable.ic_after_call_quick_selected))
        } else {
            if (selectedItems.isEmpty()) {
                holder.quickSelect.visibility = View.GONE
                holder.moveButton.visibility = View.VISIBLE
            } else {
                holder.quickSelect.visibility = View.VISIBLE
                holder.moveButton.visibility = View.GONE
                holder.quickSelect.setImageDrawable(context.resources.getDrawable(R.drawable.ic_caller_quick_unselected))
            }
        }


        val tintColor = ContextCompat.getColor(
            context,
            if (context.callerCadBaseConfig.callerCardDarkTheme) {
                R.color.after_call_card_bg_dark // Dark theme color
            } else {
                R.color.after_call_card_bg_light // Light theme color
            }
        )

        val drawable = ContextCompat.getDrawable(context, R.drawable.after_call_bordered_home_ripple)

        drawable?.mutate()?.setTint(tintColor)

        holder.mainItemView.background = drawable


        val textColorList = ContextCompat.getColorStateList(
            context, if (context.callerCadBaseConfig.callerCardDarkTheme) {
                R.color.after_call_text_color_white // Dark theme color
            } else {
                R.color.after_call_text_color_black // Light theme color
            }
        )
        holder.messageTextView.setTextColor(textColorList)

        // Handle short click
        holder.itemView.setOnClickListener {
            if (selectedItems.isNotEmpty()) {
                toggleSelection(position)
            } else {
                onClick(message, false)
            }

            if (selectedItems.size > 0) {

                onSelect.invoke(true)
            } else {

                onSelect.invoke(false)
            }
        }

        // Handle long click for multi-selection
        holder.itemView.setOnLongClickListener {

            toggleSelection(position)
            if (selectedItems.size > 0) {

                onSelect.invoke(true)
            }
            true


        }

        // Restrict drag to moveButton
        holder.moveButton.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    dragStartPosition = holder.adapterPosition
                    holder.itemView.startDragAndDrop(
                        null,
                        View.DragShadowBuilder(holder.itemView),
                        holder,
                        0
                    )
                    true
                }

                else -> false
            }
        }

        // Handle drag events on the entire item view
        holder.itemView.setOnDragListener { _, event ->
            when (event.action) {
                DragEvent.ACTION_DRAG_STARTED -> {
                    true
                }

                DragEvent.ACTION_DRAG_ENTERED -> {
                    dragEndPosition = holder.adapterPosition
                    if (dragStartPosition != RecyclerView.NO_POSITION &&
                        dragEndPosition != RecyclerView.NO_POSITION &&
                        dragStartPosition != dragEndPosition
                    ) {
                        // Move the item in the dataset
                        val movedItem = mQuickMessagesList.removeAt(dragStartPosition)
                        mQuickMessagesList.add(dragEndPosition, movedItem)

                        // Notify RecyclerView about the move
                        notifyItemMoved(dragStartPosition, dragEndPosition)

                        // Update the drag start position for the next move
                        dragStartPosition = dragEndPosition
                    }
                    true
                }

                DragEvent.ACTION_DRAG_ENDED -> {
                    // Log and persist the updated list
                    (context as? EditQuickMessagesActivity)?.updateAfterCallConfig(
                        mQuickMessagesList
                    )
                    // Reset drag positions
                    dragStartPosition = RecyclerView.NO_POSITION
                    dragEndPosition = RecyclerView.NO_POSITION
                    true
                }

                else -> false
            }
        }
    }

    fun selectAll() {
        selectedItems.clear()
        for (i in mQuickMessagesList.indices) {
            selectedItems.add(i)
        }
        notifyDataSetChanged()
        onSelect.invoke(true)
    }

    override fun getItemCount() = mQuickMessagesList.size

    fun toggleSelection(position: Int) {
        if (selectedItems.contains(position)) {
            selectedItems.remove(position)
        } else {
            selectedItems.add(position)
        }
        notifyItemChanged(position) // Update only the affected item
        onSelect.invoke(selectedItems.isNotEmpty())
    }


    fun clearSelections() {
        selectedItems.clear()
        notifyDataSetChanged()
        onSelect.invoke(false)
    }

    fun deleteSelectedItems(allClear: (Boolean) -> Unit) {
        val itemsToDelete = selectedItems.sortedDescending()
        for (position in itemsToDelete) {
            mQuickMessagesList.removeAt(position)
        }
        clearSelections()
        (context as? EditQuickMessagesActivity)?.updateAfterCallConfig(mQuickMessagesList)
        allClear.invoke(true)
    }

    class MessageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val messageTextView: TextView = itemView.findViewById(R.id.messageTextView)
        val moveButton: ImageView = itemView.findViewById(R.id.moveButton)
        val quickSelect: ImageView = itemView.findViewById(R.id.quickSelect)
        val mainItemView: RelativeLayout = itemView.findViewById(R.id.main_item_view)
    }
}
