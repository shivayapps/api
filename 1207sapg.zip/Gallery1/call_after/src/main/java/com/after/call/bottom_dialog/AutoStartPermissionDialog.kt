package com.after.call.bottom_dialog

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import com.after.call.AfterCallUtils
import com.after.call.R
import com.after.call.extensions.callerCadBaseConfig
import com.after.call.utils.CallerEventsConstants

class AutoStartPermissionDialog(
    private val context: Context,
    private val onAllowClicked: () -> Unit,
    private val onLaterClicked: () -> Unit,
) {

    private val dialogView = LayoutInflater.from(context)
        .inflate(R.layout.after_call_dialog_auto_start_permission, null)
    private val dialog = AlertDialog.Builder(context)
        .setView(dialogView)
        .setCancelable(false)
        .create()

    init {
        setupDialogAppearance()
        setupViews()
    }

    private fun setupDialogAppearance() {
        if (context.callerCadBaseConfig.callerCardDarkTheme) {
            dialog.window?.apply {
                setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                setBackgroundDrawableResource(R.drawable.after_call_bg_round_button_home_more_dark)
            }
        } else {
            dialog.window?.apply {
                setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                setBackgroundDrawableResource(R.drawable.after_call_bg_round_button_home_more_light)
            }
        }
    }

    private fun setupViews() {
        val tvTitle = dialogView.findViewById<TextView>(R.id.tvTitle)
        val tvMessage = dialogView.findViewById<TextView>(R.id.tvMessage)
        val cbDontShowAgain = dialogView.findViewById<CheckBox>(R.id.cbDontShowAgain)
        val btnLater = dialogView.findViewById<Button>(R.id.btnLater)
        val btnAllow = dialogView.findViewById<Button>(R.id.btnAllow)
        val autoDialog = dialogView.findViewById<LinearLayout>(R.id.autoDialog)

        val tintColor = ContextCompat.getColor(
            context,
            if (context.callerCadBaseConfig.callerCardDarkTheme) {
                R.color.after_call_card_bg_dark
            } else {
                R.color.after_call_card_bg_light
            }
        )

        ContextCompat.getDrawable(context, R.drawable.ic_after_call_round_bg)?.let { drawable ->
            val mutableDrawable = drawable.mutate()
            mutableDrawable.setTint(tintColor)
            autoDialog.background = mutableDrawable
        }

        val textColor = ContextCompat.getColor(
            context,
            if (context.callerCadBaseConfig.callerCardDarkTheme) {
                R.color.after_call_text_color_white
            } else {
                R.color.after_call_text_color_black
            }
        )

        tvTitle.setTextColor(textColor)
        tvMessage.setTextColor(textColor)

        btnLater.setOnClickListener {
            onLaterClicked()
            dialog.dismiss()

        }

        btnAllow.setOnClickListener {
            if (cbDontShowAgain.isChecked) {
                AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AUTO_START_CLICK_NEVER)
                context.callerCadBaseConfig.callerCardAutoStartDontShowAgain = true
            } else {
                context.callerCadBaseConfig.callerCardAutoStartDontShowAgain = false
            }
            onAllowClicked()
            dialog.dismiss()
        }
    }

    fun show() {
        dialog.show()
    }
}
