package com.after.call.keep

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.util.AttributeSet
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.annotation.Keep
import com.after.call.databinding.AfterCallContainerBinding
import java.lang.ref.WeakReference

@Keep
abstract class CallerContainer @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null,
) : RelativeLayout(context, attrs) {


    var mainContext: Activity? = null


    abstract fun getContainer(): View?

    var binding: AfterCallContainerBinding

    init {
        binding = AfterCallContainerBinding.inflate(LayoutInflater.from(context), this, true)
    }

    fun prepareData(cntx: Activity) {
        mainContext = cntx

        if(binding == null){
            binding = AfterCallContainerBinding.inflate(LayoutInflater.from(context), this, true)
        }

        try {
            binding.salesFragmentContainer.addView(getContainer())
        } catch (e: Exception) {
            Log.d("AfterCallReceiver", "addView Exception1111111 : ${e.message}")
        }
    }

    fun finish() {
        try {
            (mainContext as Activity).finishAndRemoveTask()

        } catch (e: Exception) {
        }
    }

    fun showMsg(msg: String) {
        try {
            Toast.makeText(mainContext, msg, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
        }
    }

    fun startScreenFromIntentWithoutFinish(intent: Intent) {

        try {
            context.applicationContext.startActivity(intent)
        } catch (e: Exception) {

        }
    }

    fun startScreenFromIntentWithFinish(intent: Intent) {

        try {
            context.applicationContext.startActivity(intent)
        } catch (e: Exception) {

        }
        try {
            (mainContext as Activity).finish()
        } catch (e: Exception) {
        }
    }

    fun startScreenName(activityClass: Class<*>) {

        try {
            context.applicationContext.startActivity(
                Intent(
                    context.applicationContext,
                    activityClass
                ).apply {
                    putExtra("isFromEngagement", true)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            )
        } catch (e: Exception) {

        }
        try {
            (mainContext as Activity).finish()
        } catch (e: Exception) {
        }
    }

}