package com.after.call.bottom_dialog

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.ViewGroup
import android.view.Window
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.after.call.R
import com.after.call.adapter.CustomDialogAdapter
import com.after.call.databinding.QuickReplyCustomDialogBinding
import com.after.call.extensions.callerCadBaseConfig
import com.after.call.helpers.fixItemsForQuickItems

class QuickMessageCustomDialog(
    private val context: Context,
    private val onDialogShow: (() -> Unit)? = null,
    private val onDialogDismiss: (() -> Unit)? = null,
) {

    private lateinit var adapter: CustomDialogAdapter
    private val callerMessages: MutableList<String> = mutableListOf()
    private var dialog: Dialog? = null

    fun show(itemClickListener: (String, Int) -> Unit) {
        dialog = Dialog(context, R.style.QuickReplyDialogStyle).apply {
            requestWindowFeature(Window.FEATURE_NO_TITLE)
            setContentView(R.layout.quick_reply_custom_dialog)


            val binding = QuickReplyCustomDialogBinding.bind(findViewById(R.id.dialog_root))

            // Initialize and set the adapter
            callerMessages.clear()
            callerMessages.addAll(moveSpecialItemsToBottom(getCallerMessages(context)))
            adapter = CustomDialogAdapter(callerMessages, itemClickListener)
            binding.recyclerView.adapter = adapter
            binding.recyclerView.layoutManager = LinearLayoutManager(context)

            window?.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

            // Set listeners
            setOnShowListener {
                onDialogShow?.invoke()
            }
            setOnDismissListener {
                onDialogDismiss?.invoke()
            }

            val tintColor = ContextCompat.getColor(
                context,
                if (context.callerCadBaseConfig.callerCardDarkTheme) {
                    R.color.after_call_dialogHomeBgDark // Dark theme color
                } else {
                    R.color.after_call_dialogHomeBgLight // Light theme color
                }
            )
            binding.dialogRoot.setCardBackgroundColor(tintColor)
            show()
        }
    }

    fun dismiss() {
        dialog?.dismiss()
        dialog = null
    }

    fun updateList() {
        if (dialog?.isShowing == true) {
            // Update the messages and notify the adapter
            callerMessages.clear()
            callerMessages.addAll(moveSpecialItemsToBottom(getCallerMessages(context)))
            adapter.notifyDataSetChanged()
        }
    }

    private fun getCallerMessages(context: Context): List<String> {
        return context.callerCadBaseConfig.callerCadQuickMessagesList
    }

    private fun moveSpecialItemsToBottom(messages: List<String>): List<String> {
        val mutableMessages = messages.toMutableList()

        mutableMessages.removeAll(fixItemsForQuickItems)
        mutableMessages.addAll(fixItemsForQuickItems)

        return mutableMessages
    }
}



