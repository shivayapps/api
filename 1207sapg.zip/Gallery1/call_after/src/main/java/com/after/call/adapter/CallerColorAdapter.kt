package com.after.call.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.after.call.databinding.SingleColorCallerBinding
import com.after.call.extensions.Extensions.STRING_DIFF_CALLBACK
import com.after.call.utils.CallerOnSingleClickListener


class CallerColorAdapter(val mListener: (Any) -> Unit) :
    ListAdapter<String, CallerColorAdapter.MyViewHolder>(STRING_DIFF_CALLBACK) {

    var selectedColor: String = "#6044CC"
        get() = field
        set(value) {
            field = value
            notifyDataSetChanged()
        }


    inner class MyViewHolder(private val binding: SingleColorCallerBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(color: String) {

            binding.mIVColor.isVisible = selectedColor == color

            binding.mCVColor.setCardBackgroundColor(Color.parseColor(color))

            binding.root.setOnClickListener(object : CallerOnSingleClickListener() {
                override fun onSingleClick(v: View?) {

                    selectedColor = color
                    mListener.invoke(selectedColor)
                }

            })
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(SingleColorCallerBinding.inflate(LayoutInflater.from(parent.context)))
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentTask = currentList[position]
        holder.bind(currentTask)

    }

    override fun getItemCount(): Int {
        return currentList.size
    }

}
