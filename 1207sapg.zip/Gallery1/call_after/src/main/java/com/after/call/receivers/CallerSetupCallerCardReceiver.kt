package com.after.call.receivers

/*
open class CallerSetupAfterCallReceiver : BroadcastReceiver() {
    lateinit var mContext: Context

    override fun onReceive(context: Context, intent: Intent) {
        mContext = context

        if (intent.action == TelephonyManager.ACTION_PHONE_STATE_CHANGED) {
            if (context.callerCadBaseConfig.callerCadEnable) {
                val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
                val incomingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)

                // Update call number only if empty
                if (callerCadCallNumber.isEmpty() && !incomingNumber.isNullOrEmpty()) {
                    callerCadCallNumber = incomingNumber
                }

                // Proceed only if call info should be shown
                if (context.callerCadBaseConfig.isShowCallInfo) {
                    when (state) {
                        TelephonyManager.EXTRA_STATE_IDLE -> handleCallIdleState(context)
                        TelephonyManager.EXTRA_STATE_RINGING -> handleCallRingingState(
                            context,
                            intent
                        )

                        TelephonyManager.EXTRA_STATE_OFFHOOK -> handleCallOffHookState(
                            context,
                            intent
                        )
                    }
                }
            }
        }
    }

    private fun handleCallIdleState(context: Context) {
        if (isWindowShowing) {
            stopCounter()
            if (Settings.canDrawOverlays(context)) {
                windowManager?.removeViewImmediate(binding!!.root)
            }
            isWindowShowing = false
        }

        if (Settings.canDrawOverlays(context) && context.callerCadBaseConfig.switchUnknownCallerSaved) {
            val isKeyguardLocked =
                (context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked
            if (isKeyguardLocked) {
                startIntentNoti(context)
            } else {
                if (!callerCardopen) {
                    callerCardopen = true
                    val mIntent = Intent(context, AfterCallHomeActivity::class.java).apply {
                        flags =
                            Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        putExtra("fromwhere", "ser")
                    }
                    context.startActivity(mIntent)
                }
            }
        } else {
            val keyguardManager =
                context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            val isKeyguardLocked = keyguardManager.isKeyguardLocked
            if (context.callerCadBaseConfig.switchUnknownCallerSaved) {
                startIntentNoti(context)
                if (isKeyguardLocked) {
                    startIntentNoti(context)
                } else {
                    startNormalNotification(context, "See call information")
                }
            }
        }
        handleCallEnded()
    }

    private fun handleCallRingingState(context: Context, intent: Intent) {
        if (callerCadCallNumber.isEmpty()) {
            callerCadCallNumber =
                intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: ""
        }

        if (!isWindowShowing && checkOverlayPermission(context)) {
            if (context.callerCadBaseConfig.switchUnknownCallerSaved) {
                displayWindowView(context, CallerCallState.STATE_RINGING)
                val calendar = Calendar.getInstance()
                callStartTime =
                    "${calendar.get(Calendar.HOUR_OF_DAY)}:${calendar.get(Calendar.MINUTE)}"
            }
        }
        handleIncomingCall()
    }

    private fun handleCallOffHookState(context: Context, intent: Intent) {
        if (callerCadCallNumber.isEmpty()) {
            callerCadCallNumber =
                intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: ""
        }

        if (context.callerCadBaseConfig.switchUnknownCallerSaved && !isWindowShowing && checkOverlayPermission(
                context
            )
        ) {
            displayWindowView(context, CallerCallState.STATE_OFFHOOK)
            if (callStartTime.isEmpty()) {
                val calendar = Calendar.getInstance()
                callStartTime =
                    "${calendar.get(Calendar.HOUR_OF_DAY)}:${calendar.get(Calendar.MINUTE)}"
                callStartedTime = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            }
            isWindowShowing = true
        }
        handleCallAnswered()
    }

    private fun handleCallEnded() {
        // Update callType based on conditions
        callType = if (callerCadCallNumber.isEmpty()) "No answer" else "Missed call"
    }

    private fun handleIncomingCall() {
        // Update callType
        callType = "Incoming call"
    }

    private fun handleCallAnswered() {
        // Update callType
        callType = "Call answered"
    }

    private fun checkOverlayPermission(context: Context): Boolean {
        return Settings.canDrawOverlays(context)
    }
}*/


