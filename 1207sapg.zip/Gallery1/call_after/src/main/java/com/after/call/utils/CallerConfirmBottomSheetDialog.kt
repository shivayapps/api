package com.after.call.utils

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import androidx.core.content.ContextCompat
import com.after.call.R
import com.after.call.databinding.CustomDialogLayoutCallerBinding

class CallerConfirmBottomSheetDialog(val activity: Activity) : Dialog(activity) {

    private lateinit var binding: CustomDialogLayoutCallerBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestWindowFeature(Window.FEATURE_NO_TITLE)

        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)

        setCancelable(false)
        setCanceledOnTouchOutside(false)

        binding = CustomDialogLayoutCallerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
    }
    fun show(
        title: String,
        description: String,
        positiveButtonText: String,
        negativeButtonText: String,
        positiveButtonClickListener: () -> Unit,
        negativeButtonClickListener: () -> Unit,
        theme: Boolean,
    ) {
        super.show()

        if (!this::binding.isInitialized) return

        binding.titleTextView.text = title
        binding.descriptionTextView.text = description
        binding.positiveButton.text = positiveButtonText
        binding.negativeButton.text = negativeButtonText

        if (theme) {
            binding.baseRoot.setBackgroundResource(R.drawable.after_call_rounded_darkdialog_background)
            binding.titleTextView.setTextColor(
                ContextCompat.getColor(context, R.color.after_call_text_color_white)
            )
            binding.descriptionTextView.setTextColor(
                ContextCompat.getColor(context, R.color.after_call_text_color_white)
            )
        } else {
            binding.baseRoot.setBackgroundResource(R.drawable.after_call_rounded_dialog_background)
            binding.titleTextView.setTextColor(
                ContextCompat.getColor(context, R.color.after_call_text_color_black)
            )
            binding.descriptionTextView.setTextColor(
                ContextCompat.getColor(context, R.color.after_call_text_color_black)
            )
        }

        binding.positiveButton.setOnClickListener(object : CallerOnSingleClickListener() {
            override fun onSingleClick(v: View?) {
                positiveButtonClickListener()
                dismiss()
            }
        })

        binding.negativeButton.setOnClickListener(object : CallerOnSingleClickListener() {
            override fun onSingleClick(v: View?) {
                negativeButtonClickListener()
                dismiss()
            }
        })
    }
}
