package com.after.call.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.after.call.R
import com.after.call.extensions.callerCadBaseConfig
import com.after.call.utils.AfterCallGridItem

class ThemeGridAdapter(
    cnxt: Context,
    private val items: List<AfterCallGridItem>,
    private val onClick: (AfterCallGridItem) -> Unit,
    private val onSelectPos: (Int) -> Unit,
) : RecyclerView.Adapter<ThemeGridAdapter.ViewHolder>() {

    private var selectedItemPosition: Int = cnxt.callerCadBaseConfig.callerCadSelectedTheme

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val itemAfterCallTheme: ImageView = view.findViewById(R.id.itemAfterCallTheme)
        val iconAfterCallThemeSelected: ImageView =
            view.findViewById(R.id.iconAfterCallThemeSelected)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_theme_grid, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(
        holder: ViewHolder,
        @SuppressLint("RecyclerView") position: Int,
    ) {
        val item = items[position]

        holder.itemAfterCallTheme.setImageResource(item.imageResId)

        if (position == selectedItemPosition) {
            holder.iconAfterCallThemeSelected.visibility = View.VISIBLE
        } else {
            holder.iconAfterCallThemeSelected.visibility = View.GONE
        }

        holder.itemView.setOnClickListener {
            selectedItemPosition = position
            notifyDataSetChanged()
            onClick(item)
            onSelectPos(position)
        }
    }

    override fun getItemCount(): Int = items.size
}