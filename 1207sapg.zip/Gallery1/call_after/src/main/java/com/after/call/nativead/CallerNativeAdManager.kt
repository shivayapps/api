package com.after.call.nativead

import android.annotation.SuppressLint
import android.content.Context
import com.after.call.adUtils.HIDE_NATIVE_AD
import com.after.call.adUtils.MessageEvent
import com.after.call.adUtils.SHOW_ADMOB_NATIVE_AD
import com.after.call.adUtils.SHOW_CUSTOM_NATIVE_AD
//import com.after.call.adUtils.SHOW_LOAD_URL_NATIVE_AD
//import com.after.call.adUtils.SHOW_SUGGEST_APPS_NATIVE_AD
import com.after.call.extensions.callerCadBaseConfig
import com.after.call.utils.CallerLogger
import com.google.android.gms.ads.nativead.NativeAd
import org.greenrobot.eventbus.EventBus


class CallerNativeAdManager(val context: Context) {


    companion object {
        var nativeAd: NativeAd? = null

        //        var oldLoaded: NativeAd? = null
        @SuppressLint("StaticFieldLeak")
        private var callerNativeAdManager: CallerNativeAdManager? = null
        fun getInstance(context: Context): CallerNativeAdManager {
            if (callerNativeAdManager == null) {
                callerNativeAdManager = CallerNativeAdManager(context)
            }
            return callerNativeAdManager!!
        }
    }

    var currentAdIndex = 0
    var isAdLoadedNative = false

    fun loadNativeAd() {
        CallerLogger.logE("loadNativeAd: Entry")
        if (!context.callerCadBaseConfig.callerCadAdEnable) {
            CallerLogger.logE("loadNativeAd: Native ads disabled by config")
            EventBus.getDefault().post(MessageEvent(HIDE_NATIVE_AD))
            return
        }

        CallerLogger.logE("loadNativeAd: Current Ad Index: $currentAdIndex")
        if (currentAdIndex < context.callerCadBaseConfig.callerCadNativeAdOrder.size) {
            val adType = context.callerCadBaseConfig.callerCadNativeAdOrder[currentAdIndex]
            CallerLogger.logE("loadNativeAd: Processing Ad Type: $adType")

            when (adType) {
                "admob" -> {
                    CallerLogger.logE("AdMob Native Ad Config Enabled: ${context.callerCadBaseConfig.callerCadAdmobNativeEnable}")
                    if (context.callerCadBaseConfig.callerCadAdmobNativeEnable) {
                        CallerLogger.logE("Attempting to load AdMob Native Ad")
                        CallerNativeAdRequest.loadNativeAfterCall(
                            context,
                            context.callerCadBaseConfig.callerCadAdmobAdIdNative
                        ) {
                            CallerLogger.logE("AdMob Native Ad Load Result: $it")
                            if (it != null) {
                                nativeAd = it
                                EventBus.getDefault()
                                    .post(MessageEvent(SHOW_ADMOB_NATIVE_AD, nativeAd))
                                CallerLogger.logE("AdMob Native Ad Loaded and Event Posted")
                            } else {
                                nativeAd = null
                                CallerLogger.logE("AdMob Native Ad Failed to Load. Moving to Next Ad Type.")
                                currentAdIndex++
                                loadNativeAd()
                            }
                        }
                    } else {
                        CallerLogger.logE("AdMob Native Ads Disabled. Skipping.")
                        currentAdIndex++
                        loadNativeAd()
                    }
                }

                "custom" -> {
                    CallerLogger.logE("Custom Native Ad Config Enabled: ${context.callerCadBaseConfig.callerCadCustomNativeEnable}")
                    if (context.callerCadBaseConfig.callerCadCustomNativeEnable) {

                        if (context.callerCadBaseConfig.callerCadCustomNativeValues.size > 0) {
                            if (context.callerCadBaseConfig.callerCadCustomNativeValues[0].appTitle.isNotEmpty()) {
                                EventBus.getDefault().post(MessageEvent(SHOW_CUSTOM_NATIVE_AD))
                                CallerLogger.logE("Custom Native Ad Event Posted")
                            } else {
                                CallerLogger.logE("Custom Native Values are Empty. Moving to Next Ad Type.")
                                currentAdIndex++
                                loadNativeAd()
                            }
                        } else {
                            CallerLogger.logE("Custom Native Values are Empty. Moving to Next Ad Type.")
                            currentAdIndex++
                            loadNativeAd()
                        }

                    } else {
                        CallerLogger.logE("Custom Native Ads Disabled. Skipping.")
                        currentAdIndex++
                        loadNativeAd()
                    }
                }

//                "url" -> {
////                    CallerLogger.logE("URL-Based Native Ad Config Enabled: ${context.callerCadBaseConfig.callerCadCustomPredesignNativeEnable}")
////                    if (context.callerCadBaseConfig.callerCadCustomPredesignNativeEnable) {
////                        if (context.callerCadBaseConfig.callerCadCustomPredesignNativeUrl.isNotEmpty()) {
////                            EventBus.getDefault().post(MessageEvent(SHOW_LOAD_URL_NATIVE_AD))
////                            CallerLogger.logE("URL-Based Native Ad Event Posted")
////                        } else {
////                            CallerLogger.logE("URL-Based Native Ad URL is Empty. Moving to Next Ad Type.")
////                            currentAdIndex++
////                            loadNativeAd()
////                        }
////                    } else {
//                        CallerLogger.logE("URL-Based Native Ads Disabled. Skipping.")
//                        currentAdIndex++
//                        loadNativeAd()
////                    }
//                }

//                "suggest" -> {
//                    CallerLogger.logE("Suggestion Native Ad Config Enabled: ${context.callerCadBaseConfig.callerCadCustomSuggestionNativeEnable}")
//                    if (context.callerCadBaseConfig.callerCadCustomSuggestionNativeEnable) {
//                        if (context.callerCadBaseConfig.callerCadCustomSuggestionAppsDetails.isNotEmpty()) {
//                            EventBus.getDefault().post(MessageEvent(SHOW_SUGGEST_APPS_NATIVE_AD))
//                            CallerLogger.logE("Suggestion Native Ad Event Posted")
//                        } else {
//                            CallerLogger.logE("Suggestion Native Ad Details are Empty. Moving to Next Ad Type.")
//                            currentAdIndex++
//                            loadNativeAd()
//                        }
//                    } else {
//                        CallerLogger.logE("Suggestion Native Ads Disabled. Skipping.")
//                        currentAdIndex++
//                        loadNativeAd()
//                    }
//                }

                else -> {
                    CallerLogger.logE("Unknown Ad Type: $adType. Skipping.")
                    currentAdIndex++
                    loadNativeAd()
                }
            }
        } else {
            CallerLogger.logE("No More Ad Types to Process. Hiding Native Ads.")
            EventBus.getDefault().post(MessageEvent(HIDE_NATIVE_AD))
        }
        CallerLogger.logE("loadNativeAd: Exit")
    }

    fun onDestroy() {
        nativeAd?.destroy()
        nativeAd = null
        isAdLoadedNative = false
        currentAdIndex = 0
    }

    fun isAdLoaded(): Boolean {
        return isAdLoadedNative
    }


}