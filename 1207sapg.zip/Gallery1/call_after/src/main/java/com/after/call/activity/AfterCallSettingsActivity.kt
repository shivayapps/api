package com.after.call.activity


//class AfterCallSettingsActivity : AfterCallBaseActivity() {
//
//    private lateinit var binding: ActivityCallCardSettingsCallerBinding
//    private var from: String = ""
//
//    private lateinit var permissionManager: AfterCallPermissionManager
//    override fun onCreate(savedInstanceState: Bundle?) {
//        setupWindow()
//        super.onCreate(savedInstanceState)
//        from = intent.getStringExtra("from").orEmpty()
//        binding = ActivityCallCardSettingsCallerBinding.inflate(layoutInflater)
//        setContentView(binding.root)
//
//        binding.backBtnAtTheme.setImageResource(application.callerCadBaseConfig.callerCadBackIcon)
//        initializeSwitchStates()
//        setupSwitchListeners()
//        setupClickListeners()
//        binding.customizeInsideView.isVisible = callerCadBaseConfig.customizeInsideViewEnable
//        binding.sdkversion.text = getString(R.string.sdk_version) + SDKVersion
//        checkAfterCallView(0)
//
//    }
//
//
//    override fun onResume() {
//        super.onResume()
//
//
//        updateContactPermissionState()
//        checkThemeSelected()
//
//        try {
//            callerCadBaseConfig.customizeSettingDefaultText.let { text ->
//                binding.tvCustomizeSettingDefault.text = text
//            }
//        } catch (e: Exception) {
//        }
//
//        val mainBGColor = ContextCompat.getColor(
//            this,
//            if (callerCadBaseConfig.callerCardDarkTheme) {
//                R.color.after_call_screen_bg_dark // Dark theme color
//            } else {
//                R.color.after_call_screen_bg_light // Light theme color
//            }
//        )
//        binding.main.setBackgroundColor(mainBGColor)
//
//
//        val backIconTintColor = ContextCompat.getColorStateList(
//            this, if (callerCadBaseConfig.callerCardDarkTheme) {
//                R.color.after_call_icon_color_dark // Dark theme color
//            } else {
//                R.color.after_call_icon_color_light // Light theme color
//            }
//        )
//
//
//        val tintColor = ContextCompat.getColor(
//            this,
//            if (callerCadBaseConfig.callerCardDarkTheme) {
//                R.color.after_call_card_bg_dark // Dark theme color
//            } else {
//                R.color.after_call_card_bg_light // Light theme color
//            }
//        )
//
//
//
//        binding.toolbar.setBackgroundColor(tintColor)
//        binding.backBtnAtTheme.imageTintList = backIconTintColor
//
//        ContextCompat.getDrawable(this, R.drawable.bg_caller_round_more_items)?.let { drawable ->
//            val mutableDrawable = drawable.mutate()
//            mutableDrawable.setTint(tintColor)
//            binding.itemOne.background = mutableDrawable
//            binding.itemTwo.background = mutableDrawable
//            binding.itemThree.background = mutableDrawable
//            binding.itemFour.background = mutableDrawable
//            binding.itemFive.background = mutableDrawable
//            binding.secCardSection.background = mutableDrawable
//            binding.callerCadTheme.background = mutableDrawable
//            binding.callerCadThemeMain.background = mutableDrawable
//            binding.customizeInsideView.background = mutableDrawable
//            binding.quickRepliesView.background = mutableDrawable
//        }
//
//        ContextCompat.getDrawable(this, R.drawable.custom_bordered_item_ripple)?.let { drawable ->
//            val mutableDrawable = drawable.mutate()
//            mutableDrawable.setTint(tintColor)
//        }
//
//
//        val drawable = ContextCompat.getDrawable(this, R.drawable.after_call_bordered_home_ripple)
//        val drawable1 = ContextCompat.getDrawable(this, R.drawable.after_call_bordered_home_ripple)
//        val drawable2 = ContextCompat.getDrawable(this, R.drawable.after_call_bordered_home_ripple)
//        val drawable3 = ContextCompat.getDrawable(this, R.drawable.after_call_bordered_home_ripple)
//        val drawable4 = ContextCompat.getDrawable(this, R.drawable.after_call_bordered_home_ripple)
//
//        drawable?.mutate()?.setTint(tintColor)
//        drawable1?.mutate()?.setTint(tintColor)
//        drawable2?.mutate()?.setTint(tintColor)
//        drawable3?.mutate()?.setTint(tintColor)
//        drawable4?.mutate()?.setTint(tintColor)
//
//        binding.callerCadTheme.background = drawable
//        binding.callerCadThemeMain.background = drawable1
//        binding.customizeInsideView.background = drawable2
//        binding.quickRepliesView.background = drawable3
//        binding.backBtnAtTheme.background = drawable4
//
//
//        val tintColorStateList = ContextCompat.getColorStateList(
//            this, if (callerCadBaseConfig.callerCardDarkTheme) {
//                R.color.after_call_white_all // Dark theme color
//            } else {
//                R.color.after_call_selectedColor // Light theme color
//            }
//        )
//        binding.callercadIconDarkMode.imageTintList = tintColorStateList
//        binding.callercadIconTheme.imageTintList = tintColorStateList
//        binding.callercadIconCustomize.imageTintList = tintColorStateList
//        binding.callercadIconNotificationReminder.imageTintList = tintColorStateList
//        binding.callerCadIconExtraContact.imageTintList = tintColorStateList
//        binding.callercadIconAbout.imageTintList = tintColorStateList
//        binding.callercadIconSdkversion.imageTintList = tintColorStateList
//        binding.callercadIconQuickReplies.imageTintList = tintColorStateList
//        binding.callercadIconMissCall.imageTintList = tintColorStateList
//        binding.callerCadIconNoAnswer.imageTintList = tintColorStateList
//        binding.callerCadIconUnknownCaller.imageTintList = tintColorStateList
//        binding.callerCadIconCompletedCall.imageTintList = tintColorStateList
//
//
//// Title Text color change
//        val textTitles = listOf(
//            binding.titleOne,
//            binding.titleTwo,
//            binding.titleThree,
//            binding.txtTitleCaller,
//            binding.tvCallerEnable,
//            binding.tvExtra,
//            binding.tvAbout
//        )
//
//        textTitles.forEach { textView ->
//            textView.setTextColor(tintColorStateList) // Correct method to set ColorStateList
//        }
//
//
//// Text color change
//        val textColorList = ContextCompat.getColorStateList(
//            this, if (callerCadBaseConfig.callerCardDarkTheme) {
//                R.color.after_call_text_color_white // Dark theme color
//            } else {
//                R.color.after_call_text_color_black // Light theme color
//            }
//        )
//        val textViews = listOf(
//            binding.mTitleAtTheme,
//            binding.tvDarkmode,
//            binding.tvTheme,
//            binding.tvCustomize,
//            binding.switchNotificationReminder,
//            binding.tvQuickReplies,
//            binding.switchCallerEnable,
//            binding.tvMissedCall,
//            binding.tvCompletedCall,
//            binding.tvNoAnswer,
//            binding.tvUnknownCaller,
//            binding.switchExtraContact,
//            binding.licenses,
//            binding.sdkversion
//        )
//
//        textViews.forEach { textView ->
//            textView.setTextColor(textColorList)
//        }
//        checkAndShowAutoPermissionView(this, binding.setAutoStartPermissionView, false)
//    }
//
//    private fun setupWindow() {
//        window.apply {
//            addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
//            statusBarColor = ContextCompat.getColor(
//                this@AfterCallSettingsActivity,
//                R.color.after_call_card_bg
//            )
//            decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
//        }
//    }
//
//    private fun initializeSwitchStates() {
//        binding.apply {
//            switchMissedCall.isChecked = callerCadBaseConfig.switchMissedCallSaved
//            switchCompletedCall.isChecked = callerCadBaseConfig.switchCompletedCallSaved
//            switchNoAnswer.isChecked = callerCadBaseConfig.switchNoAnswerSaved
//            switchUnknownCaller.isChecked = callerCadBaseConfig.switchUnknownCallerSaved
//            switchNotificationReminder.isChecked = callerCadBaseConfig.switchReminderSaved
//        }
//
//
//    }
//
//    private fun setupSwitchListeners() {
//        binding.switchCallerEnable.setOnCheckedChangeListener { _, isChecked ->
//            toggleCallerEnable(
//                isChecked
//            )
//        }
//        setupIndividualSwitchListeners()
//    }
//
//    override fun onBackPressed() {
//        super.onBackPressed()
//        finish()
//    }
//
//    private fun setupClickListeners() {
//        binding.apply {
//            callerCadTheme.setOnClickListener { showBottomSheetDialog() }
//            quickRepliesView.setOnClickListener {
//                startActivity(
//                    Intent(
//                        this@AfterCallSettingsActivity,
//                        EditQuickMessagesActivity::class.java
//                    )
//                )
//            }
//            backBtnAtTheme.setOnClickListener {
//                onBackPressed()
//            }
////            callerCadThemeMain.setOnClickListener {
////                startActivity(
////                    Intent(
////                        this@AfterCallSettingsActivity,
////                        AfterCallThemeActivity::class.java
////                    ).apply {
////                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
////                    })
////            }
//            licenses.setOnClickListener { showLicenseDialog() }
//        }
//
//        binding.customizeInsideView.setOnClickListener {
//
//
//            val nextActivityClass = getAfterCallCustomSettingClickActivity(this)
//
//            nextActivityClass?.let { activityClass ->
//                val intent = Intent(this, activityClass)
//                startActivity(intent)
//            } ?: run {
//                // Handle the case where the class is null
//                //  Toast.makeText(this, "Activity class not found!", Toast.LENGTH_SHORT).show()
//            }
//
//
//        }
//    }
//
//    private fun setupIndividualSwitchListeners() {
//        val switchMap = mapOf(
//            binding.switchMissedCall to { callerCadBaseConfig::switchMissedCallSaved },
//            binding.switchCompletedCall to { callerCadBaseConfig::switchCompletedCallSaved },
//            binding.switchNoAnswer to { callerCadBaseConfig::switchNoAnswerSaved },
//            binding.switchUnknownCaller to { callerCadBaseConfig::switchUnknownCallerSaved }
//        )
//        switchMap.forEach { (switch, configPropertyGetter) ->
//            val configProperty = configPropertyGetter()
//            switch.setOnClickListener {
//                if (!switch.isChecked) {
//                    showConfirmationDialog(
//                        title = switch.text.toString(),
//                        onPositive = {
//                            configProperty.set(false)
//                            switch.isChecked = false
//                            checkAfterCallView()
//                        },
//                        onNegative = {
//                            configProperty.set(true)
//                            switch.isChecked = true
//                        }
//                    )
//                } else {
//                    configProperty.set(true)
//                }
//            }
//        }
//
//        // binding.switchExtraContact.setOnClickListener { handleExtraContactSwitch() }
//
//        // Refactored logic for switchExtraContact
//        binding.switchExtraContact.setOnCheckedChangeListener { _, isChecked ->
//            if (isChecked) {
//                // Check permission before enabling
//                TedPermission.create()
//                    .setPermissionListener(object : PermissionListener {
//                        override fun onPermissionGranted() {
//                            callerCadBaseConfig.switchExtraContactSaved = true
//                            binding.switchExtraContact.isChecked = true
//                            binding.contactPermission.visibility = View.GONE
//                        }
//
//                        override fun onPermissionDenied(deniedPermissions: List<String>) {
//                            callerCadBaseConfig.switchExtraContactSaved = false
//                            binding.switchExtraContact.isChecked = false
//                            binding.contactPermission.visibility = View.VISIBLE
//                        }
//                    })
//                    .setDeniedMessage(getString(R.string.permission_denied_message))
//                    .setPermissions(
//                        Manifest.permission.READ_CONTACTS,
//                        Manifest.permission.READ_CALL_LOG
//                    )
//                    .check()
//            } else {
//                // When the switch is turned off, update the config
//                callerCadBaseConfig.switchExtraContactSaved = false
//                binding.contactPermission.visibility = View.VISIBLE
//            }
//        }
//
//        binding.switchNotificationReminder.setOnClickListener {
//            callerCadBaseConfig.switchReminderSaved = binding.switchNotificationReminder.isChecked
//        }
//    }
//
//    private fun toggleCallerEnable(isChecked: Boolean) {
//        binding.apply {
//            val visibility = if (isChecked) View.VISIBLE else View.GONE
//            mainMissedCall.visibility = visibility
//            mainCompletedCall.visibility = visibility
//            mainNoAnswer.visibility = visibility
//            mainUnknownCaller.visibility = visibility
//            txtTitleCaller.visibility = visibility
//            mainCadEnable.visibility = if (isChecked) View.GONE else View.VISIBLE
//
//            switchMissedCall.isChecked = isChecked
//            switchCompletedCall.isChecked = isChecked
//            switchNoAnswer.isChecked = isChecked
//            switchUnknownCaller.isChecked = isChecked
//            switchNotificationReminder.isChecked = isChecked
//
//            callerCadBaseConfig.apply {
//                switchMissedCallSaved = isChecked
//                switchCompletedCallSaved = isChecked
//                switchNoAnswerSaved = isChecked
//                switchUnknownCallerSaved = isChecked
//                switchReminderSaved = isChecked
//            }
//
////            switchNotificationReminder.visibility = visibility
//            secCardSection.visibility =
//                if (callerCadBaseConfig.contactpermission) View.VISIBLE else View.GONE
//            secCardSection.visibility = View.GONE
//            tvExtra.visibility = visibility
//        }
//    }
//
//    private fun updateContactPermissionState() {
//        val hasPermission = ContextCompat.checkSelfPermission(
//            this,
//            Manifest.permission.READ_CONTACTS
//        ) == PackageManager.PERMISSION_GRANTED
//        binding.apply {
//            switchExtraContact.isChecked =
//                hasPermission && callerCadBaseConfig.switchExtraContactSaved
//            contactPermission.visibility = if (hasPermission) View.GONE else View.VISIBLE
//        }
//        if (!callerCadBaseConfig.contactpermission) {
//            binding.secCardSection.visibility = View.GONE
//        }
//    }
//
//    private fun checkThemeSelected() {
//        val themeResource = when (callerCadBaseConfig.callerCadSelectedTheme) {
//            0 -> R.drawable.ic_after_call_theme_style1
//            1 -> R.drawable.ic_after_call_theme_style2
//            2 -> R.drawable.ic_after_call_theme_style3
//            3 -> R.drawable.ic_after_call_theme_style4
//            4 -> R.drawable.ic_after_call_theme_style5
//            5 -> R.drawable.ic_after_call_theme_style6
//            6 -> R.drawable.ic_after_call_theme_style7
//            7 -> R.drawable.ic_after_call_theme_style8
//            else -> R.drawable.ic_after_call_theme_style1
//        }
//        binding.insideTheme.setImageResource(themeResource)
//    }
//
//    private fun showBottomSheetDialog() {
//        val dialog = AfterCallDarkThemeDialog(this).apply {
//            setOnDismissListener {
//                // Uncomment this block if dynamic night mode behavior is needed
//                /*
//                AppCompatDelegate.setDefaultNightMode(
//                    if (callerCadBaseConfig.callerCardDarkTheme) {
//                        AppCompatDelegate.MODE_NIGHT_YES
//                    } else {
//                        AppCompatDelegate.MODE_NIGHT_NO
//                    }
//                )
//                */
//
//                onResume()
//            }
//        }
//        dialog.show()
//    }
//
//    private fun showLicenseDialog() {
//        val licenseBinding = DialogLicenseCallerBinding.inflate(layoutInflater)
//        licenseBinding.textLicense.apply {
//            text = getString(R.string.after_call_licence_view)
//            setTextColor(
//                if (callerCadBaseConfig.callerCardDarkTheme) {
//                    ContextCompat.getColor(
//                        this@AfterCallSettingsActivity,
//                        R.color.after_call_text_color_white
//                    )
//                } else {
//                    ContextCompat.getColor(
//                        this@AfterCallSettingsActivity,
//                        R.color.after_call_text_color_black
//                    )
//                }
//            )
//        }
//
//        licenseBinding.dialogTitle.setTextColor(
//            ContextCompat.getColor(
//                this,
//                if (callerCadBaseConfig.callerCardDarkTheme) R.color.after_call_text_color_white
//                else R.color.after_call_text_color_black
//            )
//        )
//
//        AlertDialog.Builder(this).apply {
//            setView(licenseBinding.root)
////            setTitle(getString(R.string.open_source_licenses))
//            setPositiveButton(getString(R.string.close)) { dialog, _ -> dialog.dismiss() }
//            create().apply {
//
//                if (callerCadBaseConfig.callerCardDarkTheme) {
//                    window?.setBackgroundDrawable(resources.getDrawable(R.drawable.after_call_rounded_darkdialog_background))
//                    licenseBinding.baseScroll.setBackgroundColor(resources.getColor(R.color.after_call_card_bg_dark))
//                    licenseBinding.textLicense.setBackgroundColor(resources.getColor(R.color.after_call_card_bg_dark))
//                } else {
//                    window?.setBackgroundDrawable(resources.getDrawable(R.drawable.after_call_rounded_dialog_background))
//                    licenseBinding.baseScroll.setBackgroundColor(resources.getColor(R.color.after_call_screen_bg_light))
//                    licenseBinding.textLicense.setBackgroundColor(resources.getColor(R.color.after_call_screen_bg_light))
//                }
//
//                show()
//            }
//        }
//    }
//
//    private fun showConfirmationDialog(
//        title: String,
//        onPositive: () -> Unit,
//        onNegative: () -> Unit,
//    ) {
//
//        CallerConfirmBottomSheetDialog(this).show(
//            title = title,
//            description = resources.getString(R.string.after_call_disableDescription),
//            positiveButtonText = getString(R.string.proceed),
//            negativeButtonText = getString(R.string.keep_it),
//            positiveButtonClickListener = {
//                onPositive()
//            },
//            negativeButtonClickListener = {
//                onNegative()
//            }, callerCadBaseConfig.callerCardDarkTheme
//        )
//    }
//
//    fun checkAfterCallView(intt: Int = 1) {
//        if (!callerCadBaseConfig.run { switchMissedCallSaved || switchCompletedCallSaved || switchNoAnswerSaved || switchUnknownCallerSaved }) {
//            binding.apply {
//                mainMissedCall.visibility = View.GONE
//                mainCompletedCall.visibility = View.GONE
//                mainNoAnswer.visibility = View.GONE
//                mainUnknownCaller.visibility = View.GONE
//                txtTitleCaller.visibility = View.GONE
//                mainCadEnable.visibility = View.VISIBLE
//                switchCallerEnable.isChecked = false
////                switchNotificationReminder.visibility = View.GONE
//                mainExtraContact.visibility = View.GONE
//                secCardSection.visibility = View.GONE
//                tvExtra.visibility = View.GONE
//            }
//            callerCadBaseConfig.apply {
//                switchMissedCallSaved = false
//                switchCompletedCallSaved = false
//                switchNoAnswerSaved = false
//                switchUnknownCallerSaved = false
//            }
//            if (intt == 1) AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_SETTING_DISABLED)
//        }
//    }
//
//    private fun handleExtraContactSwitch() {
//        if (!binding.switchExtraContact.isChecked) {
//            TedPermission.create()
//                .setPermissionListener(object : PermissionListener {
//                    override fun onPermissionGranted() {
//                        callerCadBaseConfig.switchExtraContactSaved = true
//                        binding.switchExtraContact.isChecked = true
//                        binding.contactPermission.visibility = View.GONE
//                    }
//
//                    override fun onPermissionDenied(deniedPermissions: List<String>) {
//                        callerCadBaseConfig.switchExtraContactSaved = false
//                        binding.switchExtraContact.isChecked = false
//                        binding.contactPermission.visibility = View.VISIBLE
//                    }
//                })
//                .setDeniedMessage(getString(R.string.permission_denied_message))
//                .setPermissions(
//                    Manifest.permission.READ_CONTACTS,
//                    Manifest.permission.READ_CALL_LOG
//                )
//                .check()
//        }
//    }
//}
