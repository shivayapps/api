package com.after.call.adUtils

data class MessageEvent(val type: String, val data: Any? = null)

const val SHOW_ADMOB_NATIVE_AD = "show_admob_native_ad"
const val SHOW_CUSTOM_NATIVE_AD = "show_custom_native_ad"
//const val SHOW_LOAD_URL_NATIVE_AD = "show_load_url_native_ad"
//const val SHOW_SUGGEST_APPS_NATIVE_AD = "show_suggest_apps_native_ad"
const val HIDE_NATIVE_AD = "hide_native_ad"


const val SHOW_BANNER_AD = "show_banner_ad"
const val HIDE_BANNER_AD = "hide_banner_ad"
const val NO_ADS_VIEW = "no_ads_view"

const val SHOW_SMALL_NATIVE_BANNER_AD = "show_small_native_banner_ad"

//const val SHOW_URL_BANNER_AD = "show_url_banner_ad"
const val CALLER_CARD_THEME_UPDATE = "caller_card_theme_update"

