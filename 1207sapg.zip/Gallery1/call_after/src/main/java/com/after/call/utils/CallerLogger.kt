package com.after.call.utils

import android.annotation.SuppressLint
import android.util.Log

@SuppressLint("StaticFieldLeak")
object CallerLogger {
    val isLogEnable = true

    var callerCardopen = false

    fun logE(log: String) {
        if (isLogEnable)
            Log.e("AfterCall", log)
    }
}