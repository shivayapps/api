package com.after.call.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.after.call.R
import com.after.call.extensions.callerCadBaseConfig

class CustomDialogAdapter(
    private val items: List<String>,
    private val itemClickListener: (String, Int) -> Unit,
) : RecyclerView.Adapter<CustomDialogAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val quickMessage: TextView = itemView.findViewById(R.id.quickMessage)
        val icIconLoad: ImageView = itemView.findViewById(R.id.icIconLoad)
        val mainItemQuickReply: LinearLayout = itemView.findViewById(R.id.mainItemQuickReply)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.after_call__quick_reply_item_dialog, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.quickMessage.text = item
        holder.itemView.setOnClickListener {
            itemClickListener(item, position)
        }

        when (position) {
            items.size - 2 -> {
                // Second to last item
                holder.icIconLoad.setImageResource(R.drawable.icons_chat_quick_item_text) // Replace with your icon resource
            }

            items.size - 1 -> {
                // Last item
                holder.icIconLoad.setImageResource(R.drawable.ic_after_call_quick_settings) // Replace with your icon resource
            }

            else -> {
                // Other items
                holder.icIconLoad.setImageResource(R.drawable.icons_chat_dots) // Replace with your icon resource
            }
        }

        // Determine the tint color based on the theme
        val tintColor = ContextCompat.getColor(
            holder.mainItemQuickReply.context,
            if (holder.mainItemQuickReply.context.callerCadBaseConfig.callerCardDarkTheme) {
                R.color.after_call_dialogHomeBgDark // Dark theme color
            } else {
                R.color.after_call_dialogHomeBgLight // Light theme color
            }
        )
        val textColor = ContextCompat.getColor(
            holder.mainItemQuickReply.context,
            if (holder.mainItemQuickReply.context.callerCadBaseConfig.callerCardDarkTheme) {
                R.color.after_call_dialogHomeBgLight // Dark theme color
            } else {
                R.color.after_call_dialogHomeBgDark // Light theme color
            }
        )

        val tintColorStateList = ContextCompat.getColorStateList(
            holder.mainItemQuickReply.context,
            if (holder.mainItemQuickReply.context.callerCadBaseConfig.callerCardDarkTheme) {
                R.color.after_call_white_all // Dark theme color
            } else {
                R.color.after_call_dialogHomeBgDark // Light theme color
            }
        )

        ContextCompat.getDrawable(
            holder.mainItemQuickReply.context,
            R.drawable.after_call_bordered_home_ripple
        )?.let { drawable ->
            val mutableDrawable = drawable.mutate() // Ensure the drawable is mutable
            mutableDrawable.setTint(tintColor) // Apply the tint color
            holder.mainItemQuickReply.background = mutableDrawable // Set as background
            holder.quickMessage.setTextColor(textColor)
            holder.icIconLoad.imageTintList = tintColorStateList

        }
    }

    override fun getItemCount(): Int = items.size
}
