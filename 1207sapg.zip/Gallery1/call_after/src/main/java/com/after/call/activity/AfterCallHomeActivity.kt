package com.after.call.activity

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.ContactsContract
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.Keep
import androidx.appcompat.content.res.AppCompatResources
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.bumptech.glide.Glide
import com.after.call.AfterCallUtils
import com.after.call.R
import com.after.call.adUtils.AdLoadingService
import com.after.call.adUtils.HIDE_BANNER_AD
import com.after.call.adUtils.HIDE_NATIVE_AD
import com.after.call.adUtils.MessageEvent
import com.after.call.adUtils.NO_ADS_VIEW
import com.after.call.adUtils.SHOW_ADMOB_NATIVE_AD
import com.after.call.adUtils.SHOW_BANNER_AD
import com.after.call.adUtils.SHOW_CUSTOM_NATIVE_AD
//import com.after.call.adUtils.SHOW_LOAD_URL_NATIVE_AD
import com.after.call.adUtils.SHOW_SMALL_NATIVE_BANNER_AD
//import com.after.call.adUtils.SHOW_SUGGEST_APPS_NATIVE_AD
//import com.after.call.adUtils.SHOW_URL_BANNER_AD
import com.after.call.adUtils.ServiceAction
import com.after.call.bannerad.CallerBannerAdManager
import com.after.call.bottom_dialog.QuickMessageCustomDialog
import com.after.call.databinding.ActivityAfterCallCallerBinding
import com.after.call.extensions.callerCadBaseConfig
import com.after.call.extensions.createBitmapFromText
import com.after.call.extensions.getUserPhotoByPhoneNumber
import com.after.call.extensions.isInternetConnected
import com.after.call.extensions.openURLLaunch
//import com.after.call.extensions.themeCallerResources
import com.after.call.helpers.fixItemsForQuickItems
import com.after.call.nativead.CallerNativeAdManager
import com.after.call.nativead.CallerNativeAdRequest.prepareAdView
import com.after.call.nativead.CallerNativeAdRequest.prepareCustomNativeView
import com.after.call.utils.AfterCallExpandableLayout
import com.after.call.utils.AppCategoriesIcon
import com.after.call.utils.AfterCallOverlay
import com.after.call.utils.AfterCallOverlay.callerCadCallNumber
import com.after.call.utils.AfterCallOverlay.callerCadCallType
import com.after.call.utils.AfterCallOverlay.hasContactPermission
import com.after.call.utils.AfterCallOverlay.retrieveNameFromDevice
import com.after.call.utils.CallerEventsConstants
import com.after.call.utils.CallerEventsConstants.CAD_CREATED
import com.after.call.utils.CallerLogger
import com.after.call.utils.CallerLogger.callerCardopen
import com.after.call.utils.CallerOnSingleClickListener
import com.after.call.utils.CustomNativeValue
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.nativead.NativeAd
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode


class AfterCallHomeActivity : AfterCallBaseActivity() {
    val TAG = "AdLoadingService"
    private val adLoadingServiceIntent by lazy {
        Intent(this, AdLoadingService::class.java)
    }

    companion object {
        var isActivityOpen: Boolean = false
        private var instance: AfterCallHomeActivity? = null

        fun finishActivity() {
            instance?.finishAffinity()
        }
    }

    private var bannerAdLoaded = false
    private var nativeAdLoaded = false

    private var quickMessageCustomDialog: QuickMessageCustomDialog? = null
    private var savedName: String? = ""
    private var serviceBind = false
    private var adLoadingService: AdLoadingService? = null
    private val boundServiceConnection by lazy {
        object : ServiceConnection {
            override fun onServiceConnected(className: ComponentName, service: IBinder) {
                val binder: AdLoadingService.MyBinder = service as AdLoadingService.MyBinder
                adLoadingService = binder.getService()
                serviceBind = true
                Log.e(TAG, "onServiceConnected: ")
            }

            override fun onServiceDisconnected(arg0: ComponentName) {
                adLoadingService?.runAction(ServiceAction.STOP_ACTION)
                Log.e(TAG, "onServiceDisconnected: ")
            }
        }
    }
    private lateinit var binding: ActivityAfterCallCallerBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAfterCallCallerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        isActivityOpen = true

        instance = this
        bindToADLoadingService()

        setupWindowInsets()
        setupUI()
        loadInitialData()
        setUpToolbar()
        setupListeners()
        setupNoAds()

        Handler(Looper.getMainLooper()).postDelayed({
            expandMainViews()
        }, 300)

        try {
            val notificationManager = NotificationManagerCompat.from(this)
            notificationManager.cancel(298)
        } catch (_: Exception) {
        }
        /* if (AfterCallUtils.mAfterCallContainerFragment == null) {
             binding.sale2Contain.visibility = View.GONE
         }*/
    }

    override fun onStart() {
        super.onStart()
//        bindToADLoadingService()
    }

    override fun onStop() {
        super.onStop()

//        unbindAudioService()
    }

    /*  override fun onTrimMemory(level: Int) {
          super.onTrimMemory(level)
          if (level >= ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN) {

              finishAffinity()
          }
      }*/

    override fun onBackPressed() {
        super.onBackPressed()
        finishAffinity()
    }


    override fun onDestroy() {
        super.onDestroy()
        AfterCallUtils.mAfterCallContainerFragment = null
        isActivityOpen = false
        instance = null
        if (EventBus.getDefault().isRegistered(this)) EventBus.getDefault().unregister(this)
        callerCardopen = false
        savedName = ""
        callerCadCallNumber = ""
        CallerBannerAdManager.getInstance(this).onDestroy()
        unbindAudioService()
    }

    private fun setupUI() {
        if (!EventBus.getDefault().isRegistered(this)) EventBus.getDefault().register(this)
        if (AfterCallUtils.mAfterCallContainerFragment != null) {
            if (AfterCallUtils.mAfterCallContainerFragment!!.parent != null) {
                (AfterCallUtils.mAfterCallContainerFragment!!.parent as ViewGroup).removeView(
                    AfterCallUtils.mAfterCallContainerFragment
                )
            }
            binding.sale2Contain.removeAllViews()
            binding.sale2Contain.addView(AfterCallUtils.mAfterCallContainerFragment)
        }


//        val appIcon = AppCategoriesIcon.appOpenIconFromPosition(this)
//        appIcon?.let {
//            binding.callerAppOpenIcon.setImageResource(it.imageResId)
//        }
    }

    private fun loadInitialData() {
        try {
            AfterCallUtils.mAfterCallContainerFragment?.prepareData(this)
        } catch (e: Exception) {
            Log.d("AfterCallReceiver", "addView Exception : ${e.message}")
        }
        AfterCallUtils.AfterCallEvent(CAD_CREATED)
    }

    private fun setupNoAds() {
        if (!callerCadBaseConfig.callerCadAdEnable || !isInternetConnected()) {
            setNoAdsView()
            setNoBannerAdsView()
        }
    }

    private fun setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { view, insets ->
            val systemBarsInsets = insets.getInsets(WindowInsetsCompat.Type.systemBars())
//            if (insets.isVisible(WindowInsetsCompat.Type.navigationBars())) {
                binding.main.setPadding(0, systemBarsInsets.top, 0, systemBarsInsets.bottom)
//            } else {
//                view.setPadding(0, 0, 0, 0)
//            }
            insets
        }
    }

    private fun setupListeners() {
        binding.icClose.setOnClickListener(object : CallerOnSingleClickListener() {
            override fun onSingleClick(v: View?) {
                AfterCallUtils.mAfterCallContainerFragment = null
                finish()
            }
        })
//        binding.callerAppOpen.setOnClickListener(object : CallerOnSingleClickListener() {
//            override fun onSingleClick(v: View?) {
//                startLauncherScreenFromAfterCall()
//            }
//        })
//
//        binding.callerSetting.setOnClickListener(object : CallerOnSingleClickListener() {
//            override fun onSingleClick(v: View?) {
//               val mIntent =
//                    Intent(this@AfterCallHomeActivity, AfterCallSettingsActivity::class.java)
//                mIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
//                startActivity(mIntent)
//            }
//        })
        binding.contactButton.setOnClickListener(object : CallerOnSingleClickListener() {
            override fun onSingleClick(v: View?) {
                if (callerCadCallNumber?.isNotEmpty() == true || !callerCadCallNumber.equals(
                        resources.getString(
                            R.string.after_call_private_number
                        )
                    )
                ) {
                    try {
                        val intent = Intent(Intent.ACTION_DIAL)
                        intent.setData(Uri.parse("tel:$callerCadCallNumber"))
                        startActivity(intent)
                    } catch (_: Exception) {
                    }
                } else {
                    try {
                        val intent = Intent(Intent.ACTION_DIAL)
                        intent.setData(Uri.parse("tel:"))
                        startActivity(intent)
                    } catch (_: Exception) {
                    }
                }
                finish()
            }

        })
        try {
            if (AfterCallUtils.getLogoFromSharedPreferences(this@AfterCallHomeActivity) == null) {
                binding?.icAppIcon?.visibility = View.GONE
            } else {
                binding?.icAppIcon?.setImageDrawable(
                    AfterCallUtils.getLogoFromSharedPreferences(
                        this@AfterCallHomeActivity
                    )
                )
                binding?.icAppIcon?.visibility = View.VISIBLE
            }

        } catch (e: Exception) {
            binding?.icAppIcon?.visibility = View.GONE
        }


        binding.icAppIcon.setOnClickListener(object : CallerOnSingleClickListener() {
            override fun onSingleClick(v: View?) {
                startLauncherScreenFromAfterCall()
            }

        })
        binding.mailButton.setOnClickListener(object : CallerOnSingleClickListener() {
            override fun onSingleClick(v: View?) {
                val context = v?.context
                if (context != null) {
//                    if (callerCadCallNumber?.isNotBlank() == true) {
//                        try {
//                            val cursor = context.contentResolver.query(
//                                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
//                                arrayOf(ContactsContract.CommonDataKinds.Phone.CONTACT_ID),
//                                "${ContactsContract.CommonDataKinds.Phone.NUMBER} = ?",
//                                arrayOf(callerCadCallNumber),
//                                null
//                            )
//                            if (cursor != null && cursor.moveToFirst()) {
//                                val contactId = cursor.getLong(
//                                    cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
//                                )
//                                val contactUri = Uri.withAppendedPath(
//                                    ContactsContract.Contacts.CONTENT_URI,
//                                    contactId.toString()
//                                )
//                                cursor.close()
//
//                                // Open contact details
//                                val intent = Intent(Intent.ACTION_VIEW).apply {
//                                    data = contactUri
//                                }
//                                context.startActivity(intent)
//                            } else {
//                                // No contact found, show create contact screen
//                                val intent = Intent(
//                                    ContactsContract.Intents.SHOW_OR_CREATE_CONTACT,
//                                    Uri.parse("tel:$callerCadCallNumber")
//                                ).apply {
//                                    putExtra(ContactsContract.Intents.EXTRA_FORCE_CREATE, true)
//                                }
//                                context.startActivity(intent)
//                            }
//                        } catch (e: Exception) {
//                            e.printStackTrace()
//                            Toast.makeText(
//                                context,
//                                "Unable to open the contact screen.",
//                                Toast.LENGTH_SHORT
//                            ).show()
//                        }
//                    } else {
                    try {
                        val intent = Intent(Intent.ACTION_SENDTO).apply {
                            data = Uri.parse("mailto:")
                        }
                        startActivity(intent)
                    } catch (e: Exception) {
                        e.printStackTrace()
                        Toast.makeText(
                            context,
                            "Unable to open the create contact screen.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
//                    }
                }
            }
        })


        binding.newMessageButton.setOnClickListener(object : CallerOnSingleClickListener() {
            override fun onSingleClick(v: View?) {
                quickMessageCustomDialog = QuickMessageCustomDialog(
                    this@AfterCallHomeActivity,
                    onDialogShow = {
                        binding.adsCardLayout.visibility = View.GONE
                        binding.adsTopLayout.visibility = View.GONE
                    },
                    onDialogDismiss = {
                        binding.adsCardLayout.visibility =
                            if (nativeAdLoaded) View.VISIBLE else binding.adsCardLayout.visibility
                        binding.adsTopLayout.visibility =
                            if (bannerAdLoaded) View.VISIBLE else binding.adsTopLayout.visibility
                    }
                )
                quickMessageCustomDialog?.show { selectedItem, position ->
                    val listSize =
                        callerCadBaseConfig.callerCadQuickMessagesList.size + fixItemsForQuickItems.size

                    when (position) {
                        listSize - 1 -> {
                            startActivity(
                                Intent(
                                    this@AfterCallHomeActivity,
                                    EditQuickMessagesActivity::class.java
                                )
                            )
                        }

                        listSize - 2 -> {
                            sendSms("", selectedItem)
                        }

                        else -> {
                            sendSms(callerCadCallNumber, selectedItem)
                        }
                    }
                }
            }
        })


    }

    fun sendSms(callerCadCallNumber: String?, selectedItem: String) {
        var formattedCallNumber = callerCadCallNumber

        // Check if the call number is empty or equals a specific string and reset if true
        if (formattedCallNumber?.isEmpty() == true || formattedCallNumber == resources.getString(R.string.after_call_private_number)) {
            formattedCallNumber = ""
        }

        try {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("smsto:$formattedCallNumber")
                putExtra("sms_body", selectedItem)
            }
            // Start the activity and finish the current one
            startActivity(intent)
            finish()
        } catch (e: Exception) {
            // Handle the error if the messaging app cannot be opened
            Toast.makeText(
                this@AfterCallHomeActivity,
                "Unable to open messaging app",
                Toast.LENGTH_SHORT
            ).show()
        }
    }


    private fun startLauncherScreenFromAfterCall() {
        try {
            val pm = packageManager
            val intent = pm.getLaunchIntentForPackage(application.packageName)
            intent?.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            intent?.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK
            intent?.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
            finish()
        } catch (e: Exception) {
            Log.e("Exception", "" + e.message)
        }
    }

    private fun setAfterCallTheme() {

//        val drawable = ContextCompat.getDrawable(this, R.drawable.bg_caller_round_button_ripple)
//        val drawable1 = ContextCompat.getDrawable(this, R.drawable.bg_caller_round_button_ripple)
//        val newColor = ContextCompat.getColor(
//            this,
//            callerCadThemeList[callerCadBaseConfig.callerCadSelectedTheme].btnColor
//        )
//        drawable?.mutate()?.setTint(newColor)
//        drawable1?.mutate()?.setTint(newColor)
//        binding.callerAppOpen.background = drawable
//        binding.callerSetting.background = drawable1


        if (AfterCallUtils.mAfterCallContainerFragment == null) {

//            binding.sale2Contain.removeAllViews()

            // Inflate and set the no_view_default_view
            val noViewDefaultView = LayoutInflater.from(binding.root.context)
                .inflate(R.layout.no_view_default_view, binding.sale2Contain, false)
            noViewDefaultView.findViewById<ImageView>(R.id.appIcon)
                .setImageDrawable(getDefaultAppIcon(this))
            noViewDefaultView.findViewById<TextView>(R.id.appTitle).text = getAppName(this)

            val appDescription = AppCategoriesIcon.getDefaultDescriptionFromPosition(this)
            noViewDefaultView.findViewById<TextView>(R.id.appDescription).text = appDescription

            val backgroundDrawable =
                ContextCompat.getDrawable(this, R.drawable.ic_after_call_send_round_bg)
            val colorArray = resources.obtainTypedArray(R.array.caller_cad_theme_colors)
            val selectedColor = colorArray.getColor(
                callerCadBaseConfig.callerCadSelectedTheme,
                ContextCompat.getColor(this, R.color.after_call_selectedColor)
            )
            backgroundDrawable?.setTint(selectedColor)
            noViewDefaultView.findViewById<TextView>(R.id.viewMoreButton).background =
                backgroundDrawable
            noViewDefaultView.setOnClickListener {
                startLauncherScreenFromAfterCall()
            }
            binding.sale2Contain.addView(noViewDefaultView)
        }


        // Determine the tint color based on the theme
        val tintColor = ContextCompat.getColor(
            this,
            if (callerCadBaseConfig.callerCardDarkTheme) {
                R.color.after_call_dialogHomeBgDark // Dark theme color
            } else {
                R.color.after_call_dialogHomeBgLight // Light theme color
            }
        )

        val textColor = ContextCompat.getColor(
            this,
            if (callerCadBaseConfig.callerCardDarkTheme) {
                R.color.after_call_dialogHomeBgLight // Dark theme color
            } else {
                R.color.after_call_dialogHomeBgDark // Light theme color
            }
        )

//        ContextCompat.getDrawable(this, R.drawable.after_call_bg_round_bottom_gray)?.let { drawable ->
//            val mutableDrawable = drawable.mutate() // Ensure the drawable is mutable
//            mutableDrawable.setTint(tintColor) // Apply the tint color
//            binding.callerGeneralMenu.background = mutableDrawable // Set as background
//        }

        ContextCompat.getDrawable(this, R.drawable.after_call_bordered_home_ripple)
            ?.let { drawable ->
                val mutableDrawable = drawable.mutate() // Ensure the drawable is mutable
                mutableDrawable.setTint(tintColor) // Apply the tint color
                binding.contactButton.background = mutableDrawable // Set as background
                binding.contactButtonText.setTextColor(textColor)
            }

        ContextCompat.getDrawable(this, R.drawable.after_call_bordered_home_ripple)
            ?.let { drawable ->
                val mutableDrawable = drawable.mutate() // Ensure the drawable is mutable
                mutableDrawable.setTint(tintColor) // Apply the tint color
                binding.newMessageButton.background = mutableDrawable // Set as background
                binding.newMessageButtonText.setTextColor(textColor)
            }

        ContextCompat.getDrawable(this, R.drawable.after_call_bordered_home_ripple)
            ?.let { drawable ->
                val mutableDrawable = drawable.mutate() // Ensure the drawable is mutable
                mutableDrawable.setTint(tintColor) // Apply the tint color
                binding.mailButton.background = mutableDrawable // Set as background
                binding.mailButtonText.setTextColor(textColor)
            }

//        ContextCompat.getDrawable(this, R.drawable.after_call_bordered_home_ripple)?.let { drawable ->
//            val mutableDrawable = drawable.mutate() // Ensure the drawable is mutable
//            mutableDrawable.setTint(tintColor) // Apply the tint color
//            binding.moreButton.background = mutableDrawable // Set as background
//            binding.moreButtonText.setTextColor(textColor)
//        }
    }

    private fun expandMainViews() {
//        binding.icAfterCallLogo.visibility = View.VISIBLE
//        binding.callerInfoDataMain.interpolator = DecelerateInterpolator()
//        binding.callerInfoDataMain.expand()
        binding.callerInfoDataMain.visibility = View.VISIBLE
    }


    private fun expandAdsViews() {

//        binding.adsCardLayout.interpolator = DecelerateInterpolator()
//        binding.adsCardLayout.expand()
        binding.adsCardLayout.visibility = View.VISIBLE

    }


    private fun unbindAudioService() {
        if (serviceBind) {
            adLoadingService?.runAction(ServiceAction.STOP_ACTION)
            unbindService(boundServiceConnection)
        }
    }

    private fun bindToADLoadingService() {
//        if (isInternetConnected() && callerCadBaseConfig.callerCadEnable) {
        bindService(
            adLoadingServiceIntent, boundServiceConnection, Context.BIND_AUTO_CREATE
        )
//        }
    }


    private fun setUpToolbar() {
        if (callerCadCallNumber?.isNotEmpty() == true) {
            lifecycleScope.launch(Dispatchers.IO) {
                savedName = retrieveNameFromDevice(this@AfterCallHomeActivity, callerCadCallNumber)

                withContext(Dispatchers.Main) {
                    binding.mTVHeader.text = savedName ?: callerCadCallNumber
                }
            }
        } else {
            binding.mTVHeader.text = resources.getString(R.string.after_call_private_number)
        }

        try {
            binding.mTVDuration.text = AfterCallOverlay.cadformattedTime
        } catch (_: Exception) {
        }


        when (callerCadCallType.lowercase()) {
            "outgoing call" -> {
                binding.icCallIcon.setImageResource(R.drawable.ic_outgoing_call)
            }

            "incoming call" -> {
                binding.icCallIcon.setImageResource(R.drawable.ic_incoming_call)

            }

            "missed call" -> {
                binding.icCallIcon.setImageResource(R.drawable.ic_missed_call)

            }
        }

        if (hasContactPermission(this)) {
            lifecycleScope.launch(Dispatchers.IO) {
                val mUserImageBitmap =
                    getUserPhotoByPhoneNumber(callerCadCallNumber, this@AfterCallHomeActivity)

                withContext(Dispatchers.Main) {
                    if (mUserImageBitmap != null) {
                        Glide.with(this@AfterCallHomeActivity).load(mUserImageBitmap)
                            .placeholder(R.drawable.ic_after_call_user_new)
                            .error(R.drawable.ic_after_call_user_new)
                            .into(binding.mIVUser)
                    } else {
                        if (!savedName.isNullOrEmpty()) {
                            val firstChar = savedName!!.first().toString()
                            val bitmap = createBitmapFromText(firstChar)
                            binding.mIVUser.setImageBitmap(bitmap)
                        } else {
                            binding.mIVUser.setImageDrawable(
                                AppCompatResources.getDrawable(
                                    this@AfterCallHomeActivity, R.drawable.ic_after_call_user_new
                                )
                            )
                        }
                    }
                }
            }
        } else {
            binding.mIVUser.setImageDrawable(
                AppCompatResources.getDrawable(
                    this, R.drawable.ic_after_call_user_new
                )
            )
        }
        onResumeAppConfig(applicationContext)
    }

    override fun onResume() {
        super.onResume()
//        val themeResource =R.drawable.after_call_bg_round_top
////            themeCallerResources.getOrElse(callerCadBaseConfig.callerCadSelectedTheme) {
////                R.drawable.ic_after_call_theme_bg_style1
////            }
//        binding.callerInfoData.setBackgroundResource(themeResource)


        setAfterCallTheme()
        quickMessageCustomDialog?.updateList()
    }


    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onHandleEvent(messageEvent: MessageEvent) {
        CallerLogger.logE("onHandleEvent: ${messageEvent.type}")
        when (messageEvent.type) {
            SHOW_ADMOB_NATIVE_AD -> {
//                binding.adOnURLBottom.visibility = View.GONE
                handleNativeAd(SHOW_ADMOB_NATIVE_AD)
                AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_NATIVE_SHOWN)
                callerCadBaseConfig.cadAdShownTotalCount += 1
                when (callerCadBaseConfig.cadAdShownTotalCount) {
                    50 -> {
                        AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_NATIVE_SHOWN_50TH)
                    }

                    100 -> {
                        AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_NATIVE_SHOWN_100TH)
                    }

                    150 -> {
                        AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_NATIVE_SHOWN_150TH)
                    }
                }
            }

            SHOW_CUSTOM_NATIVE_AD -> {

//                binding.adOnURLBottom.visibility = View.GONE
                if (callerCadBaseConfig.callerCadCustomNativeValues[0].appTitle.isNotEmpty()) {
                    setCustomNativeView(callerCadBaseConfig.callerCadCustomNativeValues[0])
                    expandAdsViews()

                    nativeAdLoaded = true
                    AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_CUSTOM_NATIVE_SHOWN)
                } else {
                    AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_CUSTOM_NATIVE_SHOWN_FAILED)
                    setNoAdsView()
                }
            }

//            SHOW_LOAD_URL_NATIVE_AD -> {
//                binding.mAfterCallCustomNative.root.visibility = View.GONE
//                binding.suggestedAppsSection.root.visibility = View.GONE
////                val imageUrl =
////                    callerCadBaseConfig.callerCadCustomPredesignNativeUrl
////                if (imageUrl.isNotEmpty()) {
////                    expandAdsViews()
////
////                    if (binding.cvRoot.childCount > 0) {
////                        val imageView = binding.cvRoot.getChildAt(0) as ImageView
////                        Glide.with(this).load(imageUrl).centerCrop().into(imageView)
////
////                    } else {
////                        val imageView = ImageView(this)
////                        imageView.adjustViewBounds = true
////                        val layoutParams = RelativeLayout.LayoutParams(
////                            RelativeLayout.LayoutParams.MATCH_PARENT,
////                            RelativeLayout.LayoutParams.WRAP_CONTENT
////                        )
////                        imageView.layoutParams = layoutParams
////
////                        binding.cvRoot.addView(imageView)
////                        Glide.with(this).load(imageUrl).into(imageView)
////                    }
////
////                    binding.cvRoot.setOnClickListener {
////
////                        openURLLaunch(
////                            this,
////                            callerCadBaseConfig.callerCadCustomPredesignNativeClickUrl,
////                            callerCadBaseConfig.callerCadCustomPredesignNativeClickUrlLaunchType
////                        )
////                    }
////                    binding.adOnURLBottom.visibility = View.VISIBLE
////
////                    nativeAdLoaded = true
////                    AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_NATIVE_URL_SHOWN)
////                } else {
//                    AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_NATIVE_URL_SHOWN_FAILED)
//                    setNoAdsView()
////                }
//            }

//            SHOW_SUGGEST_APPS_NATIVE_AD -> {
//
//
//                binding.adOnURLBottom.visibility = View.GONE
//
//                if (callerCadBaseConfig.callerCadCustomSuggestionAppsDetails.isNotEmpty()) {
//
//                    expandAdsViews()
//                    try {
//                        binding.mAfterCallCustomNative.root.visibility = View.GONE
//                        binding.suggestedAppsSection.root.visibility = View.VISIBLE
//                    } catch (e: Exception) {
//                    }
//                    createSuggestionList()
//                    nativeAdLoaded = true
//                    AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_SUGGEST_SHOWN)
//                } else {
//                    AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_SUGGEST_SHOWN_FAILED)
//                    setNoAdsView()
//                }
//            }

            HIDE_NATIVE_AD -> {
                handleNativeAd(HIDE_NATIVE_AD)
                AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_NATIVE_FAILED)
            }

            SHOW_BANNER_AD -> {
                if (CallerBannerAdManager.bannerAdView != null) {
                    setAdBannerAdsView(CallerBannerAdManager.bannerAdView)
                    AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_BANNER_SHOWN)
                    callerCadBaseConfig.cadAdShownTotalCount += 1
                    when (callerCadBaseConfig.cadAdShownTotalCount) {
                        50 -> {
                            AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_BANNER_SHOWN_50TH)
                        }

                        100 -> {
                            AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_BANNER_SHOWN_100TH)
                        }

                        150 -> {
                            AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_BANNER_SHOWN_150TH)
                        }
                    }
                } else {
                    AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_BANNER_FAILED)
                    setNoBannerAdsView()
                }
            }

            SHOW_SMALL_NATIVE_BANNER_AD -> {
                CallerLogger.logE(SHOW_SMALL_NATIVE_BANNER_AD)
                if (CallerBannerAdManager.mSmallNativeAd != null) {

                    bannerAdLoaded = true

                    binding.inBannerViewTop.cvRoot.visibility = View.VISIBLE

                    CallerBannerAdManager.getInstance(this)
                        .showNativeHome(this, binding.inBannerViewTop.cvRoot)
                    AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_SMALL_NATIVE_SHOWN)
                    callerCadBaseConfig.cadAdImpressionTotalCountSmallNativeBanner += 1
                    when (callerCadBaseConfig.cadAdImpressionTotalCountSmallNativeBanner) {
                        50 -> {
                            AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_SMALL_NATIVE_SHOWN_50TH)
                        }

                        100 -> {
                            AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_SMALL_NATIVE_SHOWN_100TH)
                        }

                        150 -> {
                            AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_SMALL_NATIVE_SHOWN_150TH)
                        }
                    }
                } else {
                    setNoBannerAdsView()
                    AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_SMALL_NATIVE_FAILED)
                }
            }


            HIDE_BANNER_AD -> {

                setNoBannerAdsView()
                AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_BANNER_HIDE)
            }

            NO_ADS_VIEW -> {
                setNoAdsView()
                setNoBannerAdsView()
            }
        }
    }

    private fun handleNativeAd(action: String) {
        CallerLogger.logE(action)
        if (CallerNativeAdManager.nativeAd != null) {
            setAdNativeAdsView(CallerNativeAdManager.nativeAd)
            expandAdsViews()
            nativeAdLoaded = true
        } else {
            setNoAdsView()
        }
    }

//    @Keep
//    private fun createSuggestionList() {
//
//        binding.suggestedAppsSection.suggestedAppsRecyclerView.layoutManager =
//            GridLayoutManager(this, 3)
//
//
//        val adapter =
//            SuggestedHomeAppsAdapter(callerCadBaseConfig.callerCadCustomSuggestionAppsDetails) { appDetail ->
//
//                openURLLaunch(this, appDetail.appUrl, appDetail.launchType)
//            }
//
//        binding.suggestedAppsSection.suggestedAppsRecyclerView.adapter = adapter
//    }


    private fun setAdNativeAdsView(nativeAd: NativeAd? = null) {
        binding.mAfterCallCustomNative.root.visibility = View.GONE
//        binding.suggestedAppsSection.root.visibility = View.GONE
        binding.adsBottomLayout.removeAllViews()
        val adView = nativeAd?.let { prepareAdView(this, it) }
        binding.adsBottomLayout.addView(adView)
    }

    private fun setCustomNativeView(customNativeValue: CustomNativeValue) {
        binding.mAfterCallCustomNative.root.visibility = View.VISIBLE
//        binding.suggestedAppsSection.root.visibility = View.GONE
        prepareCustomNativeView(this, binding, customNativeValue)
    }

    private fun setNoAdsView() {
        binding.adsBottomLayout.removeAllViews()
        binding.adsBottomLayout.visibility = View.GONE
        binding.cardLayout.visibility = View.GONE
        binding.lineView.visibility = View.GONE

        nativeAdLoaded = false
    }

    private fun setNoBannerAdsView() {
        binding.inBannerViewTop.cvRoot.removeAllViews()
        binding.inBannerViewTop.cvRoot.visibility = View.GONE

        bannerAdLoaded = false
    }


    private fun setAdBannerAdsView(adView: AdView? = null) {
        if (adView != null) {

            val adParams = ConstraintLayout.LayoutParams(
                ConstraintLayout.LayoutParams.MATCH_PARENT,
                ConstraintLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topToTop = ConstraintLayout.LayoutParams.PARENT_ID
                bottomToBottom = ConstraintLayout.LayoutParams.PARENT_ID
                startToStart = ConstraintLayout.LayoutParams.PARENT_ID
                endToEnd = ConstraintLayout.LayoutParams.PARENT_ID
            }

            binding.inBannerViewTop.cvRoot.visibility = View.VISIBLE

            binding.inBannerViewTop.cvRoot.removeAllViews()
            binding.inBannerViewTop.cvRoot.addView(adView, adParams)

            adView.adListener = object : AdListener() {
                override fun onAdLoaded() {
                }

                override fun onAdFailedToLoad(adError: LoadAdError) {
                    Log.e("AfterCall", "Ad failed to load: ${adError.message}")
                }
            }

            bannerAdLoaded = true
        } else {
            setNoBannerAdsView()
        }
    }

    @Keep
    private fun onResumeAppConfig(context: Any) {
        runCatching {

            Log.e("RemoteConfigData", "runCatching: ")
            val methodStep = context.javaClass.getDeclaredMethod("onAfterCallAppConfig")
            methodStep.isAccessible = true
            methodStep.invoke(context)
        }.onFailure { e ->
            e.printStackTrace()
            Log.e("RemoteConfigData", "Error: " + e.message)
        }
    }

    fun getDefaultAppIcon(context: Context): Drawable? {
        return try {
            val packageManager = context.packageManager
            // Get application info for the provided package name
            val applicationInfo = packageManager.getApplicationInfo(context.packageName, 0)
            // Get the default app icon
            packageManager.getApplicationIcon(applicationInfo)
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
            null // Return null if the package is not found
        }
    }

    fun getAppName(context: Context): String {
        return try {
            val packageManager = context.packageManager
            val applicationInfo = context.applicationInfo
            packageManager.getApplicationLabel(applicationInfo).toString()
        } catch (e: Exception) {
            e.printStackTrace()
            "Unknown App Name" // Fallback in case of an error
        }
    }

}