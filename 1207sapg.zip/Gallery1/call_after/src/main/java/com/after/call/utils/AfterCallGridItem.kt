package com.after.call.utils

import androidx.annotation.Keep


@Keep
data class AfterCallGridItem(
    val title: String,
    val imageResId: Int,
    val imageBG: Int,
    val topColor: Int,
    val bottomColor: Int,
    val btnColor: Int,
)