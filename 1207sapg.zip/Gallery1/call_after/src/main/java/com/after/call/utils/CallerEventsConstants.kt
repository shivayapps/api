package com.after.call.utils

object CallerEventsConstants {
    const val CAD_CLICK_SETUP = "after_call_click_setup"
    const val CAD_CALL_ALLOW_PERMISSION = "after_call_call_allow_permission"
    const val CAD_CALL_DENY_PERMISSION = "after_call_call_deny_permission"
    const val CAD_OVERLAY_ALLOW_PERMISSION = "after_call_overlay_allow_permission"
    const val CAD_OVERLAY_DENY_PERMISSION = "after_call_overlay_deny_permission"

    const val CAD_CREATED = "after_call_created"
    const val CAD_AD_NATIVE_SHOWN = "after_call_ad_native_shown"
    const val CAD_AD_NATIVE_SHOWN_50TH = "after_call_ad_native_shown_50th"
    const val CAD_AD_NATIVE_SHOWN_100TH = "after_call_ad_native_shown_100th"
    const val CAD_AD_NATIVE_SHOWN_150TH = "after_call_ad_native_shown_150th"
    const val CAD_AD_NATIVE_IMPRESSION_1 = "after_call_ad_native_impression_1"
    const val CAD_AD_NATIVE_IMPRESSION_2 = "after_call_ad_native_impression_2"
    const val CAD_AD_NATIVE_IMPRESSION_3 = "after_call_ad_native_impression_3"
    const val CAD_AD_NATIVE_IMPRESSION_4 = "after_call_ad_native_impression_4"
    const val CAD_AD_NATIVE_IMPRESSION_5 = "after_call_ad_native_impression_5"
    const val CAD_AD_NATIVE_IMPRESSION_6 = "after_call_ad_native_impression_6"
    const val CAD_AD_NATIVE_IMPRESSION_7 = "after_call_ad_native_impression_7"
    const val CAD_AD_NATIVE_FAILED = "after_call_ad_native_failed"

    const val CAD_AD_NATIVE_URL_SHOWN = "after_call_ad_native_url_shown"
    const val CAD_AD_NATIVE_URL_SHOWN_FAILED = "after_call_ad_native_url_shown_failed"

    const val CAD_AD_SUGGEST_SHOWN = "after_call_ad_native_suggest_shown"
    const val CAD_AD_SUGGEST_SHOWN_FAILED = "after_call_ad_native_suggest_shown_failed"

    const val CAD_AD_CUSTOM_NATIVE_SHOWN = "after_call_ad_custom_native_shown"
    const val CAD_AD_CUSTOM_NATIVE_SHOWN_FAILED = "after_call_ad_custom_native_shown_failed"

    const val CAD_AD_BANNER_URL_SHOWN = "after_call_ad_banner_url_shown"
    const val CAD_AD_BANNER_URL_SHOWN_FAILED = "after_call_ad_banner_url_shown_failed"

    const val CAD_AD_SMALL_NATIVE_SHOWN = "after_call_ad_small_native_shown"
    const val CAD_AD_SMALL_NATIVE_SHOWN_50TH = "after_call_ad_small_native_shown_50th"
    const val CAD_AD_SMALL_NATIVE_SHOWN_100TH = "after_call_ad_small_native_shown_100th"
    const val CAD_AD_SMALL_NATIVE_SHOWN_150TH = "after_call_ad_small_native_shown_150th"
    const val CAD_AD_SMALL_NATIVE_IMPRESSION_1 = "after_call_ad_small_native_impression_1"
    const val CAD_AD_SMALL_NATIVE_IMPRESSION_2 = "after_call_ad_small_native_impression_2"
    const val CAD_AD_SMALL_NATIVE_IMPRESSION_3 = "after_call_ad_small_native_impression_3"
    const val CAD_AD_SMALL_NATIVE_IMPRESSION_4 = "after_call_ad_small_native_impression_4"
    const val CAD_AD_SMALL_NATIVE_IMPRESSION_5 = "after_call_ad_small_native_impression_5"
    const val CAD_AD_SMALL_NATIVE_IMPRESSION_6 = "after_call_ad_small_native_impression_6"
    const val CAD_AD_SMALL_NATIVE_IMPRESSION_7 = "after_call_ad_small_native_impression_7"
    const val CAD_AD_SMALL_NATIVE_FAILED = "after_call_ad_small_native_failed"

    const val CAD_AD_BANNER_SHOWN = "after_call_ad_banner_shown"
    const val CAD_AD_BANNER_SHOWN_50TH = "after_call_ad_banner_shown_50th"
    const val CAD_AD_BANNER_SHOWN_100TH = "after_call_ad_banner_shown_100th"
    const val CAD_AD_BANNER_SHOWN_150TH = "after_call_ad_banner_shown_150th"

    const val CAD_AD_BANNER_IMPRESSION_1 = "after_call_ad_banner_impression_1"
    const val CAD_AD_BANNER_IMPRESSION_2 = "after_call_ad_banner_impression_2"
    const val CAD_AD_BANNER_IMPRESSION_3 = "after_call_ad_banner_impression_3"
    const val CAD_AD_BANNER_IMPRESSION_4 = "after_call_ad_banner_impression_4"
    const val CAD_AD_BANNER_IMPRESSION_5 = "after_call_ad_banner_impression_5"
    const val CAD_AD_BANNER_IMPRESSION_6 = "after_call_ad_banner_impression_6"
    const val CAD_AD_BANNER_IMPRESSION_7 = "after_call_ad_banner_impression_7"
    const val CAD_AD_BANNER_FAILED = "after_call_ad_banner_failed"
    const val CAD_AD_BANNER_HIDE = "after_call_ad_banner_hide"
    const val CAD_SETTING_DISABLED = "after_call_setting_disabled"


    const val CAD_AUTO_START_DIALOG_SHOW = "after_call_auto_start_dialog_show"
    const val CAD_AUTO_START_CLICK_ALLOW = "after_call_auto_start_click_allow"
    const val CAD_AUTO_START_CLICK_LATER = "after_call_auto_start_click_later"
    const val CAD_AUTO_START_CLICK_NEVER = "after_call_auto_start_click_never"
    const val CAD_DEVICE_BRAND = "after_call_device_brand"
}
