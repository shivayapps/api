package com.after.call.utils

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.ActivityResultRegistry
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class AfterCallPermissionManager(
    private val activity: AppCompatActivity, // Ensure activity is a ComponentActivity
    registry: ActivityResultRegistry,
) {
    private var permissionCallback: ((isGranted: Boolean) -> Unit)? = null
    private var callerCadPermission: String = ""

    fun requestGeneralPermission(permission: String, callback: (isGranted: Boolean) -> Unit) {
        permissionCallback = callback
        callerCadPermission = permission
        if (ContextCompat.checkSelfPermission(
                activity,
                permission
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            permissionCallback?.invoke(true)
        } else {
            requestPhoneStatePermissionLauncher.launch(callerCadPermission)
        }
    }

    private lateinit var requestPhoneStatePermissionLauncher: ActivityResultLauncher<String>

    init {
        requestPhoneStatePermissionLauncher = registry.register(
            "phone_state_permission", ActivityResultContracts.RequestPermission()
        ) { isGranted ->
            if (isGranted) {
                permissionCallback?.invoke(true)
            } else {
                // Permission denied
                if (ActivityCompat.shouldShowRequestPermissionRationale(
                        activity,
                        callerCadPermission
                    )
                ) {
                    showRationaleDialog(
                        "Permission Denied",
                        "This permission is necessary to access. Please allow it."
                    ) {
                        requestPhoneStatePermissionLauncher.launch(callerCadPermission)
                    }
                } else {
                    showSettingsDialog(
                        "This Permission Required",
                        "This permission is required. Please enable it from settings."
                    )
                }
            }
        }
    }

    fun requestOverlayPermission(callback: (isGranted: Boolean) -> Unit) {
        permissionCallback = callback

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (Settings.canDrawOverlays(activity)) {
                permissionCallback?.invoke(true)
            } else {
                showRationaleDialog(
                    "Overlay Permission Denied",
                    "This permission is required to display content over other apps. Please allow it."
                ) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:${activity.packageName}")
                    )
                    overlayPermissionLauncher.launch(intent)
                }
            }
        } else {
            permissionCallback?.invoke(true)
        }
    }

    private val overlayPermissionLauncher: ActivityResultLauncher<Intent> =
        registry.register("overlay_permission", ActivityResultContracts.StartActivityForResult()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                permissionCallback?.invoke(Settings.canDrawOverlays(activity))
            } else {
                permissionCallback?.invoke(true)
            }
        }

    private fun showRationaleDialog(title: String, message: String, onPositive: () -> Unit) {
        AlertDialog.Builder(activity)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Allow") { _, _ -> onPositive.invoke() }
            .setNegativeButton("Cancel") { _, _ -> permissionCallback?.invoke(false) }
            .show()
    }

    private fun showSettingsDialog(title: String, message: String) {
        AlertDialog.Builder(activity)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Open Settings") { _, _ ->
                val intent = Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:${activity.packageName}")
                )
                activity.startActivity(intent)
            }
            .setNegativeButton("Cancel") { _, _ ->
                permissionCallback?.invoke(false)
            }
            .show()
    }
}
