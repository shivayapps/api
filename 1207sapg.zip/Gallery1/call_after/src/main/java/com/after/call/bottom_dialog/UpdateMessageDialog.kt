package com.after.call.bottom_dialog

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import com.after.call.R
import com.after.call.extensions.callerCadBaseConfig


class UpdateMessageDialog(
    context: Context,
    private val listener: OnMessageActionListener,
    private val initialMessage: String,
) : Dialog(context, R.style.QuickMessageDialogStyle) {

    private lateinit var editText: EditText
    private lateinit var okButton: Button
    private lateinit var deleteButton: Button
    private lateinit var cancelButton: Button
    private lateinit var dialogTitle: TextView
    private lateinit var bgMain: ConstraintLayout

    interface OnMessageActionListener {
        fun onMessageUpdated(message: String)
        fun onMessageDeleted()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)

        if (context.callerCadBaseConfig.callerCardDarkTheme) {
            window?.apply {
                setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                setBackgroundDrawableResource(R.drawable.after_call_bg_round_button_home_more_dark)
            }
        } else {
            window?.apply {
                setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                setBackgroundDrawableResource(R.drawable.after_call_bg_round_button_home_more_light)
            }
        }

        setContentView(R.layout.caller_dialog_update_quick_message)

        editText = findViewById(R.id.dialogEditText)
        okButton = findViewById(R.id.dialogOkButton)
        deleteButton = findViewById(R.id.dialogUpdateButton)
        cancelButton = findViewById(R.id.dialogCancelButton)
        dialogTitle = findViewById(R.id.dialogTitle)
        bgMain = findViewById(R.id.bg_main)

        // Set initial message in EditText
        editText.setText(initialMessage)

        okButton.setOnClickListener {
            val updatedMessage = editText.text.toString().trim()
            if (updatedMessage.isNotEmpty()) {
                listener.onMessageUpdated(updatedMessage)
                dismiss()
            }
        }

        deleteButton.setOnClickListener {
            listener.onMessageDeleted()
            dismiss()
        }

        cancelButton.setOnClickListener {
            cancel()
        }

        val tintColor = ContextCompat.getColor(
            context,
            if (context.callerCadBaseConfig.callerCardDarkTheme) {
                R.color.after_call_card_bg_dark // Dark theme color
            } else {
                R.color.after_call_card_bg_light // Light theme color
            }
        )
        ContextCompat.getDrawable(context, R.drawable.ic_after_call_round_bg)?.let { drawable ->
            val mutableDrawable = drawable.mutate()
            mutableDrawable.setTint(tintColor)
            bgMain.background = mutableDrawable
        }


        if (context.callerCadBaseConfig.callerCardDarkTheme) {
            dialogTitle.setTextColor(
                ContextCompat.getColor(
                    context,
                    R.color.after_call_text_color_white
                )
            )
            editText.setTextColor(
                ContextCompat.getColor(
                    context,
                    R.color.after_call_text_color_white
                )
            )
        } else {
            dialogTitle.setTextColor(
                ContextCompat.getColor(
                    context,
                    R.color.after_call_text_color_black
                )
            )
            editText.setTextColor(
                ContextCompat.getColor(
                    context,
                    R.color.after_call_text_color_black
                )
            )
        }
    }
}