package com.after.call.utils

import android.app.Activity
import android.app.AlertDialog
import android.graphics.drawable.Drawable
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.cardview.widget.CardView
import com.after.call.R
import com.after.call.databinding.CustomDialogLayoutCallerBinding

class CallerDisableDialog(val context: Activity) {
    private val alertDialog: AlertDialog


    var binding: CustomDialogLayoutCallerBinding

    init {


        binding = CustomDialogLayoutCallerBinding.inflate(context.layoutInflater)


        alertDialog = AlertDialog.Builder(context).create()
        alertDialog.setView(binding.root)
        alertDialog.setCancelable(false)
    }

    fun show(title: String, description: String, positiveButtonText: String, negativeButtonText: String, positiveButtonClickListener: () -> Unit, negativeButtonClickListener: () -> Unit,theme : Boolean) {
        binding.titleTextView.text = title
        binding.descriptionTextView.text = description
        binding.positiveButton.text = positiveButtonText
        binding.negativeButton.text = negativeButtonText

        binding.positiveButton.setOnClickListener(object : CallerOnSingleClickListener(){
            override fun onSingleClick(v: View?) {
                positiveButtonClickListener()
                alertDialog.dismiss()
            }
        })

        binding.negativeButton.setOnClickListener(object : CallerOnSingleClickListener(){
            override fun onSingleClick(v: View?) {
                negativeButtonClickListener()
                alertDialog.dismiss()
            }
        })

        if (theme) {
            val drawable: Drawable? = context.resources.getDrawable(R.drawable.after_call_rounded_darkdialog_background)
            alertDialog.window?.setBackgroundDrawable(drawable)
            binding.descriptionTextView.setTextColor(context.resources.getColor(R.color.after_call_white_all))
            binding.titleTextView.setTextColor(context.resources.getColor(R.color.after_call_white_all))

        } else {
            val drawable: Drawable? = context.resources.getDrawable(R.drawable.after_call_rounded_dialog_background)
            alertDialog.window?.setBackgroundDrawable(drawable)
            binding.descriptionTextView.setTextColor(context.resources.getColor(R.color.after_call_black))
            binding.titleTextView.setTextColor(context.resources.getColor(R.color.after_call_black))
        }

        alertDialog.show()
    }

}


