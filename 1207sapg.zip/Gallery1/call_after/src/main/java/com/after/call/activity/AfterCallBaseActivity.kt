package com.after.call.activity

import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import com.after.call.R
import com.after.call.extensions.callerCadBaseConfig

open class AfterCallBaseActivity : AppCompatActivity() {
    override fun onResume() {
        super.onResume()
        /* if (callerCadBaseConfig.callerCardDarkTheme) {
             AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
             WindowCompat.getInsetsController(window, window.decorView).apply {
                 isAppearanceLightStatusBars = false
             }
         } else {
             AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
             WindowCompat.getInsetsController(window, window.decorView).apply {
                 isAppearanceLightStatusBars = true
             }
         }*/

        setCustomStatusBar()
    }


    fun setCustomStatusBar() {
        if (baseContext.callerCadBaseConfig.callerCardDarkTheme) {
            val window = this.window
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.statusBarColor = ContextCompat.getColor(this, R.color.after_call_card_bg_dark)
            window.navigationBarColor =
                ContextCompat.getColor(this, R.color.after_call_card_bg_dark)
            WindowCompat.getInsetsController(window, window.decorView).apply {
                isAppearanceLightStatusBars = false
            }
        } else {
            val window = this.window
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.statusBarColor = ContextCompat.getColor(this, R.color.after_call_card_bg_light)
            window.navigationBarColor =
                ContextCompat.getColor(this, R.color.after_call_card_bg_light)
            WindowCompat.getInsetsController(window, window.decorView).apply {
                isAppearanceLightStatusBars = true
            }
        }
    }
}