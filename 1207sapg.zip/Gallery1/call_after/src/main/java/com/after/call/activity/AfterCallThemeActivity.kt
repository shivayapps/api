package com.after.call.activity


//class AfterCallThemeActivity : AfterCallBaseActivity() {
//
//    lateinit var binding: ActivityAfterCallThemeBinding
//    private var selectedThemePosition: Int = 0
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//
//        val window = window
//        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
//        window.statusBarColor =
//            ContextCompat.getColor(this, R.color.after_call_card_bg)
//
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
//        }
//
//        binding = ActivityAfterCallThemeBinding.inflate(layoutInflater)
//        setContentView(binding.root)
//
//
//        binding.backBtnAtTheme.setImageResource(application.callerCadBaseConfig.callerCadBackIcon)
//        selectedThemePosition = callerCadBaseConfig.callerCadSelectedTheme
//
//        binding.recyclerView.layoutManager = GridLayoutManager(this, 4)
//        binding.recyclerView.adapter = ThemeGridAdapter(this, callerCadThemeList, { item ->
//            binding.callerCadPopupLayout.callerInfoData.setBackgroundResource(item.imageBG)
//
//            val drawable =
//                ContextCompat.getDrawable(
//                    this,
//                    R.drawable.bg_caller_round_button_ripple
//                )
//            val drawable1 =
//                ContextCompat.getDrawable(
//                    this,
//                    R.drawable.bg_caller_round_button_ripple
//                )
//            val newColor = ContextCompat.getColor(this, item.btnColor)
//            drawable?.mutate()?.setTint(newColor)
//
//            drawable1?.mutate()?.setTint(newColor)
//
//            binding.callerCadPopupLayout.callerAppOpen.background = drawable
//            binding.callerCadPopupLayout.callerSetting.background = drawable1
//        }, { position ->
//            selectedThemePosition = position
//        })
//
//
//        binding.backBtnAtTheme.setOnClickListener(object : CallerOnSingleClickListener() {
//            override fun onSingleClick(v: View?) {
//                onBackPressed()
//            }
//        })
//
//        binding.mThemeApplyBtn.setOnClickListener(object : CallerOnSingleClickListener() {
//            override fun onSingleClick(v: View?) {
//                callerCadBaseConfig.callerCadSelectedTheme = selectedThemePosition
//                Toast.makeText(
//                    this@AfterCallThemeActivity,
//                    getString(R.string.theme_applied_successfully),
//                    Toast.LENGTH_SHORT
//                ).show()
//
//                CALLER_CAD_THEME_CHANGE = true
//                finish()
//            }
//        })
//        updateSelectedTheme()
//
//    }
//
//    private fun updateSelectedTheme() {
//        val drawable =
//            ContextCompat.getDrawable(
//                this,
//                R.drawable.bg_caller_round_button_ripple
//            )
//        val newColor = ContextCompat.getColor(
//            this,
//            callerCadThemeList[callerCadBaseConfig.callerCadSelectedTheme].btnColor
//        )
//        drawable?.mutate()?.setTint(newColor)
//        binding.callerCadPopupLayout.callerAppOpen.background = drawable
//        binding.callerCadPopupLayout.callerSetting.background = drawable
//
//        val themeResource = when (callerCadBaseConfig.callerCadSelectedTheme) {
//            0 -> R.drawable.ic_after_call_theme_bg_style1
//            1 -> R.drawable.ic_after_call_theme_bg_style1
//            2 -> R.drawable.ic_after_call_theme_bg_style3
//            3 -> R.drawable.ic_after_call_theme_bg_style4
//            4 -> R.drawable.ic_after_call_theme_bg_style5
//            5 -> R.drawable.ic_after_call_theme_bg_style6
//            6 -> R.drawable.ic_after_call_theme_bg_style7
//            7 -> R.drawable.ic_after_call_theme_bg_style8
//            else -> R.drawable.ic_after_call_theme_bg_style1
//        }
//        binding.callerCadPopupLayout.callerInfoData.setBackgroundResource(themeResource)
//    }
//
//
//    override fun onResume() {
//        super.onResume()
//
//
//        val mainBGColor = ContextCompat.getColor(
//            this,
//            if (callerCadBaseConfig.callerCardDarkTheme) {
//                R.color.after_call_screen_bg_dark // Dark theme color
//            } else {
//                R.color.after_call_screen_bg_light // Light theme color
//            }
//        )
//        binding.main.setBackgroundColor(mainBGColor)
//        binding.recyclerView.setBackgroundColor(mainBGColor)
//
//
//        val backIconTintColor = ContextCompat.getColorStateList(
//            this, if (callerCadBaseConfig.callerCardDarkTheme) {
//                R.color.after_call_icon_color_dark // Dark theme color
//            } else {
//                R.color.after_call_icon_color_light // Light theme color
//            }
//        )
//        val tintColor = ContextCompat.getColor(
//            this,
//            if (callerCadBaseConfig.callerCardDarkTheme) {
//                R.color.after_call_card_bg_dark // Dark theme color
//            } else {
//                R.color.after_call_card_bg_light // Light theme color
//            }
//        )
//
//        binding.toolbar.setBackgroundColor(tintColor)
//        binding.backBtnAtTheme.imageTintList = backIconTintColor
//
//        val drawable = ContextCompat.getDrawable(this, R.drawable.after_call_bordered_home_ripple)
//
//        drawable?.mutate()?.setTint(tintColor)
//
//        binding.backBtnAtTheme.background = drawable
//
//        val tintColorStateList = ContextCompat.getColorStateList(
//            this, if (callerCadBaseConfig.callerCardDarkTheme) {
//                R.color.after_call_white_all // Dark theme color
//            } else {
//                R.color.after_call_selectedColor // Light theme color
//            }
//        )
//
//        binding.mThemeTitle.setTextColor(tintColorStateList)
//        binding.mThemePreview.setTextColor(tintColorStateList)
//
//// Text color change
//        val textColorList = ContextCompat.getColorStateList(
//            this, if (callerCadBaseConfig.callerCardDarkTheme) {
//                R.color.after_call_text_color_white // Dark theme color
//            } else {
//                R.color.after_call_text_color_black // Light theme color
//            }
//        )
//
//        val textViews = listOf(
//            binding.mTitleAtTheme
//        )
//        textViews.forEach { textView ->
//            textView.setTextColor(textColorList) // Correct method to set ColorStateList
//        }
//
//
//    }
//
//
//}
//
