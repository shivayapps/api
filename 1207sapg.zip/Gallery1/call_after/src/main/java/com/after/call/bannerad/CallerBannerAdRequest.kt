package com.after.call.bannerad

import android.content.Context
import android.os.Build
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import androidx.window.layout.WindowMetricsCalculator
import com.after.call.AfterCallUtils
import com.after.call.adUtils.CallerAdState
import com.after.call.extensions.callerCadBaseConfig
import com.after.call.extensions.isInternetConnected
import com.after.call.utils.CallerEventsConstants
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError


object CallerBannerAdRequest {
    private var topCallerAdState: CallerAdState = CallerAdState.NONE

    fun loadBannerAfterCall(context: Context, adId: String, callBack: (AdView?) -> Unit) {
        if (!context.isInternetConnected()) {
            topCallerAdState = CallerAdState.NONE
            callBack.invoke(null)
            return
        }
        topCallerAdState = CallerAdState.LOADING
        loadBanner(context.applicationContext, adId, onAdClick = {
        }, callBack)
    }

    private fun loadBanner(
        context: Context,
        adId: String,
        onAdClick: () -> Unit,
        callBack: (AdView?) -> Unit,
    ) {

        val callerCadParameters = context.callerCadBaseConfig
          val adView = AdView(context)
          adView.adListener = object : AdListener() {
              override fun onAdFailedToLoad(adError: LoadAdError) {

                  callBack.invoke(null)
              }

              override fun onAdLoaded() {

                  callBack.invoke(adView)
              }

              override fun onAdClicked() {
                  super.onAdClicked()
                  onAdClick.invoke()
              }

              override fun onAdImpression() {
                  super.onAdImpression()

                  callerCadParameters.cadAdImpressionTotalCountBanner += 1

                  when (callerCadParameters.cadAdImpressionTotalCountBanner) {
                      1-> {
                          AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_BANNER_IMPRESSION_1)
                      }
                      2-> {
                          AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_BANNER_IMPRESSION_2)
                      }
                      3-> {
                          AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_BANNER_IMPRESSION_3)
                      }
                      4-> {
                          AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_BANNER_IMPRESSION_4)
                      }
                      5-> {
                          AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_BANNER_IMPRESSION_5)
                      }
                      6-> {
                          AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_BANNER_IMPRESSION_6)
                      }
                      7-> {
                          AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_BANNER_IMPRESSION_7)
                      }
                  }
              }
          }
        val space = context.resources.getDimension(com.intuit.sdp.R.dimen._6sdp) * 2

        val adWidthPixels = context.resources.displayMetrics.widthPixels.toFloat() - space
        val adWidthDp = adWidthPixels / context.resources.displayMetrics.density
        val adSize =
            AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(
                context,
                adWidthDp.toInt()
            )


        adView.setAdSize(adSize)

          adView.adUnitId = adId
          adView.loadAd(AdRequest.Builder().build())
    }
}