package com.after.call.helpers


const val CALLER_CAD_REMOTE_CONFIG = "after_call_remote_config"

var CALLER_CAD_THEME_CHANGE = false

const val IS_SHOW_CALL_INFO = "isShowCallInfo"
const val ENGAGE_ACTIVITY_CLASS_KEY = "EngageActivityClass"
const val RECENT_MSG = "recentsMsgs"

const val PREF_NAME = "SAVE_LIST_SHARED_PREFERENCES"

const val CALLER_CAD_DARK_THEME = "callerCardDarkTheme"
const val CALLER_CAD_AUTO_START_LATER = "CALLERCADAUTOSTARTLATER"
const val CALLER_CAD_AUTO_START_DONT_SHOW_AGAIN = "CALLER_CAD_AUTO_START_DONT_SHOW_AGAIN"
const val CALLER_CAD_AUTO_START_ALLOWED = "CALLERCADAUTOSTARTALLOWED"
const val SWITCH_MISSED_CALL_SAVED = "switchMissedCallSaved"
const val SWITCH_REMINDER_SAVED = "switchReminderSaved"
const val SWITCH_NO_ANSWER_SAVED = "switchNoAnswerSaved"
const val SWITCH_COMPLETED_CALL_SAVED = "switchCompletedCallSaved"
const val SWITCH_EXTRA_CONTACT_SAVED = "switchExtraContactSaved"
const val SWITCH_UNKNOWN_CALLER_SAVED = "switchUnknownCallerSaved"
const val CAD_AD_SHOWN_TOTAL_COUNT = "cadAdShownTotalCount"
const val CAD_AD_IMPRESSION_TOTAL_COUNT = "cadAdImpressionTotalCount"
const val CONTACT_PERMISSION_DATA = "contactpermissiondata"
const val CALLER_CAD_PREFS_KEY = "AfterCallPrefsKey"
const val TEXT_COLOR = "text_color"
const val STATUS_BG_COLOR = "statusbar_color"
const val CALLER_CAD_SELECTED_THEME = "caller_cad_selected_Theme"
const val BACKGROUND_COLOR = "background_color"
const val PRIMARY_COLOR = "primary_color_2"
const val USE_24_HOUR_FORMAT = "use_24_hour_format"
const val DATE_FORMAT = "date_format"
const val TEXT_CURSOR_COLOR = "text_cursor_color"

val fixItemsForQuickItems = listOf("Write a message", "Edit Quick Messages")

const val DATE_FORMAT_ONE = "dd.MM.yyyy"
const val DATE_FORMAT_TWO = "dd/MM/yyyy"
const val DATE_FORMAT_THREE = "MM/dd/yyyy"
const val DATE_FORMAT_FOUR = "yyyy-MM-dd"
const val DATE_FORMAT_FIVE = "d MMMM yyyy"
const val DATE_FORMAT_SIX = "MMMM d yyyy"
const val DATE_FORMAT_SEVEN = "MM-dd-yyyy"
const val DATE_FORMAT_EIGHT = "dd-MM-yyyy"

const val TIME_FORMAT_12 = "hh:mm a"
const val TIME_FORMAT_24 = "HH:mm"






