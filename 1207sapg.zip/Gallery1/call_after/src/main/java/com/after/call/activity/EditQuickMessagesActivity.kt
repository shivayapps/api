package com.after.call.activity

import android.content.Context
import android.content.res.ColorStateList
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.after.call.R
import com.after.call.adapter.EditQuickMessageListAdapter
import com.after.call.bottom_dialog.AddMessageDialog
import com.after.call.bottom_dialog.UpdateMessageDialog
import com.after.call.databinding.ActivityEditQuickMessagesBinding
import com.after.call.extensions.callerCadBaseConfig
import com.after.call.utils.CallerOnSingleClickListener

class EditQuickMessagesActivity : AfterCallBaseActivity() {

    lateinit var binding: ActivityEditQuickMessagesBinding
    private lateinit var adapter: EditQuickMessageListAdapter
    private lateinit var mQuickMessagesList: MutableList<String>
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val window = window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor =
            ContextCompat.getColor(this, R.color.after_call_card_bg)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        }

        binding = ActivityEditQuickMessagesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        mQuickMessagesList = getCallerMessages(this).toMutableList()

        binding.backBtnAtTheme.setImageResource(application.callerCadBaseConfig.callerCadBackIcon)
        setupRecyclerView()
        setupFloatButton()
        setupSelectAllButton()
        setupDeleteButton()
        setupTheme()


    }

    private fun setupTheme() {

        val mainBGColor = ContextCompat.getColor(
            this,
            if (callerCadBaseConfig.callerCardDarkTheme) {
                R.color.after_call_screen_bg_dark // Dark theme color
            } else {
                R.color.after_call_screen_bg_light // Light theme color
            }
        )
        binding.main.setBackgroundColor(mainBGColor)
        binding.recyclerView.setBackgroundColor(mainBGColor)


        val backIconTintColor = ContextCompat.getColorStateList(
            this, if (callerCadBaseConfig.callerCardDarkTheme) {
                R.color.after_call_icon_color_dark // Dark theme color
            } else {
                R.color.after_call_icon_color_light // Light theme color
            }
        )
        val tintColor = ContextCompat.getColor(
            this,
            if (callerCadBaseConfig.callerCardDarkTheme) {
                R.color.after_call_card_bg_dark // Dark theme color
            } else {
                R.color.after_call_card_bg_light // Light theme color
            }
        )

        binding.toolbar.setBackgroundColor(tintColor)
        binding.backBtnAtTheme.imageTintList = backIconTintColor

        val drawable = ContextCompat.getDrawable(this, R.drawable.after_call_bordered_home_ripple)

        drawable?.mutate()?.setTint(tintColor)

        binding.backBtnAtTheme.background = drawable

        val tintColorStateList = ContextCompat.getColorStateList(
            this, if (callerCadBaseConfig.callerCardDarkTheme) {
                R.color.after_call_white_all // Dark theme color
            } else {
                R.color.after_call_selectedColor // Light theme color
            }
        )
// Text color change
        val textColorList = ContextCompat.getColorStateList(
            this, if (callerCadBaseConfig.callerCardDarkTheme) {
                R.color.after_call_text_color_white // Dark theme color
            } else {
                R.color.after_call_text_color_black // Light theme color
            }
        )

        val textViews = listOf(
            binding.mTitleAtTheme
        )
        textViews.forEach { textView ->
            textView.setTextColor(textColorList) // Correct method to set ColorStateList
        }
    }
    private fun setupRecyclerView() {
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = EditQuickMessageListAdapter(
            mQuickMessagesList = mQuickMessagesList,
            context = this,
            onClick = { message, isLongPress ->
                handleMessageClick(message, isLongPress)
            },
            onSelect = { isSelected ->
                binding.selectAllButton.visibility = if (isSelected) View.VISIBLE else View.GONE
                binding.mQuickItemDeleteBtn.visibility = if (isSelected) View.VISIBLE else View.GONE
            }
        )
        binding.recyclerView.adapter = adapter

        // Show "No Quick Message Found" if the list is empty
        if (mQuickMessagesList.isEmpty()) {
            binding.noQuickMessagesText.visibility = View.VISIBLE
        } else {
            binding.noQuickMessagesText.visibility = View.GONE
        }
    }

    private fun setupFloatButton() {


        binding.quickMessageAddFab.setOnClickListener(object : CallerOnSingleClickListener() {
            override fun onSingleClick(v: View?) {
                showAddMessageDialog()
            }
        })

        binding.backBtnAtTheme.setOnClickListener(object : CallerOnSingleClickListener() {
            override fun onSingleClick(v: View?) {
                onBackPressed()
            }
        })
    }

    private fun setupSelectAllButton() {
        binding.selectAllButton.setOnClickListener {
            if (adapter.selectedItems.size == mQuickMessagesList.size) {
                // Clear all selections
                adapter.clearSelections()
                binding.selectAllButton.setImageDrawable(
                    ResourcesCompat.getDrawable(
                        resources,
                        R.drawable.ic_caller_quick_unselected,
                        null
                    )
                )
            } else {
                // Select all items
                adapter.selectAll()
                binding.selectAllButton.setImageDrawable(
                    ResourcesCompat.getDrawable(
                        resources,
                        R.drawable.ic_after_call_quick_selected,
                        null
                    )
                )
            }
        }
    }


    override fun onBackPressed() {
        if (adapter.selectedItems.size > 0) {
            adapter.clearSelections()
        } else {
            super.onBackPressed()
        }
    }


    private fun setupDeleteButton() {
        binding.mQuickItemDeleteBtn.setOnClickListener {
            adapter.deleteSelectedItems { success ->
                if (mQuickMessagesList.isEmpty()) {
                    binding.noQuickMessagesText.visibility = View.VISIBLE
                } else {
                    binding.noQuickMessagesText.visibility = View.GONE
                }
            }
        }

        val colorStateList = if (callerCadBaseConfig.callerCardDarkTheme) {
            ColorStateList.valueOf(ContextCompat.getColor(this, R.color.after_call_text_color_white))
        } else {
            ColorStateList.valueOf(ContextCompat.getColor(this, R.color.after_call_text_color_black))
        }
        binding.mQuickItemDeleteBtn.imageTintList = colorStateList

    }

    private fun showAddMessageDialog() {
        val dialog = AddMessageDialog(this, object : AddMessageDialog.OnMessageEnteredListener {
            override fun onMessageEntered(message: String) {
                mQuickMessagesList.add(message)
                adapter.notifyItemInserted(mQuickMessagesList.size - 1)
                updateAfterCallConfig()
                if (mQuickMessagesList.isEmpty()) {
                    binding.noQuickMessagesText.visibility = View.VISIBLE
                } else {
                    binding.noQuickMessagesText.visibility = View.GONE
                }
            }
        })

        dialog.show()
    }

    fun updateAfterCallConfig() {
        this.callerCadBaseConfig.callerCadQuickMessagesList = mQuickMessagesList
    }

    fun updateAfterCallConfig(mQuickMessagesList: MutableList<String>) {
        this.callerCadBaseConfig.callerCadQuickMessagesList = mQuickMessagesList
    }

    private fun updateRecyclerView() {

    }

    private fun handleMessageClick(message: String, isLongPress: Boolean) {
        if (isLongPress) {
            Toast.makeText(this, "Clicked: $message", Toast.LENGTH_SHORT).show()
        } else {
            showEditMessageDialog(message)
        }
    }

    private fun showEditMessageDialog(currentMessage: String) {
        val dialog =
            UpdateMessageDialog(this, object : UpdateMessageDialog.OnMessageActionListener {
                override fun onMessageUpdated(message: String) {
                    val index = mQuickMessagesList.indexOf(currentMessage)
                    if (index != -1) {
                        mQuickMessagesList[index] = message
                        adapter.notifyItemChanged(index)
                        updateAfterCallConfig()
                        Toast.makeText(
                            this@EditQuickMessagesActivity,
                            "Message Updated",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun onMessageDeleted() {
                    val index = mQuickMessagesList.indexOf(currentMessage)
                    if (index != -1) {
                        mQuickMessagesList.removeAt(index)
                        adapter.notifyItemRemoved(index)
                        updateAfterCallConfig()
                        Toast.makeText(
                            this@EditQuickMessagesActivity,
                            "Message Deleted",
                            Toast.LENGTH_SHORT
                        ).show()

                        if (mQuickMessagesList.isEmpty()) {
                            binding.noQuickMessagesText.visibility = View.VISIBLE
                        } else {
                            binding.noQuickMessagesText.visibility = View.GONE
                        }
                    }
                }
            }, currentMessage)

        dialog.show()
    }

    private fun getCallerMessages(context: Context): List<String> {
        return context.callerCadBaseConfig.callerCadQuickMessagesList
    }
}


