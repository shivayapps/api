package com.after.call.helpers

import android.content.Context
import android.text.format.DateFormat
import androidx.annotation.Keep
import androidx.core.content.ContextCompat
import com.after.call.R
import com.after.call.extensions.getSharedPrefs
import com.after.call.utils.AfterCallSuggestionAppDetail
import com.after.call.utils.CustomNativeValue
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.text.SimpleDateFormat

@Keep
open class AfterCallBaseConfig(val context: Context) {
    protected val prefs = context.getSharedPrefs()

    companion object {
        fun newInstance(context: Context) = AfterCallBaseConfig(context)
    }

    // Boolean Flags
    var callerCadPermissionDialogEnable: Boolean
        get() = prefs.getBoolean("CALLER_CAD_PERMISSION_DIALOG_ENABLE", true)
        set(value) = prefs.edit().putBoolean("CALLER_CAD_PERMISSION_DIALOG_ENABLE", value).apply()

    var callerCadPermissionDialogDismiss: Boolean
        get() = prefs.getBoolean("CALLER_CAD_PERMISSION_DIALOG_DISMISS", true)
        set(value) = prefs.edit().putBoolean("CALLER_CAD_PERMISSION_DIALOG_DISMISS", value).apply()

    var callerCadEnable: Boolean
        get() = prefs.getBoolean("CALLER_CAD_ENABLE", true)
        set(value) = prefs.edit().putBoolean("CALLER_CAD_ENABLE", value).apply()

    var callerCadAdEnable: Boolean
        get() = prefs.getBoolean("CALLER_CAD_AD_ENABLE", true)
        set(value) = prefs.edit().putBoolean("CALLER_CAD_AD_ENABLE", value).apply()

    // Other preferences (e.g., AdMob, Custom Native, etc.)
    var callerCadAdmobNativeEnable: Boolean
        get() = prefs.getBoolean("CALLER_CAD_ADMOB_NATIVE_ENABLE", true)
        set(value) = prefs.edit().putBoolean("CALLER_CAD_ADMOB_NATIVE_ENABLE", value).apply()


    var callerCadBackIcon: Int
        get() = prefs.getInt("CALLER_CAD_BACK_ICON", R.drawable.after_call_arrow_back_white)
        set(value) = prefs.edit().putInt("CALLER_CAD_BACK_ICON", value).apply()


    var callerCadCustomNativeEnable: Boolean
        get() = prefs.getBoolean("CALLER_CAD_CUSTOM_NATIVE_ENABLE", true)
        set(value) = prefs.edit().putBoolean("CALLER_CAD_CUSTOM_NATIVE_ENABLE", value).apply()

//    var callerCadCustomPredesignNativeEnable: Boolean
//        get() = prefs.getBoolean("CALLER_CAD_CUSTOM_PRE_DESIGN_NATIVE_ENABLE", true)
//        set(value) = prefs.edit().putBoolean("CALLER_CAD_CUSTOM_PRE_DESIGN_NATIVE_ENABLE", value)
//            .apply()

//    var callerCadCustomSuggestionNativeEnable: Boolean
//        get() = prefs.getBoolean("CALLER_CAD_CUSTOM_SUGGESTION_NATIVE_ENABLE", true)
//        set(value) = prefs.edit().putBoolean("CALLER_CAD_CUSTOM_SUGGESTION_NATIVE_ENABLE", value)
//            .apply()

    var callerCadAdmobBannerEnable: Boolean
        get() = prefs.getBoolean("CALLER_CAD_ADMOB_BANNER_ENABLE", true)
        set(value) = prefs.edit().putBoolean("CALLER_CAD_ADMOB_BANNER_ENABLE", value).apply()

    var callerCadAdmobSmallNativeEnable: Boolean
        get() = prefs.getBoolean("CALLER_CAD_ADMOB_SMALL_NATIVE_ENABLE", true)
        set(value) = prefs.edit().putBoolean("CALLER_CAD_ADMOB_SMALL_NATIVE_ENABLE", value).apply()

//    var callerCadCustomPreDesignBannerEnable: Boolean
//        get() = prefs.getBoolean("CALLER_CAD_CUSTOM_PRE_DESIGN_BANNER_ENABLE", true)
//        set(value) = prefs.edit().putBoolean("CALLER_CAD_CUSTOM_PRE_DESIGN_BANNER_ENABLE", value)
//            .apply()

    var callerCadQuickMessagesList: List<String>
        get() {
            val savedMessages = prefs.getString("CALLER_QUICK_MESSAGES", null)
            return savedMessages?.split("|")
                ?.map { it.trim() } // Remove leading/trailing whitespace
                ?.filter { it.isNotEmpty() } // Filter out empty messages
                ?: listOf(
                    "Please Call me back",
                    "Please call back when you are available",
                    "I called you, but could not reach you"
                )
        }
        set(value) {
            prefs.edit().putString(
                "CALLER_QUICK_MESSAGES",
                value.filter { it.isNotEmpty() }.joinToString("|")
            ).apply()
        }



    var callerCadNativeAdOrder: List<String>
        get() {
            val savedOrder = prefs.getString("CALLER_CAD_NATIVE_AD_ORDER", null)
            return savedOrder?.split(",") ?: listOf("admob", "custom")
        }
        set(value) {
            prefs.edit().putString("CALLER_CAD_NATIVE_AD_ORDER", value.joinToString(",")).apply()
        }

    var callerCadBannerAdsOrder: List<String>
        get() {
            val savedOrder = prefs.getString("CALLER_CAD_BANNER_ADS_ORDER", null)
            return savedOrder?.split(",") ?: listOf("banner", "native")
        }
        set(value) {
            prefs.edit().putString("CALLER_CAD_BANNER_ADS_ORDER", value.joinToString(",")).apply()
        }

    // Ad IDs
    var callerCadAdmobAdIdNative: String
        get() = prefs.getString("CALLER_CAD_ADMOB_AD_ID_NATIVE", "") ?: ""
        set(value) = prefs.edit().putString("CALLER_CAD_ADMOB_AD_ID_NATIVE", value).apply()

    var callerCadAdmobAdIdSmallNative: String
        get() = prefs.getString("CALLER_CAD_ADMOB_AD_ID_SMALL_NATIVE", "") ?: ""
        set(value) = prefs.edit().putString("CALLER_CAD_ADMOB_AD_ID_SMALL_NATIVE", value).apply()

    var callerCadAdmobAdIdBanner: String
        get() = prefs.getString("CALLER_CAD_ADMOB_AD_ID_BANNER", "") ?: ""
        set(value) = prefs.edit().putString("CALLER_CAD_ADMOB_AD_ID_BANNER", value).apply()


    var callerCadCustomNativeValues: List<CustomNativeValue>
        get() {
            val json = prefs.getString("CALLER_CAD_CUSTOM_NATIVE_VALUES", "[]") ?: "[]"
            val type = object : TypeToken<List<CustomNativeValue>>() {}.type
            return Gson().fromJson(json, type)
        }
        set(value) {
            val json = Gson().toJson(value)
            prefs.edit().putString("CALLER_CAD_CUSTOM_NATIVE_VALUES", json).apply()
        }


    // Suggestion Apps Details (List of AfterCallSuggestionAppDetail objects)
//    var callerCadCustomSuggestionAppsDetails: List<AfterCallSuggestionAppDetail>
//        get() {
//            val json = prefs.getString("CALLER_CAD_CUSTOM_SUGGESTION_APPS_DETAILS", "[]") ?: "[]"
//            val type = object : TypeToken<List<AfterCallSuggestionAppDetail>>() {}.type
//            return Gson().fromJson(json, type)
//        }
//        set(value) {
//            val json = Gson().toJson(value)
//            prefs.edit().putString("CALLER_CAD_CUSTOM_SUGGESTION_APPS_DETAILS", json).apply()
//        }

    // Predesign URLs
//    var callerCadCustomPredesignNativeUrl: String
//        get() = prefs.getString("CALLER_CAD_CUSTOM_PRE_DESIGN_NATIVE_URL", "") ?: ""
//        set(value) = prefs.edit().putString("CALLER_CAD_CUSTOM_PRE_DESIGN_NATIVE_URL", value)
//            .apply()

//    var callerCadCustomPredesignBannerUrl: String
//        get() = prefs.getString("CALLER_CAD_CUSTOM_PRE_DESIGN_BANNER_URL", "") ?: ""
//        set(value) = prefs.edit().putString("CALLER_CAD_CUSTOM_PRE_DESIGN_BANNER_URL", value)
//            .apply()


//    var callerCadCustomPredesignNativeClickUrl: String
//        get() = prefs.getString("CALLER_CAD_CUSTOM_PRE_DESIGN_NATIVE_CLICK_URL", "") ?: ""
//        set(value) = prefs.edit().putString("CALLER_CAD_CUSTOM_PRE_DESIGN_NATIVE_CLICK_URL", value)
//            .apply()

//    var callerCadCustomPredesignBannerClickUrl: String
//        get() = prefs.getString("CALLER_CAD_CUSTOM_PRE_DESIGN_BANNER_CLICK_URL", "") ?: ""
//        set(value) = prefs.edit().putString("CALLER_CAD_CUSTOM_PRE_DESIGN_BANNER_CLICK_URL", value)
//            .apply()


//    var callerCadCustomPredesignNativeClickUrlLaunchType: String
//        get() = prefs.getString("CALLER_CAD_CUSTOM_PRE_DESIGN_NATIVE_CLICK_URL_LAUNCH_TYPE", "")
//            ?: ""
//        set(value) = prefs.edit()
//            .putString("CALLER_CAD_CUSTOM_PRE_DESIGN_NATIVE_CLICK_URL_LAUNCH_TYPE", value)
//            .apply()

//    var callerCadCustomPredesignBannerClickUrlLaunchType: String
//        get() = prefs.getString("CALLER_CAD_CUSTOM_PRE_DESIGN_BANNER_CLICK_URL_LAUNCH_TYPE", "")
//            ?: ""
//        set(value) = prefs.edit()
//            .putString("CALLER_CAD_CUSTOM_PRE_DESIGN_BANNER_CLICK_URL_LAUNCH_TYPE", value)
//            .apply()



    var callerCadSelectedTheme: Int
        get() = prefs.getInt(CALLER_CAD_SELECTED_THEME, 0)
        set(textColor) = prefs.edit().putInt(CALLER_CAD_SELECTED_THEME, textColor).apply()

    var customizeInsideViewEnable: Boolean
        get() = prefs.getBoolean("CUSTOMIZE_INSIDE_VIEW_ENABLE", true)
        set(value) = prefs.edit().putBoolean("CUSTOMIZE_INSIDE_VIEW_ENABLE", value).apply()


    var callerCadAppOpenIcon: Int
        get() = prefs.getInt("CALLER_CAD_APP_OPEN_ICON", 0)
        set(value) = prefs.edit().putInt("CALLER_CAD_APP_OPEN_ICON", value).apply()


    var callerCadAppOpenDescription: String?
        get() = prefs.getString("CALLER_CAD_APP_OPEN_DESCRIPTION", "")
        set(value) = prefs.edit().putString("CALLER_CAD_APP_OPEN_DESCRIPTION", value).apply()


    var callerCadDeviceDetails: String?
        get() = prefs.getString("CALLER_CAD_DEVICE_DETAILS", "")
        set(value) = prefs.edit().putString("CALLER_CAD_DEVICE_DETAILS", value).apply()


    var lastFetchTime: Long
        get() = prefs.getLong("LAST_FETCH_TIME", 0L)
        set(value) = prefs.edit().putLong("LAST_FETCH_TIME", value).apply()


    var isShowCallInfo: Boolean
        get() = prefs.getBoolean(IS_SHOW_CALL_INFO, true)
        set(value) = prefs.edit().putBoolean(IS_SHOW_CALL_INFO, value).apply()

    var engageActivityClass: String?
        get() = prefs.getString(ENGAGE_ACTIVITY_CLASS_KEY, "")
        set(value) = prefs.edit().putString(ENGAGE_ACTIVITY_CLASS_KEY, value).apply()

    var customizeSettingDefaultText: String?
        get() = prefs.getString("CUSTOMIZE_SETTING_DEFAULT_TEXT", "")
        set(value) = prefs.edit().putString("CUSTOMIZE_SETTING_DEFAULT_TEXT", value).apply()

    var contactpermission: Boolean
        get() = prefs.getBoolean(CONTACT_PERMISSION_DATA, false)
        set(value) = prefs.edit().putBoolean(CONTACT_PERMISSION_DATA, value).apply()


    var callerCardDarkTheme: Boolean
        get() = prefs.getBoolean(CALLER_CAD_DARK_THEME, false)
        set(value) = prefs.edit().putBoolean(CALLER_CAD_DARK_THEME, value).apply()


    var callerCardAutoStartLater: Boolean
        get() = prefs.getBoolean(CALLER_CAD_AUTO_START_LATER, false)
        set(value) = prefs.edit().putBoolean(CALLER_CAD_AUTO_START_LATER, value).apply()


    var clickOnAutostartView: Boolean
        get() = prefs.getBoolean("clickOnView", false)
        set(value) = prefs.edit().putBoolean("clickOnView", value).apply()


    var callerCardAutoStartDontShowAgain: Boolean
        get() = prefs.getBoolean(CALLER_CAD_AUTO_START_DONT_SHOW_AGAIN, false)
        set(value) = prefs.edit().putBoolean(CALLER_CAD_AUTO_START_DONT_SHOW_AGAIN, value).apply()


    var callerCardAutoStartAllowed: Boolean
        get() = prefs.getBoolean(CALLER_CAD_AUTO_START_ALLOWED, false)
        set(value) = prefs.edit().putBoolean(CALLER_CAD_AUTO_START_ALLOWED, value).apply()


    var switchMissedCallSaved: Boolean
        get() = prefs.getBoolean(SWITCH_MISSED_CALL_SAVED, true)
        set(value) = prefs.edit().putBoolean(SWITCH_MISSED_CALL_SAVED, value).apply()


    var switchReminderSaved: Boolean
        get() = prefs.getBoolean(SWITCH_REMINDER_SAVED, true)
        set(value) = prefs.edit().putBoolean(SWITCH_REMINDER_SAVED, value).apply()

    var switchNoAnswerSaved: Boolean
        get() = prefs.getBoolean(SWITCH_NO_ANSWER_SAVED, true)
        set(value) = prefs.edit().putBoolean(SWITCH_NO_ANSWER_SAVED, value).apply()

    var switchCompletedCallSaved: Boolean
        get() = prefs.getBoolean(SWITCH_COMPLETED_CALL_SAVED, true)
        set(value) = prefs.edit().putBoolean(SWITCH_COMPLETED_CALL_SAVED, value).apply()

    var switchExtraContactSaved: Boolean
        get() = prefs.getBoolean(SWITCH_EXTRA_CONTACT_SAVED, false)
        set(value) = prefs.edit().putBoolean(SWITCH_EXTRA_CONTACT_SAVED, value).apply()


    var switchUnknownCallerSaved: Boolean
        get() = prefs.getBoolean(SWITCH_UNKNOWN_CALLER_SAVED, true)
        set(value) = prefs.edit().putBoolean(SWITCH_UNKNOWN_CALLER_SAVED, value).apply()

    var cadAdShownTotalCount: Int
        get() = prefs.getInt(CAD_AD_SHOWN_TOTAL_COUNT, 0)
        set(value) = prefs.edit().putInt(CAD_AD_SHOWN_TOTAL_COUNT, value).apply()

    var cadAdImpressionTotalCountNative: Int
        get() = prefs.getInt(CAD_AD_IMPRESSION_TOTAL_COUNT, 0)
        set(value) = prefs.edit().putInt(CAD_AD_IMPRESSION_TOTAL_COUNT, value).apply()

    var cadAdImpressionTotalCountBanner: Int
        get() = prefs.getInt("CAD_AD_IMPRESSION_BANNER_TOTAL_COUNT", 0)
        set(value) = prefs.edit().putInt("CAD_AD_IMPRESSION_BANNER_TOTAL_COUNT", value).apply()

    var cadAdImpressionTotalCountSmallNativeBanner: Int
        get() = prefs.getInt("CAD_AD_IMPRESSION_SMALL_NATIVE_BANNER_TOTAL_COUNT", 0)
        set(value) = prefs.edit().putInt("CAD_AD_IMPRESSION_SMALL_NATIVE_BANNER_TOTAL_COUNT", value)
            .apply()


    // Save ArrayList<String> to SharedPreferences
    fun saveList(context: Context, stringArrayList: ArrayList<String>) {
        val sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()

        val stringSet = HashSet(stringArrayList)
        editor.putStringSet(RECENT_MSG, stringSet)

        editor.apply()
    }

    fun retrieveList(context: Context): ArrayList<String> {
        val sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val stringSet = sharedPreferences.getStringSet(RECENT_MSG, null)
        stringSet?.reversed()
        return if (stringSet == null) {
            ArrayList() // Return empty ArrayList if no data found
        } else {
            ArrayList(stringSet)
        }
    }


    var textColor: Int
        get() = prefs.getInt(
            TEXT_COLOR,
            context.resources.getColor(R.color.after_call_black)
        )
        set(textColor) = prefs.edit().putInt(TEXT_COLOR, textColor).apply()

    var statusBarColor: Int
        get() = prefs.getInt(
            STATUS_BG_COLOR,
            ContextCompat.getColor(context, R.color.after_call_white)
        )
        set(textColor) = prefs.edit().putInt(STATUS_BG_COLOR, textColor).apply()

    var backgroundColor: Int
        get() = prefs.getInt(
            BACKGROUND_COLOR,
            context.resources.getColor(R.color.after_call_white)
        )
        set(backgroundColor) = prefs.edit().putInt(BACKGROUND_COLOR, backgroundColor).apply()

    var primaryColor: Int
        get() = prefs.getInt(
            PRIMARY_COLOR,
            context.resources.getColor(R.color.after_call_selectedColor)
        )
        set(primaryColor) = prefs.edit().putInt(PRIMARY_COLOR, primaryColor).apply()

    var use24HourFormat: Boolean
        get() = prefs.getBoolean(USE_24_HOUR_FORMAT, DateFormat.is24HourFormat(context))
        set(use24HourFormat) = prefs.edit().putBoolean(USE_24_HOUR_FORMAT, use24HourFormat).apply()


    var dateFormat: String
        get() = prefs.getString(DATE_FORMAT, getDefaultDateFormat())!!
        set(dateFormat) = prefs.edit().putString(DATE_FORMAT, dateFormat).apply()

    private fun getDefaultDateFormat(): String {
        val format = DateFormat.getDateFormat(context)
        val pattern = (format as SimpleDateFormat).toLocalizedPattern()
        return when (pattern.lowercase().replace(" ", "")) {
            "d.M.y" -> DATE_FORMAT_ONE
            "dd/mm/y" -> DATE_FORMAT_TWO
            "mm/dd/y" -> DATE_FORMAT_THREE
            "y-mm-dd" -> DATE_FORMAT_FOUR
            "dmmmmy" -> DATE_FORMAT_FIVE
            "mmmmdy" -> DATE_FORMAT_SIX
            "mm-dd-y" -> DATE_FORMAT_SEVEN
            "dd-mm-y" -> DATE_FORMAT_EIGHT
            else -> DATE_FORMAT_ONE
        }
    }

    var textCursorColor: Int
        get() = prefs.getInt(TEXT_CURSOR_COLOR, -2)
        set(textCursorColor) = prefs.edit().putInt(TEXT_CURSOR_COLOR, textCursorColor).apply()

}


