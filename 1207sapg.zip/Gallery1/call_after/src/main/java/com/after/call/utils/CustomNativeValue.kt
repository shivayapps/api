package com.after.call.utils

import androidx.annotation.Keep


@Keep
data class CustomNativeValue(
    val appTitle: String,
    val appDes: String,
    val appIcon: String,
    val appBanner: String,
    val appButtonText: String = "Install",
    val appUrl: String,
    val launch_type: String,
)