package com.after.call.extensions

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.TelecomManager
import android.text.TextUtils
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.Keep
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
import com.after.call.AfterCallUtils
import com.after.call.R
import com.after.call.bottom_dialog.AutoStartPermissionDialog
import com.after.call.helpers.CALLER_CAD_PREFS_KEY
import com.after.call.helpers.CALLER_CAD_REMOTE_CONFIG
import com.after.call.helpers.AfterCallBaseConfig
import com.after.call.helpers.TIME_FORMAT_12
import com.after.call.helpers.TIME_FORMAT_24
import com.after.call.utils.AfterCallGridItem
import com.after.call.utils.AfterCallSuggestionAppDetail
import com.after.call.utils.CallerEventsConstants
import com.after.call.utils.CallerThemeColors
import com.after.call.utils.CustomNativeValue
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import org.json.JSONObject


//val callerCadThemeList = listOf(
//    AfterCallGridItem(
//        "AfterCallTheme1",
//        R.drawable.ic_after_call_theme_style1,
//        R.drawable.ic_after_call_theme_bg_style1,
//        R.color.ic_after_call_theme_style1_color_top,
//        R.color.ic_after_call_theme_style1_color_bottom,
//        R.color.ic_after_call_theme_style1_btn_color
//    ),
//    AfterCallGridItem(
//        "AfterCallTheme2",
//        R.drawable.ic_after_call_theme_style2,
//        R.drawable.ic_after_call_theme_bg_style1,
//        R.color.ic_after_call_theme_style2_color_top,
//        R.color.ic_after_call_theme_style2_color_bottom,
//        R.color.ic_after_call_theme_style2_btn_color
//    ),
//    AfterCallGridItem(
//        "AfterCallTheme3",
//        R.drawable.ic_after_call_theme_style3,
//        R.drawable.ic_after_call_theme_bg_style3,
//        R.color.ic_after_call_theme_style3_color_top,
//        R.color.ic_after_call_theme_style3_color_bottom,
//        R.color.ic_after_call_theme_style3_btn_color
//    ),
//    AfterCallGridItem(
//        "AfterCallTheme4",
//        R.drawable.ic_after_call_theme_style4,
//        R.drawable.ic_after_call_theme_bg_style4,
//        R.color.ic_after_call_theme_style4_color_top,
//        R.color.ic_after_call_theme_style4_color_bottom,
//        R.color.ic_after_call_theme_style4_btn_color
//    ),
//    AfterCallGridItem(
//        "AfterCallTheme5",
//        R.drawable.ic_after_call_theme_style5,
//        R.drawable.ic_after_call_theme_bg_style5,
//        R.color.ic_after_call_theme_style5_color_top,
//        R.color.ic_after_call_theme_style5_color_bottom,
//        R.color.ic_after_call_theme_style5_btn_color
//    ),
//    AfterCallGridItem(
//        "AfterCallTheme6",
//        R.drawable.ic_after_call_theme_style6,
//        R.drawable.ic_after_call_theme_bg_style6,
//        R.color.ic_after_call_theme_style6_color_top,
//        R.color.ic_after_call_theme_style6_color_bottom,
//        R.color.ic_after_call_theme_style6_btn_color
//    ),
//    AfterCallGridItem(
//        "AfterCallTheme7",
//        R.drawable.ic_after_call_theme_style7,
//        R.drawable.ic_after_call_theme_bg_style7,
//        R.color.ic_after_call_theme_style7_color_top,
//        R.color.ic_after_call_theme_style7_color_bottom,
//        R.color.ic_after_call_theme_style7_btn_color
//    ),
//    AfterCallGridItem(
//        "AfterCallTheme8",
//        R.drawable.ic_after_call_theme_style8,
//        R.drawable.ic_after_call_theme_bg_style8,
//        R.color.ic_after_call_theme_style8_color_top,
//        R.color.ic_after_call_theme_style8_color_bottom,
//        R.color.ic_after_call_theme_style8_btn_color
//    )
//)

fun Context.getSharedPrefs() = getSharedPreferences(CALLER_CAD_PREFS_KEY, Context.MODE_PRIVATE)
val Context.callerCadBaseConfig: AfterCallBaseConfig get() = AfterCallBaseConfig.newInstance(this)
val Context.telecomManager: TelecomManager get() = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
fun Context.getTimeFormat() =
    if (callerCadBaseConfig.use24HourFormat) TIME_FORMAT_24 else TIME_FORMAT_12

fun Context.getProperTextColor() = callerCadBaseConfig.textColor

fun Context.getProperBackgroundColor() = callerCadBaseConfig.backgroundColor
fun Context.getProperPrimaryColor() = callerCadBaseConfig.primaryColor
fun Context.getProperTextCursorColor() = callerCadBaseConfig.textCursorColor


var callerCurrentTheme: CallerThemeColors = CallerThemeColors.DEFAULT

//@Keep
//fun fetchAfterCallRemoteOld(
//    context: Context,
//    setMinimumFetchIntervalInSeconds: Long,
//    callback: () -> Unit,
//) {
//
//    Log.d(
//        "RemoteConfigData",
//        "----------------START-------------------------------"
//    )
//    val remoteConfig = FirebaseRemoteConfig.getInstance()
//
//    remoteConfig.setConfigSettingsAsync(
//        FirebaseRemoteConfigSettings.Builder()
//            .setMinimumFetchIntervalInSeconds(setMinimumFetchIntervalInSeconds)
//            .setFetchTimeoutInSeconds(0)
//            .build()
//    )
//    remoteConfig.reset()
//    remoteConfig.fetchAndActivate()
//        .addOnCompleteListener { task ->
//            if (task.isSuccessful) {
//
//                val remoteConfigData = remoteConfig.getString(CALLER_CAD_REMOTE_CONFIG)
//
//                if (remoteConfigData.isNotEmpty()) {
//
//                    try {
//                        val remoteJSON = JSONObject(remoteConfigData)
//
//                        try {
//                            context.callerCadBaseConfig.callerCadPermissionDialogEnable =
//                                remoteJSON.optBoolean("caller_cad_permission_dialog_enable", false)
//                            Log.d(
//                                "RemoteConfigData",
//                                "caller_cad_permission_dialog_enable: ${context.callerCadBaseConfig.callerCadPermissionDialogEnable}"
//                            )
//                        } catch (e: Exception) {
//                            Log.e(
//                                "RemoteConfigData",
//                                "RemoteConfigError - failed: ${task.exception?.message}"
//                            )
//                        }
//
//                        try {
//                            context.callerCadBaseConfig.callerCadPermissionDialogDismiss =
//                                remoteJSON.optBoolean("caller_cad_permission_dialog_dismiss", false)
//                            Log.d(
//                                "RemoteConfigData",
//                                "caller_cad_permission_dialog_dismiss: ${context.callerCadBaseConfig.callerCadPermissionDialogDismiss}"
//                            )
//                        } catch (e: Exception) {
//                            Log.e(
//                                "RemoteConfigData",
//                                "RemoteConfigError - failed: ${task.exception?.message}"
//                            )
//                        }
//
//                        try {
//                            context.callerCadBaseConfig.callerCadEnable =
//                                remoteJSON.optBoolean("caller_cad_enable", false)
//                            Log.d(
//                                "RemoteConfigData",
//                                "caller_cad_enable: ${context.callerCadBaseConfig.callerCadEnable}"
//                            )
//                        } catch (e: Exception) {
//                            Log.e(
//                                "RemoteConfigData",
//                                "RemoteConfigError - failed: ${task.exception?.message}"
//                            )
//                        }
//
//                        try {
//                            context.callerCadBaseConfig.callerCadAdEnable =
//                                remoteJSON.optBoolean("caller_cad_ad_enable", false)
//                            Log.d(
//                                "RemoteConfigData",
//                                "caller_cad_ad_enable: ${context.callerCadBaseConfig.callerCadAdEnable}"
//                            )
//                        } catch (e: Exception) {
//                            Log.e(
//                                "RemoteConfigData",
//                                "RemoteConfigError - failed: ${task.exception?.message}"
//                            )
//                        }
//
//                        try {
//                            context.callerCadBaseConfig.callerCadAdmobNativeEnable =
//                                remoteJSON.optBoolean("caller_cad_admob_native_enable", false)
//                            Log.d(
//                                "RemoteConfigData",
//                                "caller_cad_admob_native_enable: ${context.callerCadBaseConfig.callerCadAdmobNativeEnable}"
//                            )
//                        } catch (e: Exception) {
//                            Log.e(
//                                "RemoteConfigData",
//                                "RemoteConfigError - failed: ${task.exception?.message}"
//                            )
//                        }
//
//                        try {
//                            context.callerCadBaseConfig.callerCadCustomNativeEnable =
//                                remoteJSON.optBoolean("caller_cad_custom_native_enable", false)
//                            Log.d(
//                                "RemoteConfigData",
//                                "caller_cad_custom_native_enable: ${context.callerCadBaseConfig.callerCadCustomNativeEnable}"
//                            )
//                        } catch (e: Exception) {
//                            Log.e(
//                                "RemoteConfigData",
//                                "RemoteConfigError - failed: ${task.exception?.message}"
//                            )
//                        }
//
//                        try {
//                            context.callerCadBaseConfig.callerCadCustomPredesignNativeEnable =
//                                remoteJSON.optBoolean(
//                                    "caller_cad_custom_predesign_native_enable",
//                                    false
//                                )
//                            Log.d(
//                                "RemoteConfigData",
//                                "caller_cad_custom_predesign_native_enable: ${context.callerCadBaseConfig.callerCadCustomPredesignNativeEnable}"
//                            )
//                        } catch (e: Exception) {
//                            Log.e(
//                                "RemoteConfigData",
//                                "RemoteConfigError - failed: ${task.exception?.message}"
//                            )
//                        }
//
//                        try {
//                            context.callerCadBaseConfig.callerCadCustomSuggestionNativeEnable =
//                                remoteJSON.optBoolean(
//                                    "caller_cad_custom_suggestion_native_enable",
//                                    false
//                                )
//                            Log.d(
//                                "RemoteConfigData",
//                                "caller_cad_custom_suggestion_native_enable: ${context.callerCadBaseConfig.callerCadCustomSuggestionNativeEnable}"
//                            )
//                        } catch (e: Exception) {
//                            Log.e(
//                                "RemoteConfigData",
//                                "RemoteConfigError - failed: ${task.exception?.message}"
//                            )
//                        }
//
//                        try {
//                            context.callerCadBaseConfig.callerCadAdmobBannerEnable =
//                                remoteJSON.optBoolean("caller_cad_admob_banner_enable", false)
//                            Log.d(
//                                "RemoteConfigData",
//                                "caller_cad_admob_banner_enable: ${context.callerCadBaseConfig.callerCadAdmobBannerEnable}"
//                            )
//                        } catch (e: Exception) {
//                            Log.e(
//                                "RemoteConfigData",
//                                "RemoteConfigError - failed: ${task.exception?.message}"
//                            )
//                        }
//
//                        try {
//                            context.callerCadBaseConfig.callerCadAdmobSmallNativeEnable =
//                                remoteJSON.optBoolean("caller_cad_admob_small_native_enable", false)
//                            Log.d(
//                                "RemoteConfigData",
//                                "caller_cad_admob_small_native_enable: ${context.callerCadBaseConfig.callerCadAdmobSmallNativeEnable}"
//                            )
//                        } catch (e: Exception) {
//                            Log.e(
//                                "RemoteConfigData",
//                                "RemoteConfigError - failed: ${task.exception?.message}"
//                            )
//                        }
//
//                        try {
//                            context.callerCadBaseConfig.callerCadCustomPreDesignBannerEnable =
//                                remoteJSON.optBoolean(
//                                    "caller_cad_custom_predesign_banner_enable",
//                                    false
//                                )
//                            Log.d(
//                                "RemoteConfigData",
//                                "caller_cad_custom_predesign_banner_enable: ${context.callerCadBaseConfig.callerCadCustomPreDesignBannerEnable}"
//                            )
//                        } catch (e: Exception) {
//                            Log.e(
//                                "RemoteConfigData",
//                                "RemoteConfigError - failed: ${task.exception?.message}"
//                            )
//                        }
//
//                        try {// Arrays (ensure data is valid)
//                            context.callerCadBaseConfig.callerCadNativeAdOrder =
//                                remoteJSON.optJSONArray("caller_cad_native_ad_order")
//                                    ?.let { jsonArray ->
//                                        List(jsonArray.length()) { jsonArray.getString(it) }
//                                    } ?: listOf("admob", "custom", "url", "suggest")
//                            Log.d(
//                                "RemoteConfigData",
//                                "caller_cad_native_ad_order: ${context.callerCadBaseConfig.callerCadNativeAdOrder}"
//                            )
//                        } catch (e: Exception) {
//                            Log.e(
//                                "RemoteConfigData",
//                                "RemoteConfigError - failed: ${task.exception?.message}"
//                            )
//                        }
//
//                        try {
//                            context.callerCadBaseConfig.callerCadBannerAdsOrder =
//                                remoteJSON.optJSONArray("caller_cad_banner_ad_order")
//                                    ?.let { jsonArray ->
//                                        List(jsonArray.length()) { jsonArray.getString(it) }
//                                    } ?: listOf("banner", "native", "url")
//
//                            Log.d(
//                                "RemoteConfigData",
//                                "caller_cad_banner_ad_order: ${
//                                    remoteJSON.optJSONArray("caller_cad_banner_ad_order")
//                                        ?.let { jsonArray ->
//                                            List(jsonArray.length()) { jsonArray.getString(it) }
//                                        } ?: listOf("banner", "native", "url")
//                                }"
//                            )
//
//                            Log.d(
//                                "RemoteConfigData",
//                                "caller_cad_banner_ad_order: ${context.callerCadBaseConfig.callerCadBannerAdsOrder}"
//                            )
//                        } catch (e: Exception) {
//                            Log.e(
//                                "RemoteConfigData",
//                                "RemoteConfigError - failed: ${task.exception?.message}"
//                            )
//                        }
//
//                        try {
//                            context.callerCadBaseConfig.callerCadAdmobAdIdNative =
//                                remoteJSON.optString("caller_cad_admob_ad_id_native", "")
//                            Log.d(
//                                "RemoteConfigData",
//                                "caller_cad_admob_ad_id_native: ${context.callerCadBaseConfig.callerCadAdmobAdIdNative}"
//                            )
//                        } catch (e: Exception) {
//                            Log.e(
//                                "RemoteConfigData",
//                                "RemoteConfigError - failed: ${task.exception?.message}"
//                            )
//                        }
//
//                        try {
//                            context.callerCadBaseConfig.callerCadAdmobAdIdSmallNative =
//                                remoteJSON.optString("caller_cad_admob_ad_id_small_native", "")
//                            Log.d(
//                                "RemoteConfigData",
//                                "caller_cad_admob_ad_id_small_native: ${context.callerCadBaseConfig.callerCadAdmobAdIdSmallNative}"
//                            )
//                        } catch (e: Exception) {
//                            Log.e(
//                                "RemoteConfigData",
//                                "RemoteConfigError - failed: ${task.exception?.message}"
//                            )
//                        }
//
//                        try {
//                            context.callerCadBaseConfig.callerCadAdmobAdIdBanner =
//                                remoteJSON.optString("caller_cad_admob_ad_id_banner", "")
//                            Log.d(
//                                "RemoteConfigData",
//                                "caller_cad_admob_ad_id_banner: ${context.callerCadBaseConfig.callerCadAdmobAdIdBanner}"
//                            )
//                        } catch (e: Exception) {
//                            Log.e(
//                                "RemoteConfigData",
//                                "RemoteConfigError - failed: ${task.exception?.message}"
//                            )
//                        }
//
//                        try {// Custom native values
//                            context.callerCadBaseConfig.callerCadCustomNativeValues =
//                                remoteJSON.optJSONArray("caller_cad_custom_native_values")
//                                    ?.let { jsonArray ->
//                                        List(jsonArray.length()) {
//                                            val item = jsonArray.getJSONObject(it)
//                                            CustomNativeValue(
//                                                appTitle = item.optString("app_title", ""),
//                                                appDes = item.optString("app_des", ""),
//                                                appIcon = item.optString("app_icon", ""),
//                                                appBanner = item.optString("app_banner", ""),
//                                                appButtonText = item.optString(
//                                                    "app_button_text",
//                                                    ""
//                                                ),
//                                                appUrl = item.optString("app_url", ""),
//                                                launch_type = item.optString("launch_type", "")
//                                            ).apply {
//                                                Log.d(
//                                                    "RemoteConfigData",
//                                                    "CustomNativeValue appTitle: $appTitle"
//                                                )
//                                                Log.d(
//                                                    "RemoteConfigData",
//                                                    "CustomNativeValue appDes: $appDes"
//                                                )
//                                                Log.d(
//                                                    "RemoteConfigData",
//                                                    "CustomNativeValue appIcon: $appIcon"
//                                                )
//                                                Log.d(
//                                                    "RemoteConfigData",
//                                                    "CustomNativeValue appBanner: $appBanner"
//                                                )
//                                                Log.d(
//                                                    "RemoteConfigData",
//                                                    "CustomNativeValue appUrl: $appUrl"
//                                                )
//                                                Log.d(
//                                                    "RemoteConfigData",
//                                                    "CustomNativeValue launch_type: $launch_type"
//                                                )
//                                            }
//                                        }
//                                    } ?: emptyList()
//                        } catch (e: Exception) {
//
//                            Log.e(
//                                "RemoteConfigData",
//                                "RemoteConfigError - failed: ${task.exception?.message}"
//                            )
//                        }
//
//                        try {// Suggestion apps details
//                            context.callerCadBaseConfig.callerCadCustomSuggestionAppsDetails =
//                                remoteJSON.optJSONArray("caller_cad_custom_suggestion_apps_details")
//                                    ?.let { jsonArray ->
//                                        List(jsonArray.length()) {
//                                            val item = jsonArray.getJSONObject(it)
//                                            AfterCallSuggestionAppDetail(
//                                                appTitle = item.optString("app_title", ""),
//                                                appDes = item.optString("app_des", ""),
//                                                appIcon = item.optString("app_icon", ""),
//                                                appBanner = item.optString("app_banner", ""),
//                                                appUrl = item.optString("app_url", ""),
//                                                launchType = item.optString("launch_type", "")
//                                            ).apply {
//                                                Log.d(
//                                                    "RemoteConfigData",
//                                                    "AfterCallSuggestionAppDetail appTitle: $appTitle"
//                                                )
//                                                Log.d(
//                                                    "RemoteConfigData",
//                                                    "AfterCallSuggestionAppDetail appDes: $appDes"
//                                                )
//                                                Log.d(
//                                                    "RemoteConfigData",
//                                                    "AfterCallSuggestionAppDetail appIcon: $appIcon"
//                                                )
//                                                Log.d(
//                                                    "RemoteConfigData",
//                                                    "AfterCallSuggestionAppDetail appBanner: $appBanner"
//                                                )
//                                                Log.d(
//                                                    "RemoteConfigData",
//                                                    "AfterCallSuggestionAppDetail appUrl: $appUrl"
//                                                )
//                                                Log.d(
//                                                    "RemoteConfigData",
//                                                    "AfterCallSuggestionAppDetail launch_type: $launchType"
//                                                )
//                                            }
//                                        }
//                                    } ?: emptyList()
//                        } catch (e: Exception) {
//                            Log.e(
//                                "RemoteConfigData",
//                                "RemoteConfigError - failed: ${task.exception?.message}"
//                            )
//                        }
//                        handleAdUrl(
//                            remoteJSON,
//                            context,
//                            "native",
//                            "caller_cad_custom_predesign_native_url"
//                        )
//                        handleAdUrl(
//                            remoteJSON,
//                            context,
//                            "banner",
//                            "caller_cad_custom_predesign_banner_url"
//                        )
//
//
//                    } catch (e: Exception) {
//                        e.printStackTrace()
//                        Log.e(
//                            "RemoteConfigData",
//                            "RemoteConfigError - Error processing remote config data",
//                            e
//                        )
//                    }
//                } else {
//                    Log.e("RemoteConfigError", "Remote config data is empty or null")
//                }
//
//
//            } else {
//                Log.e(
//                    "RemoteConfigData",
//                    "RemoteConfigError - Fetch failed: ${task.exception?.message}"
//                )
//            }
//
//            Log.d(
//                "RemoteConfigData",
//                "----------------STOP-------------------------------"
//            )
//
//            // Callback after processing
//            callback.invoke()
//        }
//
//
//}

@Keep
fun fetchAfterCallRemote(
    context: Context,
    setMinimumFetchIntervalInSeconds: Long,
    callback: () -> Unit,
) {

    Log.d(
        "RemoteConfigData",
        "----------------START-------------------------------"
    )
    val remoteConfig = FirebaseRemoteConfig.getInstance()
    val remoteConfigData = remoteConfig.getString(CALLER_CAD_REMOTE_CONFIG)
//    val remoteConfigData = readJsonFromAssets(context, "call_after_debug.json")

    if (remoteConfigData.isNotEmpty()) {
        try {
            val remoteJSON = JSONObject(remoteConfigData)

            try {
                context.callerCadBaseConfig.callerCadPermissionDialogEnable =
                    remoteJSON.optBoolean("after_call_permission_dialog_enable", false)
                Log.d(
                    "RemoteConfigData",
                    "after_call_permission_dialog_enable: ${context.callerCadBaseConfig.callerCadPermissionDialogEnable}"
                )
            } catch (e: Exception) {
                Log.e(
                    "RemoteConfigData",
                    "RemoteConfigError - failed: ${e?.message}"
                )
            }

            try {
                context.callerCadBaseConfig.callerCadPermissionDialogDismiss =
                    remoteJSON.optBoolean("after_call_permission_dialog_dismiss", false)
                Log.d(
                    "RemoteConfigData",
                    "after_call_permission_dialog_dismiss: ${context.callerCadBaseConfig.callerCadPermissionDialogDismiss}"
                )
            } catch (e: Exception) {
                Log.e(
                    "RemoteConfigData",
                    "RemoteConfigError - failed: ${e?.message}"
                )
            }

            try {
                context.callerCadBaseConfig.callerCadEnable =
                    remoteJSON.optBoolean("after_call_enable", false)
                Log.d(
                    "RemoteConfigData",
                    "after_call_enable: ${context.callerCadBaseConfig.callerCadEnable}"
                )
            } catch (e: Exception) {
                Log.e(
                    "RemoteConfigData",
                    "RemoteConfigError - failed: ${e?.message}"
                )
            }

            try {
                context.callerCadBaseConfig.callerCadAdEnable =
                    remoteJSON.optBoolean("after_call_ad_enable", false)
                Log.d(
                    "RemoteConfigData",
                    "after_call_ad_enable: ${context.callerCadBaseConfig.callerCadAdEnable}"
                )
            } catch (e: Exception) {
                Log.e(
                    "RemoteConfigData",
                    "RemoteConfigError - failed: ${e?.message}"
                )
            }

            try {
                context.callerCadBaseConfig.callerCadAdmobNativeEnable =
                    remoteJSON.optBoolean("after_call_admob_native_enable", false)
                Log.d(
                    "RemoteConfigData",
                    "after_call_admob_native_enable: ${context.callerCadBaseConfig.callerCadAdmobNativeEnable}"
                )
            } catch (e: Exception) {
                Log.e(
                    "RemoteConfigData",
                    "RemoteConfigError - failed: ${e?.message}"
                )
            }

            try {
                context.callerCadBaseConfig.callerCadCustomNativeEnable =
                    remoteJSON.optBoolean("after_call_custom_native_enable", false)
                Log.d(
                    "RemoteConfigData",
                    "after_call_custom_native_enable: ${context.callerCadBaseConfig.callerCadCustomNativeEnable}"
                )
            } catch (e: Exception) {
                Log.e(
                    "RemoteConfigData",
                    "RemoteConfigError - failed: ${e?.message}"
                )
            }

//            try {
//                context.callerCadBaseConfig.callerCadCustomPredesignNativeEnable =
//                    remoteJSON.optBoolean(
//                        "after_call_custom_predesign_native_enable",
//                        false
//                    )
//                Log.d(
//                    "RemoteConfigData",
//                    "after_call_custom_predesign_native_enable: ${context.callerCadBaseConfig.callerCadCustomPredesignNativeEnable}"
//                )
//            } catch (e: Exception) {
//                Log.e(
//                    "RemoteConfigData",
//                    "RemoteConfigError - failed: ${e?.message}"
//                )
//            }

//            try {
//                context.callerCadBaseConfig.callerCadCustomSuggestionNativeEnable =
//                    remoteJSON.optBoolean(
//                        "after_call_custom_suggestion_native_enable",
//                        false
//                    )
//                Log.d(
//                    "RemoteConfigData",
//                    "after_call_custom_suggestion_native_enable: ${context.callerCadBaseConfig.callerCadCustomSuggestionNativeEnable}"
//                )
//            } catch (e: Exception) {
//                Log.e(
//                    "RemoteConfigData",
//                    "RemoteConfigError - failed: ${e?.message}"
//                )
//            }

            try {
                context.callerCadBaseConfig.callerCadAdmobBannerEnable =
                    remoteJSON.optBoolean("after_call_admob_banner_enable", false)
                Log.d(
                    "RemoteConfigData",
                    "after_call_admob_banner_enable: ${context.callerCadBaseConfig.callerCadAdmobBannerEnable}"
                )
            } catch (e: Exception) {
                Log.e(
                    "RemoteConfigData",
                    "RemoteConfigError - failed: ${e?.message}"
                )
            }

            try {
                context.callerCadBaseConfig.callerCadAdmobSmallNativeEnable =
                    remoteJSON.optBoolean("after_call_admob_small_native_enable", false)
                Log.d(
                    "RemoteConfigData",
                    "after_call_admob_small_native_enable: ${context.callerCadBaseConfig.callerCadAdmobSmallNativeEnable}"
                )
            } catch (e: Exception) {
                Log.e(
                    "RemoteConfigData",
                    "RemoteConfigError - failed: ${e?.message}"
                )
            }

//            try {
//                context.callerCadBaseConfig.callerCadCustomPreDesignBannerEnable =
//                    remoteJSON.optBoolean(
//                        "after_call_custom_predesign_banner_enable",
//                        false
//                    )
//                Log.d(
//                    "RemoteConfigData",
//                    "after_call_custom_predesign_banner_enable: ${context.callerCadBaseConfig.callerCadCustomPreDesignBannerEnable}"
//                )
//            } catch (e: Exception) {
//                Log.e(
//                    "RemoteConfigData",
//                    "RemoteConfigError - failed: ${e?.message}"
//                )
//            }

            try {// Arrays (ensure data is valid)
                context.callerCadBaseConfig.callerCadNativeAdOrder =
                    remoteJSON.optJSONArray("after_call_native_ad_order")
                        ?.let { jsonArray ->
                            List(jsonArray.length()) { jsonArray.getString(it) }
                        } ?: listOf("admob", "custom")
                Log.d(
                    "RemoteConfigData",
                    "after_call_native_ad_order: ${context.callerCadBaseConfig.callerCadNativeAdOrder}"
                )
            } catch (e: Exception) {
                Log.e(
                    "RemoteConfigData",
                    "RemoteConfigError - failed: ${e?.message}"
                )
            }

            try {
                context.callerCadBaseConfig.callerCadBannerAdsOrder =
                    remoteJSON.optJSONArray("after_call_banner_ad_order")
                        ?.let { jsonArray ->
                            List(jsonArray.length()) { jsonArray.getString(it) }
                        } ?: listOf("banner", "native")

                Log.d(
                    "RemoteConfigData",
                    "after_call_banner_ad_order: ${
                        remoteJSON.optJSONArray("after_call_banner_ad_order")
                            ?.let { jsonArray ->
                                List(jsonArray.length()) { jsonArray.getString(it) }
                            } ?: listOf("banner", "native")
                    }"
                )

                Log.d(
                    "RemoteConfigData",
                    "after_call_banner_ad_order: ${context.callerCadBaseConfig.callerCadBannerAdsOrder}"
                )
            } catch (e: Exception) {
                Log.e(
                    "RemoteConfigData",
                    "RemoteConfigError - failed: ${e?.message}"
                )
            }

            try {
                context.callerCadBaseConfig.callerCadAdmobAdIdNative =
                    remoteJSON.optString("after_call_admob_ad_id_native", "")
                Log.d(
                    "RemoteConfigData",
                    "after_call_admob_ad_id_native: ${context.callerCadBaseConfig.callerCadAdmobAdIdNative}"
                )
            } catch (e: Exception) {
                Log.e(
                    "RemoteConfigData",
                    "RemoteConfigError - failed: ${e?.message}"
                )
            }

            try {
                context.callerCadBaseConfig.callerCadAdmobAdIdSmallNative =
                    remoteJSON.optString("after_call_admob_ad_id_small_native", "")
                Log.d(
                    "RemoteConfigData",
                    "after_call_admob_ad_id_small_native: ${context.callerCadBaseConfig.callerCadAdmobAdIdSmallNative}"
                )
            } catch (e: Exception) {
                Log.e(
                    "RemoteConfigData",
                    "RemoteConfigError - failed: ${e?.message}"
                )
            }

            try {
                context.callerCadBaseConfig.callerCadAdmobAdIdBanner =
                    remoteJSON.optString("after_call_admob_ad_id_banner", "")
                Log.d(
                    "RemoteConfigData",
                    "after_call_admob_ad_id_banner: ${context.callerCadBaseConfig.callerCadAdmobAdIdBanner}"
                )
            } catch (e: Exception) {
                Log.e(
                    "RemoteConfigData",
                    "RemoteConfigError - failed: ${e?.message}"
                )
            }

            try {// Custom native values
                context.callerCadBaseConfig.callerCadCustomNativeValues =
                    remoteJSON.optJSONArray("after_call_custom_native_values")
                        ?.let { jsonArray ->
                            List(jsonArray.length()) {
                                val item = jsonArray.getJSONObject(it)
                                CustomNativeValue(
                                    appTitle = item.optString("app_title", ""),
                                    appDes = item.optString("app_des", ""),
                                    appIcon = item.optString("app_icon", ""),
                                    appBanner = item.optString("app_banner", ""),
                                    appButtonText = item.optString(
                                        "app_button_text",
                                        ""
                                    ),
                                    appUrl = item.optString("app_url", ""),
                                    launch_type = item.optString("launch_type", "")
                                ).apply {
                                    Log.d(
                                        "RemoteConfigData",
                                        "CustomNativeValue appTitle: $appTitle"
                                    )
                                    Log.d(
                                        "RemoteConfigData",
                                        "CustomNativeValue appDes: $appDes"
                                    )
                                    Log.d(
                                        "RemoteConfigData",
                                        "CustomNativeValue appIcon: $appIcon"
                                    )
                                    Log.d(
                                        "RemoteConfigData",
                                        "CustomNativeValue appBanner: $appBanner"
                                    )
                                    Log.d(
                                        "RemoteConfigData",
                                        "CustomNativeValue appUrl: $appUrl"
                                    )
                                    Log.d(
                                        "RemoteConfigData",
                                        "CustomNativeValue launch_type: $launch_type"
                                    )
                                }
                            }
                        } ?: emptyList()
            } catch (e: Exception) {

                Log.e(
                    "RemoteConfigData",
                    "RemoteConfigError - failed: ${e?.message}"
                )
            }

//            try {// Suggestion apps details
//                context.callerCadBaseConfig.callerCadCustomSuggestionAppsDetails =
//                    remoteJSON.optJSONArray("after_call_custom_suggestion_apps_details")
//                        ?.let { jsonArray ->
//                            List(jsonArray.length()) {
//                                val item = jsonArray.getJSONObject(it)
//                                AfterCallSuggestionAppDetail(
//                                    appTitle = item.optString("app_title", ""),
//                                    appDes = item.optString("app_des", ""),
//                                    appIcon = item.optString("app_icon", ""),
//                                    appBanner = item.optString("app_banner", ""),
//                                    appUrl = item.optString("app_url", ""),
//                                    launchType = item.optString("launch_type", "")
//                                ).apply {
//                                    Log.d(
//                                        "RemoteConfigData",
//                                        "AfterCallSuggestionAppDetail appTitle: $appTitle"
//                                    )
//                                    Log.d(
//                                        "RemoteConfigData",
//                                        "AfterCallSuggestionAppDetail appDes: $appDes"
//                                    )
//                                    Log.d(
//                                        "RemoteConfigData",
//                                        "AfterCallSuggestionAppDetail appIcon: $appIcon"
//                                    )
//                                    Log.d(
//                                        "RemoteConfigData",
//                                        "AfterCallSuggestionAppDetail appBanner: $appBanner"
//                                    )
//                                    Log.d(
//                                        "RemoteConfigData",
//                                        "AfterCallSuggestionAppDetail appUrl: $appUrl"
//                                    )
//                                    Log.d(
//                                        "RemoteConfigData",
//                                        "AfterCallSuggestionAppDetail launch_type: $launchType"
//                                    )
//                                }
//                            }
//                        } ?: emptyList()
//            } catch (e: Exception) {
//                Log.e(
//                    "RemoteConfigData",
//                    "RemoteConfigError - failed: ${e?.message}"
//                )
//            }
//            handleAdUrl(
//                remoteJSON,
//                context,
//                "native",
//                "after_call_custom_predesign_native_url"
//            )
//            handleAdUrl(
//                remoteJSON,
//                context,
//                "banner",
//                "after_call_custom_predesign_banner_url"
//            )
        } catch (e: Exception) {
            e.printStackTrace()
            Log.e(
                "RemoteConfigData",
                "RemoteConfigError - Error processing remote config data",
                e
            )
        }
    } else {
        Log.e("RemoteConfigError", "Remote config data is empty or null")
    }

    callback.invoke()

}

fun readJsonFromAssets(context: Context, fileName: String): String {
    return try {
        context.assets.open(fileName).bufferedReader().use { it.readText() }
    } catch (e: Exception) {
        Log.e(
            "RemoteConfigData",
            "readJsonFromAssets.Exception:$e"
        )
        ""
    }
}

//private fun handleAdUrl(remoteJSON: JSONObject, context: Context, adType: String, urlKey: String) {
//    try {
//        val urlObject = remoteJSON.optJSONObject(urlKey)
//        if (urlObject != null) {
////            val imageUrl = urlObject.optString("image_url", "")
////            val clickUrl = urlObject.optString("click_url", "")
////            val launchType = urlObject.optString("launch_type", "")
//
//            when (adType) {
//                "native" -> {
//                    context.callerCadBaseConfig.callerCadCustomPredesignNativeUrl = imageUrl
//                    context.callerCadBaseConfig.callerCadCustomPredesignNativeClickUrl = clickUrl
//                    context.callerCadBaseConfig.callerCadCustomPredesignNativeClickUrlLaunchType =
//                        launchType
//                }
//
//                "banner" -> {
//                    context.callerCadBaseConfig.callerCadCustomPredesignBannerUrl = imageUrl
//                    context.callerCadBaseConfig.callerCadCustomPredesignBannerClickUrl = clickUrl
//                    context.callerCadBaseConfig.callerCadCustomPredesignBannerClickUrlLaunchType =
//                        launchType
//                }
//            }
//            Log.d(
//                "RemoteConfigDataLaunchType",
//                "$urlKey: $imageUrl, click_url: $clickUrl" + "launchType: $launchType"
//            )
//        } else {
//            Log.e("RemoteConfigData", "$urlKey object is null.")
//        }
//    } catch (e: Exception) {
//        Log.e("RemoteConfigData", "RemoteConfigError - failed: ${e.message}")
//    }
//}

/**
 * Creates a bitmap with a single character text.
 * @param text The character to display in the bitmap.
 * @return The generated bitmap.
 */
fun createBitmapFromText(text: String): Bitmap {
    val size = 128 // Bitmap size in pixels
    val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    canvas.drawColor(Color.WHITE) // Background color

    val paint = Paint().apply {
        color = Color.BLACK
        textSize = 64f
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }

    val xPos = canvas.width / 2
    val yPos = (canvas.height / 2 - (paint.descent() + paint.ascent()) / 2).toInt()

    canvas.drawText(text, xPos.toFloat(), yPos.toFloat(), paint)
    return bitmap
}


//fun showAutoStartPermissionDialog(context: Context) {
//
//    val manufacturer = Build.MANUFACTURER.lowercase()
//
//    if (context.callerCadBaseConfig.callerCadDeviceDetails?.isEmpty() == true) {
//        context.callerCadBaseConfig.callerCadDeviceDetails = manufacturer
//        AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_DEVICE_BRAND + "_$manufacturer")
//    }
//
//    val supportedManufacturers = listOf(
//        "realme", "xiaomi", "poco", "huawei", "honor",
//        "tecno", "asus", "lenovo"
//    )
//    val supportedManufacturersMI = listOf(
//        "xiaomi", "poco"
//    )
//
//    val sharedPreferences = context.getSharedPreferences("app_preferences", Context.MODE_PRIVATE)
//    val launchCountKey = "launch_count"
//    val lastDialogShownDateKey = "last_dialog_shown_date"
//    val launchCount = sharedPreferences.getInt(launchCountKey, 10)
//    val lastDialogShownDate = sharedPreferences.getLong(lastDialogShownDateKey, 0L)
//
//    val currentDate = System.currentTimeMillis()
//    val oneDayInMillis = 24 * 60 * 60 * 1000 // 24 hours in milliseconds
//
//
//    // Check if 1 day has passed since the last dialog was shown
//    val canShowDialogToday = currentDate - lastDialogShownDate >= oneDayInMillis
//
//    if (!context.callerCadBaseConfig.callerCardAutoStartDontShowAgain) {
//
//        if (!context.callerCadBaseConfig.callerCardAutoStartLater) {
//
//            if (launchCount >= 10 && canShowDialogToday) {
//                if (supportedManufacturersMI.any { manufacturer.contains(it) }) {
//                    if (!Autostart.getSafeState(context)) {
//                        checkAutoStartAndShowPermissionDialog(context)
//                    }
//                } else if (supportedManufacturers.any { manufacturer.contains(it) }) {
//                    if (!isBatteryOptimizationIgnored(context)) {
//                        checkAutoStartAndShowPermissionDialog(context)
//                    }
//                }
//                // Update the launch count and set the last dialog shown date
//                sharedPreferences.edit()
//                    .putInt(launchCountKey, 0)
//                    .putLong(lastDialogShownDateKey, currentDate)
//                    .apply()
//            } else {
//                sharedPreferences.edit().putInt(launchCountKey, launchCount + 1).apply()
//            }
//        } else {
//            sharedPreferences.edit().putInt(launchCountKey, launchCount + 1).apply()
//
//            if (launchCount >= 10) {
//                context.callerCadBaseConfig.callerCardAutoStartLater = false
//            }
//        }
//    }
//}

/*fun showAutoStartPermissionDialog(context: Context) {

    Log.e("launchCountlaunchCount","showAutoStartPermissionDialog Enter - ")
    val manufacturer = Build.MANUFACTURER.lowercase()
    // List of manufacturers requiring auto-start permission handling
    val supportedManufacturers = listOf(
        "realme", "xiaomi", "poco", "huawei", "honor",
        "tecno", "asus", "lenovo"
    )
    val supportedManufacturersMI = listOf(
        "xiaomi", "poco"
    )

    val sharedPreferences = context.getSharedPreferences("app_preferences", Context.MODE_PRIVATE)
    val launchCountKey = "launch_count"
    val launchCount = sharedPreferences.getInt(launchCountKey, 4)

    Log.e("launchCountlaunchCount","launchCount 0 - " + launchCount)
    if (!context.callerCadBaseConfig.callerCardAutoStartDontShowAgain) {

        if (!context.callerCadBaseConfig.callerCardAutoStartLater) {

            Log.e("launchCountlaunchCount","launchCount 1 - " + launchCount)
            if (launchCount >= 4) {
                if (supportedManufacturersMI.any { manufacturer.contains(it) }) {
                    if (!Autostart.getSafeState(context)) {
                        checkAutoStartAndShowPermissionDialog(context)
                    }
                }else if (supportedManufacturers.any { manufacturer.contains(it) }) {

                    if (!isBatteryOptimizationIgnored(context)) {
                        checkAutoStartAndShowPermissionDialog(context)
                    }
                }
                sharedPreferences.edit().putInt(launchCountKey, 0).apply()
            } else {
                sharedPreferences.edit().putInt(launchCountKey, launchCount + 1).apply()
            }
        }else{

            sharedPreferences.edit().putInt(launchCountKey, launchCount + 1).apply()
            Log.e("launchCountlaunchCount","launchCount 2 - " + launchCount)

            if(launchCount >= 4){
                context.callerCadBaseConfig.callerCardAutoStartLater = false
            }

        }

    }
}*/


private fun isBatteryOptimizationIgnored(context: Context): Boolean {
    val packageName = context.packageName
    val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
    return powerManager.isIgnoringBatteryOptimizations(packageName)
}


//fun checkAndShowAutoPermissionView(
//    context: Context,
//    parentView: ViewGroup,
//    closeable: Boolean,
//): View? {
//
//
//    val manufacturer = Build.MANUFACTURER.lowercase()
//    // List of manufacturers requiring auto-start permission handling
//    val supportedManufacturers = listOf(
//        "realme", "xiaomi", "poco", "huawei", "honor",
//        "tecno", "asus", "lenovo"
//    )
//    val supportedManufacturersMI = listOf(
//        "xiaomi", "poco"
//    )
//
//
//    if (supportedManufacturersMI.any { manufacturer.contains(it) }) {
//        if (Autostart.getSafeState(context)) {
//
//            //   parentView.addView(null)
//            parentView.visibility = View.GONE
//            return null
//        }
//    }
//    if (context.callerCadBaseConfig.clickOnAutostartView) {
//
//        //     parentView.addView(null)
//        parentView.visibility = View.GONE
//        return null
//    }
//    // Check if the current manufacturer is in the supported list
//    if (supportedManufacturers.any { manufacturer.contains(it) }) {
//
//
//        if (isBatteryOptimizationIgnored(context)) {
//            //    parentView.addView(null)
//            parentView.visibility = View.GONE
//            return null
//        }
//
//        val customView = LayoutInflater.from(context)
//            .inflate(R.layout.caller_cad_view_for_battery_optimization, parentView, false)
//        val allowButton = customView.findViewById<TextView>(R.id.allow_button)
//        val closeButton = customView.findViewById<ImageView>(R.id.closeButton)
//
//        allowButton.setOnClickListener {
//            checkAutoStartAndShowPermissionDialog(context)
//        }
//        closeButton.visibility = if (closeable) View.VISIBLE else View.GONE
//
//        closeButton.setOnClickListener {
//            context.callerCadBaseConfig.clickOnAutostartView = true
//            parentView.removeView(customView)
//        }
//        parentView.visibility = View.VISIBLE
//        parentView.addView(customView)
//
//        return customView
//
//    } else {
//        //   parentView.addView(null)
//        parentView.visibility = View.GONE
//        return null
//    }
//}


private fun checkAutoStartAndShowPermissionDialog(context: Context) {

    val autoStartDialog = AutoStartPermissionDialog(
        context = context,
        onAllowClicked = {
            AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AUTO_START_CLICK_ALLOW)
            setAutoStartPermission(context)
        },
        onLaterClicked = {
            // Handle "Later" action
            AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AUTO_START_CLICK_LATER)
            context.callerCadBaseConfig.callerCardAutoStartLater = true
        }
    )

    autoStartDialog.show()
    AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AUTO_START_DIALOG_SHOW)

}


private fun setAutoStartPermission(context: Context) {
    try {
        val intent = Intent()
        val manufacturer = Build.MANUFACTURER.lowercase()

        Log.e("setAutoStartPermission", " manufacturer - $manufacturer")
        when {

            manufacturer.contains("xiaomi") || manufacturer.contains("poco") -> {
                intent.setComponent(
                    ComponentName(
                        "com.miui.securitycenter",
                        "com.miui.permcenter.autostart.AutoStartManagementActivity"
                    )
                )
            }

            manufacturer.contains("huawei") || manufacturer.contains("honor") -> {
                intent.setComponent(
                    ComponentName(
                        "com.huawei.systemmanager",
                        "com.huawei.systemmanager.optimize.process.ProtectActivity"
                    )
                )
            }

            manufacturer.contains("tecno") -> {
                intent.setComponent(
                    ComponentName(
                        "com.transsion.phonemaster",
                        "com.transsion.phonemaster.main.SmartManagerMainActivity"
                    )
                )
            }

            manufacturer.contains("asus") -> {
                intent.setComponent(
                    ComponentName(
                        "com.asus.mobilemanager",
                        "com.asus.mobilemanager.entry.FunctionActivity"
                    )
                )
            }

            manufacturer.contains("lenovo") -> {
                intent.setComponent(
                    ComponentName(
                        "com.lenovo.security",
                        "com.lenovo.security.autostart.AutoStartActivity"
                    )
                )
            }

            manufacturer.contains("realme") -> {


                openBatterySettingsForPackage(context)
                return
            }

            else -> {
                Log.e(
                    "setAutoStartPermission",
                    " Auto Start Permission is not supported for this device."
                )
                return
            }
        }

        // Verify the activity exists
        val packageManager = context.packageManager
        if (intent.resolveActivity(packageManager) != null) {
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(intent)
        } else {


            Log.e("setAutoStartPermission", " Unable to find Auto Start settings on this device.")
        }


    } catch (e: Exception) {
        Log.e("setAutoStartPermission", "Exception - " + e.message)
        Log.e("setAutoStartPermission", "printStackTrace - " + e.printStackTrace())
    }
}


private fun openBatterySettingsForPackage(context: Context) {
    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
        data = Uri.fromParts("package", context.packageName, null)
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
    }
    context.startActivity(intent)

    Toast.makeText(context, "Go to Battery usage -> Allow auto-launch", Toast.LENGTH_LONG).show()
}


@Keep
fun openURLLaunch(context: Context, url: String, launchType: String) {
    if (url.isBlank()) {
        Log.e("openURLLaunch", "URL is blank. Cannot proceed.")
        return
    }

    Log.d("openURLLaunch", "Attempting launchType  : $launchType")

    try {
        when (launchType.lowercase()) {
            "system" -> {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }

            "custom" -> {
                openCustomTab(context, url)

            }

            else -> {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }
        }
    } catch (e: ActivityNotFoundException) {
        Log.e("openURLaunch", "No Activity found to handle the intent for URL: $url", e)
    } catch (e: Exception) {
        Log.e("openURLLaunch", "Error launching URL: $url", e)
    }
}

fun openCustomTab(context: Context, url: String) {

    val drawable: Drawable =
        ContextCompat.getDrawable(context, R.drawable.after_call_arrow_back_white)!!
    val bitmap = drawableToBitmap(drawable)


    val customTabsIntent = CustomTabsIntent.Builder()
        .setShowTitle(true)
        .setToolbarColor(context.getColor(R.color.after_call_white_all))
        .setCloseButtonIcon(bitmap)
        .setDefaultShareMenuItemEnabled(false)
        .build()

    customTabsIntent.launchUrl(context, Uri.parse(url))
}

private const val SYSTEM_PROPS_CLASS = "android.os.SystemProperties"
private const val MIUI_VERSION_PROPERTY = "ro.miui.ui.version.code"

@Keep
fun isOnMiui(): Boolean {
    Class.forName(SYSTEM_PROPS_CLASS).apply {
        return !TextUtils.isEmpty(
            getMethod("get", String::class.java)
                .invoke(this, MIUI_VERSION_PROPERTY) as String
        )
    }
}

fun drawableToBitmap(drawable: Drawable): Bitmap {
    val width = drawable.intrinsicWidth
    val height = drawable.intrinsicHeight

    // Create a bitmap with the same dimensions as the drawable
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)

    // Create a canvas to draw the drawable onto the bitmap
    val canvas = Canvas(bitmap)
    drawable.setBounds(0, 0, canvas.width, canvas.height)
    drawable.draw(canvas)

    return bitmap
}

// Function to retrieve user's photo from contacts based on phone number
@SuppressLint("Range")
fun getUserPhotoByPhoneNumber(phoneNumber: String?, context: Context): Bitmap? {
    val projection = arrayOf(ContactsContract.CommonDataKinds.Photo.PHOTO)

    // Query contacts based on phone number
    val cursor = context.contentResolver.query(
        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
        null,
        ContactsContract.CommonDataKinds.Phone.NUMBER + " = ?",
        arrayOf(phoneNumber),
        null
    )

    cursor?.use {
        if (it.moveToFirst()) {
            // Get contact ID from the cursor
            val contactId =
                it.getString(it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID))

            // Use the contact ID to query for the photo
            val photoCursor = context.contentResolver.query(
                ContactsContract.Data.CONTENT_URI,
                projection,
                ContactsContract.Data.CONTACT_ID + " = ? AND " + ContactsContract.Data.MIMETYPE + " = ?",
                arrayOf(contactId, ContactsContract.CommonDataKinds.Photo.CONTENT_ITEM_TYPE),
                null
            )
            var userPhoto: Bitmap?
            photoCursor?.use { photoCursorInner ->
                if (photoCursorInner.moveToFirst()) {
                    val photoData =
                        photoCursorInner.getBlob(
                            photoCursorInner.getColumnIndex(
                                ContactsContract.CommonDataKinds.Photo.PHOTO
                            )
                        )
                    try {
                        if (photoData != null) {
                            userPhoto =
                                BitmapFactory.decodeByteArray(photoData, 0, photoData.size)
                            return userPhoto
                        }
                    } catch (e: Exception) {

                    }
                }
            }
        }
    }
    return null
}