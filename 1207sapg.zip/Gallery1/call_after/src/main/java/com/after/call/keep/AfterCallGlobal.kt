package com.after.call.keep

import android.app.Application
import android.content.Context
import androidx.annotation.Keep
import com.after.call.AfterCallUtils
import com.after.call.extensions.callerCadBaseConfig
import com.after.call.utils.AppCategoriesIcon

@Keep
object AfterCallGlobal {

    /**
     * Initializes the Caller Card feature.
     *
     * @param application The Application instance.
     * @param appIcon An instance of [AppCategoriesIcon] representing the app icon configuration.
     * @param firebaseEventListener Optional listener for Firebase events.
     */
    fun initializeAfterCall(
        application: Application,
        appIcon: AppCategoriesIcon,
        appCustomSettingAvailability: Boolean,
        appCustomSettingClickScreen: Class<*>? = null,
        firebaseEventListener: CallerFirebaseEventListener?,
    ) {
        AfterCallUtils.initializeAfterCall(application, firebaseEventListener)
        AppCategoriesIcon.saveOpenIconFromPosition(application, appIcon)


        application.callerCadBaseConfig.customizeInsideViewEnable = appCustomSettingAvailability
        if (appCustomSettingAvailability) {
            if (appCustomSettingClickScreen != null) {
                AfterCallUtils.setAfterCallCustomSettingClickActivity(
                    application,
                    appCustomSettingClickScreen
                )
            } else {
                application.callerCadBaseConfig.customizeInsideViewEnable = false
            }
        }
    }

    fun setBackIconInAfterCall(application: Application, icon: Int) {
        application.callerCadBaseConfig.callerCadBackIcon = icon
    }

    /**
     * Opens the Caller Card settings screen.
     *
     * @param context The Context used to launch the settings screen.
     */
    fun openAfterCallSettingScreen(context: Context) {
        AfterCallUtils.openAfterCallSettingScreen(context)
    }

    /**
     * Opens the Caller Card settings screen.
     *
     * @param context The Context used to launch the settings screen.
     */
    fun openAppCustomSettingScreen(context: Context) {
        AfterCallUtils.getAfterCallCustomSettingClickActivity(context)
    }

    /**
     * Sets the Caller Card fragment if not already set.
     *
     * @param callerContainer An optional [CallerContainer] instance to set as the fragment.
     */
    fun setAfterCallFragment(callerContainer: CallerContainer?) {
        if (AfterCallUtils.mAfterCallContainerFragment == null && callerContainer != null) {
            AfterCallUtils.setAfterCallFragment(callerContainer)
        }
    }
}
