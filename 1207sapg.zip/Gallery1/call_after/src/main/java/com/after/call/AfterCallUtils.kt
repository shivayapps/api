package com.after.call

import android.Manifest
import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import androidx.annotation.Keep
//import com.after.call.activity.AfterCallSettingsActivity
import com.after.call.extensions.callerCadBaseConfig
import com.after.call.keep.CallerContainer
import com.after.call.keep.CallerFirebaseEventListener
import com.google.android.gms.ads.MobileAds


@Keep
object AfterCallUtils {

    const val SDKVersion = "1.9.7"

    @SuppressLint("StaticFieldLeak")
    var mAfterCallContainerFragment: CallerContainer? = null

    var callerCadApplication: Application? = null

    var firebaseeventlistener: CallerFirebaseEventListener? = null

    fun AfterCallEvent(string: String) {
        try {
            firebaseeventlistener?.onEventListen(string)
        } catch (_: Exception) {
        }
    }
    fun initializeAfterCall(
        application: Application, firebaseeventlisten: CallerFirebaseEventListener?,
    ) {

        callerCadApplication = application
        MobileAds.initialize(application)
        hasContactPermissionInManifest(application)
        firebaseeventlistener = firebaseeventlisten

    }

    fun  hasContactPermissionInManifest(context: Context) {
        context.callerCadBaseConfig.contactpermission = hasPermissionInManifest(context)
    }


    fun hasPermissionInManifest(context: Context): Boolean {

        val packageInfo = context.packageManager.getPackageInfo(context.packageName, PackageManager.GET_PERMISSIONS)
        val permissions = packageInfo.requestedPermissions

        if (permissions.isNullOrEmpty())
            return false

        for (perm in permissions) {
            if (perm == Manifest.permission.READ_CONTACTS)
                return true
        }

        return false
    }


    fun openAfterCallSettingScreen(context: Context) {
//        val mIntent =
//            Intent(context, AfterCallSettingsActivity::class.java)
//        mIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
//        context.startActivity(mIntent)
    }


    fun setAfterCallFragment(fragment: CallerContainer?) {

        mAfterCallContainerFragment = fragment
    }

    var engageActivityClass: Class<*>? = null

    fun setAfterCallCustomSettingClickActivity(mContext: Context, activityClass: Class<*>) {
        engageActivityClass = activityClass
        mContext.callerCadBaseConfig.engageActivityClass = activityClass.name
    }

    fun getAfterCallCustomSettingClickActivity(mContext: Context): Class<*>? {
        engageActivityClass =
            mContext.callerCadBaseConfig.engageActivityClass?.let {
                Class.forName(
                    it
                )
            }
        return engageActivityClass
    }

    fun getLogoFromSharedPreferences(context: Context): Drawable? {
        return try {
            val packageManager = context.packageManager
            val applicationInfo =
                packageManager.getApplicationInfo(callerCadApplication?.packageName!!, 0)
            packageManager.getApplicationIcon(applicationInfo)
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
            null
        }
    }

}