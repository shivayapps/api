package com.after.call.bannerad

import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import com.after.call.AfterCallUtils
import com.after.call.R
import com.after.call.adUtils.HIDE_BANNER_AD
import com.after.call.adUtils.MessageEvent
import com.after.call.adUtils.SHOW_BANNER_AD
import com.after.call.adUtils.SHOW_SMALL_NATIVE_BANNER_AD
//import com.after.call.adUtils.SHOW_URL_BANNER_AD
import com.after.call.databinding.LayoutListItemNativeBinding
import com.after.call.extensions.callerCadBaseConfig
import com.after.call.extensions.isInternetConnected
import com.after.call.utils.CallerEventsConstants
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.nativead.NativeAd
import org.greenrobot.eventbus.EventBus


class CallerBannerAdManager(val context: Context) {

    companion object {
        var bannerAdView: AdView? = null
        var mSmallNativeAd: NativeAd? = null

        @SuppressLint("StaticFieldLeak")
        private var callerBannerAdManager: CallerBannerAdManager? = null
        fun getInstance(context: Context): CallerBannerAdManager {
            if (callerBannerAdManager == null) {
                callerBannerAdManager = CallerBannerAdManager(context)
            }
            return callerBannerAdManager!!
        }

    }

    var currentAdIndex = 0


    fun loadBannerAd() {
        Log.d("LoadBannerAd", "Starting loadBannerAd. CurrentAdIndex: $currentAdIndex")

        if (currentAdIndex < context.callerCadBaseConfig.callerCadBannerAdsOrder.size) {
            val adType = context.callerCadBaseConfig.callerCadBannerAdsOrder[currentAdIndex]
            Log.d("LoadBannerAd", "Processing ad type: $adType")

            when (adType) {
                "banner" -> {
                    if (context.callerCadBaseConfig.callerCadAdmobBannerEnable) {
                        Log.d("LoadBannerAd", "Loading AdMob banner ad.")
                        loadBannerAds()
                    } else {
                        Log.d("LoadBannerAd", "AdMob banner ads are disabled. Moving to next ad.")
                        currentAdIndex++
                        loadBannerAd()
                    }
                }

                "native" -> {
                    if (context.callerCadBaseConfig.callerCadAdmobSmallNativeEnable) {
                        Log.d("LoadBannerAd", "Loading AdMob small native ad.")
                        loadSmallNativeHome()
                    } else {
                        Log.d(
                            "LoadBannerAd",
                            "AdMob small native ads are disabled. Moving to next ad."
                        )
                        currentAdIndex++
                        loadBannerAd()
                    }
                }

//                "url" -> {
//                    if (context.callerCadBaseConfig.callerCadCustomPreDesignBannerEnable) {
//                        Log.d("LoadBannerAd", "Loading custom pre-designed banner.")
//                        loadBannerImageOrGif()
//                    } else {
//                        Log.d(
//                            "LoadBannerAd",
//                            "Custom pre-designed banners are disabled. Moving to next ad."
//                        )
//                        currentAdIndex++
//                        loadBannerAd()
//                    }
//                }

                else -> {
                    Log.w("LoadBannerAd", "Unknown ad type: $adType")
                    currentAdIndex++
                    loadBannerAd()
                }
            }
        } else {
            Log.d("LoadBannerAd", "No more ads to load. Posting HIDE_BANNER_AD event.")
            EventBus.getDefault().post(MessageEvent(HIDE_BANNER_AD))
        }
    }



    fun loadBannerAds() {
        if (!context.callerCadBaseConfig.callerCadAdEnable) {
            return
        }
        CallerBannerAdRequest.loadBannerAfterCall(
            context,
            context.callerCadBaseConfig.callerCadAdmobAdIdBanner
        ) {
            if (it != null) {

                bannerAdView = it
                EventBus.getDefault().post(MessageEvent(SHOW_BANNER_AD, bannerAdView))
            } else {

                currentAdIndex++
                loadBannerAd()

            }
        }
    }

    fun loadSmallNativeHome() {
        Log.d("AfterCall", "Starting loadSmallNativeHome.")

        if (!context.isInternetConnected()) {
            Log.w("AfterCall", "No internet connection. Aborting ad load.")
            return
        }

        if (!context.callerCadBaseConfig.callerCadAdEnable) {
            Log.w("AfterCall", "Ads are disabled in the configuration. Aborting ad load.")
            return
        }

        val adLoader =
            AdLoader.Builder(context, context.callerCadBaseConfig.callerCadAdmobAdIdSmallNative)
                .forNativeAd {
                    Log.d("AfterCall", "Native ad successfully loaded.")
                    mSmallNativeAd = it
                    EventBus.getDefault().post(MessageEvent(SHOW_SMALL_NATIVE_BANNER_AD))
                }
                .withAdListener(object : AdListener() {
                    override fun onAdFailedToLoad(adError: LoadAdError) {
                        Log.e("AfterCall", "Failed to load native ad: ${adError.message}")
                        currentAdIndex++
                        loadBannerAd()
                    }

                    override fun onAdImpression() {
                        super.onAdImpression()
                        Log.d("AfterCall", "Ad impression recorded.")

                        context.callerCadBaseConfig.cadAdImpressionTotalCountSmallNativeBanner += 1
                        val impressionCount =
                            context.callerCadBaseConfig.cadAdImpressionTotalCountSmallNativeBanner
                        Log.d("AfterCall", "Impression count: $impressionCount")

                        when (impressionCount) {
                            1 -> AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_SMALL_NATIVE_IMPRESSION_1)
                            2 -> AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_SMALL_NATIVE_IMPRESSION_2)
                            3 -> AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_SMALL_NATIVE_IMPRESSION_3)
                            4 -> AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_SMALL_NATIVE_IMPRESSION_4)
                            5 -> AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_SMALL_NATIVE_IMPRESSION_5)
                            6 -> AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_SMALL_NATIVE_IMPRESSION_6)
                            7 -> AfterCallUtils.AfterCallEvent(CallerEventsConstants.CAD_AD_SMALL_NATIVE_IMPRESSION_7)
                        }
                    }
                })
                .build()

        Log.d("AfterCall", "Requesting to load native ad.")
        adLoader.loadAd(AdRequest.Builder().build())
    }


    fun showNativeHome(context: Context, parentView: ViewGroup) {
        mSmallNativeAd?.let {
            parentView.visibility = View.VISIBLE
            populateSmallNativeAd(context, parentView, it)
        }
    }


    fun onDestroy() {
        mSmallNativeAd?.destroy()
        mSmallNativeAd = null
        isAdLoadedBanner = false
        currentAdIndex = 0
    }

    fun populateSmallNativeAd(
        mContext: Context,
        view: View,
        nativeAd: NativeAd,
    ) {

        try {

            val applyBackground =
                ContextCompat.getDrawable(context, R.drawable.ads_item_gradiant_rounded)
            val colorArray = context.resources.obtainTypedArray(R.array.caller_cad_theme_colors)
            val selectedColor = colorArray.getColor(
                context.callerCadBaseConfig.callerCadSelectedTheme,
                ContextCompat.getColor(context, R.color.after_call_selectedColor)
            )
            applyBackground?.setTint(selectedColor)

            LayoutListItemNativeBinding.bind(view).apply {
                //            if(adCallToAction!=null) adCallToAction.setTextColor(Color.WHITE)
                adHeadline.text = nativeAd.headline
                adBody.text = nativeAd.body


                adCallToAction.text = nativeAd.callToAction
                val textColor = ContextCompat.getColor(context, R.color.after_call_text_color_white)
                adCallToAction.setTextColor(textColor)
                adCallToAction.background = applyBackground

                if (nativeAd.icon != null) {
                    ivAdAppIcon.setImageDrawable(nativeAd.icon!!.drawable)
                    nativeAdView.iconView = ivAdAppIcon
                } else {
                    ivAdAppIcon.layoutParams.width = 0
                }
                nativeAdView.headlineView = adHeadline
                nativeAdView.bodyView = adBody
                nativeAdView.callToActionView = adCallToAction
                nativeAdView.setNativeAd(nativeAd)
//                nativeAdView.setBackgroundColor(view.context.resources.getColor(R.color.smallnativebg))
                nativeAdView.visibility = View.VISIBLE


            }
        } catch (e: Exception) {
        }
    }

    var isAdLoadedBanner = false

    fun isAdLoaded(): Boolean {
        return isAdLoadedBanner
    }


}