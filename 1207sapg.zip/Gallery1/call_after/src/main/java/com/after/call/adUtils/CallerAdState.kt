package com.after.call.adUtils

enum class CallerAdState {
    NONE,
    LOADING,
    SUCCESS,
    FAILED
}