package com.after.call.nativead

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.after.call.AfterCallUtils
import com.after.call.R
import com.after.call.adUtils.CallerAdState
import com.after.call.databinding.ActivityAfterCallCallerBinding
import com.after.call.extensions.callerCadBaseConfig
import com.after.call.extensions.isInternetConnected
import com.after.call.extensions.openURLLaunch
import com.after.call.utils.CallerEventsConstants
import com.after.call.utils.CallerLogger
import com.after.call.utils.CallerOnSingleClickListener
import com.after.call.utils.CustomNativeValue
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.VideoOptions
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView


object CallerNativeAdRequest {
    private var topCallerAdState: CallerAdState = CallerAdState.NONE


    fun loadNativeAfterCall(context: Context, adId: String, callBack: (NativeAd?) -> Unit) {
        if (!context.isInternetConnected()) {
            topCallerAdState = CallerAdState.NONE
            callBack.invoke(null)
            return
        }
        topCallerAdState = CallerAdState.LOADING
        loadNative(context.applicationContext, adId, onAdClick = {
        }, callBack)

    }




    private fun loadNative(context: Context, adId: String, onAdClick: () -> Unit, callBack: (NativeAd?) -> Unit) {


        Log.e("BBCCBBCCBBCC", " -------->>  loadNative")

        val callerCadParameters = context.callerCadBaseConfig

        val videoOptionBuilder = VideoOptions.Builder()
            .setClickToExpandRequested(true)
            .setStartMuted(true)

        val nativeAdOptionsBuilder = NativeAdOptions.Builder()
            .setReturnUrlsForImageAssets(false)
            .setRequestMultipleImages(false)
            .setAdChoicesPlacement(NativeAdOptions.ADCHOICES_TOP_RIGHT)
            .setVideoOptions(videoOptionBuilder.build())

        val adLoader = AdLoader.Builder(context, adId)
            .forNativeAd { nativeAd ->
                callBack(nativeAd)
                CallerLogger.logE("nativeAd loaded")
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    CallerLogger.logE("onAdFailedToLoad $adError")
                    callBack(null)
                }

                override fun onAdClicked() {
                    onAdClick()
                    CallerLogger.logE("onAdClicked")
                }

                override fun onAdImpression() {
                    CallerLogger.logE("onAdImpression Native")
                    callerCadParameters.cadAdImpressionTotalCountNative += 1

                    // Handle impression events efficiently using a map
                    val impressionEventMap = mapOf(
                        1 to CallerEventsConstants.CAD_AD_NATIVE_IMPRESSION_1,
                        2 to CallerEventsConstants.CAD_AD_NATIVE_IMPRESSION_2,
                        3 to CallerEventsConstants.CAD_AD_NATIVE_IMPRESSION_3,
                        4 to CallerEventsConstants.CAD_AD_NATIVE_IMPRESSION_4,
                        5 to CallerEventsConstants.CAD_AD_NATIVE_IMPRESSION_5,
                        6 to CallerEventsConstants.CAD_AD_NATIVE_IMPRESSION_6,
                        7 to CallerEventsConstants.CAD_AD_NATIVE_IMPRESSION_7
                    )
                    impressionEventMap[callerCadParameters.cadAdImpressionTotalCountNative]?.let {
                        AfterCallUtils.AfterCallEvent(it)
                    }
                }
            })
            .withNativeAdOptions(nativeAdOptionsBuilder.build())
            .build()

        val adRequest = AdRequest.Builder().build()
        adLoader.loadAd(adRequest)
    }


    fun prepareAdView(context: Context, nativeAd: NativeAd): View {
        val adView = LayoutInflater.from(context).inflate(R.layout.layout_google_native_ad_big_caller, null) as NativeAdView
        val headlineView = adView.findViewById<TextView>(R.id.ad_headline)
        if (headlineView != null) {
            headlineView.text = nativeAd.headline
            adView.headlineView = headlineView
        }

        val bodyView = adView.findViewById<TextView>(R.id.ad_body)
        if (bodyView != null) {
            bodyView.text = nativeAd.body
            adView.bodyView = bodyView
        }
        val callToActionView = adView.findViewById<TextView>(R.id.ad_call_to_action)
        if (callToActionView != null) {
            callToActionView.text = nativeAd.callToAction
            adView.callToActionView = callToActionView
        }

        val backgroundDrawable =
            ContextCompat.getDrawable(context, R.drawable.after_call_selector_native_gradient)
        val colorArray = context.resources.obtainTypedArray(R.array.caller_cad_theme_colors)
        val selectedColor = colorArray.getColor(
            context.callerCadBaseConfig.callerCadSelectedTheme,
            ContextCompat.getColor(context, R.color.after_call_selectedColor)
        )
        backgroundDrawable?.setTint(selectedColor)
        callToActionView.background = backgroundDrawable

        val adAppIcon = adView.findViewById<ImageView>(R.id.ad_app_icon)
        if (adAppIcon != null && nativeAd.icon != null) {
            adAppIcon.visibility = View.VISIBLE
            adAppIcon.setImageDrawable(nativeAd.icon!!.drawable)
            adView.iconView = adAppIcon
        } else {
            adAppIcon.visibility = View.GONE
        }
        try {
            val mediaView = adView.findViewById<MediaView>(R.id.ad_media)
            if (mediaView != null) {
                mediaView.visibility = View.VISIBLE
                adView.mediaView = mediaView
                nativeAd.mediaContent?.let {
                    mediaView.setMediaContent(it)

                }
                mediaView.setImageScaleType(ImageView.ScaleType.FIT_CENTER)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        adView.setNativeAd(nativeAd)
        return adView
    }


    fun prepareCustomNativeView(
        context: Context,
        binding: ActivityAfterCallCallerBinding,
        customNativeValue: CustomNativeValue,
    ) {
        // Use ViewBinding for layout inflation and view references

        // Set app icon
        Glide.with(context)
            .load(customNativeValue.appIcon)
            .into(binding.mAfterCallCustomNative.adAppIcon)

        // Set headline text
        binding.mAfterCallCustomNative.adHeadline.text = customNativeValue.appTitle

        // Set body text
        binding.mAfterCallCustomNative.adBody.text = customNativeValue.appDes

        // Set call-to-action button text and visibility
        binding.mAfterCallCustomNative.adCallToAction.text =
            if (customNativeValue.appButtonText.isNotEmpty()) {
                customNativeValue.appButtonText
            } else {
                context.getString(R.string.install)
            }


        binding.mAfterCallCustomNative.adCallToAction.setOnClickListener(object :
            CallerOnSingleClickListener() {
            override fun onSingleClick(v: View?) {

                openURLLaunch(
                    context,
                    customNativeValue.appUrl,
                    customNativeValue.launch_type
                )
            }
        })

        val backgroundDrawable =
            ContextCompat.getDrawable(context, R.drawable.after_call_selector_native_gradient)
        val colorArray = context.resources.obtainTypedArray(R.array.caller_cad_theme_colors)
        val selectedColor = colorArray.getColor(
            context.callerCadBaseConfig.callerCadSelectedTheme,
            ContextCompat.getColor(context, R.color.after_call_selectedColor)
        )
        backgroundDrawable?.setTint(selectedColor)
        binding.mAfterCallCustomNative.adCallToAction.background = backgroundDrawable




        binding.mAfterCallCustomNative.adAppIcon.setOnClickListener(object :
            CallerOnSingleClickListener() {
            override fun onSingleClick(v: View?) {
                openURLLaunch(
                    context,
                    customNativeValue.appUrl,
                    customNativeValue.launch_type
                )
            }
        })
        binding.mAfterCallCustomNative.adMediaImage.setOnClickListener(object :
            CallerOnSingleClickListener() {
            override fun onSingleClick(v: View?) {
                openURLLaunch(
                    context,
                    customNativeValue.appUrl,
                    customNativeValue.launch_type
                )
            }
        })
        binding.mAfterCallCustomNative.adMediaImage.visibility = View.VISIBLE
        Glide.with(context)
            .load(customNativeValue.appBanner)
            .into(binding.mAfterCallCustomNative.adMediaImage)
    }
}