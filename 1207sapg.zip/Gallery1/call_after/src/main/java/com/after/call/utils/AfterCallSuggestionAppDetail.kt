package com.after.call.utils

import androidx.annotation.Keep

@Keep
data class AfterCallSuggestionAppDetail(
    val appTitle: String,
    val appDes: String,
    val appIcon: String,
    val appBanner: String,
    val appUrl: String,
    val launchType: String,
)