package com.after.call.bottom_dialog

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.after.call.R
import com.after.call.databinding.BottomSheetLayoutBinding
import com.after.call.extensions.callerCadBaseConfig


class AfterCallDarkThemeDialog(var activity: Activity) : Dialog(activity) {

    lateinit var binding: BottomSheetLayoutBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        binding = BottomSheetLayoutBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )


        if (activity.callerCadBaseConfig.callerCardDarkTheme) {
            val drawable: Drawable? =
                ContextCompat.getDrawable(
                    context,
                    R.drawable.after_call_rounded_darkdialog_background
                )
            binding.root.background = drawable
        } else {
            val drawable: Drawable? =
                ContextCompat.getDrawable(context, R.drawable.after_call_rounded_dialog_background)
            binding.root.background = drawable
        }

        if (context.callerCadBaseConfig.callerCardDarkTheme) {
            binding.lightText.setTextColor(
                ContextCompat.getColor(
                    context,
                    R.color.after_call_text_color_white
                )
            )
            binding.darkText.setTextColor(
                ContextCompat.getColor(
                    context,
                    R.color.after_call_text_color_white
                )
            )
        } else {
            binding.lightText.setTextColor(
                ContextCompat.getColor(
                    context,
                    R.color.after_call_text_color_black
                )
            )
            binding.darkText.setTextColor(
                ContextCompat.getColor(
                    context,
                    R.color.after_call_text_color_black
                )
            )
        }

        intView()

        intListener()
    }

    private fun intView() {

        if (activity.callerCadBaseConfig.callerCardDarkTheme) {
            binding.radioDark.isChecked = true
            binding.radioLight.isChecked = false
        } else {
            binding.radioDark.isChecked = false
            binding.radioLight.isChecked = true
        }

        val tintColor = ContextCompat.getColor(
            context,
            if (context.callerCadBaseConfig.callerCardDarkTheme) {
                R.color.after_call_card_bg_dark // Dark theme color
            } else {
                R.color.after_call_card_bg_light // Light theme color
            }
        )

        ContextCompat.getDrawable(context, R.drawable.after_call_bg_bottomsheet_dialog)
            ?.let { drawable ->
                val mutableDrawable = drawable.mutate()
                mutableDrawable.setTint(tintColor)
                binding.bgMain.background = mutableDrawable
            }




    }

    private fun intListener() {
        // Handle the Apply button click
        binding.closeButton.setOnClickListener {
            val selectedTheme = when (binding.radioGroup.checkedRadioButtonId) {
                binding.radioDark.id -> "Dark"
                binding.radioLight.id -> "Light"
                else -> null
            }
            selectedTheme?.let {
                applyTheme(it)
                dismiss()
            } ?: run {
                Toast.makeText(activity, "Please select a theme", Toast.LENGTH_SHORT).show()
            }
        }
        binding.darkThemeMain.setOnClickListener {
            binding.radioDark.isChecked = true
            binding.radioLight.isChecked = false
            binding.radioGroup.check(binding.radioDark.id)
        }

        binding.liteThemeMain.setOnClickListener {
            binding.radioLight.isChecked = true
            binding.radioDark.isChecked = false
            binding.radioGroup.check(binding.radioLight.id)
        }


    }

    private fun applyTheme(theme: String) {
        when (theme) {
            "Dark" -> {
                activity.callerCadBaseConfig.callerCardDarkTheme = true
            }

            "Light" -> {
                activity.callerCadBaseConfig.callerCardDarkTheme = false
            }
        }

        /*
                if (activity.callerCadBaseConfig.callerCardDarkTheme) {
                    val drawable: Drawable? =
                        ContextCompat.getDrawable(
                            context,
                            R.drawable.after_call_rounded_darkdialog_background
                        )
                    binding.root.background = drawable


                } else {
                    val drawable: Drawable? =
                        ContextCompat.getDrawable(context, R.drawable.after_call_rounded_dialog_background)
                    binding.root.background = drawable
                }

                if (context.callerCadBaseConfig.callerCardDarkTheme) {
                    binding.lightText.setTextColor(ContextCompat.getColor(context, R.color.after_call_text_color_white))
                    binding.darkText.setTextColor(ContextCompat.getColor(context, R.color.after_call_text_color_white))
                } else {
                    binding.lightText.setTextColor(ContextCompat.getColor(context, R.color.after_call_text_color_black))
                    binding.darkText.setTextColor(ContextCompat.getColor(context, R.color.after_call_text_color_black))
                }*/
    }
}