package com.after.call.receivers

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.telephony.TelephonyManager
import com.after.call.activity.AfterCallHomeActivity
import com.after.call.extensions.callerCadBaseConfig
import com.after.call.utils.AfterCallNotification.startIntentNoti
import com.after.call.utils.AfterCallOverlay.binding
import com.after.call.utils.AfterCallOverlay.cadformattedTime
import com.after.call.utils.AfterCallOverlay.callType
import com.after.call.utils.AfterCallOverlay.callerCadCallNumber
import com.after.call.utils.AfterCallOverlay.callerCadCallType
import com.after.call.utils.AfterCallOverlay.displayWindowView
import com.after.call.utils.AfterCallOverlay.isWindowShowing
import com.after.call.utils.AfterCallOverlay.stopCounter
import com.after.call.utils.AfterCallOverlay.windowManager
import com.after.call.utils.CallerLogger.callerCardopen
import java.util.Date

open class AfterCallCallReceiver : BroadcastReceiver() {
    private lateinit var mContext: Context

    override fun onReceive(context: Context, intent: Intent) {
        if (!context.callerCadBaseConfig.callerCadEnable) return

        intent.extras?.let { extras ->
            val stateStr = extras.getString(TelephonyManager.EXTRA_STATE)
            val number = extras.getString(TelephonyManager.EXTRA_INCOMING_NUMBER)

            val state = when (stateStr) {
                TelephonyManager.EXTRA_STATE_IDLE -> TelephonyManager.CALL_STATE_IDLE
                TelephonyManager.EXTRA_STATE_OFFHOOK -> TelephonyManager.CALL_STATE_OFFHOOK
                TelephonyManager.EXTRA_STATE_RINGING -> TelephonyManager.CALL_STATE_RINGING
                else -> return
            }

            onCallStateChanged(context, state, number)
        }
    }


    private fun onCallStateChanged(context: Context?, state: Int, number: String?) {
        if (lastState == state) return
        val currentTime = Date()
        when (state) {
            TelephonyManager.CALL_STATE_RINGING -> {
                isIncoming = true
                callStartTimeDate = currentTime
                callerCadCallNumber = number
                onIncomingCallReceived(context, number)
            }

            TelephonyManager.CALL_STATE_OFFHOOK -> handleOffHookState(context, currentTime, number)
            TelephonyManager.CALL_STATE_IDLE -> handleCallEnded(context, currentTime)
        }
        lastState = state
    }

    private fun handleOffHookState(context: Context?, currentTime: Date, number: String?) {
        if (lastState != TelephonyManager.CALL_STATE_RINGING) {
            isIncoming = false
            if (!isOutgoingCallPickedUp) {
                callStartTimeDate = currentTime
                isOutgoingCallPickedUp = true
            }
            callerCadCallNumber = number
            onOutgoingCallStarted(context, callerCadCallNumber)
        } else {
            isIncoming = true
            callStartTimeDate = currentTime
            onIncomingCallAnswered(context, callerCadCallNumber)
        }
    }

    private fun handleCallEnded(context: Context?, currentTime: Date) {
        when (lastState) {
            TelephonyManager.CALL_STATE_RINGING -> {
                val ringingDuration =
                    currentTime.time - (callStartTimeDate?.time ?: currentTime.time)
                onMissedCall(context, callerCadCallNumber, ringingDuration)
            }

            TelephonyManager.CALL_STATE_OFFHOOK -> {
                val talkDuration = currentTime.time - (callStartTimeDate?.time ?: currentTime.time)
                if (isIncoming) {
                    onIncomingCallEnded(context, callerCadCallNumber, talkDuration)
                } else {
                    onOutgoingCallEnded(context, callerCadCallNumber, talkDuration)
                }
            }
        }
        isOutgoingCallPickedUp = false
    }

    private fun handleCallIdleState(context: Context) {
        if (isWindowShowing) {
            stopCounter()
            removeOverlayViewIfVisible(context)
        }
        if (context.callerCadBaseConfig.switchUnknownCallerSaved) {
            val keyguardManager =
                context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            if (keyguardManager.isKeyguardLocked) {
                startIntentNoti(context)
            } else {
                startAfterCallActivity(context)
            }
        }
    }

    private fun handleCallRingingState(context: Context, number: String?) {
        if (!isWindowShowing && checkOverlayPermission(context) && context.callerCadBaseConfig.switchUnknownCallerSaved) {
            displayWindowView(context)
        }
    }

    private fun handleCallOffHookState(context: Context, number: String?) {
        if (!isWindowShowing && checkOverlayPermission(context) && context.callerCadBaseConfig.switchUnknownCallerSaved) {
            displayWindowView(context)
            isWindowShowing = true
        }
    }

    private fun removeOverlayViewIfVisible(context: Context) {
        if (isWindowShowing && Settings.canDrawOverlays(context)) {
            windowManager?.removeViewImmediate(binding!!.root)
            isWindowShowing = false
        }
    }

    private fun checkOverlayPermission(context: Context): Boolean =
        Settings.canDrawOverlays(context)

    private fun startAfterCallActivity(context: Context) {
        if (!callerCardopen) {
            callerCardopen = true
            val intent = Intent(context, AfterCallHomeActivity::class.java).apply {
                flags =
                    Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK
                putExtra("fromwhere", "ser")
            }
            context.startActivity(intent)
        }
    }

    private fun formatTalkDuration(durationMs: Long): String {
        val totalSeconds = durationMs / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds / 60) % 60
        val seconds = totalSeconds % 60

        return if (totalSeconds < 60) {
            "$totalSeconds second${if (totalSeconds > 1) "s" else ""}"
        } else {
            String.format("%02d:%02d:%02d", hours, minutes, seconds)
        }
    }

    companion object {
        private const val TAG = "AfterCallPhoneCallReceiver"
        private var lastState = TelephonyManager.CALL_STATE_IDLE
        private var callStartTimeDate: Date? = null
        private var isIncoming = false
        private var isOutgoingCallPickedUp = false
    }

    fun onIncomingCallReceived(ctx: Context?, number: String?) {
        mContext = ctx ?: return
        callerCadCallNumber = number.orEmpty()

        if (mContext.callerCadBaseConfig.callerCadEnable && mContext.callerCadBaseConfig.isShowCallInfo) {
            handleCallRingingState(mContext, number)
        }
    }

    fun onIncomingCallAnswered(ctx: Context?, number: String?) {
        mContext = ctx ?: return
        callerCadCallNumber = number.orEmpty()

        if (mContext.callerCadBaseConfig.callerCadEnable && mContext.callerCadBaseConfig.isShowCallInfo) {
            handleCallOffHookState(mContext, number)
        }

        removeOverlayViewIfVisible(ctx)
    }

    fun onIncomingCallEnded(ctx: Context?, number: String?, talkDuration: Long) {
        mContext = ctx ?: return
        callerCadCallNumber = number.orEmpty()
        callerCadCallType = "Incoming call"
        callType = "Incoming call"

        cadformattedTime = if (talkDuration > 0) {
            "Incoming call : ${formatTalkDuration(talkDuration)}"
        } else {
            "Incoming call"
        }

        if (mContext.callerCadBaseConfig.callerCadEnable) {
            handleCallIdleState(mContext)
        }
    }

    fun onOutgoingCallStarted(ctx: Context?, number: String?) {
        mContext = ctx ?: return
        callerCadCallNumber = number.orEmpty()

        if (mContext.callerCadBaseConfig.callerCadEnable && mContext.callerCadBaseConfig.isShowCallInfo) {
            handleCallOffHookState(mContext, number)
        }
    }

    fun onOutgoingCallEnded(ctx: Context?, number: String?, talkDuration: Long) {
        mContext = ctx ?: return
        callerCadCallNumber = number.orEmpty()
        callerCadCallType = "Outgoing call"
        callType = "Outgoing call"

        cadformattedTime = if (talkDuration > 0) {
            "Outgoing call : ${formatTalkDuration(talkDuration)}"
        } else {
            "No Answer"
        }

        if (mContext.callerCadBaseConfig.callerCadEnable) {
            handleCallIdleState(mContext)
        }
    }

    fun onMissedCall(ctx: Context?, number: String?, ringingDuration: Long) {
        mContext = ctx ?: return
        callerCadCallNumber = number.orEmpty()
        callType = "Missed call"
        callerCadCallType = "Missed call"

        cadformattedTime = if (ringingDuration > 0) {
            "Missed call : ${formatTalkDuration(ringingDuration)}"
        } else {
            "Missed call"
        }

        if (mContext.callerCadBaseConfig.callerCadEnable) {
            handleCallIdleState(mContext)
        }
    }
}