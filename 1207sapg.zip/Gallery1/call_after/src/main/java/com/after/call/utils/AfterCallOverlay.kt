package com.after.call.utils

import android.Manifest
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.after.call.AfterCallUtils
import com.after.call.R
import com.after.call.activity.AfterCallHomeActivity
import com.after.call.databinding.OverlayLayoutCallerBinding
import com.after.call.extensions.callerCadBaseConfig
import com.after.call.extensions.createBitmapFromText
import com.after.call.extensions.getUserPhotoByPhoneNumber
import kotlin.math.absoluteValue


object AfterCallOverlay {

    @SuppressLint("StaticFieldLeak")
    var binding: OverlayLayoutCallerBinding? = null
    var floatWindowLayoutParam: WindowManager.LayoutParams? = null
    var windowManager: WindowManager? = null
    var isWindowShowing: Boolean = false
    var callerCadCallNumber: String? = ""
    var cadformattedTime: String = ""
    var callType: String = "No answer"
    var seconds = 0
    var callerCadCallType = ""


    @SuppressLint("Range")
    fun retrieveNameFromDevice(context: Context, callNumber: String?): String? {
        if (ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_CALL_LOG
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return null
        }

        val cleanedCallNumber = callNumber?.filter { it.isDigit() }
        var cursor: Cursor? = null
        try {
            cursor = context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
                ),
                null,
                null,
                null
            )

            cursor?.use {
                while (it.moveToNext()) {
                    val contactNumber =
                        it.getString(it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER))
                            .filter { char -> char.isDigit() }

                    if (cleanedCallNumber?.takeLast(7) == contactNumber.takeLast(7)) {
                        return it.getString(it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME))
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("AfterCallOverlay", "Error retrieving contact name: ${e.message}")
        } finally {
            cursor?.close()
        }
        return null
    }

//    val themesOverlay = arrayOf(
//        R.drawable.ic_after_call_theme_overlay_style1,
//        R.drawable.ic_after_call_theme_overlay_style2,
//        R.drawable.ic_after_call_theme_overlay_style3,
//        R.drawable.ic_after_call_theme_overlay_style4,
//        R.drawable.ic_after_call_theme_overlay_style5,
//        R.drawable.ic_after_call_theme_overlay_style6,
//        R.drawable.ic_after_call_theme_overlay_style7,
//        R.drawable.ic_after_call_theme_overlay_style8
//    )

    fun displayWindowView(mContext: Context) {


        if (AfterCallHomeActivity.isActivityOpen) {
            AfterCallHomeActivity.finishActivity()
        }


        binding = OverlayLayoutCallerBinding.inflate(LayoutInflater.from(mContext))
        windowManager = mContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val displayMetrics = DisplayMetrics()
        windowManager?.defaultDisplay?.getMetrics(displayMetrics)


        floatWindowLayoutParam = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    or WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                    or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                    or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )

        if (callerCadCallNumber?.isNotEmpty() == true) {

            binding?.number?.text = callerCadCallNumber
        } else {
            binding?.number?.text = mContext.resources.getString(R.string.after_call_private_number)
        }

        val themeResource = R.drawable.after_call_bg_round_top
//            themesOverlay.getOrNull(mContext.callerCadBaseConfig.callerCadSelectedTheme)
//                ?: R.drawable.ic_after_call_theme_overlay_style1
//                ?:
        binding?.callerCadOverlayBg?.setBackgroundResource(themeResource)

        Looper.myLooper()?.let {
            Handler(it).postDelayed({
                if (callerCadCallNumber?.isNotEmpty() == true) {
                    // If callNumber is not empty, try to retrieve name from device
                    val name = retrieveNameFromDevice(mContext, callerCadCallNumber!!)

                    // Update the name or callNumber in the binding
                    binding?.number?.text = name ?: callerCadCallNumber

                    // Load or create user image
                    if (hasContactPermission(mContext)) {
                        val userImageBitmap =
                            getUserPhotoByPhoneNumber(callerCadCallNumber!!, mContext)

                        if (userImageBitmap != null) {
                            // Load the user image if available
                            Glide.with(mContext).load(userImageBitmap)
                                .placeholder(R.drawable.ic_after_call_user_new)
                                .error(R.drawable.ic_after_call_user_new)
                                .into(binding?.mIVUser ?: return@postDelayed)
                        } else {
                            // Create a bitmap with the first character of the name
                            if (!name.isNullOrEmpty()) {
                                val firstChar = name.first().toString()
                                val bitmap = createBitmapFromText(firstChar)
                                binding?.mIVUser?.setImageBitmap(bitmap)
                            } else {
                                // Set default image if name is null or empty
                                binding?.mIVUser?.setImageDrawable(
                                    AppCompatResources.getDrawable(
                                        mContext, R.drawable.ic_after_call_user_new
                                    )
                                )
                            }
                        }
                    } else {
                        // Set default image if permission is not granted
                        binding?.mIVUser?.setImageDrawable(
                            AppCompatResources.getDrawable(
                                mContext, R.drawable.ic_after_call_user_new
                            )
                        )
                    }
                } else {
                    // If callNumber is empty, display "Private number"
                    binding?.number?.text =
                        mContext.resources.getString(R.string.after_call_private_number)

                    // Set default image
                    binding?.mIVUser?.setImageDrawable(
                        AppCompatResources.getDrawable(
                            mContext, R.drawable.ic_after_call_user_new
                        )
                    )
                }
            }, 1000)
        }

        val overlayView: View = binding!!.root
        floatWindowLayoutParam?.gravity = Gravity.TOP

        floatWindowLayoutParam?.windowAnimations = R.style.CallerEnterAnim
        floatWindowLayoutParam?.x = 0
        floatWindowLayoutParam?.y = 0


        val animSlideIn = AnimatorSet()
        animSlideIn.playTogether(
            ObjectAnimator.ofFloat(overlayView, "translationX", 0f),
            ObjectAnimator.ofFloat(overlayView, "translationY", 0f)
        )
        animSlideIn.duration = 5000
        animSlideIn.start()

        val CLICK_THRESHOLD = 5


        overlayView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = floatWindowLayoutParam?.x ?: 0
                    initialY = floatWindowLayoutParam?.y ?: 0
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    floatWindowLayoutParam?.apply {
                        x = (initialX + (event.rawX - initialTouchX)).toInt()
                        y = (initialY + (event.rawY - initialTouchY)).toInt()
                        windowManager?.updateViewLayout(overlayView, this)
                    }
                    true
                }

                MotionEvent.ACTION_UP -> {
                    if ((event.rawX - initialTouchX).absoluteValue < CLICK_THRESHOLD &&
                        (event.rawY - initialTouchY).absoluteValue < CLICK_THRESHOLD
                    ) {
                        overlayView.performClick()
                    }
                    true
                }

                else -> false
            }
        }



        binding?.icClose?.setOnClickListener(object : CallerOnSingleClickListener() {
            override fun onSingleClick(v: View?) {
                try {
                    windowManager?.removeViewImmediate(binding!!.root)
                    windowManager?.removeView(binding!!.root)
                } catch (e: Exception) {
                }
                overlayView.visibility = View.GONE
                isWindowShowing = false
                stopCounter()
            }

        })



        try {
            if (AfterCallUtils.getLogoFromSharedPreferences(mContext) == null) {

                binding?.icAppIcon?.visibility = View.GONE
            } else {
                binding?.icAppIcon?.setImageDrawable(
                    AfterCallUtils.getLogoFromSharedPreferences(
                        mContext
                    )
                )
                binding?.icAppIcon?.visibility = View.VISIBLE
            }

        } catch (e: Exception) {
            binding?.icAppIcon?.visibility = View.GONE
        }


        windowManager?.addView(
            overlayView,
            floatWindowLayoutParam
        )
        isWindowShowing = true


        /* if (state == CallerCallState.STATE_RINGING || state == CallerCallState.STATE_OFFHOOK) {
             binding?.mTVDuration?.let {
                 startCounter(binding?.mTVDuration!!)
             }
         }*/

        startCountCall()
    }

    fun startCountCall() {
        binding?.mTVDuration?.let {
            startCounter(binding?.mTVDuration!!)
        }
    }

    var initialTouchX = 0.0f
    var initialTouchY = 0.0f
    var initialX = 0
    var initialY = 0

    private var counterHandler: Handler? = null
    private var counterRunnable: Runnable? = null

    fun startCounter(duration: TextView) {
        seconds = 0
        counterHandler = Handler(Looper.getMainLooper())
        counterRunnable = object : Runnable {
            override fun run() {
                seconds++
                val minutes = seconds / 60
                val remainingSeconds = seconds % 60
                val formattedTime = String.format("%02d:%02d", minutes, remainingSeconds)
                duration.text = "Duration: $formattedTime"
                counterHandler?.postDelayed(this, 1000)
            }
        }
        counterHandler?.post(counterRunnable!!)
    }

    fun stopCounter() {
        counterHandler?.removeCallbacks(counterRunnable!!)
        counterHandler = null
    }


    fun hasContactPermission(context: Context?): Boolean {
        return (ContextCompat.checkSelfPermission(context!!, Manifest.permission.READ_CONTACTS)
                == PackageManager.PERMISSION_GRANTED)
    }

}