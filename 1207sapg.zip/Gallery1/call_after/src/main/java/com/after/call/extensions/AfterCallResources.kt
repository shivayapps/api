package com.after.call.extensions

import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import com.after.call.R

fun Resources.getColoredBitmap(resourceId: Int, newColor: Int): Bitmap {
    val drawable = getDrawable(resourceId)
    val bitmap = Bitmap.createBitmap(
        drawable.intrinsicWidth,
        drawable.intrinsicHeight,
        Bitmap.Config.ARGB_8888
    )
    val canvas = Canvas(bitmap)
    drawable.setBounds(0, 0, canvas.width, canvas.height)
    drawable.colorFilter = PorterDuffColorFilter(newColor, PorterDuff.Mode.SRC_IN)
    drawable.draw(canvas)
    return bitmap
}

//val themeCallerResources = arrayOf(
//    R.drawable.ic_after_call_theme_bg_style1,
//    R.drawable.ic_after_call_theme_bg_style1,
//    R.drawable.ic_after_call_theme_bg_style3,
//    R.drawable.ic_after_call_theme_bg_style4,
//    R.drawable.ic_after_call_theme_bg_style5,
//    R.drawable.ic_after_call_theme_bg_style6,
//    R.drawable.ic_after_call_theme_bg_style7,
//    R.drawable.ic_after_call_theme_bg_style8
//)


fun Resources.hasNavBar(): Boolean {
    val id = getIdentifier("config_showNavigationBar", "bool", "android")
    return id > 0 && getBoolean(id)
}

fun Resources.getNavBarHeight(): Int {
    val id = getIdentifier("navigation_bar_height", "dimen", "android")
    return if (id > 0 && hasNavBar()) {
        getDimensionPixelSize(id)
    } else
        0
}







