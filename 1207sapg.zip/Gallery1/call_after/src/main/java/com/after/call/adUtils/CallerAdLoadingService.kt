package com.after.call.adUtils

import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import com.after.call.bannerad.CallerBannerAdManager
import com.after.call.extensions.callerCadBaseConfig
import com.after.call.extensions.isInternetConnected
import com.after.call.nativead.CallerNativeAdManager
import com.after.call.utils.CallerLogger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.greenrobot.eventbus.EventBus

enum class ServiceAction(val value: String) {
    START_ACTION("start"),
    STOP_ACTION("stop")
}

class AdLoadingService : Service() {
    val TAG = "AdLoadingService: "
    val callerNativeAdManager: CallerNativeAdManager by lazy {
        CallerNativeAdManager.getInstance(this)
    }
    val callerBannerAdManager: CallerBannerAdManager by lazy {
        CallerBannerAdManager.getInstance(this)
    }

    private val binder by lazy {
        MyBinder()
    }

    inner class MyBinder : Binder() {
        fun getService() = this@AdLoadingService
    }

    override fun onBind(intent: Intent?): IBinder {
        CallerLogger.logE(TAG + "onBind: ")

        return binder
    }

    override fun onRebind(intent: Intent?) {
        CallerLogger.logE(TAG + "onRebind: ")
        super.onRebind(intent)
    }

    override fun onCreate() {
        super.onCreate()


        if (callerCadBaseConfig.callerCadAdEnable && isInternetConnected()) {
            CoroutineScope(Dispatchers.IO).launch {
                loadNativeAd()
                loadBannerAd()
            }
        } else {
            EventBus.getDefault().post(MessageEvent(NO_ADS_VIEW))
        }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        CallerLogger.logE(TAG + "onUnbind: ")
        return super.onUnbind(intent)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }


    override fun onDestroy() {
        super.onDestroy()
        CallerLogger.logE(TAG + "onDestroy: ")
        // Clean up resources like loaded ads
        callerNativeAdManager.onDestroy()
        callerBannerAdManager.onDestroy()
    }

    fun runAction(action: ServiceAction) {
        when (action) {
            ServiceAction.START_ACTION -> startPlayback()
            ServiceAction.STOP_ACTION -> stopPlayback()
        }
    }

    private fun startPlayback() {
        CallerLogger.logE(TAG + "startPlayback: ")

    }

    private fun stopPlayback() {
        CallerLogger.logE(TAG + "stopPlayback: ")
    }

    private var isNativeAdLoadedOnce = false
    private var isBannerAdLoadedOnce = false

    private suspend fun loadNativeAd() {
        if (!isNativeAdLoadedOnce) {
            isNativeAdLoadedOnce = true // Set the flag
            withContext(Dispatchers.IO) {
                if (!callerNativeAdManager.isAdLoaded()) {
                    CallerLogger.logE("$TAG loadNativeAd:")
                    callerNativeAdManager.isAdLoadedNative = true
                    callerNativeAdManager.loadNativeAd()
                }
            }
        }


    }

    private suspend fun loadBannerAd() {
        if (!isBannerAdLoadedOnce) {

            isBannerAdLoadedOnce = true
            withContext(Dispatchers.Main) {
                if (!callerBannerAdManager.isAdLoaded()) {
                    CallerLogger.logE("$TAG loadBannerAd:")
                    callerBannerAdManager.isAdLoadedBanner = true
                    callerBannerAdManager.loadBannerAd()
                }
            }
        }


    }

    /* private suspend fun loadNativeAd() {
         withContext(Dispatchers.IO) {
             if (!callerNativeAdManager.isAdLoaded()) {
                 CallerLogger.logE(TAG + "loadNativeAd: ")
                 callerNativeAdManager.isAdLoadedNative = true
                 callerNativeAdManager.loadNativeAd()
             }
         }
     }

     private suspend fun loadBannerAd() {
         withContext(Dispatchers.Main) {
             if (!callerBannerAdManager.isAdLoaded()) {
                 CallerLogger.logE(TAG + "loadBannerAd: ")
                 callerBannerAdManager.isAdLoadedBanner = true
                 callerBannerAdManager.loadBannerAd()
             }
         }
     }*/

}