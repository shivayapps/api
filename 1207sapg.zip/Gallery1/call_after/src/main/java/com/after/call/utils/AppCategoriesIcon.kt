package com.after.call.utils

import android.content.Context
import com.after.call.R
import com.after.call.extensions.callerCadBaseConfig

enum class AppCategoriesIcon(val imageResId: Int, val description: String) {

    CALLER_CAD_APP_BATTERY(R.drawable.ic_app_categories_battery, "Optimize Your Battery Life"),
    CALLER_CAD_APP_CALENDAR(R.drawable.ic_app_categories_calendar, "Stay organized, Stay Ahead"),
    CALLER_CAD_APP_DOCUMENTS(R.drawable.ic_app_categories_document, "All Your Docs, One Place"),
    CALLER_CAD_APP_EDUCATIONAL(R.drawable.ic_app_categories_education, "Study Smarter, Not Harder"),
    CALLER_CAD_APP_FILE_MANAGERS(
        R.drawable.ic_app_categories_folder,
        "Folder Management Made Simple"
    ),
    CALLER_CAD_APP_FINANCE(R.drawable.ic_app_categories_finance, "Control Your Finances Easily"),
    CALLER_CAD_APP_FITNESS_HEALTH(
        R.drawable.ic_app_categories_fitness_health,
        "Empower Your Fitness Journey"
    ),
    CALLER_CAD_APP_FOOD_RECIPES(R.drawable.ic_app_categories_food, "Food That Feels Like Home"),
    CALLER_CAD_APP_MESSAGING(R.drawable.ic_app_categories_message, "Stay Connected, Always"),
    CALLER_CAD_APP_MUSIC(R.drawable.ic_app_categories_music, "Play Your Favorite Beats"),
    CALLER_CAD_APP_PHOTOGRAPHY(R.drawable.ic_app_categories_photography, "Capture Life’s Moments"),
    CALLER_CAD_APP_SECURITY_ANTIVIRUS(
        R.drawable.ic_app_categories_security_lock,
        "The Key to Your Protection"
    ),
    CALLER_CAD_APP_SHOPPING(R.drawable.ic_app_categories_shopping, "Shopping, the Easy Way"),
    CALLER_CAD_APP_SPORTS(R.drawable.ic_app_categories_sport, "Where Passion Meets Play"),
    CALLER_CAD_APP_TRAVEL(R.drawable.ic_app_categories_travel, "Find Your Next Adventure"),
    CALLER_CAD_APP_VIDEOGRAPHY(R.drawable.ic_app_categories_video, "Play Your Favorite Moments");

    companion object {


        fun saveOpenIconFromPosition(context: Context, appCategoriesIcon: AppCategoriesIcon) {

            context.callerCadBaseConfig.callerCadAppOpenIcon = appCategoriesIcon.ordinal


            context.callerCadBaseConfig.callerCadAppOpenDescription = appCategoriesIcon.description
        }

        fun appOpenIconFromPosition(context: Context): AppCategoriesIcon? {
            return values().getOrNull(context.callerCadBaseConfig.callerCadAppOpenIcon) // Returns null if position is out of bounds
        }

        fun getDefaultDescriptionFromPosition(context: Context): String? {
            return context.callerCadBaseConfig.callerCadAppOpenDescription
        }




    }


}