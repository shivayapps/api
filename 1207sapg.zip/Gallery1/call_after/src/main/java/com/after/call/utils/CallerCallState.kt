package com.after.call.utils

enum class CallerCallState{
    STATE_OFFHOOK,STATE_RINGING,STATE_IDLE
}