plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
    alias(libs.plugins.ksp)
    id("maven-publish")
}
android {
    namespace = "com.after.call"
    compileSdk = 35

    defaultConfig {
        minSdk = 26
        targetSdk = 35
        multiDexEnabled = true
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        ndk {
            abiFilters += listOf("armeabi-v7a", "arm64-v8a", "x86", "x86_64")
        }
    }
    buildTypes {
        debug {
            isMinifyEnabled = true
            isShrinkResources = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            consumerProguardFiles("consumer-rules.pro")
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            consumerProguardFiles("consumer-rules.pro")
        }
    }
    buildFeatures {
        viewBinding = true
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
//        isCoreLibraryDesugaringEnabled = true
    }
    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs = listOf(
            "-Xstring-concat=inline"
        )
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
        baseline = file("lint-baseline.xml")
    }

}

//publishing {
//    publications {
//        create<MavenPublication>("callercad") {
////        maven("callercad") {
//            groupId = "com.after.call"
//            artifactId = "callercard"
//            version = "1.9.7"
//            artifact("./build/outputs/aar/callercard-release.aar")
//        }
//    }
//    repositories {
//        maven {
//            name = "GitLab"
//            url = uri("https://gitlab.com/api/v4/projects/58218588/packages/maven")
//            credentials(HttpHeaderCredentials::class) {
//                name = "Private-Token"
//                value = "glpat-vhA3y3MYjP2rwBQM2ant"
//            }
//            authentication {
//                create<HttpHeaderAuthentication>("header")
//            }
//        }
//    }
//}

dependencies {

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity:1.9.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("com.intuit.sdp:sdp-android:1.1.1")
    implementation("org.greenrobot:eventbus:3.3.1")
    implementation("androidx.multidex:multidex:2.0.1")

    implementation("com.github.bumptech.glide:glide:4.12.0")
    implementation(platform(libs.firebase.bom))
    implementation(libs.firebase.config)

    annotationProcessor("com.github.bumptech.glide:compiler:4.12.0")

    implementation("com.google.code.gson:gson:2.8.6")
    implementation("androidx.recyclerview:recyclerview:1.2.1")

//    implementation("io.github.ParkSangGwon:tedpermission-normal:3.4.2")
//    implementation("org.lsposed.hiddenapibypass:hiddenapibypass:5.0")

    //mediation
    implementation("com.google.android.gms:play-services-ads:23.6.0")

    implementation("androidx.window:window:1.1.0")

    implementation("androidx.browser:browser:1.8.0")


}