# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}

# Uncomment this to preserve the line number information for
# debugging stack traces.
#-keepattributes SourceFile,LineNumberTable

# If you keep the line number information, uncomment this to
# hide the original source file name.
#-renamesourcefileattribute SourceFile
-dontshrink
-keepattributes *Annotation*
-keepclassmembers class ** {
    @org.greenrobot.eventbus.Subscribe <methods>;
}
-keep enum org.greenrobot.eventbus.ThreadMode { *; }

-dontwarn com.facebook.infer.annotation.Nullsafe$Mode
-dontwarn com.facebook.infer.annotation.Nullsafe


-keepclassmembers class ** {
    public void onEvent*(**);
}



-keep class org.greenrobot.eventbus.** { *; }
-dontwarn org.greenrobot.eventbus.**
 -keep class com.after.call.adUtils.CallerMessageEventKt { *; }


-dontwarn com.gun0912.tedpermission.PermissionBuilder
-dontwarn com.gun0912.tedpermission.PermissionListener
-dontwarn com.gun0912.tedpermission.normal.TedPermission$Builder
-dontwarn com.gun0912.tedpermission.normal.TedPermission
-dontwarn com.gun0912.tedpermission.provider.TedPermissionProvider
-dontwarn org.jacoco.core.**
-dontwarn java.lang.**

 # Keep all files
 # Keep all files
# -keep class com.after.call.** { *; }

 # Keep specific file

 -keep class com.after.call.receivers.CallerSetupAfterCallReceiver.** { *; }
 -keep class com.after.call.receivers.AfterCallPhoneCallReceiver.** { *; }
 -keep class com.after.call.receivers.AfterCallCallReceiver { *; }
-keep class com.after.call.keep.** { *; }
 -keep class com.after.call.adapter.** { *; }
 -keep class com.after.call.adUtils.** { *; }
 -keep class com.after.call.bannerad.** { *; }
 -keep class com.after.call.fragments.** { *; }
 -keep class com.after.call.fragments.** { *; }
 -keep class com.after.call.nativead.** { *; }
 -keep class com.after.call.extensions.** { *; }
 -keep class com.after.call.helpers.** { *; }
 -keep class com.after.call.utils.** { *; }
 -keep class com.after.call.wheelpicker.** { *; }
-keep class com.after.call.R$id { *; }
 # Obfuscation dictionaries
-obfuscationdictionary obfuscation-dictionary.txt
 -classobfuscationdictionary class-obfuscation-dictionary.txt
 -packageobfuscationdictionary package-obfuscation-dictionary.txt


# Keep resource IDs
-keepclassmembers class **.R$* {
    public static <fields>;
}

# Keep activity and fragment classes
-keep class * extends android.app.Activity
-keep class * extends android.app.Fragment
-keep class * extends androidx.fragment.app.Fragment


# Ensure all layout resource IDs are kept
-keep public class * extends android.view.View {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
    void set*(...);
}

# Preserve any class that references layout resources directly
-keep class * {
    public static final int id;
}


# Keep AdMob classes
-keep public class com.google.android.gms.ads.** { *; }
-keepclassmembers class com.google.android.gms.ads.** {
    public *;
    protected *;
    private *;
}
-keep public class com.google.android.gms.ads.** { public *; }
-keep public class com.google.ads.** { public *; }
-keep class com.google.android.gms.** { *; }
-keep class com.google.android.gms.ads.** { *; }
-keep class com.google.android.gms.ads.AdRequest { *; }
-keep class com.after.call.utils.CustomNativeValue { *; }
-keep class com.after.call.utils.AppCategoriesIcon { *; }
-keep class com.after.call.utils.SuggestionAppDetail.** { *; }
-keep class com.after.call.utils.GridItem.** { *; }
-keepnames class com.google.android.gms.ads.AdRequest { *; }

-keepclassmembers class com.google.android.gms.ads.** { *; }
-dontwarn com.google.android.gms.**
-keep public class com.google.android.gms.common.internal.safeparcel.SafeParcelable { public static final *** NULL; }
-keepnames class * implements android.os.Parcelable
-keepclassmembers class * implements android.os.Parcelable { public static final *** CREATOR; }
-keep @interface com.google.android.gms.common.annotation.KeepName
-keepnames @com.google.android.gms.common.annotation.KeepName class *
-keepclassmembernames class * { @com.google.android.gms.common.annotation.KeepName *; }
-keep @interface com.google.android.gms.common.util.DynamiteApi
-keep class com.google.android.apps.common.proguard.UsedBy*
-keep @com.google.android.apps.common.proguard.UsedBy* class *
-keepclassmembers class * { @com.google.android.apps.common.proguard.UsedBy* *; }
-dontwarn android.security.NetworkSecurityPolicy
-dontwarn android.app.Notification
-keep class com.facebook.** {
   *;
}
-keep class com.google.ads.mediation.admob.AdMobAdapter { *; }
-keep class com.google.ads.mediation.** { *; }
-keep class com.facebook.infer.annotation.** { *; }

-keep public class com.facebook.** { public *; }
-keepclasseswithmembers class * {
    *** *onError(...);
}
-keep class com.loopj.android.** { *; }
-keep class com.after.call.AfterCallUtils.** { *; }
-keep class com.after.call.utils.Helper.** { *; }
-keep class sun.misc.Unsafe.** { *; }
-keep class dalvik.system.VMRuntime.** { *; }
-keep class com.after.call.utils.AfterCallExpandableLayout.** { *; }
-keep class com.after.call.utils.AfterCallRoundedImageView.** { *; }
-keep class com.after.call.helpers.AfterCallBaseConfig.** { *; }
-keep class com.after.call.helpers.AfterCallConstantsKt.** { *; }
-keep class com.after.call.extensions.CallerExtensionsKt.** { *; }
-keep class com.after.call.extensions.DrawableKt.** { *; }
-keep class com.after.call.extensions.AfterCallEditTextKt.** { *; }
-keep class com.after.call.extensions.Extensions.** { *; }
-keep class com.after.call.extensions.IntKt.** { *; }
-keep class com.after.call.extensions.AfterCallContextKt.** { *; }
-keep class com.after.call.extensions.StringKt.** { *; }
-keep class com.after.call.extensions.AfterCallResourcesKt.** { *; }
-keep class messages.sms.text.chat.messanger.app.commons.helpers.ConstantsKt.** { *; }
-keep interface com.loopj.android.** { *; }
-keepclasseswithmembers class * {
    *** *onAdLoaded(...);
}
-keepclasseswithmembers class * {
    *** *onAdClicked(...);
}

# TedPermission library rules
-keep class gun0912.tedpermission.** { *; }
-keepclassmembers class gun0912.tedpermission.** { *; }
-keepattributes *Annotation*

# Support for reflection
-dontwarn gun0912.tedpermission.**

# Keep Parcelable implementation for TedPermission
-keepclassmembers class ** implements android.os.Parcelable {
    static ** CREATOR;
}


-if class com.google.gson.reflect.TypeToken
-keep,allowobfuscation class com.google.gson.reflect.TypeToken

-keep,allowobfuscation class * extends com.google.gson.reflect.TypeToken
-keep,allowobfuscation,allowoptimization @com.google.gson.annotations.JsonAdapter class *

# Retain CustomNativeValue class and its fields
-keep class com.after.call.utils.CustomNativeValue {
    <fields>;
}

# Preserve generic type parameters for Gson
-keepattributes Signature
-keepattributes *Annotation*


# Prevent obfuscation of Gson TypeToken
-keep class com.google.gson.reflect.TypeToken {
    <init>();
}

-keepclassmembers,allowobfuscation class * {
  @com.google.gson.annotations.Expose <fields>;
  @com.google.gson.annotations.JsonAdapter <fields>;
  @com.google.gson.annotations.Since <fields>;
  @com.google.gson.annotations.Until <fields>;
}

-keepclassmembers class * extends com.google.gson.TypeAdapter {
  <init>();
}
-keepclassmembers class * implements com.google.gson.TypeAdapterFactory {
  <init>();
}
-keepclassmembers class * implements com.google.gson.JsonSerializer {
  <init>();
}
-keepclassmembers class * implements com.google.gson.JsonDeserializer {
  <init>();
}

-if class *
-keepclasseswithmembers,allowobfuscation class <1> {
  @com.google.gson.annotations.SerializedName <fields>;
}
-if class * {
  @com.google.gson.annotations.SerializedName <fields>;
}

# Retain the type information for Gson's TypeToken
-keep class com.google.gson.reflect.TypeToken {
    <init>();
}

-keep class com.google.gson.reflect.TypeToken
-keep class * extends com.google.gson.reflect.TypeToken

-keep class com.after.call.utils.CustomNativeValue { *; }
-keep class com.google.gson.reflect.TypeToken { *; }
-keep class * extends com.google.gson.reflect.TypeToken { *; }

# Prevent obfuscation of any class used by Gson serialization/deserialization
-keepattributes Signature
-keepattributes *Annotation*

# Retain fields annotated with @SerializedName (if used)
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
}


##---------------Begin: proguard configuration for Gson  ----------
# Gson uses generic type information stored in a class file when working with fields. Proguard
# removes such information by default, so configure it to keep all of it.
-keepattributes Signature

# Gson specific classes
-keep class com.google.gson.stream.** { *; }

-keep class com.google.gson.** { *; }
-keep class com.google.gson.reflect.** { *; }


-keep class com.applovin.** { *; }
#-assumenosideeffects class android.util.Log {
#    public static *** v(...);
#    public static *** d(...);
#    public static *** i(...);
#    public static *** w(...);
#    public static *** e(...);
#}
-keep class com.google.android.gms.internal.ads.**{ *; }

-dontwarn dalvik.system.VMRuntime

-keepattributes *Annotations


