package com.adconfig.adsutil.admob

import android.app.Activity
import android.content.Context
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.adconfig.adsutil.AdsParameters
import com.adconfig.adsutil.Config
import com.adconfig.adsutil.admob.BannerAdHelper.getAdSize
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError

class AdmobBanner {

//    var mNativeAd: NativeAd? = null

    val TAG = "BannerHelper_Banner"
    fun preLoad(
        mContext: Context,
        adId: String,
        listener: (isLoaded: Boolean) -> Unit?
    ) {

        if (Config.bannerAd != null && !Config.isBannerImpression) {
            Log.i(TAG, "preLoad.001:${adId}")
            listener.invoke(true)
        } else {
            var adView = AdView(mContext)

            Log.d(TAG, "001.showBanner: Banner Id -> $adId")

            adView.adListener = object : AdListener() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    listener.invoke(false)
                    Log.i(
                        TAG,
                        "001.onAdFailedToLoad: Ad failed to load -> \nresponseInfo::${adError.responseInfo}\nErrorCode::${adError.code}\nErrorMessage::${adError.message}"
                    )
                }

                override fun onAdLoaded() {
                    try {
                        Config.bannerAd = adView
                        Config.isBannerImpression = false
                        Log.d(TAG, "001.onAdLoaded")
                        listener.invoke(true)
                    } catch (e: Exception) {

                    }
                }

                override fun onAdImpression() {
                    Log.d(TAG, "001.onAdImpression")
                    Config.isBannerImpression = true
                    Config.bannerAd = null
                    super.onAdImpression()
                }

                override fun onAdClicked() {
                    super.onAdClicked()
                    Log.d(TAG, "001.onAdClicked")
                }
            }
            adView.setAdSize(
                getAdSize(
                    mContext
                )
            )
            adView.adUnitId = adId
            adView.loadAd(AdRequest.Builder().build())
        }
    }

    fun getAdSize(activity: Context): AdSize {
//        val display = activity.windowManager.defaultDisplay
//        val outMetrics = DisplayMetrics()
//        display.getMetrics(outMetrics)
//        val widthPixels = outMetrics.widthPixels.toFloat()
//        val density = outMetrics.density
//        val adWidth = (widthPixels / density).toInt()
        val adWidth = AdsParameters(activity).adWidth
//        Log.e(TAG, "adWidth:$adWidth")

        // Step 3 - Get adaptive ad size and return for setting on the ad view.
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(
            activity, adWidth
        )
    }

    fun showBannerAd(
        mContext: Context,
        frameLayout: FrameLayout
    ) {
        var adView = AdView(mContext)
        adView.adListener = object : AdListener() {
            override fun onAdFailedToLoad(adError: LoadAdError) {
                frameLayout.visibility = View.GONE

                Log.i(
                    TAG,
                    "002.onAdFailedToLoad: Ad failed to load -> \nresponseInfo::${adError.responseInfo}\nErrorCode::${adError.code}\nErrorMessage::${adError.message}"
                )
            }

            override fun onAdLoaded() {
                try {
                    Log.d(TAG, "002.onAdLoaded")
                } catch (e: Exception) {

                }

            }
            override fun onAdImpression() {
                Log.d(TAG, "002.onAdImpression")
                Config.isBannerImpression = true
                Config.bannerAd = null
                super.onAdImpression()
            }

            override fun onAdClicked() {
                super.onAdClicked()
                Log.d(TAG, "002.onAdClicked")
            }
        }

        if (Config.bannerAd != null) {
            adView = Config.bannerAd!!

            Log.d(TAG, "onLoadCacheAdView")
            if (adView.parent != null) (adView.parent as ViewGroup).removeView(adView)
            frameLayout.removeAllViews()

            val layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )

            layoutParams.gravity = Gravity.CENTER or Gravity.BOTTOM
            frameLayout.post {
                try {
                    if (adView.parent != null) (adView.parent as ViewGroup).removeView(adView)
                    frameLayout.removeAllViews()
                    frameLayout.addView(adView, layoutParams)
                    frameLayout.bringChildToFront(adView)
                    frameLayout.visibility = View.VISIBLE
                    //parent.visibility = View.VISIBLE
                    frameLayout.invalidate()
                    frameLayout.requestLayout()
                    adView.resume()
                } catch (e: Exception) {
                    Log.d(TAG, "Exception:$e")
                    frameLayout.visibility = View.GONE
                    //parent.visibility = View.GONE
                }
            }

        }

    }




}