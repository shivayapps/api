package com.adconfig.adsutil.admob

import android.app.Activity
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.adconfig.AdsConfig
import com.adconfig.R
import com.adconfig.adsutil.AdsParameters
import com.adconfig.adsutil.utils.isOnline
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import androidx.core.view.isNotEmpty
import com.adconfig.adsutil.utils.AdListenerEvent
import com.adconfig.adsutil.utils.AdListenerType
import org.greenrobot.eventbus.EventBus


object BannerAdHelper {

//    fun View.slideDown(duration: Long = 300) {
//        animate().translationY(height.toFloat()).setDuration(duration)
//            .withEndAction { visibility = View.GONE }
//    }
//    fun View.slideUp(duration: Long = 300) {
//        translationY = height.toFloat()
//        visibility = View.VISIBLE
//        animate().translationY(0f).setDuration(duration).start()
//    }

    val TAG = "ADCONFIG_BannerAdHelper"
    fun showBanner(
        context: Activity,
        container: ViewGroup,
//        parent: ViewGroup,
        adId: String,
        cacheAdView: AdView?,
        hideOnFail: Boolean = true,
        onLoaded: (isLoaded: Boolean, adView: AdView?, message: String) -> Unit,
        mAdSize: AdSize? = null,
    ) {

        if (!context.isOnline()) {
            container.visibility = View.GONE
            return
        }

        var adView = AdView(context)

        adView.adListener = object : AdListener() {
            override fun onAdFailedToLoad(adError: LoadAdError) {
                onLoaded.invoke(
                    false,
                    null,
                    "001.onAdFailedToLoad:${adError.code},${adError.message}"
                )
                Log.i(
                    TAG,
                    "001.onAdFailedToLoad: Ad failed to load -> \nresponseInfo::${adError.responseInfo}\nErrorCode::${adError.code}\nErrorMessage::${adError.message}"
                )
                if (hideOnFail) {
                    container.visibility = View.GONE
//                    parent.visibility = View.GONE
                }
            }

            override fun onAdLoaded() {
                try {
                    CoroutineScope(Dispatchers.Main).launch {
                        onLoaded.invoke(true, adView, "ok")
                        val oldParent = adView.parent as? ViewGroup
                        oldParent?.removeView(adView)
//                        oldParent?.slideDown()
                        container.removeAllViews()
                        Log.i(TAG, "onAdLoaded.addView")
                        container.visibility = View.VISIBLE
//                        parent.visibility = View.VISIBLE
                        container.addView(adView)
//                        container.slideUp()
                        adView.resume()
//                        EventBus.getDefault().post(AdListenerEvent(AdListenerType.onAdLoaded))
                    }
                } catch (e: Exception) {
                    Log.i(TAG, "onAdLoaded: Exception:$e")
                }

            }

            override fun onAdClicked() {
                super.onAdClicked()
                AdsConfig.isDialogOpen = true
            }
        }



        if (cacheAdView != null) {
            cacheAdView.pause()
            adView = cacheAdView

            if (adView.parent != null) (adView.parent as ViewGroup).removeView(adView)
//            if (adView.parent != null) (adView.parent as ViewGroup).removeAllViews()
            if (container.childCount > 0) container.removeAllViews()

//            val layoutParams = FrameLayout.LayoutParams(
//                ViewGroup.LayoutParams.MATCH_PARENT,
//                ViewGroup.LayoutParams.WRAP_CONTENT
//            )
//            layoutParams.gravity = Gravity.CENTER or Gravity.BOTTOM
            container.post {
                try {
//                    if (adView.parent != null) (adView.parent as ViewGroup).removeView(adView)
//                    if (container.childCount > 0) container.removeAllViews()
                    container.addView(adView)
                    adView.resume()
                    container.bringChildToFront(adView)
                    onLoaded.invoke(true, adView, "cache")
//                    container.visibility = View.VISIBLE
//                    parent.visibility = View.VISIBLE
//                    container.invalidate()
//                    container.requestLayout()
//                    adView.resume()
                } catch (e: Exception) {
                    container.visibility = View.GONE
//                    parent.visibility = View.GONE
                }
            }

        } else {
            if (mAdSize != null) {
                Log.d(TAG, "onLoadAdView.mAdSize-:${mAdSize.height}:${mAdSize.width}:-")
                adView.setAdSize(mAdSize)
            } else {
                val adSize = getAdSize(
                    context, container
                )
                Log.d(TAG, "onLoadAdView.adSize-:${adSize.height}:${adSize.width}:-")
                adView.setAdSize(
                    adSize
                )
            }
            Log.d("LoadAd", "loadBannerAd:$adId")
            adView.adUnitId = adId
            adView.loadAd(AdRequest.Builder().build())
        }

    }

    fun getAdSize(activity: Activity, view: ViewGroup): AdSize {
        val display = activity.windowManager.defaultDisplay
        val outMetrics = DisplayMetrics()
        display.getMetrics(outMetrics)
        val widthPixels = outMetrics.widthPixels.toFloat()
        val density = outMetrics.density
        val adWidth = (widthPixels / density).toInt()
//        val adWidth = AdsParameters(activity).adWidth
        Log.e(TAG, "adWidth:$adWidth")

        // Step 3 - Get adaptive ad size and return for setting on the ad view.
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(
            activity, adWidth
        )
    }


}