package com.adconfig.adsutil.admob

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.adconfig.R
import com.adconfig.adsutil.Config
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.VideoOptions
import com.google.android.gms.ads.nativead.AdChoicesView
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import java.lang.Exception

class AdmobNative {

//    var mNativeAd: NativeAd? = null

    val TAG = "BannerHelper_Native"
    fun preLoad(
        mContext: Context,
        adId: String,
        listener: (isLoaded: Boolean) -> Unit?
    ) {

        if(Config.nativeAd!=null && !Config.isNativeImpression) {
            Log.i(TAG, "preLoad.001:${adId}")
            listener.invoke(true)
        }else{
            Log.i(TAG, "preLoad.002:${adId}")
            val videoOptionBuilder = VideoOptions.Builder()
                .setClickToExpandRequested(true)
                .setStartMuted(true)

            val nativeAdOptionsBuilder = NativeAdOptions.Builder()
                .setVideoOptions(videoOptionBuilder.build())

            val adLoader = AdLoader.Builder(mContext, adId)
                .forNativeAd { nativeAd: NativeAd ->
                    Config.nativeAd = nativeAd
                    Config.isNativeImpression = false
                    Log.i(TAG, "onNativePreLoaded")
                    listener.invoke(true)
                }
                .withAdListener(object : AdListener() {
                    override fun onAdFailedToLoad(adError: LoadAdError) {
                        Log.i(TAG, "onAdFailedToLoad: Ad failed to load -> \nresponseInfo::${adError.responseInfo}\nErrorCode::${adError.code}\nErrorMessage::${adError.message}")
                        listener.invoke(false)
                    }

                    override fun onAdImpression() {
                        Config.isNativeImpression = true
                        Config.nativeAd = null
                        Log.i(TAG, "onAdImpression")
                        super.onAdImpression()
                    }
                })
                .withNativeAdOptions(nativeAdOptionsBuilder.build())
                .build()

            adLoader.loadAd(AdRequest.Builder().build())
        }
    }

    fun showNativeAd(
        mContext: Context,
        frameLayout: FrameLayout
    ) {
        if (Config.nativeAd != null) {
            Log.i(TAG, "populateAdmobNativeAd")
            populateAdmobNativeAd(mContext, frameLayout, Config.nativeAd!!)
//            Config.nativeAd = null
        }

    }

//    public fun showNativeAd(
//        mContext: Context,
//        frameLayout: FrameLayout,
//        mNativeAd: NativeAd? = null,
//        adId: String
//    ) {
//        if (mNativeAd != null) {
//            populateAdmobNativeAd(mContext, frameLayout, mNativeAd)
//        } else {
//            preLoad(mContext, adId, { isLoaded ->
//                if (isLoaded) {
//                    populateAdmobNativeAd(mContext, frameLayout, Config.nativeAd!!)
//                }
//            })
//        }
//    }

    private fun populateAdmobNativeAd(
        mContext: Context,
        frameLayout: FrameLayout,
        nativeAd: NativeAd
    ) {
        val mTextColor = ContextCompat.getColor(mContext, R.color.title_color)
        val mBodyColor = ContextCompat.getColor(mContext, R.color.body_color)
        val mLayout = R.layout.layout_google_native_ad_banner
        val adView = LayoutInflater.from(mContext).inflate(mLayout, null) as NativeAdView
        frameLayout.removeAllViews()
        frameLayout.addView(adView)
        frameLayout.visibility = View.VISIBLE

        val headlineView = adView.findViewById<TextView>(R.id.ad_headline)
        if (headlineView != null) {
            headlineView.setTextColor(mTextColor)
            headlineView.text = nativeAd.headline
            adView.headlineView = headlineView
        }

        val bodyView = adView.findViewById<TextView>(R.id.ad_body)
        if (bodyView != null) {
            bodyView.setTextColor(mBodyColor)
            bodyView.text = nativeAd.body
            adView.bodyView = bodyView
        }

//        val adChoiceView = adView.findViewById<AdChoicesView>(R.id.adChoiceView)
//        if (adChoiceView != null) {
//            adView.adChoicesView = adChoiceView
//        }
//
//        val adPrice = adView.findViewById<TextView>(R.id.ad_price)
//        if (adPrice != null) {
//            adPrice.setTextColor(mBodyColor)
//            adPrice.text = nativeAd.price
//            adView.priceView = adPrice
//        }
//
//        val adStore = adView.findViewById<TextView>(R.id.ad_store)
//        if (adStore != null) {
//            adStore.setTextColor(mBodyColor)
//            adStore.text = nativeAd.store
//            adView.storeView = adStore
//        }

        val callToActionView = adView.findViewById<TextView>(R.id.ad_call_to_action)
        if (callToActionView != null) {
            callToActionView.text = nativeAd.callToAction
            adView.callToActionView = callToActionView
        }

        val adAppIcon = adView.findViewById<ImageView>(R.id.ad_app_icon)
        if (adAppIcon != null && nativeAd.icon != null) {
            adAppIcon.setImageDrawable(nativeAd.icon!!.drawable)
            adView.iconView = adAppIcon
        }

        val adStars = adView.findViewById<RatingBar>(R.id.ad_stars)
        if (adStars != null && nativeAd.starRating != null) {
            adStars.rating = nativeAd.starRating!!.toFloat()
            adView.starRatingView = adStars
        }

        val advertiser = adView.findViewById<TextView>(R.id.ad_advertiser)
        if (advertiser != null) {
            advertiser.text = nativeAd.advertiser
            adView.advertiserView = advertiser
        }

        try {
            val mediaView = adView.findViewById<MediaView>(R.id.ad_media)
            if (mediaView != null) {
                mediaView.visibility = View.VISIBLE
                adView.mediaView = mediaView
                nativeAd.mediaContent?.let {
                    mediaView.mediaContent = it
                }
                mediaView.setImageScaleType(ImageView.ScaleType.FIT_CENTER)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        adView.setNativeAd(nativeAd)
    }

}