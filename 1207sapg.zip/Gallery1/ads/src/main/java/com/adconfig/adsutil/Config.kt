package com.adconfig.adsutil

import android.util.Log
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.nativead.NativeAd
import java.util.Date

object Config {

    var bannerAd: AdView? = null
    var isBannerImpression: Boolean = false
    var nativeAd: NativeAd? = null
    var isNativeImpression: Boolean = false

    var mAppOpenAd: AppOpenAd? = null
    var mInterstitialAd: InterstitialAd? = null
    var isLibraryInitialized = false

    //    var IS_DEBUG = true
    var admobAppOpenId: String = ""
    var showInterTime: Long = 0
//    var adinterval: Long = 0
//    var enablead: Boolean = false
//    var interex1: String = ""
//    var interex2: String = ""

    fun checkInterAvailable(): Boolean {
        return mInterstitialAd != null
    }

    fun checkReInter(callback: (Boolean) -> Unit) {
//        if (showInterTime != 0L) {
//            if (adinterval == 0L || !enablead) return
//            val diff = Date().time - showInterTime
//            Log.e("LLL_Splash", "loadBackPressInter: $diff")
//            if (diff < (adinterval * 1000)) {
//                callback.invoke(false)
//                return
//            }
            callback.invoke(true)
//        }
    }
}