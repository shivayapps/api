# Keep AdsConfig class and Companion object
-keep class com.adconfig.AdsConfig { *; }
-keep class com.adconfig.AdsConfig$Companion { *; }
-keepclassmembers class com.adconfig.AdsConfig {
    public static final com.adconfig.AdsConfig$Companion Companion;
}

# Keep Builder class
-keep class com.adconfig.AdsConfig$Builder { *; }

# Optional: Keep all companion objects in library to avoid future issues
-keepclassmembers class * {
    public static final ** Companion;
}
