package com.gallery.photo.image.video.mainduplicate.asynctask;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.gallery.photo.image.video.R;
import com.gallery.photo.image.video.database.GalleryDatabase;
import com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions;
import com.gallery.photo.image.video.mainduplicate.activity.duplicateactivities.DuplicateAudiosActivity;
import com.gallery.photo.image.video.mainduplicate.activity.duplicateactivities.DuplicateDocumentsActivity;
import com.gallery.photo.image.video.mainduplicate.activity.duplicateactivities.DuplicateImageActivity;
import com.gallery.photo.image.video.mainduplicate.activity.duplicateactivities.DuplicateOthersActivity;
import com.gallery.photo.image.video.mainduplicate.activity.duplicateactivities.DuplicateVideosActivity;
import com.gallery.photo.image.video.mainduplicate.adapter.IndividualAudiosAdapter;
import com.gallery.photo.image.video.mainduplicate.adapter.IndividualDocumentAdapter;
import com.backup.restore.device.image.contacts.recovery.mainduplicate.adapter.IndividualOtherAdapter;
import com.gallery.photo.image.video.mainduplicate.adapter.IndividualPhotosAdapter;
import com.gallery.photo.image.video.mainduplicate.adapter.IndividualVideosAdapter;
import com.gallery.photo.image.video.mainduplicate.callbacks.MarkedListener;
import com.gallery.photo.image.video.mainduplicate.model.IndividualGroupModel;
import com.gallery.photo.image.video.mainduplicate.model.ItemDuplicateModel;
import com.gallery.photo.image.video.mainduplicate.model.PopUp;
import com.gallery.photo.image.video.mainduplicate.utils.ShareConstants;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

@SuppressWarnings("deprecation")
@SuppressLint("StaticFieldLeak")
public class DeleteDuplicateFileAsyncTask extends AsyncTask<Void, Void, Void> {

    Activity deleteActivity;
    Context deleteContext;
    private ProgressDialog deleteDialog;
    long deleteFileSize;
    int FileDeletingCount = 0;
    ArrayList<ItemDuplicateModel> fileToBeDeleted;
    List<IndividualGroupModel> groupOfDuplicates;
    MarkedListener mMarkedListener;
    String message;
    String mIsType;

    public DeleteDuplicateFileAsyncTask(String isType, Context context, Activity activity, MarkedListener imagesMarkedListener, String messages, ArrayList<ItemDuplicateModel> fileToDeletedList, long deletingFileSize, List<IndividualGroupModel> groupOfDuplicatesList) {
        mIsType = isType;
        deleteContext = context;
        deleteActivity = activity;
        mMarkedListener = imagesMarkedListener;
        message = messages;
        fileToBeDeleted = fileToDeletedList;
        deleteFileSize = deletingFileSize;
        groupOfDuplicates = groupOfDuplicatesList;
        if (fileToDeletedList != null) {
            FileDeletingCount = fileToDeletedList.size();
        }
    }

    protected void onPreExecute() {
        super.onPreExecute();
        deleteDialog = new ProgressDialog(deleteActivity);
        deleteDialog.setMessage(message);
        deleteDialog.setCancelable(false);
        deleteDialog.setButton(androidx.appcompat.app.AlertDialog.BUTTON_NEGATIVE, deleteActivity.getString(R.string.cancel), (dialog, which) -> {
            deleteDialog.dismiss();
            deleteActivity.finish();
        });

        if (deleteDialog != null) {
            deleteDialog.show();
        }
        deleteDialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEGATIVE).setTextColor(deleteActivity.getResources().getColor(com.gallery.photo.image.video.R.color.color_primary));

    }

    protected Void doInBackground(Void... params) {

        if (fileToBeDeleted != null) {
            deletePhotosByPosition();
        }
        return null;
    }

    private void deletePhotosByPosition() {
        List<IndividualGroupModel> groupOfDuplicatesLocal = groupOfDuplicates;
        List<ItemDuplicateModel> listOfFilesToBeDeleted = fileToBeDeleted;

        for (int i = 0; i < listOfFilesToBeDeleted.size(); i++) {
            ItemDuplicateModel imageItem = (ItemDuplicateModel) listOfFilesToBeDeleted.get(i);
            int imageTag = imageItem.getFileItemGrpTag();
            int position = imageItem.getFilePosition();
            if (imageTag - 1 < groupOfDuplicatesLocal.size()) {
                IndividualGroupModel individualGroup = (IndividualGroupModel) groupOfDuplicatesLocal.get(imageTag - 1);
                List<ItemDuplicateModel> imageItems = individualGroup.getIndividualGrpOfDupes();
                for (int j = 0; j < imageItems.size(); j++) {
                    ItemDuplicateModel imageItem1 = (ItemDuplicateModel) imageItems.get(j);
                    if (imageItem1.getFilePosition() == position) {
                        GlobalVarsAndFunctions.deleteFile(deleteActivity, deleteContext, imageItem1.getFilePath());
                        imageItems.remove(imageItem1);
                        Log.d("TAG", "deletePhotosByPosition: deleted Path --- > " + imageItem1.getFilePath());
                        try {
                            if (imageItem1.getFilePath() != null)
                                GalleryDatabase.Companion.getInstance(deleteContext).MediumDao().deleteMediumPath(imageItem1.getFilePath());
                        } catch (Exception e) {

                        }

                    }
                }
                individualGroup.setIndividualGrpOfDupes(imageItems);
                individualGroup.setCheckBox(false);
            }
        }
    }


    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        if (deleteDialog.isShowing()) {
            deleteDialog.dismiss();
            switch (mIsType) {
                case "Photo":
                    setImageDuplicateAdapterWithData(mMarkedListener);
                    new PopUp(deleteContext, deleteActivity).showSpaceRecoveredPopUp(mIsType, FileDeletingCount == 1 ? deleteContext.getString(R.string.msg_duplicate_image_clean) + FileDeletingCount : deleteContext.getString(R.string.msg_duplicate_image_clean) + FileDeletingCount, deleteContext.getString(R.string.space_regained) + ShareConstants.getReadableFileSize(deleteFileSize), mMarkedListener, FileDeletingCount);
                    break;
                case "Video":
                    setVideoDuplicateAdapterWithData(mMarkedListener);
                    new PopUp(deleteContext, deleteActivity).showSpaceRecoveredPopUp(mIsType, FileDeletingCount == 1 ? deleteContext.getString(R.string.msg_duplicate_video_clean) + FileDeletingCount : deleteContext.getString(R.string.msg_duplicate_video_clean) + FileDeletingCount, deleteContext.getString(R.string.space_regained) + ShareConstants.getReadableFileSize(deleteFileSize), mMarkedListener, FileDeletingCount);
                    break;
                case "Audio":
                    setAudioDuplicateAdapterWithData(mMarkedListener);
                    new PopUp(deleteContext, deleteActivity).showSpaceRecoveredPopUp(mIsType, FileDeletingCount == 1 ? deleteContext.getString(R.string.msg_duplicate_delete_clean) + FileDeletingCount : deleteContext.getString(R.string.msg_duplicate_delete_clean) + FileDeletingCount, deleteContext.getString(R.string.space_regained) + ShareConstants.getReadableFileSize(deleteFileSize), mMarkedListener, FileDeletingCount);
                    break;
                case "Document":
                    setDocumentDuplicateAdapterWithData(mMarkedListener);
                    new PopUp(deleteContext, deleteActivity).showSpaceRecoveredPopUp(mIsType, FileDeletingCount == 1 ? deleteContext.getString(R.string.msg_duplicate_document_clean) + FileDeletingCount : deleteContext.getString(R.string.msg_duplicate_document_clean) + FileDeletingCount, deleteContext.getString(R.string.space_regained) + ShareConstants.getReadableFileSize(deleteFileSize), mMarkedListener, FileDeletingCount);
                    break;
                case "Other":
                    setOtherDuplicateAdapterWithData(mMarkedListener);
                    new PopUp(deleteContext, deleteActivity).showSpaceRecoveredPopUp(mIsType, FileDeletingCount == 1 ? deleteContext.getString(R.string.msg_duplicate_other_clean)+ FileDeletingCount : deleteContext.getString(R.string.msg_duplicate_other_clean) + FileDeletingCount, deleteContext.getString(R.string.space_regained) + ShareConstants.getReadableFileSize(deleteFileSize), mMarkedListener, FileDeletingCount);
                    break;
            }
        }
    }

    private void setImageDuplicateAdapterWithData(MarkedListener imagesMarkedListener) {
        DuplicateImageActivity.groupOfDupes = PopUp.sortByPhotosDateAscending(GlobalVarsAndFunctions.listOfGroupedDuplicatesPhotos);
        if (DuplicateImageActivity.filterListPhotos.size() != GlobalVarsAndFunctions.uniquePhotosExtension.size() && DuplicateImageActivity.filterListPhotos.size() > 0) {
            List<IndividualGroupModel> newIndividualGroupPhotos = new ArrayList<>();
            for (Entry<String, Boolean> entry : DuplicateImageActivity.filterListPhotos.entrySet()) {
                String ext = (String) entry.getKey();
                if (DuplicateImageActivity.groupOfDupes != null) {
                    for (int j = 0; j < DuplicateImageActivity.groupOfDupes.size(); j++) {
                        IndividualGroupModel individualGroupPhotos1 = (IndividualGroupModel) DuplicateImageActivity.groupOfDupes.get(j);
                        if (individualGroupPhotos1.getGroupExtension().equalsIgnoreCase(ext)) {
                            newIndividualGroupPhotos.add(individualGroupPhotos1);
                        }
                    }
                }
            }
            DuplicateImageActivity.groupOfDupes = newIndividualGroupPhotos;
        }
        IndividualPhotosAdapter individualPhotosAdapter = new IndividualPhotosAdapter(deleteContext, deleteActivity, mMarkedListener, setCheckBoxForImages(imagesMarkedListener));
        if (DuplicateImageActivity.recyclerViewForIndividualGrp != null) {
            DuplicateImageActivity.recyclerViewForIndividualGrp.setAdapter(individualPhotosAdapter);
        }
        individualPhotosAdapter.notifyDataSetChanged();
    }

    private List<IndividualGroupModel> setCheckBoxForImages(MarkedListener imagesMarkedListener) {
        List<IndividualGroupModel> listOfDupes = new ArrayList<>();
        GlobalVarsAndFunctions.file_to_be_deleted_images.clear();
        GlobalVarsAndFunctions.size_Of_File_images = 0;
        if (DuplicateImageActivity.groupOfDupes != null) {
            for (int i = 0; i < DuplicateImageActivity.groupOfDupes.size(); i++) {
                IndividualGroupModel individualGroup = (IndividualGroupModel) DuplicateImageActivity.groupOfDupes.get(i);
                individualGroup.setCheckBox(false);
                List<ItemDuplicateModel> list = new ArrayList<>();
                for (int j = 0; j < individualGroup.getIndividualGrpOfDupes().size(); j++) {
                    ItemDuplicateModel imageItem = (ItemDuplicateModel) individualGroup.getIndividualGrpOfDupes().get(j);
                    if (j == 0) {
                        imageItem.setFileCheckBox(false);
                    } else {
                        if (individualGroup.isCheckBox()) {
                            GlobalVarsAndFunctions.file_to_be_deleted_images.add(imageItem);
                            GlobalVarsAndFunctions.addSizeImages(imageItem.getSizeOfTheFile());
                        }
                        imagesMarkedListener.updateMarked();
                        imageItem.setFileCheckBox(individualGroup.isCheckBox());
                    }
                    list.add(imageItem);
                }
                individualGroup.setIndividualGrpOfDupes(list);
                listOfDupes.add(individualGroup);
            }
        }
        return listOfDupes;
    }

    private void setVideoDuplicateAdapterWithData(MarkedListener videosMarkedListener) {
        DuplicateVideosActivity.groupOfDupes = PopUp.sortByPhotosDateAscending(GlobalVarsAndFunctions.listOfGroupedDuplicatesVideos);
        if (DuplicateVideosActivity.filterListVideos.size() != GlobalVarsAndFunctions.uniqueVideosExtension.size() && DuplicateVideosActivity.filterListVideos.size() > 0) {
            List<IndividualGroupModel> newIndividualGroupVideos = new ArrayList<>();
            for (Entry<String, Boolean> entry : DuplicateVideosActivity.filterListVideos.entrySet()) {
                String ext = (String) entry.getKey();
                if (DuplicateVideosActivity.groupOfDupes != null) {
                    for (int j = 0; j < DuplicateVideosActivity.groupOfDupes.size(); j++) {
                        IndividualGroupModel individualGroupVideos1 = (IndividualGroupModel) DuplicateVideosActivity.groupOfDupes.get(j);
                        if (individualGroupVideos1.getGroupExtension().equalsIgnoreCase(ext)) {
                            newIndividualGroupVideos.add(individualGroupVideos1);
                        }
                    }
                }
            }
            DuplicateVideosActivity.groupOfDupes = newIndividualGroupVideos;
        }
        IndividualVideosAdapter individualVideosAdapter = new IndividualVideosAdapter(deleteContext, deleteActivity, videosMarkedListener,
                setCheckBoxForVideo(videosMarkedListener));
        if (DuplicateVideosActivity.recyclerViewForIndividualGrp != null) {
            DuplicateVideosActivity.recyclerViewForIndividualGrp.setAdapter(individualVideosAdapter);
        }
        individualVideosAdapter.notifyDataSetChanged();
    }

    private List<IndividualGroupModel> setCheckBoxForVideo(MarkedListener videosMarkedListener) {
        List<IndividualGroupModel> listOfDupes = new ArrayList<>();
        GlobalVarsAndFunctions.file_to_be_deleted_videos.clear();
        GlobalVarsAndFunctions.size_Of_File_videos = 0;
        if (DuplicateVideosActivity.groupOfDupes != null) {
            for (int i = 0; i < DuplicateVideosActivity.groupOfDupes.size(); i++) {
                IndividualGroupModel individualGroup = (IndividualGroupModel) DuplicateVideosActivity.groupOfDupes.get(i);
                individualGroup.setCheckBox(false);
                List<ItemDuplicateModel> list = new ArrayList<>();
                for (int j = 0; j < individualGroup.getIndividualGrpOfDupes().size(); j++) {
                    ItemDuplicateModel videoItem = (ItemDuplicateModel) individualGroup.getIndividualGrpOfDupes().get(j);
                    if (j != 0) {
                        if (videoItem.isFileCheckBox()) {
                            GlobalVarsAndFunctions.file_to_be_deleted_videos.add(videoItem);
                            GlobalVarsAndFunctions.addSizeVideos(videoItem.getSizeOfTheFile());
                        }
                        videosMarkedListener.updateMarked();
                    }
                    videoItem.setFileCheckBox(videoItem.isFileCheckBox());
                    list.add(videoItem);
                }
                individualGroup.setIndividualGrpOfDupes(list);
                listOfDupes.add(individualGroup);
            }
        }
        return listOfDupes;
    }

    private void setAudioDuplicateAdapterWithData(MarkedListener audiosMarkedListener) {
        DuplicateAudiosActivity.groupOfDupes = PopUp.sortByPhotosDateAscending(GlobalVarsAndFunctions.listOfGroupedDuplicatesAudios);
        if (DuplicateAudiosActivity.filterListAudios.size() != GlobalVarsAndFunctions.uniqueAudiosExtension.size() && DuplicateAudiosActivity.filterListAudios.size() > 0) {
            List<IndividualGroupModel> newIndividualGroupAudios = new ArrayList<>();
            for (Entry<String, Boolean> entry : DuplicateAudiosActivity.filterListAudios.entrySet()) {
                String ext = (String) entry.getKey();
                if (DuplicateAudiosActivity.groupOfDupes != null) {
                    for (int j = 0; j < DuplicateAudiosActivity.groupOfDupes.size(); j++) {
                        IndividualGroupModel individualGroupAudios1 = DuplicateAudiosActivity.groupOfDupes.get(j);
                        if (individualGroupAudios1.getGroupExtension().equalsIgnoreCase(ext)) {
                            newIndividualGroupAudios.add(individualGroupAudios1);
                        }
                    }
                }
            }
            DuplicateAudiosActivity.groupOfDupes = newIndividualGroupAudios;
        }
        IndividualAudiosAdapter individualAudiosAdapter = new IndividualAudiosAdapter(deleteContext, deleteActivity, audiosMarkedListener, setCheckBoxForAudio(audiosMarkedListener));
        if (DuplicateAudiosActivity.recyclerViewForIndividualGrp != null) {
            DuplicateAudiosActivity.recyclerViewForIndividualGrp.setAdapter(individualAudiosAdapter);
        }
        individualAudiosAdapter.notifyDataSetChanged();
    }

    private List<IndividualGroupModel> setCheckBoxForAudio(MarkedListener audiosMarkedListener) {
        List<IndividualGroupModel> listOfDupes = new ArrayList<>();
        GlobalVarsAndFunctions.file_to_be_deleted_audios.clear();
        GlobalVarsAndFunctions.size_Of_File_audios = 0;
        if (DuplicateAudiosActivity.groupOfDupes != null) {
            for (int i = 0; i < DuplicateAudiosActivity.groupOfDupes.size(); i++) {
                IndividualGroupModel individualGroup = (IndividualGroupModel) DuplicateAudiosActivity.groupOfDupes.get(i);
                individualGroup.setCheckBox(false);
                List<ItemDuplicateModel> list = new ArrayList<>();
                for (int j = 0; j < individualGroup.getIndividualGrpOfDupes().size(); j++) {
                    ItemDuplicateModel audioItem = (ItemDuplicateModel) individualGroup.getIndividualGrpOfDupes().get(j);
                    if (j != 0) {
                        if (audioItem.isFileCheckBox()) {
                            GlobalVarsAndFunctions.file_to_be_deleted_audios.add(audioItem);
                            GlobalVarsAndFunctions.addSizeAudios(audioItem.getSizeOfTheFile());
                        }
                        audiosMarkedListener.updateMarked();
                    }
                    audioItem.setFileCheckBox(audioItem.isFileCheckBox());
                    list.add(audioItem);
                }
                individualGroup.setIndividualGrpOfDupes(list);
                listOfDupes.add(individualGroup);
            }
        }
        return listOfDupes;
    }

    private void setDocumentDuplicateAdapterWithData(MarkedListener documentsMarkedListener) {
        DuplicateDocumentsActivity.groupOfDupes = PopUp.sortByPhotosDateAscending(GlobalVarsAndFunctions.listOfGroupedDuplicatesDocument);
        if (DuplicateDocumentsActivity.filterListDocuments.size() != GlobalVarsAndFunctions.uniqueDocumentsExtension.size() && DuplicateDocumentsActivity.filterListDocuments.size() > 0) {
            List<IndividualGroupModel> newIndividualGroupDocuments = new ArrayList<>();
            for (Entry<String, Boolean> entry : DuplicateDocumentsActivity.filterListDocuments.entrySet()) {
                String ext = (String) entry.getKey();
                if (DuplicateDocumentsActivity.groupOfDupes != null) {
                    for (int j = 0; j < DuplicateDocumentsActivity.groupOfDupes.size(); j++) {
                        IndividualGroupModel individualGroupDocuments1 = (IndividualGroupModel) DuplicateDocumentsActivity.groupOfDupes.get(j);
                        if (individualGroupDocuments1.getGroupExtension().equalsIgnoreCase(ext)) {
                            newIndividualGroupDocuments.add(individualGroupDocuments1);
                        }
                    }
                }
            }
            DuplicateDocumentsActivity.groupOfDupes = newIndividualGroupDocuments;
        }
        IndividualDocumentAdapter individualDocumentAdapter = new IndividualDocumentAdapter(deleteContext, deleteActivity, documentsMarkedListener,
                setDocumentCheckBox(documentsMarkedListener));
        if (DuplicateDocumentsActivity.recyclerViewForIndividualGrp != null) {
            DuplicateDocumentsActivity.recyclerViewForIndividualGrp.setAdapter(individualDocumentAdapter);
        }
        individualDocumentAdapter.notifyDataSetChanged();
    }

    private List<IndividualGroupModel> setDocumentCheckBox(MarkedListener documentsMarkedListener) {
        List<IndividualGroupModel> listOfDupes = new ArrayList<>();
        GlobalVarsAndFunctions.file_to_be_deleted_documents.clear();
        GlobalVarsAndFunctions.size_Of_File_documents = 0;
        if (DuplicateDocumentsActivity.groupOfDupes != null) {
            for (int i = 0; i < DuplicateDocumentsActivity.groupOfDupes.size(); i++) {
                IndividualGroupModel individualGroup = (IndividualGroupModel) DuplicateDocumentsActivity.groupOfDupes.get(i);
                individualGroup.setCheckBox(false);
                List<ItemDuplicateModel> list = new ArrayList<>();
                for (int j = 0; j < individualGroup.getIndividualGrpOfDupes().size(); j++) {
                    ItemDuplicateModel documentItem = (ItemDuplicateModel) individualGroup.getIndividualGrpOfDupes().get(j);
                    if (j != 0) {
                        if (documentItem.isFileCheckBox()) {
                            GlobalVarsAndFunctions.file_to_be_deleted_documents.add(documentItem);
                            GlobalVarsAndFunctions.addSizeDocuments(documentItem.getSizeOfTheFile());
                        }
                        documentsMarkedListener.updateMarked();
                    }
                    documentItem.setFileCheckBox(documentItem.isFileCheckBox());
                    list.add(documentItem);
                }
                individualGroup.setIndividualGrpOfDupes(list);
                listOfDupes.add(individualGroup);
            }
        }
        return listOfDupes;
    }

    private void setOtherDuplicateAdapterWithData(MarkedListener otherMarkedListener) {
        DuplicateOthersActivity.groupOfDupes = PopUp.sortByPhotosDateAscending(GlobalVarsAndFunctions.listOfGroupedDuplicatesOthers);
        if (DuplicateOthersActivity.filterListOthers.size() != GlobalVarsAndFunctions.uniqueOthersExtensionAfterDuplicates.size() && DuplicateOthersActivity.filterListOthers.size() > 0) {
            List<IndividualGroupModel> newIndividualGroupOthers = new ArrayList<>();
            for (Entry<String, Boolean> entry : DuplicateOthersActivity.filterListOthers.entrySet()) {
                String ext = (String) entry.getKey();
                if (DuplicateOthersActivity.groupOfDupes != null) {
                    for (int j = 0; j < DuplicateOthersActivity.groupOfDupes.size(); j++) {
                        IndividualGroupModel individualGroupOthers1 = (IndividualGroupModel) DuplicateOthersActivity.groupOfDupes.get(j);
                        if (individualGroupOthers1.getGroupExtension().equalsIgnoreCase(ext)) {
                            newIndividualGroupOthers.add(individualGroupOthers1);
                        }
                    }
                }
            }
            DuplicateOthersActivity.groupOfDupes = newIndividualGroupOthers;
        }
        IndividualOtherAdapter individualOtherAdapter = new IndividualOtherAdapter(deleteContext, deleteActivity, otherMarkedListener,
                setOthersCheckBox(otherMarkedListener));
        if (DuplicateOthersActivity.recyclerViewForIndividualGrp != null) {
            DuplicateOthersActivity.recyclerViewForIndividualGrp.setAdapter(individualOtherAdapter);
        }
        individualOtherAdapter.notifyDataSetChanged();
    }

    private List<IndividualGroupModel> setOthersCheckBox(MarkedListener otherMarkedListener) {
        List<IndividualGroupModel> listOfDupes = new ArrayList<>();
        GlobalVarsAndFunctions.file_to_be_deleted_others.clear();
        GlobalVarsAndFunctions.size_Of_File_others = 0;
        if (DuplicateOthersActivity.groupOfDupes != null) {
            for (int i = 0; i < DuplicateOthersActivity.groupOfDupes.size(); i++) {
                IndividualGroupModel individualGroup = (IndividualGroupModel) DuplicateOthersActivity.groupOfDupes.get(i);
                individualGroup.setCheckBox(false);
                List<ItemDuplicateModel> list = new ArrayList<>();
                for (int j = 0; j < individualGroup.getIndividualGrpOfDupes().size(); j++) {
                    ItemDuplicateModel otherItem = (ItemDuplicateModel) individualGroup.getIndividualGrpOfDupes().get(j);
                    if (j != 0) {
                        if (otherItem.isFileCheckBox()) {
                            GlobalVarsAndFunctions.file_to_be_deleted_others.add(otherItem);
                            GlobalVarsAndFunctions.addSizeOthers(otherItem.getSizeOfTheFile());
                        }
                        otherMarkedListener.updateMarked();
                    }
                    otherItem.setFileCheckBox(otherItem.isFileCheckBox());
                    list.add(otherItem);
                }
                individualGroup.setIndividualGrpOfDupes(list);
                listOfDupes.add(individualGroup);
            }
        }
        return listOfDupes;
    }
}
