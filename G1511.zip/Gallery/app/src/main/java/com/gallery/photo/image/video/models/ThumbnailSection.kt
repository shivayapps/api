package com.gallery.photo.image.video.models

data class ThumbnailSection(val title: String, val isBigText:Boolean=false) : ThumbnailItem()
