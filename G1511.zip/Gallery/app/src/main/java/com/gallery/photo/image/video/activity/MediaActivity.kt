package com.gallery.photo.image.video.activity

import android.app.Activity
import android.app.WallpaperManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.*
import android.text.Editable
import android.text.Html
import android.text.TextWatcher
import android.util.Log
import android.view.Gravity
import android.view.MenuItem
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.widget.PopupMenu
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.SimpleTarget
import com.bumptech.glide.request.transition.Transition
import com.example.app.ads.helper.InterstitialAdHelper
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.bindActivity.AllHiddenFileActivity
import com.gallery.photo.image.video.bindActivity.BaseBindingActivity
import com.gallery.photo.image.video.bindActivity.HiddenImagesActivity
import com.gallery.photo.image.video.adapter.MediaAdapter
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.databinding.ActivityMediaBinding
import com.gallery.photo.image.video.dialog.ChangeGridSizeDialog
import com.gallery.photo.image.video.dialog.ChangeSortingDialog
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.fragment.PhotoDirectoryFragment
import com.gallery.photo.image.video.fragment.VaultFragment
import com.gallery.photo.image.video.fragment.VideoDirectoryFragment
import com.gallery.photo.image.video.interfaces.MediaOperationsListener
import com.gallery.photo.image.video.models.Directory
import com.gallery.photo.image.video.models.Medium
import com.gallery.photo.image.video.models.ThumbnailItem
import com.gallery.photo.image.video.models.ThumbnailSection
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.videoplayer.VideoPlayerActivity
import com.gallery.photo.image.video.helpers.*
import com.gallery.photo.image.video.models.FileDirItem
import com.gallery.photo.image.video.views.MyGridLayoutManager
import com.gallery.photo.image.video.views.MyRecyclerView
import kotlinx.android.synthetic.main.activity_main_new.*
import kotlinx.android.synthetic.main.drawer_content.*
import org.jetbrains.anko.toast
import vi.imagestopdf.CreatePDFListener
import java.io.File
import java.io.IOException
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.set


class MediaActivity : BaseBindingActivity<ActivityMediaBinding>(), MediaOperationsListener,
    PopupMenu.OnMenuItemClickListener, CreatePDFListener {
    var title: String? = null
    private var mPath = ""
    private var mIsGetImageIntent = false
    private var mIsGetVideoIntent = false
    private var mIsGetAnyIntent = false
    private var mIsGettingMedia = false
    private var mAllowPickingMultiple = false
    private var mShowAll = false
    private var mShowOnlyHidden = false
    private var mLoadedInitialPhotos = false
    private var mDateFormat = ""
    private var mTimeFormat = ""

    private var mLatestMediaId = 0L
    private var mLatestMediaDateId = 0L
    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mSearchMenuItem: MenuItem? = null
    private var mLastSearchedText = ""
    private var isVideo = false
    private var isFirstTime = true
    var itemClickPath: String = ""
    var isShowInfo = false
    var isHide = true
    var isFromVault = false
    var isFromFakeVault = false
    var isFromAllFileHide = false
    var isVideoClicked = false
    var isProccessOver = false

    override fun setBinding(): ActivityMediaBinding {
        return ActivityMediaBinding.inflate(inflater)
    }

    override fun getContext(): Activity {
        return this
    }

    override fun getAppIconIDs() = arrayListOf(

        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName() = getString(R.string.app_name)

    override fun initViews() {
        intent.apply {
            mIsGetImageIntent = getBooleanExtra(GET_IMAGE_INTENT, false)
            mIsGetVideoIntent = getBooleanExtra(GET_VIDEO_INTENT, false)
            mIsGetAnyIntent = getBooleanExtra(GET_ANY_INTENT, false)
            mAllowPickingMultiple = getBooleanExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
            mShowOnlyHidden = getBooleanExtra(SHOW_ONLY_HIDDEN, false)
            isFromFakeVault = getBooleanExtra(IS_FROM_FAKE_VAULT, false)
            isFromVault = getBooleanExtra(IS_FROM_VAULT, false)
            isFromAllFileHide = getBooleanExtra(IS_FROM_ALL_HIDE_FILE, false)

        }
        if (mShowOnlyHidden)
            VaultFragment.isTabUnlock = true
        try {
            mPath = intent.getStringExtra(DIRECTORY) ?: ""
            Log.d("tag ", "Path :: $mPath")
        } catch (e: Exception) {
            showErrorToast(e)
            finish()
            return
        }
        try {
            isVideo = intent.getBooleanExtra(IS_VIDEO, false)
        } catch (e: java.lang.Exception) {
            isVideo = false
            e.printStackTrace()
        }
        mBinding.mediaRefreshLayout.setOnRefreshListener {
            mBinding.imgClose.performClick()
            startAsyncTask()
        }

        mBinding.tvTitle.text = mPath.split("/")[mPath.split("/").size - 1]
        if (isVideo) {
            mBinding.etSearch.hint = getString(R.string.msg_search_video_by_name)
        } else {
            mBinding.etSearch.hint = getString(R.string.msg_search_photo_by_name)
        }
        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            InterstitialAdHelper.loadInterstitialAd(fContext = this)
        }
    }

    override fun onResume() {
        super.onResume()
        if (mMedia.isEmpty() || config.getFolderSorting(mPath) and SORT_BY_RANDOM == 0) {
            if (shouldSkipAuthentication()) {
                tryLoadGallery()
            } else {
                handleLockedFolderOpening(mPath) { success ->
                    if (success) {
                        tryLoadGallery()
                    } else {
                        finish()
                    }
                }
            }
        }
        if (isProccessOver && getMediaAdapter() != null) {
            getMediaAdapter()!!.dismissProgress()
        }

    }

    override fun onPause() {
        super.onPause()
        mBinding.imgClose.performClick()
    }

    private fun tryLoadGallery() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!checkPermissionabove11()) {
                showGetPermissionDialog11()
            } else {
                val dirName = when {
                    mPath == FAVORITES -> getString(R.string.favorites)
                    mPath == RECYCLE_BIN -> getString(R.string.recycle_bin)
                    mPath == config.OTGPath -> getString(R.string.usb)
                    else -> getHumanizedFilename(mPath)
                }
                updateActionBarTitle(if (mShowAll) resources.getString(R.string.all_folders) else dirName)
                startAsyncTask()
                setupLayoutManager()
            }

        } else {
            handlePermission(PERMISSION_WRITE_STORAGE) {
                if (it) {
                    val dirName = when {
                        mPath == FAVORITES -> getString(R.string.favorites)
                        mPath == RECYCLE_BIN -> getString(R.string.recycle_bin)
                        mPath == config.OTGPath -> getString(R.string.usb)
                        else -> getHumanizedFilename(mPath)
                    }
                    updateActionBarTitle(if (mShowAll) resources.getString(R.string.all_folders) else dirName)
                    startAsyncTask()
                    setupLayoutManager()
                } else {
                    toast(R.string.no_storage_permissions)
                    finish()
                }
            }
        }

    }


    override fun initData() {

        when(config.mediaColumnCnt) {
            1-> mBinding.imgGridSize.setImageResource(R.drawable.grid_s1)
            2-> mBinding.imgGridSize.setImageResource(R.drawable.grid_s2)
            3-> mBinding.imgGridSize.setImageResource(R.drawable.grid_s3)
            4-> mBinding.imgGridSize.setImageResource(R.drawable.grid_s4)
        }
    }

    override fun initActions() {
        mBinding.imgSearch.setOnClickListener(this)
        mBinding.imgBack.setOnClickListener(this)
        mBinding.imgClose.setOnClickListener(this)
        mBinding.imgGridSize.setOnClickListener(this)
//        mBinding.imgSpan.setOnClickListener(this)
        mBinding.imgSort.setOnClickListener(this)
        mBinding.imgOrder.setOnClickListener(this)
        mBinding.llHideOpt.setOnClickListener(this)
        mBinding.llShareOpt.setOnClickListener(this)
        setupSearch()
    }

    private fun setupSearch() {

        mBinding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {

                searchQueryChanged(s.toString())

            }

            override fun afterTextChanged(s: Editable?) {

            }

        })
    }

    private fun searchQueryChanged(text: String) {
        ensureBackgroundThread {
            try {
                val filtered =
                    mMedia.filter { it is Medium && it.name.contains(text, true) } as ArrayList
                filtered.sortBy { it is Medium && !it.name.startsWith(text, true) }
                val grouped = MediaFetcher(applicationContext).groupMedia(
                    filtered as ArrayList<Medium>,
                    mPath,
                    GROUP_BY_NONE
                )
                runOnUiThread {
                    if (grouped.isEmpty()) {
                        mBinding.mediaEmptyTextPlaceholder.text = getString(R.string.no_items_found)
                        mBinding.mediaEmptyTextPlaceholder.beVisible()
                    } else {
                        mBinding.mediaEmptyTextPlaceholder.beGone()
                    }

                    handleGridSpacing(grouped)
                    getMediaAdapter()?.updateMedia(grouped)
                    measureRecyclerViewContent(grouped)
                }
            } catch (ignored: Exception) {
            }
        }
    }

    override fun onClick(view: View) {
        super.onClick(view)
        when (view.id) {
            R.id.imgBack -> {
                onBackPressed()
            }
            R.id.imgSearch -> {
                mBinding.etSearch. visibility = VISIBLE
                mBinding.imgClose.visibility = VISIBLE
                mBinding.tvTitle.visibility = GONE
                mBinding.imgSearch.visibility = GONE
                mBinding.layOpt.visibility = GONE
                showKeyboard(mBinding.etSearch)
            }
            R.id.imgClose -> {
                mBinding.etSearch.text = null
                mBinding.etSearch.visibility = GONE
                mBinding.imgClose.visibility = GONE
                mBinding.tvTitle.visibility = VISIBLE
                mBinding.imgSearch.visibility = VISIBLE
                mBinding.layOpt.visibility = VISIBLE
                searchQueryChanged("")
                hideKeyboard(mBinding.etSearch)
            }

//            R.id.imgSpan -> {
//                ChangeGridSizeDialog(this, false, mBinding.imgSpan) {
//                    setupLayoutManager()
//                    columnCountChanged()
//                }
//            }
            R.id.imgGridSize -> {

                ChangeGridSizeDialog(this, false, mBinding.imgGridSize) {
                    setupLayoutManager()
                    columnCountChanged()
                    when(config.mediaColumnCnt) {
                        1-> mBinding.imgGridSize.setImageResource(R.drawable.grid_s1)
                        2-> mBinding.imgGridSize.setImageResource(R.drawable.grid_s2)
                        3-> mBinding.imgGridSize.setImageResource(R.drawable.grid_s3)
                        4-> mBinding.imgGridSize.setImageResource(R.drawable.grid_s4)
                    }
                }

//                ChangeSortingDialog(this, false, mBinding.imgOptions) {
//                    mLoadedInitialPhotos = false
//                    mBinding.mediaGrid.adapter = null
//                    getMedia()
//                }
            }
            R.id.imgSort -> {

                ChangeSortingDialog(this, false, mBinding.imgSort) {
                    mLoadedInitialPhotos = false
                    mBinding.mediaGrid.adapter = null
                    getMedia()
                }
            }
            R.id.imgOrder -> {

                val currSorting = config.sorting
                var sorting = SORT_BY_NAME
                if (currSorting and SORT_BY_SIZE != 0) {
                    sorting = SORT_BY_SIZE or SORT_DESCENDING
                    if (currSorting and SORT_DESCENDING != 0) {
                        sorting = SORT_BY_SIZE
                    }
                } else if (currSorting and SORT_BY_DATE_MODIFIED != 0) {
                    sorting = SORT_BY_DATE_MODIFIED or SORT_DESCENDING
                    if (currSorting and SORT_DESCENDING != 0) {
                        sorting = SORT_BY_DATE_MODIFIED
                    }
                } else {
                    sorting = SORT_BY_NAME or SORT_DESCENDING
                    if (currSorting and SORT_DESCENDING != 0) {
                        sorting = SORT_BY_NAME
                    }
                }
                config.sorting = sorting
                mLoadedInitialPhotos = false
                mBinding.mediaGrid.adapter = null
                getMedia()
            }
            R.id.llShareOpt -> {
                if (getMediaAdapter() != null)
                    getMediaAdapter()!!.shareMedia()
            }
            R.id.llHideOpt -> {
                if (getMediaAdapter() != null)
                    getMediaAdapter()!!.toggleFileVisibility(isHide)
            }
        }
    }

//    private fun showOptionMenu() {
//        val popupMenu: PopupMenu =
//            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
//                PopupMenu(
//                    getContext(),
//                    mBinding.imgOptions,
//                    Gravity.NO_GRAVITY,
//                    R.attr.actionOverflowMenuStyle,
//                    0
//                )
//            } else {
//                PopupMenu(getContext(), mBinding.imgOptions)
//            }
//        popupMenu.menuInflater.inflate(R.menu.image_preview_option_menu, popupMenu.menu)
//        popupMenu.setOnMenuItemClickListener(this)
//        popupMenu.show()
//
//    }

    override fun onMenuItemClick(item: MenuItem?): Boolean {
//        if (item!!.itemId == R.id.menuSortBy) {
//        } else if (item!!.itemId == R.id.menuGridSize) {
//            ChangeGridSizeDialog(this, false, mBinding.imgGridSize) {
//                setupLayoutManager()
//                columnCountChanged()
//            }
//        } else {
//            val sorting = when (item.itemId) {
//                R.id.cab_name_asc -> {
//                    SORT_BY_NAME
//                }
//                R.id.cab_name_dsc -> {
//                    SORT_BY_NAME or SORT_DESCENDING
//                }
//                R.id.cab_size_asc -> {
//                    SORT_BY_SIZE
//                }
//                R.id.cab_size_dsc -> {
//                    SORT_BY_SIZE or SORT_DESCENDING
//                }
//                R.id.cab_date_asc -> {
//                    SORT_BY_DATE_MODIFIED
//                }
//                R.id.cab_date_dsc -> {
//                    SORT_BY_DATE_MODIFIED or SORT_DESCENDING
//                }
//                else -> {
//                    SORT_BY_DATE_MODIFIED or SORT_DESCENDING
//                }
//            }
//            config.sorting = sorting
//            getMedia()
//        }

//        when (item!!.itemId) {
//            R.id.menuSortBy -> {
//                ChangeSortingDialog(this, false, mBinding.imgOptions) {
//                    mLoadedInitialPhotos = false
//                    mBinding.mediaGrid.adapter = null
//                    getMedia()
//                }
//            }
//            R.id.imgSpan -> {
//                ChangeGridSizeDialog(this, false, true) {
//                    setupLayoutManager()
//                    columnCountChanged()
//                }
//            }
//        }
        return true
    }

    private fun getMedia() {
        mLoadedInitialPhotos = false
        mBinding.mediaGrid.adapter = null
        startAsyncTask()
    }
//    private fun getMedia() {
//        startAsyncTask()
//    }

    private fun startAsyncTask() {
        if (isFirstTime) {
            isFirstTime = false
            mBinding.llProgress.visibility = VISIBLE
        }
        if (mShowOnlyHidden) {
            if (File(mPath).path.getParentPath().containsNoMedia()) {
                mShowOnlyHidden = false
            }
        }

        getAllMedia(
            mPath,
            mIsGetImageIntent,
            mIsGetVideoIntent,
            mShowAll,
            TYPE_IMAGES,
            GROUP_BY_NONE,
            mShowOnlyHidden
        ) {
            ensureBackgroundThread {
                val oldMedia = mMedia.clone() as ArrayList<ThumbnailItem>
                var newMedia = it
                if (isVideo) {
                    newMedia =
                        newMedia.filter { it is Medium && it.type != TYPE_GIFS } as ArrayList<ThumbnailItem>
                }
                AsyncBackgroundWork({}, {
                    if (isFromVault) {
                        var fakeMedia: ArrayList<Medium> = if (mIsGetImageIntent) {
                            fakeVaultMediumDao.getTypeMediaFromPath(
                                mPath,
                                TYPE_IMAGES
                            ) as ArrayList<Medium>
                        } else {
                            fakeVaultMediumDao.getTypeMediaFromPath(
                                mPath,
                                TYPE_VIDEOS
                            ) as ArrayList<Medium>
                        }
                        if (mIsGetImageIntent) {
                            var gifMedia: ArrayList<Medium> =
                                fakeVaultMediumDao.getTypeMediaFromPath(
                                    mPath,
                                    TYPE_GIFS
                                ) as ArrayList<Medium>
                            fakeMedia.addAll(gifMedia)
                        }
                        Log.d(
                            "TagHidden123",
                            "Media Activity Fake Vault Media Size --> " + fakeMedia.size
                        )

                        if (isFromFakeVault) {
                            newMedia =
                                fakeMedia.filter { (it as Medium).name.startsWith(".") } as ArrayList<ThumbnailItem>
                        } else {
                            val firstListObjectIds = fakeMedia.map { it.path }.toSet()
                            newMedia =
                                newMedia.filter { !firstListObjectIds.contains((it as Medium).path) } as java.util.ArrayList<ThumbnailItem>
                        }
                    }
                    Log.d("TagHidden123", "Media Activity Current Media Size --> " + newMedia.size)
                    Log.d("TAG", "setupAdapter: " + newMedia.size.toString())
                }, {
                    try {
                        gotMedia(newMedia, false)
                        ensureBackgroundThread {
                            if (isFromFakeVault) {
                                newMedia.mapNotNull { it as? Medium }
                                    .filter { !getDoesFilePathExist(it.path) }.forEach {
                                        fakeVaultMediumDao.deleteMediumPath(it.path)
                                    }
                            }
                            oldMedia.filter { !newMedia.contains(it) }.mapNotNull { it as? Medium }
                                .filter { !getDoesFilePathExist(it.path) }.forEach {
                                    mediaDB.deleteMediumPath(it.path)
                                }
                        }
                    } catch (e: Exception) {
                    }
                })


            }

        }

    }


    private fun gotMedia(media: ArrayList<ThumbnailItem>, isFromCache: Boolean) {
        mIsGettingMedia = false
        mMedia = media
        Log.d("TAG", "setupAdapter: " + mMedia.size.toString())

        runOnUiThread {
            mBinding.llProgress.visibility = GONE
            mBinding.mediaRefreshLayout.isRefreshing = false
            mBinding.mediaEmptyTextPlaceholder.beVisibleIf(media.isEmpty() && !isFromCache)
            mBinding.mediaEmptyTextPlaceholder2.beVisibleIf(media.isEmpty() && !isFromCache)

            if (mBinding.mediaEmptyTextPlaceholder.isVisible()) {
                mBinding.mediaEmptyTextPlaceholder.text = getString(R.string.no_media_with_filters)
            }
            mBinding.mediaGrid.beVisibleIf(mBinding.mediaEmptyTextPlaceholder.isGone())

            val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
            val allowHorizontalScroll = config.scrollHorizontally && viewType == VIEW_TYPE_GRID
            mBinding.mediaVerticalFastscroller.beVisibleIf(mBinding.mediaGrid.isVisible() && !allowHorizontalScroll)
            mBinding.mediaHorizontalFastscroller.beVisibleIf(mBinding.mediaGrid.isVisible() && allowHorizontalScroll)
            setupAdapter()
        }
        ensureBackgroundThread {
            updatePhotoVideoDirectoryPath(mPath, true, false)
            updatePhotoVideoDirectoryPath(mPath, false, true)
        }
    }

    private fun getMediaAdapter() = mBinding.mediaGrid.adapter as? MediaAdapter

    private fun setupAdapter() {
        Log.d("TAG", "setupAdapter: " + mMedia.size.toString())
        if (!mShowAll && isDirEmpty()) {
            toast(getString(R.string.msg_no_media_found_in_folder))
            ensureBackgroundThread {
                if (isUnHideImage) {
                    var directory =
                        hiddenDirectoryDao.getDirectoryDetailFromDirPath(mPath.getParentPath())

                    if (directory != null) {
                        var newDir = Directory()
                        newDir.name = directory.name
                        newDir.path = directory.path
                        newDir.tmb = directory.tmb
                        newDir.taken = directory.taken
                        newDir.mediaCnt = directory.mediaCnt
                        newDir.size = directory.size
                        newDir.modified = directory.modified
                        newDir.location = directory.location
                        newDir.sortValue = directory.sortValue
                        newDir.types = directory.types
                        directoryDao.insert(newDir)

                        hiddenDirectoryDao.deleteDirPath(mPath.getParentPath())
                    }

                }
            }

            finish()
            return
        }

        val currAdapter = mBinding.mediaGrid.adapter
        if (currAdapter == null) {
//            initZoomListener()
            val fastscroller =
                if (config.scrollHorizontally) mBinding.mediaHorizontalFastscroller else mBinding.mediaVerticalFastscroller
            MediaAdapter(
                this,
                mMedia.clone() as ArrayList<ThumbnailItem>,
                this,
                this,
                mIsGetImageIntent || mIsGetVideoIntent || mIsGetAnyIntent,
                mAllowPickingMultiple,
                mPath,
                mBinding.mediaGrid,
                fastscroller,
                isFromFakeVault
            ) {
                if (it is Medium && !isFinishing) {
                    itemClicked(it.path)
                }
            }.apply {
//                setupZoomListener(mZoomListener)
                mBinding.mediaGrid.adapter = this
            }

            val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
            if (viewType == VIEW_TYPE_LIST) {
                mBinding.mediaGrid.scheduleLayoutAnimation()
            }

            setupLayoutManager()
            handleGridSpacing()
            measureRecyclerViewContent(mMedia)
        } else if (mLastSearchedText.isEmpty()) {
            (currAdapter as MediaAdapter).updateMedia(mMedia)
            handleGridSpacing()
            measureRecyclerViewContent(mMedia)
        }
        // TODO: 25/08/21 Info window changes
//        if (!config.isMediaLongPressInfoShown) {
//            if (!isShowInfo) {
//                isShowInfo = true
//                try {
//                    mBinding.img1.layoutParams.height = (displayMetrics.widthPixels / 3.2).toInt()
//                    mBinding.img1.layoutParams.width = (displayMetrics.widthPixels / 3.2).toInt()
//                } catch (e: Exception) {
//
//                }
//                mBinding.img1.visibility = VISIBLE
//                var msg = getString(R.string.msg_tap_target_image)
//                if (isVideo) {
//                    msg = getString(R.string.msg_tap_target_video)
//                }
//                if (isTablet()) {
//                    val r: Resources = mContext.resources
//                    var dimen = r.getDimension(R.dimen._25sdp)
//                    if (mContext.isTablet())
//                        dimen = r.getDimension(R.dimen._95sdp)
//                    val px = TypedValue.applyDimension(
//                        TypedValue.COMPLEX_UNIT_DIP, dimen, r.displayMetrics
//                    ).roundToInt()
//
////                    TapTargetView.showFor(this,
////                        TapTarget.forView(
////                            mBinding.img1, "",
////                            msg
////                        )
////                            .targetRadius(px / 4)
////                            .cancelable(true)
////                            .textColor(R.color.white)
////                            .descriptionTextColor(R.color.white)
////                            .descriptionTextAlpha(1f)
////                            .tintTarget(false),
////                        object : TapTargetView.Listener() {
////                            override fun onTargetClick(view: TapTargetView) {
////                                super.onTargetClick(view)
////                                view.dismiss(true)
////                                mBinding.img1.visibility = GONE
////                                config.isMediaLongPressInfoShown = true
////                            }
////
////                            override fun onTargetCancel(view: TapTargetView?) {
////                                super.onTargetCancel(view)
////                                mBinding.img1.visibility = GONE
////                                config.isMediaLongPressInfoShown = true
////                            }
////                        })
//                } else {
////                    TapTargetView.showFor(this,
////                        TapTarget.forView(
////                            mBinding.img1, "",
////                            msg
////                        )
////                            .cancelable(true)
////                            .textColor(R.color.white)
////                            .descriptionTextColor(R.color.white)
////                            .descriptionTextAlpha(1f)
////                            .tintTarget(false),
////                        object : TapTargetView.Listener() {
////                            override fun onTargetClick(view: TapTargetView) {
////                                super.onTargetClick(view)
////                                view.dismiss(true)
////                                mBinding.img1.visibility = GONE
//                                config.isMediaLongPressInfoShown = true
////                            }
////
////                            override fun onTargetCancel(view: TapTargetView?) {
////                                super.onTargetCancel(view)
////                                mBinding.img1.visibility = GONE
//                                config.isMediaLongPressInfoShown = true
////                            }
////                        })
//                }
//            }
//        }
        setupScrollDirection()
    }

    private fun itemClicked(path: String) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()
        itemClickPath = path
        if (isSetWallpaperIntent()) {
            toast(R.string.setting_wallpaper)

            val wantedWidth = wallpaperDesiredMinimumWidth
            val wantedHeight = wallpaperDesiredMinimumHeight
            val ratio = wantedWidth.toFloat() / wantedHeight

            val options = RequestOptions()
                .override((wantedWidth * ratio).toInt(), wantedHeight)
                .fitCenter()

            Glide.with(this)
                .asBitmap()
                .load(File(path))
                .apply(options)
                .into(object : SimpleTarget<Bitmap>() {
                    override fun onResourceReady(
                        resource: Bitmap,
                        transition: Transition<in Bitmap>?
                    ) {
                        try {
                            WallpaperManager.getInstance(applicationContext).setBitmap(resource)
                            setResult(Activity.RESULT_OK)
                        } catch (ignored: IOException) {
                        }

                        finish()
                    }
                })
        } else {
            val isVideo = path.isVideoFast()
            if (isVideo) {
                if (isVideoClicked)
                    return
                isVideoClicked = true
                ensureBackgroundThread {
                    var media = mMedia as ArrayList<Medium>
                    media = media.filter { medium ->
                        medium.isVideo() && medium.path.getFilenameExtension() != ".avi" && medium.path.getFilenameExtension() != ".flv"
                    } as ArrayList<Medium>
                    uriList = media.map {
                        FileProvider.getUriForFile(
                            this,
                            "$packageName.fileprovider", File(it.path)
                        )
                    } as ArrayList<Uri>
                }
                if (MainActivity.isAdShown) {
                    loadVideo(path)
                } else {
                    if (AdsManager(this).isNeedToShowAds() && isOnline()) {
                        isShowInterstitialAd {

                            isInterstitialShown = false
                            loadVideo(path)
                        }

                    } else {
                        isInterstitialShown = false
                        loadVideo(path)
                    }
                }
            } else {
                ImagePreviewActivity.mPlaceItemList = mMedia
                Intent(this, ImagePreviewActivity::class.java).apply {
                    putExtra(SKIP_AUTHENTICATION, shouldSkipAuthentication())
                    putExtra(PATH, path)
                    putExtra(SHOW_ALL, mShowAll)
                    putExtra(SHOW_ONLY_HIDDEN, mShowOnlyHidden)
                    putExtra(SHOW_FAVORITES, mPath == FAVORITES)
                    putExtra(SHOW_RECYCLE_BIN, mPath == RECYCLE_BIN)
                    putExtra(IS_FROM_FAKE_VAULT, isFromFakeVault)
                    putExtra(IS_FROM_VAULT, isFromVault)
                    putExtra(IS_FROM_ALL_HIDE_FILE, isFromAllFileHide)

                    startActivity(this)
                }
            }
        }
    }

    private var uriList = ArrayList<Uri>()
    private fun loadVideo(path: String) {
        isVideoClicked = false
        val extras = HashMap<String, Boolean>()
        extras[SHOW_FAVORITES] = mPath == FAVORITES

        if (shouldSkipAuthentication()) {
            extras[SKIP_AUTHENTICATION] = true
        }
        //                openPath(path, false, extras)
        val uri = FileProvider.getUriForFile(
            this,
            "$packageName.fileprovider", File(path)
        )


        val mimeType = getUriMimeType(path, uri)
        if (VideoPlayerActivity.mActivity != null) {
            VideoPlayerActivity.mActivity.finish()
        }

        val extension: String = uri.path!!.substring(uri.path!!.lastIndexOf("."))

        if (extension == ".avi" || extension == ".flv") {
            val file: File = File(uri.path)
            Log.e("TAG", "loadVideo:absolutePath --> " + file.absolutePath)

            val intent = Intent(Intent.ACTION_VIEW)
            intent.setDataAndType(
                Uri.parse(file.absolutePath.replace("/external_files", "")),
                "video/*"
            )
            try {
                startActivity(intent)
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(getContext(), R.string.error_no_video_activity, Toast.LENGTH_SHORT)
                    .show()
            }

        } else {
            VideoPlayerActivity.UriList = uriList
            VideoPlayerActivity.index = uriList.indexOf(uri)
            Intent(applicationContext, VideoPlayerActivity::class.java).apply {
                setDataAndType(uri, mimeType)
                addFlags(Intent.FLAG_ACTIVITY_FORWARD_RESULT)

                if (intent.extras != null) {
                    putExtras(intent.extras!!)
                }

                startActivity(this)
                overridePendingTransition(0, 0);
            }
        }
    }

    private fun shouldSkipAuthentication() = intent.getBooleanExtra(SKIP_AUTHENTICATION, false)

    private fun isSetWallpaperIntent() = intent.getBooleanExtra(SET_WALLPAPER_INTENT, false)

    private fun setupLayoutManager() {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        if (viewType == VIEW_TYPE_GRID) {
            setupGridLayoutManager()
        } else {
            setupListLayoutManager()
        }
    }

    private fun setupGridLayoutManager() {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        (mBinding.mediaGrid.layoutParams as RelativeLayout.LayoutParams).apply {
            topMargin = 0
            bottomMargin = 0
        }

        if (config.scrollHorizontally) {
            layoutManager.orientation = RecyclerView.HORIZONTAL
        } else {
            layoutManager.orientation = RecyclerView.VERTICAL
        }

        layoutManager.spanCount = config.mediaColumnCnt
        val adapter = getMediaAdapter()
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                return if (adapter?.isASectionTitle(position) == true) {
                    layoutManager.spanCount
                } else {
                    1
                }
            }
        }
    }

    private fun setupScrollDirection() {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        val allowHorizontalScroll = config.scrollHorizontally && viewType == VIEW_TYPE_GRID
        mBinding.mediaVerticalFastscroller.isHorizontal = false
        mBinding.mediaVerticalFastscroller.beGoneIf(allowHorizontalScroll)

        mBinding.mediaHorizontalFastscroller.isHorizontal = true
        mBinding.mediaHorizontalFastscroller.beVisibleIf(allowHorizontalScroll)

        val sorting = config.getFolderSorting(if (mShowAll) SHOW_ALL else mPath)
        if (allowHorizontalScroll) {
            mBinding.mediaHorizontalFastscroller.setViews(
                mBinding.mediaGrid,
                mBinding.mediaRefreshLayout
            ) {
                mBinding.mediaHorizontalFastscroller.updateBubbleText(
                    getBubbleTextItem(
                        it,
                        sorting!!
                    )
                )
            }
        } else {
            mBinding.mediaVerticalFastscroller.setViews(
                mBinding.mediaGrid,
                mBinding.mediaRefreshLayout
            ) {
                mBinding.mediaVerticalFastscroller.updateBubbleText(
                    getBubbleTextItem(
                        it,
                        sorting!!
                    )
                )
            }
        }
    }

    private fun getBubbleTextItem(index: Int, sorting: Int): String {
        var realIndex = index
        val mediaAdapter = getMediaAdapter()
        if (mediaAdapter!!.isASectionTitle(index)) {
            realIndex++
        }
        return mediaAdapter.getItemBubbleText(realIndex, sorting, mDateFormat, mTimeFormat) ?: ""
    }

    private fun isDirEmpty(): Boolean {
        return if (mMedia.size <= 0 && config.filterMedia > 0) {
            if (mPath != FAVORITES && mPath != RECYCLE_BIN) {
                if (!isUnHideImage) {
                    deleteDirectoryIfEmpty()
                    deleteDBDirectory()
                } else
                    isUnHideImage = false


            }

            if (mPath == FAVORITES) {
                ensureBackgroundThread {
                    directoryDao.deleteDirPath(FAVORITES)
                }
            }

            true
        } else {
            false
        }
    }

    private fun initZoomListener() {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        if (viewType == VIEW_TYPE_GRID) {
            val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
            mZoomListener = object : MyRecyclerView.MyZoomListener {
                override fun zoomIn() {
                    if (layoutManager.spanCount > 1) {
                        reduceColumnCount()
                        getMediaAdapter()?.finishActMode()
                    }
                }

                override fun zoomOut() {
                    if (layoutManager.spanCount < MAX_COLUMN_COUNT) {
                        increaseColumnCount()
                        getMediaAdapter()?.finishActMode()
                    }
                }
            }
        } else {
            mZoomListener = null
        }
    }

    private fun setupListLayoutManager() {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = 1
        layoutManager.orientation = RecyclerView.VERTICAL
//        media_refresh_layout.layoutParams = ConstraintLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        val smallMargin = resources.getDimension(R.dimen.small_margin).toInt()
        (mBinding.mediaGrid.layoutParams as RelativeLayout.LayoutParams).apply {
            topMargin = smallMargin
            bottomMargin = smallMargin
        }

        mZoomListener = null
    }

    private fun increaseColumnCount() {
        config.mediaColumnCnt =
            ++(mBinding.mediaGrid.layoutManager as MyGridLayoutManager).spanCount
        columnCountChanged()
    }

    private fun reduceColumnCount() {
        config.mediaColumnCnt =
            --(mBinding.mediaGrid.layoutManager as MyGridLayoutManager).spanCount
        columnCountChanged()
    }

    private fun columnCountChanged() {
        handleGridSpacing()
        ActivityCompat.invalidateOptionsMenu(this)
        getMediaAdapter()?.apply {
            notifyItemRangeChanged(0, media.size)
            measureRecyclerViewContent(media)
        }
    }

    private fun measureRecyclerViewContent(media: ArrayList<ThumbnailItem>) {
        mBinding.mediaGrid.onGlobalLayout {
            if (config.scrollHorizontally) {
                calculateContentWidth(media)
            } else {
                calculateContentHeight(media)
            }
        }
    }

    private fun calculateContentWidth(media: ArrayList<ThumbnailItem>) {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        val thumbnailWidth = layoutManager.getChildAt(0)?.width ?: 0
        val spacing = config.thumbnailSpacing
        val fullWidth =
            ((media.size - 1) / layoutManager.spanCount + 1) * (thumbnailWidth + spacing) - spacing
        mBinding.mediaHorizontalFastscroller.setContentWidth(fullWidth)
        mBinding.mediaHorizontalFastscroller.setScrollToX(mBinding.mediaGrid.computeHorizontalScrollOffset())
    }

    private fun calculateContentHeight(media: ArrayList<ThumbnailItem>) {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        val pathToCheck = if (mPath.isEmpty()) SHOW_ALL else mPath
        val hasSections =
            config.getFolderGrouping(pathToCheck) and GROUP_BY_NONE == 0 && !config.scrollHorizontally
        val sectionTitleHeight = if (hasSections) layoutManager.getChildAt(0)?.height ?: 0 else 0
        val thumbnailHeight =
            if (hasSections) layoutManager.getChildAt(1)?.height ?: 0 else layoutManager.getChildAt(
                0
            )?.height ?: 0

        var fullHeight = 0
        var curSectionItems = 0
        media.forEach {
            if (it is ThumbnailSection) {
                fullHeight += sectionTitleHeight
                if (curSectionItems != 0) {
                    val rows = ((curSectionItems - 1) / layoutManager.spanCount + 1)
                    fullHeight += rows * thumbnailHeight
                }
                curSectionItems = 0
            } else {
                curSectionItems++
            }
        }
        val spacing = config.thumbnailSpacing
        fullHeight += ((curSectionItems - 1) / layoutManager.spanCount + 1) * (thumbnailHeight + spacing) - spacing
        mBinding.mediaVerticalFastscroller.setContentHeight(fullHeight)
        mBinding.mediaVerticalFastscroller.setScrollToY(mBinding.mediaGrid.computeVerticalScrollOffset())
    }


    private fun handleGridSpacing(media: ArrayList<ThumbnailItem> = mMedia) {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        if (viewType == VIEW_TYPE_GRID) {
            val spanCount = config.mediaColumnCnt
            val spacing = config.thumbnailSpacing
            val useGridPosition = media.firstOrNull() is ThumbnailSection

            var currentGridDecoration: GridSpacingItemDecoration? = null
            if (mBinding.mediaGrid.itemDecorationCount > 0) {
                currentGridDecoration =
                    mBinding.mediaGrid.getItemDecorationAt(0) as GridSpacingItemDecoration
                currentGridDecoration.items = media
            }

            val newGridDecoration = GridSpacingItemDecoration(
                spanCount,
                spacing,
                config.scrollHorizontally,
                config.fileRoundedCorners,
                media,
                useGridPosition
            )
            if (currentGridDecoration.toString() != newGridDecoration.toString()) {
                if (currentGridDecoration != null) {
                    mBinding.mediaGrid.removeItemDecoration(currentGridDecoration)
                }
                mBinding.mediaGrid.addItemDecoration(newGridDecoration)
            }
        }
    }

    companion object {
        var mMedia = ArrayList<ThumbnailItem>()
        var isUnHideImage = false
    }

    override fun refreshItems() {
        isProccessOver = true
        startAsyncTask()
    }

    override fun tryDeleteFiles(fileDirItems: ArrayList<FileDirItem>) {
        val filtered = fileDirItems.filter { it.path.isMediaFile() } as ArrayList
        if (filtered.isEmpty()) {
            return
        }
        if (isFromVault && !isFromAllFileHide) {
            movePathsInRecycleBin(filtered.map { it.path } as ArrayList<String>,
                isFakeVaultOpen = isFromFakeVault) {
                if (it) {
                    deleteFilteredFiles(filtered)
                } else {
                    toast(R.string.unknown_error_occurred)
                }
            }
        } else {
            movePathsInRecoverTrash(filtered.map { it.path } as ArrayList<String>,
                isFakeVaultOpen = isFromFakeVault) {
                if (it) {
//                    if (getMediaAdapter() != null)
//                        getMediaAdapter()!!.dismissProgress()
//                    deleteFilteredFiles(filtered)

                    mMedia.removeAll { filtered.map { it.path }.contains((it as? Medium)?.path) }
                    if (mBinding.etSearch.text.isNotEmpty())
                        mBinding.imgClose.performClick()
                    ensureBackgroundThread {
                        if (!isFromVault) {
                            filtered.forEach {
                                deleteDBPath(it.path)

                            }
                        }
                        if (mPath.containsNoMedia() || filtered[0].path.getFilenameFromPath()
                                .startsWith(".")
                        ) {
                            if (hiddenDirectoryDao.getDirectoryThumbnail(mPath) != null) {
                                updatePhotoVideoDirectoryPath(mPath, false, true, true)
                                updatePhotoVideoDirectoryPath(mPath, true, false, true)
                            }
                        }
                        Log.d(
                            "RefreshMedia1234",
                            "updatePhotoVideoDirectoryPath: Called TYpe Video  ---> "
                        )

                        updatePhotoVideoDirectoryPath(mPath, false, true)
                        Log.d(
                            "RefreshMedia1234",
                            "updatePhotoVideoDirectoryPath: Called TYpe Image  ---> "
                        )
                        updatePhotoVideoDirectoryPath(mPath, true, false)


                        runOnUiThread {
                            MainActivity.isNeedToRefresh = true
                            VaultFragment.isNeedToRefresh = true
                            HiddenImagesActivity.isNeedToRefresh = true
                            AllHiddenFileActivity.isNeedToRefresh = true
                            isProccessOver = true
                            if (getMediaAdapter() != null)
                                getMediaAdapter()!!.dismissProgress()
                            refreshItems()
                            if (mMedia.isEmpty()) {
                                deleteDirectoryIfEmpty()
                                deleteDBDirectory()
                                finish()
                            }
                        }
                    }
                } else {
                    toast(R.string.unknown_error_occurred)
                }
            }
//            deleteFilteredFiles(filtered)
        }

    }

    private fun deleteFilteredFiles(filtered: ArrayList<FileDirItem>) {
        deleteFiles(filtered) {
            if (!it) {
                toast(R.string.unknown_error_occurred)
                if (getMediaAdapter() != null)
                    getMediaAdapter()!!.dismissProgress()
                return@deleteFiles
            }

            mMedia.removeAll { filtered.map { it.path }.contains((it as? Medium)?.path) }
            if (mBinding.etSearch.text.isNotEmpty())
                mBinding.imgClose.performClick()
            ensureBackgroundThread {
                if (!isFromVault) {
                    filtered.forEach {
                        deleteDBPath(it.path)

                    }
                }
                if (mPath.containsNoMedia() || filtered[0].path.getFilenameFromPath()
                        .startsWith(".")
                ) {
                    if (hiddenDirectoryDao.getDirectoryThumbnail(mPath) != null) {
                        updatePhotoVideoDirectoryPath(mPath, false, true, true)
                        updatePhotoVideoDirectoryPath(mPath, true, false, true)
                    }
                }
                Log.d("RefreshMedia1234", "updatePhotoVideoDirectoryPath: Called TYpe Video  ---> ")

                updatePhotoVideoDirectoryPath(mPath, false, true)
                Log.d("RefreshMedia1234", "updatePhotoVideoDirectoryPath: Called TYpe Image  ---> ")
                updatePhotoVideoDirectoryPath(mPath, true, false)


                runOnUiThread {
                    MainActivity.isNeedToRefresh = true
                    VaultFragment.isNeedToRefresh = true
                    HiddenImagesActivity.isNeedToRefresh = true
                    AllHiddenFileActivity.isNeedToRefresh = true
                    isProccessOver = true
                    if (getMediaAdapter() != null)
                        getMediaAdapter()!!.dismissProgress()
                    refreshItems()
                    if (mMedia.isEmpty()) {
                        deleteDirectoryIfEmpty()
                        deleteDBDirectory()
                        finish()
                    }
                }
            }


        }
    }

    private fun deleteDirectoryIfEmpty() {
        if (config.deleteEmptyFolders) {
            val fileDirItem = FileDirItem(mPath, mPath.getFilenameFromPath(), true)
            if (!fileDirItem.isDownloadsFolder() && fileDirItem.isDirectory) {
                ensureBackgroundThread {
                    if (fileDirItem.getProperFileCount(this, true) == 0) {
                        tryDeleteFileDirItem(fileDirItem, true, true)
                    }
                }
            }
        }
    }

    private fun deleteDBDirectory() {
        ensureBackgroundThread {
            try {
                directoryDao.deleteDirPath(mPath)
            } catch (ignored: Exception) {
            }
        }
    }

    override fun selectedPaths(paths: ArrayList<String>) {
        Intent().apply {
            putExtra(PICKED_PATHS, paths)
            setResult(Activity.RESULT_OK, this)
        }
        finish()
    }

    override fun updateMediaGridDecoration(media: ArrayList<ThumbnailItem>) {
        var currentGridPosition = 0
        media.forEach {
            if (it is Medium) {
                it.gridPosition = currentGridPosition++
            } else if (it is ThumbnailSection) {
                currentGridPosition = 0
            }
        }

        if (mBinding.mediaGrid.itemDecorationCount > 0) {
            val currentGridDecoration =
                mBinding.mediaGrid.getItemDecorationAt(0) as GridSpacingItemDecoration
            currentGridDecoration.items = media
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        if (mBinding.llProgress.visibility == VISIBLE)
            mBinding.llProgress.visibility = GONE
        finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    fun toggleToolbar(isShowActionBar: Boolean) {
        if (isShowActionBar) {
            if (mBinding.etSearch.visibility == VISIBLE)
                hideKeyboard(mBinding.etSearch)
            mBinding.llBottomOption.visibility = VISIBLE
//            if (!config.isMediaMenuInfoShown) {
//                imgOptionMenu.visibility = VISIBLE
//                TapTargetView.showFor(
//                    this,
//                    TapTarget.forView(imgOptionMenu, "Options", "Tap for more options")
//                        .cancelable(true)
//                        .textColor(R.color.white)
//                        .descriptionTextColor(R.color.white)
//                        .descriptionTextAlpha(1f)
//                        .tintTarget(true), object : TapTargetView.Listener() {
//                        override fun onTargetClick(view: TapTargetView) {
//                            super.onTargetClick(view)
//                            view.dismiss(true)
//                            imgOptionMenu.visibility = GONE
//                            config.isMediaMenuInfoShown = true
//                        }
//
//                        override fun onTargetCancel(view: TapTargetView?) {
//                            super.onTargetCancel(view)
//                            imgOptionMenu.visibility = GONE
//                            config.isMediaMenuInfoShown = true
//                        }
//                    })
//            }
        } else {
            mBinding.imgOptionMenu.visibility = GONE
            mBinding.llBottomOption.visibility = GONE
        }

    }

    fun setOptions(selectedItems: ArrayList<Medium>) {
        if (selectedItems.any {
                !it.isHidden() && !it.path.doesThisOrParentHaveNoMedia(
                    HashMap(),
                    null
                )
            }) {
            mBinding.llHideOpt.visibility = VISIBLE
            mBinding.tvHideUnHideText.text =
                resources.getString(R.string.hide_photo, selectedItems.size)
            mBinding.imgOptHideUnHide.setImageDrawable(resources.getDrawable(R.drawable.ic_option_hide))
            isHide = true
        } else if (selectedItems.any {
                it.isHidden() && !it.path.doesThisOrParentHaveNoMedia(
                    HashMap(),
                    null
                )
            }) {
            mBinding.llHideOpt.visibility = VISIBLE
            mBinding.tvHideUnHideText.text =
                resources.getString(R.string.unhide_photo, selectedItems.size)
            mBinding.imgOptHideUnHide.setImageDrawable(resources.getDrawable(R.drawable.ic_option_unhide))
            isHide = false
        } else {
            mBinding.llHideOpt.visibility = GONE
        }
    }

    override fun onPDFGenerated(pdfFile: File?, numOfImages: Int) {
        dismissProgress()
        if (getMediaAdapter() != null) {
            getMediaAdapter()!!.dismissProgress()
            getMediaAdapter()!!.finishActMode()
        }
        if (pdfFile != null) {
            if (pdfFile.exists()) {
                try {
                    MediaScannerConnection.scanFile(
                        this, arrayOf(pdfFile.absolutePath),
                        null, null
                    )
                } catch (e: Exception) {
                }
                Log.d(TAG, "onPDFGenerated:  Pdf file -->" + pdfFile!!.absolutePath)
                Log.d(TAG, "onPDFGenerated:  numberofPages -->" + numOfImages)
                toast("Your pdf is saved at ${pdfFile.absolutePath}")


                openPath(pdfFile.absolutePath, true)
            }
        }

    }
}