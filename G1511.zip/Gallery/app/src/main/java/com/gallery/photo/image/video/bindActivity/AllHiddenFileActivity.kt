package com.gallery.photo.image.video.bindActivity

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.SystemClock
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.View.VISIBLE
import android.widget.EditText
import androidx.recyclerview.widget.RecyclerView
import com.example.app.ads.helper.GiftIconHelper
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.*
import com.gallery.photo.image.video.adapter.DirectoryAdapter
import com.gallery.photo.image.video.adshelper.AdsManager

import com.gallery.photo.image.video.databinding.ActivityHiddenImagesBinding
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.fragment.PhotoDirectoryFragment
import com.gallery.photo.image.video.fragment.VaultFragment
import com.gallery.photo.image.video.fragment.VideoDirectoryFragment
import com.gallery.photo.image.video.interfaces.DirectoryOperationsListener
import com.gallery.photo.image.video.models.Directory
import com.gallery.photo.image.video.models.FakeVaultMedium
import com.gallery.photo.image.video.models.Medium
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.helpers.*
import com.gallery.photo.image.video.models.FileDirItem
import com.gallery.photo.image.video.views.MyGridLayoutManager
import com.gallery.photo.image.video.views.MyRecyclerView
import java.io.File
import java.util.*
import kotlin.collections.ArrayList

class AllHiddenFileActivity : BaseBindingActivity<ActivityHiddenImagesBinding>(), DirectoryOperationsListener {

    var title: String? = null
    private val PICK_MEDIA = 2
    private val PICK_WALLPAPER = 3


    private var mIsPickImageIntent = false
    private var mIsPickVideoIntent = false
    private var mIsGetImageContentIntent = false
    private var mIsGetVideoContentIntent = false
    private var mIsGetAnyContentIntent = false
    private var mIsSetWallpaperIntent = false
    private var mAllowPickingMultiple = false

    private var mLoadedInitialPhotos = false
    private var mShouldStopFetching = false
    private var mIsSearchOpen = false
    private var mCurrentPathPrefix = ""
    private var mOpenedSubfolders = arrayListOf("")
    private var mDateFormat = ""
    private var mTimeFormat = ""
    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mLastMediaFetcher: MediaFetcher? = null
    public var mDirs = ArrayList<Directory>()
    var mIsGettingDirs = false
    var isFABOpen = false
    var isPhotosSelected = true

    var mCurrentPhotoUri: Uri? = null
    var mCurrentPhotoPath: String = ""

    companion object {
        fun newIntent(mContext: Context): Intent {
            return Intent(mContext, AllHiddenFileActivity::class.java)
        }

        var isNeedToRefresh = false

    }

    override fun getAppIconIDs() = arrayListOf(
        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName() = getString(R.string.app_name)

    override fun setBinding(): ActivityHiddenImagesBinding {
        return ActivityHiddenImagesBinding.inflate(layoutInflater)
    }

    override fun getContext(): Activity {
        return this
    }

    override fun initData() {
        mBinding.tvTitle.text = getString(R.string.label_hidden_files)
        mBinding.directoriesClickHereToAdd.text = getString(R.string.msg_click_here_to_hide_photos)
        mBinding.etSearch.hint = getString(R.string.msg_search_photo_by_name)
        mBinding.tvGallery.text = getString(R.string.label_photos)
        mBinding.fabAddHiddenPhotoFromGallery.setImageDrawable(getDrawable(R.drawable.ic_vault_add_gallery))
        mBinding.directoriesRefreshLayout.setOnRefreshListener { getDirectories() }
        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            GiftIconHelper.loadGiftAd(
                fContext = this,
                fivGiftIcon = mBinding.giftLayout.giftAdIcon,
                fivBlastIcon = mBinding.giftLayout.giftBlastAdIcon
            )
        }
        getDirectories()
    }

    override fun initActions() {
        setupSearch()
        mBinding.imgAddHiddenPhoto.beGone()
        mBinding.rlAddHiddenPhotoVideo.beGone()
        mBinding.imgBack.setOnClickListener(this)
        mBinding.imgSearch.setOnClickListener(this)
        mBinding.imgClose.setOnClickListener(this)
        mBinding.llHideOpt.setOnClickListener(this)
        mBinding.flBackground.setOnClickListener(this)
    }

    private fun setupSearch() {

        mBinding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                setupAdapter(mDirs, s.toString())
            }

            override fun afterTextChanged(s: Editable?) {

            }

        })
    }

    override fun onClick(view: View) {
        super.onClick(view)
        when (view.id) {
            R.id.imgBack -> {
                onBackPressed()
            }
            R.id.imgSearch -> {
                mBinding.etSearch.visibility = View.VISIBLE
                mBinding.imgClose.visibility = View.VISIBLE
                mBinding.tvTitle.visibility = View.GONE
                mBinding.imgSearch.visibility = View.GONE
                mBinding.imgOptions.visibility = View.GONE
                showKeyboard(mBinding.etSearch)
            }
            R.id.imgClose -> {
                mBinding.etSearch.text = null
                mBinding.etSearch.visibility = View.GONE
                mBinding.imgClose.visibility = View.GONE
                mBinding.tvTitle.visibility = View.VISIBLE
                mBinding.imgSearch.visibility = View.VISIBLE
                mBinding.imgOptions.visibility = View.VISIBLE
                setupAdapter(mDirs, "")
                hideKeyboard(mBinding.etSearch)
            }
            R.id.llHideOpt -> {
                if (getRecyclerAdapter() != null) {
                    getRecyclerAdapter()!!.toggleFoldersVisibility(false)
                }
            }



        }
    }


    override fun onResume() {
        super.onResume()

        if (isNeedToRefresh) {
            isNeedToRefresh = false
            refreshItems()
        }
    }

    private fun getDirectories() {


        Log.d("Tag Get Directory ", mIsGettingDirs.toString())
        if (mIsGettingDirs) {
            return
        }
        mShouldStopFetching = true
        mIsGettingDirs = true
        mBinding.llProgress.beVisible()


        if (getRecyclerAdapter() != null) {
            getRecyclerAdapter()!!.dismissProgress()
            getRecyclerAdapter()!!.finishActMode()
        }
        getCachedHiddenDirectories(false, false, forceShowHidden = true) {
            gotDirectories(addTempFolderIfNeeded(it), false)
        }
    }

    fun getRecyclerAdapter() = mBinding.directoriesGrid.adapter as? DirectoryAdapter

    private fun gotDirectories(newDirs: ArrayList<Directory>, isFakeVault: Boolean) {
        mIsGettingDirs = false
        mShouldStopFetching = false
        setupLayoutManager()
        // if hidden item showing is disabled but all Favorite items are hidden, hide the Favorites folder
        if (!config.shouldShowHidden) {
            val favoritesFolder = newDirs.firstOrNull { it.areFavorites() }
            if (favoritesFolder != null && favoritesFolder.tmb.getFilenameFromPath().startsWith('.')) {
                newDirs.remove(favoritesFolder)
            }
        }

        var mDirsHiddenByGallery = ArrayList<Directory>()
        getCachedHiddenDirectories(false, false, forceShowHidden = true) {
            mDirsHiddenByGallery = it
        }


        var dirs = getSortedDirectories(newDirs)

        runOnUiThread {
            checkPlaceholderVisibility(dirs)
        }

        // cached folders have been loaded, recheck folders one by one starting with the first displayed
        mLastMediaFetcher?.shouldStop = true
        mLastMediaFetcher = MediaFetcher(this)
        val getImagesOnly = mIsPickImageIntent || mIsGetImageContentIntent
        val getVideosOnly = mIsPickVideoIntent || mIsGetVideoContentIntent
        val hiddenString = getString(R.string.hidden)
        val getProperFileSize = config.directorySorting and SORT_BY_SIZE != 0
        val albumCovers = config.parseAlbumCovers()
        val includedFolders = config.includedFolders
        val noMediaFolders = getNoMediaFoldersSync()
        val favoritePaths = ArrayList<String>()
        val lastModifieds = mLastMediaFetcher!!.getLastModifieds()
        val dateTakens = mLastMediaFetcher!!.getDateTakens()

        val foldersToScan = mLastMediaFetcher!!.getFoldersToScan(TYPE_IMAGES or TYPE_VIDEOS, true)
        foldersToScan.add(FAVORITES)
        if (config.showRecycleBinAtFolders) {
            foldersToScan.add(RECYCLE_BIN)
        } else {
            foldersToScan.remove(RECYCLE_BIN)
        }

        dirs.forEach {
            foldersToScan.remove(it.path)
        }
        for (folder in foldersToScan) {
            try {
                if (mShouldStopFetching || isDestroyed || isFinishing) {
                    return
                }
            } catch (e: Exception) {
            }

            val sorting = config.getFolderSorting(folder)
            val grouping = config.getFolderGrouping(folder)
            val getProperDateTaken = config.directorySorting and SORT_BY_DATE_TAKEN != 0 ||
                    sorting and SORT_BY_DATE_TAKEN != 0 ||
                    grouping and GROUP_BY_DATE_TAKEN_DAILY != 0 ||
                    grouping and GROUP_BY_DATE_TAKEN_MONTHLY != 0

            val getProperLastModified = config.directorySorting and SORT_BY_DATE_MODIFIED != 0 ||
                    sorting and SORT_BY_DATE_MODIFIED != 0 ||
                    grouping and GROUP_BY_LAST_MODIFIED_DAILY != 0 ||
                    grouping and GROUP_BY_LAST_MODIFIED_MONTHLY != 0

            val newMedia = mLastMediaFetcher!!.getFilesFrom(
                folder, getImagesOnly, getVideosOnly, getProperDateTaken, getProperLastModified,
                getProperFileSize, favoritePaths, false, true, lastModifieds, dateTakens
            )

            if (newMedia.isEmpty()) {
                continue
            }

            val newDir = createDirectoryFromMedia(folder, newMedia, albumCovers, hiddenString, includedFolders, getProperFileSize, noMediaFolders)
            dirs.add(newDir)

            // make sure to create a new thread for these operations, dont just use the common bg thread
            Thread {
                mediaDB.insertAll(newMedia)
            }.start()
        }

        var HiddenDirList = ArrayList<Directory>()
        Log.d("TagHidden ", "Add n111" + dirs.size)
        dirs = dirs.filter { dir ->
            !mDirsHiddenByGallery.any { it.path == dir.path } && !dir.path.startsWith(TRASH_PATH) && !dir.name.contains(".thumbnails")
        } as ArrayList<Directory>
        for (directory in dirs) {
            Log.d("TagHidden ", "Add n111" + directory.mediaCnt)
            val sorting = config.getFolderSorting(directory.path)
            val grouping = config.getFolderGrouping(directory.path)
            val getProperDateTaken = config.directorySorting and SORT_BY_DATE_TAKEN != 0 ||
                    sorting and SORT_BY_DATE_TAKEN != 0 ||
                    grouping and GROUP_BY_DATE_TAKEN_DAILY != 0 ||
                    grouping and GROUP_BY_DATE_TAKEN_MONTHLY != 0

            val getProperLastModified = config.directorySorting and SORT_BY_DATE_MODIFIED != 0 ||
                    sorting and SORT_BY_DATE_MODIFIED != 0 ||
                    grouping and GROUP_BY_LAST_MODIFIED_DAILY != 0 ||
                    grouping and GROUP_BY_LAST_MODIFIED_MONTHLY != 0
            if (directory.name.contains(hiddenString) || directory.path.containsNoMedia()) {
                Log.d("TagHidden ", "Add n111")

                var curMedia = if (isFakeVault) {
                    var type = if (isPhotosSelected)
                        TYPE_IMAGES
                    else
                        TYPE_VIDEOS
                    var gif = fakeVaultMediumDao.getTypeMediaFromPath(directory.path, TYPE_GIFS)
                    var images = fakeVaultMediumDao.getTypeMediaFromPath(directory.path, type) as java.util.ArrayList<Medium>
                    var media = images
                    media.addAll(gif)
                    media
                } else {
                    var media = mLastMediaFetcher!!.getFilesFrom(
                        directory.path, getImagesOnly, getVideosOnly, getProperDateTaken, getProperLastModified,
                        getProperFileSize, favoritePaths, false, true, lastModifieds, dateTakens
                    )
                    var fakeMedia = fakeVaultMediumDao.getMediaFromPath(directory.path)
                    val firstListObjectIds = fakeMedia.map { it.path }.toSet()
                    media.filter { !firstListObjectIds.contains(it.path) } as java.util.ArrayList<Medium>
                }

                if (curMedia.size > 0) {
                    directory.mediaCnt = curMedia.size
                    directory.tmb = curMedia[0].path
                    HiddenDirList.add(directory)
                }
            } else {
                var curMedia = if (isFakeVault) {
                    var type = if (isPhotosSelected)
                        TYPE_IMAGES
                    else
                        TYPE_VIDEOS
                    var gif = fakeVaultMediumDao.getTypeMediaFromPath(directory.path, TYPE_GIFS)
                    var images = fakeVaultMediumDao.getTypeMediaFromPath(directory.path, type) as java.util.ArrayList<Medium>
                    var media = images
                    media.addAll(gif)
                    media
                } else {
                    var media = mLastMediaFetcher!!.getFilesFrom(
                        directory.path, getImagesOnly, getVideosOnly, getProperDateTaken, getProperLastModified,
                        getProperFileSize, favoritePaths, false, true, lastModifieds, dateTakens
                    )
                    var fakeMedia = fakeVaultMediumDao.getMediaFromPath(directory.path)
                    val firstListObjectIds = fakeMedia.map { it.path }.toSet()
                    media.filter { !firstListObjectIds.contains(it.path) && it.path.getFilenameFromPath().startsWith(".") } as java.util.ArrayList<Medium>
                }
                if (curMedia.size > 0) {
                    Log.d("TagHidden ", "Add 222")
                    directory.name = directory.name + hiddenString
                    directory.mediaCnt = curMedia.size
                    directory.tmb = curMedia[0].path
                    Log.d("TagHidden ", "Add 222 -->{${directory.name}}")
                    HiddenDirList.add(directory)
                } else {
                    HiddenDirList.remove(directory)
//                    hiddenDirectoryDao.deleteDirPath(directory.path)

                }
            }
        }

        Log.d("TagHidden ", HiddenDirList.size.toString())
        mDirs = HiddenDirList
        setupAdapter(mDirs)
        Thread {

            runOnUiThread {
                mBinding.directoriesRefreshLayout.isRefreshing = false
                VaultFragment.isLoadedGallery = true
                checkPlaceholderVisibility(HiddenDirList)
                mBinding.llProgress.visibility = View.GONE
            }
        }.start()

    }

    fun setupAdapter(dirs: ArrayList<Directory>, textToSearch: String = "", forceRecreate: Boolean = false) {

        runOnUiThread {

            if (mBinding.directoriesGrid != null) {

                val currAdapter = mBinding.directoriesGrid.adapter
                val distinctDirs = dirs.distinctBy { it.path.getDistinctPath() }.toMutableList() as ArrayList<Directory>
                val sortedDirs = getSortedDirectories(distinctDirs)
                var dirsToShow = getDirsToShow(sortedDirs, mDirs, mCurrentPathPrefix).clone() as ArrayList<Directory>
                dirsToShow.sortWith { o1, o2 ->
                    o1 as Directory
                    o2 as Directory
                    var result = when {
                        config.directorySorting and SORT_BY_NAME != 0 -> {
                            o1.name.lowercase(Locale.getDefault()).compareTo(o2.name.lowercase(Locale.getDefault()))
                        }
                        config.directorySorting and SORT_BY_DATE_MODIFIED != 0 -> (o1.modified).compareTo(o2.modified)
                        config.directorySorting and SORT_BY_SIZE != 0 -> o1.mediaCnt.compareTo(o2.mediaCnt)
                        else -> o1.actualFolderCount.compareTo(o2.actualFolderCount)
                    }


                    if (config.directorySorting and SORT_DESCENDING != 0) {
                        result *= -1
                    }
                    result
                }
                if (currAdapter == null || forceRecreate) {
//                initZoomListener()
                    val fastscroller = mBinding.directoriesVerticalFastscroller
                    DirectoryAdapter(
                        this,
                        dirsToShow,
                        this,
                        mBinding.directoriesGrid,
                        isPickIntent(intent) || isGetAnyContentIntent(intent),
                        true,
                        mBinding.directoriesRefreshLayout,
                        fastscroller
                    ) {
                        val clickedDir = it as Directory
                        val path = clickedDir.path
                        if (clickedDir.subfoldersCount == 1 || !config.groupDirectSubfolders) {
                            if (path != config.tempFolderPath) {
                                itemClicked(path)
                            }
                        } else {
                            mCurrentPathPrefix = path
                            mOpenedSubfolders.add(path)
                            setupAdapter(mDirs, "")
                        }
                    }.apply {
//                    setupZoomListener(mZoomListener)
                        runOnUiThread {

                            mBinding.directoriesGrid.adapter = this
                            setupScrollDirection()

                            if (config.viewTypeFolders == VIEW_TYPE_LIST) {
                                mBinding.directoriesGrid.scheduleLayoutAnimation()
                            }
                        }
                    }
                } else {
                    runOnUiThread {
                        if (textToSearch.isNotEmpty()) {
                            dirsToShow = dirsToShow.filter { it.name.contains(textToSearch, true) }.sortedBy { !it.name.startsWith(textToSearch, true) }.toMutableList() as ArrayList
                        }
                        checkPlaceholderVisibility(dirsToShow)

                        (mBinding.directoriesGrid.adapter as? DirectoryAdapter)?.updateDirs(dirsToShow)
                    }
                }
            }
        }

    }

    private fun itemClicked(path: String) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()
        if (config.isAnyOperationRunning && path == config.lastDestinationPath) {
            toast(getString(com.gallery.photo.image.video.R.string.msg_operation_already_running))
        } else {
            handleLockedFolderOpening(path) { success ->
                if (success) {
                    Log.d("Tag", "clicked")
                    Intent(this, MediaActivity::class.java).apply {
                        putExtra(SKIP_AUTHENTICATION, true)
                        putExtra(DIRECTORY, path)
                        putExtra(SHOW_ONLY_HIDDEN, true)
                        handleMediaIntent(this)
                    }
                }
            }
        }
    }

    private fun handleMediaIntent(intent: Intent) {
        intent.apply {
            if (mIsSetWallpaperIntent) {
                putExtra(SET_WALLPAPER_INTENT, true)
                launchActivityForResult(this, PICK_WALLPAPER)
            } else {
                putExtra(GET_IMAGE_INTENT, mIsPickImageIntent || mIsGetImageContentIntent)
                putExtra(GET_VIDEO_INTENT, mIsPickVideoIntent || mIsGetVideoContentIntent)
                putExtra(GET_ANY_INTENT, mIsGetAnyContentIntent)
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, mAllowPickingMultiple)
                putExtra(IS_FROM_FAKE_VAULT, VaultFragment.isFakeVaultOpen)
                putExtra(IS_FROM_VAULT, true)
                putExtra(IS_FROM_ALL_HIDE_FILE, true)
                launchActivityForResult(this, PICK_MEDIA)
            }
        }
    }


    private fun checkPlaceholderVisibility(dirs: ArrayList<Directory>) {
        runOnUiThread {
            mBinding.directoriesEmptyPlaceholder.beVisible()
            mBinding.directoriesEmptyPlaceholder2.beGone()
            mBinding.directoriesEmptyPlaceholder.beVisibleIf(dirs.isEmpty())
            if (mIsSearchOpen) {
                mBinding.directoriesEmptyPlaceholder.beVisibleIf(dirs.isEmpty())
                mBinding.directoriesEmptyPlaceholder.text = getString(R.string.no_items_found)
            } else if (dirs.isEmpty() && config.filterMedia == getDefaultFileFilter()) {

                mBinding.directoriesEmptyPlaceholder.text = getString(R.string.no_media_with_filters)
                mBinding.directoriesEmptyPlaceholder2.text = getString(R.string.add_folder)
                mDirs = dirs
            } else {
                mBinding.directoriesEmptyPlaceholder.text = getString(R.string.no_media_with_filters)
                mBinding.directoriesEmptyPlaceholder2.text = getString(R.string.change_filters_underlined)
            }

            mBinding.directoriesEmptyPlaceholder2.underlineText()
            mBinding.directoriesGrid.beVisibleIf(mBinding.directoriesEmptyPlaceholder.isGone())
            if (dirs.isEmpty()) {
                config.hiddenCountForRate = 0

            }
        }

    }

    fun setupLayoutManager() {
        runOnUiThread(Runnable {
            if (config.viewTypeFolders == VIEW_TYPE_GRID) {
                setupGridLayoutManager()
            } else {
                setupListLayoutManager()
            }
        })

    }

    private fun setupGridLayoutManager() {
        //Hidden By Gallery App Layout Manager
        val layoutManager = mBinding.directoriesGrid.layoutManager as MyGridLayoutManager
        if (config.scrollHorizontally) {
            layoutManager.orientation = RecyclerView.HORIZONTAL
        } else {
            layoutManager.orientation = RecyclerView.VERTICAL
        }
        layoutManager.spanCount = config.dirColumnCnt
    }

    private fun setupListLayoutManager() {
        val layoutManager = mBinding.directoriesGrid.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = 1
        layoutManager.orientation = RecyclerView.VERTICAL
    }

    private fun isPickIntent(intent: Intent) = intent.action == Intent.ACTION_PICK

    private fun isGetContentIntent(intent: Intent) = intent.action == Intent.ACTION_GET_CONTENT && intent.type != null

    private fun isGetAnyContentIntent(intent: Intent) = isGetContentIntent(intent) && intent.type == "*/*"

    private fun setupScrollDirection() {
        val allowHorizontalScroll = config.scrollHorizontally && config.viewTypeFolders == VIEW_TYPE_GRID
        mBinding.directoriesVerticalFastscroller.isHorizontal = false
        mBinding.directoriesVerticalFastscroller.beGoneIf(allowHorizontalScroll)
    }

    override fun refreshItems() {
        getDirectories()

    }

    override fun deleteFolders(folders: ArrayList<File>) {
        val fileDirItems = folders.asSequence().filter { it.isDirectory }.map { FileDirItem(it.absolutePath, it.name, true) }.toMutableList() as ArrayList<FileDirItem>
        when {
            fileDirItems.isEmpty() -> return
            fileDirItems.size == 1 -> {
                try {
                    toast(String.format(getString(R.string.deleting_folder), fileDirItems.first().name))
                } catch (e: Exception) {
                    showErrorToast(e)
                }
            }
            else -> {
                val baseString = if (config.useRecycleBin) R.plurals.moving_items_into_bin else R.plurals.delete_folders
                val deletingItems = resources.getQuantityString(baseString, fileDirItems.size, fileDirItems.size)
                toast(deletingItems)
            }
        }

        val itemsToDelete = ArrayList<FileDirItem>()
        val filter = config.filterMedia
        val showHidden = true
        fileDirItems.filter {
            it.isDirectory
        }.forEach { fileDirItem ->
            if (fileDirItem.path.containsNoMedia()) {
                val files = File(fileDirItem.path).listFiles()
                files?.filter {
                    if (isPhotosSelected) {
                        it.isImageFast()
                    } else {
                        it.isVideoFast()
                    }
                }?.mapTo(itemsToDelete) { it.toFileDirItem(this) }
            } else {
                val files = File(fileDirItem.path).listFiles()
                files?.filter {
                    if (isPhotosSelected) {
                        it.isImageFast() && it.name.startsWith('.')
                    } else {
                        it.isVideoFast() && it.name.startsWith('.')
                    }

                }?.mapTo(itemsToDelete) { it.toFileDirItem(this) }
            }
        }
        val pathsToDelete = ArrayList<String>()
        itemsToDelete.mapTo(pathsToDelete) { it.path }
        Log.d("hfdfadsfdsf", "deleteFolders: " + itemsToDelete.size)
        deleteFilteredFileDirItems(itemsToDelete, folders)
    }

    private fun deleteFilteredFileDirItems(fileDirItems: ArrayList<FileDirItem>, folders: ArrayList<File>) {
        val OTGPath = config.OTGPath
        deleteFiles(fileDirItems) {
            ensureBackgroundThread {
                folders.forEach {
                    updatePhotoVideoDirectoryPath(it.absolutePath, false, true)
                    updatePhotoVideoDirectoryPath(it.absolutePath, true, false)
                }
                folders.filter { !getDoesFilePathExist(it.absolutePath, OTGPath) }.forEach {
                    directoryDao.deleteDirPath(it.absolutePath)
                }
                runOnUiThread {
                    PhotoDirectoryFragment.isNeedToRefresh = true
                    VideoDirectoryFragment.isNeedToRefresh = true
                    if (getRecyclerAdapter() != null) {
                        getRecyclerAdapter()!!.finishActMode()
                        getRecyclerAdapter()!!.dismissProgress()
                    }

                    refreshItems()
                }
                if (config.deleteEmptyFolders) {
                    folders.filter { !it.absolutePath.isDownloadsFolder() && it.isDirectory && it.toFileDirItem(this).getProperFileCount(this, true) == 0 }.forEach {
                        tryDeleteFileDirItem(it.toFileDirItem(this), true, true)
                    }
                }
            }
        }

    }


    override fun recheckPinnedFolders() {

    }

    override fun updateDirectories(directories: ArrayList<Directory>) {

    }

    fun toggleToolbar(isShowActionBar: Boolean) {
        if (isShowActionBar) {
            if (mBinding.etSearch.visibility == View.VISIBLE) {
                hideKeyboard(findViewById<EditText>(R.id.etSearch))
                findViewById<EditText>(R.id.etSearch).clearFocus()
            }
            mBinding.llBottomOption.visibility = View.VISIBLE
            mBinding.tvHideUnHideText.text = resources.getString(R.string.label_unhide_folder, 0)
            mBinding.imgOptHideUnHide.setImageDrawable(resources.getDrawable(R.drawable.ic_option_unhide))
        } else {
            mBinding.llBottomOption.visibility = View.GONE
        }
    }

    fun updateCount(size: Int) {
        mBinding.tvHideUnHideText.text = resources.getString(R.string.label_unhide_folder, size)
    }

    private fun showFABMenu() {
        isFABOpen = true
        if (getRecyclerAdapter() != null) {
            getRecyclerAdapter()!!.finishActMode()

        }
        if (mBinding.etSearch.visibility == VISIBLE) {
            mBinding.imgClose.performClick()
        }
        mBinding.imgAddHiddenPhoto.setImageDrawable(resources.getDrawable(R.drawable.ic_vault_close))
        mBinding.flBackground.beVisible()
        if (isPhotosSelected)
            mBinding.llFromCamera.beVisible()
        else
            mBinding.llFromCamera.beGone()
        mBinding.llFromGallery.beVisible()
        mBinding.llFromFolder.beVisible()
    }

    private fun closeFABMenu() {
        isFABOpen = false
        mBinding.imgAddHiddenPhoto.setImageDrawable(resources.getDrawable(R.drawable.ic_add_hidden_new))
        mBinding.flBackground.beGone()
        mBinding.llFromCamera.beGone()
        mBinding.llFromGallery.beGone()
        mBinding.llFromFolder.beGone()
    }

    override fun fromActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
        super.fromActivityResult(requestCode, resultCode, resultData)
        when (requestCode) {
            REQUEST_CODE_CAMERA -> {
                isUnLockApp = true
                VaultFragment.isTabUnlock = true
                Log.d(TAG, "onActivityResult: $mCurrentPhotoUri")

                if (resultCode == Activity.RESULT_OK) {
                    ensureBackgroundThread {
                        config.hidePhotoCountForSubscription++
                        if (directoryDao.getDirectoryDetailFromDirPath(CAMERA_DIR_PATH) != null) {
                            if (VaultFragment.isFakeVaultOpen) {
                                fakeVaultHiddenDirectoryDao.insert(directoryDao.getDirectoryDetailFromDirPath(CAMERA_DIR_PATH).getConvertedFakeVaultDirectory())
                            } else {
                                hiddenDirectoryDao.insert(directoryDao.getDirectoryDetailFromDirPath(CAMERA_DIR_PATH).getConvertedHiddenDirectory())
                            }
                        } else if (photoDirectoryDao.getDirectoryDetailFromDirPath(CAMERA_DIR_PATH) != null) {
                            if (VaultFragment.isFakeVaultOpen) {
                                fakeVaultHiddenDirectoryDao.insert(photoDirectoryDao.getDirectoryDetailFromDirPath(CAMERA_DIR_PATH).getConvertedFakeVaultDirectory())
                            } else {
                                hiddenDirectoryDao.insert(photoDirectoryDao.getDirectoryDetailFromDirPath(CAMERA_DIR_PATH).getConvertedHiddenDirectory())
                            }
                        } else {
                            updatePhotoVideoDirectoryPath(CAMERA_DIR_PATH, true, false, true)
                        }
                        if (VaultFragment.isFakeVaultOpen) {
                            insertFakeMedia(mCurrentPhotoPath)
                        }
                        runOnUiThread {
                            refreshItems()
                        }
                    }
                }
            }

        }
    }

    private fun hideFiles(selectedList: List<String>, filterType: Int) {
        var prevPath = ""
        var hiddenDirectory = ArrayList<String>()
        selectedList.forEach {
            if (prevPath != it.getParentPath()) {
                hiddenDirectory.add(it.getParentPath())
                prevPath = it.getParentPath()
            }
            val type = when {
                it.isVideoFast() -> TYPE_VIDEOS
                it.isGif() -> TYPE_GIFS
                it.isSvg() -> TYPE_SVGS
                it.isRawFast() -> TYPE_RAWS
                it.isPortrait() -> TYPE_PORTRAITS
                it.isAudioFast() -> TYPE_AUDIO
                it.isDocumentFast() -> TYPE_DOCUMENT
                else -> TYPE_IMAGES
            }
            toggleFileVisibility(it, true) {
                if (type == TYPE_IMAGES || type == TYPE_VIDEOS) {
                    if (VaultFragment.isFakeVaultOpen) {
                        insertFakeMedia(it)
                    }
                }
            }
        }
        if (filterType == CHOOSE_IMAGE_TYPE || filterType == CHOOSE_VIDEO_TYPE) {
            try {
                ensureBackgroundThread {
                    hiddenDirectory.forEach {
                        if (directoryDao.getDirectoryDetailFromDirPath(it) != null) {
                            if (VaultFragment.isFakeVaultOpen) {
                                fakeVaultHiddenDirectoryDao.insert(directoryDao.getDirectoryDetailFromDirPath(it).getConvertedFakeVaultDirectory())
                            } else {
                                hiddenDirectoryDao.insert(directoryDao.getDirectoryDetailFromDirPath(it).getConvertedHiddenDirectory())
                            }
                        } else if (photoDirectoryDao.getDirectoryDetailFromDirPath(it) != null) {
                            if (VaultFragment.isFakeVaultOpen) {
                                fakeVaultHiddenDirectoryDao.insert(photoDirectoryDao.getDirectoryDetailFromDirPath(it).getConvertedFakeVaultDirectory())
                            } else {
                                hiddenDirectoryDao.insert(photoDirectoryDao.getDirectoryDetailFromDirPath(it).getConvertedHiddenDirectory())
                            }
                        } else if (videoDirectoryDao.getDirectoryDetailFromDirPath(it) != null) {
                            if (VaultFragment.isFakeVaultOpen) {
                                fakeVaultHiddenDirectoryDao.insert(videoDirectoryDao.getDirectoryDetailFromDirPath(it).getConvertedFakeVaultDirectory())
                            } else {
                                hiddenDirectoryDao.insert(videoDirectoryDao.getDirectoryDetailFromDirPath(it).getConvertedHiddenDirectory())
                            }
                        } else {
                            if (filterType == CHOOSE_IMAGE_TYPE)
                                updatePhotoVideoDirectoryPath(it, true, false, true)
                            else if (filterType == CHOOSE_VIDEO_TYPE)
                                updatePhotoVideoDirectoryPath(it, false, true, true)
                        }
                        updatePhotoVideoDirectoryPath(it, true, false, false)
                        updatePhotoVideoDirectoryPath(it, false, true, false)

                    }
                }
            } catch (e: Exception) {
            }
        }
        runOnUiThread {
            dismissProgress()
            PhotoDirectoryFragment.isNeedToRefresh = true
            VideoDirectoryFragment.isNeedToRefresh = true
            when (filterType) {
                CHOOSE_IMAGE_TYPE -> toast(getString(R.string.msg_image_hide))
                CHOOSE_VIDEO_TYPE -> toast(getString(R.string.msg_video_hide))
                CHOOSE_AUDIO_TYPE -> toast(getString(R.string.msg_audio_hide))
                CHOOSE_DOCUMENT_TYPE -> toast(getString(R.string.msg_document_hide))
                else -> toast(getString(R.string.msg_hide_media_successfully))
            }
            isInterstitialShown = false
            refreshItems()
        }

    }

    private fun insertFakeMedia(path: String) {
        ensureBackgroundThread {
            val type = when {
                path.isVideoFast() -> TYPE_VIDEOS
                path.isGif() -> TYPE_GIFS
                path.isSvg() -> TYPE_SVGS
                path.isRawFast() -> TYPE_RAWS
                path.isPortrait() -> TYPE_PORTRAITS
                else -> TYPE_IMAGES
            }
            val duration = if (type == TYPE_VIDEOS) getDuration(path) ?: 0 else 0
            val ts = System.currentTimeMillis()
            val medium = FakeVaultMedium(
                null,
                path.getFilenameFromPath(),
                path,
                path.getParentPath(),
                ts,
                ts,
                File(path).length(),
                type,
                duration,
                false,
                0
            )
            fakeVaultMediumDao.insert(medium)
        }
    }

    override fun onBackPressed() {
        when {
            isFABOpen -> {
                closeFABMenu()
            }
            else -> {
                super.onBackPressed()
            }
        }

    }
}