package com.gallery.photo.image.video.Camera.preview;

import android.media.CamcorderProfile;
import android.media.MediaRecorder;
import android.util.Log;

public class VideoProfile {
    private static final String TAG = "VideoProfile";
    public int audioBitRate;
    public int audioChannels;
    public int audioCodec;
    public int audioSampleRate;
    public int audioSource;
    public String fileExtension;
    public int fileFormat;
    public boolean no_audio_permission;
    public boolean record_audio;
    public int videoBitRate;
    public double videoCaptureRate;
    public int videoCodec;
    public int videoFrameHeight;
    public int videoFrameRate;
    public int videoFrameWidth;
    public int videoSource;

    VideoProfile() {
        this.fileExtension = "mp4";
    }

    VideoProfile(CamcorderProfile camcorderProfile) {
        this.fileExtension = "mp4";
        this.record_audio = true;
        this.no_audio_permission = false;
        this.audioSource = 5;
        this.audioCodec = camcorderProfile.audioCodec;
        this.audioChannels = camcorderProfile.audioChannels;
        this.audioBitRate = camcorderProfile.audioBitRate;
        this.audioSampleRate = camcorderProfile.audioSampleRate;
        this.fileFormat = camcorderProfile.fileFormat;
        this.videoSource = 1;
        this.videoCodec = camcorderProfile.videoCodec;
        this.videoFrameRate = camcorderProfile.videoFrameRate;
        this.videoCaptureRate = (double) camcorderProfile.videoFrameRate;
        this.videoBitRate = camcorderProfile.videoBitRate;
        this.videoFrameHeight = camcorderProfile.videoFrameHeight;
        this.videoFrameWidth = camcorderProfile.videoFrameWidth;
    }

    public String toString() {
        return "\nAudioSource:        " + this.audioSource + "\nVideoSource:        " + this.videoSource + "\nFileFormat:         " + this.fileFormat + "\nFileExtension:         " + this.fileExtension + "\nAudioCodec:         " + this.audioCodec + "\nAudioChannels:      " + this.audioChannels + "\nAudioBitrate:       " + this.audioBitRate + "\nAudioSampleRate:    " + this.audioSampleRate + "\nVideoCodec:         " + this.videoCodec + "\nVideoFrameRate:     " + this.videoFrameRate + "\nVideoCaptureRate:   " + this.videoCaptureRate + "\nVideoBitRate:       " + this.videoBitRate + "\nVideoWidth:         " + this.videoFrameWidth + "\nVideoHeight:        " + this.videoFrameHeight;
    }

    public void copyToMediaRecorder(MediaRecorder mediaRecorder) {
        Log.d(TAG, "copyToMediaRecorder: " + mediaRecorder);
        if (this.record_audio) {
            Log.d(TAG, "record audio");
            mediaRecorder.setAudioSource(this.audioSource);
        }
        mediaRecorder.setVideoSource(this.videoSource);
        mediaRecorder.setOutputFormat(this.fileFormat);
        mediaRecorder.setVideoFrameRate(this.videoFrameRate);
        if (this.videoCaptureRate != ((double) this.videoFrameRate)) {
            Log.d(TAG, "set capture rate");
            mediaRecorder.setCaptureRate(this.videoCaptureRate);
        }
        mediaRecorder.setVideoSize(this.videoFrameWidth, this.videoFrameHeight);
        mediaRecorder.setVideoEncodingBitRate(this.videoBitRate);
        mediaRecorder.setVideoEncoder(this.videoCodec);
        if (this.record_audio) {
            mediaRecorder.setAudioEncodingBitRate(this.audioBitRate);
            mediaRecorder.setAudioChannels(this.audioChannels);
            mediaRecorder.setAudioSamplingRate(this.audioSampleRate);
            mediaRecorder.setAudioEncoder(this.audioCodec);
        }
        Log.d(TAG, "done: " + mediaRecorder);
    }
}
