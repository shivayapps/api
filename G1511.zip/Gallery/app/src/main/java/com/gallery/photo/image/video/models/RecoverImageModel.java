package com.gallery.photo.image.video.models;

import java.util.ArrayList;
import java.util.Date;

public final class RecoverImageModel {


    public String getPath() {
        return Path;
    }

    public void setPath(String path) {
        Path = path;
    }

    public String Path;

    public Date getDate() {
        return Date;
    }

    public void setDate(Date date) {
        Date = date;
    }

    public Date Date;
    public ArrayList<String> datWise;


    public boolean isSelected = false;

    public RecoverImageModel(String str, Date date) {
        this.Path = str;
        this.Date = date;
    }
}
