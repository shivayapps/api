package com.gallery.photo.image.video.lock.interfaces;


import com.gallery.photo.image.video.lock.enums.KeyboardButtonEnum;

public interface KeyboardButtonClickedListener {


    public void onKeyboardClick(KeyboardButtonEnum keyboardButtonEnum);


    public void onRippleAnimationEnd();

}
