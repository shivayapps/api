package com.gallery.photo.image.video.Camera.preview.camerasurface;

import android.content.Context;
import android.graphics.Matrix;
import android.media.MediaRecorder;
import android.util.Log;
import android.view.MotionEvent;
import android.view.TextureView;
import android.view.View;

import com.gallery.photo.image.video.Camera.cameracontroller.CameraController;
import com.gallery.photo.image.video.Camera.cameracontroller.CameraControllerException;
import com.gallery.photo.image.video.Camera.preview.Preview;


public class MyTextureView extends TextureView implements CameraSurface {
    private static final String TAG = "MyTextureView";
    private final int[] measure_spec = new int[2];
    private final Preview preview;

    public View getView() {
        return this;
    }

    public void onPause() {
    }

    public void onResume() {
    }

    public void setVideoRecorder(MediaRecorder mediaRecorder) {
    }

    public MyTextureView(Context context, Preview preview2) {
        super(context);
        this.preview = preview2;
        Log.d(TAG, "new MyTextureView");
        setSurfaceTextureListener(preview2);
    }

    public void setPreviewDisplay(CameraController cameraController) {
        Log.d(TAG, "setPreviewDisplay");
        try {
            cameraController.setPreviewTexture(this);
        } catch (CameraControllerException e) {
            Log.e(TAG, "Failed to set preview display: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        return this.preview.touchEvent(motionEvent);
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        Log.d(TAG, "onMeasure: " + i + " x " + i2);
        this.preview.getMeasureSpec(this.measure_spec, i, i2);
        int[] iArr = this.measure_spec;
        super.onMeasure(iArr[0], iArr[1]);
    }

    public void setTransform(Matrix matrix) {
        super.setTransform(matrix);
    }
}
