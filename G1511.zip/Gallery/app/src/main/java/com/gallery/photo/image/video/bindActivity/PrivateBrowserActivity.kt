package com.gallery.photo.image.video.bindActivity

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.util.Log
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.view.GravityCompat
import androidx.recyclerview.widget.DividerItemDecoration
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.adapter.BookmarkAdapter
import com.gallery.photo.image.video.databinding.ActivityPrivateBrowserBinding
import com.gallery.photo.image.video.extensions.config
import com.gallery.photo.image.video.extensions.inflater
import com.gallery.photo.image.video.fragment.VaultFragment
import com.gallery.photo.image.video.interfaces.onBookmarkClick
import com.gallery.photo.image.video.models.BrowserBookmark
import com.gallery.photo.image.video.extensions.hideKeyboard
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class PrivateBrowserActivity : BaseBindingActivity<ActivityPrivateBrowserBinding>() {
    var current_page_url = "https://www.google.com/"

    companion object {
        fun newIntent(mContext: Context): Intent {
            return Intent(mContext, PrivateBrowserActivity::class.java)
        }
    }

    override fun getContext(): Activity {
        return this
    }

    override fun initData() {
        initWebView()
        hideKeyboard()
        mBinding.etSearch.clearFocus()
        mBinding.browserWebview.loadUrl(current_page_url)
        mBinding.browserRvBookmark.addItemDecoration(
            DividerItemDecoration(
                mBinding.browserRvBookmark.context,
                DividerItemDecoration.VERTICAL
            )
        )
    }

    override fun initActions() {
        mBinding.imgBack.setOnClickListener(this)
        mBinding.imgBookMark.setOnClickListener(this)
        mBinding.imgBookMarkList.setOnClickListener(this)
        mBinding.etSearch.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                val url = "https://www.google.com/search?q=" + mBinding.etSearch.text.toString()
                mBinding.browserWebview!!.loadUrl(url)
                Log.e(
                    TAG,
                    "web view Version ==== > initActions: ${mBinding.browserWebview.settings.userAgentString}"
                )
                hideKeyboard(mBinding.etSearch)
            }
            false
        }
        mBinding.etSearch.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                if (mBinding.browserDraweLayout.isDrawerOpen(GravityCompat.END)) {
                    mBinding.browserDraweLayout.closeDrawer(GravityCompat.END)
                }
            }
        }
    }

    override fun onClick(view: View) {
        super.onClick(view)
        when (view.id) {
            R.id.imgBack -> {
                if (mBinding.browserDraweLayout.isDrawerOpen(GravityCompat.END)) {
                    mBinding.browserDraweLayout.closeDrawer(GravityCompat.END)
                    return
                }
                if (mBinding.browserWebview.canGoBack()) {
                    mBinding.browserWebview.goBack()
                } else {
                    super.onBackPressed()
                }
            }
            R.id.imgBookMark -> {
                addRemoveBookmark()
            }
            R.id.imgBookMarkList -> {
                setUpBookmark()
                openCloseDrawer()
            }
        }
    }

    private fun openCloseDrawer() {
        if (mBinding.browserDraweLayout.isDrawerOpen(GravityCompat.END)) {
            mBinding.browserDraweLayout.closeDrawer(
                GravityCompat.END
            )
        } else {
            hideKeyboard(mBinding.etSearch)
            mBinding.etSearch.clearFocus()
            mBinding.browserDraweLayout.openDrawer(GravityCompat.END)
        }

    }

    private fun setUpBookmark() {
        val bookmarks = bookmarks
        if (bookmarks.isEmpty()) {
            mBinding.browserPvEmpty.visibility = View.VISIBLE
            mBinding.browserRvBookmark.visibility = View.GONE
        } else {
            mBinding.browserPvEmpty.visibility = View.GONE
            mBinding.browserRvBookmark.visibility = View.VISIBLE
            val recyclerAdapter = BookmarkAdapter(this, bookmarks, object : onBookmarkClick {
                override fun onLinkClick(link: String) {
                    mBinding.browserWebview.loadUrl(link)
                    mContext.hideKeyboard(mBinding.etSearch)
                    openCloseDrawer()
                }
            })
            mBinding.browserRvBookmark.adapter = recyclerAdapter
        }

    }

    override fun setBinding(): ActivityPrivateBrowserBinding {
        return ActivityPrivateBrowserBinding.inflate(inflater)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun initWebView() {
        mBinding.browserWebview.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                mBinding.lottieProgressbar.visibility = View.VISIBLE
                current_page_url = url
                manageBookmarkIcon()
                mBinding.etSearch.setText(current_page_url)
            }

            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                view.loadUrl(url)
                Log.e(
                    TAG,
                    "web view Version ==== > initActions: ${mBinding.browserWebview.settings.userAgentString}"
                )
                return true
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    view.loadUrl(request.url.toString())
                }
                return true
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                mBinding.lottieProgressbar.visibility = View.GONE
                manageBookmarkIcon()
                mBinding.etSearch.setText(current_page_url)
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: WebResourceError
            ) {
                super.onReceivedError(view, request, error)
                mBinding.lottieProgressbar.visibility = View.GONE
                manageBookmarkIcon()
                mBinding.etSearch.setText(current_page_url)
            }
        }
        mBinding.browserWebview.settings.loadWithOverviewMode = true
        mBinding.browserWebview.settings.useWideViewPort = true
        mBinding.browserWebview.clearCache(true)
        mBinding.browserWebview.clearHistory()
        mBinding.browserWebview.settings.javaScriptEnabled = true
        mBinding.browserWebview.isHorizontalScrollBarEnabled = true
    }


    private fun manageBookmarkIcon() {
        if (isBookmarked) {
            mBinding.imgBookMark.setImageResource(R.drawable.ic_browser_bookmark_fill)
        } else {
            mBinding.imgBookMark.setImageResource(R.drawable.ic_browser_bookmark)
        }
    }

    private fun addRemoveBookmark() {
        val message: String = if (isBookmarked) {
            removeBookmark()
            "Bookmark Removed"
        } else {
            addBookmark()
            "Bookmarked"
        }
//        val snackbar = Snackbar.make(browser_container!!, message, Snackbar.LENGTH_LONG)
//        snackbar.show()
        manageBookmarkIcon()

    }

    private fun addBookmark() {
        val bookmarks = bookmarks
        var title = mBinding.browserWebview.title!!.trim { it <= ' ' }
        if (title.isEmpty()) {
            title = "Unknown"
        }
        val bookmark = BrowserBookmark(title, current_page_url)
        bookmarks.add(0,bookmark)
        val gson = Gson()
        val json = gson.toJson(bookmarks)
        if (VaultFragment.isFakeVaultOpen) {
            config.bookMarkListFakeVault = json
        } else
            config.bookMarkList = json
    }

    private fun removeBookmark() {
        try {
            val bookmarks = bookmarks
            if (bookmarks.isEmpty()) {
                return
            }
            val update: ArrayList<BrowserBookmark> = ArrayList()
            for (bMark in bookmarks) {
                if (!bMark.link.equals(current_page_url, ignoreCase = true)) {
                    update.add(bMark)
                }
            }
            val gson = Gson()
            val json = gson.toJson(update)
            if (VaultFragment.isFakeVaultOpen) {
                config.bookMarkListFakeVault = json
            } else
                config.bookMarkList = json
        } catch (e: Exception) {
            Log.i(TAG, "addRemoveBookmark: $e")
        }

    }

    private val bookmarks: ArrayList<BrowserBookmark>
        get() {
            val gson = Gson()
            val json = if (VaultFragment.isFakeVaultOpen) config.bookMarkListFakeVault else config.bookMarkList
            return if (json != null && json != "") {
                val type = object : TypeToken<ArrayList<BrowserBookmark?>?>() {}.type
                gson.fromJson(json, type)
            } else {
                ArrayList()
            }
        }

    private val isBookmarked: Boolean
        get() {
            val bookmarks = bookmarks
            if (bookmarks.isEmpty()) {
                return false
            }
            for (i in bookmarks.indices) {
                if (bookmarks[i].link.equals(current_page_url, ignoreCase = true)) {
                    return true
                }
            }
            return false
        }

    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }
}