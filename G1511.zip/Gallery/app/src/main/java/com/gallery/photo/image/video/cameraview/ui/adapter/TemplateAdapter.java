package com.gallery.photo.image.video.cameraview.ui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;


import com.gallery.photo.image.video.R;
import com.gallery.photo.image.video.cameraview.ui.interfaces.OnRecyclerItemClickListener;
import com.gallery.photo.image.video.cameraview.ui.model.TemplateModel;


import java.util.List;


public class TemplateAdapter extends RecyclerView.Adapter<TemplateAdapter.Holder> {
    Context mContext;
    List<TemplateModel> mList;
    OnRecyclerItemClickListener mOnRecyclerItemClickListener;

    public void refreshAdapter(List<TemplateModel> list) {
    }

    public TemplateAdapter(Context context, List<TemplateModel> list, OnRecyclerItemClickListener onRecyclerItemClickListener) {
        this.mContext = context;
        this.mList = list;
        this.mOnRecyclerItemClickListener = onRecyclerItemClickListener;
    }

    public Holder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Holder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cell_template, viewGroup, false));
    }

    public void onBindViewHolder(Holder holder, int i) {
        holder.tv_temp_date.setText(mList.get(i).getTitle());
        holder.chk_template.setSelected(mList.get(i).isSelected());
    }

    public int getItemCount() {
        return this.mList.size();
    }

    public class Holder extends RecyclerView.ViewHolder {
        ImageView chk_template;
        RelativeLayout temp_main_lay;
        TextView tv_temp_date;

        public Holder(View view) {
            super(view);
            chk_template = view.findViewById(R.id.chk_template);
            tv_temp_date = (TextView) view.findViewById(R.id.tv_temp_date);
            RelativeLayout linearLayout = (RelativeLayout) view.findViewById(R.id.temp_main_lay);
            temp_main_lay = linearLayout;

            linearLayout.setOnClickListener(view1 -> {
                if (getAdapterPosition() >= 0) {

//                    if (chk_template.isSelected()) {
//
//                        SharedPrefs.savePref(mContext, mList.get(getAdapterPosition()).getSpKey(), false);
//
//                        boolean isAddr = SharedPrefs.getBoolean(mContext, mList.get(0).getSpKey(), AppConstant.IS_ADDRESS);
//                        boolean isStreetAddr = SharedPrefs.getBoolean(mContext, mList.get(1).getSpKey(), AppConstant.IS_STREET_ADDRESS_TEMPLATE);
//                        boolean isDateTime = SharedPrefs.getBoolean(mContext, mList.get(2).getSpKey(), AppConstant.IS_DATE_TIME);
//                        if (!isAddr && !isStreetAddr && !isDateTime) {
//                            SharedPrefs.savePref(mContext, mList.get(getAdapterPosition()).getSpKey(), true);
//                            chk_template.setSelected(true);
//                            Toast.makeText(mContext, mContext.getResources().getString(R.string.please_select_at_least_one_record), Toast.LENGTH_SHORT).show();
//                        } else {
//                            chk_template.setSelected(false);
//                        }
//
//                    } else {
//                        chk_template.setSelected(true);
//                        SharedPrefs.savePref(mContext, mList.get(getAdapterPosition()).getSpKey(), true);
//                    }
                    if (mOnRecyclerItemClickListener != null) {
                        mOnRecyclerItemClickListener.OnClick_(getAdapterPosition(), view1);
                    }
                }
            });
        }
    }
}
