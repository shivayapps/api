package com.gallery.photo.image.video.bindActivity

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Resources
import android.net.Uri
import android.os.SystemClock
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.util.TypedValue
import android.view.View
import android.view.View.VISIBLE
import android.view.ViewTreeObserver
import android.widget.EditText
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.RecyclerView
import com.example.app.ads.helper.GiftIconHelper
import com.example.app.ads.helper.InterstitialAdHelper
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.gallery.MimeType
import com.example.gallery.internal.entity.SelectionSpec
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.*
import com.gallery.photo.image.video.adapter.DirectoryAdapter
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.utilities.addEvent

import com.gallery.photo.image.video.databinding.ActivityHiddenImagesBinding
import com.gallery.photo.image.video.dialog.SubscriptionDialog
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.fragment.PhotoDirectoryFragment
import com.gallery.photo.image.video.fragment.VaultFragment
import com.gallery.photo.image.video.fragment.VideoDirectoryFragment
import com.gallery.photo.image.video.interfaces.DirectoryOperationsListener
import com.gallery.photo.image.video.models.Directory
import com.gallery.photo.image.video.models.FakeVaultMedium
import com.gallery.photo.image.video.models.Medium
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.vaultgallery.model.KEY_MEDIA_LIST
import com.gallery.photo.image.video.vaultgallery.model.KEY_MEDIA_TYPE
import com.gallery.photo.image.video.vaultgallery.ui.REQUEST_SELECT_MEDIA
import com.gallery.photo.image.video.helpers.*
import com.gallery.photo.image.video.models.FileDirItem
import com.gallery.photo.image.video.views.MyGridLayoutManager
import com.gallery.photo.image.video.views.MyRecyclerView
import java.io.File
import java.util.*
import kotlin.collections.ArrayList
import kotlin.math.roundToInt

class HiddenImagesActivity : BaseBindingActivity<ActivityHiddenImagesBinding>(), DirectoryOperationsListener {

    var title: String? = null
    private val PICK_MEDIA = 2
    private val PICK_WALLPAPER = 3


    private var mIsPickImageIntent = true
    private var mIsPickVideoIntent = false
    private var mIsGetImageContentIntent = false
    private var mIsGetVideoContentIntent = false
    private var mIsGetAnyContentIntent = false
    private var mIsSetWallpaperIntent = false
    private var mAllowPickingMultiple = false

    private var mLoadedInitialPhotos = false
    private var mShouldStopFetching = false
    private var mIsSearchOpen = false
    private var mCurrentPathPrefix = ""                 // used at "Group direct subfolders" for navigation
    private var mOpenedSubfolders = arrayListOf("")     // used at "Group direct subfolders" for navigating Up with the back button
    private var mDateFormat = ""
    private var mTimeFormat = ""
    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mLastMediaFetcher: MediaFetcher? = null
    public var mDirs = ArrayList<Directory>()
    var mIsGettingDirs = false
    var isFABOpen = false
    var isPhotosSelected = true

    var mCurrentPhotoUri: Uri? = null
    var mCurrentPhotoPath: String = ""

    companion object {
        fun newIntent(mContext: Context, isPickImage: Boolean = false, isPickVideo: Boolean = false): Intent {
            var intent = Intent(mContext, HiddenImagesActivity::class.java)
            intent.putExtra(GET_IMAGE_INTENT, isPickImage)
            intent.putExtra(GET_VIDEO_INTENT, isPickVideo)

            return intent
        }

        var isNeedToRefresh = false

    }

    override fun getAppIconIDs() = arrayListOf(
        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName() = getString(R.string.app_name)

    override fun setBinding(): ActivityHiddenImagesBinding {
        return ActivityHiddenImagesBinding.inflate(layoutInflater)
    }

    override fun getContext(): Activity {
        return this
    }

    override fun initData() {
        intent.apply {
            mIsPickImageIntent = getBooleanExtra(GET_IMAGE_INTENT, false)
            mIsPickVideoIntent = getBooleanExtra(GET_VIDEO_INTENT, false)
        }
        if (mIsPickImageIntent) {
            isPhotosSelected = true
            mBinding.tvTitle.text = getString(R.string.label_photos)
            mBinding.directoriesClickHereToAdd.text = getString(R.string.msg_click_here_to_hide_photos)
            mBinding.etSearch.hint = getString(R.string.msg_search_photo_by_name)
            mBinding.tvGallery.text = getString(R.string.label_photos)
            mBinding.fabAddHiddenPhotoFromGallery.setImageDrawable(getDrawable(R.drawable.ic_vault_add_gallery))
        } else {
            addEvent("HiddenVideoActivity")
            isPhotosSelected = false
            mBinding.tvTitle.text = getString(R.string.label_videos)
            mBinding.directoriesClickHereToAdd.text = getString(R.string.msg_click_here_to_hide_videos)
            mBinding.etSearch.hint = getString(R.string.msg_search_video_by_name)
            mBinding.tvGallery.text = getString(R.string.label_videos)
            mBinding.fabAddHiddenPhotoFromGallery.setImageDrawable(getDrawable(R.drawable.ic_vault_video))
        }

        mBinding.directoriesRefreshLayout.setOnRefreshListener { getDirectories() }
        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            InterstitialAdHelper.loadInterstitialAd(fContext = this)
            GiftIconHelper.loadGiftAd(
                fContext = this,
                fivGiftIcon = mBinding.giftLayout.giftAdIcon,
                fivBlastIcon = mBinding.giftLayout.giftBlastAdIcon
            )
        }
        if (mBinding.imgAddHiddenPhoto.isVisible()) {
            try {
                mBinding.imgAddHiddenPhoto.viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
                    override fun onGlobalLayout() {
                        mBinding.imgAddHiddenPhoto.viewTreeObserver.removeOnGlobalLayoutListener(this)
                        val r: Resources = resources
                        var dimen = r.getDimension(R.dimen._7sdp)
                        val px = TypedValue.applyDimension(
                            TypedValue.COMPLEX_UNIT_DIP, dimen, r.displayMetrics
                        ).roundToInt()
                        mBinding.directoriesGrid.setPadding(3, 3, 3, mBinding.imgAddHiddenPhoto.height + px)
                    }

                })
            } catch (e: Exception) {
                val r: Resources = resources
                var dimen = r.getDimension(R.dimen._25sdp)
                val px = TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_DIP, dimen, r.displayMetrics
                ).roundToInt()
                mBinding.directoriesGrid.setPadding(3, 3, 3, px)
            }

        }
        getDirectories()
    }

    override fun initActions() {
        setupSearch()
        mBinding.imgBack.setOnClickListener(this)
        mBinding.imgSearch.setOnClickListener(this)
        mBinding.imgClose.setOnClickListener(this)
        mBinding.llHideOpt.setOnClickListener(this)
        mBinding.rlAddHiddenPhotoVideo.setOnClickListener(this)
        mBinding.flBackground.setOnClickListener(this)
        mBinding.imgAddHiddenPhoto.setOnClickListener(this)
        mBinding.fabAddHiddenPhotoFromCamera.setOnClickListener(this)
        mBinding.fabAddHiddenPhotoFromGallery.setOnClickListener(this)
        mBinding.fabAddHiddenPhotoFromFolder.setOnClickListener(this)
    }

    private fun setupSearch() {

        mBinding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                setupAdapter(mDirs, s.toString())
            }

            override fun afterTextChanged(s: Editable?) {

            }

        })
    }

    var isNeedtoShowAdAfterCameraCapture = true

    override fun onClick(view: View) {
        super.onClick(view)
        when (view.id) {
            R.id.imgBack -> {
                onBackPressed()
            }
            R.id.imgSearch -> {
                mBinding.etSearch.visibility = View.VISIBLE
                mBinding.imgClose.visibility = View.VISIBLE
                mBinding.tvTitle.visibility = View.GONE
                mBinding.imgSearch.visibility = View.GONE
                mBinding.imgOptions.visibility = View.GONE
                showKeyboard(mBinding.etSearch)
            }
            R.id.imgClose -> {
                mBinding.etSearch.text = null
                mBinding.etSearch.visibility = View.GONE
                mBinding.imgClose.visibility = View.GONE
                mBinding.tvTitle.visibility = View.VISIBLE
                mBinding.imgSearch.visibility = View.VISIBLE
                mBinding.imgOptions.visibility = View.VISIBLE
                setupAdapter(mDirs, "")
                hideKeyboard(mBinding.etSearch)
            }
            R.id.llHideOpt -> {
                if (getRecyclerAdapter() != null) {
                    getRecyclerAdapter()!!.toggleFoldersVisibility(false)
                }
            }
            R.id.imgAddHiddenPhoto -> {
                if (isPhotosSelected)
                    addEvent(plusButtonImage)
                else
                    addEvent(plusButtonVideo)
                if (config.isAnyOperationRunning) {
                    toast(getString(R.string.msg_operation_already_running))
                    return
                }
//                if (AdsManager(this).isNeedToShowAds() && (config.hidePhotoCountForSubscription >= HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION_VAL
//                            && config.hideVideoCountForSubscription >= HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION_VAL)
//                ) {
//                    SubscriptionDialog(this)
//                    {
//                        var intent = Intent(this, SubscriptionActivity::class.java)
//                        launchActivityForResult(intent, REQUEST_CODE_FOR_SUBSCRIPTION)
//                    }
//
//                } else {
                if (!isFABOpen) {
                    showFABMenu()
                } else {
                    closeFABMenu()
                }
//                }
            }
            R.id.flBackground -> {
                closeFABMenu()
            }
            R.id.fabAddHiddenPhotoFromCamera -> {
                closeFABMenu()
                isUnLockApp = true
                VaultFragment.isTabUnlock = true
                handlePermission(PERMISSION_CAMERA) {
                    isUnLockApp = true
                    VaultFragment.isTabUnlock = true
                    if (it) {
                        var totalImagesCount = config.hidePhotoCountForSubscription
                        var totalVideosCount = config.hideVideoCountForSubscription
                        totalImagesCount++
                        if (AdsManager(this).isNeedToShowAds() && (totalImagesCount > HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION_VAL)
                        ) {
                            Log.d("TAGHiddenCount", "Need Subscription")
                            runOnUiThread {
                                dismissProgress()
                                SubscriptionDialog(this, totalImagesCount, totalVideosCount)
                                {
                                    if (it) {
                                        var intent = Intent(this, SubscriptionActivity::class.java)
                                        launchActivityForResult(intent, REQUEST_CODE_FOR_SUBSCRIPTION)
                                    } else {
                                        isNeedtoShowAdAfterCameraCapture = false
                                        var root = File(CAMERA_DIR_PATH)
                                        if (!root.exists())
                                            root.mkdir()
                                        mCurrentPhotoPath = CAMERA_DIR_PATH + "/." + System.currentTimeMillis() + ".jpeg"
                                        var file = File(mCurrentPhotoPath)
                                        mCurrentPhotoUri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
                                        isUnLockApp = true
                                        VaultFragment.isTabUnlock = true
                                        val captureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                                        captureIntent.putExtra(MediaStore.EXTRA_OUTPUT, mCurrentPhotoUri)
                                        launchActivityForResult(captureIntent, REQUEST_CODE_CAMERA)
                                    }
                                }
                            }
                        } else {

                            var root = File(CAMERA_DIR_PATH)
                            if (!root.exists())
                                root.mkdir()
                            mCurrentPhotoPath = CAMERA_DIR_PATH + "/." + System.currentTimeMillis() + ".jpeg"
                            var file = File(mCurrentPhotoPath)
                            mCurrentPhotoUri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
                            isUnLockApp = true
                            VaultFragment.isTabUnlock = true
                            val captureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                            captureIntent.putExtra(MediaStore.EXTRA_OUTPUT, mCurrentPhotoUri)
                            launchActivityForResult(captureIntent, REQUEST_CODE_CAMERA)
                        }
                    } else {
                        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {
                            isUnLockApp = true
                            VaultFragment.isTabUnlock = true
                            mBinding.fabAddHiddenPhotoFromCamera.performClick()
                        } else {
                            showCameraPermissionAlert()
                        }
                    }
                }
            }
            R.id.rlAddHiddenPhotoVideo, R.id.fabAddHiddenPhotoFromGallery -> {
                closeFABMenu()
                if (isPhotosSelected)
                    addEvent(imagePickerClick)
                else
                    addEvent(videoPickerClick)
                var mSelectionSpec = SelectionSpec.getCleanInstance()
                var type = if (isPhotosSelected) {
                    mSelectionSpec.mimeTypeSet = MimeType.ofImage()
                    CHOOSE_IMAGE_TYPE
                } else {
                    mSelectionSpec.mimeTypeSet = MimeType.ofVideo()
                    CHOOSE_VIDEO_TYPE
                }
                mSelectionSpec.mediaTypeExclusive = true
                mSelectionSpec.maxSelectable = 5
                mSelectionSpec.noLimit = true
                mSelectionSpec.showPreview = false
                mSelectionSpec.showSingleMediaType = true
                mSelectionSpec.orientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                launchActivityForResult(VaultGalleryActivity.newIntent(this, type), REQUEST_SELECT_MEDIA)
            }
            R.id.fabAddHiddenPhotoFromFolder -> {
                closeFABMenu()
                if (isPhotosSelected)
                    addEvent(fromFolderClickImage)
                else
                    addEvent(fromFolderClickVideo)
                var type = if (isPhotosSelected)
                    CHOOSE_IMAGE_TYPE
                else
                    CHOOSE_VIDEO_TYPE
                startActivity(CustomFilePickerActivity.newIntent(this, type))
            }

        }
    }


    override fun onResume() {
        super.onResume()
        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            mBinding.giftLayout.clGiftIcon.beVisible()
        } else {
            mBinding.giftLayout.clGiftIcon.beGone()
        }
        if (isFromSettingForCamera) {
            isFromSettingForCamera = false
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
            ) {
                mBinding.fabAddHiddenPhotoFromCamera.performClick()
            }
        }
        if (isNeedToRefresh) {
            isNeedToRefresh = false
            refreshItems()
        }
    }

    private fun getDirectories() {


        Log.d("Tag Get Directory ", mIsGettingDirs.toString())
        if (mIsGettingDirs) {
            return
        }
        mShouldStopFetching = true
        mIsGettingDirs = true
        mBinding.llProgress.visibility = View.VISIBLE


        if (getRecyclerAdapter() != null) {
            getRecyclerAdapter()!!.dismissProgress()
            getRecyclerAdapter()!!.finishActMode()
        }

        if (VaultFragment.isFakeVaultOpen) {
            getCachedFakeVaultDirectories(forceShowHidden = true) {
                gotDirectories(addTempFolderIfNeeded(it), true)
            }
        } else {

            getCachedHiddenDirectories(false, false, forceShowHidden = true) {
                gotDirectories(addTempFolderIfNeeded(it), false)
            }

        }


    }

    fun getRecyclerAdapter() = mBinding.directoriesGrid.adapter as? DirectoryAdapter

    private fun gotDirectories(newDirs: ArrayList<Directory>, isFakeVault: Boolean) {
        mIsGettingDirs = false
        mShouldStopFetching = false
        setupLayoutManager()
        // if hidden item showing is disabled but all Favorite items are hidden, hide the Favorites folder
        if (!config.shouldShowHidden) {
            val favoritesFolder = newDirs.firstOrNull { it.areFavorites() }
            if (favoritesFolder != null && favoritesFolder.tmb.getFilenameFromPath().startsWith('.')) {
                newDirs.remove(favoritesFolder)
            }
        }

        val dirs = getSortedDirectories(newDirs)

        runOnUiThread {
            checkPlaceholderVisibility(dirs)
        }

        // cached folders have been loaded, recheck folders one by one starting with the first displayed
        mLastMediaFetcher?.shouldStop = true
        mLastMediaFetcher = MediaFetcher(this)
        val getImagesOnly = mIsPickImageIntent || mIsGetImageContentIntent
        val getVideosOnly = mIsPickVideoIntent || mIsGetVideoContentIntent
        val hiddenString = getString(R.string.hidden)
        val getProperFileSize = config.directorySorting and SORT_BY_SIZE != 0
        val favoritePaths = ArrayList<String>()
        val lastModifieds = mLastMediaFetcher!!.getLastModifieds()
        val dateTakens = mLastMediaFetcher!!.getDateTakens()


        var HiddenDirList = ArrayList<Directory>()
        var dirsNew = dirs.toMutableList()
        Log.d("TagHidden ", "Add n111" + dirsNew.size)

        for (directory in dirsNew) {
            Log.d("TagHidden ", "Add n111" + directory.mediaCnt)
            val sorting = config.getFolderSorting(directory.path)
            val grouping = config.getFolderGrouping(directory.path)
            val getProperDateTaken = config.directorySorting and SORT_BY_DATE_TAKEN != 0 ||
                    sorting and SORT_BY_DATE_TAKEN != 0 ||
                    grouping and GROUP_BY_DATE_TAKEN_DAILY != 0 ||
                    grouping and GROUP_BY_DATE_TAKEN_MONTHLY != 0

            val getProperLastModified = config.directorySorting and SORT_BY_DATE_MODIFIED != 0 ||
                    sorting and SORT_BY_DATE_MODIFIED != 0 ||
                    grouping and GROUP_BY_LAST_MODIFIED_DAILY != 0 ||
                    grouping and GROUP_BY_LAST_MODIFIED_MONTHLY != 0
            if (directory.name.contains(hiddenString) || directory.path.containsNoMedia()) {
                Log.d("TagHidden ", "Add n111")

                var curMedia = if (isFakeVault) {
                    var type = if (isPhotosSelected)
                        TYPE_IMAGES
                    else
                        TYPE_VIDEOS
                    var gif = fakeVaultMediumDao.getTypeMediaFromPath(directory.path, TYPE_GIFS)
                    var images = fakeVaultMediumDao.getTypeMediaFromPath(directory.path, type) as java.util.ArrayList<Medium>
                    var media = images
                    if (isPhotosSelected)
                        media.addAll(gif)
                    media
                } else {
                    var media = mLastMediaFetcher!!.getFilesFrom(
                        directory.path, getImagesOnly, getVideosOnly, getProperDateTaken, getProperLastModified,
                        getProperFileSize, favoritePaths, false, true, lastModifieds, dateTakens
                    )
                    var fakeMedia = fakeVaultMediumDao.getMediaFromPath(directory.path)
                    val firstListObjectIds = fakeMedia.map { it.path }.toSet()

                    if (isPhotosSelected) {
                        media.filter {
                            !firstListObjectIds.contains(it.path)
                        } as java.util.ArrayList<Medium>
                    } else {
                        media.filter {
                            !firstListObjectIds.contains(it.path) && it.type != TYPE_GIFS
                        } as java.util.ArrayList<Medium>
                    }
                }

                if (curMedia.size > 0) {
                    directory.mediaCnt = curMedia.size
                    directory.tmb = curMedia[0].path
                    HiddenDirList.add(directory)
                }
            } else {
                var curMedia = if (isFakeVault) {
                    var type = if (isPhotosSelected)
                        TYPE_IMAGES
                    else
                        TYPE_VIDEOS
                    var gif = fakeVaultMediumDao.getTypeMediaFromPath(directory.path, TYPE_GIFS)
                    var images = fakeVaultMediumDao.getTypeMediaFromPath(directory.path, type) as java.util.ArrayList<Medium>
                    var media = images
                    if (isPhotosSelected)
                        media.addAll(gif)
                    media.mapNotNull { it as? Medium }.filter { getDoesFilePathExist(it.path) }
                } else {
                    var media = mLastMediaFetcher!!.getFilesFrom(
                        directory.path, getImagesOnly, getVideosOnly, getProperDateTaken, getProperLastModified,
                        getProperFileSize, favoritePaths, false, true, lastModifieds, dateTakens
                    )

                    var fakeMedia = fakeVaultMediumDao.getMediaFromPath(directory.path)
                    val firstListObjectIds = fakeMedia.map { it.path }.toSet()
                    if (isPhotosSelected) {
                        media.filter {
                            !firstListObjectIds.contains(it.path) && it.path.getFilenameFromPath().startsWith(".")
                        } as java.util.ArrayList<Medium>
                    } else {
                        media.filter {
                            !firstListObjectIds.contains(it.path) && it.path.getFilenameFromPath().startsWith(".") && it.type != TYPE_GIFS
                        } as java.util.ArrayList<Medium>
                    }
                }
                if (curMedia.isNotEmpty()) {
                    directory.name = directory.name + hiddenString
                    directory.mediaCnt = curMedia.size
                    directory.tmb = curMedia[0].path
                    HiddenDirList.add(directory)
                } else {
                    HiddenDirList.remove(directory)
                }
            }
        }

        Log.d("TagHidden ", HiddenDirList.size.toString())
        mDirs = HiddenDirList
        setupAdapter(mDirs)
        Thread {

            runOnUiThread {
                mBinding.directoriesRefreshLayout.isRefreshing = false
                VaultFragment.isLoadedGallery = true
                checkPlaceholderVisibility(HiddenDirList)
                mBinding.llProgress.visibility = View.GONE
            }
        }.start()

    }

    fun setupAdapter(dirs: ArrayList<Directory>, textToSearch: String = "", forceRecreate: Boolean = false) {

        runOnUiThread {

            if (mBinding.directoriesGrid != null) {

                val currAdapter = mBinding.directoriesGrid.adapter
                val distinctDirs = dirs.distinctBy { it.path.getDistinctPath() }.toMutableList() as ArrayList<Directory>
                val sortedDirs = getSortedDirectories(distinctDirs)
                var dirsToShow = getDirsToShow(sortedDirs, mDirs, mCurrentPathPrefix).clone() as ArrayList<Directory>
                dirsToShow.sortWith { o1, o2 ->
                    o1 as Directory
                    o2 as Directory
                    var result = when {
                        config.directorySorting and SORT_BY_NAME != 0 -> {
                            o1.name.lowercase(Locale.getDefault()).compareTo(o2.name.lowercase(Locale.getDefault()))
                        }
                        config.directorySorting and SORT_BY_DATE_MODIFIED != 0 -> (o1.modified).compareTo(o2.modified)
                        config.directorySorting and SORT_BY_SIZE != 0 -> o1.mediaCnt.compareTo(o2.mediaCnt)
                        else -> o1.actualFolderCount.compareTo(o2.actualFolderCount)
                    }
                    if (config.directorySorting and SORT_DESCENDING != 0) {
                        result *= -1
                    }
                    result
                }
                if (currAdapter == null || forceRecreate) {
//                initZoomListener()
                    val fastscroller = mBinding.directoriesVerticalFastscroller
                    DirectoryAdapter(
                        this,
                        dirsToShow,
                        this,
                        mBinding.directoriesGrid,
                        isPickIntent(intent) || isGetAnyContentIntent(intent),
                        true,
                        mBinding.directoriesRefreshLayout,
                        fastscroller
                    ) {
                        val clickedDir = it as Directory
                        val path = clickedDir.path
                        if (clickedDir.subfoldersCount == 1 || !config.groupDirectSubfolders) {
//                            if (path != config.tempFolderPath) {
                            itemClicked(path)
//                            }
                        } else {
                            mCurrentPathPrefix = path
                            mOpenedSubfolders.add(path)
                            setupAdapter(mDirs, "")
                        }
                    }.apply {
//                    setupZoomListener(mZoomListener)
                        runOnUiThread {

                            mBinding.directoriesGrid.adapter = this
                            setupScrollDirection()

                            if (config.viewTypeFolders == VIEW_TYPE_LIST) {
                                mBinding.directoriesGrid.scheduleLayoutAnimation()
                            }
                        }
                    }
                } else {
                    runOnUiThread {
                        if (textToSearch.isNotEmpty()) {
                            dirsToShow = dirsToShow.filter { it.name.contains(textToSearch, true) }.sortedBy { !it.name.startsWith(textToSearch, true) }.toMutableList() as ArrayList
                        }
                        checkPlaceholderVisibility(dirsToShow)
                        (mBinding.directoriesGrid.adapter as? DirectoryAdapter)?.updateDirs(dirsToShow)
                    }
                }
            }
        }
    }

    private fun itemClicked(path: String) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()
        if (config.isAnyOperationRunning && path == config.lastDestinationPath) {
            toast(getString(com.gallery.photo.image.video.R.string.msg_operation_already_running))
        } else {
            handleLockedFolderOpening(path) { success ->
                if (success) {
                    Log.d("Tag", "clicked")
                    Intent(this, MediaActivity::class.java).apply {
                        putExtra(SKIP_AUTHENTICATION, true)
                        putExtra(DIRECTORY, path)
                        putExtra(SHOW_ONLY_HIDDEN, true)
                        handleMediaIntent(this)
                    }
                }
            }
        }
    }

    private fun handleMediaIntent(intent: Intent) {
        intent.apply {
            if (mIsSetWallpaperIntent) {
                putExtra(SET_WALLPAPER_INTENT, true)
                launchActivityForResult(this, PICK_WALLPAPER)
            } else {
                putExtra(GET_IMAGE_INTENT, mIsPickImageIntent || mIsGetImageContentIntent)
                putExtra(GET_VIDEO_INTENT, mIsPickVideoIntent || mIsGetVideoContentIntent)
                putExtra(GET_ANY_INTENT, mIsGetAnyContentIntent)
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, mAllowPickingMultiple)
                putExtra(IS_FROM_FAKE_VAULT, VaultFragment.isFakeVaultOpen)
                putExtra(IS_FROM_VAULT, true)
                putExtra(IS_VIDEO, !isPhotosSelected)
                launchActivityForResult(this, PICK_MEDIA)
            }
        }
    }


    private fun checkPlaceholderVisibility(dirs: ArrayList<Directory>) {
        runOnUiThread {

            mBinding.directoriesEmptyPlaceholder.beGone()
            mBinding.directoriesEmptyPlaceholder2.beGone()
            mBinding.rlAddHiddenPhotoVideo.beVisibleIf(dirs.isEmpty())
            if (mIsSearchOpen) {
                mBinding.directoriesEmptyPlaceholder.beVisibleIf(dirs.isEmpty())
                mBinding.directoriesEmptyPlaceholder.text = getString(R.string.no_items_found)
            } else if (dirs.isEmpty() && config.filterMedia == getDefaultFileFilter()) {

                mBinding.directoriesEmptyPlaceholder.text = getString(R.string.no_media_with_filters)
                mBinding.directoriesEmptyPlaceholder2.text = getString(R.string.add_folder)
                mDirs = dirs
            } else {
                mBinding.directoriesEmptyPlaceholder.text = getString(R.string.no_media_with_filters)
                mBinding.directoriesEmptyPlaceholder2.text = getString(R.string.change_filters_underlined)
            }

            mBinding.directoriesEmptyPlaceholder2.underlineText()
            mBinding.directoriesGrid.beVisibleIf(mBinding.rlAddHiddenPhotoVideo.isGone())
            if (dirs.isEmpty()) {
                config.hiddenCountForRate = 0

            }
        }

    }

    fun setupLayoutManager() {
        runOnUiThread(Runnable {
            if (config.viewTypeFolders == VIEW_TYPE_GRID) {
                setupGridLayoutManager()
            } else {
                setupListLayoutManager()
            }
        })

    }

    private fun setupGridLayoutManager() {
        //Hidden By Gallery App Layout Manager
        val layoutManager = mBinding.directoriesGrid.layoutManager as MyGridLayoutManager
        if (config.scrollHorizontally) {
            layoutManager.orientation = RecyclerView.HORIZONTAL
        } else {
            layoutManager.orientation = RecyclerView.VERTICAL
        }
        layoutManager.spanCount = config.dirColumnCnt
    }

    private fun setupListLayoutManager() {
        val layoutManager = mBinding.directoriesGrid.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = 1
        layoutManager.orientation = RecyclerView.VERTICAL
    }

    private fun isPickIntent(intent: Intent) = intent.action == Intent.ACTION_PICK

    private fun isGetContentIntent(intent: Intent) = intent.action == Intent.ACTION_GET_CONTENT && intent.type != null

    private fun isGetAnyContentIntent(intent: Intent) = isGetContentIntent(intent) && intent.type == "*/*"

    private fun setupScrollDirection() {
        val allowHorizontalScroll = config.scrollHorizontally && config.viewTypeFolders == VIEW_TYPE_GRID
        mBinding.directoriesVerticalFastscroller.isHorizontal = false
        mBinding.directoriesVerticalFastscroller.beGoneIf(allowHorizontalScroll)
    }

    override fun refreshItems() {
        getDirectories()
    }

    override fun deleteFolders(folders: ArrayList<File>) {
        val fileDirItems = folders.asSequence().filter { it.isDirectory }.map { FileDirItem(it.absolutePath, it.name, true) }.toMutableList() as ArrayList<FileDirItem>
        when {
            fileDirItems.isEmpty() -> return
            fileDirItems.size == 1 -> {
                try {
                    toast(String.format(getString(R.string.deleting_folder), fileDirItems.first().name))
                } catch (e: Exception) {
                    showErrorToast(e)
                }
            }
            else -> {
                val baseString = if (config.useRecycleBin) R.plurals.moving_items_into_bin else R.plurals.delete_folders
                val deletingItems = resources.getQuantityString(baseString, fileDirItems.size, fileDirItems.size)
                toast(deletingItems)
            }
        }

        val itemsToDelete = ArrayList<FileDirItem>()
        val filter = config.filterMedia
        val showHidden = true
        if (VaultFragment.isFakeVaultOpen) {
            fileDirItems.filter {
                it.isDirectory
            }.forEach { fileDirItem ->
                var type = if (isPhotosSelected)
                    TYPE_IMAGES
                else
                    TYPE_VIDEOS
                ensureBackgroundThread {
                    var gif = fakeVaultMediumDao.getTypeMediaFromPath(fileDirItem.path, TYPE_GIFS)
                    var images = fakeVaultMediumDao.getTypeMediaFromPath(fileDirItem.path, type) as java.util.ArrayList<Medium>
                    var media = images
                    if (isPhotosSelected)
                        media.addAll(gif)
                    media.mapTo(itemsToDelete) { FileDirItem(it.path, it.name) }
                    runOnUiThread {
                        val pathsToDelete = ArrayList<String>()
                        itemsToDelete.mapTo(pathsToDelete) { it.path }
                        Log.d("hfdfadsfdsf", "deleteFolders: " + itemsToDelete.size)
                        movePathsInRecycleBin(pathsToDelete, false, VaultFragment.isFakeVaultOpen) {
                            if (it) {
                                deleteFilteredFileDirItems(itemsToDelete, folders)
                            } else {
                                toast(R.string.unknown_error_occurred)
                            }
                        }
                    }
                }
            }
        } else {
            ensureBackgroundThread {
                fileDirItems.filter {
                    it.isDirectory
                }.forEach { fileDirItem ->
                    var type = if (isPhotosSelected)
                        TYPE_IMAGES
                    else
                        TYPE_VIDEOS
                    var gif = fakeVaultMediumDao.getTypeMediaFromPath(fileDirItem.path, TYPE_GIFS)
                    var images = fakeVaultMediumDao.getTypeMediaFromPath(fileDirItem.path, type) as java.util.ArrayList<Medium>
                    var media = images
                    if (isPhotosSelected)
                        media.addAll(gif)

                    val firstListObjectIds = media.map { it.path }.toSet()
                    if (fileDirItem.path.containsNoMedia()) {
                        val files = File(fileDirItem.path).listFiles()

                        files?.filter {

                            if (isPhotosSelected) {
                                !firstListObjectIds.contains(it.path) && (it.isImageFast() || it.isGif())
                            } else {
                                !firstListObjectIds.contains(it.path) && it.isVideoFast()
                            }
                        }?.mapTo(itemsToDelete) { it.toFileDirItem(this) }
                    } else {
                        val files = File(fileDirItem.path).listFiles()
                        files?.filter {
                            !firstListObjectIds.contains(it.path)
                            if (isPhotosSelected) {
                                !firstListObjectIds.contains(it.path) && (it.isImageFast() || it.isGif()) && it.name.startsWith('.')
                            } else {
                                !firstListObjectIds.contains(it.path) && it.isVideoFast() && it.name.startsWith('.')
                            }

                        }?.mapTo(itemsToDelete) { it.toFileDirItem(this) }
                    }

                }
                val pathsToDelete = ArrayList<String>()
                itemsToDelete.mapTo(pathsToDelete) { it.path }
                Log.d("hfdfadsfdsf", "deleteFolders: " + itemsToDelete.size)
                movePathsInRecycleBin(pathsToDelete, false, VaultFragment.isFakeVaultOpen) {
                    if (it) {
                        deleteFilteredFileDirItems(itemsToDelete, folders)
                    } else {
                        toast(R.string.unknown_error_occurred)
                    }
                }
            }
        }


    }

    private fun deleteFilteredFileDirItems(fileDirItems: ArrayList<FileDirItem>, folders: ArrayList<File>) {
        val OTGPath = config.OTGPath
        deleteFiles(fileDirItems) {
            ensureBackgroundThread {
                folders.forEach {
                    Log.d("RefreshMedia1234", "updatePhotoVideoDirectoryPath: Called TYpe Video  ---> ")
                    updatePhotoVideoDirectoryPath(it.absolutePath, false, true)
                    updatePhotoVideoDirectoryPath(it.absolutePath, true, false)
                }
                folders.filter { !getDoesFilePathExist(it.absolutePath, OTGPath) }.forEach {
                    directoryDao.deleteDirPath(it.absolutePath)
                }
                runOnUiThread {
                    PhotoDirectoryFragment.isNeedToRefresh = true
                    VideoDirectoryFragment.isNeedToRefresh = true
                    if (getRecyclerAdapter() != null) {
                        getRecyclerAdapter()!!.finishActMode()
                        getRecyclerAdapter()!!.dismissProgress()
                    }

                    refreshItems()
                }
                if (config.deleteEmptyFolders) {
                    folders.filter { !it.absolutePath.isDownloadsFolder() && it.isDirectory && it.toFileDirItem(this).getProperFileCount(this, true) == 0 }.forEach {
                        tryDeleteFileDirItem(it.toFileDirItem(this), true, true)
                    }
                }
            }
        }

    }


    override fun recheckPinnedFolders() {

    }

    override fun updateDirectories(directories: ArrayList<Directory>) {

    }

    fun toggleToolbar(isShowActionBar: Boolean) {
        if (isShowActionBar) {
            if (mBinding.etSearch.visibility == View.VISIBLE) {
                hideKeyboard(findViewById<EditText>(R.id.etSearch))
                findViewById<EditText>(R.id.etSearch).clearFocus()
            }
            mBinding.llBottomOption.visibility = View.VISIBLE
            mBinding.tvHideUnHideText.text = resources.getString(R.string.label_unhide_folder, 0)
            mBinding.imgOptHideUnHide.setImageDrawable(resources.getDrawable(R.drawable.ic_option_unhide))
            mBinding.directoriesGrid.setPadding(3, 3, 3, 3)
        } else {
            mBinding.llBottomOption.visibility = View.GONE
            val r: Resources = resources
            var dimen = r.getDimension(R.dimen._7sdp)
            val px = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, dimen, r.displayMetrics
            ).roundToInt()
            mBinding.directoriesGrid.setPadding(3, 3, 3, mBinding.imgAddHiddenPhoto.height + px)
        }
    }

    fun updateCount(size: Int) {
        mBinding.tvHideUnHideText.text = resources.getString(R.string.label_unhide_folder, size)
    }

    private fun showFABMenu() {
        isFABOpen = true
        if (getRecyclerAdapter() != null) {
            getRecyclerAdapter()!!.finishActMode()

        }
        if (mBinding.etSearch.visibility == VISIBLE) {
            mBinding.imgClose.performClick()
        }
        mBinding.imgAddHiddenPhoto.setImageDrawable(resources.getDrawable(R.drawable.ic_vault_close))
        mBinding.flBackground.beVisible()
        if (isPhotosSelected)
            mBinding.llFromCamera.beVisible()
        else
            mBinding.llFromCamera.beGone()
        mBinding.llFromGallery.beVisible()
        mBinding.llFromFolder.beVisible()
    }

    private fun closeFABMenu() {
        isFABOpen = false
        mBinding.imgAddHiddenPhoto.setImageDrawable(resources.getDrawable(R.drawable.ic_add_hidden_new))
        mBinding.flBackground.beGone()
        mBinding.llFromCamera.beGone()
        mBinding.llFromGallery.beGone()
        mBinding.llFromFolder.beGone()
    }

    override fun fromActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
        super.fromActivityResult(requestCode, resultCode, resultData)
        when (requestCode) {
            REQUEST_CODE_CAMERA -> {
                isUnLockApp = true
                VaultFragment.isTabUnlock = true
                Log.d(TAG, "onActivityResult: $mCurrentPhotoUri")

                if (resultCode == Activity.RESULT_OK) {
                    ensureBackgroundThread {
                        config.hidePhotoCountForSubscription++
                        ensureBackgroundThread {
                            uDataDao.updateCount(HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION, config.hidePhotoCountForSubscription)
                        }
                        if (directoryDao.getDirectoryDetailFromDirPath(CAMERA_DIR_PATH) != null) {
                            if (VaultFragment.isFakeVaultOpen) {
                                fakeVaultHiddenDirectoryDao.insert(directoryDao.getDirectoryDetailFromDirPath(CAMERA_DIR_PATH).getConvertedFakeVaultDirectory())
                            } else {
                                hiddenDirectoryDao.insert(directoryDao.getDirectoryDetailFromDirPath(CAMERA_DIR_PATH).getConvertedHiddenDirectory())
                            }
                        } else if (photoDirectoryDao.getDirectoryDetailFromDirPath(CAMERA_DIR_PATH) != null) {
                            if (VaultFragment.isFakeVaultOpen) {
                                fakeVaultHiddenDirectoryDao.insert(photoDirectoryDao.getDirectoryDetailFromDirPath(CAMERA_DIR_PATH).getConvertedFakeVaultDirectory())
                            } else {
                                hiddenDirectoryDao.insert(photoDirectoryDao.getDirectoryDetailFromDirPath(CAMERA_DIR_PATH).getConvertedHiddenDirectory())
                            }
                        } else {
                            updatePhotoVideoDirectoryPath(CAMERA_DIR_PATH, true, false, true)
                        }
                        if (VaultFragment.isFakeVaultOpen) {
                            insertFakeMedia(mCurrentPhotoPath)
                        } else {
                            val type = when {
                                mCurrentPhotoPath.isVideoFast() -> TYPE_VIDEOS
                                mCurrentPhotoPath.isGif() -> TYPE_GIFS
                                mCurrentPhotoPath.isSvg() -> TYPE_SVGS
                                mCurrentPhotoPath.isRawFast() -> TYPE_RAWS
                                mCurrentPhotoPath.isPortrait() -> TYPE_PORTRAITS
                                else -> TYPE_IMAGES
                            }
                            val duration = if (type == TYPE_VIDEOS) getDuration(mCurrentPhotoPath) ?: 0 else 0
                            val ts = System.currentTimeMillis()
                            val medium = Medium(
                                null,
                                mCurrentPhotoPath.getFilenameFromPath(),
                                mCurrentPhotoPath,
                                mCurrentPhotoPath.getParentPath(),
                                ts,
                                ts,
                                File(mCurrentPhotoPath).length(),
                                type,
                                duration,
                                false,
                                0
                            )
                            mediaDB.insert(medium)
                        }
                        runOnUiThread {
                            refreshItems()
                            if (AdsManager(this).isNeedToShowAds() && isOnline() && isNeedtoShowAdAfterCameraCapture) {
                                isShowInterstitialAd {
                                    isInterstitialShown = false
                                }
                            } else {
                                isInterstitialShown = false

                            }

                        }
                    }
                }
            }
            REQUEST_SELECT_MEDIA -> {
                isUnLockApp = true
                isInterstitialShown = true
                VaultFragment.isTabUnlock = true
                if (resultCode == Activity.RESULT_OK && resultData != null) {
                    var selectedList: List<String> = resultData?.getStringArrayListExtra(KEY_MEDIA_LIST)!!
                    var filterType: Int = resultData?.getIntExtra(KEY_MEDIA_TYPE, CHOOSE_IMAGE_TYPE)!!
                    showProgress(getString(R.string.please_wait))
                    ensureBackgroundThread {
                        if (filterType == CHOOSE_IMAGE_TYPE) {
                            var totalImagesCount = config.hidePhotoCountForSubscription
                            var totalVideosCount = config.hideVideoCountForSubscription
                            totalImagesCount += selectedList.size
                            if (AdsManager(this).isNeedToShowAds() && totalImagesCount > HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION_VAL) {
                                runOnUiThread {
                                    dismissProgress()
                                    SubscriptionDialog(this, totalImagesCount, totalVideosCount)
                                    {
                                        if (it) {
                                            var intent = Intent(this, SubscriptionActivity::class.java)
                                            launchActivityForResult(intent, REQUEST_CODE_FOR_SUBSCRIPTION)
                                        } else {
                                            mContext.config.hidePhotoCountForSubscription = totalImagesCount
                                            ensureBackgroundThread {
                                                uDataDao.updateCount(HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION, config.hidePhotoCountForSubscription)
                                            }
                                            hideFiles(selectedList, filterType, false)
                                        }
                                    }
                                }
                            } else {
                                mContext.config.hidePhotoCountForSubscription = totalImagesCount
                                ensureBackgroundThread {
                                    uDataDao.updateCount(HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION, config.hidePhotoCountForSubscription)
                                }
                                hideFiles(selectedList, filterType, true)
                            }
                        } else if (filterType == CHOOSE_VIDEO_TYPE) {
                            var totalImagesCount = config.hidePhotoCountForSubscription
                            var totalVideosCount = config.hideVideoCountForSubscription
                            totalVideosCount += selectedList.size
                            if (AdsManager(this).isNeedToShowAds() && totalVideosCount > HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION_VAL) {
                                runOnUiThread {
                                    dismissProgress()
                                    SubscriptionDialog(this, totalImagesCount, totalVideosCount)
                                    {
                                        if (it) {
                                            var intent = Intent(this, SubscriptionActivity::class.java)
                                            launchActivityForResult(intent, REQUEST_CODE_FOR_SUBSCRIPTION)
                                        } else {
                                            mContext.config.hideVideoCountForSubscription = totalVideosCount
                                            ensureBackgroundThread {
                                                uDataDao.updateCount(HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION, config.hideVideoCountForSubscription)
                                            }
                                            hideFiles(selectedList, filterType, false)
                                        }
                                    }
                                }
                            } else {
                                mContext.config.hideVideoCountForSubscription = totalVideosCount
                                ensureBackgroundThread {
                                    uDataDao.updateCount(HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION, config.hideVideoCountForSubscription)
                                }
                                hideFiles(selectedList, filterType, true)
                            }
                        }
                    }
                }
            }
        }
    }

    private fun hideFiles(selectedList: List<String>, filterType: Int, isNeedtoShowAd: Boolean) {
        var prevPath = ""
        var hiddenDirectory = ArrayList<String>()
        selectedList.forEach {
            if (prevPath != it.getParentPath()) {
                hiddenDirectory.add(it.getParentPath())
                prevPath = it.getParentPath()
            }
            val type = when {
                it.isVideoFast() -> TYPE_VIDEOS
                it.isGif() -> TYPE_GIFS
                it.isSvg() -> TYPE_SVGS
                it.isRawFast() -> TYPE_RAWS
                it.isPortrait() -> TYPE_PORTRAITS
                it.isAudioFast() -> TYPE_AUDIO
                it.isDocumentFast() -> TYPE_DOCUMENT
                else -> TYPE_IMAGES
            }
            toggleFileVisibility(it, true) {
                if (type == TYPE_IMAGES || type == TYPE_VIDEOS) {
                    if (VaultFragment.isFakeVaultOpen) {
                        insertFakeMedia(it)
                    }
                }
            }
        }
        if (filterType == CHOOSE_IMAGE_TYPE || filterType == CHOOSE_VIDEO_TYPE) {
//            getImageVaultGalleryData()
            try {
                ensureBackgroundThread {
                    hiddenDirectory.forEach {
                        if (directoryDao.getDirectoryDetailFromDirPath(it) != null) {
                            if (VaultFragment.isFakeVaultOpen) {
                                fakeVaultHiddenDirectoryDao.insert(directoryDao.getDirectoryDetailFromDirPath(it).getConvertedFakeVaultDirectory())
                            } else {
                                hiddenDirectoryDao.insert(directoryDao.getDirectoryDetailFromDirPath(it).getConvertedHiddenDirectory())
                            }
                        } else if (photoDirectoryDao.getDirectoryDetailFromDirPath(it) != null) {
                            if (VaultFragment.isFakeVaultOpen) {
                                fakeVaultHiddenDirectoryDao.insert(photoDirectoryDao.getDirectoryDetailFromDirPath(it).getConvertedFakeVaultDirectory())
                            } else {
                                hiddenDirectoryDao.insert(photoDirectoryDao.getDirectoryDetailFromDirPath(it).getConvertedHiddenDirectory())
                            }
                        } else if (videoDirectoryDao.getDirectoryDetailFromDirPath(it) != null) {
                            if (VaultFragment.isFakeVaultOpen) {
                                fakeVaultHiddenDirectoryDao.insert(videoDirectoryDao.getDirectoryDetailFromDirPath(it).getConvertedFakeVaultDirectory())
                            } else {
                                hiddenDirectoryDao.insert(videoDirectoryDao.getDirectoryDetailFromDirPath(it).getConvertedHiddenDirectory())
                            }
                        } else {
                            if (filterType == CHOOSE_IMAGE_TYPE)
                                updatePhotoVideoDirectoryPath(it, true, false, true)
                            else if (filterType == CHOOSE_VIDEO_TYPE)
                                updatePhotoVideoDirectoryPath(it, false, true, true)
                        }
                        updatePhotoVideoDirectoryPath(it, true, false, false)
                        updatePhotoVideoDirectoryPath(it, false, true, false)

                    }
                }
            } catch (e: Exception) {
            }
        }
        runOnUiThread {

            PhotoDirectoryFragment.isNeedToRefresh = true
            VideoDirectoryFragment.isNeedToRefresh = true
            when (filterType) {
                CHOOSE_IMAGE_TYPE -> toast(getString(R.string.msg_image_hide))
                CHOOSE_VIDEO_TYPE -> toast(getString(R.string.msg_video_hide))
                CHOOSE_AUDIO_TYPE -> toast(getString(R.string.msg_audio_hide))
                CHOOSE_DOCUMENT_TYPE -> toast(getString(R.string.msg_document_hide))
                else -> toast(getString(R.string.msg_hide_media_successfully))
            }
            isInterstitialShown = false
            refreshItems()

            dismissProgress()
            if (AdsManager(this).isNeedToShowAds() && isOnline() && isNeedtoShowAd) {
                isShowInterstitialAd {
                    isInterstitialShown = false
                }
            } else {
                isInterstitialShown = false
            }

        }

    }

    private fun insertFakeMedia(path: String) {
        ensureBackgroundThread {
            val type = when {
                path.isVideoFast() -> TYPE_VIDEOS
                path.isGif() -> TYPE_GIFS
                path.isSvg() -> TYPE_SVGS
                path.isRawFast() -> TYPE_RAWS
                path.isPortrait() -> TYPE_PORTRAITS
                else -> TYPE_IMAGES
            }
            val duration = if (type == TYPE_VIDEOS) getDuration(path) ?: 0 else 0
            val ts = System.currentTimeMillis()
            val medium = FakeVaultMedium(
                null,
                path.getFilenameFromPath(),
                path,
                path.getParentPath(),
                ts,
                ts,
                File(path).length(),
                type,
                duration,
                false,
                0
            )
            fakeVaultMediumDao.insert(medium)
        }
    }

    override fun onBackPressed() {
        when {
            isFABOpen -> {
                closeFABMenu()
            }
            else -> {
                super.onBackPressed()
            }
        }
    }
}