package com.gallery.photo.image.video.Camera;

import android.content.Context;
import android.location.Location;
import android.util.Log;


import com.gallery.photo.image.video.R;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class TextFormatter {
    private static final String TAG = "TextFormatter";
    private final Context context;
    private final DecimalFormat decimalFormat = new DecimalFormat("#0.0");

    public TextFormatter(Context context2) {
        this.context = context2;
    }

    public static String getDateString(String str, Date date) {
        if (str.equals("preference_stamp_dateformat_none")) {
            return "";
        }
        str.hashCode();
        char c = 65535;
        switch (str.hashCode()) {
            case -1966818982:
                if (str.equals("preference_stamp_dateformat_ddmmyyyy")) {
                    c = 0;
                    break;
                }
                break;
            case -34803366:
                if (str.equals("preference_stamp_dateformat_mmddyyyy")) {
                    c = 1;
                    break;
                }
                break;
            case 2084430170:
                if (str.equals("preference_stamp_dateformat_yyyymmdd")) {
                    c = 2;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
                return new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(date);
            case 1:
                return new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault()).format(date);
            case 2:
                return new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(date);
            default:
                return DateFormat.getDateInstance().format(date);
        }
    }

    public static String getTimeString(String str, Date date) {
        if (str.equals("preference_stamp_timeformat_none")) {
            return "";
        }
        str.hashCode();
        if (str.equals("preference_stamp_timeformat_12hour")) {
            return new SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(date);
        }
        if (!str.equals("preference_stamp_timeformat_24hour")) {
            return DateFormat.getTimeInstance().format(date);
        }
        return new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(date);
    }

    private String getDistanceString(double d, String str) {
        String string = this.context.getResources().getString(R.string.metres_abbreviation);
        if (str.equals("preference_units_distance_ft")) {
            d *= 3.28084d;
            string = this.context.getResources().getString(R.string.feet_abbreviation);
        }
        return this.decimalFormat.format(d) + string;
    }

    public String getGPSString(String str, String str2, boolean z, Location location, boolean z2, double d) {
        String str3;
        if (str.equals("preference_stamp_gpsformat_none")) {
            return "";
        }
        if (z) {
            Log.d(TAG, "location: " + location);
            if (str.equals("preference_stamp_gpsformat_dms")) {
                str3 = "" + LocationSupplier.locationToDMS(location.getLatitude()) + ", " + LocationSupplier.locationToDMS(location.getLongitude());
            } else {
                str3 = "" + Location.convert(location.getLatitude(), 0) + ", " + Location.convert(location.getLongitude(), 0);
            }
            if (location.hasAltitude()) {
                str3 = str3 + ", " + getDistanceString(location.getAltitude(), str2);
            }
        } else {
            str3 = "";
        }
        if (!z2) {
            return str3;
        }
        float degrees = (float) Math.toDegrees(d);
        if (degrees < 0.0f) {
            degrees += 360.0f;
        }
        Log.d(TAG, "geo_angle: " + degrees);
        if (str3.length() > 0) {
            str3 = str3 + ", ";
        }
        return str3 + "" + Math.round(degrees) + 176;
    }

    public static String formatTimeMS(long j) {
        int i = (int) ((j / 60000) % 60);
        int i2 = (int) (j / 3600000);
        return String.format(Locale.getDefault(), "%02d:%02d:%02d,%03d", new Object[]{Integer.valueOf(i2), Integer.valueOf(i), Integer.valueOf(((int) (j / 1000)) % 60), Integer.valueOf(((int) j) % 1000)});
    }
}
