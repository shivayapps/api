package com.gallery.photo.image.video.dialog

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import com.gallery.photo.image.video.Camera.PreferenceKeys
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.extensions.config
import com.gallery.photo.image.video.utilities.SharedPrefs
import org.jetbrains.anko.layoutInflater


class CameraGridDialog(
    val activity: Context, val callback: () -> Unit
) {
    private var currGrid = 0
    private var config = activity.config
    private var view: View
    var grid_values: Array<String>

    init {

        view = activity.layoutInflater.inflate(R.layout.dialog_camera_grid, null)

        val dialog = Dialog(activity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCanceledOnTouchOutside(false)
        dialog.setContentView(view)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        val ivClose = dialog.findViewById(R.id.ivClose) as ImageView
        ivClose.setOnClickListener {
            dialog.dismiss()
        }
        grid_values = activity.resources.getStringArray(R.array.preference_grid_values)
        var llNone = dialog.findViewById<LinearLayout>(R.id.llNone)
        var ll3_3 = dialog.findViewById<LinearLayout>(R.id.ll3_3)
        var llPhi3_3 = dialog.findViewById<LinearLayout>(R.id.llPhi3_3)
        var ll4_2 = dialog.findViewById<LinearLayout>(R.id.ll4_2)
        var llCrosshair = dialog.findViewById<LinearLayout>(R.id.llCrosshair)
        var selectedPos = SharedPrefs.getInt(activity, PreferenceKeys.GRID_POS)
        when (selectedPos) {
            0 -> {
                setSelectedView(llNone, ll3_3, llPhi3_3, ll4_2, llCrosshair)
            }
            1 -> {
                setSelectedView(ll3_3, llNone, llPhi3_3, ll4_2, llCrosshair)
            }
            2 -> {
                setSelectedView(llPhi3_3, llNone, ll3_3, ll4_2, llCrosshair)
            }
            3 -> {
                setSelectedView(ll4_2, llNone, ll3_3, llPhi3_3, llCrosshair)
            }
            4 -> {
                setSelectedView(llCrosshair, llNone, ll3_3, llPhi3_3, ll4_2)
            }
        }
        llNone.setOnClickListener {
            selectedPos = 0
            setSelectedView(llNone, ll3_3, llPhi3_3, ll4_2, llCrosshair)
        }
        ll3_3.setOnClickListener {
            selectedPos = 1
            setSelectedView(ll3_3, llNone, llPhi3_3, ll4_2, llCrosshair)
        }
        llPhi3_3.setOnClickListener {
            selectedPos = 2
            setSelectedView(llPhi3_3, llNone, ll3_3, ll4_2, llCrosshair)
        }
        ll4_2.setOnClickListener {
            selectedPos = 3
            setSelectedView(ll4_2, llNone, ll3_3, llPhi3_3, llCrosshair)
        }
        llCrosshair.setOnClickListener {
            selectedPos = 4
            setSelectedView(llCrosshair, llNone, ll3_3, llPhi3_3, ll4_2)
        }
        val ivDone = dialog.findViewById(R.id.ivDone) as ImageView
        ivDone.setOnClickListener {
            SharedPrefs.save(activity, PreferenceKeys.ShowGridPreferenceKey, grid_values.get(selectedPos))
            SharedPrefs.save(activity, PreferenceKeys.GRID_POS, selectedPos)

            dialog.dismiss()
            callback()
        }
        dialog.show()
    }

    private fun setSelectedView(selectedView: LinearLayout?, ll33: LinearLayout?, llphi33: LinearLayout?, ll42: LinearLayout?, llCrosshair: LinearLayout?) {
        selectedView!!.background = activity.getDrawable(R.drawable.border_grid_selected)
        ll33!!.background = activity.getDrawable(R.drawable.border_grid_unselected)
        llphi33!!.background = activity.getDrawable(R.drawable.border_grid_unselected)
        ll42!!.background = activity.getDrawable(R.drawable.border_grid_unselected)
        llCrosshair!!.background = activity.getDrawable(R.drawable.border_grid_unselected)

    }


}
