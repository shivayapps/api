package com.gallery.photo.image.video.activity

//import androidx.activity.result.contract.ActivityResultContracts
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.*
import android.util.Log
import androidx.core.content.ContextCompat
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.Purchase
import com.example.app.ads.helper.InterstitialAdHelper
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.app.ads.helper.isNeedToShowAds
import com.example.jdrodi.utilities.OnPositive
import com.example.jdrodi.utilities.isOnline
import com.example.jdrodi.utilities.showAlert
import com.gallery.photo.image.video.BuildConfig
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.database.GalleryDatabase
import com.gallery.photo.image.video.dialog.ChangePattrenLockDialog
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.fragment.REQUEST_CODE_CHECK_PASSWORD
import com.gallery.photo.image.video.fragment.VaultFragment
import com.gallery.photo.image.video.inapp.InAppPurchaseHelper
import com.gallery.photo.image.video.lock.activity.CustomPinActivity
import com.gallery.photo.image.video.lock.managers.AppLock
import com.gallery.photo.image.video.models.UData
import com.gallery.photo.image.video.rateandfeedback.ExitSPHelper
import com.gallery.photo.image.video.rateandfeedback.rateApp
import com.gallery.photo.image.video.retrofit.APIService
import com.gallery.photo.image.video.retrofit.model.ForceUpdateModel
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.extensions.baseConfig
import com.gallery.photo.image.video.extensions.deleteFiles
import com.gallery.photo.image.video.extensions.getParentPath
import com.gallery.photo.image.video.extensions.toast
import com.gallery.photo.image.video.helpers.ensureBackgroundThread
import com.gallery.photo.image.video.models.FileDirItem
import kotlinx.android.synthetic.main.activity_splash.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.*
import java.util.*
import kotlin.system.exitProcess


private val TAG = OpenAdSplashActivity::class.java.simpleName
private const val SPLASH_DELAY = 5000L

class OpenAdSplashActivity : BaseActivity(), InAppPurchaseHelper.OnPurchased {


    private var isPaused = false // For check in onResume if app is paused or lunch
    private var adsCountDownTimer: AdsCountDownTimer? = null
    private val REQUEST_CODE_CHECK = 1184

    private var isAdClosed = false
    private var isNextActivity = true


    companion object {
        public var activity: Activity? = null
        var isAsyncTaskStarted = false
    }

    // TODO: 09/06/21 for android 11 storage permission
    var goToSetting = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        activity = this
        addEvent(TAG)
        Log.d("TAGCheckTIME", "onCreate: ")
    }

    override fun getContext(): Activity {
        return this
    }


    override fun initData() {
        Log.e(TAG, "initAds: Ads Loading")
        InterstitialAdHelper.loadInterstitialAd(fContext = mContext, onAdLoaded = {
            Log.e(TAG, "initAds: Ad Loaded")
        })

        Log.d(TAG, "initData: ")

        // Need to set save rate dialog dismiss false if it is true
        // So we can again show rate dialog on back press of the main activity
        if (ExitSPHelper(this).isDismissed()) {
            ExitSPHelper(this).saveDismissed(false)
        }
        if (baseConfig.isAnyOperationRunning) {
            baseConfig.isAnyOperationRunning = false
            baseConfig.lastDestinationPath = ""

        }
        try {
            isNeedToShowAds = AdsManager(this).isNeedToShowAds()
        } catch (e: Exception) {

        }
        config.isHelpQueLoaded = false
        VaultFragment.isHiddenByGallerySelected = true
        VaultFragment.isFirstTime = true
        VaultFragment.isTabUnlock = false
        VaultFragment.isLoadedOtherApp = false
        VaultFragment.isLoadedGallery = false
        if (config.appVaultAppLock == "") {
            if (config.isFingerprintEnable) {
                config.isFingerprintEnable = false
            }
        }


        if (config.fakeVaultAppLock.isNotEmpty() && !config.isFakeVaultReset) {
            config.isFakeVaultReset = true
            Log.d(TAG, "initData: Enable Password False")
            if (supportFingerPrint()) {
                addEvent(fakeVaultReset)
                Log.d(TAG, "initData:FingerPrint Support")
                config.isAppPasswordProtectionOn = false
                config.isEnableLock = false
                config.isFingerprintEnable = false
                config.fakeVaultAppLock = ""
                config.isFakeVaultEnable = false
                config.isFakeVaultDialogShown = false
            }
            Log.d(TAG, "initData:FingerPrint Support false")
        } else
            config.isFakeVaultReset = true

        if (config.isAppPasswordProtectionOn && config.securityQuestion.isNotEmpty() && config.securityQuestionIndex == 0) {
            updateSecurityQuestionIndex()
        }
        SharedPrefs.savePref(
            this,
            "isdatathare",
            true
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && Environment.isExternalStorageManager()) {
            updateCount()
            copyDB()
        } else if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R && ContextCompat.checkSelfPermission(
                this,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            updateCount()
            copyDB()
        }


//        if (isOnline()) {
//            GlobalScope.launch {
//                checkForceUpdateStatus()
//            }
//        } else {
//            Log.i(TAG, "offline")
        startHome()
//        }
    }

    private fun updateSecurityQuestionIndex() {
        AsyncBackgroundWork({}, {
            var arrayEnglish = arrayOf(
                "Select Your Question",
                "What's your father's name?",
                "What's your mother's name?",
                "What's your birthday?",
                "What's your pets name?",
                "What's your dream job?",
                "What's your lucky number?",
                "In which city were you born?"
            )
            var arrayHindi = arrayOf(
                "अपना प्रश्न चुनें",
                "तुम्हारे पिताजी का नाम क्या है?",
                "आपकी मां का नाम क्या है?",
                "आपका जन्मदिन कब है?",
                "आपके पालतू जानवर का क्या नाम है?",
                "आप भविष्य मे क्या नौकरी करना चाहते हैं?",
                "आपका भाग्यशाली अंक क्या है?",
                "आप किस शहर में पैदा हुए थे?"
            )
            var arraySpanish = arrayOf(
                "Seleccione su pregunta",
                "¿Cuál es el nombre de tu padre?",
                "¿Cómo se llama tu madre?",
                "¿Cuándo es tu cumpleaños?",
                "¿Cual es el nombre de tu mascota?",
                "¿Cuál es el trabajo de tus sueños?",
                "¿Cual es tu numero de la suerte?",
                "¿En qué ciudad naciste?"
            )
            var arrayPortiguse = arrayOf(
                "Selecione sua pergunta",
                "Qual é o nome do seu pai?",
                "Qual o nome da sua mãe?",
                "Quando é seu aniversário?",
                "Qual é o nome do teu animal de estimação?",
                "Qual é o teu emprego de sonho?",
                "Qual é o seu número da sorte?",
                "Em que cidade você nasceu?"
            )
            var arrayUrdu = arrayOf(
                "اپنا سوال منتخب کریں",
                "آپ کے والد کا نام کیا ہے؟",
                "آپکی والدہ کا کیا نام ہے؟",
                "آپ کی سالگرہ کیا ہے؟",
                "آپ کے پالتو جانوروں کا نام کیا ہے؟",
                "آپ کا خواب کیا ہے؟",
                "آپ کا لکی نمبر کیا ہے؟",
                "تم کس شہر میں پیدا ہوئے؟"
            )
            var position = arrayEnglish.indexOf(config.securityQuestion)
            if (position == -1) {
                position = arraySpanish.indexOf(config.securityQuestion)
            }
            if (position == -1) {
                position = arrayHindi.indexOf(config.securityQuestion)
            }
            if (position == -1) {
                position = arrayPortiguse.indexOf(config.securityQuestion)
            }
            if (position == -1) {
                position = arrayUrdu.indexOf(config.securityQuestion)
            }
            Log.d(TAG, "initData: position -->" + position)
            if (position != -1)
                config.securityQuestionIndex = position
        }, {})

    }

    private fun updateCount() {
        AsyncBackgroundWork({}, {
            try {
                val data = uDataDao.get(HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION)
                if (data != null) {
                    if (data!!.titleValue != 0) {
                        config.hideVideoCountForSubscription = data!!.titleValue
                    } else if (config.hideVideoCountForSubscription != 0) {
                        uDataDao.updateCount(
                            HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION,
                            config.hideVideoCountForSubscription
                        )
                    }
                } else {
                    if (config.hideVideoCountForSubscription != 0) {
                        uDataDao.add(
                            UData(
                                null,
                                HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION,
                                config.hideVideoCountForSubscription
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            try {
                val photoData = uDataDao.get(HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION)
                if (photoData != null) {
                    if (photoData!!.titleValue != 0) {
                        config.hidePhotoCountForSubscription = photoData!!.titleValue
                    } else if (config.hideVideoCountForSubscription != 0) {
                        uDataDao.updateCount(
                            HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION,
                            config.hidePhotoCountForSubscription
                        )
                    }
                } else {
                    if (config.hidePhotoCountForSubscription != 0) {
                        uDataDao.add(
                            UData(
                                null,
                                HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION,
                                config.hidePhotoCountForSubscription
                            )
                        )
                    }

                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            Log.d(
                TAG,
                "initView: hidePhotoCountForSubscription " + mContext.config.hidePhotoCountForSubscription
            )
            Log.d(
                TAG,
                "initView: hideVideoCountForSubscription " + mContext.config.hideVideoCountForSubscription
            )
        }, {})


    }

    private fun emptyTrash() {
        AsyncBackgroundWork({}, {
            try {
                val arr = getMilliSecRangeOfDay(System.currentTimeMillis())
//                Log.d(TAG, "emptyTrash: Start Date -->"+ Date(arr[0]))
//                Log.d(TAG, "emptyTrash: End Date -->"+ Date(arr[1]))
                val imageListToDelete = mediaDB.getTrashMediaForDelete(arr[1])
                val fakeVaultImageListToDelete = fakeVaultMediumDao.getTrashMediaForDelete(arr[1])
                val filesToDelete = hideFileDao.getTrashMediaForDelete(arr[1])
                val fakeVaultFilesToDelete = fakeHideFileDao.getTrashMediaForDelete(arr[1])
                noteDao.deleteTrashNotes(arr[1])

                val deleteList = ArrayList<String>()
                if (filesToDelete.isNotEmpty())
                    deleteList.addAll(filesToDelete)
                if (imageListToDelete.isNotEmpty())
                    deleteList.addAll(imageListToDelete)
                if (fakeVaultImageListToDelete.isNotEmpty())
                    deleteList.addAll(fakeVaultImageListToDelete)
                if (fakeVaultFilesToDelete.isNotEmpty())
                    deleteList.addAll(fakeVaultFilesToDelete)
                deleteFiles(deleteList.map {
                    FileDirItem(
                        it.replace(RECYCLE_BIN, "$recycleBinPath/")
                            .replace(RECOVER_TRASH_BIN, "$recoverTrashPath/"),
                        it.removePrefix(RECYCLE_BIN).removePrefix(
                            RECOVER_TRASH_BIN
                        )
                    )
                }) {
                    Log.d(TAG, "emptyTrash:file Deleted --> $it")
                    if (it) {
                        ensureBackgroundThread {
                            mediaDB.deleteTrashMedia(arr[1])
                            fakeVaultMediumDao.deleteTrashMedia(arr[1])
                            hideFileDao.deleteTrashMedia(arr[1])
                            fakeHideFileDao.deleteTrashMedia(arr[1])
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

        }, {})
    }

    override fun initActions() {

    }


    override fun getAppIconIDs() = arrayListOf(
        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName() = getString(R.string.app_name)


    // Every time to need initialize billing
    // to check if subscription or in-app purchase was made or not and even if it is made then to check is it active or expired
    private fun initBilling() {
        runOnUiThread {
            try {
                InAppPurchaseHelper.instance!!.initBillingClient(this, this)
            } catch (e: Exception) {
                Log.e(TAG, "initBillingClient: " + e.message)
            }
        }
    }


    /**
     * Called when leaving the mContext
     */
    public override fun onPause() {
        super.onPause()
        if (adsCountDownTimer != null) {
            adsCountDownTimer!!.cancel()
        }
        isPaused = true
    }

    override fun onBackPressed() {
        super.onBackPressed()
        Log.i(TAG, "onBackPressed")
        exitProcess(0)
    }

    /**
     * Called when returning to the mContext
     */
    public override fun onResume() {
        super.onResume()

        Log.i(TAG, "onResume")
        if (!isPaused) {
            Log.i(TAG, "is not paused")
            return
        }
        isAdClosed = true
        Handler(Looper.getMainLooper()).postDelayed({ startHome() }, 100)
        Log.i(TAG, "Ads not loaded or may be null")
    }

    /**
     * AdsCountDownTimer for 5 sec delay
     */
    inner class AdsCountDownTimer(millisInFuture: Long, countDownInterval: Long) :
        CountDownTimer(millisInFuture, countDownInterval) {
        override fun onTick(millisUntilFinished: Long) {
            tv_count_down.text = (((SPLASH_DELAY - millisUntilFinished) / 1000) + 1).toString()
            Log.i(TAG, "countDownTimer: -->" + tv_count_down.text)
        }

        override fun onFinish() {
            Log.i(TAG, "countDownTimer: onFinish")
//            startHome()
            if (isAdClosed) {
//                Log.e(TAG, "isAdClosed")
            } else {

                isShowInterstitialAd {
                    startHome()
                }

                /*if (window.decorView.rootView.isShown) {
                    startHome()
                    Log.e(mTAG, "startHome::002")
                }*/

            }
        }
    }

    /**
     * If app is not purchased or subscription not found start count down for 5 sec and load ad
     */
    private fun startSplashDelay() {
        Log.e(TAG, "startSplashDelay: ")
        try {
            if (isOnline()) {
                adsCountDownTimer = AdsCountDownTimer(5000, 500)
                adsCountDownTimer!!.start()
                Log.e(TAG, "startSplashDelay:5000 ")
            } else {
                adsCountDownTimer = AdsCountDownTimer(0, 200)
                adsCountDownTimer!!.start()
                Log.e(TAG, "startSplashDelay:1000 ")
            }
            Log.e(TAG, "startSplashDelay:Loading... ")
        } catch (e: java.lang.Exception) {
            Log.e(TAG, "startSplashDelay: " + e.message)
            Thread.sleep(3000)
            isPaused = true
            startHome()
        }

    }

    /**
     * Start your splash home our desire activity
     */
    private fun startHome() {
        if (adsCountDownTimer != null) {
            adsCountDownTimer!!.cancel()
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && Environment.isExternalStorageManager()) {
            isAsyncTaskStarted = true
            getPhotoDirectories()
            getVideoDirectories()
            updateTrash()
        } else if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R && ContextCompat.checkSelfPermission(
                this,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            isAsyncTaskStarted = true
            getPhotoDirectories()
            getVideoDirectories()
            updateTrash()
        }
        startNextActivity()
    }

    private fun startNextActivity() {
        if (isNextActivity) {
            Log.d("TAGCheckTIME", "startNextActivity: ")
            Log.d(
                "TAGCheckTIME",
                "startNextActivity: --> " + "v97jg!b9uv}DV\$uT".toByteArray().toString()
            )
            isNextActivity = false
            if (config.oldLockTypeWhenFingerPrintEnable.isNotEmpty()) {
                config.isFingerprintEnable = true
            }
            if (config.oldLockTypePattern == LOCK_PATTERN || config.oldLockTypeWhenFingerPrintEnable == LOCK_PATTERN) {
                config.isAppPasswordProtectionOn = false
                config.isEnableLock = false
                config.oldLockTypePattern = ""
                config.oldLockTypeWhenFingerPrintEnable = ""
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !checkPermissionabove11()) {
                startActivity(Intent(this, AccessPermissionActivity::class.java))
            } else {
                if (baseConfig.appLanguage.isEmpty()) {
                    startActivity(Intent(this, ChooseAppLanguageActivity::class.java))
                } else {
                    startActivity(MainActivity.newIntent(this))
                }
            }
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
    }


    override fun onPurchasedSuccess(purchase: Purchase) {

    }

    override fun onProductAlreadyOwn() {

    }

    override fun onBillingSetupFinished(billingResult: BillingResult) {
        GlobalScope.launch(Dispatchers.Main) {
            InAppPurchaseHelper.instance!!.initProducts()
            InAppPurchaseHelper.instance!!.initSubscription()
            Log.i(TAG, "IN_APP_BILLING | Done")
            redirectToNextActivity()
        }
    }


    override fun onBillingUnavailable() {
        redirectToNextActivity()
    }

    override fun onBillingKeyNotFound(productId: String) {

    }

    private fun redirectToNextActivity() {
        config.isAlertBattery = false
        config.isChargerAlert = false

        if (AdsManager(this).isNeedToShowAds()) {
            startSplashDelay()
        } else {
            startHome()
        }
    }

    private fun copyDB() {
        val dbfile: File = getDatabasePath("shivaygallery.db")
        var sdir = File(DATABASE_PATH)
        var parentFile = File(sdir.absolutePath.getParentPath())
        if (!parentFile.exists()) {
            parentFile.mkdir()
        }
        if (!sdir.exists()) {
            sdir.mkdir()
        }

        val saveFile = File(DATABASE_PATH + "/shivaygallery.db")

        try {
            if (!saveFile.exists()) {
                ensureBackgroundThread {
                    addNoMedia(sdir.absolutePath) {
                        addNoMedia(sdir.absolutePath.getParentPath())
                        {
                        }
                    }
                }
                val buffersize = 8 * 1024
                val buffer = ByteArray(buffersize)
                var bytes_read = buffersize
                val savedb: OutputStream = FileOutputStream(saveFile)
                val indb: InputStream = FileInputStream(dbfile)
                while (indb.read(buffer, 0, buffersize).also { bytes_read = it } > 0) {
                    savedb.write(buffer, 0, bytes_read)
                }
                savedb.flush()
                indb.close()
                savedb.close()
                Log.e(TAG, "backupDatabase: Db Backup successful...")
                GalleryDatabase.destroyInstance()
                try {
                    GalleryDatabase.getInstance(this)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            emptyTrash()
        } catch (e: Exception) {
            e.printStackTrace()
            Log.e(TAG, "backupDatabase: ex: $e")
        }

    }


    override fun fromActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.fromActivityResult(requestCode, resultCode, data)
        if (requestCode == 1010) {
            redirectToNextAfterLockVerify()
        }
        if (requestCode == 10101) {
            redirectToNextAfterLockVerify()
        }
        if (requestCode == REQUEST_CODE_CHECK_PASSWORD) {
            if (resultCode == RESULT_OK) {
                toast(getString(R.string.msg_lock_set_sccessfully))
                config.isAppPasswordProtectionOn = true
                config.isEnableLock = true
                config.oldLockTypePattern = ""
                config.oldLockTypeWhenFingerPrintEnable = ""
            }
        }


    }

    private fun redirectToNextAfterLockVerify() {
        if (isUnLockApp) {
            if (config.oldLockTypePattern == LOCK_PATTERN || config.oldLockTypeWhenFingerPrintEnable == LOCK_PATTERN) {
                ChangePattrenLockDialog(this) {
                    if (it) {
                        val intent = Intent(this, CustomPinActivity::class.java)
                        intent.putExtra(AppLock.EXTRA_TYPE, AppLock.ENABLE_PINLOCK)
                        intent.putExtra("ChangePatternLock", true)
                        intent.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        startActivity(intent)
                    } else {
                        finish()
                    }
                }
            }

        } else {
            startNextActivity()
        }
    }


}