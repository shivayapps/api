package com.gallery.photo.image.video.activity

import android.app.ProgressDialog
import android.os.Bundle
import android.os.Handler
import androidx.annotation.Keep
import com.example.jdrodi.utilities.hideKeyboard
import com.gallery.photo.image.video.R
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlin.coroutines.CoroutineContext

@Keep
abstract class BaseActivity : MainBaseActivity(), CoroutineScope {

    lateinit var job: Job
    private val disposables = CompositeDisposable()
    override val coroutineContext: CoroutineContext
        get() = job + Dispatchers.Main
    var handler: Handler? = null
    companion object {
        var mProgressDailog: ProgressDialog? = null
    }


    fun addDisposable(disposable: Disposable) {
        disposables.add(disposable)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        job = Job()
        hideKeyboard()
        handler = Handler(mContext.mainLooper)
    }

    override fun onDestroy() {
        disposables.clear()
        job.cancel()
        super.onDestroy()
    }

    fun showProgress(msg: String) {
        if (mProgressDailog == null) {
            mProgressDailog = ProgressDialog(this, R.style.MyAlertDialogNew)
            mProgressDailog!!.setMessage(msg)

            mProgressDailog!!.setCancelable(false)
            mProgressDailog!!.setProgressStyle(ProgressDialog.STYLE_SPINNER)
            mProgressDailog!!.show()
        }
    }

    fun dismissProgress() {
        try {
            if (mProgressDailog != null && mProgressDailog!!.isShowing) {
                mProgressDailog!!.dismiss()
                mProgressDailog = null
            }
        } catch (e: Exception) {
            mProgressDailog = null
        }

    }


}