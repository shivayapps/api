package com.gallery.photo.image.video.bindActivity

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.example.app.ads.helper.InterstitialAdHelper
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.adapter.ViewPagerFragmentAdapter
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.databinding.ActivityTrashBinding
import com.gallery.photo.image.video.dialog.TrashInfoDialog
import com.gallery.photo.image.video.extensions.config
import com.gallery.photo.image.video.extensions.inflater
import com.gallery.photo.image.video.fragment.*
import com.gallery.photo.image.video.utilities.isInterstitialShown
import com.gallery.photo.image.video.extensions.beGoneIf
import com.gallery.photo.image.video.extensions.beVisibleIf
import com.google.android.material.tabs.TabLayoutMediator

class TrashActivity : BaseBindingActivity<ActivityTrashBinding>() {


    lateinit var viewPagerFragmentAdapter: ViewPagerFragmentAdapter

    var trashDialog: TrashInfoDialog? = null

    override fun getContext(): Activity {
        return this
    }

    companion object {
        var isDeleteOrRestore = false
        var isTrashDialogShown = false
        fun newIntent(mContext: Context): Intent {
            return Intent(mContext, TrashActivity::class.java)
        }

        var isNeedToRefersh = false

    }

    override fun initData() {
        val tabArray = arrayOf(
            getString(R.string.label_photos),
            getString(R.string.label_videos),
            getString(R.string.label_audio),
            getString(R.string.label_document),
            getString(R.string.label_secret_notes)
        )
        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            InterstitialAdHelper.loadInterstitialAd(fContext = this)
        }

        viewPagerFragmentAdapter = ViewPagerFragmentAdapter(this)
        viewPagerFragmentAdapter.addFragment(TrashImageFragment.newInstance())
        viewPagerFragmentAdapter.addFragment(TrashVideoFragment.newInstance())
        viewPagerFragmentAdapter.addFragment(TrashAudioFragment.newInstance())
        viewPagerFragmentAdapter.addFragment(TrashDocumentFragment.newInstance())
        viewPagerFragmentAdapter.addFragment(TrashNotesFragment.newInstance())

        mBinding.viewPagerTrash.apply {
            adapter = viewPagerFragmentAdapter
            (getChildAt(0) as RecyclerView).overScrollMode = RecyclerView.OVER_SCROLL_NEVER
            offscreenPageLimit = 5
            var fragment = viewPagerFragmentAdapter.createFragment(0)
            when (fragment) {
                is TrashImageFragment -> {
                    mBinding.imgDelete.beGoneIf(fragment.mMedia.size <= 0)
                    mBinding.imgDelete.beVisibleIf(fragment.mMedia.size > 0)
                }
            }
        }
        TabLayoutMediator(mBinding.tabLayout, mBinding.viewPagerTrash) { tab, position ->
            tab.text = tabArray[position]

        }.attach()
        mBinding.viewPagerTrash.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                var fragment = viewPagerFragmentAdapter.createFragment(position)
                when (fragment) {
                    is TrashImageFragment -> {
                        mBinding.imgDelete.beGoneIf(fragment.mMedia.size <= 0)
                        mBinding.imgDelete.beVisibleIf(fragment.mMedia.size > 0)
                    }
                    is TrashVideoFragment -> {
                        mBinding.imgDelete.beGoneIf(fragment.mMedia.size <= 0)
                        mBinding.imgDelete.beVisibleIf(fragment.mMedia.size > 0)
                    }
                    is TrashAudioFragment -> {
                        mBinding.imgDelete.beGoneIf(fragment.mMedia.size <= 0)
                        mBinding.imgDelete.beVisibleIf(fragment.mMedia.size > 0)
                    }
                    is TrashDocumentFragment -> {
                        mBinding.imgDelete.beGoneIf(fragment.mMedia.size <= 0)
                        mBinding.imgDelete.beVisibleIf(fragment.mMedia.size > 0)
                    }
                    is TrashNotesFragment -> {
                        mBinding.imgDelete.beGoneIf(fragment.noteList.size <= 0)
                        mBinding.imgDelete.beVisibleIf(fragment.noteList.size > 0)
                    }
                }
            }
        })
        if (!config.isTrashInfoDialogShown) {
            config.isTrashInfoDialogShown = true
            isTrashDialogShown = true
            trashDialog = TrashInfoDialog(this, getString(R.string.msg_delete_trash)) {
                isTrashDialogShown = false
            }
        }
    }

    override fun initActions() {
        mBinding.imgBack.setOnClickListener(this)
        mBinding.imgInfo.setOnClickListener(this)
        mBinding.llRestoreOpt.setOnClickListener(this)
        mBinding.llDeleteOpt.setOnClickListener(this)
        mBinding.imgDelete.setOnClickListener(this)
    }

    override fun setBinding(): ActivityTrashBinding {
        return ActivityTrashBinding.inflate(inflater)
    }

    fun toggleToolbar(isShowActionBar: Boolean) {
        mBinding.tabLayout.beVisibleIf(!isShowActionBar)
        mBinding.tabLayout.beGoneIf(isShowActionBar)
        mBinding.llBottomOption.beVisibleIf(isShowActionBar)
        mBinding.llBottomOption.beGoneIf(!isShowActionBar)
        mBinding.viewPagerTrash.isUserInputEnabled = !isShowActionBar
    }

    fun updateCount(size: Int) {
        mBinding.tvDeleteText.text = resources.getString(R.string.label_delete_count, size)
        mBinding.tvRestore.text = resources.getString(R.string.label_restore, size)
    }

    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()
        when (view.id) {
            R.id.imgBack -> {
                onBackPressed()

            }
            R.id.imgInfo -> {
                TrashInfoDialog(this, getString(R.string.msg_delete_trash)) {

                }
            }
            R.id.llRestoreOpt -> {
                isDeleteOrRestore = true
                var fragment = viewPagerFragmentAdapter.createFragment(mBinding.viewPagerTrash.currentItem)
                when (fragment) {
                    is TrashImageFragment -> {
                        fragment.restoreImages()
                    }
                    is TrashVideoFragment -> {
                        fragment.restoreVideo()
                    }
                    is TrashAudioFragment -> {
                        fragment.restoreAudio()
                    }
                    is TrashDocumentFragment -> {
                        fragment.restoreDocuments()
                    }
                    is TrashNotesFragment -> {
                        fragment.restoreNotes()
                    }
                }
            }
            R.id.llDeleteOpt -> {

                var fragment = viewPagerFragmentAdapter.createFragment(mBinding.viewPagerTrash.currentItem)
                when (fragment) {
                    is TrashImageFragment -> {
                        fragment.deleteImages()
                    }
                    is TrashVideoFragment -> {
                        fragment.deleteVideos()
                    }
                    is TrashAudioFragment -> {
                        fragment.deleteAudio()
                    }
                    is TrashDocumentFragment -> {
                        fragment.deleteDocuments()
                    }
                    is TrashNotesFragment -> {
                        fragment.deleteNotes()
                    }
                }
            }
            R.id.imgDelete -> {

                var fragment = viewPagerFragmentAdapter.createFragment(mBinding.viewPagerTrash.currentItem)
                when (fragment) {
                    is TrashImageFragment -> {
                        fragment.deleteAllImages()
                    }
                    is TrashVideoFragment -> {
                        fragment.deleteAllVideos()
                    }
                    is TrashAudioFragment -> {
                        fragment.deleteAllAudio()
                    }
                    is TrashDocumentFragment -> {
                        fragment.deleteAllDocuments()
                    }
                    is TrashNotesFragment -> {
                        fragment.deleteAllNotes()
                    }
                }
            }
        }
    }

    fun refreshItem(){
        var fragment = viewPagerFragmentAdapter.createFragment(mBinding.viewPagerTrash.currentItem)
        when (fragment) {
            is TrashImageFragment -> {
                fragment.refreshItems()
            }
            is TrashVideoFragment -> {
                fragment.refreshItems()
            }
            is TrashAudioFragment -> {
                fragment.refreshItems()
            }
            is TrashDocumentFragment -> {
                fragment.refreshItems()
            }
            is TrashNotesFragment -> {
                fragment.refreshItems()
            }
        }
    }


    override fun onPause() {
        super.onPause()
        if (trashDialog != null) {
            trashDialog!!.dialog.dismiss()
            isTrashDialogShown = false
        }
    }


    override fun onBackPressed() {
        if (isDeleteOrRestore) {

            if (AdsManager(this).isNeedToShowAds() && isOnline()) {
                isInterstitialShown = true
                isShowInterstitialAd{
                    isInterstitialShown = false
                    isDeleteOrRestore=false
                    finish()
                }

            } else {
                isInterstitialShown = false
                isDeleteOrRestore=false
                finish()
            }
        } else {
            finish()
        }

    }

}