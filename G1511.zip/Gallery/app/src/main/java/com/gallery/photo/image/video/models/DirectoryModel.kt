package com.gallery.photo.image.video.models

import com.bumptech.glide.signature.ObjectKey

data class DirectoryModel(
    var id: Long?,
    var path: String,
    var tmb: String,
    var name: String,
    var mediaCnt: Int,
    var modified: Long,
    var taken: Long,
    var size: Long,
    var location: Int,
    var types: Int,
    var sortValue: String,

    // used with "Group direct subfolders" enabled
    var subfoldersCount: Int = 0,
    var subfoldersMediaCount: Int = 0,
    var containsMediaFilesDirectly: Boolean = true
) {

    constructor() : this(null, "", "", "", 0, 0L, 0L, 0L, 0, 0, "", 0, 0)


    fun getKey() = ObjectKey("$path-$modified")
}
