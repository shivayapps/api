package com.gallery.photo.image.video.dialog

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Environment
import android.os.Parcelable
import android.util.DisplayMetrics
import android.view.View.GONE
import android.view.ViewGroup
import android.view.Window
import androidx.recyclerview.widget.LinearLayoutManager
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.BaseSimpleActivity
import com.gallery.photo.image.video.adapters.FilepickerFavoritesAdapter
import com.gallery.photo.image.video.adapters.FilepickerItemsAdapter
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.helpers.ensureBackgroundThread
import com.gallery.photo.image.video.models.FileDirItem
import com.gallery.photo.image.video.views.Breadcrumbs
import kotlinx.android.synthetic.main.dialog_filepicker.view.*
import java.io.File
import java.util.*


/**
 * The only filepicker constructor with a couple optional parameters
 *
 * @param activity has to be activity to avoid some Theme.AppCompat issues
 * @param currPath initial path of the dialog, defaults to the external storage
 * @param pickFile toggle used to determine if we are picking a file or a folder
 * @param showHidden toggle for showing hidden items, whose name starts with a dot
 * @param showFAB toggle the displaying of a Floating Action Button for creating new folders
 * @param callback the callback used for returning the selected file/folder
 */
class FilePickerDialog(
    val activity: BaseSimpleActivity,
    var currPath: String = Environment.getExternalStorageDirectory().toString(),
    val pickFile: Boolean = true,
    var showHidden: Boolean = false,
    val showFAB: Boolean = false,
    val canAddShowHiddenButton: Boolean = false,
    val forceShowRoot: Boolean = false,
    val showFavoritesButton: Boolean = false,
    val callback: (pickedPath: String) -> Unit
) : Breadcrumbs.BreadcrumbsListener {

    private var mFirstUpdate = true
    private var isFabClicked = false
    private var mPrevPath = ""
    private var mScrollStates = HashMap<String, Parcelable>()
    private val mDateFormat = activity.baseConfig.dateFormat
    private val mTimeFormat = activity.getTimeFormat()

    private lateinit var mDialog: Dialog
    private var mDialogView = activity.layoutInflater.inflate(R.layout.dialog_filepicker, null)

    init {
        if (!activity.getDoesFilePathExist(currPath)) {
            currPath = activity.internalStoragePath
        }

        if (!activity.getIsPathDirectory(currPath)) {
            currPath = currPath.getParentPath()
        }

        // do not allow copying files in the recycle bin manually
        if (currPath.startsWith(activity.filesDir.absolutePath)) {
            currPath = activity.internalStoragePath
        }

        mDialogView.filepicker_breadcrumbs.apply {
            listener = this@FilePickerDialog
            updateFontSize(activity.getTextSize())
            updateColor(R.color.black)
        }


        mDialog = Dialog(activity)
        mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        mDialog.setCancelable(false)
        mDialog.setContentView(mDialogView)
        mDialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        mDialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        var mHeight = 0
        try {
            val displayMetrics = DisplayMetrics()
            activity.windowManager.defaultDisplay!!.getMetrics(displayMetrics)
            mHeight = displayMetrics.heightPixels

        } catch (i: java.lang.Exception) {
        }
        mDialog.window!!.getAttributes().height = (mHeight * 0.85).toInt()
        tryUpdateItems()
        setupFavorites()


//        val font = Typeface.createFromAsset(activity.assets, "fonts/avenirltpromedium.otf")
//        mDialogView.tvTitle.typeface = font
        mDialogView.ivClose.setOnClickListener {
            mDialog.dismiss()
            callback("dismiss")
        }
        mDialogView.tvDone.setOnClickListener {
            verifyPath()
        }
        mDialogView.ivHide.setOnClickListener {
            if (!isFabClicked) {
                isFabClicked = true
                showHidden = true
                tryUpdateItems()
                mDialogView.ivHide.setImageDrawable(activity.resources.getDrawable(R.drawable.ic_hide))
            } else {
                isFabClicked = false
                showHidden = false
                tryUpdateItems()
                mDialogView.ivHide.setImageDrawable(activity.resources.getDrawable(R.drawable.ic_unhide_vector))
            }
        }

        mDialog.show()
    }

    private fun getTitle() = if (pickFile) R.string.select_file else R.string.select_folder


    private fun tryUpdateItems() {
        ensureBackgroundThread {
            getItems(currPath) {
                activity.runOnUiThread {
                    updateItems(it as ArrayList<FileDirItem>)
                }
            }
        }
    }

    private fun updateItems(items: ArrayList<FileDirItem>) {
        if (!containsDirectory(items) && !mFirstUpdate && !pickFile && !showFAB) {
            verifyPath()
            return
        }

        var sortedItems = items.sortedWith(compareBy({ !it.isDirectory }, { it.name.toLowerCase() }))
        sortedItems = sortedItems.filter { it.isDirectory }
        val adapter = FilepickerItemsAdapter(activity, sortedItems, mDialogView.filepicker_list) {
            if ((it as FileDirItem).isDirectory) {
                activity.handleLockedFolderOpening(it.path) { success ->
                    if (success) {
                        currPath = it.path
                        tryUpdateItems()
                    }
                }
            } else if (pickFile) {
                currPath = it.path
                verifyPath()
            }
        }

        val layoutManager = mDialogView.filepicker_list.layoutManager as LinearLayoutManager
        mScrollStates[mPrevPath.trimEnd('/')] = layoutManager.onSaveInstanceState()!!

        mDialogView.apply {
            filepicker_list.adapter = adapter
            ll_progress.visibility = GONE
            filepicker_breadcrumbs.setBreadcrumb(currPath)
            filepicker_fastscroller.setViews(filepicker_list) {
                filepicker_fastscroller.updateBubbleText(sortedItems.getOrNull(it)?.getBubbleText(context, mDateFormat, mTimeFormat) ?: "")
            }

            filepicker_list.scheduleLayoutAnimation()
            layoutManager.onRestoreInstanceState(mScrollStates[currPath.trimEnd('/')])
            filepicker_list.onGlobalLayout {
                filepicker_fastscroller.setScrollToY(filepicker_list.computeVerticalScrollOffset())
            }
        }

        mFirstUpdate = false
        mPrevPath = currPath
    }

    private fun verifyPath() {
        if (activity.isPathOnOTG(currPath)) {
            val fileDocument = activity.getSomeDocumentFile(currPath) ?: return
            if ((pickFile && fileDocument.isFile) || (!pickFile && fileDocument.isDirectory)) {
                sendSuccess()
            }
        } else {
            val file = File(currPath)
            if ((pickFile && file.isFile) || (!pickFile && file.isDirectory)) {
                sendSuccess()
            }
        }
    }

    private fun sendSuccess() {
        currPath = if (currPath.length == 1) {
            currPath
        } else {
            currPath.trimEnd('/')
        }
        callback(currPath)
        mDialog.dismiss()
    }

    private fun getItems(path: String, callback: (List<FileDirItem>) -> Unit) {
        if (activity.isPathOnOTG(path)) {
            activity.getOTGItems(path, showHidden, false, callback)
        } else {
            val lastModifieds = activity.getFolderLastModifieds(path)
            getRegularItems(path, lastModifieds, callback)
        }
    }

    private fun getRegularItems(path: String, lastModifieds: HashMap<String, Long>, callback: (List<FileDirItem>) -> Unit) {
        val items = ArrayList<FileDirItem>()
        val base = File(path)
        val files = base.listFiles()
        if (files == null) {
            callback(items)
            return
        }

        for (file in files) {
            if (!showHidden && file.name.startsWith('.')) {
                continue
            }

            val curPath = file.absolutePath
            val curName = curPath.getFilenameFromPath()
            val size = file.length()
            var lastModified = lastModifieds.remove(curPath)
            val isDirectory = if (lastModified != null) false else file.isDirectory
            if (lastModified == null) {
                lastModified = 0    // we don't actually need the real lastModified that badly, do not check file.lastModified()
            }

            val children = if (isDirectory) file.getDirectChildrenCount(showHidden) else 0
            items.add(FileDirItem(curPath, curName, isDirectory, children, size, lastModified))
        }
        items.filter { File(it.path).isDirectory }
        callback(items)
    }

    private fun containsDirectory(items: List<FileDirItem>) = items.any { it.isDirectory }

    private fun setupFavorites() {
        FilepickerFavoritesAdapter(activity, activity.baseConfig.favorites.toMutableList(), mDialogView.filepicker_favorites_list) {
            currPath = it as String
            verifyPath()
        }.apply {
            mDialogView.filepicker_favorites_list.adapter = this
        }
    }

    private fun showFavorites() {
        mDialogView.apply {
            filepicker_favorites_holder.beVisible()
            filepicker_files_holder.beGone()
            val drawable = activity.resources.getColoredDrawableWithColor(R.drawable.ic_folder_vector, activity.getAdjustedPrimaryColor().getContrastColor())
//            filepicker_fab_show_favorites.setImageDrawable(drawable)
        }
    }

    private fun hideFavorites() {
        mDialogView.apply {
            filepicker_favorites_holder.beGone()
            filepicker_files_holder.beVisible()
            val drawable = activity.resources.getColoredDrawableWithColor(R.drawable.ic_star_on_vector, activity.getAdjustedPrimaryColor().getContrastColor())
//            filepicker_fab_show_favorites.setImageDrawable(drawable)
        }
    }

    override fun breadcrumbClicked(id: Int) {
        if (id == 0) {
/*            StoragePickerDialog(activity, currPath, forceShowRoot, true) {
            }*/
            if (currPath != activity.internalStoragePath) {
                currPath = activity.internalStoragePath
                tryUpdateItems()
            }
        } else {
            val item = mDialogView.filepicker_breadcrumbs.getChildAt(id).tag as FileDirItem
            if (currPath != item.path.trimEnd('/')) {
                currPath = item.path
                tryUpdateItems()
            }
        }
    }
}
