package com.gallery.photo.image.video.Camera;

import android.view.View;

public interface onRecyclerClickListener {
    void setOnItemClickListener(int i, View view);
}
