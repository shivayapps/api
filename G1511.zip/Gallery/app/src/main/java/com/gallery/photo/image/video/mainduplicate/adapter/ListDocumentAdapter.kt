package com.gallery.photo.image.video.mainduplicate.adapter

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityOptionsCompat
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.mainduplicate.activity.previewactivities.PreviewDocumentActivity
import com.gallery.photo.image.video.mainduplicate.callbacks.MarkedListener
import com.gallery.photo.image.video.mainduplicate.model.IndividualGroupModel
import com.gallery.photo.image.video.mainduplicate.model.ItemDuplicateModel
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions
import com.gallery.photo.image.video.mainduplicate.utils.MyUtils
import com.gallery.photo.image.video.mainduplicate.utils.ShareConstants

class ListDocumentAdapter(
    var listDocumentAdapterContext: Context,
    var listDocumentAdapterActivity: Activity,
    var documentsMarkedListener: MarkedListener,
    var individualGroupDocuments: IndividualGroupModel,
    var document: List<ItemDuplicateModel>,
    var parentCheckbox: CheckBox
) : RecyclerView.Adapter<ListDocumentAdapter.DocumentViewHolder>() {

    var inflater: LayoutInflater = listDocumentAdapterContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
    var totalNumberOfflineInSet = 0

    class DocumentViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var documentCheckbox: CheckBox = itemView.findViewById<View>(R.id.documentcheckbox) as CheckBox
        var documentFileName: TextView = itemView.findViewById(R.id.fileName)
        var documentFilePath: TextView = itemView.findViewById(R.id.filePath)
        var documentFileSize: TextView = itemView.findViewById(R.id.fileSize)
        var imageView: ImageView = itemView.findViewById(R.id.documentFile)
        var linearLayout: LinearLayout = itemView.findViewById(R.id.linear_documents_click)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DocumentViewHolder {
        return DocumentViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.row_list_of_document_files_item, parent, false)
        )
    }

    override fun onBindViewHolder(holder: DocumentViewHolder, position: Int) {
        val lDocumentItem = document[position]
        holder.documentFileName.text = GlobalVarsAndFunctions.getFileName(lDocumentItem.filePath)
        holder.documentFileSize.text = ShareConstants.getReadableFileSize(lDocumentItem.sizeOfTheFile)
        holder.documentFilePath.text = lDocumentItem.filePath
        holder.documentCheckbox.isChecked = lDocumentItem.isFileCheckBox
        holder.imageView.setOnClickListener {
            if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
                return@setOnClickListener
            }
            ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
            val intent = Intent(listDocumentAdapterContext, PreviewDocumentActivity::class.java)
            val bundle = Bundle()
            bundle.putSerializable("documentFile", lDocumentItem)
            intent.putExtras(bundle)
            intent.putExtra("totalNumberOfFiles", totalNumberOfflineInSet)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            listDocumentAdapterActivity.startActivity(intent, ActivityOptionsCompat.makeCustomAnimation(listDocumentAdapterContext, R.anim.slide_from_right, R.anim.slide_from_left).toBundle())
        }
        holder.linearLayout.setOnClickListener {
            if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
                return@setOnClickListener
            }
            ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
            val intent = Intent(listDocumentAdapterContext, PreviewDocumentActivity::class.java)
            val bundle = Bundle()
            bundle.putSerializable("documentFile", lDocumentItem)
            intent.putExtras(bundle)
            intent.putExtra("totalNumberOfFiles", totalNumberOfflineInSet)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            listDocumentAdapterActivity.startActivity(intent, ActivityOptionsCompat.makeCustomAnimation(listDocumentAdapterContext, R.anim.slide_from_right, R.anim.slide_from_left).toBundle())
        }
        holder.documentCheckbox.setOnCheckedChangeListener { buttonView: CompoundButton, isChecked: Boolean ->
            buttonView.setOnClickListener {
                lDocumentItem.isFileCheckBox = isChecked
                var selectCount = 0
                val numOffline = itemCount
                if (lDocumentItem.isFileCheckBox) {
                    for (i in 0 until itemCount) {
                        if (document[i].isFileCheckBox) {
                            selectCount++
                        }
                    }
                    if (selectCount != numOffline) {
                        GlobalVarsAndFunctions.file_to_be_deleted_documents.add(lDocumentItem)
                        GlobalVarsAndFunctions.addSizeDocuments(lDocumentItem.sizeOfTheFile)
                        documentsMarkedListener.updateMarked()
                        individualGroupDocuments.isCheckBox = true
                        parentCheckbox.isChecked = true
                    }
                } else {
                    GlobalVarsAndFunctions.file_to_be_deleted_documents.remove(lDocumentItem)
                    GlobalVarsAndFunctions.subSizeDocuments(lDocumentItem.sizeOfTheFile)
                    documentsMarkedListener.updateMarked()
                }
                if (selectCount < numOffline - 1) {
                    parentCheckbox.isChecked = false
                    individualGroupDocuments.isCheckBox = false
                } else {
                    parentCheckbox.isChecked = true
                    individualGroupDocuments.isCheckBox = true
                }
                if (numOffline == selectCount) {
                    MyUtils.showToastMsg(
                        listDocumentAdapterContext,
                        listDocumentAdapterContext.getString(R.string.error_not_select_all_document_in_same)
                    )
                    lDocumentItem.isFileCheckBox = false
                    holder.documentCheckbox.isChecked = false
                    return@setOnClickListener
                }
                lDocumentItem.isFileCheckBox = isChecked
            }
        }
    }

    override fun getItemCount(): Int {
        totalNumberOfflineInSet = document.size
        return totalNumberOfflineInSet
    }

}