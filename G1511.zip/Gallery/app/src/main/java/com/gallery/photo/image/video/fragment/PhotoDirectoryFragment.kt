package com.gallery.photo.image.video.fragment

import android.app.ProgressDialog
import android.content.*
import android.content.res.Resources
import android.os.*
import android.util.Log
import android.util.TypedValue
import android.view.*
import android.view.View.GONE
import android.view.View.VISIBLE
import android.widget.*
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.recyclerview.widget.RecyclerView
import com.example.jdrodi.utilities.hideKeyboard
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.*
import com.gallery.photo.image.video.adapter.DirectoryAdapter
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.utilities.addEvent
import com.gallery.photo.image.video.dialog.CreateNewFolderDialog
import com.gallery.photo.image.video.dialog.FilePickerDialog
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.interfaces.DirectoryOperationsListener
import com.gallery.photo.image.video.models.Directory
import com.gallery.photo.image.video.models.Medium
import com.gallery.photo.image.video.models.ThumbnailItem
import com.gallery.photo.image.video.models.UData
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.activity.BaseSimpleActivity
import com.gallery.photo.image.video.helpers.*
import com.gallery.photo.image.video.models.FileDirItem
import com.gallery.photo.image.video.views.MyGridLayoutManager
import com.gallery.photo.image.video.views.MyRecyclerView
import kotlinx.android.synthetic.main.activity_main_new.*
import kotlinx.android.synthetic.main.fragment_photo_directory.*
import kotlinx.android.synthetic.main.fragment_photo_directory.directories_empty_placeholder
import kotlinx.android.synthetic.main.fragment_photo_directory.directories_empty_placeholder_2
import kotlinx.android.synthetic.main.fragment_photo_directory.directories_grid
import kotlinx.android.synthetic.main.fragment_photo_directory.directories_refresh_layout
import kotlinx.android.synthetic.main.fragment_photo_directory.directories_vertical_fastscroller
import org.jetbrains.anko.displayMetrics
import java.io.File
import java.util.*
import kotlin.collections.ArrayList
import kotlin.math.roundToInt


class PhotoDirectoryFragment : BaseFragment(), DirectoryOperationsListener {


    private val PICK_MEDIA = 2
    private val PICK_WALLPAPER = 3
    private val LAST_MEDIA_CHECK_PERIOD = 3000L

    private var mIsPickImageIntent = true
    private var mIsPickVideoIntent = false
    private var mIsGetImageContentIntent = false
    private var mIsGetVideoContentIntent = false
    private var mIsGetAnyContentIntent = false
    private var mIsSetWallpaperIntent = false
    private var mAllowPickingMultiple = false
    private var mIsThirdPartyIntent = false

    private var mLoadedInitialPhotos = false
    private var mIsPasswordProtectionPending = false
    private var mWasProtectionHandled = false
    private var mShouldStopFetching = false
    private var mIsSearchOpen = false
    private var mWasDefaultFolderChecked = false
    private var mLatestMediaId = 0L
    private var mLatestMediaDateId = 0L
    private var mCurrentPathPrefix = ""                 // used at "Group direct subfolders" for navigation
    private var mOpenedSubfolders = arrayListOf("")     // used at "Group direct subfolders" for navigating Up with the back button
    private var mDateFormat = ""
    private var mTimeFormat = ""
    private var mLastMediaHandler = Handler(Looper.getMainLooper())
    private var mTempShowHiddenHandler = Handler(Looper.getMainLooper())
    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mSearchMenuItem: MenuItem? = null
    private var mLastMediaFetcher: MediaFetcher? = null
    public var mDirs = ArrayList<Directory>()
    var mIsGettingDirs = false
    private var mStoredAnimateGifs = true
    private var mStoredCropThumbnails = true
    private var mStoredScrollHorizontally = true
    private var mStoredTextColor = 0
    private var mStoredAdjustedPrimaryColor = 0
    private var mStoredStyleString = ""
    var isCreateNewFolderDialogClicked = false
    var mProgressDailog: ProgressDialog? = null

    override var mLastClickTime: Long = 0
    override var mMinDuration = 1500
    var isFirstTimeAdShow = false
    var isShowInfo = false
    var refreshMediaBroadcast = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            Log.d("554654", "onReceive: --> Media Refresh intent" + intent!!.action)
            if (intent!!.action == photoRefreshActionName) {
//                SavePhotoDirectoryAsynctask.isPostExecute = false
                Log.d("554654", "onReceive: --> Media Refresh receiver")
                try {
                    if (isAdded) {
                        if (requireActivity() != null) {
                            requireActivity().runOnUiThread {
                                tryLoadGallery()
                            }
                        }
                    }
                } catch (e: Exception) {
                }
            }
        }

    }

    companion object {
        var isColumnCountChange = false
        var isSortingChange = false
        var isNeedToRefresh = false
        var isPostExecute = false
        var mMedia = ArrayList<ThumbnailItem>()
        fun getInstance(position: Int): Fragment {
            val f: PhotoDirectoryFragment = PhotoDirectoryFragment()
            val args: Bundle = Bundle()
            args.putInt("position", position)
            f.arguments = args
            return f
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requireContext().addEvent(javaClass.simpleName)
        LocalBroadcastManager.getInstance(requireContext()).registerReceiver(refreshMediaBroadcast, IntentFilter(photoRefreshActionName))
    }


    override fun initView() {
//        if (!MainActivity.isAdLoaded) {
//            var msg = mContext.getString(R.string.please_wait)
//            if (AdsManager(requireActivity()).isNeedToShowAds() && requireContext().isOnline()) {
//                msg = getString(R.string.msg_ads_loading)
//            }
//            if (MainActivity.interstitialAdShow != null) {
//                if (requireActivity() is MainActivity) {
//                    (requireActivity() as MainActivity).showProgress(msg)
//                }
//                Handler(Looper.getMainLooper()).postDelayed({
//                    if (isAdded) {
//                        requireActivity().runOnUiThread {
//                            if (requireActivity() is MainActivity) {
//                                (requireActivity() as MainActivity).dismissProgress()
//                            }
//                            if (!isFirstTimeAdShow && !MainActivity.isAdLoaded) {
//                                isFirstTimeAdShow = true
//                                if (MainActivity.interstitialAdShow != null && AdsManager(requireActivity()).isNeedToShowAds() && requireContext().isOnline()) {
//                                    MainActivity.isAdLoaded = true
//                                    Log.d("TAG898959", "onResume: Ad Load show")
//                                    if (!requireContext().config.isAppInBackGround) {
//                                        MainActivity.interstitialAdShow!!.show(requireActivity())
//                                    }
//                                }
//                            }
//                        }
//                    }
//                }, 2000)
//            }
//        }

        directories_refresh_layout.setOnRefreshListener {
            if (requireActivity().findViewById<ImageView>(R.id.imgClose) != null)
                requireActivity().findViewById<ImageView>(R.id.imgClose).performClick()
            getDirectories()
        }
        tryLoadGallery()

        directories_grid.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                super.onScrollStateChanged(recyclerView, newState)
                when (newState) {

                    RecyclerView.SCROLL_STATE_DRAGGING -> {
                        if (requireActivity().findViewById<EditText>(R.id.etSearch).visibility == VISIBLE) {
                            requireActivity().hideKeyboard(requireActivity().findViewById<EditText>(R.id.etSearch))
                            requireActivity().findViewById<EditText>(R.id.etSearch).clearFocus()
                        }
                    }
                }
            }
        })
        AsyncBackgroundWork({}, {
            if (isAdded && !mContext.config.isAlreadyHiddenCountedBefore8_1) {
                mContext.config.isAlreadyHiddenCountedBefore8_1 = true
//                var videoData = mContext.uDataDao.get(HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION)
//                var photoData = mContext.uDataDao.get(HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION)
//                if (photoData != null && videoData != null && photoData!!.titleValue) {
//                    mContext.config.hidePhotoCountForSubscription = photoData!!.titleValue
//                    mContext.config.hideVideoCountForSubscription = videoData!!.titleValue
//                } else {
                var totalImagesCount = 0
                var totalVideosCount = 0
                if (isAdded) {
                    requireContext().getCachedHiddenDirectories(false, false, forceShowHidden = true) { it ->
                        var dirList = it

                        dirList.forEach { directory ->
                            if (isAdded) {
                                val mediaFetcher = MediaFetcher(requireContext())
                                val folderGrouping = mContext.config.getFolderGrouping(directory.path)
                                val fileSorting = mContext.config.getFolderSorting(directory.path)
                                var getProperDateTaken = fileSorting and SORT_BY_DATE_TAKEN != 0 ||
                                        folderGrouping and GROUP_BY_DATE_TAKEN_DAILY != 0 ||
                                        folderGrouping and GROUP_BY_DATE_TAKEN_MONTHLY != 0

                                val getProperLastModified = fileSorting and SORT_BY_DATE_MODIFIED != 0 ||
                                        folderGrouping and GROUP_BY_LAST_MODIFIED_DAILY != 0 ||
                                        folderGrouping and GROUP_BY_LAST_MODIFIED_MONTHLY != 0
                                val getProperFileSize = fileSorting and SORT_BY_SIZE != 0
                                val getVideoDurations = mContext.config.showThumbnailVideoDuration
                                val lastModifieds = if (getProperLastModified) mediaFetcher.getLastModifieds() else java.util.HashMap()
                                val dateTakens = if (getProperDateTaken) mediaFetcher.getDateTakens() else java.util.HashMap()
                                val newMedia = mediaFetcher.getFilesFrom(
                                    directory.path, false, false, getProperDateTaken, getProperLastModified, getProperFileSize,
                                    ArrayList<String>(), getVideoDurations, true, lastModifieds, dateTakens
                                )
                                newMedia.forEach {
                                    if (it.type == TYPE_IMAGES || it.type == TYPE_GIFS)
                                        totalImagesCount++
                                    else if (it.type == TYPE_VIDEOS)
                                        totalVideosCount++
                                }
                            }
                        }

                    }
                }

                if (isAdded) {
                    requireContext().getCachedFakeVaultDirectories(forceShowHidden = true) {
                        var dirList = it

                        dirList.forEach { directory ->
                            if (isAdded) {
                                var media = requireContext().fakeVaultMediumDao.getAllMediaFromPath(directory.path) as java.util.ArrayList<Medium>
                                media.forEach {
                                    if (it.type == TYPE_IMAGES || it.type == TYPE_GIFS)
                                        totalImagesCount++
                                    else if (it.type == TYPE_VIDEOS)
                                        totalVideosCount++
                                }
                            }
                        }

                    }
                }
                if (isAdded) {
                    val videoData = mContext.uDataDao.get(HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION)
                    if (videoData == null) {
                        mContext.config.hideVideoCountForSubscription = totalVideosCount
                        mContext.uDataDao.add(UData(null, HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION, totalVideosCount))
                    } else {
                        if (videoData!!.titleValue != 0 && videoData!!.titleValue > totalVideosCount) {
                            mContext.config.hideVideoCountForSubscription = videoData!!.titleValue
                        } else if (videoData!!.titleValue != 0 && videoData!!.titleValue < totalVideosCount) {
                            mContext.config.hideVideoCountForSubscription = totalVideosCount
                            mContext.uDataDao.updateCount(HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION, mContext.config.hideVideoCountForSubscription)
                        } else if (videoData!!.titleValue != 0) {
                            mContext.config.hideVideoCountForSubscription = videoData!!.titleValue
                        }
                        //                    mContext.uDataDao.updateCount(HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION, mContext.config.hideVideoCountForSubscription)
                    }
                }
                if (isAdded) {
                    val photoData = mContext.uDataDao.get(HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION)
                    if (photoData == null) {
                        mContext.config.hidePhotoCountForSubscription = totalImagesCount
                        try {
                            mContext.uDataDao.add(UData(null, HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION, totalImagesCount))
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    } else {

                        if (photoData!!.titleValue != 0 && photoData!!.titleValue > totalImagesCount) {
                            mContext.config.hidePhotoCountForSubscription = photoData!!.titleValue
                        } else if (photoData!!.titleValue != 0 && photoData!!.titleValue < totalImagesCount) {
                            mContext.config.hidePhotoCountForSubscription = totalImagesCount
                            mContext.uDataDao.updateCount(HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION, mContext.config.hidePhotoCountForSubscription)
                        } else if (photoData!!.titleValue != 0) {
                            mContext.config.hidePhotoCountForSubscription = photoData!!.titleValue
                        }
                        //                    mContext.uDataDao.updateCount(HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION, mContext.config.hidePhotoCountForSubscription)
                    }
                }
            }

            Log.d(TAG, "initView: hidePhotoCountForSubscription " + mContext.config.hidePhotoCountForSubscription)
            Log.d(TAG, "initView: hideVideoCountForSubscription " + mContext.config.hideVideoCountForSubscription)
//            }
        }, {})


    }

    private fun setupLatestMediaId() {
        if (isAdded) {
            ensureBackgroundThread {
                if (isAdded) {
                    if (requireContext().hasPermission(PERMISSION_READ_STORAGE)) {
                        if (isAdded) {
                            mLatestMediaId = requireContext().getLatestMediaId()
                            mLatestMediaDateId = requireContext().getLatestMediaByDateId()
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()

        requireActivity().findViewById<TextView>(R.id.tvHeaderTitle).visibility = View.VISIBLE
        requireActivity().findViewById<TextView>(R.id.tvHeaderTitle).text = mContext.getString(R.string.title_my_photo)
        requireActivity().findViewById<ImageView>(R.id.imgSearch).visibility = View.VISIBLE
        requireActivity().findViewById<View>(R.id.clGiftIcon).visibility = View.GONE
        requireActivity().findViewById<View>(R.id.adViewContainer).visibility = View.GONE
        requireActivity().findViewById<LinearLayout>(R.id.layOpt).visibility = View.VISIBLE
        requireActivity().findViewById<ImageView>(R.id.imgSearch).setImageDrawable(ContextCompat.getDrawable(requireContext(), R.drawable.ic_gallery_search))
        requireActivity().findViewById<EditText>(R.id.etSearch).hint = getString(R.string.msg_search_photo_by_name)
//        etSearch.visibility= View.VISIBLE

        if (isColumnCountChange && requireContext().config.viewTypeFolders == VIEW_TYPE_GRID) {
            isColumnCountChange = false
            setupLayoutManager()
            columnCountChanged()

        }
        if (isSortingChange) {
            isSortingChange = false
            setupAdapter(mDirs)
        }
        if (MainActivity.isNeedToRefresh || isNeedToRefresh) {
            MainActivity.isNeedToRefresh = false
            isNeedToRefresh = false
            getDirectories()
        }

    }

    override fun getLayoutRes(): Int? {
        return R.layout.fragment_photo_directory
    }

    private fun tryLoadGallery() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!(requireActivity() as BaseSimpleActivity).checkPermissionabove11()) {
                (requireActivity() as MainBaseActivity).showGetPermissionDialog11()
            } else {
                setupLayoutManager()
                getDirectories()
            }

        } else {
            (requireActivity() as BaseSimpleActivity).handlePermission(PERMISSION_WRITE_STORAGE) {
                if (it) {
                    getDirectories()
                } else {
                    requireActivity().toast(R.string.no_storage_permissions)
                    requireActivity().finish()
                }
            }
        }
    }


    private fun getDirectories() {
        if (isAdded) {
            Log.d("Tag Get Directory ", mIsGettingDirs.toString())
            if (mIsGettingDirs) {
                return
            }
            mShouldStopFetching = true
            mIsGettingDirs = true
            setupLatestMediaId()
            if (getRecyclerAdapter() != null)
                getRecyclerAdapter()!!.dismissProgress()
            requireContext().getCachedPicturesDirectories {
                Log.d("554654", "getDirectories: gotDirectories called")
                if (isAdded)
                    gotDirectories(it.filter { it.mediaCnt != 0 } as ArrayList<Directory>)
            }

        }
    }

    fun showProgress(msg: String) {
        if (mProgressDailog == null) {
            mProgressDailog = ProgressDialog(activity, R.style.MyAlertDialogNew)
            mProgressDailog!!.setMessage(msg)

            mProgressDailog!!.setCancelable(false)
            mProgressDailog!!.setProgressStyle(ProgressDialog.STYLE_SPINNER)
            mProgressDailog!!.show()
        }
    }

    fun dismissProgress() {
        requireActivity().runOnUiThread {
            if (mProgressDailog != null && mProgressDailog!!.isShowing) {
                mProgressDailog!!.dismiss()
                mProgressDailog = null
            }
        }
    }

    private fun gotDirectories(newDirs: ArrayList<Directory>) {
        mIsGettingDirs = false
        mShouldStopFetching = false
        directories_grid.setItemViewCacheSize(20)
        if (isAdded)
            setupLayoutManager()
        // if hidden item showing is disabled but all Favorite items are hidden, hide the Favorites folder
        if (!requireContext().config.shouldShowHidden) {
            val favoritesFolder = newDirs.firstOrNull { it.areFavorites() }
            if (favoritesFolder != null && favoritesFolder.tmb.getFilenameFromPath().startsWith('.')) {
                newDirs.remove(favoritesFolder)
            }
        }

        val dirs = requireContext().getSortedDirectories(newDirs)
        if (requireContext().config.groupDirectSubfolders) {
            mDirs = dirs.clone() as ArrayList<Directory>
        }

        requireActivity().runOnUiThread {
            if (directories_refresh_layout != null)
                directories_refresh_layout.isEnabled = true
            setupAdapter(dirs.clone() as ArrayList<Directory>)
        }

        mLastMediaFetcher?.shouldStop = true
        mLastMediaFetcher = MediaFetcher(requireContext())
        if (isAdded) {
            ensureBackgroundThread {
                newDirs.forEach {
                    if (isAdded) {
                        try {
                            requireContext().directoryDao.insert(it)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                }
            }
        }
        mLoadedInitialPhotos = true
//        checkLastMediaChanged()
        Thread {
            if (isAdded) {
                requireActivity().runOnUiThread {
                    if (directories_refresh_layout != null)
                        directories_refresh_layout.isRefreshing = false
                }
            }
        }.start()
        if (isAdded) {
            requireActivity().runOnUiThread {
                checkPlaceholderVisibility(mDirs)
                if (directories_refresh_layout != null)
                    directories_refresh_layout.isRefreshing = false
            }
        }
    }

    fun setupAdapter(dirs: ArrayList<Directory>, textToSearch: String = "", forceRecreate: Boolean = false) {
        if (isAdded) {
            requireActivity().runOnUiThread {
                if (dirs.size != 0 || isPostExecute)
                    if (ll_progress != null) {
                        ll_progress.visibility = GONE
                    }
                mDirs = dirs
                directories_refresh_layout.isRefreshing = false
                if (directories_grid != null && dirs.size > 0) {

                    checkPlaceholderVisibility(dirs)

                    val currAdapter = directories_grid.adapter
                    var distinctDirs = try {
                        dirs.distinctBy { it.path.getDistinctPath() }.toMutableList() as ArrayList<Directory>
                    } catch (e: java.lang.Exception) {
                        dirs
                    }

                    val sortedDirs = requireContext().getSortedDirectories(distinctDirs as ArrayList<Directory>)
                    var dirsToShow = requireContext().getDirsToShow(sortedDirs, mDirs, mCurrentPathPrefix).clone() as ArrayList<Directory>
                    dirsToShow.sortWith { o1, o2 ->
                        o1 as Directory
                        o2 as Directory
                        var result = when {
                            requireContext().config.directorySorting and SORT_BY_NAME != 0 -> {
                                o1.name.lowercase(Locale.getDefault()).compareTo(o2.name.lowercase(Locale.getDefault()))
                            }
                            requireContext().config.directorySorting and SORT_BY_DATE_MODIFIED != 0 -> (o1.modified).compareTo(o2.modified)
                            requireContext().config.directorySorting and SORT_BY_SIZE != 0 -> o1.mediaCnt.compareTo(o2.mediaCnt)
                            else -> o1.mediaCnt.compareTo(o2.mediaCnt)
                        }


                        if (requireContext().config.directorySorting and SORT_DESCENDING != 0) {
                            result *= -1
                        }
                        result
                    }

//                    if (dirsToShow.size > 0 && dirsToShow.any { it.path != getString(R.string.label_add_album) }) {
//
//                        dirsToShow.add(
//                            0,
//                            Directory(
//                                101,
//                                getString(R.string.label_add_album),
//                                getString(R.string.label_add_album),
//                                getString(R.string.label_add_album),
//                                mediaCnt = 4,
//                                modified = 1623827461000,
//                                taken = 1623827461000,
//                                size = 0,
//                                location = 1,
//                                types = 1,
//                                "0",
//                                subfoldersCount = 0,
//                                subfoldersMediaCount = 4,
//                                containsMediaFilesDirectly = true
//                            )
//                        )
//                    }
                    if (currAdapter == null || forceRecreate) {
                        val fastscroller = directories_vertical_fastscroller
                        DirectoryAdapter(
                            requireContext() as BaseSimpleActivity,
                            dirsToShow,
                            this,
                            directories_grid,
                            isPickIntent(requireActivity().intent) || isGetAnyContentIntent(requireActivity().intent),
                            false,
                            directories_refresh_layout,
                            fastscroller
                        ) {
                            val clickedDir = it as Directory
                            val path = clickedDir.path
                            if (clickedDir.subfoldersCount == 1 || !requireContext().config.groupDirectSubfolders) {
                                itemClicked(path)
                            } else {
                                mCurrentPathPrefix = path
                                mOpenedSubfolders.add(path)
                                setupAdapter(mDirs, "")
                            }
                        }.apply {
                            requireActivity().runOnUiThread {
                                directories_grid.adapter = this

                                if (requireContext().config.viewTypeFolders == VIEW_TYPE_LIST) {
                                    directories_grid.scheduleLayoutAnimation()
                                }
                            }
                        }
                    } else {
                        requireActivity().runOnUiThread {
                            if (textToSearch.isNotEmpty()) {
                                dirsToShow = dirsToShow.filter { !it.path.contains("Add Album") && it.name.contains(textToSearch, true) }.sortedBy { !it.name.startsWith(textToSearch, true) }
                                    .toMutableList() as ArrayList
                            }
                            checkPlaceholderVisibility(dirsToShow)

                            (directories_grid.adapter as? DirectoryAdapter)?.updateDirs(dirsToShow)
                        }
                    }
                } else
                    checkPlaceholderVisibility(dirs)


            }
        }
    }

    fun itemClicked(path: String) {
        if (requireActivity().findViewById<EditText>(R.id.etSearch).visibility == VISIBLE) {
            if (requireActivity().findViewById<ImageView>(R.id.imgClose) != null)
                requireActivity().findViewById<ImageView>(R.id.imgClose).performClick()
        }
        if (path == getString(R.string.label_add_album)) {
            if (!isCreateNewFolderDialogClicked) {
                isCreateNewFolderDialogClicked = true
                createNewFolder()
            }
        } else {
            if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
                return
            }
            mLastClickTime = SystemClock.elapsedRealtime()
            Log.d("TAG787878", "itemClicked: " + requireContext().config.isAnyOperationRunning)
            Log.d("TAG787878", "itemClicked: " + requireContext().config.lastDestinationPath)
            if (requireContext().config.isAnyOperationRunning && path == requireContext().config.lastDestinationPath) {
                requireActivity().toast(requireContext().getString(com.gallery.photo.image.video.R.string.msg_operation_already_running))
            } else {
                requireActivity().handleLockedFolderOpening(path) { success ->
                    if (success) {
                        Log.d("Tag", "clicked")
                        Intent(requireContext(), MediaActivity::class.java).apply {
                            putExtra(SKIP_AUTHENTICATION, true)
                            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
                            putExtra(DIRECTORY, path)
                            putExtra(SHOW_ONLY_HIDDEN, false)
                            handleMediaIntent(this)
                        }
                    }
                }
            }
        }
    }


    private fun createNewFolder() {

        FilePickerDialog(requireActivity() as BaseSimpleActivity, requireContext().internalStoragePath, false, requireContext().config.shouldShowHidden, false, true) {
            if (it != "dismiss") {
                isCreateNewFolderDialogClicked = false
                CreateNewFolderDialog(requireActivity() as BaseSimpleActivity, it) {
                    if (it != "dismiss") {
                        Log.d("CreatePath", "createNewFolder: -->new path  $it")
                        Log.d("CreatePath", "createNewFolder: -->new FolderName  " + it.substringAfterLast("/"))
                        if (!it.substringAfterLast("/").matches(Regex("^[^.]*\$"))) {

                            if (File(it).exists())
                                File(it).delete()
                            requireActivity().toast(getString(R.string.error_please_enter_valid_name))
                        } else {
                            requireContext().config.tempFolderPath = it
                            hideKeyboard()
                            isCreateNewFolderDialogClicked = false
                            startActivity(
                                Intent(context, AddImageInNewFolderNewActivity::class.java)
                                    .putExtra("FileDir", it)
                                    .putExtra("ViewPager_Position", 0)
                                    .putExtra("Album Name", it.substringAfterLast("/"))
                            )
                        }
                    } else {
                        isCreateNewFolderDialogClicked = false
                    }
                }
            } else {
                isCreateNewFolderDialogClicked = false
            }


        }
    }

    private fun getCurrentlyDisplayedDirs() = getRecyclerAdapter()?.dirs ?: ArrayList()

    private fun handleMediaIntent(intent: Intent) {
        intent.apply {
            if (mIsSetWallpaperIntent) {
                putExtra(SET_WALLPAPER_INTENT, true)
                launchActivityForResult(this, PICK_WALLPAPER)

            } else {
                putExtra(GET_IMAGE_INTENT, mIsPickImageIntent || mIsGetImageContentIntent)
                putExtra(GET_VIDEO_INTENT, mIsPickVideoIntent || mIsGetVideoContentIntent)
                putExtra(GET_ANY_INTENT, mIsGetAnyContentIntent)
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, mAllowPickingMultiple)
                launchActivityForResult(intent, PICK_MEDIA)
            }
        }
    }


    private fun initZoomListener() {
        if (requireContext().config.viewTypeFolders == VIEW_TYPE_GRID) {
            val layoutManager = directories_grid.layoutManager as MyGridLayoutManager
            mZoomListener = object : MyRecyclerView.MyZoomListener {
                override fun zoomIn() {
                    if (layoutManager.spanCount > 1) {
                        reduceColumnCount()
                        getRecyclerAdapter()?.finishActMode()
                    }
                }

                override fun zoomOut() {
                    if (layoutManager.spanCount < MAX_COLUMN_COUNT) {
                        increaseColumnCount()
                        getRecyclerAdapter()?.finishActMode()
                    }
                }
            }
        } else {
            mZoomListener = null
        }
    }

    private fun getFoldersWithMedia(path: String): HashSet<String> {
        val folders = HashSet<String>()
        try {
            val files = File(path).listFiles()
            if (files != null) {
                files.sortBy { !it.isDirectory }
                for (file in files) {
                    if (file.isDirectory && !file.startsWith("${requireContext().config.internalStoragePath}/Android")) {
                        folders.addAll(getFoldersWithMedia(file.absolutePath))
                    } else if (file.isFile && file.isMediaFile()) {
                        folders.add(file.parent ?: "")
                        break
                    }
                }
            }
        } catch (ignored: Exception) {
        }

        return folders
    }

    fun getRecyclerAdapter() = directories_grid.adapter as? DirectoryAdapter


    private fun checkPlaceholderVisibility(dirs: ArrayList<Directory>) {

        if (directories_empty_placeholder != null)
            directories_empty_placeholder.beVisibleIf(dirs.isEmpty() && mLoadedInitialPhotos)
        if (directories_empty_placeholder_2 != null) {
            directories_empty_placeholder_2.beGone()
        }
        if (mIsSearchOpen) {
            directories_empty_placeholder.text = getString(R.string.no_items_found)
            directories_empty_placeholder_2.beGone()
        } else if (dirs.isEmpty() && isAdded && requireContext().config.filterMedia == getDefaultFileFilter()) {
            directories_empty_placeholder.text = getString(R.string.no_media_with_filters)
            directories_empty_placeholder_2.text = getString(R.string.add_folder)
        } else {
            if (isAdded) {
                directories_empty_placeholder.text = getString(R.string.no_media_with_filters)
                directories_empty_placeholder_2.text = getString(R.string.change_filters_underlined)
            }
        }
        if (directories_empty_placeholder_2 != null) {
            directories_empty_placeholder_2.underlineText()
            directories_empty_placeholder_2.beGone()
        }
        if (directories_grid != null)
            directories_grid.beVisibleIf(directories_empty_placeholder.isGone())
        if (dirs.isEmpty()) {
            if (isAdded) {
                if (requireActivity() is MainActivity) {
                    (requireActivity() as MainActivity).showToolbar()
                }
            }
        }
        // TODO: 24/08/21 Info window changes
        if (isAdded) {
            if (requireActivity() is MainActivity) {
                if (requireActivity().viewPagerHome.currentItem == 0) {
                    if (dirs.isNotEmpty() && dirs.size > 2) {
//                        if (!requireContext().config.isDirectoryLongPressInfoShown) {
//                            if (!isShowInfo) {
//                                isShowInfo = true
//                                if (requireActivity().drawerLayout != null)
//                                    requireActivity().drawerLayout.closeDrawers()
//                                if (mContext.isTablet()) {
//                                    try {
//                                        img1.layoutParams.height = (requireActivity().displayMetrics.widthPixels / 3.2).toInt()
//                                        img1.layoutParams.width = (requireActivity().displayMetrics.widthPixels / 3.2).toInt()
//                                    } catch (e: Exception) {
//                                    }
//                                    img1.visibility = VISIBLE
//                                    val r: Resources = mContext.resources
//                                    var dimen = r.getDimension(R.dimen._25sdp)
//                                    if (mContext.isTablet())
//                                        dimen = r.getDimension(R.dimen._95sdp)
//                                    val px = TypedValue.applyDimension(
//                                        TypedValue.COMPLEX_UNIT_DIP, dimen, r.displayMetrics
//                                    ).roundToInt()
////                                    TapTargetView.showFor(requireActivity(),
////                                        // 2
////                                        TapTarget.forView(
////                                            img1, "",
////                                            getString(R.string.msg_image_tap_target_view)
////                                        )
////                                            .targetRadius(px / 4)
////                                            .cancelable(true)
////                                            .textColor(R.color.white)
////                                            .descriptionTextColor(R.color.white)
////                                            .descriptionTextAlpha(1f)
////                                            .tintTarget(false),
////                                        object : TapTargetView.Listener() {
////                                            override fun onTargetClick(view: TapTargetView) {
////                                                super.onTargetClick(view)
////                                                view.dismiss(true)
////                                                img1.visibility = GONE
////                                                requireContext().config.isDirectoryLongPressInfoShown = true
////                                            }
////
////                                            override fun onTargetCancel(view: TapTargetView?) {
////                                                super.onTargetCancel(view)
////                                                img1.visibility = GONE
////                                                requireContext().config.isDirectoryLongPressInfoShown = true
////                                            }
////                                        })
//                                } else {
//                                    img1.visibility = VISIBLE
////                                    TapTargetView.showFor(requireActivity(),
////                                        // 2
////                                        TapTarget.forView(
////                                            img1, "",
////                                            getString(R.string.msg_image_tap_target_view)
////                                        )
////                                            .cancelable(true)
////                                            .textColor(R.color.white)
////                                            .descriptionTextColor(R.color.white)
////                                            .descriptionTextAlpha(1f)
////                                            .tintTarget(false),
////                                        object : TapTargetView.Listener() {
////                                            override fun onTargetClick(view: TapTargetView) {
////                                                super.onTargetClick(view)
////                                                view.dismiss(true)
////                                                img1.visibility = GONE
////                                                requireContext().config.isDirectoryLongPressInfoShown = true
////                                            }
////
////                                            override fun onTargetCancel(view: TapTargetView?) {
////                                                super.onTargetCancel(view)
////                                                img1.visibility = GONE
////                                                requireContext().config.isDirectoryLongPressInfoShown = true
////                                            }
////                                        })
//                                }
//                            }
//                        }
                    }
                }
            }
        }
    }


    fun setupLayoutManager() {
        if (isAdded) {
            requireActivity().runOnUiThread(Runnable {
                if (isAdded) {
                    if (requireContext().config.viewTypeFolders == VIEW_TYPE_GRID) {
                        setupGridLayoutManager()
                    } else {
                        setupListLayoutManager()
                    }
                }
            })
        }
    }

    private fun setupGridLayoutManager() {
        if (isAdded) {
            val layoutManager = directories_grid.layoutManager as MyGridLayoutManager
            if (isAdded) {
                if (requireContext().config.scrollHorizontally) {
                    layoutManager.orientation = RecyclerView.HORIZONTAL
                } else {
                    layoutManager.orientation = RecyclerView.VERTICAL
                }
                layoutManager.spanCount = requireContext().config.dirColumnCnt
            }
        }
    }

    private fun setupListLayoutManager() {
        if (isAdded) {
            val layoutManager = directories_grid.layoutManager as MyGridLayoutManager
            layoutManager.spanCount = 1
            layoutManager.orientation = RecyclerView.VERTICAL

            mZoomListener = null
        }
    }


    private fun checkLastMediaChanged() {
        if (isAdded) {
            if (requireActivity().isDestroyed) {
                return
            }
            mLastMediaHandler.postDelayed({
                ensureBackgroundThread {
                    if (isAdded) {
                        val mediaId = requireContext().getLatestMediaId()
                        val mediaDateId = requireContext().getLatestMediaByDateId()
                        if (mLatestMediaId != mediaId || mLatestMediaDateId != mediaDateId) {
                            mLatestMediaId = mediaId
                            mLatestMediaDateId = mediaDateId
                            if (isAdded) {
                                requireActivity().runOnUiThread {
                                    getDirectories()
                                }
                            }
                        } else {
                            mLastMediaHandler.removeCallbacksAndMessages(null)
                            checkLastMediaChanged()
                        }
                    }
                }
            }, LAST_MEDIA_CHECK_PERIOD)
        }
    }


    override fun refreshItems() {
        getDirectories()
    }

    override fun deleteFolders(folders: ArrayList<File>) {
        try {
            val fileDirItems = folders.asSequence().filter { it.isDirectory }.map { FileDirItem(it.absolutePath, it.name, true) }.toMutableList() as ArrayList<FileDirItem>
            when {
                fileDirItems.isEmpty() -> return
                fileDirItems.size == 1 -> {
                    try {
                        if (isAdded)
                            mContext.toast(String.format(getString(R.string.deleting_folder), fileDirItems.first().name))
                    } catch (e: Exception) {
                        if (isAdded)
                            mContext.showErrorToast(e)
                    }
                }
                else -> {
                    val baseString = if (requireContext().config.useRecycleBin) R.plurals.moving_items_into_bin else R.plurals.delete_items
                    val deletingItems = resources.getQuantityString(baseString, fileDirItems.size, fileDirItems.size)
                    if (isAdded)
                        mContext.toast(deletingItems)
                }
            }

            val itemsToDelete = ArrayList<FileDirItem>()
            val filter = requireContext().config.filterMedia
            val showHidden = requireContext().config.shouldShowHidden
            fileDirItems.filter { it.isDirectory }.forEach {
                val files = File(it.path).listFiles()
                files?.filter {
                    it.absolutePath.isMediaFile() && (showHidden || !it.name.startsWith('.')) &&
                            ((it.isImageFast() && filter and TYPE_IMAGES != 0) ||
                                    (it.isVideoFast() && filter and TYPE_VIDEOS != 0) ||
                                    (it.isGif() && filter and TYPE_GIFS != 0) ||
                                    (it.isRawFast() && filter and TYPE_RAWS != 0) ||
                                    (it.isSvg() && filter and TYPE_SVGS != 0))
                }?.mapTo(itemsToDelete) { it.toFileDirItem(requireContext()) }
            }
//            deleteFilteredFileDirItems(itemsToDelete, folders)
            val pathsToDelete = ArrayList<String>()
            itemsToDelete.mapTo(pathsToDelete) { it.path }
            Log.d("hfdfadsfdsf", "deleteFolders: " + itemsToDelete.size)
            if (getRecyclerAdapter() != null) {
                getRecyclerAdapter()!!.finishActMode()
                getRecyclerAdapter()!!.dismissProgress()
            }
            if (isAdded) {
                (mContext as BaseSimpleActivity).movePathsInRecoverTrash(pathsToDelete, false, VaultFragment.isFakeVaultOpen) {
                    if (it) {
//                        deleteFilteredFileDirItems(itemsToDelete, folders).
                        val OTGPath = requireContext().config.OTGPath
                        ensureBackgroundThread {
                            folders.forEach {
                                Log.d("RefreshMedia1234", "updatePhotoVideoDirectoryPath: Called TYpe Image  ---> ")
                                if (isAdded) {
                                    requireActivity().updatePhotoVideoDirectoryPath(it.absolutePath, true, false)
                                }
                            }
                            folders.filter { !requireContext().getDoesFilePathExist(it.absolutePath, OTGPath) }.forEach {

                                requireContext().directoryDao.deleteDirPath(it.absolutePath)
                            }
                            if (isAdded) {
                                requireActivity().runOnUiThread {
                                    if (getRecyclerAdapter() != null) {
                                        getRecyclerAdapter()!!.finishActMode()
                                        getRecyclerAdapter()!!.dismissProgress()
                                    }
                                    refreshItems()
                                }
                            }


                            if (isAdded) {
                                if (requireContext().config.deleteEmptyFolders) {
                                    folders.filter { !it.absolutePath.isDownloadsFolder() && it.isDirectory && it.toFileDirItem(requireContext()).getProperFileCount(requireContext(), true) == 0 }
                                        .forEach {
                                            (requireActivity() as BaseSimpleActivity).tryDeleteFileDirItem(it.toFileDirItem(requireContext()), true, true) {

                                            }
                                        }
                                }
                            }
                        }
                    } else {
                        mContext.toast(R.string.unknown_error_occurred)
                    }
                }
            }
        } catch (e: Exception) {
        }

    }

    private fun deleteFilteredFileDirItems(fileDirItems: ArrayList<FileDirItem>, folders: ArrayList<File>) {
        val OTGPath = requireContext().config.OTGPath
        if (isAdded) {
            (requireActivity() as BaseSimpleActivity).deleteFiles(fileDirItems) {


                ensureBackgroundThread {
                    folders.forEach {
                        Log.d("RefreshMedia1234", "updatePhotoVideoDirectoryPath: Called TYpe Image  ---> ")
                        if (isAdded) {
                            requireActivity().updatePhotoVideoDirectoryPath(it.absolutePath, true, false)
                        }
                    }
                    folders.filter { !requireContext().getDoesFilePathExist(it.absolutePath, OTGPath) }.forEach {

                        requireContext().directoryDao.deleteDirPath(it.absolutePath)
                    }
                    if (isAdded) {
                        requireActivity().runOnUiThread {
                            if (getRecyclerAdapter() != null) {
                                getRecyclerAdapter()!!.finishActMode()
                                getRecyclerAdapter()!!.dismissProgress()
                            }
                            refreshItems()
                        }
                    }


                    if (isAdded) {
                        if (requireContext().config.deleteEmptyFolders) {
                            folders.filter { !it.absolutePath.isDownloadsFolder() && it.isDirectory && it.toFileDirItem(requireContext()).getProperFileCount(requireContext(), true) == 0 }.forEach {
                                (requireActivity() as BaseSimpleActivity).tryDeleteFileDirItem(it.toFileDirItem(requireContext()), true, true) {

                                }
                            }
                        }
                    }
                }
            }
        }
    }

    override fun recheckPinnedFolders() {
    }

    override fun updateDirectories(directories: ArrayList<Directory>) {
        ensureBackgroundThread {
            if (isAdded) {
                requireContext().storeDirectoryItems(directories)
                requireContext().removeInvalidDBDirectories()
            }
        }
    }


    private fun increaseColumnCount() {
        requireContext().config.dirColumnCnt = ++(directories_grid.layoutManager as MyGridLayoutManager).spanCount
        columnCountChanged()
    }

    private fun reduceColumnCount() {
        requireContext().config.dirColumnCnt = --(directories_grid.layoutManager as MyGridLayoutManager).spanCount
        columnCountChanged()
    }

    private fun columnCountChanged() {
        getRecyclerAdapter()?.apply {
            notifyItemRangeChanged(0, dirs.size)
        }
    }


    private fun isPickIntent(intent: Intent) = intent.action == Intent.ACTION_PICK

    private fun isGetContentIntent(intent: Intent) = intent.action == Intent.ACTION_GET_CONTENT && intent.type != null

    private fun isGetAnyContentIntent(intent: Intent) = isGetContentIntent(intent) && intent.type == "*/*"

}