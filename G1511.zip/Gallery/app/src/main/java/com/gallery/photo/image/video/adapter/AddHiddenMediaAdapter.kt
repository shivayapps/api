package com.gallery.photo.image.video.adapter

import android.app.ProgressDialog
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import com.bumptech.glide.Glide
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.FavouriteActivity
import com.gallery.photo.image.video.activity.MainActivity
import com.gallery.photo.image.video.activity.MediaActivity
import com.gallery.photo.image.video.database.FavouriteDBHelper
import com.gallery.photo.image.video.dialog.DeleteWithRememberDialog
import com.gallery.photo.image.video.dialog.MoveToAlertDialog
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.fragment.VaultFragment
import com.gallery.photo.image.video.interfaces.MediaOperationsListener
import com.gallery.photo.image.video.models.*
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.helpers.VIEW_TYPE_LIST
import com.gallery.photo.image.video.views.FastScroller
import com.gallery.photo.image.video.views.MyRecyclerView
import com.gallery.photo.image.video.activity.BaseSimpleActivity
import com.gallery.photo.image.video.dialog.PropertiesDialog
import com.gallery.photo.image.video.dialog.RenameDialog
import com.gallery.photo.image.video.dialog.RenameItemDialog
import com.gallery.photo.image.video.helpers.ensureBackgroundThread
import com.gallery.photo.image.video.models.FileDirItem
import kotlinx.android.synthetic.main.photo_item_grid.view.*
import kotlinx.android.synthetic.main.video_item_grid.view.*
import kotlinx.android.synthetic.main.photo_item_grid.view.media_item_holder
import kotlinx.android.synthetic.main.photo_item_grid.view.medium_check
import kotlinx.android.synthetic.main.photo_item_grid.view.medium_name
import kotlinx.android.synthetic.main.photo_item_grid.view.medium_thumbnail
import kotlinx.android.synthetic.main.thumbnail_section.view.*
import org.jetbrains.anko.toast
import java.util.LinkedHashSet

class AddHiddenMediaAdapter(
    activity: BaseSimpleActivity, var media: ArrayList<ThumbnailItem>, val listener: MediaOperationsListener?, val isAGetIntent: Boolean,
    val allowMultiplePicks: Boolean, val path: String, recyclerView: MyRecyclerView, fastScroller: FastScroller? = null, itemClick: (Any) -> Unit
) :
    MyRecyclerViewAdapter(activity, recyclerView, fastScroller, itemClick, true) {

    private val INSTANT_LOAD_DURATION = 2000L
    private val IMAGE_LOAD_DELAY = 100L
    private val ITEM_SECTION = 0
    private val ITEM_MEDIUM_VIDEO_PORTRAIT = 1
    private val ITEM_MEDIUM_PHOTO = 2
    private val config = activity.config
    private val viewType = activity.config.getFolderViewType(if (activity.config.showAll) SHOW_ALL else path)
    private val isListViewType = viewType == VIEW_TYPE_LIST
    private var visibleItemPaths = java.util.ArrayList<String>()
    private var rotatedImagePaths = java.util.ArrayList<String>()
    private var loadImageInstantly = true
    private var delayHandler = Handler(Looper.getMainLooper())
    private var currentMediaHash = media.hashCode()
    private val hasOTGConnected = activity.hasOTGConnected()

    private var scrollHorizontally = activity.config.scrollHorizontally
    private var animateGifs = activity.config.animateGifs
    private var cropThumbnails = activity.config.cropThumbnails
    private var displayFilenames = activity.config.displayFileNames
    private var showFileTypes = activity.config.showThumbnailFileTypes
    var mProgressDailog: ProgressDialog? = null

    // variable to track event time
    var mLastClickTime: Long = 0
    var mMinDuration = 2000
    protected var selectedMainKeys = LinkedHashSet<Int>()

    init {
    }

    override fun getActionMenuId() = R.menu.cab_media

    override fun prepareActionMode(menu: Menu) {
        val selectedItems = getSelectedItems()
        if (selectedItems.isEmpty()) {
            return
        }
        menu.apply {
            val selectableItemCount = getSelectableItemCount()
            val selectedCount = Math.min(selectedKeys.size, selectableItemCount)
            if (selectedCount == selectableItemCount) {
                findItem(R.id.cab_select_all).title = "Deselect All"
                findItem(R.id.cab_select_all).icon = activity.resources.getDrawable(R.drawable.ic_deselect_all_vector)
            } else {
                findItem(R.id.cab_select_all).title = "Select All"
                findItem(R.id.cab_select_all).icon = activity.resources.getDrawable(R.drawable.ic_select_all_vector)
            }
            checkHideBtnVisibility(this, selectedItems)
        }
    }

    private fun checkHideBtnVisibility(menu: Menu, selectedItems: java.util.ArrayList<Medium>) {
        menu.findItem(R.id.cab_hide).isVisible = selectedItems.any { !it.isHidden() && !it.path.doesThisOrParentHaveNoMedia(HashMap(), null) }
        menu.findItem(R.id.cab_unhide).isVisible = selectedItems.any { it.isHidden() && !it.path.doesThisOrParentHaveNoMedia(HashMap(), null) }
    }


    override fun actionItemPressed(id: Int) {
        if (selectedKeys.isEmpty()) {
            return
        }

        when (id) {
//            R.id.cab_properties -> showProperties()
            R.id.cab_rename -> renameFile()
            R.id.cab_hide -> toggleFileVisibility(true)
            R.id.cab_unhide -> toggleFileVisibility(false)
            R.id.cab_share -> shareMedia()
            R.id.cab_copy_to -> copyMoveTo(true)
            R.id.cab_move_to -> moveFilesTo()
            R.id.cab_select_all -> selectAll()
            R.id.cab_delete -> checkDeleteConfirmation()
        }
    }

    override fun getSelectableItemCount() = media.filter { it is Medium }.size

    override fun getIsItemSelectable(position: Int) = !isASectionTitle(position)

    override fun getItemSelectionKey(position: Int) = (media.getOrNull(position) as? Medium)?.path?.hashCode()

    override fun getItemKeyPosition(key: Int) = media.indexOfFirst { (it as? Medium)?.path?.hashCode() == key }

    override fun onActionModeCreated() {
        if (activity is MediaActivity) {
            (activity as MediaActivity).toggleToolbar(true)
        }
    }

    override fun onActionModeDestroyed() {
        if (activity is MediaActivity) {
            (activity as MediaActivity).toggleToolbar(false)
        }
    }

    override fun getSelectedList(): LinkedHashSet<Int> {
        return selectedMainKeys
    }

    fun getSelectedItemCount(): java.util.ArrayList<Medium> {
        return getSelectedItems()
    }

    override fun onViewRecycled(holder: ViewHolder) {
        super.onViewRecycled(holder)
        if (!activity.isDestroyed) {
            val itemView = holder.itemView
            visibleItemPaths.remove(itemView.medium_name?.tag)
            val tmb = itemView.medium_thumbnail
            if (tmb != null) {
                Glide.with(activity).clear(tmb)
            }
        }
    }

    override fun getItemViewType(position: Int): Int {
        val tmbItem = media[position]
        return when {
            tmbItem is ThumbnailSection -> ITEM_SECTION
            (tmbItem as Medium).isVideo() || tmbItem.isPortrait() -> ITEM_MEDIUM_VIDEO_PORTRAIT
            else -> ITEM_MEDIUM_PHOTO
        }
    }

    private fun getSelectedItems() = selectedKeys.mapNotNull { getItemWithKey(it) } as java.util.ArrayList<Medium>

    private fun getSelectedPaths() = getSelectedItems().map { it.path } as java.util.ArrayList<String>

    private fun getFirstSelectedItemPath() = getItemWithKey(selectedKeys.first())?.path

    private fun getItemWithKey(key: Int): Medium? = media.firstOrNull { (it as? Medium)?.path?.hashCode() == key } as? Medium

    fun updateMedia(newMedia: java.util.ArrayList<ThumbnailItem>) {
        val thumbnailItems = newMedia.clone() as java.util.ArrayList<ThumbnailItem>
        if (thumbnailItems.hashCode() != currentMediaHash) {
            currentMediaHash = thumbnailItems.hashCode()
            media = thumbnailItems
            enableInstantLoad()
            notifyDataSetChanged()
            finishActMode()
        }
    }

    private fun enableInstantLoad() {
        loadImageInstantly = true
        /*   delayHandler.postDelayed({
               loadImageInstantly = false
           }, INSTANT_LOAD_DURATION)*/
    }

    fun isASectionTitle(position: Int) = media.getOrNull(position) is ThumbnailSection

    fun getItemBubbleText(position: Int, sorting: Int, dateFormat: String, timeFormat: String): String {
        return (media[position] as? Medium)?.getBubbleText(sorting, activity, dateFormat, timeFormat) ?: ""
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layoutType = if (viewType == ITEM_SECTION) {
            R.layout.thumbnail_section
        } else {
            if (isListViewType) {
                if (viewType == ITEM_MEDIUM_PHOTO) {
                    R.layout.photo_item_list
                } else {
                    R.layout.video_item_list
                }
            } else {
                if (viewType == ITEM_MEDIUM_PHOTO) {
                    R.layout.photo_item_grid
                } else {
                    R.layout.video_item_grid
                }
            }
        }
        return createViewHolder(layoutType, parent)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val tmbItem = media.getOrNull(position) ?: return
        if (tmbItem is Medium) {
            visibleItemPaths.add(tmbItem.path)
        }

//        val allowLongPress = (!isAGetIntent || allowMultiplePicks) && tmbItem is Medium
        val allowLongPress = false
        holder.bindView(tmbItem, tmbItem is Medium, allowLongPress) { itemView, adapterPosition ->
            if (tmbItem is Medium) {

                setupThumbnail(itemView, tmbItem)
            } else {
                setupSection(itemView, tmbItem as ThumbnailSection)
            }
        }
        bindViewHolder(holder)
    }

    private fun setupThumbnail(view: View, medium: Medium) {
        Log.d("TAG1122", "setupThumbnail: onBind ")
        val isSelected = selectedKeys.contains(medium.path.hashCode())
        view.apply {
            val padding = if (activity.config.thumbnailSpacing <= 1) {
                activity.config.thumbnailSpacing
            } else {
                0
            }

            media_item_holder.setPadding(padding, padding, padding, padding)

            play_portrait_outline?.beVisibleIf(medium.isVideo() || medium.isPortrait())
            if (medium.isVideo()) {
                play_portrait_outline?.setImageResource(R.drawable.ic_play_outline_vector)
                play_portrait_outline?.beVisible()
            } else if (medium.isPortrait()) {
                play_portrait_outline?.setImageResource(R.drawable.ic_portrait_photo_vector)
                play_portrait_outline?.beVisibleIf(showFileTypes)
            }
            if (showFileTypes && (medium.isGIF() || medium.isRaw() || medium.isSVG())) {
                file_type.setText(
                    when (medium.type) {
                        TYPE_GIFS -> R.string.gif
                        TYPE_RAWS -> R.string.raw
                        else -> R.string.svg
                    }
                )
                file_type.beGone()
            } else {
                file_type?.beGone()
            }

            medium_name.beVisibleIf(displayFilenames || isListViewType)
            medium_name.text = medium.name
            medium_name.tag = medium.path

            val showVideoDuration = medium.isVideo() && activity.config.showThumbnailVideoDuration
            if (showVideoDuration) {
                video_duration?.text = medium.videoDuration.getFormattedDuration()
            }
            video_duration?.beVisibleIf(showVideoDuration)
            medium_check.beVisibleIf(isSelected)
            if (isSelected) {
                medium_check.background.applyColorFilter(adjustedPrimaryColor)
                medium_check.applyColorFilter(contrastColor)
            }

            if (isListViewType) {
                media_item_holder.isSelected = isSelected
            }

            var path = medium.path
            if (hasOTGConnected && context.isPathOnOTG(path)) {
                path = path.getOTGPublicPath(context)
            }

            val roundedCorners = when {
                isListViewType -> ROUNDED_CORNERS_SMALL
                activity.config.fileRoundedCorners -> ROUNDED_CORNERS_BIG
                else -> ROUNDED_CORNERS_BIG
            }



            if (loadImageInstantly) {
                activity.loadImage(
                    medium.type, path, medium_thumbnail, scrollHorizontally, animateGifs, cropThumbnails, roundedCorners, medium.getKey(),
                    rotatedImagePaths
                )
            } else {
                medium_thumbnail.setImageDrawable(null)
                medium_thumbnail.isHorizontalScrolling = scrollHorizontally
                delayHandler.postDelayed({
                    val isVisible = visibleItemPaths.contains(medium.path)
                    if (isVisible) {
                        activity.loadImage(
                            medium.type, path, medium_thumbnail, scrollHorizontally, animateGifs, cropThumbnails, roundedCorners,
                            medium.getKey(), rotatedImagePaths
                        )
                    }
                }, IMAGE_LOAD_DELAY)
            }

            if (isListViewType) {
                medium_name.setTextColor(textColor)
//                play_portrait_outline?.applyColorFilter(textColor)
            }
        }
    }

    private fun setupSection(view: View, section: ThumbnailSection) {
        view.apply {
            thumbnail_section.text = section.title
//            thumbnail_section.setTextColor(textColor)
        }
    }

    override fun getItemCount(): Int {
        return media.size
    }


    private fun showProperties() {
        if (selectedKeys.size <= 1) {
            val path = getFirstSelectedItemPath() ?: return
            PropertiesDialog(activity, path, config.shouldShowHidden){}
        } else {
            val paths = getSelectedPaths()
            PropertiesDialog(activity, paths, config.shouldShowHidden){}
        }
    }

    private fun renameFile() {
        if (selectedKeys.size == 1) {
            val oldPath = getFirstSelectedItemPath() ?: return
            RenameItemDialog(activity, oldPath) {
                ensureBackgroundThread {
                    activity.updateDBMediaPath(oldPath, it)

                    activity.runOnUiThread {
                        enableInstantLoad()
                        listener?.refreshItems()
                        finishActMode()
                    }
                }
            }
        } else {
            RenameDialog(activity, getSelectedPaths(), true) {
                enableInstantLoad()
                listener?.refreshItems()
                finishActMode()
            }
        }
    }


    private fun toggleFileVisibility(hide: Boolean) {
        VaultFragment.isHideUnHideMedia = true
        ensureBackgroundThread {
            var selectedList = getSelectedItems()

            getSelectedItems().forEach {
                activity.toggleFileVisibility(it.path, hide)

            }
            ensureBackgroundThread {
                if (hide) {
                    if (activity.directoryDao.getDirectoryDetailFromDirPath(getSelectedItems()[0].path.getParentPath()) != null)
                        activity.hiddenDirectoryDao.insert(activity.directoryDao.getDirectoryDetailFromDirPath(getSelectedItems()[0].path.getParentPath()).getConvertedHiddenDirectory())
                } else {
                    MediaActivity.isUnHideImage = true
                }
            }

            activity.runOnUiThread {
                if (activity is MediaActivity)
                    if (activity.findViewById<EditText>(R.id.etSearch).text.isNotEmpty())
                        if (activity.findViewById<ImageView>(R.id.imgClose) != null)
                            activity.findViewById<ImageView>(R.id.imgClose).performClick()
                listener?.refreshItems()
                finishActMode()
                MainActivity.isNeedToRefresh = true
                VaultFragment.isNeedToRefresh = true
                if (activity is FavouriteActivity) {
                    Log.d("TAG", "onResume: FavouritActivity - > refresh")
                    activity.refreshItems()
                }
                if (hide) {
                    if (selectedList[0].type == TYPE_VIDEOS)
                        activity.toast(activity.getString(R.string.msg_video_hide))
                    else if (selectedList[0].type == TYPE_IMAGES)
                        activity.toast(activity.getString(R.string.msg_image_hide))
                }

            }
        }
    }

    private fun shareMedia() {
        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()

        isUnLockApp = true
        if (selectedKeys.size == 1 && selectedKeys.first() != -1) {
            activity.shareMediumPath(getSelectedItems().first().path)
        } else if (selectedKeys.size > 1) {
            activity.shareMediaPaths(getSelectedPaths())
        }
    }

    private fun moveFilesTo() {
        MoveToAlertDialog(activity, activity.getString(R.string.alert_confirm_move)) {
            if (it) {
                activity.handleDeletePasswordProtection {
                    copyMoveTo(false)
                }
            }

        }

    }

    private fun copyMoveTo(isCopyOperation: Boolean) {
        VaultFragment.isHideUnHideMedia = true
        if (activity is MediaActivity)
            if (activity.findViewById<EditText>(R.id.etSearch).text.isNotEmpty())
                if (activity.findViewById<ImageView>(R.id.imgClose) != null)
                    activity.findViewById<ImageView>(R.id.imgClose).performClick()
        val paths = getSelectedPaths()

        val recycleBinPath = activity.recycleBinPath
        val fileDirItems = paths.asSequence().filter { isCopyOperation || !it.startsWith(recycleBinPath) }.map {
            FileDirItem(it, it.getFilenameFromPath())
        }.toMutableList() as java.util.ArrayList

        if (!isCopyOperation && paths.any { it.startsWith(recycleBinPath) }) {
            activity.toast(R.string.moving_recycle_bin_items_disabled, Toast.LENGTH_LONG)
        }

        if (fileDirItems.isEmpty()) {

            return
        }
        if (paths.size > 5) {
            finishActMode()
        }
        activity.baseConfig.isAnyOperationRunning = true
        Log.d("TAG787878", "itemClicked: " + activity.config.isAnyOperationRunning)
        Log.d("TAG787878", "itemClicked: " + activity.config.lastDestinationPath)
        activity.tryCopyMoveFilesTo(fileDirItems, isCopyOperation) {
            finishActMode()
            if (it == "None") {
                activity.baseConfig.isAnyOperationRunning = false
                baseConfig.lastDestinationPath = ""
                Log.d("TAG787878", "itemClicked: " + activity.config.isAnyOperationRunning)
                Log.d("TAG787878", "itemClicked: " + activity.config.lastDestinationPath)
                if (activity is MainActivity)
                    if (activity.findViewById<EditText>(R.id.etSearch).text.isNotEmpty())
                        if (activity.findViewById<ImageView>(R.id.imgClose) != null)
                            activity.findViewById<ImageView>(R.id.imgClose).performClick()
            } else {


                val destinationPath = it
                baseConfig.lastDestinationPath = destinationPath
                config.tempFolderPath = ""
                if (isCopyOperation) {
                    activity.toast(R.string.copying_success)
                } else {
                    activity.toast(R.string.moving_success)
                }
                activity.applicationContext.rescanFolderMedia(destinationPath)
                activity.applicationContext.rescanFolderMedia(fileDirItems.first().getParentPath())

                val newPaths = fileDirItems.map { "$destinationPath/${it.name}" }.toMutableList() as java.util.ArrayList<String>
                activity.rescanPaths(newPaths) {
                    activity.fixDateTaken(newPaths, false)
                }
                if (activity is MainActivity)
                    if (activity.findViewById<EditText>(R.id.etSearch).text.isNotEmpty())
                        if (activity.findViewById<ImageView>(R.id.imgClose) != null)
                            activity.findViewById<ImageView>(R.id.imgClose).performClick()

                if (!isCopyOperation) {
                    VaultFragment.isNeedToRefresh = true
                    listener?.refreshItems()
                    var favoritesDB = FavouriteDBHelper(activity)
                    fileDirItems.forEach {
                        favoritesDB.deleteFavDetails(it.path)
                    }

                }

                Log.d("TAG787878", "itemClicked: " + activity.config.isAnyOperationRunning)
                Log.d("TAG787878", "itemClicked: " + activity.config.lastDestinationPath)
                baseConfig.isAnyOperationRunning = false
                baseConfig.lastDestinationPath = ""
            }
        }
    }

    fun showProgress(msg: String) {
        mProgressDailog = ProgressDialog(activity, R.style.MyAlertDialogNew)
        mProgressDailog!!.setMessage(msg)

        mProgressDailog!!.setCancelable(false)
        mProgressDailog!!.setProgressStyle(ProgressDialog.STYLE_SPINNER)
        mProgressDailog!!.show()
    }

    fun dismissProgress() {
        activity.runOnUiThread {
            if (mProgressDailog != null && mProgressDailog!!.isShowing) {
                mProgressDailog!!.dismiss()
            }
        }
    }

    private fun checkDeleteConfirmation() {

        if (config.isDeletePasswordProtectionOn) {
            activity.handleDeletePasswordProtection {
                deleteFiles()
            }
        }
        else {
            askConfirmDelete()
        }
    }

    private fun askConfirmDelete() {
        val itemsCnt = selectedKeys.size
        val firstPath = getSelectedPaths().first()
        val items = if (itemsCnt == 1) {
            "\"${firstPath.getFilenameFromPath()}\""
        } else {
            resources.getQuantityString(R.plurals.delete_items, itemsCnt, itemsCnt)
        }

        val isRecycleBin = firstPath.startsWith(activity.recycleBinPath)
        val baseString = if (config.useRecycleBin && !isRecycleBin) R.string.msg_move_vault_trash else R.string.deletion_confirmation
        val question = String.format(resources.getString(baseString), items)
        DeleteWithRememberDialog(activity, question) {
            if (it) {
                showProgress(activity.getString(R.string.msg_deleting))
                config.tempSkipDeleteConfirmation = it
                deleteFiles()
            } else {
                finishActMode()
            }

        }
    }

    private fun deleteFiles() {
        VaultFragment.isHideUnHideMedia = true
        if (selectedKeys.isEmpty()) {
            return
        }

        val SAFPath = getSelectedPaths().firstOrNull { activity.needsStupidWritePermissions(it) } ?: getFirstSelectedItemPath() ?: return
        activity.handleSAFDialog(SAFPath) {
            if (!it) {
                return@handleSAFDialog
            }

            val fileDirItems = ArrayList<FileDirItem>(selectedKeys.size)
            val removeMedia = ArrayList<Medium>(selectedKeys.size)
            val positions = getSelectedItemPositions()
            var dbHelper = FavouriteDBHelper(activity)

            getSelectedItems().forEach {
                fileDirItems.add(FileDirItem(it.path, it.name))
                removeMedia.add(it)
                dbHelper.deleteFavDetails(it.path)
            }
            removeSelectedItems(positions)
            currentMediaHash = media.hashCode()
            media.removeAll(removeMedia)
            listener?.tryDeleteFiles(fileDirItems)
            listener?.updateMediaGridDecoration(media)

        }
    }

}