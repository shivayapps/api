package com.gallery.photo.image.video.dialog

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import com.gallery.photo.image.video.R


class ConfirmUnFavouritePhotoDialog(
    val activity: Activity, val callback: (isConfirm: Boolean) -> Unit
) {

    private var view: View
    val dialog: Dialog

    init {
        view = activity.layoutInflater.inflate(R.layout.dialog_confirm_unfavourite, null)
        dialog = Dialog(activity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(view)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        val ivClose = dialog.findViewById(R.id.ivClose) as ImageView
        val tvTitle = dialog.findViewById(R.id.tvTitle) as TextView
//        val font = Typeface.createFromAsset(activity.assets, "fonts/avenirltpromedium.otf")
//        tvTitle.typeface = font


        ivClose.setOnClickListener {
            dialog.dismiss()
            callback(false)
        }

        val tvDone = dialog.findViewById(R.id.tvDone) as TextView
        tvDone.setOnClickListener {
            dialog.dismiss()
            callback(true)
        }

        dialog.show()

    }


}
