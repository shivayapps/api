package com.gallery.photo.image.video.Camera.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.gallery.photo.image.video.R;
import com.gallery.photo.image.video.Camera.PreferenceKeys;
import com.gallery.photo.image.video.Camera.onRecyclerClickListener;
import com.gallery.photo.image.video.utilities.SharedPrefs;


public class
GridAdapter extends RecyclerView.Adapter<GridAdapter.MyViewHolder> {
    Context mContext;
    String[] mGrid_entries;
    onRecyclerClickListener mOnRecyclerClickListener;
    int selctedPos;

    public GridAdapter(Context context, String[] strArr, onRecyclerClickListener onrecyclerclicklistener) {
        this.mContext = context;
        this.mGrid_entries = strArr;
        this.mOnRecyclerClickListener = onrecyclerclicklistener;
        this.selctedPos = SharedPrefs.getInt(context, PreferenceKeys.GRID_POS, 0);
    }

    public void refreshAdapter(int i) {
        this.selctedPos = i;
        notifyDataSetChanged();
    }

    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cell_grid_dialog, viewGroup, false));
    }

    public void onBindViewHolder(MyViewHolder myViewHolder, final int i) {
        if (myViewHolder instanceof MyViewHolder) {
            myViewHolder.tv_grid.setText(this.mGrid_entries[i]);
            if (this.selctedPos == i) {
                myViewHolder.imgTick.setSelected(true);
            } else {
                myViewHolder.imgTick.setSelected(false);
            }
            myViewHolder.grid_layout.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    if (GridAdapter.this.mOnRecyclerClickListener != null) {
                        GridAdapter.this.mOnRecyclerClickListener.setOnItemClickListener(i, view);
                    }
                    GridAdapter.this.selctedPos = i;
                    GridAdapter.this.notifyDataSetChanged();
                }
            });
        }
    }

    public int getItemCount() {
        return this.mGrid_entries.length;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        LinearLayout grid_layout;
        ImageView imgTick;
        TextView tv_grid;

        public MyViewHolder(View view) {
            super(view);
            this.tv_grid = (TextView) view.findViewById(R.id.tv_grid);
            this.imgTick = (ImageView) view.findViewById(R.id.img_tick);
            this.grid_layout = (LinearLayout) view.findViewById(R.id.grid_layout);
        }
    }
}
