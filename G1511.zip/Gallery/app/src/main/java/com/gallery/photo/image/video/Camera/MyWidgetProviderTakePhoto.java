package com.gallery.photo.image.video.Camera;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class MyWidgetProviderTakePhoto extends AppWidgetProvider {
    private static final String TAG = "MyWidgetProviderTakePho";

    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] iArr) {
        Log.d(TAG, "onUpdate");
        Log.d(TAG, "length = " + iArr.length);
        for (int i : iArr) {
            Log.d(TAG, "appWidgetId: " + i);
            PendingIntent.getActivity(context, 0, new Intent(context, TakePhoto.class), 0);
        }
    }
}
