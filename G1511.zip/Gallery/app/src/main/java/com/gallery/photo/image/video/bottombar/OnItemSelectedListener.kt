package com.gallery.photo.image.video.bottombar

interface OnItemSelectedListener {

    fun onItemSelect(pos: Int): Boolean
}
