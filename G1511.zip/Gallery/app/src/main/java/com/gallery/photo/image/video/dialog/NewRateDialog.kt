package com.gallery.photo.image.video.dialog

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.*
import android.view.animation.AnimationUtils
import androidx.appcompat.widget.Toolbar
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.rateandfeedback.ExitSPHelper
import com.gallery.photo.image.video.extensions.toast
import kotlinx.android.synthetic.main.new_rate_dialog.*


class NewRateDialog(val fContext: Context, val callback: (rate: Int) -> Unit) : Dialog(fContext), View.OnClickListener {
    val Context.inflater: LayoutInflater get() = LayoutInflater.from(this)
    val Context.displayWidth: Int get() = resources.displayMetrics.widthPixels
    var mode = "feedback"
    var rate = 0


    init {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        val sheetView = fContext.inflater.inflate(R.layout.new_rate_dialog, null)
        window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        setContentView(sheetView)
        setCancelable(false)
        setCanceledOnTouchOutside(false)

        window!!.setGravity(Gravity.CENTER)
        window!!.setLayout((0.9 * fContext.displayWidth).toInt(), Toolbar.LayoutParams.WRAP_CONTENT)
        initListeners()

        val animZoomIn = AnimationUtils.loadAnimation(fContext, R.anim.zoon_in_out)
        iv_rate_cartoon.startAnimation(animZoomIn)
        show()


    }

    private fun initListeners() {

        iv_rate_close.setOnClickListener(this)
        tv_rate_rate_app.setOnClickListener(this)
        ic_rate_star_one.setOnClickListener(this)
        ic_rate_star_two.setOnClickListener(this)
        ic_rate_star_three.setOnClickListener(this)
        ic_rate_star_four.setOnClickListener(this)
        ic_rate_star_five.setOnClickListener(this)

    }

    override fun onClick(v: View?) {

        when (v!!.id) {

            R.id.iv_rate_close -> {
                ExitSPHelper(fContext).saveDismissed(true)
                cancel()
                dismiss()
            }
            R.id.ic_rate_star_one -> {
                mode = "feedback"
                rate = 1
                ic_rate_star_one.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_star_gold))
                ic_rate_star_two.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_star_gray))
                ic_rate_star_three.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_star_gray))
                ic_rate_star_four.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_star_gray))
                ic_rate_star_five.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_star_gray))
                iv_rate_cartoon.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_cartoon_one))
                tv_rate_dec.text = fContext.getString(R.string.msg_rate_us_1_to_3)
                tv_rate_rate_app.text = fContext.getString(R.string.label_rate_us)
                tv_rate_wecan.visibility = View.VISIBLE
                iv_rate_arrow.visibility = View.VISIBLE
                val animZoomIn = AnimationUtils.loadAnimation(fContext, R.anim.zoon_in_out)
                iv_rate_cartoon.startAnimation(animZoomIn)

            }
            R.id.ic_rate_star_two -> {
                mode = "feedback"
                rate = 2
                ic_rate_star_one.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_star_gold))
                ic_rate_star_two.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_star_gold))
                ic_rate_star_three.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_star_gray))
                ic_rate_star_four.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_star_gray))
                ic_rate_star_five.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_star_gray))
                iv_rate_cartoon.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_cartoon_one))
                tv_rate_dec.text = fContext.getString(R.string.msg_rate_us_1_to_3)
                tv_rate_rate_app.text = fContext.getString(R.string.label_rate_us)
                tv_rate_wecan.visibility = View.VISIBLE
                iv_rate_arrow.visibility = View.VISIBLE
                val animZoomIn = AnimationUtils.loadAnimation(fContext, R.anim.zoon_in_out)
                iv_rate_cartoon.startAnimation(animZoomIn)

            }
            R.id.ic_rate_star_three -> {
                mode = "feedback"
                rate = 3
                ic_rate_star_one.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_star_gold))
                ic_rate_star_two.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_star_gold))
                ic_rate_star_three.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_star_gold))
                ic_rate_star_four.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_star_gray))
                ic_rate_star_five.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_star_gray))
                iv_rate_cartoon.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_cartoon_three))
                tv_rate_dec.text = fContext.getString(R.string.msg_rate_us_1_to_3)
                tv_rate_rate_app.text = fContext.getString(R.string.label_rate_us)
                tv_rate_wecan.visibility = View.VISIBLE
                iv_rate_arrow.visibility = View.VISIBLE
                val animZoomIn = AnimationUtils.loadAnimation(fContext, R.anim.zoon_in_out)
                iv_rate_cartoon.startAnimation(animZoomIn)

            }
            R.id.ic_rate_star_four -> {
                mode = "feedback"
                rate = 4

                ic_rate_star_one.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_star_gold))
                ic_rate_star_two.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_star_gold))
                ic_rate_star_three.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_star_gold))
                ic_rate_star_four.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_star_gold))
                ic_rate_star_five.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_star_gray))
                iv_rate_cartoon.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_cartoon_four))
                tv_rate_dec.text = fContext.getString(R.string.msg_rate_us_thanks_for_feedback)
                tv_rate_rate_app.text = fContext.getString(R.string.label_rate_us)
                tv_rate_wecan.visibility = View.VISIBLE
                iv_rate_arrow.visibility = View.VISIBLE
                val animZoomIn = AnimationUtils.loadAnimation(fContext, R.anim.zoon_in_out)
                iv_rate_cartoon.startAnimation(animZoomIn)

            }
            R.id.ic_rate_star_five -> {
                mode = "playstore"
                rate = 5
                ic_rate_star_one.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_star_gold))
                ic_rate_star_two.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_star_gold))
                ic_rate_star_three.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_star_gold))
                ic_rate_star_four.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_star_gold))
                ic_rate_star_five.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_star_gold))
                iv_rate_cartoon.setImageDrawable(fContext.resources.getDrawable(R.drawable.ic_rate_cartoon_five))
                tv_rate_dec.text = fContext.getString(R.string.msg_rate_us_thanks_for_feedback)
                tv_rate_rate_app.text = fContext.getString(R.string.label_rate_us_google_play)
                tv_rate_wecan.visibility = View.INVISIBLE
                iv_rate_arrow.visibility = View.INVISIBLE
                val animZoomIn = AnimationUtils.loadAnimation(fContext, R.anim.zoon_in_out)
                iv_rate_cartoon.startAnimation(animZoomIn)

            }
            R.id.tv_rate_rate_app -> {
                if (rate == 0) {
                    fContext.toast(fContext.getString(R.string.msg_rate_no_selection))
                } else {
                    ExitSPHelper(fContext).saveRate()
                    dismiss()
                    callback(rate)
                }

//                if (mode.equals("feedback")) {
//                    SharedPrefs.save(fContext, "review", "yes")
////                    mNewFeedbackDialog = NewFeedbackDialog(fContext, rate)
////                    mNewFeedbackDialog!!.show()
//                    fContext.startActivity(FeedbackActivity.newIntent(fContext, rate))
//                } else if (mode.equals("playstore")) {
//                    SharedPrefs.save(fContext, "review", "yes")
//                    fContext.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google" + ".com/store/apps/details?id=" + fContext.packageName)))
//                }
//                cancel()
//                dismiss()

            }
        }

    }
}