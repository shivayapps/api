package com.gallery.photo.image.video.bindActivity

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.os.SystemClock
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.util.TypedValue
import android.view.View
import android.view.ViewTreeObserver
import android.widget.EditText
import androidx.recyclerview.widget.RecyclerView
import com.example.app.ads.helper.GiftIconHelper
import com.example.app.ads.helper.InterstitialAdHelper
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.adapter.AudioDocFileAdapter
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.utilities.addEvent

import com.gallery.photo.image.video.databinding.ActivityHiddenAudioDocumentBinding
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.fragment.VaultFragment
import com.gallery.photo.image.video.interfaces.MediaOperationsListener
import com.gallery.photo.image.video.models.*
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.vaultgallery.model.KEY_MEDIA_LIST
import com.gallery.photo.image.video.vaultgallery.model.KEY_MEDIA_TYPE
import com.gallery.photo.image.video.vaultgallery.ui.GalleryEngine
import com.gallery.photo.image.video.vaultgallery.ui.REQUEST_SELECT_MEDIA
import com.gallery.photo.image.video.helpers.*
import com.gallery.photo.image.video.models.FileDirItem
import com.gallery.photo.image.video.views.MyGridLayoutManager
import kotlinx.android.synthetic.main.activity_media.*
import java.io.File
import kotlin.collections.ArrayList
import kotlin.math.roundToInt

class HiddenAudioActivity : BaseBindingActivity<ActivityHiddenAudioDocumentBinding>(), MediaOperationsListener {

    var title: String? = null

    private var mAllowPickingMultiple = false
    private var mShouldStopFetching = false
    private var mIsSearchOpen = false
    public var mDirs = ArrayList<HideFilesDetail>()
    var mIsGettingDirs = false
    var isPickAudio = true
    var isFABOpen = false
    private var mLastSearchedText = ""
    override var mMinDuration = 1500

    companion object {
        var isNeedToRefersh = false
        fun newIntent(mContext: Context, isPickAudio: Boolean = true): Intent {
            var intent = Intent(mContext, HiddenAudioActivity::class.java)
            intent.putExtra(GET_IMAGE_INTENT, isPickAudio)
            return intent
        }

    }

    override fun getAppIconIDs() = arrayListOf(
        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName() = getString(R.string.app_name)

    override fun setBinding(): ActivityHiddenAudioDocumentBinding {
        return ActivityHiddenAudioDocumentBinding.inflate(layoutInflater)
    }

    override fun getContext(): Activity {
        return this
    }

    override fun initData() {
        intent.apply {
            isPickAudio = getBooleanExtra(GET_IMAGE_INTENT, true)
        }

        if (isPickAudio) {
            mBinding.tvTitle.text = getString(R.string.label_audio)
            mBinding.directoriesClickHereToAdd.text = getString(R.string.msg_click_here_to_hide_audio)
            mBinding.tvGallery.text = getString(R.string.label_audio)
            mBinding.fabAddHiddenPhotoFromGallery.setImageDrawable(getDrawable(R.drawable.ic_vault_audio))
        } else {
            addEvent("HiddenDocumentActivity")
            mBinding.tvTitle.text = getString(R.string.label_document)
            mBinding.directoriesClickHereToAdd.text = getString(R.string.msg_click_here_to_hide_document)
            mBinding.tvGallery.text = getString(R.string.label_document)
            mBinding.fabAddHiddenPhotoFromGallery.setImageDrawable(getDrawable(R.drawable.ic_vault_document))
        }
        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            InterstitialAdHelper.loadInterstitialAd(fContext = this)
            GiftIconHelper.loadGiftAd(
                fContext = this,
                fivGiftIcon = mBinding.giftLayout.giftAdIcon,
                fivBlastIcon = mBinding.giftLayout.giftBlastAdIcon
            )
        }
        mBinding.directoriesRefreshLayout.setOnRefreshListener { getAudioDocument() }
        if (mBinding.imgAddHiddenPhoto.isVisible()) {
            try {
                mBinding.imgAddHiddenPhoto.viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
                    override fun onGlobalLayout() {
                        mBinding.imgAddHiddenPhoto.viewTreeObserver.removeOnGlobalLayoutListener(this)
                        val r: Resources = resources
                        var dimen = r.getDimension(R.dimen._7sdp)
                        val px = TypedValue.applyDimension(
                            TypedValue.COMPLEX_UNIT_DIP, dimen, r.displayMetrics
                        ).roundToInt()
                        mBinding.directoriesGrid.setPadding(3, 3, 3, mBinding.imgAddHiddenPhoto.height + px)
                    }

                })
            } catch (e: Exception) {
                val r: Resources = resources
                var dimen = r.getDimension(R.dimen._25sdp)
                val px = TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_DIP, dimen, r.displayMetrics
                ).roundToInt()
                mBinding.directoriesGrid.setPadding(3, 3, 3, px)
            }

        }
        getAudioDocument()
    }

    override fun initActions() {
        setupSearch()
        mBinding.imgBack.setOnClickListener(this)
        mBinding.imgSearch.setOnClickListener(this)
        mBinding.imgClose.setOnClickListener(this)
        mBinding.llHideOpt.setOnClickListener(this)
        mBinding.rlAddHiddenPhotoVideo.setOnClickListener(this)
        mBinding.flBackground.setOnClickListener(this)
        mBinding.imgAddHiddenPhoto.setOnClickListener(this)
        mBinding.fabAddHiddenPhotoFromGallery.setOnClickListener(this)
        mBinding.fabAddHiddenPhotoFromFolder.setOnClickListener(this)
    }

    private fun setupSearch() {
        mBinding.etSearch.hint = getString(R.string.msg_search_photo_by_name)
        mBinding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                setupAdapter(mDirs, s.toString())
            }

            override fun afterTextChanged(s: Editable?) {

            }

        })
    }

    override fun onResume() {
        super.onResume()
        if (isNeedToRefersh) {
            isNeedToRefersh = false
            getAudioDocument()
        }
    }

    override fun onClick(view: View) {
        super.onClick(view)
        when (view.id) {
            R.id.imgBack -> {
                onBackPressed()
            }
            R.id.imgSearch -> {
                mBinding.etSearch.visibility = View.VISIBLE
                mBinding.imgClose.visibility = View.VISIBLE
                mBinding.tvTitle.visibility = View.GONE
                mBinding.imgSearch.visibility = View.GONE
                mBinding.imgOptions.visibility = View.GONE
                showKeyboard(mBinding.etSearch)
            }
            R.id.imgClose -> {
                mBinding.etSearch.text = null
                mBinding.etSearch.visibility = View.GONE
                mBinding.imgClose.visibility = View.GONE
                mBinding.tvTitle.visibility = View.VISIBLE
                mBinding.imgSearch.visibility = View.VISIBLE
                mBinding.imgOptions.visibility = View.VISIBLE
                setupAdapter(mDirs, "")
                hideKeyboard(mBinding.etSearch)
            }
            R.id.imgAddHiddenPhoto -> {
                if (isPickAudio)
                    addEvent(plusButtonAudio)
                else
                    addEvent(plusButtonDocument)
                if (config.isAnyOperationRunning) {
                    toast(getString(R.string.msg_operation_already_running))
                    return
                }
                if (!isFABOpen) {
                    showFABMenu()
                } else {
                    closeFABMenu()
                }
            }
            R.id.flBackground -> {
                closeFABMenu()
            }
            R.id.rlAddHiddenPhotoVideo, R.id.fabAddHiddenPhotoFromGallery -> {
                closeFABMenu()
                if (isPickAudio)
                    addEvent(audioPickerClick)
                else
                    addEvent(documentPickerClick)
                var type = if (isPickAudio)
                    CHOOSE_AUDIO_TYPE
                else
                    CHOOSE_DOCUMENT_TYPE
                GalleryEngine.Builder()
                    .choose(type)
                    .multiple(true)
                    .maxSelect(5)
                    .forResult(this)
            }
            R.id.fabAddHiddenPhotoFromFolder -> {
                closeFABMenu()
                if (isPickAudio)
                    addEvent(fromFolderClickAudio)
                else
                    addEvent(fromFolderClickDocument)
                var type = if (isPickAudio)
                    CHOOSE_AUDIO_TYPE
                else
                    CHOOSE_DOCUMENT_TYPE
                startActivity(CustomFilePickerActivity.newIntent(this, type))
            }
            R.id.llHideOpt -> {
                if (getRecyclerAdapter() != null) {
                    getRecyclerAdapter()!!.toggleFileVisibility(false)
                }
            }
        }
    }


    private fun getAudioDocument() {
        Log.d("Tag Get Directory ", mIsGettingDirs.toString())
        if (mIsGettingDirs) {
            return
        }
        mShouldStopFetching = true
        mIsGettingDirs = true
        mBinding.llProgress.visibility = View.VISIBLE


        if (getRecyclerAdapter() != null) {
            getRecyclerAdapter()!!.dismissProgress()
            getRecyclerAdapter()!!.finishActMode()
        }
        var type = if (isPickAudio)
            TYPE_AUDIO
        else
            TYPE_DOCUMENT
        if (VaultFragment.isFakeVaultOpen) {
            ensureBackgroundThread {
                var hideMedia = fakeHideFileDao.getMediaFromType(type)
                hideMedia.filter { !getDoesFilePathExist(it.path) }.forEach {
                    fakeHideFileDao.deleteHideFilesDetailPath(it.path)
                }
                Log.d(TAG, "getDirectories: Hide Media size -->" + hideMedia.size)
                gotDirectories(hideMedia as ArrayList<HideFilesDetail>)
            }
        } else {
            ensureBackgroundThread {
                var hideMedia = hideFileDao.getMediaFromType(type)
                hideMedia.filter { !getDoesFilePathExist(it.path) }.forEach {
                    hideFileDao.deleteHideFilesDetailPath(it.path)
                }
                Log.d(TAG, "getDirectories: Hide Media size -->" + hideMedia.size)
                gotDirectories(hideMedia as ArrayList<HideFilesDetail>)
            }

        }
    }

    override fun fromActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
        super.fromActivityResult(requestCode, resultCode, resultData)
        when (requestCode) {
            REQUEST_SELECT_MEDIA -> {
                isUnLockApp = true
                isInterstitialShown = true
                VaultFragment.isTabUnlock = true
                if (resultCode == RESULT_OK && resultData != null) {
                    var selectedList: List<String> = resultData?.getStringArrayListExtra(KEY_MEDIA_LIST)!!
                    var filterType: Int = resultData?.getIntExtra(KEY_MEDIA_TYPE, CHOOSE_IMAGE_TYPE)!!
                    showProgress(getString(R.string.please_wait))
                    ensureBackgroundThread {
                        if (filterType == CHOOSE_AUDIO_TYPE) {
                            var totalAudioCount = config.hideAudioCountForSubscription
//                            var totalVideosCount = config.hideVideoCountForSubscription
                            totalAudioCount += selectedList.size
//                            if (AdsManager(this).isNeedToShowAds() && totalImagesCount > HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION_VAL) {
//                                runOnUiThread {
//                                    dismissProgress()
//                                    SubscriptionDialog(this, totalImagesCount, totalVideosCount)
//                                    {
//                                        var intent = Intent(this, SubscriptionActivity::class.java)
//                                        launchActivityForResult(intent, REQUEST_CODE_FOR_SUBSCRIPTION)
//                                    }
//                                }
//                            } else {
                            mContext.config.hideAudioCountForSubscription = totalAudioCount
                            hideFiles(selectedList, filterType)
//                            }
                        } else if (filterType == CHOOSE_DOCUMENT_TYPE) {
//                            var totalImagesCount = config.hidePhotoCountForSubscription
                            var totalDocumentCount = config.hideDocumentCountForSubscription
                            totalDocumentCount += selectedList.size
//                            if (AdsManager(this).isNeedToShowAds() && totalVideosCount > HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION_VAL) {
//                                runOnUiThread {
//                                    dismissProgress()
//                                    SubscriptionDialog(this, totalImagesCount, totalVideosCount)
//                                    {
//                                        var intent = Intent(this, SubscriptionActivity::class.java)
//                                        launchActivityForResult(intent, REQUEST_CODE_FOR_SUBSCRIPTION)
//                                    }
//                                }
//                            } else {
                            mContext.config.hideDocumentCountForSubscription = totalDocumentCount
                            hideFiles(selectedList, filterType)
//                            }
                        }
                    }
                }
            }
        }
    }

    private fun hideFiles(selectedList: List<String>, filterType: Int) {
        var prevPath = ""
        var hiddenDirectory = ArrayList<String>()
        selectedList.forEachIndexed { index, it ->
            if (prevPath != it.getParentPath()) {
                hiddenDirectory.add(it.getParentPath())
                prevPath = it.getParentPath()
            }
            val type = when {
                it.isVideoFast() -> TYPE_VIDEOS
                it.isGif() -> TYPE_GIFS
                it.isSvg() -> TYPE_SVGS
                it.isRawFast() -> TYPE_RAWS
                it.isPortrait() -> TYPE_PORTRAITS
                it.isAudioFast() -> TYPE_AUDIO
                it.isDocumentFast() -> TYPE_DOCUMENT
                else -> TYPE_IMAGES
            }
            toggleFileVisibility(it, true) {

                val file = HideFilesDetail(
                    null,
                    it.getFilenameFromPath(),
                    it,
                    it.getParentPath(),
                    System.currentTimeMillis(),
                    System.currentTimeMillis(),
                    File(it).length(),
                    type,
                    false,
                    0
                )
                ensureBackgroundThread {
                    if (VaultFragment.isFakeVaultOpen) {
                        try {
                            fakeHideFileDao.insert(file.getConvertedFakeFileDetail())
                        } catch (e: Exception) {
                        }
                    } else {
                        try {
                            hideFileDao.insert(file)
                        } catch (e: Exception) {
                        }
                    }
                    if (index == selectedList.size - 1) {
                        runOnUiThread {
                            dismissProgress()
                            when (filterType) {
                                CHOOSE_IMAGE_TYPE -> toast(getString(R.string.msg_image_hide))
                                CHOOSE_VIDEO_TYPE -> toast(getString(R.string.msg_video_hide))
                                CHOOSE_AUDIO_TYPE -> toast(getString(R.string.msg_audio_hide))
                                CHOOSE_DOCUMENT_TYPE -> toast(getString(R.string.msg_document_hide))
                                else -> toast(getString(R.string.msg_hide_media_successfully))
                            }
                            isInterstitialShown = false
                            refreshItems()
                            if (AdsManager(this).isNeedToShowAds() && isOnline()) {
                                isShowInterstitialAd {
                                    isInterstitialShown = false
                                }
                            } else {
                                isInterstitialShown = false

                            }
                        }
                    }
                }

            }
        }


    }


    fun getRecyclerAdapter() = mBinding.directoriesGrid.adapter as? AudioDocFileAdapter

    private fun gotDirectories(newDirs: ArrayList<HideFilesDetail>) {
        mDirs = newDirs
        mIsGettingDirs = false
        mShouldStopFetching = false
        setupLayoutManager()
        setupAdapter(newDirs)
        Thread {

            runOnUiThread {
                mBinding.directoriesRefreshLayout.isRefreshing = false
                VaultFragment.isLoadedGallery = true
                checkPlaceholderVisibility(newDirs)
                mBinding.llProgress.visibility = View.GONE
            }
        }.start()

    }

    fun setupAdapter(dirs: List<HideFilesDetail>, textToSearch: String = "", forceRecreate: Boolean = false) {

        runOnUiThread {

            if (mBinding.directoriesGrid != null) {
                val currAdapter = mBinding.directoriesGrid.adapter
                if (currAdapter == null) {
                    val fastscroller = mBinding.directoriesVerticalFastscroller
                    AudioDocFileAdapter(
                        this, dirs as ArrayList<HideFilesDetail>, this, false,
                        mAllowPickingMultiple, mBinding.directoriesGrid, fastscroller
                    ) {
                        if (it is HideFilesDetail && !isFinishing) {
                            itemClicked(it.path)
                        }
                    }.apply {
//                setupZoomListener(mZoomListener)
                        mBinding.directoriesGrid.adapter = this
                    }
                    setupLayoutManager()
                } else if (mLastSearchedText.isEmpty()) {
                    (currAdapter as AudioDocFileAdapter).updateMedia(dirs as java.util.ArrayList<HideFilesDetail>)
                }
            }
        }

    }

    private fun itemClicked(path: String) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()
        if (config.isAnyOperationRunning && path == config.lastDestinationPath) {
            toast(getString(com.gallery.photo.image.video.R.string.msg_operation_already_running))
        } else {
            isUnLockApp = true
            openPath(path, true)
        }
    }


    private fun checkPlaceholderVisibility(dirs: ArrayList<HideFilesDetail>) {
        runOnUiThread {

            mBinding.directoriesEmptyPlaceholder.beGone()
            mBinding.directoriesEmptyPlaceholder2.beGone()
            mBinding.rlAddHiddenPhotoVideo.beVisibleIf(dirs.isEmpty())
            if (mIsSearchOpen) {
                mBinding.directoriesEmptyPlaceholder.beVisibleIf(dirs.isEmpty())
                mBinding.directoriesEmptyPlaceholder.text = getString(R.string.no_items_found)
            } else if (dirs.isEmpty() && config.filterMedia == getDefaultFileFilter()) {

                mBinding.directoriesEmptyPlaceholder.text = getString(R.string.no_media_with_filters)
                mBinding.directoriesEmptyPlaceholder2.text = getString(R.string.add_folder)

            } else {
                mBinding.directoriesEmptyPlaceholder.text = getString(R.string.no_media_with_filters)
                mBinding.directoriesEmptyPlaceholder2.text = getString(R.string.change_filters_underlined)
            }

            mBinding.directoriesEmptyPlaceholder2.underlineText()
            mBinding.directoriesGrid.beVisibleIf(mBinding.rlAddHiddenPhotoVideo.isGone())
            if (dirs.isEmpty()) {
                config.hiddenCountForRate = 0

            }
        }

    }

    fun setupLayoutManager() {
        runOnUiThread(Runnable {
            setupListLayoutManager()
        })

    }


    private fun setupListLayoutManager() {
        val layoutManager = mBinding.directoriesGrid.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = 1
        layoutManager.orientation = RecyclerView.VERTICAL
    }


    private fun isGetContentIntent(intent: Intent) = intent.action == Intent.ACTION_GET_CONTENT && intent.type != null


    override fun refreshItems() {
        getAudioDocument()

    }

    override fun tryDeleteFiles(fileDirItems: ArrayList<FileDirItem>) {
        val filtered = fileDirItems.filter { !getIsPathDirectory(it.path) } as ArrayList
        if (filtered.isEmpty()) {
            if (getRecyclerAdapter() != null)
                getRecyclerAdapter()!!.dismissProgress()
            return
        }
        val pathsToDelete = ArrayList<String>()
        filtered.mapTo(pathsToDelete) { it.path }
        movePathsInRecycleBin(pathsToDelete, true, VaultFragment.isFakeVaultOpen) {
            if (it) {
                deleteFilteredFiles(filtered)
            } else {
                toast(R.string.unknown_error_occurred)
            }
        }

    }

    private fun deleteFilteredFiles(filtered: ArrayList<FileDirItem>) {
        deleteFiles(filtered) {
            if (!it) {
                toast(R.string.unknown_error_occurred)
                if (getRecyclerAdapter() != null)
                    getRecyclerAdapter()!!.dismissProgress()
                return@deleteFiles
            }

            mDirs.removeAll { filtered.map { it.path }.contains((it as? HideFilesDetail)?.path) }
            if (etSearch.text.isNotEmpty())
                imgClose.performClick()
            ensureBackgroundThread {
                runOnUiThread {
                    if (getRecyclerAdapter() != null)
                        getRecyclerAdapter()!!.dismissProgress()
                    refreshItems()
                }
            }


        }
    }

    override fun selectedPaths(paths: ArrayList<String>) {

    }

    override fun updateMediaGridDecoration(media: ArrayList<ThumbnailItem>) {

    }


    fun toggleToolbar(isShowActionBar: Boolean) {
        if (isShowActionBar) {
            if (mBinding.etSearch.visibility == View.VISIBLE) {
                hideKeyboard(findViewById<EditText>(R.id.etSearch))
                findViewById<EditText>(R.id.etSearch).clearFocus()
            }
            mBinding.llBottomOption.beVisible()
            if (isPickAudio)
                mBinding.tvHideUnHideText.text = resources.getString(R.string.label_unhide_audio, 0)
            else
                mBinding.tvHideUnHideText.text = resources.getString(R.string.label_unhide_document, 0)
            mBinding.imgOptHideUnHide.setImageDrawable(resources.getDrawable(R.drawable.ic_option_unhide))
            mBinding.imgAddHiddenPhoto.beGone()

            mBinding.directoriesGrid.setPadding(3, 3, 3, 3)
        } else {
            mBinding.llBottomOption.beGone()
            mBinding.imgAddHiddenPhoto.beVisible()
            val r: Resources = resources
            var dimen = r.getDimension(R.dimen._7sdp)
            val px = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, dimen, r.displayMetrics
            ).roundToInt()
            mBinding.directoriesGrid.setPadding(3, 3, 3, mBinding.imgAddHiddenPhoto.height + px)
        }
    }

    fun updateCount(size: Int) {
        if (isPickAudio)
            mBinding.tvHideUnHideText.text = resources.getString(R.string.label_unhide_audio, size)
        else
            mBinding.tvHideUnHideText.text = resources.getString(R.string.label_unhide_document, size)
    }

    private fun showFABMenu() {
        isFABOpen = true
        if (getRecyclerAdapter() != null) {
            getRecyclerAdapter()!!.finishActMode()
        }
        if (mBinding.etSearch.visibility == View.VISIBLE) {
            mBinding.imgClose.performClick()
        }
        mBinding.imgAddHiddenPhoto.setImageDrawable(resources.getDrawable(R.drawable.ic_vault_close))
        mBinding.flBackground.beVisible()
        mBinding.llFromGallery.beVisible()
        mBinding.llFromFolder.beVisible()
    }

    private fun closeFABMenu() {
        isFABOpen = false
        mBinding.imgAddHiddenPhoto.setImageDrawable(resources.getDrawable(R.drawable.ic_add_hidden_new))
        mBinding.flBackground.beGone()
        mBinding.llFromGallery.beGone()
        mBinding.llFromFolder.beGone()
    }

    override fun onBackPressed() {
        when {
            isFABOpen -> {
                closeFABMenu()
            }
            else -> {
                super.onBackPressed()
            }
        }
    }
}