package com.gallery.photo.image.video.models

open class ThumbnailItem
