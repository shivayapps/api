package com.gallery.photo.image.video.models;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class RecoverPhotoListModel {

    Date Date = new Date();

    public Date getDate() {
        return Date;
    }

    public void setDate(java.util.Date date) {
        Date = date;
    }

    public List<RecoverImageModel> getRestoreModles() {
        return restoreModles;
    }

    public void setRestoreModles(List<RecoverImageModel> restoreModles) {
        this.restoreModles = restoreModles;
    }

    List<RecoverImageModel> restoreModles = new ArrayList<>();
}
