package com.gallery.photo.image.video.interfaces

import android.widget.ImageView

interface ImageEffectSelectListener {
    fun onEffectItemSelect(position:Int,imageView: ImageView)
}