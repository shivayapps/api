package com.gallery.photo.image.video.models

import androidx.annotation.Keep

@Keep
class QuestionDataList(val id: Int, val question: String, val answer: String, var expand: Boolean = false) {

}