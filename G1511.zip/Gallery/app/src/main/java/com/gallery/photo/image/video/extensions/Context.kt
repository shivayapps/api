package com.gallery.photo.image.video.extensions

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.*
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.database.Cursor
import android.graphics.Color
import android.graphics.Point
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import androidx.preference.PreferenceManager
import android.provider.BaseColumns
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.MediaStore.*
import android.provider.OpenableColumns
import android.telecom.TelecomManager
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import androidx.loader.content.CursorLoader
import com.github.ajalt.reprint.core.Reprint
import com.gallery.photo.image.video.helpers.*
import com.gallery.photo.image.video.helpers.MyContentProvider.Companion.COL_ACCENT_COLOR
import com.gallery.photo.image.video.helpers.MyContentProvider.Companion.COL_APP_ICON_COLOR
import com.gallery.photo.image.video.helpers.MyContentProvider.Companion.COL_BACKGROUND_COLOR
import com.gallery.photo.image.video.helpers.MyContentProvider.Companion.COL_LAST_UPDATED_TS
import com.gallery.photo.image.video.helpers.MyContentProvider.Companion.COL_NAVIGATION_BAR_COLOR
import com.gallery.photo.image.video.helpers.MyContentProvider.Companion.COL_PRIMARY_COLOR
import com.gallery.photo.image.video.helpers.MyContentProvider.Companion.COL_TEXT_COLOR
import com.gallery.photo.image.video.models.SharedTheme
import com.gallery.photo.image.video.views.*
import java.io.File
import java.util.*
import android.app.AppOpsManager
import android.app.ProgressDialog
import android.graphics.Bitmap
import android.graphics.PointF
import android.graphics.drawable.Drawable
import android.hardware.fingerprint.FingerprintManager
import android.media.AudioManager
import android.os.*
import android.provider.*
import android.provider.MediaStore.Files
import android.provider.MediaStore.Images
import android.text.TextUtils
import android.util.Log
import android.view.LayoutInflater
import android.widget.ImageView
import androidx.annotation.StringRes
import androidx.browser.customtabs.CustomTabsIntent
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.bumptech.glide.Glide
import com.bumptech.glide.Priority
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.load.resource.bitmap.CenterCrop
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.Target
import com.bumptech.glide.signature.ObjectKey
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.MainActivity.Companion.isInternalCall
import com.gallery.photo.image.video.activity.RecoverPhotoDateWiseActivity
import com.gallery.photo.image.video.database.DataDatabase
import com.gallery.photo.image.video.database.FavouriteDBHelper
import com.gallery.photo.image.video.database.FilesDatabase
import com.gallery.photo.image.video.database.GalleryDatabase
import com.gallery.photo.image.video.fragment.PhotoDirectoryFragment
import com.gallery.photo.image.video.fragment.VaultFragment
import com.gallery.photo.image.video.interfaces.*
import com.gallery.photo.image.video.models.*
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.views.MySquareImageView
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.helpers.*
import jp.co.cyberagent.android.gpuimage.*
import kotlinx.coroutines.launch
import org.apache.commons.io.IOUtils
import org.jetbrains.anko.layoutInflater
import java.io.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.Comparator
import kotlin.collections.ArrayList
import kotlin.collections.HashMap
import kotlin.collections.set

val Context.audioManager get() = getSystemService(Context.AUDIO_SERVICE) as AudioManager
const val OP_SYSTEM_ALERT_WINDOW = 24
fun Context.getHumanizedFilename(path: String): String {
    val humanized = humanizePath(path)
    return humanized.substring(humanized.lastIndexOf("/") + 1)
}


val Context.config: Config get() = Config.newInstance(applicationContext)

val Context.uDataDao: UDataDao get() = DataDatabase.getInstance(applicationContext).uDataDao()
val Context.hideFileDao: HideFilesDetailDao get() = FilesDatabase.getInstance(applicationContext).hideFilesDetailDao()
val Context.fakeHideFileDao: FakeHideFilesDetailDao get() = FilesDatabase.getInstance(applicationContext).fakeHideFilesDetailDao()
val Context.noteDao: NoteDao get() = FilesDatabase.getInstance(applicationContext).noteDao()
val Context.directoryDao: DirectoryDao get() = GalleryDatabase.getInstance(applicationContext).DirectoryDao()
val Context.hiddenDirectoryDao: HiddenDirectoryDao get() = GalleryDatabase.getInstance(applicationContext).HiddenDirectoryDao()
val Context.fakeVaultHiddenDirectoryDao: FakeVaultHiddenDirectoryDao get() = GalleryDatabase.getInstance(applicationContext).FakeVaultHiddenDirectoryDao()

val Context.photoDirectoryDao: PhotoDirectoryDao get() = GalleryDatabase.getInstance(applicationContext).PhotoDirectoryDao()
val Context.videoDirectoryDao: VideoDirectoryDao get() = GalleryDatabase.getInstance(applicationContext).VideoDirectoryDao()

val Context.mediaDB: MediumDao get() = GalleryDatabase.getInstance(applicationContext).MediumDao()
val Context.fakeVaultMediumDao: FakeVaultMediumDao get() = GalleryDatabase.getInstance(applicationContext).FakeVaultMediumDao()

val Context.dateTakensDB: DateTakensDao get() = GalleryDatabase.getInstance(applicationContext).DateTakensDao()

val Context.recycleBin: File get() = File(TRASH_PATH)
val Context.recycleBinPath: String get() = TRASH_PATH

val Context.recoverTrashPath: String get() = RECOVER_PATH
val Context.recoverTrash: File get() = File(RECOVER_PATH)

fun Context.movePinnedDirectoriesToFront(dirs: ArrayList<Directory>): ArrayList<Directory> {
    val foundFolders = ArrayList<Directory>()
    val pinnedFolders = config.pinnedFolders

    dirs.forEach {
        if (pinnedFolders.contains(it.path)) {
            foundFolders.add(it)
        }
    }

    dirs.removeAll(foundFolders)
    dirs.addAll(0, foundFolders)
    if (config.tempFolderPath.isNotEmpty()) {
        val newFolder = dirs.firstOrNull { it.path == config.tempFolderPath }
        if (newFolder != null) {
            dirs.remove(newFolder)
            dirs.add(0, newFolder)
        }
    }

    if (config.showRecycleBinAtFolders && config.showRecycleBinLast) {
        val binIndex = dirs.indexOfFirst { it.isRecycleBin() }
        if (binIndex != -1) {
            val bin = dirs.removeAt(binIndex)
            dirs.add(bin)
        }
    }
    return dirs
}

fun Context.getSortedDirectories(source: ArrayList<Directory>): ArrayList<Directory> {
    val sorting = config.directorySorting
    val dirs = source.clone() as ArrayList<Directory>

    if (sorting and SORT_BY_RANDOM != 0) {
        dirs.shuffle()
        return movePinnedDirectoriesToFront(dirs)
    } else if (sorting and SORT_BY_CUSTOM != 0) {
        val newDirsOrdered = ArrayList<Directory>()
        config.customFoldersOrder.split("|||").forEach { path ->
            val index = dirs.indexOfFirst { it.path == path }
            if (index != -1) {
                val dir = dirs.removeAt(index)
                newDirsOrdered.add(dir)
            }
        }

        dirs.mapTo(newDirsOrdered, { it })
        return newDirsOrdered
    }

    dirs.sortWith(Comparator { o1, o2 ->
        o1 as Directory
        o2 as Directory

        var result = when {
            sorting and SORT_BY_NAME != 0 -> {
                if (sorting and SORT_USE_NUMERIC_VALUE != 0) {
                    AlphanumericComparator().compare(o1.sortValue.lowercase(Locale.getDefault()), o2.sortValue.lowercase(Locale.getDefault()))
                } else {
                    o1.sortValue.lowercase(Locale.getDefault()).compareTo(o2.sortValue.lowercase(Locale.getDefault()))
                }
            }
            sorting and SORT_BY_PATH != 0 -> {
                if (sorting and SORT_USE_NUMERIC_VALUE != 0) {
                    AlphanumericComparator().compare(o1.sortValue.lowercase(Locale.getDefault()), o2.sortValue.lowercase(Locale.getDefault()))
                } else {
                    o1.sortValue.lowercase(Locale.getDefault()).compareTo(o2.sortValue.lowercase(Locale.getDefault()))
                }
            }
            sorting and SORT_BY_PATH != 0 -> AlphanumericComparator().compare(o1.sortValue.lowercase(Locale.getDefault()), o2.sortValue.lowercase(Locale.getDefault()))
            sorting and SORT_BY_SIZE != 0 -> (o1.sortValue.toLongOrNull() ?: 0).compareTo(o2.sortValue.toLongOrNull() ?: 0)
            sorting and SORT_BY_DATE_MODIFIED != 0 -> (o1.sortValue.toLongOrNull() ?: 0).compareTo(o2.sortValue.toLongOrNull() ?: 0)
            else -> (o1.sortValue.toLongOrNull() ?: 0).compareTo(o2.sortValue.toLongOrNull() ?: 0)
        }

        if (sorting and SORT_DESCENDING != 0) {
            result *= -1
        }
        result
    })

    return movePinnedDirectoriesToFront(dirs)
}

fun Context.getDirsToShow(dirs: ArrayList<Directory>, allDirs: ArrayList<Directory>, currentPathPrefix: String): ArrayList<Directory> {
    return if (config.groupDirectSubfolders) {
        dirs.forEach {
            it.subfoldersCount = 0
            it.subfoldersMediaCount = it.mediaCnt
        }

        val parentDirs = getDirectParentSubfolders(dirs, currentPathPrefix)
        updateSubfolderCounts(dirs, parentDirs)

        // show the current folder as an available option too, not just subfolders
        if (currentPathPrefix.isNotEmpty()) {
            val currentFolder = allDirs.firstOrNull { parentDirs.firstOrNull { it.path == currentPathPrefix } == null && it.path == currentPathPrefix }
            currentFolder?.apply {
                subfoldersCount = 1
                parentDirs.add(this)
            }
        }

        getSortedDirectories(parentDirs)
    } else {
        dirs.forEach { it.subfoldersMediaCount = it.mediaCnt }
        dirs
    }
}

fun Context.getDirectParentSubfolders(dirs: ArrayList<Directory>, currentPathPrefix: String): ArrayList<Directory> {
    val folders = dirs.map { it.path }.sorted().toMutableSet() as HashSet<String>
    val currentPaths = LinkedHashSet<String>()
    val foldersWithoutMediaFiles = ArrayList<String>()
    var newDirId = 1000L

    for (path in folders) {
        /*if (path == RECYCLE_BIN || path == FAVORITES) {
            continue
        }*/

        if (currentPathPrefix.isNotEmpty()) {
            if (!path.startsWith(currentPathPrefix, true)) {
                continue
            }

            if (!File(path).parent.equals(currentPathPrefix, true)) {
                continue
            }
        }

        if (currentPathPrefix.isNotEmpty() && path == currentPathPrefix || File(path).parent.equals(currentPathPrefix, true)) {
            currentPaths.add(path)
        } else if (folders.any { !it.equals(path, true) && (File(path).parent.equals(it, true) || File(it).parent.equals(File(path).parent, true)) }) {
            // if we have folders like
            // /storage/emulated/0/Pictures/Images and
            // /storage/emulated/0/Pictures/Screenshots,
            // but /storage/emulated/0/Pictures is empty, still Pictures with the first folders thumbnails and proper other info
            val parent = File(path).parent
            if (parent != null && !folders.contains(parent) && dirs.none { it.path == parent }) {
                currentPaths.add(parent)
                val isSortingAscending = config.sorting.isSortingAscending()
                val subDirs = dirs.filter { File(it.path).parent.equals(File(path).parent, true) } as ArrayList<Directory>
                if (subDirs.isNotEmpty()) {
                    val lastModified = if (isSortingAscending) {
                        subDirs.minByOrNull { it.modified } as Long
                    } else {
                        subDirs.maxByOrNull { it.modified } as Long
                    } ?: 0

                    val dateTaken = if (isSortingAscending) {
                        subDirs.minByOrNull { it.taken } as Long
                    } else {
                        subDirs.maxByOrNull { it.taken } as Long
                    } ?: 0

                    var mediaTypes = 0
                    subDirs.forEach {
                        mediaTypes = mediaTypes or it.types
                    }

                    val directory = Directory(
                        newDirId++,
                        parent,
                        subDirs.first().tmb,
                        getFolderNameFromPath(parent),
                        subDirs.sumBy { it.mediaCnt },
                        lastModified,
                        dateTaken,
                        subDirs.sumByLong { it.size },
                        getPathLocation(parent),
                        mediaTypes,
                        ""
                    )

                    directory.containsMediaFilesDirectly = false
                    dirs.add(directory)
                    currentPaths.add(parent)
                    foldersWithoutMediaFiles.add(parent)
                }
            }
        } else {
            currentPaths.add(path)
        }
    }

    var areDirectSubfoldersAvailable = false
    currentPaths.forEach {
        val path = it
        currentPaths.forEach {
            if (!foldersWithoutMediaFiles.contains(it) && !it.equals(path, true) && File(it).parent?.equals(path, true) == true) {
                areDirectSubfoldersAvailable = true
            }
        }
    }

    /* if (currentPathPrefix.isEmpty() && folders.contains(RECYCLE_BIN)) {
         currentPaths.add(RECYCLE_BIN)
     }*/

    if (currentPathPrefix.isEmpty() && folders.contains(FAVORITES)) {
        currentPaths.add(FAVORITES)
    }

    if (folders.size == currentPaths.size) {
        return dirs.filter { currentPaths.contains(it.path) } as ArrayList<Directory>
    }

    folders.clear()
    folders.addAll(currentPaths)

    val dirsToShow = dirs.filter { folders.contains(it.path) } as ArrayList<Directory>
    return if (areDirectSubfoldersAvailable) {
        getDirectParentSubfolders(dirsToShow, currentPathPrefix)
    } else {
        dirsToShow
    }
}

fun Context.updateSubfolderCounts(children: ArrayList<Directory>, parentDirs: ArrayList<Directory>) {
    for (child in children) {
        var longestSharedPath = ""
        for (parentDir in parentDirs) {
            if (parentDir.path == child.path) {
                longestSharedPath = child.path
                continue
            }

            if (child.path.startsWith(parentDir.path, true) && parentDir.path.length > longestSharedPath.length) {
                longestSharedPath = parentDir.path
            }
        }

        // make sure we count only the proper direct subfolders, grouped the same way as on the main screen
        parentDirs.firstOrNull { it.path == longestSharedPath }?.apply {
            if (path.equals(child.path, true) || path.equals(File(child.path).parent, true) || children.any { it.path.equals(File(child.path).parent, true) }) {
                if (child.containsMediaFilesDirectly) {
                    subfoldersCount++
                }

                if (path != child.path) {
                    subfoldersMediaCount += child.mediaCnt
                }
            }
        }
    }
}

fun Context.getNoMediaFolders(callback: (folders: ArrayList<String>) -> Unit) {
    ensureBackgroundThread {
        callback(getNoMediaFoldersSync())
    }
}

fun Context.getNoMediaFoldersSync(): ArrayList<String> {
    val folders = ArrayList<String>()

    val uri = Files.getContentUri("external")
    val projection = arrayOf(Files.FileColumns.DATA)
    val selection = "${Files.FileColumns.MEDIA_TYPE} = ? AND ${Files.FileColumns.TITLE} LIKE ?"
    val selectionArgs = arrayOf(Files.FileColumns.MEDIA_TYPE_NONE.toString(), "%$NOMEDIA%")
    val sortOrder = "${Files.FileColumns.DATE_MODIFIED} DESC"
    val OTGPath = config.OTGPath

    var cursor: Cursor? = null
    try {
        cursor = contentResolver.query(uri, projection, selection, selectionArgs, sortOrder)
        if (cursor?.moveToFirst() == true) {
            do {
                val path = cursor.getStringValue(Files.FileColumns.DATA) ?: continue
                val noMediaFile = File(path)
                if (getDoesFilePathExist(noMediaFile.absolutePath, OTGPath) && noMediaFile.name == NOMEDIA) {
                    folders.add(noMediaFile.parent)
                }
            } while (cursor.moveToNext())
        }
    } catch (ignored: Exception) {
    } finally {
        cursor?.close()
    }

    return folders
}

fun Context.rescanFolderMedia(path: String) {
    ensureBackgroundThread {
        rescanFolderMediaSync(path)
    }
}

fun Context.rescanFolderMediaSync(path: String) {
    getCachedMedia(path) {
        val cached = it
        getAllMedia(path, false, false, false, TYPE_IMAGES or TYPE_VIDEOS, GROUP_BY_NONE, false) {
            ensureBackgroundThread {
                val newMedia = it
                val media = newMedia.filter { it is Medium } as ArrayList<Medium>
                try {
                    mediaDB.insertAll(media)

                    cached.forEach {
                        if (!newMedia.contains(it)) {
                            val mediumPath = (it as? Medium)?.path
                            if (mediumPath != null && !mediumPath.startsWith(RECOVER_TRASH_BIN)) {
                                deleteDBPath(mediumPath)
                            }
                        }
                    }
                } catch (ignored: Exception) {
                }
            }
        }
    }
}

fun Context.storeDirectoryItems(items: ArrayList<Directory>) {
    ensureBackgroundThread {
        directoryDao.insertAll(items)
    }
}

fun Context.checkAppendingHidden(path: String, hidden: String, includedFolders: MutableSet<String>, noMediaFolders: ArrayList<String>): String {
    val dirName = getFolderNameFromPath(path)
    val folderNoMediaStatuses = java.util.HashMap<String, Boolean>()
    noMediaFolders.forEach { folder ->
        folderNoMediaStatuses["$folder/$NOMEDIA"] = true
    }

    return if (path.doesThisOrParentHaveNoMedia(folderNoMediaStatuses, null) && !path.isThisOrParentIncluded(includedFolders)) {
        "$dirName $hidden"
    } else {
        dirName
    }
}

fun Context.getFolderNameFromPath(path: String): String {
    return when (path) {
        internalStoragePath -> getString(R.string.internal)
        sdCardPath -> getString(R.string.sd_card)
        otgPath -> getString(R.string.usb)
        FAVORITES -> getString(R.string.favorites)
        RECYCLE_BIN -> getString(R.string.recycle_bin)
        else -> path.getFilenameFromPath()
    }
}

fun Context.loadImage(
    type: Int, path: String, target: MySquareImageView, horizontalScroll: Boolean, animateGifs: Boolean, cropThumbnails: Boolean,
    roundCorners: Int, signature: ObjectKey, skipMemoryCacheAtPaths: ArrayList<String>? = null
) {
    target.isHorizontalScrolling = horizontalScroll



    if (type == TYPE_IMAGES || type == TYPE_VIDEOS || type == TYPE_RAWS || type == TYPE_PORTRAITS) {
        if (type == TYPE_IMAGES && path.isPng()) {
            loadPng(path, target, cropThumbnails, roundCorners, signature, skipMemoryCacheAtPaths)
        } else {
            loadJpg(path, target, cropThumbnails, roundCorners, signature, skipMemoryCacheAtPaths)
        }
    } else if (type == TYPE_GIFS) {
        if (!animateGifs) {
            loadStaticGIF(path, target, cropThumbnails, roundCorners, signature, skipMemoryCacheAtPaths)
            return
        }

        try {
//            val gifDrawable = GifDrawable(path)
//            target.setImageDrawable(gifDrawable)
//            gifDrawable.start()
//
//            target.scaleType = if (cropThumbnails) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.FIT_CENTER
            //For rounded square GIF display
            loadEnimatedGIF(path, target, cropThumbnails, roundCorners, signature, skipMemoryCacheAtPaths)
        } catch (e: Exception) {
            loadStaticGIF(path, target, cropThumbnails, roundCorners, signature, skipMemoryCacheAtPaths)
        } catch (e: OutOfMemoryError) {
            loadStaticGIF(path, target, cropThumbnails, roundCorners, signature, skipMemoryCacheAtPaths)
        }
    } else if (type == TYPE_SVGS) {
//        loadSVG(path, target, cropThumbnails, roundCorners, signature)
    }
}

fun Context.addTempFolderIfNeeded(dirs: ArrayList<Directory>): ArrayList<Directory> {
    val tempFolderPath = config.tempFolderPath
    return if (tempFolderPath.isNotEmpty()) {
        val directories = ArrayList<Directory>()
        val newFolder = Directory(null, tempFolderPath, "", tempFolderPath.getFilenameFromPath(), 0, 0, 0, 0L, getPathLocation(tempFolderPath), 0, "")
        directories.add(newFolder)
        directories.addAll(dirs)
        directories
    } else {
        dirs
    }
}

fun Context.getPathLocation(path: String): Int {
    return when {
        isPathOnSD(path) -> LOCATION_SD
        isPathOnOTG(path) -> LOCATION_OTG
        else -> LOCATION_INTERNAL
    }
}

fun Context.loadPng(path: String, target: MySquareImageView, cropThumbnails: Boolean, roundCorners: Int, signature: ObjectKey, skipMemoryCacheAtPaths: ArrayList<String>? = null) {
    val options = RequestOptions()
        .signature(signature)
        .skipMemoryCache(skipMemoryCacheAtPaths?.contains(path) == true)
        .diskCacheStrategy(DiskCacheStrategy.ALL)
        .placeholder(R.drawable.image_placeholder)
        .format(DecodeFormat.PREFER_ARGB_8888)

    if (cropThumbnails) options.centerCrop() else options.fitCenter()
    var builder = Glide.with(applicationContext)
        .load(path)
        .apply(options)
        .listener(object : RequestListener<Drawable> {
            override fun onLoadFailed(e: GlideException?, model: Any?, targetBitmap: Target<Drawable>?, isFirstResource: Boolean): Boolean {
                e!!.printStackTrace()
//                tryLoadingWithPicasso(path, target, cropThumbnails, roundCorners, signature)
//                loadPng(path, target, cropThumbnails, roundCorners, signature, skipMemoryCacheAtPaths)
                return false
            }

            override fun onResourceReady(resource: Drawable?, model: Any?, targetBitmap: Target<Drawable>?, dataSource: DataSource?, isFirstResource: Boolean): Boolean {
                return false
            }
        })

    if (roundCorners != ROUNDED_CORNERS_NONE) {
        val cornerSize = if (roundCorners == ROUNDED_CORNERS_SMALL) R.dimen.rounded_corner_radius_small else R.dimen.rounded_corner_radius_big
        val cornerRadius = resources.getDimension(cornerSize).toInt()
        builder = builder.transform(CenterCrop(), RoundedCorners(cornerRadius))
    }
    try {
        builder.into(target)
    } catch (e: java.lang.Exception) {
        e.printStackTrace()
    }
}

fun Context.loadJpg(path: String, target: MySquareImageView, cropThumbnails: Boolean, roundCorners: Int, signature: ObjectKey, skipMemoryCacheAtPaths: ArrayList<String>? = null) {

    val options = RequestOptions()
        .signature(signature)
        .placeholder(R.drawable.image_placeholder)
        .skipMemoryCache(skipMemoryCacheAtPaths?.contains(path) == true)
        .diskCacheStrategy(DiskCacheStrategy.ALL)

    if (cropThumbnails) options.centerCrop() else options.fitCenter()
    var builder = Glide.with(applicationContext)
        .load(path)
        .apply(options)
//        .transition(DrawableTransitionOptions.withCrossFade())

    if (roundCorners != ROUNDED_CORNERS_NONE) {
        val cornerSize = if (roundCorners == ROUNDED_CORNERS_SMALL) R.dimen.rounded_corner_radius_small else R.dimen.rounded_corner_radius_big
        val cornerRadius = resources.getDimension(cornerSize).toInt()
        builder = builder.transform(CenterCrop(), RoundedCorners(cornerRadius))
    }

    builder.into(target)
}

fun Context.loadStaticGIF(path: String, target: MySquareImageView, cropThumbnails: Boolean, roundCorners: Int, signature: ObjectKey, skipMemoryCacheAtPaths: ArrayList<String>? = null) {
    val options = RequestOptions()
        .signature(signature)
        .skipMemoryCache(skipMemoryCacheAtPaths?.contains(path) == true)
        .priority(Priority.LOW)
        .diskCacheStrategy(DiskCacheStrategy.RESOURCE)

    if (cropThumbnails) options.centerCrop() else options.fitCenter()
    var builder = Glide.with(applicationContext)
        .asBitmap() // make sure the GIF wont animate
        .load(path)
        .apply(options)

    if (roundCorners != ROUNDED_CORNERS_NONE) {
        val cornerSize = if (roundCorners == ROUNDED_CORNERS_SMALL) R.dimen.rounded_corner_radius_small else R.dimen.rounded_corner_radius_big
        val cornerRadius = resources.getDimension(cornerSize).toInt()
        builder = builder.transform(CenterCrop(), RoundedCorners(cornerRadius))
    }

    builder.into(target)
}

fun Context.loadEnimatedGIF(path: String, target: MySquareImageView, cropThumbnails: Boolean, roundCorners: Int, signature: ObjectKey, skipMemoryCacheAtPaths: ArrayList<String>? = null) {
    val options = RequestOptions()
        .signature(signature)
        .skipMemoryCache(skipMemoryCacheAtPaths?.contains(path) == true)
        .priority(Priority.LOW)
        .placeholder(R.drawable.image_placeholder)
        .diskCacheStrategy(DiskCacheStrategy.RESOURCE)

    if (cropThumbnails) options.centerCrop() else options.fitCenter()
    var builder = Glide.with(applicationContext)
        .asGif() // make sure the GIF wont animate
        .load(path)
        .apply(options)

    if (roundCorners != ROUNDED_CORNERS_NONE) {
        val cornerSize = if (roundCorners == ROUNDED_CORNERS_SMALL) R.dimen.rounded_corner_radius_small else R.dimen.rounded_corner_radius_big
        val cornerRadius = resources.getDimension(cornerSize).toInt()
        builder = builder.transform(CenterCrop(), RoundedCorners(cornerRadius))
    }

    builder.into(target)
}


fun Context.getCachedDirectories(
    getVideosOnly: Boolean = false,
    getImagesOnly: Boolean = false,
    forceShowHidden: Boolean = false,
    getAllDir: Boolean = false,
    callback: (ArrayList<Directory>) -> Unit
) {
    ensureBackgroundThread {
//        try {
//            Process.setThreadPriority(Process.THREAD_PRIORITY_MORE_FAVORABLE)
//        } catch (ignored: Exception) {
//        }

        val directories = try {
            directoryDao.getAll() as ArrayList<Directory>
        } catch (e: Exception) {
            ArrayList<Directory>()
        }
        if (getAllDir) {
            val photoDirectories = try {
                photoDirectoryDao.getAll() as ArrayList<PhotoDirectory>
            } catch (e: Exception) {
                ArrayList<Directory>()
            }
            photoDirectories.forEach {
                directories.add((it as PhotoDirectory).getConvertedDirectory())
            }
            val videoDirectories = try {
                videoDirectoryDao.getAll() as ArrayList<VideoDirectory>
            } catch (e: Exception) {
                ArrayList<Directory>()
            }
            videoDirectories.forEach {
                directories.add((it as VideoDirectory).getConvertedDirectory())
            }
        }
        if (!config.showRecycleBinAtFolders) {
            directories.removeAll { it.isRecycleBin() }
        }

        val shouldShowHidden = config.shouldShowHidden || forceShowHidden
        val excludedPaths = config.excludedFolders
        val includedPaths = config.includedFolders

        val folderNoMediaStatuses = HashMap<String, Boolean>()
        val noMediaFolders = getNoMediaFoldersSync()
        noMediaFolders.forEach { folder ->
            folderNoMediaStatuses["$folder/$NOMEDIA"] = true
        }

        var filteredDirectories = directories.filter {
            it.path.shouldFolderBeVisible(excludedPaths, includedPaths, shouldShowHidden, folderNoMediaStatuses) { path, hasNoMedia ->
                folderNoMediaStatuses[path] = hasNoMedia
            }
        } as ArrayList<Directory>
        val filterMedia = config.filterMedia

        filteredDirectories = (when {
            getVideosOnly -> filteredDirectories.filter { it.types and TYPE_VIDEOS != 0 }
            getImagesOnly -> filteredDirectories.filter { it.types and TYPE_IMAGES != 0 }
            else -> filteredDirectories.filter {
                (filterMedia and TYPE_IMAGES != 0 && it.types and TYPE_IMAGES != 0) ||
                        (filterMedia and TYPE_VIDEOS != 0 && it.types and TYPE_VIDEOS != 0) ||
                        (filterMedia and TYPE_GIFS != 0 && it.types and TYPE_GIFS != 0) ||
                        (filterMedia and TYPE_RAWS != 0 && it.types and TYPE_RAWS != 0) ||
                        (filterMedia and TYPE_SVGS != 0 && it.types and TYPE_SVGS != 0) ||
                        (filterMedia and TYPE_PORTRAITS != 0 && it.types and TYPE_PORTRAITS != 0)
            }
        }) as ArrayList<Directory>

        val hiddenString = resources.getString(R.string.hidden)
        if (shouldShowHidden) {
            filteredDirectories.forEach {
                val noMediaPath = "${it.path}/$NOMEDIA"
                val hasNoMedia = if (folderNoMediaStatuses.keys.contains(noMediaPath)) {
                    folderNoMediaStatuses[noMediaPath]!!
                } else {
                    it.path.doesThisOrParentHaveNoMedia(folderNoMediaStatuses) { path, hasNoMedia ->
                        val newPath = "$path/$NOMEDIA"
                        folderNoMediaStatuses[newPath] = hasNoMedia
                    }
                }


                it.name = if (hasNoMedia && !it.path.isThisOrParentIncluded(includedPaths)) {
                    "${it.name.removeSuffix(hiddenString).trim()} $hiddenString"
                } else {
                    it.name.removeSuffix(hiddenString).trim()
                }
            }
        } else {
            //For hidden folder not display in photo/video
            filteredDirectories = filteredDirectories.filter {
                !it.path.containsNoMedia() && !it.name.contains(hiddenString)

            } as ArrayList<Directory>
        }

        val clone = filteredDirectories.clone() as ArrayList<Directory>
        callback(clone.distinctBy { it.path.getDistinctPath() } as ArrayList<Directory>)
        removeInvalidDBDirectories(filteredDirectories)
    }
}

fun Context.getCachedPicturesDirectories(forceShowHidden: Boolean = false, callback: (ArrayList<Directory>) -> Unit) {
    ensureBackgroundThread {
//        try {
//            Process.setThreadPriority(Process.THREAD_PRIORITY_MORE_FAVORABLE)
//        } catch (ignored: Exception) {
//        }

        val hiddenDirectories = try {
            photoDirectoryDao.getAll() as ArrayList<PhotoDirectory>
        } catch (e: Exception) {
            ArrayList<Directory>()
        }
        var directories = ArrayList<Directory>()
        hiddenDirectories.forEach {
            directories.add((it as PhotoDirectory).getConvertedDirectory())
        }
        if (!config.showRecycleBinAtFolders) {
            directories.removeAll { it.isRecycleBin() }
        }

        val shouldShowHidden = config.shouldShowHidden || forceShowHidden
        val excludedPaths = config.excludedFolders
        val includedPaths = config.includedFolders

        val folderNoMediaStatuses = HashMap<String, Boolean>()
        val noMediaFolders = getNoMediaFoldersSync()
        noMediaFolders.forEach { folder ->
            folderNoMediaStatuses["$folder/$NOMEDIA"] = true
        }

        var filteredDirectories = directories.filter {
            it.path.shouldFolderBeVisible(excludedPaths, includedPaths, shouldShowHidden, folderNoMediaStatuses) { path, hasNoMedia ->
                folderNoMediaStatuses[path] = hasNoMedia
            }
        } as ArrayList<Directory>
        val filterMedia = config.filterMedia
        filteredDirectories = filteredDirectories.filter { it.types and TYPE_IMAGES != 0 } as ArrayList<Directory>


        val hiddenString = resources.getString(R.string.hidden)
        if (shouldShowHidden) {
            filteredDirectories.forEach {
                val noMediaPath = "${it.path}/$NOMEDIA"
                val hasNoMedia = if (folderNoMediaStatuses.keys.contains(noMediaPath)) {
                    folderNoMediaStatuses[noMediaPath]!!
                } else {
                    it.path.doesThisOrParentHaveNoMedia(folderNoMediaStatuses) { path, hasNoMedia ->
                        val newPath = "$path/$NOMEDIA"
                        folderNoMediaStatuses[newPath] = hasNoMedia
                    }
                }


                it.name = if (hasNoMedia && !it.path.isThisOrParentIncluded(includedPaths)) {
                    "${it.name.removeSuffix(hiddenString).trim()} $hiddenString"
                } else {
                    it.name.removeSuffix(hiddenString).trim()
                }
            }
        } else {
            //For hidden folder not display in photo/video
            filteredDirectories = filteredDirectories.filter {
                !it.path.containsNoMedia() && !it.name.contains(hiddenString)

            } as ArrayList<Directory>
        }

        val clone = filteredDirectories.clone() as ArrayList<Directory>
        callback(clone.distinctBy { it.path.getDistinctPath() } as ArrayList<Directory>)
        removeInvalidDBDirectories(filteredDirectories)
    }
}

fun Context.getCachedVideoDirectories(forceShowHidden: Boolean = false, callback: (ArrayList<Directory>) -> Unit) {
    ensureBackgroundThread {
//        try {
//            Process.setThreadPriority(Process.THREAD_PRIORITY_MORE_FAVORABLE)
//        } catch (ignored: Exception) {
//        }

        val hiddenDirectories = try {
            videoDirectoryDao.getAll() as ArrayList<VideoDirectory>
        } catch (e: Exception) {
            ArrayList<Directory>()
        }
        var directories = ArrayList<Directory>()
        hiddenDirectories.forEach {
            directories.add((it as VideoDirectory).getConvertedDirectory())
        }
        if (!config.showRecycleBinAtFolders) {
            directories.removeAll { it.isRecycleBin() }
        }

        val shouldShowHidden = config.shouldShowHidden || forceShowHidden
        val excludedPaths = config.excludedFolders
        val includedPaths = config.includedFolders

        val folderNoMediaStatuses = HashMap<String, Boolean>()
        val noMediaFolders = getNoMediaFoldersSync()
        noMediaFolders.forEach { folder ->
            folderNoMediaStatuses["$folder/$NOMEDIA"] = true
        }

        var filteredDirectories = directories.filter {
            it.path.shouldFolderBeVisible(excludedPaths, includedPaths, shouldShowHidden, folderNoMediaStatuses) { path, hasNoMedia ->
                folderNoMediaStatuses[path] = hasNoMedia
            }
        } as ArrayList<Directory>
        val filterMedia = config.filterMedia

        filteredDirectories = filteredDirectories.filter { it.types and TYPE_VIDEOS != 0 } as ArrayList<Directory>

        val hiddenString = resources.getString(R.string.hidden)
        if (shouldShowHidden) {
            filteredDirectories.forEach {
                val noMediaPath = "${it.path}/$NOMEDIA"
                val hasNoMedia = if (folderNoMediaStatuses.keys.contains(noMediaPath)) {
                    folderNoMediaStatuses[noMediaPath]!!
                } else {
                    it.path.doesThisOrParentHaveNoMedia(folderNoMediaStatuses) { path, hasNoMedia ->
                        val newPath = "$path/$NOMEDIA"
                        folderNoMediaStatuses[newPath] = hasNoMedia
                    }
                }


                it.name = if (hasNoMedia && !it.path.isThisOrParentIncluded(includedPaths)) {
                    "${it.name.removeSuffix(hiddenString).trim()} $hiddenString"
                } else {
                    it.name.removeSuffix(hiddenString).trim()
                }
            }
        } else {
            //For hidden folder not display in photo/video
            filteredDirectories = filteredDirectories.filter {
                !it.path.containsNoMedia() && !it.name.contains(hiddenString)

            } as ArrayList<Directory>
        }

        val clone = filteredDirectories.clone() as ArrayList<Directory>
        callback(clone.distinctBy { it.path.getDistinctPath() } as ArrayList<Directory>)
        removeInvalidDBDirectories(filteredDirectories)
    }
}

fun Context.getCachedHiddenDirectoriesAccordingType(forceShowHidden: Boolean = false, callback: (ArrayList<Directory>) -> Unit) {
    ensureBackgroundThread {
        val hiddenDirectories = try {
            hiddenDirectoryDao.getAll() as ArrayList<HiddenDirectory>
        } catch (e: Exception) {
            ArrayList<Directory>()
        }
        var directories = ArrayList<Directory>()
        hiddenDirectories.forEach {
            directories.add((it as HiddenDirectory).getConvertedDirectory())
        }
        if (!config.showRecycleBinAtFolders) {
            directories.removeAll { it.isRecycleBin() }
        }

        val shouldShowHidden = config.shouldShowHidden || forceShowHidden
        val excludedPaths = config.excludedFolders
        val includedPaths = config.includedFolders

        val folderNoMediaStatuses = HashMap<String, Boolean>()
        val noMediaFolders = getNoMediaFoldersSync()
        noMediaFolders.forEach { folder ->
            folderNoMediaStatuses["$folder/$NOMEDIA"] = true
        }

        var filteredDirectories = directories.filter {
            it.path.shouldFolderBeVisible(excludedPaths, includedPaths, shouldShowHidden, folderNoMediaStatuses) { path, hasNoMedia ->
                folderNoMediaStatuses[path] = hasNoMedia
            }
        } as ArrayList<Directory>


        val hiddenString = resources.getString(R.string.hidden)
        if (shouldShowHidden) {
            filteredDirectories.forEach {
                val noMediaPath = "${it.path}/$NOMEDIA"
                val hasNoMedia = if (folderNoMediaStatuses.keys.contains(noMediaPath)) {
                    folderNoMediaStatuses[noMediaPath]!!
                } else {
                    it.path.doesThisOrParentHaveNoMedia(folderNoMediaStatuses) { path, hasNoMedia ->
                        val newPath = "$path/$NOMEDIA"
                        folderNoMediaStatuses[newPath] = hasNoMedia
                    }
                }


                it.name = if (hasNoMedia && !it.path.isThisOrParentIncluded(includedPaths)) {
                    "${it.name.removeSuffix(hiddenString).trim()} $hiddenString"
                } else {
                    it.name.removeSuffix(hiddenString).trim()
                }
            }
        } else {
            //For hidden folder not display in photo/video
            filteredDirectories = filteredDirectories.filter {
                !it.path.containsNoMedia() && !it.name.contains(hiddenString)

            } as ArrayList<Directory>
        }

        val clone = filteredDirectories.clone() as ArrayList<Directory>
        callback(clone.distinctBy { it.path.getDistinctPath() } as ArrayList<Directory>)
        removeInvalidDBDirectories(filteredDirectories)
    }
}


fun Context.getCachedHiddenDirectories(getVideosOnly: Boolean = false, getImagesOnly: Boolean = false, forceShowHidden: Boolean = false, callback: (ArrayList<Directory>) -> Unit) {
    ensureBackgroundThread {
//        try {
//            Process.setThreadPriority(Process.THREAD_PRIORITY_MORE_FAVORABLE)
//        } catch (ignored: Exception) {
//        }

        val hiddenDirectories = try {
            hiddenDirectoryDao.getAll() as ArrayList<HiddenDirectory>
        } catch (e: Exception) {
            ArrayList<Directory>()
        }
        var directories = ArrayList<Directory>()
        hiddenDirectories.forEach {
            directories.add((it as HiddenDirectory).getConvertedDirectory())
        }
        if (!config.showRecycleBinAtFolders) {
            directories.removeAll { it.isRecycleBin() }
        }

        val shouldShowHidden = config.shouldShowHidden || forceShowHidden
        val excludedPaths = config.excludedFolders
        val includedPaths = config.includedFolders

        val folderNoMediaStatuses = HashMap<String, Boolean>()
        val noMediaFolders = getNoMediaFoldersSync()
        noMediaFolders.forEach { folder ->
            folderNoMediaStatuses["$folder/$NOMEDIA"] = true
        }

        var filteredDirectories = directories.filter {
            it.path.shouldFolderBeVisible(excludedPaths, includedPaths, shouldShowHidden, folderNoMediaStatuses) { path, hasNoMedia ->
                folderNoMediaStatuses[path] = hasNoMedia
            }
        } as ArrayList<Directory>


        val hiddenString = resources.getString(R.string.hidden)
        if (shouldShowHidden) {
            filteredDirectories.forEach {
                val noMediaPath = "${it.path}/$NOMEDIA"
                val hasNoMedia = if (folderNoMediaStatuses.keys.contains(noMediaPath)) {
                    folderNoMediaStatuses[noMediaPath]!!
                } else {
                    it.path.doesThisOrParentHaveNoMedia(folderNoMediaStatuses) { path, hasNoMedia ->
                        val newPath = "$path/$NOMEDIA"
                        folderNoMediaStatuses[newPath] = hasNoMedia
                    }
                }


                it.name = if (hasNoMedia && !it.path.isThisOrParentIncluded(includedPaths)) {
                    "${it.name.removeSuffix(hiddenString).trim()} $hiddenString"
                } else {
                    it.name.removeSuffix(hiddenString).trim()
                }
            }
        } else {
            //For hidden folder not display in photo/video
            filteredDirectories = filteredDirectories.filter {
                !it.path.containsNoMedia() && !it.name.contains(hiddenString)

            } as ArrayList<Directory>
        }

        val clone = filteredDirectories.clone() as ArrayList<Directory>
        callback(clone.distinctBy { it.path.getDistinctPath() } as ArrayList<Directory>)
        removeInvalidDBDirectories(filteredDirectories)
    }
}

fun Context.getCachedFakeVaultDirectories(forceShowHidden: Boolean = false, callback: (ArrayList<Directory>) -> Unit) {
    ensureBackgroundThread {
        val fakeVaultDirectories = try {
            fakeVaultHiddenDirectoryDao.getAll() as ArrayList<FakeVaultHiddenDirectory>
        } catch (e: Exception) {
            ArrayList<Directory>()
        }
        var directories = ArrayList<Directory>()
        fakeVaultDirectories.forEach {
            directories.add((it as FakeVaultHiddenDirectory).getConvertedDirectory())
        }
        if (!config.showRecycleBinAtFolders) {
            directories.removeAll { it.isRecycleBin() }
        }

        val shouldShowHidden = config.shouldShowHidden || forceShowHidden
        val excludedPaths = config.excludedFolders
        val includedPaths = config.includedFolders

        val folderNoMediaStatuses = HashMap<String, Boolean>()
        val noMediaFolders = getNoMediaFoldersSync()
        noMediaFolders.forEach { folder ->
            folderNoMediaStatuses["$folder/$NOMEDIA"] = true
        }

        var filteredDirectories = directories.filter {
            it.path.shouldFolderBeVisible(excludedPaths, includedPaths, shouldShowHidden, folderNoMediaStatuses) { path, hasNoMedia ->
                folderNoMediaStatuses[path] = hasNoMedia
            }
        } as ArrayList<Directory>


        val hiddenString = resources.getString(R.string.hidden)
        if (shouldShowHidden) {
            filteredDirectories.forEach {
                val noMediaPath = "${it.path}/$NOMEDIA"
                val hasNoMedia = if (folderNoMediaStatuses.keys.contains(noMediaPath)) {
                    folderNoMediaStatuses[noMediaPath]!!
                } else {
                    it.path.doesThisOrParentHaveNoMedia(folderNoMediaStatuses) { path, hasNoMedia ->
                        val newPath = "$path/$NOMEDIA"
                        folderNoMediaStatuses[newPath] = hasNoMedia
                    }
                }
                it.name = if (hasNoMedia && !it.path.isThisOrParentIncluded(includedPaths)) {
                    "${it.name.removeSuffix(hiddenString).trim()} $hiddenString"
                } else {
                    it.name.removeSuffix(hiddenString).trim()
                }
            }
        } else {
            //For hidden folder not display in photo/video
            filteredDirectories = filteredDirectories.filter {
                !it.path.containsNoMedia() && !it.name.contains(hiddenString)

            } as ArrayList<Directory>
        }

        val clone = filteredDirectories.clone() as ArrayList<Directory>
        callback(clone.distinctBy { it.path.getDistinctPath() } as ArrayList<Directory>)
        removeInvalidDBDirectories(filteredDirectories)
    }
}

fun Context.getFavoritePaths(): ArrayList<String> {
    /*return try {
        favoritesDB.getValidFavoritePaths() as ArrayList<String>
    } catch (e: Exception) {
        ArrayList()
    }*/
    return ArrayList()
}

fun Context.getOTGFolderChildren(path: String) = getDocumentFile(path)?.listFiles()
fun Context.getOTGFolderChildrenNames(path: String) = getOTGFolderChildren(path)?.map { it.name }?.toMutableList()


fun Context.deleteDBPath(path: String) {
    if (path.startsWith(recycleBinPath))
        deleteMediumWithPath(path.replaceFirst(recycleBinPath, RECYCLE_BIN))
    else if (path.startsWith(recoverTrashPath))
        deleteMediumWithPath(path.replaceFirst(recoverTrashPath, RECOVER_TRASH_BIN))
}

fun Context.deleteMediumWithPath(path: String) {
    try {
        mediaDB.deleteMediumPath(path)
    } catch (ignored: Exception) {
    }
}


fun Context.updateDBMediaPath(oldPath: String, newPath: String, isFromFakeVault: Boolean = false) {
    val newFilename = newPath.getFilenameFromPath()
    val newParentPath = newPath.getParentPath()
    try {
        mediaDB.updateMedium(newFilename, newPath, newParentPath, oldPath)
        if (isFromFakeVault) {
            fakeVaultMediumDao.updateMedium(newFilename, newPath, newParentPath, oldPath)
        }
//        favoritesDB.updateFavorite(newFilename, newPath, newParentPath, oldPath)
    } catch (ignored: Exception) {
    }
}

// remove the "recycle_bin" from the file path prefix, replace it with real bin path /data/user...
fun Context.getUpdatedDeletedMedia(): ArrayList<Medium> {
    val media = try {
        mediaDB.getDeletedMedia() as ArrayList<Medium>
    } catch (ignored: Exception) {
        ArrayList<Medium>()
    }

    media.forEach {
        it.path = File(recycleBinPath, it.path.removePrefix(RECYCLE_BIN)).toString()
    }
    return media
}

fun Context.getUpdatedTrashMediaPath(media: ArrayList<Medium>): ArrayList<Medium> {
    media.forEach {
        it.path = File(recycleBinPath, it.path.removePrefix(RECYCLE_BIN)).toString()
    }
    return media
}

fun Context.getUpdatedRecoverTrashMediaPath(media: ArrayList<Medium>): ArrayList<Medium> {
    media.forEach {
        it.path = File(recoverTrashPath, it.path.removePrefix(RECOVER_TRASH_BIN)).toString()
    }
    return media
}

fun Context.getUpdatedTrashFilePath(media: ArrayList<HideFilesDetail>): ArrayList<HideFilesDetail> {
    media.forEach {
        it.path = File(recycleBinPath, it.path.removePrefix(RECYCLE_BIN)).toString()
    }
    return media
}


fun Context.getCachedMedia(path: String, getVideosOnly: Boolean = false, getImagesOnly: Boolean = false, callback: (ArrayList<ThumbnailItem>) -> Unit) {
    ensureBackgroundThread {
        val mediaFetcher = MediaFetcher(this)
        val foldersToScan = if (path.isEmpty()) mediaFetcher.getFoldersToScan(TYPE_VIDEOS or TYPE_IMAGES, false) else arrayListOf(path)
        var media = ArrayList<Medium>()
        if (path == FAVORITES) {
            media.addAll(mediaDB.getFavorites())
        }

        if (path == RECYCLE_BIN) {
            media.addAll(getUpdatedDeletedMedia())
        }

        if (config.filterMedia and TYPE_PORTRAITS != 0) {
            val foldersToAdd = ArrayList<String>()
            for (folder in foldersToScan) {
                val allFiles = File(folder).listFiles() ?: continue
                allFiles.filter { it.name.startsWith("img_", true) && it.isDirectory }.forEach {
                    foldersToAdd.add(it.absolutePath)
                }
            }
            foldersToScan.addAll(foldersToAdd)
        }

        val shouldShowHidden = config.shouldShowHidden
        foldersToScan.filter { path.isNotEmpty() || !config.isFolderProtected(it) }.forEach {
            try {
                val currMedia = mediaDB.getMediaFromPath(it)
                media.addAll(currMedia)
            } catch (ignored: Exception) {
            }
        }

        if (!shouldShowHidden) {
            media = media.filter { !it.path.contains("/.") } as ArrayList<Medium>
        }

        val filterMedia = config.filterMedia
        media = (when {
            getVideosOnly -> media.filter { it.type == TYPE_VIDEOS }
            getImagesOnly -> media.filter { it.type == TYPE_IMAGES }
            else -> media.filter {
                (filterMedia and TYPE_IMAGES != 0 && it.type == TYPE_IMAGES) ||
                        (filterMedia and TYPE_VIDEOS != 0 && it.type == TYPE_VIDEOS) ||
                        (filterMedia and TYPE_GIFS != 0 && it.type == TYPE_GIFS) ||
                        (filterMedia and TYPE_RAWS != 0 && it.type == TYPE_RAWS) ||
                        (filterMedia and TYPE_SVGS != 0 && it.type == TYPE_SVGS) ||
                        (filterMedia and TYPE_PORTRAITS != 0 && it.type == TYPE_PORTRAITS)
            }
        }) as ArrayList<Medium>

        val pathToUse = if (path.isEmpty()) SHOW_ALL else path
        mediaFetcher.sortMedia(media, config.getFolderSorting(pathToUse))
        val grouped = mediaFetcher.groupMedia(media, pathToUse, GROUP_BY_NONE)
        callback(grouped.clone() as ArrayList<ThumbnailItem>)
        val OTGPath = config.OTGPath

        try {
            val mediaToDelete = ArrayList<Medium>()
            // creating a new thread intentionally, do not reuse the common background thread
            Thread {
                media.filter { !getDoesFilePathExist(it.path, OTGPath) }.forEach {
                    if (it.path.startsWith(recycleBinPath)) {
                        deleteDBPath(it.path)
                    } else {
                        if (!it.path.startsWith(RECOVER_TRASH_BIN)) {
                            mediaToDelete.add(it)
                        }
                    }
                }

                if (mediaToDelete.isNotEmpty()) {
                    mediaDB.deleteMedia(*mediaToDelete.toTypedArray())

//                    mediaToDelete.filter { it.isFavorite }.forEach {
//                        favoritesDB.deleteFavoritePath(it.path)
//                    }
                }
            }.start()
        } catch (ignored: Exception) {
        }
    }
}

fun Context.removeInvalidDBDirectories(dirs: ArrayList<Directory>? = null) {
    val dirsToCheck = dirs ?: directoryDao.getAll()
    val OTGPath = config.OTGPath
    dirsToCheck.filter { !it.areFavorites() && !it.isRecycleBin() && !getDoesFilePathExist(it.path, OTGPath) && it.path != config.tempFolderPath }.forEach {
        try {
            directoryDao.deleteDirPath(it.path)
        } catch (ignored: Exception) {
        }
    }
}

fun Context.createDirectoryFromMedia(
    path: String, curMedia: ArrayList<Medium>, albumCovers: ArrayList<AlbumCover>, hiddenString: String,
    includedFolders: MutableSet<String>, getProperFileSize: Boolean, noMediaFolders: ArrayList<String>
): Directory {
    val OTGPath = config.OTGPath
    val grouped = MediaFetcher(this).groupMedia(curMedia, path, GROUP_BY_NONE)
    var thumbnail: String? = null

    albumCovers.forEach {
        if (it.path == path && getDoesFilePathExist(it.tmb, OTGPath)) {
            thumbnail = it.tmb
        }
    }

    if (thumbnail == null) {
        val sortedMedia = grouped.filter { it is Medium }.toMutableList() as ArrayList<Medium>
        thumbnail = sortedMedia.firstOrNull { getDoesFilePathExist(it.path, OTGPath) }?.path ?: ""
    }

    if (config.OTGPath.isNotEmpty() && thumbnail!!.startsWith(config.OTGPath)) {
        thumbnail = thumbnail!!.getOTGPublicPath(applicationContext)
    }

    val isSortingAscending = config.directorySorting.isSortingAscending()
    val defaultMedium = Medium(0, "", "", "", 0L, 0L, 0L, 0, 0, false, 0L)
    val firstItem = curMedia.firstOrNull() ?: defaultMedium
    val lastItem = curMedia.lastOrNull() ?: defaultMedium
    val dirName = checkAppendingHidden(path, hiddenString, includedFolders, noMediaFolders)
    val lastModified = if (isSortingAscending) Math.min(firstItem.modified, lastItem.modified) else Math.max(firstItem.modified, lastItem.modified)
    val dateTaken = if (isSortingAscending) Math.min(firstItem.taken, lastItem.taken) else Math.max(firstItem.taken, lastItem.taken)
    val size = if (getProperFileSize) curMedia.sumByLong { it.size } else 0L
    val mediaTypes = curMedia.getDirMediaTypes()
    val sortValue = getDirectorySortingValue(curMedia, path, dirName, size)
    return Directory(null, path, thumbnail!!, dirName, curMedia.size, lastModified, dateTaken, size, getPathLocation(path), mediaTypes, sortValue, actualFolderCount = curMedia.size)
}

fun Context.getDirectorySortingValue(media: ArrayList<Medium>, path: String, name: String, size: Long): String {
    val sorting = config.directorySorting
    val sorted = when {
        sorting and SORT_BY_NAME != 0 -> return name
        sorting and SORT_BY_PATH != 0 -> return path
        sorting and SORT_BY_SIZE != 0 -> return size.toString()
        sorting and SORT_BY_DATE_MODIFIED != 0 -> media.sortedBy { it.modified }
        sorting and SORT_BY_DATE_TAKEN != 0 -> media.sortedBy { it.taken }
        else -> media
    }

    val relevantMedium = if (sorting.isSortingAscending()) {
        sorted.firstOrNull() ?: return ""
    } else {
        sorted.lastOrNull() ?: return ""
    }

    val result: Any = when {
        sorting and SORT_BY_DATE_MODIFIED != 0 -> relevantMedium.modified
        sorting and SORT_BY_DATE_TAKEN != 0 -> relevantMedium.taken
        else -> 0
    }

    return result.toString()
}

fun Context.updateDirectoryPath(path: String) {
    val mediaFetcher = MediaFetcher(applicationContext)
    val getImagesOnly = true
    val getVideosOnly = true
    val hiddenString = getString(R.string.hidden)
    val albumCovers = config.parseAlbumCovers()
    val includedFolders = config.includedFolders
    val noMediaFolders = getNoMediaFoldersSync()

    val sorting = config.getFolderSorting(path)
    val grouping = config.getFolderGrouping(path)
    val getProperDateTaken = config.directorySorting and SORT_BY_DATE_TAKEN != 0 ||
            sorting and SORT_BY_DATE_TAKEN != 0 ||
            grouping and GROUP_BY_DATE_TAKEN_DAILY != 0 ||
            grouping and GROUP_BY_DATE_TAKEN_MONTHLY != 0

    val getProperLastModified = config.directorySorting and SORT_BY_DATE_MODIFIED != 0 ||
            sorting and SORT_BY_DATE_MODIFIED != 0 ||
            grouping and GROUP_BY_LAST_MODIFIED_DAILY != 0 ||
            grouping and GROUP_BY_LAST_MODIFIED_MONTHLY != 0

    val getProperFileSize = config.directorySorting and SORT_BY_SIZE != 0

    val lastModifieds = if (getProperLastModified) mediaFetcher.getFolderLastModifieds(path) else HashMap()
    val dateTakens = mediaFetcher.getFolderDateTakens(path)
    val favoritePaths = getFavoritePaths()
    val curMedia = mediaFetcher.getFilesFrom(
        path, getImagesOnly, getVideosOnly, getProperDateTaken, getProperLastModified, getProperFileSize,
        favoritePaths, false, false, lastModifieds, dateTakens
    )
    val directory = createDirectoryFromMedia(path, curMedia, albumCovers, hiddenString, includedFolders, getProperFileSize, noMediaFolders)
    updateDBDirectory(directory)
    updatePhotoVideoDirectoryPath(path, true, false)
    updatePhotoVideoDirectoryPath(path, false, true)
}

fun Context.addDirectoryPath(path: String) {
    val mediaFetcher = MediaFetcher(applicationContext)
    val getImagesOnly = true
    val getVideosOnly = true
    val hiddenString = getString(R.string.hidden)
    val albumCovers = config.parseAlbumCovers()
    val includedFolders = config.includedFolders
    val noMediaFolders = getNoMediaFoldersSync()

    val sorting = config.getFolderSorting(path)
    val grouping = config.getFolderGrouping(path)
    val getProperDateTaken = config.directorySorting and SORT_BY_DATE_TAKEN != 0 ||
            sorting and SORT_BY_DATE_TAKEN != 0 ||
            grouping and GROUP_BY_DATE_TAKEN_DAILY != 0 ||
            grouping and GROUP_BY_DATE_TAKEN_MONTHLY != 0

    val getProperLastModified = config.directorySorting and SORT_BY_DATE_MODIFIED != 0 ||
            sorting and SORT_BY_DATE_MODIFIED != 0 ||
            grouping and GROUP_BY_LAST_MODIFIED_DAILY != 0 ||
            grouping and GROUP_BY_LAST_MODIFIED_MONTHLY != 0

    val getProperFileSize = config.directorySorting and SORT_BY_SIZE != 0

    val lastModifieds = if (getProperLastModified) mediaFetcher.getFolderLastModifieds(path) else HashMap()
    val dateTakens = mediaFetcher.getFolderDateTakens(path)
    val favoritePaths = getFavoritePaths()
    val curMedia = mediaFetcher.getFilesFrom(
        path, getImagesOnly, getVideosOnly, getProperDateTaken, getProperLastModified, getProperFileSize,
        favoritePaths, false, false, lastModifieds, dateTakens
    )
    val directory = createDirectoryFromMedia(path, curMedia, albumCovers, hiddenString, includedFolders, getProperFileSize, noMediaFolders)
    updateDBDirectory(directory)
}

fun Context.updatePhotoVideoDirectoryPath(path: String, isImage: Boolean = false, isVideo: Boolean = false, isHidden: Boolean = false) {
    val mediaFetcher = MediaFetcher(applicationContext)
    val getImagesOnly = isImage
    val getVideosOnly = isVideo
    val hiddenString = getString(R.string.hidden)
    val albumCovers = config.parseAlbumCovers()
    val includedFolders = config.includedFolders
    val noMediaFolders = getNoMediaFoldersSync()

    val sorting = config.getFolderSorting(path)
    val grouping = config.getFolderGrouping(path)
    val getProperDateTaken = config.directorySorting and SORT_BY_DATE_TAKEN != 0 ||
            sorting and SORT_BY_DATE_TAKEN != 0 ||
            grouping and GROUP_BY_DATE_TAKEN_DAILY != 0 ||
            grouping and GROUP_BY_DATE_TAKEN_MONTHLY != 0

    val getProperLastModified = config.directorySorting and SORT_BY_DATE_MODIFIED != 0 ||
            sorting and SORT_BY_DATE_MODIFIED != 0 ||
            grouping and GROUP_BY_LAST_MODIFIED_DAILY != 0 ||
            grouping and GROUP_BY_LAST_MODIFIED_MONTHLY != 0

    val getProperFileSize = config.directorySorting and SORT_BY_SIZE != 0

    val lastModifieds = if (getProperLastModified) mediaFetcher.getFolderLastModifieds(path) else HashMap()
    val dateTakens = mediaFetcher.getFolderDateTakens(path)
    val favoritePaths = getFavoritePaths()
    var curMedia = mediaFetcher.getFilesFrom(
        path, getImagesOnly, getVideosOnly, getProperDateTaken, getProperLastModified, getProperFileSize,
        favoritePaths, false, isHidden, lastModifieds, dateTakens
    )
    if (isVideo) {
        curMedia = curMedia.filter { it.type != TYPE_GIFS } as java.util.ArrayList<Medium>
    }
    Log.d("RefreshMedia1234", "updatePhotoVideoDirectoryPath: CurrentPath  ---> " + path)
    Log.d("RefreshMedia1234", "updatePhotoVideoDirectoryPath: CurrentMedia  ---> " + curMedia.size)
    val directory = createDirectoryFromMedia(path, curMedia, albumCovers, hiddenString, includedFolders, getProperFileSize, noMediaFolders)
    try {

        if (directory.mediaCnt == 0) {
            directoryDao.deleteDirPath(directory.path)
//            if (isHidden) {
//                if (VaultFragment.isFakeVaultOpen) {
//                    fakeVaultHiddenDirectoryDao.deleteDirPath(directory.path)
//                } else {
//                    hiddenDirectoryDao.deleteDirPath(directory.path)
//                }
//            }
            if (isImage && !isHidden) {
                Log.d("RefreshMedia1234", "updatePhotoVideoDirectoryPath: Update Image  ---> " + directory.path)
                Log.d("RefreshMedia1234", "updatePhotoVideoDirectoryPath: Update Media Count  ---> " + directory.mediaCnt)

                photoDirectoryDao.deleteDirPath(directory.getConvertedPictureDirectory().path)
                LocalBroadcastManager.getInstance(this).sendBroadcast(Intent().setAction(photoRefreshActionName))
            }
            if (isVideo && !isHidden) {
                videoDirectoryDao.deleteDirPath(directory.getConvertedVideoDirectory().path)
                LocalBroadcastManager.getInstance(this).sendBroadcast(Intent().setAction(videoRefreshActionName))
            }
        } else {
            directoryDao.insert(directory)
            if (isHidden) {
                if (VaultFragment.isFakeVaultOpen) {
                    fakeVaultHiddenDirectoryDao.insert(directory.getConvertedFakeVaultDirectory())
                } else
                    hiddenDirectoryDao.insert(directory.getConvertedHiddenDirectory())
            }
            if (isImage && !isHidden) {
                Log.d("RefreshMedia1234", "updatePhotoVideoDirectoryPath: Update Image  ---> " + directory.path)
                Log.d("RefreshMedia1234", "updatePhotoVideoDirectoryPath: Update Media Count  ---> " + directory.mediaCnt)

                photoDirectoryDao.insert(directory.getConvertedPictureDirectory())
                LocalBroadcastManager.getInstance(this).sendBroadcast(Intent().setAction(photoRefreshActionName))
            }
            if (isVideo && !isHidden) {
                videoDirectoryDao.insert(directory.getConvertedVideoDirectory())
                LocalBroadcastManager.getInstance(this).sendBroadcast(Intent().setAction(videoRefreshActionName))
            }
        }
    } catch (ignored: Exception) {
        Log.d("RefreshMedia1234", "updatePhotoVideoDirectoryPath: Exception  ---> " + ignored.printStackTrace())
        ignored.printStackTrace()
    }
}

fun Context.updateDBDirectory(directory: Directory) {
    try {
        directoryDao.updateDirectory(directory.path, directory.tmb, directory.mediaCnt, directory.modified, directory.taken, directory.size, directory.types, directory.sortValue)

    } catch (ignored: Exception) {
    }
}

fun Context.addFakeMedia(path: String) {
    ensureBackgroundThread {
        if (!getDoesFilePathExist(path)) {
            return@ensureBackgroundThread
        }

        val type = when {
            path.isVideoFast() -> TYPE_VIDEOS
            path.isGif() -> TYPE_GIFS
            path.isSvg() -> TYPE_SVGS
            path.isRawFast() -> TYPE_RAWS
            path.isPortrait() -> TYPE_PORTRAITS
            else -> TYPE_IMAGES
        }
        try {
            val duration = if (type == TYPE_VIDEOS) getDuration(path) ?: 0 else 0
            val ts = System.currentTimeMillis()
            val medium = FakeVaultMedium(
                null,
                path.getFilenameFromPath(),
                path,
                path.getParentPath(),
                ts,
                ts,
                File(path).length(),
                type,
                duration,
                false,
                0
            )
            fakeVaultMediumDao.insert(medium)
        } catch (e: Exception) {
        }
    }
}

fun Context.addFileToDB(path: String, fakeVaultOpen: Boolean = false) {
    ensureBackgroundThread {
        if (!getDoesFilePathExist(path)) {
            return@ensureBackgroundThread
        }

        val type = when {
            path.isVideoFast() -> TYPE_VIDEOS
            path.isGif() -> TYPE_GIFS
            path.isRawFast() -> TYPE_RAWS
            path.isSvg() -> TYPE_SVGS
            path.isPortrait() -> TYPE_PORTRAITS
            path.isAudioFast() -> TYPE_AUDIO
            path.isDocumentFast() -> TYPE_DOCUMENT
            else -> TYPE_IMAGES
        }

        try {
            val ts = System.currentTimeMillis()
            val file = HideFilesDetail(
                null,
                path.getFilenameFromPath(),
                path,
                path.getParentPath(),
                ts,
                ts,
                File(path).length(),
                type,
                false,
                0
            )
            if (fakeVaultOpen)
                fakeHideFileDao.insert(file.getConvertedFakeFileDetail())
            else
                hideFileDao.insert(file)
        } catch (ignored: Exception) {
        }
    }
}


fun Context.addPathToDB(path: String) {
    ensureBackgroundThread {
        if (!getDoesFilePathExist(path)) {
            return@ensureBackgroundThread
        }

        val type = when {
            path.isVideoFast() -> TYPE_VIDEOS
            path.isGif() -> TYPE_GIFS
            path.isRawFast() -> TYPE_RAWS
            path.isSvg() -> TYPE_SVGS
            path.isPortrait() -> TYPE_PORTRAITS
            else -> TYPE_IMAGES
        }

        try {
//            val isFavorite = favoritesDB.isFavorite(path)
            val isFavorite = false
            val videoDuration = if (type == TYPE_VIDEOS) getDuration(path) ?: 0 else 0
            val medium = Medium(
                null, path.getFilenameFromPath(), path, path.getParentPath(), System.currentTimeMillis(), System.currentTimeMillis(),
                File(path).length(), type, videoDuration, isFavorite, 0L
            )

            mediaDB.insert(medium)
        } catch (ignored: Exception) {
        }
    }
}

fun Context.getFileDateTaken(path: String): Long {
    val projection = arrayOf(
        Images.Media.DATE_TAKEN
    )

    val uri = Files.getContentUri("external")
    val selection = "${Images.Media.DATA} = ?"
    val selectionArgs = arrayOf(path)

    try {
        val cursor = contentResolver.query(uri, projection, selection, selectionArgs, null)
        cursor?.use {
            if (cursor.moveToFirst()) {
                return cursor.getLongValue(Images.Media.DATE_TAKEN)
            }
        }
    } catch (ignored: Exception) {
    }

    return 0L
}

fun Context.saveBitmapInInternalStorage(bitmapImage: Bitmap?): String? {
    val cw = ContextWrapper(this)

    // path to /data/data/yourapp/app_data/imageDir
    val directory = cw.getDir("imageDir", Context.MODE_PRIVATE)
    // Create imageDir

    val mypath: File = File(directory, "cropped.png")
    if (mypath.exists())
        mypath.delete()
    if (bitmapImage != null) {

        Log.e("TAG", "" + mypath)
        var fos: FileOutputStream? = null
        try {
            fos = FileOutputStream(mypath)
            // Use the compress method on the BitMap object to write image to the OutputStream
            bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fos)
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
            //FirebaseCrash.report(e);
        } finally {
            try {
                fos!!.close()
            } catch (e: IOException) {
                e.printStackTrace()
                //FirebaseCrash.report(e);
            }
        }
    } else {
        Log.e("TAG", "Not Saved Image------------------------------------------------------->")
    }
    return mypath.absolutePath
}

fun Context.supportFingerPrint(): Boolean {
    // Check if we're running on Android 6.0 (M) or higher
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        //Fingerprint API only available on from Android 6.0 (M)
        try {
            val fingerprintManager = getSystemService(Context.FINGERPRINT_SERVICE) as FingerprintManager
            if (!fingerprintManager.isHardwareDetected) {
                //  Toast.makeText(context, "Device doesn't support fingerprint authentication", Toast.LENGTH_SHORT).show();
                // Device doesn't support fingerprint authentication
                false
            } else fingerprintManager.hasEnrolledFingerprints()
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
            false
        }
    } else false
}

fun Context.canDrawOverlays(): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        Settings.canDrawOverlays(this)
    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
        checkOp(this, OP_SYSTEM_ALERT_WINDOW)
    } else {
        true
    }
}

private fun checkOp(context: Context, op: Int): Boolean {
    val manager = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    try {
        val method = AppOpsManager::class.java.getDeclaredMethod("checkOp", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, String::class.java)
        return AppOpsManager.MODE_ALLOWED == method.invoke(manager, op, Binder.getCallingUid(), context.packageName) as Int
    } catch (e: java.lang.Exception) {
        Log.e("TAG", Log.getStackTraceString(e))
    }
    return false
}

/**
 * Extension method to Get String resource for Context.
 */
fun Context.getStringRes(@StringRes id: Int) = resources.getString(id)

/**
 * Extension method to get LayoutInflater
 */
internal inline val Context.inflater: LayoutInflater get() = LayoutInflater.from(this)

fun Context.getFilePathFromURIWhenEmpty(contentUri: Uri): String? {
    val fileName = getFileName(contentUri)
    var myDir = File(cacheDir, "")
    if (!myDir.exists()) {
        myDir.mkdirs()
    }
    if (!TextUtils.isEmpty(fileName)) {
        val copyFile: File = File(myDir.getPath().toString() + File.separator + fileName)
        copy(this, contentUri, copyFile)
        return copyFile.absolutePath
    }
    return null
}

fun copy(context: Context, srcUri: Uri?, dstFile: File?) {
    try {
        val inputStream = context.contentResolver.openInputStream(srcUri!!) ?: return
        val outputStream: OutputStream = FileOutputStream(dstFile)
        IOUtils.copy(inputStream, outputStream)
        inputStream.close()
        outputStream.close()
    } catch (e: IOException) {
        e.printStackTrace()
    } catch (e: java.lang.Exception) {
        e.printStackTrace()
    }
}

fun Context.getFileName(uri: Uri): String? {
    var result: String? = null
    if (uri.scheme == "content") {
        val cursor = contentResolver.query(uri, null, null, null, null)
        try {
            if (cursor != null && cursor.moveToFirst()) {
                result = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME))
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            if (cursor != null)
                cursor!!.close()
        }
    }
    if (result == null) {
        result = uri.path
        val cut = result!!.lastIndexOf('/')
        if (cut != -1) {
            result = result.substring(cut + 1)
        }
    }
    return result
}


fun Context.openExternalBrowser(url: String) {
    try {
        launchBrowser(url)
    } catch (e: ActivityNotFoundException) {
        toast(getString(R.string.went_wrong))
    }
}

fun Context.launchBrowser(url: String) {
    try {

        val customTabsIntent: CustomTabsIntent = CustomTabsIntent.Builder()
            .addDefaultShareMenuItem()
            .setToolbarColor(ContextCompat.getColor(this, R.color.colorPrimary))
            .setShowTitle(true)
            .addDefaultShareMenuItem()
            .build()
        isInternalCall = true
        customTabsIntent.launchUrl(this, Uri.parse(url.replace(" ", "+")))
    } catch (e: ActivityNotFoundException) {
        toast(getString(R.string.went_wrong))
    } catch (e: SecurityException) {
        toast(getString(R.string.went_wrong))
    } catch (e: Exception) {
        toast(getString(R.string.went_wrong))
    }

}

fun Context.isTablet(): Boolean {
    return ((resources.configuration.screenLayout and Configuration.SCREENLAYOUT_SIZE_MASK) >= Configuration.SCREENLAYOUT_SIZE_LARGE)
}


fun Context.restorePhotos(selectedPhoto: java.util.ArrayList<String>, callback: () -> Unit) {
    var objProgressDialog: ProgressDialog? = null
    var Count = 0
    AsyncBackgroundWork({
        objProgressDialog = ProgressDialog(this)
        objProgressDialog!!.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL)
        objProgressDialog!!.isIndeterminate = false
        objProgressDialog!!.max = selectedPhoto.size
        objProgressDialog!!.setMessage(getString(R.string.label_recovering_images_progress))
        objProgressDialog!!.setCancelable(false)
        objProgressDialog!!.show()
    }, {
        for (i in selectedPhoto.indices) {
            Count++
            mainscope.launch {
                objProgressDialog!!.progress = Count
            }
            val file: File = File((selectedPhoto.get(i)))
            val filePath =
                Environment.getExternalStorageDirectory().path + "/Restored Photos"

            val file2: File = File(filePath)
            var sb = file2.absolutePath.toString() + "/"
            val date = Date()
            val simpleDateFormat = SimpleDateFormat("yyyy-MM-dd_HH_mm_s", Locale.US)
            sb += simpleDateFormat.format(date).toString() + i.toString() + ".png"
            val file3 = File(sb.toString())
            try {
                if (!file2.exists()) {
                    file2.mkdirs()
                }
                val channel = FileInputStream(file).channel
                val channel2 = FileOutputStream(file3).channel
                channel!!.transferTo(0, channel.size(), channel2)
                Log.d("TAG", "retoreAll: " + file2.absolutePath)
                Log.d("TAG", "retoreAll: " + file3.absolutePath)
                if (channel != null) {
                    channel.close()
                }
                channel2?.close()
                addPathToDB(sb)
                if (Build.VERSION.SDK_INT >= 19) {
                    val intent = Intent(Intent.ACTION_MEDIA_SCANNER_FINISHED)
                    intent.data = Uri.fromFile(file3)
                    sendBroadcast(intent)
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
    }, {
        if (objProgressDialog != null) {
            objProgressDialog!!.dismiss()
        }
        callback()
    })
}

fun Context.getImageEffectThumb(path: String, effectClickListener: ImageEffectSelectListener, callback: (viewList: ArrayList<View>) -> Unit) {
    val filters: List<FilterType> = arrayListOf(
        FilterType.CONTRAST,
        FilterType.INVERT,
        FilterType.PIXELATION,
        FilterType.HUE,
        FilterType.GAMMA,
        FilterType.GRAYSCALE,
        FilterType.SOBEL_EDGE_DETECTION,
        FilterType.POSTERIZE,
        FilterType.FILTER_GROUP,
        FilterType.SATURATION,
        FilterType.VIGNETTE,
        FilterType.SKETCH,
        FilterType.HAZE,
        FilterType.LEVELS_FILTER_MIN
    )
    val effectViewList = ArrayList<View>()
    AsyncBackgroundWork({}, {
        filters.forEachIndexed { index, filterType ->
            val view: View = layoutInflater.inflate(R.layout.row_image_edit_gpu_effect, null, false)
            try {
                val ivEffect = view.findViewById<View>(R.id.ivEffect) as ImageView
                ivEffect.scaleType = ImageView.ScaleType.FIT_XY
                ivEffect.tag = index
                var uri = Uri.fromFile(File(path))
                val bitmap: Bitmap = MediaStore.Images.Media.getBitmap(contentResolver, uri)
                val converetdImage: Bitmap = getResizedBitmap(bitmap, 500)!!
                val gpuImage = GPUImage(this)
                gpuImage.setImage(converetdImage)
                gpuImage.setFilter(createFilterForType(filterType))
                ivEffect.setImageBitmap(gpuImage.bitmapWithFilterApplied)
                if (index == 0) {
                    ivEffect.setBackgroundResource(R.drawable.image_edit_select_effect_background)
                }
                ivEffect.setOnClickListener { effectClickListener.onEffectItemSelect(index, ivEffect) }
            } catch (e: Exception) {
                Log.e("TAG", "effect_row:Exception  ")
                e.printStackTrace()
            }
            effectViewList.add(view)
        }
    }, {
        callback(effectViewList)
    })
}

fun getResizedBitmap(image: Bitmap, maxSize: Int): Bitmap? {
    var width = image.width
    var height = image.height
    val bitmapRatio = width.toFloat() / height.toFloat()
    if (bitmapRatio > 1) {
        width = maxSize
        height = (width / bitmapRatio).toInt()
    } else {
        height = maxSize
        width = (height * bitmapRatio).toInt()
    }
    return Bitmap.createScaledBitmap(image, width, height, true)
}

fun createFilterForType(type: FilterType): GPUImageFilter? {
    return when (type) {
        FilterType.CONTRAST -> GPUImageContrastFilter(2.0f)
        FilterType.INVERT -> GPUImageColorInvertFilter()
        FilterType.PIXELATION -> GPUImagePixelationFilter()
        FilterType.HUE -> GPUImageHueFilter(90.0f)
        FilterType.GAMMA -> GPUImageGammaFilter(2.0f)
        FilterType.SEPIA -> GPUImageSepiaFilter()
        FilterType.GRAYSCALE -> GPUImageGrayscaleFilter()
        FilterType.SHARPEN -> {
            val sharpness = GPUImageSharpenFilter()
            sharpness.setSharpness(2.0f)
            sharpness
        }
        FilterType.EMBOSS -> GPUImageEmbossFilter()
        FilterType.SOBEL_EDGE_DETECTION -> GPUImageSobelEdgeDetection()
        FilterType.POSTERIZE -> GPUImagePosterizeFilter()
        FilterType.FILTER_GROUP -> {
            val filters: MutableList<GPUImageFilter> = LinkedList()
            filters.add(GPUImageContrastFilter())
            filters.add(GPUImageDirectionalSobelEdgeDetectionFilter())
            filters.add(GPUImageGrayscaleFilter())
            GPUImageFilterGroup(filters)
        }
        FilterType.SATURATION -> GPUImageSaturationFilter(1.0f)
        FilterType.VIGNETTE -> {
            val centerPoint = PointF()
            centerPoint.x = 0.5f
            centerPoint.y = 0.5f
            GPUImageVignetteFilter(centerPoint, floatArrayOf(0.0f, 0.0f, 0.0f), 0.3f, 0.75f)
        }
        FilterType.KUWAHARA -> GPUImageKuwaharaFilter()
        FilterType.SKETCH -> GPUImageSketchFilter()
        FilterType.TOON -> GPUImageToonFilter()
        FilterType.HAZE -> GPUImageHazeFilter()
        FilterType.LEVELS_FILTER_MIN -> {
            val levelsFilter = GPUImageLevelsFilter()
            levelsFilter.setMin(0.0f, 3.0f, 1.0f)
            levelsFilter
        }
        else -> throw IllegalStateException("No filter of that type!")
    }
}


fun Context.getFavouriteMedia(
    mPath: String, isPickImage: Boolean = false, isPickVideo: Boolean = false,
    showAll: Boolean, filterType: Int, groupBy: Int, callback: (media: ArrayList<ThumbnailItem>) -> Unit
) {
    val mediaFetcher = MediaFetcher(this)
    val dbHelper = FavouriteDBHelper(this)
    var mediaList = ArrayList<ThumbnailItem>()
    AsyncBackgroundWork({}, {
        val pathToUse = if (showAll) SHOW_ALL else mPath
        val folderGrouping = config.getFolderGrouping(pathToUse)
        val fileSorting = config.getFolderSorting(pathToUse)
        val getProperDateTaken = fileSorting and SORT_BY_DATE_TAKEN != 0 ||
                folderGrouping and GROUP_BY_DATE_TAKEN_DAILY != 0 ||
                folderGrouping and GROUP_BY_DATE_TAKEN_MONTHLY != 0

        val getProperLastModified = fileSorting and SORT_BY_DATE_MODIFIED != 0 ||
                folderGrouping and GROUP_BY_LAST_MODIFIED_DAILY != 0 ||
                folderGrouping and GROUP_BY_LAST_MODIFIED_MONTHLY != 0
        val getProperFileSize = fileSorting and SORT_BY_SIZE != 0

        val favoritePaths = dbHelper.getAllFavouriteList()
        val getVideoDurations = config.showThumbnailVideoDuration
        val lastModifieds = if (getProperLastModified) mediaFetcher.getLastModifieds() else java.util.HashMap()
        val dateTakens = if (getProperDateTaken) mediaFetcher.getDateTakens() else java.util.HashMap()

        val media = if (showAll) {
            val foldersToScan = mediaFetcher.getFoldersToScan(filterType, false).filter {
                it != RECYCLE_BIN &&
                        !config.isFolderProtected(it)
            }
//            val foldersToScan = mediaFetcher.getFoldersToScan()
            val media = ArrayList<Medium>()
            foldersToScan.forEach {
                val newMedia = mediaFetcher.getFilesFrom(
                    it, isPickImage, isPickVideo, getProperDateTaken, getProperLastModified, getProperFileSize,
                    favoritePaths, getVideoDurations, false, lastModifieds, dateTakens
                )
                media.addAll(newMedia)
            }

            mediaFetcher.sortMedia(media, config.getFolderSorting(SHOW_ALL))
            media
        } else {
            mediaFetcher.getFilesFrom(
                mPath, isPickImage, isPickVideo, getProperDateTaken, getProperLastModified, getProperFileSize, favoritePaths,
                getVideoDurations, false, lastModifieds, dateTakens
            )
        }
        mediaList = mediaFetcher.groupMedia(media, pathToUse, groupBy)
    }, {
        callback(mediaList)
    })
}

fun Context.getHDCameraMedia(
    mPath: String, isPickImage: Boolean = false, isPickVideo: Boolean = false,
    showAll: Boolean, filterType: Int, groupBy: Int, mShowOnlyHidden: Boolean, callback: (mediaList: ArrayList<ThumbnailItem>) -> Unit
) {
    val mediaFetcher = MediaFetcher(this)
    var mediaList = ArrayList<ThumbnailItem>()
    AsyncBackgroundWork({}, {
        val pathToUse = if (showAll) SHOW_ALL else mPath
        val folderGrouping = GROUP_BY_LAST_MODIFIED_DAILY
        val fileSorting = SORT_BY_DATE_MODIFIED or SORT_DESCENDING
        val getProperDateTaken = fileSorting and SORT_BY_DATE_TAKEN != 0 ||
                folderGrouping and GROUP_BY_DATE_TAKEN_DAILY != 0 ||
                folderGrouping and GROUP_BY_DATE_TAKEN_MONTHLY != 0

        val getProperLastModified = fileSorting and SORT_BY_DATE_MODIFIED != 0 ||
                folderGrouping and GROUP_BY_LAST_MODIFIED_DAILY != 0 ||
                folderGrouping and GROUP_BY_LAST_MODIFIED_MONTHLY != 0
        val getProperFileSize = fileSorting and SORT_BY_SIZE != 0
        val getVideoDurations = config.showThumbnailVideoDuration
        val lastModifieds = if (getProperLastModified) mediaFetcher.getLastModifieds() else java.util.HashMap()
        val dateTakens = if (getProperDateTaken) mediaFetcher.getDateTakens() else java.util.HashMap()

        val media = if (showAll) {
            val foldersToScan = mediaFetcher.getFoldersToScan(filterType, mShowOnlyHidden).filter {
                it != RECYCLE_BIN && it != FAVORITES &&
                        !config.isFolderProtected(it)
            }
            val media = ArrayList<Medium>()
            foldersToScan.forEach {
                val newMedia = mediaFetcher.getFilesFrom(
                    it, isPickImage, isPickVideo, getProperDateTaken, getProperLastModified, getProperFileSize,
                    ArrayList<String>(), getVideoDurations, mShowOnlyHidden, lastModifieds, dateTakens
                )
                mediaFetcher.sortMedia(media, SORT_BY_DATE_MODIFIED)
                media.addAll(newMedia)
            }
            media
        } else {
            val newMedia = mediaFetcher.getFilesFrom(
                mPath, isPickImage, isPickVideo, getProperDateTaken, getProperLastModified, getProperFileSize, ArrayList<String>(),
                getVideoDurations, mShowOnlyHidden, lastModifieds, dateTakens
            )
            newMedia
        }
        mediaList = mediaFetcher.groupMedia(media, pathToUse, groupBy)
    }, {
        callback(mediaList)
    })

}

fun Context.getRecoverMedia(
    mPath: String, isPickImage: Boolean = false, isPickVideo: Boolean = false,
    showAll: Boolean, filterType: Int, groupBy: Int, mShowOnlyHidden: Boolean, mShowAllGroup: Boolean, isFromTimeLine: Boolean = false, callback: (mediaList: ArrayList<ThumbnailItem>) -> Unit
) {
    val mediaFetcher = MediaFetcher(this)
    var mediaList = ArrayList<ThumbnailItem>()
    AsyncBackgroundWork({}, {
        val pathToUse = if (showAll) SHOW_ALL else mPath
        val folderGrouping = config.getFolderGrouping(pathToUse)
        val fileSorting = config.getFolderSorting(pathToUse)
        val getProperDateTaken = fileSorting and SORT_BY_DATE_TAKEN != 0 ||
                folderGrouping and GROUP_BY_DATE_TAKEN_DAILY != 0 ||
                folderGrouping and GROUP_BY_DATE_TAKEN_MONTHLY != 0

        val getProperLastModified = fileSorting and SORT_BY_DATE_MODIFIED != 0 ||
                folderGrouping and GROUP_BY_LAST_MODIFIED_DAILY != 0 ||
                folderGrouping and GROUP_BY_LAST_MODIFIED_MONTHLY != 0
        val getProperFileSize = fileSorting and SORT_BY_SIZE != 0
        val getVideoDurations = config.showThumbnailVideoDuration
        val lastModifieds = if (getProperLastModified) mediaFetcher.getLastModifieds() else java.util.HashMap<String, Long>()
        val dateTakens = if (getProperDateTaken) mediaFetcher.getDateTakens() else java.util.HashMap()

        val media = if (showAll) {
            val foldersToScan = mediaFetcher.getFoldersToScan(filterType, mShowOnlyHidden).filter {
                it != RECYCLE_BIN && it != FAVORITES &&
                        !config.isFolderProtected(it)
            }
            val media = ArrayList<Medium>()
            foldersToScan.forEach {
                val newMedia = mediaFetcher.getFilesFrom(
                    it, isPickImage, isPickVideo, getProperDateTaken, getProperLastModified, getProperFileSize,
                    ArrayList<String>(), getVideoDurations, mShowOnlyHidden, lastModifieds, dateTakens
                )
                mediaFetcher.sortMedia(media, config.getFolderSorting(SHOW_ALL))
                media.addAll(newMedia)
            }
            media
        } else {
            val newMedia = mediaFetcher.getFilesFrom(
                mPath, isPickImage, isPickVideo, getProperDateTaken, getProperLastModified, getProperFileSize, ArrayList<String>(),
                getVideoDurations, mShowOnlyHidden, lastModifieds, dateTakens
            )
            newMedia
        }

        Log.d("TAG", "setupAdapter: doInBackground" + media.size.toString())
        if (!isFromTimeLine)
            RecoverPhotoDateWiseActivity.allMediaList = mediaFetcher.groupMediaForRecover(media, pathToUse, groupBy, true, isFromTimeLine)
        mediaList = mediaFetcher.groupMediaForRecover(media, pathToUse, groupBy, mShowAllGroup, isFromTimeLine)
    }, {
        callback(mediaList)
    })
}


fun Context.getPhotoDirectories() {
    val TAG = "GetPhotoDirectory"
    var cnt = 0
    AsyncBackgroundWork({}, {
        var newDirs = ArrayList<Directory>()
        var mLastMediaFetcher = MediaFetcher(this)
        val hiddenString = getString(R.string.hidden)
        val albumCovers = config.parseAlbumCovers()
        val includedFolders = config.includedFolders
        val noMediaFolders = getNoMediaFoldersSync()
        val tempFolderPath = config.tempFolderPath
        val getProperFileSize = config.directorySorting and SORT_BY_SIZE != 0
        val favoritePaths = getFavoritePaths()
        val dirPathsToRemove = ArrayList<String>()
        val lastModifieds = mLastMediaFetcher.getLastModifieds()
        val dateTakens = mLastMediaFetcher.getDateTakens()

        val photoFoldersToScan = mLastMediaFetcher!!.getFoldersToScan(TYPE_IMAGES, false)
        photoFoldersToScan.add(FAVORITES)
        for (folder in photoFoldersToScan) {


            val sorting = config.getFolderSorting(folder)
            val grouping = config.getFolderGrouping(folder)
            val getProperDateTaken = config.directorySorting and SORT_BY_DATE_TAKEN != 0 ||
                    sorting and SORT_BY_DATE_TAKEN != 0 ||
                    grouping and GROUP_BY_DATE_TAKEN_DAILY != 0 ||
                    grouping and GROUP_BY_DATE_TAKEN_MONTHLY != 0

            val getProperLastModified = config.directorySorting and SORT_BY_DATE_MODIFIED != 0 ||
                    sorting and SORT_BY_DATE_MODIFIED != 0 ||
                    grouping and GROUP_BY_LAST_MODIFIED_DAILY != 0 ||
                    grouping and GROUP_BY_LAST_MODIFIED_MONTHLY != 0

            val newMedia = mLastMediaFetcher!!.getFilesFrom(
                folder, true, false, getProperDateTaken, getProperLastModified,
                getProperFileSize, favoritePaths, false, false, lastModifieds, dateTakens
            )

            if (newMedia.isEmpty()) {
                try {
                    photoDirectoryDao.deleteDirPath(folder)
                } catch (e: Exception) {
                }
                continue
            }
            getCachedMedia(folder)
            {
                val cached = it
                cached.forEach {
                    if (!newMedia.contains(it)) {
                        val mediumPath = (it as? Medium)?.path
                        if (mediumPath != null && !mediumPath.startsWith(RECOVER_TRASH_BIN)) {
                            deleteDBPath(mediumPath)
                        }
                    }
                }
            }

            val newDir = createDirectoryFromMedia(folder, newMedia, albumCovers, hiddenString, includedFolders, getProperFileSize, noMediaFolders)
            newDirs.add(newDir)
            cnt++
            // make sure to create a new thread for these operations, dont just use the common bg thread
            Thread {
                try {
                    try {
                        photoDirectoryDao.insert(newDir.getConvertedPictureDirectory())
                    } catch (e: java.lang.Exception) {
                        Log.e(TAG, "gotDirectories: catch" + e.printStackTrace())
                        e.printStackTrace()
                    }

                    Log.d(TAG, "gotDirectories: Data Inserted")
                    if (folder != RECYCLE_BIN) {
                        mediaDB.insertAll(newMedia)
                    }
                    if (cnt > 10) {
                        cnt = 0
                        LocalBroadcastManager.getInstance(this).sendBroadcast(Intent().setAction(photoRefreshActionName))
                    }

                } catch (ignored: Exception) {
                    ignored.printStackTrace()
                }
            }.start()
        }

    }, {
        PhotoDirectoryFragment.isPostExecute = true
        LocalBroadcastManager.getInstance(this).sendBroadcast(Intent().setAction(photoRefreshActionName))
    })
}


fun Context.getVideoDirectories() {
    val TAG = "GetVideoDirectory"
    var cnt = 0
    AsyncBackgroundWork({

    }, {
        var newDirs = ArrayList<Directory>()
        var mLastMediaFetcher = MediaFetcher(this)
        val hiddenString = getString(R.string.hidden)
        val albumCovers = config.parseAlbumCovers()
        val includedFolders = config.includedFolders
        val noMediaFolders = getNoMediaFoldersSync()
        val getProperFileSize = config.directorySorting and SORT_BY_SIZE != 0
        val favoritePaths = getFavoritePaths()
        val lastModifieds = mLastMediaFetcher.getLastModifieds()
        val dateTakens = mLastMediaFetcher.getDateTakens()
        val foldersToScan = mLastMediaFetcher!!.getFoldersToScan(TYPE_VIDEOS, false)
        foldersToScan.add(FAVORITES)
        for (folder in foldersToScan) {
            val sorting = config.getFolderSorting(folder)
            val grouping = config.getFolderGrouping(folder)
            val getProperDateTaken = config.directorySorting and SORT_BY_DATE_TAKEN != 0 ||
                    sorting and SORT_BY_DATE_TAKEN != 0 ||
                    grouping and GROUP_BY_DATE_TAKEN_DAILY != 0 ||
                    grouping and GROUP_BY_DATE_TAKEN_MONTHLY != 0

            val getProperLastModified = config.directorySorting and SORT_BY_DATE_MODIFIED != 0 ||
                    sorting and SORT_BY_DATE_MODIFIED != 0 ||
                    grouping and GROUP_BY_LAST_MODIFIED_DAILY != 0 ||
                    grouping and GROUP_BY_LAST_MODIFIED_MONTHLY != 0

            var newMedia = mLastMediaFetcher!!.getFilesFrom(
                folder, false, true, getProperDateTaken, getProperLastModified,
                getProperFileSize, favoritePaths, false, false, lastModifieds, dateTakens
            )

            newMedia = newMedia.filter { it.type != TYPE_GIFS } as java.util.ArrayList<Medium>

            if (newMedia.isEmpty()) {
                try {
                    videoDirectoryDao.deleteDirPath(folder)
                } catch (e: Exception) {
                }
                continue
            }
            getCachedMedia(folder)
            {
                val cached = it
                cached.forEach {
                    if (!newMedia.contains(it)) {
                        val mediumPath = (it as? Medium)?.path
                        if (mediumPath != null && !mediumPath.startsWith(RECOVER_TRASH_BIN)) {
                            deleteDBPath(mediumPath)
                        }
                    }
                }
            }
//            Log.d(TAG, "gotDirectories:folder --> " + folder + "  newMedia --> " + newMedia.size)
            val newDir = createDirectoryFromMedia(folder, newMedia, albumCovers, hiddenString, includedFolders, getProperFileSize, noMediaFolders)
            newDir.tmb = newMedia[0].path
            newDir.mediaCnt = newMedia.size
            newDirs.add(newDir)
            cnt++
            // make sure to create a new thread for these operations, dont just use the common bg thread
            Thread {
                try {
                    try {
                        videoDirectoryDao.insert(newDir.getConvertedVideoDirectory())
                    } catch (e: java.lang.Exception) {
                        Log.e(TAG, "gotDirectories: catch" + e.printStackTrace())
                        e.printStackTrace()
                    }
                    Log.d(TAG, "gotDirectories: Data Inserted newMedia ->" + newMedia.size)
                    mediaDB.insertAll(newMedia)
                    if (cnt > 5) {
                        cnt = 0
                        LocalBroadcastManager.getInstance(this).sendBroadcast(Intent().setAction(videoRefreshActionName))
                    }
                } catch (ignored: Exception) {
                    ignored.printStackTrace()
                }
            }.start()
        }
    }, {
        LocalBroadcastManager.getInstance(this).sendBroadcast(Intent().setAction(videoRefreshActionName))
    })
}


fun Context.getAllMedia(
    mPath: String, isPickImage: Boolean = false, isPickVideo: Boolean = false,
    showAll: Boolean, filterType: Int, groupBy: Int, mShowOnlyHidden: Boolean, callback: (mediaList: ArrayList<ThumbnailItem>) -> Unit
) {
    val mediaFetcher = MediaFetcher(this)
    var mediaList = ArrayList<ThumbnailItem>()
    AsyncBackgroundWork({}, {
        val pathToUse = if (showAll) SHOW_ALL else mPath
        val folderGrouping = config.getFolderGrouping(pathToUse)
        val fileSorting = config.getFolderSorting(pathToUse)
        var getProperDateTaken = fileSorting and SORT_BY_DATE_TAKEN != 0 ||
                folderGrouping and GROUP_BY_DATE_TAKEN_DAILY != 0 ||
                folderGrouping and GROUP_BY_DATE_TAKEN_MONTHLY != 0

        val getProperLastModified = fileSorting and SORT_BY_DATE_MODIFIED != 0 ||
                folderGrouping and GROUP_BY_LAST_MODIFIED_DAILY != 0 ||
                folderGrouping and GROUP_BY_LAST_MODIFIED_MONTHLY != 0
        val getProperFileSize = fileSorting and SORT_BY_SIZE != 0
//        val favoritePaths = context.getFavoritePaths()
        val getVideoDurations = config.showThumbnailVideoDuration
        val lastModifieds = if (getProperLastModified) mediaFetcher.getLastModifieds() else java.util.HashMap<String, Long>()
        val dateTakens = if (getProperDateTaken) mediaFetcher.getDateTakens() else java.util.HashMap()

        var media = if (showAll) {
            val foldersToScan = mediaFetcher.getFoldersToScan(filterType, mShowOnlyHidden).filter {
                it != RECYCLE_BIN && it != FAVORITES &&
                        !config.isFolderProtected(it)
            }
            val media = ArrayList<Medium>()
            foldersToScan.forEach {
                val newMedia = mediaFetcher.getFilesFrom(
                    it, isPickImage, isPickVideo, getProperDateTaken, getProperLastModified, getProperFileSize,
                    ArrayList<String>(), getVideoDurations, mShowOnlyHidden, lastModifieds, dateTakens
                )
                mediaFetcher.sortMedia(media, config.getFolderSorting(SHOW_ALL))
                media.addAll(newMedia)
            }


            media
        } else {
            val newMedia = mediaFetcher.getFilesFrom(
                mPath, isPickImage, isPickVideo, getProperDateTaken, getProperLastModified, getProperFileSize, ArrayList<String>(),
                getVideoDurations, mShowOnlyHidden, lastModifieds, dateTakens
            )
            newMedia
        }

//        Log.d("TAG", "setupAdapter: doInBackground" + media.size.toString())
        mediaList = mediaFetcher.groupMedia(media as java.util.ArrayList<Medium>, pathToUse, groupBy)
    }, {
        callback(mediaList)
    })
}

fun Context.updateTrash() {
    AsyncBackgroundWork({}, {
        val TAG = "updateTrash"
        var newMedia: ArrayList<Medium> = mediaDB.getAllDeletedMedia(RECOVER_TRASH_BIN) as ArrayList<Medium>
        Log.d(TAG, "getMedia: -->" + newMedia.size)
        newMedia.filter {
            var path = File(recoverTrashPath, it.path.removePrefix(RECOVER_TRASH_BIN)).toString()
            !getDoesFilePathExist(path)
        }.forEach {
            mediaDB.deleteMediumPath(it.path)
        }
    }, {})

}

//fun Context.getImageVaultGalleryData() {
////     val albumItemMapping = mutableMapOf<String, AlbumItem>()
//    imageAlbumItemMapping.clear()
////    imageAlbumItemMapping.put(ALL_MEDIA_ALBUM_NAME,AlbumItem(ALL_MEDIA_ALBUM_NAME, "", ""))
////    imageAlbumItemMapping[ALL_MEDIA_ALBUM_NAME] =
////        AlbumItem(ALL_MEDIA_ALBUM_NAME, "", "")
//    AsyncBackgroundWork({}, {
//        val contentUri = MediaStore.Files.getContentUri("external")
//        val selection =
////            "(${MediaStore.Files.FileColumns.MEDIA_TYPE}=? OR " +
////                    "${MediaStore.Files.FileColumns.MEDIA_TYPE}=? OR " +
//            "${MediaStore.Files.FileColumns.MEDIA_TYPE}=? AND " +
//                    "${MediaStore.MediaColumns.SIZE} > 0"
//        val selectionArgs =
//            arrayOf(
//                MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString()
//            )
//        val projections =
//            arrayOf(
//                MediaStore.Files.FileColumns._ID,
//                MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
//                MediaStore.MediaColumns.DATA,
//                MediaStore.MediaColumns.DISPLAY_NAME,
//                MediaStore.MediaColumns.DATE_MODIFIED,
//                MediaStore.MediaColumns.MIME_TYPE,
//                MediaStore.MediaColumns.WIDTH,
//                MediaStore.MediaColumns.HEIGHT,
//                MediaStore.MediaColumns.SIZE,
//                MediaStore.Video.Media.DURATION
//            )
//
//        val sortBy = "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
////        val mimeType = "application/pdf"
////        val whereClause = MediaStore.Files.FileColumns.MIME_TYPE + " IN ('" + mimeType + "') AND " + "${MediaStore.MediaColumns.SIZE} > 0" +
////                " AND ${MediaStore.MediaColumns.DATA} NOT LIKE '/storage/emulated/0/Android%'"
//
//        val cursor =
//            contentResolver.query(contentUri, projections, selection, selectionArgs, sortBy)
//
//
//        if (true == cursor?.moveToFirst()) {
//            val pathCol = cursor.getColumnIndex(MediaStore.MediaColumns.DATA)
//            val bucketNameCol =
//                cursor.getColumnIndex(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
//            val nameCol = cursor.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME)
//            val dateCol = cursor.getColumnIndex(MediaStore.MediaColumns.DATE_MODIFIED)
//            val mimeType = cursor.getColumnIndex(MediaStore.MediaColumns.MIME_TYPE)
//            val sizeCol = cursor.getColumnIndex(MediaStore.MediaColumns.SIZE)
//            val durationCol = cursor.getColumnIndex(MediaStore.Video.Media.DURATION)
//            val widthCol = cursor.getColumnIndex(MediaStore.MediaColumns.WIDTH)
//            val heightCol = cursor.getColumnIndex(MediaStore.MediaColumns.HEIGHT)
//
//            do {
//                val path = cursor.getString(pathCol)
//                val bucketName = cursor.getString(bucketNameCol)
//                var name = cursor.getString(nameCol)
//                val dateTime = cursor.getLong(dateCol)
//                val type = cursor.getString(mimeType)
//                val size = cursor.getLong(sizeCol)
//                val duration = cursor.getLong(durationCol)
//                val width = cursor.getInt(widthCol)
//                val height = cursor.getInt(heightCol)
//
//                if (path.isNullOrEmpty() || type.isNullOrEmpty())
//                    continue
//                else if (!path.isImageFast() && !path.isGif())
//                    continue
//
//                val file = File(path)
//                if (!file.exists() || !file.isFile)
//                    continue
//////
////                if (MimeType.IMAGE == setting?.mimeType &&
////                    !type.startsWith(MimeType.IMAGE.toString())
////                )
////                    continue
//
//
//                if (name == null) {
//                    name = path.getFilenameFromPath()
//                }
////                Log.d("vaultGalleryName", "fetchAlbumSync: Name -->" + name)
//                if (path.getParentPath().contains(".")) {
//                    continue
//                }
//                if (path.getParentPath().containsNoMedia()) {
//                    continue
//                }
//                if (path.getFilenameFromPath().startsWith(".")) {
//                    continue
//                }
//
//                val media = Media(path, name, bucketName, size, dateTime, duration, width, height)
//
//                // Initialize the album of all media
//
//                if (imageAlbumItemMapping.keys.isEmpty()) {
//                    imageAlbumItemMapping[ALL_MEDIA_ALBUM_NAME] ?: run {
//                        imageAlbumItemMapping[ALL_MEDIA_ALBUM_NAME] =
//                            AlbumItem(ALL_MEDIA_ALBUM_NAME, "", path)
//                    }
////                    addAlbumItem(ALL_VIDEO_NAME, "", path)
//                }
//                // Put the current media in the album of all media
//                if (imageAlbumItemMapping[ALL_MEDIA_ALBUM_NAME]?.mediaList != null && !imageAlbumItemMapping[ALL_MEDIA_ALBUM_NAME]?.mediaList?.contains(media)!!)
//                    imageAlbumItemMapping[ALL_MEDIA_ALBUM_NAME]?.mediaList?.add(media)
////                if (type.startsWith(MimeType.VIDEO.toString())) {
////                    if (!isFirstVideoCoverAdded) {
////                        isFirstVideoCoverAdded = true
////                        albumItemMapping[ALL_VIDEO_NAME] =
////                            AlbumItem(ALL_VIDEO_NAME, "", media.path)
////                    }
////                    addMediaToAlbum(ALL_VIDEO_NAME, media)
////                }
//                // Put the current media in the corresponding album
//                val folder = file.parentFile?.absolutePath ?: ""
//                if (path != null) {
//                    var folderName = path.getParentPath()
//                    Log.d("vaultGallery", "fetchAlbumSync: name--> $name")
//                    imageAlbumItemMapping[folderName] ?: run {
//                        imageAlbumItemMapping[folderName] =
//                            AlbumItem(folderName.substringAfterLast("/"), folder, path)
//                    }
//                }
//                if (path != null) {
//                    if (imageAlbumItemMapping[path.getParentPath()]?.mediaList != null && !imageAlbumItemMapping[path.getParentPath()]?.mediaList?.contains(media)!!)
//                        imageAlbumItemMapping[path.getParentPath()]?.mediaList?.add(media)
//                }
//
//            } while (cursor.moveToNext())
//        }
//        cursor?.close()
//    }, {
//    })
//
//}

//from common


fun Context.getSharedPrefs() =
    PreferenceManager.getDefaultSharedPreferences(this)


val Context.isRTLLayout: Boolean get() = resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL

fun Context.updateTextColors(viewGroup: ViewGroup, tmpTextColor: Int = 0, tmpAccentColor: Int = 0) {
    val textColor = if (tmpTextColor == 0) baseConfig.textColor else tmpTextColor
    val backgroundColor = baseConfig.backgroundColor
    val accentColor = if (tmpAccentColor == 0) {
        when {
            isWhiteTheme() || isBlackAndWhiteTheme() -> baseConfig.accentColor
            else -> baseConfig.primaryColor
        }
    } else {
        tmpAccentColor
    }

    val cnt = viewGroup.childCount
    (0 until cnt).map { viewGroup.getChildAt(it) }.forEach {
        when (it) {
            is MyTextView -> it.setColors(textColor, accentColor, backgroundColor)
            is MyAppCompatSpinner -> it.setColors(textColor, accentColor, backgroundColor)
            is MySwitchCompat -> it.setColors(textColor, accentColor, backgroundColor)
            is MyCompatRadioButton -> it.setColors(textColor, accentColor, backgroundColor)
            is MyAppCompatCheckbox -> it.setColors(textColor, accentColor, backgroundColor)
            is MyEditText -> it.setColors(textColor, accentColor, backgroundColor)
            is MyAutoCompleteTextView -> it.setColors(textColor, accentColor, backgroundColor)
            is MyFloatingActionButton -> it.setColors(textColor, accentColor, backgroundColor)
            is MySeekBar -> it.setColors(textColor, accentColor, backgroundColor)
            is MyButton -> it.setColors(textColor, accentColor, backgroundColor)
            is MyTextInputLayout -> it.setColors(textColor, accentColor, backgroundColor)
            is ViewGroup -> updateTextColors(it, textColor, accentColor)
        }
    }
}

fun Context.getLinkTextColor(): Int {
    return if (baseConfig.primaryColor == resources.getColor(R.color.color_primary)) {
        baseConfig.primaryColor
    } else {
        baseConfig.textColor
    }
}

fun Context.isBlackAndWhiteTheme() = baseConfig.textColor == Color.WHITE && baseConfig.primaryColor == Color.BLACK && baseConfig.backgroundColor == Color.BLACK

fun Context.isWhiteTheme() = baseConfig.textColor == DARK_GREY && baseConfig.primaryColor == Color.WHITE && baseConfig.backgroundColor == Color.WHITE

fun Context.getAdjustedPrimaryColor() = when {
    isWhiteTheme() || isBlackAndWhiteTheme() -> baseConfig.accentColor
    else -> baseConfig.primaryColor
}

fun Context.toast(id: Int, length: Int = Toast.LENGTH_SHORT) {
    toast(getString(id), length)
}

fun Context.toast(msg: String, length: Int = Toast.LENGTH_SHORT) {
    try {
        if (isOnMainThread()) {
            doToast(this, msg, length)
        } else {
            Handler(Looper.getMainLooper()).post {
                doToast(this, msg, length)
            }
        }
    } catch (e: Exception) {
    }
}

private fun doToast(context: Context, message: String, length: Int) {
    if (context is Activity) {
        if (!context.isFinishing && !context.isDestroyed) {
            Toast.makeText(context, message, length).show()
        }
    } else {
        Toast.makeText(context, message, length).show()
    }
}

fun Context.showErrorToast(msg: String, length: Int = Toast.LENGTH_LONG) {
    toast(String.format(getString(R.string.an_error_occurred), msg), length)
}

fun Context.showErrorToast(exception: Exception, length: Int = Toast.LENGTH_LONG) {
    showErrorToast(exception.toString(), length)
}

val Context.baseConfig: BaseConfig get() = BaseConfig.newInstance(this)
val Context.sdCardPath: String get() = baseConfig.sdCardPath
val Context.internalStoragePath: String get() = baseConfig.internalStoragePath
val Context.otgPath: String get() = baseConfig.OTGPath

fun Context.isFingerPrintSensorAvailable() = isMarshmallowPlus() && Reprint.isHardwarePresent()

fun Context.getLatestMediaId(uri: Uri = Files.getContentUri("external")): Long {
    val projection = arrayOf(
        BaseColumns._ID
    )
    val sortOrder = "${BaseColumns._ID} DESC LIMIT 1"
    try {
        val cursor = contentResolver.query(uri, projection, null, null, sortOrder)
        cursor?.use {
            if (cursor.moveToFirst()) {
                return cursor.getLongValue(BaseColumns._ID)
            }
        }
    } catch (ignored: Exception) {
    }
    return 0
}

fun Context.getLatestMediaByDateId(uri: Uri = Files.getContentUri("external")): Long {
    val projection = arrayOf(
        BaseColumns._ID
    )
    val sortOrder = "${Images.ImageColumns.DATE_TAKEN} DESC LIMIT 1"
    try {
        val cursor = contentResolver.query(uri, projection, null, null, sortOrder)
        cursor?.use {
            if (cursor.moveToFirst()) {
                return cursor.getLongValue(BaseColumns._ID)
            }
        }
    } catch (ignored: Exception) {
    }
    return 0
}

// some helper functions were taken from https://github.com/iPaulPro/aFileChooser/blob/master/aFileChooser/src/com/ipaulpro/afilechooser/utils/FileUtils.java
fun Context.getRealPathFromURI(uri: Uri): String? {
    if (uri.scheme == "file") {
        return uri.path
    }

    if (isDownloadsDocument(uri)) {
        val id = DocumentsContract.getDocumentId(uri)
        if (id.areDigitsOnly()) {
            val newUri = ContentUris.withAppendedId(Uri.parse("content://downloads/public_downloads"), id.toLong())
            val path = getDataColumn(newUri)
            if (path != null) {
                return path
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && id.startsWith("msf:")) {
            val split = id.split(":")
            val selection = "_id=?"
            val selectionArgs = arrayOf(split[1])
            return getDataColumn(MediaStore.Downloads.EXTERNAL_CONTENT_URI, selection, selectionArgs)
        }
    } else if (isExternalStorageDocument(uri)) {
        val documentId = DocumentsContract.getDocumentId(uri)
        val parts = documentId.split(":")
        if (parts[0].equals("primary", true)) {
            return "${Environment.getExternalStorageDirectory().absolutePath}/${parts[1]}"
        }
    } else if (isMediaDocument(uri)) {
        val documentId = DocumentsContract.getDocumentId(uri)
        val split = documentId.split(":").dropLastWhile { it.isEmpty() }.toTypedArray()
        val type = split[0]

        val contentUri = when (type) {
            "video" -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            "audio" -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            else -> Images.Media.EXTERNAL_CONTENT_URI
        }

        val selection = "_id=?"
        val selectionArgs = arrayOf(split[1])
        val path = getDataColumn(contentUri, selection, selectionArgs)
        if (path != null) {
            return path
        }
    }

    return getDataColumn(uri)
}

fun Context.getDataColumn(uri: Uri, selection: String? = null, selectionArgs: Array<String>? = null): String? {
    try {
        val projection = arrayOf(Files.FileColumns.DATA)
        val cursor = contentResolver.query(uri, projection, selection, selectionArgs, null)
        cursor?.use {
            if (cursor.moveToFirst()) {
                val data = cursor.getStringValue(Files.FileColumns.DATA)
                if (data != "null") {
                    return data
                }
            }
        }
    } catch (e: Exception) {
    }
    return null
}

private fun isMediaDocument(uri: Uri) = uri.authority == "com.android.providers.media.documents"

private fun isDownloadsDocument(uri: Uri) = uri.authority == "com.android.providers.downloads.documents"

private fun isExternalStorageDocument(uri: Uri) = uri.authority == "com.android.externalstorage.documents"

fun Context.hasPermission(permId: Int) = ContextCompat.checkSelfPermission(this, getPermissionString(permId)) == PackageManager.PERMISSION_GRANTED

fun Context.getPermissionString(id: Int) = when (id) {
    PERMISSION_READ_STORAGE -> Manifest.permission.READ_EXTERNAL_STORAGE
    PERMISSION_WRITE_STORAGE -> Manifest.permission.WRITE_EXTERNAL_STORAGE
    PERMISSION_CAMERA -> Manifest.permission.CAMERA
    PERMISSION_RECORD_AUDIO -> Manifest.permission.RECORD_AUDIO
    PERMISSION_READ_CONTACTS -> Manifest.permission.READ_CONTACTS
    PERMISSION_WRITE_CONTACTS -> Manifest.permission.WRITE_CONTACTS
    PERMISSION_READ_CALENDAR -> Manifest.permission.READ_CALENDAR
    PERMISSION_WRITE_CALENDAR -> Manifest.permission.WRITE_CALENDAR
    PERMISSION_CALL_PHONE -> Manifest.permission.CALL_PHONE
    PERMISSION_READ_CALL_LOG -> Manifest.permission.READ_CALL_LOG
    PERMISSION_WRITE_CALL_LOG -> Manifest.permission.WRITE_CALL_LOG
    PERMISSION_GET_ACCOUNTS -> Manifest.permission.GET_ACCOUNTS
    PERMISSION_READ_SMS -> Manifest.permission.READ_SMS
    PERMISSION_SEND_SMS -> Manifest.permission.SEND_SMS
    PERMISSION_READ_PHONE_STATE -> Manifest.permission.READ_PHONE_STATE
//    PERMISSION_CORSE_LOCATION -> Manifest.permission.ACCESS_COARSE_LOCATION
//    PERMISSION_FINE_LOCATION -> Manifest.permission.ACCESS_FINE_LOCATION
    else -> ""
}

fun Context.launchActivityIntent(intent: Intent) {
    try {
        startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        toast(R.string.no_app_found)
    } catch (e: Exception) {
        showErrorToast(e)
    }
}

fun Context.getFilePublicUri(file: File, applicationId: String): Uri {
    // for images/videos/gifs try getting a media content uri first, like content://media/external/images/media/438
    // if media content uri is null, get our custom uri like content://com.simplemobiletools.gallery.provider/external_files/emulated/0/DCIM/IMG_20171104_233915.jpg
    var uri = if (file.isMediaFile()) {
        getMediaContentUri(file.absolutePath)
    } else {
        getMediaContent(file.absolutePath, Files.getContentUri("external"))
    }

    if (uri == null) {
        uri = FileProvider.getUriForFile(this, "$applicationId.fileprovider", file)
    }

    return uri!!
}

fun Context.getMediaContentUri(path: String): Uri? {
    val uri = when {
        path.isImageFast() -> Images.Media.EXTERNAL_CONTENT_URI
        path.isVideoFast() -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        else -> Files.getContentUri("external")
    }

    return getMediaContent(path, uri)
}

fun Context.getMediaContent(path: String, uri: Uri): Uri? {
    val projection = arrayOf(Images.Media._ID)
    val selection = Images.Media.DATA + "= ?"
    val selectionArgs = arrayOf(path)
    try {
        val cursor = contentResolver.query(uri, projection, selection, selectionArgs, null)
        cursor?.use {
            if (cursor.moveToFirst()) {
                val id = cursor.getIntValue(Images.Media._ID).toString()
                return Uri.withAppendedPath(uri, id)
            }
        }
    } catch (e: Exception) {
    }
    return null
}

fun Context.queryCursor(
    uri: Uri,
    projection: Array<String>,
    selection: String? = null,
    selectionArgs: Array<String>? = null,
    sortOrder: String? = null,
    showErrors: Boolean = false,
    callback: (cursor: Cursor) -> Unit
) {
    try {
        val cursor = contentResolver.query(uri, projection, selection, selectionArgs, sortOrder)
        cursor?.use {
            if (cursor.moveToFirst()) {
                do {
                    callback(cursor)
                } while (cursor.moveToNext())
            }
        }
    } catch (e: Exception) {
        if (showErrors) {
            showErrorToast(e)
        }
    }
}

fun Context.getFilenameFromUri(uri: Uri): String {
    return if (uri.scheme == "file") {
        File(uri.toString()).name
    } else {
        getFilenameFromContentUri(uri) ?: uri.lastPathSegment ?: ""
    }
}

fun Context.getMimeTypeFromUri(uri: Uri): String {
    var mimetype = uri.path?.getMimeType() ?: ""
    if (mimetype.isEmpty()) {
        try {
            mimetype = contentResolver.getType(uri) ?: ""
        } catch (e: IllegalStateException) {
        }
    }
    return mimetype
}

fun Context.ensurePublicUri(path: String, applicationId: String): Uri? {
    return if (isPathOnOTG(path)) {
        getDocumentFile(path)?.uri
    } else {
        val uri = Uri.parse(path)
        if (uri.scheme == "content") {
            uri
        } else {
            val newPath = if (uri.toString().startsWith("/")) uri.toString() else uri.path
            val file = File(newPath)
            getFilePublicUri(file, applicationId)
        }
    }
}

fun Context.ensurePublicUri(uri: Uri, applicationId: String): Uri {
    return if (uri.scheme == "content") {
        uri
    } else {
        val file = File(uri.path)
        getFilePublicUri(file, applicationId)
    }
}

fun Context.getFilenameFromContentUri(uri: Uri): String? {
    val projection = arrayOf(
        OpenableColumns.DISPLAY_NAME
    )

    try {
        val cursor = contentResolver.query(uri, projection, null, null, null)
        cursor?.use {
            if (cursor.moveToFirst()) {
                return cursor.getStringValue(OpenableColumns.DISPLAY_NAME)
            }
        }
    } catch (e: Exception) {
    }
    return null
}

fun Context.getSizeFromContentUri(uri: Uri): Long {
    val projection = arrayOf(OpenableColumns.SIZE)
    try {
        val cursor = contentResolver.query(uri, projection, null, null, null)
        cursor?.use {
            if (cursor.moveToFirst()) {
                return cursor.getLongValue(OpenableColumns.SIZE)
            }
        }
    } catch (e: Exception) {
    }
    return 0L
}

fun Context.getSharedThemeSync(cursorLoader: CursorLoader): SharedTheme? {
    val cursor = cursorLoader.loadInBackground()
    cursor?.use {
        if (cursor.moveToFirst()) {
            try {
                val textColor = cursor.getIntValue(COL_TEXT_COLOR)
                val backgroundColor = cursor.getIntValue(COL_BACKGROUND_COLOR)
                val primaryColor = cursor.getIntValue(COL_PRIMARY_COLOR)
                val accentColor = cursor.getIntValue(COL_ACCENT_COLOR)
                val appIconColor = cursor.getIntValue(COL_APP_ICON_COLOR)
                val navigationBarColor = cursor.getIntValueOrNull(COL_NAVIGATION_BAR_COLOR) ?: INVALID_NAVIGATION_BAR_COLOR
                val lastUpdatedTS = cursor.getIntValue(COL_LAST_UPDATED_TS)
                return SharedTheme(textColor, backgroundColor, primaryColor, appIconColor, navigationBarColor, lastUpdatedTS, accentColor)
            } catch (e: Exception) {
            }
        }
    }
    return null
}

fun Context.getMyContentProviderCursorLoader() = CursorLoader(this, MyContentProvider.MY_CONTENT_URI, null, null, null, null)

fun Context.getMyContactsCursor(favoritesOnly: Boolean, withPhoneNumbersOnly: Boolean) = try {
    val getFavoritesOnly = if (favoritesOnly) "1" else "0"
    val getWithPhoneNumbersOnly = if (withPhoneNumbersOnly) "1" else "0"
    val args = arrayOf(getFavoritesOnly, getWithPhoneNumbersOnly)
    CursorLoader(this, MyContactsContentProvider.CONTACTS_CONTENT_URI, null, null, args, null)
} catch (e: Exception) {
    null
}

fun Context.getDialogTheme() = if (baseConfig.backgroundColor.getContrastColor() == Color.WHITE) R.style.MyDialogTheme_Dark else R.style.MyDialogTheme

fun Context.getCurrentFormattedDateTime(): String {
    val simpleDateFormat = SimpleDateFormat("yyyy_MM_dd_HH_mm_ss", Locale.getDefault())
    return simpleDateFormat.format(Date(System.currentTimeMillis()))
}

fun Context.updateSDCardPath() {
    ensureBackgroundThread {
        val oldPath = baseConfig.sdCardPath
        baseConfig.sdCardPath = getSDCardPath()
        if (oldPath != baseConfig.sdCardPath) {
            baseConfig.treeUri = ""
        }
    }
}

fun Context.getUriMimeType(path: String, newUri: Uri): String {
    var mimeType = path.getMimeType()
    if (mimeType.isEmpty()) {
        mimeType = getMimeTypeFromUri(newUri)
    }
    return mimeType
}


fun Context.isPackageInstalled(pkgName: String): Boolean {
    return try {
        packageManager.getPackageInfo(pkgName, 0)
        true
    } catch (e: Exception) {
        false
    }
}

// format day bits to strings like "Mon, Tue, Wed"
fun Context.getSelectedDaysString(bitMask: Int): String {
    val dayBits = arrayListOf(MONDAY_BIT, TUESDAY_BIT, WEDNESDAY_BIT, THURSDAY_BIT, FRIDAY_BIT, SATURDAY_BIT, SUNDAY_BIT)
    val weekDays = resources.getStringArray(R.array.week_days_short).toList() as java.util.ArrayList<String>

    if (baseConfig.isSundayFirst) {
        dayBits.moveLastItemToFront()
        weekDays.moveLastItemToFront()
    }

    var days = ""
    dayBits.forEachIndexed { index, bit ->
        if (bitMask and bit != 0) {
            days += "${weekDays[index]}, "
        }
    }
    return days.trim().trimEnd(',')
}

fun Context.formatMinutesToTimeString(totalMinutes: Int) = formatSecondsToTimeString(totalMinutes * 60)

fun Context.formatSecondsToTimeString(totalSeconds: Int): String {
    val days = totalSeconds / DAY_SECONDS
    val hours = (totalSeconds % DAY_SECONDS) / HOUR_SECONDS
    val minutes = (totalSeconds % HOUR_SECONDS) / MINUTE_SECONDS
    val seconds = totalSeconds % MINUTE_SECONDS
    val timesString = StringBuilder()
    if (days > 0) {
        val daysString = String.format(resources.getQuantityString(R.plurals.days, days, days))
        timesString.append("$daysString, ")
    }

    if (hours > 0) {
        val hoursString = String.format(resources.getQuantityString(R.plurals.hours, hours, hours))
        timesString.append("$hoursString, ")
    }

    if (minutes > 0) {
        val minutesString = String.format(resources.getQuantityString(R.plurals.minutes, minutes, minutes))
        timesString.append("$minutesString, ")
    }

    if (seconds > 0) {
        val secondsString = String.format(resources.getQuantityString(R.plurals.seconds, seconds, seconds))
        timesString.append(secondsString)
    }

    var result = timesString.toString().trim().trimEnd(',')
    if (result.isEmpty()) {
        result = String.format(resources.getQuantityString(R.plurals.minutes, 0, 0))
    }
    return result
}

fun Context.getFormattedMinutes(minutes: Int, showBefore: Boolean = true) = getFormattedSeconds(if (minutes == -1) minutes else minutes * 60, showBefore)

fun Context.getFormattedSeconds(seconds: Int, showBefore: Boolean = true) = when (seconds) {
    -1 -> getString(R.string.no_reminder)
    0 -> getString(R.string.at_start)
    else -> {
        when {
            seconds < 0 && seconds > -60 * 60 * 24 -> {
                val minutes = -seconds / 60
                getString(R.string.during_day_at).format(minutes / 60, minutes % 60)
            }
            seconds % YEAR_SECONDS == 0 -> {
                val base = if (showBefore) R.plurals.years_before else R.plurals.by_years
                resources.getQuantityString(base, seconds / YEAR_SECONDS, seconds / YEAR_SECONDS)
            }
            seconds % MONTH_SECONDS == 0 -> {
                val base = if (showBefore) R.plurals.months_before else R.plurals.by_months
                resources.getQuantityString(base, seconds / MONTH_SECONDS, seconds / MONTH_SECONDS)
            }
            seconds % WEEK_SECONDS == 0 -> {
                val base = if (showBefore) R.plurals.weeks_before else R.plurals.by_weeks
                resources.getQuantityString(base, seconds / WEEK_SECONDS, seconds / WEEK_SECONDS)
            }
            seconds % DAY_SECONDS == 0 -> {
                val base = if (showBefore) R.plurals.days_before else R.plurals.by_days
                resources.getQuantityString(base, seconds / DAY_SECONDS, seconds / DAY_SECONDS)
            }
            seconds % HOUR_SECONDS == 0 -> {
                val base = if (showBefore) R.plurals.hours_before else R.plurals.by_hours
                resources.getQuantityString(base, seconds / HOUR_SECONDS, seconds / HOUR_SECONDS)
            }
            seconds % MINUTE_SECONDS == 0 -> {
                val base = if (showBefore) R.plurals.minutes_before else R.plurals.by_minutes
                resources.getQuantityString(base, seconds / MINUTE_SECONDS, seconds / MINUTE_SECONDS)
            }
            else -> {
                val base = if (showBefore) R.plurals.seconds_before else R.plurals.by_seconds
                resources.getQuantityString(base, seconds, seconds)
            }
        }
    }
}


@RequiresApi(Build.VERSION_CODES.N)
fun Context.saveImageRotation(path: String, degrees: Int): Boolean {
    if (!needsStupidWritePermissions(path)) {
        saveExifRotation(ExifInterface(path), degrees)
        return true
    } else if (isNougatPlus()) {
        val documentFile = getSomeDocumentFile(path)
        if (documentFile != null) {
            val parcelFileDescriptor = contentResolver.openFileDescriptor(documentFile.uri, "rw")
            val fileDescriptor = parcelFileDescriptor!!.fileDescriptor
            saveExifRotation(ExifInterface(fileDescriptor), degrees)
            return true
        }
    }
    return false
}

fun Context.saveExifRotation(exif: ExifInterface, degrees: Int) {
    val orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
    val orientationDegrees = (orientation.degreesFromOrientation() + degrees) % 360
    exif.setAttribute(ExifInterface.TAG_ORIENTATION, orientationDegrees.orientationFromDegrees())
    exif.saveAttributes()
}


fun Context.getLaunchIntent() = packageManager.getLaunchIntentForPackage(baseConfig.appId)

fun Context.getCanAppBeUpgraded() = proPackages.contains(baseConfig.appId.removeSuffix(".debug").removePrefix("com.simplemobiletools."))

fun Context.getProUrl() = "https://play.google.com/store/apps/details?id=${baseConfig.appId.removeSuffix(".debug")}.pro"

fun Context.getStoreUrl() = "https://play.google.com/store/apps/details?id=${packageName.removeSuffix(".debug")}"

fun Context.getTimeFormat() = if (baseConfig.use24HourFormat) TIME_FORMAT_24 else TIME_FORMAT_12

fun Context.getResolution(path: String): Point? {
    return if (path.isImageFast() || path.isImageSlow()) {
        path.getImageResolution()
    } else if (path.isVideoFast() || path.isVideoSlow()) {
        getVideoResolution(path)
    } else {
        null
    }
}

fun Context.getVideoResolution(path: String): Point? {
    var point = try {
        val retriever = MediaMetadataRetriever()
        retriever.setDataSource(path)
        val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)!!.toInt()
        val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)!!.toInt()
        Point(width, height)
    } catch (ignored: Exception) {
        null
    }

    if (point == null && path.startsWith("content://", true)) {
        try {
            val fd = contentResolver.openFileDescriptor(Uri.parse(path), "r")?.fileDescriptor
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(fd)
            val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)!!.toInt()
            val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)!!.toInt()
            point = Point(width, height)
        } catch (ignored: Exception) {
        }
    }

    return point
}

fun Context.getDuration(path: String): Int? {
    val projection = arrayOf(
        MediaStore.MediaColumns.DURATION
    )

    val uri = getFileUri(path)
    val selection = if (path.startsWith("content://")) "${BaseColumns._ID} = ?" else "${MediaStore.MediaColumns.DATA} = ?"
    val selectionArgs = if (path.startsWith("content://")) arrayOf(path.substringAfterLast("/")) else arrayOf(path)

    try {
        val cursor = contentResolver.query(uri, projection, selection, selectionArgs, null)
        cursor?.use {
            if (cursor.moveToFirst()) {
                return Math.round(cursor.getIntValue(MediaStore.MediaColumns.DURATION) / 1000.toDouble()).toInt()
            }
        }
    } catch (ignored: Exception) {
    }

    return try {
        val retriever = MediaMetadataRetriever()
        retriever.setDataSource(path)
        Math.round(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)!!.toInt() / 1000f)
    } catch (ignored: Exception) {
        null
    }
}

fun Context.getTitle(path: String): String? {
    val projection = arrayOf(
        MediaStore.MediaColumns.TITLE
    )

    val uri = getFileUri(path)
    val selection = if (path.startsWith("content://")) "${BaseColumns._ID} = ?" else "${MediaStore.MediaColumns.DATA} = ?"
    val selectionArgs = if (path.startsWith("content://")) arrayOf(path.substringAfterLast("/")) else arrayOf(path)

    try {
        val cursor = contentResolver.query(uri, projection, selection, selectionArgs, null)
        cursor?.use {
            if (cursor.moveToFirst()) {
                return cursor.getStringValue(MediaStore.MediaColumns.TITLE)
            }
        }
    } catch (ignored: Exception) {
    }

    return try {
        val retriever = MediaMetadataRetriever()
        retriever.setDataSource(path)
        retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
    } catch (ignored: Exception) {
        null
    }
}

fun Context.getArtist(path: String): String? {
    val projection = arrayOf(
        MediaStore.Audio.Media.ARTIST
    )

    val uri = getFileUri(path)
    val selection = if (path.startsWith("content://")) "${BaseColumns._ID} = ?" else "${MediaStore.MediaColumns.DATA} = ?"
    val selectionArgs = if (path.startsWith("content://")) arrayOf(path.substringAfterLast("/")) else arrayOf(path)

    try {
        val cursor = contentResolver.query(uri, projection, selection, selectionArgs, null)
        cursor?.use {
            if (cursor.moveToFirst()) {
                return cursor.getStringValue(MediaStore.Audio.Media.ARTIST)
            }
        }
    } catch (ignored: Exception) {
    }

    return try {
        val retriever = MediaMetadataRetriever()
        retriever.setDataSource(path)
        retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
    } catch (ignored: Exception) {
        null
    }
}

fun Context.getAlbum(path: String): String? {
    val projection = arrayOf(
        MediaStore.Audio.Media.ALBUM
    )

    val uri = getFileUri(path)
    val selection = if (path.startsWith("content://")) "${BaseColumns._ID} = ?" else "${MediaStore.MediaColumns.DATA} = ?"
    val selectionArgs = if (path.startsWith("content://")) arrayOf(path.substringAfterLast("/")) else arrayOf(path)

    try {
        val cursor = contentResolver.query(uri, projection, selection, selectionArgs, null)
        cursor?.use {
            if (cursor.moveToFirst()) {
                return cursor.getStringValue(MediaStore.Audio.Media.ALBUM)
            }
        }
    } catch (ignored: Exception) {
    }

    return try {
        val retriever = MediaMetadataRetriever()
        retriever.setDataSource(path)
        retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)
    } catch (ignored: Exception) {
        null
    }
}

fun Context.getMediaStoreLastModified(path: String): Long {
    val projection = arrayOf(
        MediaStore.MediaColumns.DATE_MODIFIED
    )

    val uri = getFileUri(path)
    val selection = "${BaseColumns._ID} = ?"
    val selectionArgs = arrayOf(path.substringAfterLast("/"))

    try {
        val cursor = contentResolver.query(uri, projection, selection, selectionArgs, null)
        cursor?.use {
            if (cursor.moveToFirst()) {
                return cursor.getLongValue(MediaStore.MediaColumns.DATE_MODIFIED) * 1000
            }
        }
    } catch (ignored: Exception) {
    }
    return 0
}

fun Context.getStringsPackageName() = getString(R.string.package_name)

fun Context.getFontSizeText() = getString(
    when (baseConfig.fontSize) {
        FONT_SIZE_SMALL -> R.string.small
        FONT_SIZE_MEDIUM -> R.string.medium
        FONT_SIZE_LARGE -> R.string.large
        else -> R.string.extra_large
    }
)

fun Context.getTextSize() = when (baseConfig.fontSize) {
    FONT_SIZE_SMALL -> resources.getDimension(R.dimen.smaller_text_size)
    FONT_SIZE_MEDIUM -> resources.getDimension(R.dimen.bigger_text_size)
    FONT_SIZE_LARGE -> resources.getDimension(R.dimen.big_text_size)
    else -> resources.getDimension(R.dimen.extra_big_text_size)
}

val Context.telecomManager: TelecomManager get() = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
val Context.windowManager: WindowManager get() = getSystemService(Context.WINDOW_SERVICE) as WindowManager
val Context.notificationManager: NotificationManager get() = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
//val Context.shortcutManager: ShortcutManager get() = getSystemService(ShortcutManager::class.java) as ShortcutManager

val Context.portrait get() = resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
val Context.navigationBarRight: Boolean get() = usableScreenSize.x < realScreenSize.x && usableScreenSize.x > usableScreenSize.y
val Context.navigationBarBottom: Boolean get() = usableScreenSize.y < realScreenSize.y && usableScreenSize.y > usableScreenSize.x
val Context.navigationBarHeight: Int get() = if (navigationBarBottom && navigationBarSize.y != usableScreenSize.y) navigationBarSize.y else 0
val Context.navigationBarWidth: Int get() = if (navigationBarRight) navigationBarSize.x else 0

val Context.navigationBarSize: Point
    get() = when {
        navigationBarRight -> Point(newNavigationBarHeight, usableScreenSize.y)
        navigationBarBottom -> Point(usableScreenSize.x, newNavigationBarHeight)
        else -> Point()
    }

val Context.newNavigationBarHeight: Int
    get() {
        var navigationBarHeight = 0
        val resourceId = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        if (resourceId > 0) {
            navigationBarHeight = resources.getDimensionPixelSize(resourceId)
        }
        return navigationBarHeight
    }

val Context.statusBarHeight: Int
    get() {
        var statusBarHeight = 0
        val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
        if (resourceId > 0) {
            statusBarHeight = resources.getDimensionPixelSize(resourceId)
        }
        return statusBarHeight
    }

val Context.actionBarHeight: Int
    get() {
        val styledAttributes = theme.obtainStyledAttributes(intArrayOf(android.R.attr.actionBarSize))
        val actionBarHeight = styledAttributes.getDimension(0, 0f)
        styledAttributes.recycle()
        return actionBarHeight.toInt()
    }


val Context.usableScreenSize: Point
    get() {
        val size = Point()
        windowManager.defaultDisplay.getSize(size)
        return size
    }

val Context.realScreenSize: Point
    get() {
        val size = Point()
        windowManager.defaultDisplay.getRealSize(size)
        return size
    }

fun Context.getCornerRadius() = resources.getDimension(R.dimen.rounded_corner_radius_small)

fun Context.copyToClipboard(text: String) {
    val clip = ClipData.newPlainText(getString(R.string.simple_commons), text)
    (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(clip)
    toast(R.string.value_copied_to_clipboard)
}

