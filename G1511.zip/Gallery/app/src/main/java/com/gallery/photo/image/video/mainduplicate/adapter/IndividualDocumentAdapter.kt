package com.gallery.photo.image.video.mainduplicate.adapter

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.CompoundButton
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.mainduplicate.callbacks.MarkedListener
import com.gallery.photo.image.video.mainduplicate.model.IndividualGroupModel
import com.gallery.photo.image.video.mainduplicate.model.ItemDuplicateModel
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions
import java.util.*

class IndividualDocumentAdapter(
    var individualDocumentAdapterContext: Context,
    var individualDocumentAdapterActivity: Activity,
    var documentsMarkedListener: MarkedListener,
    var groupOfDupesDocuments: List<IndividualGroupModel>) : RecyclerView.Adapter<IndividualDocumentAdapter.DocumentViewHolder>() {

    var mLayoutManager: LinearLayoutManager? = null

    class DocumentViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var checkBox: CheckBox = itemView.findViewById<View>(R.id.cb_grp_checkbox) as CheckBox
        var recyclerView: RecyclerView = itemView.findViewById<View>(R.id.rv_documents) as RecyclerView
        var textView: TextView = itemView.findViewById(R.id.tv_grp_name)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DocumentViewHolder {
        return DocumentViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.adapter_media_document, parent, false)
        )
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: DocumentViewHolder, position: Int) {
        val individualGroup = groupOfDupesDocuments[position]
        holder.textView.text = "Set " + individualGroup.groupTag
        holder.checkBox.isChecked = individualGroup.isCheckBox
        mLayoutManager = LinearLayoutManager(individualDocumentAdapterContext)

        val lListDocumentAdapter = ListDocumentAdapter(individualDocumentAdapterContext, individualDocumentAdapterActivity, documentsMarkedListener, groupOfDupesDocuments[position],
            individualGroup.individualGrpOfDupes!!, holder.checkBox)
        holder.recyclerView.layoutManager = mLayoutManager
        holder.recyclerView.adapter = lListDocumentAdapter

        holder.checkBox.setOnCheckedChangeListener { buttonView: CompoundButton, isChecked: Boolean ->
            buttonView.setOnClickListener {
                individualGroup.isCheckBox = isChecked
                val listDocumentAdapter1 = ListDocumentAdapter(individualDocumentAdapterContext, individualDocumentAdapterActivity, documentsMarkedListener, groupOfDupesDocuments[position], setCheckBox(individualGroup.individualGrpOfDupes, isChecked), holder.checkBox)
                holder.recyclerView.adapter = listDocumentAdapter1
                listDocumentAdapter1.notifyDataSetChanged()
            }
        }
    }

    override fun getItemCount(): Int {
        return groupOfDupesDocuments.size
    }

    private fun setCheckBox(documentItems: List<ItemDuplicateModel>?, value: Boolean): List<ItemDuplicateModel> {
        val lListOfDupes: MutableList<ItemDuplicateModel> = ArrayList()
        for (i in documentItems!!.indices) {
            val documentItem = documentItems[i]
            when {
                i != 0 -> {
                    if (!value) {
                        GlobalVarsAndFunctions.file_to_be_deleted_documents.remove(documentItem)
                        GlobalVarsAndFunctions.subSizeDocuments(documentItem.sizeOfTheFile)
                        documentsMarkedListener.updateMarked()
                    } else if (!documentItem.isFileCheckBox) {
                        GlobalVarsAndFunctions.file_to_be_deleted_documents.add(documentItem)
                        GlobalVarsAndFunctions.addSizeDocuments(documentItem.sizeOfTheFile)
                        documentsMarkedListener.updateMarked()
                    }
                    documentItem.isFileCheckBox = value
                    lListOfDupes.add(documentItem)
                }
                documentItem.isFileCheckBox -> {
                    GlobalVarsAndFunctions.file_to_be_deleted_documents.remove(documentItem)
                    documentItem.isFileCheckBox = false
                    lListOfDupes.add(documentItem)
                }
                else -> {
                    documentItem.isFileCheckBox = false
                    lListOfDupes.add(documentItem)
                }
            }
        }
        return lListOfDupes
    }
}