package com.gallery.photo.image.video.cameraview.ui.fragment;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.gallery.photo.image.video.R;
import com.gallery.photo.image.video.cameraview.ui.adapter.TemplateAdapter;
import com.gallery.photo.image.video.cameraview.ui.interfaces.OnRecyclerItemClickListener;
import com.gallery.photo.image.video.cameraview.ui.model.TemplateModel;
import com.gallery.photo.image.video.fragment.BaseFragment;

import java.util.ArrayList;
import java.util.List;


public class TemplateFragment extends BaseFragment {

    private View rootView;
    private static final String TAG = "TemplateFragment";

    List<TemplateModel> mList = new ArrayList();
    private RecyclerView mRecyclerview;


    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.fragment_template, container, false);
        mRecyclerview = rootView.findViewById(R.id.fragment_recyclerview);

        fillList();
        return rootView;
    }


    private void fillList() {
        List<TemplateModel> list = mList;
        if (list != null) {
            if (list.size() > 0) {
                mList.clear();
            }


//            TemplateModel templateModel2 = new TemplateModel();
//            templateModel2.setTitle(getString(R.string.address));
//            templateModel2.setSpKey(SharedPrefs.IS_ADDRESS);
//            templateModel2.setSelected(SharedPrefs.getBoolean(getActivity(), templateModel2.getSpKey(), AppConstant.IS_ADDRESS));
//            mList.add(0, templateModel2);
//
//            TemplateModel templateModel3 = new TemplateModel();
//            templateModel3.setTitle(getString(R.string.street_address));
//            templateModel3.setSpKey(SharedPrefs.IS_STREET_ADDRESS);
//            templateModel3.setSelected(SharedPrefs.getBoolean(getActivity(), templateModel3.getSpKey(), AppConstant.IS_STREET_ADDRESS_TEMPLATE));
//            mList.add(1, templateModel3);
//
//            TemplateModel templateModel5 = new TemplateModel();
//            templateModel5.setTitle(getString(R.string.date_and_time));
//            templateModel5.setSpKey(SharedPrefs.IS_DATE_TIME);
//            templateModel5.setSelected(SharedPrefs.getBoolean(getActivity(), templateModel5.getSpKey(), AppConstant.IS_DATE_TIME));
//            mList.add(2, templateModel5);

        }
        setAdapter();
    }

    private void setAdapter() {
        mRecyclerview.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
        TemplateAdapter templateAdapter = new TemplateAdapter(getContext(), this.mList, new OnRecyclerItemClickListener() {
            public void OnLongClick_(int i, View view) {
            }

            public void OnClick_(int i, View view) {
                Log.e(TAG, "OnClick_: "+i );
                requireActivity().setResult(Activity.RESULT_OK);

            }
        });
        mRecyclerview.setAdapter(templateAdapter);
    }




    @Nullable
    @Override
    public Integer getLayoutRes() {
        return R.layout.fragment_template;
    }
}
