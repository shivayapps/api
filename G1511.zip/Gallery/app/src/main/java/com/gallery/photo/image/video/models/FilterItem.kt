package com.gallery.photo.image.video.models

import android.graphics.Bitmap
import com.example.gallery.filter.Filter

data class FilterItem(var bitmap: Bitmap, val filter: Filter)
