package com.gallery.photo.image.video.bindActivity

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.text.HtmlCompat
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.example.app.ads.helper.InterstitialAdHelper
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.MainActivity
import com.gallery.photo.image.video.adapter.ViewPagerFragmentAdapter
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.databinding.ActivityRecoverPhotoTabBinding
import com.gallery.photo.image.video.dialog.NewRateDialog
import com.gallery.photo.image.video.dialog.TrashInfoDialog
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.fragment.*
import com.gallery.photo.image.video.models.*
import com.gallery.photo.image.video.rateandfeedback.*
import com.gallery.photo.image.video.rateandfeedback.library_feedback.sendEmail
import com.gallery.photo.image.video.utilities.*
import com.google.android.material.tabs.TabLayoutMediator
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import org.jetbrains.anko.toast
import kotlin.collections.ArrayList

class RecoverPhotoTabActivity : BaseBindingActivity<ActivityRecoverPhotoTabBinding>() {

    var title: String? = null
    var isFromOneSignal = false
    var isFromSettings = false
    var isScanFinished = false
    val mPermissionStorage = arrayOf(
        android.Manifest.permission.READ_EXTERNAL_STORAGE,
        android.Manifest.permission.WRITE_EXTERNAL_STORAGE
    )


    var isRateDialogDisplay = false
    var isRateDialogDisplayed = false
    lateinit var viewPagerFragmentAdapter: ViewPagerFragmentAdapter
    var trashDialog: TrashInfoDialog? = null
    override fun getContext(): Activity {
        return this
    }

    override fun initData() {

        mBinding.imgBack.setOnClickListener {
            onBackPressed()
        }


        if (checkPermissionStorage(mContext)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                checkAllFilePermission()
            } else {
                setData()
            }
        } else {
            givePermissions(mPermissionStorage)
        }

    }

    private fun setData() {
        val tabArray = arrayOf(
            getString(R.string.label_photos),
            getString(R.string.label_videos),
        )
        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            InterstitialAdHelper.loadInterstitialAd(fContext = this)
        }
        viewPagerFragmentAdapter = ViewPagerFragmentAdapter(this)
        viewPagerFragmentAdapter.addFragment(RecoverTrashPhotoFragment.newInstance())
        viewPagerFragmentAdapter.addFragment(RecoverTrashVideoFragment.newInstance())
        mBinding.viewPagerRecover.apply {
            adapter = viewPagerFragmentAdapter
            (getChildAt(0) as RecyclerView).overScrollMode = RecyclerView.OVER_SCROLL_NEVER

        }
        TabLayoutMediator(mBinding.tabLayout, mBinding.viewPagerRecover) { tab, position ->
            tab.text = tabArray[position]

        }.attach()
        mBinding.viewPagerRecover.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                var fragment = viewPagerFragmentAdapter.createFragment(position)
                when (fragment) {
                    is RecoverTrashPhotoFragment -> {
                        mBinding.imgDelete.beGoneIf(fragment.mMedia.size <= 0)
                        mBinding.imgDelete.beVisibleIf(fragment.mMedia.size > 0)
                    }
                    is RecoverTrashVideoFragment -> {
                        mBinding.imgDelete.beGoneIf(fragment.mMedia.size <= 0)
                        mBinding.imgDelete.beVisibleIf(fragment.mMedia.size > 0)
                    }
                }
            }
        })
        if (!config.isRecoverTrashInfoDialogShown) {
            config.isRecoverTrashInfoDialogShown = true
            trashDialog = TrashInfoDialog(this, getString(R.string.msg_delete_trash)) {

            }
        }
    }

    override fun initActions() {
        mBinding.llRestoreOpt.setOnClickListener(this)
        mBinding.llDeleteOpt.setOnClickListener(this)
        mBinding.imgInfo.setOnClickListener(this)
        mBinding.imgDelete.setOnClickListener(this)
    }

    override fun getAppIconIDs() = arrayListOf(
        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName() = getString(R.string.app_name)

    override fun initViews() {


        if (intent.hasExtra("IsCheckOneSignalNotification")) {
            isFromOneSignal = intent.getBooleanExtra("IsCheckOneSignalNotification", false)
        }

    }


    private fun checkPermissionStorage(mContext: Activity): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (checkPermissionabove11()) {
                return true
            }
            return false
        } else {
            return if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
            ) {
                isUnLockApp = true
                isAppOpenAdShow = false
                ActivityCompat.requestPermissions(
                    this, arrayOf(android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE, android.Manifest.permission.READ_EXTERNAL_STORAGE),
                    101
                )
                false
            } else {
                true
            }
        }


    }

    fun checkAllFilePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                setData()
            } else {
                isFromSettings = true
                val intent = Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse(String.format("package:%s", packageName))
                )
                try {
                    launchActivityForResult(intent, 2296)
                } catch (e: Exception) {
                }
            }
        }
    }

    private fun givePermissions(permissions: Array<String>) {

        isUnLockApp = true
        Dexter.withContext(mContext)
            .withPermissions(*permissions)
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport) {

                    when {
                        report.areAllPermissionsGranted() -> {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                checkAllFilePermission()
                            } else {
                                setData()
                            }
                        }
                        report.isAnyPermissionPermanentlyDenied -> {
                            showSettingsDialog()
                        }
                        else -> {
                            givePermissions(mPermissionStorage)
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(p0: MutableList<com.karumi.dexter.listener.PermissionRequest>?, token: PermissionToken?) {
                    token!!.continuePermissionRequest()
                }
            }).check()
    }

    private fun showSettingsDialog() {
        isUnLockApp = true
        val alertDialogBuilder = AlertDialog.Builder(this, R.style.MyAlertDialogNew)
        alertDialogBuilder.setTitle(HtmlCompat.fromHtml("<font color='#0a82f3'>" + getString(R.string.error_permission_required) + "</font>", HtmlCompat.FROM_HTML_MODE_LEGACY))
            .setMessage(getString(R.string.msg_allow_permission_storage))
            .setPositiveButton(getString(R.string.ok))
            { dialog, which ->
                dialog.dismiss()
                isFromSettings = true
                val intent = Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", packageName, null)
                )
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            }
            .setNegativeButton(getString(R.string.cancel)) { dialog, which ->
                dialog.dismiss()
                finish()
            }
            .setCancelable(false)
        alertDialogBuilder.show()
    }


    override fun fromActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.fromActivityResult(requestCode, resultCode, data)
        if (requestCode == 2296) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    setData()
                    Log.e("mTAG", "onActivityResult: Service Start ")
                } else {
                    if (isFromOneSignal) {
                        startActivity(MainActivity.newIntent(this))
                        finish()
                        Toast.makeText(mContext, getString(R.string.error_permission_required), Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(mContext, getString(R.string.error_permission_required), Toast.LENGTH_SHORT).show()
                    }
                }
            }
        } else if (requestCode == 200) {
            if (checkPermissionStorage(mContext)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    checkAllFilePermission()
                } else {
                    setData()
                }
            } else {
                if (isFromOneSignal) {
                    startActivity(MainActivity.newIntent(this))
                    finish()
                    Toast.makeText(mContext, getString(R.string.error_permission_required), Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(mContext, getString(R.string.error_permission_required), Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()

        if (isFromSettings) {
            isFromSettings = false
            if (checkPermissionStorage(mContext)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    checkAllFilePermission()
                } else {
                    setData()
                }
            }
        }
        if (isScanFinished) {
            if (!isRateDialogDisplay) {
                val sp = ExitSPHelper(this)
                if (!sp.isRated() && config.recoverCountForRate >= RECOVER_COUNT_FOR_RATE_VAL) {
                    isRateDialogDisplay = true
                    isRateDialogDisplayed = true
                    NewRateDialog(this) {
                        if (it > 3) {
                            rateApp()
                        } else if (it >= 0) {
                            sendEmail()
                        }
                    }
//                    ratingDialog(object : OnRateListener {
//                        override fun onRate(rate: Int) {
//                            isRateDialogDisplay = false
//                            if (rate >= 3) {
//                                rateApp()
//                            } else if (rate >= 0) {
//                                startActivity(FeedbackActivity.newIntent(this@RecoverPhotoTabActivity, rate))
//                            }
//                        }
//                    })
                }
            }
        }


    }


    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()
        when (view.id) {
            R.id.imgInfo -> {
                TrashInfoDialog(this, getString(R.string.msg_delete_trash)) {

                }
            }
            R.id.llRestoreOpt -> {
                isDeleteOrRestore = true
                var fragment = viewPagerFragmentAdapter.createFragment(mBinding.viewPagerRecover.currentItem)
                when (fragment) {
                    is RecoverTrashPhotoFragment -> {
                        fragment.restoreImages()
                    }
                    is RecoverTrashVideoFragment -> {
                        fragment.restoreVideos()
                    }
                }
            }
            R.id.llDeleteOpt -> {

                var fragment = viewPagerFragmentAdapter.createFragment(mBinding.viewPagerRecover.currentItem)
                when (fragment) {
                    is RecoverTrashPhotoFragment -> {
                        fragment.deleteImages()
                    }
                    is RecoverTrashVideoFragment -> {
                        fragment.deleteVideos()
                    }

                }
            }
            R.id.imgDelete -> {
                if (config.isAnyOperationRunning) {
                    toast(getString(R.string.msg_operation_already_running))
                    return
                }
                var fragment = viewPagerFragmentAdapter.createFragment(mBinding.viewPagerRecover.currentItem)
                when (fragment) {
                    is RecoverTrashPhotoFragment -> {
                        fragment.deleteAllImages()
                    }
                    is RecoverTrashVideoFragment -> {
                        fragment.deleteAllVideos()
                    }
                }
            }
        }
    }

    fun toggleToolbar(isShowActionBar: Boolean) {
        mBinding.tabLayout.beVisibleIf(!isShowActionBar)
        mBinding.tabLayout.beGoneIf(isShowActionBar)
        mBinding.llBottomOption.beVisibleIf(isShowActionBar)
        mBinding.llBottomOption.beGoneIf(!isShowActionBar)
        mBinding.viewPagerRecover.isUserInputEnabled = !isShowActionBar
    }

    fun updateCount(size: Int) {
        mBinding.tvDeleteText.text = resources.getString(R.string.label_delete_count, size)
        mBinding.tvRestore.text = resources.getString(R.string.label_restore, size)
    }

    companion object {
        var mMedia = ArrayList<ThumbnailItem>()
        var allMediaList = ArrayList<ThumbnailItem>()
        var isDeleteOrRestore = false
    }


    override fun onPause() {
        super.onPause()
        if (trashDialog != null) {
            trashDialog!!.dialog.dismiss()
        }
    }


    override fun setBinding(): ActivityRecoverPhotoTabBinding {
        return ActivityRecoverPhotoTabBinding.inflate(inflater)
    }
    override fun onBackPressed() {
        if (isDeleteOrRestore) {

            if (AdsManager(this).isNeedToShowAds() && isOnline()) {
                isInterstitialShown = true
                isShowInterstitialAd{
                    isInterstitialShown = false
                    isDeleteOrRestore =false
                    finish()
                }

            } else {
                isInterstitialShown = false
                isDeleteOrRestore =false
                finish()
            }
        } else {
            finish()
        }

    }

}