package com.gallery.photo.image.video.bindActivity

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.StrictMode
import android.os.SystemClock
import android.provider.Settings
import android.view.View
import androidx.annotation.LayoutRes
import androidx.annotation.UiThread
import androidx.core.text.HtmlCompat
import com.example.jdrodi.utilities.SPUtil
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.BaseActivity
import com.gallery.photo.image.video.utilities.addEvent
import com.gallery.photo.image.video.utilities.isUnLockApp
import com.gallery.photo.image.video.utilities.selectedLanguageCommon
import com.gallery.photo.image.video.extensions.baseConfig
import com.gallery.photo.image.video.extensions.getColoredDrawableWithColor

const val REQ_CODE_CAMERA_PERMISSION=10302
abstract class MainBaseBindingActivity : BaseActivity(), View.OnClickListener {
    var isFromSettingForCamera = false;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        addEvent(javaClass.simpleName)
        selectedLanguageCommon = baseConfig.appLanguage
        val policy: StrictMode.ThreadPolicy = StrictMode.ThreadPolicy.Builder()
            .permitAll().build()
        StrictMode.setThreadPolicy(policy)
        mContext = getContext()
        sp = SPUtil(mContext)

        getLayoutRes()?.let {
            setContentView(it)
        }
    }

    override fun setContentView(view: View) {
        super.setContentView(view)
        setContentView()
    }

    fun setContentView() {
        initViews()
        initAds()
        initData()
        initActions()
    }

    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()
    }

    /**
     * This method for set-up your data before call setContentView()
     */
    open fun setParamBeforeLayoutInit() {}

    @UiThread
    @LayoutRes
    abstract fun getLayoutRes(): Int?

    fun showCameraPermissionAlert() {
        isUnLockApp = true
        val alertDialogBuilder = AlertDialog.Builder(this, R.style.MyAlertDialogNew)
        alertDialogBuilder.setTitle(HtmlCompat.fromHtml("<font color='#0a82f3'>" + getString(R.string.error_permission_required) + "</font>", HtmlCompat.FROM_HTML_MODE_LEGACY))
            .setMessage(getString(R.string.msg_allow_permission_camera))
            .setPositiveButton(getString(R.string.ok))
            { dialog, which ->
                dialog.dismiss()
                dirsDialog1 = null
                isFromSettingForCamera=true
                val intent = Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", packageName, null)
                )
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
                //                            Share.isAppOpenAdShow = false
            }
            .setNegativeButton(getString(R.string.cancel)) { dialog, which ->
                dialog.dismiss()
                dirsDialog1 = null
                //                            finish()
            }
            .setCancelable(false)
        //alert dialog with theme

        if (dirsDialog1 == null) {
            dirsDialog1 = alertDialogBuilder.create()
            if (!dirsDialog1!!.isShowing()) {
                dirsDialog1!!.show()
                val bgDrawable = resources.getColoredDrawableWithColor(com.gallery.photo.image.video.R.drawable.dialog_bg, baseConfig.backgroundColor)
                dirsDialog1!!.window?.setBackgroundDrawable(bgDrawable)
                dirsDialog1!!.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setTextColor(resources.getColor(com.gallery.photo.image.video.R.color.color_primary))
                dirsDialog1!!.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEGATIVE).setTextColor(resources.getColor(com.gallery.photo.image.video.R.color.color_primary))
                dirsDialog1!!.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEUTRAL).setTextColor(resources.getColor(com.gallery.photo.image.video.R.color.color_primary))
            }
        }
    }

    var dirsDialog1: AlertDialog? = null

}