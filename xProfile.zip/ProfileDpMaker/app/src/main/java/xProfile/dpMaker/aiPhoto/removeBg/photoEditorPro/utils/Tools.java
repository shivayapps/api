package xProfile.dpMaker.aiPhoto.removeBg.photoEditorPro.utils;

public enum Tools {
    NONE,
    PROFILE,
    DRIP,
    FLIP,
    STICKER,
    PATTERN,
    DEGRADE,
    COLOR,
    ADJUST,
    ERASE,
    MAGIC,
    LASSO,
    RESTORE,
    ZOOM
}
