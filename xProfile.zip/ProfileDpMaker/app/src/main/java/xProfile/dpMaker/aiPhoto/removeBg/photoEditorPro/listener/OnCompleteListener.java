package xProfile.dpMaker.aiPhoto.removeBg.photoEditorPro.listener;

public interface OnCompleteListener {

    void onComplete();

}