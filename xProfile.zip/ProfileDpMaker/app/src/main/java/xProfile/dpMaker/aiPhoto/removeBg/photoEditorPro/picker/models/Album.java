package xProfile.dpMaker.aiPhoto.removeBg.photoEditorPro.picker.models;

public class Album {
    public String name;
    public String cover;

    public Album(String name, String cover) {
        this.name = name;
        this.cover = cover;
    }
}
