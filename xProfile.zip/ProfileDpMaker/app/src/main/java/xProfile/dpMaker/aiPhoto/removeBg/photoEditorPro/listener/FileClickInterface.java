package xProfile.dpMaker.aiPhoto.removeBg.photoEditorPro.listener;

public interface FileClickInterface {
    public void onPhotoClick(String filePath);
}
