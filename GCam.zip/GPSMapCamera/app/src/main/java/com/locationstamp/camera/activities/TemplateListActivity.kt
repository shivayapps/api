package com.locationstamp.camera.activities

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.ViewCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.adconfig.AdsConfig
import com.adconfig.adsutil.Config.checkReInter
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.locationstamp.camera.R
import com.locationstamp.camera.adapters.TemplateAdapter
import com.locationstamp.camera.databinding.ActivityTemplateListBinding
import com.locationstamp.camera.extentions.baseConfig
import com.locationstamp.camera.extentions.AdCache
import com.locationstamp.camera.extentions.beVisible
import com.locationstamp.camera.helper.LogUtils
import com.locationstamp.camera.helper.TEMPLATE_POSITION
import com.locationstamp.camera.helper.activity_tag
import com.locationstamp.camera.helper.open_tag

class TemplateListActivity : BaseActivity() {
    private var showingTemplate: Int = 0
    private lateinit var binding: ActivityTemplateListBinding
    private lateinit var templateAdapter: TemplateAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTemplateListBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        LogUtils.logAdapterMessages(
            this@TemplateListActivity, activity_tag, open_tag, TemplateListActivity::class.java.simpleName.toString()
        )
        showingTemplate = intent.getIntExtra("showingTemplate", 0)
        //hideNavigationBar()
        setViewPagerData()
        allClicks()

        loadBanner()
        loadInterAd()
    }

    private fun loadInterAd() {
        if (baseConfig.isNeedInterAd) {
            val interAdId = getString(R.string.inter_all)
            AdmobIntersAdImpl().load(this, interAdId)
        } else {
            checkReInter {
                if (it) {
                    val interAdId = getString(R.string.inter_all)
                    AdmobIntersAdImpl().load(this, interAdId)
                    baseConfig.isNeedInterAd = true
                }
            }
        }
    }

    var isAdLoaded = false
    var mAdView: AdView? = null
    private fun loadBanner() {
        val adId = getString(R.string.banner_template)
        BannerAdHelper.showBanner(
            this, binding.flNative, binding.flNative, adId,
            AdCache.templateAdView, { isLoaded, adView, message ->
                mAdView = adView
                AdCache.templateAdView = adView
                isAdLoaded = isLoaded
            })
    }

//    override fun onResume() {
//        super.onResume()
//        mAdView?.resume()
//    }

//    override fun onPause() {
//        super.onPause()
//        mAdView?.pause()
//    }
//    override fun onDestroy() {
//        super.onDestroy()
//        mAdView?.destroy()
//    }

    private fun allClicks() {
        binding.ivBack.setOnClickListener { onBackPressed() }
        binding.ivSave.setOnClickListener {
            baseConfig.templateSelected = baseConfig.templateSelectedTemporary
            if (showingTemplate == baseConfig.templateSelected) {
                finish()
            } else {
                val data = Intent()
                data.putExtra("template_position", baseConfig.templateSelected)
                setResult(Activity.RESULT_OK, data)
                finish()
            }
        }
    }

    private fun setViewPagerData() {
        val pageItems = listOf(
//            PageItem(R.layout.template_item_1),
//            PageItem(R.layout.template_item_2),
//            PageItem(R.layout.template_item_3),
//            PageItem(R.layout.template_item_4),
//            PageItem(R.layout.template_item_5),
            R.layout.template_layout_1,
            R.layout.template_layout_2,
            R.layout.template_layout_3,
            R.layout.template_layout_4,
            R.layout.template_layout_5,
            //PageItem(R.layout.template_layout_6),
        )

        templateAdapter = TemplateAdapter(this@TemplateListActivity, pageItems, { position ->
            baseConfig.templateSelectedTemporary = position
            templateAdapter.setCurrentItem(position, true)
            binding.ivSave.beVisible()
        })

        binding.rvTemplate.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        binding.rvTemplate.setHasFixedSize(true)
        binding.rvTemplate.adapter = templateAdapter
        templateAdapter.setCurrentItem(baseConfig.templateSelected, true)

//        TabLayoutMediator(binding.tabLayout, binding.viewPager) { tab, position ->
//            //Some implementation
////            binding.viewPager.adapter?.notifyItemChanged(position)
//        }.attach()
//        viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
//            override fun onPageSelected(position: Int) {
//                // This method is called when a new page is selected.
//                Log.w("msg", "onPageSelected: " + position)
////                baseConfig.templateSelected = position
//                baseConfig.templateSelectedTemporary = position
//                // If you want to notify your adapter of changes when a new page is selected, you can do it here.
////                viewPager.adapter?.notifyDataSetChanged()
//            }
//
//            // You can override other methods like onPageScrolled and onPageScrollStateChanged if needed.
//        })

        binding.tvEditTemplate.setOnClickListener {
            startActivity(Intent(this, TemplateEditorActivity::class.java).putExtra(TEMPLATE_POSITION, baseConfig.templateSelectedTemporary))
        }
    }


    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }

    override fun onResume() {
        super.onResume()
        mAdView?.resume()
        Log.w("msg", "onResume:templateActivity ")
//        binding.viewPager.adapter?.notifyItemChanged(baseConfig.templateSelectedTemporary)
        //binding.viewPager.adapter?.notifyDataSetChanged()
    }

    override fun onBackPressed() {
        if (baseConfig.isNeedInterAd) {
            AdsConfig.showInterstitialAd(this@TemplateListActivity) {
                if (it) baseConfig.isNeedInterAd = false
                finish()
            }
        } else {
            super.onBackPressed()
        }
    }

    fun onSave() {
        baseConfig.templateSelected = baseConfig.templateSelectedTemporary
//            Log.w("msg", "allClicks: " + showingTemplate)
//            Log.w("msg", "allClicks: " + baseConfig.templateSelected)
        if (showingTemplate == baseConfig.templateSelected) {
            finish()
        } else {
            val data = Intent()
            data.putExtra("template_position", baseConfig.templateSelected)
            setResult(Activity.RESULT_OK, data)
            finish()
        }
    }
}