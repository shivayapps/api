package com.locationstamp.camera.views

import android.content.Context
import android.graphics.Typeface
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatEditText
import com.locationstamp.camera.extentions.baseConfig

class MyRegularFontEditText : AppCompatEditText {
    constructor(context: Context) : super(context)

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs)

    constructor(context: Context, attrs: AttributeSet, defStyle: Int) : super(context, attrs, defStyle)

    companion object {
        private var mTypeface: Typeface? = null
    }

    init {
        val config = context.baseConfig
        if (mTypeface == null) {
            mTypeface = Typeface.createFromAsset(context.assets, "font/poppins_regular.ttf")
        }
        typeface = if (config.setSystemFont) {
            Typeface.DEFAULT
        } else {
            mTypeface
        }
    }
}
