package com.locationstamp.camera

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.adconfig.AdsConfig
import com.adconfig.adsutil.openad.AppOpenApplication
import com.adconfig.adsutil.openad.OpenAdHelper
import com.adconfig.adsutil.openad.WelcomeBackActivity
import com.google.firebase.FirebaseApp
import com.google.firebase.crashlytics.FirebaseCrashlytics
import com.locationstamp.camera.activities.AppPermissionActivity
import com.locationstamp.camera.activities.SplashActivity


class MyApplication : AppOpenApplication(), AppOpenApplication.AppLifecycleListener {

    override fun onCreate() {
        super.onCreate()

        context = this
        FirebaseApp.initializeApp(applicationContext)
        FirebaseCrashlytics.getInstance()
            .setCrashlyticsCollectionEnabled(!BuildConfig.VERSION_NAME.contains("test"));
        val appOpenId = getString(R.string.open_all)
        AdsConfig.builder()
            .setTestDeviceId("0")
            .setAdmobAppOpenId(appOpenId)
            .build(this)

        setAppLifecycleListener(this)
        initMobileAds()

    }

    override fun onResumeApp(fCurrentActivity: Activity): Boolean {
        if (fCurrentActivity is SplashActivity) {
            Log.d("AppOpenCheck", "Activity is AdActivity, returning false")
            return false
        } else if (fCurrentActivity is AppPermissionActivity) {
            return false
        } else if (AdsConfig.isSystemDialogOpen) {
            Handler(Looper.getMainLooper()).postDelayed({
                AdsConfig.isSystemDialogOpen = false
            }, 2000)
            return false
        }
        return true
    }

    override fun onActivityCreated(fCurrentActivity: Activity, savedInstanceState: Bundle?) {

    }

    override fun onAppOpenCreatedEvent(fCurrentActivity: Activity) {
        if (onResumeApp(fCurrentActivity))
            if (!fCurrentActivity.isDestroyed && !fCurrentActivity.isFinishing) {
                if (OpenAdHelper.isAdAvailable()) {
                    val intent = Intent(fCurrentActivity, WelcomeBackActivity::class.java)
                    intent.putExtra("isAdLoading", OpenAdHelper.isAdLoading)
                    fCurrentActivity.startActivity(intent)
                }
            }
    }

    override fun onAppOpenShownEvent(fCurrentActivity: Activity) {
    }

    override fun onAppOpenFailedEvent(fCurrentActivity: Activity) {
    }

    companion object {
        lateinit var context: Context
    }


//    private inner class AppOpenAdManager {
//        private var appOpenAd: AppOpenAd? = null
//        private var isLoadingAd = false
//        var isShowingAd = false
//
//        /** Keep track of the time an app open ad is loaded to ensure you don't show an expired ad. */
//        private var loadTime: Long = 0
//
//        /**
//         * Load an ad.
//         *
//         * @param context the context of the activity that loads the ad
//         */
//        fun loadAd(context: Context) {
//            // Do not load ad if there is an unused ad or one is already loading.
//            if (isLoadingAd || isAdAvailable()) {
//                return
//            }
//
//            isLoadingAd = true
//            val request = AdRequest.Builder().build()
//            AppOpenAd.load(
//                context,
//                AdStaticData.getOpenAdId(this@MyApplication),
//                request,
//                object : AppOpenAd.AppOpenAdLoadCallback() {
//                    /**
//                     * Called when an app open ad has loaded.
//                     *
//                     * @param ad the loaded app open ad.
//                     */
//                    override fun onAdLoaded(ad: AppOpenAd) {
//                        appOpenAd = ad
//                        isLoadingAd = false
//                        loadTime = Date().time
//                        Log.w(LOG_TAG, "onAdLoaded.")
//                    }
//
//                    /**
//                     * Called when an app open ad has failed to load.
//                     *
//                     * @param loadAdError the error.
//                     */
//                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
//                        isLoadingAd = false
//                        Log.w(LOG_TAG, "onAdFailedToLoad: " + loadAdError.message)
//                        reLoadAd(context)
//                    }
//                }
//            )
//        }
//
//        fun reLoadAd(context: Context) {
//            // Do not load ad if there is an unused ad or one is already loading.
//            if (isLoadingAd || isAdAvailable()) {
//                return
//            }
//
//            isLoadingAd = true
//            val request = AdRequest.Builder().build()
//            AppOpenAd.load(
//                context,
//                AdStaticData.getOpenAdReloadId(this@MyApplication),
//                request,
//                object : AppOpenAd.AppOpenAdLoadCallback() {
//                    /**
//                     * Called when an app open ad has loaded.
//                     *
//                     * @param ad the loaded app open ad.
//                     */
//                    override fun onAdLoaded(ad: AppOpenAd) {
//                        appOpenAd = ad
//                        isLoadingAd = false
//                        loadTime = Date().time
//                        Log.w(LOG_TAG, "onAdLoaded.")
//                    }
//
//                    /**
//                     * Called when an app open ad has failed to load.
//                     *
//                     * @param loadAdError the error.
//                     */
//                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
//                        isLoadingAd = false
//                        Log.w(LOG_TAG, "onAdFailedToLoad: " + loadAdError.message)
//                    }
//                }
//            )
//        }
//
//        /** Check if ad was loaded more than n hours ago. */
//        private fun wasLoadTimeLessThanNHoursAgo(numHours: Long): Boolean {
//            val dateDifference: Long = Date().time - loadTime
//            val numMilliSecondsPerHour: Long = 3600000
//            return dateDifference < numMilliSecondsPerHour * numHours
//        }
//
//        /** Check if ad exists and can be shown. */
//        private fun isAdAvailable(): Boolean {
//            // Ad references in the app open beta will time out after four hours, but this time limit
//            // may change in future beta versions. For details, see:
//            // https://support.google.com/admob/answer/9341964?hl=en
//            return appOpenAd != null && wasLoadTimeLessThanNHoursAgo(4)
//        }
//
//        /**
//         * Show the ad if one isn't already showing.
//         *
//         * @param activity the activity that shows the app open ad
//         */
//        fun showAdIfAvailable(activity: Activity) {
//            showAdIfAvailable(
//                activity,
//                object : OnShowAdCompleteListener {
//                    override fun onShowAdComplete() {
//                        // Empty because the user will go back to the activity that shows the ad.
//                    }
//                }
//            )
//        }
//
//        /**
//         * Show the ad if one isn't already showing.
//         *
//         * @param activity the activity that shows the app open ad
//         * @param onShowAdCompleteListener the listener to be notified when an app open ad is complete
//         */
//        fun showAdIfAvailable(activity: Activity, onShowAdCompleteListener: OnShowAdCompleteListener) {
//            // If the app open ad is already showing, do not show the ad again.
//            if (isShowingAd) {
//                Log.w(LOG_TAG, "The app open ad is already showing.")
//                return
//            }
//
//            // If the app open ad is not available yet, invoke the callback.
//            if (!isAdAvailable()) {
//                Log.w(LOG_TAG, "The app open ad is not ready yet.")
//                onShowAdCompleteListener.onShowAdComplete()
//                loadAd(activity)
//                return
//            }
//
//            Log.w(LOG_TAG, "Will show ad.")
//
//            appOpenAd?.fullScreenContentCallback =
//                object : FullScreenContentCallback() {
//                    /** Called when full screen content is dismissed. */
//                    override fun onAdDismissedFullScreenContent() {
//                        // Set the reference to null so isAdAvailable() returns false.
//                        appOpenAd = null
//                        isShowingAd = false
//                        Log.w(LOG_TAG, "onAdDismissedFullScreenContent.")
//
//                        onShowAdCompleteListener.onShowAdComplete()
//                        loadAd(activity)
//
//                    }
//
//                    /** Called when fullscreen content failed to show. */
//                    override fun onAdFailedToShowFullScreenContent(adError: AdError) {
//                        appOpenAd = null
//                        isShowingAd = false
//                        Log.w(LOG_TAG, "onAdFailedToShowFullScreenContent: " + adError.message)
//
//                        onShowAdCompleteListener.onShowAdComplete()
//                        loadAd(activity)
//                    }
//
//                    /** Called when fullscreen content is shown. */
//                    override fun onAdShowedFullScreenContent() {
//                        Log.w(LOG_TAG, "onAdShowedFullScreenContent.")
//                    }
//                }
//            isShowingAd = true
//            appOpenAd?.show(activity)
//        }
//    }

//    fun adConfigFinishAffinity() {
//        isSplashResumeOn = true
//    }
//
//    fun openAdHide() {
//        isOpenAdHide = true
//    }
}