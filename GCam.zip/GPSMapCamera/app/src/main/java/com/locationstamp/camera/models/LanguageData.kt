package com.locationstamp.camera.models

data class LanguageData(var name: String, var languageCode: String)
