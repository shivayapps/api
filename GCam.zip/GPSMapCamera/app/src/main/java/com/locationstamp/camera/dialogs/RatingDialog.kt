package com.locationstamp.camera.dialogs

import android.app.Activity
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.adconfig.AdsConfig
import com.google.android.play.core.review.ReviewInfo
import com.google.android.play.core.review.ReviewManager
import com.google.android.play.core.review.ReviewManagerFactory
import com.locationstamp.camera.R
import com.locationstamp.camera.databinding.DialogRatingBinding
import com.locationstamp.camera.extentions.baseConfig
import com.locationstamp.camera.extentions.getReviewEmail
import com.locationstamp.camera.extentions.toast
import java.lang.ref.WeakReference
import java.util.prefs.Preferences

class RatingDialog(
    var activity: Activity
) : Dialog(activity) {

    lateinit var bindingDialog: DialogRatingBinding
    var rate: Float = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.setDimAmount(0.8f)
        window?.setGravity(Gravity.BOTTOM)

        bindingDialog = DialogRatingBinding.inflate(layoutInflater)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT
        )
        setCancelable(true)
        setCanceledOnTouchOutside(true)
        AdsConfig.isSystemDialogOpen = true
        intView()

    }

    private fun intView() {
        bindingDialog.simpleRatingBar.setOnRatingChangeListener { ratingBar, rating, fromUser ->
            rate = rating
//            when (rating) {
//                0f -> {
//                    bindingDialog.txtTitle.setText(activity.getString(R.string.rate_title_good))
//                    bindingDialog.ivTop.setImageResource(R.drawable.rate_five)
//                }
//
//                1f -> {
//                    bindingDialog.txtTitle.setText(activity.getString(R.string.rate_title_fair))
//                    bindingDialog.ivTop.setImageResource(R.drawable.rate_one)
//                }
//
//                2f -> {
//                    bindingDialog.txtTitle.setText(activity.getString(R.string.rate_title_fair))
//                    bindingDialog.ivTop.setImageResource(R.drawable.rate_two)
//                }
//
//                3f -> {
//                    bindingDialog.txtTitle.setText(activity.getString(R.string.rate_title_good))
//                    bindingDialog.ivTop.setImageResource(R.drawable.rate_three)
//                }
//
//                4f -> {
//                    bindingDialog.txtTitle.setText(activity.getString(R.string.rate_title_good))
//                    bindingDialog.ivTop.setImageResource(R.drawable.rate_four)
//                }
//
//                5f -> {
//                    bindingDialog.txtTitle.setText(activity.getString(R.string.rate_title_good))
//                    bindingDialog.ivTop.setImageResource(R.drawable.rate_five)
//                }
//            }
        }

        intListener()

    }

    private fun showInAppRateDialog(activity: Activity) {

        AdsConfig.isSystemDialogOpen = true
        Log.e("RatingDialog", "showInAppRateDialog")
        val reviewManager = ReviewManagerFactory.create(activity)
        val activityRef = WeakReference(activity)
        val requestReview = reviewManager.requestReviewFlow()
        requestReview.addOnCompleteListener { task ->
            Log.e("RatingDialog", "showInAppRateDialog.task:${task.isSuccessful}")
            if (task.isSuccessful) {
                val fragmentActivity = activityRef.get()
                if (fragmentActivity != null) {
                    showInAppRateDialogInternal(
                        reviewManager,
                        fragmentActivity,
                        task.result
                    )
                }
            } else {
                Log.e("RatingDialog", "showInAppRateDialog.exception:${task.exception}")
//                log.error(task.exception)
            }
        }
    }

    private fun showInAppRateDialogInternal(
        reviewManager: ReviewManager,
        activity: Activity,
        reviewInfo: ReviewInfo
    ) {
        AdsConfig.isSystemDialogOpen = true
        Log.e("RatingDialog", "showInAppRateDialogInternal")
        val reviewFlow = reviewManager.launchReviewFlow(activity, reviewInfo)
        val activityRef = WeakReference(activity)
        reviewFlow.addOnCompleteListener { task ->
            Log.e("RatingDialog", "showInAppRateDialogInternal.task:${task.isSuccessful}")
            if (task.isSuccessful) {
                val fragmentActivity = activityRef.get()
                if (fragmentActivity != null) {
                    launchAppStore()
                    Log.e("RatingDialog", "showInAppRateDialogInternal.RateUsState.IGNORED")
//                    storeRateResult(fragmentActivity, RateUsState.IGNORED)
                }
            } else {
                Log.e("RatingDialog", "showInAppRateDialogInternal.exception:${task.exception}")
//                log.error(task.exception)
            }
        }
    }

    private fun launchAppStore() {

        AdsConfig.isSystemDialogOpen = true
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("http://play.google.com/store/apps/details?id=${activity.packageName}")
        )
        activity.startActivity(intent)
    }

    private fun launchEmail() {

        val i = Intent(Intent.ACTION_SEND)
        i.type = "message/rfc822"
        i.putExtra(Intent.EXTRA_EMAIL, arrayOf(activity.getReviewEmail()))
        i.putExtra(
            Intent.EXTRA_SUBJECT,
            "${activity.getString(R.string.app_name)} ${activity.getString(R.string.feedback)}"
        )
        i.putExtra(Intent.EXTRA_TEXT, "")
        i.setPackage("com.google.android.gm")

        try {
            AdsConfig.isSystemDialogOpen = true
            activity.startActivity(Intent.createChooser(i, "Send mail"))
        } catch (ex: ActivityNotFoundException) {
            activity.toast("There are no email clients installed")
        }
    }

    private fun intListener() {
        bindingDialog.ivCloseDialog.setOnClickListener {
            dismiss()
        }
        bindingDialog.btnOk.setOnClickListener {
            if (rate >= 4) {
                activity.baseConfig.isRatingDone = true
                showInAppRateDialog(activity)
            } else if (rate >= 1) {
                launchEmail()
            } else {
                activity.toast("Please rate us. Your opinion is important to us.")
                return@setOnClickListener
            }
            dismiss()
        }
    }

//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)
}