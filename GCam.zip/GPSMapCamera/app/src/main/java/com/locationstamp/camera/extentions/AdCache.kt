package com.locationstamp.camera.extentions

import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.nativead.NativeAd

class AdCache {
    companion object {
        var cameraAdView:AdView?=null
        var galleryAdView:AdView?=null
        var templateAdView:AdView?=null
        var fullScreeAdView:AdView?=null
        var mapAdView:AdView?=null
    }
}


