package com.timestamp.gpsmap.views

import android.content.Context
import android.graphics.Typeface
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatTextView
import com.timestamp.gpsmap.extentions.baseConfig

class MyMediumFontTextView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : AppCompatTextView(context, attrs, defStyle) {

    companion object {
        private var mTypeface: Typeface? = null
    }

    init {
        val config = context.baseConfig
        if (mTypeface == null) {
            mTypeface = Typeface.createFromAsset(context.assets, "font/hind_medium.ttf")
        }
        typeface = if (config.setSystemFont) {
            Typeface.DEFAULT
        } else {
            mTypeface
        }
    }
}