package com.timestamp.gpsmap.adapters

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.util.Log
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.timestamp.gpsmap.R
import com.timestamp.gpsmap.activities.CameraActivity
import com.timestamp.gpsmap.activities.TemplateEditActivity
import com.timestamp.gpsmap.extentions.baseConfig
import com.timestamp.gpsmap.extentions.beGoneIf
import com.timestamp.gpsmap.extentions.beVisibleIf
import com.timestamp.gpsmap.helpers.TEMPLATE_POSITION
import com.timestamp.gpsmap.listeners.OnItemClick
import com.timestamp.gpsmap.models.PageItem

class MyPagerAdapter(private val context: Context, private val items: List<PageItem>, val listener : OnItemClick) :
    RecyclerView.Adapter<MyPagerAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val layoutResId = items[viewType].layoutResId
        val itemView = layoutInflater.inflate(layoutResId, parent, false)
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        // You can perform any view setup here if needed
        holder.itemView.findViewById<ImageView>(R.id.iv_edit_template).setOnClickListener {
            context.startActivity(Intent(context, TemplateEditActivity::class.java).putExtra(TEMPLATE_POSITION, position))
        }
        holder.itemView.setOnClickListener {
            context.startActivity(Intent(context, TemplateEditActivity::class.java).putExtra(TEMPLATE_POSITION, position))
        }
        holder.itemView.findViewById<TextView>(R.id.iv_edit_template).beVisibleIf(context.baseConfig.templateSelected == position)
        holder.itemView.findViewById<TextView>(R.id.tvSetTemplate).beGoneIf(context.baseConfig.templateSelected == position)
        holder.itemView.findViewById<TextView>(R.id.tvSetTemplate).setOnClickListener {
            listener.onClick()
        }

        var fontSize = context.baseConfig.getTextSize(context)
        val typefaceCustom = when (context.baseConfig.stampFontStyle) {
            0 -> Typeface.createFromAsset(context.assets, "font/hind_medium.ttf")
            1 -> Typeface.createFromAsset(context.assets, "font/inter_medium.ttf")
            2 -> Typeface.createFromAsset(context.assets, "font/roboto_medium.ttf")
            3 -> Typeface.createFromAsset(context.assets, "font/poppins_medium.ttf")
            4 -> Typeface.createFromAsset(context.assets, "font/sf_ui_medium.otf")
            else -> Typeface.createFromAsset(context.assets, "font/hind_medium.ttf")
        }

        if(context.baseConfig.stampPosition == 0) {
            holder.itemView.findViewById<View>(R.id.flTopBottom).alightParentTopIs(true)
        } else {
            holder.itemView.findViewById<View>(R.id.flTopBottom).alightParentBottomIs(true)
        }
        holder.itemView.findViewById<View>(R.id.includedTemplate).apply {
            findViewById<CardView>(R.id.cv_map).beVisibleIf(context.baseConfig.showMap)
            findViewById<ImageView>(R.id.iv_map_template).setImageDrawable(context.baseConfig.getMapTypeImage(context))
            findViewById<TextView>(R.id.tv_address_template).apply {
                beVisibleIf(context.baseConfig.showAddress)
                text = CameraActivity.tempAddress
                setTextColor(context.baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_lat_long_template).apply {
                beVisibleIf(context.baseConfig.showLatLong)
                text = context.baseConfig.formatLatLong(
                    CameraActivity.tempLatitude,
                    CameraActivity.tempLongitude
                )
                setTextColor(context.baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_plus_code_template).apply {
                beVisibleIf(context.baseConfig.showPlusCode)
                text = "Plus code:" + context.baseConfig.stampPlusCode
                setTextColor(context.baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_note_template).apply {
                beVisibleIf(context.baseConfig.showNote)
                text = "Note: " + context.baseConfig.lastNote
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_time_template).apply {
                beVisibleIf(context.baseConfig.showDateTime)
                text = context.baseConfig.dateFormat
                setTextColor(context.baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_time_zone_template).apply {
                beVisibleIf(context.baseConfig.showTimeZone)
                text = context.baseConfig.getTimezoneText()
                setTextColor(context.baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<ImageView>(R.id.iv_logo_template).apply {
                beVisibleIf(context.baseConfig.showLogo)
            }
            findViewById<TextView>(R.id.tv_altitude_template).apply {
                beVisibleIf(context.baseConfig.showAltitude)
                text = "Altitude:" + context.baseConfig.getAltitudeText(context)
                setTextColor(context.baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_accuracy_template).apply {
                beVisibleIf(context.baseConfig.showAccuracy)
                text = "Accuracy:" + context.baseConfig.getAccuracyText(context)
                setTextColor(context.baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_weather_template).apply {
                beVisibleIf(context.baseConfig.showWeather)
                text = "Weather:" + context.baseConfig.getWeatherText(context)
                setTextColor(context.baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_wind_template).apply {
                beVisibleIf(context.baseConfig.showWind)
                text = "Wind:" + context.baseConfig.getWindText(context)
                setTextColor(context.baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_pressure_template).apply {
                beVisibleIf(context.baseConfig.showPressure)
                text = "Pressure:" + context.baseConfig.getPressureText(context)
                setTextColor(context.baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_humidity_template).apply {
                beVisibleIf(context.baseConfig.showHumidity)
                text = "Humidity:" + CameraActivity.tempHumidity
                setTextColor(context.baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
        }
    }

    override fun getItemCount(): Int {
        return items.size
    }

    override fun getItemViewType(position: Int): Int {
        // Return the viewType (position) as it corresponds to the layout resource ID
        return position
    }

    infix fun View.alightParentBottomIs(aligned: Boolean) {
        Log.w("msg", "alightParentBottomIs: " + aligned)
        val layoutParams = this.layoutParams as? RelativeLayout.LayoutParams
        if (aligned) {
            (this.layoutParams as? RelativeLayout.LayoutParams)?.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM)
        } else {
            (this.layoutParams as? RelativeLayout.LayoutParams)?.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM, 0)
        }
        this.layoutParams = layoutParams
    }

    infix fun View.alightParentTopIs(aligned: Boolean) {
        Log.w("msg", "alightParentTopIs: " + aligned)
        val layoutParams = this.layoutParams as? RelativeLayout.LayoutParams
        if (aligned) {
            (this.layoutParams as? RelativeLayout.LayoutParams)?.addRule(RelativeLayout.ALIGN_PARENT_TOP)
        } else {
            (this.layoutParams as? RelativeLayout.LayoutParams)?.addRule(RelativeLayout.ALIGN_PARENT_TOP, 0)
        }
        this.layoutParams = layoutParams
    }

    /*override fun getItemId(position: Int): Long {
        return super.getItemId(position)
    }*/
}