package com.timestamp.gpsmap.models

data class RatioItem(val width: Int, val height: Int)
