package com.timestamp.gpsmap.adloaders

import android.content.Context
import android.content.pm.PackageInfo
import android.util.Log
import com.timestamp.gpsmap.R
import com.timestamp.gpsmap.MyApplication
import com.timestamp.gpsmap.helpers.EventKeys
import org.json.JSONArray


object AdStaticData {

    val admob_openAd = "admob_openAd"
    val admob_openAd_2 = "admob_openAd_2"
    val admob_banner = "admob_banner"
    val admob_banner_2 = "admob_banner_2"
    var admob_interstitial = "admob_interstitial"
    var admob_interstitial_2 = "admob_interstitial_2"
    var admob_native = "admob_native"
    var admob_native_2 = "admob_native_2"

    val adIds: String = MyApplication.remoteConfig.getString(EventKeys.adIdsJson)
    val array = JSONArray(adIds)
    val obj = array.getJSONObject(0)
    val admob_openAd_id = obj.getString(admob_openAd)
    val admob_openAd_id_2 = obj.getString(admob_openAd_2)
    val admob_banner_id = obj.getString(admob_banner)
    val admob_banner_id_2 = obj.getString(admob_banner_2)
    val admob_interstitial_id = obj.getString(admob_interstitial)
    val admob_interstitial_id_2 = obj.getString(admob_interstitial_2)
    val admob_native_id = obj.getString(admob_native)
    val admob_native_id_2 = obj.getString(admob_native_2)

    fun getOpenAdId(context: Context): String {
//        Log.w("msg", "loadIntAds:obj " + obj)
//        Log.w("msg", "loadIntAds:admob_openAd " + obj.getString(AdStaticData.admob_openAd))
        return if (verifyForTest(context)) {
            if (MyApplication.remoteConfig.getString(admob_openAd_id) != "") {
                MyApplication.remoteConfig.getString(admob_openAd_id)
            } else {
                context.getString(R.string.admob_openAd)
            }
        } else {
            "ca-app-pub-3940256099942544/9257395921"
        }
    }

    fun getOpenAdReloadId(context: Context): String {
        return if (verifyForTest(context)) {
            if (MyApplication.remoteConfig.getString(admob_openAd_id_2) != "") {
                MyApplication.remoteConfig.getString(admob_openAd_id_2)
            } else {
                context.getString(R.string.admob_openAd_2)
            }
        } else {
            "ca-app-pub-3940256099942544/9257395921"
        }
    }

    fun getBannerAdId(context: Context): String {
        return if (verifyForTest(context)) {
            if (MyApplication.remoteConfig.getString(admob_banner_id) != "") {
                MyApplication.remoteConfig.getString(admob_banner_id)
            } else {
                context.getString(R.string.admob_banner)
            }
        } else {
            "ca-app-pub-3940256099942544/6300978111"
        }
    }

    fun getBannerAdReloadId(context: Context): String {
        return if (verifyForTest(context)) {
            if (MyApplication.remoteConfig.getString(admob_banner_id_2) != "") {
                MyApplication.remoteConfig.getString(admob_banner_id_2)
            } else {
                context.getString(R.string.admob_banner_2)
            }
        } else {
            "ca-app-pub-3940256099942544/6300978111"
        }
    }

    fun getInterstitialAdLoaderId(context: Context): String {
        return if (verifyForTest(context)) {
            if (MyApplication.remoteConfig.getString(admob_interstitial_id) != "") {
                MyApplication.remoteConfig.getString(admob_interstitial_id)
            } else {
                context.getString(R.string.admob_interstitial)
            }
        } else {
            "ca-app-pub-3940256099942544/1033173712"
        }
    }

    fun getInterstitialAdLoadReloadId(context: Context): String {
        return if (verifyForTest(context)) {
            if (MyApplication.remoteConfig.getString(admob_interstitial_id_2) != "") {
                MyApplication.remoteConfig.getString(admob_interstitial_id_2)
            } else {
                context.getString(R.string.admob_interstitial_2)
            }
        } else {
            "ca-app-pub-3940256099942544/1033173712"
        }
    }

    fun getNativeId(context: Context): String {
        return if (verifyForTest(context)) {
            if (MyApplication.remoteConfig.getString(admob_native_id) != "") {
                MyApplication.remoteConfig.getString(admob_native_id)
            } else {
                context.getString(R.string.admob_native)
            }
        } else {
            "ca-app-pub-3940256099942544/2247696110"
        }
    }

    fun getBackNativeId(context: Context): String {
        return if (verifyForTest(context)) {
            if (MyApplication.remoteConfig.getString(admob_native_id_2) != "") {
                MyApplication.remoteConfig.getString(admob_native_id_2)
            } else {
                context.getString(R.string.admob_native_2)
            }
        } else {
            "ca-app-pub-3940256099942544/2247696110"
        }
    }

    private fun verifyForTest(context: Context): Boolean {
        return try {
            val pInfo: PackageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
            pInfo.versionName.matches(Regex("[0-9][0-9.]*[0-9]"))
        } catch (e: Exception) {
            Log.e("verifyForTest", "verifyForTest: Error" + e.message)
            false
        }
    }

}