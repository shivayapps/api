package com.timestamp.gpsmap.activities

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.timestamp.gpsmap.extentions.baseConfig

abstract class BaseActivity : AppCompatActivity() {

    companion object {

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        checkSelectedTheme()
    }

    @SuppressLint("NewApi")
    override fun onResume() {
        super.onResume()
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        /*Log.w(
            "msg",
            "onConfigurationChanged: " + resources?.configuration?.uiMode?.and(Configuration.UI_MODE_NIGHT_MASK)
        )
        when (resources?.configuration?.uiMode?.and(Configuration.UI_MODE_NIGHT_MASK)) {
            Configuration.UI_MODE_NIGHT_YES -> {
                appRefresh()
            }

            Configuration.UI_MODE_NIGHT_NO -> {
                appRefresh()
            }

            Configuration.UI_MODE_NIGHT_UNDEFINED -> {
                appRefresh()
            }
        }
        checkSelectedTheme()*/
    }

    private fun appRefresh() {
        recreate()
    }

//    override fun attachBaseContext(newBase: Context) {
//        if (newBase.baseConfig.useEnglish && !isTiramisuPlus()) {
//            super.attachBaseContext(MyContextWrapper(newBase).wrap(newBase, "en"))
//        } else {
//            super.attachBaseContext(newBase)
//        }
//    }

    fun hideNavigationBar() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val windowInsetsController =
                WindowCompat.getInsetsController(window, window.decorView) ?: return

            windowInsetsController.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            windowInsetsController.hide(WindowInsetsCompat.Type.navigationBars())
        } else {
            window.decorView.systemUiVisibility =
                (View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        }
    }

    private fun checkSelectedTheme() {
        when (baseConfig.themeSelectedMode) {
            0 -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
//                delegate.applyDayNight()
            }

            1 -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
//                delegate.applyDayNight()
            }
            /*2 -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
//                delegate.applyDayNight()
            }

            else -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
//                delegate.applyDayNight()
            }*/
        }
    }

    override fun attachBaseContext(base: Context?) {
        super.attachBaseContext(
            com.timestamp.gpsmap.helpers.LocaleHelper.onAttach(
                base, "en"
            )
        )
    }
}
