package com.timestamp.gpsmap.cameraview.controls;

/**
 * Base interface for controls like {@link Audio},
 * {@link Facing}, {@link Flash} and so on.
 */
public interface Control {
}
