package com.timestamp.gpsmap.activities

import android.os.Bundle
import com.timestamp.gpsmap.R
import com.timestamp.gpsmap.databinding.ActivityMapDataBinding
import com.timestamp.gpsmap.extentions.baseConfig
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapFragment
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.timestamp.gpsmap.helpers.AppUtils
import com.timestamp.gpsmap.helpers.activity_tag
import com.timestamp.gpsmap.helpers.open_tag

class MapDataActivity : BaseActivity(), OnMapReadyCallback {
    private lateinit var binding: ActivityMapDataBinding
    private lateinit var googleMap: GoogleMap

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMapDataBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AppUtils.logAdapterMessages(
            this@MapDataActivity,
            activity_tag,
            open_tag,
            MapDataActivity::class.java.simpleName.toString()
        )
        hideNavigationBar()
        val mapFragment = fragmentManager.findFragmentById(R.id.map_data) as MapFragment
        mapFragment.getMapAsync(this)

        initData()
        allClicks()
    }

    private fun initData() {
        binding.tvDateData.text = baseConfig.getCurrentDateFormatted()
        binding.tvLatData.text = "Lat: " + CameraActivity.tempLatitude
        binding.tvLongData.text = "Lon: " + CameraActivity.tempLongitude
        binding.tvAddressData.text = CameraActivity.tempAddress
        binding.tvNoteData.text = "Note: " + baseConfig.lastNote
        binding.tvTimeData.text = baseConfig.formatDateTimeWithColon()
    }

    private fun allClicks() {
        binding.ivBack.setOnClickListener {
            finish()
        }
    }

    override fun onMapReady(gMap: GoogleMap) {
        googleMap = gMap

        googleMap.mapType = baseConfig.stampMapType
        try {
            googleMap.isMyLocationEnabled = false
        } catch (se: SecurityException) {
            // Handle the security exception here
        }

        // Edit the following settings as needed
        googleMap.isTrafficEnabled = true
        googleMap.isIndoorEnabled = true
        googleMap.isBuildingsEnabled = true
        googleMap.uiSettings.setAllGesturesEnabled(false)
        /*googleMap.uiSettings.isZoomGesturesEnabled = false
        googleMap.uiSettings.isScrollGesturesEnabled = false
        googleMap.uiSettings.isCompassEnabled = false
        googleMap.uiSettings.isZoomControlsEnabled = false
        googleMap.uiSettings.isMapToolbarEnabled = false*/

        val placeLocation = LatLng(CameraActivity.tempLatitude, CameraActivity.tempLongitude) // Replace with your actual coordinates
        val placeMarker = googleMap.addMarker(
            MarkerOptions().position(placeLocation)
                .title("YOU ARE HERE"))
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(placeLocation))
        googleMap.animateCamera(CameraUpdateFactory.zoomTo(17.0f), 1000, null)
//        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(baseConfig.lastLatitude.toDouble(), baseConfig.lastLatitude.toDouble()), 15.0f))
    }
}