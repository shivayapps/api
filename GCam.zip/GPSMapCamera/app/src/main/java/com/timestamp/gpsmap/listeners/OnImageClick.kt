package com.timestamp.gpsmap.listeners

interface OnImageClick {
    fun onImgClick(position: Int)
}