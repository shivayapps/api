package com.timestamp.gpsmap.activities

import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import com.timestamp.gpsmap.adapters.ImagePagerAdapter
import com.timestamp.gpsmap.databinding.ActivityImageShowBinding
import java.io.File

class ImageShowActivity : BaseActivity() {

    private lateinit var imageList: MutableList<String>
    private lateinit var binding: ActivityImageShowBinding
    private lateinit var pagerAdapter: ImagePagerAdapter
    private var position = 0

    companion object {
        var imageShowActivity: ImageShowActivity? = null
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityImageShowBinding.inflate(layoutInflater)
        setContentView(binding.root)

        hideNavigationBar()
        imageShowActivity = this
        position = intent.getIntExtra("selectedImage", 0)
        imageList = mutableListOf()

        allClicks()
        pagerAdapter = ImagePagerAdapter(this@ImageShowActivity, this@ImageShowActivity, getImageList()) /*{ position ->
            // Open ViewPager2 with clicked image
            binding.viewPager.setCurrentItem(position, true)
        }*/

        binding.viewPager.adapter = pagerAdapter
        binding.viewPager.setCurrentItem(position, false)
    }

    private fun allClicks() {
        binding.ivBack.setOnClickListener {
            finish()
        }
    }

    private fun getImageList(): List<String> {
        val projection = arrayOf(MediaStore.Images.Media.DATA)
//        val folderPath = "/path/to/gallery/folder" // Replace with your desired folder path
        val root = Environment.getExternalStorageDirectory().toString()
        val folderPath = File("$root/DCIM/GPSCameraImages")
        val cursor = contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            projection,
            MediaStore.Images.Media.DATA + " like ? ",
            arrayOf("%$folderPath%"),
            null
        )

        cursor?.use {
            while (it.moveToNext()) {
                val imagePath = it.getString(it.getColumnIndex(MediaStore.Images.Media.DATA))
                imageList.add(imagePath)
            }
        }

        return imageList
    }

    override fun onResume() {
        super.onResume()
    }

}