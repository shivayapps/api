package com.timestamp.gpsmap.views

import android.content.Context
import android.graphics.Typeface
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatTextView
import com.timestamp.gpsmap.extentions.baseConfig

class StampMediumFontTextView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : AppCompatTextView(context, attrs, defStyle) {

    companion object {
        private var mTypeface: Typeface? = null
        private var mTypeface1: Typeface? = null
        private var mTypeface2: Typeface? = null
        private var mTypeface3: Typeface? = null
        private var mTypeface4: Typeface? = null
    }

    init {
        val config = context.baseConfig
        if (mTypeface == null) {
            mTypeface = Typeface.createFromAsset(context.assets, "font/hind_medium.ttf")
            /*mTypeface = when (config.stampFontStyle) {
                0 -> {
                    Log.w("msg", "stampFontStyle:0 ")
                    Typeface.createFromAsset(context.assets, "font/hind_medium.ttf")
                }
                1 -> {
                    Log.w("msg", "stampFontStyle:1 ")
                    Typeface.createFromAsset(context.assets, "font/inter_medium.ttf")
                }
                2 -> {
                    Log.w("msg", "stampFontStyle:2 ")
                    Typeface.createFromAsset(context.assets, "font/roboto_medium.ttf")
                }
                3 -> {
                    Log.w("msg", "stampFontStyle:3 ")
                    Typeface.createFromAsset(context.assets, "font/poppins_medium.ttf")
                }
                4 -> {
                    Log.w("msg", "stampFontStyle:4 ")
                    Typeface.createFromAsset(context.assets, "font/sf_ui_medium.otf")
                }
                else -> {
                    Log.w("msg", "stampFontStyle:else ")
                    Typeface.createFromAsset(context.assets, "font/hind_medium.ttf")
                }
            }*/
        }
        if (mTypeface1 == null) {
            mTypeface1 = Typeface.createFromAsset(context.assets, "font/inter_medium.ttf")
        }
        if (mTypeface2 == null) {
            mTypeface2 = Typeface.createFromAsset(context.assets, "font/roboto_medium.ttf")
        }
        if (mTypeface3 == null) {
            mTypeface3 = Typeface.createFromAsset(context.assets, "font/poppins_medium.ttf")
        }
        if (mTypeface4 == null) {
            mTypeface4 = Typeface.createFromAsset(context.assets, "font/sf_ui_medium.otf")
        }
        typeface = when (config.stampFontStyle) {
            0 -> mTypeface
            1 -> mTypeface1
            2 -> mTypeface2
            3 -> mTypeface3
            4 -> mTypeface4
            else -> mTypeface
        }
//        Log.w("msg", "typeface: " + typeface)
        /*typeface = if (config.setSystemFont) {
            Typeface.DEFAULT
        } else {
//            Log.w("msg", "stampFontStyle: " + config.stampFontStyle)
            mTypeface
        }*/
    }
}