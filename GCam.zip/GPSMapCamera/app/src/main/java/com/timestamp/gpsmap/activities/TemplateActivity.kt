package com.timestamp.gpsmap.activities

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.viewpager2.widget.ViewPager2
import com.timestamp.gpsmap.R
import com.timestamp.gpsmap.adapters.MyPagerAdapter
import com.timestamp.gpsmap.databinding.ActivityTemplateBinding
import com.timestamp.gpsmap.extentions.baseConfig
import com.timestamp.gpsmap.models.PageItem
import com.google.android.material.tabs.TabLayoutMediator
import com.timestamp.gpsmap.adloaders.BannerAds
import com.timestamp.gpsmap.extentions.beGone
import com.timestamp.gpsmap.extentions.beVisible
import com.timestamp.gpsmap.helpers.AppUtils
import com.timestamp.gpsmap.helpers.activity_tag
import com.timestamp.gpsmap.helpers.isOnline
import com.timestamp.gpsmap.helpers.open_tag
import com.timestamp.gpsmap.listeners.OnItemClick

class TemplateActivity : BaseActivity(), OnItemClick {
    private var showingTemplate: Int = 0
    private lateinit var binding: ActivityTemplateBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTemplateBinding.inflate(layoutInflater)
        setContentView(binding.root)

        AppUtils.logAdapterMessages(
            this@TemplateActivity,
            activity_tag,
            open_tag,
            TemplateActivity::class.java.simpleName.toString()
        )
        showingTemplate = intent.getIntExtra("showingTemplate", 0)
        hideNavigationBar()
        setViewPagerData()
        allClicks()
        loadBanner()
    }

    private fun loadBanner() {
        if (isOnline) {
            BannerAds().loadAdmobBannerAds(
                this@TemplateActivity,
                binding.flNative, ""
            )
            binding.flNative.beVisible()
        } else {
            binding.flNative.beGone()
        }
    }

    private fun allClicks() {
        binding.ivBack.setOnClickListener { finish() }
        binding.ivSave.setOnClickListener {
            baseConfig.templateSelected = baseConfig.templateSelectedTemporary
//            Log.w("msg", "allClicks: " + showingTemplate)
//            Log.w("msg", "allClicks: " + baseConfig.templateSelected)
            if(showingTemplate == baseConfig.templateSelected) {
                finish()
            } else {
                val data = Intent()
                data.putExtra("template_position", baseConfig.templateSelected)
                setResult(Activity.RESULT_OK, data)
                finish()
            }
        }
    }

    private fun setViewPagerData() {
        val pageItems = listOf(
            PageItem(R.layout.template_item_1),
            PageItem(R.layout.template_item_2),
            PageItem(R.layout.template_item_3),
            PageItem(R.layout.template_item_4),
            PageItem(R.layout.template_item_5)
        )

        val pagerAdapter = MyPagerAdapter(this@TemplateActivity, pageItems, this@TemplateActivity)
        val viewPager = binding.viewPager
        viewPager.adapter = pagerAdapter
        viewPager.setCurrentItem(baseConfig.templateSelected, false)
        TabLayoutMediator(binding.tabLayout, binding.viewPager) { tab, position ->
            //Some implementation
//            binding.viewPager.adapter?.notifyItemChanged(position)
        }.attach()
        viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                // This method is called when a new page is selected.
                Log.w("msg", "onPageSelected: " + position)
//                baseConfig.templateSelected = position
                baseConfig.templateSelectedTemporary = position
                // If you want to notify your adapter of changes when a new page is selected, you can do it here.
//                viewPager.adapter?.notifyDataSetChanged()
            }

            // You can override other methods like onPageScrolled and onPageScrollStateChanged if needed.
        })
    }

    override fun onResume() {
        super.onResume()
        Log.w("msg", "onResume:templateActivity ")
//        binding.viewPager.adapter?.notifyItemChanged(baseConfig.templateSelectedTemporary)
        binding.viewPager.adapter?.notifyDataSetChanged()
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }

    override fun onClick() {
        baseConfig.templateSelected = baseConfig.templateSelectedTemporary
//            Log.w("msg", "allClicks: " + showingTemplate)
//            Log.w("msg", "allClicks: " + baseConfig.templateSelected)
        if(showingTemplate == baseConfig.templateSelected) {
            finish()
        } else {
            val data = Intent()
            data.putExtra("template_position", baseConfig.templateSelected)
            setResult(Activity.RESULT_OK, data)
            finish()
        }
    }
}