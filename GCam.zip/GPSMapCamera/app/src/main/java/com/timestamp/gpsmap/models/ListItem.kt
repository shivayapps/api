package com.timestamp.gpsmap.models

data class ListItem(/*val imageResId: Int,*/ val text: String)
