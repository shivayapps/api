package com.timestamp.gpsmap.activities

import android.content.Intent
import android.os.Bundle
import com.timestamp.gpsmap.databinding.ActivityIntroBinding
import com.timestamp.gpsmap.extentions.baseConfig
import com.timestamp.gpsmap.helpers.AppUtils
import com.timestamp.gpsmap.helpers.activity_tag
import com.timestamp.gpsmap.helpers.open_tag

class IntroActivity : BaseActivity() {
    private lateinit var binding: ActivityIntroBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityIntroBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AppUtils.logAdapterMessages(
            this@IntroActivity,
            activity_tag,
            open_tag,
            IntroActivity::class.java.simpleName.toString()
        )
        hideNavigationBar()
        allClicks()
    }

    private fun allClicks() {
        binding.tvGetStarted.setOnClickListener {
            baseConfig.introScreenShow = 1
            startActivity(Intent(this, PermissionActivity::class.java))
            finish()
        }
    }

    /*private fun hideNavigationBar() {
        // Check if the device is running Android 11 or higher
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // Get the WindowInsetsController
            val windowInsetsController = window.insetsController

            // Hide the navigation bar
            windowInsetsController?.hide(WindowInsets.Type.navigationBars())

            // To make the navigation bar appear temporarily when swiping from the edge of the screen
            // you can use the following line:
            windowInsetsController?.systemBarsBehavior =
                WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        } else {
            // For devices running below Android 11, you can still use the deprecated flag
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
        }
    }*/
}