package com.timestamp.gpsmap.adloaders

import androidx.annotation.NonNull;
import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.timestamp.gpsmap.MyApplication
import com.timestamp.gpsmap.helpers.EventKeys
import com.timestamp.gpsmap.helpers.isOnline


class InterstitialAdLoader(val context: Activity) {

//    private var mAdmobInterstitialAd: InterstitialAd? = null

//    private var isAdLoading = false
    private val TAG = InterstitialAdLoader::class.java.simpleName

    companion object {
        private var instance: InterstitialAdLoader? = null
        private var mAdmobInterstitialAd: InterstitialAd? = null

        fun getInstance(context: Activity): InterstitialAdLoader {
            return instance ?: synchronized(this) {
                instance ?: InterstitialAdLoader(context).also { instance = it }
            }
        }
        private var isAdLoading = false
    }

    fun showFullScreenAds(
        activity: Activity,
        /*isLastAd: Boolean,*/
        listener: AdFinishWithControlListener
    ) {
        if (activity.isOnline) {
            if (mAdmobInterstitialAd != null/*isAdLoaded()*/ /*&& !appPreference.getBooleanData(PreferenceKeys.Admob_IntAd, false)*/) {
                showInterstitialAd(activity, /*isLastAd,*/ listener)
            } else {
                listener.adFinished()
            }
        } else {
            listener.adFinished()
        }
    }

    fun loadFullScreenAds(context: Context) {
        if (context.isOnline && MyApplication.remoteConfig.getBoolean(EventKeys.isInterstitialAdEnable)) {
            if (/*!isAdLoaded()*/mAdmobInterstitialAd == null && !isAdLoading) {
                loadAdmobInt(context)
            }
        }
    }

    private fun isAdLoaded(): Boolean {
        return if (!MyApplication.remoteConfig.getBoolean(EventKeys.isInterstitialAdEnable)) {
            mAdmobInterstitialAd != null
        } else {
            false
        }
    }

    private fun loadAdmobInt(context: Context) {
        if (context.isOnline && mAdmobInterstitialAd == null) {
            isAdLoading = true
            InterstitialAd.load(
                context,
                AdStaticData.getInterstitialAdLoaderId(context),
                AdRequest.Builder().build(),
                object : InterstitialAdLoadCallback() {
                    override fun onAdLoaded(@NonNull interstitialAd: InterstitialAd) {
                        // The mInterstitialAd reference will be null until
                        // an ad is loaded.
                        mAdmobInterstitialAd = interstitialAd
                        isAdLoading = false
                    }

                    override fun onAdFailedToLoad(@NonNull loadAdError: LoadAdError) {
                        mAdmobInterstitialAd = null
                        loadAdmobIntReload(context)
                    }
                })
        }
    }


    interface AdFinishWithControlListener {
        fun adFinished()
    }

    private fun showInterstitialAd(

        activity: Activity,
//        isLastAd: Boolean,
        adFinishWithControlListener: AdFinishWithControlListener
    ) {
        if (/*isAdLoaded()*/mAdmobInterstitialAd != null /*&& !appPreference.getBooleanData(PreferenceKeys.Admob_IntAd, false)*/) {
            mAdmobInterstitialAd!!.fullScreenContentCallback =
                object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
                        MyApplication.isOpenAdHideInterstitial = false
//                        isAnyAdShowing = false
                        mAdmobInterstitialAd = null
//                        appPreference.saveData(PreferenceKeys.IS_OPEN_AD, true)
//                        if (!isLastAd) {
                            loadFullScreenAds(activity)
//                        }
                        adFinishWithControlListener.adFinished()
                    }

                    override fun onAdFailedToShowFullScreenContent(@NonNull adError: AdError) {
                        mAdmobInterstitialAd = null
                        MyApplication.isOpenAdHideInterstitial = false
//                        appPreference.saveData(PreferenceKeys.IS_OPEN_AD, true)
                        adFinishWithControlListener.adFinished()
                    }

                    override fun onAdShowedFullScreenContent() {
                        MyApplication.isOpenAdHideInterstitial = true
//                        appPreference.saveData(PreferenceKeys.IS_OPEN_AD, false)
                    }
                }
//            if (!isAnyAdShowing) {
//                isAnyAdShowing = true
                mAdmobInterstitialAd!!.show(activity)
//            }
        } else {
            adFinishWithControlListener.adFinished()
        }
    }

    private fun loadAdmobIntReload(context: Context) {
        if (context.isOnline && mAdmobInterstitialAd == null) {
            InterstitialAd.load(
                context,
                AdStaticData.getInterstitialAdLoadReloadId(context),
                AdRequest.Builder().build(),
                object : InterstitialAdLoadCallback() {
                    override fun onAdLoaded(@NonNull interstitialAd: InterstitialAd) {
                        // The mInterstitialAd reference will be null until an ad is loaded.
                        mAdmobInterstitialAd = interstitialAd
                        isAdLoading = false
                    }

                    override fun onAdFailedToLoad(@NonNull errorCode: LoadAdError) {
//                        isAnyAdShowing = false
                        mAdmobInterstitialAd = null
                        isAdLoading = false
                    }
                })
        }
    }
}