package com.timestamp.gpsmap.models

import android.graphics.drawable.Drawable

data class LanguageData(var name: String, var languageCode: String, var icon: Drawable?)
