package com.timestamp.gpsmap.activities

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import androidx.recyclerview.widget.GridLayoutManager
import com.timestamp.gpsmap.adapters.ImageGridAdapter
import com.timestamp.gpsmap.adloaders.BannerAds
import com.timestamp.gpsmap.databinding.ActivityGalleryBinding
import com.timestamp.gpsmap.extentions.beGone
import com.timestamp.gpsmap.extentions.beVisible
import com.timestamp.gpsmap.helpers.isOnline
import com.timestamp.gpsmap.listeners.OnImageClick
import java.io.File


class GalleryActivity : BaseActivity(), OnImageClick {
    private lateinit var imageList: MutableList<String>
    private lateinit var binding: ActivityGalleryBinding
    private lateinit var imageGridAdapter: ImageGridAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityGalleryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        hideNavigationBar()

        allClicks()
        loadAdapterData()
//        loadBanner()
    }

    private fun loadAdapterData() {
        imageList = mutableListOf()
        loadImagesFromGallery()

        imageGridAdapter = ImageGridAdapter(imageList, this)
        binding.recyclerView.apply {
            layoutManager = GridLayoutManager(this@GalleryActivity, 2) // Adjust spanCount as needed
            adapter = imageGridAdapter
        }
    }

    private fun loadBanner() {
        if (isOnline) {
            BannerAds().loadAdmobBannerAds(
                this@GalleryActivity,
                binding.flNative, ""
            )
            binding.flNative.beVisible()
        } else {
            binding.flNative.beGone()
        }
    }

    private fun allClicks() {
        binding.ivBack.setOnClickListener {
            finish()
        }
    }

    private fun loadImagesFromGallery() {
        val projection = arrayOf(MediaStore.Images.Media.DATA)
//        val folderPath = "/path/to/gallery/folder" // Replace with your desired folder path
        val root = Environment.getExternalStorageDirectory().toString()
        val folderPath = File("$root/DCIM/GPSCameraImages")
        val cursor = contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            projection,
            MediaStore.Images.Media.DATA + " like ? ",
            arrayOf("%$folderPath%"),
            null
        )

        cursor?.use {
            while (it.moveToNext()) {
                val imagePath = it.getString(it.getColumnIndex(MediaStore.Images.Media.DATA))
                imageList.add(imagePath)
            }
        }
        if(imageList.size != 0) {
            binding.tvNoImage.beGone()
            loadBanner()
        } else {
            binding.tvNoImage.beVisible()
        }

        // Set up ViewPager2 adapter
//        val adapter = ImagePagerAdapter(imageList.sortedDescending())
//        binding.viewPager.adapter = adapter
    }

    override fun onImgClick(position: Int) {
        val intent = Intent(this, ImageShowActivity::class.java).apply {
            putExtra("selectedImage", position)
        }
//        startActivity(intent)
        startActivityForResult(intent, 202)
    }

    override fun onResume() {
        super.onResume()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 202) {
            if (resultCode == RESULT_OK) {
                val result = data!!.getBooleanExtra("isRefreshNeed",false)
                val position = data.getIntExtra("refreshPosition",0)
                if(result) {
                    imageList.removeAt(position)
                    imageGridAdapter.notifyDataSetChanged()
                }
            }
            if (resultCode == RESULT_CANCELED) {
                // Write your code if there's no result
            }
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

}