package com.timestamp.gpsmap.helpers

import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.annotation.Size
import com.timestamp.gpsmap.MyApplication
import org.jetbrains.annotations.NotNull
import java.util.*

import com.timestamp.gpsmap.BuildConfig

object AppUtils {

    /**
     * eventName0 is event name you can add any event name
     * paramName = actionName
     *
     * paramValue = actionValue or actName
     */
    @JvmStatic
    fun logAdapterMessages(context: Context,
        @NotNull @Size(min = 1L, max = 40L) eventName0: String,
        @Size(min = 1L, max = 40L) paramName0: String,
        @Size(min = 1L, max = 40L) actName: String
    ) {
        try {
            val eventName = eventName0.trim().replace(" ", "_").replace(",", "_")
            val paramName = paramName0.trim().replace(" ", "_").replace(",", "_").lowercase()
            val paramValue =
                actName.trim().replace(" ", "_").replace(",", "_").replace("/", "_").lowercase()

            val mBundle = Bundle()
            mBundle.putString(paramName, paramValue)
            if (BuildConfig.DEBUG) {
                //when need events uncomment below code
//                (context as Myapplication).getFirebaseAnalytics().logEvent(eventName, mBundle)
                Log.e("firebaseAnalytics", "$eventName $paramName $paramValue")
            } else {
                (context as MyApplication).getFirebaseAnalytics().logEvent(eventName, mBundle)
            }
        } catch (e: Exception) {
            Log.e("firebaseAnalytics: ", "excep" + e.message.toString())
        }
    }


}
