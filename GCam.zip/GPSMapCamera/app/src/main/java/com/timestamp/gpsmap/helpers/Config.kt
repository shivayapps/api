package com.timestamp.gpsmap.helpers

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.text.format.DateFormat
import android.util.Log
import android.widget.ImageView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.timestamp.gpsmap.R
import com.timestamp.gpsmap.activities.CameraActivity
import com.timestamp.gpsmap.extentions.getSharedPrefs
import com.google.android.gms.maps.GoogleMap
import com.timestamp.gpsmap.MyApplication
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone


class Config(val context: Context) {

    protected val prefs = context.getSharedPrefs()
    companion object {
        fun newInstance(context: Context) = Config(context)
    }

    var setSystemFont: Boolean
        get() = prefs.getBoolean(SET_SYSTEM_FONT, false)
        set(setSystemFont) = prefs.edit().putBoolean(SET_SYSTEM_FONT, setSystemFont).apply()

    var themeSelectedMode: Int
        get() = prefs.getInt(THEME_SELECTED_MODE, 0)
        set(themeSelectedMode) = prefs.edit().putInt(THEME_SELECTED_MODE, themeSelectedMode).apply()

    var introScreenShow: Int
        get() = prefs.getInt(INTRO_SCREEN_SHOW, 0)
        set(introScreenShow) = prefs.edit().putInt(INTRO_SCREEN_SHOW, introScreenShow).apply()

    var languageScreenShow: Int
        get() = prefs.getInt(LANGUAGE_SCREEN_SHOW, 0)
        set(languageScreenShow) = prefs.edit().putInt(LANGUAGE_SCREEN_SHOW, languageScreenShow).apply()

    var lastLatitude: Float
        get() = prefs.getFloat(LAST_LATITUDE, 0f)
        set(lastLatitude) = prefs.edit().putFloat(LAST_LATITUDE, lastLatitude).apply()

    var lastLongitude: Float
        get() = prefs.getFloat(LAST_LONGITUDE, 0f)
        set(lastLongitude) = prefs.edit().putFloat(LAST_LONGITUDE, lastLongitude).apply()

    var getAddress: String
        get() = prefs.getString(LAST_ADDRESS, "")!!
        set(getAddress) = prefs.edit().putString(LAST_ADDRESS, getAddress).apply()

    var getAccuracy: Float
        get() = prefs.getFloat(GET_ACCURACY, 0F)
        set(getAccuracy) = prefs.edit().putFloat(GET_ACCURACY, getAccuracy).apply()

    var getAltitude: Float
        get() = prefs.getFloat(GET_ALTITUDE, 0F)
        set(getAltitude) = prefs.edit().putFloat(GET_ALTITUDE, getAltitude).apply()

    var lastNote: String
        get() = prefs.getString(LAST_NOTE, "GPS MAP Camera")!!
        set(lastNote) = prefs.edit().putString(LAST_NOTE, lastNote).apply()

    var delayPictureClick: Long
        get() = prefs.getLong(DELAY_PICTURE_CLICK, ZERO_SECONDS)!!
        set(delayPictureClick) = prefs.edit().putLong(DELAY_PICTURE_CLICK, delayPictureClick).apply()

    var fontSize: Int
        get() = prefs.getInt(FONT_SIZE, 1)
        set(size) = prefs.edit().putInt(FONT_SIZE, size).apply()

    var stampPosition: Int
        get() = prefs.getInt(STAMP_POSITION, 1)
        set(stampPosition) = prefs.edit().putInt(STAMP_POSITION, stampPosition).apply()

    var weatherType: Int
        get() = prefs.getInt(WEATHER_TYPE, 0)
        set(weatherType) = prefs.edit().putInt(WEATHER_TYPE, weatherType).apply()

    var windType: Int
        get() = prefs.getInt(WIND_TYPE, 2)
        set(windType) = prefs.edit().putInt(WIND_TYPE, windType).apply()

    var pressureType: Int
        get() = prefs.getInt(PRESSURE_TYPE, 0)
        set(pressureType) = prefs.edit().putInt(PRESSURE_TYPE, pressureType).apply()

    var altitudeType: Int
        get() = prefs.getInt(ALTITUDE_TYPE, 0)
        set(altitudeType) = prefs.edit().putInt(ALTITUDE_TYPE, altitudeType).apply()

    var accuracyType: Int
        get() = prefs.getInt(ACCURACY_TYPE, 0)
        set(accuracyType) = prefs.edit().putInt(ACCURACY_TYPE, accuracyType).apply()

    var stampFontStyle: Int
        get() = prefs.getInt(STAMP_FONT_STYLE, 0)
        set(stampFontStyle) = prefs.edit().putInt(STAMP_FONT_STYLE, stampFontStyle).apply()

    var stampColor: Int
        get() = prefs.getInt(STAMP_COLOR, Color.WHITE)
        set(stampColor) = prefs.edit().putInt(STAMP_COLOR, stampColor).apply()

    var stampMapType: Int
        get() = prefs.getInt(STAMP_MAP_TYPE, 1)
        set(stampMapType) = prefs.edit().putInt(STAMP_MAP_TYPE, stampMapType).apply()

    var stampPlusCode: String?
        get() = prefs.getString(STAMP_PLUS_CODE, "")
        set(stampPlusCode) = prefs.edit().putString(STAMP_PLUS_CODE, stampPlusCode).apply()

    var stampLatLongFormat: Int
        get() = prefs.getInt(STAMP_LAT_LONG_FORMAT, 1)
        set(stampLatLongFormat) = prefs.edit().putInt(STAMP_LAT_LONG_FORMAT, stampLatLongFormat).apply()

    var stampDateFormat: Int
        get() = prefs.getInt(STAMP_DATE_FORMAT, 0)
        set(dateFormat) = prefs.edit().putInt(STAMP_DATE_FORMAT, dateFormat).apply()

    var dateFormat: String
        get() = prefs.getString(DATE_FORMAT, getDefaultDateFormat())!!
        set(dateFormat) = prefs.edit().putString(DATE_FORMAT, dateFormat).apply()

    var stampTimezone: Int
        get() = prefs.getInt(STAMP_TIMEZONE, 1)
        set(stampTimezone) = prefs.edit().putInt(STAMP_TIMEZONE, stampTimezone).apply()

    var showMap: Boolean
        get() = prefs.getBoolean(SHOW_MAP, true)
        set(showMap) = prefs.edit().putBoolean(SHOW_MAP, showMap).apply()

    var showAddress: Boolean
        get() = prefs.getBoolean(SHOW_ADDRESS, true)
        set(showAddress) = prefs.edit().putBoolean(SHOW_ADDRESS, showAddress).apply()

    var showLatLong: Boolean
        get() = prefs.getBoolean(SHOW_LAT_LONG, true)
        set(showLatLong) = prefs.edit().putBoolean(SHOW_LAT_LONG, showLatLong).apply()

    var showPlusCode: Boolean
        get() = prefs.getBoolean(SHOW_PLUS_CODE, true)
        set(showPlusCode) = prefs.edit().putBoolean(SHOW_PLUS_CODE, showPlusCode).apply()

    var showDateTime: Boolean
        get() = prefs.getBoolean(SHOW_DATE_TIME, true)
        set(showDateTime) = prefs.edit().putBoolean(SHOW_DATE_TIME, showDateTime).apply()

    var showTimeZone: Boolean
        get() = prefs.getBoolean(SHOW_TIME_ZONE, true)
        set(showTimeZone) = prefs.edit().putBoolean(SHOW_TIME_ZONE, showTimeZone).apply()

    var showLogo: Boolean
        get() = prefs.getBoolean(SHOW_LOGO, true)
        set(showLogo) = prefs.edit().putBoolean(SHOW_LOGO, showLogo).apply()

    var showNote: Boolean
        get() = prefs.getBoolean(SHOW_NOTE, true)
        set(showNote) = prefs.edit().putBoolean(SHOW_NOTE, showNote).apply()

    var showWeather: Boolean
        get() = prefs.getBoolean(SHOW_WEATHER, true)
        set(showWeather) = prefs.edit().putBoolean(SHOW_WEATHER, showWeather).apply()

    var showWind: Boolean
        get() = prefs.getBoolean(SHOW_WIND, true)
        set(showWind) = prefs.edit().putBoolean(SHOW_WIND, showWind).apply()

    var showHumidity: Boolean
        get() = prefs.getBoolean(SHOW_HUMIDITY, true)
        set(showHumidity) = prefs.edit().putBoolean(SHOW_HUMIDITY, showHumidity).apply()

    var showPressure: Boolean
        get() = prefs.getBoolean(SHOW_PRESSURE, true)
        set(showPressure) = prefs.edit().putBoolean(SHOW_PRESSURE, showPressure).apply()

    var showAltitude: Boolean
        get() = prefs.getBoolean(SHOW_ALTITUDE, true)
        set(showAltitude) = prefs.edit().putBoolean(SHOW_ALTITUDE, showAltitude).apply()

    var showAccuracy: Boolean
        get() = prefs.getBoolean(SHOW_ACCURACY, true)
        set(showAccuracy) = prefs.edit().putBoolean(SHOW_ACCURACY, showAccuracy).apply()

    var templateSelected: Int
        get() = prefs.getInt(TEMPLATE_SELECTED, 0)
        set(templateSelected) = prefs.edit().putInt(TEMPLATE_SELECTED, templateSelected).apply()

    var templateSelectedTemporary: Int
        get() = prefs.getInt(TEMPLATE_SELECTED_TEMPORARY, 0)
        set(templateSelectedTemporary) = prefs.edit().putInt(TEMPLATE_SELECTED_TEMPORARY, templateSelectedTemporary).apply()

    var selectLanguage: Int
        get() = prefs.getInt(PREF_KEY_LANGUAGE, 0)
        set(selectLanguage) = prefs.edit().putInt(PREF_KEY_LANGUAGE, selectLanguage).apply()

    var selectLanguageString: String?
        get() = prefs.getString(PREF_KEY_LANGUAGE_STRING, "English")
        set(selectLanguageString) = prefs.edit().putString(PREF_KEY_LANGUAGE_STRING, selectLanguageString).apply()

    var deviceOrientation: Int
        get() = prefs.getInt(DEVICE_ORIENTATION, 0)
        set(deviceOrientation) = prefs.edit().putInt(DEVICE_ORIENTATION, deviceOrientation).apply()

    var cameraGrid: Int
        get() = prefs.getInt(CAMERA_GRID, 0)
        set(cameraGrid) = prefs.edit().putInt(CAMERA_GRID, cameraGrid).apply()

    var cameraRatio: Float
        get() = prefs.getFloat(CAMERA_RATIO, 4f / 3f)
        set(cameraRatio) = prefs.edit().putFloat(CAMERA_RATIO, cameraRatio).apply()

    var cameraWhiteBalance: Int
        get() = prefs.getInt(CAMERA_WHITE_BALANCE, 0)
        set(cameraWhiteBalance) = prefs.edit().putInt(CAMERA_WHITE_BALANCE, cameraWhiteBalance).apply()

    var cameraSceneFilter: Int
        get() = prefs.getInt(CAMERA_SCENE_BALANCE, 0)
        set(cameraSceneFilter) = prefs.edit().putInt(CAMERA_SCENE_BALANCE, cameraSceneFilter).apply()

    var cameraFocus: Int
        get() = prefs.getInt(CAMERA_FOCUS, 0)
        set(cameraFocus) = prefs.edit().putInt(CAMERA_FOCUS, cameraFocus).apply()

    var cameraFlash: Int
        get() = prefs.getInt(CAMERA_FLASH, 0)
        set(cameraFlash) = prefs.edit().putInt(CAMERA_FLASH, cameraFlash).apply()

    var lastImageIcon: String?
        get() = prefs.getString(LAST_IMAGE_ICON, "")
        set(lastImageIcon) = prefs.edit().putString(LAST_IMAGE_ICON, lastImageIcon).apply()

//    var themeSelectedId: Int
//        get() = prefs.getInt(THEME_SELECTED_ID, R.id.radioDefault)
//        set(themeSelectedId) = prefs.edit().putInt(THEME_SELECTED_ID, themeSelectedId).apply()

//    var exportSms: Boolean
//        get() = prefs.getBoolean(EXPORT_SMS, true)
//        set(exportSms) = prefs.edit().putBoolean(EXPORT_SMS, exportSms).apply()
//
//    var keyboardHeight: Int
//        get() = prefs.getInt(SOFT_KEYBOARD_HEIGHT, context.getDefaultKeyboardHeight())
//        set(keyboardHeight) = prefs.edit().putInt(SOFT_KEYBOARD_HEIGHT, keyboardHeight).apply()

    fun rotateImageView(imgView: ImageView) {
        imgView.rotation = deviceOrientation.toFloat()
//        imgView.animate().rotation(180f).start()
    }

    fun roundToSixDecimalPlaces(value: Double): Double {
        Log.w("msg", "roundToSixDecimalPlaces: " + value)
        val decimalFormat = DecimalFormat("#.######") // Define the format with 6 decimal places
        return decimalFormat.format(value).toDouble()
    }

    fun getCurrentDateTimeFormatted(): String {
        val dateFormat = SimpleDateFormat("dd/MM/yyyy h:mm a 'GMT' Z", Locale.getDefault())

        // Set the desired time zone (GMT+5:30 in this case)
        dateFormat.timeZone = TimeZone.getTimeZone("GMT+5:30")

        // Get the current date and time
        val currentDateTime = Date()

        // Format the date and time
        return dateFormat.format(currentDateTime)
    }

    fun formatDateTimeWithColon(): String {
        val sdf = SimpleDateFormat("dd/MM/yyyy hh:mm a 'GMT' Z", Locale.getDefault())

        // Get the time zone offset in hours and minutes
        val timeZone = sdf.format(Date()).split(" ")[4]
        val offsetHours = timeZone.substring(1, 3)
        val offsetMinutes = timeZone.substring(3)

        // Add a colon between hours and minutes in the offset
        val formattedTimeZone = "+" + "$offsetHours:$offsetMinutes"

        // Replace the time zone part in the format
        val formattedDate = sdf.format(Date()).replace(timeZone, formattedTimeZone)

        return formattedDate
    }

    fun getTimezoneFormats(): List<String> {
        val timeZone = TimeZone.getDefault()

        val offsetMillis = timeZone.rawOffset
        val hours = offsetMillis / (60 * 60 * 1000)
        val minutes = (Math.abs(offsetMillis) / (60 * 1000)) % 60
        val sign = if (offsetMillis >= 0) "+" else "-"

        val offsetHoursMinutes = String.format("%02d:%02d", hours, minutes)

        return listOf(
            "$sign${String.format("%02d%02d", hours, minutes)}", // +0530
            "UTC $sign${String.format("%02d%02d", hours, minutes)}", // UTC +0530
            "GMT $sign${String.format("%02d%02d", hours, minutes)}", // GMT +0530
            "$sign$offsetHoursMinutes", // +05:30
            "UTC $sign$offsetHoursMinutes", // UTC +05:30
            "GMT $sign$offsetHoursMinutes" // GMT +05:30
        )
    }
    fun celsiusToFahrenheit(celsius: String): String {
        return (celsius.toDouble() * (9.0 / 5.0) + 32).toString()
    }

    fun getWeatherFormats(): List<String> {
        return listOf(
            CameraActivity.tempWeather + " °C",
            celsiusToFahrenheit(CameraActivity.tempWeather) + " °F"
        )
    }

    fun getWindFormats(): List<String> {
        return listOf(
            msToKmh(CameraActivity.tempWind) + " km/h",
            msToMph(CameraActivity.tempWind) + " mph",
            CameraActivity.tempWind + " m/s",
            msToKnots(CameraActivity.tempWind) + " kt"
        )
    }

    fun msToKmh(ms: String): String {
        return String.format("%.2f", (ms.toDouble() * 3.6))
    }
    fun msToMph(ms: String): String {
        return String.format("%.2f", (ms.toDouble() * 2.23694))
    }
    fun msToKnots(ms: String): String {
        return String.format("%.2f", (ms.toDouble() * 1.94384))
    }

    fun getPressureFormats(): List<String> {
        return listOf(
            CameraActivity.tempPressure + " hpa",
            hPaToMmHg(CameraActivity.tempPressure) + " mmhg",
            hPaToInHg(CameraActivity.tempPressure) + " inHg"
        )
    }

    fun hPaToMmHg(hPa: String): String {
        return String.format("%.2f", (hPa.toDouble() * 0.75006375541921))
    }
    fun hPaToInHg(hPa: String): String {
        return String.format("%.2f", (hPa.toDouble() * 0.029529983071445))
    }

    fun getAltitudeFormats(): List<String> {
        return listOf(
            String.format("%.2f", CameraActivity.tempAltitude) + " m",
            String.format("%.2f", metersToFeet(CameraActivity.tempAltitude)) + " ft",
        )
    }

    fun getAccuracyFormats(): List<String> {
        return listOf(
            String.format("%.2f", CameraActivity.tempAccuracy) + " m",
            String.format("%.2f", metersToFeet(CameraActivity.tempAccuracy.toDouble())) + " ft",
        )
    }

    fun metersToFeet(meters: Double): Double {
        return meters * 3.28084
    }

    fun getCurrentDateFormatted(): String {
        val currentDate = Date()

        // Define the desired date format
        val dateFormat = SimpleDateFormat("d, MMM, yyyy", Locale.getDefault())

        // Format the current date
        return dateFormat.format(currentDate)
    }

    fun getPictureDelayText(context: Context) = context.getString(
        when (delayPictureClick) {
            THREE_SECONDS -> R.string.timer_3sec
            FIVE_SECONDS -> R.string.timer_5sec
            else -> R.string.timer_off
        }
    )

    fun openWebsiteIntent(context: Context, url: String) {
        MyApplication().openAdHide()
        val website = if (url.startsWith("http")) {
            url
        } else {
            "https://$url"
        }

        Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse(website)
            try {
                context.startActivity(this)
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(context, R.string.no_app_found, Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
            }
        }
    }

    fun launchShare(activity: Activity, packageName: String) {
        val sendIntent = Intent()
        sendIntent.action = Intent.ACTION_SEND
        sendIntent.putExtra(
            Intent.EXTRA_TEXT,
            "Check out the App at: https://play.google.com/store/apps/details?id=$packageName"
        )
        sendIntent.type = "text/plain"
        activity.startActivity(sendIntent)
    }

    fun launchRate(activity: Activity, packageName: String) {
        Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${packageName}")).apply {
            try {
                activity.startActivity(this)
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(activity, R.string.no_app_found, Toast.LENGTH_SHORT)
                    .show()
            } catch (e: Exception) {
            }
        }
    }

    fun getTextSize(context: Context) = when (fontSize) {
        FONT_SIZE_SMALL -> context.resources.getDimension(R.dimen.small_text_size)
        FONT_SIZE_MEDIUM -> context.resources.getDimension(R.dimen.smaller_text_size)
        FONT_SIZE_LARGE -> context.resources.getDimension(R.dimen.normal_text_size)
        else -> context.resources.getDimension(R.dimen.tiny_text_size)
    }

    fun getWeatherText(context: Context) = when (weatherType) {
//        WEATHER_FORMAT_CELSIUS -> "celsius"
//        else -> "fahrenheit"
        WEATHER_FORMAT_CELSIUS -> CameraActivity.tempWeather + " °C"
        else -> celsiusToFahrenheit(CameraActivity.tempWeather) + " °F"
    }

    fun getWindText(context: Context) = when (windType) {
        WIND_FORMAT_KMH -> msToKmh(CameraActivity.tempWind) + " km/h"
        WIND_FORMAT_MPH -> msToMph(CameraActivity.tempWind) + " mph"
        WIND_FORMAT_MS -> CameraActivity.tempWind + " m/s"
        else -> msToKnots(CameraActivity.tempWind) + " kt"
    }

    fun getPressureText(context: Context) = when (pressureType) {
        PRESSURE_FORMAT_HPA -> CameraActivity.tempPressure + " hpa"
        PRESSURE_FORMAT_MMHG -> hPaToMmHg(CameraActivity.tempPressure) + " mmhg"
        else -> hPaToInHg(CameraActivity.tempPressure) + " inHg"
    }

    fun getAltitudeText(context: Context) = when (altitudeType) {
        ALTITUDE_FORMAT_METER -> String.format("%.2f", CameraActivity.tempAltitude) + " m"
        else -> String.format("%.2f", metersToFeet(CameraActivity.tempAltitude)) + " ft"
    }

    fun getAccuracyText(context: Context) = when (accuracyType) {
        ACCURACY_FORMAT_METER -> String.format("%.2f", CameraActivity.tempAccuracy) + " m"
        else -> String.format("%.2f", metersToFeet(CameraActivity.tempAccuracy.toDouble())) + " ft"
    }

    fun getFontSizeText(context: Context) = context.getString(
        when (fontSize) {
            FONT_SIZE_SMALL -> R.string.small
            FONT_SIZE_MEDIUM -> R.string.medium
            FONT_SIZE_LARGE -> R.string.large
            else -> R.string.extra_small
        }
    )

    fun getStampPositionText(context: Context) = context.getString(
        when (stampPosition) {
            STAMP_TOP -> R.string.top
            else -> R.string.bottom
        }
    )

    fun getStampFontText(context: Context) = context.getString(
        when (stampFontStyle) {
            FONT_HIND-> R.string.hind
            FONT_INTER -> R.string.inter
            FONT_ROBOTO -> R.string.roboto
            FONT_SF -> R.string.sf_ui_text
            else -> R.string.poppins
        }
    )

    /*fun getMapTypeText(context: Context) = context.getString(
        when (stampMapType) {
            MAP_NORMAL -> R.string.normal
            MAP_SATELLITE -> R.string.satellite
            MAP_TERRAIN -> R.string.terrain
            else -> R.string.hybrid
        }
    )*/
    fun getMapTypeIcon(context: Context) = context.getDrawable(
        when (stampMapType) {
            MAP_NORMAL -> R.drawable.ic_map_normal_icon
            MAP_SATELLITE -> R.drawable.ic_map_satellite_icon
            MAP_TERRAIN -> R.drawable.ic_map_terrain_icon
            else -> R.drawable.ic_map_hybrid_icon
        }
    )

    fun getMapTypeImage(context: Context) = context.getDrawable(
        when (stampMapType) {
            MAP_NORMAL -> R.drawable.ic_map_normal
            MAP_SATELLITE -> R.drawable.ic_map_satellite
            MAP_TERRAIN -> R.drawable.ic_map_terrain
            else -> R.drawable.ic_map_hybrid
        }
    )

    fun getMapType(context: Context) = when (stampMapType) {
        MAP_NORMAL -> GoogleMap.MAP_TYPE_NORMAL
        MAP_SATELLITE -> GoogleMap.MAP_TYPE_SATELLITE
        MAP_TERRAIN -> GoogleMap.MAP_TYPE_TERRAIN
        else -> GoogleMap.MAP_TYPE_HYBRID
    }

    fun getLatLongText(context: Context) = context.getString(
        when (stampLatLongFormat) {
            LATLONG_DECIMAL -> R.string.decimal
            LATLONG_DEGREE -> R.string.decimal_degree
            LATLONG_DEGREE_MICRO -> R.string.decimal_degree_micro
            LATLONG_DECIMAL_MINUTES -> R.string.decimal_minutes
            LATLONG_DEGREE_MINUTES_SECONDS -> R.string.degree_minutes_seconds
            else -> R.string.decimal_minutes_seconds
        }
    )

    /*fun getDateTimeText(context: Context) = context.getString(
        when (stampDateFormat) {
            DATE_FORMAT_ONE_CONST -> formatDateSample(DATE_FORMAT_ONE)
            DATE_FORMAT_TWO_CONST -> formatDateSample(DATE_FORMAT_TWO)
            DATE_FORMAT_THREE_CONST -> formatDateSample(DATE_FORMAT_THREE)
            DATE_FORMAT_FOUR_CONST -> formatDateSample(DATE_FORMAT_FOUR)
            DATE_FORMAT_FIVE_CONST -> formatDateSample(DATE_FORMAT_FIVE)
            DATE_FORMAT_SIX_CONST -> formatDateSample(DATE_FORMAT_SIX)
            DATE_FORMAT_SEVEN_CONST -> formatDateSample(DATE_FORMAT_SEVEN)
            else -> formatDateSample(DATE_FORMAT_EIGHT)
        }
    )*/

    private fun formatDateSample(format: String): String {
        val cal = Calendar.getInstance(Locale.ENGLISH)
        cal.timeInMillis = System.currentTimeMillis()
        return DateFormat.format(format, cal).toString()
    }

    private fun getDefaultDateFormat(): String {
        return when (stampDateFormat) {
            DATE_FORMAT_ONE_CONST -> {
                formatDateSample(DATE_FORMAT_ONE)
            }
            DATE_FORMAT_TWO_CONST -> {
                formatDateSample(DATE_FORMAT_TWO)
            }
            DATE_FORMAT_THREE_CONST -> {
                formatDateSample(DATE_FORMAT_THREE)
            }
            DATE_FORMAT_FOUR_CONST -> {
                formatDateSample(DATE_FORMAT_FOUR)
            }
            DATE_FORMAT_FIVE_CONST -> {
                formatDateSample(DATE_FORMAT_FIVE)
            }
            DATE_FORMAT_SIX_CONST -> {
                formatDateSample(DATE_FORMAT_SIX)
            }
            DATE_FORMAT_SEVEN_CONST -> {
                formatDateSample(DATE_FORMAT_SEVEN)
            }
            DATE_FORMAT_EIGHT_CONST -> {
                formatDateSample(DATE_FORMAT_EIGHT)
            }
            DATE_FORMAT_NINE_CONST -> {
                formatDateSample(DATE_FORMAT_NINE)
            }
            else -> {
                formatDateSample(DATE_FORMAT_TEN)
            }
        }
    }
//    val timezoneFormats = getTimezoneFormats()
    /*fun getTimezoneText(context: Context) = context.getString(
        when (stampTimezone) {
            TIMEZONE_FORMAT_ONE -> getTimezoneFormats()[0].toInt()
            TIMEZONE_FORMAT_TWO -> getTimezoneFormats()[1].toInt()
            TIMEZONE_FORMAT_THREE -> getTimezoneFormats()[2].toInt()
            TIMEZONE_FORMAT_FOUR -> getTimezoneFormats()[3].toInt()
            TIMEZONE_FORMAT_FIVE -> getTimezoneFormats()[4].toInt()
            else -> getTimezoneFormats()[5].toInt()
        }
    )*/

    fun getTimezoneText(): String {
        return when (stampTimezone) {
            TIMEZONE_FORMAT_ONE -> {
                getTimezoneFormats()[0]
            }
            TIMEZONE_FORMAT_TWO -> {
                getTimezoneFormats()[1]
            }
            TIMEZONE_FORMAT_THREE -> {
                getTimezoneFormats()[2]
            }
            TIMEZONE_FORMAT_FOUR -> {
                getTimezoneFormats()[3]
            }
            TIMEZONE_FORMAT_FIVE -> {
                getTimezoneFormats()[4]
            }
            else -> {
                getTimezoneFormats()[5]
            }
        }
    }

        /*when (stampTimezone) {
            TIMEZONE_FORMAT_ONE -> getTimezoneFormats()[0]
            TIMEZONE_FORMAT_TWO -> getTimezoneFormats()[1]
            TIMEZONE_FORMAT_THREE -> getTimezoneFormats()[2]
            TIMEZONE_FORMAT_FOUR -> getTimezoneFormats()[3]
            TIMEZONE_FORMAT_FIVE -> getTimezoneFormats()[4]
            else -> getTimezoneFormats()[5]
        }*/


    fun decimalFormat(latitude: Double, longitude: Double): String {
        val latD = String.format("%.6f", latitude)
        val lonD = String.format("%.6f", longitude)
        return "Lat $latD Long $lonD"
    }

    fun decimalToDegreeFormat(latitude: Double, longitude: Double): String {
        val latD = String.format("%.6f", latitude)
        val lonD = String.format("%.6f", longitude)

        return "Lat $latD° Long $lonD°"
    }

    fun decimalToDegreeMicroFormat(latitude: Double, longitude: Double): String {
        val latDirection = if (latitude >= 0) "N" else "S"
        val lonDirection = if (longitude >= 0) "E" else "W"

        val latD = String.format("%.6f", Math.abs(latitude))
        val lonD = String.format("%.6f", Math.abs(longitude))

        return "Lat $latD $latDirection Long $lonD $lonDirection"
    }

    fun decimalToDegreeMinuteFormat(latitude: Double, longitude: Double): String {

        val latD = latitude.toInt()
        val latM = (Math.abs(latitude) - latD) * 60.0

        val lonD = longitude.toInt()
        val lonM = (Math.abs(longitude) - lonD) * 60.0

        return "Lat ${"%02d%.5f".format(latD, latM)} Long ${"%03d%.5f".format(lonD, lonM)}"
    }

    fun decimalToMinuteSecondFormat(latitude: Double, longitude: Double): String {
        val latDirection = if (latitude >= 0) "N" else "S"
        val lonDirection = if (longitude >= 0) "E" else "W"

        val latD = latitude.toInt()
        val latM = ((Math.abs(latitude) - latD) * 60.0).toInt()
        val latS = ((Math.abs(latitude) - latD - (latM.toDouble() / 60.0)) * 3600.0)

        val lonD = longitude.toInt()
        val lonM = ((Math.abs(longitude) - lonD) * 60.0).toInt()
        val lonS = ((Math.abs(longitude) - lonD - (lonM.toDouble() / 60.0)) * 3600.0)

        return "Lat ${"%02d%02d%.4f".format(latD, latM, latS)} $latDirection Long ${"%03d%02d%.4f".format(lonD, lonM, lonS)} $lonDirection"
    }

    fun decimalToDegreeMinuteSecondFormat(latitude: Double, longitude: Double): String {
        val latDirection = if (latitude >= 0) "N" else "S"
        val lonDirection = if (longitude >= 0) "E" else "W"

        val latD = latitude.toInt()
        val latM = ((Math.abs(latitude) - latD) * 60.0).toInt()
        val latS = ((Math.abs(latitude) - latD - (latM.toDouble() / 60.0)) * 3600.0).toFloat()

        val lonD = longitude.toInt()
        val lonM = ((Math.abs(longitude) - lonD) * 60.0).toInt()
        val lonS = ((Math.abs(longitude) - lonD - (lonM.toDouble() / 60.0)) * 3600.0).toFloat()

        return "Lat $latDirection $latD° $latM' %.4f'' Long $lonDirection $lonD° $lonM' %.4f''".format(latS, lonS)
    }

    /*fun decimalToUTM(latitude: Double, longitude: Double): String {
        // Create a GlobalCoordinates object with your latitude and longitude
        val globalCoordinates = GlobalCoordinates(latitude, longitude)

        // Create a GeodeticCalculator with the WGS84 ellipsoid
        val geodeticCalculator = GeodeticCalculator(Ellipsoid.WGS84)

        // Calculate the UTM reference
        val utmRef = geodeticCalculator.calculateUTMRef(globalCoordinates)

        // Format the UTM reference as a string
        return "${utmRef.zone}${utmRef.band} ${utmRef.easting} E ${utmRef.northing} N"
    }*/

    fun formatLatLong(tempLatitude: Double, tempLongitude: Double): String {
        return when (stampLatLongFormat) {
            LATLONG_DECIMAL -> decimalFormat(tempLatitude, tempLongitude)
            LATLONG_DEGREE -> decimalToDegreeFormat(tempLatitude, tempLongitude)
            LATLONG_DEGREE_MICRO -> decimalToDegreeMicroFormat(tempLatitude, tempLongitude)
            LATLONG_DECIMAL_MINUTES -> decimalToDegreeMinuteFormat(tempLatitude, tempLongitude)
            LATLONG_DEGREE_MINUTES_SECONDS -> decimalToMinuteSecondFormat(tempLatitude, tempLongitude)
            LATLONG_DECIMAL_MINUTES_SECONDS -> decimalToDegreeMinuteSecondFormat(tempLatitude, tempLongitude)
            else -> "" // Handle the case where an unsupported format is selected
        }
    }

    fun rateApp(activity: Activity) {
        MyApplication().openAdHide()
        val uri = Uri.parse("market://details?id=" + context.packageName)
        val myAppLinkToMarket = Intent(Intent.ACTION_VIEW, uri)
        try {
            activity.startActivity(myAppLinkToMarket)
        } catch (e: ActivityNotFoundException) {
            Log.e("rateApp: ", e.message.toString())
        }
    }

    fun sendMail(activity: Activity, mailId: String) {
        MyApplication().openAdHide()
        val i = Intent(Intent.ACTION_SEND)

        i.type = "message/rfc822"
        i.putExtra(Intent.EXTRA_EMAIL, arrayOf(mailId))
        i.putExtra(
            Intent.EXTRA_SUBJECT,
            "${activity.getString(R.string.app_name)} ${activity.getString(R.string.feedback)}"
        )
        i.putExtra(Intent.EXTRA_TEXT, "")
        i.setPackage("com.google.android.gm")
        try {
//            MyApplication.isOpenAdHide = true
            activity.startActivity(Intent.createChooser(i, activity.getString(R.string.send_mail)))
            MyApplication.isAppIsRunning = false
            activity.finishAffinity()
        } catch (ex: ActivityNotFoundException) {
            Toast.makeText(activity, activity.getString(R.string.no_app_found), Toast.LENGTH_SHORT).show()
        }
    }

    fun checkAllPermissions(context: Context): Boolean {
        if (ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            return true
        }
        return false
    }
}
