## Version:1.0.0[30-11-2023]
```
- Whole app with all basic feature
```