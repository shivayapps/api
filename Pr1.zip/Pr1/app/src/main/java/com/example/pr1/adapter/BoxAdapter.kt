package com.example.pr1.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.example.pr1.R
import com.example.pr1.model.Box

class BoxAdapter(var listModel: ArrayList<Box>) : RecyclerView.Adapter<BoxAdapter.ViewHolder>() {

    var selectedBox: Box? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BoxAdapter.ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_view, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: BoxAdapter.ViewHolder, position: Int) {
        val data = listModel[position]

        if (selectedBox != null) {
            if (data == selectedBox
                || (data.col == selectedBox?.col!! - 1 && data.row == selectedBox?.row!!)
                || (data.row == selectedBox?.row!! - 1 && data.col == selectedBox?.col!!)
                || (data.col == selectedBox?.col!! + 1 && data.row == selectedBox?.row!!)
                || (data.row == selectedBox?.row!! + 1 && data.col == selectedBox?.col!!)
                ) {
                holder.clBox.setBackgroundColor(Color.YELLOW)
            } else {
                holder.clBox.setBackgroundColor(Color.GRAY)
            }
        } else {
            holder.clBox.setBackgroundColor(Color.GRAY)
        }

//        holder.tvVal.setText("${data.col}*${data.row}")
        holder.clBox.setOnClickListener {
            selectedBox = listModel[position]
            notifyDataSetChanged()
        }
    }

    override fun getItemCount(): Int {
        return listModel.size
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val clBox = itemView.findViewById<ConstraintLayout>(R.id.clBox)
        val tvVal = itemView.findViewById<TextView>(R.id.tvVal)
    }


}
