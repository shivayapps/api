package com.example.pr1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Display.Mode
import android.widget.Button
import android.widget.EditText
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.pr1.adapter.BoxAdapter
import com.example.pr1.model.Box

class MainActivity : AppCompatActivity() {

    var num = 0
    var listModel: ArrayList<Box>? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etVal = findViewById<EditText>(R.id.etVal)
        val btnSubmit = findViewById<Button>(R.id.btnSubmit)
        val rvData = findViewById<RecyclerView>(R.id.rvData)

        btnSubmit.setOnClickListener {
            if (!etVal.text.toString().isNullOrEmpty()) {
                num = etVal.text.toString().toInt()
                listModel = arrayListOf()
                for (i in 1..num) {
                    for (j in 1..num) {
                        listModel?.add(Box(i, j))
                    }
                }

                rvData.layoutManager=GridLayoutManager(this@MainActivity,num)
                rvData.adapter=BoxAdapter(listModel!!)

            }


        }

    }
}