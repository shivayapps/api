package com.example.pr1.model

data class Box(val col:Int,val row:Int)
