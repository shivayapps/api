package com.domain.interactor

import io.reactivex.Flowable
import com.domain.manager.NotificationManager
import com.domain.repository.MessageRepository
import javax.inject.Inject

class MarkRead @Inject constructor(
    private val messageRepo: MessageRepository,
    private val notificationManager: NotificationManager,
    private val updateBadge: UpdateBadge
) : Interactor<List<Long>>() {

    override fun buildObservable(params: List<Long>): Flowable<*> {
        val flow = Flowable.just(params.toLongArray())
            .doOnNext { threadIds -> messageRepo.markRead(*threadIds) }
            .doOnNext { threadIds -> threadIds.forEach(notificationManager::update) }
            .flatMap { updateBadge.buildObservable(Unit) } // Update the badge

        return flow
    }

}