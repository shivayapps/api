package com.domain.interactor

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import io.reactivex.Flowable
import com.domain.extensions.mapNotNull
import com.domain.interactor.Interactor
import com.domain.repository.ScheduledMessageRepository
import javax.inject.Inject

class ScheduleMessageCopy @Inject constructor(
    private val context: Context,
    private val scheduledMessageRepo: ScheduledMessageRepository
) : Interactor<Long>() {

    override fun buildObservable(params: Long): Flowable<*> {
        return Flowable.just(params)
            .mapNotNull(scheduledMessageRepo::getScheduledMessage)
            .doOnNext {
                scheduledMessageRepo.getScheduledMessage(params)?.let {
                    copy(context, it.body)
                }
            }
    }

    private fun copy(context: Context, string: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("SMS", string)
        clipboard.setPrimaryClip(clip)
    }
}