package com.messenger.sms.text.common.base

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.messenger.sms.text.R
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.Subject
import com.messenger.sms.text.common.util.extensions.LogW
import com.messenger.sms.text.common.widget.MessagesTextView

abstract class MessagesActivity : AppCompatActivity() {

    protected val menu: Subject<Menu> = BehaviorSubject.create()
    val toolbar by lazy { findViewById<Toolbar?>(R.id.toolbar) }

    @SuppressLint("InlinedApi")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        LogW("messageApp : ", "MessagesActivity Oncreat Call-------")
        onNewIntent(intent)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }

//    override fun setContentView(rootView: View) {
//        super.setContentView(rootView)
//        setSupportActionBar(findViewById(R.id.toolbar))
////        setSupportActionBar(binding.toolbar)
////        title = title
//    }

    override fun setContentView(layoutResID: Int) {
        super.setContentView(layoutResID)
        setSupportActionBar(findViewById(R.id.toolbar))
//        setSupportActionBar(binding.toolbar)
//        title = title
    }

    override fun setTitle(titleId: Int) {
//        title = getString(titleId)
        findViewById<MessagesTextView>(R.id.toolbarTitle)?.text = getString(titleId)
    }

    override fun setTitle(title: CharSequence?) {
        super.setTitle(title)
        findViewById<MessagesTextView>(R.id.toolbarTitle)?.text = title
//        binding.toolbarTitle.text = title ?: ""
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val result = super.onCreateOptionsMenu(menu)
        if (menu != null) {
            this.menu.onNext(menu)
        }
        return result
    }

    protected open fun showBackButton(show: Boolean) {
        supportActionBar?.setDisplayHomeAsUpEnabled(show)
    }

}