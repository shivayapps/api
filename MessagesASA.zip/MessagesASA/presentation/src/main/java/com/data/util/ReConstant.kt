package com.data.util

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import java.util.*
import java.util.regex.Matcher
import java.util.regex.Pattern

object ReConstant {
    val otp_regex = "(((?i)OTP)|((?i)One Time Password)|((?i)verification code)|((?i)Do not share)|((?i)Don't share it)|((?i)access code)).*(\\b\\d{4}\\b|\\b\\d{5}\\b|\\b\\d{6}\\b|\\b\\d{3}(-| )\\d{3}\\b)|(\\b\\d{4}\\b|\\b\\d{5}\\b|\\b\\d{6}\\b|\\b\\d{3}(-| )\\d{3}\\b).*(((?i)OTP)|((?i)One Time Password)|((?i)verification code)|((?i)Do not share)|((?i)Don't share it)|((?i)access code))"
    val transaction_regex = "^((?!.*(?i)Prize)(?!.*(?i)Bonus)(?!.*(?i)applying)(?!.*(?i)free credit)(?!.*(?i)eligible)(?!.*(?i)Insurance)(?!.*(?i)Pre-Qualified)(?!.*(?i)verification)(?!.*(?i)easier)(?!.*(?i)instant)(?!.*(?i)Pre-approved)(?!.*(?i)Hurry)(?!.*(?i)Business)(?!.*(?i)Sale)(?!.*(?i)Redeem)(?!.*(?i)inconvenience)(?!.*(?i)REWARD)(?!.*(?i)benefit)(?!.*(?i)insufficient)(?!.*(?i)pay later)(?!.*(?i)Mutual Fund)(?!.*(?i)requested)(?!.*(?i)benefits)(?!.*(?i)save upto)(?!.*(?i)rummy)).*((((?i)A\\/C No.)|((?i)Acct)|((?i)Acc)|((?i)Bank Account)|((?i)Account No.)|((?i)A\\/c)|((?i)Paytm Ref)|((?i)Account)|((?i)Credit Card)|((?i)Bank)|((?i)payment)|((?i)NEFT Txn)|(\\b(?i)Ac\\b)).*(((?i)credited)|((?i)transaction of)|((?i)debited)|((?i)spent)|((?i)received)|((?i)cr)|((?i)dr)|((?i)deposited)|((?i)sent)|((?i)transferred))|(((?i)credited)|((?i)transaction of)|((?i)debited)|((?i)spent)|((?i)received)|((?i)cr)|((?i)dr)|((?i)deposited)|((?i)sent)|((?i)transferred)).*(((?i)A\\/C No.)|((?i)Acct)|((?i)Acc)|((?i)Bank Account)|((?i)Account No.)|((?i)A\\/c)|((?i)Paytm Ref)|((?i)Account)|((?i)Credit Card)|((?i)Bank)|((?i)payment)|((?i)NEFT Txn)|(\\b(?i)Ac\\b)))"
    val promotion_regex = "[a-zA-Z0-9]{2}-[a-zA-Z0-9]{6}"
    val amount_regex = "(?i)(?:(?:RS|INR|MRP|USD|\\\$|£|€|₹)\\.?\\s?)(\\d+(:?\\,\\d+)?(\\,\\d+)?(\\.\\d{1,2})?)"
    val account_regex = "((?i)A\\/C No.|(?i)Acct|(?i)Acc|(?i)Bank Account|(?i)Account No.|(?i)Bank A\\/c|(?i)A\\/c|(?i)Paytm Ref:|(?i)Account|(\\b(?i)Ac\\b)|(?i)Card ending|(?i)ending with|(?i)Credit Card|(?i)TXN|(?i)Bank|(?i)Ref. No|(?i)Ref No|(?i)reference number|(?i)Ref Num.|(?i)Card no.|(?i)Bank Card|(?i)Folio).([0-9]|\\.|(?i)x*.[0-9]|\\**.[0-9]|[A-Z]*.[0-9])"
    val credit_regex = "((?i)Credit|(?i)Cr|(?i)received|(?i)deposited)"
    val debit_regex = "((?i)Debit|(?i)Dr|(?i)paid|(?i)Sent|(?i)transferred|(?i)spent|(?i)transaction of|(?i)Payment of)"

    fun copy(context: Context, string: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("SMS", string)
        clipboard.setPrimaryClip(clip)
    }

    fun parseCode(msg: String): String {
        val message = msg.replace("\n", " ").trim().lowercase(Locale.getDefault())
        if (message.contains("otp") || message.contains(
                "one time password"
            ) || message.contains(
                "do not share"
            ) || message.contains(
                "don't share it"
            ) || message.contains(
                "verification code"
            ) || message.contains(
                "access code"
            )
        ) {
            val p: Pattern = Pattern.compile("\\b\\d{6}\\b")
            val m: Matcher = p.matcher(message)
            var code = ""
            while (m.find()) {
                code = m.group(0)
            }
            return if (code.length == 6) code
            else {
                val p1: Pattern = Pattern.compile("\\b\\d{4}\\b")
                val m1: Matcher = p1.matcher(message)
                var code1 = ""
                while (m1.find()) {
                    code1 = m1.group(0)
                }
                if (code1.length == 4) code1 else {
                    val p2: Pattern = Pattern.compile("\\b\\d{5}\\b")
                    val m2: Matcher = p2.matcher(message)
                    var code2 = ""
                    while (m2.find()) {
                        code2 = m2.group(0)
                    }
                    if (code2.length == 5) code2 else {
                        val p3: Pattern = Pattern.compile("\\b\\d{3}(-| )\\d{3}\\b")
                        val m3: Matcher = p3.matcher(message)
                        var code3 = ""
                        while (m3.find()) {
                            code3 = m3.group(0).replace("-", "").replace(" ", "")
                        }
                        if (code3.length == 6) {
                            return code3
                        } else ""
                    }
                }
            }
        } else return ""
    }
}