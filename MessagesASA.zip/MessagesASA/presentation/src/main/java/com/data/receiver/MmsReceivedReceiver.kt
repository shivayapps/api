package com.data.receiver

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.klinker.android.send_message.MmsReceivedReceiver
import dagger.android.AndroidInjection
import com.domain.interactor.ReceiveMms
import javax.inject.Inject

class MmsReceivedReceiver : MmsReceivedReceiver() {

    @Inject
    lateinit var receiveMms: ReceiveMms

    override fun onReceive(context: Context?, intent: Intent?) {
        AndroidInjection.inject(this, context)
        super.onReceive(context, intent)
    }

    override fun onMessageReceived(messageUri: Uri?) {
        messageUri?.let { uri ->
            val pendingResult = goAsync()
            receiveMms.execute(uri) {
                try {
                    pendingResult.finish()
                } catch (e: IllegalStateException) {
                    com.data.extensions.LogE(
                        "IllegalStateException: ",
                        e.message.toString()
                    )
                    e.printStackTrace()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }
}
