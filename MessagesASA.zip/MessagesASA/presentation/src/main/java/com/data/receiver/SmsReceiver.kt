package com.data.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import dagger.android.AndroidInjection
import com.domain.interactor.ReceiveSms
import timber.log.Timber
import javax.inject.Inject

class SmsReceiver : BroadcastReceiver() {

    @Inject
    lateinit var receiveMessage: ReceiveSms

    override fun onReceive(context: Context, intent: Intent) {
        AndroidInjection.inject(this, context)
        Timber.v("onReceive")
        Telephony.Sms.Intents.getMessagesFromIntent(intent)?.let { messages ->

            val thre = Thread {
                val subId = intent.extras?.getInt("subscription", -1) ?: -1
                receiveMessage.execute(ReceiveSms.Params(subId, messages)) {}
            }
            thre.start()
        }
    }
}