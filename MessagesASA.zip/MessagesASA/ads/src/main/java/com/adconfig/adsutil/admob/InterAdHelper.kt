package com.adconfig.adsutil.admob

import android.app.Activity
import android.app.Application
import android.util.Log
import android.view.View
import com.adconfig.adsutil.Config
import com.adconfig.adsutil.abstract.IntersAd
import com.adconfig.adsutil.utils.AdsError
import com.adconfig.adsutil.utils.AdsListener
import com.adconfig.adsutil.utils.isAnyAdShowing
import com.google.android.gms.ads.RequestConfiguration
import java.util.Date
import kotlin.contracts.ExperimentalContracts
import kotlin.contracts.contract

object InterAdHelper {

    private val intersAd: IntersAd = AdmobIntersAdImpl()
    fun showInterstitialAd(
        activity: Activity,
        onAdClosed: (isLoaded: Boolean) -> Unit = {}
    ) {

        if(Config.enableAds) {
            intersAd.adListener(object : AdsListener {
                override fun onAdClicked() {
                    Log.i("ADCONFIG_InterAd", "onAdClicked")
                }

                override fun onAdDismissed() {
                    Log.i("ADCONFIG_InterAd", "onAdDismissed")
//                    super.onAdDismissed()
                    isAnyAdShowing = false
                    Log.i("isAnyAdShowing", "isAnyAdShowing.007:$isAnyAdShowing")
                    intersAd.destroy()
//                        intersAd.load(activity)
                    onAdClosed.invoke(true)
                }

                override fun onAdLoaded(appOpenAd: Any) {
                    Log.i("ADCONFIG_InterAd", "onAdLoaded.appOpenAd")
                }

                override fun onAdLoaded() {
                    Log.i("ADCONFIG_InterAd", "onAdLoaded")
                }

                override fun onAdFailedToShow(adsError: AdsError) {
                    isAnyAdShowing = false
                    Log.i("isAnyAdShowing", "isAnyAdShowing.008:$isAnyAdShowing")
                    Log.i(
                        "ADCONFIG_InterAd",
                        "onAdFailedToShow:${adsError.code}:${adsError.error}"
                    )
//                    super.onAdFailedToShow(p0)
                    onAdClosed.invoke(false)
                }

                override fun onAdImpression() {
//                        intersAd.destroy()
//                        intersAd.load(activity)
//                        onAdClosed.invoke()
                    Log.i("ADCONFIG_InterAd", "onAdImpression")
                }

                override fun onAdShowed() {
                    Log.i("ADCONFIG_InterAd", "onAdShowed")
                }
            })
            Log.i("isAnyAdShowing", "isAnyAdShowing:$isAnyAdShowing")
//            intersAd.load(activity)
//                if (!isAdsShowOrNot && clickCounter % Config.admobInterClick == 0) {
            try {
                if (!isAnyAdShowing && Config.mInterstitialAd != null) {
                    isAnyAdShowing = true
                    intersAd.show(activity)
                    Log.i("isAnyAdShowing", "isAnyAdShowing.012:$isAnyAdShowing")
                } else {
                    onAdClosed.invoke(false)
                }
            } catch (e: Exception) {
                Log.i("ADCONFIG_InterAd", "Exception:$e")
                onAdClosed.invoke(true)
            }
        }else {
            onAdClosed.invoke(false)
            return
        }
    }


}

