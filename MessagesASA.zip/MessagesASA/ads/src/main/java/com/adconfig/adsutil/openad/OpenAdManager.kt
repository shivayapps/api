package com.adconfig.adsutil.openad

import android.app.Activity
import android.app.Application
import android.os.Bundle
import android.util.Log
import com.adconfig.adsutil.openad.OpenAdHelper.isShowOpenAd

class OpenAdManager(
    private val myApplication: AppOpenApplication
) : Application.ActivityLifecycleCallbacks {

    var mCurrentActivity: Activity? = null

    init {
        myApplication.registerActivityLifecycleCallbacks(this)
    }

    override fun onActivityResumed(activity: Activity) {
        mCurrentActivity = activity
    }

    override fun onActivityDestroyed(activity: Activity) {

//        if (!isAppForeground) {
//            if (FullScreenNativeAdDialog.isDialogShowing) {
//                FullScreenNativeAdDialog.dismissDialog()
//            }
//        }

    }

    override fun onActivityStopped(activity: Activity) {

//        if (FullScreenNativeAdDialog.isDialogShowing) {
//            FullScreenNativeAdDialog.dismissDialog()
//        }
    }

    override fun onActivityStarted(activity: Activity) {

    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {

    }

    override fun onActivityPaused(activity: Activity) {

    }

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}

    fun showOpenAd() {
//        myApplication.mAppLifecycleListener?.onAppOpenCreatedEvent(mCurrentActivity!!)
        mCurrentActivity?.let {
            it.isShowOpenAd({
                Log.e("Sales2", "gotoMainScreen: isShowOpenAd")
            })

        }
    }
}