package com.adconfig.adsutil

import android.util.Log
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import java.util.Date

object Config {

    var mAppOpenAd: AppOpenAd? = null
    var mInterstitialAd: InterstitialAd? = null
    var isLibraryInitialized = false

    var admobAppOpenId: String = ""
    var showInterTime: Long = 0
    var adinterval: Long = 30
    var enableAds: Boolean = true

    fun checkInterAd():Boolean{
        if (Config.showInterTime != 0L) {
            if ( Config.adinterval == 0L) return false
            val diff = Date().time - Config.showInterTime
            Log.e("LLL_Splash", "loadBackPressInter: $diff")
            if (diff < (Config.adinterval * 1000)) {
                return false
            }
            return true
        }
        return true
    }

//    fun checkReInter(callback: (Boolean) -> Unit) {
//        Log.e("ADCONFIG_InterAd", "checkReInter: $showInterTime")
//        if(enableAds) {
//            if (showInterTime != 0L) {
//                if (adinterval == 0L) return
//                val diff = Date().time - showInterTime
//                Log.e("ADCONFIG_InterAd", "loadBackPressInter: $diff")
//                if (diff < (adinterval * 1000)) {
//                    callback.invoke(false)
//                    return
//                }
//                callback.invoke(true)
//            } else {
//                callback.invoke(true)
//            }
//        } else callback.invoke(false)
//    }
}