package com.adconfig.adsutil.admob

//object AdmobTestIds {
//    const val App_Open = "ca-app-pub-3940256099942544/9257395921"
//    const val Banner = "ca-app-pub-3940256099942544/9214589741"
//    const val Interstitial = "ca-app-pub-3940256099942544/1033173712"
//    const val Rewarded = "ca-app-pub-3940256099942544/5224354917"
//    const val Rewarded_Interstitial = "ca-app-pub-3940256099942544/5224354917"
//    const val Native_Advanced = "ca-app-pub-3940256099942544/2247696110"
//}