package com.mediaplayer.video.player.videoplayer.music.musicplayer.db

import android.os.Parcel
import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(indices = [Index(value = ["playlist_creator_id", "id"], unique = true)])
class SongEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "song_key")
    val songPrimaryKey: Long = 0L,
    @ColumnInfo(name = "playlist_creator_id")
    val playlistCreatorId: Long,
    val id: Long,
    val title: String,
    @ColumnInfo(name = "track_number")
    val trackNumber: Int,
    val year: Int,
    val duration: Long,
    val data: String,
    @ColumnInfo(name = "date_modified")
    val dateModified: Long,
    @ColumnInfo(name = "album_id")
    val albumId: Long,
    @ColumnInfo(name = "album_name")
    val albumName: String,
    @ColumnInfo(name = "artist_id")
    val artistId: Long,
    @ColumnInfo(name = "artist_name")
    val artistName: String,
    val composer: String?,
    @ColumnInfo(name = "album_artist")
    val albumArtist: String?
) : Parcelable {

    constructor(parcel: Parcel) : this(
        parcel.readLong(),
        parcel.readLong(),
        parcel.readLong(),
        parcel.readString()!!,
        parcel.readInt(),
        parcel.readInt(),
        parcel.readLong(),
        parcel.readString()!!,
        parcel.readLong(),
        parcel.readLong(),
        parcel.readString()!!,
        parcel.readLong(),
        parcel.readString()!!,
        parcel.readString(),
        parcel.readString()
    )

    override fun describeContents(): Int {
        return 0
    }

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeLong(songPrimaryKey)
        dest.writeLong(playlistCreatorId)
        dest.writeLong(id)
        dest.writeLong(duration)
        dest.writeLong(albumId)
        dest.writeLong(dateModified)
        dest.writeLong(artistId)
        dest.writeString(title)
        dest.writeString(data)
        dest.writeString(albumName)
        dest.writeString(composer)
        dest.writeString(artistName)
        dest.writeString(albumArtist)
        dest.writeInt(trackNumber)
        dest.writeInt(year)
    }

    companion object CREATOR : Parcelable.Creator<SongEntity> {
        override fun createFromParcel(parcel: Parcel): SongEntity {
            return SongEntity(parcel)
        }

        override fun newArray(size: Int): Array<SongEntity?> {
            return arrayOfNulls(size)
        }
    }
}
