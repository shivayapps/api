package com.mediaplayer.video.player.videoplayer.music.common.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface HideVideoDao {

    @Query("Select * from hide_video")
    fun getHideVideoLive(): LiveData<List<HideVideo>>

    @Query("Select * from hide_video")
    fun getHideVideo(): List<HideVideo>

    @Insert
    fun insertHideVideo(hideVideo: HideVideo)

    @Query("DELETE FROM hide_video")
    fun deleteHideVideo()

    @Query("DELETE from hide_video WHERE videopath = :filepath")
    fun deleteHideVideo(filepath: String?)

    @Query("Select * from hide_video WHERE videopath = :filepath")
    fun hideVideo(filepath: String?) : HideVideo

    @Query("Select * from hide_video WHERE  folderpath = :fpath and foldername = :fname")
    fun getHideVideoLive(fpath: String?,fname: String?) : LiveData<List<HideVideo>>

    @Query("Select * from hide_video WHERE  folderpath = :fpath and foldername = :fname")
    fun getHideVideo(fpath: String?,fname: String?) : List<HideVideo>

}