
package com.mediaplayer.video.player.videoplayer.music.musicplayer.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
class BlackListStoreEntity(
    @PrimaryKey
    val path: String
)
