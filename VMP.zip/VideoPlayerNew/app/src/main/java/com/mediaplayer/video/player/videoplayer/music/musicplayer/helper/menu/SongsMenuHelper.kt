
package com.mediaplayer.video.player.videoplayer.music.musicplayer.helper.menu

import android.util.Log
import androidx.fragment.app.FragmentActivity
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.musicplayer.dialogs.AddToPlaylistDialog
import com.mediaplayer.video.player.videoplayer.music.musicplayer.dialogs.DeleteSongsDialog
import com.mediaplayer.video.player.videoplayer.music.musicplayer.helper.MusicPlayerRemote
import com.mediaplayer.video.player.videoplayer.music.musicplayer.model.Song
import com.mediaplayer.video.player.videoplayer.music.musicplayer.repository.RealRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.koin.core.component.KoinComponent
import org.koin.core.component.get

object SongsMenuHelper : KoinComponent {
    fun handleMenuClick(
        activity: FragmentActivity,
        songs: List<Song>,
        menuItemId: Int
    ): Boolean {
        when (menuItemId) {
            R.id.action_play_next -> {
                MusicPlayerRemote.playNext(songs)
                return true
            }
            R.id.action_add_to_current_playing -> {
                MusicPlayerRemote.enqueue(songs)
                return true
            }
            R.id.action_add_to_playlist -> {
                CoroutineScope(Dispatchers.IO).launch {
                    val playlists = get<RealRepository>().fetchPlaylists()
                    withContext(Dispatchers.Main) {
                        AddToPlaylistDialog.create(playlists, songs)
                            .show(activity.supportFragmentManager, "ADD_PLAYLIST")
                    }
                }
                return true
            }
            R.id.action_delete_from_device -> {
                Log.e("TAG", "handleMenuClick: 4", )
                DeleteSongsDialog.create(songs).show(activity.supportFragmentManager, "DELETE_SONGS")
                return true
            }
        }
        return false
    }
}
