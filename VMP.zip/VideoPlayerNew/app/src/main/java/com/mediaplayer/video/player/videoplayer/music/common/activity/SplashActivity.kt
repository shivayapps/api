package com.mediaplayer.video.player.videoplayer.music.common.activity

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.preference.PreferenceManager
import code.name.monkey.appthemehelper.util.VersionUtils
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingActivity
import com.mediaplayer.video.player.videoplayer.music.common.database.HideVideoDatabase
import com.mediaplayer.video.player.videoplayer.music.common.utils.DATABASE_PATH
import com.mediaplayer.video.player.videoplayer.music.common.utils.addNoMedia
import com.mediaplayer.video.player.videoplayer.music.common.utils.ensureBackgroundThread
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivitySplashBinding
import com.mediaplayer.video.player.videoplayer.music.musicplayer.App
import com.mediaplayer.video.player.videoplayer.music.musicplayer.MATERIAL_YOU
import com.mediaplayer.video.player.videoplayer.music.musicplayer.RATE_COUNT
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.resolveColor
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.setDrawBehindSystemBars
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.setImmersiveFullscreen
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.setStatusBarColor
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.PreferenceUtil
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream

@SuppressLint("CustomSplashScreen")
class SplashActivity : BaseBindingActivity<ActivitySplashBinding>() {

    override fun getActivityContext(): FragmentActivity {
        return this@SplashActivity
    }

    override fun setBinding(): ActivitySplashBinding {
        return ActivitySplashBinding.inflate(layoutInflater)
    }

    override fun initViewAction() {

    }

    override fun initView() {
        super.initView()

        try {
            if (checkPermissionBelow30()) {
                copyDB()
            }
        } catch (e: Exception) {
            Log.e(TAG, "backupDatabase: ex: $e")
        }

        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        } else {
            setImmersiveFullscreen()
        }
        setStatusBarColor(resolveColor(R.attr.mainBackgroundColor))
        val eDir = PreferenceManager.getDefaultSharedPreferences(App.getContext())
        val a = eDir.getInt(RATE_COUNT, 0) + 1
        eDir.edit().putInt(RATE_COUNT, a).apply()

        if (VersionUtils.hasS()) {
            val editor = PreferenceManager.getDefaultSharedPreferences(App.getContext()).edit()
            editor.putBoolean(MATERIAL_YOU, false)
            editor.apply()
        }

        Handler(Looper.getMainLooper()).postDelayed({
            if (!checkPermissionBelow30()) {
                val intent = Intent(mActivity, GetStartedActivity::class.java)
                launchActivity(intent, true)
            } else {
                Handler(Looper.getMainLooper()).postDelayed({
                    val intent = Intent(mActivity, MainActivity::class.java)
                    launchActivity(intent, true)
                }, 10)
            }
        }, 3500)
    }

    private fun checkPermissionBelow30(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return !(ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_MEDIA_IMAGES
            ) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_MEDIA_AUDIO
            ) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_MEDIA_VIDEO
            ) != PackageManager.PERMISSION_GRANTED)
        } else {
            return !(ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED)
        }
    }

    private fun copyDB() {
        val dbFile: File = getDatabasePath("videoPlayer.db")
        val sDir = File(DATABASE_PATH)
        val parentFile = File(sDir.parentFile!!.absolutePath)
        if (!parentFile.exists()) {
            parentFile.mkdir()
        }
        if (!sDir.exists()) {
            sDir.mkdir()
        }

        val saveFile = File("$DATABASE_PATH/videoPlayer.db")

        try {
            if (!saveFile.exists()) {
                ensureBackgroundThread {
                    addNoMedia(sDir.absolutePath) {
                        addNoMedia(sDir.parentFile!!.absolutePath) {}
                    }
                }
                val bufferSize = 8 * 1024
                val buffer = ByteArray(bufferSize)
                var bytesRead: Int
                val saveDb: OutputStream = FileOutputStream(saveFile)
                val inDb: InputStream = FileInputStream(dbFile)
                while (inDb.read(buffer, 0, bufferSize).also { bytesRead = it } > 0) {
                    saveDb.write(buffer, 0, bytesRead)
                }
                saveDb.flush()
                inDb.close()
                saveDb.close()
                Log.e(TAG, "backupDatabase: Db Backup successful...")
                HideVideoDatabase.destroyInstance()
                try {
                    HideVideoDatabase.getInstance(this)
                } catch (e: Exception) {
                    Log.e(TAG, "saveFile: ex: $e")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "backupDatabase: ex: $e")
        }
    }
}