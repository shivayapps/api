package com.mediaplayer.video.player.videoplayer.music.common.base

import android.app.Application
import android.content.Context

class MyApplication : Application() {

    companion object{

        var context: Context? = null



        lateinit var mInstance: MyApplication

        @Synchronized
        fun getInstance(): MyApplication {
            return mInstance
        }
    }



    override fun onCreate() {
        super.onCreate()
        context = applicationContext
        mInstance = this
    }
}