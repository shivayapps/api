package com.mediaplayer.video.player.videoplayer.music.common.status

import android.os.Environment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingFragment
import com.mediaplayer.video.player.videoplayer.music.common.status.adapter.StatusAdapter
import com.mediaplayer.video.player.videoplayer.music.common.utils.AppConstant.Companion.FOLDER_WHATSAPP
import com.mediaplayer.video.player.videoplayer.music.databinding.FragmentVideoDownloadBinding
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.hide
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.show
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.FileUtils
import com.mediaplayer.video.player.videoplayer.music.videoplayer.model.VideoData
//import com.hdplayer.playerview.videoplayerscreen.R
//import com.hdplayer.playerview.videoplayerscreen.base.BaseBindingFragment
//import com.hdplayer.playerview.videoplayerscreen.databinding.FragmentVideoDownloadBinding
//import com.hdplayer.playerview.videoplayerscreen.ui.adapter.StatusAdapter
//import com.hdplayer.playerview.videoplayerscreen.ui.model.VideoData
//import com.hdplayer.playerview.videoplayerscreen.utils.FOLDER_WHATSAPP
//import com.hdplayer.playerview.videoplayerscreen.utils.FileUtil
//import com.hdplayer.playerview.videoplayerscreen.utils.GetDataMethod
//import com.hdplayer.playerview.videoplayerscreen.utils.doHide
//import com.hdplayer.playerview.videoplayerscreen.utils.doVisible
import java.io.File
import java.util.concurrent.Executors


class VideoDownloadFragment : BaseBindingFragment<FragmentVideoDownloadBinding>() {

    private var videosList: ArrayList<VideoData> = ArrayList()
    private var videoDownloadAdapter: StatusAdapter? = null

    override fun setBinding(
        layoutInflater: LayoutInflater,
        container: ViewGroup?
    ): FragmentVideoDownloadBinding {
        return FragmentVideoDownloadBinding.inflate(layoutInflater, container, false)
    }

    override fun initView() {
        super.initView()
        val path = FileUtils.getExternalStoragePublicDirectory(
            requireContext(),
            Environment.DIRECTORY_PICTURES
        ) + File.separator + getString(
            R.string.app_name
        ) + File.separator + FOLDER_WHATSAPP + "/Video"

        val service = Executors.newSingleThreadExecutor()
        service.execute {
            requireActivity().runOnUiThread { mBinding.progressCircular.visibility = View.VISIBLE }
            videosList = FileUtils.getAllList(path)
            requireActivity().runOnUiThread {
                mBinding.progressCircular.visibility = View.GONE
                if (videosList.size == 0) {
                    mBinding.nodata.show()
                    mBinding.rvVideoDownloadList.hide()
                } else {
                    mBinding.nodata.hide()
                    mBinding.rvVideoDownloadList.show()
                    videoDownloadAdapter =
                        StatusAdapter(videosList, requireActivity(), requireContext(), 2) {
                            mBinding.nodata.show()
                            mBinding.rvVideoDownloadList.hide()
                        }
                    mBinding.rvVideoDownloadList.adapter = videoDownloadAdapter
                }
            }
        }
    }
}