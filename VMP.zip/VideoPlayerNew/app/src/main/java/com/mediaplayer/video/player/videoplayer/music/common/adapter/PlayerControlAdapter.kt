package com.mediaplayer.video.player.videoplayer.music.common.adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.utils.ControlInfo
import com.mediaplayer.video.player.videoplayer.music.common.utils.PlayerControls
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.PreferenceUtil
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.PreferenceUtil.isEqualizerOn
import com.mediaplayer.video.player.videoplayer.music.videoplayer.player.PlayerActivity

class PlayerControlAdapter(
    private val mPlayerActivity: PlayerActivity,
    private var mControlList: MutableList<ControlInfo>,
    val listener: ControlClickListener
) : RecyclerView.Adapter<PlayerControlAdapter.ControlViewHolder>() {

    interface ControlClickListener {
        fun onControlClick(position: Int)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ControlViewHolder {
        val mView =
            LayoutInflater.from(mPlayerActivity).inflate(R.layout.img_item_list, parent, false)
        return ControlViewHolder(mView)
    }

    override fun onBindViewHolder(holder: ControlViewHolder, position: Int) {
        val playerControl = mControlList[position]

        Log.e("PlayerControlAdapter", "onBindViewHolder.position:$position")
        Log.e("PlayerControlAdapter", "onBindViewHolder.name:${playerControl?.controlInfo?.name}")

        if (playerControl != null) {
            holder.ivControl.setImageDrawable(
                ContextCompat.getDrawable(
                    mPlayerActivity,
                    playerControl.controlInfo.icon
                )
            )
        }

        if (playerControl != null) {
            holder.tvControl.setText(playerControl.controlInfo.stringRes)
        }

        if (playerControl != null) {
            when (playerControl.controlInfo) {
                PlayerControls.Speed -> {}
                PlayerControls.BgPlay -> {}
                PlayerControls.AudioTrack -> {

                }

                PlayerControls.Playlist -> {

                }

                PlayerControls.Rotate -> {}
                PlayerControls.Equalizer -> {
                    if (isEqualizerOn) {
                        holder.ivControl.setImageDrawable(
                            ContextCompat.getDrawable(
                                mPlayerActivity,
                                playerControl.controlInfo.iconActivated
                            )
                        )
                    }
                }

                PlayerControls.SleepTimer -> {}
                PlayerControls.NightMode -> {}
                PlayerControls.ShuffleVideo -> {
                    if (PreferenceUtil.isShuffleVideo) {
                        holder.ivControl.setImageDrawable(
                            ContextCompat.getDrawable(
                                mPlayerActivity,
                                playerControl.controlInfo.iconActivated
                            )
                        )
                    }
                }

                PlayerControls.Mute -> {
                    if (PlayerActivity.player != null) {
                        if (PlayerActivity.player!!.volume != 0f) {
                            holder.ivControl.setImageDrawable(
                                ContextCompat.getDrawable(
                                    mPlayerActivity,
                                    playerControl.controlInfo.iconActivated
                                )
                            )
                        }
                    }
                }

                PlayerControls.DETAIL -> {}
                PlayerControls.Slide -> {}
                PlayerControls.Empty -> {}
            }
        }

        holder.ivControl.setOnClickListener {
            listener.onControlClick(position)
        }

    }

    override fun getItemCount(): Int {
        return mControlList.size
    }

    class ControlViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivControl: ImageView = itemView.findViewById(R.id.iv_control)
        val tvControl: TextView = itemView.findViewById(R.id.tv_control)
    }
}