package com.mediaplayer.video.player.videoplayer.music.musicplayer.fragment

import android.view.LayoutInflater
import android.view.ViewGroup
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingFragment
import com.mediaplayer.video.player.videoplayer.music.databinding.FragmentPlaylistBinding

class PlaylistFragment : BaseBindingFragment<FragmentPlaylistBinding>() {
    override fun setBinding(
        layoutInflater: LayoutInflater,
        container: ViewGroup?
    ): FragmentPlaylistBinding {

        return FragmentPlaylistBinding.inflate(layoutInflater)
    }

    companion object{
        fun newInstance(): PlaylistFragment {
            return PlaylistFragment()
        }
    }
}