package com.mediaplayer.video.player.videoplayer.music.common.status

import android.app.Activity
import android.content.Intent
import android.widget.TextView
import androidx.appcompat.content.res.AppCompatResources
import androidx.fragment.app.FragmentActivity
import androidx.preference.PreferenceManager
import androidx.viewpager.widget.ViewPager
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingActivity
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityWhatsappStatusDownloadBinding
import com.mediaplayer.video.player.videoplayer.music.musicplayer.App
import com.mediaplayer.video.player.videoplayer.music.musicplayer.GENERAL_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.IMAGE_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.makeStatusBarTransparent
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.resolveColor
import com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.mediaplayer.video.player.videoplayer.music.videoplayer.adapter.ViewPagerAdapter
import org.jetbrains.anko.backgroundColor

class WhatsappStatusDownloadActivity :
    BaseBindingActivity<ActivityWhatsappStatusDownloadBinding>() {

    private var videosDownloadFragment: VideoDownloadFragment? = null

    private var photosDownloadFragment: PhotoDownloadFragment? = null

    override fun setBinding(): ActivityWhatsappStatusDownloadBinding {
        return ActivityWhatsappStatusDownloadBinding.inflate(layoutInflater)
    }

    override fun getActivityContext(): FragmentActivity {
        return this@WhatsappStatusDownloadActivity
    }

    override fun initView() {
        super.initView()

        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            IMAGE_THEME, ""
        )

        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getInt(
            GENERAL_THEME, 0
        )

        makeStatusBarTransparent()

        if (editors == "theme_image") {
            mBinding.root.background =
                RetroGlideExtension.getUserImageTheme(this@WhatsappStatusDownloadActivity)
            mBinding.constraintLayout.background = null
        } else if (editors == "theme_gradient") {
            mBinding.root.background =
                AppCompatResources.getDrawable(this, RetroGlideExtension.getUserGradientTheme())
            mBinding.constraintLayout.background = null
        } else if (edit >= 0) {
            mBinding.root.background = null
            mBinding.root.backgroundColor = resolveColor(R.attr.mainBackgroundColor)
        }

        mBinding.tvTitle.text = getString(R.string.wp_status_saver)
        viewPagerSetup()
    }

    private fun viewPagerSetup() {
        photosDownloadFragment = PhotoDownloadFragment()
        videosDownloadFragment = VideoDownloadFragment()

        val mViewPagerAdapter = ViewPagerAdapter(supportFragmentManager)

        mViewPagerAdapter.addFragment(photosDownloadFragment!!, "Photos")
        mViewPagerAdapter.addFragment(videosDownloadFragment!!, "Videos")

        mBinding.wpViewpager.adapter = mViewPagerAdapter

        mBinding.wpViewpager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int,
            ) {

            }

            override fun onPageSelected(position: Int) {

                if (position == 0) {
                    setUpDesign(mBinding.tvPhotos)
                } else {
                    setUpDesign(mBinding.tvVideos)
                }
            }

            override fun onPageScrollStateChanged(state: Int) {

            }
        })
    }

    fun setUpDesign(selectTextView: TextView) {
        mBinding.tvVideos.setTextColor(resolveColor(R.attr.text_color_subtitle))
        mBinding.tvPhotos.setTextColor(resolveColor(R.attr.text_color_subtitle))

        mBinding.tvPhotos.setBackgroundResource(R.drawable.rounded_border)
        mBinding.tvVideos.setBackgroundResource(R.drawable.rounded_border)

        selectTextView.setTextColor(resolveColor(R.attr.colorPrimary))
        selectTextView.setBackgroundResource(R.drawable.rounded_selected)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 111) {
            if (resultCode == Activity.RESULT_OK) {
                if (mBinding.wpViewpager.currentItem == 0) {
                    photosDownloadFragment!!.initView()
                } else {
                    videosDownloadFragment!!.initView()
                }
            }
        }
    }

    override fun initViewListener() {
        super.initViewListener()
        mBinding.tvVideos.setOnClickListener {
            mBinding.wpViewpager.currentItem = 1
        }
        mBinding.tvPhotos.setOnClickListener {
            mBinding.wpViewpager.currentItem = 0
        }
        mBinding.ivBack.setOnClickListener {
            onBackPressed()
        }
    }
}