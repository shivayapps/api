package com.mediaplayer.video.player.videoplayer.music.common.activity

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.view.View
import androidx.appcompat.content.res.AppCompatResources
import androidx.fragment.app.FragmentActivity
import androidx.preference.PreferenceManager
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingActivity
import com.mediaplayer.video.player.videoplayer.music.common.cropper.CropImage
import com.mediaplayer.video.player.videoplayer.music.common.cropper.CropImageView
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityThemeBinding
import com.mediaplayer.video.player.videoplayer.music.musicplayer.App
import com.mediaplayer.video.player.videoplayer.music.musicplayer.GENERAL_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.IMAGE_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.makeStatusBarTransparent
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.resolveColor
import com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.mediaplayer.video.player.videoplayer.music.videoplayer.model.VideoData
import org.jetbrains.anko.backgroundColor

class ThemeActivity : BaseBindingActivity<ActivityThemeBinding>() {

    companion object {
        var mVideoData: ArrayList<VideoData> = ArrayList()
    }

    override fun getActivityContext(): FragmentActivity {
        return this@ThemeActivity
    }

    override fun setBinding(): ActivityThemeBinding {
        return ActivityThemeBinding.inflate(layoutInflater)
    }

    override fun onResume() {
        super.onResume()
        initView()
    }

    override fun initView() {
        super.initView()

        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext())
            .getString(IMAGE_THEME, "")
        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getInt(
            GENERAL_THEME, 0
        )

        makeStatusBarTransparent()

        if (editors == "theme_image") {
            mBinding.root.background = RetroGlideExtension.getUserImageTheme(this@ThemeActivity)
            mBinding.constraintLayout.background = null
        } else if (editors == "theme_gradient") {
            mBinding.root.background =
                AppCompatResources.getDrawable(this, RetroGlideExtension.getUserGradientTheme())
            mBinding.constraintLayout.background = null
        } else if (edit >= 0) {
            mBinding.root.background = null
            mBinding.root.backgroundColor = resolveColor(R.attr.mainBackgroundColor)
        }
    }

    override fun initViewListener() {
        super.initViewListener()
        mBinding.ivBack.setOnClickListener(this)
        mBinding.clThemeImage.setOnClickListener(this)
        mBinding.clThemeColor.setOnClickListener(this)
        mBinding.clThemeGradient.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        super.onClick(v)
        when (v.id) {
            R.id.iv_back -> {
                onBackPressedDispatcher.onBackPressed()
            }

            R.id.cl_theme_image -> {
                CropImage.activity()
                    .setGuidelines(CropImageView.Guidelines.ON)
                    .setActivityTitle("Crop")
                    .setCropMenuCropButtonTitle("Crop")
                    .setAspectRatio(9, 16)
                    .start(this)
            }

            R.id.cl_theme_color -> {
                val intent = Intent(this@ThemeActivity, ThemeSaveActivity::class.java)
                intent.putExtra("themeType", "color")
                startActivity(intent)
            }

            R.id.cl_theme_gradient -> {
                val intent = Intent(this@ThemeActivity, ThemeSaveActivity::class.java)
                intent.putExtra("themeType", "gradient")
                startActivity(intent)
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            val result = CropImage.getActivityResult(data)
            if (resultCode == Activity.RESULT_OK) {
                proceedToTheme(result.uri)
            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                finish()
            }
        }
    }

    private fun proceedToTheme(fileUri: Uri) {
        val intent = Intent(this@ThemeActivity, ThemeSaveActivity::class.java)
        intent.putExtra("themeType", "image")
        intent.putExtra("fileUri", fileUri.toString())
        startActivity(intent)
    }
}