package com.mediaplayer.video.player.videoplayer.music.musicplayer.fragment

import android.content.SharedPreferences
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.navigation.contains
import androidx.navigation.ui.setupWithNavController
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingFragment
import com.mediaplayer.video.player.videoplayer.music.databinding.FragmentTempBinding
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.findNavController
import com.mediaplayer.video.player.videoplayer.music.musicplayer.model.CategoryInfo
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.PreferenceUtil


class TempFragment : BaseBindingFragment<FragmentTempBinding>(),
    SharedPreferences.OnSharedPreferenceChangeListener {



    companion object {

        fun newInstance() = TempFragment()
    }

    override fun setBinding(
        layoutInflater: LayoutInflater,
        container: ViewGroup?
    ): FragmentTempBinding {
       return FragmentTempBinding.inflate(layoutInflater)
    }

    override fun initView() {
        super.initView()

        val navController = findNavController(R.id.fragment_container)
        val navInflater = navController.navInflater
        val navGraph = navInflater.inflate(R.navigation.main_graph)

        val categoryInfo: CategoryInfo = PreferenceUtil.libraryCategory.first { it.visible }
        if (categoryInfo.visible) {
            if (!navGraph.contains(PreferenceUtil.lastTab)) PreferenceUtil.lastTab =
                categoryInfo.category.id
            navGraph.setStartDestination(
                if (PreferenceUtil.rememberLastTab) {
                    PreferenceUtil.lastTab.let {
                        if (it == 0) {
                            categoryInfo.category.id
                        } else {
                            it
                        }
                    }
                } else categoryInfo.category.id
            )
        }
        navController.graph = navGraph
        mBinding.bottomNavigationView.setupWithNavController(navController)
        mBinding.bottomNavigationView.setOnItemReselectedListener {

//           requireActivity().supportFragmentManager.currentNavigationFragment.apply {
//               if (this is IScrollHelper) {
//              // scrollToTop()
//           } }

        }

        navController.addOnDestinationChangedListener { _, destination, _ ->
            if (destination.id == navGraph.startDestinationId) {
              //  requireActivity().supportFragmentManager.currentNavigationFragment!!.enterTransition = null
            }
            when (destination.id) {
//                R.id.action_home,
                R.id.action_song, R.id.action_album, R.id.action_artist, R.id.action_folder, R.id.action_playlist, R.id.action_genre, R.id.action_search -> {
                    // Save the last tab
                    if (PreferenceUtil.rememberLastTab) {
                       // saveTab(destination.id)
                    }
                    // Show Bottom Navigation Bar
                   // setBottomNavVisibility(visible = true, animate = true)
                }
                R.id.playing_queue_fragment -> {
                  //  setBottomNavVisibility(visible = false, hideBottomSheet = true)
                }
                else -> {}
//                    setBottomNavVisibility(
//                    visible = false,
//                    animate = true
//                ) // Hide Bottom Navigation Bar
            }
        }
    }

    override fun onSharedPreferenceChanged(p0: SharedPreferences?, p1: String?) {
        TODO("Not yet implemented")
    }
}