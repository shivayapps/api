
package com.mediaplayer.video.player.videoplayer.music.musicplayer.glide

import android.graphics.drawable.Drawable
import android.widget.ImageView
import code.name.monkey.appthemehelper.util.ATHUtil
import com.bumptech.glide.request.transition.Transition
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.palette.BitmapPaletteTarget
import com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.palette.BitmapPaletteWrapper
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.ColorUtil

abstract class SingleColorTarget(view: ImageView) : BitmapPaletteTarget(view) {

    private val defaultFooterColor: Int
        get() = ATHUtil.resolveColor(view.context, R.attr.colorControlNormal)

    abstract fun onColorReady(color: Int)

    override fun onLoadFailed(errorDrawable: Drawable?) {
        super.onLoadFailed(errorDrawable)
        onColorReady(defaultFooterColor)
    }

    override fun onResourceReady(
        resource: BitmapPaletteWrapper,
        transition: Transition<in BitmapPaletteWrapper>?
    ) {
        super.onResourceReady(resource, transition)
        onColorReady(
            ColorUtil.getColor(
                resource.palette,
                ATHUtil.resolveColor(view.context, R.attr.colorPrimary)
            )
        )
    }
}
