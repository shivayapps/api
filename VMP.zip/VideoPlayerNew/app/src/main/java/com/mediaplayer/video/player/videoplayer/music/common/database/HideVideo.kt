package com.mediaplayer.video.player.videoplayer.music.common.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "hide_video")
data class HideVideo(
    @PrimaryKey(autoGenerate = true)
    var id: Int?,
    var name: String = "",
    var foldername: String = "",
    var folderpath: String = "",
    var videopath: String = "",
    var pathID: String = "") : Serializable
