package com.mediaplayer.video.player.videoplayer.music.common.status

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingActivity
import com.mediaplayer.video.player.videoplayer.music.common.utils.fileFromContentUri
import com.mediaplayer.video.player.videoplayer.music.common.utils.fileShare
import com.mediaplayer.video.player.videoplayer.music.common.utils.saveFiles
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityFullScreenBinding
import com.mediaplayer.video.player.videoplayer.music.databinding.DeleteBottomSheetLayoutBinding
import com.mediaplayer.video.player.videoplayer.music.databinding.ViewPagerLayoutBinding
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.FileUtils
import com.mediaplayer.video.player.videoplayer.music.videoplayer.model.VideoData
import java.io.File

class FullScreenActivity : BaseBindingActivity<ActivityFullScreenBinding>() {

    private var currantPosition = 0
    private var intentValue = "VALUE_STATUS"
    private var intentType = 0

    var adapter: ImageReAdapter? = null
    private var isVideo = false

    companion object {
        var allArrayList: ArrayList<VideoData> = ArrayList()
    }

    var photoList: ArrayList<VideoData> = ArrayList()

    override fun setBinding(): ActivityFullScreenBinding {
        return ActivityFullScreenBinding.inflate(layoutInflater)
    }

    override fun getActivityContext(): FragmentActivity {
        return this@FullScreenActivity
    }

    override fun initView() {
        super.initView()
        currantPosition = intent.getIntExtra("INTENT_POSITION", 0)
        intentValue = intent.getStringExtra("INTENT_KEY").toString()
        intentType = intent.getIntExtra("INTENT_TYPE", 0)

        if (intentType == 1 || intentType == 2) {
            isVideo = true
        }

        photoList.addAll(allArrayList)

        Log.e("sujal", "initView: $intentValue")
        if (intentValue == "VALUE_DOWNLOAD") {
            mBinding.tvChange.text = getString(R.string.delete)
            mBinding.ivChange.setImageResource(R.drawable.ic_delete)
        }
        viewPagerStatup()
    }

    override fun initViewAction() {
        super.initViewAction()
        mBinding.llShare.setOnClickListener {

            if (intentValue == "VALUE_STATUS") {
                fileShare(
                    this,
                    fileFromContentUri(this, Uri.parse(photoList[currantPosition].path)).path,
                    isVideo = false
                )
            } else {
                fileShare(this, photoList[currantPosition].path, isVideo = false)
            }
        }

        mBinding.ivBack.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        mBinding.llDownload.setOnClickListener {
            if (intentValue == "VALUE_STATUS") {
                saveFiles(photoList[currantPosition].path, this)
            } else {
                val deleteBottomDialog = Dialog(this)
                val deleteDialogBinding: DeleteBottomSheetLayoutBinding =
                    DeleteBottomSheetLayoutBinding.inflate(LayoutInflater.from(this))
                deleteBottomDialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
                deleteBottomDialog.setContentView(deleteDialogBinding.root)
                deleteBottomDialog.setCancelable(false)
                deleteBottomDialog.setCanceledOnTouchOutside(true)
                deleteDialogBinding.yes.setOnClickListener {
                    deleteBottomDialog.dismiss()
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        FileUtils.deleteWithoutManageExternalStorage(
                            photoList[currantPosition].path, this
                        )
                    } else {
                        val file1 = File(photoList[currantPosition].path)
                        val d = file1.delete()
                        if (d) {
                            photoList.removeAt(currantPosition)
                            if (photoList.size == 0) {
                                finish()
                            } else {
                                adapter!!.notifyItemRemoved(currantPosition)
                            }
                        }
                    }
                }
                deleteDialogBinding.cancel.setOnClickListener {
                    deleteBottomDialog.dismiss()
                }

                val lp = WindowManager.LayoutParams()
                lp.copyFrom(deleteBottomDialog.window!!.attributes)
                lp.width = WindowManager.LayoutParams.MATCH_PARENT
                lp.height = WindowManager.LayoutParams.WRAP_CONTENT
                lp.gravity = Gravity.CENTER

                deleteBottomDialog.window!!.attributes = lp
                deleteBottomDialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                deleteBottomDialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
                deleteBottomDialog.show()

            }
        }
    }

    private fun viewPagerStatup() {
        mBinding.fullViewPager.orientation = ViewPager2.ORIENTATION_HORIZONTAL
        mBinding.fullViewPager.offscreenPageLimit = 1
        adapter = ImageReAdapter(this, photoList)
        mBinding.fullViewPager.adapter = adapter
        mBinding.fullViewPager.setCurrentItem(currantPosition, false)
        mBinding.fullViewPager.registerOnPageChangeCallback(object :
            ViewPager2.OnPageChangeCallback() {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int,
            ) {
                super.onPageScrolled(position, positionOffset, positionOffsetPixels)
                currantPosition = position
                val file = File(photoList[currantPosition].path)
                mBinding.tvTitle.text = file.name
            }

            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                currantPosition = position
            }

        })
        val file = File(photoList[currantPosition].path)
        mBinding.tvTitle.text = file.name
    }


    inner class ImageReAdapter(
        private val context: Context,
        private val fileMediaList: ArrayList<VideoData>,
    ) : RecyclerView.Adapter<ImageReAdapter.MyViewHolder?>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
            return MyViewHolder(
                ViewPagerLayoutBinding.inflate(
                    LayoutInflater.from(parent.context),
                    parent,
                    false
                )
            )
        }

        override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
            val imageItem = fileMediaList[position]
            val file = File(imageItem.path)
            mBinding.tvTitle.text = file.name

            Glide.with(context)
                .load(imageItem.path)
                .placeholder(R.drawable.image_placeholder_gallery)
                .into(holder.bindings.viewImage)
        }

        override fun getItemCount(): Int {
            return fileMediaList.size
        }

        inner class MyViewHolder(var bindings: ViewPagerLayoutBinding) :
            RecyclerView.ViewHolder(bindings.root)
    }
}