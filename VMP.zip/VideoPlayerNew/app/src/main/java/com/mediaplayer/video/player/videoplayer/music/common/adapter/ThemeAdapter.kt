package com.mediaplayer.video.player.videoplayer.music.common.adapter

import android.app.Activity
import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.mediaplayer.video.player.videoplayer.music.R
import com.google.android.material.card.MaterialCardView

class ThemeAdapter(
    val mContext: Activity,
    val isColor: Boolean,
    private val themeOptions: MutableList<Int>,
    val listener: RVClickListener
    ) : RecyclerView.Adapter<ThemeAdapter.ViewHolder>() {

        var clickedPosition = 0

//        init {
//            if (imageTheme.isEmpty() && generalTheme == "light") {
//                clickedPosition = 0
//            } else if (imageTheme.isEmpty() && generalTheme == "dark") {
//                clickedPosition = 1
//            } else if (imageTheme == "theme_image") {
//                clickedPosition = 2
//            } else if (imageTheme == "theme_two") {
//                clickedPosition = 3
//            }
//        }

        interface RVClickListener {
            fun onThemeClick(position: Int)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            return ViewHolder(
                LayoutInflater.from(mContext).inflate(R.layout.raw_main_theme, parent, false)
            )
        }

        override fun getItemCount(): Int {
            return themeOptions.size
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val nearby = themeOptions[position]
            if(isColor) {
//                holder.ivThumb.setImageResource(R.drawable.plain)
//                holder.ivThumb.imageTintList = ColorStateList.valueOf(R.color.all_text_color)
                holder.ivThumb.imageTintList = ColorStateList.valueOf(mContext.getColor(nearby))
//                holder.ivThumb.setImageDrawable(ColorDrawable(nearby))
            } else {
//                holder.ivThumb.setImageDrawable(ContextCompat.getDrawable(mContext, nearby))
                holder.ivThumb.setImageResource(nearby)
            }

            //holder.mainCard.strokeColor=Color.WHITE
//            holder.mainCard.setCardBackgroundColor(Color.BLACK)
            holder.itemView.setOnClickListener {
                clickedPosition = position
                listener.onThemeClick(position)
                notifyDataSetChanged()
            }

//            if (clickedPosition == position) {
//                holder.ivCheck.isChecked = true
//            } else {
//                holder.ivCheck.isChecked = false
//            }

        }

        class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val ivThumb: ImageView = itemView.findViewById(R.id.iv_thumb)
            val mainCard: MaterialCardView = itemView.findViewById(R.id.mainCard)
        }
    }