

package com.mediaplayer.video.player.videoplayer.music.musicplayer.model

import android.os.Parcel
import android.os.Parcelable

data class Genre(
    val id: Long,
    val name: String,
    val songCount: Int
) : Parcelable {

    override fun describeContents(): Int {
        return 0;
    }

    override fun writeToParcel(dest: Parcel, flags: Int) {
    }

}