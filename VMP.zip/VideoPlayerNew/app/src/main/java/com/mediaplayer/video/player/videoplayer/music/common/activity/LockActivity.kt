package com.mediaplayer.video.player.videoplayer.music.common.activity

import android.animation.ObjectAnimator
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.view.isVisible
import androidx.fragment.app.FragmentActivity
import androidx.preference.PreferenceManager
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingActivity
import com.mediaplayer.video.player.videoplayer.music.common.utils.AppConstant
import com.mediaplayer.video.player.videoplayer.music.common.utils.gone
import com.mediaplayer.video.player.videoplayer.music.common.utils.visible
import com.mediaplayer.video.player.videoplayer.music.common.widgets.OnSingleClickListener
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityLockBinding
import com.mediaplayer.video.player.videoplayer.music.musicplayer.App
import com.mediaplayer.video.player.videoplayer.music.musicplayer.GENERAL_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.IMAGE_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.makeStatusBarTransparent
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.resolveColor
import com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.mediaplayer.video.player.videoplayer.music.videoplayer.activity.HiddenFolderActivity
import com.mediaplayer.video.player.videoplayer.music.videoplayer.hidevideo.IndicatorDots
import com.google.android.material.button.MaterialButton
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.jetbrains.anko.backgroundColor
import org.jetbrains.anko.toast

class LockActivity : BaseBindingActivity<ActivityLockBinding>() {

    private var mSetPin = false
    private var mFirstPin = ""
    private val PREFERENCES = "com.amirarcane.lockscreen"
    private val KEY_PIN = "pin"

    private var codeString = ""

    override fun getActivityContext(): FragmentActivity {
        return this@LockActivity
    }

    override fun setBinding(): ActivityLockBinding {
        return ActivityLockBinding.inflate(layoutInflater)
    }

    override fun onResume() {
        super.onResume()
        initView()
    }

    override fun initView() {
        super.initView()

        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext())
            .getString(IMAGE_THEME, "")

        val edit =
            PreferenceManager.getDefaultSharedPreferences(App.getContext()).getInt(GENERAL_THEME, 0)

        makeStatusBarTransparent()

        if (editors == "theme_image") {
            mBinding.root.background = RetroGlideExtension.getUserImageTheme(this@LockActivity)
            mBinding.constraintLayout.background = null
        } else if (editors == "theme_gradient") {
            mBinding.root.background =
                AppCompatResources.getDrawable(this, RetroGlideExtension.getUserGradientTheme())
            mBinding.constraintLayout.background = null
        } else if (edit >= 0) {
            mBinding.root.background = null
            mBinding.root.backgroundColor = resolveColor(R.attr.mainBackgroundColor)
        }

        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this)
        }

        val editor = PreferenceManager.getDefaultSharedPreferences(App.getContext())
        val ans = editor.getString(AppConstant.SECURITY_ANSWER, "")

        if (ans!!.isEmpty()) {
            mBinding.conLockView.gone
            mBinding.conSecurity.visible
        } else {
            mBinding.conLockView.visible
            mBinding.conSecurity.gone
        }

        val pin = getPinFromSharedPreferences()

        if (pin == "") {
            mBinding.title.text = "Set your pin"
            mSetPin = true
            mBinding.tvForgotPwd.gone
        } else {
            mBinding.tvForgotPwd.visible
            mBinding.title.text = "Enter your 4-Digit pin"
        }

        mBinding.indicatorDots.indicatorType = IndicatorDots.IndicatorType.FIXED

        mBinding.tvForgotPwd.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(v: View?) {
                forgotDialog(true)
            }
        })

        mBinding.btnSecurity.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(v: View?) {
                forgotDialog(false)
            }
        })
    }

    private fun getStringCode(buttonId: Int) {
        if (codeString.length < 4) {
            when (buttonId) {
                0 -> codeString += "0"
                1 -> codeString += "1"
                2 -> codeString += "2"
                3 -> codeString += "3"
                4 -> codeString += "4"
                5 -> codeString += "5"
                6 -> codeString += "6"
                7 -> codeString += "7"
                8 -> codeString += "8"
                9 -> codeString += "9"
                else -> {

                }
            }
            mBinding.indicatorDots.updateDot(codeString.length)
        }
    }

    override fun initViewListener() {
        super.initViewListener()
        mBinding.ivBack.setOnClickListener(this)

        mBinding.indicatorDots.pinLength = 4

        mBinding.btn0.setOnClickListener { getStringCode(0) }
        mBinding.btn1.setOnClickListener { getStringCode(1) }
        mBinding.btn2.setOnClickListener { getStringCode(2) }
        mBinding.btn3.setOnClickListener { getStringCode(3) }
        mBinding.btn4.setOnClickListener { getStringCode(4) }
        mBinding.btn5.setOnClickListener { getStringCode(5) }
        mBinding.btn6.setOnClickListener { getStringCode(6) }
        mBinding.btn7.setOnClickListener { getStringCode(7) }
        mBinding.btn8.setOnClickListener { getStringCode(8) }
        mBinding.btn9.setOnClickListener { getStringCode(9) }

        mBinding.btnDone.setOnClickListener {
            if (!AppConstant.mFirstTime) {
                if (codeString.length > 3) {
                    AppConstant.mFirstTime = true
                    Handler(Looper.getMainLooper()).postDelayed({
                        if (mSetPin) {
                            setPin(codeString)
                        } else {
                            checkPin(codeString)
                        }
                    }, 300)
                }
            }
        }

        mBinding.btnClear.setOnClickListener {
            if (codeString.isNotEmpty()) {
                codeString = removeLastChar(codeString)
                mBinding.indicatorDots.updateDot(codeString.length)
            }
        }
    }

    private fun removeLastChar(s: String): String {
        return if (s.isEmpty()) {
            s
        } else s.substring(0, s.length - 1)
    }

    override fun onClick(v: View) {
        super.onClick(v)
        when (v.id) {
            R.id.iv_back -> {
                onBackPressedDispatcher.onBackPressed()
            }
        }
    }

    private fun setPin(pin: String) {
        if (mFirstPin == "") {
            mFirstPin = pin
            mBinding.title.text = "Re-Enter your pin"
            codeString = ""
            mBinding.indicatorDots.updateDot(codeString.length)
            AppConstant.mFirstTime = false
        } else {
            if (pin == mFirstPin) {
                writePinToSharedPreferences(pin)
                toast("Pin set Successfully")
                mBinding.tvForgotPwd.visible
                val intent = Intent(mActivity, HiddenFolderActivity::class.java)
                launchActivity(intent)
                (this@LockActivity).finish()
                mBinding.title.text = "Enter your 4-Digit pin"
                codeString = ""
                mBinding.indicatorDots.updateDot(codeString.length)
                AppConstant.mFirstTime = true
            } else {
                shake()
                mBinding.title.text = "Set your pin"
                codeString = ""
                mBinding.indicatorDots.updateDot(codeString.length)
                mFirstPin = ""
                AppConstant.mFirstTime = false
            }
        }
    }

    private fun forgotDialog(isForgot: Boolean) {
        val dialog = Dialog(mActivity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.security_que_layout)

        val lp = WindowManager.LayoutParams()
        lp.copyFrom(dialog.window!!.attributes)
        lp.width = WindowManager.LayoutParams.MATCH_PARENT
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT
        lp.gravity = Gravity.CENTER

        dialog.window!!.attributes = lp
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)

        var selectedSecQue = ""
        var selectedPos = 0

        val ivClose = dialog.findViewById<ImageView>(R.id.iv_close_sec)
        val ivSubmit = dialog.findViewById<MaterialButton>(R.id.btn_submit)
        val etAnswer = dialog.findViewById<EditText>(R.id.et_answer)
        val spinner = dialog.findViewById<Spinner>(R.id.sp_question)

        ivClose.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(v: View?) {
                dialog.cancel()
                dialog.dismiss()
            }
        })

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>,
                view: View,
                position: Int,
                id: Long
            ) {
                selectedSecQue = spinner.selectedItem as String
                selectedPos = spinner.selectedItemPosition
            }

            override fun onNothingSelected(parent: AdapterView<*>) {

            }
        }

        val editor = PreferenceManager.getDefaultSharedPreferences(App.getContext())
        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).edit()

        ivSubmit.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(v: View?) {
                if (isForgot) {
                    val ans = editor.getString(AppConstant.SECURITY_ANSWER, "")
                    val que = editor.getString(AppConstant.SECURITY_QUESTION, "")
                    Log.e(TAG, "onSingleClick: $que : $ans")
                    when {
                        selectedPos == 0 -> {
                            toast("Please select question")
                        }

                        etAnswer.text.trim().isEmpty() -> {
                            toast("Please enter answer")
                        }

                        selectedSecQue != que -> {
                            toast("Please select right question")
                        }

                        etAnswer.text.toString() != ans -> {
                            toast("Wrong answer")
                        }

                        else -> {
                            dialog.dismiss()
                            EventBus.getDefault().post("ResetPassword")
                            if (mBinding.conSecurity.isVisible) {
                                mBinding.conLockView.visible
                                mBinding.conSecurity.gone
                            }
                        }
                    }
                } else {
                    when {
                        selectedPos == 0 -> {
                            toast("Please select question")
                        }

                        etAnswer.text.trim().isEmpty() -> {
                            toast("Please enter answer")
                        }

                        etAnswer.text.length < 5 -> {
                            toast("Please enter at least 5 character in answer")
                        }

                        else -> {
                            edit.putString(AppConstant.SECURITY_QUESTION, selectedSecQue)
                            edit.putString(AppConstant.SECURITY_ANSWER, etAnswer.text.toString())
                            edit.apply()
                            dialog.dismiss()
                            if (mBinding.conSecurity.isVisible) {
                                mBinding.conLockView.visible
                                mBinding.conSecurity.gone
                            }
                        }
                    }
                }
            }
        })
        dialog.show()
    }

    private fun checkPin(pin: String) {
        if (com.mediaplayer.video.player.videoplayer.music.videoplayer.hidevideo.util.Utils.sha256(pin) == getPinFromSharedPreferences()) {
            val intent = Intent(mActivity, HiddenFolderActivity::class.java)
            launchActivity(intent)
            (this@LockActivity).finish()
            codeString = ""
            mBinding.indicatorDots.updateDot(codeString.length)
        } else {
            shake()
            AppConstant.mFirstTime = false
            codeString = ""
            mBinding.indicatorDots.updateDot(codeString.length)
        }
    }

    private fun shake() {
        val objectAnimator: ObjectAnimator = ObjectAnimator.ofFloat(
            mBinding.indicatorDots,
            "translationX",
            0f,
            25f,
            -25f,
            25f,
            -25f,
            15f,
            -15f,
            6f,
            -6f,
            0f
        ).setDuration(1000)
        objectAnimator.start()
    }

    private fun getPinFromSharedPreferences(): String? {
        val prefs: SharedPreferences =
            mActivity.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
        return prefs.getString(KEY_PIN, "")
    }

    private fun writePinToSharedPreferences(pin: String) {
        val prefs: SharedPreferences =
            mActivity.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
        prefs.edit().putString(
            KEY_PIN,
            com.mediaplayer.video.player.videoplayer.music.videoplayer.hidevideo.util.Utils.sha256(pin)
        ).apply()
        mSetPin = false
    }

    @Subscribe
    fun OnEvent(str: String?) {
        when (str) {
            "ResetPassword" -> {
                val prefs: SharedPreferences =
                    mActivity.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
                prefs.edit().putString(KEY_PIN, "").apply()
                mFirstPin = ""
                AppConstant.mFirstTime = false
                mBinding.tvForgotPwd.gone

                val pin = getPinFromSharedPreferences()
                if (pin == "") {
                    mBinding.title.text = "Set your pin"
                    mSetPin = true

                } else {
                    mBinding.title.text = "Enter your 4-Digit pin"
                }
            }
        }
    }
}