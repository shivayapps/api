package com.mediaplayer.video.player.videoplayer.music.common.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "favorite_video")
data class FavoriteVideo(

    @PrimaryKey(autoGenerate = true)
    var id: Int?,
    var path: String = "",
    var pathID: String = "",
    var bucketName: String = "",
    var name: String = "",
    var date: Long = 0L,
    var type: String = "",
    var size: Long = 0L,
    var duration: Long = 0L,
    var width: Int = 0,
    var height: Int = 0
) :Serializable
