

package com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.palette;

import androidx.annotation.NonNull;

import com.bumptech.glide.load.engine.Resource;
import com.bumptech.glide.util.Util;

public class BitmapPaletteResource implements Resource<com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.palette.BitmapPaletteWrapper> {

  private final com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.palette.BitmapPaletteWrapper bitmapPaletteWrapper;

  public BitmapPaletteResource(com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.palette.BitmapPaletteWrapper bitmapPaletteWrapper) {
    this.bitmapPaletteWrapper = bitmapPaletteWrapper;
  }

  @NonNull
  @Override
  public com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.palette.BitmapPaletteWrapper get() {
    return bitmapPaletteWrapper;
  }

  @NonNull
  @Override
  public Class<com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.palette.BitmapPaletteWrapper> getResourceClass() {
    return BitmapPaletteWrapper.class;
  }

  @Override
  public int getSize() {
    return Util.getBitmapByteSize(bitmapPaletteWrapper.getBitmap());
  }

  @Override
  public void recycle() {
    bitmapPaletteWrapper.getBitmap().recycle();
  }
}
