
package com.mediaplayer.video.player.videoplayer.music.musicplayer.interfaces

/**
 * Created by Sujal Lathiya on 14/08/17.
 */
interface IMainActivityFragmentCallbacks {
    fun handleBackPress(): Boolean
}
