
package com.mediaplayer.video.player.videoplayer.music.musicplayer.adapter.song

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.fragment.app.FragmentActivity
import com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.GlideApp
import com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.RetroMusicColoredTarget
import com.mediaplayer.video.player.videoplayer.music.musicplayer.interfaces.ICabHolder
import com.mediaplayer.video.player.videoplayer.music.musicplayer.model.Song
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.MusicUtil
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.color.MediaNotificationProcessor

class SimpleSongAdapter(
    context: FragmentActivity,
    songs: ArrayList<Song>,
    layoutRes: Int,
    ICabHolder: ICabHolder?
) : SongAdapter(context, songs, layoutRes, ICabHolder) {

    override fun swapDataSet(dataSet: List<Song>) {
        this.dataSet = dataSet.toMutableList()
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(activity).inflate(itemLayoutRes, parent, false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        super.onBindViewHolder(holder, position)
        val fixedTrackNumber = MusicUtil.getFixedTrackNumber(dataSet[position].trackNumber)

        holder.imageText?.text = if (fixedTrackNumber > 0) fixedTrackNumber.toString() else "-"
        holder.time?.text = MusicUtil.getReadableDurationString(dataSet[position].duration)
        GlideApp.with(activity).asBitmapPalette().songCoverOptions(dataSet[position])
            .load(RetroGlideExtension.getSongModel(dataSet[position]))
            .into(object : RetroMusicColoredTarget(holder.image!!) {
                override fun onColorReady(colors: MediaNotificationProcessor) {

                }
            })
    }

    override fun getItemCount(): Int {
        return dataSet.size
    }
}
