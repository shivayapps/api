package com.videothems.videoplayer.music.adloaders

enum class NativeAdSize {
    Small, Medium, Big
}
