package com.videothems.videoplayer.music.musicplayer.transform

import android.view.View
import androidx.viewpager.widget.ViewPager

class CascadingPageTransformer : ViewPager.PageTransformer {

    private var mScaleOffset = 40

    override fun transformPage(page: View, position: Float) {
        if (position <= 0.0f) {
            //被滑动的那页  position 是-下标~ 0
            page.translationX = 0f
            page.rotation = 45 * position
            page.translationX = page.width / 3 * position
        } else {
            val scale = (page.width - mScaleOffset * position) / page.width.toFloat()

            page.scaleX = scale
            page.scaleY = scale

            page.translationX = -page.width * position
            page.translationY = mScaleOffset * 0.8f * position
        }
    }
}