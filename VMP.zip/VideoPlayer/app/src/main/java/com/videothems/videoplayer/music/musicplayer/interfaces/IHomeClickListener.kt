package com.videothems.videoplayer.music.musicplayer.interfaces

import com.videothems.videoplayer.music.musicplayer.model.Album
import com.videothems.videoplayer.music.musicplayer.model.Artist
import com.videothems.videoplayer.music.musicplayer.model.Genre

interface IHomeClickListener {
    fun onAlbumClick(album: Album)

    fun onArtistClick(artist: Artist)

    fun onGenreClick(genre: Genre)
}