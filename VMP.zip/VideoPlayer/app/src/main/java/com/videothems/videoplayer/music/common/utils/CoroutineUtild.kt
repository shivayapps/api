package com.videothems.videoplayer.music.common.utils

import kotlinx.coroutines.*


val job = SupervisorJob()


/**
 * Launch task in background
 * */
val backgroundscope = CoroutineScope(Dispatchers.Default + job)


/**
 * Launch task in io
 * */
val ioscope = CoroutineScope(Dispatchers.IO + job)

/**
 * For Update Fragment & Attach In FrameLayout
 *
 * @param fFragment your fragment
 * @param fLayout your frameLayout container witch hold your fragment
 */

/**
 * Launch task in main
 * */
val mainscope = CoroutineScope(Dispatchers.Main + job)


fun cancelAllWork() {
    backgroundscope.coroutineContext.cancelChildren()
    ioscope.coroutineContext.cancelChildren()
    mainscope.coroutineContext.cancelChildren()
}


/**
 * Similar to AsyncTask use for cpu & memory incentive task
 * onPreWork() : Run in main thread when work start
 * onBackgroundWork() : Run in background task after pre work done
 * onPostWork() : Run in main thread after background work done
 * */
fun asyncBackgroundWork(
    onPreWork: () -> Unit,
    onBackgroundWork: () -> Unit,
    onPostWork: () -> Unit
) {
    mainscope.launch {
        onPreWork()
        backgroundscope.launch {
            onBackgroundWork()
            mainscope.launch {
                onPostWork()
            }
        }
    }
}

/**
 * Similar to AsyncTask use for api call
 * onPreWork() : Run in main thread when work start
 * onBackgroundWork() : Run in io task after pre work done
 * onPostWork() : Run in main thread after io work done
 * */
fun asyncIoWork(
    onPreWork: () -> Unit,
    onBackgroundWork: () -> Unit,
    onPostWork: () -> Unit
) {
    mainscope.launch {
        onPreWork()
        ioscope.launch {
            onBackgroundWork()
            mainscope.launch {
                onPostWork()
            }
        }
    }
}