package com.videothems.videoplayer.music.musicplayer.activities


import android.content.Intent
import android.view.MenuItem
import android.view.View
import androidx.appcompat.view.ContextThemeWrapper
import androidx.appcompat.widget.PopupMenu
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.afollestad.materialcab.attached.AttachedCab
import com.afollestad.materialcab.attached.destroy
import com.afollestad.materialcab.attached.isActive
import com.afollestad.materialcab.createCab
import com.videothems.videoplayer.music.R
import com.videothems.videoplayer.music.adloaders.BannerAds
import com.videothems.videoplayer.music.adloaders.NativeAdSize
import com.videothems.videoplayer.music.adloaders.PreLoadNativeAds
import com.videothems.videoplayer.music.adloaders.PrefsAds
import com.videothems.videoplayer.music.common.base.BaseBindingActivity
import com.videothems.videoplayer.music.common.utils.isOnline
import com.videothems.videoplayer.music.databinding.ActivityAlbumDetalitBinding
import com.videothems.videoplayer.music.musicplayer.App
import com.videothems.videoplayer.music.musicplayer.EXTRA_ALBUM_ID
import com.videothems.videoplayer.music.musicplayer.GENERAL_THEME
import com.videothems.videoplayer.music.musicplayer.IMAGE_THEME
import com.videothems.videoplayer.music.musicplayer.STATUS_COLOR
import com.videothems.videoplayer.music.musicplayer.adapter.album.HorizontalAlbumAdapter
import com.videothems.videoplayer.music.musicplayer.adapter.song.SimpleSongAdapter
import com.videothems.videoplayer.music.musicplayer.dialogs.AddToPlaylistDialog
import com.videothems.videoplayer.music.musicplayer.extensions.makeStatusBarTransparent
import com.videothems.videoplayer.music.musicplayer.extensions.setDrawBehindSystemBars
import com.videothems.videoplayer.music.musicplayer.extensions.setImmersiveFullscreen
import com.videothems.videoplayer.music.musicplayer.extensions.show
import com.videothems.videoplayer.music.musicplayer.extensions.surfaceColor
import com.videothems.videoplayer.music.musicplayer.fragments.albums.AlbumDetailsViewModel
import com.videothems.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.videothems.videoplayer.music.musicplayer.glide.RetroMusicColoredTarget
import com.videothems.videoplayer.music.musicplayer.glide.SingleColorTarget
import com.videothems.videoplayer.music.musicplayer.helper.MusicPlayerRemote
import com.videothems.videoplayer.music.musicplayer.interfaces.IAlbumClickListener
import com.videothems.videoplayer.music.musicplayer.interfaces.ICabCallback
import com.videothems.videoplayer.music.musicplayer.interfaces.ICabHolder
import com.videothems.videoplayer.music.musicplayer.model.Album
import com.videothems.videoplayer.music.musicplayer.model.Artist
import com.videothems.videoplayer.music.musicplayer.repository.RealRepository
import com.videothems.videoplayer.music.musicplayer.util.MusicUtil
import com.videothems.videoplayer.music.musicplayer.util.PreferenceUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.koin.android.ext.android.get
import org.koin.androidx.viewmodel.ext.android.viewModel
import org.koin.core.parameter.parametersOf

class AlbumDetalitActivity : BaseBindingActivity<ActivityAlbumDetalitBinding>(),
    IAlbumClickListener, ICabHolder,
    PopupMenu.OnMenuItemClickListener {


    private lateinit var simpleSongAdapter: SimpleSongAdapter
    private lateinit var album: Album
    private var albumArtistExists = false

    override fun initView() {
        super.initView()

        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        } else {
            setImmersiveFullscreen()
        }

        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext())
            .getString(IMAGE_THEME, "")

        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getInt(
            GENERAL_THEME, 0
        )

        val statusColor = PreferenceManager.getDefaultSharedPreferences(App.getContext())
            .getInt(STATUS_COLOR, -1)

        makeStatusBarTransparent()
//        if (editors == "theme_image") {
//            mBinding.root.background =
//                RetroGlideExtension.getUserImageTheme(this@AlbumDetalitActivity)
//        } else if (editors == "theme_gradient") {
//            mBinding.root.background =
//                AppCompatResources.getDrawable(this, RetroGlideExtension.getUserGradientTheme())
//        } else if (edit >= 0) {
//            mBinding.root.background = null
//            mBinding.root.backgroundColor = resolveColor(R.attr.mainBackgroundColor)
//        }

        showProgressDialog(mActivity, "Please wait...")

        val id = intent.getLongExtra(EXTRA_ALBUM_ID, 0)

        val detailsViewModel by viewModel<AlbumDetailsViewModel> {
            parametersOf(id)
        }

        addMusicServiceEventListener(detailsViewModel)

        detailsViewModel.getAlbum().observe(this) {
            showAlbum(it, detailsViewModel)
        }

        setupRecyclerView()
        setupMenu()

        mBinding.icBack.setOnClickListener(object :
            com.videothems.videoplayer.music.common.widgets.OnSingleClickListener() {
            override fun onSingleClick(v: View?) {
                onBackPressed()
            }

        })

        mBinding.fragmentAlbumContent.playAction.setOnClickListener {
            MusicPlayerRemote.openQueue(album.songs, 0, true)
        }
        mBinding.fragmentAlbumContent.shuffleAction.setOnClickListener {
            MusicPlayerRemote.openAndShuffleQueue(
                album.songs,
                true
            )
        }
        setNative()
    }

    private fun setNative() {
        if (isOnline) {
            mBinding.frameLayout.visibility = View.VISIBLE
            if (PrefsAds(this).isNative10() == "1") {
                val nativeADs = PreLoadNativeAds(this)
                nativeADs.showLoadingLayoutForNative(mBinding.frameLayout, NativeAdSize.Medium)
                App.nativeAdsFiles.observe(this) { native ->
                    if (native != null) {
                        nativeADs.showNative(mBinding.frameLayout, native, NativeAdSize.Medium)
                    } else {
                        if (nativeADs.checkAdsIsOn() && App.isNativeLoading)
                            mBinding.frameLayout.visibility = View.VISIBLE
                        else
                            mBinding.frameLayout.visibility = View.GONE
                    }
                }
            } else if (PrefsAds(this).isNative10() == "0") {
                BannerAds().loadAdmobBannerAds(
                    this, mBinding.frameLayout, ""
                )
            }
        } else {
            mBinding.frameLayout.visibility = View.GONE
        }
    }


    override fun getActivityContext(): FragmentActivity {
        return this@AlbumDetalitActivity
    }


    private fun setupMenu() {
        mBinding.ivOption.setOnClickListener {
            val wrapper = ContextThemeWrapper(mActivity, R.style.MaterialPopupMenuStyle)
            val popupMenu = PopupMenu(wrapper, it)
            popupMenu.setOnMenuItemClickListener(this)
            val menu = popupMenu.menu
            val sortOrder = menu.findItem(R.id.action_sort_order)
            sortOrder.isVisible = false
            val tag = menu.findItem(R.id.action_tag_editor)
            tag.isVisible = false
            popupMenu.inflate(R.menu.menu_album_detail)
            popupMenu.show()
        }
    }


    private fun setupRecyclerView() {
        simpleSongAdapter = SimpleSongAdapter(
            this,
            ArrayList(),
            R.layout.item_song,
            this
        )
        mBinding.fragmentAlbumContent.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@AlbumDetalitActivity)
            itemAnimator = DefaultItemAnimator()
            isNestedScrollingEnabled = false
            adapter = simpleSongAdapter
        }


    }

    private fun showAlbum(album: Album, detailsViewModel: AlbumDetailsViewModel) {

        this.album = album

        mBinding.albumTitle.text = album.title
        val songText = resources.getQuantityString(
            R.plurals.albumSongs,
            album.songCount,
            album.songCount
        )
        mBinding.albumYear.text = MusicUtil.getYearString(album.year)
        mBinding.fragmentAlbumContent.songTitle.text = songText
        if (MusicUtil.getYearString(album.year) == "-") {
            mBinding.albumText.text = if (albumArtistExists) album.albumArtist else album.artistName

        } else {
            mBinding.albumText.text = album.artistName
        }
        mBinding.albumlength.text =
            MusicUtil.getReadableDurationString(MusicUtil.getTotalDuration(album.songs))
        loadAlbumCover(album)
        simpleSongAdapter.swapDataSet(album.songs)
        if (albumArtistExists) {
            detailsViewModel.getAlbumArtist(album.albumArtist.toString())
                .observe(this@AlbumDetalitActivity) {
                    loadArtistImage(it, detailsViewModel)
                }
        } else {
            detailsViewModel.getArtist(album.artistId).observe(this) {
                loadArtistImage(it, detailsViewModel)
            }
        }

    }

    private fun loadAlbumCover(album: Album) {
        com.videothems.videoplayer.music.musicplayer.glide.GlideApp.with(this@AlbumDetalitActivity)
            .asBitmapPalette()
            .albumCoverOptions(album.safeGetFirstSong())
            //.checkIgnoreMediaStore()
            .load(RetroGlideExtension.getSongModel(album.safeGetFirstSong()))
            .into(object : SingleColorTarget(mBinding.image) {
                override fun onColorReady(color: Int) {
                    setColors(color)
                }
            })

        com.videothems.videoplayer.music.musicplayer.glide.GlideApp.with(this)
            .asBitmapPalette()
            .albumCoverOptions(album.safeGetFirstSong())
            .load(RetroGlideExtension.getSongModel(album.safeGetFirstSong()))
            .into(object : RetroMusicColoredTarget(mBinding.imgBlur) {
                override fun onColorReady(colors: com.videothems.videoplayer.music.musicplayer.util.color.MediaNotificationProcessor) {
                }
            })
    }

    private fun loadArtistImage(artist: Artist, detailsViewModel: AlbumDetailsViewModel) {
        detailsViewModel.getMoreAlbums(artist).observe(this@AlbumDetalitActivity) {
            moreAlbums(it)
        }
        val artists = artist.name.split(",", "&")
        val m = com.videothems.videoplayer.music.common.artistdatabase.ArtistDatabase.getInstance(
            mActivity
        )
        val image = m.artistDao().getArtist(artists[0])
        if (image != null) {
            com.videothems.videoplayer.music.musicplayer.glide.GlideApp.with(mActivity)
                .asBitmapPalette()
                .load(image.picture)
                .placeholder(R.drawable.default_artist_art)
                .transition(RetroGlideExtension.getDefaultTransition())
                .into(object : SingleColorTarget(mBinding.artistImage) {
                    override fun onColorReady(color: Int) {
                        setColors(color)
                    }
                })
        } else {
            com.videothems.videoplayer.music.musicplayer.glide.GlideApp.with(mActivity)
                .asBitmapPalette()
                .load(RetroGlideExtension.getArtistModel(artist))
                .artistImageOptions(artist)
                .transition(RetroGlideExtension.getDefaultTransition())
                .into(object : SingleColorTarget(mBinding.artistImage) {
                    override fun onColorReady(color: Int) {
                        setColors(color)
                    }
                })
        }
    }

    private fun moreAlbums(albums: List<Album>) {
        mBinding.fragmentAlbumContent.moreTitle.show()
        mBinding.fragmentAlbumContent.moreRecyclerView.show()
        mBinding.fragmentAlbumContent.moreTitle.text =
            String.format(getString(R.string.label_more_from), album.artistName)

        val albumAdapter = HorizontalAlbumAdapter(this@AlbumDetalitActivity, albums, this, this)
        mBinding.fragmentAlbumContent.moreRecyclerView.layoutManager = GridLayoutManager(
            this@AlbumDetalitActivity,
            1,
            GridLayoutManager.HORIZONTAL,
            false
        )
        mBinding.fragmentAlbumContent.moreRecyclerView.adapter = albumAdapter

    }

    private fun setColors(color: Int) {
        mBinding.fragmentAlbumContent.apply {
//            shuffleAction.applyColor(color)
//            playAction.applyOutlineColor(color)
        }
        hideProgressDialog()
    }

    override fun onAlbumClick(albumId: Long, view: View) {
        val intent = Intent(
            mActivity,
            com.videothems.videoplayer.music.musicplayer.activities.AlbumDetalitActivity::class.java
        )
        intent.putExtra(EXTRA_ALBUM_ID, albumId)
        launchActivity(intent)
    }

    private var cab: AttachedCab? = null
    override fun openCab(menuRes: Int, callback: ICabCallback): AttachedCab {
        cab?.let {
            if (it.isActive()) {
                it.destroy()
            }
        }
        cab = createCab(R.id.toolbar_container) {
            menu(menuRes)
            closeDrawable(R.drawable.ic_close)
            backgroundColor(
                literal = com.videothems.videoplayer.music.musicplayer.util.RetroColorUtil.shiftBackgroundColor(
                    surfaceColor()
                )
            )
            slideDown()
            onCreate { cab, menu -> callback.onCabCreated(cab, menu) }
            onSelection {
                callback.onCabItemClicked(it)
            }
            onDestroy { callback.onCabFinished(it) }
        }
        return cab as AttachedCab
    }

    override fun setBinding(): ActivityAlbumDetalitBinding {
        return ActivityAlbumDetalitBinding.inflate(layoutInflater)
    }

    override fun onMenuItemClick(item: MenuItem?): Boolean {
        val song = MusicPlayerRemote.currentSong
        when (item!!.itemId) {
            R.id.action_add_to_playlist -> {
                lifecycleScope.launch(Dispatchers.IO) {
                    val playlists = get<RealRepository>().fetchPlaylists()
                    withContext(Dispatchers.Main) {
                        AddToPlaylistDialog.create(playlists, song)
                            .show(supportFragmentManager, "ADD_PLAYLIST")
                    }
                }
                return true
            }
        }
        return false
    }
}