package com.videothems.videoplayer.music.common.cropper


import android.Manifest
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.view.View
import androidx.appcompat.content.res.AppCompatResources
import androidx.fragment.app.FragmentActivity
import androidx.preference.PreferenceManager
import com.videothems.videoplayer.music.R
import com.videothems.videoplayer.music.common.base.BaseBindingActivity
import com.videothems.videoplayer.music.common.cropper.CropImageView.OnCropImageCompleteListener
import com.videothems.videoplayer.music.common.cropper.CropImageView.OnSetImageUriCompleteListener
import com.videothems.videoplayer.music.databinding.ActivityCropBinding
import com.videothems.videoplayer.music.musicplayer.App
import com.videothems.videoplayer.music.musicplayer.GENERAL_THEME
import com.videothems.videoplayer.music.musicplayer.IMAGE_THEME
import com.videothems.videoplayer.music.musicplayer.STATUS_COLOR
import com.videothems.videoplayer.music.musicplayer.extensions.makeStatusBarTransparent
import com.videothems.videoplayer.music.musicplayer.extensions.resolveColor
import com.videothems.videoplayer.music.musicplayer.extensions.setDrawBehindSystemBars
import com.videothems.videoplayer.music.musicplayer.extensions.setImmersiveFullscreen
import com.videothems.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.videothems.videoplayer.music.musicplayer.util.PreferenceUtil
import com.videothems.videoplayer.music.videoplayer.model.VideoData
import org.jetbrains.anko.backgroundColor
import java.io.File
import java.io.IOException


open class CropActivity : BaseBindingActivity<ActivityCropBinding>(), OnSetImageUriCompleteListener,
    OnCropImageCompleteListener {


    private var mCropImageUri: Uri? = null
    private var mOptions: com.videothems.videoplayer.music.common.cropper.CropImageOptions? = null

    companion object {
        var mVideoData: ArrayList<VideoData> = ArrayList()
    }

    override fun getActivityContext(): FragmentActivity {
        return this@CropActivity
    }

    override fun setBinding(): ActivityCropBinding {
        return ActivityCropBinding.inflate(layoutInflater)
    }

    override fun initView() {
        super.initView()

        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        } else {
            setImmersiveFullscreen()
        }

        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext())
            .getString(IMAGE_THEME, "")
        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getInt(
            GENERAL_THEME, 0
        )

        val statusColor = PreferenceManager.getDefaultSharedPreferences(App.getContext())
            .getInt(STATUS_COLOR, -1)

        makeStatusBarTransparent()
        if (editors == "theme_image") {
            mBinding.root.background = RetroGlideExtension.getUserImageTheme(this@CropActivity)
            mBinding.constraintLayout.background = null
        } else if (editors == "theme_gradient") {
            mBinding.root.background =
                AppCompatResources.getDrawable(this, RetroGlideExtension.getUserGradientTheme())
            mBinding.constraintLayout.background = null
        } else if (edit >= 0) {
            mBinding.root.background = null
            mBinding.root.backgroundColor = resolveColor(R.attr.mainBackgroundColor)
        }
    }

    override fun initViewAction() {
        super.initViewAction()
        val bundle = intent.getBundleExtra(com.videothems.videoplayer.music.common.cropper.CropImage.CROP_IMAGE_EXTRA_BUNDLE)
        mCropImageUri = bundle!!.getParcelable(com.videothems.videoplayer.music.common.cropper.CropImage.CROP_IMAGE_EXTRA_SOURCE)
        mOptions = bundle.getParcelable(com.videothems.videoplayer.music.common.cropper.CropImage.CROP_IMAGE_EXTRA_OPTIONS)
        if (mCropImageUri == null || mCropImageUri == Uri.EMPTY) {
            if (com.videothems.videoplayer.music.common.cropper.CropImage.isExplicitCameraPermissionRequired(this)) {
                // request permissions and handle the result in onRequestPermissionsResult()
                requestPermissions(
                    arrayOf(Manifest.permission.CAMERA),
                    com.videothems.videoplayer.music.common.cropper.CropImage.CAMERA_CAPTURE_PERMISSIONS_REQUEST_CODE
                )
            } else {
                com.videothems.videoplayer.music.common.cropper.CropImage.startPickImageActivity(this)
            }
        } else if (com.videothems.videoplayer.music.common.cropper.CropImage.isReadExternalStoragePermissionsRequired(this, mCropImageUri!!)) {
            // request permissions and handle the result in onRequestPermissionsResult()
            requestPermissions(
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                com.videothems.videoplayer.music.common.cropper.CropImage.PICK_IMAGE_PERMISSIONS_REQUEST_CODE
            )
        } else {
            // no permissions required or already grunted, can start crop image activity
            mBinding.cropImageView.setImageUriAsync(mCropImageUri)
        }

        val title =
            if (mOptions != null && mOptions!!.activityTitle != null && mOptions!!.activityTitle.isNotEmpty()) mOptions!!.activityTitle else resources.getString(
                R.string.app_name
            )
        mBinding.tvTitle.text = title
    }

    override fun onBackPressed() {
        super.onBackPressed()
        setResultCancel()
    }

    override fun initViewListener() {
        super.initViewListener()
        mBinding.ivBack.setOnClickListener(this)
        mBinding.ivCrop.setOnClickListener(this)
        mBinding.llRotate.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        super.onClick(v)
        when (v.id) {
            R.id.iv_back -> {
                onBackPressed()
            }

            R.id.iv_crop -> {
                cropImage()
            }

            R.id.ll_rotate -> {
                rotateImage(mOptions!!.rotationDegrees)
            }
        }
    }


    override fun onStart() {
        super.onStart()
        mBinding.cropImageView.setOnSetImageUriCompleteListener(this)
        mBinding.cropImageView.setOnCropImageCompleteListener(this)
    }

    override fun onStop() {
        super.onStop()
        mBinding.cropImageView.setOnSetImageUriCompleteListener(null)
        mBinding.cropImageView.setOnCropImageCompleteListener(null)
    }

    private fun setResult(uri: Uri?, error: Exception?, sampleSize: Int) {
        val resultCode =
            if (error == null) RESULT_OK else com.videothems.videoplayer.music.common.cropper.CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE
        setResult(resultCode, getResultIntent(uri, error, sampleSize))
        finish()
    }

    // region: Private methods
    private fun cropImage() {
        if (mOptions!!.noOutputImage) {
            setResult(null, null, 1)
        } else {
            val outputUri: Uri = getOutputUri()
            mBinding.cropImageView.saveCroppedImageAsync(
                outputUri,
                mOptions!!.outputCompressFormat,
                mOptions!!.outputCompressQuality,
                mOptions!!.outputRequestWidth,
                mOptions!!.outputRequestHeight,
                mOptions!!.outputRequestSizeOptions
            )
        }
    }

    /**
     * Rotate the image in the crop image view.
     */

    private fun rotateImage(degrees: Int) {
        mBinding.cropImageView.rotateImage(degrees)
    }

    protected fun getOutputUri(): Uri {
        var outputUri = mOptions!!.outputUri
        if (outputUri == null || outputUri == Uri.EMPTY) {
            outputUri = try {
                val ext =
                    if (mOptions!!.outputCompressFormat == Bitmap.CompressFormat.JPEG) ".jpg" else if (mOptions!!.outputCompressFormat == Bitmap.CompressFormat.PNG) ".png" else ".webp"
                Uri.fromFile(
                    File.createTempFile(
                        "cropped", ext,
                        cacheDir
                    )
                )
            } catch (e: IOException) {
                throw RuntimeException("Failed to create temp file for output image", e)
            }
        }
        return outputUri
    }

    private fun setResultCancel() {
        setResult(RESULT_CANCELED)
        finish()
    }

    private fun getResultIntent(
        uri: Uri?,
        error: java.lang.Exception?,
        sampleSize: Int
    ): Intent {
        val result = com.videothems.videoplayer.music.common.cropper.CropImage.ActivityResult(
            mBinding.cropImageView.imageUri,
            uri,
            error,
            mBinding.cropImageView.cropPoints,
            mBinding.cropImageView.cropRect,
            mBinding.cropImageView.rotatedDegrees,
            mBinding.cropImageView.wholeImageRect,
            sampleSize
        )
        val intent = Intent()
        intent.putExtras(getIntent())
        intent.putExtra(com.videothems.videoplayer.music.common.cropper.CropImage.CROP_IMAGE_EXTRA_RESULT, result)
        return intent
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        // handle result of pick image chooser
        if (requestCode == com.videothems.videoplayer.music.common.cropper.CropImage.PICK_IMAGE_CHOOSER_REQUEST_CODE) {
            if (resultCode == RESULT_CANCELED) {
                // User cancelled the picker. We don't have anything to crop
                setResultCancel()
            }
            if (resultCode == RESULT_OK) {
                mCropImageUri = com.videothems.videoplayer.music.common.cropper.CropImage.getPickImageResultUri(this, data)

                // For API >= 23 we need to check specifically that we have permissions to read external
                // storage.
                if (com.videothems.videoplayer.music.common.cropper.CropImage.isReadExternalStoragePermissionsRequired(this, mCropImageUri!!)) {
                    // request permissions and handle the result in onRequestPermissionsResult()
                    requestPermissions(
                        arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                        com.videothems.videoplayer.music.common.cropper.CropImage.PICK_IMAGE_PERMISSIONS_REQUEST_CODE
                    )
                } else {
                    // no permissions required or already grunted, can start crop image activity
                    mBinding.cropImageView.setImageUriAsync(mCropImageUri)
                }
            }
        }

    }

    override fun onSetImageUriComplete(
        view: com.videothems.videoplayer.music.common.cropper.CropImageView?,
        uri: Uri?,
        error: java.lang.Exception?
    ) {

        if (error == null) {
            if (mOptions?.initialCropWindowRectangle != null) {
                mBinding.cropImageView.cropRect = mOptions!!.initialCropWindowRectangle
            }
            if (mOptions?.initialRotation!! > -1) {
                mBinding.cropImageView.rotatedDegrees = mOptions!!.initialRotation
            }
        } else {
            setResult(null, error, 1)
        }
    }

    override fun onCropImageComplete(view: com.videothems.videoplayer.music.common.cropper.CropImageView?, result: com.videothems.videoplayer.music.common.cropper.CropImageView.CropResult?) {
        setResult(result!!.uri, result.error, result.sampleSize)
    }

}