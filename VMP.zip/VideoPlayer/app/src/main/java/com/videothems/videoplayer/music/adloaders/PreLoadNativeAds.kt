package com.videothems.videoplayer.music.adloaders

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import com.facebook.shimmer.ShimmerFrameLayout
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import com.videothems.videoplayer.music.R
import com.videothems.videoplayer.music.common.utils.isOnline
import com.videothems.videoplayer.music.musicplayer.App
import com.videothems.videoplayer.music.musicplayer.App.Companion.isNativeLoading

class PreLoadNativeAds(var context: Context) {

    private val TAG = PreLoadNativeAds::class.java.simpleName

    fun loadNative(
        onNativeLoadListener: (nativeAd: NativeAd?) -> Unit
    ) {
        if (PrefsAds(context).isNativeAdEnable && context.isOnline) {
            loadNativeId(onNativeLoadListener)
        } else {
            isNativeLoading = false
            Log.e(TAG, "NativeTag is not show ")
            onNativeLoadListener(null)
        }
    }

    fun loadNativeId(
        onNativeLoadListener: (nativeAd: NativeAd?) -> Unit,
        isSecId: Boolean = false
    ) {
        isNativeLoading = true
        val adLoader = AdLoader.Builder(
            context,
            if (isSecId) context.getString(R.string.admob_native) else context.getString(R.string.admob_native_2)
        )
            .forNativeAd { nativeAd: NativeAd ->
                Log.e(TAG, "NativeTag is Loaded ")
                // Show the ad.
                isNativeLoading = false
                onNativeLoadListener(nativeAd)
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    Log.e(
                        TAG,
                        "NativeTag onAdFailedToLoad code--> ${adError.code} message--> ${adError.message} "
                    )
                    if (isSecId) {
                        isNativeLoading = false
                        onNativeLoadListener(null)
                    } else
                        loadNativeId(onNativeLoadListener, true)
                }

                override fun onAdClicked() {
                    super.onAdClicked()
                    App.isOpenAdHide = true
                }
            })
            .withNativeAdOptions(
                NativeAdOptions.Builder()
                    // Methods in the NativeAdOptions.Builder class can be
                    // used here to specify individual options settings.
                    .build()
            ).build()

        adLoader.loadAd(AdRequest.Builder().build())
    }

    fun showLoadingLayoutForNative(frameLayout: FrameLayout, adSize: NativeAdSize) {
        if (context.isOnline && PrefsAds(context).isNativeAdEnable) {
            val nativeAdLoading: FrameLayout = if (adSize === NativeAdSize.Small) {
                LayoutInflater.from(context)
                    .inflate(R.layout.loading_native_banner, null, false) as FrameLayout
            } else if (adSize === NativeAdSize.Medium) {
                LayoutInflater.from(context)
                    .inflate(R.layout.small_native_layout, null, false) as FrameLayout
            } else if (adSize === NativeAdSize.Big) {
                LayoutInflater.from(context)
                    .inflate(R.layout.small_native_layout, null, false) as FrameLayout
            } else {
                LayoutInflater.from(context)
                    .inflate(R.layout.loading_native_banner, null, false) as FrameLayout
            }
            val shimmerFrameLayout =
                nativeAdLoading.findViewById<ShimmerFrameLayout>(R.id.shimmer_view_container)
            shimmerFrameLayout.startLayoutAnimation()
            frameLayout.visibility = View.VISIBLE
            frameLayout.addView(nativeAdLoading)
        }
    }

    fun checkAdsIsOn(): Boolean = PrefsAds(context).isNativeAdEnable

    fun showNative(frameLayout: FrameLayout, nativeAd: NativeAd, adSize: NativeAdSize) {
        if (context.isOnline && PrefsAds(context).isNativeAdEnable && nativeAd != null) {
            val nativeAdView: NativeAdView = if (adSize === NativeAdSize.Small) {
                LayoutInflater.from(context)
                    .inflate(R.layout.admob_native_tt_small, null, false) as NativeAdView
            } else if (adSize === NativeAdSize.Medium) {
                LayoutInflater.from(context)
                    .inflate(R.layout.admob_native_tt_small_h, null, false) as NativeAdView
            } else if (adSize === NativeAdSize.Big) {
                LayoutInflater.from(context)
                    .inflate(R.layout.admob_native_tt_small_h, null, false) as NativeAdView
            } else {
                LayoutInflater.from(context)
                    .inflate(R.layout.admob_native_tt_small, null, false) as NativeAdView
            }

            populateUnifiedNativeAdView(nativeAd, nativeAdView, true)
            frameLayout.removeAllViews()
            frameLayout.addView(nativeAdView)
            frameLayout.visibility = View.VISIBLE
        } else {
            frameLayout.visibility = View.GONE
        }
    }

    private fun populateUnifiedNativeAdView(
        nativeAd: NativeAd,
        adView: NativeAdView,
        isMediaViewHide: Boolean
    ): NativeAdView {

        val headline = adView.findViewById(R.id.ad_headline) as TextView
        headline.text = nativeAd.headline
        adView.headlineView = headline

        val bodyText = adView.findViewById(R.id.ad_body) as TextView
        bodyText.text = nativeAd.body
        adView.bodyView = bodyText

        val addon = adView.findViewById(R.id.ad_app_icon) as ImageView
        addon.setImageDrawable(nativeAd.icon?.drawable)
        adView.iconView = addon

        val adCallToAction = adView.findViewById(R.id.ad_call_to_action) as TextView
        adCallToAction.text = nativeAd.callToAction
        adView.callToActionView = adCallToAction

        val relativeLayout = adView.findViewById<RelativeLayout>(R.id.iv_relative)
        if (isMediaViewHide) {
            relativeLayout.visibility = View.GONE
        } else {
            val mediaView = adView.findViewById<MediaView>(R.id.ad_media)
            adView.mediaView = mediaView
            relativeLayout.visibility = View.VISIBLE
        }

        adView.setNativeAd((nativeAd))
        return adView
    }

}