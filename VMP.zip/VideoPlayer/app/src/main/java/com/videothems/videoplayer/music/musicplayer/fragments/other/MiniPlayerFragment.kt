package com.videothems.videoplayer.music.musicplayer.fragments.other

import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import com.videothems.videoplayer.music.R
import com.videothems.videoplayer.music.databinding.FragmentMiniPlayerBinding
import com.videothems.videoplayer.music.musicplayer.extensions.show
import com.videothems.videoplayer.music.musicplayer.fragments.base.AbsMusicServiceFragment
import com.videothems.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.videothems.videoplayer.music.musicplayer.helper.MusicPlayerRemote
import com.videothems.videoplayer.music.musicplayer.helper.MusicProgressViewUpdateHelper
import com.videothems.videoplayer.music.musicplayer.helper.PlayPauseButtonOnClickHandler
import com.videothems.videoplayer.music.musicplayer.util.PreferenceUtil
import kotlin.math.abs

open class MiniPlayerFragment : AbsMusicServiceFragment(R.layout.fragment_mini_player),
    MusicProgressViewUpdateHelper.Callback, View.OnClickListener {

    private var _binding: FragmentMiniPlayerBinding? = null
    private val binding get() = _binding!!
    private lateinit var progressViewUpdateHelper: MusicProgressViewUpdateHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        progressViewUpdateHelper = MusicProgressViewUpdateHelper(this)
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.actionNext -> MusicPlayerRemote.playNextSong()
            R.id.actionPrevious -> MusicPlayerRemote.back()
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentMiniPlayerBinding.bind(view)
        view.setOnTouchListener(FlingPlayBackController(requireContext()))
        setUpMiniPlayer()

        if (com.videothems.videoplayer.music.musicplayer.util.RetroUtil.isTablet()) {
            binding.actionNext.show()
            binding.actionPrevious.show()
        } else {
            binding.actionNext.visibility =
                if (PreferenceUtil.isExtraControls) View.VISIBLE else View.GONE
            binding.actionPrevious.visibility =
                if (PreferenceUtil.isExtraControls) View.VISIBLE else View.GONE
        }
        binding.actionNext.setOnClickListener(this)
        binding.actionPrevious.setOnClickListener(this)
    }

    private fun setUpMiniPlayer() {
        setUpPlayPauseButton()
    }

    private fun setUpPlayPauseButton() {
        binding.miniPlayerPlayPauseButton.setOnClickListener(PlayPauseButtonOnClickHandler())
    }

    private fun updateSongTitle() {
        val song = MusicPlayerRemote.currentSong
        if (song.id <= 0) {
            Log.e("MiniPlayerFragment", "updateSongTitle.001")
            binding.root.visibility = View.GONE
        } else {
            Log.e("MiniPlayerFragment", "updateSongTitle.002")
            binding.root.visibility = View.VISIBLE
        }
        Log.e("MiniPlayerFragment", "updateSongTitle:" + song.id)
        val title = song.title
        val subTitle = song.artistName
        binding.miniPlayerTitle.text = title
        binding.miniPlayerTitle.isSelected = true
        binding.miniPlayerSubTitle.text = subTitle
        binding.miniPlayerSubTitle.isSelected = true
    }

    private fun updateSongCover() {
        try {
            val song = MusicPlayerRemote.currentSong
            com.videothems.videoplayer.music.musicplayer.glide.GlideApp.with(requireContext())
                .asBitmap()
                .songCoverOptions(song)
                .transition(RetroGlideExtension.getDefaultTransition())
                .load(RetroGlideExtension.getSongModel(song))
                .into(binding.image)
        } catch (_: Exception) {
        }

    }

    override fun onServiceConnected() {
        updateSongTitle()
        updateSongCover()
        updatePlayPauseDrawableState()
    }

    override fun onPlayingMetaChanged() {
        updateSongTitle()
        updateSongCover()
    }

    override fun onPlayStateChanged() {
        updatePlayPauseDrawableState()
    }

    override fun onUpdateProgressViews(progress: Int, total: Int) {
        binding.progressBar.max = total
        val animator = ObjectAnimator.ofInt(binding.progressBar, "progress", progress)
        animator.duration = 1000
        animator.interpolator = DecelerateInterpolator()
        animator.start()
    }

    override fun onResume() {
        super.onResume()
        progressViewUpdateHelper.start()
    }

    override fun onPause() {
        super.onPause()
        progressViewUpdateHelper.stop()
    }

    protected fun updatePlayPauseDrawableState() {
        if (MusicPlayerRemote.isPlaying) {
            binding.miniPlayerPlayPauseButton.setImageResource(R.drawable.ic_play_white_64dp)
        } else {
            binding.miniPlayerPlayPauseButton.setImageResource(R.drawable.ic_pause_white_64dp)
        }
    }

    class FlingPlayBackController(context: Context) : View.OnTouchListener {

        private var flingPlayBackController = GestureDetector(context,
            object : GestureDetector.SimpleOnGestureListener() {
                override fun onFling(
                    e1: MotionEvent?,
                    e2: MotionEvent,
                    velocityX: Float,
                    velocityY: Float
                ): Boolean {
                    if (abs(velocityX) > abs(velocityY)) {
                        if (velocityX < 0) {
                            MusicPlayerRemote.playNextSong()
                            return true
                        } else if (velocityX > 0) {
                            MusicPlayerRemote.playPreviousSong()
                            return true
                        }
                    }
                    return false
                }
            })

        @SuppressLint("ClickableViewAccessibility")
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            return flingPlayBackController.onTouchEvent(event)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
