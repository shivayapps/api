package com.videothems.videoplayer.music.common.activity

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.content.SharedPreferences
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.MediaStore
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.animation.doOnEnd
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isGone
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.commit
import androidx.lifecycle.lifecycleScope
import androidx.preference.PreferenceManager
import code.name.monkey.appthemehelper.util.VersionUtils
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.videothems.videoplayer.music.R
import com.videothems.videoplayer.music.common.base.BaseBindingActivity
import com.videothems.videoplayer.music.databinding.ActivityOutMusicBinding
import com.videothems.videoplayer.music.musicplayer.App
import com.videothems.videoplayer.music.musicplayer.GENERAL_THEME
import com.videothems.videoplayer.music.musicplayer.IMAGE_THEME
import com.videothems.videoplayer.music.musicplayer.db.toPlayCount
import com.videothems.videoplayer.music.musicplayer.extensions.dip
import com.videothems.videoplayer.music.musicplayer.extensions.drawAboveSystemBarsWithPadding
import com.videothems.videoplayer.music.musicplayer.extensions.isColorLight
import com.videothems.videoplayer.music.musicplayer.extensions.keepScreenOn
import com.videothems.videoplayer.music.musicplayer.extensions.makeStatusBarTransparent
import com.videothems.videoplayer.music.musicplayer.extensions.peekHeightAnimate
import com.videothems.videoplayer.music.musicplayer.extensions.resolveColor
import com.videothems.videoplayer.music.musicplayer.extensions.safeGetBottomInsets
import com.videothems.videoplayer.music.musicplayer.extensions.setDrawBehindSystemBars
import com.videothems.videoplayer.music.musicplayer.extensions.setImmersiveFullscreen
import com.videothems.videoplayer.music.musicplayer.extensions.setLightNavigationBar
import com.videothems.videoplayer.music.musicplayer.extensions.setLightNavigationBarAuto
import com.videothems.videoplayer.music.musicplayer.extensions.setNavigationBarColorPreOreo
import com.videothems.videoplayer.music.musicplayer.extensions.setTaskDescriptionColor
import com.videothems.videoplayer.music.musicplayer.extensions.surfaceColor
import com.videothems.videoplayer.music.musicplayer.extensions.whichFragment
import com.videothems.videoplayer.music.musicplayer.fragments.LibraryViewModel
import com.videothems.videoplayer.music.musicplayer.fragments.NowPlayingScreen
import com.videothems.videoplayer.music.musicplayer.fragments.base.AbsPlayerFragment
import com.videothems.videoplayer.music.musicplayer.fragments.other.MiniPlayerFragment
import com.videothems.videoplayer.music.musicplayer.fragments.player.adaptive.AdaptiveFragment
import com.videothems.videoplayer.music.musicplayer.fragments.player.blur.BlurPlayerFragment
import com.videothems.videoplayer.music.musicplayer.fragments.player.card.CardFragment
import com.videothems.videoplayer.music.musicplayer.fragments.player.cardblur.CardBlurFragment
import com.videothems.videoplayer.music.musicplayer.fragments.player.circle.CirclePlayerFragment
import com.videothems.videoplayer.music.musicplayer.fragments.player.classic.ClassicPlayerFragment
import com.videothems.videoplayer.music.musicplayer.fragments.player.color.ColorFragment
import com.videothems.videoplayer.music.musicplayer.fragments.player.fit.FitFragment
import com.videothems.videoplayer.music.musicplayer.fragments.player.flat.FlatPlayerFragment
import com.videothems.videoplayer.music.musicplayer.fragments.player.full.FullPlayerFragment
import com.videothems.videoplayer.music.musicplayer.fragments.player.gradient.GradientPlayerFragment
import com.videothems.videoplayer.music.musicplayer.fragments.player.material.MaterialFragment
import com.videothems.videoplayer.music.musicplayer.fragments.player.normal.PlayerFragment
import com.videothems.videoplayer.music.musicplayer.fragments.player.plain.PlainPlayerFragment
import com.videothems.videoplayer.music.musicplayer.fragments.player.simple.SimplePlayerFragment
import com.videothems.videoplayer.music.musicplayer.fragments.player.tiny.TinyPlayerFragment
import com.videothems.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.videothems.videoplayer.music.musicplayer.helper.MusicPlayerRemote
import com.videothems.videoplayer.music.musicplayer.helper.SearchQueryHelper.getSongs
import com.videothems.videoplayer.music.musicplayer.model.Song
import com.videothems.videoplayer.music.musicplayer.repository.PlaylistSongsLoader
import com.videothems.videoplayer.music.musicplayer.service.MusicService
import com.videothems.videoplayer.music.musicplayer.util.PreferenceUtil
import com.videothems.videoplayer.music.musicplayer.util.ViewUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.jetbrains.anko.backgroundColor
import org.koin.androidx.viewmodel.ext.android.viewModel
import java.lang.ref.WeakReference

open class OutMusicActivity : BaseBindingActivity<ActivityOutMusicBinding>(),
    SharedPreferences.OnSharedPreferenceChangeListener {

    private lateinit var bottomSheetBehavior: com.videothems.videoplayer.music.musicplayer.RetroBottomSheetBehavior<FrameLayout>
    private val argbEvaluator: ArgbEvaluator = ArgbEvaluator()
    private var playerFragment: AbsPlayerFragment? = null
    private var miniPlayerFragment: MiniPlayerFragment? = null
    private var nowPlayingScreen: NowPlayingScreen? = null
    private var navigationBarColor = 0
    private var taskColor: Int = 0
    private var paletteColor: Int = Color.WHITE
    private val panelState: Int get() = bottomSheetBehavior.state
    private var navigationBarColorAnimator: ValueAnimator? = null
    private val libraryViewModel by viewModel<LibraryViewModel>()

    private var windowInsets: WindowInsetsCompat? = null

    private var isPause = false

    private val bottomSheetCallbackList = object : BottomSheetBehavior.BottomSheetCallback() {

        override fun onSlide(bottomSheet: View, slideOffset: Float) {
            setMiniPlayerAlphaProgress(slideOffset)
            navigationBarColorAnimator?.cancel()
            setNavigationBarColorPreOreo(
                argbEvaluator.evaluate(
                    slideOffset,
                    surfaceColor(),
                    navigationBarColor
                ) as Int
            )
        }

        override fun onStateChanged(bottomSheet: View, newState: Int) {
            when (newState) {
                BottomSheetBehavior.STATE_EXPANDED -> {
                    onPanelExpanded()
                    if (PreferenceUtil.lyricsScreenOn && PreferenceUtil.showLyrics) {
                        keepScreenOn(true)
                    }
                }

                BottomSheetBehavior.STATE_COLLAPSED -> {
                    onPanelCollapsed()
                    if ((PreferenceUtil.lyricsScreenOn && PreferenceUtil.showLyrics) || !PreferenceUtil.isScreenOnEnabled) {
                        keepScreenOn(false)
                    }
                }

                BottomSheetBehavior.STATE_SETTLING, BottomSheetBehavior.STATE_DRAGGING -> {
                    collapsePanel()
                }

                else -> {
                    println("Do a flip")
                }
            }
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(R.anim.slide_from_top, R.anim.slide_in_top)
    }

    override fun getActivityContext(): FragmentActivity {
        return this@OutMusicActivity
    }

    override fun setBinding(): ActivityOutMusicBinding {
        return ActivityOutMusicBinding.inflate(layoutInflater)
    }

    override fun initView() {
        super.initView()

        PreferenceUtil.registerOnSharedPreferenceChangedListener(this)

        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        } else {
            setImmersiveFullscreen()
        }

        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            IMAGE_THEME, ""
        )

        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getInt(
            GENERAL_THEME, 0
        )

        makeStatusBarTransparent()

        if (editors == "theme_image") {
            mBinding.root.background = RetroGlideExtension.getUserImageTheme(this@OutMusicActivity)
        } else if (editors == "theme_gradient") {
            mBinding.root.background =
                AppCompatResources.getDrawable(this, RetroGlideExtension.getUserGradientTheme())
        } else if (edit >= 0) {
            mBinding.root.background = null
            mBinding.root.backgroundColor = resolveColor(R.attr.mainBackgroundColor)
        }

        serviceToken = MusicPlayerRemote.bindToService(this, object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName, service: IBinder) {
                onServiceConnected()
            }

            override fun onServiceDisconnected(name: ComponentName) {
                onServiceDisconnected()
            }
        })

        chooseFragmentForTheme()
        setupSlidingUpPanel()
        setupBottomSheet()
        updateColor()

        ViewCompat.setOnApplyWindowInsetsListener(
            mBinding.root
        ) { _, insets ->
            windowInsets = insets
            insets
        }

        if (com.videothems.videoplayer.music.musicplayer.util.RetroUtil.isLandscape()) {
            mBinding.slidingPanel.drawAboveSystemBarsWithPadding()
        }

        navigationBarColor = surfaceColor()

        setBottomNavVisibility(visible = true, animate = true)
        expandPanel()

    }

    private var isInOneTabMode = false

    private fun setBottomNavVisibility(
        visible: Boolean = true,
        animate: Boolean = false,
        hideBottomSheet: Boolean = MusicPlayerRemote.playingQueue.isEmpty()
    ) {
        if (isInOneTabMode) {
            return
        }
        hideBottomSheet(hide = hideBottomSheet, animate = animate, isBottomNavVisible = visible)
    }

    private fun hideBottomSheet(
        hide: Boolean,
        animate: Boolean = false,
        isBottomNavVisible: Boolean = false
    ) {
        val heightOfBar =
            if (MusicPlayerRemote.isCasting) dip(R.dimen.cast_mini_player_height) else dip(R.dimen.mini_player_height)
        val heightOfBarWithTabs = heightOfBar + 0
        if (hide) {
            bottomSheetBehavior.peekHeight = -windowInsets.safeGetBottomInsets()
            bottomSheetBehavior.state = BottomSheetBehavior.STATE_COLLAPSED
        } else {
            if (MusicPlayerRemote.playingQueue.isNotEmpty()) {
                mBinding.slidingPanel.elevation = 0F

                if (isBottomNavVisible) {

                    if (animate) {
                        bottomSheetBehavior.peekHeightAnimate(heightOfBarWithTabs)
                    } else {
                        bottomSheetBehavior.peekHeight = heightOfBarWithTabs
                    }

                } else {

                    if (animate) {
                        bottomSheetBehavior.peekHeightAnimate(heightOfBar).doOnEnd {
                            mBinding.slidingPanel.bringToFront()
                        }
                    } else {
                        bottomSheetBehavior.peekHeight = heightOfBar
                        mBinding.slidingPanel.bringToFront()
                    }
                }
            }
        }
    }

    private fun setupSlidingUpPanel() {

        mBinding.slidingPanel.viewTreeObserver.addOnGlobalLayoutListener(object :
            ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                mBinding.slidingPanel.viewTreeObserver.removeOnGlobalLayoutListener(this)
                val params = mBinding.slidingPanel.layoutParams as ViewGroup.LayoutParams
                params.height = ViewGroup.LayoutParams.MATCH_PARENT
                mBinding.slidingPanel.layoutParams = params
                when (panelState) {
                    BottomSheetBehavior.STATE_EXPANDED -> onPanelExpanded()
                    BottomSheetBehavior.STATE_COLLAPSED -> onPanelCollapsed()
                    else -> {
                        // playerFragment!!.onHide()
                    }
                }
            }
        })
    }

    open fun onPanelCollapsed() {
        setMiniPlayerAlphaProgress(0F)
        animateNavigationBarColor(surfaceColor())
        setLightNavigationBarAuto()
        setTaskDescriptionColor(taskColor)
        playerFragment?.onHide()

    }

    private fun updateColor() {
        libraryViewModel.paletteColor.observe(this) { color ->
            this.paletteColor = color
            onPaletteColorChanged()
        }
    }

    open fun onPanelExpanded() {
        setMiniPlayerAlphaProgress(1F)
        onPaletteColorChanged()
        playerFragment?.onShow()
    }


    private fun setupBottomSheet() {
        bottomSheetBehavior =
            BottomSheetBehavior.from(mBinding.slidingPanel) as com.videothems.videoplayer.music.musicplayer.RetroBottomSheetBehavior<FrameLayout>
        bottomSheetBehavior.addBottomSheetCallback(bottomSheetCallbackList)
        bottomSheetBehavior.isHideable = false
        bottomSheetBehavior.setAllowDragging(true)
        setMiniPlayerAlphaProgress(0F)
    }

    override fun onResume() {
        super.onResume()
        if (bottomSheetBehavior.state == BottomSheetBehavior.STATE_EXPANDED) {
            setMiniPlayerAlphaProgress(1f)
        }
        if (isPause) {
            isPause = false
            if (MusicPlayerRemote.playingQueue.isEmpty()) {
                onBackPressedDispatcher.onBackPressed()
            }
        }

    }

    override fun onPause() {
        super.onPause()
        isPause = true
    }

    private fun setMiniPlayerAlphaProgress(progress: Float) {
        if (progress < 0) return
        val alpha = 1 - progress
        miniPlayerFragment?.view?.alpha = 1 - (progress / 0.2F)
        miniPlayerFragment?.view?.isGone = alpha == 0f
        mBinding.playerFragmentContainer.alpha = (progress - 0.2F) / 0.2F
    }

    private fun chooseFragmentForTheme() {
        nowPlayingScreen = PreferenceUtil.nowPlayingScreen

        val fragment: Fragment = when (nowPlayingScreen) {
            NowPlayingScreen.Adaptive -> AdaptiveFragment()//working
            NowPlayingScreen.Blur -> BlurPlayerFragment()//working
            NowPlayingScreen.BlurCard -> CardBlurFragment()//working
            NowPlayingScreen.Card -> CardFragment()//working
            NowPlayingScreen.Circle -> CirclePlayerFragment()//working
            NowPlayingScreen.Classic -> ClassicPlayerFragment()//working
            NowPlayingScreen.Color -> ColorFragment()//working
            NowPlayingScreen.Fit -> FitFragment()//working
            NowPlayingScreen.Flat -> FlatPlayerFragment()//working
            NowPlayingScreen.Full -> FullPlayerFragment()//working
            NowPlayingScreen.Material -> MaterialFragment()//
            NowPlayingScreen.Normal -> PlayerFragment()//working
            NowPlayingScreen.Plain -> PlainPlayerFragment()//
            NowPlayingScreen.Simple -> SimplePlayerFragment()//
            NowPlayingScreen.Gradient -> GradientPlayerFragment()//
            NowPlayingScreen.Tiny -> TinyPlayerFragment()
            else -> PlayerFragment()
        }
        supportFragmentManager.commit {
            replace(R.id.playerFragmentContainer, fragment)
        }

        playerFragment = whichFragment<AbsPlayerFragment>(R.id.playerFragmentContainer)
        miniPlayerFragment = whichFragment<MiniPlayerFragment>(R.id.miniPlayerFragment)
        miniPlayerFragment?.view?.setOnClickListener {
            expandPanel()
        }
    }


    fun collapsePanel() {
        onBackPressedDispatcher.onBackPressed()
    }

    fun expandPanel() {
        bottomSheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED
    }

    private fun setTaskDescColor(color: Int) {
        taskColor = color
        if (panelState == BottomSheetBehavior.STATE_COLLAPSED) {
            setTaskDescriptionColor(color)
        }
    }

    private fun onPaletteColorChanged() {
        if (panelState == BottomSheetBehavior.STATE_EXPANDED) {
            navigationBarColor = surfaceColor()
            setTaskDescColor(paletteColor)
            val isColorLight = paletteColor.isColorLight
            if (PreferenceUtil.isAdaptiveColor && (nowPlayingScreen == NowPlayingScreen.Normal || nowPlayingScreen == NowPlayingScreen.Flat)) {
                setLightNavigationBar(true)
                // setLightStatusBar(isColorLight)
            } else if (nowPlayingScreen == NowPlayingScreen.Card || nowPlayingScreen == NowPlayingScreen.Blur || nowPlayingScreen == NowPlayingScreen.BlurCard) {
                animateNavigationBarColor(Color.BLACK)
                navigationBarColor = Color.BLACK
                //  setLightStatusBar(false)
                setLightNavigationBar(true)
            } else if (nowPlayingScreen == NowPlayingScreen.Color
                || nowPlayingScreen == NowPlayingScreen.Tiny
                || nowPlayingScreen == NowPlayingScreen.Gradient
            ) {
                animateNavigationBarColor(paletteColor)
                navigationBarColor = paletteColor
                setLightNavigationBar(isColorLight)
                //  setLightStatusBar(isColorLight)
            } else if (nowPlayingScreen == NowPlayingScreen.Full) {
                animateNavigationBarColor(paletteColor)
                navigationBarColor = paletteColor
                setDrawBehindSystemBars()
                setLightNavigationBar(isColorLight)
                //setLightStatusBar(false)
            }
        }
    }

    private fun animateNavigationBarColor(color: Int) {
        if (VersionUtils.hasOreo()) return
        navigationBarColorAnimator?.cancel()
        navigationBarColorAnimator = ValueAnimator
            .ofArgb(window.navigationBarColor, color).apply {
                duration = ViewUtil.RETRO_MUSIC_ANIM_TIME.toLong()
                interpolator = PathInterpolator(0.4f, 0f, 1f, 1f)
                addUpdateListener { animation: ValueAnimator ->
                    setNavigationBarColorPreOreo(
                        animation.animatedValue as Int
                    )
                }
                start()
            }
    }

    override fun onDestroy() {
        super.onDestroy()
        PreferenceUtil.unregisterOnSharedPreferenceChangedListener(this)
        if (receiverRegistered) {
            unregisterReceiver(musicStateReceiver)
            receiverRegistered = false
        }
    }

    private var musicStateReceiver: MusicStateReceiver? = null

    class MusicStateReceiver(activity: OutMusicActivity) : BroadcastReceiver() {

        val reference: WeakReference<OutMusicActivity> = WeakReference(activity)

        override fun onReceive(context: Context, intent: Intent) {
            val action = intent.action
            val activity = reference.get()
            if (activity != null && action != null) {
                when (action) {
                    MusicService.FAVORITE_STATE_CHANGED -> activity.onFavoriteStateChanged()
                    MusicService.META_CHANGED -> activity.onPlayingMetaChanged()
                    MusicService.QUEUE_CHANGED -> activity.onQueueChanged()
                    MusicService.PLAY_STATE_CHANGED -> activity.onPlayStateChanged()
                    MusicService.REPEAT_MODE_CHANGED -> activity.onRepeatModeChanged()
                    MusicService.SHUFFLE_MODE_CHANGED -> activity.onShuffleModeChanged()
                    MusicService.MEDIA_STORE_CHANGED -> activity.onMediaStoreChanged()
                }
            }
        }
    }

    override fun onServiceDisconnected() {
        if (receiverRegistered) {
            unregisterReceiver(musicStateReceiver)
            receiverRegistered = false
        }

        for (listener in mMusicServiceEventListeners) {
            listener.onServiceDisconnected()
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()


        if (!receiverRegistered) {
            musicStateReceiver = MusicStateReceiver(this)

            val filter = IntentFilter()
            filter.addAction(MusicService.PLAY_STATE_CHANGED)
            filter.addAction(MusicService.SHUFFLE_MODE_CHANGED)
            filter.addAction(MusicService.REPEAT_MODE_CHANGED)
            filter.addAction(MusicService.META_CHANGED)
            filter.addAction(MusicService.QUEUE_CHANGED)
            filter.addAction(MusicService.MEDIA_STORE_CHANGED)
            filter.addAction(MusicService.FAVORITE_STATE_CHANGED)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(musicStateReceiver, filter, RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(musicStateReceiver, filter)
            }

            receiverRegistered = true
        }

        for (listener in mMusicServiceEventListeners) {
            listener.onServiceConnected()
        }

        try {
            intent ?: return
            handlePlaybackIntent(intent)
        } catch (_: Exception) {

        }
    }

    private fun handlePlaybackIntent(intent: Intent) {
        try {
            lifecycleScope.launch(Dispatchers.IO) {
                val uri: Uri? = intent.data
                val mimeType: String? = intent.type
                var handled = false
                if (intent.action != null &&
                    intent.action == MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH
                ) {
                    val songs: List<Song> = getSongs(intent.extras!!)
                    if (MusicPlayerRemote.shuffleMode == MusicService.SHUFFLE_MODE_SHUFFLE) {
                        MusicPlayerRemote.openAndShuffleQueue(songs, true)
                    } else {
                        MusicPlayerRemote.openQueue(songs, 0, true)
                    }
                    handled = true
                }
                if (uri != null && uri.toString().isNotEmpty()) {
                    MusicPlayerRemote.playFromUri(uri)
                    handled = true
                } else if (MediaStore.Audio.Playlists.CONTENT_TYPE == mimeType) {
                    val id = parseLongFromIntent(intent, "playlistId", "playlist")
                    if (id >= 0L) {
                        val position: Int = intent.getIntExtra("position", 0)
                        val songs: List<Song> =
                            PlaylistSongsLoader.getPlaylistSongList(this@OutMusicActivity, id)
                        MusicPlayerRemote.openQueue(songs, position, true)
                        handled = true
                    }
                } else if (MediaStore.Audio.Albums.CONTENT_TYPE == mimeType) {
                    val id = parseLongFromIntent(intent, "albumId", "album")
                    if (id >= 0L) {
                        val position: Int = intent.getIntExtra("position", 0)
                        val songs = libraryViewModel.albumById(id).songs
                        MusicPlayerRemote.openQueue(
                            songs,
                            position,
                            true
                        )
                        handled = true
                    }
                } else if (MediaStore.Audio.Artists.CONTENT_TYPE == mimeType) {
                    val id = parseLongFromIntent(intent, "artistId", "artist")
                    if (id >= 0L) {
                        val position: Int = intent.getIntExtra("position", 0)
                        val songs: List<Song> = libraryViewModel.artistById(id).songs
                        MusicPlayerRemote.openQueue(
                            songs,
                            position,
                            true
                        )
                        handled = true
                    }
                }
                if (handled) {
                    setIntent(Intent())
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun parseLongFromIntent(
        intent: Intent,
        longKey: String,
        stringKey: String
    ): Long {
        var id = intent.getLongExtra(longKey, -1)
        if (id < 0) {
            val idString = intent.getStringExtra(stringKey)
            if (idString != null) {
                try {
                    id = idString.toLong()
                } catch (_: NumberFormatException) {

                }
            }
        }
        return id
    }

    override fun onQueueChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onQueueChanged()
        }
    }


    override fun onPlayingMetaChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onPlayingMetaChanged()
        }
        lifecycleScope.launch(Dispatchers.IO) {
            val entity = repository.songPresentInHistory(MusicPlayerRemote.currentSong)
            if (entity != null) {
                repository.updateHistorySong(MusicPlayerRemote.currentSong)
            } else {
                repository.addSongToHistory(MusicPlayerRemote.currentSong)
            }
            val songs = repository.checkSongExistInPlayCount(MusicPlayerRemote.currentSong.id)
            if (songs.isNotEmpty()) {
                repository.updateSongInPlayCount(songs.first().apply {
                    playCount += 1
                })
            } else {
                repository.insertSongInPlayCount(MusicPlayerRemote.currentSong.toPlayCount())
            }
        }
    }

    override fun onPlayStateChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onPlayStateChanged()
        }
    }

    override fun onRepeatModeChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onRepeatModeChanged()
        }
    }

    override fun onShuffleModeChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onShuffleModeChanged()
        }
    }

    override fun onFavoriteStateChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onFavoriteStateChanged()
        }
    }

    override fun onMediaStoreChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onMediaStoreChanged()
        }
    }


    override fun onSharedPreferenceChanged(p0: SharedPreferences?, p1: String?) {

    }

}