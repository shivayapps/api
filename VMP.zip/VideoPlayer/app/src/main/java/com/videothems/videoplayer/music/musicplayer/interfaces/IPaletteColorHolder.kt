package com.videothems.videoplayer.music.musicplayer.interfaces


interface IPaletteColorHolder {
    val paletteColor: Int
}
