package com.videothems.videoplayer.music.common.status

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.storage.StorageManager
import android.provider.DocumentsContract
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.text.HtmlCompat
import androidx.fragment.app.FragmentActivity
import androidx.preference.PreferenceManager
import androidx.viewpager.widget.ViewPager
import com.videothems.videoplayer.music.R
import com.videothems.videoplayer.music.adloaders.BannerAds
import com.videothems.videoplayer.music.adloaders.InterstitialAdLoader
import com.videothems.videoplayer.music.adloaders.NativeAdSize
import com.videothems.videoplayer.music.adloaders.PreLoadNativeAds
import com.videothems.videoplayer.music.adloaders.PrefsAds
import com.videothems.videoplayer.music.common.base.BaseBindingActivity
import com.videothems.videoplayer.music.common.utils.isAppInstalled
import com.videothems.videoplayer.music.common.utils.isOnline
import com.videothems.videoplayer.music.databinding.ActivityWhatsappStatusBinding
import com.videothems.videoplayer.music.databinding.PermissionStatusBottomSheetLayoutBinding
import com.videothems.videoplayer.music.musicplayer.App
import com.videothems.videoplayer.music.musicplayer.GENERAL_THEME
import com.videothems.videoplayer.music.musicplayer.IMAGE_THEME
import com.videothems.videoplayer.music.musicplayer.extensions.hide
import com.videothems.videoplayer.music.musicplayer.extensions.makeStatusBarTransparent
import com.videothems.videoplayer.music.musicplayer.extensions.resolveColor
import com.videothems.videoplayer.music.musicplayer.extensions.show
import com.videothems.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.videothems.videoplayer.music.musicplayer.util.PreferenceUtil.whatsAppUri
import com.videothems.videoplayer.music.videoplayer.adapter.ViewPagerAdapter
import org.jetbrains.anko.backgroundColor
import java.io.File
import java.util.concurrent.Executors

class WhatsappStatusActivity : BaseBindingActivity<ActivityWhatsappStatusBinding>() {
    private var permissionLauncher: ActivityResultLauncher<Intent>? = null
    private var videosStatusFragment: VideoStatusFragment? = null
    private var photosStatusFragment: PhotoStatusFragment? = null
    private var permissionBottomDialog: AlertDialog? = null
    private var isClicks = false

    override fun setBinding(): ActivityWhatsappStatusBinding {
        return ActivityWhatsappStatusBinding.inflate(layoutInflater)
    }

    override fun getActivityContext(): FragmentActivity {
        return this@WhatsappStatusActivity
    }

    override fun initView() {
        super.initView()
        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext())
            .getString(IMAGE_THEME, "")
        val edit =
            PreferenceManager.getDefaultSharedPreferences(App.getContext()).getInt(GENERAL_THEME, 0)

        makeStatusBarTransparent()

        if (editors == "theme_image") {
            mBinding.root.background =
                RetroGlideExtension.getUserImageTheme(this@WhatsappStatusActivity)
            mBinding.constraintLayout.background = null
        } else if (editors == "theme_gradient") {
            mBinding.root.background =
                AppCompatResources.getDrawable(this, RetroGlideExtension.getUserGradientTheme())
            mBinding.constraintLayout.background = null
        } else if (edit >= 0) {
            mBinding.root.background = null
            mBinding.root.backgroundColor = resolveColor(R.attr.mainBackgroundColor)
        }

        isClicks = false
        with(mBinding) {
            tvTitle.text = getString(R.string.wp_status)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                permissionLauncher = registerForActivityResult(
                    ActivityResultContracts.StartActivityForResult()
                ) { result: ActivityResult ->
                    if (result.resultCode == Activity.RESULT_OK) {
                        if (result.data != null) {
                            if (result.data!!.data.toString() == "content://com.android.externalstorage.documents/tree/primary%3AAndroid%2Fmedia%2Fcom.whatsapp%2FWhatsApp%2FMedia%2F.Statuses") {
                                val uri = result.data?.data

                                val flag =
                                    result.data?.flags!! and Intent.FLAG_GRANT_READ_URI_PERMISSION

                                if (uri != null) {
                                    contentResolver.takePersistableUriPermission(uri, flag)
                                }

                                whatsAppUri = uri

                                mBinding.wpViewpager.show()
                                mBinding.llPermissionLayout.hide()
                                isClicks = false
                                searchForStatus(this@WhatsappStatusActivity)
                            } else {
                                mBinding.wpViewpager.hide()
                                mBinding.llPermissionLayout.show()
                                permissionBottomDialog!!.show()
                                isClicks = true
                                Toast.makeText(
                                    this@WhatsappStatusActivity,
                                    getString(R.string.not_valid),
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        } else {
                            isClicks = true
                            mBinding.wpViewpager.hide()
                            mBinding.llPermissionLayout.show()
                            permissionBottomDialog!!.show()
                        }
                    }
                }
            }

            viewPagerSetup()
            checkPermissionForWhatsApp()
        }
        setNative()
    }

    private fun setNative() {
        if (isOnline) {
            mBinding.frameLayout.visibility = View.VISIBLE
            if (PrefsAds(this).isNative3() == "1") {
                val nativeADs = PreLoadNativeAds(this)
                nativeADs.showLoadingLayoutForNative(mBinding.frameLayout, NativeAdSize.Medium)
                App.nativeAdsFiles.observe(this) { native ->
                    if (native != null) {
                        nativeADs.showNative(mBinding.frameLayout, native, NativeAdSize.Medium)
                    } else {
                        if (nativeADs.checkAdsIsOn() && App.isNativeLoading)
                            mBinding.frameLayout.visibility = View.VISIBLE
                        else
                            mBinding.frameLayout.visibility = View.GONE
                    }
                }
            } else if (PrefsAds(this).isNative3() == "0") {
                BannerAds().loadAdmobBannerAds(
                    this, mBinding.frameLayout, ""
                )
            }
        } else {
            mBinding.frameLayout.visibility = View.GONE
        }
    }

    private fun viewPagerSetup() {
        photosStatusFragment = PhotoStatusFragment()
        videosStatusFragment = VideoStatusFragment()
        val mViewPagerAdapter = ViewPagerAdapter(supportFragmentManager)
        mViewPagerAdapter.addFragment(photosStatusFragment!!, "Photos")
        mViewPagerAdapter.addFragment(videosStatusFragment!!, "Video")
        mBinding.wpViewpager.adapter = mViewPagerAdapter

        mBinding.wpViewpager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int,
            ) {

            }

            override fun onPageSelected(position: Int) {
                if (position == 0) {
                    setUpDesign(mBinding.tvPhotos)
                } else {
                    setUpDesign(mBinding.tvVideos)
                }
            }

            override fun onPageScrollStateChanged(state: Int) {

            }
        })
    }

    private fun checkPermissionForWhatsApp() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (whatsAppUri == null) {
                getPermissionRandAbove()
            } else if (TextUtils.isEmpty(whatsAppUri.toString())) {
                getPermissionRandAbove()
            } else {
                searchForStatus(this)
            }
        } else {
            if (isAppInstalled("com.whatsapp", this)) {
                searchForStatus(this)
            } else {
                Toast.makeText(this, getString(R.string.not_install), Toast.LENGTH_SHORT).show()
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun getPermissionRandAbove() {
        val intent =
            (getSystemService(Context.STORAGE_SERVICE) as StorageManager).primaryStorageVolume.createOpenDocumentTreeIntent()
        val uri = DocumentsContract.buildDocumentUri(
            "com.android.externalstorage.documents",
            "primary:Android/media/com.whatsapp/WhatsApp/" + File.separator + "Media" + File.separator + ".Statuses"
        )
        intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, uri)
        val permissionDialogBinding: PermissionStatusBottomSheetLayoutBinding =
            PermissionStatusBottomSheetLayoutBinding.inflate(LayoutInflater.from(this))

        permissionBottomDialog = AlertDialog.Builder(this).create()

        permissionBottomDialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
        permissionBottomDialog?.setCancelable(false)
        permissionBottomDialog?.setView(permissionDialogBinding.root)


        permissionBottomDialog?.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        permissionBottomDialog?.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)

        val styledText =
            getString(R.string.due_to_system_restrictions_we_need_you_to_authorize) + " <font color='#037EFF'> " + getString(
                R.string.statuses
            ) + " " + getString(
                R.string.to_download_files
            )

        val spannedText = HtmlCompat.fromHtml(styledText, HtmlCompat.FROM_HTML_MODE_LEGACY)

        permissionDialogBinding.tvStatusText.setText(
            spannedText,
            TextView.BufferType.SPANNABLE
        )

        permissionDialogBinding.ivCloase.setOnClickListener {
            permissionBottomDialog!!.dismiss()
        }

        permissionDialogBinding.yes.setOnClickListener {
            if (isAppInstalled("com.whatsapp", this)) {
                permissionBottomDialog!!.dismiss()
                permissionLauncher!!.launch(intent)
            } else {
                Toast.makeText(this, getString(R.string.not_install), Toast.LENGTH_SHORT)
                    .show()
            }
        }

        permissionBottomDialog?.show()
    }

    private fun searchForStatus(activity: Activity) {
        val service = Executors.newSingleThreadExecutor()
        service.execute {
            runOnUiThread { mBinding.progressCircular.visibility = View.VISIBLE }
            val whatApp = Analyzer(activity)
            whatApp.analyze()
            runOnUiThread {
                mBinding.progressCircular.visibility = View.GONE
                photosStatusFragment!!.setAdapters(Analyzer.whatsAppDataPhoto)
                videosStatusFragment!!.setAdapters(Analyzer.whatsAppDataVideo)
            }
        }
    }

    fun setUpDesign(selectTextView: TextView) {
        mBinding.tvVideos.setTextColor(resolveColor(R.attr.text_color_subtitle))
        mBinding.tvPhotos.setTextColor(resolveColor(R.attr.text_color_subtitle))
        mBinding.tvPhotos.setBackgroundResource(R.drawable.rounded_border)
        mBinding.tvVideos.setBackgroundResource(R.drawable.rounded_border)

        selectTextView.setTextColor(resolveColor(R.attr.colorPrimary))
        selectTextView.setBackgroundResource(R.drawable.rounded_selected)
    }

    override fun onBackPressed() {
        val clickInterval: Long = 40 * 1000
        val currentTime = System.currentTimeMillis()
        val elapsedTimeSinceLastClick = currentTime - App.lastClickTimeStatus
        if (elapsedTimeSinceLastClick >= clickInterval) {
            InterstitialAdLoader(this).showFullScreenAds(this,
                object : InterstitialAdLoader.AdFinishWithControlListener {
                    override fun adFinished() {
                        onBack()
                    }
                })
            App.lastClickTimeStatus = currentTime
        } else {
            onBack()
        }
    }

    private fun onBack() {
        super.onBackPressed()
    }

    override fun initViewListener() {
        super.initViewListener()
        mBinding.tvVideos.setOnClickListener {
            if (!isClicks) {
                mBinding.wpViewpager.currentItem = 1
            }
        }

        mBinding.tvPhotos.setOnClickListener {
            if (!isClicks) {
                mBinding.wpViewpager.currentItem = 0
            }
        }

        mBinding.ivBack.setOnClickListener {
            onBackPressed()
        }
    }
}