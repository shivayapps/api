package com.videothems.videoplayer.music.musicplayer.preferences

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import code.name.monkey.appthemehelper.common.prefs.supportv7.ATEDialogPreference
import com.bumptech.glide.Glide
import com.videothems.videoplayer.music.R
import com.videothems.videoplayer.music.databinding.PreferenceNowPlayingScreenItemBinding
import com.videothems.videoplayer.music.musicplayer.App
import com.videothems.videoplayer.music.musicplayer.extensions.colorButtons
import com.videothems.videoplayer.music.musicplayer.extensions.hide
import com.videothems.videoplayer.music.musicplayer.extensions.materialDialog1
import com.videothems.videoplayer.music.musicplayer.extensions.show
import com.videothems.videoplayer.music.musicplayer.fragments.NowPlayingScreen
import com.videothems.videoplayer.music.musicplayer.util.NavigationUtil
import com.videothems.videoplayer.music.musicplayer.util.PreferenceUtil

class NowPlayingScreenPreference @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = -1,
    defStyleRes: Int = -1
) : ATEDialogPreference(context, attrs, defStyleAttr, defStyleRes) {

    private val mLayoutRes = R.layout.preference_dialog_now_playing_screen

    override fun getDialogLayoutResource(): Int {
        return mLayoutRes
    }

}

class NowPlayingScreenPreferenceDialog : DialogFragment(), ViewPager.OnPageChangeListener {

    private var viewPagerPosition: Int = 0

    override fun onPageScrollStateChanged(state: Int) {
    }

    override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
    }

    override fun onPageSelected(position: Int) {
        this.viewPagerPosition = position
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val view = layoutInflater
            .inflate(R.layout.preference_dialog_now_playing_screen, null)

        val viewPager = view.findViewById<ViewPager>(R.id.now_playing_screen_view_pager)
            ?: throw IllegalStateException("Dialog view must contain a ViewPager with id 'now_playing_screen_view_pager'")

        viewPager.adapter = NowPlayingScreenAdapter(requireContext())
        viewPager.addOnPageChangeListener(this)
        viewPager.currentItem = PreferenceUtil.nowPlayingScreen.ordinal

        val ivClose = view.findViewById<TextView>(R.id.btn_set)

        ivClose.setOnClickListener {
            val nowPlayingScreen = NowPlayingScreen.values()[viewPagerPosition]
            if (isNowPlayingThemes(nowPlayingScreen)) {
                NavigationUtil.goToProVersion(requireContext())
            } else {
                PreferenceUtil.nowPlayingScreen = nowPlayingScreen
            }
            dialog?.dismiss()
        }

        return materialDialog1()
            .setCancelable(false)
            .setView(view)
            .create()
            .colorButtons()
    }

    companion object {
        fun newInstance(): NowPlayingScreenPreferenceDialog {
            return NowPlayingScreenPreferenceDialog()
        }
    }
}

private class NowPlayingScreenAdapter(private val context: Context) : PagerAdapter() {

    override fun instantiateItem(collection: ViewGroup, position: Int): Any {
        val nowPlayingScreen = NowPlayingScreen.values()[position]

        val inflater = LayoutInflater.from(context)
        val binding = PreferenceNowPlayingScreenItemBinding.inflate(inflater, collection, true)
        Glide.with(context).load(nowPlayingScreen.drawableResId).into(binding.image)
        binding.title.setText(nowPlayingScreen.titleRes)
        if (isNowPlayingThemes(nowPlayingScreen)) {
            binding.proText.show()
            binding.proText.setText(R.string.pro)
        } else {
            binding.proText.hide()
        }
        return binding.root
    }

    override fun destroyItem(
        collection: ViewGroup,
        position: Int,
        view: Any
    ) {
        collection.removeView(view as View)
    }

    override fun getCount(): Int {
        return NowPlayingScreen.values().size
    }

    override fun isViewFromObject(view: View, instance: Any): Boolean {
        return view === instance
    }

    override fun getPageTitle(position: Int): CharSequence {
        return context.getString(NowPlayingScreen.values()[position].titleRes)
    }
}

private fun isNowPlayingThemes(screen: NowPlayingScreen): Boolean {
    return (screen == NowPlayingScreen.Full
            || screen == NowPlayingScreen.Card
            || screen == NowPlayingScreen.Blur
            || screen == NowPlayingScreen.Color
            || screen == NowPlayingScreen.BlurCard
            || screen == NowPlayingScreen.Circle
            || screen == NowPlayingScreen.Adaptive) && App.isProVersion()
}