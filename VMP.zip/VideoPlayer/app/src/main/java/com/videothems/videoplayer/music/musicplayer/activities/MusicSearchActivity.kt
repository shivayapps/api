package com.videothems.videoplayer.music.musicplayer.activities

import android.view.View
import androidx.appcompat.content.res.AppCompatResources
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.commit
import androidx.preference.PreferenceManager
import com.videothems.videoplayer.music.R
import com.videothems.videoplayer.music.adloaders.BannerAds
import com.videothems.videoplayer.music.adloaders.NativeAdSize
import com.videothems.videoplayer.music.adloaders.PreLoadNativeAds
import com.videothems.videoplayer.music.adloaders.PrefsAds
import com.videothems.videoplayer.music.common.base.BaseBindingActivity
import com.videothems.videoplayer.music.common.utils.isOnline
import com.videothems.videoplayer.music.databinding.ActivityMusicSearchBinding
import com.videothems.videoplayer.music.musicplayer.App
import com.videothems.videoplayer.music.musicplayer.GENERAL_THEME
import com.videothems.videoplayer.music.musicplayer.IMAGE_THEME
import com.videothems.videoplayer.music.musicplayer.extensions.makeStatusBarTransparent
import com.videothems.videoplayer.music.musicplayer.extensions.resolveColor
import com.videothems.videoplayer.music.musicplayer.fragments.search.SearchFragment
import com.videothems.videoplayer.music.musicplayer.glide.RetroGlideExtension
import org.jetbrains.anko.backgroundColor

class MusicSearchActivity : BaseBindingActivity<ActivityMusicSearchBinding>() {

    private val playingQueueFragment = SearchFragment.newInstance()

    override fun getActivityContext(): FragmentActivity {
        return this@MusicSearchActivity
    }

    override fun setBinding(): ActivityMusicSearchBinding {
        return ActivityMusicSearchBinding.inflate(layoutInflater)
    }

    override fun initView() {
        super.initView()
        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext())
            .getString(IMAGE_THEME, "")

        val edit =
            PreferenceManager.getDefaultSharedPreferences(App.getContext()).getInt(GENERAL_THEME, 0)

        makeStatusBarTransparent()

        if (editors == "theme_image") {
            mBinding.root.background =
                RetroGlideExtension.getUserImageTheme(this@MusicSearchActivity)
        } else if (editors == "theme_gradient") {
            mBinding.root.background = AppCompatResources.getDrawable(this, RetroGlideExtension.getUserGradientTheme())
        } else if (edit >= 0) {
            mBinding.root.background = null
            mBinding.root.backgroundColor = resolveColor(R.attr.mainBackgroundColor)
        }

        supportFragmentManager.commit {
            replace(R.id.fm_container, playingQueueFragment)
        }
        setNative()
    }

    private fun setNative() {
        if (isOnline) {
            mBinding.frameLayout.visibility = View.VISIBLE
            if (PrefsAds(this).isNative5() == "1") {
                val nativeADs = PreLoadNativeAds(this)
                nativeADs.showLoadingLayoutForNative(mBinding.frameLayout, NativeAdSize.Medium)
                App.nativeAdsFiles.observe(this) { native ->
                    if (native != null) {
                        nativeADs.showNative(mBinding.frameLayout, native, NativeAdSize.Medium)
                    } else {
                        if (nativeADs.checkAdsIsOn() && App.isNativeLoading)
                            mBinding.frameLayout.visibility = View.VISIBLE
                        else
                            mBinding.frameLayout.visibility = View.GONE
                    }
                }
            } else if (PrefsAds(this).isNative5() == "0") {
                BannerAds().loadAdmobBannerAds(
                    this, mBinding.frameLayout, ""
                )
            }
        } else {
            mBinding.frameLayout.visibility = View.GONE
        }
    }

}