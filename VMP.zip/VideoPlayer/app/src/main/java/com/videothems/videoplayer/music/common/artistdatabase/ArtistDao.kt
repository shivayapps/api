package com.videothems.videoplayer.music.common.artistdatabase

import androidx.room.Dao
import androidx.room.Query

@Dao
interface ArtistDao {
    @Query("SELECT * FROM artist")
    fun getAllAge(): List<Artist>

    @Query("Select * from artist WHERE name LIKE  :name")
    fun getArtist(name: String?): Artist

}