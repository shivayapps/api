package com.videothems.videoplayer.music.musicplayer.fragment

import android.view.LayoutInflater
import android.view.ViewGroup
import com.videothems.videoplayer.music.common.base.BaseBindingFragment
import com.videothems.videoplayer.music.databinding.FragmentArtistBinding


class ArtistFragment : BaseBindingFragment<FragmentArtistBinding>() {
    override fun setBinding(
        layoutInflater: LayoutInflater,
        container: ViewGroup?
    ): FragmentArtistBinding {
        return FragmentArtistBinding.inflate(layoutInflater)
    }

    companion object {
        fun newInstance(): ArtistFragment {
            return ArtistFragment()
        }
    }

}