package com.videothems.videoplayer.music.adloaders

import android.app.Activity
import android.util.DisplayMetrics
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import androidx.annotation.NonNull
import com.facebook.shimmer.ShimmerFrameLayout
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.videothems.videoplayer.music.R
import com.videothems.videoplayer.music.common.utils.isOnline
import com.videothems.videoplayer.music.musicplayer.App.Companion.isOpenAdHide

class BannerAds {
    private val TAG = "BannerAds"
    var mAdView: AdView? = null
    var isRequestSend = false

    fun loadAdmobBannerAds(
        activity: Activity,
        frameLayout_admob_banner: FrameLayout, adSizeType: String
    ) {
        if (!PrefsAds(activity).isBannerAdEnable) return
        isRequestSend = true
        loadBannerAds(activity, frameLayout_admob_banner, adSizeType)
    }

    private fun loadBannerAds(
        activity: Activity,
        frameLayout_admob_banner: FrameLayout, adSizeType: String
    ) {
        if (activity.isOnline) {
            Log.w(TAG, "loadBannerAds")
            val bannerLoading = if (adSizeType == "Rectangle") {
                LayoutInflater.from(activity)
                    .inflate(R.layout.loading_rectangle_banner, null) as FrameLayout
            } else {
                LayoutInflater.from(activity).inflate(R.layout.loading_banner, null) as FrameLayout
            }
            val shimmerFrameLayout =
                bannerLoading.findViewById<ShimmerFrameLayout>(R.id.shimmer_view_container)
            shimmerFrameLayout.startLayoutAnimation()
            frameLayout_admob_banner.addView(bannerLoading)

            mAdView = AdView(activity)
            mAdView!!.setAdSize(getBannerAdsType(activity, adSizeType))
            val adId: String = activity.getString(R.string.admob_banner)

            Log.w("TAG", "AdId:$adId")
            mAdView!!.adUnitId = adId
            val adRequest: AdRequest = AdRequest.Builder().build()
            mAdView!!.loadAd(adRequest)
            mAdView!!.adListener = object : AdListener() {
                override fun onAdLoaded() {
                    Log.w(TAG + "First ", "loadBannerAds--onAdLoaded----")
                    frameLayout_admob_banner.removeAllViews()
                    frameLayout_admob_banner.addView(mAdView)
                    frameLayout_admob_banner.visibility = View.VISIBLE
                    isRequestSend = false
                }

                override fun onAdFailedToLoad(@NonNull adError: LoadAdError) {
                    Log.w(TAG + "First ", "loadBannerAds--onAdFailedToLoad----" + adError.message)
                    mAdView!!.visibility = View.GONE
                    reloadBannerAds(activity, frameLayout_admob_banner, adSizeType)
                }

                override fun onAdClicked() {
                    super.onAdClicked()
                    isOpenAdHide = true
                }
            }
        }
    }

    private fun reloadBannerAds(
        activity: Activity,
        frameLayout_admob_banner: FrameLayout, adSizeType: String
    ) {
        if (activity.isOnline) {
            Log.w(TAG + "Reload ", "reloadBannerAds-------calling--------")
            mAdView = AdView(activity)
            mAdView!!.setAdSize(getBannerAdsType(activity, adSizeType))
            mAdView!!.adUnitId = activity.getString(R.string.admob_banner_2)

            val adRequest: AdRequest = AdRequest.Builder().build()
            mAdView!!.loadAd(adRequest)
            mAdView!!.adListener = object : AdListener() {
                override fun onAdLoaded() {
                    Log.w(TAG + "Reload ", "reloadBannerAds--------onAdLoaded-------")
                    frameLayout_admob_banner.removeAllViews()
                    frameLayout_admob_banner.addView(mAdView)
                    frameLayout_admob_banner.visibility = View.VISIBLE
                    isRequestSend = false
                }

                override fun onAdFailedToLoad(adError: LoadAdError) {
                    mAdView!!.visibility = View.GONE
                    frameLayout_admob_banner.visibility = View.GONE
                    isRequestSend = false
                    Log.w(
                        TAG + "Reload ",
                        "reloadBannerAds--------onAdFailedToLoad-------" + adError.message
                    )
                }

                override fun onAdClicked() {
                    super.onAdClicked()
                    isOpenAdHide = true
                }
            }
        }
    }

    private fun getAdSize(activity: Activity): AdSize {
        // Step 2 - Determine the screen width (less decorations) to use for the ad width.
        val display = activity.windowManager.defaultDisplay
        val outMetrics = DisplayMetrics()
        display.getMetrics(outMetrics)
        val widthPixels = outMetrics.widthPixels.toFloat()
        val density = outMetrics.density
        val adWidth = (widthPixels / density).toInt()


        // Step 3 - Get adaptive ad size and return for setting on the ad view.
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, adWidth)
    }

    private fun getBannerAdsType(activity: Activity, admobBannerType: String): AdSize {
        val adSize: AdSize = if (admobBannerType == "Rectangle") {
            AdSize.MEDIUM_RECTANGLE
        } else {
            getAdSize(activity)
        }
        return adSize
    }

    fun destroyAd() {
        if (mAdView != null) {
            mAdView!!.destroy()
        }
    }

    fun resumeAd() {
        if (mAdView != null) {
            mAdView!!.resume()
        }
    }

    fun pauseAd() {
        if (mAdView != null) {
            mAdView!!.pause()
        }
    }
}