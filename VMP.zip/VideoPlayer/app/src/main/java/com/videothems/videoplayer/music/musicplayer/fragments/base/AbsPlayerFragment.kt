package com.videothems.videoplayer.music.musicplayer.fragments.base

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.graphics.drawable.AnimatedVectorDrawable
import android.graphics.drawable.Drawable
import android.media.MediaMetadataRetriever
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.GestureDetector
import android.view.MenuItem
import android.view.MotionEvent
import android.view.View
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.annotation.LayoutRes
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import androidx.navigation.findNavController
import androidx.navigation.navOptions
import androidx.viewpager.widget.ViewPager
import code.name.monkey.appthemehelper.util.VersionUtils
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.videothems.videoplayer.music.R
import com.videothems.videoplayer.music.musicplayer.EXTRA_ALBUM_ID
import com.videothems.videoplayer.music.musicplayer.EXTRA_ARTIST_ID
import com.videothems.videoplayer.music.musicplayer.activities.ArtistDetailActivity
import com.videothems.videoplayer.music.musicplayer.activities.MusicMainActivity
import com.videothems.videoplayer.music.musicplayer.activities.PlayingQueueActivity
import com.videothems.videoplayer.music.musicplayer.activities.tageditor.AbsTagEditorActivity
import com.videothems.videoplayer.music.musicplayer.activities.tageditor.SongTagEditorActivity
import com.videothems.videoplayer.music.musicplayer.db.PlaylistEntity
import com.videothems.videoplayer.music.musicplayer.db.toSongEntity
import com.videothems.videoplayer.music.musicplayer.dialogs.AddToPlaylistDialog
import com.videothems.videoplayer.music.musicplayer.dialogs.CreatePlaylistDialog
import com.videothems.videoplayer.music.musicplayer.dialogs.DeleteSongsDialog
import com.videothems.videoplayer.music.musicplayer.dialogs.PlaybackSpeedDialog
import com.videothems.videoplayer.music.musicplayer.dialogs.SleepTimerDialog
import com.videothems.videoplayer.music.musicplayer.dialogs.SongDetailDialog
import com.videothems.videoplayer.music.musicplayer.extensions.hide
import com.videothems.videoplayer.music.musicplayer.extensions.keepScreenOn
import com.videothems.videoplayer.music.musicplayer.extensions.whichFragment
import com.videothems.videoplayer.music.musicplayer.fragments.NowPlayingScreen
import com.videothems.videoplayer.music.musicplayer.fragments.ReloadType
import com.videothems.videoplayer.music.musicplayer.fragments.player.PlayerAlbumCoverFragment
import com.videothems.videoplayer.music.musicplayer.helper.MusicPlayerRemote
import com.videothems.videoplayer.music.musicplayer.interfaces.IPaletteColorHolder
import com.videothems.videoplayer.music.musicplayer.model.Song
import com.videothems.videoplayer.music.musicplayer.repository.RealRepository
import com.videothems.videoplayer.music.musicplayer.service.MusicService
import com.videothems.videoplayer.music.musicplayer.util.NavigationUtil
import com.videothems.videoplayer.music.musicplayer.util.PreferenceUtil
import com.videothems.videoplayer.music.musicplayer.util.RingtoneManager
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.Dispatchers.Main
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.koin.android.ext.android.get
import kotlin.math.abs

abstract class AbsPlayerFragment(@LayoutRes layout: Int) : AbsMainActivityFragment(layout),
    Toolbar.OnMenuItemClickListener, IPaletteColorHolder, PlayerAlbumCoverFragment.Callbacks {

    private var playerAlbumCoverFragment: PlayerAlbumCoverFragment? = null

    override fun onMenuItemClick(
        item: MenuItem
    ): Boolean {
        val song = MusicPlayerRemote.currentSong
        when (item.itemId) {
            R.id.action_playback_speed -> {
                Log.e("OnMenuClick", "action_playback_speed")
                PlaybackSpeedDialog.newInstance().show(childFragmentManager, "PLAYBACK_SETTINGS")
                return true
            }

            R.id.action_toggle_lyrics -> {
                Log.e("OnMenuClick", "action_toggle_lyrics")
                PreferenceUtil.showLyrics = !PreferenceUtil.showLyrics
                showLyricsIcon(item)
                if (PreferenceUtil.lyricsScreenOn && PreferenceUtil.showLyrics) {
                    musicMainActivity.keepScreenOn(true)
                } else if (!PreferenceUtil.isScreenOnEnabled && !PreferenceUtil.showLyrics) {
                    musicMainActivity.keepScreenOn(false)
                }
                return true
            }

            R.id.action_go_to_lyrics -> {
                Log.e("OnMenuClick", "action_go_to_lyrics")
                goToLyrics(requireActivity())
                return true
            }

            R.id.action_toggle_favorite -> {
                Log.e("OnMenuClick", "action_toggle_favorite")
                toggleFavorite(song)
                return true
            }

            R.id.action_go_to_drive_mode -> {
                Log.e("OnMenuClick", "action_go_to_drive_mode")
                NavigationUtil.gotoDriveMode(requireActivity())
                return true
            }

            R.id.action_delete_from_device -> {
                Log.e("OnMenuClick", "action_delete_from_device")
                DeleteSongsDialog.create(song).show(childFragmentManager, "DELETE_SONGS")
                return true
            }

            R.id.action_add_to_playlist -> {
                Log.e("OnMenuClick", "action_add_to_playlist")
                lifecycleScope.launch(IO) {
                    val playlists = get<RealRepository>().fetchPlaylists()
                    withContext(Main) {
                        AddToPlaylistDialog.create(playlists, song)
                            .show(childFragmentManager, "ADD_PLAYLIST")
                    }
                }
                return true
            }

            R.id.action_clear_playing_queue -> {
                Log.e("OnMenuClick", "action_clear_playing_queue")
                MusicPlayerRemote.clearQueue()
                return true
            }

            R.id.action_save_playing_queue -> {
                Log.e("OnMenuClick", "action_save_playing_queue")
                CreatePlaylistDialog.create(ArrayList(MusicPlayerRemote.playingQueue))
                    .show(childFragmentManager, "ADD_TO_PLAYLIST")
                return true
            }

            R.id.action_tag_editor -> {
                Log.e("OnMenuClick", "action_tag_editor")
                val intent = Intent(activity, SongTagEditorActivity::class.java)
                intent.putExtra(AbsTagEditorActivity.EXTRA_ID, song.id)
                startActivity(intent)
                return true
            }

            R.id.action_details -> {
                Log.e("OnMenuClick", "action_details")
                SongDetailDialog.create(song).show(childFragmentManager, "SONG_DETAIL")
                return true
            }

            R.id.action_go_to_album -> {
                Log.e("OnMenuClick", "action_go_to_album")

                val intent = Intent(
                    activity,
                    com.videothems.videoplayer.music.musicplayer.activities.AlbumDetalitActivity::class.java
                )
                intent.putExtra(EXTRA_ALBUM_ID, song.albumId)
                startActivity(intent)
                activity!!.overridePendingTransition(
                    android.R.anim.fade_in,
                    android.R.anim.fade_out
                )
                return true
            }

            R.id.action_go_to_artist -> {
                Log.e("OnMenuClick", "action_go_to_artist")
                goToArtist(requireActivity())
                return true
            }

            R.id.now_playing -> {
                Log.e("OnMenuClick", "now_playing")
                val intent = Intent(activity, PlayingQueueActivity::class.java)
                startActivity(intent)
                activity!!.overridePendingTransition(
                    android.R.anim.fade_in,
                    android.R.anim.fade_out
                )
                return true
            }

            R.id.action_show_lyrics -> {
                Log.e("OnMenuClick", "action_show_lyrics")
                goToLyrics(requireActivity())
                return true
            }

            R.id.action_equalizer -> {
                Log.e("OnMenuClick", "action_equalizer")

                NavigationUtil.openEqualizer(requireActivity())

                return true
            }

            R.id.action_sleep_timer -> {
                Log.e("OnMenuClick", "action_sleep_timer")
                SleepTimerDialog().show(parentFragmentManager, "SLEEP_TIMER")
                return true
            }

            R.id.action_set_as_ringtone -> {
                Log.e("OnMenuClick", "action_set_as_ringtone")
                if (RingtoneManager.requiresDialog(requireActivity())) {
                    RingtoneManager.getDialog(requireActivity())
                }
                val ringtoneManager = RingtoneManager(requireActivity())
                ringtoneManager.setRingtone(song)
                return true
            }

            R.id.action_go_to_genre -> {
                Log.e("OnMenuClick", "action_go_to_genre")
                val retriever = MediaMetadataRetriever()
                val trackUri =
                    ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        song.id
                    )
                retriever.setDataSource(activity, trackUri)
                var genre: String? =
                    retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE)
                if (genre == null) {
                    genre = "Not Specified"
                }
                Toast.makeText(context, genre, Toast.LENGTH_SHORT).show()
                return true
            }
        }
        Log.e("OnMenuClick", "false")
        return false
    }

    private fun showLyricsIcon(item: MenuItem) {
        val icon =
            if (PreferenceUtil.showLyrics) R.drawable.ic_lyrics else R.drawable.ic_lyrics_outline
        val drawable: Drawable = com.videothems.videoplayer.music.musicplayer.util.RetroUtil.getTintedVectorDrawable(
            requireContext(),
            icon,
            toolbarIconColor()
        )
        item.isChecked = PreferenceUtil.showLyrics
        item.icon = drawable
    }

    abstract fun playerToolbar(): Toolbar?

    abstract fun onShow()

    abstract fun onHide()

    abstract fun onBackPressed(): Boolean

    abstract fun toolbarIconColor(): Int

    override fun onServiceConnected() {
        updateIsFavorite()
    }

    override fun onPlayingMetaChanged() {
        updateIsFavorite()
    }

    override fun onFavoriteStateChanged() {
        updateIsFavorite(animate = true)
    }

    protected open fun toggleFavorite(song: Song) {
        lifecycleScope.launch(IO) {
            val playlist: PlaylistEntity = libraryViewModel.favoritePlaylist()
            val songEntity = song.toSongEntity(playlist.playListId)
            val isFavorite = libraryViewModel.isSongFavorite(song.id)
            if (isFavorite) {
                libraryViewModel.removeSongFromPlaylist(songEntity)
            } else {
                libraryViewModel.insertSongs(listOf(song.toSongEntity(playlist.playListId)))
            }
            libraryViewModel.forceReload(ReloadType.Playlists)
            requireContext().sendBroadcast(Intent(MusicService.FAVORITE_STATE_CHANGED))
        }
    }

    fun updateIsFavorite(animate: Boolean = false) {
        lifecycleScope.launch(IO) {
            val isFavorite: Boolean =
                libraryViewModel.isSongFavorite(MusicPlayerRemote.currentSong.id)
            withContext(Main) {

                val icon = if (animate && VersionUtils.hasMarshmallow()) {
                    if (isFavorite) R.drawable.avd_favorite else R.drawable.avd_unfavorite
                } else {
                    if (isFavorite) R.drawable.avd_favorite else R.drawable.avd_unfavorite
                }

                val drawable: Drawable = com.videothems.videoplayer.music.musicplayer.util.RetroUtil.getTintedVectorDrawable(
                    requireContext(),
                    icon,
                    toolbarIconColor()
                )

                if (playerToolbar() != null) {
                    playerToolbar()?.menu?.findItem(R.id.action_toggle_favorite)?.apply {
                        setIcon(drawable)
                        title =
                            if (isFavorite) getString(R.string.action_remove_from_favorites)
                            else getString(R.string.action_add_to_favorites)
                        getIcon().also {
                            if (it is AnimatedVectorDrawable) {
                                it.start()
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        playerAlbumCoverFragment = whichFragment(R.id.playerAlbumCoverFragment)
        playerAlbumCoverFragment?.setCallbacks(this)

        view.findViewById<RelativeLayout>(R.id.statusBarShadow)?.hide()
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onResume() {
        super.onResume()
        val nps = PreferenceUtil.nowPlayingScreen
        if (nps == NowPlayingScreen.Circle
            || nps == NowPlayingScreen.Tiny
        ) {
            playerToolbar()?.menu?.removeItem(R.id.action_toggle_lyrics)
        } else {
            playerToolbar()?.menu?.findItem(R.id.action_toggle_lyrics)?.apply {
                isChecked = PreferenceUtil.showLyrics
                showLyricsIcon(this)
            }
        }
        requireView().setOnTouchListener(
            if (PreferenceUtil.swipeAnywhereToChangeSong) {
                SwipeDetector(
                    requireContext(),
                    playerAlbumCoverFragment?.viewPager,
                    requireView()
                )
            } else null
        )
    }

    class SwipeDetector(val context: Context, private val viewPager: ViewPager?, val view: View) :
        View.OnTouchListener {
        private var flingPlayBackController: GestureDetector = GestureDetector(
            context,
            object : GestureDetector.SimpleOnGestureListener() {
                override fun onScroll(
                    e1: MotionEvent?,
                    e2: MotionEvent,
                    distanceX: Float,
                    distanceY: Float
                ): Boolean {
                    return when {
                        abs(distanceX) > abs(distanceY) -> {
                            // Disallow Intercept Touch Event so that parent(BottomSheet) doesn't consume the events
                            view.parent.requestDisallowInterceptTouchEvent(true)
                            true
                        }

                        else -> {
                            false
                        }
                    }
                }
            })

        @SuppressLint("ClickableViewAccessibility")
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            viewPager?.dispatchTouchEvent(event)
            return flingPlayBackController.onTouchEvent(event)
        }
    }

    companion object {
        val TAG: String = AbsPlayerFragment::class.java.simpleName
        const val VISIBILITY_ANIM_DURATION: Long = 300
    }
}

fun goToArtist(activity: Activity) {
    val song = MusicPlayerRemote.currentSong
    val intent = Intent(activity, ArtistDetailActivity::class.java)
    intent.putExtra(EXTRA_ARTIST_ID, song.artistId)
    activity.startActivity(intent)
    activity.overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
}

fun goToAlbum(activity: Activity) {

    val song = MusicPlayerRemote.currentSong

    val intent = Intent(
        activity,
        com.videothems.videoplayer.music.musicplayer.activities.AlbumDetalitActivity::class.java
    )
    intent.putExtra(EXTRA_ALBUM_ID, song.albumId)
    activity.startActivity(intent)
    activity.overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
}

fun goToLyrics(activity: Activity) {
    if (activity !is MusicMainActivity) return
    activity.apply { // Hide Bottom Bar First, else Bottom Sheet doesn't collapse fully
        setBottomNavVisibility(false)
        if (getBottomSheetBehavior().state == BottomSheetBehavior.STATE_EXPANDED) {
            collapsePanel()
        }
        findNavController(R.id.fragment_container).navigate(
            R.id.lyrics_fragment,
            null,
            navOptions { launchSingleTop = true },
            null
        )
    }
}