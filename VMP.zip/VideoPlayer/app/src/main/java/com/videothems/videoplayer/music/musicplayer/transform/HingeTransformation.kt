package com.videothems.videoplayer.music.musicplayer.transform

import android.view.View
import androidx.core.view.isVisible
import androidx.viewpager.widget.ViewPager
import kotlin.math.abs

class HingeTransformation : ViewPager.PageTransformer {
    override fun transformPage(page: View, position: Float) {

        page.translationX = -position * page.width
        page.pivotX = 0f
        page.pivotY = 0f


        when {
            position < -1 -> {    // [-Infinity,-1)
                // This page is way off-screen to the left.
                page.alpha = 0f
                // The Page is off-screen but it may still interfere with
                // click events of current page if
                // it's visibility is not set to Gone
                page.isVisible = false
            }

            position <= 0 -> {    // [-1,0]
                page.rotation = 90 * abs(position)
                page.alpha = 1 - abs(position)
                page.isVisible = true
            }

            position <= 1 -> {    // (0,1]
                page.rotation = 0f
                page.alpha = 1f
                page.isVisible = true
            }

            else -> {    // (1,+Infinity]
                // This page is way off-screen to the right.
                page.alpha = 0f
                page.isVisible = false
            }
        }
    }
}