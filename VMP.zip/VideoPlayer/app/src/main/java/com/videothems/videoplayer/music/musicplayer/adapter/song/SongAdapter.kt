package com.videothems.videoplayer.music.musicplayer.adapter.song

import android.content.Intent
import android.content.res.ColorStateList
import android.content.res.Resources
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.fragment.app.FragmentActivity
import com.videothems.videoplayer.music.R
import com.videothems.videoplayer.music.musicplayer.EXTRA_ALBUM_ID
import com.videothems.videoplayer.music.musicplayer.adapter.base.AbsMultiSelectAdapter
import com.videothems.videoplayer.music.musicplayer.extensions.hide
import com.videothems.videoplayer.music.musicplayer.extensions.show
import com.videothems.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.videothems.videoplayer.music.musicplayer.glide.RetroMusicColoredTarget
import com.videothems.videoplayer.music.musicplayer.helper.MusicPlayerRemote
import com.videothems.videoplayer.music.musicplayer.helper.SortOrder
import com.videothems.videoplayer.music.musicplayer.helper.menu.SongMenuHelper
import com.videothems.videoplayer.music.musicplayer.helper.menu.SongsMenuHelper
import com.videothems.videoplayer.music.musicplayer.interfaces.ICabCallback
import com.videothems.videoplayer.music.musicplayer.interfaces.ICabHolder
import com.videothems.videoplayer.music.musicplayer.model.Song
import com.videothems.videoplayer.music.musicplayer.util.MusicUtil
import com.videothems.videoplayer.music.musicplayer.util.PreferenceUtil
import me.zhanghai.android.fastscroll.PopupTextProvider

/**
 * Created by Sujal Lathiya on 13/08/17.
 */

open class SongAdapter(
    override val activity: FragmentActivity,
    var dataSet: MutableList<Song>,
    protected var itemLayoutRes: Int,
    ICabHolder: ICabHolder?,
    showSectionName: Boolean = true
) : AbsMultiSelectAdapter<SongAdapter.ViewHolder, Song>(
    activity,
    ICabHolder,
    R.menu.menu_media_selection
), ICabCallback, PopupTextProvider {

    private var showSectionName = true

    init {
        this.showSectionName = showSectionName
        this.setHasStableIds(true)
    }

    open fun swapDataSet(dataSet: List<Song>) {
//        for (i in dataSet)
//        {
//            if (File(i.data).exists())
//            {
//                this.dataSet.add(i)
//            }
//        }
        this.dataSet = ArrayList(dataSet)
        notifyDataSetChanged()
    }

    override fun getItemId(position: Int): Long {
        return dataSet[position].id
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view =
            try {
                LayoutInflater.from(activity).inflate(itemLayoutRes, parent, false)
            } catch (e: Resources.NotFoundException) {
                LayoutInflater.from(activity).inflate(R.layout.item_list, parent, false)
            }
        return createViewHolder(view)
    }

    protected open fun createViewHolder(view: View): ViewHolder {
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val song = dataSet[position]
        val isChecked = isChecked(song)
        holder.itemView.isActivated = isChecked
        if (isChecked) {
            holder.menu?.hide()
        } else {
            holder.menu?.show()
        }
        holder.title?.text = getSongTitle(song)
        holder.text?.text = getSongText(song)
        holder.text2?.text = getSongText(song)
        loadAlbumCover(song, holder)
        val landscape = com.videothems.videoplayer.music.musicplayer.util.RetroUtil.isLandscape()
        if ((PreferenceUtil.songGridSize > 2 && !landscape) || (PreferenceUtil.songGridSizeLand > 5 && landscape)) {
            holder.menu?.isVisible = false
        }
    }

    private fun setColors(color: com.videothems.videoplayer.music.musicplayer.util.color.MediaNotificationProcessor, holder: ViewHolder) {
        if (holder.paletteColorContainer != null) {
            holder.title?.setTextColor(color.primaryTextColor)
            holder.text?.setTextColor(color.secondaryTextColor)
            holder.paletteColorContainer?.setBackgroundColor(color.backgroundColor)
            holder.menu?.imageTintList = ColorStateList.valueOf(color.primaryTextColor)
        }
        holder.mask?.backgroundTintList = ColorStateList.valueOf(color.primaryTextColor)
    }

    protected open fun loadAlbumCover(song: Song, holder: ViewHolder) {
        if (holder.image == null) {
            return
        }
        com.videothems.videoplayer.music.musicplayer.glide.GlideApp.with(activity).asBitmapPalette().songCoverOptions(song)
            .load(RetroGlideExtension.getSongModel(song))
            .into(object : RetroMusicColoredTarget(holder.image!!) {
                override fun onColorReady(colors: com.videothems.videoplayer.music.musicplayer.util.color.MediaNotificationProcessor) {
                    setColors(colors, holder)
                }
            })
    }

    private fun getSongTitle(song: Song): String {
        return song.title
    }

    private fun getSongText(song: Song): String {
        return song.artistName
    }

    private fun getSongText2(song: Song): String {
        return song.albumName
    }

    override fun getItemCount(): Int {
        return dataSet.size
    }

    override fun getIdentifier(position: Int): Song? {
        return dataSet[position]
    }

    override fun getName(song: Song): String {
        return song.title
    }

    override fun onMultipleItemAction(menuItem: MenuItem, selection: List<Song>) {
        SongsMenuHelper.handleMenuClick(activity, selection, menuItem.itemId)
    }

    override fun getPopupText(position: Int): String {

        if (position < dataSet.size) {
            val sectionName: String? = when (PreferenceUtil.songSortOrder) {
                SortOrder.SongSortOrder.SONG_A_Z, SortOrder.SongSortOrder.SONG_Z_A -> dataSet[position].title
                SortOrder.SongSortOrder.SONG_ALBUM -> dataSet[position].albumName
                SortOrder.SongSortOrder.SONG_ARTIST -> dataSet[position].artistName
                SortOrder.SongSortOrder.SONG_YEAR -> return MusicUtil.getYearString(dataSet[position].year)
                SortOrder.SongSortOrder.COMPOSER -> dataSet[position].composer
                SortOrder.SongSortOrder.SONG_ALBUM_ARTIST -> dataSet[position].albumArtist
                else -> {
                    return ""
                }
            }

            return MusicUtil.getSectionName(sectionName)
        } else {
            return ""
        }
    }

    open inner class ViewHolder(itemView: View) : com.videothems.videoplayer.music.musicplayer.adapter.base.MediaEntryViewHolder(itemView) {
        protected open var songMenuRes = SongMenuHelper.MENU_RES
        protected open val song: Song
            get() = dataSet[layoutPosition]

        init {
            menu?.setOnClickListener(object : SongMenuHelper.OnClickSongMenu(activity) {
                override val song: Song
                    get() = this@ViewHolder.song

                override val menuRes: Int
                    get() = songMenuRes

                override fun onMenuItemClick(item: MenuItem): Boolean {

                    return onSongMenuItemClick(item) || super.onMenuItemClick(item)
                }
            })
        }

        protected open fun onSongMenuItemClick(item: MenuItem): Boolean {
            if (image != null && image!!.isVisible) {
                when (item.itemId) {
                    R.id.action_go_to_album -> {
                        val intent = Intent(
                            activity,
                            com.videothems.videoplayer.music.musicplayer.activities.AlbumDetalitActivity::class.java
                        )
                        intent.putExtra(EXTRA_ALBUM_ID, song.albumId)
                        activity.startActivity(intent)
                        activity.overridePendingTransition(
                            android.R.anim.fade_in,
                            android.R.anim.fade_out
                        )
                        return true
                    }
                }
            }
            return false
        }

        override fun onClick(v: View?) {
            if (isInQuickSelectMode) {
                toggleChecked(layoutPosition)
            } else {
                MusicPlayerRemote.openQueue(dataSet, layoutPosition, true)
            }
        }

        override fun onLongClick(v: View?): Boolean {
            return false
        }
    }

    companion object {
        val TAG: String = SongAdapter::class.java.simpleName
    }
}
