package com.videothems.videoplayer.music.common.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;

import java.util.Objects;

public class NetworkChangeReceiver extends BroadcastReceiver {

    boolean isConnected;
    public static ConnectivityReceiverListener1 connectivityReceiverListener;

    @Override
    public void onReceive(final Context context, final Intent intent) {

        if (Objects.equals(intent.getAction(), ConnectivityManager.CONNECTIVITY_ACTION)) {
            NetworkInfo networkInfo = intent.getParcelableExtra(ConnectivityManager.EXTRA_NETWORK_INFO);
            if (networkInfo != null && networkInfo.getDetailedState() == NetworkInfo.DetailedState.CONNECTED) {
                Log.e("Network", "Internet YAY");
                isConnected = true;


            } else if (networkInfo != null && networkInfo.getDetailedState() == NetworkInfo.DetailedState.DISCONNECTED) {
                Log.e("Network", "No internet :(");

                isConnected = false;
            }

            if (connectivityReceiverListener != null) {
                Log.e("Network", "onReceive: 0`" + isConnected);
                connectivityReceiverListener.onNetworkConnectionChanged(isConnected);
            } else {
                Log.e("Network", "onReceive: 1" + isConnected);
            }

        }

        NetworkChangeModel.getInstance().changeState(isConnected);
    }

    public interface ConnectivityReceiverListener1 {
        void onNetworkConnectionChanged(boolean isConnected);
    }
}
