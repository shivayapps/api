package com.videothems.videoplayer.music.common.activity

import android.os.Handler
import android.os.Looper
import androidx.fragment.app.FragmentActivity
import com.videothems.videoplayer.music.common.base.BaseBindingActivity
import com.videothems.videoplayer.music.databinding.ActivityExitBinding
import com.videothems.videoplayer.music.musicplayer.extensions.setDrawBehindSystemBars
import com.videothems.videoplayer.music.musicplayer.extensions.setImmersiveFullscreen
import com.videothems.videoplayer.music.musicplayer.util.PreferenceUtil

class ExitActivity : BaseBindingActivity<ActivityExitBinding>() {

    override fun getActivityContext(): FragmentActivity {
        return this@ExitActivity
    }

    override fun setBinding(): ActivityExitBinding {
        return ActivityExitBinding.inflate(layoutInflater)
    }

    override fun initView() {
        super.initView()
        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        } else {
            setImmersiveFullscreen()
        }

        val handler = Handler(Looper.getMainLooper())
        val r = Runnable { finishAffinity() }
        handler.postDelayed(r, 1000)

    }

    override fun onPause() {
        super.onPause()
        finishAffinity()
    }
}