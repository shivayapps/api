package com.videothems.videoplayer.music.adloaders;

import android.content.Context;
import android.content.SharedPreferences;

public class PrefsAds {
    private final SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    public PrefsAds(Context context) {
        sharedPreferences = context.getSharedPreferences("mgvideo", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }

    public void setAdsDefaults(
//            String admob_openAd,
//            String admob_openAd_2,
//            String admob_banner,
//            String admob_banner_2,
//            String admob_interstitial,
//            String admob_interstitial_2,
//            String admob_native,
//            String admob_native_2,
            String is_Native_1,
            String is_Native_2,
            String is_Native_3,
            String is_Native_4,
            String is_Native_5,
            String is_Native_6,
            String is_Native_7,
            String is_Native_8,
            String is_Native_9,
            String is_Native_10,
            String redirectLink,
            String permissionNative,
            Boolean isBannerAdEnable,
            Boolean isInterstitialAdEnable,
            Boolean isNativeAdEnable) {
        editor = sharedPreferences.edit();
//        editor.putString("admob_openAd", admob_openAd);
//        editor.putString("admob_openAd_2", admob_openAd_2);
//        editor.putString("admob_banner", admob_banner);
//        editor.putString("admob_banner_2", admob_banner_2);
//        editor.putString("admob_interstitial", admob_interstitial);
//        editor.putString("admob_interstitial_2", admob_interstitial_2);
//        editor.putString("admob_native", admob_native);
//        editor.putString("admob_native_2", admob_native_2);
        editor.putString("is_Native_1", is_Native_1);
        editor.putString("is_Native_2", is_Native_2);
        editor.putString("is_Native_3", is_Native_3);
        editor.putString("is_Native_4", is_Native_4);
        editor.putString("is_Native_5", is_Native_5);
        editor.putString("is_Native_6", is_Native_6);
        editor.putString("is_Native_7", is_Native_7);
        editor.putString("is_Native_8", is_Native_8);
        editor.putString("is_Native_9", is_Native_9);
        editor.putString("is_Native_10", is_Native_10);
        editor.putString("redirectLink", redirectLink);
        editor.putString("permissionNative", permissionNative);
        editor.putBoolean("isBannerAdEnable", isBannerAdEnable);
        editor.putBoolean("isInterstitialAdEnable", isInterstitialAdEnable);
        editor.putBoolean("isNativeAdEnable", isNativeAdEnable);
        editor.apply();
    }

    public String getOpenAdId() {
        String var = "";
        if (sharedPreferences != null) {
            var = sharedPreferences.getString("admob_openAd", "");
        }
        return var;
    }

    public String getOpenAdReloadId() {
        String var = "";
        if (sharedPreferences != null) {
            var = sharedPreferences.getString("admob_openAd_2", "");
        }
        return var;
    }

    public String getBannerAdId() {
        String var = "";
        if (sharedPreferences != null) {
            var = sharedPreferences.getString("admob_banner", "");
        }
        return var;
    }

    public String getBannerAdReloadId() {
        String var = "";
        if (sharedPreferences != null) {
            var = sharedPreferences.getString("admob_banner", "");
        }
        return var;
    }

    public String getInterstitialAdLoaderId() {
        String var = "";
        if (sharedPreferences != null) {
            var = sharedPreferences.getString("admob_interstitial", "");
        }
        return var;
    }

    public String getInterstitialAdLoadReloadId() {
        String var = "";
        if (sharedPreferences != null) {
            var = sharedPreferences.getString("admob_interstitial_2", "");
        }
        return var;
    }

    public String getNativeId() {
        String var = "";
        if (sharedPreferences != null) {
            var = sharedPreferences.getString("admob_native", "");
        }
        return var;
    }

    public String getBackNativeId() {
        String var = "";
        if (sharedPreferences != null) {
            var = sharedPreferences.getString("admob_native_2", "");
        }
        return var;
    }

    public String isNative1() {
        String var = "";
        if (sharedPreferences != null) {
            var = sharedPreferences.getString("is_Native_1", "");
        }
        return var;
    }

    public String isNative2() {
        String var = "";
        if (sharedPreferences != null) {
            var = sharedPreferences.getString("is_Native_2", "");
        }
        return var;
    }

    public String isNative3() {
        String var = "";
        if (sharedPreferences != null) {
            var = sharedPreferences.getString("is_Native_3", "");
        }
        return var;
    }

    public String isNative4() {
        String var = "";
        if (sharedPreferences != null) {
            var = sharedPreferences.getString("is_Native_4", "");
        }
        return var;
    }

    public String isNative5() {
        String var = "";
        if (sharedPreferences != null) {
            var = sharedPreferences.getString("is_Native_5", "");
        }
        return var;
    }

    public String isNative6() {
        String var = "";
        if (sharedPreferences != null) {
            var = sharedPreferences.getString("is_Native_6", "");
        }
        return var;
    }

    public String isNative7() {
        String var = "";
        if (sharedPreferences != null) {
            var = sharedPreferences.getString("is_Native_7", "");
        }
        return var;
    }

    public String isNative8() {
        String var = "";
        if (sharedPreferences != null) {
            var = sharedPreferences.getString("is_Native_8", "");
        }
        return var;
    }

    public String isNative9() {
        String var = "";
        if (sharedPreferences != null) {
            var = sharedPreferences.getString("is_Native_9", "");
        }
        return var;
    }

    public String isNative10() {
        String var = "";
        if (sharedPreferences != null) {
            var = sharedPreferences.getString("is_Native_10", "");
        }
        return var;
    }

    public String permissionNative() {
        String var = "";
        if (sharedPreferences != null) {
            var = sharedPreferences.getString("permissionNative", "");
        }
        return var;
    }

    public String redirectLink() {
        String var = "";
        if (sharedPreferences != null) {
            var = sharedPreferences.getString("redirectLink", "");
        }
        return var;
    }

    public Boolean isNativeAdEnable() {
        boolean var = true;
        if (sharedPreferences != null) {
            var = sharedPreferences.getBoolean("isNativeAdEnable", true);
        }
        return var;
    }

    public Boolean isInterstitialAdEnable() {
        boolean var = true;
        if (sharedPreferences != null) {
            var = sharedPreferences.getBoolean("isInterstitialAdEnable", true);
        }
        return var;
    }

    public Boolean isBannerAdEnable() {
        boolean var = true;
        if (sharedPreferences != null) {
            var = sharedPreferences.getBoolean("isBannerAdEnable", true);
        }
        return var;
    }

}
