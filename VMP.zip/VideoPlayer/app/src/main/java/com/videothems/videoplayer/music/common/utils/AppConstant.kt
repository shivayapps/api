package com.videothems.videoplayer.music.common.utils

import com.videothems.videoplayer.music.videoplayer.model.VideoData

class AppConstant {

    companion object {
        var mVideoData: ArrayList<VideoData> = ArrayList()
        var mDataVideo: ArrayList<VideoData> = ArrayList()
        const val FOLDER_WHATSAPP = "WhatsApp"
        const val TYPE_VIDEO_LIST = "type_video_list"
        const val EVENT_NOTIFY_PLAYLIST = "NotifyPlaylist"
        var LAYOUT_TYPE = 0
        const val VIDEO_LIST = "VideoList"
        const val BUNDDLE = "bunddle"
        const val POSITION = "position"
        const val HIDDEN = "hidden"
        const val FOLDER_NAME = "FolderName"
        const val PLAYLIST_NAME = "PlaylistName"
        const val CHOOSE_IMAGE_TYPE = 1
        const val CHOOSE_VIDEO_TYPE = 2
        const val KEY_MEDIA_LIST = "mediaList"
        const val KEY_PATH_ID_LIST = "mediaPathIdList"
        const val KEY_MEDIA_TYPE = "mediaType"
        const val GET_VIDEO_INTENT = "get_video_intent"
        const val GET_IMAGE_INTENT = "get_image_intent"
        const val SECURITY_QUESTION = "security_question"
        const val SECURITY_ANSWER = "security_answer"
        const val FOLDER_NAMES = "folder_name"
        const val FOLDER_PATHS = "folder_path"
        var mFirstTime = false
        var isLong = false
        const val NOMEDIA = ".nomedia"
    }
}