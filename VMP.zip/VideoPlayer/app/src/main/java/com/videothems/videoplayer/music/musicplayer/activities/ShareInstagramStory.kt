package com.videothems.videoplayer.music.musicplayer.activities

import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore.Images.Media
import android.view.MenuItem
import androidx.core.view.drawToBitmap
import code.name.monkey.appthemehelper.ThemeStore
import code.name.monkey.appthemehelper.util.ColorUtil
import code.name.monkey.appthemehelper.util.MaterialValueHelper
import com.videothems.videoplayer.music.databinding.ActivityShareInstagramBinding
import com.videothems.videoplayer.music.musicplayer.activities.base.AbsBaseActivity
import com.videothems.videoplayer.music.musicplayer.extensions.setDrawBehindSystemBars
import com.videothems.videoplayer.music.musicplayer.extensions.setImmersiveFullscreen
import com.videothems.videoplayer.music.musicplayer.extensions.setLightStatusBar
import com.videothems.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.videothems.videoplayer.music.musicplayer.glide.RetroMusicColoredTarget
import com.videothems.videoplayer.music.musicplayer.model.Song
import com.videothems.videoplayer.music.musicplayer.util.PreferenceUtil
import com.videothems.videoplayer.music.musicplayer.util.Share

/**
 * Created by Sujal Lathiya on 2020-02-02.
 */

class ShareInstagramStory : AbsBaseActivity() {

    private lateinit var binding: ActivityShareInstagramBinding

    companion object {
        const val EXTRA_SONG = "extra_song"
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressed()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityShareInstagramBinding.inflate(layoutInflater)
        setContentView(binding.root)
        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        } else {
            setImmersiveFullscreen()
        }

        binding.icBack.setOnClickListener {
            onBackPressed()
        }


        val song = intent.extras?.getParcelable<Song>(EXTRA_SONG)
        song?.let { songFinal ->
            com.videothems.videoplayer.music.musicplayer.glide.GlideApp.with(this)
                .asBitmapPalette()
                .songCoverOptions(songFinal)
                .load(RetroGlideExtension.getSongModel(songFinal))
                .into(object : RetroMusicColoredTarget(binding.image) {
                    override fun onColorReady(colors: com.videothems.videoplayer.music.musicplayer.util.color.MediaNotificationProcessor) {
                        val isColorLight = ColorUtil.isColorLight(colors.backgroundColor)
                        setColors(isColorLight, colors.backgroundColor)
                    }
                })

            binding.shareTitle.text = songFinal.title
            binding.shareText.text = songFinal.artistName
            binding.shareButton.setOnClickListener {
                val path: String = Media.insertImage(
                    contentResolver,
                    binding.mainContent.drawToBitmap(Bitmap.Config.ARGB_8888),
                    "Design", null
                )
                val uri = Uri.parse(path)
                Share.shareStoryToSocial(
                    this@ShareInstagramStory,
                    uri
                )
            }
        }
        binding.shareButton.setTextColor(
            MaterialValueHelper.getPrimaryTextColor(
                this,
                ColorUtil.isColorLight(ThemeStore.accentColor(this))
            )
        )
        binding.shareButton.backgroundTintList =
            ColorStateList.valueOf(ThemeStore.accentColor(this))
    }

    private fun setColors(colorLight: Boolean, color: Int) {
        setLightStatusBar(colorLight)
        binding.tvTitle.setTextColor(
            MaterialValueHelper.getPrimaryTextColor(
                this@ShareInstagramStory,
                colorLight
            )
        )
//        binding.toolbar.navigationIcon?.setTintList(
//            ColorStateList.valueOf(
//                MaterialValueHelper.getPrimaryTextColor(
//                    this@ShareInstagramStory,
//                    colorLight
//                )
//            )
//        )
        binding.mainContent.background =
            GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(color, Color.BLACK)
            )
    }
}
