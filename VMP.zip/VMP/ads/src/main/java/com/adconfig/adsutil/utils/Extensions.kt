package com.adconfig.adsutil.utils

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log


fun Context.isOnline(): Boolean {
    var haveConnectedWifi = false
    var haveConnectedMobile = false
    val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    @SuppressLint("MissingPermission") val activeNetwork = cm.activeNetworkInfo
    if (activeNetwork != null) { // connected to the internet
        if (activeNetwork.type == ConnectivityManager.TYPE_WIFI) {
            if (activeNetwork.isConnected) haveConnectedWifi = true
        } else if (activeNetwork.type == ConnectivityManager.TYPE_MOBILE) {
            if (activeNetwork.isConnected) haveConnectedMobile = true
        }
    }
    return haveConnectedWifi || haveConnectedMobile
}

//fun Context.isOnlineOld(): Boolean {
//    val connectivityManager =
//        this.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
//    val capabilities =
//        connectivityManager.getNetworkCapabilities(connectivityManager.activeNetwork)
//    if (capabilities != null) {
//        if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
//            Log.i("Internet", "NetworkCapabilities.TRANSPORT_CELLULAR")
//            return true
//        } else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
//            Log.i("Internet", "NetworkCapabilities.TRANSPORT_WIFI")
//            return true
//        } else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
//            Log.i("Internet", "NetworkCapabilities.TRANSPORT_ETHERNET")
//            return true
//        }
//    }
//    return false
//}