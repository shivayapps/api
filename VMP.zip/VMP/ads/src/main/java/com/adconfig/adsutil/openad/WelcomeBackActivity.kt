package com.adconfig.adsutil.openad

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.adconfig.adsutil.openad.OpenAdHelper.isShowOpenAd
import com.adconfig.adsutil.utils.LoadingDialog
import com.adconfig.adsutil.utils.SmUtils.isConnected
import com.adconfig.adsutil.utils.delayExecution
import com.adconfig.adsutil.utils.isAnyAdShowing
import com.adconfig.databinding.ActivityWelcomeBackBinding

import java.util.Timer
import kotlin.concurrent.timerTask

class WelcomeBackActivity : AppCompatActivity() {

    lateinit var openTimer: CountDownTimer
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        binding = ActivityWelcomeBackBinding.inflate(layoutInflater)
//        setContentView(binding.root)
//        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//        binding.root.setBackgroundColor(Color.TRANSPARENT)

        val progressDialog = LoadingDialog(this, "Loading...")
        progressDialog.show()

        if (!isConnected(this)) {
            finish()
            return
        }

        createOpenTimer()
        OpenAdHelper.loadOpenAd(this,{
            openTimer.cancel()

            isShowOpenAd { isClosed ->//onAdClosed
                Log.d("HomeTAG", "nextScreen.001")
                afterAdHandler()
            }
        })
    }

    private fun createOpenTimer() {
        Log.d("HomeTAG", "createTimerSec")
        val totalTimeMillis = 6000L
        openTimer = object : CountDownTimer(totalTimeMillis, 1000) {
            override fun onTick(l: Long) {

            }

            override fun onFinish() {
                Log.d("HomeTAG", "gotoMainScreen.007")
                afterAdHandler()
            }
        }
        openTimer.start()
    }
    fun afterAdHandler() {
        finish()
    }

    override fun onPause() {
        super.onPause()
        if (!isAnyAdShowing) {
            finish()
        }
    }

}