package com.adconfig.adsutil.admob


enum class NativeLayoutType {
    NativeBanner,
    NativeMedium,
    NativeButtonBottom,
    NativeBig,
}