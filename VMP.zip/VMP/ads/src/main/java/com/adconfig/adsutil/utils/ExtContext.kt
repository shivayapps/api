package com.adconfig.adsutil.utils

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.annotation.ColorRes
import androidx.core.content.ContextCompat

var isNeedToShowAds = true
var isAppForeground = false
var isAnyAdOpen = false
var isInterstitialAdShow = false

var isAnyAdShowing: Boolean = false
//var openAdCounter: Int = 0
var needToBlockOpenAdInternally: Boolean = false

fun Context.getcolor(@ColorRes id: Int) = ContextCompat.getColor(this, id)


fun Activity.delayExecution(millis: Long, callback: () -> Unit) {
    Handler(Looper.myLooper()!!).postDelayed({
        callback()
    }, millis)
}