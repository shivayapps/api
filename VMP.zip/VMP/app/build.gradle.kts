plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
    id("androidx.navigation.safeargs.kotlin")
    id("com.google.gms.google-services")
    id("com.google.firebase.crashlytics")
}

android {

    namespace = "com.mediaplayer.video.player.videoplayer.music"
    compileSdk = 35
    //com.videothems.videoplayer.music

    defaultConfig {
        applicationId = "com.mediaplayer.video.player.videoplayer.music"
        minSdk = 23
        targetSdk = 35
        versionCode = 27
        versionName = "2.7"

        multiDexEnabled = true
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    signingConfigs {
        create("release") {
            storeFile = rootProject.file("app/com.mediaplayer.video.player.videoplayer.music.jks")
            storePassword = "com.mediaplayer.video.player.videoplayer.music"
            keyAlias = "com.mediaplayer.video.player.videoplayer.music"
            keyPassword = "com.mediaplayer.video.player.videoplayer.music"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        getByName("release") {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")

        }
    }

    //flavorDimensions("default")
    flavorDimensions += "default"
    productFlavors {
        create("TestAd") {
            isDefault = true

            resValue("string","ads_application_id", "ca-app-pub-3940256099942544~3347511713")
            resValue("string","ads_inter", "ca-app-pub-3940256099942544/1033173712")
            resValue("string","ads_open", "ca-app-pub-3940256099942544/9257395921")

            resValue("string","native_language","ca-app-pub-3940256099942544/2247696110")

            resValue("string","bannerMain","ca-app-pub-3940256099942544/6300978111")
            resValue("string","bannerDetailList","ca-app-pub-3940256099942544/6300978111")
            resValue("string","bannerArtistDetail","ca-app-pub-3940256099942544/6300978111")
            resValue("string","bannerWaStatus","ca-app-pub-3940256099942544/6300978111")
            resValue("string","bannerAlbumDetail","ca-app-pub-3940256099942544/6300978111")
            resValue("string","bannerTheme","ca-app-pub-3940256099942544/6300978111")
            resValue("string","bannerThemeSave","ca-app-pub-3940256099942544/6300978111")
            resValue("string","bannerWaStatusDownload","ca-app-pub-3940256099942544/6300978111")
            resValue("string","bannerMusicPlayer","ca-app-pub-3940256099942544/6300978111")
            resValue("string","bannerMusicSearch","ca-app-pub-3940256099942544/6300978111")
            resValue("string","bannerAllVideo","ca-app-pub-3940256099942544/6300978111")
            resValue("string","bannerLanguage","ca-app-pub-3940256099942544/6300978111")
            resValue("string","bannerFavorite","ca-app-pub-3940256099942544/6300978111")
            resValue("string","bannerVideoSearch","ca-app-pub-3940256099942544/6300978111")

//            resValue("string","bannerSetting","ca-app-pub-3940256099942544/6300978111")
        }

        create("TestAdManager") {

            resValue("string","ads_application_id", "ca-app-pub-3940256099942544~3347511713")
            resValue("string","ads_inter", "/21775744923/example/interstitial")
            resValue("string","ads_open", "/21775744923/example/app-open")

            resValue("string","native_language","/21775744923/example/native")

            resValue("string","bannerMain","/21775744923/example/fixed-size-banner")
            resValue("string","bannerDetailList","/21775744923/example/fixed-size-banner")
            resValue("string","bannerArtistDetail","/21775744923/example/fixed-size-banner")
            resValue("string","bannerWaStatus","/21775744923/example/fixed-size-banner")
            resValue("string","bannerAlbumDetail","/21775744923/example/fixed-size-banner")
            resValue("string","bannerTheme","/21775744923/example/fixed-size-banner")
            resValue("string","bannerThemeSave","/21775744923/example/fixed-size-banner")
            resValue("string","bannerWaStatusDownload","/21775744923/example/fixed-size-banner")
            resValue("string","bannerMusicPlayer","/21775744923/example/fixed-size-banner")
            resValue("string","bannerMusicSearch","/21775744923/example/fixed-size-banner")
            resValue("string","bannerAllVideo","/21775744923/example/fixed-size-banner")
            resValue("string","bannerLanguage","/21775744923/example/fixed-size-banner")
            resValue("string","bannerFavorite","/21775744923/example/fixed-size-banner")
            resValue("string","bannerVideoSearch","/21775744923/example/fixed-size-banner")

//            resValue("string","bannerSetting","ca-app-pub-3940256099942544/6300978111")
        }
        create("LiveAd") {

            resValue("string","ads_application_id", "ca-app-pub-2750800778809761~5534022037")
            resValue("string","ads_inter", "ca-app-pub-2750800778809761/3979351497")    //need review
            resValue("string","ads_open", "ca-app-pub-2750800778809761/9896186298")     //need review

            resValue("string","native_language","ca-app-pub-2750800778809761/7286334827")

            resValue("string","bannerMain","ca-app-pub-2750800778809761/1557202281")
            resValue("string","bannerDetailList","ca-app-pub-2750800778809761/6026176971")
            resValue("string","bannerArtistDetail","ca-app-pub-2750800778809761/5049789617")
            resValue("string","bannerWaStatus","ca-app-pub-2750800778809761/4026899282")
            resValue("string","bannerAlbumDetail","ca-app-pub-2750800778809761/9554558134")
            resValue("string","bannerTheme","ca-app-pub-2750800778809761/9751451956")
            resValue("string","bannerThemeSave","ca-app-pub-2750800778809761/9479989218")

            resValue("string","bannerWaStatusDownload","ca-app-pub-2750800778809761/1400735949")    //need review
            resValue("string","bannerMusicPlayer","ca-app-pub-2750800778809761/6928394794")
            resValue("string","bannerMusicSearch","ca-app-pub-2750800778809761/5615313124")
            resValue("string","bannerAllVideo","ca-app-pub-2750800778809761/3736707947")
            resValue("string","bannerLanguage","ca-app-pub-2750800778809761/4499125274")
            resValue("string","bannerFavorite","ca-app-pub-2750800778809761/1265004576")
            resValue("string","bannerVideoSearch","ca-app-pub-2750800778809761/8951922904")

//            resValue("string","ads_reward", "ca-app-pub-2750800778809761/3289086356")
//            resValue("string","ads_reward_int", "ca-app-pub-2750800778809761/1630683468")
//            resValue("string","bannerSetting","ca-app-pub-2750800778809761/9773850292")
        }

    }
    buildFeatures {
        buildConfig = true
        viewBinding = true
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.toVersion(1.8)
        targetCompatibility = JavaVersion.toVersion(1.8)
    }

    kotlinOptions {
        jvmTarget = "1.8"
    }
}

dependencies {


    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.aar"))))

    implementation("androidx.core:core-ktx:1.7.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.9.0-beta01")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")

    implementation("androidx.browser:browser:1.4.0")

    implementation("com.intuit.sdp:sdp-android:1.1.0")
    implementation("com.intuit.ssp:ssp-android:1.1.0")
    implementation("androidx.palette:palette:1.0.0")

    implementation("com.airbnb.android:lottie:6.0.1")

    implementation(platform("com.google.firebase:firebase-bom:33.1.2"))
    implementation("com.google.firebase:firebase-crashlytics-ktx")
    implementation("com.google.firebase:firebase-analytics-ktx")
    implementation("com.google.firebase:firebase-messaging")
    implementation("com.google.firebase:firebase-dynamic-links")
    implementation("com.google.firebase:firebase-config")

    implementation(project(":gallery"))
    implementation(project(":ads"))

    implementation("com.google.android.play:app-update:2.1.0")
    implementation("com.google.android.play:review-ktx:2.0.1")
    implementation("com.google.android.gms:play-services-ads:22.3.0")
    implementation("androidx.multidex:multidex:2.0.1")

    val exo_version = "2.18.2"
    implementation("com.google.android.exoplayer:exoplayer-core:$exo_version")
    implementation("com.google.android.exoplayer:exoplayer-dash:$exo_version")
    implementation("com.google.android.exoplayer:exoplayer-ui:$exo_version")
    implementation("com.google.android.exoplayer:exoplayer-datasource:$exo_version")
    implementation("com.google.android.exoplayer:exoplayer-decoder:$exo_version")
    implementation("com.google.android.exoplayer:exoplayer-database:$exo_version")
    implementation("com.google.android.exoplayer:extension-mediasession:$exo_version")
    implementation("com.google.android.exoplayer:exoplayer-hls:$exo_version")
    implementation("com.google.android.exoplayer:exoplayer-smoothstreaming:$exo_version")
    implementation("com.google.android.exoplayer:exoplayer-rtsp:$exo_version")

    implementation("com.ibm.icu:icu4j:70.1")
    implementation("com.squareup.okhttp3:okhttp:4.9.3")
    implementation("com.jakewharton.retrofit:retrofit2-kotlin-coroutines-adapter:0.9.2")
    implementation("org.greenrobot:eventbus:3.3.1")

    val room_version = "2.6.0-alpha03"
    implementation("androidx.room:room-runtime:$room_version")
    implementation("androidx.room:room-ktx:$room_version")
    ksp("androidx.room:room-compiler:$room_version")

    implementation("androidx.gridlayout:gridlayout:1.0.0")
    implementation("androidx.cardview:cardview:1.0.0")
    implementation("androidx.annotation:annotation:1.3.0")
    implementation("androidx.recyclerview:recyclerview:1.3.0-alpha01")
    implementation("androidx.preference:preference-ktx:1.2.0")
    implementation("androidx.palette:palette-ktx:1.0.0")

    implementation("androidx.mediarouter:mediarouter:1.2.6")
    implementation("com.google.android.gms:play-services-cast-framework:21.0.1")

    implementation("org.nanohttpd:nanohttpd:2.3.1")
    implementation("androidx.navigation:navigation-runtime-ktx:2.8.2")
    implementation("androidx.navigation:navigation-fragment-ktx:2.8.2")
    implementation("androidx.navigation:navigation-ui-ktx:2.8.2")

    val lifecycle_version = "2.5.1"
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:$lifecycle_version")
    implementation("androidx.lifecycle:lifecycle-livedata-ktx:$lifecycle_version")
    implementation("androidx.lifecycle:lifecycle-livedata:$lifecycle_version")
    implementation("androidx.lifecycle:lifecycle-common-java8:$lifecycle_version")

    val retrofit_version = "2.9.0"
    implementation("com.squareup.retrofit2:retrofit:$retrofit_version")
    implementation("com.squareup.retrofit2:converter-gson:$retrofit_version")
    implementation("com.squareup.okhttp3:logging-interceptor:5.0.0-alpha.4")

    val material_dialog_version = "3.3.0"
    implementation("com.afollestad.material-dialogs:core:$material_dialog_version")
    implementation("com.afollestad.material-dialogs:input:$material_dialog_version")
    implementation("com.afollestad.material-dialogs:color:$material_dialog_version")
    implementation("com.afollestad.material-dialogs:bottomsheets:$material_dialog_version")

    implementation("com.afollestad:material-cab:2.0.1")

    //implementation("org.jetbrains.kotlin:kotlin-stdlib-jdk8:1.9.10")

    val kotlin_coroutines_version = "1.6.0"
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:$kotlin_coroutines_version")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:$kotlin_coroutines_version")

    val koin_version = "3.1.5"
    implementation("io.insert-koin:koin-core:$koin_version")
    implementation("io.insert-koin:koin-android:$koin_version")

    implementation("com.github.bumptech.glide:glide:4.16.0")
    ksp("com.github.bumptech.glide:compiler:4.16.0")
    implementation("com.github.bumptech.glide:okhttp3-integration:4.16.0")

    implementation("com.h6ah4i.android.widget.advrecyclerview:advrecyclerview:1.0.0")
    implementation("com.github.bosphere.android-fadingedgelayout:fadingedgelayout:1.0.0")
    implementation("net.yslibrary.keyboardvisibilityevent:keyboardvisibilityevent:3.0.0-RC3")
    implementation("dev.chrisbanes.insetter:insetter:0.6.1")
    implementation("org.eclipse.mylyn.github:org.eclipse.egit.github.core:2.1.5")
    implementation("com.github.Adonai:jaudiotagger:2.3.15")
    implementation("com.r0adkll:slidableactivity:2.1.0")
    implementation("me.zhanghai.android.fastscroll:library:1.1.7")
    implementation("me.tankery.lib:circularSeekBar:1.3.2")
    implementation("com.tbuonomo:dotsindicator:5.0")

}
