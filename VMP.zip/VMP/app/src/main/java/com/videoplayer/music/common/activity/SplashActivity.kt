package com.videoplayer.music.common.activity

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.preference.PreferenceManager
import code.name.monkey.appthemehelper.util.VersionUtils
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.appopen.AppOpenAd.AppOpenAdLoadCallback
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.mediaplayer.video.player.videoplayer.music.R

import com.videoplayer.music.common.base.BaseBindingActivity
import com.videoplayer.music.common.database.HideVideoDatabase
import com.videoplayer.music.common.utils.DATABASE_PATH
import com.videoplayer.music.common.utils.addNoMedia
import com.videoplayer.music.common.utils.ensureBackgroundThread
import com.videoplayer.music.common.utils.isOnline
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivitySplashBinding
import com.videoplayer.music.musicplayer.App
import com.videoplayer.music.musicplayer.FIRST_KEY
import com.videoplayer.music.musicplayer.GET_STARTED
import com.videoplayer.music.musicplayer.INTENT_KEY
import com.videoplayer.music.musicplayer.MATERIAL_YOU
import com.videoplayer.music.musicplayer.RATE_COUNT
import com.videoplayer.music.musicplayer.extensions.resolveColor
import com.videoplayer.music.musicplayer.extensions.setDrawBehindSystemBars
import com.videoplayer.music.musicplayer.extensions.setImmersiveFullscreen
import com.videoplayer.music.musicplayer.extensions.setStatusBarColor
import com.videoplayer.music.musicplayer.service.MusicService
import com.videoplayer.music.musicplayer.util.PreferenceUtil
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.Date
import java.util.concurrent.Callable

@SuppressLint("CustomSplashScreen")
class SplashActivity : BaseBindingActivity<ActivitySplashBinding>() {

    private var isIntent: Boolean = false
    private var isLoadingAd = false
    private var isShowingAd = false
    private var loadTime: Long = 0

    override fun getActivityContext(): FragmentActivity {
        return this@SplashActivity
    }

    override fun setBinding(): ActivitySplashBinding {
        return ActivitySplashBinding.inflate(layoutInflater)
    }

    override fun initViewAction() {

    }

    private fun isServiceRunning(context: Context, serviceClass: Class<*>): Boolean {
        val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        for (service in manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.name == service.service.className) {
                return true
            }
        }
        return false
    }

    override fun initView() {
        super.initView()

        try {
            if (checkPermissionBelow30()) {
                copyDB()
            }
        } catch (e: Exception) {
            Log.e(TAG, "backupDatabase: ex: $e")
        }

//        if (isServiceRunning(this@SplashActivity, MusicService::class.java)) {
//            App.isSplashResumeOn = true
//        }

        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        } else {
            setImmersiveFullscreen()
        }

        setStatusBarColor(resolveColor(R.attr.mainBackgroundColor))

        val eDir = PreferenceManager.getDefaultSharedPreferences(App.getContext())
        val a = eDir.getInt(RATE_COUNT, 0) + 1
        eDir.edit().putInt(RATE_COUNT, a).apply()

        if (VersionUtils.hasS()) {
            val editor = PreferenceManager.getDefaultSharedPreferences(App.getContext()).edit()
            editor.putBoolean(MATERIAL_YOU, false)
            editor.apply()
        }


        if (isOnline) {
            withDelay(5000) {
                if (!isIntent) {
                    isIntent = true
                    showAdIfAvailable(this@SplashActivity)
                }
                null
            }
            fetchData()
        } else {
            withDelay(3000) {
                showAdIfAvailable(this@SplashActivity)
                null
            }
        }
    }

    private fun fetchData() {
        val startTime = System.currentTimeMillis()
        val hashMap = HashMap<String, Any>()
        val remoteConfig = FirebaseRemoteConfig.getInstance()
        remoteConfig.setDefaultsAsync(R.xml.remote_config_defaults)
        remoteConfig.setConfigSettingsAsync(
            FirebaseRemoteConfigSettings.Builder().setMinimumFetchIntervalInSeconds(0).build()
        )
        remoteConfig.setDefaultsAsync(hashMap)

        remoteConfig.fetchAndActivate().addOnCompleteListener { task ->
//            val fetch = remoteConfig.getString("adIdsJson")
//            val jsonArray = JSONArray(fetch)
//            prefs.setAdsDefaults(
//
//                remoteConfig.getString("is_Native_1"),
//                remoteConfig.getString("is_Native_2"),
//                remoteConfig.getString("is_Native_3"),
//                remoteConfig.getString("is_Native_4"),
//                remoteConfig.getString("is_Native_5"),
//                remoteConfig.getString("is_Native_6"),
//                remoteConfig.getString("is_Native_7"),
//                remoteConfig.getString("is_Native_8"),
//                remoteConfig.getString("is_Native_9"),
//                remoteConfig.getString("is_Native_10"),
//                remoteConfig.getString("redirectLink"),
//                remoteConfig.getString("permissionNative"),
//                remoteConfig.getBoolean("isBannerAdEnable"),
//                remoteConfig.getBoolean("isInterstitialAdEnable"),
//                remoteConfig.getBoolean("isNativeAdEnable")
//            )
//
//            if (task.isSuccessful) {
//                remoteConfig.fetchAndActivate()
//            }
        }
    }

    private fun goNextActivity() {
        val editor = PreferenceManager.getDefaultSharedPreferences(App.getContext())
        if (!editor.getBoolean(GET_STARTED, false)) {
            val intent = Intent(mActivity, LanguageActivity::class.java)
            intent.putExtra(INTENT_KEY, FIRST_KEY)
            startActivity(intent)
            finish()
        } else {
            if (!checkPermissionBelow30()) {
                val intent = Intent(mActivity, PermissionActivity::class.java)
                startActivity(intent)
                finish()
            } else {
                Handler(Looper.getMainLooper()).postDelayed({
                    val intent = Intent(mActivity, MainActivity::class.java)
                    startActivity(intent)
                    finish()
                }, 10)
            }
        }
    }

    private fun showAdIfAvailable(activity: Activity) {
//        showAdIfAvailable(activity, object : App.OnShowAdCompleteListener {
//            override fun onShowAdComplete() {
                // Empty because the user will go back to the activity that shows the ad.
                goNextActivity()
//            }
//        })
    }



//    private fun isAdAvailable(): Boolean {
//        // Ad references in the app open beta will time out after four hours, but this time limit
//        // may change in future beta versions. For details, see:
//        // https://support.google.com/admob/answer/9341964?hl=en
//        return appOpenAd != null && wasLoadTimeLessThanNHoursAgo(4)
//    }

    private fun wasLoadTimeLessThanNHoursAgo(numHours: Long): Boolean {
        val dateDifference: Long = Date().time - loadTime
        val numMilliSecondsPerHour: Long = 3600000
        return dateDifference < numMilliSecondsPerHour * numHours
    }


    private fun checkPermissionBelow30(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            !(ContextCompat.checkSelfPermission(
                this, Manifest.permission.READ_MEDIA_IMAGES
            ) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(
                this, Manifest.permission.READ_MEDIA_AUDIO
            ) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(
                this, Manifest.permission.READ_MEDIA_VIDEO
            ) != PackageManager.PERMISSION_GRANTED)
        } else {
            !(ContextCompat.checkSelfPermission(
                this, Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(
                this, Manifest.permission.READ_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED)
        }
    }

    private fun copyDB() {
        val dbFile: File = getDatabasePath("videoPlayer.db")
        val sDir = File(DATABASE_PATH)
        val parentFile = File(sDir.parentFile!!.absolutePath)

        if (!parentFile.exists()) {
            parentFile.mkdir()
        }

        if (!sDir.exists()) {
            sDir.mkdir()
        }

        val saveFile = File("$DATABASE_PATH/videoPlayer.db")

        try {
            if (!saveFile.exists()) {
                ensureBackgroundThread {
                    addNoMedia(sDir.absolutePath) {
                        addNoMedia(sDir.parentFile!!.absolutePath) {}
                    }
                }
                val bufferSize = 8 * 1024
                val buffer = ByteArray(bufferSize)
                var bytesRead: Int
                val saveDb: OutputStream = FileOutputStream(saveFile)
                val inDb: InputStream = FileInputStream(dbFile)
                while (inDb.read(buffer, 0, bufferSize).also { bytesRead = it } > 0) {
                    saveDb.write(buffer, 0, bytesRead)
                }
                saveDb.flush()
                inDb.close()
                saveDb.close()
                Log.e(TAG, "backupDatabase: Db Backup successful...")
                HideVideoDatabase.destroyInstance()
                try {
                    HideVideoDatabase.getInstance(this)
                } catch (e: Exception) {
                    Log.e(TAG, "saveFile: ex: $e")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "backupDatabase: ex: $e")
        }
    }

    private fun withDelay(delay: Int, callable: Callable<Void?>) {
        Handler().postDelayed({
            try {
                callable.call()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }, delay.toLong())
    }

}