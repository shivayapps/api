package com.videoplayer.music.common.status

import android.content.Intent
import androidx.appcompat.content.res.AppCompatResources
import androidx.fragment.app.FragmentActivity
import androidx.preference.PreferenceManager
import androidx.viewpager.widget.ViewPager
import com.mediaplayer.video.player.videoplayer.music.R
import com.videoplayer.music.common.base.BaseBindingActivity
import com.videoplayer.music.common.status.adapter.ViewPagerAdapter
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityStatusIntroBinding
import com.videoplayer.music.musicplayer.App
import com.videoplayer.music.musicplayer.GENERAL_THEME
import com.videoplayer.music.musicplayer.IMAGE_THEME
import com.videoplayer.music.musicplayer.extensions.makeStatusBarTransparent
import com.videoplayer.music.musicplayer.extensions.resolveColor
import com.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.videoplayer.music.musicplayer.util.PreferenceUtil.whatsAppShowIntro
import org.jetbrains.anko.backgroundColor

class StatusIntroActivity : BaseBindingActivity<ActivityStatusIntroBinding>() {

//    private lateinit var viewPagerAdapter: ViewPagerAdapter
//    private lateinit var imageList: List<Int>

    override fun setBinding(): ActivityStatusIntroBinding {
        return ActivityStatusIntroBinding.inflate(layoutInflater)
    }

    override fun getActivityContext(): FragmentActivity {
        return this@StatusIntroActivity
    }

    override fun initView() {
        super.initView()

        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext())
            .getString(IMAGE_THEME, "")

        val edit =
            PreferenceManager.getDefaultSharedPreferences(App.getContext()).getInt(GENERAL_THEME, 0)

        makeStatusBarTransparent()

        if (editors == "theme_image") {
            mBinding.root.background =
                RetroGlideExtension.getUserImageTheme(this@StatusIntroActivity)
            mBinding.constraintLayout.background = null
        } else if (editors == "theme_gradient") {
            mBinding.root.background =
                AppCompatResources.getDrawable(this, RetroGlideExtension.getUserGradientTheme())
            mBinding.constraintLayout.background = null
        } else if (edit >= 0) {
            mBinding.root.background = null
            mBinding.root.backgroundColor = resolveColor(R.attr.mainBackgroundColor)
        }

        with(mBinding) {
            tvTitle.text = getString(R.string.intro)
        }

//        viewPagerSetup()

        initItem()
    }

    private fun initItem() {
        mBinding.ivBack.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
        mBinding.idIVImage.setImageResource(R.drawable.status_intro_1)

        mBinding.btnNext.setOnClickListener {
//            when (mBinding.wpViewpager.currentItem) {
//                0 -> {
//                    mBinding.wpViewpager.currentItem = 1
//                }
//
//                1 -> {
                    whatsAppShowIntro = true
                    val intent = Intent(this@StatusIntroActivity, WhatsappStatusActivity::class.java)
                    launchActivity(intent)
                    finish()
//                }
//            }
        }

    }

//    private fun viewPagerSetup() {
//        imageList = ArrayList()
//        imageList = imageList + R.drawable.status_intro_1
//
//        // on below line we are initializing our view
//        // pager adapter and adding image list to it.
//        viewPagerAdapter = ViewPagerAdapter(this@StatusIntroActivity, imageList)
//
//        // on below line we are setting
//        // adapter to our view pager.
//        mBinding.wpViewpager.adapter = viewPagerAdapter
//        mBinding.dot1.setViewPager(mBinding.wpViewpager)
//
//
//        mBinding.wpViewpager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
//            override fun onPageScrolled(
//                position: Int,
//                positionOffset: Float,
//                positionOffsetPixels: Int,
//            ) {
//
//            }
//
//            override fun onPageSelected(position: Int) {
//                if (position == 0) {
//                    mBinding.btnNext.text = "Next"
//                } else {
//                    mBinding.btnNext.text = "Done"
//                }
//            }
//
//            override fun onPageScrollStateChanged(state: Int) {
//
//            }
//        })
//    }

}