package com.videoplayer.music.musicplayer.fragment

import android.view.LayoutInflater
import android.view.ViewGroup
import com.videoplayer.music.common.base.BaseBindingFragment
import com.mediaplayer.video.player.videoplayer.music.databinding.FragmentSongFolderBinding


class SongFolderFragment : BaseBindingFragment<FragmentSongFolderBinding>() {
    override fun setBinding(
        layoutInflater: LayoutInflater,
        container: ViewGroup?
    ): FragmentSongFolderBinding {
        return FragmentSongFolderBinding.inflate(layoutInflater)
    }

    companion object {
        fun newInstance(): SongFolderFragment {
            return SongFolderFragment()
        }
    }

}