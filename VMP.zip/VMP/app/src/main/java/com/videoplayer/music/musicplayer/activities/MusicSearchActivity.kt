package com.videoplayer.music.musicplayer.activities

import android.view.View
import androidx.appcompat.content.res.AppCompatResources
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.commit
import androidx.preference.PreferenceManager
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.mediaplayer.video.player.videoplayer.music.R

import com.videoplayer.music.common.base.BaseBindingActivity
import com.videoplayer.music.common.utils.isOnline
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityMusicSearchBinding
import com.videoplayer.music.common.utils.AdCache
import com.videoplayer.music.musicplayer.App
import com.videoplayer.music.musicplayer.GENERAL_THEME
import com.videoplayer.music.musicplayer.IMAGE_THEME
import com.videoplayer.music.musicplayer.extensions.makeStatusBarTransparent
import com.videoplayer.music.musicplayer.extensions.resolveColor
import com.videoplayer.music.musicplayer.fragments.search.SearchFragment
import com.videoplayer.music.musicplayer.glide.RetroGlideExtension
import org.jetbrains.anko.backgroundColor

class MusicSearchActivity : BaseBindingActivity<ActivityMusicSearchBinding>() {

    private val playingQueueFragment = SearchFragment.newInstance()

    override fun getActivityContext(): FragmentActivity {
        return this@MusicSearchActivity
    }

    override fun setBinding(): ActivityMusicSearchBinding {
        return ActivityMusicSearchBinding.inflate(layoutInflater)
    }

    override fun initView() {
        super.initView()
        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext())
            .getString(IMAGE_THEME, "")

        val edit =
            PreferenceManager.getDefaultSharedPreferences(App.getContext()).getInt(GENERAL_THEME, 0)

        makeStatusBarTransparent()

        if (editors == "theme_image") {
            mBinding.root.background =
                RetroGlideExtension.getUserImageTheme(this@MusicSearchActivity)
        } else if (editors == "theme_gradient") {
            mBinding.root.background = AppCompatResources.getDrawable(this, RetroGlideExtension.getUserGradientTheme())
        } else if (edit >= 0) {
            mBinding.root.background = null
            mBinding.root.backgroundColor = resolveColor(R.attr.mainBackgroundColor)
        }

        supportFragmentManager.commit {
            replace(R.id.fm_container, playingQueueFragment)
        }
        setNative()
    }

    var mAdView: AdView?=null
    var isAdLoaded = false
    private fun setNative() {
        if (isOnline) {
            val adId = getString(R.string.admob_banner)
            BannerAdHelper.showBanner(this, mBinding.frameLayout,  adId,
                AdCache.bannerAdView,
                { isLoaded,adView, message ->
                    mAdView=adView
                    AdCache.bannerAdView=adView
                    isAdLoaded = isLoaded
                })

        } else {
            mBinding.frameLayout.visibility = View.GONE
        }
    }

}