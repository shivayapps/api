package com.videoplayer.music.common.utils

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.os.bundleOf
import androidx.core.text.HtmlCompat
import androidx.fragment.app.DialogFragment
import com.mediaplayer.video.player.videoplayer.music.R
import com.videoplayer.music.common.database.HideVideoDatabase
import com.videoplayer.music.musicplayer.extensions.extraNotNull
import com.videoplayer.music.musicplayer.extensions.materialDialog
import com.videoplayer.music.musicplayer.util.FileUtils
import com.videoplayer.music.musicplayer.util.SAFUtil
import com.videoplayer.music.videoplayer.model.VideoData
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import java.io.File

class DeleteVideoDialog : DialogFragment() {

    interface OnDismissListener {
        fun onDismiss()
    }

    private var onDismissListener: OnDismissListener? = null
    fun setDismissListener(dismissListener: OnDismissListener) {
        onDismissListener = dismissListener
    }

    companion object {
        fun create(song: VideoData): DeleteVideoDialog {
            val list = ArrayList<VideoData>()
            list.add(song)
            return create(list)
        }

        fun create(songs: List<VideoData>): DeleteVideoDialog {
            return DeleteVideoDialog().apply {
                arguments = bundleOf(
                    "extra_videos" to ArrayList(songs)
                )
            }
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val songs = extraNotNull<List<VideoData>>("extra_videos").value
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val deleteResultLauncher =
                registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
                    if (result.resultCode == Activity.RESULT_OK) {
                        reloadTabs()
                    }
                    Log.e("DeleteVideoDialog", "OnDismiss.ResultLauncher")
                    onDismissListener?.onDismiss()
                    dismiss()
                }
            val pendingIntent =
                MediaStore.createDeleteRequest(requireActivity().contentResolver, songs.map {
                    FileUtils.getContentUriIdVideo(Uri.parse(it.path), requireActivity())
                })

            deleteResultLauncher.launch(
                IntentSenderRequest.Builder(pendingIntent.intentSender).build()
            )

            return super.onCreateDialog(savedInstanceState)
        } else {
            val pair = if (songs.size > 1) {
                Pair(
                    R.string.delete_songs_title,
                    HtmlCompat.fromHtml(
                        String.format(getString(R.string.delete_x_videos), songs.size),
                        HtmlCompat.FROM_HTML_MODE_LEGACY
                    )
                )
            } else {
                Pair(
                    R.string.delete_song_title,
                    HtmlCompat.fromHtml(
                        String.format(getString(R.string.delete_video_x), songs[0].name),
                        HtmlCompat.FROM_HTML_MODE_LEGACY
                    )
                )
            }

            return materialDialog()
                .title(pair.first)
                .message(text = pair.second)
                .noAutoDismiss()
                .negativeButton(android.R.string.cancel)
                {
                    onDismissListener?.onDismiss()
                    dismiss()
                }
                .positiveButton(R.string.action_delete)
                {
                    deleteVideos(songs)
                }

        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            SAFUtil.REQUEST_CODE_SAF_GUIDE -> {
                SAFUtil.openTreePicker(this)
            }

            SAFUtil.REQUEST_SAF_PICK_TREE,
            SAFUtil.REQUEST_SAF_PICK_FILE -> {
                if (resultCode == Activity.RESULT_OK) {
                    SAFUtil.saveTreeUri(requireActivity(), data)
                    val songs = extraNotNull<List<VideoData>>("extra_videos").value
                    deleteVideos(songs)
                }
            }
        }
//        when (requestCode) {
//            com.videoplayer.music.musicplayer.activities.saf.SAFGuideActivity.REQUEST_CODE_SAF_GUIDE -> {
//                com.videoplayer.music.musicplayer.util.SAFUtil.openTreePicker(this)
//            }
//
//            com.videoplayer.music.musicplayer.util.SAFUtil.REQUEST_SAF_PICK_TREE,
//            com.videoplayer.music.musicplayer.util.SAFUtil.REQUEST_SAF_PICK_FILE -> {
//                if (resultCode == Activity.RESULT_OK) {
//                    com.videoplayer.music.musicplayer.util.SAFUtil.saveTreeUri(requireActivity(), data)
//                    val songs = extraNotNull<List<VideoData>>("extra_videos").value
//                    deleteVideos(songs)
//                }
//            }
//        }
    }

    private fun deleteVideos(songs: List<VideoData>) {

        val mDB = HideVideoDatabase.getInstance(activity!!)
        val db = com.videoplayer.music.common.database.VideoPlayerDatabase.getInstance(activity!!)

        for (index in songs.indices) {
            val tempFile = File(songs[index].path)
            val from = File(
                tempFile.parentFile!!.absolutePath,
                tempFile.absolutePath.substring(tempFile.absolutePath.lastIndexOf("/") + 1)
            )
            val tempFiles = File(tempFile.parentFile!!.absolutePath, ".${tempFile.name}")

            tempFiles.delete()
            if (from.renameTo(tempFiles)) {
                val contain = db!!.recentVideoDao()!!.isRecentVideo(songs[index].path)
                if (contain == 1) {
                    db.recentVideoDao().deleteRecentVideo(songs[index].path)
                }
                val contains = db.favoriteVideoDao().isFavoriteVideo(songs[index].path)
                if (contains == 1) {
                    db.favoriteVideoDao().deleteFavoriteVideo(songs[index].path)
                }
                mDB.hideVideoDao()!!.deleteHideVideo(songs[index].path)
                mDB.hideVideoDao()!!.deleteHideVideo(songs[index].path)
                MediaScannerConnection.scanFile(
                    activity!!,
                    arrayOf(tempFiles.absolutePath),
                    null
                ) { path, uri -> }
                MediaScannerConnection.scanFile(
                    activity!!,
                    arrayOf(tempFile.absolutePath),
                    null
                ) { path, uri ->
                    if (index == songs.size - 1) {
                        mainscope.launch {
                            EventBus.getDefault().post("getVideo")
                        }
                    }
                }
            }
        }

        Log.e("DeleteVideoDialog", "OnDismiss.deleteVideos")
        onDismissListener?.onDismiss()
        dismiss()
    }

    private fun reloadTabs() {

//        libraryViewModel.forceReload(ReloadType.Songs)
//        libraryViewModel.forceReload(ReloadType.HomeSections)
//        libraryViewModel.forceReload(ReloadType.Artists)
//        libraryViewModel.forceReload(ReloadType.Albums)
    }
}
