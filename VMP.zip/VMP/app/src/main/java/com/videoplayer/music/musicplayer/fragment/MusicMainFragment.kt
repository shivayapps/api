package com.videoplayer.music.musicplayer.fragment

import android.animation.ValueAnimator
import android.content.Intent
import android.graphics.Color
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.animation.PathInterpolator
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.navigation.NavOptions
import code.name.monkey.appthemehelper.util.VersionUtils
import com.google.android.material.tabs.TabLayout
import com.mediaplayer.video.player.videoplayer.music.R
import com.videoplayer.music.common.activity.MainActivity
import com.videoplayer.music.common.base.BaseBindingFragment
import com.mediaplayer.video.player.videoplayer.music.databinding.FragmentMusicMainBinding
import com.videoplayer.music.musicplayer.activities.MusicPlayerActivity
import com.videoplayer.music.musicplayer.extensions.dip
import com.videoplayer.music.musicplayer.extensions.findNavController
import com.videoplayer.music.musicplayer.extensions.isColorLight
import com.videoplayer.music.musicplayer.extensions.setLightNavigationBar
import com.videoplayer.music.musicplayer.extensions.setLightNavigationBarAuto
import com.videoplayer.music.musicplayer.extensions.setLightStatusBar
import com.videoplayer.music.musicplayer.extensions.setLightStatusBarAuto
import com.videoplayer.music.musicplayer.extensions.setNavigationBarColorPreOreo
import com.videoplayer.music.musicplayer.extensions.setTaskDescriptionColor
import com.videoplayer.music.musicplayer.extensions.surfaceColor
import com.videoplayer.music.musicplayer.extensions.whichFragment
import com.videoplayer.music.musicplayer.fragments.LibraryViewModel
import com.videoplayer.music.musicplayer.fragments.NowPlayingScreen
import com.videoplayer.music.musicplayer.fragments.other.MiniPlayerFragment
import com.videoplayer.music.musicplayer.helper.MusicPlayerRemote
import com.videoplayer.music.musicplayer.util.PreferenceUtil
import com.videoplayer.music.musicplayer.util.ViewUtil
import org.koin.androidx.viewmodel.ext.android.viewModel

class MusicMainFragment : BaseBindingFragment<FragmentMusicMainBinding>() {

    private var miniPlayerFragment: MiniPlayerFragment? = null
    private var nowPlayingScreen: NowPlayingScreen? = null
    private var navigationBarColor = 0
    private var taskColor: Int = 0
    private var paletteColor: Int = Color.WHITE
    private var navigationBarColorAnimator: ValueAnimator? = null
    private val libraryViewModel by viewModel<LibraryViewModel>()

    private var windowInsets: WindowInsetsCompat? = null

    override fun setBinding(
        layoutInflater: LayoutInflater,
        container: ViewGroup?
    ): FragmentMusicMainBinding {
        return FragmentMusicMainBinding.inflate(layoutInflater)
    }

    override fun initView() {
        super.initView()
        chooseFragmentForTheme()
        updateColor()
        val navController = findNavController(R.id.fragment_container)

        val navInflater = navController.navInflater
        val navGraph = navInflater.inflate(R.navigation.main_graph)

        navController.graph = navGraph

        val navOptions: NavOptions = NavOptions.Builder()
            .setLaunchSingleTop(true)
            .build()

        mBinding.bottomNavigationView.addOnTabSelectedListener(object :
            TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                Log.e("mmmgggg", "onTabSelected:" + tab.position)
                when (tab.position) {
                    0 -> {
                        navController.navigate(R.id.action_song, null, navOptions)
                    }

                    1 -> {
                        navController.navigate(R.id.action_album, null, navOptions)
                    }

                    2 -> {
                        navController.navigate(R.id.action_artist, null, navOptions)
                    }

                    3 -> {
                        navController.navigate(R.id.action_playlist, null, navOptions)
                    }

                    4 -> {
                        navController.navigate(R.id.action_folder, null, navOptions)
                    }
                }
                setBottomNavVisibility(visible = true)
            }

            override fun onTabUnselected(tab: TabLayout.Tab) {
            }

            override fun onTabReselected(tab: TabLayout.Tab) {
            }
        })

        navController.addOnDestinationChangedListener { _, destination, _ ->
            when (destination.id) {
                R.id.action_song, R.id.action_album, R.id.action_artist, R.id.action_folder, R.id.action_playlist, R.id.action_genre, R.id.action_search -> {
                    setBottomNavVisibility(visible = true)
                }

                R.id.playing_queue_fragment -> {
                    setBottomNavVisibility(visible = false, hideBottomSheet = true)
                }

                else -> setBottomNavVisibility(visible = false)
            }
        }
        ViewCompat.setOnApplyWindowInsetsListener(
            mBinding.root
        ) { _, insets ->
            windowInsets = insets
            insets
        }
        navigationBarColor = surfaceColor()
    }

    //    private var isInOneTabMode = false
    fun setBottomNavVisibility(
        visible: Boolean = true,
        hideBottomSheet: Boolean = MusicPlayerRemote.playingQueue.isEmpty()
    ) {
        hideBottomSheet(hide = hideBottomSheet, isBottomNavVisible = visible)
    }


    fun hideBottomSheet(
        hide: Boolean,
        isBottomNavVisible: Boolean = true
    ) {
        if (isAdded) {
            if (hide) {
                onPanelCollapsed()
                libraryViewModel.setFabMargin(if (isBottomNavVisible) R.dimen.bottom_nav_height else 0)
            } else {
                if (MusicPlayerRemote.playingQueue.isNotEmpty()) {
                    if (isBottomNavVisible) {
                        println("List")
                        libraryViewModel.setFabMargin(dip(R.dimen.mini_player_height_expanded))
                    } else {
                        println("Details")
                        libraryViewModel.setFabMargin(dip(R.dimen.mini_player_height))
                    }
                }
            }
        }
    }

    private fun onPanelCollapsed() {
        // restore values
        animateNavigationBarColor(surfaceColor())
        (requireActivity() as MainActivity).setLightStatusBarAuto()
        (requireActivity() as MainActivity).setLightNavigationBarAuto()
        (requireActivity() as MainActivity).setTaskDescriptionColor(taskColor)
    }

    private fun updateColor() {
        libraryViewModel.paletteColor.observe(this) { color ->
            this.paletteColor = color
            onPaletteColorChanged()
        }
    }

    private fun chooseFragmentForTheme() {
        nowPlayingScreen = PreferenceUtil.nowPlayingScreen
        miniPlayerFragment = whichFragment<MiniPlayerFragment>(R.id.miniPlayerFragment)
        miniPlayerFragment?.view?.setOnClickListener {
            openPlayer()
        }
    }

    private fun openPlayer() {
        val intent = Intent(mContext, MusicPlayerActivity::class.java)
        launchActivity(intent)
        mContext.overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up)
    }

    private fun setTaskDescColor(color: Int) {
        taskColor = color
    }

    private fun onPaletteColorChanged() {
        navigationBarColor = surfaceColor()
        setTaskDescColor(paletteColor)
        val isColorLight = paletteColor.isColorLight
        if (PreferenceUtil.isAdaptiveColor && (nowPlayingScreen == NowPlayingScreen.Normal || nowPlayingScreen == NowPlayingScreen.Flat)) {
            (requireActivity() as MainActivity).setLightNavigationBar(true)
            (requireActivity() as MainActivity).setLightStatusBar(isColorLight)
        } else if (nowPlayingScreen == NowPlayingScreen.Card || nowPlayingScreen == NowPlayingScreen.Blur || nowPlayingScreen == NowPlayingScreen.BlurCard) {
            animateNavigationBarColor(Color.BLACK)
            navigationBarColor = Color.BLACK
            (requireActivity() as MainActivity).setLightStatusBar(false)
            (requireActivity() as MainActivity).setLightNavigationBar(true)
        } else if (nowPlayingScreen == NowPlayingScreen.Color
            || nowPlayingScreen == NowPlayingScreen.Tiny
            || nowPlayingScreen == NowPlayingScreen.Gradient
        ) {
            animateNavigationBarColor(paletteColor)
            navigationBarColor = paletteColor
            (requireActivity() as MainActivity).setLightNavigationBar(isColorLight)
            (requireActivity() as MainActivity).setLightStatusBar(isColorLight)
        } else if (nowPlayingScreen == NowPlayingScreen.Full) {
            animateNavigationBarColor(paletteColor)
            navigationBarColor = paletteColor
            (requireActivity() as MainActivity).setLightNavigationBar(isColorLight)
            (requireActivity() as MainActivity).setLightStatusBar(false)
        } else if (nowPlayingScreen == NowPlayingScreen.Classic) {
            (requireActivity() as MainActivity).setLightStatusBar(false)
        } else if (nowPlayingScreen == NowPlayingScreen.Fit) {
            (requireActivity() as MainActivity).setLightStatusBar(false)
        }
    }

    private fun animateNavigationBarColor(color: Int) {
        if (VersionUtils.hasOreo()) return
        navigationBarColorAnimator?.cancel()
        navigationBarColorAnimator = ValueAnimator
            .ofArgb(requireActivity().window.navigationBarColor, color).apply {
                duration = ViewUtil.RETRO_MUSIC_ANIM_TIME.toLong()
                interpolator = PathInterpolator(0.4f, 0f, 1f, 1f)
                addUpdateListener { animation: ValueAnimator ->
                    (requireActivity() as MainActivity).setNavigationBarColorPreOreo(
                        animation.animatedValue as Int
                    )
                }
                start()
            }
    }

    companion object {
        fun newInstance(): MusicMainFragment {
            return MusicMainFragment()
        }
    }

}