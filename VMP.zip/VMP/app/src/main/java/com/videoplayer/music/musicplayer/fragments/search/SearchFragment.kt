package com.videoplayer.music.musicplayer.fragments.search

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.InputMethodManager
import androidx.annotation.IdRes
import androidx.core.content.getSystemService
import androidx.core.view.doOnPreDraw
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.transition.TransitionManager
import com.google.android.material.chip.ChipGroup
import com.google.android.material.shape.MaterialShapeDrawable
import com.google.android.material.transition.MaterialFadeThrough
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.databinding.FragmentSearchBinding
import com.videoplayer.music.musicplayer.adapter.SearchAdapter
import com.videoplayer.music.musicplayer.extensions.dipToPix
import com.videoplayer.music.musicplayer.extensions.focusAndShowKeyboard
import com.videoplayer.music.musicplayer.fragments.base.AbsMainActivityFragment

class SearchFragment : AbsMainActivityFragment(R.layout.fragment_search), TextWatcher,
    ChipGroup.OnCheckedChangeListener {

    companion object {
        const val QUERY = "query"
        fun newInstance(): SearchFragment {
            return SearchFragment()
        }
    }

    private var _binding: FragmentSearchBinding? = null
    private val binding get() = _binding!!

    private lateinit var searchAdapter: SearchAdapter
    private var query: String? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        enterTransition = MaterialFadeThrough().addTarget(view)
        reenterTransition = MaterialFadeThrough().addTarget(view)
        _binding = FragmentSearchBinding.bind(view)

        libraryViewModel.clearSearchResult()
        setupRecyclerView()

        binding.ivBack.setOnClickListener {
            requireActivity().onBackPressedDispatcher.onBackPressed()
        }

        binding.conLbl.setOnClickListener {
            binding.conLbl.visibility = View.GONE
            binding.searchView.visibility = View.VISIBLE
            binding.searchView.focusAndShowKeyboard()
        }

        binding.searchView.apply {
            addTextChangedListener(this@SearchFragment)
        }

        if (savedInstanceState != null) {
            query = savedInstanceState.getString(QUERY)
        }

        libraryViewModel.getSearchResult().observe(viewLifecycleOwner) {
            showData(it)
        }

        setupChips()
        postponeEnterTransition()

        view.doOnPreDraw {
            startPostponedEnterTransition()
        }
        binding.appBarLayout.statusBarForeground =
            MaterialShapeDrawable.createWithElevationOverlay(requireContext())
    }

    private fun setupChips() {
        binding.searchFilterGroup.setOnCheckedChangeListener(this)
    }

    private fun showData(data: List<Any>) {
        if (data.isNotEmpty()) {
            searchAdapter.swapDataSet(data)
        } else {
            searchAdapter.swapDataSet(ArrayList())
        }
    }

    private fun setupRecyclerView() {
        searchAdapter = SearchAdapter(requireActivity(), emptyList())
        searchAdapter.registerAdapterDataObserver(object : RecyclerView.AdapterDataObserver() {
            override fun onChanged() {
                super.onChanged()
                binding.empty.isVisible = searchAdapter.itemCount < 1
                val height = dipToPix(52f)
                binding.recyclerView.updatePadding(bottom = height.toInt())
            }
        })

        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = searchAdapter
        }
    }

    override fun afterTextChanged(newText: Editable?) {
        if (!newText.isNullOrEmpty()) {
            search(newText.toString())
            binding.recyclerView.visibility = View.VISIBLE
            binding.empty.visibility = View.GONE
        } else {
            binding.recyclerView.visibility = View.GONE
            binding.empty.visibility = View.VISIBLE
        }
    }

    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

    }

    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {

    }

    private fun search(query: String) {
        this.query = query
        TransitionManager.beginDelayedTransition(binding.appBarLayout)
        val filter = getFilter()
        libraryViewModel.search(query, filter)
    }

    private fun getFilter(): Filter {
        return when (binding.searchFilterGroup.checkedChipId) {
            R.id.chip_audio -> Filter.SONGS
            R.id.chip_artists -> Filter.ARTISTS
            R.id.chip_albums -> Filter.ALBUMS
            R.id.chip_album_artists -> Filter.ALBUM_ARTISTS
            R.id.chip_genres -> Filter.GENRES
            else -> Filter.NO_FILTER
        }
    }

    override fun onDestroyView() {
        hideKeyboard(view)
        super.onDestroyView()
        _binding = null
    }

    override fun onPause() {
        super.onPause()
        hideKeyboard(view)
    }

    private fun hideKeyboard(view: View?) {
        if (view != null) {
            val imm =
                requireContext().getSystemService<InputMethodManager>()
            imm?.hideSoftInputFromWindow(view.windowToken, 0)
        }
    }

    override fun onCheckedChanged(group: ChipGroup, @IdRes checkedId: Int) {
        search(binding.searchView.text.toString())
    }
}

enum class Filter {
    SONGS,
    ARTISTS,
    ALBUMS,
    ALBUM_ARTISTS,
    GENRES,
    NO_FILTER
}

