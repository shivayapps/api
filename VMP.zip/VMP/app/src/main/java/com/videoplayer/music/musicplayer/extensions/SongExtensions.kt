package com.videoplayer.music.musicplayer.extensions

import com.videoplayer.music.musicplayer.model.Song
import com.videoplayer.music.musicplayer.util.MusicUtil

val Song.uri get() = MusicUtil.getSongFileUri(songId = id)