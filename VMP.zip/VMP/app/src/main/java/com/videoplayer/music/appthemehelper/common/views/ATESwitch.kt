package com.videoplayer.music.appthemehelper.common.views

import android.content.Context
import android.util.AttributeSet
import android.widget.Switch
import androidx.core.view.isVisible
import com.videoplayer.music.appthemehelper.ATH
import com.videoplayer.music.appthemehelper.ThemeStore

/**
 * @author Sujal Lathiya
 */
class ATESwitch : Switch {

    constructor(context: Context) : super(context) {
        init(context)
    }

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        init(context)
    }

    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {
        init(context)
    }

    private fun init(context: Context) {
        ATH.setTint(this, ThemeStore.accentColor(context))
    }

    override fun isShown(): Boolean {
        return parent != null && isVisible
    }
}