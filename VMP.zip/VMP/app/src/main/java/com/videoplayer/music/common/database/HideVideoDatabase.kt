package com.videoplayer.music.common.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [HideVideo::class], version = 2)
abstract class HideVideoDatabase : RoomDatabase() {

    abstract fun hideVideoDao(): HideVideoDao?

    companion object {
        private var db: HideVideoDatabase? = null
        fun getInstance(context: Context): HideVideoDatabase {
            if (db == null) {
                synchronized(HideVideoDatabase::class) {
                    if (db == null) {
                        db = Room.databaseBuilder(
                            context.applicationContext,
                            HideVideoDatabase::class.java,
                            "videoPlayer.db"
                        ).fallbackToDestructiveMigration()
                            .allowMainThreadQueries()
                            .build()
                    }
                }
            }
            return db!!
        }

        fun destroyInstance() {
            db = null
        }

    }
}
