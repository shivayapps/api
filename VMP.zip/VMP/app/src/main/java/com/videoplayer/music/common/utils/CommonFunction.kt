@file:Suppress("unused")

package com.videoplayer.music.common.utils

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.util.TypedValue
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.annotation.ColorInt
import androidx.annotation.ColorRes
import androidx.annotation.DimenRes
import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.mediaplayer.video.player.videoplayer.music.R
import com.videoplayer.music.common.utils.AppConstant.Companion.FOLDER_WHATSAPP
import com.videoplayer.music.musicplayer.util.FileUtils
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.text.DecimalFormat
import java.util.concurrent.Executors
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.roundToInt


/**
 * Extension method to Get String resource for Context.
 */
fun Context.getStringRes(@StringRes id: Int) = resources.getString(id)

fun Context.getStringRes(@StringRes id: Int, vararg formatArgs: String) =
    resources.getString(id, *formatArgs)

fun <T> Context.getStringRes(@StringRes id: Int, vararg formatArgs: T) =
    resources.getString(id, *formatArgs)

/**
 * Extension method to Get Color resource for Context.
 */
fun Context.getColorRes(@ColorRes id: Int) = ContextCompat.getColor(this, id)

/**
 * Extension method to Get Drawable for resource for Context.
 */
fun Context.getDrawableRes(@DrawableRes id: Int) = ContextCompat.getDrawable(this, id)

fun Context.sdpToPx(@DimenRes id: Int) = resources.getDimensionPixelSize(id)

fun Context.dpToPx(dp: Int) = TypedValue.applyDimension(
    TypedValue.COMPLEX_UNIT_DIP,
    dp.toFloat(),
    resources.displayMetrics
).roundToInt()

fun Activity.hideStatusBar() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        window.insetsController?.let {
            it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            it.hide(WindowInsets.Type.statusBars())
        }
    } else {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                )
    }
}

fun Activity.showStatusBar() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        window.setDecorFitsSystemWindows(false)
        window.insetsController?.show(WindowInsets.Type.statusBars())
    } else {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                )
    }
}

inline fun <reified T : Enum<T>> Intent.putEnumExtra(victim: T): Intent =
    putExtra(T::class.java.name, victim.ordinal)

inline fun <reified T : Enum<T>> Bundle.putEnumExtra(victim: T) =
    this.putInt(T::class.java.name, victim.ordinal)

inline fun <reified T : Enum<T>> Intent.getEnumExtra(): T =
    getIntExtra(T::class.java.name, -1).takeUnless { it == -1 }
        ?.let { T::class.java.enumConstants!![it] } ?: T::class.java.enumConstants!![0]

inline fun <reified T : Enum<T>> Bundle.getEnumExtra(): T =
    this.getInt(T::class.java.name, -1).takeUnless { it == -1 }
        ?.let { T::class.java.enumConstants!![it] } ?: T::class.java.enumConstants!![0]

fun setDuration(j: Long): String {
    val str: String
    val str2: String
    val str3: String
    val i = (j / 3600000).toInt()
    val j2 = j % 3600000
    val i2 = j2.toInt() / 60000
    val i3 = (j2 % 60000 / 1000).toInt()
    str = if (i < 10 && i != 0) {
        "0$i:"
    } else if (i >= 10) {
        "$i:"
    } else {
        ""
    }
    str2 = if (i2 < 10) {
        "0$i2"
    } else {
        i2.toString() + ""
    }
    str3 = if (i3 < 10) {
        "0$i3"
    } else {
        i3.toString() + ""
    }
    return "$str$str2:$str3"
}

fun formateSize(j: Long): String {
    if (j <= 0) {
        return "0"
    }
    val d = j.toDouble()
    val log10 = (log10(d) / log10(1024.0)).toInt()
    val sb = StringBuilder()
    val decimalFormat = DecimalFormat("#,##0.#")
    val pow = 1024.0.pow(log10.toDouble())
    java.lang.Double.isNaN(d)
    java.lang.Double.isNaN(d)
    sb.append(decimalFormat.format(d / pow))
    sb.append(" ")
    sb.append(arrayOf("B", "KB", "MB", "GB", "TB")[log10])
    return sb.toString()
}
//fun View.backgroundColor(@ColorInt color: Int) {
//    setBackgroundColor(color)
//}
var View.backgroundColor: Int
    get() = (background as? android.graphics.drawable.ColorDrawable)?.color ?: Color.TRANSPARENT
    set(value) = setBackgroundColor(value)

fun Context.toast(msg: String, length: Int = Toast.LENGTH_SHORT) {
    try {
        if (isOnMainThread()) {
            doToast(this, msg, length)
        } else {
            Handler(Looper.getMainLooper()).post {
                doToast(this, msg, length)
            }
        }
    } catch (e: Exception) {
    }
}

private fun doToast(context: Context, message: String, length: Int) {
    if (context is Activity) {
        if (!context.isFinishing && !context.isDestroyed) {
            Toast.makeText(context, message, length).show()
        }
    } else {
        Toast.makeText(context, message, length).show()
    }
}

fun isOnMainThread() = Looper.myLooper() == Looper.getMainLooper()

fun saveFiles(paths: String, activity: Activity) {
    var path: String = FileUtils.getExternalStoragePublicDirectory(
        activity,
        Environment.DIRECTORY_PICTURES
    ) + File.separator + activity.getString(R.string.app_name) + File.separator + FOLDER_WHATSAPP + "/"
    var mainType: String
    var exp: String
    val service22 = Executors.newSingleThreadExecutor()
    service22.execute {
        activity.runOnUiThread { }
        val file = File(paths)
        val ext = file.name.substring(file.name.lastIndexOf("."))
        if (ext == ".mp4" || ext == ".webm") {
            mainType = "video/mp4"
            path += "Video/"
            exp = "mp4"
        } else {
            mainType = "image/jpeg"
            path += "Photo/"
            exp = "jpeg"
        }
        copyFiles(path, mainType, exp, paths, activity)
        activity.runOnUiThread {
            Toast.makeText(activity, activity.getString(R.string.save), Toast.LENGTH_SHORT)
                .show()
        }
    }
}

private fun copyFiles(
    path: String,
    mainType: String,
    exp: String,
    paths: String,
    activity: Activity
) {
    val file1 = File(path)
    if (!file1.exists()) {
        file1.mkdirs()
    }
    val ss = Uri.fromFile(File(path))
    val fileNames = "GBWhatsapp2025196" + getFileName(Uri.parse(paths), activity)
    val uri: Uri = FileUtils.dataPathToNewUri(
        activity,
        ss,
        fileNames,
        MimeTypeMap.getSingleton().getExtensionFromMimeType(mainType),
        exp
    )
    FileUtils.copyFileData(activity, Uri.parse(paths), uri)
}


fun isAppInstalled(packageName: String, context: Context): Boolean {
    return try {
        context.packageManager.getPackageInfo(
            packageName,
            PackageManager.GET_ACTIVITIES
        )
        true
    } catch (ignored: PackageManager.NameNotFoundException) {
        false
    }
}


private fun getFileName(uri: Uri, activity: Activity): String {
    var name: String? = null
    if (uri.scheme == "content") {
        val cursor: Cursor? =
            activity.contentResolver.query(uri, null, null, null, null)
        if (cursor != null) {
            if (cursor.moveToFirst()) name =
                cursor.getString(cursor.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME))
            cursor.close()
        }
    } else if (uri.scheme == "file") name = uri.lastPathSegment
    return name!!.split("\\.".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()[0]
}

fun fileShare(context: Context, path: String, isAbove11WP: Boolean = false, isVideo: Boolean) {
    val share = Intent(Intent.ACTION_SEND)
    share.type = getMimeType(path)
    share.putExtra(
        Intent.EXTRA_TEXT,
        "Download App From here : https://play.google.com/store/apps/details?id=" + context.packageName
    )
    val uri = if (isAbove11WP) Uri.parse(path) else FileProvider.getUriForFile(
        context,
        context.packageName + ".provider",
        File(path)
    )
    if (isVideo) {
        share.type = "video/*"
    } else {
        share.type = "image/*"
    }

    share.putExtra(Intent.EXTRA_STREAM, uri)
    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    share.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
    context.startActivity(Intent.createChooser(share, "Share Image!"))
}

fun fileShare(context: Context, path: String, isAbove11WP: Boolean = false) {
    val share = Intent(Intent.ACTION_SEND)
    share.type = getMimeType(path)
    share.putExtra(
        Intent.EXTRA_TEXT,
        "Download App From here : https://play.google.com/store/apps/details?id=" + context.packageName
    )
    val uri = if (isAbove11WP) Uri.parse(path) else FileProvider.getUriForFile(
        context,
        context.packageName + ".provider",
        File(path)
    )
    share.type = "*/*"
    share.putExtra(Intent.EXTRA_STREAM, uri)
    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    share.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
    context.startActivity(Intent.createChooser(share, "Share Image!"))
}


private fun getMimeType(fileUri: String): String? {
    val extension = MimeTypeMap.getFileExtensionFromUrl(fileUri)
    return MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
}


fun fileFromContentUri(context: Context, contentUri: Uri): File {
    // Preparing Temp file name
    val fileExtension = getFileExtension(context, contentUri)
    val fileName = "temp_file" + if (fileExtension != null) ".$fileExtension" else ""

    // Creating Temp file
    val tempFile = File(context.cacheDir, fileName)
    tempFile.createNewFile()

    try {
        val oStream = FileOutputStream(tempFile)
        val inputStream = context.contentResolver.openInputStream(contentUri)

        inputStream?.let {
            copy(inputStream, oStream)
        }

        oStream.flush()
    } catch (e: Exception) {
        e.printStackTrace()
    }

    return tempFile
}

private fun copy(source: InputStream, target: OutputStream) {
    val buf = ByteArray(8192)
    var length: Int
    while (source.read(buf).also { length = it } > 0) {
        target.write(buf, 0, length)
    }
}

private fun getFileExtension(context: Context, uri: Uri): String? {
    val fileType: String? = context.contentResolver.getType(uri)
    return MimeTypeMap.getSingleton().getExtensionFromMimeType(fileType)
}

