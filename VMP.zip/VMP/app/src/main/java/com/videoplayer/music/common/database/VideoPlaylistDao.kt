package com.videoplayer.music.common.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface VideoPlaylistDao {
    @Query("Select * from video_playlist")
    fun getPlaylistLive(): LiveData<List<VideoPlaylist>>

    @Query("Select * from video_playlist")
    fun getPlaylistTopLive(): LiveData<List<VideoPlaylist>>

    @Query("Select * from video_playlist")
    fun getPlaylist(): List<VideoPlaylist>

    @Insert
    fun insertPlaylist(playlist: VideoPlaylist)

    @Query("DELETE from video_playlist WHERE PlaylistName = :playlistname")
    fun deletePlaylist(playlistname: String?)

    @Query("Select count(*) from video_playlist WHERE PlaylistName = :filepath")
    fun isAdded(filepath: String?): Int
}