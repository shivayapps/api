package com.videoplayer.music.musicplayer.model.smartplaylist

import android.os.Parcel
import android.os.Parcelable
import com.mediaplayer.video.player.videoplayer.music.R
import com.videoplayer.music.musicplayer.App
import com.videoplayer.music.musicplayer.model.Song
import org.koin.core.component.KoinComponent


class HistoryPlaylist() : AbsSmartPlaylist(
    name = App.getContext().getString(R.string.history),
    iconRes = R.drawable.ic_history
), KoinComponent {

    constructor(parcel: Parcel) : this() {
    }

    override fun songs(): List<Song> {
        return topPlayedRepository.recentlyPlayedTracks()
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        super.writeToParcel(parcel, flags)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<HistoryPlaylist> {
        override fun createFromParcel(parcel: Parcel): HistoryPlaylist {
            return HistoryPlaylist(parcel)
        }

        override fun newArray(size: Int): Array<HistoryPlaylist?> {
            return arrayOfNulls(size)
        }
    }
}