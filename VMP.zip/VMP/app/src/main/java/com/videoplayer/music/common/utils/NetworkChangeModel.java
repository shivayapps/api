package com.videoplayer.music.common.utils;

import android.app.Activity;

public class NetworkChangeModel {

    public interface OnNetworkChangeListener {
        void isNetworkConnected(boolean fIsConnected);
    }

    private static NetworkChangeModel mInstance;
    private OnNetworkChangeListener mListener;
    private boolean mState;

    private Activity mActivity;

    private NetworkChangeModel() {
    }

    public static NetworkChangeModel getInstance() {
        if (mInstance == null) {
            mInstance = new NetworkChangeModel();
        }
        return mInstance;
    }

    public void setListener(Activity fActivity, OnNetworkChangeListener listener) {
        mActivity = fActivity;
        mListener = listener;
    }

    void changeState(boolean state) {
        if (mListener != null) {
            mState = state;

            if (!mActivity.isFinishing()) {
                notifyStateChange();
            }
        }
    }

    private void notifyStateChange() {

        mListener.isNetworkConnected(mState);
    }
}