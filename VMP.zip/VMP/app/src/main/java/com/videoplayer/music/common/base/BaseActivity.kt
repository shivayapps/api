@file:Suppress("unused")

package com.videoplayer.music.common.base

import android.app.Activity
import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.content.IntentSender
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.AnimRes
import androidx.annotation.AnimatorRes
import androidx.annotation.LayoutRes
import androidx.annotation.UiThread
import androidx.core.app.ActivityOptionsCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentTransaction
import com.videoplayer.music.common.activity.LocaleHelper
import com.videoplayer.music.common.utils.RENAME_REQUEST_CODE
import com.videoplayer.music.common.utils.REQUEST_CODE_URIS
import com.videoplayer.music.common.utils.isOnline
import com.videoplayer.music.musicplayer.activities.base.AbsThemeActivity
import com.videoplayer.music.musicplayer.helper.MusicPlayerRemote
import com.videoplayer.music.musicplayer.interfaces.IMusicServiceEventListener
import com.videoplayer.music.musicplayer.repository.RealRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import org.koin.android.ext.android.inject
import kotlin.coroutines.CoroutineContext

/**
 * @author Sujal Lathiya
 *
 * BaseActivity.kt - A simple class contains some modifications to the native Activity.
 * This Class use with or without ViewBinding property.
 * also you have use this class in JAVA or KOTLIN both language.
 *
 * use of this class
 * you have to extend your Activity using this class like.
 * in Java :- {class MainActivity extends BaseActivity}
 * in Kotlin :- {class MainActivity : BaseActivity()}
 *
 * NOTE :- if you use this class with ViewBinding then you must override onCreate() method of Activity
 */

@Suppress("MemberVisibilityCanBePrivate")
abstract class BaseActivity : AbsThemeActivity(), CoroutineScope, View.OnClickListener, IMusicServiceEventListener {

    @Suppress("PropertyName")
    val TAG: String = javaClass.simpleName

    var mJob: Job = Job()
    val mActivity: FragmentActivity
        get() {
            return getActivityContext()
        }

    var dialog: ProgressDialog? = null
    val mMusicServiceEventListeners = ArrayList<IMusicServiceEventListener>()
    var receiverRegistered: Boolean = false
    var serviceToken: MusicPlayerRemote.ServiceToken? = null

    val repository: RealRepository by inject()

    var mLastClickTime: Long = 0

    var mMinDuration = 1000

    override val coroutineContext: CoroutineContext
        get() = mJob + Dispatchers.Main

    override fun attachBaseContext(base: Context?) {
        super.attachBaseContext(LocaleHelper.onAttach(base!!, "en"))
    }

    fun setStatusBarGradiant(activity: Activity, drawableRes: Drawable) {
        val window: Window = activity.window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor = ContextCompat.getColor(activity, android.R.color.transparent)
        window.navigationBarColor = ContextCompat.getColor(activity, android.R.color.transparent)
        window.setBackgroundDrawable(drawableRes)
    }

    private var mRequestCode: Int = 0

    private val launcher: ActivityResultLauncher<Intent> =
        registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result: ActivityResult ->
            fromActivityResult(
                requestCode = mRequestCode,
                resultCode = result.resultCode,
                data = result.data
            )
        }

    private val launcherSender =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
            if (result != null) {
                fromActivityResult(
                    requestCode = mRequestCode,
                    resultCode = result.resultCode,
                    data = result.data
                )
            }
        }

    //</editor-fold>
    override fun onServiceConnected() {

    }

    override fun onServiceDisconnected() {

    }

    override fun onQueueChanged() {

    }

    override fun onFavoriteStateChanged() {

    }

    override fun onPlayingMetaChanged() {

    }

    override fun onPlayStateChanged() {

    }

    override fun onRepeatModeChanged() {

    }

    override fun onShuffleModeChanged() {

    }

    override fun onMediaStoreChanged() {

    }


    override fun onCreate(savedInstanceState: Bundle?) {
        setParamBeforeLayoutInit()
        super.onCreate(null)

        getLayoutRes()?.let {
            setContentView(it)
        }
    }

    override fun onResume() {
        super.onResume()
        initJob()
    }

    fun addMusicServiceEventListener(listenerI: IMusicServiceEventListener?) {
        if (listenerI != null) {
            mMusicServiceEventListeners.add(listenerI)
        }
    }

    fun removeMusicServiceEventListener(listenerI: IMusicServiceEventListener?) {
        if (listenerI != null) {
            mMusicServiceEventListeners.remove(listenerI)
        }
    }

    /**
     * If You Not Using viewBinding
     * @param layoutResID Pass Your Layout File Resource Id Like This 'R.layout.activity_main'
     */
    override fun setContentView(layoutResID: Int) {
        super.setContentView(layoutResID)
        setContentView()
    }

    /**
     * If You Using viewBinding
     * @param view pass Your Layout File Lick 'ActivityMainBinding.inflate(getLayoutInflater()).getRoot()'
     */
    override fun setContentView(view: View) {
        super.setContentView(view)
        setContentView()
    }

    private fun setContentView() {
        initView()
        loadAds()
        initViewAction()
        initViewListener()
    }

    //<editor-fold desc="Default Function">
    /**
     * This Method for set you Activity Context
     *
     * @return
     * in Java :- {return MainActivity.this;}
     * in Kotlin :- {return this@MainActivity}
     */
    @UiThread
    abstract fun getActivityContext(): FragmentActivity

    /**
     * This method for set your layout
     *
     * If you use this class without using ViewBinding,
     * then you don't need to override onCreate() method
     *
     * without using viewBinding @return Your Layout File Resource Id Lick This 'return R.layout.activity_main'
     *
     * or if you use viewBinding then @return 'return null' for base reference
     */
    @UiThread
    @LayoutRes
    abstract fun getLayoutRes(): Int?
    //</editor-fold>

    //<editor-fold desc="Open Function">
    /**
     * This method for set-up your data before call setContentView()
     */
    open fun setParamBeforeLayoutInit() {}

    /**
     * This method For Init All Ads.
     */
    @UiThread
    open fun initAds() {
    }

    /**
     * This method For Init Your Layout File's All View
     */
    @UiThread
    open fun initView() {

    }

    /**
     * This method For Init Your Default Action Performance On View
     */

    @UiThread
    open fun initViewAction() {
    }

    /**
     * This method For Set Your All Type Of Listeners
     */
    @UiThread
    open fun initViewListener() {
    }

    /**
     * This method For Set Your All View Click Listener,
     * now you no need to write multiple line code for 'View.setOnClickListener(this)'
     * just call this method and pass your all view like
     *
     * setClickListener(view1, view2)
     *
     * @param fViews list of your all passed view's.
     */

    @UiThread
    open fun setClickListener(vararg fViews: View) {
        for (lView in fViews) {
            lView.setOnClickListener(this)
        }
    }
    //</editor-fold>

    //<editor-fold desc="Call On Start Screen">

    /**
     * This method for initialized your Coroutine job
     */
    private fun initJob() {
        mJob = Job()
    }

    /**
     * This method for load your all type of ads
     */

    private fun loadAds() {
        if (isOnline) {
            initAds()
        }
    }
    //</editor-fold>

    //<editor-fold desc="New Activity Intent">

    /**
     * This Method for get your next activity intent
     *
     * @param isAddFlag [Default value:- true] for set up your activity flag in your intent
     * @param fBundle lambda fun for pass data throw intent
     */

    inline fun <reified T : Activity> getActivityIntent(
        isAddFlag: Boolean = true,
        fBundle: Bundle.() -> Unit = {},
    ): Intent {
        val lIntent = Intent(mActivity, T::class.java)

        if (isAddFlag) {
            lIntent.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
            lIntent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        lIntent.putExtras(Bundle().apply(fBundle))

        return lIntent
    }

    /**
     * This Method will replace your default method of [startActivityForResult]
     *
     * @param fIntent Your Launcher Screen Intent
     * @param fRequestCode Your Request Code For Get Result Of Your Next Activity
     * @param fEnterAnimId your activity Enter animation
     * @param fExitAnimId your activity Exit animation
     */

    open fun launchActivityForResult(
        fIntent: Intent,
        fRequestCode: Int,
        @AnimatorRes @AnimRes fEnterAnimId: Int = android.R.anim.fade_in,
        @AnimatorRes @AnimRes fExitAnimId: Int = android.R.anim.fade_out
    ) {
        mRequestCode = fRequestCode
        launcher.launch(
            fIntent,
            ActivityOptionsCompat.makeCustomAnimation(mActivity, fEnterAnimId, fExitAnimId)
        )
    }

    open fun launchActivityForResult(
        fIntent: IntentSender,
        fRequestCode: Int,
        @AnimatorRes @AnimRes fEnterAnimId: Int = android.R.anim.fade_in,
        @AnimatorRes @AnimRes fExitAnimId: Int = android.R.anim.fade_out
    ) {
        mRequestCode = fRequestCode
        val intentSenderRequest = IntentSenderRequest.Builder(fIntent).build()
        launcherSender.launch(
            intentSenderRequest,
            ActivityOptionsCompat.makeCustomAnimation(mActivity, fEnterAnimId, fExitAnimId)
        )
    }

    /**
     * This Method will replace your default method of [startActivity]
     *
     * @param fIntent Your Launcher Screen Intent
     * @param isNeedToFinish [Default value:- false] pass [isNeedToFinish = true] for finish your caller screen after call next screen
     * @param fEnterAnimId your activity Enter animation
     * @param fExitAnimId your activity Exit animation
     */

    open fun launchActivity(
        fIntent: Intent,
        isNeedToFinish: Boolean = false,
        @AnimatorRes @AnimRes fEnterAnimId: Int = android.R.anim.fade_in,
        @AnimatorRes @AnimRes fExitAnimId: Int = android.R.anim.fade_out
    ) {
        mActivity.startActivity(fIntent)
        mActivity.overridePendingTransition(fEnterAnimId, fExitAnimId)

        if (isNeedToFinish) {
            mActivity.finish()
        }
    }

    /**
     * This Method will replace your default method of [onActivityResult]
     *
     * @param requestCode The integer request code originally supplied to launchActivityForResult(), allowing you to identify who this result came from.
     * @param resultCode The integer result code returned by the child activity through its setResult().
     * @param data An Intent, which can return result data to the caller (various data can be attached to Intent "extras").
     */

    @UiThread
    open fun fromActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
    }
    //</editor-fold>

    //<editor-fold desc="Update Fragment">
    /**
     * This method For Update Fragment & Attach In FrameLayout
     *
     * you have call this method using FrameLayout.
     * @param fFragment your fragment
     * @param enterAnim your fragment enter animation file
     * @param exitAnim your fragment exit animation file
     */
    @UiThread
    open fun FrameLayout.updateFragment(
        fFragment: Fragment,
        @AnimatorRes @AnimRes enterAnim: Int = android.R.anim.fade_in,
        @AnimatorRes @AnimRes exitAnim: Int = android.R.anim.fade_out,
    ) {

        supportFragmentManager
            .beginTransaction()
            .setCustomAnimations(enterAnim, exitAnim)
            .replace(this.id, fFragment)
            .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
            .commit()
    }

    // </editor-fold>

    override fun onClick(v: View) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    override fun onDestroy() {
        super.onDestroy()
        mJob.cancel()
        MusicPlayerRemote.unbindFromService(serviceToken)
    }

    fun showProgressDialogWithCancelListener(
        activity: Activity,
        message: String?,
        cancelDialog: () -> Unit
    ) {
        /*if (dialog != null) {
            dialog.dismiss();
        }*/

        try {
            if (dialog == null) {
                dialog = ProgressDialog(activity)
                dialog!!.setMessage(message)
                dialog!!.setCanceledOnTouchOutside(false)
                dialog!!.setCancelable(true)
                dialog!!.setOnCancelListener {
                    dialog!!.dismiss()
                    cancelDialog()
                }
                if (!activity.isFinishing) dialog!!.show()
            }
        } catch (e: java.lang.Exception) {

        }
    }

    fun showProgressDialog(activity: Activity, message: String?) {
        /*if (dialog != null) {
            dialog.dismiss();
        }*/
        try {
            if (dialog == null) {
                dialog = ProgressDialog(activity)
                dialog!!.setMessage(message)
                dialog!!.setCancelable(false)
                if (!activity.isFinishing) dialog!!.show()
            }
        } catch (e: java.lang.Exception) {

        }
    }

    fun requestWriteR(pathID: String, onUpdate: () -> Unit) {
        //files to modify
        val uriList: List<Uri> = listOf(
            Uri.withAppendedPath(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                pathID
            )
        )
        //requesting file write permission for specific files
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val pi = MediaStore.createWriteRequest(contentResolver, uriList)
            launchActivityForResult(pi.intentSender, RENAME_REQUEST_CODE)
        } else {
            onUpdate.invoke()
//            renameFunction(path, pathID,onUpdate)
        }
    }

    fun requestWriteR(imageUri: ArrayList<Uri>, code: Int? = null, onUpdate: () -> Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
//            val contentResolver: ContentResolver = activity.contentResolver
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val pi = MediaStore.createWriteRequest(contentResolver, imageUri)
                    launchActivityForResult(pi.intentSender, code ?: REQUEST_CODE_URIS)
                } else {
                    onUpdate.invoke()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        } else {
            onUpdate.invoke()
        }
    }


//    fun renameFunction(path: String, pathID: String,onUpdate: () -> Unit) {
//        val renameBottomDialog = BottomSheetDialog(this)
//        val renameBottomDialogBinding: RenameBottomDialogBinding =
//            RenameBottomDialogBinding.inflate(LayoutInflater.from(this))
//        renameBottomDialog.setContentView(renameBottomDialogBinding.root)
//        renameBottomDialog.setCancelable(false)
//        renameBottomDialog.setCanceledOnTouchOutside(true)
//        renameBottomDialog.show()
//        var name = File(path).name
//        if (name.indexOf(".") > 0) {
//            name = name.substring(0, name.lastIndexOf("."))
//        }
//        renameBottomDialogBinding.etName.setText(name)
//        renameBottomDialogBinding.yes.setOnClickListener {
//
//            var newName = renameBottomDialogBinding.etName.text!!.trim().toString()
//            if (newName.isNotEmpty()) {
//                val currentFile = File(path)
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
//
//                    val newName = renameBottomDialogBinding.etName.text
//                    if (newName != null && currentFile.exists() && newName.toString()
//                            .isNotEmpty()
//                    ) {
//                        val newFile = File(
//                            currentFile.parentFile,
//                            newName.toString() + "." + currentFile.extension
//                        )
//                        if (!newFile.exists()) {
//                            renameBottomDialog.dismiss()
//                            val fromUri = Uri.withAppendedPath(
//                                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
//                                pathID
//                            )
//
//
//                            ContentValues().also {
//                                it.put(MediaStore.Files.FileColumns.IS_PENDING, 1)
//                                contentResolver.update(fromUri, it, null, null)
//                                it.clear()
//                                //updating file details
//                                it.put(
//                                    MediaStore.Files.FileColumns.DISPLAY_NAME,
//                                    newName.toString()
//                                )
//                                it.put(MediaStore.Files.FileColumns.IS_PENDING, 0)
//                                contentResolver.update(fromUri, it, null, null)
//                            }
//
//                            MediaScannerConnection.scanFile(
//                                this, arrayOf(newFile.toString()), arrayOf("video/*")
//                            ) { p0, p1 ->
//                                Handler(Looper.getMainLooper()).postDelayed({
//                                    //updateUI(path, newFile)
//                                    onUpdate.invoke()
//                                }, 1000)
//
//                            }
//                        } else {
//                            Toast.makeText(
//                                this,
//                                getString(R.string.this_name_is_already_in_use_please_use_another_name),
//                                Toast.LENGTH_SHORT
//                            ).show()
//                        }
//
//                    }
//                } else {
//                    val newName = renameBottomDialogBinding.etName.text
//                    if (newName != null && currentFile.exists() && newName.toString()
//                            .isNotEmpty()
//                    ) {
//                        val newFile = File(
//                            currentFile.parentFile,
//                            newName.toString() + "." + currentFile.extension
//                        )
//                        if (!newFile.exists()) {
//                            renameBottomDialog.dismiss()
//                            if (currentFile.renameTo(newFile)) {
//                                MediaScannerConnection.scanFile(
//                                    this, arrayOf(newFile.toString()), arrayOf("video/*")
//                                ) { p0, p1 ->
//                                    Handler(Looper.getMainLooper()).postDelayed({
//                                        //updateUI(path, newFile)
//                                        onUpdate.invoke()
//                                    }, 1000)
//                                }
//                            }
//                        } else {
//                            Toast.makeText(
//                                this,
//                                getString(R.string.this_name_is_already_in_use_please_use_another_name),
//                                Toast.LENGTH_SHORT
//                            ).show()
//                        }
//                    }
//                }
//            } else {
//                Toast.makeText(
//                    this,
//                    this.getString(R.string.enter_name),
//                    Toast.LENGTH_SHORT
//                ).show()
//            }
//
//        }
//        renameBottomDialogBinding.cancel.setOnClickListener {
//            renameBottomDialog.dismiss()
//        }
//    }

    fun hideProgressDialog() {
        try {
            if (dialog != null) {
                dialog!!.dismiss()
                dialog = null
            }
        } catch (e: java.lang.Exception) {

        }
    }
}