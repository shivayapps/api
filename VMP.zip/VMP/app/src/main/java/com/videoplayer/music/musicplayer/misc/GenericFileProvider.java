

package com.videoplayer.music.musicplayer.misc;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {
}
