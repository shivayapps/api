package com.videoplayer.music.musicplayer.activities

import android.graphics.Color
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.view.isVisible
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.afollestad.materialcab.attached.AttachedCab
import com.afollestad.materialcab.attached.destroy
import com.afollestad.materialcab.attached.isActive
import com.afollestad.materialcab.createCab
import com.bumptech.glide.Glide
import com.h6ah4i.android.widget.advrecyclerview.animator.DraggableItemAnimator
import com.h6ah4i.android.widget.advrecyclerview.animator.GeneralItemAnimator
import com.h6ah4i.android.widget.advrecyclerview.draggable.RecyclerViewDragDropManager
import com.mediaplayer.video.player.videoplayer.music.R
import com.videoplayer.music.common.base.BaseBindingActivity
import com.videoplayer.music.common.utils.AppConstant
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityPlaylistDetailBinding
import com.videoplayer.music.musicplayer.App
import com.videoplayer.music.musicplayer.GENERAL_THEME
import com.videoplayer.music.musicplayer.IMAGE_THEME
import com.videoplayer.music.musicplayer.adapter.song.OrderablePlaylistSongAdapter
import com.videoplayer.music.musicplayer.db.PlaylistWithSongs
import com.videoplayer.music.musicplayer.db.toSongs
import com.videoplayer.music.musicplayer.extensions.makeStatusBarTransparent
import com.videoplayer.music.musicplayer.extensions.resolveColor
import com.videoplayer.music.musicplayer.extensions.surfaceColor
import com.videoplayer.music.musicplayer.fragments.LibraryViewModel
import com.videoplayer.music.musicplayer.fragments.playlists.PlaylistDetailsViewModel
import com.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.videoplayer.music.musicplayer.glide.RetroMusicColoredTarget
import com.videoplayer.music.musicplayer.glide.playlistPreview.PlaylistPreview
import com.videoplayer.music.musicplayer.interfaces.ICabCallback
import com.videoplayer.music.musicplayer.interfaces.ICabHolder
import com.videoplayer.music.musicplayer.model.Song
import com.videoplayer.music.musicplayer.util.MusicUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import com.videoplayer.music.common.utils.backgroundColor
import com.videoplayer.music.musicplayer.glide.RetroGlideExtension.asBitmapPalette
import com.videoplayer.music.musicplayer.glide.RetroGlideExtension.playlistOptions
import org.koin.androidx.viewmodel.ext.android.viewModel
import org.koin.core.parameter.parametersOf

open class PlaylistDetailActivity : BaseBindingActivity<ActivityPlaylistDetailBinding>(),
    ICabHolder {

    private lateinit var playlist: PlaylistWithSongs
    private lateinit var viewModel: PlaylistDetailsViewModel
    val libraryViewModel: LibraryViewModel by viewModel()
    private lateinit var playlistSongAdapter: OrderablePlaylistSongAdapter

    override fun initView() {
        super.initView()

        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            IMAGE_THEME, ""
        )

        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getInt(
            GENERAL_THEME, 0
        )

        makeStatusBarTransparent()

        if (editors == "theme_image") {
            mBinding.root.background =
                RetroGlideExtension.getUserImageTheme(this@PlaylistDetailActivity)
        } else if (editors == "theme_gradient") {
            mBinding.root.background =
                AppCompatResources.getDrawable(this, RetroGlideExtension.getUserGradientTheme())
        } else if (edit >= 0) {
            mBinding.root.background = null
            mBinding.root.backgroundColor = resolveColor(R.attr.mainBackgroundColor)
        }

        playlist = (intent.getSerializableExtra(AppConstant.BUNDDLE) as PlaylistWithSongs?)!!

        val view by viewModel<PlaylistDetailsViewModel> {
            parametersOf(playlist)
        }

        viewModel = view

        addMusicServiceEventListener(viewModel)

        setUpRecyclerView()

        viewModel.getSongs().observe(this@PlaylistDetailActivity) {
            songs(it.toSongs())
        }

        mBinding.tvPlaylistName.text = playlist.playlistEntity.playlistName
        mBinding.tvPlaylistDura.text = getPlaylistText(playlist)

        Glide.with(this).asBitmapPalette().playlistOptions().load(PlaylistPreview(playlist))
            .into(object : RetroMusicColoredTarget(mBinding.imgBlur) {
                override fun onColorReady(colors: com.videoplayer.music.musicplayer.util.color.MediaNotificationProcessor) {
                    setColors(Color.WHITE)
                }
            })

        mBinding.ivBack.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
    }

    private fun getPlaylistText(playlist: PlaylistWithSongs): String {
        return MusicUtil.getPlaylistInfoString(mActivity, playlist.songs.toSongs())
    }

    override fun onPause() {
        mActivity.lifecycleScope.launch(Dispatchers.IO) {
            playlistSongAdapter.saveSongs(playlist.playlistEntity)
        }
        super.onPause()
    }

    override fun getActivityContext(): FragmentActivity {
        return this@PlaylistDetailActivity
    }

    protected open fun setColors(color: Int) {
//        mBinding.img.backgroundTintList = ColorStateList.valueOf(color)
    }

    fun songs(songs: List<Song>) {
        mBinding.progressIndicator.hide()
        if (songs.isNotEmpty()) {
            playlistSongAdapter.swapDataSet(songs)
        } else {
            showEmptyView()
        }
    }

    private fun showEmptyView() {
        mBinding.empty.isVisible = true
        mBinding.emptyText.isVisible = true
    }

    private fun setUpRecyclerView() {
        playlistSongAdapter = OrderablePlaylistSongAdapter(
            playlist.playlistEntity,
            this@PlaylistDetailActivity,
            ArrayList(),
            R.layout.item_queue,
            this
        )

        val dragDropManager = RecyclerViewDragDropManager()

        val wrappedAdapter: RecyclerView.Adapter<*> =
            dragDropManager.createWrappedAdapter(playlistSongAdapter)


        val animator: GeneralItemAnimator = DraggableItemAnimator()
        mBinding.recyclerView.itemAnimator = animator

        dragDropManager.attachRecyclerView(mBinding.recyclerView)

        mBinding.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@PlaylistDetailActivity)
            mBinding.recyclerView.adapter = wrappedAdapter
        }

        playlistSongAdapter.registerAdapterDataObserver(object :
            RecyclerView.AdapterDataObserver() {
            override fun onChanged() {
                super.onChanged()
                checkIsEmpty()
            }
        })
    }

    private fun checkIsEmpty() {
        mBinding.empty.isVisible = playlistSongAdapter.itemCount == 0
        mBinding.emptyText.isVisible = playlistSongAdapter.itemCount == 0
    }

    private var cab: AttachedCab? = null

    override fun openCab(menuRes: Int, callback: ICabCallback): AttachedCab {
        cab?.let {
            println("Cab")
            if (it.isActive()) {
                it.destroy()
            }
        }
        cab = createCab(R.id.toolbar_container) {
            menu(menuRes)
            closeDrawable(R.drawable.ic_close)
            backgroundColor(literal = com.videoplayer.music.musicplayer.util.RetroColorUtil.shiftBackgroundColor(surfaceColor()))
            slideDown()
            onCreate { cab, menu -> callback.onCabCreated(cab, menu) }
            onSelection {
                callback.onCabItemClicked(it)
            }
            onDestroy { callback.onCabFinished(it) }
        }
        return cab as AttachedCab
    }

    override fun setBinding(): ActivityPlaylistDetailBinding {
        return ActivityPlaylistDetailBinding.inflate(layoutInflater)
    }
}