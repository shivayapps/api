package com.videoplayer.music.musicplayer.interfaces

import android.view.View
import com.videoplayer.music.musicplayer.model.Genre

interface IGenreClickListener {
    fun onClickGenre(genre: Genre, view: View)
}