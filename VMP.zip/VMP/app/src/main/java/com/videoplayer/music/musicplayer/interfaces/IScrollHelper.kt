package com.videoplayer.music.musicplayer.interfaces

interface IScrollHelper {
    fun scrollToTop()
}