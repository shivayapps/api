package com.videoplayer.music.common.utils

import com.google.android.gms.ads.AdView

class AdCache {
    companion object {
        var bannerMain:AdView?=null
        var bannerDetailList:AdView?=null
        var bannerArtistDetail:AdView?=null
        var bannerWaStatus:AdView?=null
        var bannerAlbumDetail:AdView?=null
        var bannerTheme:AdView?=null
        var bannerThemeSave:AdView?=null
        var bannerWaStatusDownload:AdView?=null
        var bannerMusicPlayer:AdView?=null
        var bannerMusicSearch:AdView?=null
        var bannerAllVideo:AdView?=null
        var bannerSetting:AdView?=null
        var bannerLanguage:AdView?=null
        var bannerFavorite:AdView?=null
        var bannerVideoSearch:AdView?=null
    }
}


