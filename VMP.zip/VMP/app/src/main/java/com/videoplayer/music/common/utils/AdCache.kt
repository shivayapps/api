package com.videoplayer.music.common.utils

import com.google.android.gms.ads.AdView

class AdCache {
    companion object {
        var bannerAdView:AdView?=null


    }
}


