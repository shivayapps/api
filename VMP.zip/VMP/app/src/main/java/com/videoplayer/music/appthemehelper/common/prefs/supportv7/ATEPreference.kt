

package com.videoplayer.music.appthemehelper.common.prefs.supportv7

import android.content.Context
import android.util.AttributeSet
import androidx.preference.Preference

class ATEPreference @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : Preference(context, attrs, defStyleAttr, defStyleRes) {

    init {
//        icon?.colorFilter = BlendModeColorFilterCompat.createBlendModeColorFilterCompat(
//            ATHUtil.resolveColor(
//                context,
//                android.androidx.appcompat.R.attr.colorControlNormal
//            ), BlendModeCompat.SRC_IN
//        )
    }
}