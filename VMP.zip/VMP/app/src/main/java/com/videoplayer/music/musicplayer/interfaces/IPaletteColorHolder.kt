package com.videoplayer.music.musicplayer.interfaces


interface IPaletteColorHolder {
    val paletteColor: Int
}
