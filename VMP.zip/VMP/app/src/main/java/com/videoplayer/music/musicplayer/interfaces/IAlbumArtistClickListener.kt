package com.videoplayer.music.musicplayer.interfaces

import android.view.View

interface IAlbumArtistClickListener {
    fun onAlbumArtist(artistName: String, view: View)
}
