package com.videoplayer.music.musicplayer.preferences

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import code.name.monkey.appthemehelper.common.prefs.supportv7.ATEDialogPreference
import com.bumptech.glide.Glide
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.databinding.PreferenceDialogNowPlayingScreenBinding
import com.mediaplayer.video.player.videoplayer.music.databinding.PreferenceNowPlayingScreenItemBinding
import com.videoplayer.music.musicplayer.App
import com.videoplayer.music.musicplayer.extensions.hide
import com.videoplayer.music.musicplayer.extensions.materialDialog1
import com.videoplayer.music.musicplayer.extensions.show
import com.videoplayer.music.musicplayer.fragments.AlbumCoverStyle
import com.videoplayer.music.musicplayer.fragments.AlbumCoverStyle.Card
import com.videoplayer.music.musicplayer.fragments.AlbumCoverStyle.Circle
import com.videoplayer.music.musicplayer.fragments.AlbumCoverStyle.FullCard
import com.videoplayer.music.musicplayer.fragments.AlbumCoverStyle.values
import com.videoplayer.music.musicplayer.util.NavigationUtil
import com.videoplayer.music.musicplayer.util.PreferenceUtil
import com.videoplayer.music.musicplayer.util.ViewUtil

class AlbumCoverStylePreference @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = -1,
    defStyleRes: Int = -1
) : ATEDialogPreference(context, attrs, defStyleAttr, defStyleRes) {

    private val mLayoutRes = R.layout.preference_dialog_now_playing_screen

    override fun getDialogLayoutResource(): Int {
        return mLayoutRes
    }

}

class AlbumCoverStylePreferenceDialog : DialogFragment(),
    ViewPager.OnPageChangeListener {

    private var viewPagerPosition: Int = 0

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val binding = PreferenceDialogNowPlayingScreenBinding.inflate(layoutInflater)

        binding.nowPlayingScreenViewPager.apply {
            adapter = AlbumCoverStyleAdapter(requireContext())
            addOnPageChangeListener(this@AlbumCoverStylePreferenceDialog)
            pageMargin = ViewUtil.convertDpToPixel(32f, resources).toInt()
            currentItem = PreferenceUtil.albumCoverStyle.ordinal
        }

        binding.tvTitle.text = getString(R.string.pref_title_album_cover_style)

        binding.btnSet.setOnClickListener {
            val coverStyle = values()[viewPagerPosition]
            if (isAlbumCoverStyle(coverStyle)) {
                NavigationUtil.goToProVersion(requireActivity())
            } else {
                PreferenceUtil.albumCoverStyle = coverStyle
            }
            dialog?.dismiss()
        }
        return materialDialog1().setView(binding.root).create()
    }

    override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
    }

    override fun onPageSelected(position: Int) {
        this.viewPagerPosition = position
    }

    override fun onPageScrollStateChanged(state: Int) {
    }

    private class AlbumCoverStyleAdapter(private val context: Context) :
        PagerAdapter() {

        override fun instantiateItem(collection: ViewGroup, position: Int): Any {
            val albumCoverStyle = values()[position]

            val inflater = LayoutInflater.from(context)
            val binding = PreferenceNowPlayingScreenItemBinding.inflate(inflater, collection, true)

            Glide.with(context).load(albumCoverStyle.drawableResId).into(binding.image)
            binding.title.setText(albumCoverStyle.titleRes)

            if (isAlbumCoverStyle(albumCoverStyle)) {
                binding.proText.show()
                binding.proText.setText(R.string.pro)
            } else {
                binding.proText.hide()
            }

            return binding.root
        }

        override fun destroyItem(
            collection: ViewGroup,
            position: Int,
            view: Any
        ) {
            collection.removeView(view as View)
        }

        override fun getCount(): Int {
            return values().size
        }

        override fun isViewFromObject(view: View, instace: Any): Boolean {
            return view === instace
        }

        override fun getPageTitle(position: Int): CharSequence {
            return context.getString(values()[position].titleRes)
        }
    }

    companion object {
        val TAG: String = AlbumCoverStylePreferenceDialog::class.java.simpleName

        fun newInstance(): AlbumCoverStylePreferenceDialog {
            return AlbumCoverStylePreferenceDialog()
        }
    }
}

private fun isAlbumCoverStyle(style: AlbumCoverStyle): Boolean {
    return (App.isProVersion() && (style == Circle || style == Card || style == FullCard))
}