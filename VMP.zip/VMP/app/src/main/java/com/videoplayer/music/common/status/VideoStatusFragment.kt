package com.videoplayer.music.common.status

import android.view.LayoutInflater
import android.view.ViewGroup
import com.videoplayer.music.common.base.BaseBindingFragment
import com.videoplayer.music.common.status.adapter.StatusAdapter
import com.mediaplayer.video.player.videoplayer.music.databinding.FragmentVideoStatusBinding
import com.videoplayer.music.musicplayer.extensions.hide
import com.videoplayer.music.musicplayer.extensions.show
import com.videoplayer.music.videoplayer.model.VideoData


class VideoStatusFragment : BaseBindingFragment<FragmentVideoStatusBinding>() {
    private var videoStatusAdapter: StatusAdapter? = null

    override fun setBinding(
        layoutInflater: LayoutInflater,
        container: ViewGroup?
    ): FragmentVideoStatusBinding {
        return FragmentVideoStatusBinding.inflate(layoutInflater, container, false)
    }

    override fun initView() {
        super.initView()
        setNoData()
    }

    fun setAdapters(photoList: ArrayList<VideoData>) {
        if (isAdded) {
            if (photoList.size == 0) {
                mBinding.nodata.show()
                mBinding.rvVideoStatusList.hide()
            } else {
                mBinding.nodata.hide()
                mBinding.rvVideoStatusList.show()
                videoStatusAdapter =
                    StatusAdapter(photoList, requireActivity(), requireContext(), 1) {

                    }
                mBinding.rvVideoStatusList.adapter = videoStatusAdapter
            }
        }
    }

    private fun setNoData() {
        mBinding.nodata.show()
        mBinding.rvVideoStatusList.hide()
    }
}