package com.videoplayer.music.common.activity

import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.util.Log
import android.view.View
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.palette.graphics.Palette
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.BannerAdHelper
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.google.android.gms.ads.AdView
import com.mediaplayer.video.player.videoplayer.music.R

import com.videoplayer.music.common.adapter.ThemeAdapter
import com.videoplayer.music.common.base.BaseBindingActivity
import com.videoplayer.music.common.utils.isOnline
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityThemeSaveBinding
import com.videoplayer.music.common.utils.AdCache
import com.videoplayer.music.musicplayer.App
import com.videoplayer.music.musicplayer.Constants
import com.videoplayer.music.musicplayer.GENERAL_THEME
import com.videoplayer.music.musicplayer.IMAGE_THEME
import com.videoplayer.music.musicplayer.STATUS_COLOR
import com.videoplayer.music.musicplayer.THEME_POS
import com.videoplayer.music.musicplayer.extensions.makeStatusBarTransparent
import com.videoplayer.music.musicplayer.extensions.resolveColor
import com.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.videoplayer.music.musicplayer.util.PreferenceUtil
import com.videoplayer.music.videoplayer.model.VideoData
import org.jetbrains.anko.backgroundColor
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream

class ThemeSaveActivity : BaseBindingActivity<ActivityThemeSaveBinding>() {

    private var mBitmap: Bitmap? = null
    private var mFinalBitmap: Bitmap? = null
    private var mThemeStr = "theme_image"
    private var mThemePos = 0
    private var mDominantColor = Color.WHITE

    companion object {
        var mVideoData: ArrayList<VideoData> = ArrayList()
    }

    override fun getActivityContext(): FragmentActivity {
        return this@ThemeSaveActivity
    }

    override fun setBinding(): ActivityThemeSaveBinding {
        return ActivityThemeSaveBinding.inflate(layoutInflater)
    }

    var sharedPreferences: SharedPreferences? = null
    override fun initView() {
        super.initView()

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(App.getContext())
        val editors = sharedPreferences?.getString(IMAGE_THEME, "")
        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getInt(
            GENERAL_THEME, 0
        )

        makeStatusBarTransparent()

        if (editors == "theme_image") {
            mBinding.root.background = RetroGlideExtension.getUserImageTheme(this@ThemeSaveActivity)
        } else if (editors == "theme_gradient") {
            mBinding.root.background =
                AppCompatResources.getDrawable(this, RetroGlideExtension.getUserGradientTheme())
        } else if (edit >= 0) {
            mBinding.root.background = null
            mBinding.root.backgroundColor = resolveColor(R.attr.mainBackgroundColor)
        }
        setNative()
    }

    var mAdView: AdView?=null
    var isAdLoaded = false
    private fun setNative() {
        if (isOnline) {

            val adId = getString(R.string.admob_banner)
            BannerAdHelper.showBanner(this, mBinding.frameLayout,  adId,
                AdCache.bannerAdView,
                { isLoaded,adView, message ->
                    mAdView=adView
                    AdCache.bannerAdView=adView
                    isAdLoaded = isLoaded
                })

        } else {
            mBinding.frameLayout.visibility = View.GONE
        }
    }


    override fun initViewAction() {
        super.initViewAction()

        when (intent.getStringExtra("themeType")) {
            "image" -> {
                mThemeStr = "theme_image"
                setupImageTheme()
            }

            "color" -> {
                mThemeStr = ""
                setupColorTheme()
            }

            "gradient" -> {
                mThemeStr = "theme_gradient"
                setupGradientTheme()
            }

            else -> {
                mThemeStr = "theme_image"
                setupImageTheme()
            }
        }
    }

    private fun setupImageTheme() {
        val fileUri = Uri.parse(intent.getStringExtra("fileUri"))

        Log.e("ThemeSaveActivity", "proceedToTheme.fileUri-003: $fileUri")

        if (fileUri != null) {
            Glide.with(this).asBitmap().load(fileUri).diskCacheStrategy(DiskCacheStrategy.NONE)
                .listener(object : RequestListener<Bitmap> {
                    override fun onLoadFailed(
                        e: GlideException?,
                        model: Any?,
                        target: Target<Bitmap>?,
                        isFirstResource: Boolean
                    ): Boolean {
                        Log.e("ThemeSaveActivity", "proceedToTheme.onLoadFailed")
                        return false
                    }

                    override fun onResourceReady(
                        resource: Bitmap?,
                        model: Any?,
                        target: Target<Bitmap>?,
                        dataSource: DataSource?,
                        isFirstResource: Boolean
                    ): Boolean {
                        Log.e("ThemeSaveActivity", "proceedToTheme.onResourceReady")
                        resource?.let {
                            mBitmap = it
                            val d: Drawable = BitmapDrawable(
                                resources, mBitmap
                            )

                            mBinding.root.background = d
                            mBinding.ivPreview.setImageBitmap(mBitmap)
                            mFinalBitmap = mBitmap
                            mDominantColor = getDominantColor(mFinalBitmap!!)
                        }

                        return true
                    }
                }).into(mBinding.ivPreview)
        }
        mBinding.llSeekbar.visibility = View.VISIBLE
        mBinding.llList.visibility = View.GONE

    }

    private fun setupColorTheme() {
        mBinding.llSeekbar.visibility = View.GONE
        mBinding.llList.visibility = View.VISIBLE

        val themeColors = getThemeColor()

        val adapters = ThemeAdapter(this@ThemeSaveActivity,
            true,
            themeColors,
            object : ThemeAdapter.RVClickListener {
                override fun onThemeClick(position: Int) {
                    mThemePos = position
                    val mColor = themeColors[position]
                    mBinding.ivPreviewHeader.setBackgroundColor(resources.getColor(mColor))
                }
            })

        mBinding.rvList.layoutManager =
            LinearLayoutManager(this@ThemeSaveActivity, LinearLayoutManager.HORIZONTAL, false)

        mBinding.rvList.adapter = adapters
    }


    private fun setupGradientTheme() {
        mBinding.llSeekbar.visibility = View.GONE
        mBinding.llList.visibility = View.VISIBLE

        val drawableIds = getThemeOptions()

        val adapters = ThemeAdapter(this@ThemeSaveActivity,
            false,
            drawableIds,
            object : ThemeAdapter.RVClickListener {
                override fun onThemeClick(position: Int) {
                    mThemePos = position
                    val mDrawable = drawableIds[position]
                    mBinding.ivPreview.setImageResource(mDrawable)
                }
            })

        mBinding.rvList.layoutManager =
            LinearLayoutManager(this@ThemeSaveActivity, LinearLayoutManager.HORIZONTAL, false)

        mBinding.rvList.adapter = adapters
    }

    private fun getThemeColor(): MutableList<Int> {
        val options: MutableList<Int> = ArrayList()
        options.add(Color.parseColor("#FF5713"))
        options.add(Color.parseColor("#FE9F0C"))
        options.add(Color.parseColor("#5D5CE6"))
        options.add(Color.parseColor("#FECB00"))
        options.add(Color.parseColor("#64D1FF"))
        options.add(Color.parseColor("#0B84FE"))
        options.add(Color.parseColor("#BF5AF3"))
        options.add(Color.parseColor("#2ED158"))
        options.add(Color.parseColor("#FE375E"))
//        options.add(R.color.md_red_A400)
//        options.add(R.color.md_blue_A400)
//        options.add(R.color.md_deep_purple_A400)
//        options.add(R.color.md_deep_orange_A400)
//        options.add(R.color.md_green_A700)
//        options.add(R.color.md_cyan_400)
//        options.add(R.color.teal_200)
//        options.add(R.color.teal_700)
        return options
    }

    private fun getThemeOptions(): MutableList<Int> {
        val options: MutableList<Int> = ArrayList()
        options.add(R.drawable.gradient_theme_01)
        options.add(R.drawable.gradient_theme_02)
        options.add(R.drawable.gradient_theme_03)
        options.add(R.drawable.gradient_theme_04)
        options.add(R.drawable.gradient_theme_05)
        options.add(R.drawable.gradient_theme_06)
        options.add(R.drawable.gradient_theme_07)
        options.add(R.drawable.gradient_theme_08)
        options.add(R.drawable.gradient_theme_09)
        options.add(R.drawable.gradient_theme_10)
        options.add(R.drawable.gradient_theme_11)
        options.add(R.drawable.gradient_theme_12)
        options.add(R.drawable.gradient_theme_13)
        options.add(R.drawable.gradient_theme_14)
        options.add(R.drawable.gradient_theme_15)
        options.add(R.drawable.gradient_theme_16)
        options.add(R.drawable.gradient_theme_17)
        options.add(R.drawable.gradient_theme_18)
        options.add(R.drawable.gradient_theme_19)
        return options
    }

    private fun saveImage(bitmap: Bitmap, fileName: String) {
        val appDir = filesDir
        val file = File(appDir, fileName)
        var successful = false
        try {
            BufferedOutputStream(FileOutputStream(file)).use {
                successful =
                    com.videoplayer.music.musicplayer.util.ImageUtil.resizeBitmap(
                        bitmap, 2048
                    ).compress(Bitmap.CompressFormat.PNG, 100, it)
            }
        } catch (e: Exception) {
            Log.e("ThemeSaveActivity", "saveImage.onFailure:$e")
        }
        if (successful) {
            Log.e("ThemeSaveActivity", "saveImage.successful:" + appDir.path)
            saveSuccessful(mThemeStr, -1)
        }
    }

    private fun saveSuccessful(themeStr: String? = null, generalTheme: Int = -1) {
        val editor = sharedPreferences?.edit()
        if (themeStr?.isNotEmpty()!!) {
            editor?.putString(IMAGE_THEME, themeStr)
            editor?.putInt(GENERAL_THEME, 0)
            editor?.putInt(STATUS_COLOR, mDominantColor)
            Log.e("ThemeSaveActivity", "saveImage.001:$themeStr $mThemePos")
        } else {
            editor?.putString(IMAGE_THEME, "")
            editor?.putInt(GENERAL_THEME, generalTheme)
            editor?.putInt(STATUS_COLOR, -1)
            Log.e("ThemeSaveActivity", "saveImage.002:$themeStr $generalTheme")
            setTheme(PreferenceUtil.themeResFromPrefValue(generalTheme))
        }

        editor?.putInt(THEME_POS, mThemePos)
        editor?.apply()

        startActivity(
            Intent(this@ThemeSaveActivity, MainActivity::class.java).addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            )
        )

    }

    override fun initViewListener() {
        super.initViewListener()
        mBinding.ivClose.setOnClickListener(this)
        mBinding.ivSave.setOnClickListener(this)
        mBinding.sbBlur.onProgressChangedListener = object :
            com.videoplayer.music.common.bubbleseekbar.BubbleSeekBar.OnProgressChangedListener {
            override fun onProgressChanged(
                bubbleSeekBar: com.videoplayer.music.common.bubbleseekbar.BubbleSeekBar?,
                progress: Int,
                progressFloat: Float,
                fromUser: Boolean
            ) {
                mFinalBitmap =
                    com.videoplayer.music.common.utils.blurry.Blurry.with(this@ThemeSaveActivity)
                        .radius(progress).sampling(1)
                        .color(Color.argb(mBinding.sbTransparency.progress, 0, 0, 0)).from(mBitmap)
                        .get()

                mBinding.ivPreview.setImageBitmap(mFinalBitmap)
                mDominantColor = getDominantColor(mFinalBitmap!!)
            }

            override fun getProgressOnActionUp(
                bubbleSeekBar: com.videoplayer.music.common.bubbleseekbar.BubbleSeekBar?,
                progress: Int,
                progressFloat: Float
            ) {
            }

            override fun getProgressOnFinally(
                bubbleSeekBar: com.videoplayer.music.common.bubbleseekbar.BubbleSeekBar?,
                progress: Int,
                progressFloat: Float,
                fromUser: Boolean
            ) {
            }
        }

        mBinding.sbTransparency.onProgressChangedListener = object :
            com.videoplayer.music.common.bubbleseekbar.BubbleSeekBar.OnProgressChangedListener {
            override fun onProgressChanged(
                bubbleSeekBar: com.videoplayer.music.common.bubbleseekbar.BubbleSeekBar?,
                progress: Int,
                progressFloat: Float,
                fromUser: Boolean
            ) {

                mFinalBitmap =
                    com.videoplayer.music.common.utils.blurry.Blurry.with(this@ThemeSaveActivity)
                        .radius(mBinding.sbBlur.progress).sampling(1)
                        .color(Color.argb(progress, 0, 0, 0)).from(mBitmap).get()

                mBinding.ivPreview.setImageBitmap(mFinalBitmap)
                mDominantColor = getDominantColor(mFinalBitmap!!)
            }

            override fun getProgressOnActionUp(
                bubbleSeekBar: com.videoplayer.music.common.bubbleseekbar.BubbleSeekBar?,
                progress: Int,
                progressFloat: Float
            ) {
            }

            override fun getProgressOnFinally(
                bubbleSeekBar: com.videoplayer.music.common.bubbleseekbar.BubbleSeekBar?,
                progress: Int,
                progressFloat: Float,
                fromUser: Boolean
            ) {

            }
        }
    }

    override fun onBackPressed() {
        val clickInterval: Long = 40 * 1000
        val currentTime = System.currentTimeMillis()
        val elapsedTimeSinceLastClick = currentTime - App.lastClickTimeTheme
        if (elapsedTimeSinceLastClick >= clickInterval) {

            AdsConfig.showInterstitialAd(this@ThemeSaveActivity) {
                onBack()
            }

            App.lastClickTimeTheme = currentTime
        } else {
            onBack()
        }
    }

    private fun onBack() {
        super.onBackPressed()
    }

    override fun onClick(v: View) {
        super.onClick(v)
        when (v.id) {
            R.id.iv_close -> {
                onBackPressed()
            }

            R.id.iv_save -> {
                if (mThemeStr == "theme_image") {
                    mFinalBitmap?.let {
                        saveImage(it, Constants.USER_IMAGE_THEME)
                    }
                } else if (mThemeStr == "theme_gradient") {
                    saveSuccessful(mThemeStr, -1)
                } else if (mThemeStr.isEmpty()) {
                    saveSuccessful("", mThemePos)
                }

            }
        }
    }

    fun getDominantColor(bitmap: Bitmap): Int {
        return Palette.Builder(bitmap).generate()
            .getDominantColor(ContextCompat.getColor(this, R.color.white))
    }

}