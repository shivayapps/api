package com.videoplayer.music.musicplayer.fragments.settings

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.InsetDrawable
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.databinding.FragmentMainSettingsBinding
import com.videoplayer.music.musicplayer.extensions.drawAboveSystemBarsWithPadding
import com.videoplayer.music.musicplayer.util.PreferenceUtil
import com.videoplayer.music.musicplayer.util.PreferenceUtil.videoSkipDuration
import com.videoplayer.music.videoplayer.adapter.SingleChoiceAdapter

class MainSettingsFragment : Fragment(), View.OnClickListener {

    private var _binding: FragmentMainSettingsBinding? = null

    private val binding get() = _binding!!

    override fun onClick(view: View) {
        findNavController().navigate(
            when (view.id) {
                R.id.nowPlayingSettings -> R.id.action_mainSettingsFragment_to_nowPlayingSettingsFragment
                R.id.audioSettings -> R.id.action_mainSettingsFragment_to_audioSettings
                R.id.notificationSettings -> R.id.action_mainSettingsFragment_to_notificationSettingsFragment
                R.id.otherSettings -> R.id.action_mainSettingsFragment_to_otherSettingsFragment
                else -> R.id.action_mainSettingsFragment_to_nowPlayingSettingsFragment
            }
        )
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMainSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    @SuppressLint("SetTextI18n")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.checkAutoPlay.isChecked = PreferenceUtil.isAutoNext
        binding.skipVideoSummery.text = "${videoSkipDuration * 10} ${getString(R.string.second)}"
        binding.skipVideoDuration.setOnClickListener {
            setSkipDuration()
        }

        if (PreferenceUtil.isAutoNext) binding.autoPlaySummary.text = getString(R.string._on)
        else binding.autoPlaySummary.text = getString(R.string.off)
        binding.autoPlay.setOnClickListener {
            binding.checkAutoPlay.toggle()
            PreferenceUtil.isAutoNext = binding.checkAutoPlay.isChecked

            if (binding.checkAutoPlay.isChecked) binding.autoPlaySummary.text =
                getString(R.string._on)
            else binding.autoPlaySummary.text = getString(R.string.off)
        }

        binding.orientationSummery.text = getString(
            com.videoplayer.music.videoplayer.player.Prefs(
                context
            ).orientation.description)

        binding.settingOrientation.setOnClickListener {
            setRotation()
        }

        binding.audioSettings.setOnClickListener(this)
        binding.nowPlayingSettings.setOnClickListener(this)
        binding.notificationSettings.setOnClickListener(this)
        binding.otherSettings.setOnClickListener(this)
        binding.container.drawAboveSystemBarsWithPadding()
    }

    @SuppressLint("SetTextI18n")
    private fun setSkipDuration() {
        try {
            val dialogView = layoutInflater.inflate(R.layout.duration_dialog, null)
            val lblTitle = dialogView.findViewById<TextView>(R.id.lbl_Title)
            val btnCancel = dialogView.findViewById<TextView>(R.id.btn_no)
            val btnApply = dialogView.findViewById<TextView>(R.id.btn_yes)
            val rvSpeed = dialogView.findViewById<RecyclerView>(R.id.rv_speed)

            lblTitle.text = getString(R.string.skip_duration)

            val listSpeed: ArrayList<String> = ArrayList()

            listSpeed.add(getString(R.string.none))

            listSpeed.add("10 ${getString(R.string.second)}")
            listSpeed.add("20 ${getString(R.string.second)}")
            listSpeed.add("30 ${getString(R.string.second)}")

            val adapter = SingleChoiceAdapter(activity!!)

            adapter.listItem = listSpeed

            val layoutManager = LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false)

            var selectedValue = videoSkipDuration

            adapter.onItemClickListener =
                AdapterView.OnItemClickListener { _: AdapterView<*>?, _: View?, position: Int, _: Long ->
                    selectedValue = position
                }

            adapter.selectedPosition = videoSkipDuration
            rvSpeed.layoutManager = layoutManager
            rvSpeed.adapter = adapter

            val alert = AlertDialog.Builder(context)
            alert.setView(dialogView)
            alert.setCancelable(true)

            val alertDialog = alert.create()
            alertDialog.setCancelable(true)
            alertDialog.setCanceledOnTouchOutside(true)

            val inset = InsetDrawable(ColorDrawable(Color.TRANSPARENT), 40)
            alertDialog.window!!.setBackgroundDrawable(inset)

            val wlp: WindowManager.LayoutParams = alertDialog.window?.attributes!!
            alertDialog?.window!!.attributes = wlp
            alertDialog.show()

            btnCancel.setOnClickListener {
                alertDialog.dismiss()
            }

            btnApply.setOnClickListener {
                videoSkipDuration = selectedValue
                binding.skipVideoSummery.text =
                    "${videoSkipDuration * 10} ${getString(R.string.second)}"
                alertDialog.dismiss()
            }

            alertDialog.setOnCancelListener {

            }

            alertDialog.show()
        } catch (ignored: Exception) {
            Log.e("TAG", ignored.toString())
        }

    }

    private fun setRotation() {
        try {
            val dialogView = layoutInflater.inflate(R.layout.duration_dialog, null)
            val lblTitle = dialogView.findViewById<TextView>(R.id.lbl_Title)
            val btnCancel = dialogView.findViewById<TextView>(R.id.btn_no)
            val btnApply = dialogView.findViewById<TextView>(R.id.btn_yes)
            val rvSpeed = dialogView.findViewById<RecyclerView>(R.id.rv_speed)

            lblTitle.text = getString(R.string.orientation)
            val mPrefs = com.videoplayer.music.videoplayer.player.Prefs(context)
            val listSpeed: ArrayList<String> = ArrayList()
            listSpeed.add(getString(R.string.video_orientation_video))
            listSpeed.add(getString(R.string.video_orientation_sensor))

            val adapter = SingleChoiceAdapter(activity!!)
            adapter.listItem = listSpeed

            val layoutManager = LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false)

            var selectedValue = mPrefs.orientation.value

            adapter.onItemClickListener =
                AdapterView.OnItemClickListener { _: AdapterView<*>?, _: View?, position: Int, _: Long ->
                    selectedValue = position
                }

            adapter.selectedPosition = mPrefs.orientation.value
            rvSpeed.layoutManager = layoutManager
            rvSpeed.adapter = adapter

            val alert = AlertDialog.Builder(context)
            alert.setView(dialogView)
            alert.setCancelable(true)
            val alertDialog = alert.create()
            alertDialog.setCancelable(true)
            alertDialog.setCanceledOnTouchOutside(true)
            val inset = InsetDrawable(ColorDrawable(Color.TRANSPARENT), 40)
            alertDialog.window!!.setBackgroundDrawable(inset)

            val wlp: WindowManager.LayoutParams = alertDialog.window?.attributes!!
            alertDialog?.window!!.attributes = wlp
            alertDialog.show()

            btnCancel.setOnClickListener {
                alertDialog.dismiss()
            }

            btnApply.setOnClickListener {
                if (selectedValue == 0) {
                    binding.orientationSummery.text = getString(com.videoplayer.music.videoplayer.player.Utils.Orientation.VIDEO.description)
                    mPrefs.orientation = com.videoplayer.music.videoplayer.player.Utils.Orientation.VIDEO
                    mPrefs.updateOrientation()
                } else if (selectedValue == 1) {
                    binding.orientationSummery.text =
                        getString(com.videoplayer.music.videoplayer.player.Utils.Orientation.SENSOR.description)
                    mPrefs.orientation = com.videoplayer.music.videoplayer.player.Utils.Orientation.SENSOR
                    mPrefs.updateOrientation()
                }
                alertDialog.dismiss()
            }

            alertDialog.setOnCancelListener {

            }

            alertDialog.show()

        } catch (ignored: Exception) {
            Log.e("TAG", ignored.toString())
        }

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
