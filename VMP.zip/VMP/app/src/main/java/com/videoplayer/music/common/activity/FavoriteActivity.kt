package com.videoplayer.music.common.activity

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.content.res.AppCompatResources
import androidx.appcompat.view.ContextThemeWrapper
import androidx.appcompat.widget.PopupMenu
import androidx.core.content.FileProvider
import androidx.fragment.app.FragmentActivity
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.DefaultItemAnimator
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.mediaplayer.video.player.videoplayer.music.BuildConfig
import com.mediaplayer.video.player.videoplayer.music.R

import com.videoplayer.music.common.adapter.FavoriteVideoAdapter
import com.videoplayer.music.common.base.BaseBindingActivity
import com.videoplayer.music.common.database.FavoriteVideo
import com.videoplayer.music.common.database.RecentVideo
import com.videoplayer.music.common.database.VideoDatalist
import com.videoplayer.music.common.database.VideoPlaylist
import com.videoplayer.music.common.utils.AppConstant
import com.videoplayer.music.common.utils.formateSize
import com.videoplayer.music.common.utils.isOnline
import com.videoplayer.music.common.utils.setDuration
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityFavoriteBinding
import com.mediaplayer.video.player.videoplayer.music.databinding.AddPlaylistDialogBinding
import com.mediaplayer.video.player.videoplayer.music.databinding.FileInfoDialogBinding
import com.videoplayer.music.common.utils.AdCache
import com.videoplayer.music.musicplayer.App
import com.videoplayer.music.musicplayer.GENERAL_THEME
import com.videoplayer.music.musicplayer.IMAGE_THEME
import com.videoplayer.music.musicplayer.extensions.makeStatusBarTransparent
import com.videoplayer.music.musicplayer.extensions.resolveColor
import com.videoplayer.music.musicplayer.extensions.setDrawBehindSystemBars
import com.videoplayer.music.musicplayer.extensions.setImmersiveFullscreen
import com.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.videoplayer.music.musicplayer.util.PreferenceUtil
import com.videoplayer.music.videoplayer.activity.VideoSearchActivity
import com.videoplayer.music.videoplayer.adapter.AddPlaylistAdapter
import com.videoplayer.music.videoplayer.model.VideoData
import org.greenrobot.eventbus.EventBus
import org.jetbrains.anko.backgroundColor
import org.jetbrains.anko.toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FavoriteActivity : BaseBindingActivity<ActivityFavoriteBinding>() {

    private lateinit var mVideoAdapter: FavoriteVideoAdapter
    private lateinit var mDB: com.videoplayer.music.common.database.VideoPlayerDatabase
    private var mVideoData: ArrayList<VideoData> = java.util.ArrayList()

    private var mVideoDataList: java.util.ArrayList<FavoriteVideo> = java.util.ArrayList()

    private var mVideoDataFav: java.util.ArrayList<FavoriteVideo> = java.util.ArrayList()

    private lateinit var mPlayListVideoAdapter: AddPlaylistAdapter

    override fun getActivityContext(): FragmentActivity {
        return this@FavoriteActivity
    }

    override fun setBinding(): ActivityFavoriteBinding {
        return ActivityFavoriteBinding.inflate(layoutInflater)
    }

    override fun initView() {
        super.initView()

        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        } else {
            setImmersiveFullscreen()
        }

        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext())
            .getString(IMAGE_THEME, "")

        val edit =
            PreferenceManager.getDefaultSharedPreferences(App.getContext()).getInt(GENERAL_THEME, 0)

        makeStatusBarTransparent()

        if (editors == "theme_image") {
            mBinding.root.background = RetroGlideExtension.getUserImageTheme(this@FavoriteActivity)
            mBinding.constraintLayout.background = null
        } else if (editors == "theme_gradient") {
            mBinding.root.background =
                AppCompatResources.getDrawable(this, RetroGlideExtension.getUserGradientTheme())
            mBinding.constraintLayout.background = null
        } else if (edit >= 0) {
            mBinding.root.background = null
            mBinding.root.backgroundColor = resolveColor(R.attr.mainBackgroundColor)
        }

        mDB = com.videoplayer.music.common.database.VideoPlayerDatabase.getInstance(
            mActivity
        )
    }

    var mAdView: AdView?=null
    var isAdLoaded = false
    private fun setNative() {
        if (isOnline) {
            val adId = getString(R.string.bannerFavorite)
            BannerAdHelper.showBanner(this, mBinding.frameLayout,mBinding.frameLayout,  adId,
                AdCache.bannerFavorite,
                { isLoaded,adView, message ->
                    mAdView=adView
                    AdCache.bannerFavorite=adView
                    isAdLoaded = isLoaded
                })
        } else {
            mBinding.frameLayout.visibility = View.GONE
        }
    }

    override fun initViewAction() {
        super.initViewAction()

        mDB.favoriteVideoDao().getFavoriteVideoLive().observe(mActivity) { mList ->
            if (mList.isEmpty()) {
                mVideoData.removeAll(mVideoData.toSet())
                mBinding.conEmptyView.visibility = View.VISIBLE
                mBinding.rvFavorite.visibility = View.GONE
            } else {
                mVideoDataFav.removeAll(mVideoDataFav.toSet())
                mVideoDataFav.addAll(mList)
                mVideoDataList.removeAll(mVideoDataList.toSet())
                mVideoDataList.addAll(mList)
                mBinding.conEmptyView.visibility = View.GONE
                mBinding.rvFavorite.visibility = View.VISIBLE

                if (mVideoDataList[mVideoDataList.size - 1].path.isEmpty()) {
                    mVideoDataList.removeAt(mVideoDataList.size - 1)
                }

                mVideoAdapter = FavoriteVideoAdapter(
                    mActivity, mVideoDataList, this, AppConstant.TYPE_VIDEO_LIST
                )
                mBinding.rvFavorite.run {
                    adapter = mVideoAdapter
                    itemAnimator = DefaultItemAnimator()
                }

                while (mBinding.rvFavorite.itemDecorationCount > 0) {
                    mBinding.rvFavorite.removeItemDecorationAt(0)
                }
                mBinding.rvFavorite.addItemDecoration(
                    com.videoplayer.music.common.utils.ItemOffsetDecoration(
                        mActivity, R.dimen._2sdp
                    )
                )

                mVideoData.removeAll(mVideoData.toSet())

                for (data in mList) {
                    mVideoData.add(
                        VideoData(
                            data.path,
                            data.pathID,
                            data.bucketName,
                            data.name,
                            data.date,
                            data.type,
                            data.size,
                            data.duration,
                            data.width,
                            data.height
                        )
                    )
                }

                setNative()
            }
        }
    }

    override fun initViewListener() {
        super.initViewListener()
        mBinding.ivSearch.setOnClickListener(this)
        mBinding.ivBack.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        super.onClick(v)

        when (v.id) {
            R.id.iv_all_option -> {
                val pos = v.tag as Int
                val data = getRecyclerVideoPlaylistData(v.getTag(R.id.TYPE).toString(), pos)
                getMenu(v, data)

            }

            R.id.con_main -> {
                val position = v.tag as Int
                val positions = mVideoDataFav.indexOf(mVideoAdapter.getItem(position))

                val data = getRecyclerVideoPlaylistData(v.getTag(R.id.TYPE).toString(), positions)
                if (com.videoplayer.music.videoplayer.player.PlayerActivity.mActivity != null) {
                    com.videoplayer.music.videoplayer.player.PlayerActivity.mActivity!!.finish()
                }
                AppConstant.mVideoData.clear()
                AppConstant.mVideoData.addAll(mVideoData)
                val intent = Intent(
                    mActivity,
                    com.videoplayer.music.videoplayer.player.PlayerActivity::class.java
                )
                intent.putExtra(AppConstant.POSITION, positions)
                launchActivity(intent)

                val db =
                    com.videoplayer.music.common.database.VideoPlayerDatabase.getInstance(
                        mActivity
                    )
                val contain = db!!.recentVideoDao()!!.isRecentVideo(data.path)

                if (contain == 0) {

                    val bookmark = RecentVideo(
                        null,
                        data.path,
                        data.pathID,
                        data.bucketName,
                        data.name,
                        data.date,
                        data.type,
                        data.size,
                        data.duration,
                        data.width,
                        data.height
                    )
                    db.recentVideoDao()!!.insertRecentVideo(bookmark)
                } else {
                    db.recentVideoDao().deleteRecentVideo(data.path)
                    val bookmark = RecentVideo(
                        null,
                        data.path,
                        data.pathID,
                        data.bucketName,
                        data.name,
                        data.date,
                        data.type,
                        data.size,
                        data.duration,
                        data.width,
                        data.height
                    )
                    db.recentVideoDao()!!.insertRecentVideo(bookmark)
                }
            }

            R.id.iv_search -> {

                VideoSearchActivity.mVideoData.removeAll(VideoSearchActivity.mVideoData.toSet())
                VideoSearchActivity.mVideoData.addAll(mVideoData)
                val intent = Intent(mActivity, VideoSearchActivity::class.java)
                launchActivity(intent)

            }

            R.id.iv_back -> {
                onBackPressedDispatcher.onBackPressed()
            }
        }
    }

    private fun getMenu(v: View, data: FavoriteVideo) {
        val wrapper = ContextThemeWrapper(mActivity, R.style.MaterialPopupMenuStyle)
        val popupMenu = PopupMenu(wrapper, v)
        popupMenu.menuInflater.inflate(R.menu.video_option, popupMenu.menu)
        val m = popupMenu.menu

        val contain = mDB.favoriteVideoDao().isFavoriteVideo(data.path)

        if (contain == 0) {
            m.findItem(R.id.menuUnFav).isVisible = false
            m.findItem(R.id.menuFavorite).isVisible = true
        } else {
            m.findItem(R.id.menuUnFav).isVisible = true
            m.findItem(R.id.menuFavorite).isVisible = false
        }
        m.findItem(R.id.menuDelete).isVisible = false
        popupMenu.setOnMenuItemClickListener { item ->
            when (item.itemId) {

                R.id.menuAddPlaylist -> {
                    addToPlaylistDialog(data)
                }

                R.id.menuFavorite -> {
                    val favorite = FavoriteVideo(
                        null,
                        data.path,
                        data.pathID,
                        data.bucketName,
                        data.name,
                        data.date,
                        data.type,
                        data.size,
                        data.duration,
                        data.width,
                        data.height
                    )
                    mDB.favoriteVideoDao().insertFavoriteVideo(favorite)
                }

                R.id.menuUnFav -> {
                    mDB.favoriteVideoDao().deleteFavoriteVideo(data.path)
                }

                R.id.menuFileInfo -> {
                    fileInfoDialog(data)
                }

                R.id.menuShare -> {
                    val uri = FileProvider.getUriForFile(
                        mActivity,
                        BuildConfig.APPLICATION_ID + ".provider",
                        File(data.path)
                    )
                    val intent = Intent(Intent.ACTION_SEND)
                    intent.type = "video/*"
                    intent.putExtra(Intent.EXTRA_TEXT, getString(R.string.share_msg))
                    intent.putExtra(Intent.EXTRA_STREAM, uri)
                    startActivity(Intent.createChooser(intent, "Share Video"))
                }
            }
            true
        }

        val menuHelper: Any
        val argTypes: Array<Class<*>?>
        try {
            val fMenuHelper: java.lang.reflect.Field =
                PopupMenu::class.java.getDeclaredField("mPopup")
            fMenuHelper.isAccessible = true
            menuHelper = fMenuHelper.get(popupMenu)!!
            argTypes = arrayOf(Boolean::class.javaPrimitiveType)
            menuHelper.javaClass.getDeclaredMethod("setForceShowIcon", *argTypes)
                .invoke(menuHelper, true)
        } catch (_: Exception) {

        }

        popupMenu.show()
    }

    private fun addToPlaylistDialog(data: FavoriteVideo) {
        val addToPlaylistDialog = Dialog(mActivity)
        addToPlaylistDialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        addToPlaylistDialog.setCancelable(false)
        val dialogBinding = AddPlaylistDialogBinding.inflate(LayoutInflater.from(mActivity))
        addToPlaylistDialog.setContentView(dialogBinding.root)

        val lp = WindowManager.LayoutParams()
        lp.copyFrom(addToPlaylistDialog.window!!.attributes)
        lp.width = WindowManager.LayoutParams.MATCH_PARENT
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT
        lp.gravity = Gravity.CENTER

        addToPlaylistDialog.window!!.attributes = lp
        addToPlaylistDialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        addToPlaylistDialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)

        val mDB = com.videoplayer.music.common.database.VideoPlayerDatabase.getInstance(
            mActivity
        )

        mPlayListVideoAdapter = AddPlaylistAdapter(
            R.layout.playlistname_list, {
                when (it.id) {
                    R.id.con_add_main -> {
                        val pos = it.tag as Int
                        val dt = getRecyclerVideo(it.getTag(R.id.TYPE).toString(), pos)
                        val added = mDB.videoDataDao().isAdded(data.path, dt.PlaylistName)
                        if (added == 0) {
                            val add = VideoDatalist(
                                null,
                                dt.PlaylistName,
                                data.path,
                                data.pathID,
                                data.bucketName,
                                data.name,
                                data.date,
                                data.type,
                                data.size,
                                data.duration,
                                data.width,
                                data.height
                            )
                            mDB.videoDataDao().insertPlaylistVideo(add)
                            EventBus.getDefault().post(AppConstant.EVENT_NOTIFY_PLAYLIST)
                        } else {
                            toast("Already exists in playlist")
                        }
                        addToPlaylistDialog.cancel()
                        addToPlaylistDialog.dismiss()
                    }
                }

            }, AppConstant.TYPE_VIDEO_LIST
        )

        dialogBinding.rvListname.run {
            adapter = mPlayListVideoAdapter
        }
        val mList = mDB.videoPlaylistDao().getPlaylist()

        if (mList.isEmpty()) {
            dialogBinding.tvChoosePlaylistLbl.visibility = View.GONE
            dialogBinding.rvListname.visibility = View.GONE
        } else {
            dialogBinding.tvChoosePlaylistLbl.visibility = View.VISIBLE
            dialogBinding.rvListname.visibility = View.VISIBLE
            mPlayListVideoAdapter.removeAll()
            mPlayListVideoAdapter.addAll(mList as java.util.ArrayList<VideoPlaylist>)
        }

        dialogBinding.ivCloseAddPlaylist.setOnClickListener {
            addToPlaylistDialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
            addToPlaylistDialog.cancel()
            addToPlaylistDialog.dismiss()
        }

        dialogBinding.btnAddCreate.setOnClickListener {
            addToPlaylistDialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
            val name = dialogBinding.etAddPlaylistName.text.toString().trim()
            if (name.isNotEmpty()) {
                val playlist = VideoPlaylist(name)
                val exists = mDB.videoPlaylistDao().isAdded(name)
                if (exists == 0) {
                    mDB.videoPlaylistDao().insertPlaylist(playlist)
                    val added = mDB.videoDataDao().isAdded(data.path, name)
                    if (added == 0) {
                        val add = VideoDatalist(
                            null,
                            name,
                            data.path,
                            data.pathID,
                            data.bucketName,
                            data.name,
                            data.date,
                            data.type,
                            data.size,
                            data.duration,
                            data.width,
                            data.height
                        )
                        mDB.videoDataDao().insertPlaylistVideo(add)
                        EventBus.getDefault().post(AppConstant.EVENT_NOTIFY_PLAYLIST)
                    } else {
                        toast("Already exists in playlist")
                    }
                    addToPlaylistDialog.cancel()
                    addToPlaylistDialog.dismiss()
                } else {
                    toast("Playlist name already exists")
                }
            } else {
                toast("Please enter playlist name")
            }

        }
        addToPlaylistDialog.show()

    }

    @SuppressLint("SetTextI18n")
    private fun fileInfoDialog(data: FavoriteVideo) {
        val dialog = Dialog(mActivity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        val dialogBinding = FileInfoDialogBinding.inflate(LayoutInflater.from(mActivity))
        dialog.setContentView(dialogBinding.root)

        val lp = WindowManager.LayoutParams()
        lp.copyFrom(dialog.window!!.attributes)
        lp.width = WindowManager.LayoutParams.MATCH_PARENT
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT
        lp.gravity = Gravity.CENTER

        dialog.window!!.attributes = lp
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
        val outputFormat = SimpleDateFormat("EEE d MMM yyyy HH:mm", Locale.ENGLISH)
        dialogBinding.tvFileTitle.text = data.name
        dialogBinding.tvFilePath.text = data.path
        dialogBinding.tvFileSize.text = formateSize(data.size)
        dialogBinding.tvFileFormate.text = data.type
        dialogBinding.tvFileDura.text = setDuration(data.duration)
        dialogBinding.tvFileDimen.text = "${data.width} x ${data.height}"
        dialogBinding.tvFileDate.text = outputFormat.format(Date(data.date))

        dialogBinding.closeFileInfo.setOnClickListener {
            dialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
            dialog.cancel()
            dialog.dismiss()

        }
        dialog.show()
    }

    private fun getRecyclerVideoPlaylistData(type: String, pos: Int): FavoriteVideo {
        var data: FavoriteVideo? = null
        when (type) {
            AppConstant.TYPE_VIDEO_LIST -> {
                data = mVideoAdapter.getItem(pos)
            }
        }
        return data!!
    }

    private fun getRecyclerVideo(type: String, pos: Int): VideoPlaylist {
        var data: VideoPlaylist? = null
        when (type) {
            AppConstant.TYPE_VIDEO_LIST -> {
                data = mPlayListVideoAdapter.getItem(pos)
            }
        }
        return data!!
    }
}