package com.videoplayer.music.musicplayer.activities

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.graphics.Color
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.animation.doOnEnd
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.commit
import androidx.lifecycle.lifecycleScope
import androidx.preference.PreferenceManager
import code.name.monkey.appthemehelper.util.VersionUtils
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.mediaplayer.video.player.videoplayer.music.R

import com.videoplayer.music.common.activity.MainActivity
import com.videoplayer.music.common.base.BaseBindingActivity
import com.videoplayer.music.common.utils.isOnline
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityMusicPlayerBinding
import com.videoplayer.music.common.utils.AdCache
import com.videoplayer.music.musicplayer.App
import com.videoplayer.music.musicplayer.App.Companion.lastClickTimeMusic
import com.videoplayer.music.musicplayer.GENERAL_THEME
import com.videoplayer.music.musicplayer.IMAGE_THEME
import com.videoplayer.music.musicplayer.db.toPlayCount
import com.videoplayer.music.musicplayer.extensions.dip
import com.videoplayer.music.musicplayer.extensions.drawAboveSystemBarsWithPadding
import com.videoplayer.music.musicplayer.extensions.isColorLight
import com.videoplayer.music.musicplayer.extensions.keepScreenOn
import com.videoplayer.music.musicplayer.extensions.makeStatusBarTransparent
import com.videoplayer.music.musicplayer.extensions.peekHeightAnimate
import com.videoplayer.music.musicplayer.extensions.resolveColor
import com.videoplayer.music.musicplayer.extensions.safeGetBottomInsets
import com.videoplayer.music.musicplayer.extensions.setDrawBehindSystemBars
import com.videoplayer.music.musicplayer.extensions.setImmersiveFullscreen
import com.videoplayer.music.musicplayer.extensions.setLightNavigationBar
import com.videoplayer.music.musicplayer.extensions.setLightNavigationBarAuto
import com.videoplayer.music.musicplayer.extensions.setNavigationBarColorPreOreo
import com.videoplayer.music.musicplayer.extensions.setTaskDescriptionColor
import com.videoplayer.music.musicplayer.extensions.surfaceColor
import com.videoplayer.music.musicplayer.extensions.whichFragment
import com.videoplayer.music.musicplayer.fragments.LibraryViewModel
import com.videoplayer.music.musicplayer.fragments.NowPlayingScreen
import com.videoplayer.music.musicplayer.fragments.base.AbsPlayerFragment
import com.videoplayer.music.musicplayer.fragments.player.adaptive.AdaptiveFragment
import com.videoplayer.music.musicplayer.fragments.player.blur.BlurPlayerFragment
import com.videoplayer.music.musicplayer.fragments.player.card.CardFragment
import com.videoplayer.music.musicplayer.fragments.player.cardblur.CardBlurFragment
import com.videoplayer.music.musicplayer.fragments.player.circle.CirclePlayerFragment
import com.videoplayer.music.musicplayer.fragments.player.classic.ClassicPlayerFragment
import com.videoplayer.music.musicplayer.fragments.player.color.ColorFragment
import com.videoplayer.music.musicplayer.fragments.player.fit.FitFragment
import com.videoplayer.music.musicplayer.fragments.player.flat.FlatPlayerFragment
import com.videoplayer.music.musicplayer.fragments.player.full.FullPlayerFragment
import com.videoplayer.music.musicplayer.fragments.player.gradient.GradientPlayerFragment
import com.videoplayer.music.musicplayer.fragments.player.material.MaterialFragment
import com.videoplayer.music.musicplayer.fragments.player.normal.PlayerFragment
import com.videoplayer.music.musicplayer.fragments.player.plain.PlainPlayerFragment
import com.videoplayer.music.musicplayer.fragments.player.simple.SimplePlayerFragment
import com.videoplayer.music.musicplayer.fragments.player.tiny.TinyPlayerFragment
import com.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.videoplayer.music.musicplayer.helper.MusicPlayerRemote
import com.videoplayer.music.musicplayer.service.MusicService
import com.videoplayer.music.musicplayer.util.PreferenceUtil
import com.videoplayer.music.musicplayer.util.ViewUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.jetbrains.anko.backgroundColor
import org.koin.androidx.viewmodel.ext.android.viewModel
import java.lang.ref.WeakReference

open class MusicPlayerActivity : BaseBindingActivity<ActivityMusicPlayerBinding>() {

    private lateinit var bottomSheetBehavior: com.videoplayer.music.musicplayer.RetroBottomSheetBehavior<FrameLayout>
    private val argbEvaluator: ArgbEvaluator = ArgbEvaluator()
    private var playerFragment: AbsPlayerFragment? = null

    private var nowPlayingScreen: NowPlayingScreen? = null
    private var navigationBarColor = 0
    private var taskColor: Int = 0
    private var paletteColor: Int = Color.WHITE
    private val panelState: Int get() = bottomSheetBehavior.state
    private var navigationBarColorAnimator: ValueAnimator? = null
    protected val libraryViewModel by viewModel<LibraryViewModel>()

    private var windowInsets: WindowInsetsCompat? = null
    private var isPause = false

    private val bottomSheetCallbackList = object : BottomSheetBehavior.BottomSheetCallback() {

        override fun onSlide(bottomSheet: View, slideOffset: Float) {
            setMiniPlayerAlphaProgress(slideOffset)
            navigationBarColorAnimator?.cancel()
            setNavigationBarColorPreOreo(
                argbEvaluator.evaluate(
                    slideOffset, surfaceColor(), navigationBarColor
                ) as Int
            )
        }


        override fun onStateChanged(bottomSheet: View, newState: Int) {
            when (newState) {
                BottomSheetBehavior.STATE_EXPANDED -> {
                    onPanelExpanded()
                    if (PreferenceUtil.lyricsScreenOn && PreferenceUtil.showLyrics) {
                        keepScreenOn(true)
                    }
                }

                BottomSheetBehavior.STATE_COLLAPSED -> {
                    onPanelCollapsed()
                    if ((PreferenceUtil.lyricsScreenOn && PreferenceUtil.showLyrics) || !PreferenceUtil.isScreenOnEnabled) {
                        keepScreenOn(false)
                    }
                }

                BottomSheetBehavior.STATE_SETTLING, BottomSheetBehavior.STATE_DRAGGING -> {
                    collapsePanel()
                }

                else -> {
                    println("Do a flip")
                }
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val clickInterval: Long = 60 * 1000
        val currentTime = System.currentTimeMillis()
        val elapsedTimeSinceLastClick = currentTime - lastClickTimeMusic
        if (elapsedTimeSinceLastClick >= clickInterval) {
            AdsConfig.showInterstitialAd(this@MusicPlayerActivity) {
                onBack()
            }
            lastClickTimeMusic = currentTime
        } else {
            onBack()
        }
    }

    private fun onBack() {
        if (intent.hasExtra("Click")) {
            val intent = Intent(mActivity, MainActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            launchActivity(intent, true)
        } else {
            super.onBackPressed()
        }
        overridePendingTransition(R.anim.slide_from_top, R.anim.slide_in_top)
    }

    override fun getActivityContext(): FragmentActivity {
        return this@MusicPlayerActivity
    }

    override fun setBinding(): ActivityMusicPlayerBinding {
        return ActivityMusicPlayerBinding.inflate(layoutInflater)
    }

    fun getBottomSheetBehavior() = bottomSheetBehavior

    override fun initView() {
        super.initView()
        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        } else {
            setImmersiveFullscreen()
        }

        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            IMAGE_THEME, ""
        )
        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getInt(
            GENERAL_THEME, 0
        )

        makeStatusBarTransparent()
        if (editors == "theme_image") {
            mBinding.root.background =
                RetroGlideExtension.getUserImageTheme(this@MusicPlayerActivity)
        } else if (editors == "theme_gradient") {
            mBinding.root.background =
                AppCompatResources.getDrawable(this, RetroGlideExtension.getUserGradientTheme())
        } else if (edit >= 0) {
            mBinding.root.background = null
            mBinding.root.backgroundColor = resolveColor(R.attr.mainBackgroundColor)
        }

        serviceToken = MusicPlayerRemote.bindToService(this, object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName, service: IBinder) {
                onServiceConnected()
            }

            override fun onServiceDisconnected(name: ComponentName) {
                onServiceDisconnected()
            }
        })

        chooseFragmentForTheme()
        setupSlidingUpPanel()
        setupBottomSheet()
        updateColor()

        ViewCompat.setOnApplyWindowInsetsListener(
            mBinding.root
        ) { _, insets ->
            windowInsets = insets
            insets
        }

        if (com.videoplayer.music.musicplayer.util.RetroUtil.isLandscape()) {
            mBinding.slidingPanel.drawAboveSystemBarsWithPadding()
        }

        navigationBarColor = surfaceColor()

        setBottomNavVisibility(visible = true, animate = true)

        expandPanel()

        if (PreferenceUtil.lyricsScreenOn && PreferenceUtil.showLyrics) {
            keepScreenOn(true)
        } else if (!PreferenceUtil.isScreenOnEnabled && !PreferenceUtil.showLyrics) {
            keepScreenOn(false)
        }

        setNative()
    }

    var mAdView: AdView?=null
    var isAdLoaded = false
    private fun setNative() {
        if (isOnline) {

            val adId = getString(R.string.bannerMusicPlayer)
            BannerAdHelper.showBanner(this, mBinding.frameLayout,  adId,
                AdCache.bannerMusicPlayer,
                { isLoaded,adView, message ->
                    mAdView=adView
                    AdCache.bannerMusicPlayer=adView
                    isAdLoaded = isLoaded
                })

        } else {
            mBinding.frameLayout.visibility = View.GONE
        }
    }

    private var isInOneTabMode = false

    private fun setBottomNavVisibility(
        visible: Boolean = true,
        animate: Boolean = false,
        hideBottomSheet: Boolean = MusicPlayerRemote.playingQueue.isEmpty()
    ) {
        if (isInOneTabMode) {
            return
        }
        hideBottomSheet(hide = hideBottomSheet, animate = animate, isBottomNavVisible = visible)
    }

    private fun hideBottomSheet(
        hide: Boolean, animate: Boolean = false, isBottomNavVisible: Boolean = false
    ) {
        val heightOfBar =
            if (MusicPlayerRemote.isCasting) dip(R.dimen.cast_mini_player_height) else dip(R.dimen.mini_player_height)
        val heightOfBarWithTabs = heightOfBar + 0
        if (hide) {
            bottomSheetBehavior.peekHeight = -windowInsets.safeGetBottomInsets()
            bottomSheetBehavior.state = BottomSheetBehavior.STATE_COLLAPSED
        } else {
            if (MusicPlayerRemote.playingQueue.isNotEmpty()) {
                mBinding.slidingPanel.elevation = 0F

                if (isBottomNavVisible) {
                    println("List")
                    if (animate) {
                        bottomSheetBehavior.peekHeightAnimate(heightOfBarWithTabs)
                    } else {
                        bottomSheetBehavior.peekHeight = heightOfBarWithTabs
                    }

                } else {
                    println("Details")
                    if (animate) {
                        bottomSheetBehavior.peekHeightAnimate(heightOfBar).doOnEnd {
                            mBinding.slidingPanel.bringToFront()
                        }
                    } else {
                        bottomSheetBehavior.peekHeight = heightOfBar
                        mBinding.slidingPanel.bringToFront()
                    }
                }
            }
        }
    }


    private fun setupSlidingUpPanel() {
        mBinding.slidingPanel.viewTreeObserver.addOnGlobalLayoutListener(object :
            ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                mBinding.slidingPanel.viewTreeObserver.removeOnGlobalLayoutListener(this)
                val params = mBinding.slidingPanel.layoutParams as ViewGroup.LayoutParams
                params.height = ViewGroup.LayoutParams.MATCH_PARENT
                mBinding.slidingPanel.layoutParams = params
                when (panelState) {
                    BottomSheetBehavior.STATE_EXPANDED -> onPanelExpanded()
                    BottomSheetBehavior.STATE_COLLAPSED -> onPanelCollapsed()
                    else -> {
                        // playerFragment!!.onHide()
                    }
                }
            }
        })
    }

    fun onPanelCollapsed() {
        setMiniPlayerAlphaProgress(0F)
        // restore values
        animateNavigationBarColor(surfaceColor())
        // setLightStatusBarAuto()
        setLightNavigationBarAuto()
        setTaskDescriptionColor(taskColor)
        playerFragment?.onHide()

    }

    private fun updateColor() {
        libraryViewModel.paletteColor.observe(this) { color ->
            this.paletteColor = color
            onPaletteColorChanged()
        }
    }

    fun onPanelExpanded() {
        setMiniPlayerAlphaProgress(1F)
        onPaletteColorChanged()
        playerFragment?.onShow()
    }


    private fun setupBottomSheet() {
        bottomSheetBehavior =
            BottomSheetBehavior.from(mBinding.slidingPanel) as com.videoplayer.music.musicplayer.RetroBottomSheetBehavior<FrameLayout>
        bottomSheetBehavior.addBottomSheetCallback(bottomSheetCallbackList)
        bottomSheetBehavior.isHideable = false
        bottomSheetBehavior.setAllowDragging(true)
        setMiniPlayerAlphaProgress(0F)
    }

    override fun onPause() {
        super.onPause()
        isPause = true
        Log.e(TAG, "onPause: ")
    }

    private var musicStateReceiver: MusicStateReceiver? = null

    override fun onResume() {
        super.onResume()
        if (nowPlayingScreen != PreferenceUtil.nowPlayingScreen) {
            recreate()
        }
        if (bottomSheetBehavior.state == BottomSheetBehavior.STATE_EXPANDED) {
            setMiniPlayerAlphaProgress(1f)
        }

        if (isPause) {
            isPause = false
            if (MusicPlayerRemote.playingQueue.isEmpty()) {
                try {
                    if (intent.hasExtra("Click")) {
                        mActivity.finishAndRemoveTask()
                    } else {
                        onBackPressed()
                    }
                } catch (e: Exception) {

                }
            }
        }
    }

    private fun setMiniPlayerAlphaProgress(progress: Float) {
        if (progress < 0) return
        mBinding.playerFragmentContainer.alpha = (progress - 0.2F) / 0.2F
    }


    private fun chooseFragmentForTheme() {
        nowPlayingScreen = PreferenceUtil.nowPlayingScreen

        val fragment: Fragment = when (nowPlayingScreen) {
            NowPlayingScreen.Adaptive -> AdaptiveFragment()//working
            NowPlayingScreen.Blur -> BlurPlayerFragment()//working
            NowPlayingScreen.BlurCard -> CardBlurFragment()//working
            NowPlayingScreen.Card -> CardFragment()//working
            NowPlayingScreen.Circle -> CirclePlayerFragment()//working
            NowPlayingScreen.Classic -> ClassicPlayerFragment()//working
            NowPlayingScreen.Color -> ColorFragment()//working
            NowPlayingScreen.Fit -> FitFragment()//working
            NowPlayingScreen.Flat -> FlatPlayerFragment()//working
            NowPlayingScreen.Full -> FullPlayerFragment()//working
            NowPlayingScreen.Material -> MaterialFragment()//
            NowPlayingScreen.Normal -> PlayerFragment()//working
            NowPlayingScreen.Plain -> PlainPlayerFragment()//
            NowPlayingScreen.Simple -> SimplePlayerFragment()//
            NowPlayingScreen.Gradient -> GradientPlayerFragment()//
            NowPlayingScreen.Tiny -> TinyPlayerFragment()
            else -> PlayerFragment()
        }
        supportFragmentManager.commit {
            replace(R.id.playerFragmentContainer, fragment)
        }

        playerFragment = whichFragment<AbsPlayerFragment>(R.id.playerFragmentContainer)
    }

    fun collapsePanel() {
        onBackPressedDispatcher.onBackPressed()
    }

    private fun expandPanel() {
        bottomSheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED
    }

    private fun setTaskDescColor(color: Int) {
        taskColor = color
        if (panelState == BottomSheetBehavior.STATE_COLLAPSED) {
            setTaskDescriptionColor(color)
        }
    }

    private fun onPaletteColorChanged() {
        if (panelState == BottomSheetBehavior.STATE_EXPANDED) {
            navigationBarColor = surfaceColor()
            setTaskDescColor(paletteColor)
            val isColorLight = paletteColor.isColorLight
            if (PreferenceUtil.isAdaptiveColor && (nowPlayingScreen == NowPlayingScreen.Normal || nowPlayingScreen == NowPlayingScreen.Flat)) {
                setLightNavigationBar(true)
                // setLightStatusBar(isColorLight)
            } else if (nowPlayingScreen == NowPlayingScreen.Card || nowPlayingScreen == NowPlayingScreen.Blur || nowPlayingScreen == NowPlayingScreen.BlurCard) {
                animateNavigationBarColor(Color.BLACK)
                navigationBarColor = Color.BLACK
                //  setLightStatusBar(false)
                setLightNavigationBar(true)
            } else if (nowPlayingScreen == NowPlayingScreen.Color || nowPlayingScreen == NowPlayingScreen.Tiny || nowPlayingScreen == NowPlayingScreen.Gradient) {
                animateNavigationBarColor(paletteColor)
                navigationBarColor = paletteColor
                setLightNavigationBar(isColorLight)
                //  setLightStatusBar(isColorLight)
            } else if (nowPlayingScreen == NowPlayingScreen.Full) {
                animateNavigationBarColor(paletteColor)
                navigationBarColor = paletteColor
                setDrawBehindSystemBars()
                setLightNavigationBar(isColorLight)
                //setLightStatusBar(false)
            }
        }
    }

    private fun animateNavigationBarColor(color: Int) {
        if (VersionUtils.hasOreo()) return
        navigationBarColorAnimator?.cancel()
        navigationBarColorAnimator = ValueAnimator.ofArgb(window.navigationBarColor, color).apply {
            duration = ViewUtil.RETRO_MUSIC_ANIM_TIME.toLong()
            interpolator = PathInterpolator(0.4f, 0f, 1f, 1f)
            addUpdateListener { animation: ValueAnimator ->
                setNavigationBarColorPreOreo(
                    animation.animatedValue as Int
                )
            }
            start()
        }
    }

    override fun onServiceConnected() {
        if (!receiverRegistered) {
            musicStateReceiver = MusicStateReceiver(this)

            val filter = IntentFilter()
            filter.addAction(MusicService.PLAY_STATE_CHANGED)
            filter.addAction(MusicService.SHUFFLE_MODE_CHANGED)
            filter.addAction(MusicService.REPEAT_MODE_CHANGED)
            filter.addAction(MusicService.META_CHANGED)
            filter.addAction(MusicService.QUEUE_CHANGED)
            filter.addAction(MusicService.MEDIA_STORE_CHANGED)
            filter.addAction(MusicService.FAVORITE_STATE_CHANGED)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                registerReceiver(musicStateReceiver, filter, RECEIVER_EXPORTED)
            } else {
                registerReceiver(musicStateReceiver, filter)
            }

            receiverRegistered = true
        }

        for (listener in mMusicServiceEventListeners) {
            listener.onServiceConnected()
        }
    }

    class MusicStateReceiver(activity: MusicPlayerActivity) : BroadcastReceiver() {

        val reference: WeakReference<MusicPlayerActivity> = WeakReference(activity)

        override fun onReceive(context: Context, intent: Intent) {
            val action = intent.action
            val activity = reference.get()
            if (activity != null && action != null) {
                when (action) {
                    MusicService.FAVORITE_STATE_CHANGED -> activity.onFavoriteStateChanged()
                    MusicService.META_CHANGED -> activity.onPlayingMetaChanged()
                    MusicService.QUEUE_CHANGED -> activity.onQueueChanged()
                    MusicService.PLAY_STATE_CHANGED -> activity.onPlayStateChanged()
                    MusicService.REPEAT_MODE_CHANGED -> activity.onRepeatModeChanged()
                    MusicService.SHUFFLE_MODE_CHANGED -> activity.onShuffleModeChanged()
                    MusicService.MEDIA_STORE_CHANGED -> activity.onMediaStoreChanged()
                }
            }
        }
    }

    override fun onServiceDisconnected() {
        if (receiverRegistered) {
            unregisterReceiver(musicStateReceiver)
            receiverRegistered = false
        }

        for (listener in mMusicServiceEventListeners) {
            listener.onServiceDisconnected()
        }
    }

    override fun onQueueChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onQueueChanged()
        }
    }


    override fun onPlayingMetaChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onPlayingMetaChanged()
        }
        lifecycleScope.launch(Dispatchers.IO) {
            val entity = repository.songPresentInHistory(MusicPlayerRemote.currentSong)
            if (entity != null) {
                repository.updateHistorySong(MusicPlayerRemote.currentSong)
            } else {
                repository.addSongToHistory(MusicPlayerRemote.currentSong)
            }
            val songs = repository.checkSongExistInPlayCount(MusicPlayerRemote.currentSong.id)
            if (songs.isNotEmpty()) {
                repository.updateSongInPlayCount(songs.first().apply {
                    playCount += 1
                })
            } else {
                repository.insertSongInPlayCount(MusicPlayerRemote.currentSong.toPlayCount())
            }
        }
    }

    override fun onPlayStateChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onPlayStateChanged()
        }
    }

    override fun onRepeatModeChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onRepeatModeChanged()
        }
    }

    override fun onShuffleModeChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onShuffleModeChanged()
        }
    }

    override fun onFavoriteStateChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onFavoriteStateChanged()
        }
    }

    override fun onMediaStoreChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onMediaStoreChanged()
        }
    }
}