package com.videoplayer.music.musicplayer.glide

import android.graphics.drawable.Drawable
import android.widget.ImageView
import com.bumptech.glide.request.transition.Transition
import com.videoplayer.music.musicplayer.App

abstract class RetroMusicColoredTarget(view: ImageView) : com.videoplayer.music.musicplayer.glide.palette.BitmapPaletteTarget(view) {

    abstract fun onColorReady(colors: com.videoplayer.music.musicplayer.util.color.MediaNotificationProcessor)

    override fun onLoadFailed(errorDrawable: Drawable?) {
        super.onLoadFailed(errorDrawable)
        onColorReady(com.videoplayer.music.musicplayer.util.color.MediaNotificationProcessor.errorColor(App.getContext()))
    }

    override fun onResourceReady(
        resource: com.videoplayer.music.musicplayer.glide.palette.BitmapPaletteWrapper,
        transition: Transition<in com.videoplayer.music.musicplayer.glide.palette.BitmapPaletteWrapper>?
    ) {
        super.onResourceReady(resource, transition)
        com.videoplayer.music.musicplayer.util.color.MediaNotificationProcessor(App.getContext())
            .getPaletteAsync({
            onColorReady(it)
        }, resource.bitmap)
    }
}
