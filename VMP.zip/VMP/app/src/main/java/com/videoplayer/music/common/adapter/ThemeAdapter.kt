package com.videoplayer.music.common.adapter

import android.app.Activity
import android.content.res.ColorStateList
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.mediaplayer.video.player.videoplayer.music.R
import com.videoplayer.music.musicplayer.glide.playlistPreview.GlideScope

class ThemeAdapter(
    val mContext: Activity,
    private val isColor: Boolean,
    private val themeOptions: MutableList<Int>,
    val listener: RVClickListener
) : RecyclerView.Adapter<ThemeAdapter.ViewHolder>() {

    private var clickedPosition = 0

    interface RVClickListener {
        fun onThemeClick(position: Int)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            LayoutInflater.from(mContext).inflate(R.layout.raw_main_theme, parent, false)
        )
    }

    override fun getItemCount(): Int {
        return themeOptions.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val nearby = themeOptions[position]
        Log.e("onBindViewHolder","position:$position")
        if (isColor) {
//            holder.ivThumb.imageTintList = ColorStateList.valueOf(mContext.resources.getColor(nearby))
            holder.ivThumb.imageTintList = ColorStateList.valueOf(ContextCompat.getColor(mContext, nearby))
        } else {
//            Glide.with(mContext).asBitmap().load(nearby).into(holder.ivThumb)
//            holder.ivThumb.setImageDrawable(ContextCompat.getDrawable(mContext, nearby))
            holder.ivThumb.setImageResource(nearby)
//            holder.ivThumb.setImageDrawable(mContext.getDrawable(nearby))
        }

        holder.itemView.setOnClickListener {
            clickedPosition = position
            listener.onThemeClick(position)
            notifyDataSetChanged()
        }
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivThumb: ImageView = itemView.findViewById(R.id.iv_thumb)
    }
}