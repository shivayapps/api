package com.videoplayer.music.common.adapter

import android.app.Activity
import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.mediaplayer.video.player.videoplayer.music.R

class ThemeAdapter(
    val mContext: Activity,
    private val isColor: Boolean,
    private val themeOptions: MutableList<Int>,
    val listener: RVClickListener
) : RecyclerView.Adapter<ThemeAdapter.ViewHolder>() {

    private var clickedPosition = 0

    interface RVClickListener {
        fun onThemeClick(position: Int)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            LayoutInflater.from(mContext).inflate(R.layout.raw_main_theme, parent, false)
        )
    }

    override fun getItemCount(): Int {
        return themeOptions.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val nearby = themeOptions[position]
        if (isColor) {
//            holder.ivThumb.imageTintList = ColorStateList.valueOf(mContext.getColor(nearby))
            holder.ivThumb.imageTintList = ColorStateList.valueOf(nearby)
        } else {
            holder.ivThumb.setImageResource(nearby)
        }

        holder.itemView.setOnClickListener {
            clickedPosition = position
            listener.onThemeClick(position)
            notifyDataSetChanged()
        }
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivThumb: ImageView = itemView.findViewById(R.id.iv_thumb)
    }
}