package com.videoplayer.music.common.activity

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.view.View
import androidx.appcompat.content.res.AppCompatResources
import androidx.fragment.app.FragmentActivity
import androidx.preference.PreferenceManager
import com.adconfig.AdsConfig
import com.adconfig.adsutil.AdsParameters
import com.adconfig.adsutil.Config
import com.adconfig.adsutil.Config.checkReInter
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.BannerAdHelper
import com.adconfig.adsutil.utils.LoadingDialog
import com.google.android.gms.ads.AdView
import com.mediaplayer.video.player.videoplayer.music.R

import com.videoplayer.music.common.base.BaseBindingActivity
import com.videoplayer.music.common.utils.isOnline
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityThemeBinding
import com.videoplayer.music.common.cropper.CropImage
import com.videoplayer.music.common.utils.AdCache
import com.videoplayer.music.musicplayer.App
import com.videoplayer.music.musicplayer.GENERAL_THEME
import com.videoplayer.music.musicplayer.IMAGE_THEME
import com.videoplayer.music.musicplayer.extensions.makeStatusBarTransparent
import com.videoplayer.music.musicplayer.extensions.resolveColor
import com.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.videoplayer.music.videoplayer.model.VideoData
import com.videoplayer.music.common.utils.backgroundColor

class ThemeActivity : BaseBindingActivity<ActivityThemeBinding>() {

    companion object {
        var mVideoData: ArrayList<VideoData> = ArrayList()
    }

    override fun getActivityContext(): FragmentActivity {
        return this@ThemeActivity
    }

    override fun setBinding(): ActivityThemeBinding {
        return ActivityThemeBinding.inflate(layoutInflater)
    }

    override fun onResume() {
        super.onResume()
        initView()
    }

    lateinit var adsPreferences: AdsParameters
    override fun initAds() {
        super.initAds()
        adsPreferences = AdsParameters(this)
//        val adId = getString(R.string.ads_inter)
//        if (adsPreferences.isNeedInterAd) {
//            AdmobIntersAdImpl().load(this, adId)
//        } else {
//            checkReInter {
//                if (it) {
//                    AdmobIntersAdImpl().load(this, adId)
//                    adsPreferences.isNeedInterAd = true
//                }
//            }
//        }
    }

    override fun initView() {
        super.initView()

        //https://www.figma.com/design/Ij6Gt5dUvk5tyshEti8ZEW/Walper---Wallpaper-App-UI-Kit-(Preview)-(Community)?node-id=0-1&node-type=canvas&t=LnmlgvLS7BoPSHV4-0
        //https://www.figma.com/design/TVSMI00SjvGhtDhnLOAl0J/Apple-Home-App-Wallpaper-Templates-(Community)?node-id=1-3&node-type=canvas&t=aqxFYWFTXl2q9itu-0

        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext())
            .getString(IMAGE_THEME, "")
        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getInt(
            GENERAL_THEME, 0
        )

        makeStatusBarTransparent()

        if (editors == "theme_image") {
            mBinding.root.background = RetroGlideExtension.getUserImageTheme(this@ThemeActivity)
            mBinding.constraintLayout.background = null
        } else if (editors == "theme_gradient") {
            mBinding.root.background =
                AppCompatResources.getDrawable(this, RetroGlideExtension.getUserGradientTheme())
            mBinding.constraintLayout.background = null
        } else if (edit >= 0) {
            mBinding.root.background = null
            mBinding.root.backgroundColor = resolveColor(R.attr.mainBackgroundColor)
        }
        setNative()
    }

    var mAdView: AdView? = null
    var isAdLoaded = false
    private fun setNative() {
        if (isOnline) {
            val adId = getString(R.string.bannerTheme)
            BannerAdHelper.showBanner(this, mBinding.frameLayout, mBinding.frameLayout, adId,
                AdCache.bannerTheme,
                { isLoaded, adView, message ->
                    mAdView = adView
                    AdCache.bannerTheme = adView
                    isAdLoaded = isLoaded
                })

        } else {
            mBinding.frameLayout.visibility = View.GONE
        }
    }

    override fun onBackPressed() {

        if (adsPreferences.isNeedInterAd && checkReInter()) {
            val progressDialog = LoadingDialog(this, "Loading...")
            progressDialog.show()
            val adId = getString(R.string.ads_inter)
            AdmobIntersAdImpl().load(this, adId) { isLoaded: Boolean ->
                progressDialog.dismiss()
                if (isLoaded) {
                    AdsConfig.showInterstitialAd(this) {
                        //if(it) adsPreferences.isNeedInterAd = false
                        finish()
                    }
                } else {
                    finish()
                }
            }

        } else {
            super.onBackPressed()
        }

//        val clickInterval: Long = 40 * 1000
//        val currentTime = System.currentTimeMillis()
//        val elapsedTimeSinceLastClick = currentTime - App.lastClickTimeTheme
//        if (elapsedTimeSinceLastClick >= clickInterval) {
//
//            AdsConfig.showInterstitialAd(this@ThemeActivity) {
//                onBack()
//            }
//
//            App.lastClickTimeTheme = currentTime
//        } else {
//            onBack()
//        }
    }

//    private fun onBack() {
//        super.onBackPressed()
//    }

    override fun initViewListener() {
        super.initViewListener()
        mBinding.ivBack.setOnClickListener(this)
        mBinding.clThemeImage.setOnClickListener(this)
        mBinding.clThemeColor.setOnClickListener(this)
        mBinding.clThemeGradient.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        super.onClick(v)
        when (v.id) {
            R.id.iv_back -> {
                onBackPressed()
            }

            R.id.cl_theme_image -> {
                CropImage.activity()
                    .setGuidelines(com.videoplayer.music.common.cropper.CropImageView.Guidelines.ON)
                    .setActivityTitle("Crop").setCropMenuCropButtonTitle("Crop")
                    .setAspectRatio(9, 16).start(this)
            }

            R.id.cl_theme_color -> {
                val intent = Intent(this@ThemeActivity, ThemeSaveActivity::class.java)
                intent.putExtra("themeType", "color")
                startActivity(intent)
            }

            R.id.cl_theme_gradient -> {
                val intent = Intent(this@ThemeActivity, ThemeSaveActivity::class.java)
                intent.putExtra("themeType", "gradient")
                startActivity(intent)
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == com.videoplayer.music.common.cropper.CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            val result =
                com.videoplayer.music.common.cropper.CropImage.getActivityResult(data)
            if (resultCode == Activity.RESULT_OK) {
                proceedToTheme(result.uri)
            } else if (resultCode == com.videoplayer.music.common.cropper.CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                finish()
            }
        }
    }

    private fun proceedToTheme(fileUri: Uri) {
        val intent = Intent(this@ThemeActivity, ThemeSaveActivity::class.java)
        intent.putExtra("themeType", "image")
        intent.putExtra("fileUri", fileUri.toString())
        startActivity(intent)
    }
}