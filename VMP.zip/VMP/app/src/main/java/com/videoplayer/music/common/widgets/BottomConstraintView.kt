package com.videoplayer.music.common.widgets

import android.content.Context
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import com.airbnb.lottie.LottieAnimationView
import com.airbnb.lottie.LottieCompositionFactory
import com.bumptech.glide.Glide
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.databinding.LayoutBottomTabbarBinding

//import com.example.gallerymvvm.R
//import com.example.gallerymvvm.databinding.LayoutBottomTabbarBinding

class BottomConstraintView : ConstraintLayout, View.OnClickListener {

    var callBack: ((Int) -> Unit)? = null

    var binding: LayoutBottomTabbarBinding = LayoutBottomTabbarBinding.inflate(LayoutInflater.from(context), this, true)

    constructor(context: Context) : super(context)

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs)

    override fun onFinishInflate() {
        super.onFinishInflate()
        initListeners()
        selectItem(0)

    }

    private fun initListeners() {
        binding.video.setOnClickListener(this)
        binding.music.setOnClickListener(this)

    }

    override fun onClick(view: View?) {

        when (view) {

            binding.video -> {
                callBack?.invoke(0)
                // selectItem(0)
            }

            binding.music -> {
                callBack?.invoke(1)
                // selectItem(1)
            }
        }
    }

    fun selectItem(index: Int) {
        val iconVideoSelected = ContextCompat.getDrawable(context, R.drawable.ic_tab1_selected)
        val iconMusicSelected = ContextCompat.getDrawable(context, R.drawable.ic_tab2_selected)
        val iconVideo = ContextCompat.getDrawable(context, R.drawable.ic_tab1)
        val iconMusic = ContextCompat.getDrawable(context, R.drawable.ic_tab2)

        when (index) {

            0 -> {
                loadLottie(iconVideoSelected, binding.ivVideo, binding.tvTitleVideo)
                loadVec(iconMusic, binding.ivMusic, binding.tvTitleMusic)
            }

            1 -> {
                loadLottie(iconMusicSelected, binding.ivMusic, binding.tvTitleMusic)
                loadVec(iconVideo, binding.ivVideo, binding.tvTitleVideo)
            }

        }
    }

    private fun loadVec(drawable: Drawable?, lav: ImageView, tv: TextView) {
        Glide.with(context)
            .load(drawable)
            .into(lav)

        tv.setTextColor(ContextCompat.getColor(context, R.color.gray))
    }

    private fun loadLottie(drawable: Drawable?, lottieAnimationView: ImageView, tv: TextView) {
        Glide.with(context)
            .load(drawable)
            .into(lottieAnimationView)
        tv.setTextColor(ContextCompat.getColor(context, R.color.color_primary))
    }


}