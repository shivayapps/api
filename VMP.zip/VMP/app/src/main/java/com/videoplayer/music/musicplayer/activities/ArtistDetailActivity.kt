package com.videoplayer.music.musicplayer.activities


import android.content.Intent
import android.text.Spanned
import android.util.Log
import android.view.View
import androidx.appcompat.content.res.AppCompatResources
import androidx.fragment.app.FragmentActivity
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.adconfig.adsutil.admob.BannerAdHelper
import com.afollestad.materialcab.attached.AttachedCab
import com.afollestad.materialcab.attached.destroy
import com.afollestad.materialcab.attached.isActive
import com.afollestad.materialcab.createCab
import com.google.android.gms.ads.AdView
import com.mediaplayer.video.player.videoplayer.music.R

import com.videoplayer.music.common.base.BaseBindingActivity
import com.videoplayer.music.common.utils.isOnline
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityArtistDetailBinding
import com.videoplayer.music.common.utils.AdCache
import com.videoplayer.music.musicplayer.App
import com.videoplayer.music.musicplayer.EXTRA_ALBUM_ID
import com.videoplayer.music.musicplayer.EXTRA_ARTIST_ID
import com.videoplayer.music.musicplayer.GENERAL_THEME
import com.videoplayer.music.musicplayer.IMAGE_THEME
import com.videoplayer.music.musicplayer.adapter.album.HorizontalAlbumAdapter
import com.videoplayer.music.musicplayer.adapter.song.SimpleSongAdapter
import com.videoplayer.music.musicplayer.extensions.makeStatusBarTransparent
import com.videoplayer.music.musicplayer.extensions.resolveColor
import com.videoplayer.music.musicplayer.extensions.setDrawBehindSystemBars
import com.videoplayer.music.musicplayer.extensions.setImmersiveFullscreen
import com.videoplayer.music.musicplayer.extensions.surfaceColor
import com.videoplayer.music.musicplayer.fragments.artists.ArtistDetailsViewModel
import com.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.videoplayer.music.musicplayer.glide.SingleColorTarget
import com.videoplayer.music.musicplayer.helper.MusicPlayerRemote
import com.videoplayer.music.musicplayer.interfaces.IAlbumClickListener
import com.videoplayer.music.musicplayer.interfaces.ICabCallback
import com.videoplayer.music.musicplayer.interfaces.ICabHolder
import com.videoplayer.music.musicplayer.model.Artist
import com.videoplayer.music.musicplayer.util.MusicUtil
import com.videoplayer.music.musicplayer.util.PreferenceUtil
import org.jetbrains.anko.backgroundColor
import org.koin.androidx.viewmodel.ext.android.viewModel
import org.koin.core.parameter.parametersOf

class ArtistDetailActivity : BaseBindingActivity<ActivityArtistDetailBinding>(),
    IAlbumClickListener, ICabHolder {

    private lateinit var detailsViewModel: ArtistDetailsViewModel
    private lateinit var artist: Artist
    private lateinit var songAdapter: SimpleSongAdapter
    private lateinit var albumAdapter: HorizontalAlbumAdapter
    private var biography: Spanned? = null
    private var lang: String? = null

    override fun initView() {
        super.initView()

        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        } else {
            setImmersiveFullscreen()
        }

        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            IMAGE_THEME, ""
        )
        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getInt(
            GENERAL_THEME, 0
        )

        makeStatusBarTransparent()

        if (editors == "theme_image") {
            mBinding.root.background =
                RetroGlideExtension.getUserImageTheme(this@ArtistDetailActivity)
        } else if (editors == "theme_gradient") {
            mBinding.root.background =
                AppCompatResources.getDrawable(this, RetroGlideExtension.getUserGradientTheme())
        } else if (edit >= 0) {
            mBinding.root.background = null
            mBinding.root.backgroundColor = resolveColor(R.attr.mainBackgroundColor)
        }

        showProgressDialog(mActivity, "Please wait...")

        Log.e(TAG, "initView: ")

        val id = intent.getLongExtra(EXTRA_ARTIST_ID, 0)

        val detail: ArtistDetailsViewModel by viewModel {
            parametersOf(id, null)
        }

        detailsViewModel = detail

        addMusicServiceEventListener(detailsViewModel)

        detailsViewModel.getArtist().observe(this@ArtistDetailActivity) {
            showArtist(it)
        }

        setupRecyclerView()

        mBinding.fragmentArtistContent.playAction.apply {
            setOnClickListener { MusicPlayerRemote.openQueue(artist.sortedSongs, 0, true) }
        }

        mBinding.fragmentArtistContent.shuffleAction.apply {
            setOnClickListener { MusicPlayerRemote.openAndShuffleQueue(artist.songs, true) }
        }

        mBinding.icBack.setOnClickListener(object :
            com.videoplayer.music.common.widgets.OnSingleClickListener() {
            override fun onSingleClick(v: View?) {
                onBackPressed()
            }
        })
        setNative()
    }

    var mAdView: AdView?=null
    var isAdLoaded = false
    private fun setNative() {
        if (isOnline) {

            val adId = getString(R.string.bannerArtistDetail)
            BannerAdHelper.showBanner(this, mBinding.frameLayout,mBinding.frameLayout,  adId,
                AdCache.bannerArtistDetail,
                { isLoaded,adView, message ->
                    mAdView=adView
                    AdCache.bannerArtistDetail=adView
                    isAdLoaded = isLoaded
                })

        } else {
            mBinding.frameLayout.visibility = View.GONE
        }
    }

    override fun getActivityContext(): FragmentActivity {
        return this@ArtistDetailActivity
    }

    private fun showArtist(artist: Artist) {
        if (artist.songCount == 0) {
            return
        }
        this.artist = artist
        loadArtistImage(artist)

        mBinding.artistTitle.text = artist.name
        mBinding.text.text = String.format(
            "%s • %s",
            MusicUtil.getArtistInfoString(this@ArtistDetailActivity, artist),
            MusicUtil.getReadableDurationString(MusicUtil.getTotalDuration(artist.songs))
        )
        val songText = resources.getQuantityString(
            R.plurals.albumSongs,
            artist.songCount,
            artist.songCount
        )
        val albumText = resources.getQuantityString(
            R.plurals.albums,
            artist.songCount,
            artist.songCount
        )
        mBinding.fragmentArtistContent.songTitle.text = songText
        mBinding.fragmentArtistContent.albumTitle.text = albumText
        songAdapter.swapDataSet(artist.sortedSongs)
        albumAdapter.swapDataSet(artist.albums)



        Log.e(TAG, "showArtist: ")
    }

    private fun setupRecyclerView() {
        albumAdapter = HorizontalAlbumAdapter(this@ArtistDetailActivity, ArrayList(), this, this)
        mBinding.fragmentArtistContent.albumRecyclerView.apply {
            itemAnimator = DefaultItemAnimator()
            layoutManager = GridLayoutManager(this.context, 1, GridLayoutManager.HORIZONTAL, false)
            adapter = albumAdapter
        }
        songAdapter =
            SimpleSongAdapter(this@ArtistDetailActivity, ArrayList(), R.layout.item_song, this)
        mBinding.fragmentArtistContent.recyclerView.apply {
            itemAnimator = DefaultItemAnimator()
            layoutManager = LinearLayoutManager(this.context)
            adapter = songAdapter
        }
        Log.e(TAG, "setupRecyclerView: ")
    }

    private fun loadArtistImage(artist: Artist) {
        val artists = artist.name.split(",", "&")
        val m = com.videoplayer.music.common.artistdatabase.ArtistDatabase.getInstance(
            mActivity
        )
        val image = m.artistDao().getArtist(artists[0])
        if (image != null) {
            com.videoplayer.music.musicplayer.glide.GlideApp.with(mActivity)
                .asBitmapPalette()
//                .albumCoverOptions(album.safeGetFirstSong())
                //.checkIgnoreMediaStore()
                .load(image.picture)
                .placeholder(R.drawable.default_artist_art)
                .transition(RetroGlideExtension.getDefaultTransition())
                .into(object : SingleColorTarget(mBinding.image) {
                    override fun onColorReady(color: Int) {
                        setColors(color)
                    }
                })
//            GlideApp.with(mActivity)
//                .asBitmapPalette()
//                .load(image.picture)
//                .placeholder(R.drawable.default_artist_art)
//                .transition(RetroGlideExtension.getDefaultTransition())
//                .into(object : SingleColorTarget(mBinding.image) {
//                    override fun onColorReady(color: Int) {
//                        setColors(color)
//                    }
//                })
        } else {
            com.videoplayer.music.musicplayer.glide.GlideApp.with(mActivity)
                .asBitmapPalette()
                .load(RetroGlideExtension.getArtistModel(artist))
                .artistImageOptions(artist)
                .transition(RetroGlideExtension.getDefaultTransition())
                .into(object : SingleColorTarget(mBinding.image) {
                    override fun onColorReady(color: Int) {
                        setColors(color)
                    }
                })
        }
    }

    private fun setColors(color: Int) {
        hideProgressDialog()
    }

    override fun onAlbumClick(albumId: Long, view: View) {
        val intent = Intent(
            this@ArtistDetailActivity,
            AlbumDetalitActivity::class.java
        )
        intent.putExtra(EXTRA_ALBUM_ID, albumId)
        launchActivity(intent)
    }


    private var cab: AttachedCab? = null

    override fun openCab(menuRes: Int, callback: ICabCallback): AttachedCab {
        cab?.let {
            if (it.isActive()) {
                it.destroy()
            }
        }
        cab = createCab(R.id.toolbar_container) {
            menu(menuRes)
            closeDrawable(R.drawable.ic_close)
            backgroundColor(
                literal = com.videoplayer.music.musicplayer.util.RetroColorUtil.shiftBackgroundColor(
                    surfaceColor()
                )
            )
            slideDown()
            onCreate { cab, menu -> callback.onCabCreated(cab, menu) }
            onSelection {
                callback.onCabItemClicked(it)
            }
            onDestroy { callback.onCabFinished(it) }
        }
        return cab as AttachedCab
    }

    override fun setBinding(): ActivityArtistDetailBinding {
        return ActivityArtistDetailBinding.inflate(layoutInflater)
    }
}