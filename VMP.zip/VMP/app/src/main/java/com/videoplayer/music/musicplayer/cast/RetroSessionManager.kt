package com.videoplayer.music.musicplayer.cast

import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.SessionManagerListener

interface RetroSessionManager : SessionManagerListener<CastSession> {
    override fun onSessionResuming(p0: CastSession, p1: String) {

    }

    override fun onSessionStartFailed(p0: CastSession, p1: Int) {

    }

    override fun onSessionResumeFailed(p0: CastSession, p1: Int) {

    }

    override fun onSessionEnding(p0: CastSession) {

    }
}