package com.videoplayer.music.musicplayer.interfaces

import android.view.View

interface IAlbumClickListener {
    fun onAlbumClick(albumId: Long, view: View)
}
