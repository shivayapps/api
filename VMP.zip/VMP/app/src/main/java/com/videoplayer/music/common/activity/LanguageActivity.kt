package com.videoplayer.music.common.activity

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageView
import androidx.appcompat.content.res.AppCompatResources
import androidx.fragment.app.FragmentActivity
import androidx.preference.PreferenceManager
import com.adconfig.adsutil.admob.BannerAdHelper
import com.adconfig.adsutil.admob.NativeAdHelper
import com.adconfig.adsutil.admob.NativeLayoutType
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.mediaplayer.video.player.videoplayer.music.R

import com.videoplayer.music.common.activity.LocaleHelper.onAttach
import com.videoplayer.music.common.activity.LocaleHelper.setLocale
import com.videoplayer.music.common.base.BaseBindingActivity
import com.videoplayer.music.common.utils.isOnline
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityLanguegeBinding
import com.videoplayer.music.common.utils.AdCache
import com.videoplayer.music.common.utils.MyBounceInterpolator
import com.videoplayer.music.musicplayer.ADAPTIVE_COLOR_APP
import com.videoplayer.music.musicplayer.ALBUM_COVER_TRANSFORM
import com.videoplayer.music.musicplayer.APPBAR_MODE
import com.videoplayer.music.musicplayer.App
import com.videoplayer.music.musicplayer.BANNER_IMAGE_PATH
import com.videoplayer.music.musicplayer.BLACK_THEME
import com.videoplayer.music.musicplayer.CAROUSEL_EFFECT
import com.videoplayer.music.musicplayer.CIRCLE_PLAY_BUTTON
import com.videoplayer.music.musicplayer.CIRCULAR_ALBUM_ART
import com.videoplayer.music.musicplayer.CUSTOM_FONT
import com.videoplayer.music.musicplayer.DESATURATED_COLOR
import com.videoplayer.music.musicplayer.EXTRA_SONG_INFO
import com.videoplayer.music.musicplayer.FIRST_KEY
import com.videoplayer.music.musicplayer.GET_STARTED
import com.videoplayer.music.musicplayer.HOME_ARTIST_GRID_STYLE
import com.videoplayer.music.musicplayer.IMAGE_THEME
import com.videoplayer.music.musicplayer.INTENT_KEY
import com.videoplayer.music.musicplayer.KEEP_SCREEN_ON
import com.videoplayer.music.musicplayer.LANGUAGE_CODE
import com.videoplayer.music.musicplayer.LANGUAGE_KEY
import com.videoplayer.music.musicplayer.LANGUAGE_NAME
import com.videoplayer.music.musicplayer.LIBRARY_CATEGORIES
import com.videoplayer.music.musicplayer.MATERIAL_YOU
import com.videoplayer.music.musicplayer.PROFILE_IMAGE_PATH
import com.videoplayer.music.musicplayer.ROUND_CORNERS
import com.videoplayer.music.musicplayer.TAB_TEXT_MODE
import com.videoplayer.music.musicplayer.TOGGLE_ADD_CONTROLS
import com.videoplayer.music.musicplayer.TOGGLE_FULL_SCREEN
import com.videoplayer.music.musicplayer.TOGGLE_GENRE
import com.videoplayer.music.musicplayer.TOGGLE_HOME_BANNER
import com.videoplayer.music.musicplayer.TOGGLE_SEPARATE_LINE
import com.videoplayer.music.musicplayer.TOGGLE_VOLUME
import com.videoplayer.music.musicplayer.USER_NAME
import com.videoplayer.music.musicplayer.WALLPAPER_ACCENT
import com.videoplayer.music.musicplayer.extensions.makeStatusBarTransparent
import com.videoplayer.music.musicplayer.extensions.setDrawBehindSystemBars
import com.videoplayer.music.musicplayer.extensions.setImmersiveFullscreen
import com.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.videoplayer.music.musicplayer.util.PreferenceUtil

class LanguageActivity : BaseBindingActivity<ActivityLanguegeBinding>(),
    SharedPreferences.OnSharedPreferenceChangeListener {

    private var languageSting = ""
    private var intentValue = ""

    override fun setBinding(): ActivityLanguegeBinding {
        return ActivityLanguegeBinding.inflate(layoutInflater)
    }

    override fun getActivityContext(): FragmentActivity {
        return this@LanguageActivity
    }

    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
        if (key == MATERIAL_YOU || key == WALLPAPER_ACCENT || key == BLACK_THEME || key == ADAPTIVE_COLOR_APP || key == USER_NAME || key == TOGGLE_FULL_SCREEN || key == TOGGLE_VOLUME || key == ROUND_CORNERS || key == CAROUSEL_EFFECT || key == TOGGLE_GENRE || key == BANNER_IMAGE_PATH || key == PROFILE_IMAGE_PATH || key == CIRCULAR_ALBUM_ART || key == KEEP_SCREEN_ON || key == TOGGLE_SEPARATE_LINE || key == TOGGLE_HOME_BANNER || key == TOGGLE_ADD_CONTROLS || key == HOME_ARTIST_GRID_STYLE || key == ALBUM_COVER_TRANSFORM || key == DESATURATED_COLOR || key == EXTRA_SONG_INFO || key == TAB_TEXT_MODE || key == LANGUAGE_NAME || key == LIBRARY_CATEGORIES || key == CUSTOM_FONT || key == APPBAR_MODE || key == CIRCLE_PLAY_BUTTON) {
            postRecreate()
        }
    }

    override fun initView() {
        super.initView()
        PreferenceUtil.registerOnSharedPreferenceChangedListener(this)

        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        } else {
            setImmersiveFullscreen()
        }

        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext())
            .getString(IMAGE_THEME, "")

        makeStatusBarTransparent()

        if (editors == "theme_image") {
            val userImageTheme = RetroGlideExtension.getUserImageTheme(this@LanguageActivity)
            mBinding.mainBg.setImageDrawable(userImageTheme)
            mBinding.constraintLayout.background = null
        } else if (editors == "theme_gradient") {
            val userGradientTheme =
                AppCompatResources.getDrawable(this, RetroGlideExtension.getUserGradientTheme())
            mBinding.mainBg.setImageDrawable(userGradientTheme)
            mBinding.constraintLayout.background = null
        }

        setNative()
        init()
        clickEvents()
    }

    override fun onBackPressed() {
        if (LANGUAGE_KEY == intentValue) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        } else {
            finish()
        }
    }

    private fun clickEvents() {
        mBinding.backVector.setOnClickListener {
            onBackPressed()
        }
        mBinding.llEng.setOnClickListener {
            changeIcon(mBinding.ivEng, "en")
        }
        mBinding.llGerman.setOnClickListener {
            changeIcon(mBinding.ivGerman, "de")
        }
        mBinding.llSpanish.setOnClickListener {
            changeIcon(mBinding.ivSpanish, "es")
        }
        mBinding.llFilipino.setOnClickListener {
            changeIcon(mBinding.ivFilipino, "fil")
        }
        mBinding.llHindi.setOnClickListener {
            changeIcon(mBinding.ivHindi, "hi")
        }
        mBinding.llIndonesian.setOnClickListener {
            changeIcon(mBinding.ivIndonesian, "in")
        }
        mBinding.llItalian.setOnClickListener {
            changeIcon(mBinding.ivItalian, "it")
        }
        mBinding.llTurkish.setOnClickListener {
            changeIcon(mBinding.ivTurkish, "tr")
        }
        mBinding.llChinese.setOnClickListener {
            changeIcon(mBinding.ivChinese, "zh")
        }
        mBinding.llArabic.setOnClickListener {
            changeIcon(mBinding.ivArabic, "ar")
        }
        mBinding.llRussian.setOnClickListener {
            changeIcon(mBinding.ivRussian, "ru")
        }
        mBinding.llJapanese.setOnClickListener {
            changeIcon(mBinding.ivJapanese, "ja")
        }

        mBinding.doneVector.setOnClickListener {
            val editor = PreferenceManager.getDefaultSharedPreferences(App.getContext()).edit()
            editor.putString(LANGUAGE_CODE, languageSting)
            editor.apply()
            updateViews(languageSting)
            if (LANGUAGE_KEY == intentValue) {
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            } else {
                editor.putBoolean(GET_STARTED, true)
                editor.apply()
                startActivity(Intent(this, PermissionActivity::class.java))
                finish()
            }
        }
    }

    var mAdView: AdView? = null
    var isAdLoaded = false
    private fun setNative() {
        if (isOnline) {
//            NativeAdHelper(
//                this,
//                mBinding.frameLayout,
//                mBinding.frameLayout,
//                NativeLayoutType.NativeBig,
//                getString(R.string.native_language)
//            ) { isLoaded ->
//
//            }.loadAd();


            val adId = getString(R.string.bannerLanguage)
            BannerAdHelper.showBanner(
                this, mBinding.frameLayout, mBinding.frameLayout, adId,
                AdCache.bannerLanguage,
                { isLoaded, adView, message ->
                    mAdView = adView
                    AdCache.bannerLanguage = adView
                    isAdLoaded = isLoaded
                },
                AdSize.MEDIUM_RECTANGLE
//                AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, 360)
            )

        } else {
            mBinding.frameLayout.visibility = View.GONE
        }
    }


    private fun updateViews(languageCode: String) {
        setLocale(this, languageCode)
    }

    private fun init() {
        intentValue = intent.getStringExtra(INTENT_KEY).toString()
        if (intentValue == FIRST_KEY) {
            mBinding.backVector.visibility = View.GONE
        }

//        mBinding.ivRussian.setPadding(0, 0, 0, 20)
        val editor = PreferenceManager.getDefaultSharedPreferences(App.getContext())
        languageSting = editor.getString(LANGUAGE_CODE, "").toString()
        when (languageSting) {
            "en" -> {
                changeIcon(mBinding.ivEng, languageSting)
            }

            "de" -> {
                changeIcon(mBinding.ivGerman, languageSting)
            }

            "es" -> {
                changeIcon(mBinding.ivSpanish, languageSting)
            }

            "fil" -> {
                changeIcon(mBinding.ivFilipino, languageSting)
            }

            "hi" -> {
                changeIcon(mBinding.ivHindi, languageSting)
            }

            "in" -> {
                changeIcon(mBinding.ivIndonesian, languageSting)
            }

            "it" -> {
                changeIcon(mBinding.ivItalian, languageSting)
            }

            "tr" -> {
                changeIcon(mBinding.ivTurkish, languageSting)
            }

            "zh" -> {
                changeIcon(mBinding.ivChinese, languageSting)
            }

            "ar" -> {
                changeIcon(mBinding.ivArabic, languageSting)
            }

            "ru" -> {
                changeIcon(mBinding.ivRussian, languageSting)
            }

            "ja" -> {
                changeIcon(mBinding.ivJapanese, languageSting)
            }
        }
    }

    private fun changeIcon(selectImage: ImageView, selectValue: String) {

        mBinding.doneVector.visibility = View.VISIBLE
        val myAnim = AnimationUtils.loadAnimation(this, R.anim.bounce);
        val interpolator = MyBounceInterpolator(0.2, 20.0)
        myAnim.setInterpolator(interpolator)
        myAnim.repeatMode = Animation.RESTART
        mBinding.doneVector.startAnimation(myAnim)

        mBinding.ivEng.setImageResource(R.drawable.ic_un_check_radio)
        mBinding.ivSpanish.setImageResource(R.drawable.ic_un_check_radio)
        mBinding.ivGerman.setImageResource(R.drawable.ic_un_check_radio)
        mBinding.ivHindi.setImageResource(R.drawable.ic_un_check_radio)
        mBinding.ivFilipino.setImageResource(R.drawable.ic_un_check_radio)
        mBinding.ivChinese.setImageResource(R.drawable.ic_un_check_radio)
        mBinding.ivItalian.setImageResource(R.drawable.ic_un_check_radio)
        mBinding.ivTurkish.setImageResource(R.drawable.ic_un_check_radio)
        mBinding.ivIndonesian.setImageResource(R.drawable.ic_un_check_radio)
        mBinding.ivRussian.setImageResource(R.drawable.ic_un_check_radio)
        mBinding.ivArabic.setImageResource(R.drawable.ic_un_check_radio)
        mBinding.ivJapanese.setImageResource(R.drawable.ic_un_check_radio)
        selectImage.setImageResource(R.drawable.ic_check_radio)
        languageSting = selectValue
    }

    override fun attachBaseContext(base: Context?) {
        super.attachBaseContext(onAttach(base!!, "en"))
    }

}