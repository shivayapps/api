package com.videoplayer.music.musicplayer.activities

import android.content.Intent
import android.view.View
import androidx.appcompat.content.res.AppCompatResources
import androidx.fragment.app.FragmentActivity
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.adconfig.adsutil.admob.BannerAdHelper
import com.afollestad.materialcab.attached.AttachedCab
import com.afollestad.materialcab.attached.destroy
import com.afollestad.materialcab.attached.isActive
import com.afollestad.materialcab.createCab
import com.google.android.gms.ads.AdView
import com.mediaplayer.video.player.videoplayer.music.R

import com.videoplayer.music.common.base.BaseBindingActivity
import com.videoplayer.music.common.utils.isOnline
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityDetailListBinding
import com.videoplayer.music.common.utils.AdCache
import com.videoplayer.music.musicplayer.App
import com.videoplayer.music.musicplayer.EXTRA_ALBUM_ID
import com.videoplayer.music.musicplayer.EXTRA_ARTIST_ID
import com.videoplayer.music.musicplayer.EXTRA_PLAYLIST_TYPE
import com.videoplayer.music.musicplayer.FAVOURITES
import com.videoplayer.music.musicplayer.GENERAL_THEME
import com.videoplayer.music.musicplayer.HISTORY_PLAYLIST
import com.videoplayer.music.musicplayer.IMAGE_THEME
import com.videoplayer.music.musicplayer.LAST_ADDED_PLAYLIST
import com.videoplayer.music.musicplayer.RECENT_ALBUMS
import com.videoplayer.music.musicplayer.RECENT_ARTISTS
import com.videoplayer.music.musicplayer.STATUS_COLOR
import com.videoplayer.music.musicplayer.TOP_ALBUMS
import com.videoplayer.music.musicplayer.TOP_ARTISTS
import com.videoplayer.music.musicplayer.TOP_PLAYED_PLAYLIST
import com.videoplayer.music.musicplayer.adapter.album.AlbumAdapter
import com.videoplayer.music.musicplayer.adapter.artist.ArtistAdapter
import com.videoplayer.music.musicplayer.adapter.song.ShuffleButtonSongAdapter
import com.videoplayer.music.musicplayer.adapter.song.SongAdapter
import com.videoplayer.music.musicplayer.db.toSong
import com.videoplayer.music.musicplayer.extensions.makeStatusBarTransparent
import com.videoplayer.music.musicplayer.extensions.resolveColor
import com.videoplayer.music.musicplayer.extensions.setDrawBehindSystemBars
import com.videoplayer.music.musicplayer.extensions.setImmersiveFullscreen
import com.videoplayer.music.musicplayer.extensions.surfaceColor
import com.videoplayer.music.musicplayer.fragments.LibraryViewModel
import com.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.videoplayer.music.musicplayer.interfaces.IAlbumClickListener
import com.videoplayer.music.musicplayer.interfaces.IArtistClickListener
import com.videoplayer.music.musicplayer.interfaces.ICabCallback
import com.videoplayer.music.musicplayer.interfaces.ICabHolder
import com.videoplayer.music.musicplayer.model.Album
import com.videoplayer.music.musicplayer.model.Artist
import com.videoplayer.music.musicplayer.repository.RealRepository
import com.videoplayer.music.musicplayer.util.PreferenceUtil
import org.jetbrains.anko.backgroundColor


class DetailListActivity : BaseBindingActivity<ActivityDetailListBinding>(), IArtistClickListener,
    IAlbumClickListener,
    ICabHolder {

    private val getRepository: RealRepository get() = repository
    lateinit var libraryViewModel: LibraryViewModel
    override fun initView() {
        super.initView()

        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        } else {
            setImmersiveFullscreen()
        }
        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            IMAGE_THEME, ""
        )
//        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
//            GENERAL_THEME,"")
        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getInt(
            GENERAL_THEME, 0
        )

        val statusColor = PreferenceManager.getDefaultSharedPreferences(App.getContext())
            .getInt(STATUS_COLOR, -1)
        makeStatusBarTransparent()
        if (editors == "theme_image") {
//            mBinding.root.background = ContextCompat.getDrawable(mActivity,R.drawable.img_theme_one)
            mBinding.root.background =
                RetroGlideExtension.getUserImageTheme(this@DetailListActivity)
            mBinding.constraintLayout.background = null
        } else if (editors == "theme_gradient") {
//            mBinding.root.background = ContextCompat.getDrawable(mActivity,R.drawable.img_theme_two)
            mBinding.root.background =
                AppCompatResources.getDrawable(this, RetroGlideExtension.getUserGradientTheme())
            mBinding.constraintLayout.background = null
        }
//        else if (edit == "ligt" || edit == "dark"){
        else if (edit >= 0) {
            mBinding.root.background = null
            mBinding.root.backgroundColor = resolveColor(R.attr.mainBackgroundColor)
        }

        val id = intent.getIntExtra(EXTRA_PLAYLIST_TYPE, 0)

        mBinding.progressIndicator.hide()

        libraryViewModel = LibraryViewModel(getRepository)

        when (id) {
            TOP_ARTISTS -> loadArtists(R.string.top_artists, TOP_ARTISTS)
            RECENT_ARTISTS -> loadArtists(R.string.recent_artists, RECENT_ARTISTS)
            TOP_ALBUMS -> loadAlbums(R.string.top_albums, TOP_ALBUMS)
            RECENT_ALBUMS -> loadAlbums(R.string.recent_albums, RECENT_ALBUMS)
            FAVOURITES -> loadFavorite()
            HISTORY_PLAYLIST -> loadHistory()
            LAST_ADDED_PLAYLIST -> lastAddedSongs()
            TOP_PLAYED_PLAYLIST -> topPlayed()
        }

        mBinding.ivBack.setOnClickListener(object : com.videoplayer.music.common.widgets.OnSingleClickListener() {
            override fun onSingleClick(v: View?) {
                onBackPressed()
            }

        })
        setNative()
    }

    var mAdView: AdView?=null
    var isAdLoaded = false
    private fun setNative() {
        if (isOnline) {

            val adId = getString(R.string.admob_banner)
            BannerAdHelper.showBanner(this, mBinding.frameLayout,  adId,
                AdCache.bannerAdView,
                { isLoaded,adView, message ->
                    mAdView=adView
                    AdCache.bannerAdView=adView
                    isAdLoaded = isLoaded
                })

        } else {
            mBinding.frameLayout.visibility = View.GONE
        }
    }

    override fun initAds() {
        super.initAds()
    }

    override fun getActivityContext(): FragmentActivity {
        return this@DetailListActivity
    }

    private fun artistAdapter(artists: List<Artist>): ArtistAdapter = ArtistAdapter(
        this@DetailListActivity,
        artists,
        R.layout.item_grid_circle,
        this, this@DetailListActivity
    )

    private fun albumAdapter(albums: List<Album>): AlbumAdapter = AlbumAdapter(
        this@DetailListActivity,
        albums,
        R.layout.item_grid,
        this, this@DetailListActivity
    )

    private fun loadArtists(title: Int, type: Int) {
        mBinding.tvFmName.text = getString(title)
        val artistAdapter = artistAdapter(listOf())
        mBinding.recyclerView.apply {
            adapter = artistAdapter
            layoutManager = gridLayoutManager()
        }
        libraryViewModel.artists(type).observe(this@DetailListActivity) { artists ->
            artistAdapter.swapDataSet(artists)
        }
    }

    private fun loadAlbums(title: Int, type: Int) {
        mBinding.tvFmName.text = getString(title)
        val albumAdapter = albumAdapter(listOf())
        mBinding.recyclerView.apply {
            adapter = albumAdapter
            layoutManager = gridLayoutManager()
        }
        libraryViewModel.albums(type).observe(this@DetailListActivity) { albums ->
            albumAdapter.swapDataSet(albums)
        }
    }

    private fun loadHistory() {

        mBinding.tvFmName.text = getString(R.string.history)
        val songAdapter = ShuffleButtonSongAdapter(
            this@DetailListActivity,
            mutableListOf(),
            R.layout.item_list, this
        )
        mBinding.recyclerView.apply {
            adapter = songAdapter
            layoutManager = linearLayoutManager()
        }
        libraryViewModel.observableHistorySongs().observe(this@DetailListActivity) {
            if (it.isEmpty()) {
                mBinding.empty.visibility = View.VISIBLE
            } else {
                mBinding.empty.visibility = View.GONE
                songAdapter.swapDataSet(it)
            }
        }
    }

    private fun lastAddedSongs() {
        mBinding.tvFmName.text = getString(R.string.last_added)
        val songAdapter = ShuffleButtonSongAdapter(
            this@DetailListActivity,
            mutableListOf(),
            R.layout.item_list, this
        )
        mBinding.recyclerView.apply {
            adapter = songAdapter
            layoutManager = linearLayoutManager()
            scheduleLayoutAnimation()
        }
        libraryViewModel.recentSongs().observe(this@DetailListActivity) { songs ->
            if (songs.isEmpty()) {
                mBinding.empty.visibility = View.VISIBLE
            } else {
                mBinding.empty.visibility = View.GONE
                songAdapter.swapDataSet(songs)
            }
        }
    }

    private fun topPlayed() {
        mBinding.tvFmName.text = getString(R.string.my_top_tracks)
        val songAdapter = ShuffleButtonSongAdapter(
            this@DetailListActivity,
            mutableListOf(),
            R.layout.item_list, this
        )
        mBinding.recyclerView.apply {
            adapter = songAdapter
            layoutManager = linearLayoutManager()
        }
        libraryViewModel.playCountSongs().observe(this@DetailListActivity) { songs ->
            if (songs.isEmpty()) {
                mBinding.empty.visibility = View.VISIBLE
            } else {
                mBinding.empty.visibility = View.GONE
                songAdapter.swapDataSet(songs)
            }
        }
    }

    private fun loadFavorite() {
        mBinding.tvFmName.text = getString(R.string.favorites)
        val songAdapter = SongAdapter(
            this@DetailListActivity,
            mutableListOf(),
            R.layout.item_list, this
        )
        mBinding.recyclerView.apply {
            adapter = songAdapter
            layoutManager = linearLayoutManager()
        }
        libraryViewModel.favorites().observe(this@DetailListActivity) { songEntities ->
            val songs = songEntities.map { songEntity -> songEntity.toSong() }
            songAdapter.swapDataSet(songs)
        }
    }


    private fun linearLayoutManager(): LinearLayoutManager =
        LinearLayoutManager(this@DetailListActivity, LinearLayoutManager.VERTICAL, false)

    private fun gridLayoutManager(): GridLayoutManager =
        GridLayoutManager(this@DetailListActivity, gridCount(), GridLayoutManager.VERTICAL, false)

    private fun gridCount(): Int {
        if (com.videoplayer.music.musicplayer.util.RetroUtil.isTablet()) {
            return if (com.videoplayer.music.musicplayer.util.RetroUtil.isLandscape()) 6 else 4
        }
        return if (com.videoplayer.music.musicplayer.util.RetroUtil.isLandscape()) 4 else 2
    }

    override fun onAlbumClick(albumId: Long, view: View) {
        val intent = Intent(
            this@DetailListActivity,
            com.videoplayer.music.musicplayer.activities.AlbumDetalitActivity::class.java
        )
        intent.putExtra(EXTRA_ALBUM_ID, albumId)
        launchActivity(intent)

    }

    override fun onArtist(artistId: Long, view: View) {
        val intent = Intent(this@DetailListActivity, ArtistDetailActivity::class.java)
        intent.putExtra(EXTRA_ARTIST_ID, artistId)
        launchActivity(intent)
    }

    private var cab: AttachedCab? = null
    override fun openCab(menuRes: Int, callback: ICabCallback): AttachedCab {
        cab?.let {
            println("Cab")
            if (it.isActive()) {
                it.destroy()
            }
        }
        cab = createCab(R.id.toolbar_container) {
            menu(menuRes)
            closeDrawable(R.drawable.ic_close)
            backgroundColor(literal = com.videoplayer.music.musicplayer.util.RetroColorUtil.shiftBackgroundColor(surfaceColor()))
            slideDown()
            onCreate { cab, menu -> callback.onCabCreated(cab, menu) }
            onSelection {
                callback.onCabItemClicked(it)
            }
            onDestroy { callback.onCabFinished(it) }
        }
        return cab as AttachedCab
    }


    override fun setBinding(): ActivityDetailListBinding {
        return ActivityDetailListBinding.inflate(layoutInflater)
    }
}