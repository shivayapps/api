package com.videoplayer.music.musicplayer.glide

import android.graphics.drawable.Drawable
import android.widget.ImageView
import com.videoplayer.music.appthemehelper.util.ATHUtil
import com.bumptech.glide.request.transition.Transition
import com.mediaplayer.video.player.videoplayer.music.R

abstract class SingleColorTarget(view: ImageView) : com.videoplayer.music.musicplayer.glide.palette.BitmapPaletteTarget(view) {

    private val defaultFooterColor: Int
        get() = ATHUtil.resolveColor(view.context, androidx.appcompat.R.attr.colorControlNormal)

    abstract fun onColorReady(color: Int)

    override fun onLoadFailed(errorDrawable: Drawable?) {
        super.onLoadFailed(errorDrawable)
        onColorReady(defaultFooterColor)
    }

    override fun onResourceReady(
        resource: com.videoplayer.music.musicplayer.glide.palette.BitmapPaletteWrapper,
        transition: Transition<in com.videoplayer.music.musicplayer.glide.palette.BitmapPaletteWrapper>?
    ) {
        super.onResourceReady(resource, transition)
        onColorReady(
            com.videoplayer.music.musicplayer.util.ColorUtil.getColor(
                resource.palette,
                ATHUtil.resolveColor(view.context, R.attr.colorPrimary)
            )
        )
    }
}
