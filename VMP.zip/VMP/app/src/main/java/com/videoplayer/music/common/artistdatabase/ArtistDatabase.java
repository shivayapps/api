package com.videoplayer.music.common.artistdatabase;


import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {Artist.class}, exportSchema = false, version = 2)
public abstract class ArtistDatabase extends RoomDatabase {
    private static final String DB_NAME = "artist_db";
    private static ArtistDatabase Instance;

    public static synchronized ArtistDatabase getInstance(Context context) {
        if (Instance == null) {
            Instance = Room.databaseBuilder(context.getApplicationContext(), ArtistDatabase.class, DB_NAME)
                    .fallbackToDestructiveMigration()
                    .allowMainThreadQueries()
                    .createFromAsset("music_artist.db")
                    .build();
        }
        return Instance;
    }

    public abstract ArtistDao artistDao();
}
