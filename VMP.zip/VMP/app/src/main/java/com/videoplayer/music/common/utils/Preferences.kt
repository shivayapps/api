package com.videoplayer.music.common.utils

import android.content.Context
import android.content.SharedPreferences
import android.os.Environment
import android.text.format.DateFormat
import android.util.Log
import androidx.core.content.ContextCompat
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat
import java.util.Date
import java.util.LinkedList
import java.util.Locale


class Preferences(var context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("PREF_NAME", Context.MODE_PRIVATE)
    private val editor: SharedPreferences.Editor = prefs.edit()

    fun saveObjectList(objectList: ArrayList<Any>) {
        Log.e("Preferences", "saveObjectList.size:${objectList.size}")
        val editor: SharedPreferences.Editor = prefs.edit()
        val gson = Gson()
        val json = gson.toJson(objectList)

        Log.e("Preferences", "saveObjectList.json:${json}")
        editor.putString("media_list", json)
        editor.apply()
    }

    fun getObjectList(): ArrayList<Any> {
        val gson = Gson()
        val json: String = prefs.getString("media_list", "") ?: ""
        Log.e("Preferences", "getObjectList.json:${json}")
        val type: Type = object : TypeToken<ArrayList<Any>>() {}.type
        val objectList: ArrayList<Any> = gson.fromJson(json, type)
        Log.e("Preferences", "getObjectList.size:${objectList.size}")
        return objectList
    }

    var isFirstTimeInstall: Boolean
        get() = prefs.getBoolean("isFirstTimeInstall", true)
        set(value) = prefs.edit().putBoolean("isFirstTimeInstall", value).apply()

    //    var isEnableAds: Boolean
//        get() = prefs.getBoolean("isEnableAds", true)
//        set(value) = prefs.edit().putBoolean("isEnableAds", value).apply()
//    var isEnableOpenAds: Boolean
//        get() = prefs.getBoolean("isEnableOpenAds", true)
//        set(value) = prefs.edit().putBoolean("isEnableOpenAds", value).apply()
    var isRatingDone: Boolean
        get() = prefs.getBoolean("isRatingDone", false)
        set(isRatingDone) = prefs.edit().putBoolean("isRatingDone", isRatingDone).apply()
    var isNeedInterAd: Boolean
        get() = prefs.getBoolean("isNeedInterAd", true)
        set(isNeedInterAd) = prefs.edit().putBoolean("isNeedInterAd", isNeedInterAd).apply()
    var isNeedCleaner: Boolean
        get() = prefs.getBoolean("isNeedCleaner", true)
        set(isNeedCleaner) = prefs.edit().putBoolean("isNeedCleaner", isNeedCleaner).apply()
    var strCleanCount: String
        get() = prefs.getString("strCleanCount", "") ?: ""
        set(strCleanCount) = prefs.edit().putString("strCleanCount", strCleanCount).apply()

    var refreshMedia: Boolean
        get() = prefs.getBoolean("addedNewMedia", false)
        set(addedNewMedia) = prefs.edit().putBoolean("addedNewMedia", addedNewMedia).apply()
    var scanMedia: Boolean
        get() = prefs.getBoolean("scanMedia", false)
        set(allowVideoGestures) = prefs.edit().putBoolean("scanMedia", allowVideoGestures).apply()
    var deleteAfter30Days: Boolean
        get() = prefs.getBoolean("deleteAfter30Days", false)
        set(deleteAfter30Days) = prefs.edit().putBoolean("deleteAfter30Days", deleteAfter30Days).apply()


//    fun addFolderProtection(path: String) { prefs.edit().putBoolean("isProtected$path", true).apply() }
//    fun removeFolderProtection(path: String) { prefs.edit().remove("isProtected$path").apply() }

//    fun isFolderProtected(path: String) =prefs.getBoolean("isProtected$path", false)

//    var openVideosOnSeparateScreen: Boolean
//        get() = prefs.getBoolean(Constant.OPEN_VIDEOS_ON_SEPARATE_SCREEN, false)
//        set(openVideosOnSeparateScreen) = prefs.edit().putBoolean(Constant.OPEN_VIDEOS_ON_SEPARATE_SCREEN, openVideosOnSeparateScreen).apply()

//    var bottomActions: Boolean
//        get() = prefs.getBoolean(Constant.BOTTOM_ACTIONS, true)
//        set(bottomActions) = prefs.edit().putBoolean(Constant.BOTTOM_ACTIONS, bottomActions).apply()

    var use24HourFormat: Boolean
        get() = prefs.getBoolean("USE_24_HOUR_FORMAT", DateFormat.is24HourFormat(context))
        set(use24HourFormat) = prefs.edit().putBoolean("USE_24_HOUR_FORMAT", use24HourFormat).apply()

    var enableFingerprint: Boolean
        get() = prefs.getBoolean("USE_FINGERPRINT", false)
        set(enableFingerprint) = prefs.edit().putBoolean("USE_FINGERPRINT", enableFingerprint).apply()
    var hideSystemUI: Boolean
        get() = prefs.getBoolean("HIDE_SYSTEM_UI", false)
        set(hideSystemUI) = prefs.edit().putBoolean("HIDE_SYSTEM_UI", hideSystemUI).apply()

    var hideVault: Boolean
        get() = prefs.getBoolean("VAULT_VISIBILITY", false)
        set(hideVault) = prefs.edit().putBoolean("VAULT_VISIBILITY", hideVault).apply()
    var hintExclude: Boolean
        get() = prefs.getBoolean("hintExclude", false)
        set(hideVault) = prefs.edit().putBoolean("hintExclude", hideVault).apply()
    var hintRecycle: Boolean
        get() = prefs.getBoolean("hintRecycle", false)
        set(hideVault) = prefs.edit().putBoolean("hintRecycle", hideVault).apply()

    var hideCamera: Boolean
        get() = prefs.getBoolean("CAMERA_VISIBILITY", false)
        set(hideVault) = prefs.edit().putBoolean("CAMERA_VISIBILITY", hideVault).apply()

    var maxBrightness: Boolean
        get() = prefs.getBoolean("MAX_BRIGHTNESS", false)
        set(maxBrightness) = prefs.edit().putBoolean("MAX_BRIGHTNESS", maxBrightness).apply()

    var keepLastModified: Boolean
        get() = prefs.getBoolean("KEEP_LAST_MODIFIED", true)
        set(keepLastModified) = prefs.edit().putBoolean("KEEP_LAST_MODIFIED", keepLastModified).apply()

    var passwordRetryCount: Int
        get() = prefs.getInt("PASSWORD_RETRY_COUNT", 0)
        set(passwordRetryCount) = prefs.edit().putInt("PASSWORD_RETRY_COUNT", passwordRetryCount).apply()


    var passwordCountdownStartMs: Long
        get() = prefs.getLong("PASSWORD_COUNTDOWN_START_MS", 0L)
        set(passwordCountdownStartMs) = prefs.edit().putLong("PASSWORD_COUNTDOWN_START_MS", passwordCountdownStartMs).apply()
    var showNotch: Boolean
        get() = prefs.getBoolean("SHOW_NOTCH", true)
        set(showNotch) = prefs.edit().putBoolean("SHOW_NOTCH", showNotch).apply()

    var hintEditShown: Boolean
        get() = prefs.getBoolean("hintEditShown", false)
        set(value) = prefs.edit().putBoolean("hintEditShown", value).apply()
    var isConfirmEditAction: Boolean
        get() = prefs.getBoolean("isConfirmEditAction", false)
        set(value) = prefs.edit().putBoolean("isConfirmEditAction", value).apply()

    var appOpenCounter: Int
        get() = prefs.getInt("appOpenCounter", 0)
        set(value) = prefs.edit().putInt("appOpenCounter", value).apply()
    var appPermissionCount: Int
        get() = prefs.getInt("appPermissionCount", 0)
        set(value) = prefs.edit().putInt("appPermissionCount", value).apply()

    var isFirstSession: Boolean
        get() = prefs.getBoolean("isFirstSession", true)
        set(value) = prefs.edit().putBoolean("isFirstSession", value).apply()

    var sessionCounter: Int
        get() = prefs.getInt("sessionCounter", 0)
        set(splashCounter) = prefs.edit().putInt("sessionCounter", splashCounter).apply()

    var splashCounter: Int
        get() = prefs.getInt("splashCounter", 0)
        set(splashCounter) = prefs.edit().putInt("splashCounter", splashCounter).apply()

    var updateCancelCounter: Int
        get() = prefs.getInt("updateCancelCounter", 0)
        set(value) = prefs.edit().putInt("updateCancelCounter", value).apply()

    fun setSelectLanguage(result: Int) {
        editor.putInt("PREF_KEY_LANGUAGE", result)
        editor.apply()
    }

    fun getSelectLanguage(): Int {
        return prefs.getInt("PREF_KEY_LANGUAGE", -1)
    }

    fun removeLangPos() {
        editor.remove("PREF_KEY_LANGUAGE")
        editor.apply()
    }

    fun setSelectLanguageCode(result: String) {
        editor.putString("KEY_LANGUAGE", result)
        editor.apply()
    }

    fun getSelectLanguageCode(): String {
        return prefs.getString("KEY_LANGUAGE", "0") ?: "0"
    }

    var systemLocalLanguage: String
        get() = prefs.getString("systemLocalLanguage", "0") ?: "0"
        set(value) = prefs.edit().putString("systemLocalLanguage", value).apply()

    var splashDelay: Long
        get() = prefs.getLong("splash_delay", 8000) ?: 8000
        set(value) = prefs.edit().putLong("splash_delay", value).apply()
    var nativeDelay: Long
        get() = prefs.getLong("native_delay", 1500) ?: 1500
        set(value) = prefs.edit().putLong("native_delay", value).apply()

    fun setInt(key: String, result: Int) {
        editor.putInt(key, result)
        editor.apply()
    }

    fun getInt(key: String, default: Int? = 0): Int {
        return prefs.getInt(key, default!!)
    }

    fun setString(key: String, result: String) {
        editor.putString(key, result)
        editor.apply()
    }

    fun getString(key: String, default: String? = ""): String {
        return prefs.getString(key, default!!) ?: ""
    }

    fun setBoolean(key: String, result: Boolean) {
        editor.putBoolean(key, result)
        editor.apply()
    }

    fun getBoolean(key: String, default: Boolean? = false): Boolean {
        return prefs.getBoolean(key, default!!)
    }


    fun logOnceDailyWithInterval(result: (logged: Boolean, daysInterval: Int) -> Unit) {
        try {
            val lastLoggedDate = prefs.getString("last_logged_date", null)
            val currentDate = getCurrentDate()

            val intervalDays = if (lastLoggedDate != null) {
                getDaysBetweenDates(lastLoggedDate, currentDate)
            } else {
                -1 // If there is no previous log, return -1 for interval
            }

            if (lastLoggedDate == null || lastLoggedDate != currentDate) {
                prefs.edit().putString("last_logged_date", currentDate).apply()
                result(true, intervalDays) // Log successful
            } else {
                result(false, intervalDays) // No log today, just return the interval
            }
        } catch (e: Exception) {
            result(false, -1)
        }
    }

    private fun getDaysBetweenDates(date1: String, date2: String): Int {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return try {
            val parsedDate1 = dateFormat.parse(date1)
            val parsedDate2 = dateFormat.parse(date2)
            val diffInMillis = kotlin.math.abs(parsedDate2.time - parsedDate1.time)
            val elapsedDays = (diffInMillis / (1000 * 60 * 60 * 24)).toInt()
            elapsedDays
        } catch (e: Exception) {
            -1
        }
    }

    private fun getCurrentDate(): String {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return dateFormat.format(Date())
    }

}