package com.videoplayer.music.appthemehelper.common.prefs.supportv7

import android.content.Context
import android.util.AttributeSet
import androidx.preference.CheckBoxPreference
import com.mediaplayer.video.player.videoplayer.music.R

/**
 * @author Sujal Lathiya
 */
class ATESwitchPreference @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = -1,
    defStyleRes: Int = -1
) :
    CheckBoxPreference(context, attrs, defStyleAttr, defStyleRes) {

    init {
        widgetLayoutResource = R.layout.ate_preference_switch_support
//        icon?.colorFilter = BlendModeColorFilterCompat.createBlendModeColorFilterCompat(
//            ATHUtil.resolveColor(
//                context,
//                android.androidx.appcompat.R.attr.colorControlNormal
//            ), BlendModeCompat.SRC_IN
//        )
    }

}