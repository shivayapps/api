package com.videoplayer.music.musicplayer.activities

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.appcompat.content.res.AppCompatResources
import androidx.navigation.NavController
import androidx.navigation.NavDestination
import androidx.preference.PreferenceManager
import com.videoplayer.music.appthemehelper.ThemeStore
import com.videoplayer.music.appthemehelper.util.VersionUtils
import com.adconfig.AdsConfig
import com.adconfig.adsutil.AdsParameters
import com.adconfig.adsutil.Config.checkReInter
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.BannerAdHelper
import com.afollestad.materialdialogs.MaterialDialog
import com.afollestad.materialdialogs.color.ColorCallback
import com.google.android.gms.ads.AdView
import com.mediaplayer.video.player.videoplayer.music.R

import com.videoplayer.music.common.utils.isOnline
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivitySettingsBinding
import com.videoplayer.music.common.utils.AdCache
import com.videoplayer.music.musicplayer.App
import com.videoplayer.music.musicplayer.GENERAL_THEME
import com.videoplayer.music.musicplayer.IMAGE_THEME
import com.videoplayer.music.musicplayer.activities.base.AbsThemeActivity
import com.videoplayer.music.musicplayer.appshortcuts.DynamicShortcutManager
import com.videoplayer.music.musicplayer.extensions.extra
import com.videoplayer.music.musicplayer.extensions.findNavController
import com.videoplayer.music.musicplayer.extensions.makeStatusBarTransparent
import com.videoplayer.music.musicplayer.extensions.resolveColor
import com.videoplayer.music.musicplayer.extensions.setDrawBehindSystemBars
import com.videoplayer.music.musicplayer.extensions.setImmersiveFullscreen
import com.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.videoplayer.music.musicplayer.util.PreferenceUtil
import com.videoplayer.music.common.utils.backgroundColor

class SettingsActivity : AbsThemeActivity(), ColorCallback, OnThemeChangedListener {
    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        val mSavedInstanceState = extra<Bundle>(TAG).value ?: savedInstanceState
        super.onCreate(mSavedInstanceState)

        binding = ActivitySettingsBinding.inflate(layoutInflater)

        setContentView(binding.root)

        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        } else {
            setImmersiveFullscreen()
        }

        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            IMAGE_THEME, ""
        )

        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getInt(
            GENERAL_THEME, 0
        )

        makeStatusBarTransparent()

        if (editors == "theme_image") {
            binding.root.background = RetroGlideExtension.getUserImageTheme(this@SettingsActivity)
            binding.constraintLayout.background = null
        } else if (editors == "theme_gradient") {
            binding.root.background =
                AppCompatResources.getDrawable(this, RetroGlideExtension.getUserGradientTheme())
            binding.constraintLayout.background = null
        } else if (edit >= 0) {
            binding.root.background = null
            binding.root.backgroundColor = resolveColor(R.attr.mainBackgroundColor)
        }

        setupToolbar()

        binding.ivBack.setOnClickListener {
            onBackPressed()
        }
        setNative()
    }


    private val clickInterval: Long = 60 * 1000 // 40 second in milliseconds
    private var lastClickTime: Long = 0

    private fun clickEventAtMinute() {

        if (adsPreferences.isNeedInterAd) {
            AdsConfig.showInterstitialAd(this) {
                if(it) adsPreferences.isNeedInterAd = false
                finish()
            }
        } else {
            super.onBackPressed()
        }
    }


    lateinit var adsPreferences: AdsParameters

    var mAdView: AdView?=null
    var isAdLoaded = false

    private fun setNative() {
        adsPreferences = AdsParameters(this)
        val adId = getString(R.string.ads_inter)
        if (adsPreferences.isNeedInterAd) {
            AdmobIntersAdImpl().load(this, adId)
        } else {
            checkReInter {
                if (it) {
                    AdmobIntersAdImpl().load(this, adId)
                    adsPreferences.isNeedInterAd = true
                }
            }
        }
        if (isOnline) {

//            val adId = getString(R.string.bannerSetting)
//            BannerAdHelper.showBanner(this, binding.frameLayout,binding.frameLayout,  adId,
//                AdCache.bannerSetting,
//                { isLoaded,adView, message ->
//                    mAdView=adView
//                    AdCache.bannerSetting=adView
//                    isAdLoaded = isLoaded
//                })

        } else {
            binding.frameLayout.visibility = View.GONE
        }
    }

    override fun onBackPressed() {
        clickEventAtMinute()
    }

    fun onBack() {
        if (findNavController(R.id.contentFrame).navigateUp() || super.onSupportNavigateUp()) {
            findNavController(R.id.contentFrame).navigateUp() || super.onSupportNavigateUp()
        } else {
            super.onBackPressed()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
    }

    private fun setupToolbar() {
        val navController: NavController = findNavController(R.id.contentFrame)
        navController.addOnDestinationChangedListener { _, _, _ ->
            binding.tvFolderName.text =
                navController.currentDestination?.let { getStringFromDestination(it) }
        }
    }

    private fun getStringFromDestination(currentDestination: NavDestination): String {
        val idRes = when (currentDestination.id) {
            R.id.mainSettingsFragment -> R.string.action_settings
            R.id.audioSettings -> R.string.pref_header_audio
            R.id.imageSettingFragment -> R.string.pref_header_images
            R.id.notificationSettingsFragment -> R.string.notification
            R.id.nowPlayingSettingsFragment -> R.string.now_playing
            R.id.otherSettingsFragment -> R.string.others
            R.id.personalizeSettingsFragment -> R.string.personalize
            R.id.themeSettingsFragment -> R.string.general_settings_title
            else -> R.id.action_settings
        }
        return getString(idRes)
    }

    override fun onSupportNavigateUp(): Boolean {
        return findNavController(R.id.contentFrame).navigateUp() || super.onSupportNavigateUp()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressedDispatcher.onBackPressed()
        }
        return super.onOptionsItemSelected(item)
    }

    override fun invoke(dialog: MaterialDialog, color: Int) {
        ThemeStore.editTheme(this).accentColor(color).commit()
        if (VersionUtils.hasNougatMR())
            DynamicShortcutManager(this).updateDynamicShortcuts()
        restart()
    }

    override fun onThemeValuesChanged() {
        restart()
    }

    private fun restart() {
        val savedInstanceState = Bundle().apply {
            onSaveInstanceState(this)
        }
        finish()
        val intent = Intent(this, this::class.java).putExtra(TAG, savedInstanceState)
        startActivity(intent)
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    companion object {
        val TAG: String = SettingsActivity::class.java.simpleName
    }
}

interface OnThemeChangedListener {
    fun onThemeValuesChanged()
}
