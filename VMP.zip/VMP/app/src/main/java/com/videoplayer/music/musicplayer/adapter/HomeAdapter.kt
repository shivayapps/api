package com.videoplayer.music.musicplayer.adapter

import android.annotation.SuppressLint
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.annotation.AnimRes
import androidx.annotation.AnimatorRes
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatTextView
import androidx.core.os.bundleOf
import androidx.navigation.findNavController
import androidx.navigation.fragment.FragmentNavigatorExtras
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mediaplayer.video.player.videoplayer.music.R
import com.videoplayer.music.musicplayer.EXTRA_ALBUM_ID
import com.videoplayer.music.musicplayer.EXTRA_ARTIST_ID
import com.videoplayer.music.musicplayer.EXTRA_GENRE
import com.videoplayer.music.musicplayer.EXTRA_PLAYLIST_TYPE
import com.videoplayer.music.musicplayer.FAVOURITES
import com.videoplayer.music.musicplayer.RECENT_ALBUMS
import com.videoplayer.music.musicplayer.RECENT_ARTISTS
import com.videoplayer.music.musicplayer.TOP_ALBUMS
import com.videoplayer.music.musicplayer.TOP_ARTISTS
import com.videoplayer.music.musicplayer.activities.ArtistDetailActivity
import com.videoplayer.music.musicplayer.activities.DetailListActivity
import com.videoplayer.music.musicplayer.adapter.album.AlbumAdapter
import com.videoplayer.music.musicplayer.adapter.artist.ArtistAdapter
import com.videoplayer.music.musicplayer.adapter.song.SongAdapter
import com.videoplayer.music.musicplayer.interfaces.IAlbumClickListener
import com.videoplayer.music.musicplayer.interfaces.IArtistClickListener
import com.videoplayer.music.musicplayer.interfaces.IGenreClickListener
import com.videoplayer.music.musicplayer.model.Album
import com.videoplayer.music.musicplayer.model.Artist
import com.videoplayer.music.musicplayer.model.Genre
import com.videoplayer.music.musicplayer.model.Home
import com.videoplayer.music.musicplayer.model.Song
import com.videoplayer.music.musicplayer.util.PreferenceUtil

class HomeAdapter(
    private val activity: AppCompatActivity
) : RecyclerView.Adapter<RecyclerView.ViewHolder>(), IArtistClickListener, IAlbumClickListener,
    IGenreClickListener {

    private var list = listOf<Home>()

    override fun getItemViewType(position: Int): Int {
        return list[position].homeSection
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val layout =
            LayoutInflater.from(activity).inflate(R.layout.section_recycler_view, parent, false)
        return when (viewType) {
            RECENT_ARTISTS, TOP_ARTISTS -> ArtistViewHolder(layout)
            FAVOURITES -> PlaylistViewHolder(layout)
            TOP_ALBUMS, RECENT_ALBUMS -> AlbumViewHolder(layout)
            else -> {
                ArtistViewHolder(layout)
            }
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val home = list[position]
        when (getItemViewType(position)) {
            RECENT_ALBUMS -> {
                val viewHolder = holder as AlbumViewHolder
                viewHolder.bindView(home)
                viewHolder.clickableArea.setOnClickListener {
//                    it.findFragment<HomeFragment>().setSharedAxisXTransitions()
//                    activity.findNavController(R.id.fragment_container).navigate(
//                        R.id.detailListFragment,
//                        bundleOf("type" to RECENT_ALBUMS)
//                    )

                    val intent = Intent(activity, DetailListActivity::class.java)
                    intent.putExtra(EXTRA_PLAYLIST_TYPE, RECENT_ALBUMS)
                    launchActivity(intent)

                }
            }

            TOP_ALBUMS -> {
                val viewHolder = holder as AlbumViewHolder
                viewHolder.bindView(home)
                viewHolder.clickableArea.setOnClickListener {
//                    it.findFragment<HomeFragment>().setSharedAxisXTransitions()
//                    activity.findNavController(R.id.fragment_container).navigate(
//                        R.id.detailListFragment,
//                        bundleOf("type" to TOP_ALBUMS)
//                    )
                    val intent = Intent(activity, DetailListActivity::class.java)
                    intent.putExtra(EXTRA_PLAYLIST_TYPE, TOP_ALBUMS)
                    launchActivity(intent)

                }
            }

            RECENT_ARTISTS -> {
                val viewHolder = holder as ArtistViewHolder
                viewHolder.bindView(home)
                viewHolder.clickableArea.setOnClickListener {
//                    it.findFragment<HomeFragment>().setSharedAxisXTransitions()
//                    activity.findNavController(R.id.fragment_container).navigate(
//                        R.id.detailListFragment,
//                        bundleOf("type" to RECENT_ARTISTS)
//                    )
                    val intent = Intent(activity, DetailListActivity::class.java)
                    intent.putExtra(EXTRA_PLAYLIST_TYPE, RECENT_ARTISTS)
                    launchActivity(intent)
                }
            }

            TOP_ARTISTS -> {
                val viewHolder = holder as ArtistViewHolder
                viewHolder.bindView(home)
                viewHolder.clickableArea.setOnClickListener {
//                    it.findFragment<HomeFragment>().setSharedAxisXTransitions()
//                    activity.findNavController(R.id.fragment_container).navigate(
//                        R.id.detailListFragment,
//                        bundleOf("type" to TOP_ARTISTS)
//                    )

                    val intent = Intent(activity, DetailListActivity::class.java)
                    intent.putExtra(EXTRA_PLAYLIST_TYPE, TOP_ARTISTS)
                    launchActivity(intent)
                }
            }

            FAVOURITES -> {
                val viewHolder = holder as PlaylistViewHolder
                viewHolder.bindView(home)
                viewHolder.clickableArea.setOnClickListener {
//                    it.findFragment<HomeFragment>().setSharedAxisXTransitions()
//                    activity.findNavController(R.id.fragment_container).navigate(
//                        R.id.detailListFragment,
//                        bundleOf("type" to FAVOURITES)
//                    )

                    val intent = Intent(activity, DetailListActivity::class.java)
                    intent.putExtra(EXTRA_PLAYLIST_TYPE, FAVOURITES)
                    launchActivity(intent)
                }
            }
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    @SuppressLint("NotifyDataSetChanged")
    fun swapData(sections: List<Home>) {
        list = sections
        notifyDataSetChanged()
    }

    private inner class AlbumViewHolder(view: View) : AbsHomeViewItem(view) {
        fun bindView(home: Home) {
            title.setText(home.titleRes)
            recyclerView.apply {
                adapter = albumAdapter(home.arrayList as List<Album>)
                layoutManager = gridLayoutManager()
            }
        }
    }

    private fun launchActivity(
        fIntent: Intent,
        isNeedToFinish: Boolean = false,
        @AnimatorRes @AnimRes fEnterAnimId: Int = android.R.anim.fade_in,
        @AnimatorRes @AnimRes fExitAnimId: Int = android.R.anim.fade_out
    ) {
        activity.startActivity(fIntent)
        activity.overridePendingTransition(fEnterAnimId, fExitAnimId)

        if (isNeedToFinish) {
            activity.finish()
        }
    }

    private inner class ArtistViewHolder(view: View) : AbsHomeViewItem(view) {
        fun bindView(home: Home) {
            title.setText(home.titleRes)
            recyclerView.apply {
                layoutManager = linearLayoutManager()
                adapter = artistsAdapter(home.arrayList as List<Artist>)
            }
        }
    }

    private inner class PlaylistViewHolder(view: View) : AbsHomeViewItem(view) {
        fun bindView(home: Home) {
            title.setText(home.titleRes)
            recyclerView.apply {
                val songAdapter = SongAdapter(
                    activity,
                    home.arrayList as MutableList<Song>,
                    R.layout.item_favourite_card, null
                )
                layoutManager = linearLayoutManager()
                adapter = songAdapter
            }
        }
    }

    open class AbsHomeViewItem(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val recyclerView: RecyclerView = itemView.findViewById(R.id.recyclerView)
        val title: AppCompatTextView = itemView.findViewById(R.id.title)
        val arrow: ImageView = itemView.findViewById(R.id.arrow)
        val clickableArea: ViewGroup = itemView.findViewById(R.id.clickable_area)
    }

    private fun artistsAdapter(artists: List<Artist>) =
        ArtistAdapter(activity, artists, PreferenceUtil.homeArtistGridStyle, null, this)

    private fun albumAdapter(albums: List<Album>) =
        AlbumAdapter(activity, albums, PreferenceUtil.homeAlbumGridStyle, null, this)

    private fun gridLayoutManager() =
        GridLayoutManager(activity, 1, GridLayoutManager.HORIZONTAL, false)

    private fun linearLayoutManager() =
        LinearLayoutManager(activity, LinearLayoutManager.HORIZONTAL, false)

    override fun onArtist(artistId: Long, view: View) {
//        activity.findNavController(R.id.fragment_container).navigate(
//            R.id.artistDetailsFragment,
//            bundleOf(EXTRA_ARTIST_ID to artistId),
//            null,
//            FragmentNavigatorExtras(
//                view to artistId.toString()
//            )
//        )

        val intent = Intent(activity, ArtistDetailActivity::class.java)
        intent.putExtra(EXTRA_ARTIST_ID, artistId)
        launchActivity(intent)
    }

    override fun onAlbumClick(albumId: Long, view: View) {
//        activity.findNavController(R.id.fragment_container).navigate(
//            R.id.albumDetailsFragment,
//            bundleOf(EXTRA_ALBUM_ID to albumId),
//            null,
//            FragmentNavigatorExtras(
//                view to albumId.toString()
//            )
//        )
        val intent = Intent(
            activity,
            com.videoplayer.music.musicplayer.activities.AlbumDetalitActivity::class.java
        )
        intent.putExtra(EXTRA_ALBUM_ID, albumId)
        launchActivity(intent)
    }

    override fun onClickGenre(genre: Genre, view: View) {
        activity.findNavController(R.id.fragment_container).navigate(
            R.id.genreDetailsFragment,
            bundleOf(EXTRA_GENRE to genre),
            null,
            FragmentNavigatorExtras(
                view to "genre"
            )
        )
    }

}
