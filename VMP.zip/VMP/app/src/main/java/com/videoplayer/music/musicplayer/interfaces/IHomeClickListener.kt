package com.videoplayer.music.musicplayer.interfaces

import com.videoplayer.music.musicplayer.model.Album
import com.videoplayer.music.musicplayer.model.Artist
import com.videoplayer.music.musicplayer.model.Genre

interface IHomeClickListener {
    fun onAlbumClick(album: Album)

    fun onArtistClick(artist: Artist)

    fun onGenreClick(genre: Genre)
}