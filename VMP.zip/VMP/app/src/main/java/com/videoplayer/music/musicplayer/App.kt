package com.videoplayer.music.musicplayer

import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.os.Bundle
import android.util.Log
import androidx.annotation.Keep
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.OnLifecycleEvent
import androidx.multidex.MultiDexApplication
import com.videoplayer.music.appthemehelper.ThemeStore
import com.videoplayer.music.appthemehelper.util.VersionUtils
import com.adconfig.AdsConfig
import com.adconfig.adsutil.openad.AppOpenApplication
import com.adconfig.adsutil.openad.OpenAdHelper
import com.adconfig.adsutil.openad.WelcomeBackActivity

import com.google.android.gms.ads.MobileAds


import com.google.firebase.FirebaseApp
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.analytics.ktx.analytics
import com.google.firebase.ktx.Firebase
import com.mediaplayer.video.player.videoplayer.music.R
import com.videoplayer.music.common.activity.SplashActivity
import com.videoplayer.music.musicplayer.appshortcuts.DynamicShortcutManager
import com.videoplayer.music.musicplayer.helper.WallpaperAccentManager
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin
import java.security.MessageDigest
import java.util.Date

class App : AppOpenApplication(), AppOpenApplication.AppLifecycleListener {

    //raffaello
    private val wallpaperAccentManager = WallpaperAccentManager(this)
    private lateinit var firebaseAnalytics: FirebaseAnalytics
    private var currentActivity: Activity? = null
//    private lateinit var appOpenAdManager: AppOpenAdManager

    override fun onCreate() {
        super.onCreate()

        instance = this

        startKoin {
            androidContext(this@App)
            modules(appModules)
        }

        if (!ThemeStore.isConfigured(this, 3)) {
            ThemeStore.editTheme(this).accentColorRes(R.color.select_text_color)
                .coloredNavigationBar(true).commit()
        }

        val inter_ad = getString(R.string.ads_inter)
        val open_ad = getString(R.string.ads_open)

        AdsConfig.builder()
            .setTestDeviceId("9B032261719C0E27EC3951981DEC9E59")
            .setAdmobAppOpenId(open_ad)
            .build(this)

        MobileAds.initialize(this)
//        ProcessLifecycleOwner.get().lifecycle.addObserver(this)
//        appOpenAdManager = AppOpenAdManager()
        FirebaseApp.initializeApp(this)
        firebaseAnalytics = Firebase.analytics
        wallpaperAccentManager.init()

        if (VersionUtils.hasNougatMR()) DynamicShortcutManager(this).initDynamicShortcuts()

        try {
            val filter = IntentFilter()
            filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
            registerReceiver(
                com.videoplayer.music.common.utils.NetworkChangeReceiver(), filter
            )
            val info = packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES)
            for (signature in info.signatures) {
                val md = MessageDigest.getInstance("SHA")
                md.update(signature.toByteArray())
                //Log.e("KeyHash:", Base64.encodeToString(md.digest(), Base64.DEFAULT))
            }
        } catch (_: Exception) {

        }
    }

    override fun onTerminate() {
        super.onTerminate()
        wallpaperAccentManager.release()
    }

    companion object {
        private var instance: App? = null

        fun getContext(): App {
            return instance!!
        }

        fun isProVersion(): Boolean {
            return false
        }

//        var isOpenAdHide = false // to prevent open ad after click on privacy policy(etc.)
//        var isOpenAdHideInterstitial = false // to prevent open ad overlay with interstitial ad
//        var isSplashResumeOn = false // to prevent open ad in splash
//        var isNativeLoading = false


        @JvmStatic
        var lastClickTime: Long = 0
        var lastClickTimeMusic: Long = 0
        var lastClickTimeStatus: Long = 0
        var lastClickTimeTheme: Long = 0
    }


    override fun onResumeApp(fCurrentActivity: Activity): Boolean {
        if (fCurrentActivity is SplashActivity) return false
        else if (AdsConfig.isSystemDialogOpen) {
            AdsConfig.isSystemDialogOpen = false
            return false
        }
        return true
    }

    override fun onAppOpenCreatedEvent(fCurrentActivity: Activity) {
        if (onResumeApp(fCurrentActivity))
            if (!fCurrentActivity.isDestroyed && !fCurrentActivity.isFinishing) {
                if (OpenAdHelper.isAdAvailable()) {
                    val intent = Intent(fCurrentActivity, WelcomeBackActivity::class.java)
                    intent.putExtra("isAdLoading", OpenAdHelper.isAdLoading)
                    fCurrentActivity.startActivity(intent)
                }
//            else {
//                logMessages("app_appopen_created", fCurrentActivity.localClassName)
//            }
            }
    }

    override fun onAppOpenShownEvent(fCurrentActivity: Activity) {
    }

    override fun onAppOpenFailedEvent(fCurrentActivity: Activity) {
    }
}
