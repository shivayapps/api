package com.videoplayer.music.musicplayer.fragments.base

import android.os.Bundle
import android.view.View
import androidx.annotation.LayoutRes
import com.videoplayer.music.appthemehelper.util.VersionUtils
import com.mediaplayer.video.player.videoplayer.music.R
import com.videoplayer.music.common.base.BaseActivity
import com.videoplayer.music.musicplayer.extensions.setLightStatusBarAuto
import com.videoplayer.music.musicplayer.extensions.setTaskDescriptionColorAuto
import com.videoplayer.music.musicplayer.fragments.LibraryViewModel
import org.koin.androidx.viewmodel.ext.android.sharedViewModel

abstract class AbsMainActivityFragment(@LayoutRes layout: Int) : AbsMusicServiceFragment(layout) {
    val libraryViewModel: LibraryViewModel by sharedViewModel()

    val musicMainActivity: BaseActivity get() = activity as BaseActivity

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        setHasOptionsMenu(true)
        musicMainActivity.setTaskDescriptionColorAuto()
    }

    private fun setStatusBarColor(view: View, color: Int) {
        val statusBar = view.findViewById<View>(R.id.status_bar)
        if (statusBar != null) {
            if (VersionUtils.hasMarshmallow()) {
                statusBar.setBackgroundColor(color)
                musicMainActivity.setLightStatusBarAuto(color)
            } else {
                statusBar.setBackgroundColor(color)
            }
        }
    }

    fun setStatusBarColorAuto() {

    }

}
