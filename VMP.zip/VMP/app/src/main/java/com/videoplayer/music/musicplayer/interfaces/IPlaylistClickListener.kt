package com.videoplayer.music.musicplayer.interfaces

import android.view.View
import com.videoplayer.music.musicplayer.db.PlaylistWithSongs

interface IPlaylistClickListener {
    fun onPlaylistClick(playlistWithSongs: PlaylistWithSongs, view: View)
}