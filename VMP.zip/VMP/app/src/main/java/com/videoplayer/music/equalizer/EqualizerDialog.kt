package com.videoplayer.music.equalizer

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.PresetReverb
import android.text.TextUtils
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.databinding.EqualizerDialogBinding
import com.videoplayer.music.musicplayer.util.PreferenceUtil.isEqualizerOn

class EqualizerDialog(
    private val fContext: Context,
    val audioSessionId: Int
) : BottomSheetDialog(
    fContext, R.style.MenuButtomAnimationStyle
) {

    private val TAG = "EqualizerDialog"
    private val titleString = ""
    private val titleRes = 0

    private var mEqualizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var presetReverb: PresetReverb? = null

    private var points = floatArrayOf(0.0f, 0.0f, 0.0f, 0.0f, 0.0f)
    private val numberOfFreqBands: Short = 5

    private var y = 0
    private val seekBarFinal = arrayOfNulls<SeekBar>(5)
    private var equalizerDialogBinding: EqualizerDialogBinding =
        EqualizerDialogBinding.inflate(LayoutInflater.from(fContext))

    init {
        setContentView(equalizerDialogBinding.root)
        initLayoutPrams()
        setCanceledOnTouchOutside(true)
        setCancelable(true)
        setOnDismissListener {

            if (mEqualizer != null) {
                mEqualizer!!.release()
            }

            if (bassBoost != null) {
                bassBoost!!.release()
            }

            if (presetReverb != null) {
                presetReverb!!.release()
            }

            com.videoplayer.music.equalizer.Settings.isEditing = false
        }
        setOnShowListener { initViewListener() }
    }

    private fun initLayoutPrams() {
        val window = window
        window!!.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        val attributes = window.attributes
        val systemService = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val displayMetrics = DisplayMetrics()
        systemService.defaultDisplay.getMetrics(displayMetrics)
        attributes.height = FrameLayout.LayoutParams.WRAP_CONTENT
        attributes.width = systemService.defaultDisplay.width
        attributes.gravity = Gravity.BOTTOM
    }


    var equalizerPresetSpinnerAdapter: com.videoplayer.music.equalizer.adapter.SingleCheckAdapter? = null

    private fun equalizeSound() {
        val equalizerPresetNames: MutableList<String> = ArrayList()
        equalizerPresetNames.add("Custom")
        for (i in 0 until mEqualizer!!.numberOfPresets) {
            equalizerPresetNames.add(mEqualizer!!.getPresetName(i.toShort()))
        }
        equalizerPresetSpinnerAdapter =
            com.videoplayer.music.equalizer.adapter.SingleCheckAdapter(
                fContext,
                equalizerPresetNames
            )
        equalizerDialogBinding.equalizerPresetSpinner.adapter = equalizerPresetSpinnerAdapter
        if (com.videoplayer.music.equalizer.Settings.isEqualizerReloaded && com.videoplayer.music.equalizer.Settings.presetPos != 0) {
            equalizerPresetSpinnerAdapter!!.setSelection(com.videoplayer.music.equalizer.Settings.presetPos)
        }
        equalizerPresetSpinnerAdapter!!.setOnItemClickListener { _, _, position, _ ->
            try {
                if (position != 0) {
                    Log.e(TAG, "setOnItemClickListener.position " + (position - 1).toShort())
                    mEqualizer!!.usePreset((position - 1).toShort())
                    com.videoplayer.music.equalizer.Settings.presetPos = position
                    val lowerEqualizerBandLevel = mEqualizer!!.bandLevelRange[0]
                    for (i in 0 until numberOfFreqBands) {
                        seekBarFinal[i]!!.progress =
                            mEqualizer!!.getBandLevel(i.toShort()) - lowerEqualizerBandLevel
                        points[i] =
                            (mEqualizer!!.getBandLevel(i.toShort()) - lowerEqualizerBandLevel).toFloat()
                        com.videoplayer.music.equalizer.Settings.seekbarpos[i] = mEqualizer!!.getBandLevel(i.toShort()).toInt()
                        com.videoplayer.music.equalizer.Settings.equalizerModel.seekbarpos[i] =
                            mEqualizer!!.getBandLevel(i.toShort()).toInt()
                    }
                }
            } catch (e: java.lang.Exception) {
                Log.e(
                    TAG,
                    "setOnItemClickListener.Exception: equalizerPresetSpinnerAdapter " + e.localizedMessage
                )
                Toast.makeText(
                    fContext,
                    "Error while updating Equalizer",
                    Toast.LENGTH_SHORT
                ).show()
            }
            com.videoplayer.music.equalizer.Settings.equalizerModel.presetPos = position
        }
    }

    private fun initViewListener() {

//        val mEndButton = Button(fContext)
//        mEndButton.setBackgroundColor(themeColor)
//        mEndButton.setTextColor(textColor)

        com.videoplayer.music.equalizer.Settings.isEditing = true

        if (com.videoplayer.music.equalizer.Settings.equalizerModel == null) {
            Log.e(TAG, "initViewListener.equalizerModel")
            com.videoplayer.music.equalizer.Settings.equalizerModel =
                com.videoplayer.music.equalizer.EqualizerModel()
            com.videoplayer.music.equalizer.Settings.equalizerModel.reverbPreset = PresetReverb.PRESET_NONE
            com.videoplayer.music.equalizer.Settings.equalizerModel.bassStrength = (1000 / 19).toShort()
        } else {
            Log.e(TAG, "initViewListener.equalizerModel not null")
        }

        mEqualizer = Equalizer(0, audioSessionId)
        bassBoost = BassBoost(0, audioSessionId)
        bassBoost?.enabled = true
        val bassBoostSettingTemp = bassBoost?.properties
        val bassBoostSetting = BassBoost.Settings(bassBoostSettingTemp.toString())
        bassBoostSetting.strength = com.videoplayer.music.equalizer.Settings.equalizerModel.bassStrength
        bassBoost?.properties = bassBoostSetting


        Log.e(TAG, "initViewListener.reverbPreset001:" + com.videoplayer.music.equalizer.Settings.equalizerModel.reverbPreset)
        Log.e(TAG, "initViewListener.reverbPreset002:" + com.videoplayer.music.equalizer.Settings.reverbPreset)
        presetReverb = PresetReverb(0, audioSessionId)
//        presetReverb?.preset = Settings.equalizerModel.reverbPreset

        try {
//            presetReverb!!.preset = Settings.reverbPreset
            presetReverb?.preset = com.videoplayer.music.equalizer.Settings.equalizerModel.reverbPreset
        } catch (e: Exception) {
            Log.e(TAG, "Exception: reverbController 001:" + e.localizedMessage)
            e.printStackTrace()
        }
        presetReverb?.enabled = true

        mEqualizer?.enabled = true

        if (com.videoplayer.music.equalizer.Settings.presetPos == 0) {
            for (bandIdx in 0 until mEqualizer?.numberOfBands!!) {
                mEqualizer?.setBandLevel(bandIdx.toShort(), com.videoplayer.music.equalizer.Settings.seekbarpos[bandIdx].toShort())
            }
        } else {
            Log.e(TAG, "Settings.presetPos:" + com.videoplayer.music.equalizer.Settings.presetPos.toShort())
            mEqualizer?.usePreset((com.videoplayer.music.equalizer.Settings.presetPos - 1).toShort())
        }

        if (titleRes != 0) {
            try {
                equalizerDialogBinding.equalizerFragmentTitle.text = fContext.getString(titleRes)
            } catch (e: Exception) {
                Log.e(TAG, "onViewCreated: unable to set title because " + e.localizedMessage)
            }
        } else if (!TextUtils.isEmpty(titleString)) {
            equalizerDialogBinding.equalizerFragmentTitle.text = titleString
        }

        val equalizerSwitch: Switch = equalizerDialogBinding.equalizerSwitch
        equalizerSwitch.isChecked = isEqualizerOn

        equalizerSwitch.setOnCheckedChangeListener { _, isChecked ->
            isEqualizerOn = isChecked
            mEqualizer!!.enabled = isChecked
            bassBoost!!.enabled = isChecked
            presetReverb!!.enabled = isChecked

            if (isChecked) {
                equalizerDialogBinding.controllerBass.isEnabled = true
                equalizerDialogBinding.controller3D.isEnabled = true
                for (i in seekBarFinal.indices) {
                    seekBarFinal[i]!!.isEnabled = true
                }
            } else {
                equalizerDialogBinding.controllerBass.isEnabled = false
                equalizerDialogBinding.controller3D.isEnabled = false
                for (i in seekBarFinal.indices) {
                    seekBarFinal[i]!!.isEnabled = false
                }
            }
        }

        equalizerDialogBinding.equalizerPresetSpinner.layoutManager = LinearLayoutManager(
            fContext,
            LinearLayoutManager.HORIZONTAL,
            false
        )

        equalizerDialogBinding.controllerBass.progressBackgroundTintList =
            ColorStateList.valueOf(Color.DKGRAY)
        equalizerDialogBinding.controllerBass.progressTintList =
            ColorStateList.valueOf(Color.parseColor("#FE284D"))

        equalizerDialogBinding.controller3D.progressBackgroundTintList =
            ColorStateList.valueOf(Color.DKGRAY)
        equalizerDialogBinding.controller3D.progressTintList =
            ColorStateList.valueOf(Color.parseColor("#FE284D"))

        Log.e(TAG, "EqualizerBottomSheetDialog.init.004")
        if (!com.videoplayer.music.equalizer.Settings.isEqualizerReloaded) {
            var x = 0
            if (bassBoost != null) {
                try {
                    x = bassBoost!!.roundedStrength * 19 / 1000
                } catch (e: Exception) {
                    Log.e(TAG, "Exception: isEqualizerReloaded " + e.localizedMessage)
                    e.printStackTrace()
                }
            }
            if (presetReverb != null) {
                try {
                    y = presetReverb!!.preset * 19 / 6
                } catch (e: Exception) {
                    Log.e(TAG, "Exception: presetReverb " + e.localizedMessage)
                    e.printStackTrace()
                }
            }
            if (x == 0) {
                equalizerDialogBinding.controllerBass.progress = 1
            } else {
                equalizerDialogBinding.controllerBass.progress = x
            }
            if (y == 0) {
                equalizerDialogBinding.controller3D.progress = 1
            } else {
                equalizerDialogBinding.controller3D.progress = y
            }
        } else {
            val x = com.videoplayer.music.equalizer.Settings.bassStrength * 19 / 1000
            y = com.videoplayer.music.equalizer.Settings.reverbPreset * 19 / 6
            if (x == 0) {
                equalizerDialogBinding.controllerBass.progress = 1
            } else {
                equalizerDialogBinding.controllerBass.progress = x
            }
            if (y == 0) {
                equalizerDialogBinding.controller3D.progress = 1
            } else {
                equalizerDialogBinding.controller3D.progress = y
            }
        }

        equalizerDialogBinding.controllerBass.setOnSeekBarChangeListener(object :
            SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                com.videoplayer.music.equalizer.Settings.bassStrength = (1000f / 19 * progress).toInt().toShort()
                try {
                    bassBoost!!.setStrength(com.videoplayer.music.equalizer.Settings.bassStrength)
                    com.videoplayer.music.equalizer.Settings.equalizerModel.bassStrength = com.videoplayer.music.equalizer.Settings.bassStrength
                } catch (e: Exception) {
                    Log.e(TAG, "Exception: bassController " + e.localizedMessage)
                    e.printStackTrace()
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })

        equalizerDialogBinding.controller3D.setOnSeekBarChangeListener(object :
            SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                com.videoplayer.music.equalizer.Settings.reverbPreset = (progress * 6 / 19).toShort()
                Log.e(TAG, "initViewListener.reverbPreset003:" + com.videoplayer.music.equalizer.Settings.reverbPreset)
                com.videoplayer.music.equalizer.Settings.equalizerModel.reverbPreset = com.videoplayer.music.equalizer.Settings.reverbPreset
                try {
                    presetReverb!!.preset = com.videoplayer.music.equalizer.Settings.reverbPreset
                } catch (e: Exception) {
                    Log.e(TAG, "Exception: reverbController 002" + e.localizedMessage)
                    e.printStackTrace()
                }
                y = progress
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })

        Log.e(TAG, "EqualizerBottomSheetDialog.init.005")

        val lowerEqualizerBandLevel = mEqualizer!!.bandLevelRange[0]
        val upperEqualizerBandLevel = mEqualizer!!.bandLevelRange[1]

        for (i in 0 until numberOfFreqBands) {
            val equalizerBandIndex = i.toShort()
            val frequencyHeaderTextView = TextView(fContext)
            frequencyHeaderTextView.layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            frequencyHeaderTextView.gravity = Gravity.CENTER_HORIZONTAL
            frequencyHeaderTextView.text =
                (mEqualizer!!.getCenterFreq(equalizerBandIndex) / 1000).toString() + "Hz"
            val seekBarRowLayout = LinearLayout(fContext)
            seekBarRowLayout.orientation = LinearLayout.VERTICAL
            val lowerEqualizerBandLevelTextView = TextView(fContext)
            lowerEqualizerBandLevelTextView.layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            lowerEqualizerBandLevelTextView.text = (lowerEqualizerBandLevel / 100).toString() + "dB"
            val upperEqualizerBandLevelTextView = TextView(fContext)
            lowerEqualizerBandLevelTextView.layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            upperEqualizerBandLevelTextView.text = (upperEqualizerBandLevel / 100).toString() + "dB"
            val layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            layoutParams.weight = 1f
            var seekBar = SeekBar(fContext)
            var textView = TextView(fContext)
            when (i) {
                0 -> {
                    seekBar = equalizerDialogBinding.seekBar1
                    textView = equalizerDialogBinding.textView1
                }

                1 -> {
                    seekBar = equalizerDialogBinding.seekBar2
                    textView = equalizerDialogBinding.textView2
                }

                2 -> {
                    seekBar = equalizerDialogBinding.seekBar3
                    textView = equalizerDialogBinding.textView3
                }

                3 -> {
                    seekBar = equalizerDialogBinding.seekBar4
                    textView = equalizerDialogBinding.textView4
                }

                4 -> {
                    seekBar = equalizerDialogBinding.seekBar5
                    textView = equalizerDialogBinding.textView5
                }
            }
            seekBar.progressBackgroundTintList = ColorStateList.valueOf(Color.DKGRAY)
            seekBar.progressTintList = ColorStateList.valueOf(Color.parseColor("#FE284D"))
            seekBarFinal[i] = seekBar
            seekBar.id = i
            seekBar.max = upperEqualizerBandLevel - lowerEqualizerBandLevel

            textView.text = frequencyHeaderTextView.text
            textView.textAlignment = View.TEXT_ALIGNMENT_CENTER
            if (com.videoplayer.music.equalizer.Settings.isEqualizerReloaded) {
                points[i] = (com.videoplayer.music.equalizer.Settings.seekbarpos[i] - lowerEqualizerBandLevel).toFloat()
                seekBar.progress = com.videoplayer.music.equalizer.Settings.seekbarpos[i] - lowerEqualizerBandLevel
            } else {
                points[i] =
                    (mEqualizer!!.getBandLevel(equalizerBandIndex) - lowerEqualizerBandLevel).toFloat()
                seekBar.progress =
                    mEqualizer!!.getBandLevel(equalizerBandIndex) - lowerEqualizerBandLevel
                com.videoplayer.music.equalizer.Settings.seekbarpos[i] = mEqualizer!!.getBandLevel(equalizerBandIndex).toInt()
                com.videoplayer.music.equalizer.Settings.isEqualizerReloaded = true
            }

            seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                    mEqualizer!!.setBandLevel(
                        equalizerBandIndex,
                        (progress + lowerEqualizerBandLevel).toShort()
                    )
                    points[seekBar.id] =
                        (mEqualizer!!.getBandLevel(equalizerBandIndex) - lowerEqualizerBandLevel).toFloat()
                    com.videoplayer.music.equalizer.Settings.seekbarpos[seekBar.id] = progress + lowerEqualizerBandLevel
                    com.videoplayer.music.equalizer.Settings.equalizerModel.seekbarpos[seekBar.id] =
                        progress + lowerEqualizerBandLevel
                }

                override fun onStartTrackingTouch(seekBar: SeekBar) {
                    equalizerPresetSpinnerAdapter?.setSelection(0)
                    com.videoplayer.music.equalizer.Settings.presetPos = 0
                    com.videoplayer.music.equalizer.Settings.equalizerModel.presetPos = 0
                }

                override fun onStopTrackingTouch(seekBar: SeekBar) {
                }
            })
        }

        equalizeSound()

    }
}