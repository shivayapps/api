package com.videoplayer.music.musicplayer.adapter.album

import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.FragmentActivity
import com.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.videoplayer.music.musicplayer.glide.RetroMusicColoredTarget
import com.videoplayer.music.musicplayer.helper.HorizontalAdapterHelper
import com.videoplayer.music.musicplayer.interfaces.IAlbumClickListener
import com.videoplayer.music.musicplayer.interfaces.ICabHolder
import com.videoplayer.music.musicplayer.model.Album
import com.videoplayer.music.musicplayer.util.MusicUtil

class HorizontalAlbumAdapter(
    activity: FragmentActivity,
    dataSet: List<Album>,
    ICabHolder: ICabHolder?,
    albumClickListener: IAlbumClickListener
) : AlbumAdapter(
    activity, dataSet, HorizontalAdapterHelper.LAYOUT_RES, ICabHolder, albumClickListener
) {

    override fun createViewHolder(view: View, viewType: Int): ViewHolder {
        val params = view.layoutParams as ViewGroup.MarginLayoutParams
        HorizontalAdapterHelper.applyMarginToLayoutParams(activity, params, viewType)
        return ViewHolder(view)
    }

    override fun setColors(color: com.videoplayer.music.musicplayer.util.color.MediaNotificationProcessor, holder: ViewHolder) {
        // holder.title?.setTextColor(ATHUtil.resolveColor(activity, android.R.attr.textColorPrimary))
        // holder.text?.setTextColor(ATHUtil.resolveColor(activity, android.R.attr.textColorSecondary))
    }

    override fun loadAlbumCover(album: Album, holder: ViewHolder) {
        if (holder.image == null) return
        com.videoplayer.music.musicplayer.glide.GlideApp.with(activity).asBitmapPalette().albumCoverOptions(album.safeGetFirstSong())
            .load(RetroGlideExtension.getSongModel(album.safeGetFirstSong()))
            .into(object : RetroMusicColoredTarget(holder.image!!) {
                override fun onColorReady(colors: com.videoplayer.music.musicplayer.util.color.MediaNotificationProcessor) {
                    setColors(colors, holder)
                }
            })
    }

    override fun getAlbumText(album: Album): String {
        return MusicUtil.getYearString(album.year)
    }

    override fun getItemViewType(position: Int): Int {
        return HorizontalAdapterHelper.getItemViewType(position, itemCount)
    }

    override fun getItemCount(): Int {
        return dataSet.size
    }

    companion object {
        val TAG: String = AlbumAdapter::class.java.simpleName
    }
}
