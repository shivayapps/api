package com.videoplayer.music.musicplayer.adapter.song

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.fragment.app.FragmentActivity
import com.bumptech.glide.Glide
import com.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.videoplayer.music.musicplayer.glide.RetroGlideExtension.asBitmapPalette
import com.videoplayer.music.musicplayer.glide.RetroGlideExtension.songCoverOptions
import com.videoplayer.music.musicplayer.glide.RetroMusicColoredTarget
import com.videoplayer.music.musicplayer.interfaces.ICabHolder
import com.videoplayer.music.musicplayer.model.Song
import com.videoplayer.music.musicplayer.util.MusicUtil

class SimpleSongAdapter(
    context: FragmentActivity,
    songs: ArrayList<Song>,
    layoutRes: Int,
    ICabHolder: ICabHolder?
) : SongAdapter(context, songs, layoutRes, ICabHolder) {

    override fun swapDataSet(dataSet: List<Song>) {
        this.dataSet = dataSet.toMutableList()
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(activity).inflate(itemLayoutRes, parent, false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        super.onBindViewHolder(holder, position)
        val fixedTrackNumber = MusicUtil.getFixedTrackNumber(dataSet[position].trackNumber)

        holder.imageText?.text = if (fixedTrackNumber > 0) fixedTrackNumber.toString() else "-"
        holder.time?.text = MusicUtil.getReadableDurationString(dataSet[position].duration)
        Glide.with(activity).asBitmapPalette().songCoverOptions(dataSet[position])
            .load(RetroGlideExtension.getSongModel(dataSet[position]))
            .into(object : RetroMusicColoredTarget(holder.image!!) {
                override fun onColorReady(colors: com.videoplayer.music.musicplayer.util.color.MediaNotificationProcessor) {

                }
            })
    }

    override fun getItemCount(): Int {
        return dataSet.size
    }
}
