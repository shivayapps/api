package com.videoplayer.music.common.activity

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.preference.PreferenceManager
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.mediaplayer.video.player.videoplayer.music.R

import com.videoplayer.music.common.base.BaseBindingActivity
import com.videoplayer.music.common.database.HideVideoDatabase
import com.videoplayer.music.common.utils.isOnline
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityPermissionBinding
import com.videoplayer.music.common.utils.AdCache
import com.videoplayer.music.musicplayer.ADAPTIVE_COLOR_APP
import com.videoplayer.music.musicplayer.ALBUM_COVER_TRANSFORM
import com.videoplayer.music.musicplayer.APPBAR_MODE
import com.videoplayer.music.musicplayer.App
import com.videoplayer.music.musicplayer.BANNER_IMAGE_PATH
import com.videoplayer.music.musicplayer.BLACK_THEME
import com.videoplayer.music.musicplayer.CAROUSEL_EFFECT
import com.videoplayer.music.musicplayer.CIRCLE_PLAY_BUTTON
import com.videoplayer.music.musicplayer.CIRCULAR_ALBUM_ART
import com.videoplayer.music.musicplayer.CUSTOM_FONT
import com.videoplayer.music.musicplayer.DESATURATED_COLOR
import com.videoplayer.music.musicplayer.EXTRA_SONG_INFO
import com.videoplayer.music.musicplayer.GENERAL_THEME
import com.videoplayer.music.musicplayer.HOME_ARTIST_GRID_STYLE
import com.videoplayer.music.musicplayer.IMAGE_THEME
import com.videoplayer.music.musicplayer.KEEP_SCREEN_ON
import com.videoplayer.music.musicplayer.LANGUAGE_NAME
import com.videoplayer.music.musicplayer.LIBRARY_CATEGORIES
import com.videoplayer.music.musicplayer.MATERIAL_YOU
import com.videoplayer.music.musicplayer.PROFILE_IMAGE_PATH
import com.videoplayer.music.musicplayer.ROUND_CORNERS
import com.videoplayer.music.musicplayer.TAB_TEXT_MODE
import com.videoplayer.music.musicplayer.TOGGLE_ADD_CONTROLS
import com.videoplayer.music.musicplayer.TOGGLE_FULL_SCREEN
import com.videoplayer.music.musicplayer.TOGGLE_GENRE
import com.videoplayer.music.musicplayer.TOGGLE_HOME_BANNER
import com.videoplayer.music.musicplayer.TOGGLE_SEPARATE_LINE
import com.videoplayer.music.musicplayer.TOGGLE_VOLUME
import com.videoplayer.music.musicplayer.USER_NAME
import com.videoplayer.music.musicplayer.WALLPAPER_ACCENT
import com.videoplayer.music.musicplayer.extensions.resolveColor
import com.videoplayer.music.musicplayer.extensions.setDrawBehindSystemBars
import com.videoplayer.music.musicplayer.extensions.setImmersiveFullscreen
import com.videoplayer.music.musicplayer.extensions.setStatusBarColor
import com.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.videoplayer.music.musicplayer.util.PreferenceUtil

class PermissionActivity : BaseBindingActivity<ActivityPermissionBinding>(),
    SharedPreferences.OnSharedPreferenceChangeListener {

    private var isOpenPermissionDialog = false
    override fun getActivityContext(): FragmentActivity {
        return this@PermissionActivity
    }

    override fun setBinding(): ActivityPermissionBinding {
        return ActivityPermissionBinding.inflate(layoutInflater)
    }

    override fun initView() {
        super.initView()
        PreferenceUtil.registerOnSharedPreferenceChangedListener(this)
        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        } else {
            setImmersiveFullscreen()
        }

        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext())
            .getString(IMAGE_THEME, "")
        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext())
            .getInt(GENERAL_THEME, 0)

        setStatusBarColor(resolveColor(R.attr.mainBackgroundColor))

        if (editors == "theme_image") {
            val userImageTheme = RetroGlideExtension.getUserImageTheme(this@PermissionActivity)
            mBinding.imgBackground.setImageDrawable(userImageTheme)
            mBinding.constraintLayout.background = null
        } else if (editors == "theme_gradient") {
            val userGradientTheme =
                AppCompatResources.getDrawable(this, RetroGlideExtension.getUserGradientTheme())
            mBinding.imgBackground.setImageDrawable(userGradientTheme)
            mBinding.constraintLayout.background = null
        } else if (edit >= 0) {
            mBinding.imgBackground.setImageDrawable(null)
        }

        var mAdView: AdView?=null
        var isAdLoaded = false
        if (isOnline) {

            val adId = getString(R.string.admob_banner)
            BannerAdHelper.showBanner(this, mBinding.frameLayout,  adId,
                AdCache.bannerAdView,
                { isLoaded,adView, message ->
                    mAdView=adView
                    AdCache.bannerAdView=adView
                    isAdLoaded = isLoaded
                })

        } else {
            mBinding.frameLayout.visibility = View.GONE
        }
    }

    override fun initViewListener() {
        super.initViewListener()
        mBinding.btnPermission.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        super.onClick(v)
        when (v.id) {
            R.id.btn_permission -> {
                if (!checkPermissionBelow30()) {
                    ActivityCompat.requestPermissions(mActivity, REQUIRED_PERMISSIONS, 1)
                } else {
                    val intent = Intent(mActivity, MainActivity::class.java)
                    launchActivity(intent, true)
                }
            }
        }
    }

    private val REQUIRED_PERMISSIONS =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_AUDIO,
                Manifest.permission.READ_MEDIA_VIDEO
            )
        } else {
            arrayOf(
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE
            )
        }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (permissions.isEmpty()) {
            return
        }
        var permissionDetail: String? = null
        var allPermissionsGranted = true

        if (grantResults.isNotEmpty()) {
            for (grantResult in grantResults) {
                if (grantResult != PackageManager.PERMISSION_GRANTED) {
                    allPermissionsGranted = false
                    break
                }
            }
        }

        if (!allPermissionsGranted) {
            var somePermissionsForeverDenied = false
            for (permission in permissions) {
                if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                    if (requestCode == 1) {
                        ActivityCompat.requestPermissions(
                            mActivity,
                            arrayOf(
                                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                Manifest.permission.READ_EXTERNAL_STORAGE
                            ),
                            1
                        )
                        break
                    }
                } else {
                    if (ActivityCompat.checkSelfPermission(
                            this,
                            permission
                        ) != PackageManager.PERMISSION_GRANTED
                    ) {
                        somePermissionsForeverDenied = true
                    }
                }
            }
            if (somePermissionsForeverDenied) {
                if (!isOpenPermissionDialog) {
                    val alertDialogBuilder = AlertDialog.Builder(this)
                    if (ContextCompat.checkSelfPermission(
                            this,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                        ) != PackageManager.PERMISSION_GRANTED
                        && ContextCompat.checkSelfPermission(
                            this,
                            Manifest.permission.READ_EXTERNAL_STORAGE
                        ) != PackageManager.PERMISSION_GRANTED
                    ) {
                        permissionDetail = "Please allow permission for storage"
                    }
                    alertDialogBuilder.setTitle("Permissions Required")
                        .setMessage(permissionDetail)
                        .setPositiveButton("Ok") { dialog, _ ->
                            dialog.dismiss()
                            dialog.dismiss()
                            isOpenPermissionDialog = false

                            val intent = Intent(
                                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.fromParts("package", packageName, null)
                            )
                            launchActivityForResult(intent, 221)
                        }.setNegativeButton("Cancel") { dialog, _ ->
                            isOpenPermissionDialog = false
//                            finishAffinity()
                            dialog.dismiss()
                        }.setCancelable(false).create().show()
                    isOpenPermissionDialog = true
                }
            }
        } else {
            if (requestCode == 1) {
                val intent = Intent(mActivity, MainActivity::class.java)
                launchActivity(intent, true)
            }
        }
    }

    override fun fromActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.fromActivityResult(requestCode, resultCode, data)
        if (requestCode == 221 && checkPermissionBelow30()) {
            HideVideoDatabase.destroyInstance()
            try {
                HideVideoDatabase.getInstance(this)
            } catch (_: Exception) {

            }
            val intent = Intent(mActivity, MainActivity::class.java)
            launchActivity(intent, true)
        } else if (requestCode == 222) {
            HideVideoDatabase.destroyInstance()
            try {
                HideVideoDatabase.getInstance(this)
            } catch (_: Exception) {

            }
            val intent = Intent(mActivity, MainActivity::class.java)
            launchActivity(intent, true)
        }
    }

    private fun checkPermissionBelow30(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return !(ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_MEDIA_IMAGES
            ) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_MEDIA_AUDIO
            ) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_MEDIA_VIDEO
            ) != PackageManager.PERMISSION_GRANTED)
        } else {
            return !(ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED)
        }
    }

    override fun onSharedPreferenceChanged(p0: SharedPreferences?, key: String?) {
        if (key == MATERIAL_YOU || key == WALLPAPER_ACCENT || key == BLACK_THEME || key == ADAPTIVE_COLOR_APP || key == USER_NAME || key == TOGGLE_FULL_SCREEN || key == TOGGLE_VOLUME || key == ROUND_CORNERS || key == CAROUSEL_EFFECT || key == TOGGLE_GENRE || key == BANNER_IMAGE_PATH || key == PROFILE_IMAGE_PATH || key == CIRCULAR_ALBUM_ART || key == KEEP_SCREEN_ON || key == TOGGLE_SEPARATE_LINE || key == TOGGLE_HOME_BANNER || key == TOGGLE_ADD_CONTROLS || key == HOME_ARTIST_GRID_STYLE || key == ALBUM_COVER_TRANSFORM || key == DESATURATED_COLOR || key == EXTRA_SONG_INFO || key == TAB_TEXT_MODE || key == LANGUAGE_NAME || key == LIBRARY_CATEGORIES || key == CUSTOM_FONT || key == APPBAR_MODE || key == CIRCLE_PLAY_BUTTON) {
            postRecreate()
        }
    }
}