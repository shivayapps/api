package com.example.admob.adLoader;

import static com.example.admob.utils.AdsConstants.isPremiumEnabled;
import static com.example.admob.utils.AdsConstants.is_openAdshow_on_resume;
import static com.example.admob.utils.AdsConstants.remoteConfig;
import static com.example.admob.utils.CheckInternetConnection.isOnline;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ProcessLifecycleOwner;

import com.example.admob.utils.AdsConstants;
import com.example.admob.utils.PreferenceManager;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.admanager.AdManagerAdRequest;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.util.Date;

public abstract class OpenAdApplication extends Application implements Application.ActivityLifecycleCallbacks, DefaultLifecycleObserver {


    private String TAG = "OpenAdApplication";
    private AppOpenAdManager appOpenAdManager;
    private Activity currentActivity;
    private AppLifecycleListener appLifecycleListener;

//    private String admobOpenAdId;
//    private String admobOpenAdReloadId;

    private static final String F_Load = "f_load";
    private static String F_Show = "f_show";
    private static final String F_Fail_Load = "f_fail";
    private static final String F_Request = "f_request";

    private static String F_Dismiss = "f_dismiss";
    private static String F_Impression = "f_impression";
    private static String F_Show_Fail = "f_show_fail";
    private static String F_Click = "f_click";

    private static final String B_Load = "b_load";
    private static final String B_Fail_Load = "b_fail";
    private static final String B_Request = "b_request";

    // GoogleAnalyt icsEvent Variable
    private static final String openAds = "Admob_Open_Ads";
    private static final String inResume = "In_Resume";


    public FirebaseAnalytics analytics() {
        return FirebaseAnalytics.getInstance(this);
    }

    ;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.e(TAG, "onCreate: ");

        appOpenAdManager = new AppOpenAdManager();
        registerActivityLifecycleCallbacks(this);
        ProcessLifecycleOwner.get().getLifecycle().addObserver(this);

        //Log.e(TAG, "onCreate: Open Ad ID" + openAdsId(this) + "---" + "Reload OpenAd Id" + openAdsReloadId(this));

    }

    @Override
    public void onStart(@NonNull LifecycleOwner owner) {
        DefaultLifecycleObserver.super.onStart(owner);
        Log.e(TAG, "onStart: ---------------------- OpenAdApplication");
    }

    @Override
    public void onStop(@NonNull LifecycleOwner owner) {
        DefaultLifecycleObserver.super.onStop(owner);
        Log.e(TAG, "onStop: ---------------------- OpenAdApplication");
    }

    @Override
    public void onDestroy(@NonNull LifecycleOwner owner) {
        DefaultLifecycleObserver.super.onDestroy(owner);
        Log.e(TAG, "onDestroy: ---------------------- OpenAdApplication");
    }


    @Override
    public void onResume(@NonNull LifecycleOwner owner) {
        DefaultLifecycleObserver.super.onResume(owner);
        Log.e(TAG, "msg: ---------------------- OpenAdApplication" + " " + currentActivity);
        Log.e(TAG, "msg: ---------------------- getSHOW_OPEN_AD" + " " + PreferenceManager.Companion.getBooleanData(this, PreferenceManager.Companion.getSHOW_OPEN_AD(), true));
        Log.e(TAG, "msg: ---------------------- is_openAdshow_on_resume" + " " + remoteConfig.getBoolean(is_openAdshow_on_resume));
        //Added line 103 for control open ads at resume From Firebase by hardik 1.47
        if (remoteConfig.getBoolean(is_openAdshow_on_resume)) {
            if (PreferenceManager.Companion.getBooleanData(this, PreferenceManager.Companion.getSHOW_OPEN_AD(), true)) {

                if (appLifecycleListener.onResumeApp(currentActivity)) {

                    appOpenAdManager.showAdIfAvailable(currentActivity);
                }
            }
        }
    }

    public void setAppLifeCycleListener(AppLifecycleListener appLifeCycleListener) {
        this.appLifecycleListener = appLifeCycleListener;
    }

    public void setOpenAdIds() {

//        this.admobOpenAdId = AdsConstants.getAdmob_open_ads(this);
//        this.admobOpenAdReloadId = AdsConstants.getAdmob_open_ads_back(this);
        appOpenAdManager.loadAd(this);

//        Log.e(TAG, "setOpenAdIds: ----------------------" + admobOpenAdId);
//        Log.e(TAG, "setOpenAdIds: ---------------------- Reload" + admobOpenAdReloadId);

    }

    public interface AppLifecycleListener {
        Boolean onResumeApp(Activity currentActivity);
    }


    public void destroyAd() {
        if (appOpenAdManager != null) {
            appOpenAdManager.destroyAd();
        }
    }

    public interface OnShowAdCompleteListener {
        void onShowAdComplete();
    }


    @Override
    public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle savedInstanceState) {

    }

    @Override
    public void onActivityStarted(@NonNull Activity activity) {
        if (!appOpenAdManager.isShowingAd) {
            currentActivity = activity;
        }
    }

    @Override
    public void onActivityResumed(@NonNull Activity activity) {
        currentActivity = activity;
    }

    @Override
    public void onActivityPaused(@NonNull Activity activity) {

    }

    @Override
    public void onActivityStopped(@NonNull Activity activity) {


    }

    @Override
    public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {

    }

    @Override
    public void onActivityDestroyed(@NonNull Activity activity) {
        currentActivity = null;
    }

    /**
     * Inner class that loads and shows app open ads.
     */
    private class AppOpenAdManager {


        private AppOpenAd appOpenAd = null;
        private boolean isLoadingAd = false;
        private boolean isShowingAd = false;

        /**
         * Keep track of the time an app open ad is loaded to ensure you don't show an expired ad.
         */
        private long loadTime = 0;

        /**
         * Constructor.
         */
        public AppOpenAdManager() {
        }

        /**
         * Load an ad.
         *
         * @param context the context of the activity that loads the ad
         */
        public void loadAd(Context context) {
            // Do not load ad if there is an unused ad or one is already loading.
            Log.e("msg", " - - - - - - - - - - " + " isLoadingAd : " + isLoadingAd + " isAdAvailable : " + isAdAvailable());
            Log.e("msg", " - - - - - - - - - - " + " isOnline : " + isOnline(context) + " isPremiumEnabled : " + isPremiumEnabled(context));
            if (isOnline(context) && !isPremiumEnabled(context)) {
                if (isLoadingAd || isAdAvailable()) {
                    return;
                }
                isLoadingAd = true;

                AdManagerAdRequest request = new AdManagerAdRequest.Builder().build();


                Bundle bundle = new Bundle();
                bundle.putString(F_Request, F_Request);
                analytics().logEvent(openAds, bundle);
                Log.e("msg", " - - - - - - - - - - " + openAds + " + " + F_Request + " + " + F_Request + " " + AdsConstants.getAdmob_open_ads(context));

                AppOpenAd.load(
                    context,
                    /*admobOpenAdId*/AdsConstants.getAdmob_open_ads(context),
                    request,
                    AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT,
                    new AppOpenAd.AppOpenAdLoadCallback() {
                        /**
                         * Called when an app open ad has loaded.
                         *
                         * @param ad the loaded app open ad.
                         */
                        @Override
                        public void onAdLoaded(AppOpenAd ad) {

                            Bundle bundle = new Bundle();
                            bundle.putString(F_Load, F_Load);
                            analytics().logEvent(openAds, bundle);

                            Log.e("msg", " - - - - - - - - - - " + openAds + " + " + F_Load + " + " + F_Load + " " + AdsConstants.getAdmob_open_ads(context));

                            appOpenAd = ad;
                            isLoadingAd = false;

                            loadTime = (new Date()).getTime();

                            Log.d(TAG, "onAdLoaded.");


                        }


                        @Override
                        public void onAdFailedToLoad(LoadAdError loadAdError) {

                            Bundle bundle = new Bundle();
                            bundle.putString(F_Fail_Load, F_Fail_Load);
                            analytics().logEvent(openAds, bundle);

                            Log.e("msg", " - - - - - - - - - - " + openAds + " + " + F_Fail_Load + " + " + F_Fail_Load + " " + AdsConstants.getAdmob_open_ads(context));
                            isLoadingAd = false;


                            Log.d(TAG, "onAdFailedToLoad: " + loadAdError.getMessage());
                            reloadOpenAd(context);

                        }
                    });
            }

        }


        private void reloadOpenAd(Context context) {
            F_Show = "b_show";
            F_Dismiss = "b_dismiss";
            F_Impression = "b_impression";
            F_Show_Fail = "b_show_fail";
            F_Click = "b_click";
            Bundle bundle = new Bundle();
            bundle.putString(B_Request, B_Request);
            analytics().logEvent(openAds, bundle);

            Log.e("msg", " - - - - - - - - - - " + openAds + " + " + B_Request + " + " + B_Request + " " + AdsConstants.getAdmob_open_ads_back(context));

            if (isLoadingAd || isAdAvailable()) {
                return;
            }

            isLoadingAd = true;
            AdManagerAdRequest request = new AdManagerAdRequest.Builder().build();
            AppOpenAd.load(
                context,
                /*admobOpenAdReloadId*/AdsConstants.getAdmob_open_ads_back(context),
                request,
                AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT,
                new AppOpenAd.AppOpenAdLoadCallback() {
                    /**
                     * Called when an app open ad has loaded.
                     *
                     * @param ad the loaded app open ad.
                     */
                    @Override
                    public void onAdLoaded(AppOpenAd ad) {
                        Bundle bundle = new Bundle();
                        bundle.putString(B_Load, B_Load);
                        analytics().logEvent(openAds, bundle);

                        Log.e("msg", " - - - - - - - - - - " + openAds + " + " + B_Load + " + " + B_Load + " " + AdsConstants.getAdmob_open_ads_back(context));
                        appOpenAd = ad;
                        isLoadingAd = false;

                        loadTime = (new Date()).getTime();

                        Log.d(TAG, "reloadOpenAd onAdLoaded.");

                    }


                    @Override
                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        Bundle bundle = new Bundle();
                        bundle.putString(B_Fail_Load, B_Fail_Load);
                        analytics().logEvent(openAds, bundle);

                        Log.e("msg", " - - - - - - - - - - " + openAds + " + " + B_Fail_Load + " + " + B_Fail_Load + " " + AdsConstants.getAdmob_open_ads_back(context));
                        isLoadingAd = false;

                        Log.d(TAG, "reloadOpenAd onAdFailedToLoad: " + loadAdError.getMessage());

                    }
                });
        }

        /**
         * Check if ad was loaded more than n hours ago.
         */
        private boolean wasLoadTimeLessThanNHoursAgo(long numHours) {
            long dateDifference = (new Date()).getTime() - loadTime;
            long numMilliSecondsPerHour = 3600000;
            return (dateDifference < (numMilliSecondsPerHour * numHours));
        }

        /**
         * Check if ad exists and can be shown.
         */
        private boolean isAdAvailable() {

            return appOpenAd != null && wasLoadTimeLessThanNHoursAgo(4);
        }


        private void showAdIfAvailable(@NonNull final Activity activity) {
            Log.d("AppOpen", "Resume getSHOW_OPEN_AD ------------------- " + PreferenceManager.Companion.getBooleanData(activity, PreferenceManager.Companion.getSHOW_OPEN_AD()));

            if (PreferenceManager.Companion.getBooleanData(activity, PreferenceManager.Companion.getSHOW_OPEN_AD())) {
                showAdIfAvailable(
                    activity,
                    () -> {

                        Log.d(TAG, "ONADSHOWCOMPLETE ------------------- ");
                    });
            }
        }


        private void showAdIfAvailable(
            @NonNull final Activity activity,
            @NonNull OnShowAdCompleteListener onShowAdCompleteListener) {
            // If the app open ad is already showing, do not show the ad again.
            if (isShowingAd) {
                Log.d(TAG, "The app open ad is already showing.");
                PreferenceManager.Companion.saveData(activity, PreferenceManager.Companion.getSHOW_OPEN_AD(), true);

                return;
            }

            // If the app open ad is not available yet, invoke the callback then load the ad.
            if (!isAdAvailable()) {
                Log.d(TAG, "The app open ad is not ready yet.");
                Log.d(TAG, "isAdAvailable------------" + activity);

                onShowAdCompleteListener.onShowAdComplete();
                loadAd(activity);
                return;
            }

            Log.d(TAG, "Will show ad.");

            appOpenAd.setFullScreenContentCallback(
                new FullScreenContentCallback() {
                    /** Called when full screen content is dismissed. */
                    @Override
                    public void onAdDismissedFullScreenContent() {
                        Bundle bundle = new Bundle();
                        bundle.putString(F_Dismiss, inResume);
                        analytics().logEvent(openAds, bundle);

                        Log.e("msg", " - - - - - - - - - - " + openAds + " + " + F_Dismiss + " + " + inResume);
                        appOpenAd = null;
                        isShowingAd = false;

                        PreferenceManager.Companion.saveData(activity, PreferenceManager.Companion.getSHOW_OPEN_AD(), true);

                        Log.d(TAG, "onAdDismissedFullScreenContent.");
                        //Toast.makeText(activity, "onAdDismissedFullScreenContent", Toast.LENGTH_SHORT).show();
                        onShowAdCompleteListener.onShowAdComplete();
                        loadAd(activity);
                        F_Show = "f_show";
                        F_Dismiss = "f_dismiss";
                        F_Impression = "f_impression";
                        F_Show_Fail = "f_show_fail";
                        F_Click = "f_click";
                    }

                    /** Called when fullscreen content failed to show. */
                    @Override
                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                        appOpenAd = null;
                        isShowingAd = false;

                        PreferenceManager.Companion.saveData(activity, PreferenceManager.Companion.getSHOW_OPEN_AD(), true);

                        Bundle bundle = new Bundle();
                        bundle.putString(F_Dismiss, inResume);
                        analytics().logEvent(openAds, bundle);

                        Log.e("msg", " - - - - - - - - - - " + openAds + " + " + F_Show_Fail + " + " + inResume + " Error : " + adError.getCode());
                        onShowAdCompleteListener.onShowAdComplete();
                        loadAd(activity);
                        F_Show = "f_show";
                        F_Dismiss = "f_dismiss";
                        F_Impression = "f_impression";
                        F_Show_Fail = "f_show_fail";
                        F_Click = "f_click";
                    }

                    /** Called when fullscreen content is shown. */
                    @Override
                    public void onAdShowedFullScreenContent() {
                        PreferenceManager.Companion.saveData(activity, PreferenceManager.Companion.getSHOW_OPEN_AD(), false);
                        Log.d(TAG, "onAdShowedFullScreenContent.");
                        Bundle bundle = new Bundle();
                        bundle.putString(F_Show, inResume);
                        analytics().logEvent(openAds, bundle);

                        Log.e("msg", " - - - - - - - - - - " + openAds + " + " + F_Show + " + " + inResume);
                    }

                    @Override
                    public void onAdClicked() {
                        super.onAdClicked();
                        Bundle bundle = new Bundle();
                        bundle.putString(F_Click, inResume);
                        analytics().logEvent(openAds, bundle);

                        Log.e("msg", " - - - - - - - - - - " + openAds + " + " + F_Click + " + " + inResume);
                    }

                    @Override
                    public void onAdImpression() {
                        super.onAdImpression();
                        Bundle bundle = new Bundle();
                        bundle.putString(F_Impression, inResume);
                        analytics().logEvent(openAds, bundle);

                        Log.e("msg", " - - - - - - - - - - " + openAds + " + " + F_Impression + " + " + inResume);
                    }
                });
            isShowingAd = true;
            appOpenAd.show(activity);
        }

        public void destroyAd() {

            appOpenAd = null;
        }
    }
}
