package com.example.admob.utils;

import android.content.Context;

import com.example.admob.R;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;

public class AdsConstants {

    public static FirebaseRemoteConfig remoteConfig = FirebaseRemoteConfig.getInstance();


    private static String isRemoveAds = "is_remove_ads";
    private static String admob_app_open = "admob_app_open";
    private static String back_admob_open_ads = "back_admob_open_ads";
    public static String is_openAdshow_on_resume = "is_openAdshow_on_resume";

    /**
     * This method is used to check the user has purchased the premium plan or not.
     * If this shared preference value isRemoveAds is true then no ads will load.
     */
    public static boolean isPremiumEnabled(Context context) {
        return PreferenceManager.Companion.getBooleanData(context, isRemoveAds);
    }

    public static String getAdmob_open_ads(Context context) {
        String admob_open_ads = "";
        if (PreferenceManager.Companion.getBooleanData(context, "veriify_test_ad")) {
            if (!remoteConfig.getString(admob_app_open).equals("")) {
                admob_open_ads = remoteConfig.getString(admob_app_open);
            } else {
                if (context != null) {
                    admob_open_ads = context.getString(R.string.admob_app_open);

                }
            }
        } else {
            admob_open_ads = "ca-app-pub-3940256099942544/3419835294";
        }
        return admob_open_ads;
    }

    public static String getAdmob_open_ads_back(Context context) {
        String admob_open_ads = "";
        if (PreferenceManager.Companion.getBooleanData(context, "veriify_test_ad")) {
            if (!remoteConfig.getString(back_admob_open_ads).equals("")) {
                admob_open_ads = remoteConfig.getString(back_admob_open_ads);
            } else {
                if (context != null) {
                    admob_open_ads = context.getString(R.string.admob_back_app_open);
                }
            }
        } else {
            admob_open_ads = "ca-app-pub-3940256099942544/3419835294";
        }
        return admob_open_ads;
    }
}
