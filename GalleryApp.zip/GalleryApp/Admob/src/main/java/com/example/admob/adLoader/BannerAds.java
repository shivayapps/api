package com.example.admob.adLoader;

import android.app.Activity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;

import com.example.admob.utils.PreferenceManager;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.firebase.analytics.FirebaseAnalytics;

public class BannerAds {
    public static AdView mAdView;
    private static final String TAG = BannerAds.class.getSimpleName();

    private static String F_Request = "f_request";
    private static String F_Load = "f_load";
    private static String F_Fail_Load = "f_fail_load";
    private static String F_Open = "f_open";
    private static String F_Dismiss = "f_dismiss";


    private static String F_Click = "f_click";


    private static String B_Request = "b_request";
    private static String B_Load = "b_load";
    private static String B_Fail_Load = "b_fail_load";


    private static String eventName = "Admob_Banner";

    public static void loadAdmob_BannerADs(final Activity activity,
                                           FrameLayout frameLayout, String admob_banner, String admob_back_banner, String back_id_required, String admob_banner_control, boolean isCollapsible, AdFinishedCallback adFinisdhedCallback, String activityName, FirebaseAnalytics analytics) {
        Log.w("msg", "Load Admob Banner " + admob_banner_control);

        F_Open = "f_open";
        F_Dismiss = "f_dismiss";

        F_Click = "f_click";
        if (activity != null) {
            Bundle bundle = new Bundle();
            bundle.putString(F_Request, activityName);
            if (analytics != null) {
                analytics.logEvent(eventName, bundle);

            }
            Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + F_Request + " + " + activityName + " ");
            mAdView = new AdView(activity);
            mAdView.setAdSize(getBannerAdsType(activity, admob_banner_control));
            mAdView.setAdUnitId(admob_banner);
            AdRequest adRequest;
            if (isCollapsible) {
                Bundle extras = new Bundle();
                extras.putString("collapsible", "bottom");
                mAdView.setBackgroundColor(activity.getResources().getColor(com.example.admob.R.color.white));
                adRequest = new AdRequest.Builder()
                    .addNetworkExtrasBundle(AdMobAdapter.class, extras).build();
            } else {
                adRequest = new AdRequest.Builder().build();
            }

            frameLayout.addView(mAdView);
            mAdView.loadAd(adRequest);
            mAdView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                    Bundle bundle = new Bundle();
                    bundle.putString(F_Load, activityName);
                    if (analytics != null) {
                        analytics.logEvent(eventName, bundle);
                    }
                    Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + F_Load + " + " + activityName + " ");

                    frameLayout.setVisibility(View.VISIBLE);
                    mAdView.setVisibility(View.VISIBLE);
                    if (adFinisdhedCallback != null) {
                        adFinisdhedCallback.adFinished();
                    }
                }

                @Override
                public void onAdOpened() {
                    super.onAdOpened();
                    Bundle bundle = new Bundle();
                    bundle.putString(F_Open, activityName);
                    if (analytics != null) {
                        analytics.logEvent(eventName, bundle);

                    }
                    Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + F_Open + " + " + activityName + " ");
                }



                @Override
                public void onAdClosed() {
                    super.onAdClosed();
                    Bundle bundle = new Bundle();
                    bundle.putString(F_Dismiss, activityName);
                    if (analytics != null) {
                        analytics.logEvent(eventName, bundle);
                    }
                    Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + F_Dismiss + " + " + activityName + " ");
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError errorCode) {
                    mAdView.setVisibility(View.GONE);
                    frameLayout.setVisibility(View.GONE);
                    Bundle bundle = new Bundle();
                    bundle.putString(F_Fail_Load, activityName);
                    if (analytics != null) {
                        analytics.logEvent(eventName, bundle);
                    }
                    Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + F_Fail_Load + " + " + activityName + " " + " Error : " + errorCode.getCode());
                    if (back_id_required.equals("true")) {
                        loadAdmob_BannerADsReLoad(activity, frameLayout, admob_back_banner, admob_banner_control, isCollapsible, adFinisdhedCallback, activityName, analytics);
                    }
                }

                @Override
                public void onAdClicked() {
                    PreferenceManager.Companion.saveData(activity, PreferenceManager.Companion.getSystemDialogOpened(), true);
                    Bundle bundle = new Bundle();
                    bundle.putString(F_Click, activityName);
                    if (analytics != null) {
                        analytics.logEvent(eventName, bundle);
                    }
                    Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + F_Click + " + " + activityName + " ");
                }

            });
        }
    }


    public interface AdFinishedCallback {
        void adFinished();

        void adFailedtoshow();
    }

    // This method is used to check the which type of banner ad should display to the user. (This value will come from firebase remote config)
    private static AdSize getBannerAdsType(Activity activity, String admobBannerType) {
        AdSize adSize;
        Log.e(TAG, "ad types for Screen " + admobBannerType);
        switch (admobBannerType) {
            case BANNER:
                adSize = AdSize.BANNER;
                break;
            case ADAPTIVE_BANNER:
                adSize = getAdaptiveAdsize(activity);
                break;
            case SMART_BANNER:
                adSize = AdSize.SMART_BANNER;
                break;
            case MEDIUM_BANNER:
                adSize = AdSize.LARGE_BANNER;
                break;
            case MEDIUM_RECTANGLE:
                adSize = AdSize.MEDIUM_RECTANGLE;
                break;
            default:
                throw new IllegalArgumentException("Not Valid ADMOB Banner Type");
        }
        Log.e(TAG, "BannerAdLoader---------------  getBannerAdsType" + admobBannerType);
        return adSize;
    }

    private static AdSize getAdaptiveAdsize(Activity activity) {
        Display display = activity.getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;

        int adWidth = (int) (widthPixels / density);


        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, adWidth);
    }

    public static void destroyAd() {
        if (mAdView != null) {
            mAdView.destroy();
        }
    }

    public static void resumeAd() {
        if (mAdView != null) {
            mAdView.resume();
        }
    }

    public static void pauseAd() {
        if (mAdView != null) {
            mAdView.pause();
        }
    }

    public static void loadAdmob_BannerADsReLoad(final Activity activity, FrameLayout frameLayout, String admob_back_banner, String admob_banner_control, boolean isCollapsible, AdFinishedCallback adFinisdhedCallback, String activityName, FirebaseAnalytics analytics) {
        F_Open = "b_open";
        F_Dismiss = "b_dismiss";
        F_Click = "b_click";
        Bundle bundle = new Bundle();
        bundle.putString(B_Request, activityName);
        if (analytics != null) {
            analytics.logEvent(eventName, bundle);

        }
        Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + B_Request + " + " + activityName + " ");
        mAdView = new AdView(activity);
        mAdView.setAdSize(getBannerAdsType(activity, admob_banner_control));
        mAdView.setAdUnitId(admob_back_banner);
        frameLayout.addView(mAdView);
        AdRequest adRequest;
        if (isCollapsible) {
            Bundle extras = new Bundle();
            extras.putString("collapsible", "bottom");
            mAdView.setBackgroundColor(activity.getResources().getColor(com.example.admob.R.color.white));
            adRequest = new AdRequest.Builder()
                .addNetworkExtrasBundle(AdMobAdapter.class, extras).build();
        } else {
            adRequest = new AdRequest.Builder().build();
        }
        mAdView.loadAd(adRequest);
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                Bundle bundle = new Bundle();
                bundle.putString(B_Load, activityName);
                if (analytics != null) {

                    analytics.logEvent(eventName, bundle);
                }
                Log.w("msg", "Admob  - - - - - - - - - " + eventName + " + " + B_Load + " + " + activityName + " ");

                frameLayout.setVisibility(View.VISIBLE);
                mAdView.setVisibility(View.VISIBLE);
                if (adFinisdhedCallback != null) {
                    adFinisdhedCallback.adFinished();
                }
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError errorCode) {
                Bundle bundle = new Bundle();
                bundle.putString(B_Fail_Load, activityName);
                if (analytics != null) {

                    analytics.logEvent(eventName, bundle);
                }

                Log.w("msg", "Admob  - - - - - - - - - " + eventName + " + " + B_Fail_Load + " + " + activityName + " " + " Error : " + errorCode.getCode());

                mAdView.setVisibility(View.GONE);
                frameLayout.setVisibility(View.GONE);
                if (adFinisdhedCallback != null) {
                    adFinisdhedCallback.adFailedtoshow();
                }
            }



            @Override
            public void onAdOpened() {
                super.onAdOpened();
                Bundle bundle = new Bundle();
                bundle.putString(F_Open, activityName);
                if (analytics != null) {
                    analytics.logEvent(eventName, bundle);
                }
                Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + F_Open + " + " + activityName + " ");
            }

            @Override
            public void onAdClicked() {
                Bundle bundle = new Bundle();
                bundle.putString(F_Click, activityName);
                if (analytics != null) {
                    analytics.logEvent(eventName, bundle);
                }
                Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + F_Click + " + " + activityName + " ");
                PreferenceManager.Companion.saveData(activity, PreferenceManager.Companion.getSystemDialogOpened(), true);
            }


            @Override
            public void onAdClosed() {
                super.onAdClosed();
                Bundle bundle = new Bundle();
                bundle.putString(F_Dismiss, activityName);
                if (analytics != null) {
                    analytics.logEvent(eventName, bundle);
                }
                Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + F_Dismiss + " + " + activityName + " ");
            }
        });
    }

    static final String BANNER = "banner";
    static final String ADAPTIVE_BANNER = "adaptive_banner";
    static final String SMART_BANNER = "smart_banner";
    static final String MEDIUM_BANNER = "medium_banner";
    static final String MEDIUM_RECTANGLE = "medium_rectangle";


}
