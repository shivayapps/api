package albums.gallery.photo.folder.picasa.app.web.gallery.startLikePro.Activity;

import static albums.gallery.photo.folder.picasa.app.web.gallery.FirebaseConfigHelper.remoteConfig;
import static albums.gallery.photo.folder.picasa.app.web.gallery.FirebaseConfigHelper.subscription_theme_color;

import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

import albums.gallery.photo.folder.picasa.app.web.gallery.FirebaseConfigHelper;
import albums.gallery.photo.folder.picasa.app.web.gallery.GoogleAnalyticsEvent;
import albums.gallery.photo.folder.picasa.app.web.gallery.R;
import albums.gallery.photo.folder.picasa.app.web.gallery.activities.MainActivity;
import albums.gallery.photo.folder.picasa.app.web.gallery.helpers.Config;
import albums.gallery.photo.folder.picasa.app.web.gallery.models.InAppPurchaseModel;
import albums.gallery.photo.folder.picasa.app.web.gallery.preference.PreferenceKeys;
import albums.gallery.photo.folder.picasa.app.web.gallery.service.CallAPIAppPurchase;
import albums.gallery.photo.folder.picasa.app.web.gallery.service.SubscriptionModel;
import albums.gallery.photo.folder.picasa.app.web.gallery.startLikePro.inappsubscription.IabHelper;
import albums.gallery.photo.folder.picasa.app.web.gallery.startLikePro.inappsubscription.IabResult;
import albums.gallery.photo.folder.picasa.app.web.gallery.startLikePro.inappsubscription.Inventory;
import albums.gallery.photo.folder.picasa.app.web.gallery.startLikePro.inappsubscription.Purchase;
import albums.gallery.photo.folder.picasa.app.web.gallery.startLikePro.inappsubscription.SkuDetails;
import retrofit2.Response;


public class SubScriptionActivity extends AppCompatActivity {
    String Tag = "msg";
    ImageView mi_button_next;
    RelativeLayout skip_lay, rel_start;
    TextView subscription_month_trial, intro_subscription_try_limitedversion, intro_subscription_text;
    static final int RC_REQUEST = 10001;
    IabHelper mHelper;
    ProgressBar progress;
    private ArrayList<SubscriptionModel> objKeyList = new ArrayList<>();

    String mDelaroySku = "";
    String mFirstChoiceSku = "";
    boolean mAutoRenewEnabled = false;
    boolean mSubscribedToDelaroy = false;
    private String mSelectedSubscriptionPeriod = "";
    private int REQ_FOR_QUERY_INVENTORY = 0;
    public static final int REQUEST_FOR_SKU_DETAIL = 1;
    public RelativeLayout background;
    public TextView start_like_a_pro;
    public TextView unlock_all_premium_themes;
    public TextView enjoy_app_without_coins;
    public TextView download_stickers_and_emojis;
    public TextView line1;
    public TextView line2;
    public TextView line3;
    public TextView unlock_all_premium;
    public ImageView intro_medal, close_sub;
    public LinearLayout linearLayout;
    public TextView ads_free;
    public TextView skip;
    private String isFrom = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_scription);
        findViewId();
        GetInAppPurchaseData_Service();
        isFrom = getIntent().getStringExtra("isFrom");

        close_sub = findViewById(R.id.close_sub);
        background = findViewById(R.id.background_);
        start_like_a_pro = findViewById(R.id.welcome_lay);
        unlock_all_premium_themes = findViewById(R.id.unlock_all_premium_themes);
        enjoy_app_without_coins = findViewById(R.id.enjoy_app_without_coins);
        download_stickers_and_emojis = findViewById(R.id.download_stickers_and_emojis);
        line1 = findViewById(R.id.line1);
        line2 = findViewById(R.id.line2);
        line3 = findViewById(R.id.line3);
        subscription_month_trial = findViewById(R.id.subscription_month_trial);
        intro_subscription_try_limitedversion = findViewById(R.id.intro_subscription_try_limitedversion);
        intro_medal = findViewById(R.id.intro_medal);
        unlock_all_premium = findViewById(R.id.unlock_all_premium);
        ads_free = findViewById(R.id.ads_free);
        intro_subscription_text = findViewById(R.id.intro_subscription_text);
        skip = findViewById(R.id.skip);
        // Themeing
//        boolean theme = new Config(this).getTheme();
        String theme = remoteConfig.getString(subscription_theme_color);
        GoogleAnalyticsEvent.logAdapter(GoogleAnalyticsEvent.subscription, GoogleAnalyticsEvent.view, "from " + isFrom);

        if (!theme.equals("dark")) {
            background.setBackgroundResource(R.drawable.bg_light);
            intro_medal.setImageResource(R.drawable.medal_light);
            start_like_a_pro.setTextColor(getResources().getColor(R.color.dark_));
            unlock_all_premium_themes.setTextColor(getResources().getColor(R.color.dark_));
            enjoy_app_without_coins.setTextColor(getResources().getColor(R.color.dark_));
            download_stickers_and_emojis.setTextColor(getResources().getColor(R.color.dark_));
            line1.setTextColor(getResources().getColor(R.color.dark_));
            line2.setTextColor(getResources().getColor(R.color.dark_));
            line3.setTextColor(getResources().getColor(R.color.dark_));
            subscription_month_trial.setTextColor(getResources().getColor(R.color.dark_));
            intro_subscription_try_limitedversion.setTextColor(getResources().getColor(R.color.dark_));
            unlock_all_premium.setTextColor(getResources().getColor(R.color.dark_));
            ads_free.setTextColor(getResources().getColor(R.color.dark_));
            intro_subscription_text.setTextColor(getResources().getColor(R.color.dark_));
            skip.setTextColor(getResources().getColor(R.color.black));
            try {
                close_sub.setImageDrawable(getResources().getDrawable(R.drawable.ic_back));
            } catch (Resources.NotFoundException e) {
                close_sub.setImageResource(R.drawable.ic_back);
            }
        } else {
            background.setBackgroundResource(R.drawable.bg_dark);
            intro_medal.setImageResource(R.drawable.medal_dark);
            start_like_a_pro.setTextColor(getResources().getColor(R.color.light_));
            unlock_all_premium_themes.setTextColor(getResources().getColor(R.color.light_));
            enjoy_app_without_coins.setTextColor(getResources().getColor(R.color.light_));
            download_stickers_and_emojis.setTextColor(getResources().getColor(R.color.light_));
            line1.setTextColor(getResources().getColor(R.color.light_));
            line2.setTextColor(getResources().getColor(R.color.light_));
            line3.setTextColor(getResources().getColor(R.color.light_));
            subscription_month_trial.setTextColor(getResources().getColor(R.color.light_));
            intro_subscription_try_limitedversion.setTextColor(getResources().getColor(R.color.light_));
            unlock_all_premium.setTextColor(getResources().getColor(R.color.light_));
            ads_free.setTextColor(getResources().getColor(R.color.light_));
            intro_subscription_text.setTextColor(getResources().getColor(R.color.light_));
            skip.setTextColor(getResources().getColor(R.color.white));
            try {
                close_sub.setImageDrawable(getResources().getDrawable(R.drawable.ic_back_dark));
            } catch (Resources.NotFoundException e) {
                close_sub.setImageResource(R.drawable.ic_back_dark);
            }
        }
        if (isItFirstTime()) {
            close_sub.setVisibility(View.GONE);
            skip_lay.setVisibility(View.VISIBLE);
            intro_subscription_try_limitedversion.setVisibility(View.VISIBLE);

        } else {
            close_sub.setVisibility(View.VISIBLE);
            skip_lay.setVisibility(View.GONE);
            intro_subscription_try_limitedversion.setVisibility(View.GONE);

        }
        onClick();

    }

    private void onClick() {
        mi_button_next.setOnClickListener(new PayClick());
        intro_subscription_try_limitedversion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GoogleAnalyticsEvent.logAdapter(
                    GoogleAnalyticsEvent.subscription,
                    GoogleAnalyticsEvent.click,
                    GoogleAnalyticsEvent.tryLimitedVersion);
                nextClick();
            }
        });
        skip_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GoogleAnalyticsEvent.logAdapter(
                    GoogleAnalyticsEvent.subscription,
                    GoogleAnalyticsEvent.click,
                    GoogleAnalyticsEvent.skip);
                nextClick();
            }
        });
        close_sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GoogleAnalyticsEvent.logAdapter(
                    GoogleAnalyticsEvent.subscription,
                    GoogleAnalyticsEvent.click,
                    GoogleAnalyticsEvent.closeButton);

                nextClick();
            }
        });
        rel_start.setOnClickListener(new PayClick());
        intro_subscription_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Config(SubScriptionActivity.this).saveData(SubScriptionActivity.this, PreferenceKeys.SystemDialogOpened, true);
                GoogleAnalyticsEvent.logAdapter(
                    GoogleAnalyticsEvent.subscription,
                    GoogleAnalyticsEvent.termsPrivacy + " " + isFrom,
                    GoogleAnalyticsEvent.subs_clicked
                );
                try {
                    Intent goPolicy = new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.privacy_policy)));
                    goPolicy.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(goPolicy);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(SubScriptionActivity.this, R.string.No_application_request_install_web_browser, Toast.LENGTH_LONG).show();
                } catch (Exception e1) {
                    Toast.makeText(SubScriptionActivity.this, R.string.Error_Try_Again_Later, Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void findViewId() {
        progress = findViewById(R.id.progressbar);
        skip_lay = findViewById(R.id.skip_lay);
        rel_start = findViewById(R.id.rel_start);
        mi_button_next = findViewById(R.id.mi_button_next);
        intro_subscription_text = findViewById(R.id.intro_subscription_text);
        subscription_month_trial = findViewById(R.id.subscription_month_trial);
        intro_subscription_try_limitedversion = findViewById(R.id.intro_subscription_try_limitedversion);
    }

    private class PayClick implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            GoogleAnalyticsEvent.logAdapter(
                GoogleAnalyticsEvent.subscription,
                GoogleAnalyticsEvent.subs_clicked,
                GoogleAnalyticsEvent.freeTrial
            );
            new Config(SubScriptionActivity.this).saveData(SubScriptionActivity.this,PreferenceKeys.SystemDialogOpened,true);
            payNow();
        }
    }

    private void nextClick() {

            startActivity(new Intent(SubScriptionActivity.this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            finish();

    }


//    void complain(String message) {
//        Log.w(Tag, "**** Delaroy Error: " + message);
//        alert("Error: " + message);
//    }

    void alert(String message) {
        try {
            if (!isFinishing()) {
                AlertDialog.Builder bld = new AlertDialog.Builder(SubScriptionActivity.this);
                bld.setMessage(message);
//                 bld.setNeutralButton("OK", null);
                bld.setNeutralButton(R.string.ok, null);
                Log.w(Tag, "inAppPurchase Showing alert dialog: " + message);
                bld.create().show();
            }
        } catch (WindowManager.BadTokenException e) {

        }
    }

    private void initINP() {
        mHelper = new IabHelper(SubScriptionActivity.this, objKeyList.get(0).getBase64EncodedPublicKey(), SubScriptionActivity.this);
        mHelper.enableDebugLogging(true);
        try {
            new Config(SubScriptionActivity.this).saveDataSubString(SubScriptionActivity.this, PreferenceKeys.start_like_pro, objKeyList.get(0).getInappPurchaseKey());
            mHelper.startSetup(new IabHelper.OnIabSetupFinishedListener() {
                public void onIabSetupFinished(IabResult result) {
                    Log.w(Tag, "inAppPurchase Setup finished.");

                    if (!result.isSuccess()) {
                        // Oh noes, there was a problem.
//                        complain("Problem setting up in-app billing: " + result);
                        new Config(SubScriptionActivity.this).saveDataSubBool(SubScriptionActivity.this, PreferenceKeys.in_app_subscription_setup_failed, true);
                        return;
                    }
                    new Config(SubScriptionActivity.this).saveDataSubBool(SubScriptionActivity.this, PreferenceKeys.in_app_subscription_setup_failed, false);


                    // Have we been disposed of in the meantime? If so, quit.
                    if (mHelper == null) return;

                    Log.i(Tag, "inAppPurchase request for check Query inventory is active or not");
                    REQ_FOR_QUERY_INVENTORY = REQUEST_FOR_SKU_DETAIL;
//                List<String> itemSku = new ArrayList<>();
                    List<String> subSku = new ArrayList<>();
                    subSku.add(objKeyList.get(0).getInappPurchaseKey());
                    try {
                        mHelper.queryInventoryAsync(true, subSku, subSku, mQotInventoryListener);
                    } catch (IabHelper.IabAsyncInProgressException e) {
                        // e.printStackTrace();
                    }
                }
            });
        } catch (Exception e) {
            // e.printStackTrace();
        }
    }

    // Callback for when a purchase is finished
    IabHelper.OnIabPurchaseFinishedListener mPurchaseFinishedListener = new IabHelper.OnIabPurchaseFinishedListener() {
        public void onIabPurchaseFinished(IabResult result, Purchase purchase) {
            Log.w(Tag, "inAppPurchase Purchase finished: " + result + ", purchase: " + purchase);
            // if we were disposed of in the meantime, quit.
            if (mHelper == null) return;
            if (result.isFailure()) {
                GoogleAnalyticsEvent.logAdapter(
                    GoogleAnalyticsEvent.subscription,
                    GoogleAnalyticsEvent.purchaseFailed, isFrom
                );
                showErrorToast();
//            complain("Error purchasing: " + result);
                return;
            }
            if (!verifyDeveloperPayload(purchase)) {
                showErrorToast();
//                complain("Error purchasing. Authenticity verification failed.");
                return;
            }
            Log.w(Tag, "inAppPurchase Purchase successful.");
            if (purchase.getSku().equals(objKeyList.get(0).getInappPurchaseKey())) {
                GoogleAnalyticsEvent.logAdapter(
                    GoogleAnalyticsEvent.subscription,
                    GoogleAnalyticsEvent.freeTrial,
                    GoogleAnalyticsEvent.purchasedSuccessful
                );
                // bought the rasbita subscription
                Log.w(Tag, "inAppPurchase Gallery subscription purchased.");
                alert("Thank you for subscribing to Gallery!");
                mSubscribedToDelaroy = true;
                mAutoRenewEnabled = purchase.isAutoRenewing();
                new Config(SubScriptionActivity.this).saveDataSubBool(SubScriptionActivity.this, FirebaseConfigHelper.is_remove_ads, mAutoRenewEnabled);
                mDelaroySku = purchase.getSku();
            } else {
                GoogleAnalyticsEvent.logAdapter(
                    GoogleAnalyticsEvent.subscription,
                    GoogleAnalyticsEvent.freeTrial,
                    GoogleAnalyticsEvent.didNotPurchased
                );
            }
        }
    };

    // Called when consumption is complete
    IabHelper.OnConsumeFinishedListener mConsumeFinishedListener = new IabHelper.OnConsumeFinishedListener() {
        public void onConsumeFinished(Purchase purchase, IabResult result) {
            Log.w(Tag, "inAppPurchase Consumption finished. Purchase: " + purchase + ", result: " + result);
        }
    };

    boolean verifyDeveloperPayload(Purchase p) {
        Log.w(Tag, "Purchase_time== " + p.getPurchaseTime());

        return true;
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (mHelper == null) return;
        Log.w(Tag, "OnActivityResult===" + requestCode + "--" + resultCode);
        if (!mHelper.handleActivityResult(requestCode,
            resultCode, data)) {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private void payNow() {
        String payload = "";
        if (!FirebaseConfigHelper.getIsAppAdFree(SubScriptionActivity.this)) {
            try {
                if (FirebaseConfigHelper.isNetworkConnected(SubScriptionActivity.this)
                    && !new Config(SubScriptionActivity.this).getBooleanData(SubScriptionActivity.this, PreferenceKeys.in_app_subscription_setup_failed, false)) {
                    if (mHelper != null) {
                        if (TextUtils.isEmpty(mSelectedSubscriptionPeriod)) {
                            // The user has not changed from the default selection
                            mSelectedSubscriptionPeriod = mFirstChoiceSku;
                        }
                        Log.w(Tag, "inAppPurchase mSelectedSubscriptionPeriod== " + mSelectedSubscriptionPeriod);
                        List<String> oldSkus = null;
                        if (!TextUtils.isEmpty(mDelaroySku)
                            && !mDelaroySku.equals(mSelectedSubscriptionPeriod)) {
                            // The user currently has a valid subscription, any purchase action is going to
                            // replace that subscription
                            oldSkus = new ArrayList<String>();
                            oldSkus.add(mDelaroySku);
                        }
                        try {
                            mHelper.launchPurchaseFlow(SubScriptionActivity.this, mSelectedSubscriptionPeriod, IabHelper.ITEM_TYPE_SUBS,
                                oldSkus, RC_REQUEST, mPurchaseFinishedListener, payload);
                        } catch (IabHelper.IabAsyncInProgressException e) {
//                            complain("Error launching purchase flow. Another async operation in progress.");
//                            showErrorToast();
                        }
//                        mSelectedSubscriptionPeriod = "";
//                        mFirstChoiceSku = "";
                    } else {
                        Toast.makeText(SubScriptionActivity.this, R.string.something_went_wrong_Please_Try_Again_Later, Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(SubScriptionActivity.this, R.string.network_try_again, Toast.LENGTH_SHORT).show();

                }
            } catch (Exception e) {
                Toast.makeText(SubScriptionActivity.this, R.string.something_went_wrong_Please_Try_Again_Later, Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(SubScriptionActivity.this, R.string.package_already_bought, Toast.LENGTH_SHORT).show();
        }
    }

    private IabHelper.QueryInventoryFinishedListener mQotInventoryListener = new IabHelper.QueryInventoryFinishedListener() {
        @Override
        public void onQueryInventoryFinished(IabResult result, Inventory inv) {
            try {
                Log.d(Tag, "inAppPurchase mQotInventoryListener Query inventory finished.");
                handleQueryInventoryFinishResult(result, inv, REQ_FOR_QUERY_INVENTORY);
            } catch (Exception e) {
                // e.printStackTrace();
            }
        }
    };

    private void handleQueryInventoryFinishResult(IabResult result, Inventory inventory, int requestForQueryInventory) {
        try {
            // Have we been disposed of in the meantime? If so, quit.
            if (mHelper == null) return;
            // Is it a failure?
            if (result.isFailure()) {
                Log.e(Tag, "inAppPurchase mQotInventoryListener Failed to query inventory: " + result);
                return;
            }
            Log.d(Tag, "inAppPurchase mQotInventoryListener Query inventory was successful.");
            switch (requestForQueryInventory) {
                case REQUEST_FOR_SKU_DETAIL:
                    try {
                        SkuDetails monthlySKU = inventory.getSkuDetails(objKeyList.get(0).getInappPurchaseKey());
                        if (monthlySKU != null) {
                            String price = monthlySKU.getPrice();
                            Log.w(Tag, "inAppPurchase SkuDetails are below......");
                            Log.w(Tag, "inAppPurchase monthlySKU.getSku::->" + monthlySKU.getSku());
                            Log.w(Tag, "inAppPurchase monthlySKU.getType::->" + monthlySKU.getType());
                            Log.w(Tag, "inAppPurchase monthlySKU.getPrice: " + monthlySKU.getPrice());
                            Log.w(Tag, "inAppPurchase monthlySKU.getPriceAmountMicros::->" + monthlySKU.getPrice());
                            Log.w(Tag, "inAppPurchase monthlySKU.getTitle::->" + monthlySKU.getTitle());
                            Log.w(Tag, "inAppPurchase monthlySKU.getDescription::->" + monthlySKU.getDescription());
                            Log.w(Tag, "inAppPurchase monthlySKU.getDescription::->" + monthlySKU.getPriceCurrencyCode());
                            Log.w(Tag, "inAppPurchase monthlySKU price : " + price);

                            new Config(SubScriptionActivity.this).saveDataSubString(SubScriptionActivity.this, "start_like_pro_price", price);
                            subscription_month_trial.setText(price + " " + getString(R.string.subscription_month_trial1));

                        } else {
                            Log.e(Tag, "inAppPurchase yearlySKU details is null");
                        }
                    } catch (Exception e) {
                    }
                    break;
            }

        } catch (Exception e) {
        }
    }

    private void GetInAppPurchaseData_Service() {
//        progress.setVisibility(View.VISIBLE);
        CallAPIAppPurchase.callApiDataForIAP(SubScriptionActivity.this, new CallAPIAppPurchase.callBack() {
            @Override
            public void onLoaded(Response<InAppPurchaseModel> response) {
                try {
                    if (response != null) {
                        ArrayList<InAppPurchaseModel> objInAppPurchaseModelList = response.body().getObjInAppKeyList();
                        Log.w(Tag, "objInAppPurchaseModelList== " + objInAppPurchaseModelList);
                        if (objInAppPurchaseModelList.size() > 0) {
                            for (int i = 0; i < objInAppPurchaseModelList.size(); i++) {
                                //                            JSONObject c = keyList.getJSONObject(i);
                                String id = objInAppPurchaseModelList.get(i).getId();
                                String name = objInAppPurchaseModelList.get(i).getName();
                                String key = objInAppPurchaseModelList.get(i).getInappPurchaseKey();
                                String gallery_base64EncodedPublicKey = objInAppPurchaseModelList.get(i).getGallery_base64EncodedPublicKey();
                                FirebaseConfigHelper.logMethod("Subscription Act   ", "key ---" + key + "gallery_base64EncodedPublicKey --- " + gallery_base64EncodedPublicKey);

                                objKeyList.add(new SubscriptionModel(key, gallery_base64EncodedPublicKey));

                            }
                            if (objKeyList.size() > 0) {
                                Log.w(Tag, "pro_app_key_from_server== " + objKeyList.get(0).getInappPurchaseKey());
                                initINP();
                                mSelectedSubscriptionPeriod = objKeyList.get(0).getInappPurchaseKey();
                            } else {
                                loadAgainData();
                            }
                        } else {
                            objKeyList.add(new SubscriptionModel(FirebaseConfigHelper.pro_app_key, FirebaseConfigHelper.gallery_base64EncodedPublicKey));
                            Log.w(Tag, "pro_app_key_from_app2== " + objKeyList.get(0).getInappPurchaseKey());
                            initINP();
                            mSelectedSubscriptionPeriod = objKeyList.get(0).getInappPurchaseKey();
                        }
                    } else {
                        loadAgainData();
                    }
                } catch (Exception e) {
                    loadAgainData();
                }
                progress.setVisibility(View.GONE);
            }


            @Override
            public void onServerError() {
                loadAgainData();
            }

            @Override
            public void onNetworkError() {
                loadAgainData();
            }
        });
    }

    private void loadAgainData() {
        progress.setVisibility(View.GONE);
        objKeyList.add(new SubscriptionModel(FirebaseConfigHelper.pro_app_key, FirebaseConfigHelper.gallery_base64EncodedPublicKey));
        FirebaseConfigHelper.logMethod(
            "Subscription loadAgainData   ",
            "key ---" + FirebaseConfigHelper.pro_app_key + "gallery_base64EncodedPublicKey --- " + FirebaseConfigHelper.gallery_base64EncodedPublicKey
        );
        initINP();
        mSelectedSubscriptionPeriod = objKeyList.get(0).getInappPurchaseKey();
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(SubScriptionActivity.this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        finish();
    }

    void showErrorToast() {
        Toast.makeText(SubScriptionActivity.this, "Something Went Wrong , Please Try Again Later...", Toast.LENGTH_SHORT).show();
    }

    public boolean isItFirstTime() {

        if (getBooleanData(SubScriptionActivity.this, "firstTime", true)) {
            saveData(SubScriptionActivity.this, "firstTime", false);
            return true;
        } else {
            return false;
        }
    }

    public boolean getBooleanData(Context context, String key, boolean def) {

        try {
            if (context != null)
                return context.getSharedPreferences(PreferenceKeys.THEME_PREFS, Context.MODE_PRIVATE).getBoolean(key, def);
            else
                return false;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean saveData(Context context, String key, boolean val) {
        if (context == null)
            return false;
        context.getSharedPreferences(PreferenceKeys.THEME_PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(key, val)
            .apply();
        return false;
    }
}
