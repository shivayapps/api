//package albums.gallery.photo.folder.picasa.app.web.gallery
//
//import androidx.appcompat.app.AppCompatActivity
//import android.os.Bundle
//import androidx.recyclerview.widget.GridLayoutManager
//import kotlinx.android.synthetic.main.activity_donate.*
//
//class DonateActivity : AppCompatActivity() {
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_donate)
//
//
//
//    }
//}
