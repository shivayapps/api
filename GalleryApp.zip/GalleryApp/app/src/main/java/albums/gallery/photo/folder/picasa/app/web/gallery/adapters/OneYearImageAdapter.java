package albums.gallery.photo.folder.picasa.app.web.gallery.adapters;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.qintong.library.InsLoadingView;

import albums.gallery.photo.folder.picasa.app.web.gallery.GoogleAnalyticsEvent;
import albums.gallery.photo.folder.picasa.app.web.gallery.views.OneStatusActivity;
import albums.gallery.photo.folder.picasa.app.web.gallery.R;
import albums.gallery.photo.folder.picasa.app.web.gallery.models.GalleryImageModel;

import java.util.ArrayList;

import jp.wasabeef.glide.transformations.BlurTransformation;

import static com.qintong.library.InsLoadingView.Status.LOADING;
import static com.qintong.library.InsLoadingView.Status.UNCLICKED;


public class OneYearImageAdapter extends RecyclerView.Adapter<OneYearImageAdapter.ViewHolder> {
    public static ArrayList<GalleryImageModel> oneYearOldImages;

    Context context;
    private LayoutInflater inflater;
    Activity activity;
    SharedPreferences.Editor editor;
    SharedPreferences sharedPref;


    public OneYearImageAdapter(Context context, Activity activity, ArrayList<GalleryImageModel> oneYearOldImages) {
        this.context = context;
        try {
            this.oneYearOldImages = oneYearOldImages;
        } catch (Exception e) {

        }
        this.inflater = LayoutInflater.from(context);
        this.activity = activity;
        sharedPref = this.context.getSharedPreferences("Prefs", Context.MODE_PRIVATE);
        editor = sharedPref.edit();
    }

    @NonNull
    @Override
    public OneYearImageAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.status_item_view, parent, false);
        return new OneYearImageAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OneYearImageAdapter.ViewHolder holder, @SuppressLint("RecyclerView") int position) {


        if (sharedPref.getInt("primary_color_2", -1) == -1) {
            holder.status_text.setTextColor(Color.parseColor("#000000"));
        } else {
            holder.status_text.setTextColor(Color.parseColor("#ffffff"));
        }

        try {
            if (oneYearOldImages.size() > 0) {                   // Change by parth - v1.0.30

                Glide.with(context).load(oneYearOldImages.get(0).getPath()).transform(new CenterCrop(), new BlurTransformation(7)).into(holder.imageView1);
                holder.status_text.setText("1 Year");
            }
        } catch (Exception e) {

        }


        holder.status_itemview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                try {
//                    Intent inew = new Intent(context, OneStatusViewAct.class);
//                    inew.putExtra("status_view1", position);
//                    context.startActivity(inew);
//                } catch (Exception e) {
//
//                }

            }
        });

        holder.imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (holder.imageView1.getStatus()) {

                    case UNCLICKED:
                        holder.imageView1.setStatus(LOADING);
                        // By Parth Crash Solving 1.0.35 23
                        try {
                            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        GoogleAnalyticsEvent.logAdapter(GoogleAnalyticsEvent.mainScreen,GoogleAnalyticsEvent.story,GoogleAnalyticsEvent.oneYear);
                                        Intent inew = new Intent(context, OneStatusActivity.class);
                                        inew.putExtra("status_view1", position);
                                        context.startActivity(inew);
                                        holder.imageView1.setStatus(UNCLICKED);
                                    } catch (Exception e) {

                                    }
                                }
                            }, 1700);
                        } catch (Exception e) {

                        }

                        break;
                    case LOADING:
//                        holder.imageView1.setStatus(CLICKED);
                        break;
                    case CLICKED:
                        holder.imageView1.setStatus(UNCLICKED);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return 1;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        InsLoadingView imageView1;
        TextView status_text;
        RelativeLayout status_itemview;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView1 = itemView.findViewById(R.id.imageView1);
            status_itemview = itemView.findViewById(R.id.status_itemview);
            status_text = itemView.findViewById(R.id.status_text);
        }
    }
}
