package albums.gallery.photo.folder.picasa.app.web.gallery.models

data class ThumbnailSection(val title: String) : ThumbnailItem()
