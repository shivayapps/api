package albums.gallery.photo.folder.picasa.app.web.gallery.dailyNotification

import albums.gallery.photo.folder.picasa.app.web.gallery.models.GalleryData
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.MediaStore
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.*


class NotificationReceiver : BroadcastReceiver() {
    override fun onReceive(p0: Context?, p1: Intent?) {
        val notificationHelper = NotificationHelper(p0!!)
        notificationHelper.createNotificationChannel()
        if(p1 != null) {
            dailynotification(p0)
            Log.d("PICTURES_01","------------------" + p1.getStringExtra("arrayList")!!)
            notificationHelper.triggerNotification( p1.getStringExtra("image_path")!!, p1.getStringExtra("image_date")!!, p1.getIntExtra("year_",-1)!!, p1.getStringExtra("arrayList")!!)
        }
    }

    fun dailynotification(context: Context) {
        Log.d("DAILY_NOT","DAILYNOTIFICATION---------------SECOND")
        val path: String;
        val date: String;
        val year: Int;
        val calendar: Calendar = Calendar.getInstance()
        calendar.set(Calendar.HOUR_OF_DAY, 15)
        calendar.set(Calendar.MINUTE,46)
        calendar.set(Calendar.SECOND, 0)
        if (calendar.getTime().compareTo(Date()) < 0) calendar.add(Calendar.DAY_OF_MONTH, 1)

        if (getPictures(5,context) != null) {
            path = getPictures(5,context)?.get(0)?.path!!
            date = getPictures(5,context)?.get(0)?.date!!
            year = getPictures(5,context)?.get(0)?.year!!
        } else if (getPictures(3,context) != null) {
            path = getPictures(3,context)?.get(0)?.path!!
            date = getPictures(3,context)?.get(0)?.date!!
            year = getPictures(3,context)?.get(0)?.year!!
        } else if (getPictures(1,context) != null) {
            path = getPictures(1,context)?.get(0)?.path!!
            date = getPictures(1,context)?.get(0)?.date!!
            year = getPictures(1,context)?.get(0)?.year!!
        } else {
            path = "NOT_DEFINED"
            date = "NOT_DEFINED"
            year = -1
        }
        val dataToPass = Gson().toJson(getPictures(0,context))

        val intent = Intent(context.applicationContext, NotificationReceiver::class.java)
        intent.putExtra("image_path", path)
        intent.putExtra("image_date", date)
        intent.putExtra("year_", year)
        intent.putExtra("arrayList",dataToPass)
        val pendingIntent = PendingIntent.getBroadcast(
            context.applicationContext,
            22,
            intent,
            /*PendingIntent.FLAG_UPDATE_CURRENT*/
            PendingIntent.FLAG_MUTABLE
        )

        val alarmManager = context.getSystemService(AppCompatActivity.ALARM_SERVICE) as AlarmManager

        if (path != "NOT_DEFINED") {
            alarmManager?.setExact(
                AlarmManager.RTC_WAKEUP,
                calendar.getTimeInMillis(),
                pendingIntent
            )
        }
    }

    private fun getPictures(yearAgo: Int, context: Context): ArrayList<GalleryData>? {
        val arr: ArrayList<GalleryData> = ArrayList<GalleryData>()
        try {

            val calendar: Calendar = Calendar.getInstance()
            val currentDate: Date = calendar.time

            calendar.add(Calendar.YEAR, -yearAgo)
            val yearBeforeDate: Date = calendar.time
            val formatter: DateFormat = SimpleDateFormat("dd/MM/yyyy")
            val yearBeforeDate0 = formatter.parse(formatter.format(yearBeforeDate))
            Log.d("DATE_FORMATED", "1---" + yearBeforeDate0.toString())

            calendar.add(Calendar.DATE, -35)
            val yearBeforeDateTemp = calendar.time
            val yearBeforeDate1 = formatter.parse(formatter.format(yearBeforeDateTemp))
            Log.d("DATE_FORMATED", "2---" + yearBeforeDate1.toString())

            val cursor = context?.contentResolver?.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                arrayOf(
                    MediaStore.Images.Media._ID,
                    MediaStore.Images.Media.DATA,
                    MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
                    MediaStore.Images.Media.DATE_TAKEN,
                    MediaStore.Images.Media.MIME_TYPE,
                    MediaStore.Images.Media.DATE_ADDED
                ),
                MediaStore.Images.Media.DATE_TAKEN + "<= ? AND " + MediaStore.Images.Media.DATE_TAKEN + ">= ?",
                arrayOf("" + yearBeforeDate0.time, "" + yearBeforeDate1.time),
                MediaStore.Images.Media.DATE_TAKEN + " " + "ASC",
                null
            )
            if (cursor == null) Log.d("IMAGES_NOTIFICATION", "NO IMAGES")
            else {
                Log.d("IMAGES_NOTIFICATION", "___ " + cursor.count + " param + " + yearAgo);

                if (cursor.count == 0) {
                    return null
                }
                try {
                    while (cursor.moveToNext()) {
                        Log.d("IMAGES_NOTIFICATION", cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)) + " param + " + yearAgo)
                        val absolutePath = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA))
                        val miliSeconds = (cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))).toLong()
                        arr.add(
                            GalleryData(
                                absolutePath,
                                DateFormat.getDateInstance().format(miliSeconds),
                                yearAgo
                            )
                        )
                    }
                } catch (e: Exception) {

                } finally {
                    // By Parth Crash Solving 1.0.35 21
                    cursor.close()
                }
            }
        } catch (e: Exception) {
            Log.d("IMAGES_NOTIFICATION", "___Encountered Error" + e.stackTraceToString() + " param + " + yearAgo);

        }
        return arr
    }
}
