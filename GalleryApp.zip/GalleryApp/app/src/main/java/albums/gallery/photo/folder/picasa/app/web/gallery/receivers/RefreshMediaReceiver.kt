package albums.gallery.photo.folder.picasa.app.web.gallery.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import album.gallery.photo.folder.picasa.app.web.gallery.commons.helpers.REFRESH_PATH
import albums.gallery.photo.folder.picasa.app.web.gallery.extensions.addPathToDB

class RefreshMediaReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val path = intent.getStringExtra(REFRESH_PATH) ?: return
        context.addPathToDB(path)
    }
}
