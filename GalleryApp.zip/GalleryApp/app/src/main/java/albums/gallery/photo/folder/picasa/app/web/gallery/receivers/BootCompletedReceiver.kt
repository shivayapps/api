package albums.gallery.photo.folder.picasa.app.web.gallery.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import album.gallery.photo.folder.picasa.app.web.gallery.commons.helpers.ensureBackgroundThread
import albums.gallery.photo.folder.picasa.app.web.gallery.extensions.updateDirectoryPath
import albums.gallery.photo.folder.picasa.app.web.gallery.helpers.MediaFetcher

class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        ensureBackgroundThread {
            MediaFetcher(context).getFoldersToScan().forEach {
                context.updateDirectoryPath(it)
            }
        }
    }
}
