package albums.gallery.photo.folder.picasa.app.web.gallery.preference;

public class PreferenceKeys {


    public static String CONTACTS_SUGGESTION_ENABLE = "contacts_suggestion_enable";
    public static String LOAD_PREDICTION = "load_prediction";
    public static String LOAD_DEFAULT_THEME = "load_default_theme_2";
    public static String AUTO_CURRACT_ENABLE = "auto_curract_enable";
    public static String APP_VERSION_CODE = "app_version_code";
    public static String VERSION_CODE = "version_code";
    public static String APP_PKG_NAME = "app_pkg_name";

    public static String PRIVACY_DIALOG_CHECK = "privacy_check";
    public static String UPDATE_COUNTER = "Update_Counter";
    public static String APP_OPEN_LOG_TAG = "app_setup";
    public static String KEYBOARD_SET_TAG = "isKeyboardSet";
    public static String STAP_1_COMPLETE = "app_setup_Step1_Complete";
    public static String STAP_2_COMPLETE = "isKeyboardSet";
    public static String Type = "type";
    public static String THEME_MODEL_KEY = "Theme_model_key";
    public static String THEME_PREFS = "THEME_PREFS";
    public static String THEME_AD_PREFS = "Theme_Ad_Prefs";
    public static String IMAGE_PREVIEW_COLOR = "image_preview_color";
    public static String SHOW_OPEN_AD = "show_open_ad";
    public static String VERIFY_TEST_AD = "veriify_test_ad";


    public static String start_like_pro = "start_like_pro";
    public static String in_app_subscription_setup_failed = "in_app_subscription_setup_failed";
    public static String SystemDialogOpened = "SystemDialogOpened";
    public static String openAdVar = "openAdVar";

}
