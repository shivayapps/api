package albums.gallery.photo.folder.picasa.app.web.gallery.service;

import androidx.annotation.Keep;


import albums.gallery.photo.folder.picasa.app.web.gallery.models.InAppPurchaseModel;
import io.reactivex.Observable;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

@Keep
public interface ApiService {


    @POST("getProSubscriptionKey.php")
    Call<InAppPurchaseModel> getInAppPurchaseKeys();
}
