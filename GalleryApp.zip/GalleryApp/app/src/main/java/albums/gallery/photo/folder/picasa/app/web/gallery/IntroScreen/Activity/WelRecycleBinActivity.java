package albums.gallery.photo.folder.picasa.app.web.gallery.IntroScreen.Activity;

import static albums.gallery.photo.folder.picasa.app.web.gallery.helpers.ConstantsKt.SHOW_INT_AD;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import albums.gallery.photo.folder.picasa.app.web.gallery.GoogleAnalyticsEvent;
import albums.gallery.photo.folder.picasa.app.web.gallery.R;
import albums.gallery.photo.folder.picasa.app.web.gallery.FirebaseConfigHelper;
import albums.gallery.photo.folder.picasa.app.web.gallery.activities.MainActivity;
import albums.gallery.photo.folder.picasa.app.web.gallery.startLikePro.Activity.SubScriptionActivity;

public class WelRecycleBinActivity extends AppCompatActivity {

    private Animation animFadeIn, animFadeIn1, animFadeIn2;
    TextView text1, text2, text3, skip_text;
    RelativeLayout third_act_layout;
    ImageView media_icon;
    private Animation animFadeIn_bottom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.wel_recyclebin);
        getWindow().setStatusBarColor(Color.parseColor("#ffffff"));
        text1 = findViewById(R.id.text1);
        text2 = findViewById(R.id.text2);
        text3 = findViewById(R.id.text3);
        skip_text = findViewById(R.id.skip_text);
        skip_text.setPaintFlags(skip_text.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        media_icon = findViewById(R.id.media_icon);
        third_act_layout = findViewById(R.id.third_act_layout);
        animFadeIn = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.left_to_right);
        animFadeIn1 = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.left_to_right);
        animFadeIn2 = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.left_to_right);
        animFadeIn_bottom = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slide_in_bottom);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                media_icon.setVisibility(View.VISIBLE);
                media_icon.startAnimation(animFadeIn_bottom);

            }
        }, 300);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                text1.setAnimation(animFadeIn);
                text1.setVisibility(View.VISIBLE);
            }
        }, 600);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                text2.setAnimation(animFadeIn1);
                text2.setVisibility(View.VISIBLE);
            }
        }, 1300);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                text3.setAnimation(animFadeIn2);
                text3.setVisibility(View.VISIBLE);
            }
        }, 2000);
        third_act_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GoogleAnalyticsEvent.logAdapter(
                    GoogleAnalyticsEvent.getProtectMedia(),
                    GoogleAnalyticsEvent.click,
                    GoogleAnalyticsEvent.getNext_button());

                if (!FirebaseConfigHelper.getIsAppAdFree(WelRecycleBinActivity.this)
                    && FirebaseConfigHelper.isNetworkConnected(WelRecycleBinActivity.this) && FirebaseConfigHelper.verifyInstallerId(WelRecycleBinActivity.this)
                    && FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.inAppSubscriptionenabled)
                ) {
                    Intent intent = new Intent(WelRecycleBinActivity.this, SubScriptionActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra("isFrom", WelRecycleBinActivity.this.getClass().getSimpleName());
                    startActivity(intent);
                    overridePendingTransition(R.anim.enter, R.anim.exit);
                    finish();
                } else {
                    startActivity(new Intent(WelRecycleBinActivity.this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra(SHOW_INT_AD, true));

                    finish();

                }
//                startActivity(new Intent(WelRecycleBinActivity.this, SubScriptionActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
//                overridePendingTransition(R.anim.enter, R.anim.exit);
//                finish();


            }
        });

        skip_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GoogleAnalyticsEvent.logAdapter(
                    GoogleAnalyticsEvent.getProtectMedia(),
                    GoogleAnalyticsEvent.click,
                    GoogleAnalyticsEvent.getSkip_button());
                if (!FirebaseConfigHelper.getIsAppAdFree(WelRecycleBinActivity.this)
                    && FirebaseConfigHelper.isNetworkConnected(WelRecycleBinActivity.this) && FirebaseConfigHelper.verifyInstallerId(WelRecycleBinActivity.this)
                    && FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.inAppSubscriptionenabled)
                ) {
                    Intent intent = new Intent(WelRecycleBinActivity.this, SubScriptionActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra("isFrom", WelRecycleBinActivity.this.getClass().getSimpleName());

                    startActivity(intent);
                    overridePendingTransition(R.anim.enter, R.anim.exit);
                    finish();
                } else {
                    startActivity(new Intent(WelRecycleBinActivity.this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra(SHOW_INT_AD, true));

                    finish();

                }

            }
        });
    }

}
