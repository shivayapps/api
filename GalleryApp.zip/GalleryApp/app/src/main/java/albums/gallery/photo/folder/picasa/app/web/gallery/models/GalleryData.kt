package albums.gallery.photo.folder.picasa.app.web.gallery.models

import android.os.Parcel
import android.os.Parcelable


data class GalleryData(
    val path: String?,
    val date: String?,
    val year: Int
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString(),
        parcel.readString(),
        parcel.readInt()
    ) {
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(path)
        parcel.writeString(date)
        parcel.writeInt(year)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<GalleryData> {
        override fun createFromParcel(parcel: Parcel): GalleryData {
            return GalleryData(parcel)
        }

        override fun newArray(size: Int): Array<GalleryData?> {
            return arrayOfNulls(size)
        }
    }
}
