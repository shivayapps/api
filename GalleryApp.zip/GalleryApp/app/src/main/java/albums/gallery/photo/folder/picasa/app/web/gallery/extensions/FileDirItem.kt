package albums.gallery.photo.folder.picasa.app.web.gallery.extensions

import album.gallery.photo.folder.picasa.app.web.gallery.commons.models.FileDirItem

fun FileDirItem.isDownloadsFolder() = path.isDownloadsFolder()
