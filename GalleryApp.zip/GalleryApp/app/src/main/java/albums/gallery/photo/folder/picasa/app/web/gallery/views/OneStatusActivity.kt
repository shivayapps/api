package albums.gallery.photo.folder.picasa.app.web.gallery.views

import album.gallery.photo.folder.picasa.app.web.gallery.commons.dialogs.PropertiesDialog
import albums.gallery.photo.folder.picasa.app.web.gallery.*
import albums.gallery.photo.folder.picasa.app.web.gallery.adapters.OneYearImageAdapter
import albums.gallery.photo.folder.picasa.app.web.gallery.extensions.config
import albums.gallery.photo.folder.picasa.app.web.gallery.extensions.setOnSingleClickListener
import albums.gallery.photo.folder.picasa.app.web.gallery.helpers.Config
import albums.gallery.photo.folder.picasa.app.web.gallery.preference.PreferenceKeys
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.bumptech.glide.Glide
import com.example.admob.adLoader.InterstitialAdLoader
import jp.shts.android.storiesprogressview.StoriesProgressView
import kotlinx.android.synthetic.main.activity_status.*
import java.io.File

class OneStatusActivity : AppCompatActivity(), StoriesProgressView.StoriesListener {
    private var storiesProgressView: StoriesProgressView? = null
    var pressTime = 0L
    var limit = 500L
    private var counter = 0
    private var stories_text: TextView? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_status)


        if (config.theme) {
            blurry_image.setBackgroundColor(ContextCompat.getColor(this@OneStatusActivity, R.color.light_))
        } else {
            blurry_image.setBackgroundColor(ContextCompat.getColor(this@OneStatusActivity, R.color.dark_))
        }

        storiesProgressView = findViewById<View>(R.id.stories) as StoriesProgressView
        stories_text = findViewById<View>(R.id.stories_text) as TextView
        val ic_close_lay = findViewById<View>(R.id.ic_close_lay) as RelativeLayout
        val ic_hint_lay = findViewById<View>(R.id.ic_hint_lay) as RelativeLayout
        val google_info_lay = findViewById<View>(R.id.google_info_lay) as RelativeLayout
        val google_share_lay = findViewById<View>(R.id.google_share_lay) as RelativeLayout
        if (!FirebaseConfigHelper.getIsAppAdFree(this) && FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.isIntEnableStatusBackPress)) {
            loadInterstitalAd()
        }
        try {
            if (OneYearImageAdapter.oneYearOldImages != null && OneYearImageAdapter.oneYearOldImages.size > 0) {      // Change by Arti - v1.0.30

                storiesProgressView!!.setStoriesCount(OneYearImageAdapter.oneYearOldImages.size)
                storiesProgressView!!.setStoryDuration(3000L)
                storiesProgressView!!.setStoriesListener(this)
                //        storiesProgressView.startStories();
                counter = intent.getIntExtra("status_view1", 0)
                storiesProgressView!!.startStories(counter)
                Glide.with(this).load(OneYearImageAdapter.oneYearOldImages.get(intent.getIntExtra("status_view1", 0)).path)
                    .into(findViewById<View>(R.id.blurry_image) as ImageView)
                stories_text!!.setText(OneYearImageAdapter.oneYearOldImages.get(intent.getIntExtra("status_view1", 0)).date);

                val reverse = findViewById<View>(R.id.reverse)
                reverse.setOnClickListener { storiesProgressView!!.reverse() }
                reverse.setOnTouchListener(onTouchListener)

                val skip = findViewById<View>(R.id.skip)
                skip.setOnClickListener { storiesProgressView!!.skip() }
                skip.setOnTouchListener(onTouchListener)

                val gif_load_b = findViewById<View>(R.id.gif_load_b) as ImageView
                gif_load_b.setOnClickListener {
                    Log.w("msg", "gif_load_b click----");
                    gif_load_b.visibility = View.GONE
                    gif_load.visibility = View.GONE
                }


                ic_close_lay.setOnClickListener { onBackPressed() }
                ic_hint_lay.setOnClickListener {

                    try {
                        gif_load_b.visibility = View.VISIBLE
                        Glide.with(this).asGif().load(R.drawable.glide_finger).into(findViewById<View>(R.id.gif_load) as ImageView)
                        gif_load.visibility = View.VISIBLE
                        storiesProgressView!!.pause();
                        // By Parth Crash Solving 1.0.35 23
                        try {
                            Handler(Looper.getMainLooper()).postDelayed({
                                gif_load_b.visibility = View.GONE
                                gif_load.visibility = View.GONE
                                storiesProgressView!!.resume();
                            }, 7500)
                        } catch (e: Exception) {

                        }
                    } catch (e: Exception) {
                    }
                }
                google_info_lay.setOnClickListener {
                    Log.w("msg", "google_info_lay click----");
                    try {
                        storiesProgressView!!.pause();

                        if (OneYearImageAdapter.oneYearOldImages.get(counter).path != null) {
                            // WEIRED
                            PropertiesDialog(this@OneStatusActivity, OneYearImageAdapter.oneYearOldImages.get(counter).path, false)
                        }
                    } catch (e: Exception) {
                    }
                }
                google_share_lay.setOnSingleClickListener {
                    storiesProgressView!!.pause();
                    Config(this@OneStatusActivity).saveData(this@OneStatusActivity, PreferenceKeys.SystemDialogOpened, true) ;
                    ShareImage(OneYearImageAdapter.oneYearOldImages.get(counter).path);

                }
            }
        } catch (e: Exception) {
        }
    }



    private val onTouchListener = View.OnTouchListener { v, event ->
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                pressTime = System.currentTimeMillis()
                storiesProgressView!!.pause()
                return@OnTouchListener false
            }
            MotionEvent.ACTION_UP -> {
                val now = System.currentTimeMillis()
                storiesProgressView!!.resume()
                return@OnTouchListener limit < now - pressTime
            }
        }
        false
    }

    override fun onComplete() {
        finish()

    }

    override fun onPrev() {
        try {
            counter = counter - 1
            if (counter < 0) {
                onNext()
            }
            Glide.with(this).load(OneYearImageAdapter.oneYearOldImages.get(counter).path).into(findViewById<View>(R.id.blurry_image) as ImageView)
            stories_text!!.setText(OneYearImageAdapter.oneYearOldImages.get(counter).date)

                stories_text!!.visibility = View.VISIBLE
                ic_hint_lay!!.visibility = View.VISIBLE
                google_info_lay.visibility = View.VISIBLE
                google_share_lay.visibility = View.VISIBLE

        } catch (e: java.lang.Exception) {
           finish()
        }
    }

    override fun onNext() {
        try {
            counter = counter + 1
            Glide.with(this).load(OneYearImageAdapter.oneYearOldImages.get(counter).path).into(findViewById<View>(R.id.blurry_image) as ImageView)
            stories_text!!.setText(OneYearImageAdapter.oneYearOldImages.get(counter).date)

                stories_text!!.visibility = View.VISIBLE
                ic_hint_lay!!.visibility = View.VISIBLE
                google_info_lay.visibility = View.VISIBLE
                google_share_lay.visibility = View.VISIBLE

        } catch (e: Exception) {
            finish()
        }

    }

    private fun ShareImage(ImagePath: String) {
        val text = "Hey! Look at our amazing memories I found on this app  " + "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID
        val pictureUri = FileProvider.getUriForFile(this@OneStatusActivity, "$packageName.provider", File(ImagePath))
        val shareIntent = Intent()
        shareIntent.action = Intent.ACTION_SEND
        shareIntent.putExtra(Intent.EXTRA_TEXT, text)
        shareIntent.putExtra(Intent.EXTRA_STREAM, pictureUri)
        shareIntent.type = "image/*"
        shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(shareIntent, "Share image..."))
    }

    override fun onDestroy() {
        storiesProgressView!!.destroy();

        super.onDestroy()
    }
    override fun onBackPressed() {
        finishedWithAds { super.onBackPressed() }
    }
    private fun finishedWithAds(callback: () -> Unit) {
        if (!FirebaseConfigHelper.getIsAppAdFree(this) && FirebaseConfigHelper.isNetworkConnected(this) && FirebaseConfigHelper.remoteConfig.getBoolean(
                FirebaseConfigHelper.isIntEnableStatusBackPress
            )
        ) {
            val admob_int = FirebaseConfigHelper.getAdmob_int(this)
            val admob_back_int = FirebaseConfigHelper.getAdmobBack_int(this)
            val admob_rewared = FirebaseConfigHelper.getAdmobRewared(this)
            val admob_back_rewared = FirebaseConfigHelper.getAdmobBackRewared(this)
            val admob_rewared_int = FirebaseConfigHelper.getAdmobRewaredInt(this)
            val admob_back_rewared_int = FirebaseConfigHelper.getAdmobBackRewaredInt(this)
            InterstitialAdLoader.showAdWithControl(
                this,
                FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_interstitial_control),
                false,
                object : InterstitialAdLoader.adfinishwithControl {
                    override fun adfinished() {

                        callback()
                    }


                    override fun rewaredfailed() {

                        callback()
                    }
                },
                admob_int,
                admob_back_int,
                admob_rewared,
                admob_back_rewared,
                admob_rewared_int,
                admob_back_rewared_int,
                FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.back_id_required),
                GoogleAnalyticsEvent.randomStoryStatus + "_status_on_backpress",
                GalleryMainApplication.getInstance()?.firebaseAnalytics,


                )

        } else {
            callback()
        }
    }
    private fun loadInterstitalAd() {
        val admob_int = FirebaseConfigHelper.getAdmob_int(this)
        val admob_back_int = FirebaseConfigHelper.getAdmobBack_int(this)
        val admob_rewarded = FirebaseConfigHelper.getAdmobRewared(this)
        val admob_back_rewarded = FirebaseConfigHelper.getAdmobBackRewared(this)
        val admob_rewarded_int = FirebaseConfigHelper.getAdmobRewaredInt(this)
        val admob_back_rewarded_int = FirebaseConfigHelper.getAdmobBackRewaredInt(this)
        InterstitialAdLoader.loadAd(
            this, FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_interstitial_control), admob_int, admob_back_int,
            FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.back_id_required),
            admob_rewarded,
            admob_back_rewarded,
            admob_rewarded_int,
            admob_back_rewarded_int,this.javaClass.simpleName,
            GoogleAnalyticsEvent.oneStoryStatus,
            GalleryMainApplication.getInstance()?.firebaseAnalytics,
            { }
        )
    }
}
