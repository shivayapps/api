package albums.gallery.photo.folder.picasa.app.web.gallery.IntroScreen.Activity;

import static albums.gallery.photo.folder.picasa.app.web.gallery.FirebaseConfigHelper.verifyInstallerId;
import static albums.gallery.photo.folder.picasa.app.web.gallery.helpers.ConstantsKt.SHOW_INT_AD;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import albums.gallery.photo.folder.picasa.app.web.gallery.GoogleAnalyticsEvent;
import albums.gallery.photo.folder.picasa.app.web.gallery.R;
import albums.gallery.photo.folder.picasa.app.web.gallery.FirebaseConfigHelper;
import albums.gallery.photo.folder.picasa.app.web.gallery.activities.MainActivity;
import albums.gallery.photo.folder.picasa.app.web.gallery.startLikePro.Activity.SubScriptionActivity;

public class PDupFilesActivity extends AppCompatActivity {

    private Animation animFadeIn, animFadeIn_bottom;
    TextView text1, text2, text3, textview_title1, textview_title2, skip_text;
    RelativeLayout second_act_layout;
    ImageView recycle_icon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.wel_duplicate);
        getWindow().setStatusBarColor(Color.parseColor("#ffffff"));
        text1 = findViewById(R.id.text1);
        text2 = findViewById(R.id.text2);
        textview_title1 = findViewById(R.id.textview_title1);
        textview_title2 = findViewById(R.id.textview_title2);
        text3 = findViewById(R.id.text3);
        recycle_icon = findViewById(R.id.recycle_icon);
        second_act_layout = findViewById(R.id.second_act_layout);
        skip_text = findViewById(R.id.skip_text);
        skip_text.setPaintFlags(skip_text.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        animFadeIn_bottom = AnimationUtils.loadAnimation(getApplicationContext(),
            R.anim.slide_in_bottom);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                recycle_icon.setVisibility(View.VISIBLE);
                recycle_icon.startAnimation(animFadeIn_bottom);

            }
        }, 600);
        animFadeIn = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.pull_out);


        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                textview_title1.setAnimation(animFadeIn);
                textview_title1.setVisibility(View.VISIBLE);
            }
        }, 200);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                textview_title2.setAnimation(animFadeIn);
                textview_title2.setVisibility(View.VISIBLE);
            }
        }, 350);

        second_act_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GoogleAnalyticsEvent.Companion.logAdapter(
                    GoogleAnalyticsEvent.removeDuplicateImages,
                    GoogleAnalyticsEvent.click,
                    GoogleAnalyticsEvent.Companion.getNext_button());
                startActivity(new Intent(PDupFilesActivity.this, WelFavouriteActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                overridePendingTransition(R.anim.enter, R.anim.exit);
                finish();

            }
        });
        skip_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GoogleAnalyticsEvent.Companion.logAdapter(
                    GoogleAnalyticsEvent.removeDuplicateImages,
                    GoogleAnalyticsEvent.click,
                    GoogleAnalyticsEvent.skipButton);
                if (!FirebaseConfigHelper.getIsAppAdFree(PDupFilesActivity.this)
                    && FirebaseConfigHelper.isNetworkConnected(PDupFilesActivity.this) && verifyInstallerId(PDupFilesActivity.this)
                    && FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.inAppSubscriptionenabled)
                ) {
                    startActivity(new Intent(PDupFilesActivity.this, SubScriptionActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    overridePendingTransition(R.anim.enter, R.anim.exit);
                    finish();
                } else {
                    startActivity(new Intent(PDupFilesActivity.this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra(SHOW_INT_AD, true));
                    finish();
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (!FirebaseConfigHelper.getIsAppAdFree(PDupFilesActivity.this)
            && FirebaseConfigHelper.isNetworkConnected(PDupFilesActivity.this) && verifyInstallerId(PDupFilesActivity.this)
            && FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.inAppSubscriptionenabled )) {
            startActivity(new Intent(PDupFilesActivity.this, SubScriptionActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            overridePendingTransition(R.anim.enter, R.anim.exit);
            finish();
        } else {
            startActivity(new Intent(PDupFilesActivity.this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra(SHOW_INT_AD, true));
            finish();
        }
    }

}
