package albums.gallery.photo.folder.picasa.app.web.gallery.activities

import album.gallery.photo.folder.picasa.app.web.gallery.commons.extensions.*
import album.gallery.photo.folder.picasa.app.web.gallery.commons.views.*
import albums.gallery.photo.folder.picasa.app.web.gallery.FirebaseConfigHelper
import albums.gallery.photo.folder.picasa.app.web.gallery.GalleryMainApplication
import albums.gallery.photo.folder.picasa.app.web.gallery.GoogleAnalyticsEvent
import albums.gallery.photo.folder.picasa.app.web.gallery.R
import albums.gallery.photo.folder.picasa.app.web.gallery.databinding.ActivityThemeBinding
import albums.gallery.photo.folder.picasa.app.web.gallery.databinding.DialogConformThemeBinding

import albums.gallery.photo.folder.picasa.app.web.gallery.extensions.config
import albums.gallery.photo.folder.picasa.app.web.gallery.helpers.FROM_SETTINGS
import albums.gallery.photo.folder.picasa.app.web.gallery.helpers.FROM_THEMES
import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.view.ContextThemeWrapper
import android.view.KeyEvent
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.example.admob.adLoader.BannerAds
import com.example.admob.adLoader.InterstitialAdLoader
import com.google.android.material.tabs.TabLayout


class ThemeActivity : SimpleActivity() {
    lateinit var mBind: ActivityThemeBinding
    private var isDark = false
    private var themeToggled = false
    private var isFrom = ""
    private var isThemeChanged = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        mBind = ActivityThemeBinding.inflate(layoutInflater)
        setContentView(mBind.root)
        isFrom = intent.getStringExtra("isFrom").toString()
        if (!FirebaseConfigHelper.getIsAppAdFree(this@ThemeActivity) && FirebaseConfigHelper.isNetworkConnected(this@ThemeActivity)) {
            mBind.adLay.beVisible()
            forBannerAds()
            val admob_int = FirebaseConfigHelper.getAdmob_int(this@ThemeActivity)
            val admob_back_int = FirebaseConfigHelper.getAdmobBack_int(this@ThemeActivity)
            val admob_rewarded = FirebaseConfigHelper.getAdmobRewared(this@ThemeActivity)
            val admob_back_rewarded = FirebaseConfigHelper.getAdmobBackRewared(this@ThemeActivity)
            val admob_rewarded_int = FirebaseConfigHelper.getAdmobRewaredInt(this@ThemeActivity)
            val admob_back_rewarded_int = FirebaseConfigHelper.getAdmobBackRewaredInt(this@ThemeActivity)

            InterstitialAdLoader.loadAd(
                this@ThemeActivity, FirebaseConfigHelper.remoteConfig.getString(
                    FirebaseConfigHelper.admob_interstitial_control
                ),
                admob_int, admob_back_int,
                FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.back_id_required),
                admob_rewarded,
                admob_back_rewarded,
                admob_rewarded_int,
                admob_back_rewarded_int,"themeActivity",
                GoogleAnalyticsEvent.themeActivity,
                GalleryMainApplication.getInstance()?.firebaseAnalytics, { }
            )

        } else {
            mBind.adLay.beGone()
        }


        mBind.tvHeader.setColors(config.textColor, config.accentColor, config.backgroundColor)
        mBind.ivBack.applyColorFilter(config.textColor)

        isDark = config.theme
        if (supportActionBar != null) {
            supportActionBar!!.hide()
        }


        val isDark = config.theme


        onClickItem()
        if (isDark) {
            mBind.rlLight.isEnabled = false
            mBind.rlDark.isEnabled = true
            mBind.rbLight.isChecked = true
            applyLight()
        } else {
            mBind.rlLight.isEnabled = true
            mBind.rlDark.isEnabled = false
            mBind.rbDark.isChecked = true
            applyDark()
        }
        toggleTheme(isDark)
    }


    private fun onClickItem() {

        mBind.rbDark.setOnClickListener {
            mBind.rlDark.performClick()
        }

        mBind.rbLight.setOnClickListener {
            mBind.rlLight.performClick()

        }

        mBind.rlLight.setOnClickListener {

            GoogleAnalyticsEvent.logAdapter(GoogleAnalyticsEvent.themeMode, isFrom, GoogleAnalyticsEvent.light)
            showDialogForThemeChange({
                isThemeChanged = true
                themeToggled = true
                config.theme = true
                applyLight()
                it.isEnabled = false
                mBind.rlDark.isEnabled = true

            }, {
                isThemeChanged = false
                mBind.rbLight.isChecked = false
                mBind.rbDark.isChecked = true
            })


        }

        mBind.ivBack.setOnClickListener {
            onBackPressed()
        }

        mBind.rlDark.setOnClickListener {

            GoogleAnalyticsEvent.logAdapter(GoogleAnalyticsEvent.themeMode, isFrom, GoogleAnalyticsEvent.dark)
            showDialogForThemeChange({
                isThemeChanged = true
                themeToggled = true
                config.theme = false
                applyDark()
                it.isEnabled = false
                mBind.rlLight.isEnabled = true
            }, {
                isThemeChanged = false
                mBind.rbLight.isChecked = true
                mBind.rbDark.isChecked = false
            })


        }
    }

    private fun applyDark() {
        toggleTheme(false)
        mBind.ivBack.applyColorFilter(Color.parseColor("#FFFFFF"))

        mBind.rbLight.isChecked = false
        mBind.rbDark.isChecked = true
    }

    private fun showDialogForThemeChange(applyCallback: () -> Unit, cancelCallBack: () -> Unit) {
        val ctw = ContextThemeWrapper(this, R.style.MaterialAlertDialog_rounded)
        val binding = DialogConformThemeBinding.inflate(layoutInflater)
        binding.messageTheme.text = getString(R.string.set_themes)
        binding.messageThemeSub.text = getString(R.string.are_you_sure_to_change_theme)
        if (config.theme) {
            binding.messageTheme.setTextColor(ContextCompat.getColor(this, R.color.black))
            binding.messageThemeSub.setTextColor(ContextCompat.getColor(this, R.color.permission_subtitle))

        } else {
            binding.messageTheme.setTextColor(ContextCompat.getColor(this, R.color.white))
            binding.messageThemeSub.setTextColor(ContextCompat.getColor(this, R.color.permission_subtitle_dark))

        }
        val alert = AlertDialog.Builder(ctw)
        alert.setView(binding.root)
        alert.setCancelable(true)
        alert.setPositiveButton(
            "Apply"
        ) { dialog, num ->
            run {
                dialog.dismiss()
                changeThemeWithAd(applyCallback)
            }
        }
        alert.setNegativeButton("Cancel", { dialog, which ->
            cancelCallBack()
            dialog.dismiss()
        })
        alert.setOnKeyListener(object : DialogInterface.OnKeyListener {
            override fun onKey(dialog: DialogInterface?, keyCode: Int, event: KeyEvent?): Boolean {
                return if (keyCode == KeyEvent.KEYCODE_BACK) {
                    cancelCallBack()
                    dialog?.cancel()
                    true
                } else {
                    false
                }
            }

        })
        val dialog: AlertDialog = alert.create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(ContextCompat.getColor(this, R.color.permission_btn_color))
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(ContextCompat.getColor(this, R.color.permission_btn_color))
        }
        dialog.show()
        val color = if (config.theme) {
            ContextCompat.getColor(this, R.color.white)
        } else {
            ContextCompat.getColor(this, R.color.permission_bg_bottomsheet_dark)
        }
        dialog.getWindow()?.setBackgroundDrawable(resources.getColoredDrawableWithColor(R.drawable.corenered_layout, color))


    }

    private fun changeThemeWithAd(callback: () -> Unit) {
        if (!FirebaseConfigHelper.getIsAppAdFree(this@ThemeActivity) && FirebaseConfigHelper.isNetworkConnected(this@ThemeActivity) && FirebaseConfigHelper.remoteConfig.getBoolean(
                FirebaseConfigHelper.is_thememode_changing_interstitial_enable
            )
        ) {
            val admob_int = FirebaseConfigHelper.getAdmob_int(this@ThemeActivity)
            val admob_back_int = FirebaseConfigHelper.getAdmobBack_int(this@ThemeActivity)
            val admob_rewared = FirebaseConfigHelper.getAdmobRewared(this@ThemeActivity)
            val admob_back_rewared = FirebaseConfigHelper.getAdmobBackRewared(this@ThemeActivity)
            val admob_rewared_int = FirebaseConfigHelper.getAdmobRewaredInt(this@ThemeActivity)
            val admob_back_rewared_int = FirebaseConfigHelper.getAdmobBackRewaredInt(this@ThemeActivity)
            InterstitialAdLoader.showAdWithControl(
                this@ThemeActivity,
                FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_interstitial_control),
                false,
                object : InterstitialAdLoader.adfinishwithControl {
                    override fun adfinished() {
                        FirebaseConfigHelper.logMethod("nativeshow  ", "Theme Dark")
                        callback()
                    }


                    override fun rewaredfailed() {
                        FirebaseConfigHelper.logMethod("nativeshow  ", "Theme Dark")
                        callback()
                    }
                },
                admob_int,
                admob_back_int,
                admob_rewared,
                admob_back_rewared,
                admob_rewared_int,
                admob_back_rewared_int,
                FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.back_id_required),
                GoogleAnalyticsEvent.themeActivity + "_change_theme_ok_click",
                GalleryMainApplication.getInstance()?.firebaseAnalytics,


                )

        } else {
            callback()
        }
    }

    private fun applyLight() {
        toggleTheme(true)
        mBind.ivBack.applyColorFilter(Color.parseColor("#000000"))
        mBind.rbLight.isChecked = true
        mBind.rbDark.isChecked = false
    }


    private fun toggleTheme(dark: Boolean) {
        val textColor = if (dark) 0xFF333333.toInt() else Color.parseColor("#FFFFFF")
        val accentColor = if (dark) Color.parseColor("#007AFF") else Color.parseColor("#007AFF")
        val backgroundColor = if (dark) Color.parseColor("#FFFFFF") else Color.parseColor("#000000")
        val primaryColor = if (dark) Color.parseColor("#FFFFFF") else Color.parseColor("#000000")
        val navigationColor = if (dark) Color.parseColor("#FFFFFF") else Color.parseColor("#000000")
        mBind.ivBack.applyColorFilter(config.textColor)
        window.decorView.setBackgroundColor(backgroundColor)
        updateActionbarColor(primaryColor)
        updateNavigationBarColor(navigationColor)
        updateTextColors0(mBind.scrollview, textColor, accentColor)
        saveChanges(textColor, accentColor, primaryColor, backgroundColor)
    }

    private fun saveChanges(
        textColorParam: Int,
        accentColorParam: Int,
        primaryColorParam: Int,
        backgroundColorParam: Int
    ) {
        baseConfig.apply {
            textColor = textColorParam
            backgroundColor = backgroundColorParam
            primaryColor = primaryColorParam
            accentColor = accentColorParam
            navigationBarColor = textColorParam
        }
    }

    private fun updateTextColors0(viewGroup: ViewGroup, tmpTextColor: Int = 0, tmpAccentColor: Int = 0) {
        val textColor = if (tmpTextColor == 0) baseConfig.textColor else tmpTextColor
        val backgroundColor = baseConfig.backgroundColor
        val accentColor = if (tmpAccentColor == 0) {
            when {
                isWhiteTheme() || isBlackAndWhiteTheme() -> baseConfig.accentColor
                else -> baseConfig.accentColor
            }
        } else {
            tmpAccentColor
        }

        val cnt = viewGroup.childCount
        (0 until cnt).map { viewGroup.getChildAt(it) }.forEach {
            when (it) {
                is TabLayout -> it.setTabTextColors(textColor, Color.parseColor("#007AFF"))
                is TextView -> it.setTextColor(textColor)
                is MyTextView -> {
                    it.setColors(textColor, accentColor, backgroundColor)
                    it.setTypeface(Typeface.createFromAsset(applicationContext.assets, "Montserrat.ttf"), Typeface.NORMAL)
                }
                is MyAppCompatSpinner -> it.setColors(textColor, accentColor, backgroundColor)
                is MySwitchCompat -> it.setColors(textColor, accentColor, backgroundColor)
                is MyCompatRadioButton -> it.setColors(textColor, accentColor, backgroundColor)
                is MyAppCompatCheckbox -> it.setColors(textColor, accentColor, backgroundColor)
                is MyEditText -> it.setColors(textColor, accentColor, backgroundColor)
                is MyAutoCompleteTextView -> it.setColors(textColor, accentColor, backgroundColor)
                is MyFloatingActionButton -> it.setColors(textColor, accentColor, backgroundColor)
                is MySeekBar -> it.setColors(textColor, accentColor, backgroundColor)
                is MyButton -> it.setColors(textColor, accentColor, backgroundColor)
                is MyTextInputLayout -> it.setColors(textColor, accentColor, backgroundColor)
                is ViewGroup -> updateTextColors(it, textColor, accentColor)

            }
        }
    }

    override fun onBackPressed() {
        Log.w("msg", "onBackPressed: setting" + intent.getBooleanExtra(FROM_SETTINGS, false))
        val passIntent: Intent =
            if (!intent.getBooleanExtra(FROM_SETTINGS, false)) {
                Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

            } else {
                Intent(this, SettingsActivity::class.java).putExtra(FROM_THEMES, isThemeChanged).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)

            }
        startActivity(passIntent)
        finish()


    }

    private fun forBannerAds() {
        if (FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.themeModeBannerAdEnabled)) {
            val back_id_required = FirebaseConfigHelper.isBackIdRequired(this)
            val admobBanner = FirebaseConfigHelper.getAdmobBanner(this)
            val admobBackBanner = FirebaseConfigHelper.getAdmobBackBanner(this)
            if (getDeviceHeight() > 1280) {
                BannerAds.loadAdmob_BannerADs(
                    this, mBind.admobBannerAds, admobBanner, admobBackBanner,
                    back_id_required,
                    FirebaseConfigHelper.remoteConfig.getString(
                        FirebaseConfigHelper.themeModeBannerAdTypeControl
                    ),
                    FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.isCollapsiveBannerEnableThemeMode),
                    object : BannerAds.AdFinishedCallback {
                        override fun adFinished() {

                        }

                        override fun adFailedtoshow() {

                        }

                    },
                    GoogleAnalyticsEvent.themeActivity,
                    GalleryMainApplication.getInstance()?.firebaseAnalytics,
                )
            } else {
                BannerAds.loadAdmob_BannerADs(
                    this, mBind.admobBannerAds, admobBanner, admobBackBanner,
                    back_id_required,
                    FirebaseConfigHelper.remoteConfig.getString(
                        FirebaseConfigHelper.themeModeBannerAdTypeControl
                    ),
                    false,
                    object : BannerAds.AdFinishedCallback {
                        override fun adFinished() {

                        }

                        override fun adFailedtoshow() {

                        }

                    },
                    GoogleAnalyticsEvent.themeActivity,
                    GalleryMainApplication.getInstance()?.firebaseAnalytics,
                )
            }
        } else {
            mBind.adLay.beGone()
        }
    }

    private fun getDeviceHeight(): Int {
        val displayMetrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(displayMetrics)
        val height: Int = displayMetrics.heightPixels
        return height
    }

    override fun onResume() {
        super.onResume()
        if (!FirebaseConfigHelper.getIsAppAdFree(this)) {
            BannerAds.destroyAd();

        }
    }

    override fun onPause() {
        super.onPause()
        if (!FirebaseConfigHelper.getIsAppAdFree(this)) {
            BannerAds.destroyAd();

        }
    }

    override fun onDestroy() {
        if (!FirebaseConfigHelper.getIsAppAdFree(this)) {
            BannerAds.destroyAd();

        }
        super.onDestroy()

    }
}
