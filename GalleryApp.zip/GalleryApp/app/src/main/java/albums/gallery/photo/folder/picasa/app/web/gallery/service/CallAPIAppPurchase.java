package albums.gallery.photo.folder.picasa.app.web.gallery.service;

import android.content.Context;

import albums.gallery.photo.folder.picasa.app.web.gallery.FirebaseConfigHelper;
import albums.gallery.photo.folder.picasa.app.web.gallery.models.InAppPurchaseModel;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class CallAPIAppPurchase {

    public interface callBack {
        void onLoaded(Response<InAppPurchaseModel> response);

        void onServerError();

        void onNetworkError();
    }


    public static void callApiDataForIAP(Context context, callBack callBack) {

        ApiService api = ApiClient.getClient().create(ApiService.class);
        Call<InAppPurchaseModel> call = api.getInAppPurchaseKeys();
        call.enqueue(new Callback<InAppPurchaseModel>() {
            @Override
            public void onResponse(retrofit2.Call<InAppPurchaseModel> call, Response<InAppPurchaseModel> response) {
                callBack.onLoaded(response);
            }
            @Override
            public void onFailure(retrofit2.Call<InAppPurchaseModel> call, Throwable t) {
                if (FirebaseConfigHelper.isNetworkConnected(context)) {
                    callBack.onServerError();
                } else {
                    callBack.onNetworkError();
                }
            }
        });

    }
}
