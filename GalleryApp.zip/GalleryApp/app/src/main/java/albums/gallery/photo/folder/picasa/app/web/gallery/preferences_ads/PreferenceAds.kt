package albums.gallery.photo.folder.picasa.app.web.gallery.preferences_ads

import android.content.Context

internal class PreferenceAds {
    companion object {
        // Constants
        val THEME_PREFS = "THEME_PREFS";
        val SHOW_OPEN_AD = "show_open_ad"

        // By Parth for saving bool shared prefs
        internal fun saveData(context: Context?, key: String?, value: Boolean?) {
            if (context == null) return
            if (value != null) {
                context.getSharedPreferences(THEME_PREFS, Context.MODE_PRIVATE).edit().putBoolean(key, value).apply()
            }
        }

        fun saveToShowOpenAd(context: Context?, value: Boolean?) {
            saveData(context, SHOW_OPEN_AD, value)
        }
    }
}
