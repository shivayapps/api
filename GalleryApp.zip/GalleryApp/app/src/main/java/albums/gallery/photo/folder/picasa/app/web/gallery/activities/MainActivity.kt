package albums.gallery.photo.folder.picasa.app.web.gallery.activities

import album.gallery.photo.folder.picasa.app.web.gallery.commons.dialogs.ConfirmationDialog
import album.gallery.photo.folder.picasa.app.web.gallery.commons.dialogs.SecurityDialog
import album.gallery.photo.folder.picasa.app.web.gallery.commons.extensions.*
import album.gallery.photo.folder.picasa.app.web.gallery.commons.helpers.*
import album.gallery.photo.folder.picasa.app.web.gallery.commons.views.*
import albums.gallery.photo.folder.picasa.app.web.gallery.*
import albums.gallery.photo.folder.picasa.app.web.gallery.DeplicateFInd.GroupActivity
import albums.gallery.photo.folder.picasa.app.web.gallery.DeplicateFInd.GroupActivityBlack
import albums.gallery.photo.folder.picasa.app.web.gallery.adapters.MediaAdapter
import albums.gallery.photo.folder.picasa.app.web.gallery.adapters.ViewPagerAdapter
import albums.gallery.photo.folder.picasa.app.web.gallery.dailyNotification.NotificationReceiver
import albums.gallery.photo.folder.picasa.app.web.gallery.databinding.BottomsheetExitBinding
import albums.gallery.photo.folder.picasa.app.web.gallery.extensions.config
import albums.gallery.photo.folder.picasa.app.web.gallery.extensions.launchSettings
import albums.gallery.photo.folder.picasa.app.web.gallery.fragments.AlbumFragment
import albums.gallery.photo.folder.picasa.app.web.gallery.fragments.AllMediaFragment
import albums.gallery.photo.folder.picasa.app.web.gallery.helpers.*
import albums.gallery.photo.folder.picasa.app.web.gallery.models.GalleryData
import albums.gallery.photo.folder.picasa.app.web.gallery.preference.PreferenceKeys
import albums.gallery.photo.folder.picasa.app.web.gallery.preferences_ads.PreferenceAds
import albums.gallery.photo.folder.picasa.app.web.gallery.service.SubscriptionModel
import albums.gallery.photo.folder.picasa.app.web.gallery.startLikePro.Activity.SubScription_RemoveAdsActivity
import albums.gallery.photo.folder.picasa.app.web.gallery.startLikePro.inappsubscription.IabHelper
import android.annotation.SuppressLint
import android.app.*
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.ColorStateList
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.util.Log
import android.view.*
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import androidx.core.view.MenuItemCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.viewpager2.widget.ViewPager2
import com.checkapplive.mylibrary.LiveAppActivity
import com.example.admob.adLoader.BannerAds
import com.example.admob.adLoader.InterstitialAdLoader
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.google.android.play.core.review.ReviewInfo
import com.google.android.play.core.review.ReviewManager
import com.google.android.play.core.review.ReviewManagerFactory
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.gson.Gson
import com.treebo.internetavailabilitychecker.InternetAvailabilityChecker
import com.treebo.internetavailabilitychecker.InternetConnectivityListener
import eu.dkaratzas.android.inapp.update.Constants
import eu.dkaratzas.android.inapp.update.InAppUpdateManager
import eu.dkaratzas.android.inapp.update.InAppUpdateManager.InAppUpdateHandler
import eu.dkaratzas.android.inapp.update.InAppUpdateStatus
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.fragment_all_media.*
import java.io.File
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.*


class MainActivity : SimpleActivity(), InAppUpdateHandler, InternetConnectivityListener {
    // Initialise the DrawerLayout, NavigationView and ToggleBar
    private lateinit var actionBarToggle: ActionBarDrawerToggle
    var theme = true
    var imageCount = ""
    var mHelper: IabHelper? = null
    var mLastClickTime: Long = 0
    var slide_click: Int = 0
    private val PICK_MEDIA = 2
    private val PICK_WALLPAPER = 3
    var radio_group: RadioGroup? = null
    var dark_theme: RadioButton? = null
    var light_theme: RadioButton? = null
    var dialog: Dialog? = null
    private val objKeyList: ArrayList<SubscriptionModel> = ArrayList()
    private var mSelectedSubscriptionPeriod = ""

    var progressDialog: ProgressDialog? = null
    private var mIsPickImageIntent = false
    private var mIsPickVideoIntent = false
    private var mIsGetImageContentIntent = false
    private var mIsGetVideoContentIntent = false
    private var mIsGetAnyContentIntent = false
    private var mIsSetWallpaperIntent = false
    private var mAllowPickingMultiple = false
    var albumFragment: AlbumFragment? = null
    private val TAG = "MAIN_ACTIVITY"
    lateinit var switch: SwitchCompat
    lateinit var headerView: View
    lateinit var removeAds: RelativeLayout
    lateinit var message: TextView
    lateinit var go_premium: TextView
    lateinit var main_ads_header: LinearLayout
    lateinit var line_view_drawer: View
    lateinit var header: LinearLayout
    private var reviewInfo: ReviewInfo? = null
    var manager: ReviewManager? = null
    private var doubleBackToExitPressedOnce = false

    //inAppUpdate
    private var inAppUpdateManager: InAppUpdateManager? = null
    private val REQ_CODE_VERSION_UPDATE = 530

    var alertDialog1: AlertDialog? = null
    lateinit var mInternetAvailabilityChecker: InternetAvailabilityChecker

    @RequiresApi(Build.VERSION_CODES.O)
    @SuppressLint("ResourceAsColor")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.O) requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        else requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        setContentView(R.layout.activity_main)
        loadInterstitialAds()
        try {


            GoogleAnalyticsEvent.logAdapter(GoogleAnalyticsEvent.SplashOpenAds, "view", GoogleAnalyticsEvent.mainScreen)

            GalleryMainApplication.mInstance.setOpenAdIds()

//        dailynotification()
//        getPictures(0)
            supportActionBar!!.elevation = 0F

            if (FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.update_dialog_show).equals("true")) {
                updateChecker()
            }
            loadAds()
            mInternetAvailabilityChecker = InternetAvailabilityChecker.getInstance()
            mInternetAvailabilityChecker.addInternetConnectivityListener(this)
            theme = config.theme
            fireBaseConfigGet()
            toggleThemeInit(theme)
            invalidateOptionsMenu()
            appLaunched(BuildConfig.APPLICATION_ID)
            navigation.setBackgroundColor(baseConfig.backgroundColor)
            navigation.itemTextColor = ColorStateList.valueOf(baseConfig.textColor)
            navigation.itemIconTintList = ColorStateList.valueOf(Color.parseColor("#007AFF"))
            val menu: Menu = navigation.menu
            val menuItem: MenuItem = menu.findItem(R.id.pass_hidden)
            val actionView: View = MenuItemCompat.getActionView(menuItem)
            switch = actionView.findViewById(R.id.drawer_switch)
            headerView = navigation.getHeaderView(0)
            removeAds = headerView.findViewById(R.id.price_layout)
            message = headerView.findViewById(R.id.message)
            go_premium = headerView.findViewById(R.id.go_premium)
            main_ads_header = headerView.findViewById(R.id.main_ads_header)
            line_view_drawer = headerView.findViewById(R.id.line_view_drawer)
            header = headerView.findViewById(R.id.header)
            switch.isChecked = config.isHiddenPasswordProtectionOn
            switch.setOnClickListener {
                openSecurityDialogHiddenProtect()
            }

            if (!FirebaseConfigHelper.getIsAppAdFree(this@MainActivity)) {
                main_ads_header.visibility = View.VISIBLE
                line_view_drawer.visibility = View.VISIBLE
                Log.w("msg", "inApp Gallr val price " + Config(this@MainActivity).getStringData(this@MainActivity, "start_like_pro_price"))
                val nav_header = navigation.getHeaderView(0)

//            if (!Config(this@MainActivity).getStringData(this@MainActivity, "start_like_pro_price").equals("")) {
//                nav_header.price_data.text = Config(this@MainActivity).getStringData(this@MainActivity, "start_like_pro_price") + " / REMOVE ADS"
//                Log.w(
//                    "msg", "inApp Gallry Ad ad_remove_tv.text " + Config(this@MainActivity).getStringData(this@MainActivity, "start_like_pro_price")
//                )
//            } else {
                Log.w("msg", "inApp else ")
                if (!FirebaseConfigHelper.isNetworkConnected(this@MainActivity)) {
//                    try {
//                        GetInAppPurchaseData_Service()
//                    } catch (e: Exception) {
//                        main_ads_header.visibility = View.GONE
//                        line_view_drawer.visibility = View.GONE
//                    }
//                } else {
                    main_ads_header.visibility = View.GONE
                    line_view_drawer.visibility = View.GONE
                }
//            }
            } else {
//            main_ads_header.visibility = View.GONE
//            line_view_drawer.visibility = View.GONE
                removeAds.visibility = View.GONE
                go_premium.text = "Premium User"
                message.text = "Enjoy ads-free version."

            }

            if (intent?.getBooleanExtra(SHOW_INT_AD, false) == true) {
                val bundle = Bundle()
                bundle.putBoolean(SHOW_INT_AD, true)
                albumFragment = AlbumFragment()
                albumFragment?.arguments = bundle
                // loadFirstAd()
            } else {
                val bundle = Bundle()
                bundle.putBoolean(SHOW_INT_AD, false)
                albumFragment = AlbumFragment()
                albumFragment?.arguments = bundle
            }

            actionBarToggle = ActionBarDrawerToggle(this, drawer_layout, 0, 0)
            drawer_layout.addDrawerListener(actionBarToggle)
            drawer_layout.addDrawerListener(object : DrawerLayout.DrawerListener {
                override fun onDrawerSlide(drawerView: View, slideOffset: Float) {
                }

                override fun onDrawerOpened(drawerView: View) {

                    GoogleAnalyticsEvent.logAdapter(
                        GoogleAnalyticsEvent.mainScreen,
                        GoogleAnalyticsEvent.drawer,
                        GoogleAnalyticsEvent.open
                    )
                    // GoogleAnalyticsEvent.passEvent_forActivity(this@MainActivity, GoogleAnalyticsEvent.main_screen, GoogleAnalyticsEvent.drawer_button)
                    Config(this@MainActivity).side_click = slide_click
                    if (Config(this@MainActivity).side_click == 3) {
                        Log.w(
                            TAG,
                            "onDrawerOpened:is_homescreen_drawer_interstitial_enable=  " + FirebaseConfigHelper.remoteConfig.getBoolean(
                                FirebaseConfigHelper.is_homescreen_drawer_interstitial_enable
                            )
                        )
                        if (!FirebaseConfigHelper.getIsAppAdFree(this@MainActivity) && FirebaseConfigHelper.remoteConfig.getBoolean(
                                FirebaseConfigHelper.is_homescreen_drawer_interstitial_enable
                            )
                        ) {
                            val admob_int = FirebaseConfigHelper.getAdmob_int(this@MainActivity)
                            val admob_back_int = FirebaseConfigHelper.getAdmobBack_int(this@MainActivity)
                            val admob_rewared = FirebaseConfigHelper.getAdmobRewared(this@MainActivity)
                            val admob_back_rewared = FirebaseConfigHelper.getAdmobBackRewared(this@MainActivity)
                            val admob_rewared_int = FirebaseConfigHelper.getAdmobRewaredInt(this@MainActivity)
                            val admob_back_rewared_int = FirebaseConfigHelper.getAdmobBackRewaredInt(this@MainActivity)

                            InterstitialAdLoader.showAdWithControl(
                                this@MainActivity,
                                FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_interstitial_control),
                                false,
                                object : InterstitialAdLoader.adfinishwithControl {
                                    override fun adfinished() {
                                        FirebaseConfigHelper.logMethod("adfinished  ", "drawer open ")
                                    }


                                    override fun rewaredfailed() {
                                        FirebaseConfigHelper.logMethod("rewaredfailed  ", "drawer open ")

                                    }
                                },
                                admob_int,
                                admob_back_int,
                                admob_rewared,
                                admob_back_rewared,
                                admob_rewared_int,
                                admob_back_rewared_int,
                                FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.back_id_required),
                                GoogleAnalyticsEvent.mainScreen + "_drawer_open",
                                GalleryMainApplication.getInstance()?.firebaseAnalytics,

                                )

                            slide_click = 0
                            Config(this@MainActivity).side_click = 0
                        }
                    }
                    slide_click++
                }

                override fun onDrawerClosed(drawerView: View) {
                }

                override fun onDrawerStateChanged(newState: Int) {
                }

            })
            actionBarToggle.syncState()
            supportActionBar?.setDisplayHomeAsUpEnabled(true)
            loadMenuIcon()
            checkIsAppLiveorNot()
            navigation.setNavigationItemSelectedListener {
                when (it.itemId) {
                    R.id.favorites -> {
                        GoogleAnalyticsEvent.logAdapter(
                            GoogleAnalyticsEvent.mainScreen,
                            GoogleAnalyticsEvent.drawer,
                            GoogleAnalyticsEvent.drawer_favourites
                        )

                        openFavorite()

                        drawer_layout.closeDrawer(GravityCompat.START)
                    }
                    R.id.recycle_bin -> {
                        GoogleAnalyticsEvent.logAdapter(
                            GoogleAnalyticsEvent.mainScreen,
                            GoogleAnalyticsEvent.drawer,
                            GoogleAnalyticsEvent.recycleBin
                        )
                        openRecyclebin()
                    }
                    R.id.duplicare_find -> {
                        GoogleAnalyticsEvent.logAdapter(
                            GoogleAnalyticsEvent.mainScreen,
                            GoogleAnalyticsEvent.drawer,
                            GoogleAnalyticsEvent.removeDuplicateImages
                        )
                        if (theme == false) {
                            val i = Intent(this, GroupActivityBlack::class.java)
                            i.putExtra("image_count", imageCount)
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            startActivity(i)
                        } else {
                            val i = Intent(this, GroupActivity::class.java)
                            i.putExtra("image_count", imageCount)
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            startActivity(i)
                        }
                    }
                    R.id.dark_themes -> {
                        GoogleAnalyticsEvent.logAdapter(
                            GoogleAnalyticsEvent.mainScreen,
                            GoogleAnalyticsEvent.drawer,
                            GoogleAnalyticsEvent.themes
                        )
                        drawer_layout.closeDrawer(GravityCompat.START)


                        openTheme()
                        // showAlertDialog()

                    }
                    R.id.pass_hidden -> {
                        GoogleAnalyticsEvent.logAdapter(
                            GoogleAnalyticsEvent.mainScreen,
                            GoogleAnalyticsEvent.drawer,
                            GoogleAnalyticsEvent.lockPrivateFiles
                        )
                        val menu: Menu = navigation.menu
                        val menuItem: MenuItem = menu.findItem(R.id.pass_hidden)
                        val actionView: View = MenuItemCompat.getActionView(menuItem)
                        switch = actionView.findViewById(R.id.drawer_switch)
                        openSecurityDialogHiddenProtect()
                    }
                    R.id.settings -> {
                        GoogleAnalyticsEvent.logAdapter(
                            GoogleAnalyticsEvent.mainScreen,
                            GoogleAnalyticsEvent.drawer,
                            GoogleAnalyticsEvent.settings
                        )

                        launchSettings()

                        if (drawer_layout.isDrawerOpen(GravityCompat.START)) {
                            drawer_layout.closeDrawers()
                        }
                    }
                    R.id.donation -> Toast.makeText(this, "DONATION", Toast.LENGTH_LONG).show()
                    R.id.game -> Toast.makeText(this, "GAME", Toast.LENGTH_LONG).show()
                    R.id.rate_us -> Toast.makeText(this, "RATE US", Toast.LENGTH_LONG).show()
                    R.id.about -> {
                        GoogleAnalyticsEvent.logAdapter(
                            GoogleAnalyticsEvent.mainScreen,
                            GoogleAnalyticsEvent.drawer,
                            GoogleAnalyticsEvent.aboutUs
                        )
                        openAbout()
                    }
                }
                true
            }

            removeAds.setOnClickListener {
                GoogleAnalyticsEvent.logAdapter(
                    GoogleAnalyticsEvent.mainScreen,
                    GoogleAnalyticsEvent.drawer,
                    GoogleAnalyticsEvent.getPremiumVersion
                )
                if (FirebaseConfigHelper.isNetworkConnected(this@MainActivity)) {
                    val intent = Intent(this@MainActivity, SubScription_RemoveAdsActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    intent.putExtra("isFrom", GoogleAnalyticsEvent.drawer)
                    startActivity(intent)
                } else {
                    toast("No Internet !, please try again later.")
                }
            }
            navigation.setBackgroundColor(baseConfig.backgroundColor)
            navigation.itemTextColor = ColorStateList.valueOf(baseConfig.textColor)
            navigation.itemIconTintList = ColorStateList.valueOf(Color.parseColor("#007AFF"))
            val viewPager2: ViewPager2 = findViewById(R.id.view_pager_2)

            val fragmentList = arrayListOf(
                albumFragment!!,
                AllMediaFragment.newInstance()
            )

            val talLabels = arrayListOf(
                "Album",
                "All Media"
            )

            viewPager2.adapter = ViewPagerAdapter(this, fragmentList)
            TabLayoutMediator(tab_layout, viewPager2) { tab, position ->
                tab.text = talLabels[position]
            }.attach()
            tab_layout.getTabAt(0)?.setIcon(R.drawable.album_48)
            tab_layout.getTabAt(1)?.setIcon(R.drawable.media_48)

            tab_layout.getTabAt(0)?.icon?.setColorFilter(resources.getColor(R.color.commonInTheme), PorterDuff.Mode.SRC_IN)
            tab_layout.getTabAt(1)?.icon?.setColorFilter(baseConfig.textColor, PorterDuff.Mode.SRC_IN)

            if (theme) {
                tab_layout.setTabTextColors(resources.getColor(R.color.dark_), resources.getColor(R.color.commonInTheme))
            } else {
                tab_layout.setTabTextColors(resources.getColor(R.color.light_), resources.getColor(R.color.commonInTheme))
            }
            tab_layout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
                override fun onTabSelected(tab: TabLayout.Tab?) {
                    if (tab != null) {
                        tab_layout.getTabAt(tab.position)?.icon?.setColorFilter(resources.getColor(R.color.commonInTheme), PorterDuff.Mode.SRC_IN)
                    }
                    if (tab != null) {
                        Log.d("MAIN_SCREEN", tab.text as String)
                        if ((tab.text as String).equals("Album")) {
                            GoogleAnalyticsEvent.logAdapter(
                                GoogleAnalyticsEvent.mainScreen,
                                GoogleAnalyticsEvent.swipe,
                                GoogleAnalyticsEvent.album
                            )
                        } else {
                            GoogleAnalyticsEvent.logAdapter(
                                GoogleAnalyticsEvent.mainScreen,
                                GoogleAnalyticsEvent.swipe,
                                GoogleAnalyticsEvent.all_media
                            )
                        }
                    }
                }

                override fun onTabUnselected(tab: TabLayout.Tab?) {
                    if (tab != null) {
                        tab.position?.let { tab_layout.getTabAt(it)?.icon?.setColorFilter(baseConfig.textColor, PorterDuff.Mode.SRC_IN) }
                    }
                }

                override fun onTabReselected(tab: TabLayout.Tab?) {
                }

            })
        } catch (e: Exception) {
            Log.w(TAG, "onCreate: ${e.message}")
        }
    }

    private fun loadAds() {
        if (!FirebaseConfigHelper.getIsAppAdFree(this)) {

            val admob_int = FirebaseConfigHelper.getAdmob_int(this)
            val admob_back_int = FirebaseConfigHelper.getAdmobBack_int(this)
            val admob_rewarded = FirebaseConfigHelper.getAdmobRewared(this)
            val admob_back_rewarded = FirebaseConfigHelper.getAdmobBackRewared(this)
            val admob_rewarded_int = FirebaseConfigHelper.getAdmobRewaredInt(this)
            val admob_back_rewarded_int = FirebaseConfigHelper.getAdmobBackRewaredInt(this)

            InterstitialAdLoader.loadAd(
                this,
                FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_interstitial_control),
                admob_int,
                admob_back_int,
                FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.back_id_required),
                admob_rewarded,
                admob_back_rewarded,
                admob_rewarded_int,
                admob_back_rewarded_int,
                "MainActivity", GoogleAnalyticsEvent.mainScreen + "_onCreate",
                GalleryMainApplication.getInstance()?.firebaseAnalytics, {}

            )
        }
    }

    fun dailynotification() {
        val path: String
        val date: String
        val year: Int

        val calendar: Calendar = Calendar.getInstance()
        calendar.set(Calendar.HOUR_OF_DAY, 11)
        calendar.set(Calendar.MINUTE, 40)
        calendar.set(Calendar.SECOND, 0)
//        if (calendar.getTime().compareTo(Date()) < 0) calendar.add(Calendar.DAY_OF_MONTH, 1)

        if (getPictures(5) != null) {
            path = getPictures(5)?.get(0)?.path!!
            date = getPictures(5)?.get(0)?.date!!
            year = getPictures(5)?.get(0)?.year!!
        } else if (getPictures(3) != null) {
            path = getPictures(3)?.get(0)?.path!!
            date = getPictures(3)?.get(0)?.date!!
            year = getPictures(3)?.get(0)?.year!!
        } else if (getPictures(1) != null) {
            path = getPictures(1)?.get(0)?.path!!
            date = getPictures(1)?.get(0)?.date!!
            year = getPictures(1)?.get(0)?.year!!
        } else {
            path = "NOT_DEFINED"
            date = "NOT_DEFINED"
            year = -1
        }
        val dataToPass = Gson().toJson(getPictures(0))

        val intent = Intent(applicationContext, NotificationReceiver::class.java)
        intent.putExtra("image_path", path)
        intent.putExtra("image_date", date)
        intent.putExtra("year_", year)
        intent.putExtra("arrayList", dataToPass)
        val pendingIntent = PendingIntent.getBroadcast(
            applicationContext,
            22,
            intent,
            /*PendingIntent.FLAG_UPDATE_CURRENT*/
            PendingIntent.FLAG_MUTABLE
        )

        val alarmManager = getSystemService(ALARM_SERVICE) as AlarmManager

        if (path != "NOT_DEFINED") {
            alarmManager.setExact(
                AlarmManager.RTC_WAKEUP,
                calendar.timeInMillis,
                pendingIntent
            )
        }
    }


    fun openAbout() {
        val intent = Intent(this, AboutActivity::class.java)
        startActivity(intent)
        if (drawer_layout.isDrawerOpen(GravityCompat.START)) {
            drawer_layout.closeDrawers()
        }
    }

    override fun onResume() {
        super.onResume()
        navigation.setBackgroundColor(baseConfig.backgroundColor)
        navigation.itemTextColor = ColorStateList.valueOf(baseConfig.textColor)
        navigation.itemIconTintList = ColorStateList.valueOf(Color.parseColor("#007AFF"))
        // Theme Config using Shared Preference
        theme = config.theme
        toggleThemeInit(theme)
        invalidateOptionsMenu()
    }

    private fun getPictures(yearAgo: Int): ArrayList<GalleryData>? {
        val arr: ArrayList<GalleryData> = ArrayList<GalleryData>()
        try {

            val calendar: Calendar = Calendar.getInstance()
            val currentDate: Date = calendar.time

            calendar.add(Calendar.YEAR, -yearAgo)
            calendar.add(Calendar.DATE, -1)
            val yearBeforeDate: Date = calendar.time
            val formatter: DateFormat = SimpleDateFormat("dd/MM/yyyy")
            val yearBeforeDate0 = formatter.parse(formatter.format(yearBeforeDate))

            calendar.add(Calendar.DATE, -1)
            val yearBeforeDateTemp = calendar.time
            val yearBeforeDate1 = formatter.parse(formatter.format(yearBeforeDateTemp))

            val cursor = contentResolver?.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                arrayOf(
                    MediaStore.Images.Media._ID,
                    MediaStore.Images.Media.DATA,
                    MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
                    MediaStore.Images.Media.DATE_TAKEN,
                    MediaStore.Images.Media.MIME_TYPE,
                    MediaStore.Images.Media.DATE_ADDED
                ),
                MediaStore.Images.Media.DATE_TAKEN + "<= ? AND " + MediaStore.Images.Media.DATE_TAKEN + ">= ?",
                arrayOf("" + yearBeforeDate0.time, "" + yearBeforeDate1.time),
                MediaStore.Images.Media.DATE_TAKEN + " " + "ASC",
                null
            )
            if (cursor == null) Log.d("IMAGES_NOTIFICATION", "NO IMAGES")
            else {
                Log.d("IMAGES_NOTIFICATION", "___ " + cursor.count + " param + " + yearAgo)

                if (cursor.count == 0) {
                    return null
                }
                try {
                    while (cursor.moveToNext()) {
                        Log.d("IMAGES_NOTIFICATION", cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)) + " param + " + yearAgo)
                        val absolutePath = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA))
                        val miliSeconds = (cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))).toLong()
                        arr.add(
                            GalleryData(
                                absolutePath,
                                DateFormat.getDateInstance().format(miliSeconds),
                                yearAgo
                            )
                        )
                    }
                } catch (e: Exception) {

                } finally {
                    // By Parth Crash Solving 1.0.35
                    cursor.close()
                }
            }
        } catch (e: Exception) {
        }
        return arr
    }


    private fun progressDialogDismiss() {
        if (!isFinishing && progressDialog != null && progressDialog!!.isShowing) {
            progressDialog!!.dismiss()
        }
    }

    private fun showbackDialog(activity: Activity, admob_int: String, admob_back_int: String, back_id_required: String, isNetConnected: Boolean) {
        //  custom dialog

        val builder = AlertDialog.Builder(this)
        val inflater = try {
            application.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        } catch (e: Exception) {
            baseContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        }
        val convertview =
            when (config.theme) {
                true -> inflater.inflate(R.layout.exit_dialog1, null)
                false -> inflater.inflate(R.layout.exit_dialog_dark, null)
            }


        val button_rate = convertview.findViewById<TextView>(R.id.button_rate) as TextView
        val leave_layout = convertview.findViewById<View>(R.id.leave_layout) as RelativeLayout
        val close_app_lay = convertview.findViewById<View>(R.id.close_app_lay) as RelativeLayout
        leave_layout.setPadding(25, 50, 25, 0)
        builder.setView(convertview)
        val button_exit = convertview.findViewById<TextView>(R.id.button_exit) as TextView
        button_exit.setOnClickListener {
            GoogleAnalyticsEvent.logAdapter(
                GoogleAnalyticsEvent.mainScreen,
                GoogleAnalyticsEvent.exitDialog,
                GoogleAnalyticsEvent.exit
            )
//            System.exit(0)
            val startMain = Intent(Intent.ACTION_MAIN)
            startMain.addCategory(Intent.CATEGORY_HOME)
            startMain.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(startMain)
            finishAffinity()
        }

        close_app_lay.setOnClickListener {
            GoogleAnalyticsEvent.logAdapter(
                GoogleAnalyticsEvent.mainScreen,
                GoogleAnalyticsEvent.exitDialog,
                GoogleAnalyticsEvent.close
            )
            if (isNetConnected) {
                InterstitialAdLoader.loadAdmobInt(
                    activity, admob_int, admob_back_int, back_id_required, GoogleAnalyticsEvent.mainScreen,
                    GalleryMainApplication.getInstance()?.firebaseAnalytics,
                    {}

                )
            }
            if (alertDialog1 != null && alertDialog1!!.isShowing) {
                alertDialog1!!.dismiss()
            }
        }

        button_rate.setOnClickListener {
            GoogleAnalyticsEvent.logAdapter(
                GoogleAnalyticsEvent.mainScreen,
                GoogleAnalyticsEvent.exitDialog,
                GoogleAnalyticsEvent.rate
            )
            if (isNetConnected) {
                InterstitialAdLoader.loadAdmobInt(
                    activity, admob_int, admob_back_int, back_id_required, GoogleAnalyticsEvent.mainScreen,
                    GalleryMainApplication.getInstance()?.firebaseAnalytics,
                    {}
                )
            }
            initReview()
            if (alertDialog1 != null && alertDialog1!!.isShowing) {
                alertDialog1!!.dismiss()
            }
        }
        try {
            alertDialog1 = builder.create()
            try {
                val window: Window = alertDialog1!!.window!!
                if (window != null) {
                    window.attributes.windowAnimations = R.style.popup_window_animation
                }
            } catch (e: Exception) {
            }
            if (!activity.isFinishing) {
                alertDialog1?.show()
            }
            alertDialog1?.setOnCancelListener(DialogInterface.OnCancelListener {
                try {
                    if (isNetConnected) {
                        InterstitialAdLoader.loadAdmobInt(
                            activity, admob_int, admob_back_int, back_id_required, GoogleAnalyticsEvent.mainScreen,
                            GalleryMainApplication.getInstance()?.firebaseAnalytics,
                            {}
                        )
                    }

                } catch (e: Exception) {
                    e.printStackTrace()
                }
            })
            alertDialog1?.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        } catch (e: Exception) {
//            System.exit(0)
            val startMain = Intent(Intent.ACTION_MAIN)
            startMain.addCategory(Intent.CATEGORY_HOME)
            startMain.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(startMain)
            finishAffinity()
        }
    }

    override fun onSupportNavigateUp(): Boolean {

        if (this.drawer_layout.isDrawerOpen(GravityCompat.START)) {
            this.drawer_layout.closeDrawer(GravityCompat.START)
        } else {
            this.drawer_layout.openDrawer(GravityCompat.START)

        }
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (actionBarToggle.onOptionsItemSelected(item)) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun loadMenuIcon() {
        try {
            navigation.menu.findItem(R.id.recycle_bin).setIcon(R.drawable.recycle_bin)
            navigation.menu.findItem(R.id.duplicare_find).setIcon(R.drawable.duplicate_img_remover)
            navigation.menu.findItem(R.id.dark_themes).setIcon(R.drawable.theme)
            navigation.menu.findItem(R.id.pass_hidden).setIcon(R.drawable.private_files)
            navigation.menu.findItem(R.id.settings).setIcon(R.drawable.settings)
            navigation.menu.findItem(R.id.donation).setIcon(R.drawable.donate)
            navigation.menu.findItem(R.id.game).setIcon(R.drawable.game)
            navigation.menu.findItem(R.id.rate_us).setIcon(R.drawable.rate)
            navigation.menu.findItem(R.id.about).setIcon(R.drawable.about)
        } catch (e: Exception) {

        }
    }

    fun openFavorite() {
        handleLockedFolderOpening("favorites") { success ->
            if (success) {
                Intent(this, MediaActivity::class.java).apply {
                    putExtra(SKIP_AUTHENTICATION, true)
                    putExtra(DIRECTORY, "favorites")
                    handleMediaIntent(this)
                }
            }
        }

    }


    fun toggleThemeInit(dark: Boolean) {
        val textColor = if (dark) 0xFF333333.toInt() else Color.parseColor("#FFFFFF")
        val accentColor = if (dark) Color.parseColor("#007AFF") else Color.parseColor("#007AFF")
        val backgroundColor = if (dark) Color.parseColor("#FFFFFF") else Color.parseColor("#000000")
        val primaryColor = if (dark) Color.parseColor("#FFFFFF") else Color.parseColor("#000000")
        val navigationColor = if (dark) Color.parseColor("#FFFFFF") else Color.parseColor("#000000")


        window.decorView.setBackgroundColor(backgroundColor)
        updateActionbarColor0(primaryColor)
        updateNavigationBarColor0(navigationColor)
//        updateTextColors0(parentView, textColor, accentColor)
        // updateRecentsAppIcon_()
        saveChangesInit(true, textColor, accentColor, primaryColor, backgroundColor, navigationColor)
    }

    fun updateRecentsAppIcon_() {
        if (baseConfig.isUsingModifiedAppIcon) {
            val appIconIDs = getAppIconIDs()
            val currentAppIconColorIndex = getCurrentAppIconColorIndex()
            if (appIconIDs.size - 1 < currentAppIconColorIndex) {
                return
            }

            val recentsIcon = BitmapFactory.decodeResource(resources, appIconIDs[currentAppIconColorIndex])
            val title = getAppLauncherName()
            val color = baseConfig.backgroundColor

            val description = ActivityManager.TaskDescription(title, recentsIcon, color)
            setTaskDescription(description)
        }
    }

    private fun getCurrentAppIconColorIndex(): Int {
        val appIconColor = baseConfig.appIconColor
        getAppIconColors().forEachIndexed { index, color ->
            if (color == appIconColor) {
                return index
            }
        }
        return 0
    }

    fun updateActionbarColor0(color: Int = baseConfig.primaryColor) {
        supportActionBar?.setBackgroundDrawable(ColorDrawable(color))
        updateActionBarTitle(supportActionBar?.title.toString(), color)
        updateStatusbarColor(color)
        setTaskDescription(ActivityManager.TaskDescription(null, null, color))
    }

    fun updateNavigationBarColor0(color: Int = baseConfig.navigationBarColor) {
        if (baseConfig.navigationBarColor != INVALID_NAVIGATION_BAR_COLOR) {
            try {
                val colorToUse = if (color == -2) -1 else color
                window.navigationBarColor = colorToUse
                if (isOreoPlus()) {
                    if (color.getContrastColor() == 0xFF333333.toInt()) {
                        window.decorView.systemUiVisibility = window.decorView.systemUiVisibility.addBit(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
                    } else {
                        window.decorView.systemUiVisibility = window.decorView.systemUiVisibility.removeBit(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
                    }
                }
            } catch (ignored: Exception) {
            }
        }
    }


    private fun openTheme() {
        val intent = Intent(this@MainActivity, ThemeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        intent.putExtra("isFrom", GoogleAnalyticsEvent.drawer)
        intent.putExtra("from_settings", false)
        startActivity(intent)
    }

    private fun restartAppToChageTheme() {
        Handler().postDelayed({
            finishAffinity()
            val intent = intent
            startActivity(intent.putExtra(SHOW_INT_AD, false))
        }, 100L)

    }

    private fun saveChangesInit(
        finishAfterSave: Boolean,
        textColorParam: Int,
        accentColorParam: Int,
        primaryColorParam: Int,
        backgroundColorParam: Int,
        navigationColorParam: Int
    ) {
        baseConfig.apply {
            textColor = textColorParam
            backgroundColor = backgroundColorParam
            primaryColor = primaryColorParam
            accentColor = accentColorParam
            navigationBarColor = navigationColorParam

            // -1 is used as an invalid value, lets make use of it for white
//            navigationBarColor = if (curNavigationBarColor == INVALID_NAVIGATION_BAR_COLOR) {
//                -2
//            } else {
//                curNavigationBarColor
//            }
        }
    }

    fun updateTextColors0(viewGroup: ViewGroup, tmpTextColor: Int = 0, tmpAccentColor: Int = 0) {
        val textColor = if (tmpTextColor == 0) baseConfig.textColor else tmpTextColor
        val backgroundColor = baseConfig.backgroundColor
        val accentColor = if (tmpAccentColor == 0) {
            when {
                isWhiteTheme() || isBlackAndWhiteTheme() -> baseConfig.accentColor
                else -> baseConfig.accentColor
            }
        } else {
            tmpAccentColor
        }

        val cnt = viewGroup.childCount
        (0 until cnt).map { viewGroup.getChildAt(it) }.forEach {
            when (it) {
                is TabLayout -> it.setTabTextColors(textColor, Color.parseColor("#007AFF"))
                is TextView -> it.setTextColor(textColor)
                is MyTextView -> it.setColors(textColor, accentColor, backgroundColor)
                is MyAppCompatSpinner -> it.setColors(textColor, accentColor, backgroundColor)
                is MySwitchCompat -> it.setColors(textColor, accentColor, backgroundColor)
                is MyCompatRadioButton -> it.setColors(textColor, accentColor, backgroundColor)
                is MyAppCompatCheckbox -> it.setColors(textColor, accentColor, backgroundColor)
                is MyEditText -> it.setColors(textColor, accentColor, backgroundColor)
                is MyAutoCompleteTextView -> it.setColors(textColor, accentColor, backgroundColor)
                is MyFloatingActionButton -> it.setColors(textColor, accentColor, backgroundColor)
                is MySeekBar -> it.setColors(textColor, accentColor, backgroundColor)
                is MyButton -> it.setColors(textColor, accentColor, backgroundColor)
                is MyTextInputLayout -> it.setColors(textColor, accentColor, backgroundColor)
                is ViewGroup -> updateTextColors(it, textColor, accentColor)

            }
        }
    }

    fun openRecyclebin() {
        handleLockedFolderOpening("recycle_bin") { success ->
            if (success) {
                Log.d(TAG, "ITEM CLICKED")
                Intent(this, MediaActivity::class.java).apply {
                    putExtra(SKIP_AUTHENTICATION, true)
                    putExtra(DIRECTORY, "recycle_bin")
                    handleMediaIntent(this)
                }
            }
        }
    }

    private fun openSecurityDialog() {
        val tabToShow = if (config.isAppPasswordProtectionOn) config.appProtectionType else SHOW_ALL_TABS
        SecurityDialog(this, config.appPasswordHash, tabToShow) { hash, type, success ->
            if (success) {
                val hasPasswordProtection = config.isAppPasswordProtectionOn
                //
                /*settings_app_password_protection.isChecked = !hasPasswordProtection*/
                config.isAppPasswordProtectionOn = !hasPasswordProtection
                config.appPasswordHash = if (hasPasswordProtection) "" else hash
                config.appProtectionType = type

                if (config.isAppPasswordProtectionOn) {
                    val confirmationTextId = if (config.appProtectionType == PROTECTION_FINGERPRINT)
                        R.string.fingerprint_setup_successfully else R.string.protection_setup_successfully
                    ConfirmationDialog(this, "", confirmationTextId, R.string.ok, 0) {
                        switch.isChecked = config.isAppPasswordProtectionOn
                    }
                }
            }
            switch.isChecked = config.isAppPasswordProtectionOn
        }
    }

    private fun openSecurityDialogHiddenProtect() {
        val tabToShow = if (config.isHiddenPasswordProtectionOn) config.hiddenProtectionType else SHOW_ALL_TABS
        SecurityDialog(this, config.hiddenPasswordHash, tabToShow) { hash, type, success ->
            if (success) {
                val hasPasswordProtection = config.isHiddenPasswordProtectionOn
                config.isHiddenPasswordProtectionOn = !hasPasswordProtection
                config.hiddenPasswordHash = if (hasPasswordProtection) "" else hash
                config.hiddenProtectionType = type

                if (config.isHiddenPasswordProtectionOn) {
                    val confirmationTextId = if (config.hiddenProtectionType == PROTECTION_FINGERPRINT)
                        R.string.fingerprint_setup_successfully else R.string.protection_setup_successfully
                    ConfirmationDialog(this, "", confirmationTextId, R.string.ok, 0) {
                        switch.isChecked = config.isHiddenPasswordProtectionOn
                    }
                }
            }
            switch.isChecked = config.isHiddenPasswordProtectionOn
        }
    }

    private fun handleMediaIntent(intent: Intent) {
        intent.apply {
            if (mIsSetWallpaperIntent) {
                putExtra(SET_WALLPAPER_INTENT, true)
                startActivityForResult(this, PICK_WALLPAPER)
            } else {
                putExtra(GET_IMAGE_INTENT, mIsPickImageIntent || mIsGetImageContentIntent)
                putExtra(GET_VIDEO_INTENT, mIsPickVideoIntent || mIsGetVideoContentIntent)
                putExtra(GET_ANY_INTENT, mIsGetAnyContentIntent)
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, mAllowPickingMultiple)
                startActivityForResult(this, PICK_MEDIA)
            }
        }
    }


//    private fun showAlertDialog() {
//        try {
//            val view = layoutInflater.inflate(R.layout.change_theme_dialog, null)
//            val builder = AlertDialog.Builder(this)
//            radio_group = view.findViewById(R.id.radio_group1)
//            dark_theme = view.findViewById(R.id.dark_theme)
//            light_theme = view.findViewById(R.id.light_theme)
//            val color = baseConfig.primaryColor
//            if (color == -1 /*white*/) {
//                dark_theme!!.isChecked = false
//                light_theme!!.isChecked = true
//            } else {
//                val colorStateList = ColorStateList(
//                    arrayOf(
//                        intArrayOf(-android.R.attr.state_enabled),
//                        intArrayOf(android.R.attr.state_enabled)
//                    ), intArrayOf(
//                        Color.WHITE //disabled
//                        , Color.WHITE //enabled
//                    )
//                )
//                light_theme!!.setButtonTintList(colorStateList) //set the color tint list
//                light_theme!!.invalidate()
//                dark_theme!!.setButtonTintList(colorStateList) //set the color tint list
//                dark_theme!!.invalidate()
//
//                view.change_theme_bg.setBackgroundColor(getResources().getColor(R.color.black_theme_color_dialog))
//                light_theme!!.setTextColor(getResources().getColor(R.color.white))
//                dark_theme!!.setTextColor(getResources().getColor(R.color.white))
//                dark_theme!!.isChecked = true
//                light_theme!!.isChecked = false
//            }
//            dialog = builder.create().apply {
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//                    setupDialogStuff(view, this)
//                }
//            }
//        } catch (e: Exception) {
//        }
//
//    }

    fun radio_dark_theme(view: View) {
        dialog!!.dismiss()
    }

    fun radio_light_theme(view: View) {
        dialog!!.dismiss()
    }

    fun fireBaseConfigGet() {
        val remoteConfig = FirebaseRemoteConfig.getInstance()
        if (remoteConfig.getString("splesh_screen_ads_show_duration") != "")
            Config(this).spleshAdsShowDuration =
                remoteConfig.getString("splesh_screen_ads_show_duration").toInt()
        Config(this).deleteAdsShow = remoteConfig.getBoolean("delete_ads_show")
        if (remoteConfig.getString("on_delete_ads_show_interval") != "")
            Config(this).deleteAdsShowInterval =
                remoteConfig.getString("on_delete_ads_show_interval").toInt()
        Config(this).exitDialogShow = remoteConfig.getBoolean("exit_dialog_show")
        Config(this).exitThankyouDialogShow = remoteConfig.getBoolean("exit_thankyou_screen_show")
        Config(this).show_native_banner = remoteConfig.getBoolean("bottom_native_or_banner")
        Config(this).show_donation = remoteConfig.getBoolean("show_donation")
        Config(this).home_nativebanner_enable = remoteConfig.getBoolean("home_nativebanner_enable")
        Log.w("firbase", " counter spleshAdsShowDuration" + Config(this).spleshAdsShowDuration)
        Log.w("firbase", " counter deleteAdsShow" + Config(this).deleteAdsShow)
        Log.w("firbase", " counter deleteAdsShowInterval" + Config(this).deleteAdsShowInterval)
        Log.w("firbase", " counter exitDialogShow" + Config(this).exitDialogShow)
        Log.w("firbase", " counter exitThankyouDialogShow" + Config(this).exitThankyouDialogShow)
        Log.w("firbase", " counter show_native_banner" + Config(this).show_native_banner)
        Log.w("firbase", " counter show_donation" + Config(this).show_donation)
        Log.w("firbase", " counter home_nativebanner_enable" + Config(this).home_nativebanner_enable)

    }

    private fun initReview() {

        if (!FirebaseConfigHelper.verifyInstallerId(this@MainActivity) && Build.MANUFACTURER.equals("samsung")) {
            val uri = Uri.parse("https://apps.samsung.com/appquery/AppRating.as?appId=" + packageName)
            val myAppLinkToMarket = Intent(Intent.ACTION_VIEW, uri)
            try {
                startActivity(myAppLinkToMarket)
            } catch (e: ActivityNotFoundException) {
//         Toast.makeText(this, "Impossible to find an application for the market", Toast.LENGTH_LONG).show()
            }
        } else {
            try {
                Log.w("msg", "ThemeKEyboardOpenTestActivit==-=-=-")
                manager = ReviewManagerFactory.create(this)
                val request: com.google.android.play.core.tasks.Task<ReviewInfo> =
                    manager!!.requestReviewFlow()
                request.addOnCompleteListener({ task ->
                    if (task.isSuccessful) {
                        // We can get the ReviewInfo object
                        try {
                            reviewInfo = task.result
                            Log.w("msg", "task<reviewInfo> " + reviewInfo)

                            val flow: com.google.android.play.core.tasks.Task<Void> =
                                manager!!.launchReviewFlow(
                                    this@MainActivity,
                                    reviewInfo!!
                                )
                            flow.addOnCompleteListener({ task1 ->
                                try {
                                    Log.w("task<void>", task1.isComplete.toString() + "")
                                    Log.w("task<void>", task1.isSuccessful.toString() + "")
                                    Log.w("msg", "task<void>" + task1.result)
                                    if (task1.result == null) {
                                        Config(this).saveData(this, PreferenceKeys.SystemDialogOpened, true)
                                        rateUs()
                                    }
                                } catch (e: java.lang.Exception) {
                                    Config(this).saveData(this, PreferenceKeys.SystemDialogOpened, true)
                                    Log.w("msg", "catch : else 1333  ${e.message}")
                                    rateUs()
                                }
                            })
                        } catch (e: java.lang.Exception) {
                            Config(this).saveData(this, PreferenceKeys.SystemDialogOpened, true)
                            Log.w("msg", "catch : else 1338 ${e.message}")
                            rateUs()
                        }
                    } else {
                        Config(this).saveData(this, PreferenceKeys.SystemDialogOpened, true)
                        Log.w("msg", "initReview : else 1340")
                        // There was some problem, continue regardless of the result.
                        rateUs()
                    }
                })
            } catch (e: java.lang.Exception) {
                Config(this).saveData(this, PreferenceKeys.SystemDialogOpened, true)
                rateUs()
            }
        }
    }

    fun rateUs() {
        if (!FirebaseConfigHelper.verifyInstallerId(this@MainActivity) && Build.MANUFACTURER.equals("samsung")) {
            val uri = Uri.parse("https://apps.samsung.com/appquery/AppRating.as?appId=" + packageName)
            val myAppLinkToMarket = Intent(Intent.ACTION_VIEW, uri)
            try {
                startActivity(myAppLinkToMarket)
            } catch (e: ActivityNotFoundException) {
                Log.d("msg", "rateUs:  ${e.message}")
//         Toast.makeText(this, "Impossible to find an application for the market", Toast.LENGTH_LONG).show()
            }
        } else {
            Log.w("msg", "rateUs: ---else ")
            val uri = Uri.parse("market://details?id=" + packageName)
            val myAppLinkToMarket = Intent(Intent.ACTION_VIEW, uri)
            try {
                startActivity(myAppLinkToMarket)
            } catch (e: ActivityNotFoundException) {
                Log.d("msg", "rateUs: else  ${e.message}")
//         Toast.makeText(this, "Impossible to find an application for the market", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun checkIsAppLiveorNot() {
        try {

            FirebaseConfigHelper.logMethod(
                "checkIsAppLiveorNot", "boolean is_app_redirect_immediate net " + FirebaseConfigHelper.remoteConfig.getBoolean(
                    FirebaseConfigHelper.is_app_redirect_immediate
                )
            )
            FirebaseConfigHelper.logMethod(
                "checkIsAppLiveorNot", "boolean is_app_live net " + FirebaseConfigHelper.remoteConfig.getBoolean(
                    FirebaseConfigHelper.is_app_live
                )
            )
            FirebaseConfigHelper.logMethod(
                "checkIsAppLiveorNot", "boolean app_redirect_package net " + FirebaseConfigHelper.remoteConfig.getBoolean(
                    FirebaseConfigHelper.app_redirect_package
                )
            )
            if (FirebaseConfigHelper.isNetworkConnected(this@MainActivity)) {
                val hl = Handler()
                val rbl = Runnable {
                    val liveAppActivity = LiveAppActivity()
                    FirebaseConfigHelper.logMethod(
                        "checkIsAppLiveorNot",
                        "boolean is_app_redirect_immediate net " + FirebaseConfigHelper.remoteConfig.getBoolean(
                            FirebaseConfigHelper.is_app_redirect_immediate
                        )
                    )
                    // Hardik  v1.7.0.0 new Solution getResources().getDrawable()
                    liveAppActivity.checkAppisLiveOrNot(
                        this@MainActivity,
                        this@MainActivity,
                        FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.is_app_live),
                        FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.is_app_redirect_immediate),
                        FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.app_redirect_package),
                        resources.getDrawable(R.drawable.shape_g_data),
                        resources.getDrawable(R.drawable.shape_g_border)
                    )
                }
                hl.postDelayed(rbl, 3000)
            }
        } catch (e: java.lang.Exception) {
            FirebaseConfigHelper.logMethod(
                "checkIsAppLiveorNot error ",
                " mFirebaseRemoteConfig List  admob_ boolean is_app_redirect_immediate  Catch " + e.message
            )
        }
    }

    private fun updateChecker() {
        Log.w(TAG, " Main act updateChecker ")
        try {
            inAppUpdateManager = InAppUpdateManager.Builder(this, REQ_CODE_VERSION_UPDATE)
                .resumeUpdates(true)
                .mode(if (FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.immediate_update_mode)) Constants.UpdateMode.IMMEDIATE else Constants.UpdateMode.FLEXIBLE)
                .snackBarMessage("An update has just been downloaded.")
                .snackBarAction("RESTART")
                .useCustomNotification(true)
                .handler(this@MainActivity)
            inAppUpdateManager!!.checkForAppUpdate()
        } catch (e: java.lang.Exception) {
        }
    }

    fun closeDrawer() {
        drawer_layout.closeDrawer(GravityCompat.START)
    }


    fun alert(message: String) {
        try {
            if (!isFinishing) {
                val bld = android.app.AlertDialog.Builder(this@MainActivity)
                bld.setMessage(message)
                //                 bld.setNeutralButton("OK", null)
                bld.setNeutralButton(R.string.ok, null)
                Log.w("msg", "inAppPurchase Showing alert dialog: $message")
                bld.create().show()
            }
        } catch (e: java.lang.Exception) {
        }
    }


    override fun onPause() {
        super.onPause()
        Log.d("Pause", " - - - - - - - - - -  - - - - -  - onPause")
    }

    @RequiresApi(Build.VERSION_CODES.R)
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (mHelper == null) return
        Log.w("msg", "OnActivityResult===$requestCode--$resultCode")
        if (!mHelper!!.handleActivityResult(
                requestCode,
                resultCode, data
            )
        ) {
            if (requestCode == 4466 && resultCode == Activity.RESULT_OK) {
                Log.d("MEDIA_ACTIVITY_RESULT", "RESULT All Media Fragment____________________________________________________________ 1")
                val uris: ArrayList<Uri> = intent?.getParcelableArrayListExtra<Uri>("uriPaths")!!
                for (i in uris) {
                    Log.d("MEDIA_ACTIVITY_RESULT", uris.toString())
                    renameFile(i, ".${File(i.path).name}")
                }
            } else if (requestCode == 4455 && resultCode == Activity.RESULT_OK) {
                Log.d("MEDIA_ACTIVITY_RESULT", "RESULT ALL MEDIA____________________________________________________________ 2")
                try {
                    // Log.d("INTENTNULLORONOT","=sdgs===" + (resultData?.getStringExtra("newName")==null).toString() + " +++ "+ intent.getStringExtra("newName"))
                    renameFile(Uri.parse(intent?.getStringExtra(CURRENT_PATH)), intent?.getStringExtra(NEW_NAME))
                } catch (e: Exception) {
                }
            } else if (requestCode == 7894) {
                if (resultCode == Activity.RESULT_OK) {
                    Log.d("MOVE_INTENT", "-------------------------------ALLOW")
                    getMediaAdapter()?.moveMultipleFiles()

                } else {
                    Log.d("MOVE_INTENT", "-------------------------------DENY")
                }
            } else if (requestCode == 3368) {
                if (resultCode == Activity.RESULT_OK) {
                    Log.d("DELETE_INTENT", "-------------------------------ALLOW_")
                } else {
                    Log.d("DELETE_INTENT", "-------------------------------DENY_")
                    getMediaAdapter()?.deleteFromRecycleBin()
                }

            } else if (requestCode == 4488) {
                if (resultCode == Activity.RESULT_OK) {
                    getMediaAdapter()?.renameMultipleFiles()
                    Log.d("DELETE_INTENT", "-------------------------------ALLOW")
                } else {
                    Log.d("DELETE_INTENT", "-------------------------------DENY")
                }
            }
            if (requestCode == REQ_CODE_VERSION_UPDATE) {
                if (resultCode == RESULT_CANCELED) {
                    // If the update is cancelled by the user,
                    // you can request to start the update again.
                    if (FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.immediate_update_mode)) {
                        PreferenceAds.saveToShowOpenAd(this@MainActivity, false)
                        inAppUpdateManager!!.checkForAppUpdate()
                    } else {
                        PreferenceAds.saveToShowOpenAd(this@MainActivity, true)
                    }
                    Log.w(TAG, "Update flow failed! Result code: $resultCode")
                }
            }
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    fun getMediaAdapter() = media_grid_fragment.adapter as? MediaAdapter

    fun showErrorToast() {
        Toast.makeText(this@MainActivity, "Something Went Wrong , Please Try Again Later...", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {

        Log.w("msg", "MainAct_ondestroy== ")
        if (alertDialog1 != null && alertDialog1?.isShowing!!) {
            alertDialog1?.dismiss()
        }
        try {
            if (!isFinishing && dialog != null && dialog?.isShowing!!) {
                dialog!!.dismiss()
            }
            progressDialogDismiss()
        } catch (e: Exception) {
        }
        super.onDestroy()
        Log.w("msg", "MainAct_ondestroy After== ")
    }

    override fun onInAppUpdateError(code: Int, error: Throwable?) {
        PreferenceAds.saveToShowOpenAd(this@MainActivity, true)
        Log.w(TAG, "Main act onInAppUpdateError $code")
    }

    override fun onInAppUpdateStatus(status: InAppUpdateStatus?) {
        Log.w(TAG, "Main act onInAppUpdateStatus $status")
        try {
            if (status!!.isDownloaded) {
                Log.w(TAG, "Main act onInAppUpdateStatus isDownloaded ")
                val snack = Snackbar.make(findViewById(android.R.id.content), "An update has just been downloaded.", Snackbar.LENGTH_INDEFINITE)
                snack.setAction("RESTART", object : View.OnClickListener {
                    override fun onClick(p0: View?) {
                        PreferenceAds.saveToShowOpenAd(this@MainActivity, true)
                        if (SystemClock.elapsedRealtime() - mLastClickTime < 700) {
                            return
                        }
                        mLastClickTime = SystemClock.elapsedRealtime()
                        inAppUpdateManager!!.completeUpdate()
                    }
                })
                snack.show()
            }
        } catch (e: Exception) {
        }
    }

    override fun onInternetConnectivityChanged(isConnected: Boolean) {
        if (isConnected) {
            try {
                headerView = navigation.getHeaderView(0)
                main_ads_header = headerView.findViewById(R.id.main_ads_header)
                line_view_drawer = headerView.findViewById(R.id.line_view_drawer)

                main_ads_header.visibility = View.VISIBLE
                line_view_drawer.visibility = View.VISIBLE
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun loadInterstitialAds() {
        if (!FirebaseConfigHelper.getIsAppAdFree(this)) {

            val admob_int = FirebaseConfigHelper.getAdmob_int(this)
            val admob_back_int = FirebaseConfigHelper.getAdmobBack_int(this)
            val admob_rewarded = FirebaseConfigHelper.getAdmobRewared(this)
            val admob_back_rewarded = FirebaseConfigHelper.getAdmobBackRewared(this)
            val admob_rewarded_int = FirebaseConfigHelper.getAdmobRewaredInt(this)
            val admob_back_rewarded_int = FirebaseConfigHelper.getAdmobBackRewaredInt(this)

            InterstitialAdLoader.loadAd(
                this,
                FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_interstitial_control),
                admob_int,
                admob_back_int,
                FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.back_id_required),
                admob_rewarded,
                admob_back_rewarded,
                admob_rewarded_int,
                admob_back_rewarded_int, this.javaClass.simpleName, GoogleAnalyticsEvent.mainScreen,
                GalleryMainApplication.getInstance()?.firebaseAnalytics,
                { }
            )
        }
    }

    override fun onBackPressed() {
        GoogleAnalyticsEvent.logAdapter(
            GoogleAnalyticsEvent.mainScreen,
            GoogleAnalyticsEvent.exitDialog,
            GoogleAnalyticsEvent.opened
        )
        if (this.drawer_layout.isDrawerOpen(GravityCompat.START)) {
            this.drawer_layout.closeDrawer(GravityCompat.START)
        } else {
            this.drawer_layout.closeDrawer(GravityCompat.START)
            if (!FirebaseConfigHelper.getIsAppAdFree(this)) {
                exitDialog()
            } else {
                doubleTapForExit()
            }


        }
    }

    private fun doubleTapForExit() {
        if (doubleBackToExitPressedOnce) {
            doubleBackToExitPressedOnce = false
            super.onBackPressed()
            return
        }
        doubleBackToExitPressedOnce = true
        Toast.makeText(this, "Please click back again to exit", Toast.LENGTH_SHORT).show()
        Handler(Looper.getMainLooper()).postDelayed({ doubleBackToExitPressedOnce = false }, 2000)

    }
    private fun exitDialog() {
        val back_id_required = FirebaseConfigHelper.isBackIdRequired(this)
        val admobBanner = FirebaseConfigHelper.getAdmobBanner(this)
        val admobBackBanner = FirebaseConfigHelper.getAdmobBackBanner(this)
        val dialog = BottomSheetDialog(this, R.style.MaterialAlertDialog_rounded)
        val binding = BottomsheetExitBinding.inflate(layoutInflater)
        with(binding) {
            if (config.theme) {
                rlMainLay.setBackground(
                    resources.getColoredDrawableWithColor(
                        R.drawable.ic_permission_bottomsheet,
                        ContextCompat.getColor(this@MainActivity, R.color.ad_loaded_main_bg)
                    )
                )


                txtAdLoading.setTextColor(ContextCompat.getColor(this@MainActivity, R.color.exit_text_color))
                txtExit.setTextColor(ContextCompat.getColor(this@MainActivity, R.color.exit_text_color))
                clExit.setBackground(
                    resources.getColoredDrawableWithColor(
                        R.drawable.ic_permission_bottomsheet,
                        ContextCompat.getColor(this@MainActivity, R.color.white)
                    )
                )

            } else {
                rlMainLay.setBackground(
                    resources.getColoredDrawableWithColor(
                        R.drawable.ic_permission_bottomsheet,
                        ContextCompat.getColor(this@MainActivity, R.color.permission_bg_bottomsheet_dark)
                    )
                )
                clExit.setBackground(
                    resources.getColoredDrawableWithColor(
                        R.drawable.ic_permission_bottomsheet,
                        ContextCompat.getColor(this@MainActivity, R.color.black_exit)
                    )
                )
                txtAdLoading.setTextColor(ContextCompat.getColor(this@MainActivity, R.color.exit_text_color_dark))
                txtExit.setTextColor(ContextCompat.getColor(this@MainActivity, R.color.white))
            }
        }
        if (FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.isHomeExitBannerAdEnable) && FirebaseConfigHelper.isNetworkConnected(
                this
            )
        ) {
            BannerAds.loadAdmob_BannerADs(
                this, binding.bannerAdLay, admobBanner, admobBackBanner,
                back_id_required,
                FirebaseConfigHelper.remoteConfig.getString(
                    FirebaseConfigHelper.HomeExitBannerAdType
                ),
                false,
                object : BannerAds.AdFinishedCallback {
                    override fun adFinished() {


                        binding.rlMainBannerAdLay.beVisible()
                        binding.ivAdIsLoadingJson.beGone()
                    }

                    override fun adFailedtoshow() {
                        binding.rlMainLay.setBackground(
                            resources.getColoredDrawableWithColor(
                                R.drawable.corenered_layout,
                                ContextCompat.getColor(this@MainActivity, R.color.white)
                            )
                        )

                        binding.rlMainBannerAdLay.beGone()
                        binding.ivAdIsLoadingJson.beVisible()
                    }

                },
                GoogleAnalyticsEvent.mainScreen,
                GalleryMainApplication.getInstance()?.firebaseAnalytics,
            )
        } else {
            binding.rlMainBannerAdLay.beGone()
            binding.ivAdIsLoadingJson.beVisible()
        }




        binding.clExit.setOnClickListener {
            finishAffinity()
        }

        dialog.setOnKeyListener(object : DialogInterface.OnKeyListener {
            override fun onKey(dialog: DialogInterface?, keyCode: Int, event: KeyEvent?): Boolean {
                return if (keyCode == KeyEvent.KEYCODE_BACK) {
                    dialog?.cancel()
                    true
                } else {
                    false
                }
            }

        })
        dialog.setContentView(binding.root)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        if (!this.isFinishing) {
            dialog.show()
        }


    }
}
