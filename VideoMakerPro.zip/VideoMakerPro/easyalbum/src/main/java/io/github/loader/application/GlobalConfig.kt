package io.github.loader.application

import android.app.Application
import android.content.Context
//import io.github.loader.BuildConfig

object GlobalConfig {
    @JvmField
    val DEBUG = false

    lateinit var appContext: Context

    fun setAppContext(context: Application) {
        appContext = context
    }
}