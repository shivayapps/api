package io.github.album.interfaces;

public interface AlbumListener {
    void onAlbumClose(boolean hadConfirm);
}
