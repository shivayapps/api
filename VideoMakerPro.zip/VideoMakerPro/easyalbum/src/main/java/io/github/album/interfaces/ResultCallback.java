package io.github.album.interfaces;

import io.github.album.AlbumResult;

public interface ResultCallback {
    void onResult(AlbumResult result);
}
