package com.photo.effect.motion.editor.activities

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.adconfig.adsutil.AdsParameters
import com.adconfig.adsutil.openad.OpenAdHelper
import com.adconfig.adsutil.openad.OpenAdHelper.isShowOpenAd
import com.photo.effect.motion.editor.R
import com.photo.effect.motion.editor.util.Preferences

class SplashActivity : BaseActivity() {

    lateinit var preferences: Preferences
    public override fun onCreate(bundle: Bundle?) {
        super.onCreate(bundle)
        enableEdgeToEdge()
        setContentView(R.layout.activity_splash)
        val mainView = findViewById<View>(R.id.main)
        ViewCompat.setOnApplyWindowInsetsListener(mainView) { v: View, insets: WindowInsetsCompat ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            }
            insets
        }

        preferences = Preferences(this)
        initAdSize()
        initView()
    }

    private fun initView() {
        var splashCounter = preferences.splashCounter
        splashCounter++
        preferences.splashCounter = splashCounter

        Log.e("SplashTag", "appOpenCounter:${splashCounter}")
        val AdmobAppOpenId = getString(R.string.open_splash)
        Log.e("SplashTag", "AdmobAppOpenId:${AdmobAppOpenId}")
//        if (splashCounter % 3 == 0) {
        Log.e("SplashTag", "appOpenCounter%7-true")
        createTimerSec()
        OpenAdHelper.loadOpenAdId(this, {
            countDownTimer.cancel()
            isShowOpenAd { isLoaded ->//onAdClosed
//                if (!isLoaded) {
//                    splashCounter--
//                    preferences.splashCounter = splashCounter
//                } else {
//                    preferences.isNeedInterAd = false
//                }
                startActivity(nextScreen())
            }
        }, AdmobAppOpenId)
//        } else {
//            Log.e("SplashTag", "appOpenCounter%2-else")
//            gotoMainScreen()
//        }
    }

    private fun gotoMainScreen() {
        Log.e("SplashTag", "gotoMainScreen")
        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(nextScreen())
        }, 100)
    }

    private lateinit var countDownTimer: CountDownTimer
    private fun createTimerSec() {

        val totalTimeMillis = 6

        countDownTimer = object : CountDownTimer(totalTimeMillis * 1000L, 1000) {

            override fun onTick(l: Long) {

            }

            override fun onFinish() {
                gotoMainScreen()
            }
        }
        countDownTimer.start()
    }


    private fun nextScreen(): Intent {
        Log.e("SplashTag", "nextScreen call")

        var intent = Intent(this, MainActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return intent
    }

    private fun initAdSize() {
        val display = windowManager.defaultDisplay
        val outMetrics = DisplayMetrics()
        display.getMetrics(outMetrics)
        val widthPixels = outMetrics.widthPixels.toFloat()

        val density = outMetrics.density
        val adWidth = (widthPixels / density).toInt()

        AdsParameters(this@SplashActivity).adWidth = adWidth
    }

    public override fun onDestroy() {
        super.onDestroy()
    }
}
