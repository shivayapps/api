package com.photo.effect.motion.editor.activities;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.MediaController;
import android.widget.VideoView;

import androidx.activity.EdgeToEdge;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.photo.effect.motion.editor.R;

public class VideoPlayerActivity extends BaseActivity implements View.OnClickListener {

    public MediaController mediaController;
    Uri uri = null;

    public VideoView videoView;


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_video_player);

        View mainView = findViewById(R.id.main);
        ViewCompat.setOnApplyWindowInsetsListener(mainView, (v, insets) -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            }
            return insets;
        });
        addControls();
        getDataShowVideo();
    }

    private void getDataShowVideo() {
        this.uri = (Uri) getIntent().getParcelableExtra("VIDEO");
        if (this.mediaController == null) {
            MediaController mediaController2 = new MediaController(this);
            this.mediaController = mediaController2;
            mediaController2.setAnchorView(this.videoView);
            this.videoView.setMediaController(this.mediaController);
        }
        this.videoView.setVideoURI(this.uri);
        this.videoView.requestFocus();
        this.videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            public void onPrepared(MediaPlayer mediaPlayer) {
                VideoPlayerActivity.this.videoView.start();
                mediaPlayer.setOnVideoSizeChangedListener(new MediaPlayer.OnVideoSizeChangedListener() {
                    public void onVideoSizeChanged(MediaPlayer mediaPlayer, int i, int i2) {
                        VideoPlayerActivity.this.mediaController.setAnchorView(VideoPlayerActivity.this.videoView);
                    }
                });
            }
        });
    }

    private void addControls() {
        this.videoView = (VideoView) findViewById(R.id.videoView);
        findViewById(R.id.btnBackFinal).setOnClickListener(this);
    }

    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.btnBackFinal) {
            super.onBackPressed();
        }
    }



    public void onDestroy() {
        super.onDestroy();
    }
}
