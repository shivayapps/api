package com.photo.effect.motion.editor.dialog;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import com.photo.effect.motion.editor.R;
import com.photo.effect.motion.editor.activities.VideoPreviewActivity;


public class ExitDialog extends Dialog {
    Activity context;
    TextView tvDiscard;
    TextView tvKeep;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        getWindow().setGravity(Gravity.BOTTOM);
        getWindow().setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT
        );
    }

    public ExitDialog(Activity activity) {
        super(activity);
        this.context = activity;
        setContentView(R.layout.dialog_exit);
        addControls();
        addEvents();
    }

    private void addEvents() {
        this.tvDiscard.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ExitDialog.this.context.finish();
                if (ExitDialog.this.context instanceof VideoPreviewActivity) {
                    ExitDialog.this.dismiss();
                    ((VideoPreviewActivity) ExitDialog.this.context).destroyMovie();

                }
            }
        });
        this.tvKeep.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ExitDialog.this.dismiss();
            }
        });
    }

    private void addControls() {
        this.tvDiscard = (TextView) findViewById(R.id.tv_discard);
        this.tvKeep = (TextView) findViewById(R.id.tv_keep);
        setCanceledOnTouchOutside(true);
    }
}
