package com.photo.effect.motion.editor.util

import android.content.Context
import android.content.SharedPreferences
import android.os.Environment
import android.text.format.DateFormat
import android.util.Log
import androidx.core.content.ContextCompat
import com.photo.effect.motion.editor.R
import java.lang.reflect.Type;
import java.text.SimpleDateFormat
import java.util.LinkedList
import java.util.Locale


class Preferences(var context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("motioneditor", Context.MODE_PRIVATE)
    private val editor: SharedPreferences.Editor = prefs.edit()


    var isFirstTimeInstall: Boolean
        get() = prefs.getBoolean("isFirstTimeInstall", true)
        set(value) = prefs.edit().putBoolean("isFirstTimeInstall", value).apply()
    var isRatingDone: Boolean
        get() = prefs.getBoolean("isRatingDone", false)
        set(allowVideoGestures) = prefs.edit().putBoolean("isRatingDone", allowVideoGestures).apply()
    var isNeedInterAd: Boolean
        get() = prefs.getBoolean("isNeedInterAd", true)
        set(allowVideoGestures) = prefs.edit().putBoolean("isNeedInterAd", allowVideoGestures).apply()

    var loopVideos: Boolean
        get() = prefs.getBoolean("loop_videos", false)
        set(loop) = prefs.edit().putBoolean("loop_videos", loop).apply()

    var isSetLanguage: Boolean
        get() = prefs.getBoolean("isSetLanguage", false)
        set(isSetLanguage) = prefs.edit().putBoolean("isSetLanguage", isSetLanguage).apply()

    var selectLanguageCode: String
        get() = prefs.getString("KEY_LANGUAGE", "0") ?: "0"
        set(value) = prefs.edit().putString("KEY_LANGUAGE", value).apply()
    var systemLocalLanguage: String
        get() = prefs.getString("systemLocalLanguage", "0") ?: "0"
        set(value) = prefs.edit().putString("systemLocalLanguage", value).apply()

    var appOpenCounter: Int
        get() = prefs.getInt("appOpenCounter", 0)
        set(appOpenCounter) = prefs.edit().putInt("appOpenCounter", appOpenCounter).apply()

    var sessionCounter: Int
        get() = prefs.getInt("sessionCounter", 0)
        set(splashCounter) = prefs.edit().putInt("sessionCounter", splashCounter).apply()

    var splashCounter: Int
        get() = prefs.getInt("splashCounter", 0)
        set(splashCounter) = prefs.edit().putInt("splashCounter", splashCounter).apply()

    var updateCancelCounter: Int
        get() = prefs.getInt("updateCancelCounter", 0)
        set(value) = prefs.edit().putInt("updateCancelCounter", value).apply()

    fun putTheme(themeValue: Int) {
        editor.putInt("key_theme", themeValue)
        editor.apply()
    }

    fun getThemeValue(): Int {
        return prefs.getInt("key_theme", 0)
    }

    fun setSelectLanguage(result: Int) {
        editor.putInt("language", result)
        editor.apply()
    }

    fun getSelectLanguage(): Int {
        return prefs.getInt("language", 0)
    }

    var internalStoragePath: String
        get() = prefs.getString("INTERNAL_STORAGE_PATH", getDefaultInternalPath())!!
        set(internalStoragePath) = prefs.edit().putString("INTERNAL_STORAGE_PATH", internalStoragePath).apply()

    private fun getDefaultInternalPath() = if (prefs.contains("INTERNAL_STORAGE_PATH")) "" else context.getInternalStoragePath()

    private fun getEverShownFolders() = hashSetOf(
        internalStoragePath,
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).absolutePath,
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath,
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).absolutePath,
        "${Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).absolutePath}/Screenshots",
        "$internalStoragePath/WhatsApp/Media/WhatsApp Images",
        "$internalStoragePath/WhatsApp/Media/WhatsApp Images/Sent",
        "$internalStoragePath/WhatsApp/Media/WhatsApp Video",
        "$internalStoragePath/WhatsApp/Media/WhatsApp Video/Sent",
        "$internalStoragePath/WhatsApp/Media/.Statuses",
        "$internalStoragePath/Android/media/com.whatsapp/WhatsApp/Media",
        "$internalStoragePath/Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Images",
        "$internalStoragePath/Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Video"
    )

}