package com.photo.effect.motion.editor.activities;

import static java.lang.System.in;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.adconfig.AdsConfig;
import com.adconfig.adsutil.AdsParameters;
import com.adconfig.adsutil.Config;
import com.adconfig.adsutil.admob.AdmobIntersAdImpl;
import com.adconfig.adsutil.admob.BannerAdHelper;

import com.bumptech.glide.Glide;

import com.google.android.gms.ads.AdView;
import com.photo.effect.motion.editor.util.AdCache;
import com.photo.effect.motion.editor.util.AdManager;
import com.video.photoeditor.activity.EditPhotoActivity;
import com.photo.effect.motion.editor.R;
import com.photo.effect.motion.editor.adapter.PhotoAdapter;
import com.photo.effect.motion.editor.listeners.ItemClickListener;
import com.photo.effect.motion.editor.model.Photo;
import com.photo.effect.motion.editor.view.RoundRectView;
import com.h6ah4i.android.widget.advrecyclerview.draggable.RecyclerViewDragDropManager;

import java.io.File;
import java.util.ArrayList;

import io.github.album.AlbumResult;
import io.github.album.AlbumStyle;
import io.github.album.EasyAlbum;
import io.github.album.MediaData;
import io.github.album.interfaces.AlbumListener;
import io.github.album.interfaces.ResultCallback;
import io.github.loader.Option;
import io.github.loader.TypeMediaFilter;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function3;

public class PickedImagesActivity extends BaseActivity implements View.OnClickListener {
    private LinearLayout btnAddPhoto;
    //    private ImageView btnEditPhoto;
    private LinearLayout btnAddMore;
    private CardView btnMovie;
    private RecyclerViewDragDropManager dragMgr;

    public ImageView imgPhoto;

    public ArrayList<Photo> listPhoto = new ArrayList<>();
    private RoundRectView llHolderRecyclerView;

    public String pathSelected;
    private Photo photo1;

    public PhotoAdapter photoAdapter;
    private ArrayList<String> photos = null;

    public Photo photoselected;

    public int positionSelected = 0;
    private ProgressDialog progressDialog;
    private RecyclerView recyclerPhoto;
    private ArrayList<String> selectedPhotos = new ArrayList<>();
    private ArrayList<String> sendPhotos = new ArrayList<>();
    private Uri uriSelected = null;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_picked_images);

//        if(new AdsParameters(this).isNeedInterAd() && Config.INSTANCE.checkInterAd()) {
        new AdmobIntersAdImpl().load(this, getString(R.string.ads_inter));
//        }

        addControls();
        addRecyclerView();
        addPhoto();


        findViewById(R.id.back).setOnClickListener(view -> {
            onBackPressed();
        });


        LinearLayout adContainer = findViewById(R.id.ad_container);
        //MAX + Fb bidding Ads
//        AdManager.initAD(PickedImagesActivity.this);
//        AdManager.BannerAd(PickedImagesActivity.this, adContainer, getResources().getColor(R.color.bg_color));
//        AdManager.LoadInterstitalAd(PickedImagesActivity.this);

        String adId = getString(R.string.admob_banner_pickimage);
        BannerAdHelper.INSTANCE.showBanner(this, adContainer, adContainer, adId,
                AdCache.bannerPickImage, new Function3<Boolean, AdView, String, Unit>() {
                    @Override
                    public Unit invoke(Boolean aBoolean, AdView adView, String s) {
                        AdCache.bannerPickImage = adView;
                        return null;
                    }
                }, null);

    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(PickedImagesActivity.this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    private void addRecyclerView() {
        this.recyclerPhoto = findViewById(R.id.recyclerPhoto);
        RecyclerViewDragDropManager recyclerViewDragDropManager = new RecyclerViewDragDropManager();
        this.dragMgr = recyclerViewDragDropManager;
        recyclerViewDragDropManager.setInitiateOnMove(false);
        this.dragMgr.setInitiateOnLongPress(true);
        this.recyclerPhoto.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        PhotoAdapter photoAdapter2 = new PhotoAdapter(this.listPhoto, this, new ItemClickListener() {
            public void onItemClick(View view, int i) {
                PickedImagesActivity.this.positionSelected = i;
                PickedImagesActivity selectedPhotoActivity = PickedImagesActivity.this;
                selectedPhotoActivity.photoselected = (Photo) selectedPhotoActivity.listPhoto.get(i);
                PickedImagesActivity selectedPhotoActivity2 = PickedImagesActivity.this;
                selectedPhotoActivity2.pathSelected = selectedPhotoActivity2.photoselected.paths;
                Glide.with(PickedImagesActivity.this).load(PickedImagesActivity.this.photoselected.paths).into(PickedImagesActivity.this.imgPhoto);
            }

            public void onItemDeleteClick(View view, int i) {
                PickedImagesActivity.this.listPhoto.remove(i);
                PickedImagesActivity.this.photoAdapter.notifyDataSetChanged();
            }

            public void onItemEditClick(View view, int i) {
                gotoPhotoEditor();
            }
        });
        this.photoAdapter = photoAdapter2;
        photoAdapter2.setHasStableIds(true);
        this.recyclerPhoto.setAdapter(this.dragMgr.createWrappedAdapter(this.photoAdapter));
        this.dragMgr.attachRecyclerView(this.recyclerPhoto);
    }

    private void addControls() {
        this.llHolderRecyclerView = findViewById(R.id.llRecyclerView);
//        this.btnEditPhoto = findViewById(R.id.btnEditPhoto);
        this.btnMovie = findViewById(R.id.movie_add_float);
        this.btnAddMore = findViewById(R.id.photo_add_float);
        this.btnAddPhoto = findViewById(R.id.movie_add);
        this.imgPhoto = findViewById(R.id.imageViewPhoto);
        this.btnAddMore.setOnClickListener(this);
        this.btnAddPhoto.setOnClickListener(this);
//        this.btnEditPhoto.setOnClickListener(this);
        this.btnMovie.setOnClickListener(this);
    }

    @SuppressLint("RestrictedApi")
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
//        if (i2 == -1 && intent != null && i == ImagePickerActivity.PICKER_REQUEST_CODE) {
//            this.selectedPhotos.clear();
//            ArrayList<String> arrayList = intent.getExtras().getStringArrayList(ImagePickerActivity.KEY_DATA_RESULT);//(ArrayList) Matisse.obtainPathResult(intent);
//
//            this.selectedPhotos = arrayList;
//            if (arrayList != null && !arrayList.isEmpty()) {
//                if (intent != null) {
//                    this.btnAddPhoto.setVisibility(View.GONE);
//                    this.llHolderRecyclerView.setVisibility(View.VISIBLE);
//                    this.btnAddMore.setVisibility(View.VISIBLE);
//                    this.btnEditPhoto.setVisibility(View.VISIBLE);
//                }
//                for (int i3 = 0; i3 < this.selectedPhotos.size(); i3++) {
//                    this.listPhoto.add(new Photo((long) i3, this.selectedPhotos.get(i3)));
//                }
//                this.photo1 = this.listPhoto.get(0);
//                this.uriSelected = Uri.fromFile(new File(this.photo1.paths));
//                Glide.with(this).load(this.uriSelected).into(this.imgPhoto);
//                this.photoAdapter.notifyDataSetChanged();
//            }
//        }
        if (i == 113 && i2 == 115) {
            this.photos = intent.getStringArrayListExtra("AFTER");
            this.selectedPhotos.clear();
            this.sendPhotos.clear();
            this.listPhoto.clear();
            ArrayList<String> arrayList2 = this.photos;
            if (arrayList2 != null) {
                this.selectedPhotos.addAll(arrayList2);
                for (int i4 = 0; i4 < this.selectedPhotos.size(); i4++) {
                    this.listPhoto.add(new Photo((long) i4, this.selectedPhotos.get(i4)));
                }
            }
            this.photo1 = this.listPhoto.get(0);
            this.uriSelected = Uri.fromFile(new File(this.photo1.paths));
            Glide.with((FragmentActivity) this).load(this.uriSelected).into(this.imgPhoto);
        }
    }

    public void onClick(View view) {
        int id = view.getId();

//        if (id == R.id.btnEditPhoto) {
//            gotoPhotoEditor();
//            return;
//        } else
        if (id == R.id.movie_add || id == R.id.photo_add_float) {
            addPhoto();
            return;
        } else if (id == R.id.movie_add_float) {
//            this.photoAdapter.notifyDataSetChanged();
            next();
//            new CreateMovieAsync().execute();
            return;
        } else {
            // No action needed for other IDs
            return;
        }
    }

    private void next() {
        sendPhotos.clear();
        for (int i = 0; i < listPhoto.size(); i++) {
            sendPhotos.add(listPhoto.get(i).paths);
        }

        if (sendPhotos.size() < 3) {
            Toast.makeText(PickedImagesActivity.this, getString(R.string.more_than_3_photos), Toast.LENGTH_SHORT).show();
        } else {
            AdsConfig.Companion.showInterstitialAd(PickedImagesActivity.this, new Function1<Boolean, Unit>() {
                @Override
                public Unit invoke(Boolean aBoolean) {
                    Intent intent = new Intent(PickedImagesActivity.this, VideoPreviewActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putStringArrayList("PHOTO", sendPhotos);
                    intent.putExtras(bundle);
                    startActivity(intent);
                    return null;
                }
            });


        }
    }


    private void addPhoto() {

        EasyAlbum.config().setStyle(new AlbumStyle());
        EasyAlbum.from(this)
                .setFilter(new TypeMediaFilter(Option.ALL))
                .setSelectedLimit(30)
                .setAllString("All Image")
//                .enableOriginal()
                .setAlbumListener(new AlbumListener() {
                    @Override
                    public void onAlbumClose(boolean hadConfirm) {
                        Log.e("EasyAlbum", "setAlbumListener:" + hadConfirm);
                    }
                })
                .start(new ResultCallback() {
                    @Override
                    public void onResult(AlbumResult result) {
                        Log.e("EasyAlbum", "resultListener:" + ", " + result.selectedList.size() + ", " + result.selectedList.get(0).getPath());
                        //replaceCurrentPiece(result.selectedList.get(0).getPath());
//                        selectedPhotos.clear();
//                        ArrayList<String> arrayList = intent.getExtras().getStringArrayList(ImagePickerActivity.KEY_DATA_RESULT);//(ArrayList) Matisse.obtainPathResult(intent);

                        for (MediaData mediaData : result.selectedList) {
                            selectedPhotos.add(mediaData.getPath());
                        }

                        if (selectedPhotos != null && !selectedPhotos.isEmpty()) {
//                            if (intent != null) {
                            btnAddPhoto.setVisibility(View.GONE);
                            llHolderRecyclerView.setVisibility(View.VISIBLE);
                            btnAddMore.setVisibility(View.VISIBLE);
//                            btnEditPhoto.setVisibility(View.VISIBLE);
//                            }
                            for (int i3 = 0; i3 < selectedPhotos.size(); i3++) {
                                listPhoto.add(new Photo((long) i3, selectedPhotos.get(i3)));
                            }
                            photo1 = listPhoto.get(0);
                            uriSelected = Uri.fromFile(new File(photo1.paths));
                            Glide.with(PickedImagesActivity.this).load(uriSelected).into(imgPhoto);
                            photoAdapter.notifyDataSetChanged();
                        }
                    }
                });

//        Intent mIntent = new Intent(PickedImagesActivity.this, ImagePickerActivity.class);
//        mIntent.putExtra(ImagePickerActivity.KEY_LIMIT_MAX_IMAGE, 30);
//        mIntent.putExtra(ImagePickerActivity.KEY_LIMIT_MIN_IMAGE, 4);
//        startActivityForResult(mIntent, ImagePickerActivity.PICKER_REQUEST_CODE);
    }


    public void onPostResume() {
        super.onPostResume();
    }


    public void onDestroy() {
        super.onDestroy();
        Runtime.getRuntime().gc();
    }


    public void onStop() {
        ProgressDialog progressDialog2 = this.progressDialog;
        if (progressDialog2 != null && progressDialog2.isShowing()) {
            this.progressDialog.dismiss();
        }
        super.onStop();
    }


    public void gotoPhotoEditor() {
        Intent intent = new Intent(PickedImagesActivity.this, EditPhotoActivity.class);
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < this.listPhoto.size(); i++) {
            arrayList.add(this.listPhoto.get(i).paths);
        }
        intent.putStringArrayListExtra("PHOTO", arrayList);
        intent.putExtra("POSITION", this.positionSelected);
        if (this.positionSelected < arrayList.size()) {
            startActivityForResult(intent, 113);
        }
    }


}
