package com.photo.effect.motion.editor.util;

import com.google.android.gms.ads.AdView;

public class AdCache {
    public static AdView bannerHome = null;
    public static AdView bannerEdit = null;
    public static AdView bannerPickImage = null;
    public static AdView bannerVideoPreview = null;
    public static AdView bannerShare = null;
}
