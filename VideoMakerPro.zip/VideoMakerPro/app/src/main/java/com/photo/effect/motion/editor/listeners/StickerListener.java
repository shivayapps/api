package com.photo.effect.motion.editor.listeners;

public interface StickerListener {
    void onStickerClick(int i);
}
