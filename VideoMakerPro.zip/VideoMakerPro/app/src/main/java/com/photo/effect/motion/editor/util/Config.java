package com.photo.effect.motion.editor.util;

public class Config {
    public static String FACE = "com.facebook.katana";
    public static String GMAIL = "com.google.android.gm";
    public static String INSTA = "com.instagram.android";
    public static String MESSEGER = "com.facebook.orca";
    public static String TWITTER = "com.twitter.android";
    public static String WHATSAPP = "com.whatsapp";
    public static String YOUTU = "com.google.android.youtube";
}
