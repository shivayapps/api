package com.photo.effect.motion.editor.model;

public class Sample {
    private int imgSample;

    public Sample(int i) {
        this.imgSample = i;
    }

    public Sample() {
    }

    public int getImgSample() {
        return this.imgSample;
    }

    public void setImgSample(int i) {
        this.imgSample = i;
    }
}
