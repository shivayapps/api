package com.photo.effect.motion.editor.util;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;


import com.photo.effect.motion.editor.R;


public class AdManager {
    public static int adCounter = 1;
    public static int adDisplayCounter = 10;

//    public static AlertDialog ProgressDialog;

    public static String REMOTE_AD = "a";

    static void startActivity(Activity context, Intent intent, int requestCode) {
        if (intent != null) {
            context.startActivityForResult(intent, requestCode);
        }
    }



    public static void initAD(Activity activity) {

//        if ( REMOTE_AD.equals("a")) {
//
//            MobileAds.initialize(activity, new OnInitializationCompleteListener() {
//                @Override
//                public void onInitializationComplete(InitializationStatus initializationStatus) {
//                }
//            });
//        }else if (AdManager.REMOTE_AD.equals("f")) {
//            AppLovinSdk.getInstance(activity).setMediationProvider("max");
//            AppLovinSdk.initializeSdk(activity, configuration -> {
//            });
//        }
    }

    public static void BannerAd(Activity activity, LinearLayout linearLayout, int color) {

//        if ( REMOTE_AD.equals("a")) {
//            final AdView mAdView = new AdView(activity);
//            mAdView.setAdSize(AdSize.BANNER);
//            mAdView.setAdUnitId(activity.getString(R.string.admob_banner_id));
//            AdRequest adore = new AdRequest.Builder().build();
//            mAdView.loadAd(adore);
//            linearLayout.addView(mAdView);
//
//
//            mAdView.setAdListener(new AdListener() {
//
//                @Override
//                public void onAdLoaded() {
//                    linearLayout.setVisibility(View.VISIBLE);
//                    super.onAdLoaded();
//
//                    Log.e("ddddd", "dddd");
//                }
//
//                @Override
//                public void onAdOpened() {
//                    super.onAdOpened();
//                    linearLayout.setVisibility(View.GONE);
//                    Log.e("ddddd1", "dddd");
//
//                }
//
//                @Override
//                public void onAdFailedToLoad(LoadAdError loadAdError) {
//                    super.onAdFailedToLoad(loadAdError);
//                    mAdView.destroy();
//                    linearLayout.setVisibility(View.GONE);
//                    Log.e("ddddd2", "dddd" + loadAdError.getMessage());
//
//                }
//            });
//        } else if (REMOTE_AD.equals("f")) {
//
//            maxAdView = new MaxAdView(activity.getResources().getString(R.string.max_banner), activity);
//
//            // Stretch to the width of the screen for banners to be fully functional
//            int width = ViewGroup.LayoutParams.MATCH_PARENT;
//
//            // Banner height on phones and tablets is 50 and 90, respectively
//            int heightPx = activity.getResources().getDimensionPixelSize(R.dimen.banner_height);
//
//            maxAdView.setLayoutParams(new FrameLayout.LayoutParams(width, heightPx));
//
//            // Set background or background color for banners to be fully functional
//            maxAdView.setBackgroundColor(color);
//
//            if (isNetworkConnected(activity)) {
//                linearLayout.addView(maxAdView);
//
//                // Load the banner
//                if (maxAdView != null) {
//                    maxAdView.loadAd();
//                }
//            }
//        }

    }

    static Intent maxIntent;
    static int maxRequstCode;
//    static MaxInterstitialAd maxInterstitialAd;

    static boolean isNetworkConnected(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

        return cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo().isConnected();
    }


//    static MaxAd nativeAd;

    public static void createNativeAdMAX(Activity context, RelativeLayout nativeAdContainer) {

//        if (REMOTE_AD.equals("a")) {
//            AdLoader.Builder builder = new AdLoader.Builder(context, context.getString(R.string.admob_native_id))
//                    .forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
//                        @Override
//                        public void onNativeAdLoaded(NativeAd nativeAd) {
//
//                            NativeAdView adView = (NativeAdView) context.getLayoutInflater()
//                                    .inflate(R.layout.ad_lay, null);
//                            // This method sets the text, images and the native ad, etc into the ad
//                            // view.
//                            populateNativeAdView(nativeAd, adView);
//                            nativeAdContainer.removeAllViews();
//                            nativeAdContainer.addView(adView);
//                        }
//                    });
//
//            VideoOptions videoOptions =
//                    new VideoOptions.Builder().setStartMuted(true).build();
//
//            NativeAdOptions adOptions =
//                    new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
//
//            builder.withNativeAdOptions(adOptions);
//
//            AdLoader adLoader = builder.withAdListener(
//                            new AdListener() {
//                                @Override
//                                public void onAdFailedToLoad(LoadAdError loadAdError) {
//                                }
//                            })
//                    .build();
//
//            adLoader.loadAds(new AdRequest.Builder().build(),10);
//
//        }else if (REMOTE_AD.equals("f")) {
//
//            nativeAd = null;
//            MaxNativeAdLoader nativeAdLoader = new MaxNativeAdLoader(context.getResources().getString(R.string.max_native), context);
//            nativeAdLoader.setNativeAdListener(new MaxNativeAdListener() {
//                @Override
//                public void onNativeAdLoaded(final MaxNativeAdView nativeAdView, final MaxAd ad) {
//                    // Clean up any pre-existing native ad to prevent memory leaks.
//                    if (nativeAd != null) {
//                        nativeAdLoader.destroy(nativeAd);
//                    }
//
//                    // Save ad for cleanup.
//                    nativeAd = ad;
//
//                    // Add ad view to view.
//                    nativeAdContainer.removeAllViews();
//                    nativeAdContainer.addView(nativeAdView);
//                }
//
//                @Override
//                public void onNativeAdLoadFailed(final String adUnitId, final MaxError error) {
//                    // We recommend retrying with exponentially higher delays up to a maximum delay
//                }
//
//                @Override
//                public void onNativeAdClicked(final MaxAd ad) {
//                    // Optional click callback
//                }
//            });
//
//            nativeAdLoader.loadAd();
//        }
    }


}
