package com.flask.colorpicker;

public interface OnColorSelectedListener {
	void onColorSelected(int selectedColor);
}
