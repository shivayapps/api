package com.flask.colorpicker;

public interface OnColorChangedListener {
	void onColorChanged(int selectedColor);
}
