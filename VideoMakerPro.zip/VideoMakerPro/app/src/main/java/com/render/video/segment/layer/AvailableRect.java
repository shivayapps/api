package com.render.video.segment.layer;

import android.graphics.PointF;
import android.graphics.RectF;

/**
 * Created by huangwei on 2015/6/3.
 */
public class AvailableRect {
      public RectF rectF;
      public float rotation;
      /**
       * 为null则以区域中点为中心点
       */
      public PointF rotationPivot;
}
