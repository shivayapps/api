package com.render.video.segment;

import com.render.video.opengl.GLESCanvas;

/**
 * Created by huangwei on 2015/6/29.
 */
public abstract class GLMovieSegment extends MovieSegment<GLESCanvas> {
}
