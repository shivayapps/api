package com.render.video.model;


public class PhotoInfo {
    public Object extra;
    public String description;
}
