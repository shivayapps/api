package com.video.photoeditor.interfaces;

public interface ShadowFragmentListener {
    void onDyShadowChangeListener(int i);

    void onRadiusChangeListener(int i);

    void onShadowColorSelected(int i);
}
