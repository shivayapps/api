package com.video.photoeditor.dialog;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import com.photo.effect.motion.editor.R;

public class DiscardDialog extends Dialog {
    Activity context;
    TextView tvDiscard;
    TextView tvKeep;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        getWindow().setGravity(Gravity.BOTTOM);
        getWindow().setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT
        );
    }

    public DiscardDialog(Activity activity) {
        super(activity);
        this.context = activity;
        setContentView(R.layout.edit_photo_discard_dialog);
        addControls();
        addEvents();
    }

    private void addEvents() {
        this.tvDiscard.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DiscardDialog.this.context.finish();
            }
        });
        this.tvKeep.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DiscardDialog.this.dismiss();
            }
        });
    }

    private void addControls() {
        this.tvDiscard =  findViewById(R.id.tv_discard);
        this.tvKeep =  findViewById(R.id.tv_keep);
        setCanceledOnTouchOutside(true);
    }
}
