package com.video.photoeditor.interfaces;

public interface FontFragmentListener {
    void onFontSelected(String str);
}
