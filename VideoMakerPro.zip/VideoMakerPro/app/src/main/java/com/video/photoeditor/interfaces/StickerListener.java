package com.video.photoeditor.interfaces;

public interface StickerListener {
    void onStickerClick(int i);
}
