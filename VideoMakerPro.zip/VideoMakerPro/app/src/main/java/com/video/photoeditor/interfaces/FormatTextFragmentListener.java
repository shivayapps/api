package com.video.photoeditor.interfaces;

public interface FormatTextFragmentListener {
    void onTextAlign(int i);

    void onTextPadding(int i);

    void onTextSize(int i);

    void onTextStyle(int i);
}
