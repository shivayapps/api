package com.video.photoeditor.interfaces;

public interface SpacingFragmentListener {
    void onLineHeight(int i);

    void onSpacingLetter(float f);
}
