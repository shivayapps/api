package com.video.photoeditor.photoeditor;

public enum ViewType {
    BRUSH_DRAWING,
    TEXT,
    IMAGE,
    EMOJI
}
