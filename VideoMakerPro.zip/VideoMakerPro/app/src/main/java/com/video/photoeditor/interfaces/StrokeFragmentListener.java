package com.video.photoeditor.interfaces;

public interface StrokeFragmentListener {
    void onStrokeColorSelected(int i);

    void onStrokeWidthChangeListener(int i);
}
