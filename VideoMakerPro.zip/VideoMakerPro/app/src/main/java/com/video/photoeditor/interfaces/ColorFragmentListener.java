package com.video.photoeditor.interfaces;

public interface ColorFragmentListener {
    void onColorOpacityChangeListerner(int i);

    void onColorSelected(int i);
}
