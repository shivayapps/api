package com.adconfig.adsutil.openad

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.adconfig.adsutil.openad.OpenAdHelper.isShowOpenAd
import com.adconfig.adsutil.utils.SmUtils.isConnected
import com.adconfig.adsutil.utils.delayExecution
import com.adconfig.adsutil.utils.isAnyAdShowing
import com.adconfig.databinding.ActivityWelcomeBackBinding

import java.util.Timer
import kotlin.concurrent.timerTask

class WelcomeBackActivity : AppCompatActivity() {
    private lateinit var binding: ActivityWelcomeBackBinding
    var isAdShow = false
    var isTimeOver = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWelcomeBackBinding.inflate(layoutInflater)
        setContentView(binding.root)
        if (!isConnected(this)) {
            finish()
            return
        }
        finishAdsTimer()

        if (intent.getBooleanExtra("isAdLoading", false)) {
            startAdsTimer()
            Handler(Looper.getMainLooper()).postDelayed({
                if (!isAdShow) finish()
            }, 500)
        } else {
            if (OpenAdHelper.isAdAvailable()) {
                delayExecution(500) {
                    isAdShow = false
                    isShowOpenAd({
                        Log.e("Sales2", "gotoMainScreen: isShowOpenAd")
                        isAdShow = true
                        if (it) {
                            finish()
                        }
                    })
                }

            } else {
                finish()
//                LogEvent.logEvent("app_appopen_created", "WelcomeBackActivity")
//                OpenAdHelper.destroy()
//                OpenAdHelper.loadOpenAd(applicationContext,
//                    onAdLoad = {
//                        if (isDestroyed || isFinishing) return@loadOpenAd
//                        isAdShow = false
//                        (this).isShowOpenAd({
//                            Log.e("Sales2", "gotoMainScreen: isShowOpenAd")
//                            if (it) finish()
//                        }, onAdLoad = {
//                            Log.e("Sales2", "gotoMainScreen: onAdLoad")
//
//                        }, onAdFailed = {
////                            LogEvent.logEvent("app_ad_appopen_failed", "WelcomeBackActivity")
//                        }, onAdShow = {
//                            Log.e("Sales2", "gotoMainScreen: onAdShow")
//
////                            LogEvent.logEvent("app_ad_appopen_shown", "WelcomeBackActivity")
//                        }, onAdEvent = {
//
//                            if (it) {
//                                isAdShow = true
//                                LogEvent.logEvent("app_ad_appopen_shown", "WelcomeBackActivity")
//                            } else {
//                                LogEvent.logEvent("app_ad_appopen_failed", "WelcomeBackActivity")
//                            }
//                        })
//                    },
//                    onAdFailed = {
//
//                        LogEvent.logEvent("app_ad_appopen_failed", "WelcomeBackActivity")
//                        finish()
//                    }, onAdShow = {
////                        LogEvent.logEvent("app_ad_appopen_shown", "WelcomeBackActivity")
//                    })

//                Handler(Looper.getMainLooper()).postDelayed({
//                    isTimeOver = true
//                    if (!isAdShow) finish()
//                }, 3500)

            }
        }
    }

    private var timer: Timer? = null
    fun startAdsTimer() {
        val timeOut = 500L
        timer?.cancel()
        timer = Timer()
        timer?.schedule(timerTask {
            Log.e("loadNativeCustom", "startAdsTimer: loadNativeAds")

            runOnUiThread {
                if (isDestroyed || isFinishing) return@runOnUiThread
                if (OpenAdHelper.isAdAvailable()) {
                    timer?.cancel()
                    isAdShow = false
                    (this@WelcomeBackActivity).isShowOpenAd({
                        isAdShow = true
                        Log.e("Sales2", "gotoMainScreen: isShowOpenAd")
                        finish()
                    })
                }
            }
        }, timeOut, timeOut)

    }

    private var finishTimer: Timer? = null
    fun finishAdsTimer() {
        val timeOut = 3500L
        finishTimer?.cancel()
        finishTimer = Timer()
        finishTimer?.schedule(timerTask {
            Log.e("finishAdsTimer", "startAdsTimer: finishAdsTimer $isAdShow")
            finishTimer?.cancel()
            isTimeOver = true
            if (!isAdShow) finish()
//            runOnUiThread {
//            }
        }, timeOut, timeOut)

    }

    override fun onPause() {
        super.onPause()
        if (!isAnyAdShowing) {
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        if (isTimeOver) {
            finish()
        }
    }
}