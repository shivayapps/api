package com.adconfig.adsutil.utils

import android.app.Activity
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.annotation.ColorRes
import androidx.core.content.ContextCompat

var isNeedToShowAds = true
var isAppForeground = false
var isAnyAdOpen = false
var isInterstitialAdShow = false

var isAnyAdShowing: Boolean = false
//var openAdCounter: Int = 0
var needToBlockOpenAdInternally: Boolean = false

fun Context.getcolor(@ColorRes id: Int) = ContextCompat.getColor(this, id)

fun Activity.delayExecution(millis: Long, callback: () -> Unit) {
    Handler(Looper.myLooper()!!).postDelayed({
        callback()
    }, millis)
}

fun Context.isOnline(): Boolean {
    val connectivityManager =
        this.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val capabilities =
        connectivityManager.getNetworkCapabilities(connectivityManager.activeNetwork)
    if (capabilities != null) {
        if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
            Log.i("Internet", "NetworkCapabilities.TRANSPORT_CELLULAR")
            return true
        } else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
            Log.i("Internet", "NetworkCapabilities.TRANSPORT_WIFI")
            return true
        } else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
            Log.i("Internet", "NetworkCapabilities.TRANSPORT_ETHERNET")
            return true
        }
    }
    return false
}