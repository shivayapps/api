package com.bankbalanceinquiry.ministatement.adapternew;

import static com.bankbalanceinquiry.ministatement.utils.Constant.findBankIcon;

import android.app.Activity;
import android.graphics.Bitmap;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.adconfig.adsutil.admob.BannerAdHelper;
import com.adconfig.adsutil.admob.NativeAdHelper;
import com.adconfig.adsutil.admob.NativeLayoutType;
import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.common.ReadJsonFile;
import com.bankbalanceinquiry.ministatement.inapp.AdsManager;
import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;
import com.bankbalanceinquiry.ministatement.utils.AdCache;
import com.bankbalanceinquiry.ministatement.utils.TextDrawable;
import com.bankbalanceinquiry.ministatement.utils.NetworkManager;
import com.google.android.gms.ads.AdView;


import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Random;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function3;

public class AllAccountListNewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private final Activity activity;
    public ClickActivDeactiveint clickActivDeactiveint;
    private ArrayList<HomeAccoutList> allAccountModels = new ArrayList<>();
    HashMap<String, HomeAccoutList> hashData = new HashMap<>();
    private ArrayList<Integer> colors = new ArrayList<>();
//    private Object nativeAd = null;

    JSONObject jsonObject;


    public void addData(HomeAccoutList homeAccoutList) {
        String key = homeAccoutList.full_name + "_" + homeAccoutList.FinalAccountNo;
        if (!hashData.containsKey(key)) {
            hashData.put(key, homeAccoutList);
            allAccountModels.add(homeAccoutList);
            notifyItemInserted(allAccountModels.size());

//            insertAdsPos();

        }
    }

    public void updateDataBalance(HomeAccoutList homeAccoutList) {
        String key = homeAccoutList.full_name + "_" + homeAccoutList.FinalAccountNo;
        if (hashData.containsKey(key)) {
            hashData.put(key, homeAccoutList);
            for (int i = 0; i < allAccountModels.size(); i++) {
                String key1 = allAccountModels.get(i).full_name + "_" + allAccountModels.get(i).FinalAccountNo;
                if (key1.equals(key)) {
                    allAccountModels.get(i).FinalAccountBalance = homeAccoutList.FinalAccountBalance;
                    notifyItemChanged(i);
                    break;
                }
            }
        }
    }


    public interface ClickActivDeactiveint {
        void ClickActiveDeactive(int position, int color, HomeAccoutList modelData);

        void ClickBusinessOrPersion(int position);
    }

    public void RegisterInterface(ClickActivDeactiveint photoInterface) {
        this.clickActivDeactiveint = photoInterface;
    }

    public AllAccountListNewAdapter(Activity activity, ArrayList<HomeAccoutList> listOfAllImages) {
        this.activity = activity;
        this.allAccountModels.clear();
        this.allAccountModels.addAll(listOfAllImages);
        hashData.clear();
        this.colors.clear();
        this.colors.add(ContextCompat.getColor(activity, R.color.google_blue));
        this.colors.add(ContextCompat.getColor(activity, R.color.google_red));
        this.colors.add(ContextCompat.getColor(activity, R.color.google_yellow));
        this.colors.add(ContextCompat.getColor(activity, R.color.google_green));

        if (new AdsManager(activity).isNeedToShowAds() && NetworkManager.isInternetConnected(activity)) {
            insertAdsPos();
        }
        jsonObject = ReadJsonFile.GetAssetsFileGetDataJsonObject(activity, "sms/bank_list_icons");
    }

    public void insertAdsPos() {
        removeAdpos();
        if (allAccountModels != null && allAccountModels.size() > 1 && allAccountModels.get(1).getType() != 1) {
            HomeAccoutList info = new HomeAccoutList(1);
            int posToIntert = 1;
            if (allAccountModels.size() > 2) {
                posToIntert = 2;
            }
            allAccountModels.add(posToIntert, info);
            notifyItemInserted(posToIntert);
        }
    }

    Boolean isAdLoaded=false;
    AdView mAdView;
    public void loadNativeAd(AdViewHolder holder1) {

        String adId=activity.getString(R.string.g_banner_acctlist);
        BannerAdHelper.INSTANCE.showBanner(activity, holder1.adLayout, adId, AdCache.Companion.getBannerAcctlist(), new Function3<Boolean, AdView, String, Unit>() {
            @Override
            public Unit invoke(Boolean aBoolean, AdView adView, String s) {
                AdCache.Companion.setBannerAccthist(adView);
                mAdView=adView;
                isAdLoaded=true;
                return null;
            }
        },null);
//        AdmobAdManager.getInstance().LoadNativeAd(activity, activity.getString(R.string.admob_native_id), new AdEventListener() {
//            @Override
//            public void onAdLoaded(Object object) {
//                nativeAd = object;
//                populateNativeAds(holder1);
//                Log.e("JASFCgvacascfszc", "ONLOADFEEDFCF");
//            }
//
//            @Override
//            public void onAdClosed() {
//            }
//
//            @Override
//            public void onLoadError(String errorCode) {
//                Log.e("JASFCgvacascfszc", errorCode + "::");
//                removeAdpos();
//            }
//        }, false);

/*

        AdmobAdManager.getInstance().LoadNativeAdSmall(activity, activity.getString(R.string.native_id), new AdEventListener() {
            @Override
            public void onAdLoaded(Object object) {
                nativeAd = object;
                populateNativeAds(holder1);
            }

            @Override
            public void onAdClosed() {
            }

            @Override
            public void onLoadError(String errorCode) {
                removeAdpos();
            }


*/
/* @Override
            public void onAdLoaded(MaxNativeAdView maxNativeAdView, MaxAd maxAd) {
                nativeAd = maxNativeAdView;
                populateNativeAds(holder1);
            }*//*


        }, 1);
*/


    }

    public int getAdPos() {
        for (int i = 0; i < allAccountModels.size(); i++) {
            if (allAccountModels.get(i).getType() == 1) {
                return i;
            }
        }
        return -1;
    }

    public void removeAdpos() {
        for (int i = 0; i < allAccountModels.size(); i++) {
            if (allAccountModels.get(i).getType() == 1) {
                allAccountModels.remove(i);
                notifyItemRemoved(i);
                break;
            }
        }
    }


    @Override
    public int getItemViewType(int position) {
        return allAccountModels.get(position).getType();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        switch (i) {
            case 1:
                LayoutInflater layoutInflater = LayoutInflater.from(viewGroup.getContext());
                View view = layoutInflater.inflate(R.layout.native_frame_layout, viewGroup, false);
                return new AdViewHolder(view);
            default:
                View view1 = LayoutInflater.from(activity).inflate(R.layout.raw_account_list, viewGroup, false);
                return new MyViewHolder(view1);
        }


    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder1, final int position) {
        if (holder1.getItemViewType() == 0) {
            MyViewHolder holder = (MyViewHolder) holder1;
            if (position != (allAccountModels.size() - 1)) {
                holder.view_space.setVisibility(View.GONE);
            } else {
                holder.view_space.setVisibility(View.VISIBLE);
            }
            final HomeAccoutList alldata = allAccountModels.get(position);
            String AccountNumber = alldata.FinalAccountNo;
            String Date = alldata.dateValAccount;
            String AccountAmount = alldata.FinalAccountBalance;
            String name = alldata.full_name.replace(" Bank", "");
            if (!TextUtils.isEmpty(AccountNumber)) {
                holder.tvBankNameAndAcNo.setText(name + " - " + AccountNumber);
            } else {
                if (alldata.bankNickName != null && !alldata.bankNickName.isEmpty()) {
                    holder.tvBankNameAndAcNo.setText(alldata.bankNickName);
                } else {
                    holder.tvBankNameAndAcNo.setText(name);
                }
            }
            if (!TextUtils.isEmpty(AccountAmount)) {
                if (AccountAmount.contains(",")) {
                    AccountAmount = AccountAmount.replace(",", "");
                }
                double d = 0;
                try {
                    d = Double.parseDouble(AccountAmount);
                } catch (Exception e) {

                }
                NumberFormat nf = NumberFormat.getNumberInstance(Locale.US);
                DecimalFormat decim = (DecimalFormat) nf;
                decim.applyPattern("#,##,###.##");
                if (AccountAmount.contains(".")) {
                    String afterPoint = AccountAmount.substring(AccountAmount.indexOf(".") + 1);
                    if (afterPoint.length() > 2) {
//                        DecimalFormat decim = new DecimalFormat("#,##,###.##");
                        AccountAmount = decim.format(d);
                    }
                }
//                DecimalFormat decim = new DecimalFormat("#,##,###.#");
                AccountAmount = decim.format(d);

                holder.tvBalanceAndDate.setText(activity.getString(R.string.Rs) + " " + AccountAmount);
            } else {
                holder.tvBalanceAndDate.setText("");
            }

            java.util.Date date = new Date(System.currentTimeMillis());
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy", Locale.US);
            String year = simpleDateFormat.format(date);
            String dateVal = Date;
            if (Date.contains(year)) {
                dateVal = Date.replace(" " + year, "");
            }

            holder.tvDate.setText(dateVal);
            String FirstName = alldata.full_name;
            int color = 0;
            Bitmap bb;
            /*if (!TextUtils.isEmpty(getBankName(alldata.full_name))) {
                int id = activity.getResources().getIdentifier(getBankName(alldata.full_name), "drawable", activity.getPackageName());
                if (id != -1) {
                    // bb = BitmapFactory.decodeResource(activity.getResources(), id);
                    holder.ivBankLogo.setImageResource(id);
                } else {
                    Random rnd = new Random();
                    color = colors.get(rnd.nextInt(3));
                    if (!TextUtils.isEmpty(FirstName) && !FirstName.equalsIgnoreCase("")) {
                        String FirstLetter = FirstName.substring(0, 1);
                        TextDrawable drawable = TextDrawable.builder()
                                .buildRound(FirstLetter, color);

                        holder.ivBankLogo.setImageDrawable(drawable);
                    } else {
                        TextDrawable drawable = TextDrawable.builder()
                                .buildRound("U", color);
                        holder.ivBankLogo.setImageDrawable(drawable);
                    }
                }
            } else {
                Random rnd = new Random();
                color = colors.get(rnd.nextInt(3));
                if (!TextUtils.isEmpty(FirstName) && !FirstName.equalsIgnoreCase("")) {
                    String FirstLetter = FirstName.substring(0, 1);
                    TextDrawable drawable = TextDrawable.builder()
                            .buildRound(FirstLetter, color);
                    holder.ivBankLogo.setImageDrawable(drawable);
                } else {
                    TextDrawable drawable = TextDrawable.builder()
                            .buildRound("U", color);
                    holder.ivBankLogo.setImageDrawable(drawable);
                }
            }*/


            String nameImage = findBankIcon(activity, alldata.full_name, jsonObject);
            int id = activity.getResources().getIdentifier(/*"ic_" +*/ nameImage, "drawable", activity.getPackageName());
            if ((nameImage != null) && !(TextUtils.isEmpty(nameImage)) && (id != -1)) {
              /*  istr = assetManager.open("bank_icons/" + nameImage + ".png");
                Bitmap bitmap = BitmapFactory.decodeStream(istr);
                holder.ivBankLogo.setImageBitmap(bitmap);*/
                holder.ivBankLogo.setImageResource(id);
            } else {
                Random rnd = new Random();
                color = colors.get(rnd.nextInt(3));
                if (!TextUtils.isEmpty(FirstName) && !FirstName.equalsIgnoreCase("")) {
                    String FirstLetter = FirstName.substring(0, 1);
                    TextDrawable drawable = TextDrawable.builder()
                            .buildRound(FirstLetter, color);
                    holder.ivBankLogo.setImageDrawable(drawable);
                } else {
                    TextDrawable drawable = TextDrawable.builder()
                            .buildRound("U", color);
                    holder.ivBankLogo.setImageDrawable(drawable);
                }
            }


            final int finalColor = color;
            holder.llMain.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (clickActivDeactiveint != null) {
                        clickActivDeactiveint.ClickActiveDeactive(holder.getLayoutPosition(), finalColor, allAccountModels.get(holder.getLayoutPosition()));
                    }
                }
            });
        } else if (holder1.getItemViewType() == 1) {

//            if (nativeAd != null) {
//                populateNativeAds((AdViewHolder) holder1);
//            } else {
                loadNativeAd((AdViewHolder) holder1);
//            }
        }
    }


    private void populateNativeAds(AdViewHolder holder1) {
//        if (nativeAd instanceof NativeAd) {
//            AdmobAdManager.getInstance()
//                    .populateUnifiedSmallNativeAdView(activity, holder1.adLayout, (NativeAd) nativeAd, false);
//        } /*else {
//            AdmobAdManager.getInstance()
//                    .populateUnifiedSmallNativeApplovin(activity, holder1.adLayout, (MaxNativeAdView) nativeAd, null, false);
//        }*/
    }


    public class AdViewHolder extends RecyclerView.ViewHolder {

        private final FrameLayout adLayout;
        LinearLayout li_adss;

        AdViewHolder(View itemView) {
            super(itemView);
            adLayout = itemView.findViewById(R.id.adLayout);
            li_adss = itemView.findViewById(R.id.li_adss);
        }
    }

    @Override
    public int getItemCount() {
        return allAccountModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private final LinearLayout llMain;
        private final ImageView ivBankLogo;
        private final TextView tvBankNameAndAcNo;
        private final TextView tvBalanceAndDate;
        private final TextView tvDate;
        View view_space;

//        private ImageView ivActiveInActive;
//        private TextView tvActiveInActive;
//
//        private RelativeLayout rlPersonBusiness;
//        private ImageView ivBusinessOrPersion;
//        private TextView tvBusinessOrPersion;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            view_space = itemView.findViewById(R.id.view_space);
            llMain = itemView.findViewById(R.id.llMain);
            ivBankLogo = itemView.findViewById(R.id.ivBankLogo);
            tvBankNameAndAcNo = itemView.findViewById(R.id.tvBankNameAndAcNo);
            tvDate = itemView.findViewById(R.id.tvDDate);
            tvBalanceAndDate = itemView.findViewById(R.id.tvBalanceAndDate);

//            ivActiveInActive = itemView.findViewById(R.id.ivActiveInActive);
//            tvActiveInActive = itemView.findViewById(R.id.tvActiveInActive);
//
//            rlPersonBusiness = itemView.findViewById(R.id.rlPersonBusiness);
//            ivBusinessOrPersion = itemView.findViewById(R.id.ivBusinessOrPersion);
//            tvBusinessOrPersion = itemView.findViewById(R.id.tvBusinessOrPersion);
        }
    }


    private String getBankName(String name) {

        switch (name) {
            case "Allahabad Bank":
                return "ic_alb";
            case "American Express":
                return "ic_aeb";
            case "Andhra Bank":
                return "ic_anb";
            case "Axis Bank":
                return "ic_axb";
            case "Bank of Baroda":
                return "ic_bob";
            case "Bank of India":
                return "ic_boi";
            case "Bank of Maharashtra":
                return "ic_bom";
            case "Corporation Bank":
                return "ic_crb";
            case "Canara Bank":
                return "ic_cnb";
            case "Citibank":
                return "ic_cb";
            case "Deutsche Bank":
                return "ic_db";
            case "Federal Bank":
                return "ic_fbl";
            case "HDFC Bank":
                return "ic_hdf";
            case "HSBC":
                return "ic_hsb";
            case "ICICI Bank":
                return "ic_ici";
            case "IDBI Bank":
                return "ic_idb";
            case "Indian Bank":
                return "ic_inb";
            case "IndusInd Bank":
                return "ic_iib";
            case "Kotak Mahindra Bank":
                return "ic_kmb";
            case "Punjab National Bank":
                return "ic_pnb";
            case "State Bank of India":
                return "ic_sbi";
            case "Standard Chartered":
                return "ic_scb";
            case "Union Bank of India":
                return "ic_uob";
            case "Yes Bank":
                return "ic_ybl";
            case "Central Bank of India":
                return "ic_cbi";
            case "Vijaya Bank":
                return "ic_vjb";
            case "Syndicate Bank":
                return "ic_syb";
            case "Indian Overseas Bank":
                return "ic_iob";
            case "South Indian Bank":
                return "ic_sib";
            case "City Union Bank":
                return "ic_cub";
            case "Saraswat Bank":
                return "ic_src";
            case "United Bank of India":
                return "ic_ubi";
            case "Dhanlaxmi Bank":
                return "ic_dlb";
            case "Tamilnad Mercantile Bank":
                return "ic_tmb";
            case "IDFC First Bank":
                return "ic_idf";
            case "Karnataka Bank":
                return "ic_ktb";
            case "Punjab & Sind Bank":
                return "ic_psb";
            case "Bandhan Bank":
                return "ic_band";
            default:
                return "";
        }

    }
}
