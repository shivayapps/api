package com.bankbalanceinquiry.ministatement.activity.ui;

import static android.content.Context.MODE_PRIVATE;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.core.text.HtmlCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.adconfig.AdsConfig;
import com.bankbalanceinquiry.ministatement.OnItemClickListner;
import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.activity.BillsNewActivity;
import com.bankbalanceinquiry.ministatement.activity.CashWithdrawalActivity;
import com.bankbalanceinquiry.ministatement.activity.SplashActivity;
import com.bankbalanceinquiry.ministatement.activity.StateActivity;
import com.bankbalanceinquiry.ministatement.activity.SubActivity_homePage;
import com.bankbalanceinquiry.ministatement.adapter.AllAccountListAdapter;
import com.bankbalanceinquiry.ministatement.adapter.listBankAdapter;
import com.bankbalanceinquiry.ministatement.adapternew.AllAccountListNewAdapter;
import com.bankbalanceinquiry.ministatement.common.CommonFun;
import com.bankbalanceinquiry.ministatement.common.ReadJsonFile;
import com.bankbalanceinquiry.ministatement.currency.data.ExchangeRates;
import com.bankbalanceinquiry.ministatement.currency.data.Rate;
import com.bankbalanceinquiry.ministatement.currency.view.main.CurrencyActivity;
import com.bankbalanceinquiry.ministatement.currency.view.main.SpinnerAdapter;
import com.bankbalanceinquiry.ministatement.currency.viewmodel.main.CurrentInputViewModel;
import com.bankbalanceinquiry.ministatement.currency.viewmodel.main.ExchangeRatesViewModel;
import com.bankbalanceinquiry.ministatement.currency.widget.searchablespinner.SearchableSpinner;
import com.bankbalanceinquiry.ministatement.database.DatabaseAccess;
import com.bankbalanceinquiry.ministatement.databased.DBHelperAccount;
import com.bankbalanceinquiry.ministatement.databased.DBHelperAccountHistory;
import com.bankbalanceinquiry.ministatement.databased.DBHelperBills;
import com.bankbalanceinquiry.ministatement.databased.DBHelperCash;
import com.bankbalanceinquiry.ministatement.databased.StoreValue;
import com.bankbalanceinquiry.ministatement.databasedNew.DBHelperAccountNew;
import com.bankbalanceinquiry.ministatement.financialcalculator.Calculations;
import com.bankbalanceinquiry.ministatement.inapp.AdsManager;
import com.bankbalanceinquiry.ministatement.model.AllAccountModel;
import com.bankbalanceinquiry.ministatement.model.AllAccountModelHistory;
import com.bankbalanceinquiry.ministatement.model.BilsEmiModel;
import com.bankbalanceinquiry.ministatement.model.CashModelHistory;
import com.bankbalanceinquiry.ministatement.model.bankname;
import com.bankbalanceinquiry.ministatement.model.mbalance;
import com.bankbalanceinquiry.ministatement.model.passBook;
import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;
import com.bankbalanceinquiry.ministatement.utils.NetworkManager;





import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;


public class BoxviewFragment extends Fragment implements AllAccountListNewAdapter.ClickActivDeactiveint, OnItemClickListner {
    public static String bank_name, txtbank_id, txtbank_short;
    public static String account_name;
    static Integer aval_balance;
    int bank_id;
    String url_netBank, bank_change;
    public static List<passBook> pData;
    Button change_bank;
    private LinearLayout bank_balance, emi_calcu, ussd_banking, sms_banking, online_banking, epf_service,ll_cash,ll_bills,ll_holiday;
    public static TextView account_balance, account_no, details;
    static ImageView see_passbook;
    public static LinearLayout box_view_relative;
    public static LinearLayout list_bank_relative;
    public static ListView custom_list_view;
    List<bankname> mData;
    List<mbalance> mBalanceList = new ArrayList<>();
    SharedPreferences preferences;
    SharedPreferences.Editor editorBank;
    //RelativeLayout account_passbook;
    Context context;
    RecyclerView recycle_passBank;
    // NestedScrollView scrollMain;
    ScrollView scrollMain;
    listBankAdapter listBankAdapter;
    ArrayList<String> array_Account = new ArrayList<>();
    ArrayList<String> array_Amount = new ArrayList<>();
    public static List<String> find = new ArrayList<>();
    int check;
    String selectfrom;

    private Button btnAccount;

    private Activity activity;
    private ArrayList<AllAccountModel> allAccountModels;
    private ArrayList<AllAccountModel> allAccountModelstmp;
    private AllAccountListAdapter allAccountListAdapter;
    private final AsyncTask mMyTask = null;
    private ProgressBar pbLoading;

    //private ArrayList<BankNameLogo> bankNameLogos;
    private String BankName = "";
    private final String BankNameFinal = "";
    private final int BankIconFinal = 0;


    private DBHelperAccount mydbAccount;
    private DBHelperAccountNew mydbAccountNew;
    private DBHelperCash mydbCash;
    private DBHelperBills mydbBill;
    private DBHelperAccountHistory dbHelperAccountHistory;


    private ArrayList<CashModelHistory> cashModelHistories;
    private ArrayList<AllAccountModelHistory> allAccountModelHistories;
    String TodayDate = "";
    private ArrayList<BilsEmiModel> bilsEmiModels;


    private final ArrayList<HomeAccoutList> homeAccoutLists = new ArrayList<>();
    private final ArrayList<HomeAccoutList> allTransactionList = new ArrayList<>();
    private RecyclerView rvAccountList;
    private AllAccountListNewAdapter allAccountListNewAdapter;

    private final ArrayList<String> tempAccountNo = new ArrayList<>();

    //    TextView mCount;
    //RelativeLayout mLoading;
    //    SeekBar mProgress;
//    ImageView mCancel;
    boolean isCountRunning = true;

//    CardView mCashL, mBillL;

    private TextView count;
    //    private LinearLayout progress_lay;
    private FrameLayout adLayout;
    private CardView adcard;

    private ExchangeRatesViewModel ratesModel;
    private CurrentInputViewModel inputModel;
    private TextView tvCalculations;
    private TextView tvFrom;
    private TextView tvTo;
    private TextView tvCurrencyFrom;
    private TextView tvCurrencyTo;
    private SearchableSpinner spinnerFrom;
    private SearchableSpinner spinnerTo;
    private TextView tvDate;
    private TextView tvFee;
    private RelativeLayout ivMore;
    private View root;


    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        root = inflater.inflate(R.layout.fragment_boxview, container, false);


//        progress = root.findViewById(R.id.progress);
        count = root.findViewById(R.id.count);
        scrollMain = root.findViewById(R.id.scrollMain);


        context = getActivity();
        activity = getActivity();


        adLayout = root.findViewById(R.id.adLayout);
        adcard = root.findViewById(R.id.adcard);

        Log.e("BoxViewfrg==", "Yes");

//        if (new AdsManager(getActivity()).isNeedToShowAds() && NetworkManager.isInternetConnected(getActivity())) {
//            new NativeAdHelper(getActivity(), adLayout, NativeLayoutType.NativeMedium).loadAd();
//        }

        account_balance = root.findViewById(R.id.account_balance);
        account_no = root.findViewById(R.id.account_no);
        details = root.findViewById(R.id.details);
        see_passbook = root.findViewById(R.id.see_passbook);

        bank_balance = root.findViewById(R.id.bank_balance);
        emi_calcu = root.findViewById(R.id.emi_calcu);
        ussd_banking = root.findViewById(R.id.ussd_banking);
        sms_banking = root.findViewById(R.id.sms_banking);
        online_banking = root.findViewById(R.id.online_banking);
        epf_service = root.findViewById(R.id.epf_service);
        recycle_passBank = root.findViewById(R.id.recycle_passBank);
        ll_cash = root.findViewById(R.id.ll_cash);
        ll_bills = root.findViewById(R.id.ll_bills);
        ll_holiday = root.findViewById(R.id.ll_holiday);

        list_bank_relative = root.findViewById(R.id.list_bank_relative);
        box_view_relative = root.findViewById(R.id.box_view_relative);
        //account_passbook = root.findViewById(R.id.account_passbook);

        initCurrencyView();

        change_bank = root.findViewById(R.id.change_bank);


        preferences = getActivity().getSharedPreferences("bank_select", MODE_PRIVATE);
        editorBank = preferences.edit();

        rvAccountList = root.findViewById(R.id.rvAccountList);
        pbLoading = root.findViewById(R.id.pbLoading);

        LinearLayoutManager linearLayoutManagern = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        rvAccountList.setLayoutManager(linearLayoutManagern);

        btnAccount = root.findViewById(R.id.btnAccount);
      /*  btnAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(), AllAccountActivity.class);
                startActivity(i);
            }
        });*/

        //set list Bank
        custom_list_view = root.findViewById(R.id.custom_list_view);
        String[] bankColor_array = getActivity().getResources().getStringArray(R.array.listcolors);

        try {
            DatabaseAccess databaseAccess = DatabaseAccess.getInstance(getActivity());
            databaseAccess.open();
            mData = databaseAccess.getList();
            databaseAccess.close();

            /*listBankAdapter = new listBankAdapter(getActivity(), mData, bankColor_array);
            listBankAdapter.OnItemClickListener(this);
            custom_list_view.setAdapter(listBankAdapter);*/
            custom_list_view.setScrollingCacheEnabled(true);

        } catch (Exception e) {
            e.printStackTrace();
        }

        pbLoading.setVisibility(View.GONE);
        mydbAccount = new DBHelperAccount(activity);
        mydbAccountNew = new DBHelperAccountNew(activity);
        mydbCash = new DBHelperCash(activity);
        mydbBill = new DBHelperBills(activity);
        dbHelperAccountHistory = new DBHelperAccountHistory(activity);

        if (CommonFun.IsAllSmsmFill.equalsIgnoreCase("")) {
            String FirstTime = StoreValue.GetFirstime("OK");
            if (FirstTime.equalsIgnoreCase("")) {
                CommonFun.IsAllSmsmFill = "";
                Log.e("FIRSTIMEINSERDATA==>", "FirstTime");
                if (mMyTask != null) {
                    if (mMyTask.getStatus() == AsyncTask.Status.RUNNING) {
                        // My AsyncTask is currently doing work in doInBackground()
                    }
                } else {
                    // mMyTask = new AllOptionFilterFirstTime().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                    String FirstTimeON = StoreValue.GetLodingData("DOUBLE");
                    if (FirstTimeON.equalsIgnoreCase("")) {
                        StoreValue.SetLodingData("DOUBLE", "Ok");
                        Log.e("FirstTimeON", FirstTimeON);
                    } else {
                        Log.e("FirstTimeON", " AfterLoad");
//                        mMyTask = new MyTaskNewAccount().execute(20);
                        //mLoading.setVisibility(View.VISIBLE);
//                        mCancel.setVisibility(View.VISIBLE);
                        //account_passbook.setVisibility(View.GONE);
                       /* if (!isMyServiceRunning(SmsService.class)) {
                            getActivity().startService(new Intent(getActivity(), SmsService.class));
                        }*/
//                        countThread.start();
                    }
                }

            } else {
                // mLoading.setVisibility(View.GONE);
//                mCancel.setVisibility(View.GONE);
                //account_passbook.setVisibility(View.VISIBLE);

                // CommonFun.IsAllSmsmFill = "AllFill";
                Log.e("FIRSTIMEINSERDATA==>", " AlredyInsert");
                CallNewHomeAccount();
            }
        } else {
            //mLoading.setVisibility(View.GONE);
//            mCancel.setVisibility(View.GONE);
            //account_passbook.setVisibility(View.VISIBLE);
            CallNewHomeAccount();
        }


        //Check preference
        bank_change = preferences.getString("bank", "no_select");
        bank_name = preferences.getString("bank_name", "No Bank");
        txtbank_id = preferences.getString("bank_id", "No Id");
        txtbank_short = preferences.getString("bank_short", "No Short");

        if (bank_change.matches("select")) {
            list_bank_relative.setVisibility(View.GONE);
            box_view_relative.setVisibility(View.VISIBLE);
            bank_id = Integer.parseInt(txtbank_id);
            Log.e("txtbank_", " " + txtbank_short);
        } else {
            list_bank_relative.setVisibility(View.GONE);
            box_view_relative.setVisibility(View.VISIBLE);

        }

        pData = new ArrayList<>();
        //add Data in Passbook model
        aval_balance = 0;
        // readMessages();

//        account_balance.setText("\u20B9" + aval_balance);


        Log.e("Size Array--)", " " + array_Account.size());
        Log.e("Size PArray--)", " " + pData.size());

        for (int j = 0; j < array_Account.size(); j++) {
            check = 0;
            for (int i = 0; i < pData.size(); i++) {
                if (j == pData.get(i).getBank_type()) {
                    try {
                        if (pData.get(i).getPass_which().matches("Cr")) {
                            check = check + Integer.parseInt(pData.get(i).getPass_amount());
                            Log.e("Ava_c--)", " " + check);
                        } else if (pData.get(i).getPass_which().matches("Dr")) {
                            check = check - Integer.parseInt(pData.get(i).getPass_amount());
                        }
                    } catch (Exception e) {
                        Log.e("Error--)", " " + e.getMessage());
                    }
                }
            }
            Log.e("AmountAccoutasaaaa", String.valueOf(check));
            array_Amount.add(String.valueOf(check));
        }


        bank_balance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bank_change.matches("select")) {
                    //navController.navigate(R.id.nav_bank_balnce);
                    startNextActivity(0);
                } else {
                    selectfrom = "bank_balance";
                    ////checkAndSetAdapter();
                    list_bank_relative.setVisibility(View.VISIBLE);
                    box_view_relative.setVisibility(View.GONE);
                    listBankAdapter = new listBankAdapter(getActivity(), mData, bankColor_array);
                    listBankAdapter.OnItemClickListener(BoxviewFragment.this);
                    custom_list_view.setAdapter(listBankAdapter);
                }
                /*AdmobAdManager.getInstance().loadInterstitialAd(getActivity(), getString(R.string.interstitial_id), 3, () -> {
                });*/
            }
        });

        ussd_banking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bank_change.matches("select")) {
//                    navController.navigate(R.id.nav_bank_ussd);
                    startNextActivity(2);

                } else {

                    selectfrom = "ussd_banking";
                    list_bank_relative.setVisibility(View.VISIBLE);
                    //checkAndSetAdapter();
                    box_view_relative.setVisibility(View.GONE);

                    listBankAdapter = new listBankAdapter(getActivity(), mData, bankColor_array);
                    listBankAdapter.OnItemClickListener(BoxviewFragment.this);
                    custom_list_view.setAdapter(listBankAdapter);
                }
                /*AdmobAdManager.getInstance().loadInterstitialAd(getActivity(), getString(R.string.interstitial_id), 3, () -> {
                });*/
            }
        });


        sms_banking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (bank_change.matches("select")) {
                   /* AdmobAdManager.getInstance().loadInterstitialAd(getActivity(), getString(R.string.interstitial_id), 1, (AdmobAdManager.OnAdClosedListener) () -> {
                    });*/
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            //      navController.navigate(R.id.nav_sms_banking);
                            startNextActivity(3);

                        }
                    }, 200);
                } else {
                   /* AdmobAdManager.getInstance().loadInterstitialAd(getActivity(), getString(R.string.interstitial_id), 3, (AdmobAdManager.OnAdClosedListener) () -> {
                    });*/

                    selectfrom = "sms_banking";
                    list_bank_relative.setVisibility(View.VISIBLE);
                    //checkAndSetAdapter();
                    box_view_relative.setVisibility(View.GONE);

                    listBankAdapter = new listBankAdapter(getActivity(), mData, bankColor_array);
                    listBankAdapter.OnItemClickListener(BoxviewFragment.this);
                    custom_list_view.setAdapter(listBankAdapter);
                }

            }
        });

        online_banking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bank_change.matches("select")) {
                    try {
                        url_netBank = preferences.getString("bank_url", "no_url");
                        Handler handler = new Handler(Looper.getMainLooper());
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {

                                Uri webpage = Uri.parse(url_netBank);

                                if (!url_netBank.startsWith("http://") && !url_netBank.startsWith("https://")) {
                                    webpage = Uri.parse("http://" + url_netBank);
                                }
                                if (getActivity() != null) {
                                    Intent i = new Intent(Intent.ACTION_VIEW, webpage);
//                            i.setData(webpage);
                                    if (i.resolveActivity(getActivity().getPackageManager()) != null) {
                                        startActivity(i);
                                    }
                                }
                            }
                        }, 1500);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    selectfrom = "online_banking";
                    list_bank_relative.setVisibility(View.VISIBLE);
                    //checkAndSetAdapter();
                    box_view_relative.setVisibility(View.GONE);
                    listBankAdapter = new listBankAdapter(getActivity(), mData, bankColor_array);
                    listBankAdapter.OnItemClickListener(BoxviewFragment.this);
                    custom_list_view.setAdapter(listBankAdapter);
                }

            }
        });

        epf_service.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bank_change.matches("select")) {
                    /*AdmobAdManager.getInstance().loadInterstitialAd(getActivity(), getString(R.string.interstitial_id), 3, (AdmobAdManager.OnAdClosedListener) () -> {
                    });*/
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            // navController.navigate(R.id.nav_epf_service);
                            startNextActivity(5);

                        }
                    }, 200);
                } else {
                    /*AdmobAdManager.getInstance().loadInterstitialAd(getActivity(), getString(R.string.interstitial_id), 3, (AdmobAdManager.OnAdClosedListener) () -> {
                    });*/
                    selectfrom = "epf_service";
                    list_bank_relative.setVisibility(View.VISIBLE);
                    //checkAndSetAdapter();
                    box_view_relative.setVisibility(View.GONE);

                    listBankAdapter = new listBankAdapter(getActivity(), mData, bankColor_array);
                    listBankAdapter.OnItemClickListener(BoxviewFragment.this);
                    custom_list_view.setAdapter(listBankAdapter);
                }


            }
        });
        ll_cash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(NetworkManager.isNetworkAvailable(getActivity()) && new AdsManager(getActivity()).isNeedToShowAds()) {
                    AdsConfig.Companion.showInterstitialAd(getActivity(), new Function1<Boolean, Unit>() {
                        @Override
                        public Unit invoke(Boolean aBoolean) {
                            Intent i = new Intent(getActivity(), CashWithdrawalActivity.class);
                            startActivity(i);
                            return null;
                        }
                    });

                } else {
                    Intent i = new Intent(getActivity(), CashWithdrawalActivity.class);
                    startActivity(i);
                }

            }
        });
        ll_bills.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(NetworkManager.isNetworkAvailable(getActivity()) && new AdsManager(getActivity()).isNeedToShowAds()) {

                    AdsConfig.Companion.showInterstitialAd(getActivity(), new Function1<Boolean, Unit>() {
                        @Override
                        public Unit invoke(Boolean aBoolean) {

                            Intent i = new Intent(getActivity(), BillsNewActivity.class);
                            startActivity(i);
                            return null;
                        }
                    });
                } else {
                    Intent i = new Intent(getActivity(), BillsNewActivity.class);
                    startActivity(i);
                }

            }
        });
        ll_holiday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(NetworkManager.isNetworkAvailable(getActivity()) && new AdsManager(getActivity()).isNeedToShowAds()) {
                    AdsConfig.Companion.showInterstitialAd(getActivity(), new Function1<Boolean, Unit>() {
                        @Override
                        public Unit invoke(Boolean aBoolean) {

                            Intent i = new Intent(getActivity(), StateActivity.class);
                            startActivity(i);
                            return null;
                        }
                    });
                } else {
                    Intent i = new Intent(getActivity(), StateActivity.class);
                    startActivity(i);
                }

            }
        });

        emi_calcu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bank_change.matches("select")) {
                    //  navController.navigate(R.id.nav_bank_emi);
//                    startNextActivity(1);

                    if(NetworkManager.isNetworkAvailable(getActivity()) && new AdsManager(getActivity()).isNeedToShowAds()) {
                        AdsConfig.Companion.showInterstitialAd(getActivity(), new Function1<Boolean, Unit>() {
                            @Override
                            public Unit invoke(Boolean aBoolean) {

                                Intent i = new Intent(getActivity(), Calculations.class);
                                startActivity(i);
                                return null;
                            }
                        });
                    } else {
                        Intent i = new Intent(getActivity(), Calculations.class);
                        startActivity(i);
                    }
                   /* AdmobAdManager.getInstance().loadInterstitialAd(getActivity(), getString(R.string.interstitial_id), 3, (AdmobAdManager.OnAdClosedListener) () -> {
                    });*/
                } else {
                    selectfrom = "emi_calcu";
                    list_bank_relative.setVisibility(View.VISIBLE);
                    //checkAndSetAdapter();
                    box_view_relative.setVisibility(View.GONE);

                    listBankAdapter = new listBankAdapter(getActivity(), mData, bankColor_array);
                    listBankAdapter.OnItemClickListener(BoxviewFragment.this);
                    custom_list_view.setAdapter(listBankAdapter);
                }
            }
        });


        Log.e("FrgmentOpne Mm", "newww");
        return root;
    }
/*
    private void checkAndSetAdapter() {
        if (listBankAdapter == null) {
            String[] bankColor_array = getActivity().getResources().getStringArray(R.array.listcolors);
            listBankAdapter = new listBankAdapter(getActivity(), mData, bankColor_array);
            listBankAdapter.OnItemClickListener(this);
            custom_list_view.setAdapter(listBankAdapter);
            custom_list_view.setScrollingCacheEnabled(true);
        }
    }*/

//    public void loadNative() {
//        Log.e("HOMEMMEMMEEMEE", "JKSDFHCJS");
//        AdmobAdManager.getInstance().LoadNativeAd(getActivity(), getString(R.string.admob_native_id), new AdEventListener() {
//            @Override
//            public void onAdLoaded(Object object) {
//                AdmobAdManager.getInstance().populateUnifiedNativeAdView(getContext(), adLayout, (NativeAd) object, true, true);
//            }
//
//            @Override
//            public void onAdClosed() {
//            }
//
//            @Override
//            public void onLoadError(String errorCode) {
//            }
//        }, true);
//    }


    private void initCurrencyView() {
        // model
        this.ratesModel = new ViewModelProvider(this).get(ExchangeRatesViewModel.class);
        this.inputModel = new ViewModelProvider(this).get(CurrentInputViewModel.class);

        // views
        this.tvCalculations = root.findViewById(R.id.textCalculations);
        this.tvFrom = root.findViewById(R.id.textFrom);
        this.tvTo = root.findViewById(R.id.textTo);
        this.tvCurrencyFrom = root.findViewById(R.id.currencyFrom);
        this.tvCurrencyTo = root.findViewById(R.id.currencyTo);
        this.spinnerFrom = root.findViewById(R.id.spinnerFrom);
        this.spinnerTo = root.findViewById(R.id.spinnerTo);
        this.tvDate = root.findViewById(R.id.textRefreshed);
        this.tvFee = root.findViewById(R.id.textFee);
        this.ivMore = root.findViewById(R.id.rlMore);

        setListeners();

        observe();

//        int positionLastFrom = 0;
//        if (inputModel.getLastRateFrom() != null) {
//            {
//                positionLastFrom = ((SpinnerAdapter) spinnerFrom.getAdapter()).getPosition(inputModel.getLastRateFrom());
//            }
//            spinnerFrom.setSelection(positionLastFrom);
//            int positionLastTo = 0;
//            if (inputModel.getLastRateTo() != null) {
//                positionLastTo = ((SpinnerAdapter) spinnerTo.getAdapter()).getPosition(inputModel.getLastRateTo());
//            }
//            spinnerTo.setSelection(positionLastTo);
//        }

        inputModel.clear();
        inputModel.addNumber("1");
    }

    private void setListeners() {
        ivMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (new AdsManager(getActivity()).isNeedToShowAds() && NetworkManager.isInternetConnected(getActivity())) {
                    AdsConfig.Companion.showInterstitialAd(getActivity(), new Function1<Boolean, Unit>() {
                        @Override
                        public Unit invoke(Boolean aBoolean) {

                            startActivity(new Intent(getActivity(), CurrencyActivity.class));
                            return null;
                        }
                    });
                } else {
                    startActivity(new Intent(getActivity(), CurrencyActivity.class));
                }
            }
        });
        spinnerFrom.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                inputModel.setCurrencyFrom(
                        (Rate) (adapterView.getAdapter()).getItem(position)
                );
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        spinnerTo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                inputModel.setCurrencyTo(
                        (Rate) (adapterView.getAdapter()).getItem(position)
                );
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    private void observe() {
        ratesModel.getExchangeRate().observe(this, new Observer<ExchangeRates>() {
            @Override
            public void onChanged(ExchangeRates exchangeRates) {

                String providerString = "";
                providerString = "frankfurter.app";
//                switch (Database.Companion.getInstance(getActivity()).getApiProvider()) {
//                    case 1:
//                        providerString = "frankfurter.app";
//                        break;
//                    default:
//                        providerString = "exchangerate.host";
//                        break;
//                }

                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
                String dateString = exchangeRates.getDate();

                if (dateString != null && providerString != null) {
                    tvDate.setText(HtmlCompat.fromHtml(
                            getString(
                                    R.string.rates_date_latest,
                                    dateString,
                                    providerString
                            ),
                            HtmlCompat.FROM_HTML_MODE_LEGACY
                    ));
                }

                if (exchangeRates.getRates() != null) {
                    spinnerFrom.setAdapter(new SpinnerAdapter(getActivity(), android.R.layout.simple_spinner_item, exchangeRates.getRates()));
                    spinnerTo.setAdapter(new SpinnerAdapter(getActivity(), android.R.layout.simple_spinner_item, exchangeRates.getRates()));
                }
                int positionLastFrom = 0;
                if (inputModel.getLastRateFrom() != null) {
                    {
                        positionLastFrom = ((SpinnerAdapter) spinnerFrom.getAdapter()).getPosition(inputModel.getLastRateFrom());
                    }
                    spinnerFrom.setSelection(positionLastFrom);
                    int positionLastTo = 0;
                    if (inputModel.getLastRateTo() != null) {
                        positionLastTo = ((SpinnerAdapter) spinnerTo.getAdapter()).getPosition(inputModel.getLastRateTo());
                    }
                    spinnerTo.setSelection(positionLastTo);

                }
            }
        });

        inputModel.getCurrentInput().observe(requireActivity(), new Observer<String>() {
            @Override
            public void onChanged(String s) {
                tvFrom.setText(s);
            }
        });

        inputModel.getCurrentInputConverted().observe(this, new Observer<String>() {
            @Override
            public void onChanged(String s) {
                tvTo.setText(s);
            }
        });
        inputModel.getCalculationInput().observe(this, new Observer<String>() {
            @Override
            public void onChanged(String s) {
                tvCalculations.setText(s);
            }
        });
        inputModel.getCurrencyFrom().observe(this, new Observer<String>() {
            @Override
            public void onChanged(String s) {
                tvCurrencyFrom.setText(s);
            }
        });
        inputModel.getCurrencyTo().observe(this, new Observer<String>() {
            @Override
            public void onChanged(String s) {
                tvCurrencyTo.setText(s);
            }
        });
    }

    private boolean isMyServiceRunning(Class<?> serviceClass) {
        if (getActivity() != null) {
            ActivityManager manager = (ActivityManager) getActivity().getSystemService(Context.ACTIVITY_SERVICE);
            if (manager != null) {
                for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
                    if (serviceClass.getName().equals(service.service.getClassName())) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    @Override
    public void onDestroyView() {
        //EventBus.getDefault().unregister(this);
        super.onDestroyView();
    }

    /*@Subscribe
    public void OnSmsProgress(final SmsProgress smsProgress) {
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    mCount.setText(SmsService.smsCount + "/" + SmsService.TotalCount);
                    mProgress.setMax(SmsService.TotalCount);
                    mProgress.setProgress(smsProgress.getProgress());
                }
            });
        }
    }*/

    /*@Subscribe
    public void OnSmsList(final SmsList smsList) {
        isCountRunning = false;
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    account_passbook.setVisibility(View.VISIBLE);
                    //mLoading.setVisibility(View.GONE);
//                    mCancel.setVisibility(View.GONE);
                    homeAccoutLists.clear();
                    allTransactionList.clear();
                    homeAccoutLists.addAll(smsList.getHomeAccoutLists());
                    allTransactionList.addAll(smsList.getAllTransactionList());

//                    StoreValue.SetFirstime("OK", "Ok");
//                    CommonFun.IsAllSmsmFill = "AllFill";
                    pbLoading.setVisibility(View.GONE);

                    if (DialogProgress != null) {
                        DialogProgress.dismiss();
                    }

                    //  HomeScreen Account
//                    CallHomeScreenAllAccoutNew();
                    CallNewHomeAccount();
                }
            });
        }

    }*/


    private void CallNewHomeAccount() {
        pbLoading.setVisibility(View.GONE);
        homeAccoutLists.clear();
        ArrayList<HomeAccoutList> homeAccoutListArrayList = mydbAccountNew.GetAllAccountNew();
        homeAccoutLists.addAll(homeAccoutListArrayList);
        if (homeAccoutLists.size() > 0) {
            //navBalance.setText("\u20B9" + calculateTotalBal(homeAccoutListArrayList));
            //   homeAccoutLists.add(1, new HomeAccoutList(1));
            allAccountListNewAdapter = new AllAccountListNewAdapter(activity, homeAccoutLists);
            allAccountListNewAdapter.RegisterInterface(BoxviewFragment.this);
            rvAccountList.setAdapter(allAccountListNewAdapter);
            allAccountListNewAdapter.notifyDataSetChanged();
        } else
            Log.e("TAG", "CallNewHomeAccount: No transaction SMS found");
    }


    private String calculateTotalBal(ArrayList<HomeAccoutList> homeAccoutListArrayList) {
        double total = 0;
        for (HomeAccoutList homeAccount : homeAccoutListArrayList) {
            String bal = homeAccount.FinalAccountBalance;
            if (!TextUtils.isEmpty(bal)) {
                bal = bal.replace(",", "");
                double v = Double.parseDouble(bal);
                total += v;
            }
        }

        String s = String.valueOf(total);
        NumberFormat nf = NumberFormat.getNumberInstance(Locale.US);
        DecimalFormat decim = (DecimalFormat) nf;
        decim.applyPattern("#,##,###.##");
        if (s.contains(".")) {
            String afterPoint = s.substring(s.indexOf(".") + 1);
            if (afterPoint.length() > 2) {
                return decim.format(total);
            }
        }
//        DecimalFormat decim = new DecimalFormat("#,##,###.##");
        return decim.format(total);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    private Dialog DialogProgress = null;
    private ProgressBar progress_horizontal;
    private TextView tvValue;
    private int mycound = 0;
    private int TotalCount = 0;

    @Override
    public void onItemClick() {
        bank_change = preferences.getString("bank", "no_select");
        bank_name = preferences.getString("bank_name", "No Bank");
        txtbank_id = preferences.getString("bank_id", "No Id");
        txtbank_short = preferences.getString("bank_short", "No Short");

        if (selectfrom != null) {

            if (selectfrom.equalsIgnoreCase("bank_balance")) {
                startNextActivity(0);
                // navController.navigate(R.id.nav_bank_balnce);
            } else if (selectfrom.equalsIgnoreCase("ussd_banking")) {
                startNextActivity(2);

//                Intent i = new Intent(getActivity(), Calculations.class);
//                startActivity(i);


//                navController.navigate(R.id.nav_bank_ussd);
            } else if (selectfrom.equalsIgnoreCase("sms_banking")) {
                startNextActivity(3);

                //   navController.navigate(R.id.nav_sms_banking);
            } else if (selectfrom.equalsIgnoreCase("online_banking")) {
                try {
                    url_netBank = preferences.getString("bank_url", "no_url");
                    Handler handler = new Handler(Looper.getMainLooper());
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {

                            Uri webpage = Uri.parse(url_netBank);

                            if (!url_netBank.startsWith("http://") && !url_netBank.startsWith("https://")) {
                                webpage = Uri.parse("http://" + url_netBank);
                            }
                            if (getActivity() != null) {
                                Intent i = new Intent(Intent.ACTION_VIEW, webpage);
                                try {
                                    if (i.resolveActivity(getActivity().getPackageManager()) != null) {
                                        startActivity(i);
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    }, 1500);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (selectfrom.equalsIgnoreCase("epf_service")) {
                startNextActivity(5);

//                navController.navigate(R.id.nav_epf_service);
            } else if (selectfrom.equalsIgnoreCase("emi_calcu")) {
                //startNextActivity(1);

                if(NetworkManager.isNetworkAvailable(getActivity()) && new AdsManager(getActivity()).isNeedToShowAds()) {

                    AdsConfig.Companion.showInterstitialAd(getActivity(), new Function1<Boolean, Unit>() {
                        @Override
                        public Unit invoke(Boolean aBoolean) {
                            Intent i = new Intent(getActivity(), Calculations.class);
                            startActivity(i);

                            return null;
                        }
                    });
                } else {
                    Intent i = new Intent(getActivity(), Calculations.class);
                    startActivity(i);
                }


                // navController.navigate(R.id.nav_bank_emi);
            } else {
                //   navController.navigate(R.id.nav_box);
            }
            selectfrom = null;
        }
    }

    private void startNextActivity(int type) {

        if(NetworkManager.isNetworkAvailable(getActivity()) && new AdsManager(getActivity()).isNeedToShowAds()) {

            AdsConfig.Companion.showInterstitialAd(getActivity(), new Function1<Boolean, Unit>() {
                @Override
                public Unit invoke(Boolean aBoolean) {

                    Intent i = new Intent(getActivity(), SubActivity_homePage.class);
                    i.putExtra("viewType", type);
                    startActivity(i);
                    return null;
                }
            });
        } else {
            Intent i = new Intent(getActivity(), SubActivity_homePage.class);
            i.putExtra("viewType", type);
            startActivity(i);
        }
    }


    public boolean isBack() {
        if (list_bank_relative.getVisibility() == View.VISIBLE) {
            list_bank_relative.setVisibility(View.GONE);
            box_view_relative.setVisibility(View.VISIBLE);
            return true;
        }
        return false;
    }


    private class MyTaskNewAccount extends AsyncTask<Integer, Integer, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            allAccountModelHistories = new ArrayList<>();
            CallProgress();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            StoreValue.SetFirstime("OK", "Ok");
            CommonFun.IsAllSmsmFill = "AllFill";
            pbLoading.setVisibility(View.GONE);

            if (DialogProgress != null) {
                DialogProgress.dismiss();
            }

            //  HomeScreen Account
            CallHomeScreenAllAccoutNew();


            //   Account History
//            AccountHistory();


        }

        @Override
        protected String doInBackground(Integer... params) {
            Uri message = Uri.parse("content://sms/inbox");
            ContentResolver cr = activity.getContentResolver();
            Cursor c = cr.query(message, null, null, null, null);

            int totalSMS = 0;
            if (c != null) {
                totalSMS = c.getCount();
            }
            TotalCount = totalSMS;
            if (progress_horizontal != null) {
                progress_horizontal.setMax(totalSMS);
            }
            //  JSONArray jsonArray = ReadJsonFile.GetAssetsFileGetDataJsonArray(activity, "sms/rulestmp");
            //JSONArray jsonArray = ReadJsonFile.GetAssetsFileGetDataJsonArray(activity, "sms/rules_final_updated");
            JSONArray jsonArray = ReadJsonFile.GetAssetsFileGetDataJsonArray(activity, "sms/rules_new");
            if (c != null && c.moveToFirst()) {
                for (int i = 0; i < totalSMS; i++) {
                    //                    String id = c.getString(c.getColumnIndexOrThrow("_id"));
                    String BankNameTitle = c.getString(c.getColumnIndexOrThrow("address"));
                    String body = c.getString(c.getColumnIndexOrThrow("body"));
                    //                    String read = c.getString(c.getColumnIndexOrThrow("read"));
                    //                    String date = c.getString(c.getColumnIndexOrThrow("date"));
                    String datestr = c.getString(c.getColumnIndexOrThrow("date"));
                    //                    String type = c.getString(c.getColumnIndexOrThrow("type"));
                    //                    String person = c.getString(c.getColumnIndexOrThrow("person"));

                    long dateV = Long.parseLong(datestr);
                    CheckisTransactionSms(jsonArray, BankNameTitle, body, dateV);

                    try {
                        publishProgress(i);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    c.moveToNext();

                }
                c.close();
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            Log.e("onProgressUpdate==>?", values[0] + "");
            if (tvValue != null) {
                mycound++;
                Log.e("my Count", mycound + "");
                tvValue.setText(mycound + "/ " + TotalCount);
            }
            if (progress_horizontal != null) {
                progress_horizontal.setProgress(mycound);
            }
        }
    }

    private void AccountHistory() {
        for (int i = 0; i < allAccountModelHistories.size(); i++) {
            AllAccountModelHistory alldata = allAccountModelHistories.get(i);
            String TitleDateHistory = alldata.getTitleDate();
            String dateValHistory = alldata.getDate();
            String AccountNo = alldata.getAccountno();
            String AccountAmount = alldata.getAccountamount();
            String CheckIsDebitCredit = alldata.getCreditdebit();
            String FinalDescription = alldata.getFinalDescription();
            String TransferFrom = alldata.getTransferFrom();
            try {
                dbHelperAccountHistory.InsertHistory(TitleDateHistory, dateValHistory, AccountNo, AccountAmount,
                        CheckIsDebitCredit, FinalDescription, TransferFrom);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        allAccountModelHistories = new ArrayList<>();
        allAccountModelHistories.addAll(dbHelperAccountHistory.GetHistory());
    }

    private void CallAccountHistoryAddDb() {
        for (int i = 0; i < allAccountModelHistories.size(); i++) {
            AllAccountModelHistory alldata = allAccountModelHistories.get(i);
            String TitleDateHistory = alldata.getTitleDate();
            String dateValHistory = alldata.getDate();
            String AccountNo = alldata.getAccountno();
            String AccountAmount = alldata.getAccountamount();
            String CheckIsDebitCredit = alldata.getCreditdebit();
            String FinalDescription = alldata.getFinalDescription();
            String TransferFrom = alldata.getTransferFrom();

            try {
                dbHelperAccountHistory.InsertHistory(TitleDateHistory, dateValHistory, AccountNo, AccountAmount,
                        CheckIsDebitCredit, FinalDescription, TransferFrom);
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    private void CallHomeScreenAllAccoutNew() {
        for (int i = 0; i < homeAccoutLists.size(); i++) {
            HomeAccoutList alldata = homeAccoutLists.get(i);
            try {
                mydbAccountNew.InsertAccount(alldata);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        for (int i = 0; i < allTransactionList.size(); i++) {
            HomeAccoutList alldata = allTransactionList.get(i);
            try {
                mydbAccountNew.InsertTransaction(alldata);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        CallNewHomeAccount();

    }

    private void CheckisTransactionSms(JSONArray jsonArray, String bankNameTitle, String body, long dateV) {
        JSONObject jsonObject;
        JSONArray senderss;
        int mObjectPosition = 999;

        SimpleDateFormat formatterAccount = new SimpleDateFormat("dd-MMM-yy");
        SimpleDateFormat FormateMontHistory = new SimpleDateFormat("MMMM");
        SimpleDateFormat formatterHistory = new SimpleDateFormat("dd MMMM yyyy, hh:mm aa");

        HomeAccoutList homeAccount = new HomeAccoutList();

        if (!TextUtils.isEmpty(bankNameTitle)) {
            if (jsonArray != null) {
                for (int i = 0; i < jsonArray.length(); i++) {
                    jsonObject = jsonArray.optJSONObject(i);
                    senderss = jsonObject.optJSONArray("senders");
                    if (senderss != null) {
                        for (int j = 0; j < senderss.length(); j++) {
                            try {
                                String SenderName = senderss.get(j).toString();
                                if (bankNameTitle.toLowerCase().contains(SenderName.toLowerCase())) {
                                    mObjectPosition = i;
                                    homeAccount.full_name = jsonObject.getString("full_name");
                                    break;
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            }
            if (mObjectPosition != 999) {
                try {
                    getTransectionDetails(homeAccount, body, jsonArray.getJSONObject(mObjectPosition));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }


        homeAccount.dateValAccount = formatterAccount.format(new Date(dateV));
        homeAccount.DateTransactionHistory = FormateMontHistory.format(new Date(dateV));
        homeAccount.dateValHistory = formatterHistory.format(new Date(dateV));

        // Account List
        if (!homeAccount.account_type.equalsIgnoreCase("phone")) {
            if (!TextUtils.isEmpty(homeAccount.FinalAccountBalance) || homeAccount.account_type.equalsIgnoreCase("prepaid")) {
                if (!TextUtils.isEmpty(homeAccount.full_name)) {
                    if (!TextUtils.isEmpty(homeAccount.FinalAccountNo)) {
                        if (homeAccount.FinalAccountNo.length() > 4) {
                            homeAccount.FinalAccountNo = homeAccount.FinalAccountNo.substring(homeAccount.FinalAccountNo.length() - 4);
                        }
                        if (tempAccountNo.size() != 0) {
                            if (!tempAccountNo.contains(homeAccount.FinalAccountNo)) {
                                boolean isF = false;
                                for (int i = 0; i < tempAccountNo.size() && !isF; i++) {
                                    if (tempAccountNo.get(i).length() > homeAccount.FinalAccountNo.length()) {
                                        if (tempAccountNo.get(i).contains(homeAccount.FinalAccountNo)) {
                                            isF = true;
                                            homeAccount.FinalAccountNo = tempAccountNo.get(i);
                                        }
                                    } else {
                                        if (homeAccount.FinalAccountNo.contains(tempAccountNo.get(i))) {
                                            isF = true;
                                            homeAccount.FinalAccountNo = tempAccountNo.get(i);
                                        }
                                    }
                                }
                                if (!isF) {
                                    homeAccoutLists.add(homeAccount);
                                    tempAccountNo.add(homeAccount.FinalAccountNo);
                                }
                            }
                        } else {
                            homeAccoutLists.add(homeAccount);
                            tempAccountNo.add(homeAccount.FinalAccountNo);
                        }
                    } else {
                        if (!tempAccountNo.contains(homeAccount.full_name)) {
                            homeAccoutLists.add(homeAccount);
                            tempAccountNo.add(homeAccount.full_name);
                        }
                    }
                }
            }
        }


        // Account History
        if (!TextUtils.isEmpty(homeAccount.full_name)) {
            if (!TextUtils.isEmpty(homeAccount.amount)) {
                String amount = homeAccount.amount.replaceAll(",", "");
                homeAccount.amount = amount;
//                if (homeAccount.FinalAccountNo.length() > 4) {
//                    homeAccount.FinalAccountNo = homeAccount.FinalAccountNo.substring(homeAccount.FinalAccountNo.length() - 4);
//                }

                if (TextUtils.isEmpty(homeAccount.transactionDesc)) {
                    if (!TextUtils.isEmpty(homeAccount.mTransactionType)) {
                        homeAccount.transactionDesc = getTransactionDesc(homeAccount.mTransactionType);
                    } else if (!TextUtils.isEmpty(homeAccount.txn_type)) {
                        homeAccount.transactionDesc = getTransactionDesc(homeAccount.txn_type);
                    } else {
                        homeAccount.transactionDesc = "Unknown Transaction";
                    }
                } else if (homeAccount.transactionDesc.equalsIgnoreCase("atm") ||
                        homeAccount.transactionDesc.equalsIgnoreCase("debit_atm")) {
                    homeAccount.transactionDesc = "ATM withdrawal";
                } else if (homeAccount.transactionDesc.equalsIgnoreCase("debit") ||
                        homeAccount.transactionDesc.equalsIgnoreCase("debit_card")) {
                    homeAccount.transactionDesc = "Debit Card Transaction";
                } else if (homeAccount.transactionDesc.equalsIgnoreCase("credit_card")) {
                    homeAccount.transactionDesc = "Credit Card Transaction";
                } else if (homeAccount.transactionDesc.equalsIgnoreCase("credit_card_bill")) {
                    homeAccount.transactionDesc = "Credit Card Bill";
                }

                if (!TextUtils.isEmpty(homeAccount.transactionPos)) {
                    homeAccount.finalTransactionDesc = homeAccount.transactionPos;
                } else if (homeAccount.transactionDescs.size() != 0) {
                    for (String s : homeAccount.transactionDescs) {
                        if (!TextUtils.isEmpty(s)) {
                            homeAccount.finalTransactionDesc = s;
                            break;
                        }
                    }
                }
                allTransactionList.add(homeAccount);
            }
        }
    }


    private void getTransectionDetails(HomeAccoutList homeAccount, String body, JSONObject jsonObject) {

        int posID = -1, amountId = -1, ruleId = -1, dateId = -1, eventNameId = -1, eventLocationId = -1, eventInfoId = -1;

        try {
            BankName = jsonObject.optString("full_name");
            JSONArray patternsary = jsonObject.optJSONArray("patterns");
            if (patternsary != null) {
                boolean isPatternMatch = false;
                for (int jj = 0; jj < patternsary.length() && !isPatternMatch; jj++) {
                    JSONObject jsonObjectt = patternsary.optJSONObject(jj);
                    String Regx = jsonObjectt.optString("regex");

                    Pattern regEx = Pattern.compile(Regx);
                    Matcher m = regEx.matcher(body);
                    if (m.find()) {
                        isPatternMatch = true;
                        homeAccount.account_type = jsonObjectt.optString("account_type");
                        homeAccount.sms_type = jsonObjectt.optString("sms_type");
                        String data_fields = jsonObjectt.optString("data_fields");
                        JSONObject obj_data_fields = new JSONObject(data_fields);

                        String typeKey = getTypeKey(homeAccount.sms_type);
                        if (!TextUtils.isEmpty(typeKey) && obj_data_fields.has(typeKey)) {
                            homeAccount.mTransactionType = obj_data_fields.optString(typeKey);
                        } else {
                            if (obj_data_fields.has("transaction_type_rule") &&
                                    obj_data_fields.getJSONObject("transaction_type_rule").has("rules")) {

                                ruleId = obj_data_fields.getJSONObject("transaction_type_rule").getInt("group_id");
                                String ruleValue = m.group(ruleId);
                                JSONArray transaction_type_rules = obj_data_fields.getJSONObject("transaction_type_rule").getJSONArray("rules");
                                boolean isFound = false;
                                JSONObject ruleObj = null;
                                for (int i = 0; i < transaction_type_rules.length() && !isFound; i++) {
                                    ruleObj = transaction_type_rules.getJSONObject(i);
                                    String value = ruleObj.getString("value");
                                    if (value.equalsIgnoreCase(ruleValue)) {
                                        isFound = true;
                                    }
                                }
                                if (ruleObj != null) {
                                    if (ruleObj.has("pos_override")) {
                                        homeAccount.transactionDesc = ruleObj.getString("pos_override");
                                    }
                                    if (ruleObj.has("txn_type")) {
                                        homeAccount.txn_type = ruleObj.getString("txn_type");
                                        if (homeAccount.txn_type.equalsIgnoreCase("debit_atm")) {
                                            homeAccount.isAtmWithDraw = true;
                                        }
                                    }
                                }

                            }
                        }

                        if (obj_data_fields.has("amount")) {
                            if (obj_data_fields.getJSONObject("amount").has("group_id")) {
                                amountId = obj_data_fields.getJSONObject("amount").getInt("group_id");
                                homeAccount.amount = m.group(amountId);  //AccountAmount
                            } else if (obj_data_fields.getJSONObject("amount").has("group_ids")) {
                                JSONArray ids = obj_data_fields.getJSONObject("amount").getJSONArray("group_ids");
                                for (int i = 0; i < ids.length(); i++) {
                                    homeAccount.amounts.add(m.group(ids.getInt(i)));
                                }
                            }
                            if (obj_data_fields.getJSONObject("amount").has("txn_direction")) {
                                homeAccount.isDebited = false;
                            }
                        }
//                        ArrayList<String> values = new ArrayList<>();
//                        if (homeAccount.amount.equalsIgnoreCase("7,999.00")) {
//
//                            int count = m.groupCount();
//                            for (int c = 0; c < count; c++) {
//                                String v = m.group(c);
//                                values.add(v);
//                            }
//                        }

                        if (obj_data_fields.has("date")) {
                            if (obj_data_fields.getJSONObject("date").has("use_sms_time")) {
                                homeAccount.use_sms_time = obj_data_fields.getJSONObject("date").getBoolean("use_sms_time");
                            } else if (obj_data_fields.getJSONObject("date").has("formats")) {
                                JSONArray array = obj_data_fields.getJSONObject("date").getJSONArray("formats");
                                for (int i = 0; i < array.length(); i++) {
                                    String format = array.getJSONObject(i).getString("format");
                                    homeAccount.dateFormats.add(format);
                                }
                                if (obj_data_fields.getJSONObject("date").has("group_id")) {
                                    dateId = obj_data_fields.getJSONObject("date").getInt("group_id");
                                    homeAccount.date = m.group(dateId);  // account_Date
                                } else if (obj_data_fields.getJSONObject("date").has("group_ids")) {
                                    JSONArray ids = obj_data_fields.getJSONObject("date").getJSONArray("group_ids");
                                    for (int i = 0; i < ids.length(); i++) {
                                        homeAccount.dates.add(m.group(ids.getInt(i)));
                                    }
                                }
                            }
                        }
//                        if (TextUtils.isEmpty(homeAccount.transactionDesc)) {
//                            getDataFromDataFields(obj_data_fields, "pos", homeAccount.transactionDesc, posID, homeAccount.transactionDescs, m);
//                        }

                        if (obj_data_fields.has("pos")) {
                            if (obj_data_fields.getJSONObject("pos").has("value")) {
                                homeAccount.transactionDesc = obj_data_fields.getJSONObject("pos").getString("value");
                            }
                            if (obj_data_fields.getJSONObject("pos").has("group_id")) {
                                posID = obj_data_fields.getJSONObject("pos").getInt("group_id");
                                homeAccount.transactionPos = m.group(posID);
                            } else if (obj_data_fields.getJSONObject("pos").has("group_ids")) {
                                JSONArray ids = obj_data_fields.getJSONObject("pos").getJSONArray("group_ids");
                                for (int i = 0; i < ids.length(); i++) {
                                    homeAccount.transactionDescs.add(m.group(ids.getInt(i)));
                                }
                            }

                        }


                        if (homeAccount.sms_type.equalsIgnoreCase("event")) {
                            getDataFromDataFields(obj_data_fields, "name", homeAccount.eventName, eventNameId, homeAccount.eventNames, m);
                            getDataFromDataFields(obj_data_fields, "event_info", homeAccount.eventInfo, eventInfoId, homeAccount.eventInfos, m);
                            getDataFromDataFields(obj_data_fields, "event_location", homeAccount.eventLocation, eventLocationId, homeAccount.eventLocations, m);
                        }

                        // Account No
                        JSONObject objpan = obj_data_fields.optJSONObject("pan");
                        String pan = "";
                        if (objpan != null) {
                            if (objpan.has("value")) {
                                homeAccount.panValue = objpan.getString("value");
                            }
                            pan = objpan.optString("group_id");
                        }
                        // pan
                        if (!TextUtils.isEmpty(pan)) {
                            homeAccount.FinalAccountNo = m.group(Integer.parseInt(pan));
                        }

                        // Account Balance
                        JSONObject objaccount_balance = obj_data_fields.optJSONObject("account_balance");
                        String account_balance = "";
                        if (objaccount_balance != null) {
                            account_balance = objaccount_balance.optString("group_id");
                        }
                        // Account Balance
                        if (!TextUtils.isEmpty(account_balance)) {
                            if (TextUtils.isDigitsOnly(account_balance)) {
                                homeAccount.FinalAccountBalance = m.group(Integer.parseInt(account_balance));
                            }
                        }

                        if (!TextUtils.isEmpty(homeAccount.mTransactionType) && homeAccount.mTransactionType.equalsIgnoreCase("credit")) {
                            homeAccount.isDebited = false;
                        }

                    }

                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    private String getTypeKey(String sms_type) {
        return sms_type + "_type";
    }


    private void getDataFromDataFields(JSONObject obj_data_fields, String key, String mainValue, int mainId, ArrayList<String> valuesArray, Matcher m) {
        try {
            if (obj_data_fields.has(key)) {
                if (obj_data_fields.getJSONObject(key).has("value")) {
                    mainValue = obj_data_fields.getJSONObject(key).getString("value");
                } else {
                    if (obj_data_fields.getJSONObject(key).has("group_id")) {
                        mainId = obj_data_fields.getJSONObject(key).getInt("group_id");
                        mainValue = m.group(mainId);
                    } else if (obj_data_fields.getJSONObject(key).has("group_ids")) {
                        JSONArray ids = obj_data_fields.getJSONObject(key).getJSONArray("group_ids");
                        for (int i = 0; i < ids.length(); i++) {
                            valuesArray.add(m.group(ids.getInt(i)));
                        }
                    }
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    private String getTransactionDesc(String transactionType) {
        String transactionDesc = "";
        switch (transactionType) {
            case "balance":
                transactionDesc = "Your Account Balance";
                break;
            case "upi":
                transactionDesc = "UPI Transaction";
                break;
            case "debit_card":
                transactionDesc = "Debit Card Transaction";
                break;
            case "net_banking":
                transactionDesc = "Net Banking";
                break;
            case "credit":
                transactionDesc = "Credited to your Account";
                break;
            case "cheque":
                transactionDesc = "Cheque Transaction";
                break;
            case "debit_atm":
                transactionDesc = "ATM withdrawal";
                break;
            case "credit_card":
                transactionDesc = "Credit Card Transaction";
                break;
            case "credit_card_bill":
                transactionDesc = "Credit Card Bill";
                break;
            case "loan_emi":
                transactionDesc = "Loan EMI";
                break;
            case "mobile_bill":
                transactionDesc = "Mobile Bill";
                break;
            case "debit_prepaid":
                transactionDesc = "Prepaid Debit Card Transaction";
                break;
            case "bill":
                transactionDesc = "Bill";
                break;
            case "internate_bill":
                transactionDesc = "Internet Bill";
                break;
            case "electricity_bill":
                transactionDesc = "Electricity Bill";
                break;
            case "insurance_premium":
                transactionDesc = "Insurance Premium";
                break;
            case "gas_bill":
                transactionDesc = "Gas Bill";
                break;
        }
        return transactionDesc;
    }


    private void CallProgress() {
        DialogProgress = new Dialog(activity);
        DialogProgress.requestWindowFeature(Window.FEATURE_NO_TITLE);
        DialogProgress.getWindow().setBackgroundDrawable(null);
        DialogProgress.setContentView(R.layout.layout_loding_allbg);
        DialogProgress.getWindow().setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT);
        DialogProgress.setCancelable(false);
        DialogProgress.setCanceledOnTouchOutside(false);

        tvValue = DialogProgress.findViewById(R.id.value123);
        progress_horizontal = DialogProgress.findViewById(R.id.progress_horizontal);

        DialogProgress.show();
    }

    private void CallFilterDataMultiviewType() {
        Log.e("cashModelHistories", cashModelHistories.size() + "");
        for (int i = 0; i < cashModelHistories.size(); i++) {
            CashModelHistory alldata = cashModelHistories.get(i);
            String TitleDateCash = alldata.getTitleDate();
            String dateValCash = alldata.getDate();
            String AccountNo = alldata.getAccountno();
            String AccountAmount = alldata.getAccountamount();
            String CheckIsDebitCredit = alldata.getCreditdebit();
            String BankName = alldata.getBankName();
            try {
                mydbCash.InsertCash(TitleDateCash, dateValCash, AccountNo, AccountAmount,
                        CheckIsDebitCredit, BankName);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        ArrayList<CashModelHistory> db = new ArrayList<>();
        db.addAll(mydbCash.GetCash());
        Log.e("cashModelHistoriesDB", db.size() + "");

    }


    private String extractMerchantNameFromSMSMy(String mMessage) {
        String MarchantFound = "";
        try {
            Pattern regEx = Pattern.compile("(?i)(?:\\sInfo.\\s*)([A-Za-z0-9*]*\\s?-?\\s?[A-Za-z0-9*]*\\s?-?\\.?)");
            // Find instance of pattern matches
            Matcher m = regEx.matcher(mMessage);
            if (m.find()) {
                String mMerchantName = m.group();
                mMerchantName = mMerchantName.replaceAll("^\\s+|\\s+$", "");//trim from start and end
                mMerchantName = mMerchantName.replace("Info.", "");
                MarchantFound = mMerchantName;
            } else {
                MarchantFound = "";
            }
        } catch (Exception e) {
            MarchantFound = "";
        }

        return MarchantFound;
    }


    @Override
    public void ClickActiveDeactive(final int position, final int color, HomeAccoutList modelData) {
        Log.e("PositionAccount", position + "");

       /* if (homeAccoutLists.size() > 0) {
            Intent i = new Intent(getActivity(), AccountHisotryActivity.class);
            i.putExtra("OBJ", homeAccoutLists.get(position));
            i.putExtra("color", color);
            startActivity(i);
        }
*/
    }

    @Override
    public void ClickBusinessOrPersion(int position) {
        if (allAccountModels.size() > 0) {
            boolean isActivinactive = allAccountModels.get(position).isBusinessOrPersion();
            allAccountModels.get(position).setBusinessOrPersion(!isActivinactive);

            if (allAccountListAdapter != null) {
                allAccountListAdapter.notifyDataSetChanged();
            }
        }
    }

}