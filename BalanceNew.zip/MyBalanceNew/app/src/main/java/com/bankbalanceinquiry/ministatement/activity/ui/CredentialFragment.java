package com.bankbalanceinquiry.ministatement.activity.ui;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.activity.BillsNewActivity;
import com.bankbalanceinquiry.ministatement.activity.CashWithdrawalActivity;
import com.bankbalanceinquiry.ministatement.inapp.AdsManager;
import com.bankbalanceinquiry.ministatement.store.ui.fragments.GeneratePasswordFragment;
import com.bankbalanceinquiry.ministatement.store.ui.fragments.SettingsFragment;
import com.bankbalanceinquiry.ministatement.store.ui.fragments.account.PasswordFragment;
import com.bankbalanceinquiry.ministatement.store.ui.fragments.card.CardFragment;
import com.bankbalanceinquiry.ministatement.utils.NetworkManager;


import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;


public class CredentialFragment extends Fragment {


    BottomNavigationView bottomNav;
    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_credential, container, false);

        bottomNav= root.findViewById(R.id.bottom_nav);
        loadFragment(new PasswordFragment());

        bottomNav.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.homeFragment : {
                        loadFragment(new PasswordFragment());
                        return true;
                    }
                    case R.id.cardFragment :{
                        loadFragment(new CardFragment());
                        return true;
                    }
//                    case R.id.passwordFragment : {
//                        loadFragment(new GeneratePasswordFragment());
//                        return true;
//                    }
//                    case R.id.settingsFragment : {
//                        loadFragment(new SettingsFragment());
//                        return true;
//                    }
                }
                return false;
            }
        });

        return root;
    }

    private void loadFragment(Fragment fragment) {
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment, fragment);
        transaction.commit();
    }

    @Override
    public void onDestroyView() {
        //EventBus.getDefault().unregister(this);
        super.onDestroyView();
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
    }


}