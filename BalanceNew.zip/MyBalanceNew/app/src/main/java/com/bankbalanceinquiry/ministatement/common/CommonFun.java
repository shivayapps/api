package com.bankbalanceinquiry.ministatement.common;

import android.app.Activity;
import android.text.TextUtils;

import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bankbalanceinquiry.ministatement.model.AllAccountModel;
import com.bankbalanceinquiry.ministatement.model.BilsEmiModel;
import com.bankbalanceinquiry.ministatement.model.CashModelHistory;
import com.bankbalanceinquiry.ministatement.model.FirstTimeSmsModel;

import java.util.ArrayList;

public class CommonFun {

    public static ArrayList<AllAccountModel> allAccountModelsFun = new ArrayList<>();

    public static ArrayList<FirstTimeSmsModel> firstTimeSmsModels = new ArrayList<>();

    public static ArrayList<CashModelHistory> CashModelHistoriesTmp = new ArrayList<>();

    public static ArrayList<BilsEmiModel> BilsEmiModels = new ArrayList<>();

    public static String IsAllSmsmFill = "";
    public static String isIncommingSmsNotify = "";

    public static void RecyclerViewGridLayout(Activity activity, RecyclerView recyclerView, int SpanCount) {
        GridLayoutManager layoutManager = new GridLayoutManager(activity, SpanCount);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
    }


    public static void RecyclerViewLinearLayout(Activity activity, RecyclerView recyclerView) {
        LinearLayoutManager layoutManager = new LinearLayoutManager(activity);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
    }


    public static int findSum(String str) {
        int sum = 0;
        String temp = "";
        try {
            if (TextUtils.isEmpty(str)) {
                return 0;
            }
            for (int i = 0; i < str.length(); i++) {
                char ch = str.charAt(i);
                if (Character.isDigit(ch))
                    temp += ch;
                else {
                    sum += Integer.parseInt(temp);
                    temp = "0";
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (TextUtils.isEmpty(temp)) {
            temp = "0";
        }
        return sum + Integer.parseInt(temp);
    }
}
