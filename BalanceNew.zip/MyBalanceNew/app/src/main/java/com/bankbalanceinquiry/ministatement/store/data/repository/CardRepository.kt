package com.bankbalanceinquiry.ministatement.store.data.repository

import androidx.lifecycle.LiveData
import com.bankbalanceinquiry.ministatement.store.data.model.Card
import com.bankbalanceinquiry.ministatement.store.data.room.CardDao

class CardRepository(private val cardDao: CardDao) {
    val readAllCard: LiveData<List<Card>> = cardDao.readAllCard()

    suspend fun addCard(card: Card){
        cardDao.addCard(card)
    }

    suspend fun editCard(card: Card){
        cardDao.editCard(card)
    }

    suspend fun deleteCard(card: Card){
        cardDao.deleteCard(card)
    }

}