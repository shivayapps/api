package com.bankbalanceinquiry.ministatement.fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.bankbalanceinquiry.ministatement.OnItemClickListner;
import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.adapter.listBankAdapter;
import com.bankbalanceinquiry.ministatement.database.DatabaseAccess;
import com.bankbalanceinquiry.ministatement.model.bankname;

import java.util.List;

public class ChangeBankFragment extends Fragment implements OnItemClickListner {

    View root;
    public ListView custom_list_view;
    listBankAdapter listBankAdapter;
    List<bankname> mData;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        root = inflater.inflate(R.layout.fragment_changebank, container, false);

        custom_list_view = root.findViewById(R.id.custom_list_view);

        DatabaseAccess databaseAccess = DatabaseAccess.getInstance(getActivity());
        databaseAccess.open();
        mData = databaseAccess.getList();
        databaseAccess.close();
        String[] bankColor_array = getActivity().getResources().getStringArray(R.array.listcolors);

      /*  if (mData != null && mData.size() > 1 && AdmobAdManager.getInstance().isNetworkAvailable(getContext())) {
            bankname info = new bankname();
            info.setType(1);
            mData.add(1, info);
        }*/
        listBankAdapter = new listBankAdapter(getActivity(), mData, bankColor_array);
        listBankAdapter.OnItemClickListener(this);

        custom_list_view.setAdapter(listBankAdapter);
        custom_list_view.setScrollingCacheEnabled(true);
        Log.e("Size---)", "" + mData.size());
        // toolbar.setTitle(getString(R.string.app_name));


        return root;
    }

    public void onbackPressed() {
        if (getActivity() != null) {
            super.getActivity().onBackPressed();
        }
    }

    @Override
    public void onItemClick() {
        onbackPressed();
    }
}
