package com.bankbalanceinquiry.ministatement.activity

//import kotlinx.android.synthetic.main.activity_state.*
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.BannerAdHelper
import com.bankbalanceinquiry.ministatement.R
import com.bankbalanceinquiry.ministatement.adapter.StateAdapter
import com.bankbalanceinquiry.ministatement.databinding.ActivityStateBinding
import com.bankbalanceinquiry.ministatement.inapp.AdsManager
import com.bankbalanceinquiry.ministatement.utils.AdCache
import com.bankbalanceinquiry.ministatement.utils.NetworkManager
import com.google.android.gms.ads.AdView
import org.json.JSONObject
import java.io.InputStream

class StateActivity : AppCompatActivity() {


//    lateinit var mRVState: RecyclerView
    lateinit var mStateLayout: LinearLayoutManager
    lateinit var mStateAdapter: StateAdapter
    lateinit var mStateList: ArrayList<String>
    private lateinit var binding: ActivityStateBinding

    var isAdLoaded = false
    var mAdView: AdView?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStateBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        setContentView(R.layout.activity_state)

        initToolBar()

        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //getSupportActionBar().setHomeAsUpIndicator(getResources().getDrawable(R.drawable.ic_drawer));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = getColor(R.color.app_color)
        }

        mStateList = arrayListOf()

//        hideSystemUI()
//        imgBtnBack.setOnClickListener { onBackPressed() }
//        mTVToolbar.text = "Select State"

//        mRVState = findViewById(R.id.mRVState)


        AdmobIntersAdImpl().load(this, getString(R.string.g_interstitial_id2))
        if (NetworkManager.isInternetConnected(
                this@StateActivity
            )
        ) {
            val adId = getString(R.string.g_banner_state)
            BannerAdHelper.showBanner(
                this,
                binding.adLayout,
                adId,
                AdCache.bannerState,
                { aBoolean: Boolean?, adView: AdView?, s: String? ->
                    AdCache.bannerState = adView
                    mAdView = adView
                    isAdLoaded = true
                    null
                },
                null
            )
        }

//        mIVSearch.visibility = View.VISIBLE
//        mIVSearch.setOnClickListener {
//            mETSearch.visibility = View.VISIBLE
//            mETSearch.hint = "Search State"
//            mIVSearch.visibility = View.GONE
//        }
        val json: String?
//        val inputStream: InputStream = this.assets.open("state.json");
        val inputStream: InputStream = this.assets.open("holiday_2024.json");
        val size = inputStream.available();
        val buffer: ByteArray = ByteArray(size)
        inputStream.read(buffer);
        inputStream.close();
        json = String(buffer, charset("UTF-8"))

//        mETSearch.addTextChangedListener(object : TextWatcher {
//            override fun afterTextChanged(s: Editable?) {
//                filterState(s.toString())
//            }
//            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
//            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
//            }
//        })

        val jsonRootObject = JSONObject(json)
        val jsonObject = jsonRootObject.getJSONObject("states")
        val keys = jsonObject.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            mStateList.add(key)
        }

        mStateLayout = LinearLayoutManager(this)
        mStateAdapter = StateAdapter(this, mStateList, object : StateAdapter.ClickListener {
            override fun onItemClick(position: String) {
                if (AdsManager(this@StateActivity).isNeedToShowAds()
                    && NetworkManager.isInternetConnected(this@StateActivity)) {
                    AdsConfig.showInterstitialAd(this@StateActivity) {
                        val intent = Intent(this@StateActivity, HolidayActivity::class.java)
                        intent.putExtra("state", position)
                        startActivity(intent)
                    }


                } else {
                    val intent = Intent(this@StateActivity, HolidayActivity::class.java)
                    intent.putExtra("state", position)
                    startActivity(intent)
                }
            }
        })
        binding.mRVState.layoutManager = mStateLayout
        binding.mRVState.adapter = mStateAdapter
    }

    override fun onPause() {
        super.onPause()
        if (mAdView != null) mAdView!!.pause()
    }

    override fun onResume() {
        super.onResume()
        if (mAdView != null) mAdView!!.resume()
    }

    private var toolbar: Toolbar? = null
    private fun initToolBar() {
        toolbar = findViewById<Toolbar>(R.id.toolbar)
        toolbar!!.setTitle("Search State")
        setSupportActionBar(toolbar)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.setDisplayShowHomeEnabled(true)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

}