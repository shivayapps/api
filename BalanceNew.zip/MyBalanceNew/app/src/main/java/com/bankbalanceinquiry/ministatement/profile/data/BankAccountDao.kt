package com.bankbalanceinquiry.ministatement.profile.data

import androidx.room.*
import com.bankbalanceinquiry.ministatement.profile.data.BankAccount
import kotlinx.coroutines.flow.Flow

@Dao
interface BankAccountDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(bankAccount: BankAccount)

    @Update
    fun update(bankAccount: BankAccount)

    @Delete
    fun delete(bankAccount: BankAccount)

    @Query("SELECT * FROM bank_account WHERE id = :id")
    fun getItem(id: Int): BankAccount

    @Query("SELECT * FROM bank_account ORDER BY bank_name ASC")
    fun getItems(): List<BankAccount>
}