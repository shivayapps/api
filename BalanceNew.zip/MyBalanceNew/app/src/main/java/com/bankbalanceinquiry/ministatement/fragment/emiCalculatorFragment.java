package com.bankbalanceinquiry.ministatement.fragment;

import static android.content.Context.INPUT_METHOD_SERVICE;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.activity.SubActivity_homePage;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class emiCalculatorFragment extends Fragment {

    EditText amount, rate, period_text, date;
    Spinner spinner;
    ImageView calendar;
    TextView calculate, reset, monthly_emi, total_interest, total_payment, details;
    String[] arraySpinner = new String[]{};
    public static String loan_period_month;

    public static long loan_amount;
    public static float loan_interest;
    long loan_month;
    LinearLayout loan_calculate_linear;
    public static String click, static_emi, static_rate, static_payment, start_date;
    public static double intreset;
    public static double total_emi;
    public static String month_text;
    public static int year_digit;
//    LoadAds loadAds;

    FrameLayout fl_adplaceholder_bal;
    Context mContext;


    private FrameLayout frameLayout;
    private FrameLayout adLayout;
    private CardView adcard;


    @Nullable
    @Override
    public View onCreateView(@NonNull final LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_emicalculator, container, false);
        arraySpinner = new String[]{getString(R.string.month), getString(R.string.year)};
        mContext = getActivity();

        amount = view.findViewById(R.id.amount);
        rate = view.findViewById(R.id.interest);
        period_text = view.findViewById(R.id.loan_period_text);
        date = view.findViewById(R.id.date);

        spinner = view.findViewById(R.id.spinner);

        calendar = view.findViewById(R.id.cal);
        calculate = view.findViewById(R.id.calculate);
        details = view.findViewById(R.id.details);
        monthly_emi = view.findViewById(R.id.monthly_emi);
        total_interest = view.findViewById(R.id.total_interest);
        total_payment = view.findViewById(R.id.total_payment);

        fl_adplaceholder_bal = view.findViewById(R.id.fl_adplaceholder_emi);
        reset = view.findViewById(R.id.reset);
        loan_calculate_linear = view.findViewById(R.id.loan_calculate_linear);


        final Calendar cal = Calendar.getInstance();
        SimpleDateFormat month_date = new SimpleDateFormat("MMM-yyyy");
        String ma = month_date.format(cal.getTime());
        date.setText(ma);


        //set Spinner data
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_spinner_item, arraySpinner);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                loan_period_month = period_text.getText().toString();

                if (i == 0) {
                    click = "month";
                    loan_period_month = period_text.getText().toString();
                } else {
                    click = "year";

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

//        refreshAd();
        calendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogFragment newFragment = new DatePickerFragment();
                newFragment.show(getFragmentManager(), "Date Picker");
            }
        });

        calculate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if (TextUtils.isEmpty(amount.getText().toString()) || TextUtils.isEmpty(rate.getText().toString()) || TextUtils.isEmpty(period_text.getText().toString())) {
                    Toast.makeText(getActivity(), "Please First Fill the Value", Toast.LENGTH_SHORT).show();


                    // Toast.makeText(getActivity()," "+month_digit,Toast.LENGTH_SHORT).show();
                } else {
//                    loadAds.showFullAd(1);
                    InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(), 0);

                    Calendar calender = Calendar.getInstance();
                    start_date = date.getText().toString();

                    //get Month and year From Calender
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMM-yyyy");
                    try {
                        String newDateStr = simpleDateFormat.format(simpleDateFormat.parse(start_date));
                        String[] str = newDateStr.split("-");

                        month_text = str[0];
                        year_digit = Integer.parseInt(str[1]);

                    } catch (ParseException e) {
                        e.printStackTrace();
                    }

                    loan_calculate_linear.setVisibility(View.VISIBLE);
                    Log.e("chcek", " " + click);

                    if (click.matches("month")) {
                        loan_period_month = period_text.getText().toString();
                        Log.e("period_m", " " + loan_period_month);
                    } else if (click.matches("year")) {
                        loan_period_month = String.valueOf(1);
                        try {
                            int year = Integer.parseInt(period_text.getText().toString());
                            int month = year * 12;
                            loan_period_month = String.valueOf(month);
                            Log.e("period", " " + loan_period_month);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                    loan_amount = Long.parseLong(amount.getText().toString());
                    loan_interest = Float.parseFloat(rate.getText().toString());
                    loan_month = Long.parseLong(loan_period_month);
                    Log.e("month", " " + loan_month);


                    intreset = loan_interest / 12 / 100;

                    Log.e("Detail---)", " " + loan_amount + " " + (1 + intreset) + " " + loan_month);

                    double up_interest = Math.pow((1 + intreset), loan_month);

                    Log.e("Detail_up", " " + up_interest);


                    total_emi = (loan_amount * intreset * (up_interest / ((up_interest) - 1)));
                    NumberFormat nf = NumberFormat.getNumberInstance(Locale.US);
                    DecimalFormat decim = (DecimalFormat) nf;
                    decim.applyPattern("##.##");
                    double format = Double.parseDouble(decim.format(total_emi));
                    double total_pay = format * loan_month;
                    double total_intrest = total_pay - loan_amount;

                    Log.e("total_emi", " " + total_emi);
                    Log.e("total_emi", " " + total_pay);
                    Log.e("total_emi", " " + total_intrest);

                    monthly_emi.setText(decim.format(total_emi) + " \u20B9");
                    total_interest.setText(decim.format(total_intrest) + " \u20B9");
                    total_payment.setText(decim.format(total_pay) + " \u20B9");

                    static_emi = monthly_emi.getText().toString();
                    static_rate = total_interest.getText().toString();
                    static_payment = total_payment.getText().toString();

                }

            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                loan_calculate_linear.setVisibility(View.GONE);

                amount.setText("");
                rate.setText("");
                period_text.setText("");

                amount.setHint("500000");
                rate.setHint("0.5");
                period_text.setHint("12");

                Calendar cal = Calendar.getInstance();
                SimpleDateFormat month_date = new SimpleDateFormat("");
                String ma = month_date.format(cal.getTime());
                date.setText(ma);
            }
        });

        details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startNextActivity(7);
                //navController.navigate(R.id.nav_full_emi);

            }
        });
        adLayout = view.findViewById(R.id.adLayout);
        adcard = view.findViewById(R.id.adcard);
        int colors = ContextCompat.getColor(getActivity(), R.color.colorAccent);
//        AdmobAdManager.getInstance().LoadNativeAd(getActivity(), getString(R.string.temp_adx_native_id), new AdEventListener() {
//            @Override
//            public void onAdLoaded(Object object) {
//                //    AdmobAdManager.getInstance(mContext).populateUnifiedSmallNativeAdView(mContext ,adLayout  , (NativeAd) object);
//                AdmobAdManager.getInstance().populateUnifiedNativeAdView(mContext, adLayout, (NativeAd) object, true, true);
//
//            }
//
//            @Override
//            public void onAdClosed() {
//            }
//
//            @Override
//            public void onLoadError(String errorCode) {
//            }
//            /*@Override
//            public void onAdLoaded(MaxNativeAdView maxNativeAdView, MaxAd maxAd) {
//                AdmobAdManager.getInstance(getActivity())
//                        .populateUnifiedSmallNativeApplovin(getActivity(), adLayout, maxNativeAdView, maxAd, true);
//            }*/
//        }, true);
        return view;
    }


    private void startNextActivity(int type) {
        Intent i = new Intent(getActivity(), SubActivity_homePage.class);
        i.putExtra("viewType", type);
        startActivity(i);
    }


}
