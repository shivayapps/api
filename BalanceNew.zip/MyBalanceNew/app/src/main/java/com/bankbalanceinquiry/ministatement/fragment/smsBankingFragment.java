package com.bankbalanceinquiry.ministatement.fragment;

import static android.content.Context.MODE_PRIVATE;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.adconfig.adsutil.admob.BannerAdHelper;
import com.adconfig.adsutil.admob.NativeAdHelper;
import com.adconfig.adsutil.admob.NativeLayoutType;
import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.adapter.smsList_Adapter;
import com.bankbalanceinquiry.ministatement.database.DatabaseAccess;
import com.bankbalanceinquiry.ministatement.inapp.AdsManager;
import com.bankbalanceinquiry.ministatement.model.smsInfo;
import com.bankbalanceinquiry.ministatement.utils.AdCache;
import com.bankbalanceinquiry.ministatement.utils.NetworkManager;
import com.google.android.gms.ads.AdView;


import java.util.List;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function3;

public class smsBankingFragment extends Fragment {
    String bank_name;
    RecyclerView sms_recycle;
    List<smsInfo> mSMS;
    smsList_Adapter smsList_adapter;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editorBank;
    private FrameLayout adLayout;
    private View view;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_smsbanking, container, false);

        sms_recycle = view.findViewById(R.id.custom_sms_list);
        /*AdmobAdManager.getInstance().loadInterstitialAd(getActivity(), getString(R.string.interstitial_id), 1, (AdmobAdManager.OnAdClosedListener) () -> {
        });*/
        sharedPreferences = getActivity().getSharedPreferences("bank_select", MODE_PRIVATE);
        editorBank = sharedPreferences.edit();
        adLayout = view.findViewById(R.id.adContainer);
        //Check preference
        bank_name = sharedPreferences.getString("bank_name", "No Bank");
        // bank_name=bank_n;

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        sms_recycle.setLayoutManager(linearLayoutManager);

        DatabaseAccess databaseAccess = DatabaseAccess.getInstance(getActivity());
        databaseAccess.open();
        mSMS = databaseAccess.getSMS_detail(bank_name);
        databaseAccess.close();

        smsList_adapter = new smsList_Adapter(getActivity(), mSMS);
        sms_recycle.setAdapter(smsList_adapter);

        if (new AdsManager(getActivity()).isNeedToShowAds() && NetworkManager.isInternetConnected(getActivity())) {
            loadNative();
        }
        return view;
    }


    Boolean isAdLoaded=false;
    AdView mAdView;
    public void loadNative() {

        String adId=getString(R.string.g_banner_smsbanking);
        BannerAdHelper.INSTANCE.showBanner(getActivity(), adLayout, adId, AdCache.Companion.getBannerSmsBanking(), new Function3<Boolean, AdView, String, Unit>() {
            @Override
            public Unit invoke(Boolean aBoolean, AdView adView, String s) {
                AdCache.Companion.setBannerSmsBanking(adView);
                mAdView=adView;
                isAdLoaded=true;
                return null;
            }
        },null);
    }


    @Override
    public void onPause() {
        super.onPause();
        if(mAdView!=null) mAdView.pause();
    }

    @Override
    public void onResume() {
        super.onResume();
        if(mAdView!=null) mAdView.resume();
    }
}
