package com.bankbalanceinquiry.ministatement.activity;

import static com.bankbalanceinquiry.ministatement.utils.Constant.setLocale;

import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.fragment.ChangeBankFragment;
import com.bankbalanceinquiry.ministatement.fragment.bankBalanceFragment;
import com.bankbalanceinquiry.ministatement.fragment.detailEMIFragment;
import com.bankbalanceinquiry.ministatement.fragment.emiCalculatorFragment;
import com.bankbalanceinquiry.ministatement.fragment.epfServiceFragment;
import com.bankbalanceinquiry.ministatement.fragment.sendMoneyFragment;
import com.bankbalanceinquiry.ministatement.fragment.smsBankingFragment;
import com.bankbalanceinquiry.ministatement.fragment.ussdBankingFragment;


public class SubActivity_homePage extends AppCompatActivity {


    public Toolbar toolbar;
    private ActionBar actionBar;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLocale(this);
        setContentView(R.layout.activity_sub_home_page);
        getWindow().setStatusBarColor(getResources().getColor(R.color.app_color));

        /*if (getIntent().hasExtra("showAd") && getIntent().getBooleanExtra("showAd", false)) {
            AdmobAdManager.getInstance().loadInterstitialAd(this, getString(R.string.interstitial_id), 1, (AdmobAdManager.OnAdClosedListener) () -> {
            });
        } else {

            AdmobAdManager.getInstance().loadInterstitialAd(this, getString(R.string.interstitial_id), 3, (AdmobAdManager.OnAdClosedListener) () -> {
            });
        }*/
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);

        int type = getIntent().getIntExtra("viewType", 0);
        final FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        Fragment fragment = null;
        switch (type) {
            case 0:
                fragment = new bankBalanceFragment();
                toolbar.setTitle(getString(R.string.bank_balance_check));
                break;
            case 1:
                fragment = new emiCalculatorFragment();
                toolbar.setTitle(getString(R.string.emi_calculator1));
                break;
            case 2:
                fragment = new ussdBankingFragment();
                toolbar.setTitle(getString(R.string.ussd_banking));

                break;
            case 3:
                fragment = new smsBankingFragment();
                toolbar.setTitle(getString(R.string.sms_banking));

                break;
            case 5:
                fragment = new epfServiceFragment();
                toolbar.setTitle(getString(R.string.epf_service));

                break;
            case 6:
                fragment = new ChangeBankFragment();
                toolbar.setTitle(getString(R.string.list_bank));
                break;
            case 7:
                fragment = new detailEMIFragment();
                toolbar.setTitle(getString(R.string.app_name));
                break;
            case 8:
                fragment = new sendMoneyFragment();
                toolbar.setTitle(getString(R.string.app_name));
                break;
        }
        if (fragment != null) {
            transaction.replace(R.id.frame_base, fragment);
            transaction.addToBackStack(null);
            transaction.commit();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        finish();
    }
}
