package com.bankbalanceinquiry.ministatement.newmodel;

import java.io.Serializable;
import java.util.ArrayList;

public class HomeAccoutList implements Serializable {

    //0 data , 1 ad
    int type = 0;
    public int id;
    public String full_name = "";
    public String bankNickName = "";
    public String account_type = "";
    public String sms_type = "";
    public String FinalAccountBalance = "";
    public String FinalAccountNo = "";
    public String body = "";

    public ArrayList<String> transactionDescs = new ArrayList<>();
    public ArrayList<String> dates = new ArrayList<>();
    public ArrayList<String> amounts = new ArrayList<>();
    public ArrayList<String> eventNames = new ArrayList<>();
    public ArrayList<String> eventLocations = new ArrayList<>();
    public ArrayList<String> eventInfos = new ArrayList<>();
    public ArrayList<String> dateFormats = new ArrayList<>();

    public String panValue = "";
    public String mTransactionType = "";
    public String transactionDesc = "";
    public String transactionPos = "";

    ////////date included in message
    public String date = "";
    public String amount = "";
    public String eventName = "";
    public String eventLocation = "";
    public String eventInfo = "";

    public String txn_type = "";

    public boolean isDebited = true;
    public boolean isAtmWithDraw = false;
    public boolean use_sms_time = false;


    public String finalTransactionDesc = "";
    ///////////date of messge in different format
    public String dateValAccount, DateTransactionHistory, dateValHistory;
    public int GetTitleType = 1;
    public boolean isSectionHeader = false;
    public ArrayList<String> CreditedData = new ArrayList<>();
    public ArrayList<String> DebitedData = new ArrayList<>();


    public long dateLongValue = 0;
    public int dateValue = 0;
    public int monthValue = 0;
    public String monthValueString = "";
    public int yearValue = 0;

    public HomeAccoutList() {
    }

    public HomeAccoutList(int type) {
        this.type = type;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
