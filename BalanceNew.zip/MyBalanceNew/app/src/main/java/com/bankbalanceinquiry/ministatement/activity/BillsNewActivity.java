package com.bankbalanceinquiry.ministatement.activity;

import static com.bankbalanceinquiry.ministatement.utils.Constant.setLocale;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.adconfig.adsutil.admob.BannerAdHelper;
import com.adconfig.adsutil.admob.NativeAdHelper;
import com.adconfig.adsutil.admob.NativeLayoutType;
import com.bankbalanceinquiry.ministatement.Events.SmsProgress;
import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.activity.ui.BillsFragment;
import com.bankbalanceinquiry.ministatement.financialcalculator.Calculations;
import com.bankbalanceinquiry.ministatement.inapp.AdsManager;
import com.bankbalanceinquiry.ministatement.utils.AdCache;
import com.bankbalanceinquiry.ministatement.utils.Constant;
import com.bankbalanceinquiry.ministatement.utils.NetworkManager;
import com.bankbalanceinquiry.ministatement.utils.PreferenceHelper;
import com.bankbalanceinquiry.ministatement.utils.SmsService;


import com.google.android.gms.ads.AdView;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.google.android.material.tabs.TabLayout;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function3;


public class BillsNewActivity extends AppCompatActivity {

    private ViewPager mPager;
    private PagerAdapter pagerAdapter;
    private Toolbar toolbar;
    TabLayout tabLayout;
    String[] keys = new String[]{};

    private LinearProgressIndicator progress;
    private TextView count;
    private LinearLayout progress_lay;
    String currentBillType = "";


    private FrameLayout adcard;
    private FrameLayout adLayout;


    @Subscribe
    public void OnSmsProgress(final SmsProgress smsProgress) {
        if (!isFinishing()) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (smsProgress.isShowProgress()) {
                        if (progress_lay.getVisibility() != View.VISIBLE) {
                            progress_lay.setVisibility(View.VISIBLE);
                        }
                    } else {
                        progress_lay.setVisibility(View.GONE);
                    }
                    //count.setText(SmsService.smsCount + "/" + SmsService.TotalCount);
                    int per = (SmsService.smsCount * 100) / SmsService.TotalCount;
                    //moneyBinding.count.setText(SmsService.smsCount + "/" + SmsService.TotalCount);
                    // count.setText(per + "%");
                    count.setText(getResources().getString(R.string.analyzing_from_sms_service) + " " + per + "%");

                    //progress.setMax(SmsService.TotalCount);
                    //progress.setProgress(smsProgress.getProgress());
                    if (SmsService.smsCount == (SmsService.TotalCount - 1)) {
                        PreferenceHelper.saveToUserDefaults(BillsNewActivity.this, Constant.TRACK_PREF, "1");
                        progress_lay.setVisibility(View.GONE);
                    }
                }
            });
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if(mAdView!=null) mAdView.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(mAdView!=null) mAdView.resume();
    }

    Boolean isAdLoaded = false;
    AdView mAdView;

    public void loadNative() {
        if (new AdsManager(BillsNewActivity.this).isNeedToShowAds() && NetworkManager.isInternetConnected(BillsNewActivity.this)) {
//            new NativeAdHelper(this, adLayout, NativeLayoutType.NativeBanner, getString(R.string.G_NATIVE_ID)).loadAd();
            String adId = getString(R.string.g_banner_billnew);
            BannerAdHelper.INSTANCE.showBanner(this, adLayout, adId, AdCache.Companion.getBannerBillnew(), new Function3<Boolean, AdView, String, Unit>() {
                @Override
                public Unit invoke(Boolean aBoolean, AdView adView, String s) {
                    AdCache.Companion.setBannerBillnew(adView);
                    mAdView = adView;
                    isAdLoaded = true;
                    return null;
                }
            }, null);
        }
//        isAdLoaded = true;
//        AdmobAdManager.getInstance().LoadNativeAd(this, getString(R.string.native_id), new AdEventListener() {
//            @Override
//            public void onAdLoaded(Object object) {
//                //   AdmobAdManager.getInstance().populateUnifiedSmallNativeAdView(getContext(), adLayout, (NativeAd) object);
//                AdmobAdManager.getInstance(BillsNewActivity.this).populateUnifiedNativeAdView(BillsNewActivity.this, adLayout, (NativeAd) object, true, true);
//
//            }
//
//            @Override
//            public void onAdClosed() {
//                isAdLoaded = false;
//
//            }
//
//            @Override
//            public void onLoadError(String errorCode) {
//                isAdLoaded = false;
//
//            }
//
//            @Override
//            public void onAdLoaded(MaxNativeAdView maxNativeAdView, MaxAd maxAd) {
//                isAdLoaded = true;
//
//                AdmobAdManager.getInstance(BillsNewActivity.this)
//                        .populateUnifiedSmallNativeApplovin(BillsNewActivity.this, adLayout, maxNativeAdView, maxAd, true);
//
//            }
//        }, true);
    }


    @Subscribe
    public void OnSmsProgress(final Intent intent) {
        if (!isFinishing() && intent != null && pagerAdapter != null) {
            if (intent.getAction() == "UPDATEVIEW") {
                String billType = intent.getStringExtra("billType");
                int itemCount = intent.getIntExtra("itemCount", 0);
                if (currentBillType.equals(billType)) {
                    if (itemCount > 0) {
//                        adcard.setVisibility(View.GONE);
                    } else {
//                        adcard.setVisibility(View.GONE);

//                        if (!isAdLoaded) {
//                        }
//                        adcard.setVisibility(View.VISIBLE);
                    }
                }

            }
        }
    }


    @Override
    protected void onDestroy() {
        EventBus.getDefault().unregister(this);
        super.onDestroy();
    }

    private boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        if (manager != null) {
            for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
                if (serviceClass.getName().equals(service.service.getClassName())) {
                    return true;
                }
            }
        }
        return false;
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLocale(this);
        setContentView(R.layout.activity_bills);
        keys = new String[]{"loan", "prepaid", "phone",
                "credit_card", "generic", "electricity",
                "insurance", "gas"};
        currentBillType = "loan";

        InitToolBar();
        adcard = findViewById(R.id.adcard);
        adLayout = findViewById(R.id.adLayout);

        if (!EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().register(this);

        progress = findViewById(R.id.progress);
        count = findViewById(R.id.count);
        progress_lay = findViewById(R.id.progress_lay);


        mPager = findViewById(R.id.pager);
        tabLayout = findViewById(R.id.tab_layout);
        tabLayout.setupWithViewPager(mPager);
        tabLayout.setTabMode(TabLayout.MODE_SCROLLABLE);
        pagerAdapter = new ScreenSlidePagerAdapter(getSupportFragmentManager());
        mPager.setAdapter(pagerAdapter);
        mPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                currentBillType = keys[position];
                EventBus.getDefault().post(new Intent("CHECK_FOR_UPDATE").putExtra("billType", currentBillType));
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                EventBus.getDefault().post(new Intent("CHECK_FOR_UPDATE").putExtra("billType", currentBillType));
            }
        }, 200);

        loadNative();
    }


    private void InitToolBar() {
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(getString(R.string.bill_emi_title));
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }


    private class ScreenSlidePagerAdapter extends FragmentStatePagerAdapter {
        public ScreenSlidePagerAdapter(FragmentManager fm) {
            super(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        }

        @Override
        public Fragment getItem(int position) {
            return new BillsFragment(keys[position]);
        }

        @Override
        public int getCount() {
            return keys.length;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return getEmptyMessage(keys[position]);
        }

    }

    private String getEmptyMessage(String mKey) {
        switch (mKey) {
            case "loan":
                return getString(R.string.load_emi);
            case "prepaid":
                return getString(R.string.prepaid_bills);
            case "phone":
                return getString(R.string.phone_bills);
            case "credit_card":
                return getString(R.string.credit_card_bills);
            case "generic":
                return getString(R.string.generic_bills);
            case "electricity":
                return getString(R.string.electricity_bills);
            case "insurance":
                return getString(R.string.insurance_bills);
            case "gas":
                return getString(R.string.gas_bills);
            default:
                return getString(R.string.bill_emi);
        }
    }
}
