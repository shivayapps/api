package com.bankbalanceinquiry.ministatement.utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;
import android.webkit.WebView;

import androidx.annotation.NonNull;

import com.adconfig.adsutil.AdsParameters;
import com.adconfig.adsutil.openad.WelcomeBackActivity;
import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.activity.SplashActivity;
import com.bankbalanceinquiry.ministatement.inapp.AdsManager;
import com.adconfig.AdsConfig;
import com.adconfig.adsutil.Config;
import com.adconfig.adsutil.openad.AppOpenApplication;
import com.adconfig.adsutil.openad.OpenAdHelper;
import com.bankbalanceinquiry.ministatement.profile.data.BankRoomDatabase;
//import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings;
import com.onesignal.OneSignal;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;


public class MyApplication extends AppOpenApplication implements AppOpenApplication.AppLifecycleListener {

    private static MyApplication application;
    public static Context context;
//    private AppOpenManager appOpenManager;

    public BankRoomDatabase bankDatabase;
    public static boolean IS_SDK_INITIALIZED = false;

    @Override
    public void onCreate() {
        super.onCreate();
        application = this;
        context = getApplicationContext();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            String process = getProcessName();
            if (getPackageName() != process) WebView.setDataDirectorySuffix(process);
        }
//        MobileAds.initialize(getApplicationContext());

        AdsParameters adsParameters= new AdsParameters(getApplicationContext());

        int openCounter = adsParameters.getOpenCounter();
        openCounter++;
        adsParameters.setOpenCounter(openCounter);

//        String interstitialAdId = getString(R.string.G_INTERSTITIAL_ID);
        String appOpenId = getString(R.string.G_APPOPEN_ID);
//        String bannerId = getString(R.string.G_BANNER_ID);
//        String nativeId = getString(R.string.G_NATIVE_ID);

        if (openCounter%2==0) {
//            interstitialAdId = getString(R.string.G_INTERSTITIAL_ID_OLD);
            appOpenId = getString(R.string.G_APPOPEN_ID_OLD);
//            bannerId = getString(R.string.G_BANNER_ID_OLD);
//            nativeId = getString(R.string.G_NATIVE_ID_OLD);
        }

//        AdsConfig.Companion
//                .builder()
//                .isEnableAds(true)
//                .isEnableOpenAds(true)
//                .setTestDeviceId("138C82055F352E2F7B6148F0AAA7895F")
//                .setAdmobInterstitialAdId(interstitialAdId)
//                .setAdmobAppOpenId(appOpenId)
//                .setAdmobBannerId(bannerId)
//                .setAdmobNativeId(nativeId)
//                .build(this);

        AdsConfig.Companion.builder()
                .isEnableAds(true)
                .isEnableOpenAds(true)
                .setTestDeviceId("0")
//            .setAdmobInterstitialAdId(AdmobInterstitialAdId)
                .setAdmobAppOpenId(appOpenId)
                .build(this);

        setAppLifecycleListener(this);
        initMobileAds();
//        OpenAdHelper.INSTANCE.loadOpenAd(this, new Function0<Unit>() {
//            @Override
//            public Unit invoke() {
//                return null;
//            }
//        });
        bankDatabase = BankRoomDatabase.Companion.getDatabase(this);

//        new OpenAdModel(this).loadOpenAd(this, new Function0<Unit>() {
//            @Override
//            public Unit invoke() {
//                return null;
//            }
//        });
        fireBaseConfigGet();

        new Thread(() -> {
            OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE);
            OneSignal.initWithContext(MyApplication.this);
            OneSignal.setAppId("5007b7dd-aa51-4729-878a-cc64bc96576f");
        }).start();

        //destroyAllLoadedAd();
//        appOpenManager = new AppOpenManager(MyApplication.this);
//        AppLifecycleObserver appLifecycleObserver = new AppLifecycleObserver(new appOpenLifeCycleChange() {
//            @Override
//            public void onBackground() {
//
//            }
//
//            @Override
//            public void onForeground() {
//                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.Q) {
//                    if (!isShowingAd) {
//                        appOpenManager.appInForeground();
//                    }
//                }
//
//            }
//        });
//        ProcessLifecycleOwner.get().getLifecycle().addObserver(appLifecycleObserver);
    }

    public void fireBaseConfigGet() {
        try {
            final FirebaseRemoteConfig mFirebaseRemoteConfig = FirebaseRemoteConfig.getInstance();
            //Setting Developer Mode enabled to fast retrieve the values
            mFirebaseRemoteConfig.setConfigSettingsAsync(
                    new FirebaseRemoteConfigSettings.Builder()
                            .setMinimumFetchIntervalInSeconds(0)
                            .build());
            mFirebaseRemoteConfig.setDefaultsAsync(R.xml.remote_confing_defaults);
            mFirebaseRemoteConfig.fetch(0)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Log.e("fireBaseConfigGet","isSuccessful");
                                mFirebaseRemoteConfig.activate();
//                                String interAdClickCount = mFirebaseRemoteConfig.getString("interAdClickCount");
//                                Boolean isAdEnable = mFirebaseRemoteConfig.getBoolean("isAdEnable");
//                                Boolean isOpenAdEnable = mFirebaseRemoteConfig.getBoolean("isOpenAdEnable");
//                                String admobInterstitialAdId = mFirebaseRemoteConfig.getString("admobInterstitialAdId");
//                                String admobAppOpenId = mFirebaseRemoteConfig.getString("admobAppOpenId");
//                                String admobBannerId = mFirebaseRemoteConfig.getString("admobBannerId");
//                                String admobNativeId = mFirebaseRemoteConfig.getString("admobNativeId");
//                                String admobRewardId = mFirebaseRemoteConfig.getString("admobRewardId");

//                                Log.e("fireBaseConfigGet", "interAdClickCount:"+interAdClickCount);
//                                Log.e("fireBaseConfigGet", "isAdEnable:"+isAdEnable);
//                                Log.e("fireBaseConfigGet", "isOpenAdEnable:"+isOpenAdEnable);
//                                Log.e("fireBaseConfigGet", "admobInterstitialAdId:"+admobInterstitialAdId);
//                                Log.e("fireBaseConfigGet", "admobAppOpenId:"+admobAppOpenId);
//                                Log.e("fireBaseConfigGet", "admobBannerId:"+admobBannerId);
//                                Log.e("fireBaseConfigGet", "admobNativeId:"+admobNativeId);
//                                Log.e("fireBaseConfigGet", "admobRewardId:"+admobRewardId);

//                                if(isAdEnable!=null) Config.INSTANCE.setAdsEnable(isAdEnable);
//                                if(interAdClickCount !=null && !interAdClickCount.isEmpty()) Config.INSTANCE.setAdmobInterClick((Integer.parseInt(interAdClickCount)));
//                                if(isOpenAdEnable!=null) Config.INSTANCE.setOpenAdEnable(isOpenAdEnable);

//                                if(admobInterstitialAdId!=null && !admobInterstitialAdId.isEmpty()) Config.INSTANCE.setAdmobInterstitialAdId(admobInterstitialAdId);
//                                if(admobAppOpenId!=null && !admobAppOpenId.isEmpty()) Config.INSTANCE.setAdmobAppOpenId(admobAppOpenId);
//                                if(admobBannerId!=null && !admobBannerId.isEmpty()) Config.INSTANCE.setAdmobBannerId(admobBannerId);
//                                if(admobNativeId!=null && !admobNativeId.isEmpty()) Config.INSTANCE.setAdmobNativeId(admobNativeId);

//                                if(admobRewardId!=null) Config.INSTANCE.setAdmobRewardId(admobRewardId);
                            } else {
                                Log.e("fireBaseConfigGet","taskFailed");
                            }

                        }
                    });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Context getAppContext() {
        if (application == null) {
            application = new MyApplication();
        }
        return application;
    }

    @Override
    public boolean onResumeApp(@NonNull Activity fCurrentActivity) {

        if(fCurrentActivity instanceof SplashActivity){
            return false;
        } else if(!new AdsManager(fCurrentActivity).isNeedToShowAds()) {
            return false;
        }
        return true;
    }

    @Override
    public void onAppOpenCreatedEvent(@NonNull Activity fCurrentActivity) {

        if (onResumeApp(fCurrentActivity))
            if (!fCurrentActivity.isDestroyed() && !fCurrentActivity.isFinishing()) {
//            if (!OpenAdHelper.isAdAvailable()) {
                Intent intent = new Intent(fCurrentActivity, WelcomeBackActivity.class);
                intent.putExtra("isAdLoading", OpenAdHelper.INSTANCE.isAdLoading());
                fCurrentActivity.startActivity(intent);
//            }
//            else {
//                logMessages("app_appopen_created", fCurrentActivity.localClassName)
//            }
            }
    }

    @Override
    public void onAppOpenShownEvent(@NonNull Activity fCurrentActivity) {

    }

    @Override
    public void onAppOpenFailedEvent(@NonNull Activity fCurrentActivity) {

    }
}
