package com.bankbalanceinquiry.ministatement.activity;

import static android.content.Intent.ACTION_DIAL;
import static com.bankbalanceinquiry.ministatement.utils.Constant.findBankIcon;
import static com.bankbalanceinquiry.ministatement.utils.Constant.setLocale;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.ColorUtils;
import androidx.fragment.app.Fragment;
import androidx.palette.graphics.Palette;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.adconfig.adsutil.admob.NativeAdHelper;
import com.adconfig.adsutil.admob.NativeLayoutType;
import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.adapter.DetailsTransactionPagerAdapter;
import com.bankbalanceinquiry.ministatement.common.CommonFun;
import com.bankbalanceinquiry.ministatement.common.ReadJsonFile;
import com.bankbalanceinquiry.ministatement.database.DatabaseAccess;
import com.bankbalanceinquiry.ministatement.databasedNew.DBHelperAccountNew;
import com.bankbalanceinquiry.ministatement.financialcalculator.Calculations;
import com.bankbalanceinquiry.ministatement.fragment.AccountHisotryFragment;
import com.bankbalanceinquiry.ministatement.fragment.AccountHisotryTrendFragment;
import com.bankbalanceinquiry.ministatement.inapp.AdsManager;
import com.bankbalanceinquiry.ministatement.model.bankname;
import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;
import com.bankbalanceinquiry.ministatement.utils.TextDrawable;

import com.bankbalanceinquiry.ministatement.utils.NetworkManager;


import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.tabs.TabLayout;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;

import it.sephiroth.android.library.viewrevealanimator.ViewRevealAnimator;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;

public class AccountHisotryActivity1 extends AppCompatActivity {

    private Activity activity;
    private Toolbar toolbar;

    LinearLayout li_editName, li_check;
    private RecyclerView rvAccountList;
    private ProgressBar pbLoading;
    private HomeAccoutList allAccountModel;

    private LinearLayout llEmpty;
    private TextView txtTitle;
    private TextView tvEmptyMessage;
    private TextView tvTotalAmout, tvAccountNo;

    private String TitleName = "Transactions";

    private ViewRevealAnimator mViewAnimator;

    private DBHelperAccountNew dbHelperAccountHistory;
    private final ArrayList<HomeAccoutList> allAccountModelHistories = new ArrayList<>();
    private final ArrayList<HomeAccoutList> allData = new ArrayList<>();
    int color, colorTransparent;
    RelativeLayout mBarBg2;
    ImageView mEdit, ic_bank_icon;
    TextView mFirstName, mLastName, txt_tap;
    CollapsingToolbarLayout collapsingToolbar;

    ViewPager viewPager;
    TabLayout tablayout;
    private DetailsTransactionPagerAdapter adapter;
    private List<bankname> MDetail = new ArrayList<>();

    private final ArrayList<Integer> colors = new ArrayList<>();
//    public static int appBarFlag = 0;

    String titleText = "";
    String availableBalance = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLocale(this);

        setContentView(R.layout.activity_account_hisotry_test_1);

        this.colors.add(ContextCompat.getColor(this, R.color.google_blue));
        this.colors.add(ContextCompat.getColor(this, R.color.google_red));
        this.colors.add(ContextCompat.getColor(this, R.color.google_yellow));
        this.colors.add(ContextCompat.getColor(this, R.color.google_green));
        tablayout = findViewById(R.id.tablayout);
        collapsingToolbar = findViewById(R.id.collapsingToolbar);
        viewPager = findViewById(R.id.viewPager);
        pbLoading = findViewById(R.id.pbLoading);
        mEdit = findViewById(R.id.edit);
        activity = this;
        dbHelperAccountHistory = new DBHelperAccountNew(activity);
        mBarBg2 = findViewById(R.id.bar_bg_2);
        mViewAnimator = findViewById(R.id.animator);
        txt_tap = findViewById(R.id.txt_tap);
        ic_bank_icon = findViewById(R.id.ic_bank_icon);
        mFirstName = findViewById(R.id.firstName);
        mLastName = findViewById(R.id.lastName);
        li_editName = findViewById(R.id.li_editName);
        li_check = findViewById(R.id.li_check);


        mEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editDialog();
            }
        });
        li_editName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editDialog();
            }
        });

        pbLoading.setVisibility(View.VISIBLE);
        Intent getdata = getIntent();
        if (getdata != null) {
            allAccountModel = (HomeAccoutList) getdata.getSerializableExtra("OBJ");
            color = getdata.getIntExtra("color", ContextCompat.getColor(this, R.color.colorPrimary));
            if (color == 0 || color == -1) {
                color = ContextCompat.getColor(this, R.color.colorPrimary);
            }
            DatabaseAccess databaseAccess = DatabaseAccess.getInstance(AccountHisotryActivity1.this);
            databaseAccess.open();
            MDetail = databaseAccess.getBalance_details(allAccountModel.full_name);
            databaseAccess.close();

            if (allAccountModel != null) {
                String name = allAccountModel.full_name.replace(" Bank", "");
                TitleName = name;

                String f = getValue(allAccountModel.FinalAccountNo + "_f");
                String l = getValue(allAccountModel.FinalAccountNo + "_l");
                mFirstName.setText(allAccountModel.full_name);
                if (!TextUtils.isEmpty(f)) {
                    mFirstName.setText(f);
                }
                if (!TextUtils.isEmpty(l)) {
                    mLastName.setText(l);
                }
                if (!TextUtils.isEmpty(l) || !TextUtils.isEmpty(f)) {
                    txt_tap.setVisibility(View.GONE);
                    mLastName.setText(l + " -" + allAccountModel.full_name);
                }
            }
            //try {
                /*if (!TextUtils.isEmpty(allAccountModel.full_name) && (MDetail != null) && (MDetail.size() > 0)) {

                    int id = getResources().getIdentifier("ic_" + MDetail.get(0).getB_short().toLowerCase(), "drawable", getPackageName());
                    //  int id = getResources().getIdentifier("ic_hdf", "drawable", getPackageName());
                    if (id != -1) {
                        ic_bank_icon.setImageResource(id);
                        Bitmap bb = BitmapFactory.decodeResource(activity.getResources(), id);
                        Palette palette = Palette.from(bb).generate();
                        color = palette.getDarkVibrantColor(ContextCompat.getColor(this, R.color.colorPrimary));
                    } else {
                        Random rnd = new Random();
                        color = colors.get(rnd.nextInt(3));
                        if (!TextUtils.isEmpty(allAccountModel.full_name) && !allAccountModel.full_name.equalsIgnoreCase("")) {
                            String FirstLetter = allAccountModel.full_name.substring(0, 1);
                            TextDrawable drawable = TextDrawable.builder()
                                    .buildRound(FirstLetter, color);
                            ic_bank_icon.setImageDrawable(drawable);
                        } else {
                            TextDrawable drawable = TextDrawable.builder()
                                    .buildRound("U", color);
                            ic_bank_icon.setImageDrawable(drawable);

                        }
                    }
                } else {
                    Random rnd = new Random();
                    color = colors.get(rnd.nextInt(3));
                    if (!TextUtils.isEmpty(allAccountModel.full_name) && !allAccountModel.full_name.equalsIgnoreCase("")) {
                        String FirstLetter = allAccountModel.full_name.substring(0, 1);
                        TextDrawable drawable = TextDrawable.builder()
                                .buildRound(FirstLetter, color);
                        ic_bank_icon.setImageDrawable(drawable);

                    } else {
                        TextDrawable drawable = TextDrawable.builder()
                                .buildRound("U", color);
                        ic_bank_icon.setImageDrawable(drawable);
                    }
                }


            } catch (Exception e) {
                e.printStackTrace();
            }
*/

            JSONObject jsonObject;
            jsonObject = ReadJsonFile.GetAssetsFileGetDataJsonObject(activity, "sms/bank_list_icons");
            String nameImage = findBankIcon(activity, allAccountModel.full_name, jsonObject);
            int id = getResources().getIdentifier(/*"ic_" +*/ nameImage, "drawable", getPackageName());

            if ((nameImage != null) && !(TextUtils.isEmpty(nameImage)) && (id != -1)) {
                ic_bank_icon.setImageResource(id);
                Bitmap bb = BitmapFactory.decodeResource(activity.getResources(), id);
                Palette palette = Palette.from(bb).generate();
                color = palette.getDarkVibrantColor(ContextCompat.getColor(this, R.color.colorPrimary));
            } else {
                Random rnd = new Random();
                color = colors.get(rnd.nextInt(3));
                if (!TextUtils.isEmpty(allAccountModel.full_name) && !allAccountModel.full_name.equalsIgnoreCase("")) {
                    String FirstLetter = allAccountModel.full_name.substring(0, 1);
                    TextDrawable drawable = TextDrawable.builder()
                            .buildRound(FirstLetter, color);
                    ic_bank_icon.setImageDrawable(drawable);

                } else {
                    TextDrawable drawable = TextDrawable.builder()
                            .buildRound("U", color);
                    ic_bank_icon.setImageDrawable(drawable);
                }
            }


            colorTransparent = color;
//            colorTransparent = ColorUtils.setAlphaComponent(colorTransparent, 20);
            colorTransparent = ColorUtils.setAlphaComponent(colorTransparent, 15);
            collapsingToolbar.setContentScrimColor(color);
            InitToolBar();
            //InitComponent();
            InitComponentNew();
            setUpViewPager();
            AppBarLayout.LayoutParams params = (AppBarLayout.LayoutParams) collapsingToolbar.getLayoutParams();
//            appBarFlag = params.getScrollFlags();
//            params.setScrollFlags(0);


            li_check.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (MDetail != null && MDetail.size() > 0) {

                        Uri number = Uri.parse("tel:" + MDetail.get(0).getB_inquiry().toString());
                        Intent callIntent = new Intent(ACTION_DIAL, number);
                        try {
                            startActivity(callIntent);
                            // }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }

                }
            });

        }

        loadNativeAd();
//        loadBannerAds();

    }


    private void loadNativeAd() {
        FrameLayout adLayout = findViewById(R.id.adLayout);

        if (new AdsManager(AccountHisotryActivity1.this).isNeedToShowAds() && NetworkManager.isInternetConnected(AccountHisotryActivity1.this)) {

            new NativeAdHelper(this, adLayout, NativeLayoutType.NativeBanner,null,"").loadAd();

        }

//        AdmobAdManager.getInstance().LoadNativeAd(activity, activity.getString(R.string.temp_adx_native_id), new AdEventListener() {
//            @Override
//            public void onAdLoaded(Object object) {
//                AdmobAdManager.getInstance()
//                        .populateUnifiedSmallNativeAdView(activity, adLayout, (NativeAd) object, 7);
//            }
//
//            @Override
//            public void onAdClosed() {
//            }
//
//            @Override
//            public void onLoadError(String errorCode) {
//
//            }
//        }, false);

    }
//
//    private void loadBannerAds() {
//        FrameLayout adLayout = findViewById(R.id.adLayout);
//
//        AdmobAdManager.getInstance().LoadAdaptiveBanner(this, adLayout,
//                getResources().getString(R.string.admob_banner_id), null);
//    }


    private void setUpViewPager() {
        viewPager = findViewById(R.id.viewPager);
        List<Fragment> fragmentList = new ArrayList<>();

        Bundle b = new Bundle();
        b.putSerializable("OBJ", allAccountModel);
        b.putSerializable("color", color);
        b.putSerializable("colorTransparent", colorTransparent);
        b.putString("type", "All");
        b.putString("balance", availableBalance);
        b.putString("bankName", titleText);

        AccountHisotryTrendFragment fr1 = new AccountHisotryTrendFragment();
        fr1.setArguments(b);
        Bundle b1 = new Bundle();
        b1.putSerializable("OBJ", allAccountModel);
        b1.putSerializable("color", color);
        b1.putSerializable("colorTransparent", colorTransparent);
        b1.putString("type", "All");
        b1.putString("balance", availableBalance);
        b1.putString("bankName", titleText);
        AccountHisotryFragment fr2 = new AccountHisotryFragment();
        fr2.setArguments(b1);
        Bundle b2 = new Bundle();
        b2.putSerializable("OBJ", allAccountModel);
        b2.putSerializable("color", color);
        b2.putSerializable("colorTransparent", colorTransparent);
        b2.putString("type", "Credited");
        b2.putString("balance", availableBalance);
        b2.putString("bankName", titleText);
        AccountHisotryFragment fr3 = new AccountHisotryFragment();
        fr3.setArguments(b2);
        Bundle b3 = new Bundle();
        b3.putSerializable("OBJ", allAccountModel);
        b3.putSerializable("color", color);
        b3.putSerializable("colorTransparent", colorTransparent);
        b3.putString("type", "Debited");
        b3.putString("balance", availableBalance);
        b3.putString("bankName", titleText);
        AccountHisotryFragment fr4 = new AccountHisotryFragment();
        fr4.setArguments(b3);
        fragmentList.add(fr1);
        fragmentList.add(fr2);
        fragmentList.add(fr3);
        fragmentList.add(fr4);
        List<String> titlesList = new ArrayList<>();
        titlesList.add("Trend");
        titlesList.add("All");
        titlesList.add("Credited");
        titlesList.add("Debited");
        adapter = new DetailsTransactionPagerAdapter(getSupportFragmentManager(), this, fragmentList, titlesList);
        viewPager.setAdapter(adapter);
        // lastSelected = 0;
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                //changeSelectOption(position);
            }

            @Override
            public void onPageSelected(int position) {
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        tablayout.setupWithViewPager(viewPager);
        tablayout.addOnTabSelectedListener(new TabLayout.ViewPagerOnTabSelectedListener(viewPager));
        tablayout.setBackgroundColor(color);
        viewPager.setOffscreenPageLimit(4);
        viewPager.setCurrentItem(1);

    }


    private void editDialog() {
        final Dialog dialog = new Dialog(this, R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCanceledOnTouchOutside(true);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialog_edit);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));


        final EditText mFname = dialog.findViewById(R.id.f_name);
        final EditText mLname = dialog.findViewById(R.id.l_name);

        String f = getValue(allAccountModel.FinalAccountNo + "_f");
        String l = getValue(allAccountModel.FinalAccountNo + "_l");

        if (!TextUtils.isEmpty(f)) {
            mFname.setText(f);
        }
        if (!TextUtils.isEmpty(l)) {
            mLname.setText(l);
        }

        Button ok = dialog.findViewById(R.id.btnAddTextSDialog);
        Button cancel = dialog.findViewById(R.id.btnCancelDialog);

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String f = mFname.getText().toString().trim();
                String l = mLname.getText().toString().trim();
                if (TextUtils.isEmpty(f)) {
                    return;
                }
                if (TextUtils.isEmpty(l)) {
                    return;
                }
                mFirstName.setText(f);
                mLastName.setText(l);
                if (!TextUtils.isEmpty(l) || !TextUtils.isEmpty(f)) {
                    txt_tap.setVisibility(View.GONE);
                    mLastName.setText(l + " -" + allAccountModel.full_name);
                }
                setValue(allAccountModel.FinalAccountNo + "_f", f);
                setValue(allAccountModel.FinalAccountNo + "_l", l);
                dialog.dismiss();
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }


    public String getValue(String key) {
        SharedPreferences sp = getSharedPreferences("bank_details", MODE_PRIVATE);
        return sp.getString(key, "");
    }

    public void setValue(String key, String value) {
        SharedPreferences sp = getSharedPreferences("bank_details", MODE_PRIVATE);
        sp.edit().putString(key, value).apply();
    }


    private void InitToolBar() {
        toolbar = findViewById(R.id.toolbar);
        txtTitle = findViewById(R.id.txtTitle);
        //toolbar.setTitle("Transactions");
        if (allAccountModel != null) {
            toolbar.setTitle(TitleName + " - X" + allAccountModel.FinalAccountNo);
            titleText = TitleName + " - X" + allAccountModel.FinalAccountNo;
            txtTitle.setText(TitleName + " - X" + allAccountModel.FinalAccountNo);
        } else {
            toolbar.setTitle(TitleName);
            txtTitle.setText(TitleName);
            titleText = TitleName;

        }
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
//        mBarBg.setBackgroundColor(color);
        mBarBg2.setBackgroundColor(color);
        toolbar.setBackgroundColor(color);
        int mixColor = mixTwoColors(color, Color.WHITE, 0.5f);
        mViewAnimator.setBackgroundColor(mixColor);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(color);
        }
    }

    private int mixTwoColors(int color1, int color2, float amount) {
        final byte ALPHA_CHANNEL = 24;
        final byte RED_CHANNEL = 16;
        final byte GREEN_CHANNEL = 8;
        final byte BLUE_CHANNEL = 0;

        final float inverseAmount = 1.0f - amount;

        int a = ((int) (((float) (color1 >> ALPHA_CHANNEL & 0xff) * amount) +
                ((float) (color2 >> ALPHA_CHANNEL & 0xff) * inverseAmount))) & 0xff;
        int r = ((int) (((float) (color1 >> RED_CHANNEL & 0xff) * amount) +
                ((float) (color2 >> RED_CHANNEL & 0xff) * inverseAmount))) & 0xff;
        int g = ((int) (((float) (color1 >> GREEN_CHANNEL & 0xff) * amount) +
                ((float) (color2 >> GREEN_CHANNEL & 0xff) * inverseAmount))) & 0xff;
        int b = ((int) (((float) (color1 & 0xff) * amount) +
                ((float) (color2 & 0xff) * inverseAmount))) & 0xff;

        return a << ALPHA_CHANNEL | r << RED_CHANNEL | g << GREEN_CHANNEL | b << BLUE_CHANNEL;
    }

    @Override
    protected void onDestroy() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(ContextCompat.getColor(this, R.color.colorPrimary));
        }
        super.onDestroy();
    }

    /* private void InitComponent() {
        rvAccountList = findViewById(R.id.rvAccountList);
        pbLoading = findViewById(R.id.pbLoading);

        tvTotalAmout = findViewById(R.id.tvTotalAmout);
        llDisplayData = findViewById(R.id.llDisplayData);

        rllayoutContent = findViewById(R.id.rllayoutContent);

        CommonFun.RecyclerViewLinearLayout(activity, rvAccountList);

        llEmpty = findViewById(R.id.llEmpty);
        tvEmptyMessage = findViewById(R.id.tvEmptyMessage);
        ivEmptyImage = findViewById(R.id.ivEmptyImage);
        tvEmptyMessage.setText("Transactions history empty");

        mViewAnimator = findViewById(R.id.animator);
        if (allAccountModel != null) {
            Log.e("ClickAccountNoFinal", allAccountModel.getAccountNo());
            try {
                tvTotalAmout.setText("\u20B9 " + allAccountModel.getAvilabeClearBalance());
            } catch (Exception e) {
                e.printStackTrace();
            }

            pbLoading.setVisibility(View.VISIBLE);
            avilabeBalanceModels = new ArrayList<>();
            avilabeBalanceModels.addAll(AllBankAvilabeBalancMsg.AddAvilableMsg());
            AllBankingTransferFrom.addAll(AllBankAvilabeBalancMsg.GetTransperFrom());
            //mMyTask = new GetAllSmsOnTransaction().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

            mViewAnimator.setHideBeforeReveal(true);
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    //   mViewAnimator.setDisplayedChild(mViewAnimator.getDisplayedChild(), true, new Point(250, 250));
                    mViewAnimator.showNext();
                }
            }, 700);
        }


        CheckDataNotifyOrNot();
        CallDb();
        //  CallMultiviewTypeAdapter();
    }
    */

    private void InitComponentNew() {
        rvAccountList = findViewById(R.id.rvAccountList);
        tvAccountNo = findViewById(R.id.tvAccountNo);

        tvTotalAmout = findViewById(R.id.tvTotalAmout);

        CommonFun.RecyclerViewLinearLayout(activity, rvAccountList);

        llEmpty = findViewById(R.id.llEmpty);
        tvEmptyMessage = findViewById(R.id.tvEmptyMessage);
//        ivEmptyImage = findViewById(R.id.ivEmptyImage);
        tvEmptyMessage.setText(getString(R.string.empty_transaction_history));

        if (allAccountModel != null) {
            if (!TextUtils.isEmpty(allAccountModel.FinalAccountBalance)) {
                try {
                    tvTotalAmout.setText("\u20B9 " + allAccountModel.FinalAccountBalance);
                    availableBalance = "\u20B9 " + allAccountModel.FinalAccountBalance;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                tvTotalAmout.setText("");
            }
//            if (!TextUtils.isEmpty(allAccountModel.FinalAccountNo)) {
//                tvAccountNo.setText("Account No - " + "XX" + allAccountModel.FinalAccountNo);
//            } else {
//                tvAccountNo.setText("");
//            }
            tvAccountNo.setVisibility(View.GONE);

            mViewAnimator.setHideBeforeReveal(true);
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    //   mViewAnimator.setDisplayedChild(mViewAnimator.getDisplayedChild(), true, new Point(250, 250));
                    if (!isFinishing()) {
                        mViewAnimator.showNext();
                    }
                }
            }, 700);
        }/*
        accountHistoryAdapter = new AccountHistoryAdapter1(activity, allAccountModelHistories, color, colorTransparent, type);
        rvAccountList.setAdapter(accountHistoryAdapter);*/


        CheckDataNotifyOrNot();
        CallDb();

    }

    private void CheckDataNotifyOrNot() {
        if (CommonFun.isIncommingSmsNotify.equalsIgnoreCase("")) {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    CheckDataNotifyOrNot();
                    Log.e("NotificationYes==>", "not Incomming");
                }
            }, 2000);
        } else {
            CommonFun.isIncommingSmsNotify = "";
            CallDb();
        }
    }

    private void CallDb() {

        new Thread(new Runnable() {
            @Override
            public void run() {
                allAccountModelHistories.clear();
                allData.clear();
                allData.addAll(dbHelperAccountHistory.GetTransactions(allAccountModel.FinalAccountNo, allAccountModel.full_name));
//                allAccountModelHistories.addAll(dbHelperAccountHistory.GetTransactions(allAccountModel.FinalAccountNo, allAccountModel.full_name));
                ArrayList<HomeAccoutList> tmpdata = new ArrayList<>();
                ArrayList<HomeAccoutList> tmpdataFinal = new ArrayList<>();
                SimpleDateFormat formatterHistory = new SimpleDateFormat("dd MMMM yyyy, hh:mm aa", Locale.US);

                if (allData.size() > 0) {
                    for (HomeAccoutList allDatum : allData) {
                        try {
                            Date date3 = formatterHistory.parse(allDatum.dateValHistory);
                            allDatum.dateLongValue = date3.getTime();
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                    }
                    Collections.sort(allData, new Comparator<HomeAccoutList>() {
                        @Override
                        public int compare(HomeAccoutList t1, HomeAccoutList t2) {
                            return Long.valueOf(t2.dateLongValue).compareTo(Long.valueOf(t1.dateLongValue));
                        }
                    });
                    String ModelClickAccountNo = allAccountModel.FinalAccountNo;
                    for (int i = 0; i < allData.size(); i++) {
                        String ForiAccountName = allData.get(i).FinalAccountNo;
                        if (ModelClickAccountNo.equalsIgnoreCase(ForiAccountName)) {
                            tmpdata.add(allData.get(i));
                        }
                    }
                    if (tmpdata.size() > 0) {
                        String header = "";
                        ArrayList<String> CreditData = new ArrayList<>();
                        ArrayList<String> DebitData = new ArrayList<>();
                        boolean istitlefound = false;
                        for (int i = 0; i < tmpdata.size(); i++) {
                            istitlefound = false;
                            HomeAccoutList adddata = tmpdata.get(i);
                            if (!(header.equals(adddata.DateTransactionHistory))) {

                                String CheckCreditDebit = isDebitedOrCredited(adddata);
                                CreditData = new ArrayList<>();
                                DebitData = new ArrayList<>();

                                if (CheckCreditDebit.equalsIgnoreCase("1")) {
                                    CreditData.add(tmpdata.get(i).amount);
                                } else {
                                    DebitData.add(tmpdata.get(i).amount);
                                }

                                istitlefound = true;
                                HomeAccoutList sectionCell = new HomeAccoutList();
                                sectionCell.DateTransactionHistory = adddata.DateTransactionHistory;
                                sectionCell.dateLongValue = adddata.dateLongValue;
                                sectionCell.isSectionHeader = true;
                                sectionCell.GetTitleType = 0;
                                //  sectionCell.amount = tmpdata.get(i).amount;
                                sectionCell.CreditedData = CreditData;
                                sectionCell.DebitedData = DebitData;
                                tmpdataFinal.add(sectionCell);
                                header = adddata.DateTransactionHistory;
                            }

                            if (!istitlefound) {
                                String CheckCreditDebit = isDebitedOrCredited(tmpdata.get(i));
                                if (CheckCreditDebit.equalsIgnoreCase("1")) {
                                    CreditData.add(tmpdata.get(i).amount);
                                } else {
                                    DebitData.add(tmpdata.get(i).amount);
                                }
                            }

                            adddata.GetTitleType = 1;
                            tmpdataFinal.add(adddata);
                        }
                    }

                    allData.clear();
                    allData.addAll(tmpdataFinal);
                    if (allData.size() > 50) {
                        for (int i = 0; i < 50; i++) {
                            allAccountModelHistories.add(allData.get(i));
                        }
                    } else {
                        allAccountModelHistories.addAll(allData);
                    }

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            pbLoading.setVisibility(View.GONE);
                            if (allAccountModelHistories.size() > 0) {
                                // rvAccountList.setVisibility(View.VISIBLE);
                                rvAccountList.setVisibility(View.GONE);

                                llEmpty.setVisibility(View.GONE);
                                // accountHistoryAdapter.notifyDataSetChanged();
                            } else {
                                rvAccountList.setVisibility(View.GONE);
                                llEmpty.setVisibility(View.VISIBLE);
                            }
                        }
                    });

                } else {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            pbLoading.setVisibility(View.GONE);
                            rvAccountList.setVisibility(View.GONE);
                            llEmpty.setVisibility(View.VISIBLE);
                        }
                    });
                }
            }
        }).start();


    }

    private String getFormatedAmount(String amount) {
        return NumberFormat.getNumberInstance(Locale.getDefault()).format(amount);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }


    private String isDebitedOrCredited(HomeAccoutList homeAccount) {
        String isDebitedOrCredited = "0";
        if (homeAccount.isAtmWithDraw) {
            isDebitedOrCredited = "0";
        } else if (homeAccount.isDebited) {
            isDebitedOrCredited = "0";
        } else {
            isDebitedOrCredited = "1";
        }
        return isDebitedOrCredited;
    }
}

