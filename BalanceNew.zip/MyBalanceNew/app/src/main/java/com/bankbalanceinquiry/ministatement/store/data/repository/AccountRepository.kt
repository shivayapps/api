package com.bankbalanceinquiry.ministatement.store.data.repository

import androidx.lifecycle.LiveData
import com.bankbalanceinquiry.ministatement.store.data.room.AccountDao
import com.bankbalanceinquiry.ministatement.store.data.model.Account


class AccountRepository(private val accountDao: AccountDao) {
    val readAllAccount: LiveData<List<Account>> = accountDao.readAllAccount()

    suspend fun addAccount(account: Account){
        accountDao.addAccount(account)
    }

    suspend fun editAccount(account: Account){
        accountDao.editAccount(account)
    }

    suspend fun deleteAccount(account: Account){
        accountDao.deleteAccount(account)
    }
}