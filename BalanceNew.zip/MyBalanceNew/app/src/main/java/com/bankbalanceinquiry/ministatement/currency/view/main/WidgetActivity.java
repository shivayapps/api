package com.bankbalanceinquiry.ministatement.currency.view.main;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.*;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.text.HtmlCompat;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.bankbalanceinquiry.ministatement.currency.data.ExchangeRates;
import com.bankbalanceinquiry.ministatement.currency.data.Rate;
import com.bankbalanceinquiry.ministatement.currency.repository.Database;
import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.currency.viewmodel.main.CurrentInputViewModel;
import com.bankbalanceinquiry.ministatement.currency.viewmodel.main.ExchangeRatesViewModel;
import com.bankbalanceinquiry.ministatement.currency.widget.searchablespinner.SearchableSpinner;

import java.text.SimpleDateFormat;
import java.util.Locale;


public class WidgetActivity extends AppCompatActivity {

    private ExchangeRatesViewModel ratesModel;
    private CurrentInputViewModel inputModel;
    private TextView tvCalculations;
    private TextView tvFrom;
    private TextView tvTo;
    private TextView tvCurrencyFrom;
    private TextView tvCurrencyTo;
    private SearchableSpinner spinnerFrom;
    private SearchableSpinner spinnerTo;
    private TextView tvDate;
    private TextView tvFee;
    private RelativeLayout ivMore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_widget);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().setStatusBarColor(getColor(R.color.app_color));
        }

        // model
        this.ratesModel = new ViewModelProvider(this).get(ExchangeRatesViewModel.class);
        this.inputModel = new ViewModelProvider(this).get(CurrentInputViewModel.class);

        // views
        this.tvCalculations = findViewById(R.id.textCalculations);
        this.tvFrom = findViewById(R.id.textFrom);
        this.tvTo = findViewById(R.id.textTo);
        this.tvCurrencyFrom = findViewById(R.id.currencyFrom);
        this.tvCurrencyTo = findViewById(R.id.currencyTo);
        this.spinnerFrom = findViewById(R.id.spinnerFrom);
        this.spinnerTo = findViewById(R.id.spinnerTo);
        this.tvDate = findViewById(R.id.textRefreshed);
        this.tvFee = findViewById(R.id.textFee);
        this.ivMore = findViewById(R.id.rlMore);

        setListeners();

        observe();

        inputModel.clear();
        inputModel.addNumber("1");
    }


    private void setListeners() {
        ivMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(WidgetActivity.this, CurrencyActivity.class));
            }
        });
        spinnerFrom.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                inputModel.setCurrencyFrom(
                        (Rate) (adapterView.getAdapter()).getItem(position)
                );
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        spinnerTo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                inputModel.setCurrencyTo(
                        (Rate) (adapterView.getAdapter()).getItem(position)
                );
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }


    private void observe() {
        ratesModel.getExchangeRate().observe(this, new Observer<ExchangeRates>() {
            @Override
            public void onChanged(ExchangeRates exchangeRates) {

                String providerString = "frankfurter.app";
//                switch (Database.Companion.getInstance(WidgetActivity.this).getApiProvider()) {
//                    case 1:
//                        providerString = "frankfurter.app";
//                        break;
//                    default:
//                        providerString = "exchangerate.host";
//                        break;
//                }

                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
                String dateString = exchangeRates.getDate();
//                String dateString = null;
//                if (date != null) {
//                    dateString = simpleDateFormat.format(date);
//                }
                //tvDate.text = getString(R.string.rates_date_latest, dateString,providerString)

                if (dateString != null && providerString != null) {
                    tvDate.setText(HtmlCompat.fromHtml(
                            getString(
                                    R.string.rates_date_latest,
                                    dateString,
                                    providerString
                            ),
                            HtmlCompat.FROM_HTML_MODE_LEGACY
                    ));
                }

                if (exchangeRates.getRates() != null) {
                    spinnerFrom.setAdapter(new SpinnerAdapter(WidgetActivity.this, android.R.layout.simple_spinner_item, exchangeRates.getRates()));
                    spinnerTo.setAdapter(new SpinnerAdapter(WidgetActivity.this, android.R.layout.simple_spinner_item, exchangeRates.getRates()));
                }
                int positionLastFrom = 0;
                if (inputModel.getLastRateFrom() != null) {
                    {
                        positionLastFrom = ((SpinnerAdapter) spinnerFrom.getAdapter()).getPosition(inputModel.getLastRateFrom());
                    }
                    spinnerFrom.setSelection(positionLastFrom);
                    int positionLastTo = 0;
                    if (inputModel.getLastRateTo() != null) {
                        positionLastTo = ((SpinnerAdapter) spinnerTo.getAdapter()).getPosition(inputModel.getLastRateTo());
                    }
                    spinnerFrom.setSelection(positionLastFrom);

                }
            }
        });

        inputModel.getCurrentInput().observe(this, new Observer<String>() {
            @Override
            public void onChanged(String s) {
                tvFrom.setText(s);
            }
        });

        inputModel.getCurrentInputConverted().observe(this, new Observer<String>() {
            @Override
            public void onChanged(String s) {
                tvTo.setText(s);
            }
        });
        inputModel.getCalculationInput().observe(this, new Observer<String>() {
            @Override
            public void onChanged(String s) {
                tvCalculations.setText(s);
            }
        });
        inputModel.getCurrencyFrom().observe(this, new Observer<String>() {
            @Override
            public void onChanged(String s) {
                tvCurrencyFrom.setText(s);
            }
        });
        inputModel.getCurrencyTo().observe(this, new Observer<String>() {
                @Override
                public void onChanged(String s) {
                    tvCurrencyTo.setText(s);
                }
        });
    }
}
