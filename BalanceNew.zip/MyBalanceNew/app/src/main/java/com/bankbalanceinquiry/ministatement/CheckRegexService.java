package com.bankbalanceinquiry.ministatement;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CheckRegexService extends Service {


    String[] messagesList = new String[]{
            "ICICI Bank Acct XX232 debited for Rs 5000.00 on 06-Sep-22;",
            "An amount of INR 7,500.00 has been credited to XXXX0467 on 21/09/2022 towards NEFT by Sender LIC OF INDIA KHARAGPUR DIVISIO, IFSC INDB0000006, Sender A/c XXXX9241, INDUSIND BANK, Nariman Point, UTR INDBN21091491479, Total Avail. Bal INR 38657.55- Canara Bank",
            "Debit\\nINR 239.00\\nA/c no. XX1863\\n15-09-22 10:29:19\\nUPI/P2M/225834513706/billdeskt/ICICI Ban\\nBal INR 609.82\\nSMS BLOCKUPI Cust ID to 8691000002, if not you-Axis Bank",
            "Your a/c XXXXXXXXXXXX2729 is debited Rs. 18.00 on 10/2/2022",
            "Dear Customer, transaction of INR 455.00 done on ICICI Bank Account XX346 on 14-Apr-22. Info: MIN*Airtel Pa. The Available Balance is INR 2,85,686.74. Call on 18002662 for dispute or SMS BLOCK 346 to 9215676766.",
            "Please maintain EMI of Rs. 1938.00 for CONSUMER DURABLE LOAN A/c no.  ****3794 on 02-OCT-22. EMI presentation will happen on all days including bank holidays. Loan a/c will get updated in 3 working days. Click  idfcfir.st/WAEng and enter 9903 for Statement  or download our app  https://idfcfir.st/Update. IDFC FIRST BANK.",
            "Dear Customer, EMI due for A/C no XXXXX840296.Please pay immediately to avoid Late payment Charges. Please ignore, if already paid.-SBI",
            "Your a/c no XXXXXXXXXXXXX878 is credited by Rs 170.00 on 11-09-22 by a/c linked to mobile 9XXXXXXXX999 (IMPS Ref no 225416600947)-PNB",
            "Rs.4400 transferred from A/c ...6156 to:TRTR/2082085813. Total Bal:Rs.506CR. Avlbl Amt:Rs.506(23-03-2022 08:46:15) - Bank of Baroda",
            "Account  No. XXXXXX3737 DEBIT with amount Rs. 10000.00 on 11-03-2022. Balance: Rs.29401.00. [ IN371159]",
            "An amount of INR 1,000.00 has been CREDITED to your account XXXX1310 on 05/09/2022.Total Avail.bal INR 1,525.10.- Canara Bank",
            "Dear Customer, INR 1,000.00 credited to your A/c No XX2578 on 05/09/2022 through NEFT with UTR RBI2492230347032 by GOVT OF TAMILNADU E-Payments Principal Secretary, INFO: 7030053-SBI",
            "Dear Customer, Your A/c X1674 is credited with Rs.1000.00 Info: UPI/SBIN/224874275512/NANDHINI  C/U. Final balance is Rs.1367.04-South Indian Bank",
            "Dear SBI User, your A/c X1087-debited by Rs10000.0 on 30Sep",
            "Dear SBI Customer, Rs.1500 withdrawn at SBI ATM EBBJ004617010 from A/cX7847 on 16Aug22 Transaction Number 7328. Available Balance Rs.1839. If not withdrawn by you, forward this SMS to 9223008333 / call 1800111109 or 09449112211 to block your card. Download YONO SBI. Use SBI ATMs.",
            "Dear SBI Customer, Mini Statement taken from A/cX6108 at SBI ATM EBBJ004617010 on 24Jun21. Transaction Number 1749. If not done by you, forward this SMS to 9223008333 / call 1800111109 or 09449112211 to block your card. Download YONO SBI. Please use SBI ATMs for better security.",
            "Dear Customer, Balance Enquiry from A/cX6108 at SBI ATM EBBJ004617010 on 15May22. Transaction Number 7426. If not done by you, forward this SMS to 9223008333/ call 1800111109 or 09449112211 to block your card. FOR BALANCE ENQUIRY,call CONTACT CENTRE 1800112211/18004253800.DOWNLOAD YONO SBI",
            "Rs.15.00 is debited from Kotak Bank a/c XXXX1351 to Q342360653@ybl on 08-09-22. To report fraud/raise dispute, click kotak.com/fraud. New balance: Rs. 8.47",
            "<#> 760828 is One Time Password for registering yourself to Canara e-Passbook app. Please do not share this with others. CWzFoBvJHfg -Canara Bank"
    };
    String[] regexList = new String[]{
            "/(?i)\\w+.Bank A\\w+.X+\\d{3}.*debited.*?(INR|Rs).\\d+(\\.\\d{1,2}).*(\\d{0,2}-\\w{0,3}-\\d{2})*/g",
            "/(?i)\\w+.*?((INR|Rs)[\\.,\\s]*([\\d,]*\\.?\\d{0,2})).*?credited.*?.X+\\d{0,4}.*?(\\d{0,2}[\\/|-]\\d{0,2}[\\/|-]\\d{0,4}).*?((?:neft|inb|upi|imps|mob|rtgs)).*?Sender.*?[\\.,\\s]IFSC([\\s][A-Z]{4}0\\d{6})[\\.,\\s].(sender.a\\/c.X+\\d{0,4}).*?[\\.,\\s].*?UTR.([A-Z]{5}\\d{11})[\\.,\\s]*(total.*?Avail.*?Bal).*?((INR|Rs)[\\.,\\s]*([\\d,]*\\.?\\d{0,2})).*/gm",
            "/(?i)(debit|credit).*?((INR|Rs|Rs.)[\\.,\\s]*([\\d,]*\\.?\\d{0,2})).*?a\\/c.*?X+\\d{0,4}.*?(\\d{0,2}[\\/|-]\\d{0,2}[\\/|-]\\d{0,4}).*?(\\d{2}[:]\\d{2}[:]\\d{2}).*?(UPI\\/\\w{3}\\/\\d{12}\\/\\w*).*?(\\w{2}\\/\\w*).*?((INR|Rs|Rs.)[\\.,\\s]*([\\d,]*\\.?\\d{0,2})).*?(SMS.BLOCKUPI.cust.id.to).*?\\d{10}.*/gm",
            "/(?i)\\w+.[a\\/c|account].*?X+\\d{0,4}.*?(?:INR|Rs.|Rs).*?([\\d,]\\.\\d{0,2}).*?(\\d{0,2}[\\/|-]\\d{0,2}[\\/|-]\\d{0,4})/g",
            "/(?i)d\\w{3}.c\\w{7}[\\.,\\s].transaction.*?((INR|Rs|Rs.).*?([\\d,]*\\.\\d{0,2})).*?on.*?(a\\/c|account|acc).X+\\d{0,4}.*?(\\d{2}[\\/|-]\\w{0,3}[\\/|-]\\d{0,4}).*?info:.([A-Z]{3}\\*[a-z]+).*?the.available.balance.is.((INR|Rs|Rs.).*?([\\d,]*\\.\\d{0,2})).*?call.on.*?\\d+.*?or.sms.block.\\d{0,3}.to.\\d{10}.*/g",
            "/(?i)\\w+.*?emi.of.*?([Rs|Rs.|INR][\\.,\\s]*([\\d,]*\\.\\d{0,2})).*?(a\\/c|account|acc).no[\\.,\\s]*(x+|\\*+\\d{0,4}).*?(\\d{0,2}[\\/|-]\\w{0,3}[\\/|-]\\d{0,4}).*?emi.*?happen.*?bank.*?loan\\s(a\\/c|account|acc).*?updated.*?click.*?enter\\s(\\d{0,4}).*?statement.*?download.*?app.*/gm",
            "/(?i)d\\w{3}.c\\w{7}[\\.,\\s].emi.due.*?(a\\/c|account|acc)\\sno\\s(x+\\d{0,6}).*?(?:pay).*?(?:ignore).*/g",
            "/(?i)\\w+.*(a\\/c|account|acc)\\sno\\s(x+\\d{0,6}).*?(credited|debited).*?([Rs|Rs.|INR][\\.,\\s]*([\\d,]*\\.\\d{0,2})).*?(\\d{0,2}[\\/|-]\\d{0,2}[\\/|-]\\d{0,4}).*?(a\\/c|account|acc).*?linked.*?mobile.*?(X+\\d+).*?((?:neft|inb|upi|imps|mob|rtgs)).*?(\\d+).*/g",
            "/(?i)([Rs|Rs.|INR]*([\\d,].*?\\d{0,2})).*?(transferred|withdrawn).*?(a\\/c|account|acc)\\s((x|\\.)+\\d{0,6}).*?total.*?(bal|balance).*?([Rs|Rs.|INR]*([\\d,].*?\\d{0,2})).*?(avail|avlbl|available).*?([Rs|Rs.|INR]*([\\d,].*?\\d{0,2})).*?.*?(\\d{0,2}[\\/|-]\\d{0,2}[\\/|-]\\d{0,4}).*?(\\d{2}[:]\\d{2}[:]\\d{2}).*/gm",
            "/(?i)(account|acc).*?(\\.+|X+)\\d+.*?(debit|credit).*?((?:INR|Rs.|Rs).*?([\\d,]\\.\\d{0,2})).*?(\\d{0,2}[\\/|-]\\d{0,2}[\\/|-]\\d{0,4}).*?(balance|bal).*?[Rs|Rs.|INR]*([\\d,]*\\.\\d{0,2}).*?[a-z]{2}\\d{6}.*/gm",
            "/(?i)\\w+.*?amount.*?([Rs|Rs.|INR]*([\\d,]*\\.\\d{0,2})).*?(credit|debit).*?(account|acc).*?(x+|\\.+)\\d{0,4}.*?(\\d{0,2}[\\/|-]\\d{0,2}[\\/|-]\\d{0,4}).*?(available|avail|total\\savail|total|final).*?((Rs.|Rs|INR).*?([\\d,]\\.\\d{0,2})).*/gm",
            "/(?i)\\w+.*?((INR|Rs)[\\.,\\s]*([\\d,]*\\.?\\d{0,2})).*?(credit|debit).*?.X+\\d{0,4}.*?(\\d{0,2}[\\/|-]\\d{0,2}[\\/|-]\\d{0,4}).*?((?:neft|inb|upi|imps|mob|rtgs)).*?UTR.([A-Z]{0,5}\\d{0,13})[\\.,\\s]by.*?info\\:\\s\\d{0,7}.*/gm",
            "/(?i)dear.customer.*?(account|acc|a\\/c).*?(x+|\\.+)\\d{0,4}.*?(credit|debit).*?((INR|Rs.|Rs)[\\.,\\s]*([\\d,]*\\.?\\d{0,2})).*?info.*?(UPI\\/[[:alnum:]]{0,4}\\/\\d{12}\\/[[:alnum:]]*).*?(available|avail|total\\savail|total|final).*?((Rs.|Rs|INR).*?([\\d,]\\.\\d{0,2})).*/gm",
            "/(?i)dear.*?(account|acc|a\\/c).*?((x+|\\.+)\\d{0,4}).*?(debit|credit).*?((INR|Rs.|Rs)[\\.,\\s]*([\\d,]*\\.\\d{0,2})).*?(\\d{2}[[:alnum:]]{0,3})/gm",
            "/(?i)dear.*?customer.*?((INR|Rs)[\\.,\\s]*([\\d,]*\\.?\\d{0,2})).*?(credit|debit|transferred|withdrawn).*?atm.([a-z]{4}\\d{9}).*?(account|acc|a\\/c).*?(x+\\d{0,4}).*?(\\d{2}\\w{0,3}\\d{0,4}).*?transaction.*?(\\d{4}).*?(available|avail|total\\savail|total|final).*?((Rs.|Rs|INR).*?([\\d,]\\.\\d{0,2})).if.not.*?sms.*?(\\d{10}).*?call.*?((\\d{10}.or.\\d{0,11})|(\\d{10})).*?download.*?use.*?atm.*/gm",
            "/(?i)dear.*?customer.*?statement.*?from.*?(account|acc|a\\/c).*?(x+\\d{0,4}).*?atm.([a-z]{4}\\d{9}).*?(\\d{2}\\w{0,3}\\d{0,4}).*?transaction.*?(\\d{4}).*?if.not.*?sms.*?(\\d{10}).*?call.*?((\\d{10}.or.\\d{0,11})|(\\d{10})).*?download.*?use.*?atm.*/gm",
            "/(?i)dear.\\w+.*balance.*?(account|acc|a\\/c).*?(x+|\\.+)\\d{0,4}.*?atm.([a-z]{4}\\d{9}).*?(\\d{2}\\w{0,3}\\d{0,4}).*?transaction.*?(\\d{4}).*?if.not.*?sms.*?(\\d{10}).*?call.*?((\\d{10}.or.\\d{0,11})|(\\d{10})).*?enquiry.*?contact.(center|centre).*?((\\d{10}\\/\\d{0,11})|(\\d{10})).*?download.*/gm",
            "/(?i)([Rs|Rs.|INR]*([\\d,].*?\\d{0,2})).*?(transferred|withdrawn|debit|credit).*?kotak.bank.*?(a\\/c|account|acc)\\s((x|\\.)+\\d{0,6}).*?[a-z]\\d{9}\\@[a-z]{3}.*?(\\d{0,2}[\\/|-]\\d{0,2}[\\/|-]\\d{0,4}).*?report.*?click.*?(balance|bal).*?((Rs.|Rs|INR).*([\\d,]*\\.\\d{0,2}))/gm",
            "/(?i)(\\d{0,6}).*?(otp|one.time.password).*?canara.*?app.*?share.*?([[:alnum:]]{11}).*?bank/gm"
    };


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {


        Log.e("REGEXMATCHERRR", messagesList.length + "::" + regexList.length);

        int i = -1;
        int i1 = -1;
        try {
            for (String s : messagesList) {
                i++;
                boolean isMatch = false;
                for (String s1 : regexList) {
                    i1++;
                    Pattern regEx = Pattern.compile(s1);
                    Matcher m = regEx.matcher(s);
                    if (m.find()) {
                        isMatch = false;
                        Log.e("REGEXMATCHERRR", i + "::" + m + "::\n" + i1 + "::" + s1);
                        break;
                    }
                    if (!isMatch) {
                        Log.e("REGEXMATCHERRR", s1 + ":");
                    }
                }
            }
        } catch (Exception e) {
            Log.e("REGEXMATCHERRR", e.getMessage() + "::EXCEPTION::");
        }


        return START_STICKY;
    }

}
