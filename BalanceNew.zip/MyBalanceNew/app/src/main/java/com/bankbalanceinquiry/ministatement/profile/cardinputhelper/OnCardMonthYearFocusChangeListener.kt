package com.bankbalanceinquiry.ministatement.profile.cardinputhelper

import android.annotation.SuppressLint
import android.view.View
import android.widget.EditText
import com.bankbalanceinquiry.ministatement.profile.cardinputhelper.CardMonthYearFormatter.SLASH

open class OnCardMonthYearFocusChangeListener(
    private val needMonthZeroPadding: Boolean = false
) : View.OnFocusChangeListener {

    open fun onErrorDetected(error: CardMonthYearError) {}

    override fun onFocusChange(view: View?, focus: Boolean) {
        if (!focus) {
            if (needMonthZeroPadding) {
                insertMonthZeroIfNeed((view as EditText))
            }

            val error = CardMonthYearValidator.validateOnFocusChanged((view as EditText).text)
            onErrorDetected(error)
        }
    }

    @SuppressLint("SetTextI18n")
    private fun insertMonthZeroIfNeed(editText: EditText) {
        val text = editText.text.toString()
        val monthYear = CardMonthYear.from(text, true, false)
        editText.setText("${monthYear.month}$SLASH${monthYear.year}")
    }
}