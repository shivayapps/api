package com.bankbalanceinquiry.ministatement.store.viewModel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.bankbalanceinquiry.ministatement.store.data.room.AccountDatabase
import com.bankbalanceinquiry.ministatement.store.data.model.Account
import com.bankbalanceinquiry.ministatement.store.data.repository.AccountRepository
import kotlinx.coroutines.launch

class AccountViewModel(application: Application) : AndroidViewModel(application) {

    val readAllData: LiveData<List<Account>>
    private val repository : AccountRepository

    init {
        val accountDao = AccountDatabase.getDatabase(application).accountDao()
        repository = AccountRepository(accountDao)
        readAllData = repository.readAllAccount
    }

    fun addAccount(account: Account){
        viewModelScope.launch{
            repository.addAccount(account)
        }
    }

    fun editAccount(account: Account){
        viewModelScope.launch{
            repository.editAccount(account)
        }
    }

    fun deleteAccount(account: Account){
        viewModelScope.launch {
            repository.deleteAccount(account)
        }
    }
}