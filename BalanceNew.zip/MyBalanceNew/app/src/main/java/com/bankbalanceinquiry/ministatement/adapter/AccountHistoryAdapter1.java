package com.bankbalanceinquiry.ministatement.adapter;

import static com.bankbalanceinquiry.ministatement.utils.Constant.generateHtmlString1;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.print.PDFPrint;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.activity.PdfViewerExampleActivity;
import com.bankbalanceinquiry.ministatement.model.AllAccountModelHistory;
import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;
import com.marcoscg.dialogsheet.DialogSheet;
import com.shuhart.stickyheader.StickyAdapter;
import com.tejpratapsingh.pdfcreator.utils.FileManager;
import com.tejpratapsingh.pdfcreator.utils.PDFUtil;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AccountHistoryAdapter1 extends
        StickyAdapter<RecyclerView.ViewHolder, RecyclerView.ViewHolder> {

    /*
public class AccountHistoryAdapter1 extends
        RecyclerView.Adapter<RecyclerView.ViewHolder> implements KmStickyListener {*/

    private final ArrayList<HomeAccoutList> dataSet;
    private String Rs = "Rs.";

    private String balance = "", bankName = "";

    private final Activity activity;
    private int total_types;
    private final int bgColor;
    private final int colorTransparent;
    String type;
    public ClickHistory ApkDetails;

    @Override
    public int getHeaderPositionForItem(int itemPosition) {
        Integer headerPosition = 0;
        for (Integer i = itemPosition; i > 0; i--) {
            if (isHeader(i)) {
                headerPosition = i;
                return headerPosition;
            }
        }
        return headerPosition;
    }

    @Override
    public void onBindHeaderViewHolder(RecyclerView.ViewHolder holder1, int headerPosition) {
        CallTitleType((TypeTitle) holder1, headerPosition);
    }


    @Override
    public RecyclerView.ViewHolder onCreateHeaderViewHolder(ViewGroup parent) {
        return createViewHolder(parent, 0);
    }

    Boolean isHeader(Integer itemPosition) {
        if (itemPosition < dataSet.size()) {
            if (dataSet.get(itemPosition).GetTitleType == 0) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }


    }

    public interface ClickHistory {
        void ClickValue(AllAccountModelHistory callNumber);
    }

    public void RegisterInterface(ClickHistory photoInterface) {
        this.ApkDetails = photoInterface;
    }

    public static class TypeTitle extends RecyclerView.ViewHolder {
        private final TextView tvTitle;
        View leftView;
        LinearLayout li_1;
        private final TextView tvCreditedAmount, tvCreditedAmountPrefix;
        private final TextView tvDebitedAmount, tvDebitedAmountPrefix;

        public TypeTitle(View itemView) {
            super(itemView);
            leftView = itemView.findViewById(R.id.leftView);
            li_1 = itemView.findViewById(R.id.li_1);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvCreditedAmount = itemView.findViewById(R.id.tvCreditedAmount);
            tvCreditedAmountPrefix = itemView.findViewById(R.id.tvCreditedAmountPrefix);
            tvDebitedAmount = itemView.findViewById(R.id.tvDebitedAmount);
            tvDebitedAmountPrefix = itemView.findViewById(R.id.tvDebitedAmountPrefix);
        }
    }

    public static class TypeData extends RecyclerView.ViewHolder {
        private final ImageView micName;
        private final TextView tvDDate;
        private final TextView tvAmount;
        private final TextView tvSenderName;
        private final TextView tvUnknown;
        private final LinearLayout mMainLayout;
        View view_devider;

        public TypeData(View itemView) {
            super(itemView);
            view_devider = itemView.findViewById(R.id.view_devider);
            micName = itemView.findViewById(R.id.micName);
            tvDDate = itemView.findViewById(R.id.tvDDate);
            tvAmount = itemView.findViewById(R.id.tvAmount);
            tvSenderName = itemView.findViewById(R.id.tvSenderName);
            tvUnknown = itemView.findViewById(R.id.tvUnknown);
            mMainLayout = itemView.findViewById(R.id.mainLayout);
        }
    }

    public AccountHistoryAdapter1(Activity context, ArrayList<HomeAccoutList> data, int color, int colorTransparent, String type,
                                  String balance, String bankName) {
        this.activity = context;
        this.dataSet = data;
        this.bgColor = color;
        this.balance = balance;
        this.bankName = bankName;
        this.colorTransparent = colorTransparent;
        this.type = type;
        Rs = activity.getString(R.string.Rs);

    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        switch (viewType) {
            case 0:
                if (type.equalsIgnoreCase("All")) {
                    view = LayoutInflater.from(parent.getContext()).inflate(R.layout.raw_history_title1, parent, false);
                } else {
                    view = LayoutInflater.from(parent.getContext()).inflate(R.layout.raw_history_title_debited, parent, false);
                }
                return new TypeTitle(view);

            case 1:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.raw_history_data1, parent, false);
                return new TypeData(view);
        }
        return null;
    }

    @Override
    public int getItemViewType(int position) {
        switch (dataSet.get(position).GetTitleType) {
            case 0:
                return 0;
            case 1:
                return 1;
            default:
                return -1;
        }
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder,
                                 final int listPosition) {

        if (dataSet.get(holder.getAdapterPosition()) != null) {
            switch (dataSet.get(holder.getAdapterPosition()).GetTitleType) {
                case 0:
                    CallTitleType(((TypeTitle) holder), holder.getAdapterPosition());
                    break;
                case 1:
                    CallDataType(((TypeData) holder), holder.getAdapterPosition());
                    break;
            }
        }
    }

    private void CallDataType(TypeData holder, final int listPosition) {
        HomeAccoutList object = dataSet.get(holder.getAdapterPosition());
        if (isHeader(holder.getAdapterPosition() + 1)) {
            holder.view_devider.setVisibility(View.INVISIBLE);
        } else {
            holder.view_devider.setVisibility(View.VISIBLE);
        }
        Date date = new Date(System.currentTimeMillis());
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy", Locale.US);
        String year = simpleDateFormat.format(date);
        String dateVal = object.dateValHistory;
        if (!TextUtils.isEmpty(object.finalTransactionDesc)) {
            holder.tvUnknown.setVisibility(View.GONE);
            holder.tvUnknown.setText(object.finalTransactionDesc + " ");
        } else {
            holder.tvUnknown.setVisibility(View.GONE);
        }
        if (object.dateValHistory.contains(year)) {
            dateVal = object.dateValHistory.replace(" " + year, "");
        }
        holder.tvDDate.setText(dateVal + "");
        SimpleDateFormat formatterHistory = new SimpleDateFormat("dd MMMM yyyy, hh:mm aa", Locale.US);
        SimpleDateFormat formatterHistory1 = new SimpleDateFormat("dd MMM", Locale.US);
        Date date3 = null;
        try {
            date3 = formatterHistory.parse(object.dateValHistory);
            object.dateValHistory = formatterHistory1.format(date3);

        } catch (ParseException e) {
            e.printStackTrace();
        }
        dateVal = object.dateValHistory;
        holder.tvDDate.setText(dateVal + "");


        if (object.isDebited) {
            holder.tvAmount.setTextColor(ContextCompat.getColor(activity, R.color.google_red));
            //   holder.mMainLayout.setBackgroundColor(ContextCompat.getColor(activity, R.color.google_red_light));
        } else {
            holder.tvAmount.setTextColor(ContextCompat.getColor(activity, R.color.google_green));
        }
        String Amout = object.amount;
        if (TextUtils.isEmpty(Amout)) {
            Amout = "0";
        }
        if (Amout.contains(",")) {
            Amout = Amout.replace(",", "");
        }
        double d = Double.parseDouble(Amout);
        NumberFormat nf = NumberFormat.getNumberInstance(Locale.US);
        DecimalFormat decim = (DecimalFormat) nf;
        decim.applyPattern("#,##,###.##");
        if (Amout.contains(".")) {
            String afterPoint = Amout.substring(Amout.indexOf(".") + 1);
            if (afterPoint.length() > 2) {
//                DecimalFormat decim = new DecimalFormat("#,##,###.##");
                Amout = decim.format(d);
            }
        }
//        DecimalFormat decim = new DecimalFormat("#,##,###.##");
        Amout = decim.format(d);
        try {
            String finalAmout = Amout;
            holder.tvAmount.setText(Rs + " " + finalAmout);
        } catch (Exception e) {
        }
        if (!TextUtils.isEmpty(object.finalTransactionDesc)) {
            holder.tvSenderName.setText(object.finalTransactionDesc + " ");
        } else {
            if (TextUtils.isEmpty(object.transactionDesc)) {
                if (object.isDebited) {
                    holder.tvSenderName.setText(activity.getResources().getString(R.string.debited));
                } else {
                    holder.tvSenderName.setText(activity.getResources().getString(R.string.credited));
                }
            } else {
                holder.tvSenderName.setText(object.transactionDesc);
            }
        }

       /* final int drawable = getTransactionImage(object.transactionDesc);
        if (drawable != -1) {
            holder.micName.setImageResource(drawable);
        } else {
            String FirstName = object.transactionDesc.replaceAll(" ", "");
            if (!TextUtils.isEmpty(FirstName)) {
                String FirstLetter = FirstName.substring(0, 1);
                TextDrawable drawable1 = TextDrawable.builder()
                        .buildRound(FirstLetter, ContextCompat.getColor(activity, R.color.app_color));
                holder.micName.setImageDrawable(drawable1);
            }
        }*/
        holder.mMainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                new DialogSheet(activity)
                        .setTitle("Account no" + (object.FinalAccountNo.length() < 4 ? " - X" : " - ") + object.FinalAccountNo)
                        .setMessage(object.body)
                        .setColoredNavigationBar(true)
                        .setTitleTextSize(20)
                        .setButtonsTextSize(15)
                        .setBackgroundColor(Color.WHITE)
                        .show();
            }
        });

    }

    private void CallTitleType(TypeTitle holder, int headerPosition) {
        HomeAccoutList object = dataSet.get(headerPosition);
        SimpleDateFormat formatterHistory1 = new SimpleDateFormat("MMM yyyy", Locale.US);
        holder.leftView.setBackgroundColor(bgColor);
        object.DateTransactionHistory = formatterHistory1.format(new Date(object.dateLongValue));
        holder.tvTitle.setText(object.DateTransactionHistory);
        holder.tvTitle.setTextColor(bgColor);
        holder.li_1.setBackgroundColor(colorTransparent);
        String AmoutCredited = CallAccountBalanceTesting(object.CreditedData);
        String AmoutDebited = CallAccountBalanceTesting(object.DebitedData);
        if (type.equalsIgnoreCase("All")) {
            holder.tvCreditedAmount.setText("+ \t" + Rs + " " + AmoutCredited);
            holder.tvDebitedAmount.setText("- \t" + Rs + " " + AmoutDebited);
        } else {
            if (type.equalsIgnoreCase("Debited")) {
                holder.tvCreditedAmount.setText("- \t" + Rs + " " + AmoutDebited);
                holder.tvCreditedAmount.setTextColor(ContextCompat.getColor(activity, R.color.google_red));
            } else if (type.equalsIgnoreCase("Credited")) {
                holder.tvCreditedAmount.setTextColor(ContextCompat.getColor(activity, R.color.google_green));
                holder.tvCreditedAmount.setText("+ \t" + Rs + " " + AmoutCredited);
            }
        }

        holder.li_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showPdfDownloadDialog(headerPosition);
            }
        });

    }

    private void showPdfDownloadDialog(int headerPosition) {
        final Dialog rateDialog = new Dialog(activity, R.style.WideDialog);
        rateDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        rateDialog.setCancelable(true);
        rateDialog.setContentView(R.layout.dialog_pdf_selection);
        rateDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        ImageView img_selected_month, img_last_2_month, img_last_3_month, img_last_6_month;
        LinearLayout li_selected_month, li_last_2_month, li_last_3_month, li_last_6_month;
        TextView txt_process = rateDialog.findViewById(R.id.txt_process);
        li_last_6_month = rateDialog.findViewById(R.id.li_last_6_month);
        li_last_3_month = rateDialog.findViewById(R.id.li_last_3_month);
        li_last_2_month = rateDialog.findViewById(R.id.li_last_2_month);
        li_selected_month = rateDialog.findViewById(R.id.li_selected_month);
        img_selected_month = rateDialog.findViewById(R.id.img_selected_month);
        img_last_2_month = rateDialog.findViewById(R.id.img_last_2_month);
        img_last_3_month = rateDialog.findViewById(R.id.img_last_3_month);
        img_last_6_month = rateDialog.findViewById(R.id.img_last_6_month);
        final int[] selectionType = {0};
        selectMonthData(0, img_selected_month, img_last_2_month, img_last_3_month, img_last_6_month);

        li_selected_month.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectionType[0] = 0;
                selectMonthData(0, img_selected_month, img_last_2_month, img_last_3_month, img_last_6_month);
            }
        });
        li_last_2_month.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectionType[0] = 1;

                selectMonthData(1, img_selected_month, img_last_2_month, img_last_3_month, img_last_6_month);
            }
        });
        li_last_3_month.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectionType[0] = 2;

                selectMonthData(2, img_selected_month, img_last_2_month, img_last_3_month, img_last_6_month);
            }
        });
        li_last_6_month.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectionType[0] = 3;
                selectMonthData(3, img_selected_month, img_last_2_month, img_last_3_month, img_last_6_month);
            }
        });
        txt_process.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rateDialog.dismiss();
                processPdfData(selectionType[0], headerPosition);
            }
        });

        rateDialog.show();
    }

    private void processPdfData(int i, int headerPosition) {
        ArrayList<HomeAccoutList> dataSetFinal = new ArrayList<>();
        int totalMonths = 0;
        switch (i) {
            case 0:
                totalMonths = 1;
                break;
            case 1:
                totalMonths = 2;
                break;
            case 2:
                totalMonths = 3;
                break;
            case 3:
                totalMonths = 6;
                break;
        }
        int completeMonth = 0;
        for (int i1 = headerPosition; i1 < dataSet.size(); i1++) {
            HomeAccoutList homeAccoutList = dataSet.get(i1);
            if (homeAccoutList.GetTitleType == 0) {
                if (completeMonth == 0 || completeMonth < totalMonths) {
                    dataSetFinal.add(homeAccoutList);
                    completeMonth++;
                } else {
                    break;
                }
            } else {
                dataSetFinal.add(homeAccoutList);
            }
        }
        String hexColor = String.format("%#06X", (0xFFFFFF & bgColor));
        Log.e("JHGSAUHgucaaaaaaasa", hexColor + "::");

        hexColor = hexColor.replace("#", "#20");
        String htmlString = generateHtmlString1(dataSetFinal, bankName, balance, bgColor, type, activity);
        FileManager.getInstance().cleanTempFolder(activity);
        // Create Temp File to save Pdf To
        // final File savedPDFFile = FileManager.getInstance().createTempFile(activity, "pdf", false);
        final File savedPDFFile;
        try {
            //savedPDFFile = FileManager.getInstance().getFileUrlFromExternalStoragePrivateFile(activity, "pdf");
            Calendar cc = Calendar.getInstance();
            String fileName = "BankBanalce_" + cc.getTimeInMillis() + ".pdf";
            savedPDFFile = commonDocumentDirPath("BankBalance", fileName);
            PDFUtil.generatePDFFromHTML(activity, savedPDFFile, htmlString
                    , new PDFPrint.OnPDFPrintListener() {
                        @Override
                        public void onSuccess(File file) {
                            // Open Pdf Viewer
                            Uri pdfUri = Uri.fromFile(savedPDFFile);

                            Intent intentPdfViewer = new Intent(activity, PdfViewerExampleActivity.class);
                            intentPdfViewer.putExtra(PdfViewerExampleActivity.PDF_FILE_URI, pdfUri);
                            intentPdfViewer.putExtra("AccountName", bankName);
                            intentPdfViewer.putExtra("color", bgColor);
                            activity.startActivity(intentPdfViewer);
                            Toast.makeText(activity, activity.getResources().getString(R.string.pdfSuccess), Toast.LENGTH_LONG).show();
                        }

                        @Override
                        public void onError(Exception exception) {
                            exception.printStackTrace();
                        }
                    });
        } catch (Exception e) {
            e.printStackTrace();
        }
        // Generate Pdf From Html


    }

    public static File commonDocumentDirPath(String FolderName, String fileName) {
        File dir = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS) + "/" + FolderName);
        } else {
            dir = new File(Environment.getExternalStorageDirectory() + "/" + FolderName);
        }
        // Make sure the path directory exists.
        if (!dir.exists()) {
            // Make it, if it doesn't exit
            boolean success = dir.mkdirs();
            if (!success) {
                dir = null;
            }
        }
        File file = new File(dir + "/" + fileName);
        try {
            file.createNewFile();
        } catch (IOException e) {

            e.printStackTrace();
        }
        return file;
    }

    private void selectMonthData(int i, ImageView img_selected_month, ImageView img_last_2_month, ImageView img_last_3_month, ImageView img_last_6_month) {
        img_selected_month.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.img_check_unselect));
        img_last_2_month.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.img_check_unselect));
        img_last_3_month.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.img_check_unselect));
        img_last_6_month.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.img_check_unselect));
        switch (i) {
            case 0:
                img_selected_month.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.img_select));
                break;
            case 1:
                img_last_2_month.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.img_select));
                break;
            case 2:
                img_last_3_month.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.img_select));
                break;
            case 3:
                img_last_6_month.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.img_select));
                break;
        }
    }

    private void savePdf() {

    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }

    private String CallAccountBalanceTesting(ArrayList<String> tempList) {
        double sum = 0;
        for (int i = 0; i < tempList.size(); i++) {
            String AmoutValue = tempList.get(i);
            if (!TextUtils.isEmpty(AmoutValue)) {
                double value = Double.parseDouble(AmoutValue);
                sum += value;
            }
        }
        String s = String.valueOf(sum);
        NumberFormat nf = NumberFormat.getNumberInstance(Locale.US);
        DecimalFormat decim = (DecimalFormat) nf;
        decim.applyPattern("#,##,###.##");
        if (s.contains(".")) {
            String afterPoint = s.substring(s.indexOf(".") + 1);
            if (afterPoint.length() > 2) {
                return decim.format(sum);
            }
        }
        return decim.format(sum);
//        return String.valueOf(CommonFun.findSum(finalallbalance.toString()));
    }
/*
    private int getTransactionImage(String transactionType) {
        switch (transactionType) {
            case "Your Account Balance":
                return R.drawable.ic_your_account_balance;
            case "UPI Transaction":
                return R.drawable.ic_upi_transaction;
            case "Debit Card Transaction":
                return R.drawable.ic_debit_card_transaction;
            case "Net Banking":
                return R.drawable.ic_net_banking;
            case "Credited to your Account":
                return R.drawable.ic_credited_to_your_account;
            case "Cheque Transaction":
                return R.drawable.ic_cheque_transaction;
            case "ATM withdrawal":
                return R.drawable.ic_atm_withdrawal;
            case "Credit Card Transaction":
                return R.drawable.ic_credit_card_transaction;
            case "Credit Card Bill":
                return R.drawable.ic_credit_card_bill;
            case "Loan EMI":
                return R.drawable.ic_loan_emi;
            case "Mobile Bill":
                return R.drawable.ic_mobile_bill;
            case "Prepaid Debit Card Transaction":
                return R.drawable.ic_prepaid_debit_card_transaction;
            case "Bill":
                return R.drawable.ic_bill;
            case "Internet Bill":
                return R.drawable.ic_internet_bill;
            case "Electricity Bill":
                return R.drawable.ic_electricity_bill;
            case "Insurance Premium":
                return R.drawable.ic_insurance_premium;
            case "Gas Bill":
                return R.drawable.ic_gas_bill;
        }
        return -1;
    }*/
}
