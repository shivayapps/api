package com.bankbalanceinquiry.ministatement.fragment;

import static android.content.Intent.ACTION_DIAL;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import com.adconfig.adsutil.admob.BannerAdHelper;
import com.adconfig.adsutil.admob.NativeAdHelper;
import com.adconfig.adsutil.admob.NativeLayoutType;
import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.inapp.AdsManager;
import com.bankbalanceinquiry.ministatement.utils.AdCache;
import com.bankbalanceinquiry.ministatement.utils.NetworkManager;
import com.google.android.gms.ads.AdView;


import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function3;

public class epfServiceFragment extends Fragment {

    CardView balance_detail_sms, balance_detail_call, balance_details_online;

    Context context;
    private FrameLayout adLayout;
    private FrameLayout adLayoutBottom;
    private CardView adcard;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_epfservice, container, false);

        context = getActivity();
//        refreshAd();
        balance_detail_sms = view.findViewById(R.id.balance_detail_sms);
        balance_detail_call = view.findViewById(R.id.balance_detail_call);
        balance_details_online = view.findViewById(R.id.balance_details_online);


        balance_detail_sms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String phone = "7738299899";
                Uri uri = Uri.parse("smsto:" + phone);
                Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
                intent.putExtra("sms_body", "EPFOHO UAN ENG");
                if (getActivity() != null && intent.resolveActivity(getActivity().getPackageManager()) != null) {
                    startActivity(intent);
                }
            }
        });

        balance_detail_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri number = Uri.parse("tel:" + Uri.encode("01122901406"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
               /* if (getActivity() != null && callIntent.resolveActivity(getActivity().getPackageManager()) != null) {
                startActivity(callIntent);}*/
                try {
                    if (getActivity() != null) {
                        startActivity(callIntent);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });

        balance_details_online.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (getActivity() != null) {
                    String url = "https://passbook.epfindia.gov.in/MemberPassBook/Login";
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    if (i.resolveActivity(getActivity().getPackageManager()) != null) {
                        startActivity(i);
                    }
                }
            }
        });

        adLayoutBottom = view.findViewById(R.id.adLayoutBottom);
        adLayout = view.findViewById(R.id.adLayout);
        adcard = view.findViewById(R.id.adcard);

        if (new AdsManager(getActivity()).isNeedToShowAds() && NetworkManager.isInternetConnected(getActivity())) {
            loadNative();
        }

        return view;
    }


    Boolean isAdLoaded=false;
    AdView mAdView;
    public void loadNative() {

//        new NativeAdHelper(getActivity(), adLayoutBottom, NativeLayoutType.NativeBanner,getString(R.string.G_NATIVE_ID)).loadAd();

        String adId=getString(R.string.g_banner_epffrag);
        BannerAdHelper.INSTANCE.showBanner(getActivity(), adLayoutBottom, adId, AdCache.Companion.getBannerEpffrag(), new Function3<Boolean, AdView, String, Unit>() {
            @Override
            public Unit invoke(Boolean aBoolean, AdView adView, String s) {
                AdCache.Companion.setBannerEpffrag(adView);
                mAdView=adView;
                isAdLoaded=true;
                return null;
            }
        },null);
        /*AdmobAdManager.getInstance().LoadNativeAdSmall(getActivity(), getString(R.string.native_id), new AdEventListener() {
            @Override
            public void onAdLoaded(Object object) {
                // AdmobAdManager.getInstance().populateUnifiedNativeAdView(context ,adLayout  , (NativeAd) object , true , false);
                AdmobAdManager.getInstance().populateUnifiedSmallNativeAdView(context, adLayout, (NativeAd) object);
            }

            @Override
            public void onAdClosed() {
            }

            @Override
            public void onLoadError(String errorCode) {
                adcard.setVisibility(View.GONE);
            }
          *//*  @Override
            public void onAdLoaded(MaxNativeAdView maxNativeAdView, MaxAd maxAd) {
                AdmobAdManager.getInstance(getActivity())
                        .populateUnifiedSmallNativeApplovin(getActivity(), adLayout, maxNativeAdView, maxAd, false);
            }*//*
        }, 4);*/
//        AdmobAdManager.getInstance().LoadNativeAd(getActivity(), getString(R.string.temp_adx_native_id), new AdEventListener() {
//            @Override
//            public void onAdLoaded(Object object) {
//                //    AdmobAdManager.getInstance(mContext).populateUnifiedSmallNativeAdView(mContext ,adLayout  , (NativeAd) object);
//                AdmobAdManager.getInstance().populateUnifiedNativeAdView(context, adLayout, (NativeAd) object, true, true);
//
//            }
//
//            @Override
//            public void onAdClosed() {
//            }
//
//            @Override
//            public void onLoadError(String errorCode) {
//            }
//            /*@Override
//            public void onAdLoaded(MaxNativeAdView maxNativeAdView, MaxAd maxAd) {
//                AdmobAdManager.getInstance(getActivity())
//                        .populateUnifiedSmallNativeApplovin(getActivity(), adLayout, maxNativeAdView, maxAd, true);
//            }*/
//        }, true);
    }

    @Override
    public void onPause() {
        super.onPause();
        if(mAdView!=null) mAdView.pause();
    }

    @Override
    public void onResume() {
        super.onResume();
        if(mAdView!=null) mAdView.resume();
    }

}
