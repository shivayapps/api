package com.bankbalanceinquiry.ministatement.adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.adconfig.adsutil.admob.NativeAdHelper;
import com.adconfig.adsutil.admob.NativeLayoutType;
import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.model.smsInfo;



import java.util.List;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;

public class smsList_Adapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    Activity mContext;
    private static final int HEADER = 0;
    private static final int ITEM = 1;
    List<smsInfo> mSMS;
    private Object nativeAd = null;

    public smsList_Adapter(FragmentActivity activity, List<smsInfo> mSMS) {
        mContext = activity;
        this.mSMS = mSMS;
        //  loadNativeAd();
        /*if (mSMS != null && mSMS.size() > 1) {
            smsInfo info = new smsInfo();
            info.setType(1);
            mSMS.add(1, info);
            notifyItemInserted(1);
        }*/
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v;
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        switch (viewType) {
            case HEADER:
                v = layoutInflater.inflate(R.layout.native_frame_layout_sms, parent, false);
                return new AdViewHolder(v);
            default:
                v = layoutInflater.inflate(R.layout.sms_layout_recycle, parent, false);
                return new ItemViewHolder(v);
        }

    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {

        if (!(holder.getAbsoluteAdapterPosition() < mSMS.size())) {
            return;
        }

        if (holder.getItemViewType() == ITEM) {
            ((ItemViewHolder) holder).list_textsms.setText(mSMS.get(holder.getAbsoluteAdapterPosition()).getS_title());

            ((ItemViewHolder) holder).card_sms.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    final String textMsg = mSMS.get(holder.getAbsoluteAdapterPosition()).getS_message();
                    final String phone = mSMS.get(holder.getAbsoluteAdapterPosition()).getS_mobile();
                    Log.e("sms_msg-->", " " + mSMS.get(holder.getAbsoluteAdapterPosition()).getS_message());
                    Log.e("sms_msg-->", " " + mSMS.get(holder.getAbsoluteAdapterPosition()).getS_mobile());

                    final Dialog smsDailog = new Dialog(mContext, R.style.WideDialog);
                    smsDailog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    smsDailog.setCancelable(true);
                    smsDailog.setContentView(R.layout.custom_sms_dialog);
                    smsDailog.setCanceledOnTouchOutside(true);
                    smsDailog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

                    TextView text_sms = smsDailog.findViewById(R.id.card_sms_edit);
                    Button send_sms = smsDailog.findViewById(R.id.send_sms);

                    text_sms.setText(textMsg);
                    send_sms.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    Uri uri = Uri.parse("smsto:" + phone);
                                    Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
                                    intent.putExtra("sms_body", textMsg);
                                    try {
                                        mContext.startActivity(intent);
                                    } catch (Exception e) {
                                        Toast.makeText(mContext, "No app found to perform this action! Please try again later.", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }, 200);
                        }
                    });

                    smsDailog.show();
                }

            });
        } else if (holder.getItemViewType() == HEADER) {
            if (nativeAd != null) {
                populateNativeAds((AdViewHolder) holder);
            } else {
                loadNativeAd((AdViewHolder) holder);
            }
        }
    }

    private void populateNativeAds(AdViewHolder holder1) {
//        if (nativeAd instanceof NativeAd) {
//            AdmobAdManager.getInstance()
//                    .populateUnifiedSmallNativeAdView(mContext, holder1.adLayout, (NativeAd) nativeAd, 5);
//        } /*else {
//            AdmobAdManager.getInstance()
//                    .populateUnifiedSmallNativeApplovin(activity, holder1.adLayout, (MaxNativeAdView) nativeAd, null, false);
//        }*/
    }


    public void loadNativeAd(AdViewHolder holder1) {
        new NativeAdHelper(mContext, holder1.adLayout, NativeLayoutType.NativeBanner).loadAd();

//        AdmobAdManager.getInstance().LoadNativeAdSmall(mContext, mContext.getString(R.string.temp_adx_native_id), new AdEventListener() {
//            @Override
//            public void onAdLoaded(Object object) {
//                nativeAd = object;
//                populateNativeAds(holder1);
//            }
//
//            @Override
//            public void onAdClosed() {
//            }
//
//            @Override
//            public void onLoadError(String errorCode) {
//                removeAdpos();
//            }
//
//        }, 3);

    }

    public void removeAdpos() {
        for (int i = 0; i < mSMS.size(); i++) {
            if (mSMS.get(i).getType() == 1) {
                mSMS.remove(i);
                notifyItemRemoved(i);
                break;
            }
        }
    }


    public class AdViewHolder extends RecyclerView.ViewHolder {

        private final FrameLayout adLayout;
        LinearLayout li_adss;

        AdViewHolder(View itemView) {
            super(itemView);
            adLayout = itemView.findViewById(R.id.adLayout);
            li_adss = itemView.findViewById(R.id.li_adss);
        }
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {
        TextView list_textsms;
        CardView card_sms;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);

            list_textsms = itemView.findViewById(R.id.list_textsms);
            card_sms = itemView.findViewById(R.id.card_sms);
        }
    }

    @Override
    public int getItemViewType(int position) {
        if (mSMS.get(position).getType() == 0) {
            return ITEM;
        } else {
            return HEADER;
        }
    }

    @Override
    public int getItemCount() {
        return mSMS.size();
    }

    private void refreshAd() {


    }
}
