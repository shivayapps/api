package com.bankbalanceinquiry.ministatement.Admanager;

import static androidx.lifecycle.Lifecycle.Event.ON_START;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.Application;
import android.content.ComponentName;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.lifecycle.ProcessLifecycleOwner;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.utils.Constant;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.appopen.AppOpenAd;

import java.util.Date;
import java.util.List;

public class AppOpenManager implements LifecycleObserver, Application.ActivityLifecycleCallbacks {
    private static final String LOG_TAG = "AppOpenManager";
    private AppOpenAd appOpenAd = null;
    private AppOpenAd.AppOpenAdLoadCallback loadCallback;
    private final Application myApplication;
    private Activity currentActivity;
    public static boolean isShowingAd = false;
    private final long loadTime = 0;
    boolean isBackToFor = false;
    boolean isFor = true;
    public boolean isFirstTime = false;
    public boolean isLoading = false;

    public AppOpenManager(Application myApplication) {
        this.myApplication = myApplication;
        this.myApplication.registerActivityLifecycleCallbacks(this);
        ProcessLifecycleOwner.get().getLifecycle().addObserver(this);
        //fetchAd();
    }

    @OnLifecycleEvent(ON_START)
    public void onStart() {

    }

    public void fetchAd(String appId) {
        Log.e("AppopenStart : ", "Start");
        if (isAdAvailable() || isLoading) {
            return;
        }
        isLoading = true;
        Log.d(LOG_TAG, "onLOadStart");

        loadCallback = new AppOpenAd.AppOpenAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull AppOpenAd appOpenAd) {
                super.onAdLoaded(appOpenAd);
                Log.e("AppopenStart : ", "Loaded!");
                AppOpenManager.this.appOpenAd = appOpenAd;
                isLoading = false;
                showAdIfAvailable();
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
                if (appId.equals(myApplication.getApplicationContext().getString(R.string.G_APPOPEN_ID))) {
                    isLoading = false;
                    fetchAd(myApplication.getApplicationContext().getString(R.string.G_APPOPEN_ID));
                }
                Log.e("LOG_TAG", "::ERRR" + loadAdError.getMessage() + "::" + loadAdError.getCode());
            }
        };
        AdRequest request = getAdRequest();
        if (currentActivity != null) {
            AppOpenAd.load(myApplication, appId, request,
                    AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, loadCallback);
        }
    }

    public void appInForeground() {
        if (!Constant.isShplashScreen) {
            fetchAd(myApplication.getApplicationContext().getString(R.string.G_APPOPEN_ID));
        }
    }

    private AdRequest getAdRequest() {
        return new AdRequest.Builder().build();
    }

    public boolean isAdAvailable() {
        return appOpenAd != null;
    }

    private boolean wasLoadTimeLessThanNHoursAgo(long numHours) {
        long dateDifference = (new Date()).getTime() - this.loadTime;
        long numMilliSecondsPerHour = 3600000;
        return (dateDifference < (numMilliSecondsPerHour * numHours));
    }

    public void showAdIfAvailable() {
        Log.d(LOG_TAG, "ADSSSS:" + isShowingAd + "::::" + isAdAvailable());
        if (!isShowingAd) {
            if (isAdAvailable()) {
                Log.d(LOG_TAG, "Will show ad.");
                FullScreenContentCallback fullScreenContentCallback =
                        new FullScreenContentCallback() {
                            @Override
                            public void onAdDismissedFullScreenContent() {
                                AppOpenManager.this.appOpenAd = null;
                                isShowingAd = false;
                                // fetchAd();
                            }

                            @Override
                            public void onAdFailedToShowFullScreenContent(AdError adError) {
                                Log.d(LOG_TAG, "Error display show ad." + adError.getMessage());
                                isShowingAd = false;
                            }

                            @Override
                            public void onAdShowedFullScreenContent() {

                            }
                        };
                Log.d(LOG_TAG, String.valueOf(currentActivity));
                appOpenAd.setFullScreenContentCallback(fullScreenContentCallback);
                isShowingAd = true;
                appOpenAd.show(currentActivity);
            } else {
                Log.d(LOG_TAG, "Can not show ad.");
                fetchAd(myApplication.getApplicationContext().getString(R.string.G_APPOPEN_ID));
            }
        }
    }

    @Override
    public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle bundle) {
        currentActivity = activity;
    }

    @Override
    public void onActivityStarted(@NonNull Activity activity) {
        currentActivity = activity;
    }


    @Override
    public void onActivityResumed(@NonNull Activity activity) {
        currentActivity = activity;
        Log.e("ONBACKKKKKK", "BACKKKK:6666");
        if (isApplicationBroughtToBackground()) {
            isFor = false;
        } else {
            if (!isFor) {
                isBackToFor = true;
                if (!Constant.isShplashScreen) {
//                    showAdIfAvailable();
                    fetchAd(myApplication.getApplicationContext().getString(R.string.G_APPOPEN_ID));
                }
                Log.d(LOG_TAG, "onStartRESUMEE");
            } else {
                isBackToFor = false;
            }
            isFor = true;
        }
    }

    @Override
    public void onActivityPaused(@NonNull Activity activity) {

        if (isApplicationBroughtToBackground()) {
            isFor = false;
            if (isFirstTime) {
                isFirstTime = false;
            }
//            fetchAd();
            /*Toast.makeText(myApplication.context, "APP IS IN BACK", Toast.LENGTH_SHORT).show();*/
        } else {
            if (!isFor) {
                isBackToFor = true;
                if (!Constant.isShplashScreen) {
//                    showAdIfAvailable();
                    fetchAd(myApplication.getApplicationContext().getString(R.string.G_APPOPEN_ID));
                }
                Log.d(LOG_TAG, "onStart");

                /* Toast.makeText(myApplication.context, "APP IS IN FOREE", Toast.LENGTH_SHORT).show();*/
            } else {
                isBackToFor = false;
            }
            isFor = true;
        }
    }


    @Override
    public void onActivityPostResumed(@NonNull Activity activity) {
        Log.e("ONBACKKKKKK", "BACKKKK:6666");
        if (isApplicationBroughtToBackground()) {
            isFor = false;
        } else {
            if (!isFor) {
                isBackToFor = true;
                if (!Constant.isShplashScreen) {
//                    showAdIfAvailable();
                    fetchAd(myApplication.getApplicationContext().getString(R.string.G_APPOPEN_ID));
                }
                Log.d(LOG_TAG, "onStartRESUMEE");
            } else {
                isBackToFor = false;
            }
            isFor = true;
        }
    }


    @Override
    public void onActivityStopped(@NonNull Activity activity) {
    }

    @Override
    public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle bundle) {
    }

    @Override
    public void onActivityDestroyed(@NonNull Activity activity) {
        currentActivity = null;
    }

    @Override
    public void onActivityPreCreated(@NonNull Activity activity, @Nullable Bundle savedInstanceState) {
    }

    @Override
    public void onActivityPostCreated(@NonNull Activity activity, @Nullable Bundle savedInstanceState) {

    }

    @Override
    public void onActivityPreStarted(@NonNull Activity activity) {

    }

    @Override
    public void onActivityPostStarted(@NonNull Activity activity) {

    }

    @Override
    public void onActivityPreResumed(@NonNull Activity activity) {
        currentActivity = activity;


    }

    @Override
    public void onActivityPrePaused(@NonNull Activity activity) {

    }

    @Override
    public void onActivityPostPaused(@NonNull Activity activity) {

    }

    @Override
    public void onActivityPreStopped(@NonNull Activity activity) {

    }

    @Override
    public void onActivityPostStopped(@NonNull Activity activity) {

    }


    private boolean isApplicationBroughtToBackground() {
        try {
            ActivityManager am = (ActivityManager) myApplication.getSystemService(Context.ACTIVITY_SERVICE);
            List<ActivityManager.RunningTaskInfo> tasks = am.getRunningTasks(1);
            if (!tasks.isEmpty()) {
                ComponentName topActivity = tasks.get(0).topActivity;
                return !topActivity.getPackageName().equals(myApplication.getPackageName());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public void onActivityPreSaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {

    }

    @Override
    public void onActivityPostSaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {

    }

    @Override
    public void onActivityPreDestroyed(@NonNull Activity activity) {

    }

    @Override
    public void onActivityPostDestroyed(@NonNull Activity activity) {

    }
}
