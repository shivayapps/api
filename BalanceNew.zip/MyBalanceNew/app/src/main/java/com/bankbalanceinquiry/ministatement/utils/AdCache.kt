package com.bankbalanceinquiry.ministatement.utils

import android.os.Build
import android.os.Environment
import android.os.Looper
import androidx.annotation.ChecksSdkIntAtLeast
import com.google.android.gms.ads.AdView


class AdCache {
    companion object {
        var bannerHome:AdView?=null
        var bannerCurrency:AdView?=null
        var bannerSmsBanking:AdView?=null
        var bannerEpffrag:AdView?=null
        var bannerHoliday:AdView?=null
        var bannerCashwithdraw:AdView?=null
        var bannerBillnew:AdView?=null
        var bannerUssdfrag:AdView?=null
        var bannerAccthist:AdView?=null
        var bannerSmslist:AdView?=null
        var bannerBanklist:AdView?=null
        var bannerBankacct:AdView?=null
        var bannerAcctlist:AdView?=null
        var bannerState:AdView?=null

    }
}


