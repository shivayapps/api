package com.bankbalanceinquiry.ministatement.fragment;

import static android.content.Context.MODE_PRIVATE;
import static android.content.Intent.ACTION_DIAL;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import com.adconfig.adsutil.admob.BannerAdHelper;
import com.adconfig.adsutil.admob.NativeAdHelper;
import com.adconfig.adsutil.admob.NativeLayoutType;
import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.activity.SubActivity_homePage;
import com.bankbalanceinquiry.ministatement.inapp.AdsManager;
import com.bankbalanceinquiry.ministatement.utils.AdCache;
import com.bankbalanceinquiry.ministatement.utils.NetworkManager;
import com.google.android.gms.ads.AdView;


import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function3;

public class ussdBankingFragment extends Fragment {


    Button dial_ussd, already_setup;
    CardView send_money, receive_money, check_bal, profile, upi_pin, p_request, transaction;
    RelativeLayout second_ussd_list, first_ussd;
    SharedPreferences pref;
    String check_setup;
    public static String money;
    Context mContext;

    private View root;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        root = inflater.inflate(R.layout.fragement_ussd, container, false);

        mContext = getActivity();


        dial_ussd = root.findViewById(R.id.dial_ussd);
        already_setup = root.findViewById(R.id.already_setup);
        second_ussd_list = root.findViewById(R.id.second_ussd_list);
        first_ussd = root.findViewById(R.id.ussd_first);
        send_money = root.findViewById(R.id.send_money);
        receive_money = root.findViewById(R.id.receive_money);
        check_bal = root.findViewById(R.id.check_balance);
        profile = root.findViewById(R.id.profile);
        upi_pin = root.findViewById(R.id.upi_pin);
        p_request = root.findViewById(R.id.pending_request);
        transaction = root.findViewById(R.id.transaction);

        pref = getActivity().getSharedPreferences("setup", MODE_PRIVATE);
        final SharedPreferences.Editor editor = pref.edit();

        check_setup = pref.getString("click", "no");

        Log.e("check", check_setup);
        if (check_setup.matches("yes")) {
            first_ussd.setVisibility(View.GONE);
            second_ussd_list.setVisibility(View.VISIBLE);
        } else {
            first_ussd.setVisibility(View.VISIBLE);
            second_ussd_list.setVisibility(View.GONE);
        }


        //clcik event
        dial_ussd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri number = Uri.parse("tel:" + Uri.encode("*99#"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
                try {
                    if (getActivity() != null) {
                        startActivity(callIntent);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        already_setup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editor.putString("click", "yes");
                editor.commit();
                first_ussd.setVisibility(View.GONE);
                second_ussd_list.setVisibility(View.VISIBLE);
            }
        });

        send_money.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                money = "send";
                // navController.navigate(R.id.nav_send_money);

                startNextActivity(8);

            }
        });

        receive_money.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Uri number = Uri.parse("tel:" + Uri.encode("*99*2#"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
                try {
                    if (getActivity() != null) {
                        startActivity(callIntent);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }


            }
        });

        check_bal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri check_bal = Uri.parse("tel:" + Uri.encode("*99*3#"));
                Intent check_in = new Intent(ACTION_DIAL, check_bal);
                try {
                    if (getActivity() != null) {
                        startActivity(check_in);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                money = "profile";
                startNextActivity(8);
//                navController.navigate(R.id.nav_send_money);
            }
        });

        upi_pin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                money = "upi";
                startNextActivity(8);

//                navController.navigate(R.id.nav_send_money);
            }
        });

        p_request.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Uri check_bal = Uri.parse("tel:" + Uri.encode("*99*5#"));
                Intent check_in = new Intent(ACTION_DIAL, check_bal);
                try {
                    if (getActivity() != null) {
                        startActivity(check_in);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        transaction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Uri transaction = Uri.parse("tel:" + Uri.encode("*99*6#"));
                Intent tranc_in = new Intent(ACTION_DIAL, transaction);
                try {
                    if (getActivity() != null) {
                        startActivity(tranc_in);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
        loadBanner();
        return root;
    }


    private void startNextActivity(int type) {
        Intent i = new Intent(getActivity(), SubActivity_homePage.class);
        i.putExtra("viewType", type);
        startActivity(i);
    }

    Boolean isAdLoaded=false;
                AdView mAdView;
    public void loadBanner() {
//        FrameLayout mAdView = root.findViewById(R.id.adContainer);

        if (new AdsManager(getActivity()).isNeedToShowAds() && NetworkManager.isInternetConnected(getActivity())) {
            FrameLayout mAdLayout = root.findViewById(R.id.fl_adplaceholder_ussd);
//            new NativeAdHelper(getActivity(), mAdView, NativeLayoutType.NativeBanner,getString(R.string.G_NATIVE_ID)).loadAd();
            String adId=getString(R.string.g_banner_ussdfrag);
            BannerAdHelper.INSTANCE.showBanner(getActivity(), mAdLayout, adId, AdCache.Companion.getBannerUssdfrag(), new Function3<Boolean, AdView, String, Unit>() {
                @Override
                public Unit invoke(Boolean aBoolean, AdView adView, String s) {
                    AdCache.Companion.setBannerUssdfrag(adView);
                    mAdView=adView;
                    isAdLoaded=true;
                    return null;
                }
            },null);
        }
//        AdmobAdManager.getInstance().LoadNativeAd(getActivity(), mContext.getString(R.string.temp_adx_native_id), new AdEventListener() {
//            @Override
//            public void onAdLoaded(Object object) {
//
//                //  AdmobAdManager.getInstance(mContext).populateUnifiedSmallNativeAdView(mContext, mAdView, (NativeAd) object);
//                AdmobAdManager.getInstance().populateUnifiedNativeAdView(mContext, mAdView, (NativeAd) object,
//                        true, true);
//            }
//
//            @Override
//            public void onAdClosed() {
//
//            }
//
//            @Override
//            public void onLoadError(String errorCode) {
////                send_native.setVisibility(View.GONE);
//            }
//
//         /*   @Override
//            public void onAdLoaded(MaxNativeAdView maxNativeAdView, MaxAd maxAd) {
//                AdmobAdManager.getInstance(getActivity())
//                        .populateUnifiedSmallNativeApplovin(getActivity(), mAdView, maxNativeAdView, maxAd, true);
//            }*/
//        }, true);
    }


    @Override
    public void onPause() {
        super.onPause();
        if(mAdView!=null) mAdView.pause();
    }

    @Override
    public void onResume() {
        super.onResume();
        if(mAdView!=null) mAdView.resume();
    }

    @Override
    public void onDestroy() {
//        if(mAdView!=null) mAdView.destroy();
        super.onDestroy();
    }
}
