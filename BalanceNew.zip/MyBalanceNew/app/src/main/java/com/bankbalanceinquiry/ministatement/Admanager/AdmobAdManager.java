package com.bankbalanceinquiry.ministatement.Admanager;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.bankbalanceinquiry.ministatement.R;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;

import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

public class AdmobAdManager {

    private final String TAG = "AdmobAdManager";
    private final String TAG1 = "APPLOVINADSS";
    //private final String TAG1 = "AdmobAdManager";
    private static AdmobAdManager singleton;
    public InterstitialAd interstitialAd;

    public boolean isAdLoad = false;
    public boolean isAdLoadProcessing = false;
    public boolean isAdLoadFailed = false;

    private ProgressDialog progressDialog;
    private NativeAd nativeAd;

    public static AdmobAdManager getInstance() {
        if (singleton == null) {
            singleton = new AdmobAdManager();
        }
        return singleton;
    }

    private void setUpProgress(Context context) {
        progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Ad Showing...");
        progressDialog.setCancelable(true);
        progressDialog.setCanceledOnTouchOutside(false);
    }

    public void showProgress(Activity activity) {
        activity.runOnUiThread(() -> {
            try {
                setUpProgress(activity);
                if (progressDialog != null && !progressDialog.isShowing()) {
                    progressDialog.show();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

    }

    public void dismissProgress(Activity activity) {
        activity.runOnUiThread(() -> {
            try {
                if (progressDialog != null && progressDialog.isShowing()) {
                    progressDialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

//    public void loadInterstitialAd(Activity context, String interstitialAdID) {
//        if (interstitialAd == null && !isAdLoadProcessing) {
//            isAdLoadProcessing = true;
//            AdRequest adRequest = new AdRequest.Builder().build();
//            InterstitialAd.load(context, interstitialAdID, adRequest, new InterstitialAdLoadCallback() {
//                @Override
//                public void onAdLoaded(@NonNull InterstitialAd interstitialAds) {
//                    Log.d(TAG, "dsds onAdLoaded: ");
//                    isAdLoad = true;
//                    isAdLoadFailed = false;
//                    isAdLoadProcessing = false;
//                    interstitialAd = interstitialAds;
//                }
//
//                @Override
//                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
//                    if (interstitialAdID.equals(context.getString(R.string.temp_adx_interstitial_id))) {
//                        isAdLoadProcessing = false;
//                        loadInterstitialAd(context, context.getString(R.string.admob_interstitial_id));
//                    } else if (interstitialAdID.equals(context.getString(R.string.temp_adx_interstitial_splash_id))) {
//                        isAdLoadProcessing = false;
//                        loadInterstitialAd(context, context.getString(R.string.admob_interstitial_splash_id));
//                    } else {
//                        isAdLoad = false;
//                        isAdLoadFailed = true;
//                        isAdLoadProcessing = false;
//                    }
//
//                    Log.d(TAG, "dsds onAdFailedToLoad:INTER:: " + loadAdError.getMessage());
//
//                }
//            });
//        }
//    }

//    public void loadInterstitialAd(Activity context, String interstitialAdID, int number, OnAdClosedListener onAdClosedListener) {
//        if (!AppOpenManager.isShowingAd) {
//            Random random = new Random();
//            int r = random.nextInt(number);
//            if (number == 1 || r == 1) {
//                if (interstitialAd != null) {
//                    if (isAdLoad && !isAdLoadFailed && !isAdLoadProcessing) {
//                        interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
//                            @Override
//                            public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) {
//                                super.onAdFailedToShowFullScreenContent(adError);
//                                if (progressDialog != null && progressDialog.isShowing()) {
//                                    progressDialog.dismiss();
//                                }
//                                interstitialAd = null;
//                                isAdLoad = false;
//                                isAdLoadProcessing = false;
//                                isAdLoadFailed = false;
//                                if (onAdClosedListener != null) {
//                                    onAdClosedListener.onAdClosed();
//                                }
//                            }
//
//                            @Override
//                            public void onAdShowedFullScreenContent() {
//                                super.onAdShowedFullScreenContent();
//                                AppOpenManager.isShowingAd = true;
//                            }
//
//                            @Override
//                            public void onAdDismissedFullScreenContent() {
//                                super.onAdDismissedFullScreenContent();
//                                if (progressDialog != null && progressDialog.isShowing()) {
//                                    progressDialog.dismiss();
//                                }
//                                AppOpenManager.isShowingAd = false;
//                                isAdLoad = false;
//                                isAdLoadProcessing = false;
//                                isAdLoadFailed = false;
//                                interstitialAd = null;
//                                // loadInterstitialAd(context, interstitialAdID);
//
//                                if (onAdClosedListener != null) {
//                                    onAdClosedListener.onAdClosed();
//                                }
//                            }
//                        });
//                        interstitialAd.show(context);
//                    } else {
//                        Log.e(TAG, "Ads still loading!");
//                        if (onAdClosedListener != null) {
//                            onAdClosedListener.onAdClosed();
//                        }
//                    }
//                } else {
//                    if (!TextUtils.isEmpty(interstitialAdID)) {
//                        loadInterstitialAd(context, interstitialAdID);
//                    }
//                    if (onAdClosedListener != null) {
//                        onAdClosedListener.onAdClosed();
//                    }
//                }
//            } else {
//                if (onAdClosedListener != null) {
//                    onAdClosedListener.onAdClosed();
//                }
//            }
//        } else {
//            if (onAdClosedListener != null) {
//                onAdClosedListener.onAdClosed();
//            }
//        }
//    }

    public interface OnAdClosedListener {
        public void onAdClosed();
    }

    public boolean isNetworkAvailable(Context c) {
        boolean isAvailable = false;
        if (c != null) {
            ConnectivityManager manager = (ConnectivityManager)
                    c.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = manager.getActiveNetworkInfo();
            if (networkInfo != null && networkInfo.isConnected()) {
                isAvailable = true;
            }
        }

        return isAvailable;
    }


    public void LoadAdaptiveBanner(Context context, FrameLayout adContainerView, String bannerAdID, final AdEventListener adEventListener) {

        try {

            if (isNetworkAvailable(context)) {
                // Create an ad request. Check your logcat output for the hashed device ID to
                // get test ads on a physical device. e.g.
                // "Use AdRequest.Builder.addTestDevice("ABCDEF012345") to get test ads on this device."
                AdView adView = new AdView(context);
                adView.setAdUnitId(bannerAdID);
                adContainerView.removeAllViews();
                adContainerView.addView(adView);

                final AdSize adSize = getAdSize(context, adContainerView);
                adView.setAdSize(adSize);

                AdRequest adRequest =
                        new AdRequest.Builder().build();
                adView.setAdListener(new AdListener() {
                    @Override
                    public void onAdLoaded() {
                        super.onAdLoaded();
                        if (adEventListener != null) {
                            adEventListener.onAdLoaded(null);
                        }
                    }

                    @Override
                    public void onAdClosed() {
                        super.onAdClosed();

                        if (adEventListener != null) {
                            adEventListener.onAdClosed();
                        }
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        super.onAdFailedToLoad(loadAdError);
                        if (adEventListener != null) {
                            adEventListener.onLoadError(loadAdError.getMessage());
                        }
                        Log.e(TAG, "onAdFailedAdaptiveBanner: " + loadAdError.toString());
                    }
                });

                // Start loading the ad in the background.
                adView.loadAd(adRequest);
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.e(TAG, "LoadAdaptiveBanner: " + e.toString());
        }

    }


    public AdSize getAdSize(Context context, FrameLayout adContainerView) {
        // Determine the screen width (less decorations) to use for the ad width.
        Display display = ((Activity) context).getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float density = outMetrics.density;

        float adWidthPixels = adContainerView.getWidth();

        // If the ad hasn't been laid out, default to the full screen width.
        if (adWidthPixels == 0) {
            adWidthPixels = outMetrics.widthPixels;
        }

        int adWidth = (int) (adWidthPixels / density);

        //  return AdSize.getCurrentOrientationBannerAdSizeWithWidth(context, adWidth);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(context, adWidth);
    }


    public NativeAd nativeAd0;
    public NativeAd nativeAd1;
    boolean isNativeProcessing = false;
    boolean isNativeProcessingAppLovinBig = false;
    boolean isNativeProcessingAppLovinSmall = false;
    AtomicInteger finalA = new AtomicInteger();


    public void LoadNativeAdHomepage(final Activity context, String nativeAdID, final AdEventListener adEventListener) {
      /*  if (isNetworkAvailable(context)) {

            AdLoader.Builder builder = new AdLoader.Builder(context, nativeAdID);
            builder.forNativeAd(unifiedNativeAd -> {
                nativeAd0 = unifiedNativeAd;
                isNativeProcessing = false;
                finalA.set(0);
                if (adEventListenerCurrentBig != null) {
                    adEventListenerCurrentBig.onAdLoaded(unifiedNativeAd);
                }


            }).withAdListener(new AdListener() {
                @Override
                public void onAdClosed() {
                    super.onAdClosed();
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    super.onAdFailedToLoad(loadAdError);
                    if (nativeAdID.equals(context.getString(R.string.temp_adx_native_id))) {
                        isNativeProcessing = false;
                        Log.e(TAG, "onAdFailedToLoadNative:" + loadAdError.getCode());
                        LoadNativeAdHomepage(context, context.getString(R.string.admob_native_id), adEventListener);
                    } else {
                        isNativeProcessing = false;
                        if (adEventListener != null) {
                            adEventListener.onLoadError(loadAdError.getMessage());
                        }
                        Log.e(TAG, "onAdFailedToLoadNative:ADEX" + loadAdError.getCode());
                    }

                }

                @Override
                public void onAdLoaded() {
                    isNativeProcessing = false;
                    super.onAdLoaded();

                }
            });
            VideoOptions videoOptions = new VideoOptions.Builder()
                    .setStartMuted(true)
                    .build();
            com.google.android.gms.ads.nativead.NativeAdOptions adOptions = new com.google.android.gms.ads.nativead.NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
            builder.withNativeAdOptions(adOptions);
            AdLoader adLoader = builder.build();
            Log.e(TAG, "onAdSTARTNATIVE:" + "LOADDDDDD::INIT");
            isNativeProcessing = true;
            adLoader.loadAd(new AdRequest.Builder().build());
        }*/
    }


    public NativeAd languageNativeAd;
    boolean isNativeLanguageProcessing = false;

//    public void LoadLanguageNativeAd(final Activity context, String nativeAdID,
//                                     final AdEventListener adEventListener) {
//        if (isNetworkAvailable(context)) {
//            AdLoader.Builder builder = new AdLoader.Builder(context, nativeAdID);
//            builder.forNativeAd(unifiedNativeAd -> {
//                languageNativeAd = unifiedNativeAd;
//                isNativeLanguageProcessing = false;
//                finalA.set(0);
//                if (adEventListener != null) {
//                    adEventListener.onAdLoaded(unifiedNativeAd);
//                }
//            }).withAdListener(new AdListener() {
//                @Override
//                public void onAdClosed() {
//                    super.onAdClosed();
//                    LoadLanguageNativeAd(context, nativeAdID, adEventListener);
//                }
//
//                @Override
//                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
//                    super.onAdFailedToLoad(loadAdError);
//                    if (nativeAdID.equals(context.getString(R.string.temp_adx_native_language_id))) {
//                        isNativeLanguageProcessing = false;
//                        Log.e(TAG, "onAdFailedToLoadNative:" + loadAdError.getCode());
//                        LoadLanguageNativeAd(context, context.getString(R.string.admob_native_language_id), adEventListener);
//                    } else {
//                        isNativeLanguageProcessing = false;
//                        if (adEventListener != null) {
//                            adEventListener.onLoadError(loadAdError.getMessage());
//                        }
//                        Log.e(TAG, "onAdFailedToLoadNative:ADEX" + loadAdError.getCode());
//                    }
//                }
//
//                @Override
//                public void onAdLoaded() {
//                    isNativeLanguageProcessing = false;
//                    super.onAdLoaded();
//
//                }
//            });
//            VideoOptions videoOptions = new VideoOptions.Builder()
//                    .setStartMuted(true)
//                    .build();
//            com.google.android.gms.ads.nativead.NativeAdOptions adOptions = new com.google.android.gms.ads.nativead.NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
//            builder.withNativeAdOptions(adOptions);
//            AdLoader adLoader = builder.build();
//            Log.e(TAG, "onAdSTARTNATIVE:" + "LOADDDDDD::INIT");
//            isNativeLanguageProcessing = true;
//            adLoader.loadAd(new AdRequest.Builder().build());
//
//            /*if (adEventListener != null && languageNativeAd != null) {
//                adEventListener.onAdLoaded(languageNativeAd);
//            }*/
//        }
//    }


    public boolean isNativeLoading = false;

//    public void LoadNativeAd(final Context context, String nativeAdID, final AdEventListener adEventListener, boolean isBig) {
//        AdLoader.Builder builder = new AdLoader.Builder(context, nativeAdID);
//        isNativeLoading = true;
//
//        builder.forNativeAd(unifiedNativeAd -> {
//            nativeAd = unifiedNativeAd;
//            isNativeLoading = false;
//            if (adEventListener != null) {
//                adEventListener.onAdLoaded(unifiedNativeAd);
//            }
//        }).withAdListener(new AdListener() {
//            @Override
//            public void onAdClosed() {
//                isNativeLoading = false;
//                super.onAdClosed();
//            }
//
//            @Override
//            public void onAdFailedToLoad(LoadAdError loadAdError) {
//                super.onAdFailedToLoad(loadAdError);
//                if (nativeAdID.equals(context.getString(R.string.admob_native_id))) {
//                    LoadNativeAd(context, context.getString(R.string.temp_adx_native_id), adEventListener, isBig);
//                } else {
//                    isNativeLoading = false;
//
//                    if (adEventListener != null) {
//                        adEventListener.onLoadError(loadAdError.getMessage());
//                    }
//                }
//                Log.e(TAG, "onAdFailedToLoadNative:" + loadAdError.getCode());
//            }
//
//            @Override
//            public void onAdLoaded() {
//                super.onAdLoaded();
//            }
//
//            @Override
//            public void onAdClicked() {
//                super.onAdClicked();
//            }
//
//            @Override
//            public void onAdOpened() {
//                super.onAdOpened();
//                nativeAd = null;
//                LoadNativeAd(context, nativeAdID, adEventListener, isBig);
//            }
//        });
//        VideoOptions videoOptions = new VideoOptions.Builder()
//                .setStartMuted(true)
//                .build();
//        com.google.android.gms.ads.nativead.NativeAdOptions adOptions = new com.google.android.gms.ads.nativead.NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
//        builder.withNativeAdOptions(adOptions);
//        AdLoader adLoader = builder.build();
//        adLoader.loadAd(new AdRequest.Builder().build());
//
//    }

    public void LoadNativeAdSmall(final Activity context, String nativeAdID, final AdEventListener adEventListener, int ViewType) {

        //viewtype  0 normalAdView
        //1 my money list &&
        //2 cash list && bank list
        //3 bills view


        if (adEventListener != null) {
            adEventListener.onLoadError("Error");
        }
    /*    AdLoader.Builder builder = new AdLoader.Builder(context, nativeAdID);
        builder.forNativeAd(unifiedNativeAd -> {
            if (adEventListener != null) {
                adEventListener.onAdLoaded(unifiedNativeAd);
            }
        }).withAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                super.onAdClosed();
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
                if (nativeAdID.equals(context.getString(R.string.temp_adx_native_id))) {
                    LoadNativeAdSmall(context, context.getString(R.string.admob_native_id), adEventListener, ViewType);
                } else {
                    if (adEventListener != null) {
                        adEventListener.onLoadError(loadAdError.getMessage());
                    }
                    Log.e(TAG, "onAdFailedToLoadNative:" + loadAdError.getCode());
                }
            }

            @Override
            public void onAdLoaded() {
                isNativeProcessing = false;
                super.onAdLoaded();
            }

            @Override
            public void onAdClicked() {
                super.onAdClicked();
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder()
                .setStartMuted(true)
                .build();
        com.google.android.gms.ads.nativead.NativeAdOptions adOptions = new com.google.android.gms.ads.nativead.NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.build();
        adLoader.loadAd(new AdRequest.Builder().build());*/
    }


    public NativeAd nativeAd10;
    public NativeAd nativeAd11;
    boolean isNativeProcessing1 = false;
    AtomicInteger finalA1 = new AtomicInteger();
    private AdEventListener adEventListenerCurrentBig1;


    public void populateUnifiedNativeAdView(Context context, FrameLayout frameLayout, NativeAd nativeAd, boolean isShowMedia, boolean isGrid) {
        if (isNetworkAvailable(context)) {
            LayoutInflater inflater = LayoutInflater.from(context);
            // Inflate the Ad view.  The layout referenced should be the one you created in the last step.
            NativeAdView adView;
            if (isGrid) {
                adView = (NativeAdView) inflater.inflate(R.layout.layout_big_native_ad_mob, null);
            } else {
                adView = (NativeAdView) (isShowMedia ?
                        inflater.inflate(R.layout.layout_big_native_ad_mob, null) :
                        inflater.inflate(R.layout.layout_small_native_ad_mob, null));

            }

            if (frameLayout != null) {
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
                frameLayout.setVisibility(View.VISIBLE);
            }
            try {

                MediaView mediaView = adView.findViewById(R.id.mediaView);
                if (isShowMedia) {
                    mediaView.setMediaContent(nativeAd.getMediaContent());
                    mediaView.setOnHierarchyChangeListener(new ViewGroup.OnHierarchyChangeListener() {
                        @Override
                        public void onChildViewAdded(View parent, View child) {
                            if (child instanceof ImageView) {
                                ImageView imageView = (ImageView) child;
                                imageView.setAdjustViewBounds(true);
                                imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                            }
                        }

                        @Override
                        public void onChildViewRemoved(View parent, View child) {
                        }
                    });
                }
                adView.setMediaView(mediaView);

                adView.setHeadlineView(adView.findViewById(R.id.adTitle));
                adView.setBodyView(adView.findViewById(R.id.adDescription));
                adView.setIconView(adView.findViewById(R.id.adIcon));
                adView.setAdvertiserView(adView.findViewById(R.id.adAdvertiser));
                adView.setCallToActionView(adView.findViewById(R.id.callToAction));

                ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());

                if (nativeAd.getBody() == null) {
                    adView.getBodyView().setVisibility(View.INVISIBLE);
                } else {
                    adView.getBodyView().setVisibility(View.VISIBLE);/*
                    ((TextView) adView.getBodyView()).setText("\t\t\t" + nativeAd.getBody());*/
                    String text = nativeAd.getBody();
                    text = text.trim();
                    // text = "        " + text;
                    ((TextView) adView.getBodyView()).setText(text);
                }
                if (nativeAd.getCallToAction() == null) {
                    adView.getCallToActionView().setVisibility(View.INVISIBLE);
                } else {
                    adView.getCallToActionView().setVisibility(View.VISIBLE);
                    String textoo = nativeAd.getCallToAction();
                    ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
                }

                if (nativeAd.getIcon() == null) {
                    adView.getIconView().setVisibility(View.GONE);
                } else {
                    ((ImageView) adView.getIconView()).setImageDrawable(nativeAd.getIcon().getDrawable());
                    adView.getIconView().setVisibility(View.VISIBLE);
                }


                if (nativeAd.getAdvertiser() == null) {
                    adView.getAdvertiserView().setVisibility(View.GONE);
                } else {
                    ((TextView) adView.getAdvertiserView()).setText(nativeAd.getAdvertiser());
                    adView.getAdvertiserView().setVisibility(View.VISIBLE);
                }
                adView.getAdvertiserView().setVisibility(View.GONE);


//                adView.setNativeAd(nativeAd);
                if (isShowMedia) {
                    adView.getMediaView().setVisibility(View.VISIBLE);
                } else {
                    adView.getMediaView().setVisibility(View.GONE);
                }

                VideoController vc = nativeAd.getMediaContent().getVideoController();
                try {
                    vc.mute(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (vc.hasVideoContent()) {
                    vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                        @Override
                        public void onVideoEnd() {
                            super.onVideoEnd();
                        }
                    });
                }


                adView.setNativeAd(nativeAd);

            } catch (Exception e) {
                e.printStackTrace();
                Log.e(TAG, "populateUnifiedNativeAdView Exception: " + e.getMessage());
            }
        }
    }

    public void populateUnifiedSmallNativeAdView(Context context, FrameLayout frameLayout, NativeAd nativeAd, boolean isShowMedia) {
        if (isNetworkAvailable(context)) {
            LayoutInflater inflater = LayoutInflater.from(context);
            // Inflate the Ad view.  The layout referenced should be the one you created in the last step.
            NativeAdView adView = (NativeAdView) inflater.inflate(R.layout.layout_small_native_ad_mob_with_media, null);


            if (frameLayout != null) {
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
                frameLayout.setVisibility(View.VISIBLE);
            }
            try {

                MediaView mediaView = adView.findViewById(R.id.mediaView);
                if (isShowMedia) {
                    mediaView.setMediaContent(nativeAd.getMediaContent());
                    mediaView.setOnHierarchyChangeListener(new ViewGroup.OnHierarchyChangeListener() {
                        @Override
                        public void onChildViewAdded(View parent, View child) {
                            if (child instanceof ImageView) {
                                ImageView imageView = (ImageView) child;
                                imageView.setAdjustViewBounds(true);
                                imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                            }
                        }

                        @Override
                        public void onChildViewRemoved(View parent, View child) {
                        }
                    });
                }
                adView.setMediaView(mediaView);

                adView.setHeadlineView(adView.findViewById(R.id.adTitle));
                adView.setBodyView(adView.findViewById(R.id.adDescription));
                adView.setIconView(adView.findViewById(R.id.adIcon));
                adView.setAdvertiserView(adView.findViewById(R.id.adAdvertiser));
                adView.setCallToActionView(adView.findViewById(R.id.callToAction));

                ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());

                if (nativeAd.getBody() == null) {
                    adView.getBodyView().setVisibility(View.INVISIBLE);
                } else {
                    adView.getBodyView().setVisibility(View.VISIBLE);/*
                    ((TextView) adView.getBodyView()).setText("\t\t\t" + nativeAd.getBody());*/
                    String text = nativeAd.getBody();
                    text = text.trim();
                    // text = "        " + text;
                    ((TextView) adView.getBodyView()).setText(text);
                }
                if (nativeAd.getCallToAction() == null) {
                    adView.getCallToActionView().setVisibility(View.INVISIBLE);
                } else {
                    adView.getCallToActionView().setVisibility(View.VISIBLE);
                    String textoo = nativeAd.getCallToAction();
                    ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
                }

                if (nativeAd.getIcon() == null) {
                    adView.getIconView().setVisibility(View.GONE);
                } else {
                    ((ImageView) adView.getIconView()).setImageDrawable(nativeAd.getIcon().getDrawable());
                    adView.getIconView().setVisibility(View.VISIBLE);
                }


                if (nativeAd.getAdvertiser() == null) {
                    adView.getAdvertiserView().setVisibility(View.GONE);
                } else {
                    ((TextView) adView.getAdvertiserView()).setText(nativeAd.getAdvertiser());
                    adView.getAdvertiserView().setVisibility(View.VISIBLE);
                }
                adView.getAdvertiserView().setVisibility(View.GONE);


//                adView.setNativeAd(nativeAd);
                if (isShowMedia) {
                    adView.getMediaView().setVisibility(View.VISIBLE);
                } else {
                    adView.getMediaView().setVisibility(View.GONE);
                }

                VideoController vc = nativeAd.getMediaContent().getVideoController();
                try {
                    vc.mute(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (vc.hasVideoContent()) {
                    vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                        @Override
                        public void onVideoEnd() {
                            super.onVideoEnd();
                        }
                    });
                }


                adView.setNativeAd(nativeAd);

            } catch (Exception e) {
                e.printStackTrace();
                Log.e(TAG, "populateUnifiedNativeAdView Exception: " + e.getMessage());
            }
        }
    }

    public void populateUnifiedSmallNativeAdView(Context context, FrameLayout frameLayout, NativeAd nativeAd, int type) {
        if (isNetworkAvailable(context)) {
            LayoutInflater inflater = LayoutInflater.from(context);
            // Inflate the Ad view.  The layout referenced should be the one you created in the last step.
            NativeAdView adView;
            if (type == 1) {
                adView = (NativeAdView) inflater.inflate(R.layout.layout_small_native_ad_mob_1, null);
            } else if (type == 2) {
                adView = (NativeAdView) inflater.inflate(R.layout.layout_small_native_ad_mob_2, null);
            } else if (type == 3) {
                adView = (NativeAdView) inflater.inflate(R.layout.layout_small_native_ad_mob_3, null);
            } else if (type == 5) {
                adView = (NativeAdView) inflater.inflate(R.layout.layout_small_native_ad_mob_4, null);
            } else if (type == 6) {
                adView = (NativeAdView) inflater.inflate(R.layout.layout_small_native_ad_mob_5, null);
            } else if (type == 7) {
                adView = (NativeAdView) inflater.inflate(R.layout.layout_small_native_ad_mob_6, null);
            } else {
                adView = (NativeAdView) inflater.inflate(R.layout.layout_small_native_ad_mob_with_media, null);
            }
            if (frameLayout != null) {
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
                frameLayout.setVisibility(View.VISIBLE);
            }
            try {
                if (type == 1 || type == 2 || type == 3 || type == 5 || type == 6 || type == 7) {

                    adView.setIconView(adView.findViewById(R.id.adIcon));
                    if (nativeAd.getIcon() == null) {
                        // adView.getIconView().setVisibility(View.GONE);
                    } else {
                        ((ImageView) adView.getIconView()).setImageDrawable(nativeAd.getIcon().getDrawable());
                        // adView.getIconView().setVisibility(View.VISIBLE);
                    }
                } else {
                    MediaView mediaView = adView.findViewById(R.id.mediaView);
                    mediaView.setMediaContent(nativeAd.getMediaContent());
                    mediaView.setOnHierarchyChangeListener(new ViewGroup.OnHierarchyChangeListener() {
                        @Override
                        public void onChildViewAdded(View parent, View child) {
                            if (child instanceof ImageView) {
                                ImageView imageView = (ImageView) child;
                                imageView.setAdjustViewBounds(true);
                                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                            }
                        }

                        @Override
                        public void onChildViewRemoved(View parent, View child) {
                        }
                    });
                    adView.setMediaView(mediaView);
                    adView.getMediaView().setVisibility(View.VISIBLE);
                    VideoController vc = nativeAd.getMediaContent().getVideoController();
                    try {
                        vc.mute(true);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    if (vc.hasVideoContent()) {
                        vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                            @Override
                            public void onVideoEnd() {
                                super.onVideoEnd();
                            }
                        });
                    }
                }


                adView.setHeadlineView(adView.findViewById(R.id.adTitle));
                adView.setBodyView(adView.findViewById(R.id.adDescription));
                adView.setAdvertiserView(adView.findViewById(R.id.adAdvertiser));
                if (type == 5) {
                    adView.setCallToActionView(adView.findViewById(R.id.adIcon));

                } else {
                    adView.setCallToActionView(adView.findViewById(R.id.callToAction));

                }


                ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());

                if (nativeAd.getBody() == null) {
                    adView.getBodyView().setVisibility(View.INVISIBLE);
                } else {
                    adView.getBodyView().setVisibility(View.VISIBLE);
                    String text = nativeAd.getBody();
                    text = text.trim();
                    if (type == 7) {
                        text = "        " + text;
                    }
                    ((TextView) adView.getBodyView()).setText(text);
                }
                if (type != 5) {
                    if (nativeAd.getCallToAction() == null) {
                        adView.getCallToActionView().setVisibility(View.INVISIBLE);
                    } else {
                        adView.getCallToActionView().setVisibility(View.VISIBLE);
                        ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
                    }
                }


                if (nativeAd.getAdvertiser() == null) {
//                    adView.getAdvertiserView().setVisibility(View.GONE);
                } else {
                    ((TextView) adView.getAdvertiserView()).setText(nativeAd.getAdvertiser());
                    adView.getAdvertiserView().setVisibility(View.VISIBLE);
                }
                adView.setNativeAd(nativeAd);

                if (nativeAd.getIcon() == null) {
                    Log.e("JHSGUJHDAGDHAS", type + ":::");
                } else {
                    Log.e("JHSGUJHDAGDHAS", type + ":::NOTT");
                }

            } catch (Exception e) {
                e.printStackTrace();
                Log.e(TAG, "populateUnifiedNativeAdView Exception: " + e.getMessage());
            }
        }
    }


    //////////////////Rate Ads//////////
    public NativeAd mNativeRateAd;


//    public void LoadNativeRateAd(final Activity context, String nativeAdID, final AdEventListener adEventListener) {
//        if (!TextUtils.isEmpty(nativeAdID)) {
//            AdLoader.Builder builder = new AdLoader.Builder(context, nativeAdID);
//            builder.forNativeAd(unifiedNativeAd -> {
//                mNativeRateAd = unifiedNativeAd;
//                if (adEventListener != null) {
//                    adEventListener.onAdLoaded(unifiedNativeAd);
//                }
//            }).withAdListener(new AdListener() {
//                @Override
//                public void onAdClosed() {
//                    super.onAdClosed();
//                }
//
//                @Override
//                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
//                    super.onAdFailedToLoad(loadAdError);
//                    if (nativeAdID.equals(context.getString(R.string.temp_adx_native_id))) {
//                        LoadNativeRateAd(context, context.getString(R.string.admob_native_id), adEventListener);
//                    } else {
//                        if (adEventListener != null) {
//                            adEventListener.onLoadError(loadAdError.getMessage());
//                        }
//                    }
//                    Log.e(TAG, "onAdFailedToLoadRATEEENative:" + loadAdError.getCode());
//                }
//
//                @Override
//                public void onAdLoaded() {
//                    Log.e(TAG, "onAdLoadRATEEENative:");
//
//                    super.onAdLoaded();
//                }
//            });
//            VideoOptions videoOptions = new VideoOptions.Builder()
//                    .setStartMuted(true)
//                    .build();
//            com.google.android.gms.ads.nativead.NativeAdOptions adOptions = new com.google.android.gms.ads.nativead.NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
//            builder.withNativeAdOptions(adOptions);
//            AdLoader adLoader = builder.build();
//            adLoader.loadAd(new AdRequest.Builder().build());
//        }
//    }


    public void populateUnifiedNativeAdView1(Context context, FrameLayout frameLayout, NativeAd nativeAd, boolean isShowMedia, boolean isGrid) {
        if (isNetworkAvailable(context)) {
            mNativeRateAd = nativeAd;
            LayoutInflater inflater = LayoutInflater.from(context);
// Inflate the Ad view. The layout referenced should be the one you created in the last step.
            NativeAdView adView;
            adView = (NativeAdView) inflater.inflate(R.layout.layout_big_native_ad_mob, null);

            if (frameLayout != null) {
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
            try {
                if (isShowMedia) {
                    MediaView mediaView = adView.findViewById(R.id.mediaView);
                    mediaView.setMediaContent(nativeAd.getMediaContent());

                    mediaView.setOnHierarchyChangeListener(new ViewGroup.OnHierarchyChangeListener() {
                        @Override
                        public void onChildViewAdded(View parent, View child) {
                            if (child instanceof ImageView) {
                                ImageView imageView = (ImageView) child;
                                imageView.setAdjustViewBounds(true);
                            }
                        }

                        @Override
                        public void onChildViewRemoved(View parent, View child) {
                        }
                    });

                    adView.setMediaView(mediaView);
                }
                adView.setHeadlineView(adView.findViewById(R.id.adTitle));
                adView.setBodyView(adView.findViewById(R.id.adDescription));
                adView.setIconView(adView.findViewById(R.id.adIcon));
                adView.setAdvertiserView(adView.findViewById(R.id.adAdvertiser));
                adView.setCallToActionView(adView.findViewById(R.id.callToAction));
                ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());

                if (nativeAd.getBody() == null) {
                    adView.getBodyView().setVisibility(View.INVISIBLE);
                } else {
                    adView.getBodyView().setVisibility(View.VISIBLE);/*
                    ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
                    ((TextView) adView.getBodyView()).setText("\t\t\t" + nativeAd.getBody());*/
                    String text = nativeAd.getBody();
                    text = text.trim();
                    //   text = "        " + text;
                    ((TextView) adView.getBodyView()).setText(text);

                }

                if (nativeAd.getCallToAction() == null) {
                    adView.getCallToActionView().setVisibility(View.INVISIBLE);
                } else {
                    adView.getCallToActionView().setVisibility(View.VISIBLE);
                    ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
                }
                if (nativeAd.getIcon() == null) {
                    adView.getIconView().setVisibility(View.GONE);
                } else {
                    ((ImageView) adView.getIconView()).setImageDrawable(nativeAd.getIcon().getDrawable());
                    adView.getIconView().setVisibility(View.VISIBLE);
                }
                if (isShowMedia) {
                    adView.getMediaView().setVisibility(View.VISIBLE);
                } else {
                    adView.getMediaView().setVisibility(View.GONE);
                }

                if (nativeAd.getAdvertiser() == null) {
                    adView.getAdvertiserView().setVisibility(View.INVISIBLE);
                } else {
                    adView.getAdvertiserView().setVisibility(View.VISIBLE);
                }
                adView.getAdvertiserView().setVisibility(View.GONE);

                adView.setNativeAd(nativeAd);
                VideoController vc = nativeAd.getMediaContent().getVideoController();
                try {
                    vc.mute(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (vc.hasVideoContent()) {
                    vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                        @Override
                        public void onVideoEnd() {
                            super.onVideoEnd();
                        }
                    });
                }
                if (frameLayout != null) {
                    frameLayout.setVisibility(View.VISIBLE);
                }

                adView.setNativeAd(nativeAd);
            } catch (Exception e) {
                e.printStackTrace();
                Log.e(TAG, "populateUnifiedNativeAdView Exception: " + e.getMessage());
            }
        }
    }


   /* public void loadFacebookNative(NativeAdLayout nativeAdLayout, Activity activity) {
        NativeBannerAd nativeBannerAd = new NativeBannerAd(activity, activity.getResources().getString(R.string.fb_native_ads));
//        NativeBannerAd nativeBannerAd = new NativeBannerAd(activity, "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID");
        NativeAdListener nativeAdListener = new NativeAdListener() {

            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {
                // Native ad failed to load
                Log.e(TAG, "Native ad failed to load: " + adError.getErrorMessage());
            }

            @Override
            public void onAdLoaded(Ad ad) {
                if (nativeBannerAd == null || nativeBannerAd != ad) {
                    return;
                }
                // Inflate Native Banner Ad into Container
                inflateFacebookAd(nativeBannerAd, nativeAdLayout, activity);
                Log.d(TAG, "Native ad is loaded and ready to be displayed!");
            }

            @Override
            public void onAdClicked(Ad ad) {
                // Native ad clicked
                Log.d(TAG, "Native ad clicked!");
            }

            @Override
            public void onLoggingImpression(Ad ad) {
                // Native ad impression
                Log.d(TAG, "Native ad impression logged!");
            }
        };
        // load the ad
        nativeBannerAd.loadAd(
                nativeBannerAd.buildLoadAdConfig()
                        .withAdListener(nativeAdListener)
                        .build());
    }*/
    /*private void inflateFacebookAd(NativeBannerAd nativeBannerAd, NativeAdLayout nativeAdLayout, Activity activity) {
        // Unregister last ad
        nativeBannerAd.unregisterView();
        // Add the Ad view into the ad container.
        LayoutInflater inflater = LayoutInflater.from(activity);
        // Inflate the Ad view.  The layout referenced is the one you created in the last step.
        LinearLayout adView = (LinearLayout) inflater.inflate(R.layout.native_banner_ad_layout, nativeAdLayout, false);
        nativeAdLayout.addView(adView);

        // Add the AdChoices icon
        RelativeLayout adChoicesContainer = adView.findViewById(R.id.ad_choices_container);
        AdOptionsView adOptionsView = new AdOptionsView(activity, nativeBannerAd, nativeAdLayout);
        adChoicesContainer.removeAllViews();
        adChoicesContainer.addView(adOptionsView, 0);

        // Create native UI using the ad metadata.
        TextView nativeAdTitle = adView.findViewById(R.id.adTitle);
        TextView nativeAdSocialContext = adView.findViewById(R.id.adDescription);
        TextView sponsoredLabel = adView.findViewById(R.id.adAdvertiser);
        com.facebook.ads.MediaView nativeAdIconView = adView.findViewById(R.id.mediaView);
        Button nativeAdCallToAction = adView.findViewById(R.id.callToAction);

        // Set the Text.
        nativeAdCallToAction.setText(nativeBannerAd.getAdCallToAction());
        nativeAdCallToAction.setVisibility(
                nativeBannerAd.hasCallToAction() ? View.VISIBLE : View.INVISIBLE);
        nativeAdTitle.setText(nativeBannerAd.getAdvertiserName());
        String text = nativeBannerAd.getAdSocialContext().trim();
        text = "        " + text;
        nativeAdSocialContext.setText(text);
        sponsoredLabel.setText(nativeBannerAd.getSponsoredTranslation());

        // Register the Title and CTA button to listen for clicks.
        List<View> clickableViews = new ArrayList<>();
        clickableViews.add(nativeAdTitle);
        clickableViews.add(nativeAdCallToAction);
        nativeBannerAd.registerViewForInteraction(adView, nativeAdIconView, clickableViews);
    }*/


}
