package com.bankbalanceinquiry.ministatement.activity;

import static com.bankbalanceinquiry.ministatement.utils.Constant.isFromLanguage;
import static com.bankbalanceinquiry.ministatement.utils.Constant.setLocale;

import android.Manifest;
import android.app.ActivityManager;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager.widget.ViewPager;

import com.adconfig.adsutil.admob.BannerAdHelper;
import com.adconfig.adsutil.admob.NativeAdHelper;
import com.adconfig.adsutil.admob.NativeLayoutType;
import com.bankbalanceinquiry.ministatement.BuildConfig;
import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.activity.ui.BoxviewFragment;
import com.bankbalanceinquiry.ministatement.adapter.HomePageFragmentAdapter;
import com.bankbalanceinquiry.ministatement.animatedbottombar.AnimatedBottomBar;
import com.bankbalanceinquiry.ministatement.inapp.AdsManager;
import com.bankbalanceinquiry.ministatement.inapp_helper.AppUpdateInstallerListener;
import com.bankbalanceinquiry.ministatement.inapp_helper.AppUpdateInstallerManager;
import com.bankbalanceinquiry.ministatement.inapp_helper.InAppUpdateInstallerManager;
import com.bankbalanceinquiry.ministatement.utils.AdCache;
import com.bankbalanceinquiry.ministatement.utils.Constant;
import com.bankbalanceinquiry.ministatement.utils.NetworkManager;
import com.bankbalanceinquiry.ministatement.utils.SharedPreferenceClass;
import com.bankbalanceinquiry.ministatement.utils.SmsService;
import com.google.android.gms.ads.AdView;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textview.MaterialTextView;
import com.google.android.play.core.appupdate.AppUpdateInfo;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.install.InstallStateUpdatedListener;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.android.play.core.install.model.InstallStatus;
import com.google.android.play.core.install.model.UpdateAvailability;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;

public class drawerActivity extends AppCompatActivity {

    public static NavigationView navigationView;
    public static TextView navBalance;
    String bank_name = "";
    public static Toolbar toolbar;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editorBank;
    Button allow_Permission;
    public static int check1 = 1;

    private FrameLayout adContainer;


//    private MaterialTextView opBankBalance, opMyMoney, op_bank_bills;
    DrawerLayout drawer;

    private boolean isAdShown = false;
    private boolean isActivityPause = false;


    private ActionBar actionBar;
    public Menu mainOptionMenu;

    ViewPager viewPager;
    AnimatedBottomBar bottomMenu;
    HomePageFragmentAdapter adapter = null;

    LinearLayout home_page_view;

    long clickTime = 0;
    boolean bug = false;
    float rating = 0f;
    private AlertDialog dialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLocale(this);
        setContentView(R.layout.activity_drawer);


        EventBus.getDefault().register(this);
        sharedPreferences = getApplicationContext().getSharedPreferences("bank_select", MODE_PRIVATE);

        bank_name = sharedPreferences.getString("bank_name", "No Bank");
        home_page_view = findViewById(R.id.home_page_view);

        drawer = findViewById(R.id.drawer_layout);
//        opBankBalance = findViewById(R.id.op_bank_balance);
//        opMyMoney = findViewById(R.id.op_my_money);
//        op_bank_bills = findViewById(R.id.op_bank_bills);
       /* AdSettings.addTestDevice("c1c7c7f1-1af7-4efd-bc0a-c04e401ac2fd");
        MediationTestSuite.launch(drawerActivity.this);*/


        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        actionBar = getSupportActionBar();

        if (actionBar != null) {
            actionBar.setHomeAsUpIndicator(R.drawable.ic_hamburger);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().setStatusBarColor(getColor(R.color.app_color));
        }
        allow_Permission = findViewById(R.id.allow_Permission);
//        fl_adplaceholder_balance_rel = (LinearLayout) findViewById(R.id.fl_adplaceholder_balance_rel);

        adContainer = findViewById(R.id.banner_container);
        navigationView = findViewById(R.id.nav_view);
        navigationView.setItemIconTintList(null);

        // View headerView = navigationView.getHeaderView(0);
        navBalance = findViewById(R.id.textView_balance);

        editorBank = sharedPreferences.edit();


        setUpViewPager();

        addBottomNavigation();
        setUpNavigation();
       /* if (!isMyServiceRunning(CheckRegexService.class)) {
            startService(new Intent(this, CheckRegexService.class).putExtra("isShowProgress", false));
        }*/
        new Handler(Looper.getMainLooper()).postDelayed(() -> Constant.isShplashScreen = false, 2000);
        if (!isFromLanguage && !getIntent().hasExtra("FromNotification")) {
            if (isStoragePermissionGranted()) {
                startMessageLoadingService();
            } else {
                clickTime = Calendar.getInstance().getTimeInMillis();
                Get_Permission();
            }

//            if (getRate()) {
//                AdmobAdManager.getInstance().LoadNativeRateAd(this, getString(R.string.temp_adx_native_id), null);
//            }
//            //showInterstitialAd(true);
//            if (AdmobAdManager.getInstance().isNetworkAvailable(this)) {
//                //showInterstitialAds();
//            }
        } else {
            isFromLanguage = false;
        }
        home_page_view.setVisibility(View.VISIBLE);
        //   AdmobAdManager.getInstance().loadInterstitialAd(this, getString(R.string.interstitial_id));

        loadBannerAds();
//        checkForUpdates();
        checkAppUpdate();

        final int PROGRESS_DIALOG_DELAY = 2000; // 2 seconds
        ProgressDialog progressDialog;
        Handler handler;


        FirebaseRemoteConfig remoteConfig = FirebaseRemoteConfig.getInstance();
        if (!SharedPreferenceClass.getBoolean(drawerActivity.this, "v_" + BuildConfig.VERSION_CODE, false)) {
            remoteConfig.reset();
            SharedPreferenceClass.setBoolean(drawerActivity.this, "v_" + BuildConfig.VERSION_CODE, true);
        }

//        String adShowCount = remoteConfig.getString("adShowCount");
//        if (adShowCount.isEmpty()) {
//            adShowCount = "3";
//        }
//        Constant.adShowCount=(Integer.parseInt(adShowCount));
//
//        String removeAdCount = remoteConfig.getString("removeAdCount");
//        if (removeAdCount.isEmpty()) {
//            removeAdCount = "0";
//        }
//        Constant.removeAdCount=(Integer.parseInt(removeAdCount));


//        progressDialog = new ProgressDialog(this);
//        progressDialog.setMessage("Loading...");
//        progressDialog.setCancelable(false);
//        progressDialog.show();
//        InterstitialAdHelper.INSTANCE.loadAd(drawerActivity.this, new Function0<Unit>() {
//            @Override
//            public Unit invoke() {
//                progressDialog.dismiss();

//                InterstitialAdHelper.INSTANCE.showInterstitialAd(drawerActivity.this, true, new Function2<Boolean, Boolean, Unit>() {
//                    @Override
//                    public Unit invoke(Boolean isAdShowing, Boolean isShowFullScreenAd) {;
//                        return null;
//                    }
//                });
//                return null;
//            }
//        });

//        showAds1();
    }

    private void checkAppUpdate() {
        try {
            appUpdateInstallerManager=new InAppUpdateInstallerManager(this,1991);
            appUpdateInstallerManager.addAppUpdateListener(appUpdateInstallerListener);
            appUpdateInstallerManager.startCheckUpdate();
        } catch (Exception e) {

        }
    }

    private void popupSnackBarForCompleteUpdate() {
//        Snackbar snackBar = Snackbar.make(
//                findViewById(android.R.id.content),
//                "An update has just been downloaded.",
//                Snackbar.LENGTH_INDEFINITE
//        );
//        snackBar.setAction("RESTART") { appUpdateInstallerManager.completeUpdate(); }
//        snackBar.setActionTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark))
//        snackBar.show();

        Snackbar snackbar =
                Snackbar.make(
                        findViewById(android.R.id.content),
                        "An update has just been downloaded.",
                        Snackbar.LENGTH_INDEFINITE);
        snackbar.setAction("RESTART", view -> appUpdateInstallerManager.completeUpdate());
        snackbar.setActionTextColor(
                getResources().getColor(android.R.color.holo_blue_bright));
        snackbar.show();
    }
    private InAppUpdateInstallerManager appUpdateInstallerManager;
    private AppUpdateInstallerListener appUpdateInstallerListener=new AppUpdateInstallerListener(){
        @Override
        public void onCancelled() {

        }

        @Override
        public void onNotUpdate() {

        }

        @Override
        public void onFailure(@NonNull Exception e) {

        }

        @Override
        public void onDownloadedButNotInstalled() {
            popupSnackBarForCompleteUpdate();
        }
    };

//    private void showAds1() {
//        boolean isShowAds = getIntent().getBooleanExtra("isInterShow", false);
//        if (!isShowAds) {
//            return;
//        }
//        AdmobAdManager.getInstance().showProgress(this);
//        if (AdmobAdManager.getInstance().isAdLoad) {
//            new Handler(Looper.myLooper()).postDelayed(() -> {
//                AdmobAdManager.getInstance().dismissProgress(this);
//                AdmobAdManager.getInstance().loadInterstitialAd(drawerActivity1.this, getString(R.string.temp_adx_interstitial_id), 1, () -> {
//                });
//            }, 1000);
//        } else {
//            new Thread(() -> {
//                while (!AdmobAdManager.getInstance().isAdLoad &&
//                        !AdmobAdManager.getInstance().isAdLoadFailed) {
//                    Log.d("TAG", "showInterstitialAd: ");
//                }
//                runOnUiThread(() -> {
//                    new Handler(Looper.myLooper()).postDelayed(() -> {
//                        AdmobAdManager.getInstance().dismissProgress(this);
//                        AdmobAdManager.getInstance().loadInterstitialAd(drawerActivity1.this, getString(R.string.temp_adx_interstitial_id), 1, () -> {
//                        });
//                    }, 1000);
//                });
//            }).start();
//        }
//    }

    Boolean isAdLoaded=false;
    AdView mAdView;
    private void loadBannerAds() {

        if (new AdsManager(this).isNeedToShowAds() && NetworkManager.isInternetConnected(this)) {
            String adId=getString(R.string.g_banner_home);
            BannerAdHelper.INSTANCE.showBanner(this, adContainer, adId, AdCache.Companion.getBannerHome(), new Function3<Boolean, AdView, String, Unit>() {
                @Override
                public Unit invoke(Boolean aBoolean, AdView adView, String s) {
                    AdCache.Companion.setBannerHome(adView);
                    mAdView=adView;
                    isAdLoaded=true;
                    return null;
                }
            },null);
        }

//        AdmobAdManager.getInstance().LoadAdaptiveBanner(this, adContainer, getResources().getString(R.string.admob_banner_id), null);
    }




    public boolean isStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (ActivityCompat.checkSelfPermission(drawerActivity.this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) {
                if (Build.VERSION.SDK_INT >= 33) {
                    if (ActivityCompat.checkSelfPermission(drawerActivity.this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    return true;
                }
            } else {
                return false;
            }
        } else {
            return true;
        }
    }

    private void Get_Permission() {

        List<String> permissionsNeeded = new ArrayList<String>();
        final List<String> permissionsList = new ArrayList<String>();

        if (!addPermission(permissionsList, Manifest.permission.READ_SMS))
            permissionsNeeded.add("Read SMS");

        if (!addPermission(permissionsList, Manifest.permission.POST_NOTIFICATIONS))
            permissionsNeeded.add("POST NOTIFICATIONS");

        if (permissionsList.size() > 0) {
            if (permissionsNeeded.size() > 0) {
                for (int i = 0; i < 1; i++)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionsList.toArray(new String[permissionsList.size()]), 1);
                    }

                return;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(permissionsList.toArray(new String[permissionsList.size()]), 1);
            }
            return;
        }

    }


    private boolean addPermission(List<String> permissionsList, String permission) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsList.add(permission);
                return shouldShowRequestPermissionRationale(permission);
            }
        }

        return true;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            long clickTime1 = Calendar.getInstance().getTimeInMillis();
            long difference = 0;
            if (clickTime1 >= clickTime) {
                difference = clickTime1 - clickTime;
            } else {
                difference = clickTime - clickTime1;
            }
            if (difference < 500) {
                Toast.makeText(drawerActivity.this,
                        getString(R.string.permission_deny_msg)
                        , Toast.LENGTH_LONG).show();
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.fromParts("package", getPackageName(), null));
                startActivityForResult(intent, 05);
            }
            if (permissions.length >= 1) {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    startMessageLoadingService();
                }
            }
        }

        return;

    }


    @RequiresApi(api = Build.VERSION_CODES.R)
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 05){
            if (isStoragePermissionGranted()) {
                startMessageLoadingService();
            }
        }
        appUpdateInstallerManager.onActivityResult(requestCode, resultCode, data);
    }

    private void startMessageLoadingService() {
        if (!isMyServiceRunning(SmsService.class)) {
            ContextCompat.startForegroundService(this, new Intent(this, SmsService.class).putExtra("isShowProgress", false));
        }
    }

//    private void popupSnackbarForCompleteUpdate() {
//        Snackbar snackbar =
//                Snackbar.make(
//                        findViewById(android.R.id.content),
//                        "An update has just been downloaded.",
//                        Snackbar.LENGTH_INDEFINITE);
//        snackbar.setAction("RESTART", view -> appUpdateManager.completeUpdate());
//        snackbar.setActionTextColor(
//                getResources().getColor(android.R.color.holo_blue_bright));
//        snackbar.show();
//    }

//    private AppUpdateManager appUpdateManager; //
//    InstallStateUpdatedListener listener = state -> {
//        if (state.installStatus() == InstallStatus.DOWNLOADED) {
//            popupSnackbarForCompleteUpdate();
//        }
//
//    };

//    private void checkForUpdates() {
//        //busca en la playStore si hay una versión más reciente, y si la hay pide que se actualice la app
//        appUpdateManager = AppUpdateManagerFactory.create(this);
//
//        Task<AppUpdateInfo> appUpdateInfoTask = appUpdateManager.getAppUpdateInfo();
//
//        appUpdateInfoTask.addOnSuccessListener(appUpdateInfo -> {
//            if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE
//                    // This example applies an immediate update. To apply a flexible update
//                    // instead, pass in AppUpdateType.FLEXIBLE
//                    && appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)) {
//
//                // Request the update.
//
//                try {
//                    System.out.println("updater see if it has to update");
//                    appUpdateManager.startUpdateFlowForResult(appUpdateInfo, AppUpdateType.IMMEDIATE, this, 100);
//                } catch (IntentSender.SendIntentException e) {
//                    throw new RuntimeException(e);
//                }
//            }
//        });
//
//        appUpdateManager.registerListener(listener);
//
//    }


    private void setUpViewPager() {
        viewPager = findViewById(R.id.viewPager);
        bottomMenu = findViewById(R.id.bottom_menu);
        adapter = new HomePageFragmentAdapter(getSupportFragmentManager(), this, 3);
        viewPager.setAdapter(adapter);
        // lastSelected = 0;
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                changeSelectOption(position);

            }

            @Override
            public void onPageSelected(int position) {
              /*  if (position == 2) {
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Fragment frr = adapter.getItem(2);
                            if (frr instanceof BoxviewFragment) {
                                ((BoxviewFragment) frr).loadNative();
                            }
                        }
                    },100);
                }*/
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        if (getIntent().hasExtra("FromNotification")) {
            viewPager.post(new Runnable() {
                @Override
                public void run() {
                    viewPager.setCurrentItem(1);
                }
            });
        }
        viewPager.setOffscreenPageLimit(3);
        bottomMenu.setupWithViewPager(viewPager);
    }


    private boolean isMyServiceRunning(Class<?> serviceClass) {

        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        if (manager != null) {
            for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
                if (serviceClass.getName().equals(service.service.getClassName())) {
                    return true;
                }
            }
        }
        return false;
    }


    private void startNextActivity(int type) {
        Intent i = new Intent(this, SubActivity_homePage.class);
        i.putExtra("viewType", type);
        startActivity(i);
    }


    public void setUpNavigation() {
        LinearLayout nav_bank_change, nav_box, nav_cash, nav_bills, nav_change_lang, nav_feedback, nav_privacy, nav_share, nav_rate;

        nav_bank_change = findViewById(R.id.nav_bank_change);
        nav_box = findViewById(R.id.nav_box);
        nav_cash = findViewById(R.id.nav_cash);
        nav_bills = findViewById(R.id.nav_bills);
        nav_change_lang = findViewById(R.id.nav_change_lang);
        nav_feedback = findViewById(R.id.nav_feedback);
        nav_privacy = findViewById(R.id.nav_privacy);
        nav_share = findViewById(R.id.nav_share);
        nav_rate = findViewById(R.id.nav_rate);

        nav_bank_change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startNextActivity(6);
                closeDrawer(false);
            }
        });
        nav_box.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                closeDrawer(false);
            }
        });
        nav_cash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // navController.navigate(R.id.nav_cash);
                startActivity(new Intent(drawerActivity.this, CashWithdrawalActivity.class));
                closeDrawer(false);
            }
        });
        nav_bills.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(drawerActivity.this, BillsNewActivity.class));
                // navController.navigate(R.id.nav_bills);
                closeDrawer(false);
            }
        });
        nav_change_lang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(drawerActivity.this, LanguageSelectActivity.class).putExtra("isFromSetting", true));
                // navController.navigate(R.id.nav_bills);
                closeDrawer(false);
            }
        });
        nav_feedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // navController.navigate(R.id.nav_feedback);
                Intent email = new Intent(Intent.ACTION_SENDTO, Uri.parse(
                        "mailto:?subject=Feedback&to=" + Uri.encode(
                                getResources().getString(R.string.email)
                        )
                ));
                //  email.putExtra(Intent.EXTRA_EMAIL, new String[]{getResources().getString(R.string.email)});
                // email.putExtra(Intent.EXTRA_SUBJECT, "Feedback");
                email.putExtra(Intent.EXTRA_TEXT, "" + getResources().getString(R.string.app_name));
                //email.setType("message/rfc822");

                startActivity(Intent.createChooser(email, getString(R.string.send_mail)));

                closeDrawer(false);
            }
        });
        nav_privacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // navController.navigate(R.id.nav_privacy);
                Uri uri_privacy = Uri.parse(getResources().getString(R.string.privacy_policy));
                //url_netBank= listBankAdapter.bank_url;
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(String.valueOf(uri_privacy)));
                startActivity(i);
                closeDrawer(false);
            }
        });
        nav_share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // navController.navigate(R.id.nav_share);
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                shareIntent.setType("text/plain");
                shareIntent.putExtra(Intent.EXTRA_SUBJECT, getResources().getString(R.string.app_name));
                shareIntent.putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id=" + getPackageName());
                startActivity(shareIntent);
                closeDrawer(false);
            }
        });
        nav_rate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Uri uri = Uri.parse("market://details?id=" + drawerActivity.this.getPackageName());
                Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri);
                try {
                    startActivity(myAppLinkToMarket);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(drawerActivity.this, " Sorry, Not able to open!", Toast.LENGTH_SHORT).show();
                }

                closeDrawer(false);
            }
        });

    }

    private boolean closeDrawer(boolean isOpen) {
        if (!isOpen) {
            if (drawer.isDrawerOpen(GravityCompat.START)) {
                drawer.closeDrawer(GravityCompat.START);
                return true;
            }
        } else {
            if (!drawer.isDrawerOpen(GravityCompat.START)) {
                drawer.openDrawer(GravityCompat.START);
                return true;
            }
        }
        return false;

    }


    @Override
    protected void onPause() {
        super.onPause();
        if(mAdView!=null) mAdView.pause();
    }

    private void addBottomNavigation() {
      /*  lastClickedBottomOption = 2;
        op_bank_bills.setSelected(true);*/
        changeSelectOption(0);
//        opBankBalance.setOnClickListener(v -> {
//            // if (lastClickedBottomOption == 1 || lastClickedBottomOption == 2) {
//            viewPager.setCurrentItem(0, false);
//            // }
//        });
//        opMyMoney.setOnClickListener(v -> {
//            // if (lastClickedBottomOption == 0 || lastClickedBottomOption == 2) {
//            viewPager.setCurrentItem(1, false);
//            // }
//        });
//        op_bank_bills.setOnClickListener(v -> {
//            //  if (lastClickedBottomOption == 0 || lastClickedBottomOption == 1) {
//            viewPager.setCurrentItem(2, false);
//            //  }
//        });
    }


    /*@Subscribe
    public void getSmsList(SmsList smsList) {
        ArrayList<HomeAccoutList> allTransactionList = smsList.getAllTransactionList();
        ArrayList<HomeAccoutList> homeAccoutLists = smsList.getHomeAccoutLists();
    }*/

    @Override
    protected void onResume() {
        super.onResume();
        if(mAdView!=null) mAdView.resume();
        //EventBus.getDefault().register(this);
    }



    @Override
    protected void onDestroy() {
        EventBus.getDefault().unregister(this);
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.drawer, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        mainOptionMenu = menu;
        disablemenuItems(true);
        return super.onPrepareOptionsMenu(menu);
    }

    private void disablemenuItems(boolean isDisable) {
        if (mainOptionMenu != null) {
            if (!isDisable) {
                mainOptionMenu.findItem(R.id.action_refreshData).setEnabled(true);
                mainOptionMenu.findItem(R.id.action_refreshData).getIcon().setAlpha(255);

            } else {
                mainOptionMenu.findItem(R.id.action_refreshData).setEnabled(false);
                mainOptionMenu.findItem(R.id.action_refreshData).getIcon().setAlpha(200);

            }
            // invalidateOptionsMenu();
        }
    }

    @Subscribe
    public void OnSmsProgress(final Intent intent) {
        if (intent != null) {
            if (intent.getAction().equalsIgnoreCase("DisableOptionMenu")) {
                boolean isDisable = intent.getBooleanExtra("disabled", false);
                disablemenuItems(isDisable);
            } else if (intent.getAction().equalsIgnoreCase("CHANGE_BANK")) {
                changeSelectOption(viewPager.getCurrentItem());
            }
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null && intent.hasExtra("FromNotification")) {
            closeDrawer(false);
            if (viewPager != null && viewPager.getCurrentItem() != -1) {
                viewPager.setCurrentItem(1);
            }
        }

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.action_settings) {
            //showInterIconAds();
    /*item.setEnabled(false);
    showInterstitialAd1(true);
    new Handler().postDelayed(new Runnable() {
        @Override
        public void run() {
            item.setEnabled(true);
        }
    }, 1000);*/
            //AdmobAdManager.getInstance().loadInterstitialAd(this, getString(R.string.interstitial_id), 1, () -> {});
            return true;
        } else if (itemId == android.R.id.home) {
    /*if (viewPager.getCurrentItem() != 0) {
        onBackPressed();
    } else {*/
            closeDrawer(true);
            //}
            return true;
        } else if (itemId == R.id.action_refreshData) {
            if (isStoragePermissionGranted()) {
                Intent ii = new Intent();
                ii.setAction("RefreshData");
                EventBus.getDefault().post(ii);
                startMessageLoadingService();
            } else {
                clickTime = Calendar.getInstance().getTimeInMillis();
                Get_Permission();
            }
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }


    }



  /*  @Override
    public boolean onSupportNavigateUp() {
       *//* opBankBalance.setSelected(true);
        opMyMoney.setSelected(false);
        lastClickedBottomOption = 0;*//*
        navController = findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration) || super.onSupportNavigateUp();
    }*/


    @Override
    public void onBackPressed() {
        if (adapter != null && adapter.getItem(viewPager.getCurrentItem()) instanceof BoxviewFragment) {
            if (((BoxviewFragment) adapter.getItem(viewPager.getCurrentItem())).isBack()) {
                return;
            }
        }
        if (viewPager.getCurrentItem() == 0) {
//            performBack();
            if (!SharedPreferenceClass.getBoolean(drawerActivity.this, "apprate", false))
                showRateDailog(true);
            else
                askAlertDialog(drawerActivity.this, "Do you want to exit.?", "Press YES to Exit or NO to Cancel",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finishAffinity();
                            }
                        },
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //finishAffinity();
                            }
                        });
        } else {

            viewPager.setCurrentItem(0, false);
        }

    }

    public static void askAlertDialog(Context context, String title, String message, DialogInterface.OnClickListener positiveListener, DialogInterface.OnClickListener negativeListener) {
        new AlertDialog.Builder(context)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("Yes", positiveListener)
                .setNegativeButton("No", negativeListener)
                .show();
    }

    public void changeSelectOption(int pos) {
       /* if (mainOptionMenu != null) {
            mainOptionMenu.findItem(R.id.action_refreshData).setVisible(false);
        }*/
        bank_name = sharedPreferences.getString("bank_name", "No Bank");

        switch (pos) {
            case 0:
                if (mainOptionMenu != null) {
                    mainOptionMenu.findItem(R.id.action_refreshData).setVisible(false);
//                    mainOptionMenu.findItem(R.id.action_settings).setVisible(true);
                }
                if (bank_name.matches("No Bank")) {
                    toolbar.setTitle(getString(R.string.app_name));
                    check1 = 2;

                } else {
                    toolbar.setTitle(bank_name);
                    check1 = 0;
                }
//                opBankBalance.setSelected(true);
//                opMyMoney.setSelected(false);
//                op_bank_bills.setSelected(false);

                break;
            case 1:

                if (mainOptionMenu != null) {
                    mainOptionMenu.findItem(R.id.action_refreshData).setVisible(true);
//                    mainOptionMenu.findItem(R.id.action_settings).setVisible(false);
                }
//                opBankBalance.setSelected(false);
//                op_bank_bills.setSelected(false);
//                opMyMoney.setSelected(true);

                //       toolbar.setTitle(getString(R.string.app_name));
                if (bank_name.matches("No Bank")) {
                    toolbar.setTitle(getString(R.string.app_name));
                    check1 = 2;
                } else {
                    toolbar.setTitle(bank_name);
                    check1 = 0;
                }

                break;
            case 2:

                if (mainOptionMenu != null) {
                    mainOptionMenu.findItem(R.id.action_refreshData).setVisible(false);
//                    mainOptionMenu.findItem(R.id.action_settings).setVisible(true);
                }
                if (bank_name.matches("No Bank")) {
                    toolbar.setTitle(getString(R.string.app_name));
                    check1 = 2;
                } else {
                    toolbar.setTitle(bank_name);
                    check1 = 0;
                }
//                opBankBalance.setSelected(false);
//                opMyMoney.setSelected(false);
//                op_bank_bills.setSelected(true);

                break;
        }
    }
/*
    public Fragment getForegroundFragment() {
        Fragment navHostFragment = getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment);
        return navHostFragment == null ? null : navHostFragment.getChildFragmentManager().getFragments().get(0);
    }*/


//    public void performBack() {
//        if (closeDrawer(false)) {
//            return;
//        }
//        if (!getRate()) {
////            ShowDailog();
//
//            RateMe(true);
//        } else {
////            if (AdmobAdManager.getInstance().mNativeRateAd != null /*||
////                AdmobAdManager.getInstance().mNativeRateAdApplovin != null*/) {
////                ExitDialogNative createPlaylistDialog = new ExitDialogNative();
////                createPlaylistDialog.show(getSupportFragmentManager(), createPlaylistDialog.getTag());
////            } else {
//                closeDialog();
////            }
//        }
//
//    }


    String feedback = "";

    private void showRateDailog(final boolean isFinish) {
        final View dialogView = View.inflate(drawerActivity.this, R.layout.dialog_say_thanks, null);
        final android.app.AlertDialog.Builder mAlertDialog = new android.app.AlertDialog.Builder(drawerActivity.this)
                .setView(dialogView)
                .setCancelable(true);

        final android.app.AlertDialog mAlertDialog1 = mAlertDialog.create();
        mAlertDialog1.setCancelable(true);
        mAlertDialog1.setCanceledOnTouchOutside(true);
        mAlertDialog1.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        TextView buttonPositive = (TextView) dialogView.findViewById(R.id.btn_rate_now);
        TextView buttonNegative = (TextView) dialogView.findViewById(R.id.btn_later);
        final ImageView img_reaction = (ImageView) dialogView.findViewById(R.id.img_reaction);
        final RatingBar rating_bar = (RatingBar) dialogView.findViewById(R.id.rating_bar);
        final LinearLayout lay_feedback = (LinearLayout) dialogView.findViewById(R.id.lay_feedback);
        final EditText txtfeedback = (EditText) dialogView.findViewById(R.id.txtfeedback);


        rating_bar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                if (rating == 1) {
                    bug = true;
                    img_reaction.setImageDrawable(getResources().getDrawable(R.drawable.rate_1));
                } else if (rating == 2) {
                    bug = true;
                    img_reaction.setImageDrawable(getResources().getDrawable(R.drawable.rate_2));
                } else if (rating == 3) {
                    bug = true;
                    img_reaction.setImageDrawable(getResources().getDrawable(R.drawable.rate_3));
                } else if (rating == 4) {
                    bug = false;
                    img_reaction.setImageDrawable(getResources().getDrawable(R.drawable.rate_4));
                } else if (rating == 5) {
                    bug = false;
                    img_reaction.setImageDrawable(getResources().getDrawable(R.drawable.rate_5));
                }
            }
        });

        buttonPositive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (bug) {
                    feedback = txtfeedback.getText().toString().trim();
                    reportBug(drawerActivity.this, "Feedback/Suggestion", feedback, rating_bar.getRating());
                    mAlertDialog1.dismiss();
                } else {
                    if (rating_bar.getRating() >= 1 && rating_bar.getRating() < 4) {
                        bug = true;
                        lay_feedback.setVisibility(View.VISIBLE);

                        txtfeedback.requestFocus();
                        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm.showSoftInput(txtfeedback, InputMethodManager.SHOW_IMPLICIT);

                    } else if (rating_bar.getRating() >= 4 && rating_bar.getRating() <= 5) {
                        bug = false;
                        showRate(drawerActivity.this);
                        mAlertDialog1.dismiss();
                    } else if (rating_bar.getRating() == 0.0f) {
                        Snackbar.make(dialogView, getString(R.string.rate_app_zero_star_error), Snackbar.LENGTH_SHORT).show();
                    } else {
                        bug = false;
                        showRate(drawerActivity.this);
                        mAlertDialog1.dismiss();
                    }
                }
            }
        });
        buttonNegative.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isFinish) {
                    Intent startMain = new Intent(Intent.ACTION_MAIN);
                    startMain.addCategory(Intent.CATEGORY_HOME);
                    startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(startMain);
                    finish();
                }
                mAlertDialog1.dismiss();
            }
        });
        mAlertDialog1.show();


    }

//    private void RateMe(Boolean isFromBack) {
//        hideDialog();
//
//        final View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_say_thanks, null);
//        TextView buttonPositive = dialogView.findViewById(R.id.btn_rate_now);
//        rating = 0f;
//
//        RotationRatingBar rotationratingbar_main = dialogView.findViewById(R.id.rotationratingbar_main);
//        ImageView img_rate_emoji = dialogView.findViewById(R.id.img_rate_emoji);
//        TextView txt_rate_title = dialogView.findViewById(R.id.txt_rate_title);
//        TextView txt_rate_message = dialogView.findViewById(R.id.txt_rate_message);
//        TextView btn_later = dialogView.findViewById(R.id.btn_later);
//        rotationratingbar_main.setOnRatingChangeListener(new BaseRatingBar.OnRatingChangeListener() {
//            @Override
//            public void onRatingChange(BaseRatingBar ratingBar, float rating1, boolean fromUser) {
//                rating = rating1;
//                if (rating1 < 4.0f) {
//                    bug = true;
//                } else {
//                    bug = false;
//                }
//                changeRateImogi(img_rate_emoji, txt_rate_title, txt_rate_message);
//            }
//        });
//
//        buttonPositive.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (bug) {
//                   /* if (feedback.isEmpty()) {
//                        Snackbar.make(dialogView, getString(R.string.empty_feedback), Snackbar.LENGTH_SHORT).show();
//                    } else {*/
//                    reportBug(drawerActivity.this, "Feedback/Suggestion", "feedback", rating);
//                    hideDialog();
////                    }
//                } else {
//                    if (rating >= 4 && rating <= 5) {
//                        SharedPreferences.Editor editor = getSharedPreferences("bank_select", MODE_PRIVATE).edit();
//                        editor.putBoolean("rateApp", true);
//                        editor.apply();
//                        showRate(drawerActivity.this);
//                        hideDialog();
//                    } else if (rating == 0f) {
//                        Snackbar.make(dialogView, getString(R.string.rate_app_zero_star_error), Snackbar.LENGTH_SHORT).show();
//                    } else {
//                        SharedPreferences.Editor editor = getSharedPreferences("bank_select", MODE_PRIVATE).edit();
//                        editor.putBoolean("rateApp", true);
//                        editor.apply();
//                        showRate(drawerActivity.this);
//                        hideDialog();
//                    }
//                }
//            }
//        });
//
//        btn_later.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                hideDialog();
//                if (isFromBack) {
//
//                    SharedPreferences.Editor editor = getSharedPreferences("bank_select", MODE_PRIVATE).edit();
//                    editor.putBoolean("rateApp", true);
//                    editor.apply();
//                    Constant.isShplashScreen = true;
//                    Constant.isFirsttimeshow = false;
//                    finishAffinity();
//                }
//            }
//        });
//
//        dialog = new AlertDialog.Builder(drawerActivity.this)
//                .setView(dialogView)
//                .setCancelable(true)
//                .show();
//
//        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
//    }


    public void showRate(Context mContext) {
        try {
            mContext.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + mContext.getPackageName())));
        } catch (ActivityNotFoundException e) {
            mContext.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + mContext.getPackageName())));
        }
    }


    private void hideDialog() {
        if (dialog != null) {
            if (dialog.isShowing()) {
                dialog.dismiss();
            }
            dialog = null;
        }
    }

    public void reportBug(Context context, String subject, String errorMessage, float ratingValue) {
        // Get App Version
        PackageInfo pInfo = null;
        try {
            pInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        String version = pInfo.versionName;

        // Device Name
        String deviceName = Build.MANUFACTURER + " " + Build.MODEL;

        // OS Version
        String osVersion = Build.VERSION.RELEASE;
        int osAPI = Build.VERSION.SDK_INT;

        // Get Country Name
        String country = "";
        try {
            TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            String countryCode = "";
            if (tm != null) {
                countryCode = tm.getNetworkCountryIso();
            }
            Locale loc = new Locale("", countryCode);
            country = loc.getDisplayCountry();
        } catch (Exception e) {
            e.printStackTrace();
        }

        HashMap<String, Boolean> mapPermission = new HashMap<>();


        Iterator<Map.Entry<String, Boolean>> mIterator = mapPermission.entrySet().iterator();
        String mExtraText = "";
        while (mIterator.hasNext()) {
            Map.Entry<String, Boolean> mEntry = mIterator.next();
            if (mEntry.getKey().trim().length() > 0) {
                mExtraText += (mEntry.getKey() + " : "
                        + (mEntry.getValue() ? "YES" : "NO") + "\n");
            }
        }

        String body = "Your message: " + errorMessage +
                "\n\nRating :" + ratingValue +
                "\nDevice Information - " + context.getResources().getString(R.string.app_name) +
                "\nVersion : " + version +
                "\nDevice Name : " + deviceName +
                "\nAndroid API : " + osAPI +
                "\nAndroid Version : " + osVersion +
                "\nCountry : " + country;
        //"\nExtraText : "+mExtraText;

        subject = subject + " " + context.getResources().getString(R.string.app_name);

        try {
            context.startActivity(
                    Intent.createChooser(
                            new Intent(
                                    Intent.ACTION_SENDTO,
                                    Uri.parse(
                                            "mailto:" + context.getResources().getString(R.string.email)
                                                    + "?cc=&subject=" + Uri.encode(subject).toString()
                                                    + "&body=" + Uri.encode(body)
                                    )
                            ), context.getString(R.string.email_choose_from_client)
                    )
            );

        } catch (ActivityNotFoundException ex) {

        }
    }


    private void changeRateImogi(ImageView rate_1, TextView txt_rate_title, TextView txt_rate_message) {
        switch ((int) rating) {
            case 2:
                rate_1.setImageDrawable(ContextCompat.getDrawable(drawerActivity.this, R.drawable.rate_2));
                txt_rate_title.setText(getResources().getString(R.string.rate_title_1));
                txt_rate_message.setText(getResources().getString(R.string.rate_desc_1));
                break;
            case 3:
                rate_1.setImageDrawable(ContextCompat.getDrawable(drawerActivity.this, R.drawable.rate_3));
                txt_rate_title.setText(getResources().getString(R.string.rate_title_1));
                txt_rate_message.setText(getResources().getString(R.string.rate_desc_1));
                break;
            case 4:
                rate_1.setImageDrawable(ContextCompat.getDrawable(drawerActivity.this, R.drawable.rate_4));
                txt_rate_title.setText(getResources().getString(R.string.rate_title_2));
                txt_rate_message.setText(getResources().getString(R.string.rate_desc_2));
                break;
            case 5:
                rate_1.setImageDrawable(ContextCompat.getDrawable(drawerActivity.this, R.drawable.rate_5));
                txt_rate_title.setText(getResources().getString(R.string.rate_title_2));
                txt_rate_message.setText(getResources().getString(R.string.rate_desc_2));
                break;
            default:
                rate_1.setImageDrawable(ContextCompat.getDrawable(drawerActivity.this, R.drawable.rate_1));
                txt_rate_title.setText(getResources().getString(R.string.rate_title_1));
                txt_rate_message.setText(getResources().getString(R.string.rate_desc_1));
                break;

        }
    }


    private void closeDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.AlertDialogTheme);
        builder.setMessage(getString(R.string.exit_warning2));
        builder.setCancelable(false);
        builder.setPositiveButton(getString(R.string.exit_yes), (dialogInterface, which) -> {
            dialogInterface.dismiss();
            Constant.isShplashScreen = false;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                finishAndRemoveTask();
            }
            finish();
            finishAffinity();

        });

        builder.setNegativeButton(getString(R.string.exit_cancel), (dialog, which) -> dialog.dismiss());

        builder.show();
    }


    public void putRate(boolean rate) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("rateApp", rate);
        editor.apply();
    }

    public boolean getRate() {
        if (sharedPreferences == null) {
            return true;
        }
        return sharedPreferences.getBoolean("rateApp", false);
    }

    private void ShowDailog() {
        final Dialog rateDialog = new Dialog(drawerActivity.this, R.style.WideDialog);
        rateDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        rateDialog.setCancelable(true);
        rateDialog.setContentView(R.layout.dialog_rate_us);
        rateDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        TextView btn_rate, btn_close;
        btn_rate = rateDialog.findViewById(R.id.btn_rate);
        btn_close = rateDialog.findViewById(R.id.btn_close);


        btn_rate.setOnClickListener(view -> {
            putRate(true);
            String url = "https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName();
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse(url));
            startActivity(i);
            rateDialog.dismiss();
        });
        btn_close.setOnClickListener(view -> {
            Constant.isShplashScreen = false;
            rateDialog.dismiss();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                finishAndRemoveTask();
            }
            finish();
            finishAffinity();
        });
        check1 = 1;
        rateDialog.show();
    }


    /*public void showInterstitialAd1(boolean b) {
        if (AdmobAdManager.getInstance().isNetworkAvailable(this)) {
            AdmobAdManager.getInstance().showProgress(this);

            if (AdmobAdManager.getInstance().isAdLoad) {
                new Handler(Looper.myLooper()).postDelayed(() -> {
                    AdmobAdManager.getInstance().dismissProgress(this);
                    AdmobAdManager.getInstance().loadInterstitialAd(this, getString(R.string.temp_adx_interstitial_id), 1, () -> {
                    });
                }, 500);

            } else {
                new Thread(() -> {
                    while (!AdmobAdManager.getInstance().isAdLoad && !AdmobAdManager.getInstance().isAdLoadFailed) {
                        Log.d("TAG", "showInterstitialAd: ");
                    }
                    runOnUiThread(() -> {
//                        new Handler(Looper.myLooper()).postDelayed(() -> {
                        AdmobAdManager.getInstance().dismissProgress(this);
                        AdmobAdManager.getInstance(drawerActivity1.this).loadInterstitialAd(drawerActivity1.this, getString(R.string.temp_adx_interstitial_id), 1, () -> {
                        });
//                        }, 500);

                    });
                }).start();
            }
        }
    }*/

/*
    public void showInterstitialAds() {
        if (AdmobAdManager.getInstance().isNetworkAvailable(this)) {

            if (AdmobAdManager.getInstance().isAdLoad) {
                startActivity(new Intent(this, AdsLoadActivity.class));
            } else {
                new Thread(() -> {
                    if (!PreferenceHelper.getFromBooleans(this, Constant.LANG_SELECTED, false)) {
                        startActivity(new Intent(this, LanguageSelectActivity.class).putExtra("isFromSetting", false));
                    }
                    while (!AdmobAdManager.getInstance().isAdLoad &&
                            !AdmobAdManager.getInstance().isAdLoadFailed) {
                        Log.d("TAG", "showInterstitialAd: ");
                    }
                    while (!PreferenceHelper.getFromBooleans(this, Constant.LANG_SELECTED, false)) {
                        Log.d("TAG", "showInterstitialAd: ");
                    }
                    runOnUiThread(() -> {
//                        new Handler(Looper.myLooper()).postDelayed(() -> {
                        startActivity(new Intent(this, AdsLoadActivity.class));
//                        }, 500);
                    });
                }).start();
            }
        }
    }*/
}
