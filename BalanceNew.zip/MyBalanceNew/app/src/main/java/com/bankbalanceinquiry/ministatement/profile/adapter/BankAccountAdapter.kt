package com.bankbalanceinquiry.ministatement.profile.adapter

import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.adsutil.admob.NativeAdHelper
import com.adconfig.adsutil.admob.NativeLayoutType
import com.bankbalanceinquiry.ministatement.databinding.ListItemProfileBinding
import com.bankbalanceinquiry.ministatement.profile.data.BankAccount
import com.bankbalanceinquiry.ministatement.utils.TextDrawable
import java.util.LinkedList
import java.util.Random

class BankAccountAdapter(val bankAccountList :ArrayList<Any>,private val onItemClicked: (BankAccount, Int) -> Unit) :
    RecyclerView.Adapter<BankAccountAdapter.BankAccountViewHolder>() {

//    private val bankAccountList = ArrayList<BankAccount>()

    class BankAccountViewHolder(private var binding: ListItemProfileBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bindAds() {
            NativeAdHelper(
                binding.adsView.context,
                binding.adsView,
                NativeLayoutType.NativeBanner,
                null,
                ""
            ).loadAd()
        }

        fun bind(item: BankAccount) {
            binding.adsView.visibility=View.GONE
            val color = Color.argb(
                255,
                Random().nextInt(256),
                Random().nextInt(256),
                Random().nextInt(256)
            )
//            val drawable = TextDrawable.builder()
//                .buildRoundRect(item.bankName.substring(0, 1), color, 8)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                binding.bankLogo2.backgroundTintList= ColorStateList.valueOf(
                    color
                )
            }
            binding.bankLogo2.text=item.bankName.substring(0,1)
//            binding.bankLogo2.setImageDrawable(drawable)
            binding.title.text = item.bankName
            binding.holderName.text = item.accountHolderName
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BankAccountViewHolder {
        return BankAccountViewHolder(
            ListItemProfileBinding.inflate(
                LayoutInflater.from(
                    parent.context
                )
            )
        )
    }

    override fun getItemCount(): Int {
        return bankAccountList.size
    }

    override fun onBindViewHolder(holder: BankAccountViewHolder, position: Int) {
        val current = bankAccountList[position]
        if(current is BankAccount) {
            holder.itemView.setOnClickListener {
                onItemClicked(current, 0)
            }
            holder.bind(current)
        } else {
            holder.bindAds()
        }
    }
}