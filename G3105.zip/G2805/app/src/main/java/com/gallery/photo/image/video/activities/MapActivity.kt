package com.gallery.photo.image.video.activities

import android.Manifest
import android.annotation.SuppressLint
import android.annotation.TargetApi
import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.IntentSender
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PorterDuff
import android.location.Address
import android.location.Geocoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.google.android.gms.common.api.GoogleApiClient
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.LocationSettingsRequest
import com.google.android.gms.location.LocationSettingsStatusCodes
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CircleOptions
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.shape.MaterialShapeDrawable
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.adapter.PlaceAdapter
import com.gallery.photo.image.video.base.BaseActivity
import com.gallery.photo.image.video.customview.MyGridLayoutManager
import com.gallery.photo.image.video.database.AppDatabase
import com.gallery.photo.image.video.database.LocationEntity
import com.gallery.photo.image.video.databinding.ActivityMapsBinding
import com.gallery.photo.image.video.model.AlbumData
import com.gallery.photo.image.video.model.PictureData
import com.gallery.photo.image.video.model.PlaceData
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.LocationHelper
import com.gallery.photo.image.video.utils.Preferences
import java.io.File
import java.util.Locale

class MapActivity : BaseActivity(), OnMapReadyCallback, GoogleMap.OnCameraMoveListener,
    GoogleMap.OnCameraMoveCanceledListener {

    private var googleMap: GoogleMap? = null
    lateinit var dataBase: AppDatabase
    var albumList: ArrayList<PlaceData> = ArrayList()

    private var mCurrentLocation: LatLng? = null
    private var enterCameraListener: Boolean = false
    private val ZOOM: Float = 16.0F
    private var mapSupport: SupportMapFragment? = null
    private lateinit var mFusedLocationProviderClient: FusedLocationProviderClient
    private lateinit var mLocationRequest: LocationRequest

    private var timer: CountDownTimer? = null
    private var backgroundDrawable: MaterialShapeDrawable? = null
    private lateinit var preferences: Preferences
    private var settingsClicked = false

    companion object {
        private val LOCATION_PERMISSION = 1234
        private val UPDATE_INTERVAL = (6 * 1000).toLong()  /* 6 secs */
        private val FASTEST_INTERVAL: Long = 0 /* 1 sec */
        private val REQUEST_GRANTED = 1235
        private val REQUEST_CHECK_SETTINGS = 1236
    }

    lateinit var binding: ActivityMapsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        if(preferences.isNeedInterAd) {
            AdmobIntersAdImpl().load(this)
        }

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        dataBase = AppDatabase.getInstance(this)

        initView()
//        binding.map.onCreate(savedInstanceState)

        setBottomSheetCallback()
        //map initialization
        initializeMap()
//        materialShape()

    }
    private fun setBottomSheetCallback() {
        val params: CoordinatorLayout.LayoutParams = binding.bottomSheetLayout.layoutParams as CoordinatorLayout.LayoutParams
        val bottomSheetBehavior = BottomSheetBehavior.from(binding.bottomSheetLayout)
        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED)
        bottomSheetBehavior.addBottomSheetCallback(mBottomSheetBehaviorCallback)
        params.behavior = bottomSheetBehavior
    }

    private fun initView() {

        binding.loutToolbar.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.loutToolbar.txtTitle.text= getString(R.string.geographic_photo)


    }

    override fun onBackPressed() {

        if (preferences.isNeedInterAd) {

            AdsConfig.showInterstitialAd(this) {
                if(it) preferences.isNeedInterAd = false
                finish()
            }
        } else {
            super.onBackPressed()
        }
    }

    private fun initializeMap() {
        mapSupport = SupportMapFragment
            .newInstance(
//                GoogleMapOptions().camera(
//                    CameraPosition(
//                        LatLng(19.0760, 72.8777),
//                        16f,
//                        30f,
//                        112.5f
//                    )
//                )
            )

        mapSupport?.let {
            supportFragmentManager.beginTransaction().replace(R.id.mapFragmentPickup, it)
                .commit()
        }

        mFusedLocationProviderClient =
            LocationServices.getFusedLocationProviderClient(this)
        mLocationRequest = LocationRequest.create()
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
        mLocationRequest.fastestInterval = FASTEST_INTERVAL
        mLocationRequest.interval = UPDATE_INTERVAL
        mLocationRequest.numUpdates = 1
        locationChecks()
        checkLocationServiceAndGetMapAsync()
    }

    private fun checkLocationServiceAndGetMapAsync() {
        val locationManager = getSystemService(Context.LOCATION_SERVICE)
        if (locationManager != null) {
            mapSupport?.getMapAsync(this)
        }
    }

    private fun initData() {

        dataBase.dataDao().getLocationLiveEntityList()
            .observe(this) { places: List<LocationEntity> ->
                sortImage(places)
            }

//        Observable.fromCallable {
//            getAllImagesFromGallery()
//            true
//        }.subscribeOn(Schedulers.io())
//            .doOnError { _: Throwable? ->
//                Log.e("MapExploreActivity", "getAllImagesFromGallery:::getImageOnMap.001")
////                activity?.runOnUiThread {
////                    sortImage()
////                    getImageOnMap()
////                }
//            }
//            .subscribe { _: Boolean? ->
//                Log.e("MapExploreActivity", "getAllImagesFromGallery:::getImageOnMap.002")
////                runOnUiThread {
////                    val placeList = dataBase.dataDao().getLocationEntityList()
////                    sortImage(placeList)
////                sortImage(places)
////                    getImageOnMap()
////                }
//            }
    }

    override fun onResume() {
        super.onResume()

        if (settingsClicked) {
            settingsClicked = false
            if (LocationHelper.locationPermissionGranted(this@MapActivity)) {

                if (LocationHelper.checkLocationSettings(this@MapActivity)) {
                    requestAndUpdateLocation()
                } else {
                    displayLocationSettingsRequest()
                }
            } else {
                locationChecks()
            }
        }

    }

    @TargetApi(Build.VERSION_CODES.M)
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            LOCATION_PERMISSION -> {
                if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                    if (LocationHelper.checkLocationSettings(this)) {
                        requestAndUpdateLocation()
                    } else {
                        displayLocationSettingsRequest()
                    }
                } else {
                    if (ActivityCompat.shouldShowRequestPermissionRationale(
                            this,
                            Manifest.permission.ACCESS_FINE_LOCATION
                        )
                    ) {
                        // user denied permission but not permanently
                        showPermissionDeniedDialog(
                            getString(R.string.location_permission_denied),
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            resources.getString(R.string.permission_denied_address_location)
                        )

                    } else {
                        showPermissionEvokedDialog(
                            getString(R.string.location_permission_invoked),
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            resources.getString(R.string.permission_invoked_address_location)
                        )
                    }
                }

            }
        }
    }

    fun showPermissionDeniedDialog(dialogTitle: String, permission: String, dialogMsg: String) {
        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder.setTitle(dialogTitle)
            .setMessage(dialogMsg)
            .setPositiveButton("Retry", DialogInterface.OnClickListener
            { dialog, which ->
                if (permission.equals(Manifest.permission.ACCESS_FINE_LOCATION)) {
                    requestPermissions(
                        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                        LOCATION_PERMISSION
                    )
                }
                dialog.dismiss()

            })
            .setIcon(android.R.drawable.ic_dialog_alert)
            .setCancelable(false)
            .show()
    }

    fun showPermissionEvokedDialog(dialogTitle: String, permission: String, dialogMsg: String) {
        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder.setTitle(dialogTitle)
            .setMessage(dialogMsg)
            .setPositiveButton("Settings", DialogInterface.OnClickListener
            { dialog, which ->
                if (permission.equals(Manifest.permission.ACCESS_FINE_LOCATION)) {
                    settingsClicked = true
                }

                val intent = Intent()
                intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                intent.data = Uri.fromParts("package", applicationContext?.packageName, null)
                startActivity(intent)
                dialog.dismiss()
            })

            .setIcon(android.R.drawable.ic_dialog_alert)
            .setCancelable(false)
            .show()

    }

    var albumAdapter: PlaceAdapter? = null
    fun getImageOnMap() {

        albumAdapter = PlaceAdapter(this, albumList,
            clickListener = {
                val albumData = albumList[it]
                openImageList(albumData)
            })

//        binding.recyclerViewPlace.layoutManager = GridLayoutManager(this, 3)
//        binding.recyclerViewPlace.setHasFixedSize(false)

        binding.recyclerViewPlace.adapter = albumAdapter
        val layoutManager = binding.recyclerViewPlace.layoutManager as MyGridLayoutManager
        layoutManager.orientation = RecyclerView.VERTICAL
        (binding.recyclerViewPlace.layoutManager as MyGridLayoutManager).spanCount =3


        Log.e("MapExploreActivity", "getImageOnMap:::albumWisePictures:${albumList.size}")
        if (albumList != null && albumList.size > 0) {
            albumList.forEach { album ->
//          for (album in albumList) {
                addMarker(album)
            }
        }

    }

    private fun openImageList(placeList: PlaceData) {

        Constant.albumData = AlbumData(
            placeList.place,
            placeList.pictureData,
            "",
            0,
            0,
            isCustomAlbum = true
        )
        startActivity(Intent(this, ImageListActivity::class.java))
    }

    private fun sortImage(placeList: List<LocationEntity>) {
//        val placeList = dataBase.dataDao().getLocationEntityList()
        Log.e("MapExploreActivity", "sortImage:::placeList.${placeList.size}")
        placeList.forEach { data ->

            val strKey = data.title

            var imagesData1: ArrayList<PictureData> = ArrayList()

            val file = File(data.path)
            val pictureData = PictureData(
                file.path,
                file.name,
                file.parentFile.name,
                file.lastModified(),
                file.lastModified(),
                file.length()
            )
            for (i in albumList.indices) {
                if (albumList[i].place == strKey) {
                    albumList[i].pictureData.add(pictureData)
                }
            }

            if (albumList.filter { it.place == strKey }.isNullOrEmpty()) {
                imagesData1.add(pictureData)
                val placeData = PlaceData(imagesData1, data.title, data.latitude, data.longitude)
                albumList.add(placeData)
            }
        }

        getImageOnMap()
    }

    private fun addMarker(album: PlaceData) {
        val lat = album.lati.toDouble()
        val lng = album.long.toDouble()
        if (lat != null && lng != null) {
            val location = LatLng(lat, lng)

            Log.e("MapExploreActivity", "getImageOnMap:::addMarker==>lat:${lat}, lng:${lng}")

            val marker = googleMap?.addMarker(
                MarkerOptions()
                    .position(location)
                    .icon(
                        BitmapDescriptorFactory.fromBitmap(
                            getMarkerBitmapFromView(album.pictureData.firstOrNull()!!.filePath,album.pictureData.size)
                        )
                    )
            )
            googleMap?.moveCamera(CameraUpdateFactory.newLatLng(location))

            val maxZoom = 100.0f
            if (googleMap?.cameraPosition!!.zoom > maxZoom) googleMap?.animateCamera(
                CameraUpdateFactory.zoomTo(
                    maxZoom
                )
            )

            marker?.tag = album.place

        }
    }

    private fun getMarkerBitmapFromView(photoPath: String,size:Int): Bitmap {
        val customMarkerView: View =
            (getSystemService(AppCompatActivity.LAYOUT_INFLATER_SERVICE) as LayoutInflater).inflate(
                R.layout.custom_marker,
                null
            )
        val markerImageView = customMarkerView.findViewById<View>(R.id.profile_image) as ImageView
        val markerCounter = customMarkerView.findViewById<View>(R.id.txtCount) as TextView
        markerCounter.text="$size"

        val options = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }

        val bitmap = BitmapFactory.decodeFile(photoPath, options)
        markerImageView.setImageBitmap(bitmap)

        customMarkerView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        customMarkerView.layout(
            0,
            0,
            customMarkerView.measuredWidth,
            customMarkerView.measuredHeight
        )
        customMarkerView.buildDrawingCache()
        val returnedBitmap = Bitmap.createBitmap(
            customMarkerView.measuredWidth, customMarkerView.measuredHeight,
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(returnedBitmap)
        canvas.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN)
        val drawable = customMarkerView.background
        drawable?.draw(canvas)
        customMarkerView.draw(canvas)
        return returnedBitmap
    }

//    private fun getAllImagesFromGallery() {
//        val projection = arrayOf(
//            MediaStore.Images.Media._ID,
//            MediaStore.Images.Media.DATA,
//            MediaStore.MediaColumns.TITLE,
//            MediaStore.Images.Media.SIZE
////            , MediaStore.Images.ImageColumns.LATITUDE, MediaStore.Images.ImageColumns.LONGITUDE
//        )
//        val orderBy = MediaStore.Video.Media.DATE_TAKEN
//        val cursor: Cursor = contentResolver.query(
//            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
//            projection,
//            null,
//            null,
//            "$orderBy DESC"
//        )!!
//
////        val idIndex = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
//        val pathIndex = cursor.getColumnIndex(MediaStore.MediaColumns.DATA)
//
//        albumList.clear()
//
//        while (cursor.moveToNext()) {
//            val filePath = cursor.getString(pathIndex)
//            var latLong = FloatArray(2)
//
//            val entity = dataBase.dataDao().getLocationEntity(filePath)
//
//            if (entity == null) {
//                try {
////                    val inputStream: InputStream = requireContext().contentResolver.openInputStream(photoUri) ?: continue
//                    val exifInterface = ExifInterface(filePath)
//                    exifInterface.getLatLong(latLong)
////                    inputStream.close()
//                } catch (e: IOException) {
//                } catch (e: UnsupportedOperationException) {
//                }
//
//                if (latLong[0] != 0f && latLong[1] != 0f) {
//
//                    var latLongToAddressString = ""
//                    latLongToAddressString = latLongToAddressString(
//                        latLong[0],
//                        latLong[1]
//                    )
//
//                    dataBase.dataDao().insertLocationEntity(
//                        LocationEntity(
//                            0,
//                            latLongToAddressString,
//                            filePath,
//                            latLong[0],
//                            latLong[1]
//                        )
//                    )
//                    Log.i(
//                        "MapExploreActivity", "004.latLongToAddressString：" + latLongToAddressString
//                    )
//                }
//            }
//        }
//        cursor.close()
//    }

    private fun latLongToAddressString(latitude: Float, longitude: Float): String {
        var addressString = ""
        val geocoder = Geocoder(this, Locale.getDefault())
        try {
            val addresses: List<Address>? =
                geocoder.getFromLocation(latitude.toDouble(), longitude.toDouble(), 1)
            if (addresses != null) {
                val returnedAddress: Address = addresses[0]
                val strReturnedAddress = StringBuilder("")

                Log.w(
                    "MapExploreActivity",
                    "addressline:::==================================================="
                )
                Log.w(
                    "MapExploreActivity",
                    "addressline:::adminArea==>:${returnedAddress.adminArea}"
                )
                Log.w(
                    "MapExploreActivity",
                    "addressline:::featureName==>:${returnedAddress.featureName}"
                )
                Log.w("MapExploreActivity", "addressline:::locality==>:${returnedAddress.locality}")
                Log.w(
                    "MapExploreActivity",
                    "addressline:::subLocality==>:${returnedAddress.subLocality}"
                )
                Log.w(
                    "MapExploreActivity",
                    "addressline:::countryName==>:${returnedAddress.countryName}"
                )
                Log.w(
                    "MapExploreActivity",
                    "addressline:::subAdminArea==>:${returnedAddress.subAdminArea}"
                )
                Log.w("MapExploreActivity", "addressline:::premises==>:${returnedAddress.premises}")


                if (returnedAddress.subLocality != null) {
                    strReturnedAddress.append(returnedAddress.subLocality)
                } else if (returnedAddress.locality != null) {
                    strReturnedAddress.append(returnedAddress.locality)
                }

                addressString = strReturnedAddress.toString()
            }
        } catch (e: Exception) {
            Log.e("printStackTrace","printStackTrace:$e")
        }
        return addressString
    }

    override fun onMapReady(p0: GoogleMap) {
        this.googleMap = p0
        googleMap?.uiSettings?.isCompassEnabled = false
        googleMap?.setOnCameraMoveListener(this)
        googleMap?.setOnCameraMoveCanceledListener(this)
        initData()

        googleMap?.setOnMarkerClickListener { marker ->
            val markerTag = marker.tag as? String
            Log.e("MapExploreActivity", "MarkerClickListener.markerTag::$markerTag")
            for (album in albumList) {
                Log.e("MapExploreActivity", "MarkerClickListener.place::${album.place}")
            }
            val albumData = albumList.firstOrNull { it.place == markerTag }!!
            openImageList(albumData)
//            setBackAlbumData()
            true
        }
    }

    override fun onCameraMove() {

    }

    override fun onCameraMoveCanceled() {

    }

    private fun locationChecks() {
        if (LocationHelper.locationPermissionGranted(this)) {
            if (LocationHelper.checkLocationSettings(this)) {
                requestAndUpdateLocation()
            } else {
                displayLocationSettingsRequest()
            }
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), LOCATION_PERMISSION)
            }
        }
    }

    fun requestAndUpdateLocation() {
        try {
//            binding.bottomSheetLayout.areaFromMap.text = "Requesting Location.."
            mFusedLocationProviderClient.requestLocationUpdates(mLocationRequest, locationCallback, Looper.myLooper())

        } catch (e: SecurityException) {
            Log.e("Exception: %s", e.message ?: "")

        }
    }

    val locationCallback = object : LocationCallback() {
        override fun onLocationResult(locationResult: LocationResult?) {
            locationResult?.let {
                if (it.locations.size >0) {

                    val location = it.locations.get(0)
                    location?.let {

                        mCurrentLocation = LatLng(location.latitude ?: 0.0, location.longitude ?: 0.0)
                        setMapAddress()
                    }

                } else {
                    mCurrentLocation = LatLng(it.lastLocation.latitude ?: 0.0, locationResult.lastLocation?.longitude ?: 0.0)
                    setMapAddress()
                }

            }
        }
    }
    fun locationPermissionGranted(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun getMapAddressText(latLng: LatLng) {
        timer?.cancel()
        timer = object : CountDownTimer(800, 100) {
            override fun onFinish() {
//                if (Helper.isConnectedToInternet()) {
                    /*model.getLocationTextFromLatLong(latLng)*/
                    mCurrentLocation = latLng
//                    binding.bottomSheetLayout.areaFromMap.text = "Locating..."
//                }
            }

            override fun onTick(p0: Long) {
            }

        }
        timer?.start()
    }

    @SuppressLint("MissingPermission")
    fun setMapAddress(noCameraListener: Boolean = false) {
        if (mCurrentLocation != null && googleMap != null) {
            if (!enterCameraListener) {
                googleMap?.animateCamera(CameraUpdateFactory.newLatLngZoom(mCurrentLocation!!, ZOOM))
                enterCameraListener = true
                if (locationPermissionGranted()) {
                    googleMap?.isMyLocationEnabled = false
                    //if(mapSupport!=null) {
//                    val mapView = mapSupport?.view
//                    mapView?.findViewById<View>(Integer.parseInt("1"))?.parent?.let {
//                        val locationButton = (it as View).findViewById<View>(Integer.parseInt("2"))
//                        val rlp = locationButton.layoutParams as (RelativeLayout.LayoutParams)
//                        // position on right bottom
//                        rlp.addRule(RelativeLayout.ALIGN_PARENT_TOP, 0)
//                        rlp.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM, RelativeLayout.TRUE)
//                        rlp.setMargins(0, 0, 30, 30)
//                    }
                    // }
                }
                googleMap?.uiSettings?.isCompassEnabled = false
                googleMap?.addCircle(
                    CircleOptions()
                        .center(mCurrentLocation!!)
                        .radius(10.0)
                        .strokeColor(0x55067dcc)
                        .strokeWidth(1f)  // Border color of the circle
                        .fillColor(0x55769fc7))

                googleMap?.setOnCameraIdleListener {
                    googleMap?.let {
                        mCurrentLocation = LatLng(
                            it.cameraPosition.target.latitude,
                            it.cameraPosition.target.longitude
                        )
                        getMapAddressText(
                            LatLng(
                                it.cameraPosition.target.latitude,
                                it.cameraPosition.target.longitude
                            )
                        )

                    }
                }
            }
        } else {
            if (mCurrentLocation == null) {
                requestAndUpdateLocation()
                //getLocation
            }
        }
    }

    fun displayLocationSettingsRequest() {
        val googleApiClient = GoogleApiClient.Builder(this)
            .addApi(LocationServices.API)
            .build()
        googleApiClient.connect()
        val builder = LocationSettingsRequest.Builder().addLocationRequest(mLocationRequest)
        builder.setAlwaysShow(true)
        val result = LocationServices.SettingsApi.checkLocationSettings(googleApiClient, builder.build())
        result.setResultCallback {
            val status = it.status
            when (status.statusCode) {
                LocationSettingsStatusCodes.SUCCESS -> {
                    Log.i("LocationSettings", "Successfully enabled")
                    try {
                        status.startResolutionForResult(this, REQUEST_GRANTED)
                    } catch (e: IntentSender.SendIntentException) {
                        Log.i("LocationSettings", "PendingIntent unable to execute request.");
                    }
                }
                LocationSettingsStatusCodes.RESOLUTION_REQUIRED -> {
                    try {
                        status.startResolutionForResult(this, REQUEST_CHECK_SETTINGS);
                    } catch (e: IntentSender.SendIntentException) {
                        Log.i("LocationSettings", "PendingIntent unable to execute request.");
                    }
                    Log.i("LocationSettings", "Location settings are not satisfied.")
                }
            }
        }
    }

    val mBottomSheetBehaviorCallback = object : BottomSheetBehavior.BottomSheetCallback() {
        override fun onSlide(bottomSheet: View, slideOffset: Float) {
            val params = CoordinatorLayout.LayoutParams(
                CoordinatorLayout.LayoutParams.MATCH_PARENT,
                CoordinatorLayout.LayoutParams.MATCH_PARENT)
            params.setMargins(0, 0, 0, (slideOffset * bottomSheet.height).toInt())
            params.anchorId = R.id.bottomSheetLayout
            binding.mapFragmentPickup.layoutParams = params

//            val paramsPointer = CoordinatorLayout.LayoutParams(
//                CoordinatorLayout.LayoutParams.WRAP_CONTENT,
//                CoordinatorLayout.LayoutParams.WRAP_CONTENT)
//            paramsPointer.gravity = Gravity.CENTER
//            paramsPointer.setMargins(0, 0, 0, (slideOffset * bottomSheet.height).toInt() + (resources.getDimension(R.dimen.margin_large).toInt()))
//            binding.mapPointerIcon.layoutParams = paramsPointer


        }


        override fun onStateChanged(bottomSheet: View, newState: Int) {

        }

    }

}