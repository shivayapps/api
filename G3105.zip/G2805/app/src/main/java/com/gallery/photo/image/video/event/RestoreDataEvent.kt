package com.gallery.photo.image.video.event

import com.gallery.photo.image.video.model.RestoreData
import java.util.ArrayList

data class RestoreDataEvent(var restoreList: ArrayList<RestoreData>)
