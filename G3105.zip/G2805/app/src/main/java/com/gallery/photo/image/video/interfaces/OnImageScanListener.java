package com.gallery.photo.image.video.interfaces;

public interface OnImageScanListener {
    void onImageScan(int value);
    void onScanCompleted();
}