package com.gallery.photo.image.video.recover

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.gallery.photo.image.video.databinding.ItemPictureBinding
import com.gallery.photo.image.video.extension.beGone
import com.gallery.photo.image.video.extension.beVisible
import com.gallery.photo.image.video.model.PictureData

class RecoverAdapter(val context: Context,
                     var pictures: ArrayList<PictureData>, private val listener: View.OnClickListener? = null) :
    RecyclerView.Adapter<RecoverAdapter.Holder>(

    ) {

    inner class Holder(val binding: ItemPictureBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        Holder(ItemPictureBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount(): Int {
        return pictures.size
    }


    override fun onBindViewHolder(holder: Holder, position: Int) {
        holder.binding.apply {
            val item = pictures[holder.adapterPosition]
//            tvPath.text=item.file.path
//            tvPath.isSelected=true

            Glide.with(context).load(item.filePath)
                .into(image)
//            ivImage.loadImageFile(item.file){
//                ivDefaultImage.gone()
//            }
            if (item.isSelected) {
                icSelect.beVisible()
                icUnSelect.beGone()
            } else {
                icSelect.beGone()
                icUnSelect.beVisible()
            }
            root.setOnClickListener {
                pictures[holder.adapterPosition].isSelected = !item.isSelected
                notifyItemChanged(holder.adapterPosition)
                listener?.onClick(it.apply { tag = pictures[holder.adapterPosition] })
            }
        }
    }
}

//class ImageDiffUtils : DiffUtil.ItemCallback<FileModel>() {
//    override fun areItemsTheSame(oldItem: FileModel, newItem: FileModel): Boolean {
//        return oldItem.isSelected == newItem.isSelected
//    }
//
//    override fun areContentsTheSame(oldItem: FileModel, newItem: FileModel): Boolean {
//        return oldItem.file.absolutePath.equals(newItem.file.absolutePath) && oldItem.isSelected==newItem.isSelected
//    }
//}

