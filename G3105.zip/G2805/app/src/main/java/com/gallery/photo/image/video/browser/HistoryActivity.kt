package com.gallery.photo.image.video.browser

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.gallery.photo.image.video.browser.adapter.WebHistoryDataAdapter
import com.gallery.photo.image.video.browser.database.DataBaseClass
import com.gallery.photo.image.video.browser.model.Secure_MediaDataModal
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.base.BaseActivity
import com.gallery.photo.image.video.databinding.ActivityHistoryBinding
import com.gallery.photo.image.video.dialog.ConfirmationDialog
import com.gallery.photo.image.video.utils.Constant

class HistoryActivity : BaseActivity() {

    lateinit var binding: ActivityHistoryBinding
    lateinit var secureDataBaseClass: DataBaseClass
    var historyList: ArrayList<Secure_MediaDataModal> = ArrayList()
    var isRefreshList = false
    var isOpenHistory: Boolean = false
    var secureHistoryAdapter: WebHistoryDataAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        intView()
    }

    private fun intView() {
        isOpenHistory = intent.getBooleanExtra(Constant.EXTRA_IS_OPEN_HISTORY, false)

        secureDataBaseClass = DataBaseClass(this, this)


        binding.txtTitle.text =
            getString(if (isOpenHistory) R.string.history else R.string.Bookmark)

        binding.icDeleteBrowser.setImageDrawable(
            ContextCompat.getDrawable(
                this,
                R.drawable.ic_delete_select
            )
        )

        binding.icDeleteBrowser.visibility = View.INVISIBLE
        binding.icSelect.visibility = View.GONE
        binding.ivDone.visibility = View.GONE

        binding.nodats.text =
            getString(if (isOpenHistory) R.string.no_data_history else R.string.no_data_bookmark)

        if (isOpenHistory)
            setHistoryList()
        else
            setBookmarkList()

        intListener()
        setNoDataView()
    }

    private fun setHistoryList() {
        val arrayList: ArrayList<Secure_MediaDataModal> = secureDataBaseClass.historyList
        historyList.addAll(arrayList)
        if (historyList.size != 0) {
            historyList.reverse()
            secureHistoryAdapter =
                WebHistoryDataAdapter(historyList, this, binding.rvHistory, 0, clickListener = {
                    loadUrl(it)
                }, deleteListener = {
                    isRefreshList = true
                    setNoDataView()
                })
            val linearLayoutManager = LinearLayoutManager(this)
            binding.rvHistory.layoutManager = linearLayoutManager
            binding.rvHistory.adapter = secureHistoryAdapter
        }
    }

    private fun loadUrl(url: String) {
        val intent = Intent()
        intent.putExtra(Constant.EXTRA_OPEN_URL, url)
        setResult(Activity.RESULT_OK, intent)
        finish()
    }

    private fun setBookmarkList() {
        val arrayList: ArrayList<Secure_MediaDataModal> = secureDataBaseClass.bookmarkList
        historyList.addAll(arrayList)
        if (historyList.size != 0) {
            historyList.reverse()
            val secureHistoryAdapter =
                WebHistoryDataAdapter(historyList, this, binding.rvHistory, 1, clickListener = {
                    loadUrl(it)
                }, deleteListener = {
                    isRefreshList = true
                    setNoDataView()
                })
            val linearLayoutManager = LinearLayoutManager(this)
            binding.rvHistory.layoutManager = linearLayoutManager
            binding.rvHistory.adapter = secureHistoryAdapter
        }
    }

    private fun setNoDataView() {
        if (historyList.size == 0) {
            binding.nodats.visibility = View.VISIBLE
            binding.rvHistory.visibility = View.GONE
            binding.icDeleteBrowser.visibility = View.INVISIBLE
        } else {
            binding.nodats.visibility = View.GONE
            binding.rvHistory.visibility = View.VISIBLE
            binding.icDeleteBrowser.visibility = View.VISIBLE
        }
    }

    private fun intListener() {
        binding.icBack.setOnClickListener { onBackPressed() }
        binding.icDeleteBrowser.setOnClickListener {
            val deleteDialog = ConfirmationDialog(
                this,
                getString(R.string.clear_all),
                getString(if (isOpenHistory) R.string.cleare_history_msg else R.string.clear_bookmark_msg),
                getString(R.string.clear),
                positiveBtnClickListener = {
                    if (isOpenHistory)
                        secureDataBaseClass.allDeletesHistory()
                    else
                        secureDataBaseClass.allDeletesBookMark()
                    historyList.clear()
                    if (secureHistoryAdapter != null)
                        secureHistoryAdapter?.notifyDataSetChanged()
                    setNoDataView()
                }
            )
            deleteDialog.show(supportFragmentManager, deleteDialog.tag)
        }
    }
}