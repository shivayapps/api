package com.gallery.photo.image.video.dialog

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Point
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.core.content.FileProvider
import androidx.core.widget.addTextChangedListener
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.DialogEdittextBinding
import com.gallery.photo.image.video.extension.toast

class EditTextDialog(
    var mContext: Activity,
    var mTitle: String,
    val btnClickListener: (stringText: String) -> Unit
) : BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogEdittextBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogEdittextBinding.inflate(layoutInflater, container, false)
        intView()
        intListener()
        return bindingDialog.root
    }


    private fun intView() {


    }

    private fun intListener() {

        bindingDialog.btnCancel.setOnClickListener { dismiss() }

        bindingDialog.btnOk.setOnClickListener {
            val str=bindingDialog.edtText.text.toString().trim()
            if(str.isNotEmpty()) {
                btnClickListener.invoke(str)
                dismiss()
            } else {
                mContext.toast("Please enter valid text")
            }
        }
    }


    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}

