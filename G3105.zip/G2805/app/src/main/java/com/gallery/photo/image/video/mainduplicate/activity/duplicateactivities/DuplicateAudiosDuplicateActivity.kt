package com.gallery.photo.image.video.mainduplicate.activity.duplicateactivities

import android.annotation.SuppressLint
import android.app.Activity
import android.content.DialogInterface
import android.content.Intent
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.text.Html
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityOptionsCompat
import androidx.documentfile.provider.DocumentFile
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.mainduplicate.activity.scanningactivities.ScanningDuplicateActivity
import com.gallery.photo.image.video.mainduplicate.adapter.IndividualAudiosAdapter
import com.gallery.photo.image.video.mainduplicate.callbacks.MarkedListener
import com.gallery.photo.image.video.mainduplicate.model.DuplicateFileRemoverSharedPreferences
import com.gallery.photo.image.video.mainduplicate.model.IndividualGroupModel
import com.gallery.photo.image.video.mainduplicate.model.ItemDuplicateModel

import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activities.HomeActivity
import com.gallery.photo.image.video.base.BaseActivity
import com.gallery.photo.image.video.databinding.ActivityDuplicateAudiosBinding

import com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions
import com.gallery.photo.image.video.mainduplicate.model.PopUp
import com.gallery.photo.image.video.mainduplicate.utils.MyUtils
import com.gallery.photo.image.video.mainduplicate.utils.ShareConstants
import com.gallery.photo.image.video.mainduplicate.utils.SharedPrefsConstant

import java.util.*

@SuppressLint("StaticFieldLeak", "SetTextI18n")
class DuplicateAudiosDuplicateActivity : BaseActivity(), MarkedListener,
    View.OnClickListener {
    var mTAG: String = javaClass.simpleName
    var adapterList: List<IndividualGroupModel>? = null
    var individualAudiosAdapter: IndividualAudiosAdapter? = null
    var mLayoutManager: LinearLayoutManager? = null
    var mDuplicateFound = 0
    var index = -1
    var tempGroupOfDupes: List<IndividualGroupModel>? = null
    var top = -1
    lateinit var mContext:Activity

    companion object {
        @JvmField
        var filterListAudios = HashMap<String, Boolean>()

        @JvmField
        var groupOfDupes: List<IndividualGroupModel>? = null

        @JvmField
        var recyclerViewForIndividualGrp: RecyclerView? = null
    }


    lateinit var binding:ActivityDuplicateAudiosBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
        binding=ActivityDuplicateAudiosBinding.inflate(layoutInflater)
        setContentView(binding.root)

        mContext=getContext()
//        initViews()
//        initAds()
        initData()
        initActions()
        Log.e(mTAG, "onCreate: ")
    }

    fun getContext(): Activity {
        return this@DuplicateAudiosDuplicateActivity
    }

    fun initData() {
        recyclerViewForIndividualGrp = findViewById(R.id.recycler_view_audios)
        setSupportActionBar(binding.toolbar)
        mLayoutManager = LinearLayoutManager(mContext)
        recyclerViewForIndividualGrp!!.layoutManager = mLayoutManager
        recyclerViewForIndividualGrp!!.setHasFixedSize(true)
        initiateDataInPage()
    }

    fun initActions() {
        binding.delete!!.setOnClickListener(this)
        binding.backpressAudio!!.setOnClickListener(this)
    }

    @SuppressLint("NonConstantResourceId")
    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - com.gallery.photo.image.video.mainduplicate.utils.ShareConstants.mLastClickTime < 1200) {
            return
        }
        com.gallery.photo.image.video.mainduplicate.utils.ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
        when (view.id) {
            R.id.backpress_audio -> onBackPressed()
            R.id.delete -> deleteDuplicate()
        }
    }


    private fun initiateDataInPage() {
        try {
            StartScan().execute("")
        } catch (e: Exception) {
            Log.e(mTAG, "initiateDataInPage: " + e.message)
        }
    }

    internal inner class StartScan : AsyncTask<String?, String?, String?>() {
        override fun doInBackground(vararg params: String?): String? {
            if (DuplicateFileRemoverSharedPreferences.isInitiateRescanAndEnterAudioPageFirstTimeAfterScan(mContext)) {
                DuplicateFileRemoverSharedPreferences.setInitiateRescanAndEnterAudioPageFirstTimeAfterScan(mContext, false)
                groupOfDupes = PopUp.sortByPhotosDateAscending(com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.listOfGroupedDuplicatesAudios)
                tempGroupOfDupes = PopUp.sortByPhotosDateAscending(com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.listOfGroupedDuplicatesAudios)
                adapterList = setCheckBox(true)
            } else {
                applyFilterIntDuplicates()
                if (DuplicateFileRemoverSharedPreferences.isInitiateAudioPageAfterApplyFilter(mContext)) {
                    DuplicateFileRemoverSharedPreferences.setInitiateAudioPageAfterApplyFilter(mContext, false)
                    adapterList = setCheckBox(true)
                } else {
                    adapterList = reassignWithDefaultSelection()
                    updateMarked()
                }
            }
            return null
        }

        override fun onPostExecute(s: String?) {
            super.onPostExecute(s)
            updatePageDetails(null, null, 0, null)
            if (adapterList!!.isNotEmpty()) {
                recyclerViewForIndividualGrp!!.visibility = View.VISIBLE
                binding.llNoDuplicate!!.visibility = View.GONE
                binding.deleteExceptionFrameLayout!!.visibility = View.VISIBLE
                invalidateOptionsMenu()
                individualAudiosAdapter = IndividualAudiosAdapter(
                    mContext,  this@DuplicateAudiosDuplicateActivity,
                    adapterList!!
                )
                recyclerViewForIndividualGrp!!.adapter = individualAudiosAdapter
                individualAudiosAdapter!!.notifyDataSetChanged()
                com.gallery.photo.image.video.mainduplicate.utils.SharedPrefsConstant.save(mContext, com.gallery.photo.image.video.mainduplicate.utils.ShareConstants.RATE_DUPLICATE_COUNT, com.gallery.photo.image.video.mainduplicate.utils.SharedPrefsConstant.getInt(mContext, com.gallery.photo.image.video.mainduplicate.utils.ShareConstants.RATE_DUPLICATE_COUNT) + 1)
                return
            }
            recyclerViewForIndividualGrp!!.visibility = View.GONE
            binding.deleteExceptionFrameLayout!!.visibility = View.GONE
            binding.llNoDuplicate!!.visibility = View.VISIBLE
            invalidateOptionsMenu()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
        super.onActivityResult(requestCode, resultCode, resultData)
        if (requestCode == com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.REQUEST_CODE_OPEN_DOCUMENT_TREE && resultCode == -1) {
            if (com.gallery.photo.image.video.mainduplicate.utils.MyUtils.isSelectedStorageAccessFrameWorkPathIsProper(mContext, DocumentFile.fromTreeUri(mContext, resultData!!.data!!)!!.name)) {
                DuplicateFileRemoverSharedPreferences.setStorageAccessFrameWorkURIPermission(mContext, resultData.data.toString())
                showDeleteDialog()
                return
            }
            Toast.makeText(mContext, "Please Select Parent External Storage Dir", Toast.LENGTH_SHORT).show()
            startActivityForResult(Intent("android.intent.action.OPEN_DOCUMENT_TREE"), com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.REQUEST_CODE_OPEN_DOCUMENT_TREE)
        }
    }



    private fun showDeleteDialog() {
        if (com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_audios.size == 1) {
            PopUp(mContext, mContext).deleteAlertPopUp(
                "Audio",
                getString(R.string.msg_delete_alert_message_audio_single),
                getString(R.string.msg_delete_dialog_message_audio_single),
                com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_audios,
                com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.size_Of_File_audios,
                com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.listOfGroupedDuplicatesAudios,
                this
            )
        } else {
            PopUp(mContext, mContext).deleteAlertPopUp(
                "Audio",
                getString(R.string.msg_delete_alert_message_audios),
                getString(R.string.msg_delete_dialog_message_audios),
                com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_audios,
                com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.size_Of_File_audios,
                com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.listOfGroupedDuplicatesAudios,
                this
            )
        }
    }

    private fun deleteDuplicate() {
//        when {
            if(com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_documents.size <= 0) {
                com.gallery.photo.image.video.mainduplicate.utils.MyUtils.showToastMsg(mContext, getString(R.string.error_please_select_one_item))
            }
//            Build.VERSION.SDK_INT >= 20 -> {
                else showDeleteDialog()
//            }
//            MyUtils.getSDCardPath(mContext) == null -> {
//                showDeleteDialog()
//            }
//            DuplicateFileRemoverSharedPreferences.getStorageAccessFrameWorkURIPermission(mContext) != null -> {
//                showDeleteDialog()
//            }
//            else -> {
//                grantPermissionWithAlertDialog()
//            }
//        }
    }

//    private fun grantPermissionWithAlertDialog() {
//        val builder = AlertDialog.Builder(mContext)
//        builder.setView(layoutInflater.inflate(R.layout.dialog_saf_permission, null))
//        builder.setCancelable(false)
//        builder.setPositiveButton("Allow Permission" as CharSequence, PermissionYes())
//        builder.setNegativeButton("Cancel" as CharSequence) { dialog: DialogInterface, _: Int -> dialog.dismiss() }
//        val dialog = builder.create()
//        dialog.show()
//        val pButton = dialog.getButton(-1)
//        pButton.setTextColor(ContextCompat.getColor(mContext, R.color.colorPrimary))
//        pButton.isAllCaps = false
//        dialog.getButton(-2).isAllCaps = false
//    }

    internal inner class PermissionYes : DialogInterface.OnClickListener {
        override fun onClick(dialog: DialogInterface, which: Int) {
            dialog.dismiss()
            startActivityForResult(
                Intent("android.intent.action.OPEN_DOCUMENT_TREE"),
                com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.REQUEST_CODE_OPEN_DOCUMENT_TREE
            )
        }
    }

    private fun applyFilterIntDuplicates() {
        when {
            filterListAudios.size == com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.uniqueAudiosExtension.size -> {
                groupOfDupes = tempGroupOfDupes
            }
            filterListAudios.size > 0 -> {
                val newIndividualGroupAudios: MutableList<IndividualGroupModel> = ArrayList()
                for ((key) in filterListAudios) {
                    for (j in tempGroupOfDupes!!.indices) {
                        val individualGroupAudios1 = tempGroupOfDupes!![j]
                        if (individualGroupAudios1.groupExtension.equals(key, ignoreCase = true)) {
                            newIndividualGroupAudios.add(individualGroupAudios1)
                        }
                    }
                }
                groupOfDupes = newIndividualGroupAudios
            }
            else -> {
                groupOfDupes = tempGroupOfDupes
            }
        }
    }

    public override fun onPause() {
        var i = 0
        super.onPause()
        index = mLayoutManager!!.findFirstVisibleItemPosition()
        val v = recyclerViewForIndividualGrp!!.getChildAt(0)
        if (v != null) {
            i = v.top - recyclerViewForIndividualGrp!!.paddingTop
        }
        top = i
    }

    public override fun onResume() {
        super.onResume()
        if (index != -1) {
            mLayoutManager!!.scrollToPositionWithOffset(index, top)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.settings_1, menu)
        if (mDuplicateFound == 0) {
            menu.findItem(R.id.action_selectall).isEnabled = false
            menu.findItem(R.id.action_deselectall).isEnabled = false
            var str = "<font color='#ABABAB'>" + getString(R.string.label_menu_select_all) + "</font>"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                menu.findItem(R.id.action_selectall).title = Html.fromHtml(str, Html.FROM_HTML_MODE_COMPACT)
            } else {
                menu.findItem(R.id.action_selectall).title = Html.fromHtml(str)
            }
            var str2 = "<font color='#ABABAB'>" + getString(R.string.label_menu_deselect_all) + "</font>"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                menu.findItem(R.id.action_deselectall).title = Html.fromHtml(str2, Html.FROM_HTML_MODE_COMPACT)
            } else {
                menu.findItem(R.id.action_deselectall).title = Html.fromHtml(str2)
            }

        } else {
            menu.findItem(R.id.action_selectall).isEnabled = true
            menu.findItem(R.id.action_deselectall).isEnabled = true
            var str = "<font color='#000000'>" + getString(R.string.label_menu_select_all) + "</font>"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                menu.findItem(R.id.action_selectall).title = Html.fromHtml(str, Html.FROM_HTML_MODE_COMPACT)
            } else {
                menu.findItem(R.id.action_selectall).title = Html.fromHtml(str)
            }
            var str2 = "<font color='#000000'>" + getString(R.string.label_menu_deselect_all) + "</font>"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                menu.findItem(R.id.action_deselectall).title = Html.fromHtml(str2, Html.FROM_HTML_MODE_COMPACT)
            } else {
                menu.findItem(R.id.action_deselectall).title = Html.fromHtml(str2)
            }

        }
        invalidateOptionsMenu()
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        if (mDuplicateFound == 0) {
            menu.findItem(R.id.action_selectall).isEnabled = false
            menu.findItem(R.id.action_deselectall).isEnabled = false
            menu.findItem(R.id.action_selectall).title = Html.fromHtml("<font color='#ABABAB'>" + getString(R.string.label_menu_select_all) + "</font>")
            menu.findItem(R.id.action_deselectall).title = Html.fromHtml("<font color='#ABABAB'>" + getString(R.string.label_menu_deselect_all) + "</font>")

        } else {
            menu.findItem(R.id.action_selectall).isEnabled = true
            menu.findItem(R.id.action_deselectall).isEnabled = true
            menu.findItem(R.id.action_selectall).title = Html.fromHtml("<font color='#000000'>" + getString(R.string.label_menu_select_all) + "</font>")
            menu.findItem(R.id.action_deselectall).title = Html.fromHtml("<font color='#000000'>" + getString(R.string.label_menu_deselect_all) + "</font>")
        }
        invalidateOptionsMenu()
        return super.onPrepareOptionsMenu(menu)
    }

    @SuppressLint("WrongConstant")
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        val intent: Intent
        when (id) {
            R.id.action_home -> {
                intent = Intent(mContext, HomeActivity::class.java)
                intent.addFlags(335544320)
                startActivity(intent)
                finish()
                return true
            }
            R.id.action_rescan -> {
                com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.resetOneTimePopUp()
                filterListAudios.clear()
                intent = Intent(mContext, ScanningDuplicateActivity::class.java)
                intent.putExtra("IsCheckType", "Audio")
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent, ActivityOptionsCompat.makeCustomAnimation(mContext, android.R.anim.fade_in, android.R.anim.fade_out).toBundle())
                onBackPressed()
                return true
            }
            R.id.action_selectall -> {
                if (mDuplicateFound == 0) {
                    Toast.makeText(mContext, "No Duplicate Data Found", Toast.LENGTH_SHORT).show()
                } else {
                    imagesSelectAllAndDeselectAll(true)
                }
                return true
            }
            R.id.action_deselectall -> {
                if (mDuplicateFound == 0) {
                    Toast.makeText(mContext, "No Duplicate Data Found", Toast.LENGTH_SHORT).show()
                } else {
                    imagesSelectAllAndDeselectAll(false)
                }
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    private fun imagesSelectAllAndDeselectAll(b: Boolean) {
        individualAudiosAdapter = IndividualAudiosAdapter(mContext,  this, setCheckBox(b))
        recyclerViewForIndividualGrp!!.adapter = individualAudiosAdapter
        individualAudiosAdapter!!.notifyDataSetChanged()
        updatePageDetails(null, null, 0, null)
    }

    private fun reassignWithDefaultSelection(): List<IndividualGroupModel> {
        val listOfDupes: MutableList<IndividualGroupModel> = ArrayList()
        com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_audios.clear()
        com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.size_Of_File_audios = 0
        if (groupOfDupes != null) {
            for (i in groupOfDupes!!.indices) {
                val individualGroup = groupOfDupes!![i]
                individualGroup.isCheckBox = individualGroup.isCheckBox
                val list: MutableList<ItemDuplicateModel> = ArrayList()
                for (j in individualGroup.individualGrpOfDupes!!.indices) {
                    val audioItem = individualGroup.individualGrpOfDupes!![j]
                    if (j == 0) {
                        audioItem.isFileCheckBox = false
                    } else {
                        if (individualGroup.isCheckBox) {
                            com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_audios.add(audioItem)
                            com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.addSizeAudios(audioItem.sizeOfTheFile)
                        }
                        updateMarked()
                        audioItem.isFileCheckBox = individualGroup.isCheckBox
                    }
                    list.add(audioItem)
                }
                individualGroup.individualGrpOfDupes = list
                listOfDupes.add(individualGroup)
            }
        }
        updateDuplicateFound(listOfDupes.size)
        updateMarked()
        return listOfDupes
    }

    private fun setCheckBox(value: Boolean): List<IndividualGroupModel> {
        val listOfDupes: MutableList<IndividualGroupModel> = ArrayList()
        com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_audios.clear()
        com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.size_Of_File_audios = 0
        if (groupOfDupes != null) {
            for (i in groupOfDupes!!.indices) {
                val individualGroup = groupOfDupes!![i]
                individualGroup.isCheckBox = value
                val list: MutableList<ItemDuplicateModel> = ArrayList()
                for (j in individualGroup.individualGrpOfDupes!!.indices) {
                    val audioItem = individualGroup.individualGrpOfDupes!![j]
                    if (j == 0) {
                        audioItem.isFileCheckBox = false
                    } else {
                        if (value) {
                            com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_audios.add(audioItem)
                            com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.addSizeAudios(audioItem.sizeOfTheFile)
                        }
                        updateMarked()
                        audioItem.isFileCheckBox = value
                    }
                    list.add(audioItem)
                }
                individualGroup.individualGrpOfDupes = list
                listOfDupes.add(individualGroup)
            }
        }
        updateDuplicateFound(listOfDupes.size)
        updateMarked()
        return listOfDupes
    }

    override fun updateDuplicateFound(duplicateFound: Int) {
        try {
            runOnUiThread {
                (findViewById<View>(R.id.dupes_found) as TextView).text = resources.getString(R.string.duplicate_found) + duplicateFound
            }
            mDuplicateFound = duplicateFound
        } catch (e: Exception) {
            Log.e(mTAG, "updateDuplicateFound: " + e.message)
        }
    }

    override fun updateMarked() {
        try {
            runOnUiThread(SetBottomMark())
        } catch (e: Exception) {
            Log.e(mTAG, "updateMarked: " + e.message)
        }
    }


    internal inner class SetBottomMark : Runnable {
        override fun run() {
            val tvMarked = findViewById<TextView>(R.id.marked)
            tvMarked.visibility = View.VISIBLE
            tvMarked.text = getString(R.string.label_duplicate_size, com.gallery.photo.image.video.mainduplicate.utils.ShareConstants.getReadableFileSize(
                com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.size_Of_File_audios))
        }
    }

    override fun cleaned(numberOfPhotosCleaned: Int) {
        Log.e(mTAG, "photosCleanedAudios: ")
        try {
            runOnUiThread {
                val filesCleaned = DuplicateFileRemoverSharedPreferences.getFilesCleaned(mContext) + numberOfPhotosCleaned
                DuplicateFileRemoverSharedPreferences.setFilesCleaned(mContext, filesCleaned)
            }
        } catch (e: Exception) {
            Log.e(mTAG, "Cleaned: " + e.message)
        }
    }


    override fun updatePageDetails(str1: String?, str2: String?, int1: Int, obj: Any?) {
        if (str1 == null) {
            var duplicateCount = 0
            if (groupOfDupes != null) {
                for (i in groupOfDupes!!.indices) {
                    val individualGroup = groupOfDupes!![i]
                    if (individualGroup.individualGrpOfDupes!!.size > 1) {
                        duplicateCount = individualGroup.individualGrpOfDupes!!.size + duplicateCount - 1
                    }
                }
                updateDuplicateFound(duplicateCount)
            }
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()

        finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)

    }
}