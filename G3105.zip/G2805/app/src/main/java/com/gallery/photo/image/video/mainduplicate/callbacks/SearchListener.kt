package com.gallery.photo.image.video.mainduplicate.callbacks

interface SearchListener {
    fun checkScanFinish()
    fun updateUi(vararg count: String?)
}