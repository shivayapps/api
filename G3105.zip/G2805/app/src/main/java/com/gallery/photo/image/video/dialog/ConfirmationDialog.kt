package com.gallery.photo.image.video.dialog

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.DialogConfirmationBinding

class ConfirmationDialog(
    var mContext: Context,
    var title: String,
    var msg: String,
    var actionPositive: String,
    val positiveBtnClickListener: () -> Unit,
    var isPermanentlyDelete: Boolean = false,
    var actionCancel: String = "",
) : BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogConfirmationBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogConfirmationBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {

//        bindingDialog.txtTitle.text = title
        bindingDialog.txtMsg.text = msg
        bindingDialog.btnDelete.text = actionPositive
        if (actionCancel.isNotEmpty())
            bindingDialog.btnCancel.text = actionCancel

        bindingDialog.txtRestoredMsg.visibility =
            if (isPermanentlyDelete) View.VISIBLE else View.GONE

        bindingDialog.btnCancel.setOnClickListener { dismiss() }
        bindingDialog.btnDelete.setOnClickListener {
            dismiss()
            positiveBtnClickListener()
        }
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)

}