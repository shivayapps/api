package com.qr.barcode.scanner.shivayapps.ui.dialog

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.qr.barcode.scanner.shivayapps.databinding.TextInputDialogLayoutBinding

import com.qr.barcode.scanner.shivayapps.R
import com.qr.barcode.scanner.shivayapps.models.barcode.BarcodeDetails
import com.qr.barcode.scanner.shivayapps.models.barcode.metadata.Format
import com.qr.barcode.scanner.shivayapps.models.barcode.metadata.Type


class TextFieldDialog() :
    BottomSheetDialogFragment() {

    var updateListener: ((value: Bundle) -> Unit)? = null

    lateinit var bindingDialog: TextInputDialogLayoutBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = TextInputDialogLayoutBinding.inflate(layoutInflater, container, false)
        intListener()
        return bindingDialog.root
    }

    private fun intListener() {

        bindingDialog.btnCancel.setOnClickListener {
            dismiss()
        }
        bindingDialog.btnOk.setOnClickListener {
            val content = bindingDialog.outlinedTextField.text.toString()
            if (content.isBlank()) {
                Toast.makeText(requireContext(), "Please enter valid input", Toast.LENGTH_SHORT)
                    .show()
            } else {
                val barcodeDetails = BarcodeDetails(
                    format = Format.QR_CODE,
                    type = Type.TYPE_TEXT,
                    null, rawValue = content,
                    text = content
                )
                val bundle = Bundle().apply {
                    putParcelable("barcodeDetails", barcodeDetails)
                }
                updateListener?.invoke(bundle)
            }

            dismiss()
        }
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}