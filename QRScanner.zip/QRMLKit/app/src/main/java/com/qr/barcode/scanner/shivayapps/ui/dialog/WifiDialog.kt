package com.qr.barcode.scanner.shivayapps.ui.dialog

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.qr.barcode.scanner.shivayapps.databinding.TextInputDialogLayoutBinding

import com.qr.barcode.scanner.shivayapps.R
import com.qr.barcode.scanner.shivayapps.databinding.WifiInputDialogLayoutBinding
import com.qr.barcode.scanner.shivayapps.models.barcode.BarcodeDetails
import com.qr.barcode.scanner.shivayapps.models.barcode.data.Security
import com.qr.barcode.scanner.shivayapps.models.barcode.data.WiFi
import com.qr.barcode.scanner.shivayapps.models.barcode.metadata.Format
import com.qr.barcode.scanner.shivayapps.models.barcode.metadata.Type


class WifiDialog() :
    BottomSheetDialogFragment() {

    var updateListener: ((value: Bundle) -> Unit)? = null

    lateinit var bindingDialog: WifiInputDialogLayoutBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = WifiInputDialogLayoutBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {
        intListener()

    }

    private fun intListener() {

        bindingDialog.btnCancel.setOnClickListener {
            dismiss()
        }
        bindingDialog.btnOk.setOnClickListener {
            val ssid = bindingDialog.outlinedSSIDField.text.toString()
            val password = bindingDialog.outlinedWifiPasswordField.text.toString()
            val security = when (bindingDialog.outlinedSecurityField.text.toString()) {
                "WEP" -> Security.WEP
                "WPA" -> Security.WPA
                "WPA2" -> Security.WPA2
                else -> Security.OPEN
            }
            if (ssid.isBlank()) {
                Toast.makeText(requireContext(), "Please enter SSID", Toast.LENGTH_SHORT).show()
            } else {
                val barcodeDetails = BarcodeDetails(
                    format = Format.QR_CODE,
                    type = Type.TYPE_WIFI,
                    null,
                    "WIFI:S:$ssid;T:${bindingDialog.outlinedSecurityField.text};P:$password;",
                    wiFi = WiFi(ssid, password, security)
                )
                val bundle = Bundle().apply {
                    putParcelable("barcodeDetails", barcodeDetails)
                }

                updateListener?.invoke(bundle)
                dismiss()
            }

            dismiss()
        }
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}