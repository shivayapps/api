package com.adconfig

//class AdmobInitializer : Initializer<Unit> {
//    override fun create(context: Context) {
//        try {
//
//        } catch (e:Exception) {
//            MobileAds.initialize(context)
//        }
//    }
//
//    override fun dependencies(): MutableList<Class<out Initializer<*>>> {
//        return mutableListOf()
//    }
//}
