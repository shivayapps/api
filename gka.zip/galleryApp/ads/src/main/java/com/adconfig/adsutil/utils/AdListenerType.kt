package com.adconfig.adsutil.utils

enum class AdListenerType {
    onAdLoaded, onAdFailedToLoad, onAdImpression, onAdClicked, onAdReUsed
}