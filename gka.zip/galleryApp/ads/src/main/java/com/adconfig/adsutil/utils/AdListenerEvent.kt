package com.adconfig.adsutil.utils

data class AdListenerEvent(val listener: AdListenerType)