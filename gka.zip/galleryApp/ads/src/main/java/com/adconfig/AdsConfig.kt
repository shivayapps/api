package com.adconfig

import android.app.Activity
import android.app.Application
import android.content.Context
import android.util.Log
import androidx.annotation.Keep
import com.google.android.gms.ads.RequestConfiguration
import com.adconfig.adsutil.Config
import com.adconfig.adsutil.Config.showInterTime
import com.adconfig.adsutil.abstract.IntersAd
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.openad.OpenAdHelper
import com.adconfig.adsutil.utils.AdsError
import com.adconfig.adsutil.utils.AdsListener
import com.adconfig.adsutil.utils.isAnyAdShowing
import com.adconfig.adsutil.openad.AppOpenApplication
import com.adconfig.adsutil.utils.isAppForeground
import java.util.Date
import kotlin.contracts.ExperimentalContracts
import kotlin.contracts.contract

@Keep
class AdsConfig private constructor(
    context: Application,
    testId: String,
    admobAppOpenId: String,
) {

    class Builder {
        private lateinit var context: Application
        private var testDeviceId: String = ""
        private var admobAppOpenId: String = ""

        fun setTestDeviceId(testDeviceId: String): Builder {
            this.testDeviceId = testDeviceId
            return this
        }


        fun setAdmobAppOpenId(admobAppOpenId: String): Builder {
            this.admobAppOpenId = admobAppOpenId
            return this
        }


        fun build(context: AppOpenApplication): AdsConfig {
            if (isAppForeground) {
                OpenAdHelper.destroy()
                //OpenAdHelper.loadOpenAd(context)
            }
            return AdsConfig(
                context = context,
                testId = testDeviceId,
                admobAppOpenId = admobAppOpenId,
            )
        }
    }

    companion object {

        var isExternalAppOpen = false
        var isDialogOpen = false
        var isSystemDialogOpen = false

        fun builder(): Builder {
            return Builder()
        }

        //        private val intersAd: IntersAd by lazy {
        //            AdmobIntersAdImpl()
        //        }
        private val intersAd: IntersAd = AdmobIntersAdImpl()

        fun showInterstitialAd(
            activity: Activity,
            onAdClosed: (isLoaded: Boolean) -> Unit = {}
        ) {
            checkLibrary()
            intersAd.adListener(object : AdsListener {
                override fun onAdClicked() {
                    Log.i("ADCONFIG_showInter", "onAdClicked")
                }

                override fun onAdDismissed() {
                    Log.i("ADCONFIG_showInter", "onAdDismissed")
//                    super.onAdDismissed()
                    isAnyAdShowing = false
                    intersAd.destroy()
//                        intersAd.load(activity)
                    onAdClosed.invoke(true)
                }

                override fun onAdLoaded(appOpenAd: Any) {
                    Log.i("ADCONFIG_showInter", "onAdLoaded.appOpenAd")
                }

                override fun onAdLoaded() {
                    Log.i("ADCONFIG_showInter", "onAdLoaded")
                }

                override fun onAdFailedToLoad(adsError: AdsError) {}

                override fun onAdFailedToShow(adsError: AdsError) {
                    isAnyAdShowing = false
                    Log.i(
                        "ADCONFIG_showInter",
                        "onAdFailedToShow:${adsError.code}:${adsError.error}"
                    )
//                    super.onAdFailedToShow(p0)
                    onAdClosed.invoke(false)
                }

                override fun onAdImpression() {
//                        intersAd.destroy()
//                        intersAd.load(activity)
//                        onAdClosed.invoke()
                    Log.i("ADCONFIG_showInter", "onAdImpression")
                }

                override fun onAdShowed() {
                    Log.i("ADCONFIG_showInter", "onAdShowed")
                }
            })
            Log.i("ADCONFIG_showInter", "isAnyAdShowing:$isAnyAdShowing")
            try {
                if (!isAnyAdShowing && Config.mInterstitialAd != null) {
                    isAnyAdShowing = true
                    intersAd.show(activity)
                    showInterTime = Date().time
                } else {
                    onAdClosed.invoke(false)
                }
            } catch (e: Exception) {
                onAdClosed.invoke(false)
            }
        }

    }

    init {
        RequestConfiguration.Builder().setTestDeviceIds(listOf(testId))
        Config.admobAppOpenId = admobAppOpenId
        Config.isLibraryInitialized = true
//        intersAd.load(context)
    }
}

fun checkLibrary() {
    requireLibraryInitialized(Config.isLibraryInitialized) { "Ads library not initialized" }
}

@OptIn(ExperimentalContracts::class)
inline fun requireLibraryInitialized(flag: Boolean, lazyMessage: () -> String): Boolean {
    contract {
        returns() implies (flag)
    }

    if (Config.isLibraryInitialized.not()) {
        val message = lazyMessage()
        throw IllegalArgumentException(message)
    } else {
        return Config.isLibraryInitialized
    }
}
