package com.photogallery.utils

import android.app.Activity
import android.content.ClipData
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaScannerConnection
import android.net.Uri
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintManager
import android.provider.MediaStore
import android.provider.MediaStore.Files
import android.util.Log
import android.util.TypedValue
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.adconfig.AdsConfig
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.Target
import com.bumptech.glide.signature.ObjectKey
import com.photogallery.R
import com.photogallery.adapter.PrintPdfDocument
import com.photogallery.database.AppDatabase
import com.photogallery.database.HiddenData
import com.photogallery.database.RecentDeleteData
import com.photogallery.dialog.PdfDialog
import com.photogallery.dialog.ProgressDialog
import com.photogallery.extension.getFileUri
import com.photogallery.extension.getFilenameExtension
import com.photogallery.extension.getIntValue
import com.photogallery.extension.getLongValue
import com.photogallery.extension.openPath
import com.photogallery.extension.rescanPath
import com.photogallery.model.MediaData
import com.photogallery.model.RestoreData
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import vi.imagestopdf.CreatePDFListener
import vi.imagestopdf.PDFEngine
import java.io.File
import java.io.FileInputStream
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.IOException
import java.net.URLConnection

object Utils {


    fun printFile(context: Context?, filepath: String) {
        val printManager = context?.getSystemService(Context.PRINT_SERVICE) as PrintManager
        val printAdapter = PrintPdfDocument(context, filepath)
        printManager.print(
            "Document",
            printAdapter,
            PrintAttributes.Builder().build()
        )
    }

    fun sharePDF(context: Context, filepath: String) {

        try {
            val file = File(filepath)
            val shareIntent = Intent()
            shareIntent.action = Intent.ACTION_SEND
            shareIntent.type = "application/pdf"
            val fileUri = FileProvider.getUriForFile(
                context, context.packageName + ".provider", file
            )
            shareIntent.clipData = ClipData.newRawUri("", fileUri)
            shareIntent.putExtra(Intent.EXTRA_STREAM, fileUri)
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            context.startActivity(Intent.createChooser(shareIntent, "Share File"))
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }

    fun getUriFromPath(context: Context, filePath: String): Uri {
        val file = File(filePath)
        val uri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.provider",
            file
        )
        return uri
    }

    fun generateThumbnail(context: Context, filePath: String): Bitmap {
        val options = RequestOptions()
            .format(DecodeFormat.PREFER_ARGB_8888)
            .override(200, 200)
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .signature(ObjectKey(filePath))
            .skipMemoryCache(false)

        val builder = Glide.with(context)
            .asBitmap()
            .load(filePath)
            .apply(options)
            .into(Target.SIZE_ORIGINAL, Target.SIZE_ORIGINAL)

        return builder.get()
    }

//    public fun getScreenWidth(context: Context): Int {
//        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
//        val displayMetrics = DisplayMetrics()
////        windowManager.defaultDisplay.getMetrics(displayMetrics)
////        return displayMetrics.widthPixels
//        return windowManager.defaultDisplay.width
////        return getPointSize(context).x
//    }
//
//    public fun getScreenHeight(context: Context): Int {
//        return getPointSize(context).y
//    }
//
//    private fun getPointSize(context: Context): Point {
//        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
//        val display = wm.defaultDisplay
//        val size = Point()
//        display.getSize(size)
//        return size
//    }

    fun getMimeTypeFromFilePath(filePath: String): String? {
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(getFilenameExtension(filePath))
    }

    fun getFilenameExtension(path: String): String {
        return path.substring(path.lastIndexOf(".") + 1)
    }

    fun isVideoFile(path: String): Boolean {
        val mimeType = URLConnection.guessContentTypeFromName(path)
        return mimeType != null && mimeType.startsWith("video")
    }

    fun generatePdf(activity: Activity, selectedImageList: ArrayList<MediaData>) {
        ensureBackgroundThread {
            val uris = ArrayList<File>()
            for (i in selectedImageList.indices) {
                if (selectedImageList[i] is MediaData) {
                    val model = selectedImageList[i] as MediaData
                    uris.add(File(model.filePath))
                }
            }
            activity.runOnUiThread {
                var filename = System.currentTimeMillis().toString()
                val quality = 80
                PDFEngine.getInstance().createPDF(activity, uris, object : CreatePDFListener {
                    override fun onPDFGenerated(pdfFile: File?, numOfImages: Int) {

                        if (pdfFile != null) {
                            if (pdfFile.exists()) {
                                try {
                                    MediaScannerConnection.scanFile(
                                        activity, arrayOf(pdfFile.absolutePath),
                                        null, null
                                    )
                                } catch (e: Exception) {
                                }
                                Log.d("TAG", "onPDFGenerated:  Pdf file -->" + pdfFile!!.absolutePath)
                                Log.d("TAG", "onPDFGenerated:  numberofPages -->" + numOfImages)
                                //activity.toast("Your pdf is saved at ${pdfFile.absolutePath}")
                                try {
                                    val pdfDialog = PdfDialog(activity, activity.getString(R.string.pdf_generated), "${pdfFile.absolutePath}", {
                                        AdsConfig.isDialogOpen = true
//                                        PDFEngine.getInstance().openPDF(activity,File(pdfFile.absolutePath))
                                        activity.openPath(pdfFile.absolutePath, true)
                                    })
                                    AdsConfig.isDialogOpen = true
                                    pdfDialog.setCancelable(false)
                                    pdfDialog.show()
                                } catch (e: Exception) {
                                }
                            }
                        }
                    }
                }, filename, false, quality, true)
            }
        }
    }

    fun shareFilesList(context: Context, uris: ArrayList<Uri>) {
        val intent = Intent(Intent.ACTION_SEND_MULTIPLE)
        intent.type = "*/*"
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        try {
            context.startActivity(
                Intent.createChooser(
                    intent,
                    context.getString(R.string.share_with)
                )
            )
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(
                context,
                context.getString(R.string.no_app_found),
                Toast.LENGTH_SHORT
            ).show()
        }

    }

    internal fun getPixels(context: Context, valueInDp: Int): Int {
        val r = context.resources
        val px = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, valueInDp.toFloat(), r.displayMetrics)
        return px.toInt()
    }

    internal fun getPixels(context: Context, valueInDp: Float): Int {
        val r = context.resources
        val px = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, valueInDp, r.displayMetrics)
        return px.toInt()
    }

    internal fun getPixelsSp(context: Context, valueInSp: Int): Int {
        val r = context.resources
        val px = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, valueInSp.toFloat(), r.displayMetrics)
        return px.toInt()
    }

    internal fun getPixelsSp(context: Context, valueInSp: Float): Int {
        val r = context.resources
        val px = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, valueInSp, r.displayMetrics)
        return px.toInt()
    }

    fun shareFile(context: Context, filePath: String) {
        val file = File(filePath)
        val shareUri = FileProvider.getUriForFile(
            context,
            context.packageName + ".provider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND)
        intent.type = getMimeTypeFromFilePath(file.path)
        intent.putExtra(Intent.EXTRA_STREAM, shareUri)
        try {
            context.startActivity(
                Intent.createChooser(
                    intent,
                    context.getString(R.string.share_with)
                )
            )
        } catch (e: Exception) {
            Log.e("printStackTrace.001", "printStackTrace:$e")
            Toast.makeText(
                context,
                context.getString(R.string.no_supported_image),
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    fun deleteFile(
        context: Context,
        filePath: String,
        dataBase: AppDatabase,
        isPermanent: Boolean? = false
    ): Boolean {
        val file = File(filePath)
        val copyFileName = file.name
        val targetFolder = File(Constant.DELETE_PATH)
        if (!targetFolder.exists())
            targetFolder.mkdirs()
        val targetPath = targetFolder.path + File.separator + copyFileName
        val targetFile = File(targetPath)
        var deletedPath = ""
        var isDelete = false

        if (isPermanent!!) {
            isDelete = file.delete()

            deleteFromMediaStore(context, filePath)
            MediaScannerConnection.scanFile(
                context, arrayOf<String>(filePath), null
            ) { path: String?, uri: Uri? -> }


            return isDelete
        } else {
            try {
                deletedPath = targetFile.path
                isDelete = StorageUtils.moveFile(
                    file,
                    targetFile,
                    context
                )
                MediaScannerConnection.scanFile(
                    context, arrayOf<String>(filePath, targetPath), null
                ) { path: String?, uri: Uri? -> }
//                MediaScannerConnection.scanFile(
//                    context, arrayOf<String>(targetPath), null
//                ) { path: String?, uri: Uri? -> }

            } catch (e: FileAlreadyExistsException) {
                Log.e("printStackTrace.002", "FileAlreadyExistsException:$e")

                val separated =
                    file.name.split("\\.".toRegex()).dropLastWhile { it.isEmpty() }
                        .toTypedArray()
                val name = separated[0]
                var type = ""
                if (separated.size != 1)
                    type = "." + separated[1]
                val newPath2 =
                    targetFolder.path + "/" + name + "_" + System.currentTimeMillis() + type
                val file2 = File(newPath2)
                deletedPath = file2.path
                isDelete = StorageUtils.moveFile(
                    file,
                    file2,
                    context
                )
                MediaScannerConnection.scanFile(
                    context, arrayOf<String>(filePath, newPath2), null
                ) { path: String?, uri: Uri? -> }
            }
            if (isDelete) dataBase.dataDao()
                .insertRecentDelete(RecentDeleteData(0, deletedPath, file.parent))

            return isDelete
        }

    }

    fun deleteHideFile(
        context: Context,
        data: MediaData,
        dataBase: AppDatabase,
        isPermanent: Boolean
    ): Boolean {
        val file = File(data.filePath)
        val model = dataBase.vaultDao().getDataFromPath(data.filePath)

        if (isPermanent) {
            val isDelete = file.delete()
            deleteFromMediaStore(context, data.filePath)
            if (isDelete) dataBase.vaultDao().deleteHide(model)
            MediaScannerConnection.scanFile(
                context, arrayOf<String>(data.filePath), null
            ) { path: String?, uri: Uri? -> }
        } else {
            model.isDeleted = true
            dataBase.vaultDao().update(model)
        }

        return true
    }

    fun recentlyDeleteHideFile(
        context: Context,
        data: MediaData,
        dataBase: AppDatabase
    ): Boolean {
        val file = File(data.filePath)

        val isDelete = file.delete()
        if (isDelete)
            dataBase.dataDao()
                .removeRecentDelete(
                    RecentDeleteData(
                        data.idDataBase,
                        data.filePath,
                        data.restorePath
                    )
                )

        MediaScannerConnection.scanFile(
            context, arrayOf<String>(data.filePath), null
        ) { path: String?, uri: Uri? -> }

        return isDelete
    }

    fun copyFiles(
        activity: AppCompatActivity,
        selectPath: String,
        copyMoveList: ArrayList<MediaData>,
        selectedItem: Int,
        copyListener: () -> Unit,
    ) {
        val targetFolder = File(selectPath)
        val copyFiles = ArrayList<String>()
        val keepLastModified = Preferences(activity).keepLastModified
        if (!targetFolder.exists()) {
            targetFolder.mkdirs()
        }

        val progressDialog = ProgressDialog(
            activity,
            R.drawable.icon_copy_dialog,
            copyMoveList.size,
            activity.getString(R.string.Copying),
            ""
        )
        progressDialog.setCancelable(false)
        progressDialog.show()

        Observable.fromCallable {
            try {
                for (i in copyMoveList.indices) {
                    val copyFile = File(copyMoveList[i].filePath)
                    try {
                        val copyFileName = copyFile.name
                        val targetPath = targetFolder.path + File.separator + copyFileName
                        val targetFile = File(targetPath)

                        if (targetFile.exists()) {
                            val separated =
                                copyFile.name.split("\\.".toRegex()).dropLastWhile { it.isEmpty() }
                                    .toTypedArray()
                            val name = separated[0]
                            val type = separated[1]
                            val newPath2 =
                                targetFolder.path + "/" + name + "_" + System.currentTimeMillis() + "." + type
                            val file2 = File(newPath2)
                            val isCopied: Boolean =
                                StorageUtils.copyFile(copyFile, file2, activity)

                            if (isCopied) {
                                copyFiles.add(file2.path)
                            }
                            addIntoMediaStore(activity, newPath2)
                            MediaScannerConnection.scanFile(activity, arrayOf<String>(targetPath), null) { path, uri -> }
                            MediaScannerConnection.scanFile(activity, arrayOf<String>(newPath2), null) { path, uri -> }
                        } else {
                            val isCopied: Boolean =
                                StorageUtils.copyFile(
                                    copyFile,
                                    targetFile,
                                    activity
                                )
                            if (isCopied) {
                                copyFiles.add(targetFile.path)
                            }

                            addIntoMediaStore(activity, targetPath)
                            MediaScannerConnection.scanFile(activity, arrayOf<String>(targetPath), null) { path, uri -> }
                        }
                        if (keepLastModified) {
                            updateLastModifiedValues(activity, copyFile, targetFile)
                            activity.rescanPath(targetFile.path)
                        } else {
                            File(targetFile.path).setLastModified(System.currentTimeMillis())
                        }
                        activity.runOnUiThread {
                            progressDialog.setProgress(copyFiles.size, selectedItem)
                        }
                    } catch (e: FileNotFoundException) {

                    }
                }
            } catch (e: java.lang.Exception) {
                Log.e("printStackTrace.003", "printStackTrace:$e")
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                activity.runOnUiThread {
                    if (!activity.isFinishing && !activity.isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()
                    }
                    sendEvent("rename", targetFolder)
                    copyListener()
                }
            }
            .onErrorReturn { false }
            .subscribe { _: Boolean? ->
                activity.runOnUiThread {
                    if (!activity.isFinishing && !activity.isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()
                    }
                    sendEvent("rename", targetFolder)
                    copyListener()
                }
            }
    }

    private fun updateLastModifiedValues(
        activity: Activity, source: File, destination: File
    ) {
//        copyOldLastModified(activity, source.path, destination.path)
        val lastModified = File(source.path).lastModified()
        if (lastModified != 0L) {
            File(destination.path).setLastModified(lastModified)
        }
    }

    private fun copyOldLastModified(
        activity: Activity, sourcePath: String, destinationPath: String
    ) {
        val projection = arrayOf(
            MediaStore.Images.Media.DATE_TAKEN,
            MediaStore.Images.Media.DATE_MODIFIED
        )

        val uri = MediaStore.Files.getContentUri("external")
        val selection = "${MediaStore.MediaColumns.DATA} = ?"
        var selectionArgs = arrayOf(sourcePath)
        val cursor = activity.applicationContext.contentResolver.query(
            uri,
            projection,
            selection,
            selectionArgs,
            null
        )

        cursor?.use {
            if (cursor.moveToFirst()) {
                val dateTaken = cursor.getLongValue(MediaStore.Images.Media.DATE_TAKEN)
                val dateModified = cursor.getIntValue(MediaStore.Images.Media.DATE_MODIFIED)

                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DATE_TAKEN, dateTaken)
                    put(MediaStore.Images.Media.DATE_MODIFIED, dateModified)
                }

                selectionArgs = arrayOf(destinationPath)
                activity.applicationContext.contentResolver.update(
                    uri,
                    values,
                    selection,
                    selectionArgs
                )
            }
        }
    }

    fun moveFiles(
        activity: AppCompatActivity,
        selectPath: String,
        copyMoveList: ArrayList<MediaData>,
        selectedItem: Int,
        moveListener: () -> Unit,
        isOpenFromFavorite: Boolean = false,
        isImportFiles: Boolean = false,
    ) {
        val targetFolder = File(selectPath)
        val moveList = ArrayList<String>()
        val deleteList = ArrayList<String>()
        val keepLastModified = Preferences(activity).keepLastModified
        if (!targetFolder.exists()) {
            targetFolder.mkdirs()
        }

        val progressDialog = ProgressDialog(
            activity,
            R.drawable.icon_move_dialog,
            copyMoveList.size,
            if (isImportFiles) activity.getString(R.string.Importing) else activity.getString(R.string.Moving),
            ""
        )
        progressDialog.setCancelable(false)
        progressDialog.show()

        Observable.fromCallable {
            val favList = Preferences(activity).getFavoriteList()
            try {
                for (i in copyMoveList.indices) {
                    val moveFile = File(copyMoveList[i].filePath)
                    try {

                        val moveFileName = moveFile.name
                        val targetPath = targetFolder.path + File.separator + moveFileName
                        val targetFile = File(targetPath)
                        if (targetFile.exists()) {
                            val separated =
                                moveFile.name.split("\\.".toRegex()).dropLastWhile { it.isEmpty() }
                                    .toTypedArray()
                            val name = separated[0]
                            val type = separated[1]
                            val newPath2 =
                                targetFolder.path + "/" + name + "_" + System.currentTimeMillis() + "." + type
                            val file2 = File(newPath2)
                            val isMove: Boolean =
                                StorageUtils.moveFile(
                                    moveFile,
                                    file2,
                                    activity
                                )
                            addIntoMediaStore(activity, newPath2)
                            MediaScannerConnection.scanFile(activity, arrayOf<String>(targetPath), null) { path, uri -> }
                            MediaScannerConnection.scanFile(activity, arrayOf<String>(newPath2), null) { path, uri -> }
                            if (isMove) {
                                moveList.add(file2.path)
                                deleteList.add(moveFile.path)
                                if (favList.isNotEmpty()) {
                                    if (favList.contains(moveFile.path)) {
                                        val fPos = favList.indexOf(moveFile.path)
                                        if (fPos != -1) {
                                            favList[fPos] = file2.path
                                        }
                                    }
                                }
                            }
                        } else {
                            val isMove: Boolean =
                                StorageUtils.moveFile(
                                    moveFile,
                                    targetFile,
                                    activity
                                )
                            addIntoMediaStore(activity, targetPath)
                            MediaScannerConnection.scanFile(activity, arrayOf<String>(targetPath), null) { path, uri -> }
                            if (isMove) {
                                moveList.add(targetFile.path)
                                deleteList.add(moveFile.path)

                                if (favList.isNotEmpty()) {
                                    if (favList.contains(moveFile.path)) {
                                        val fPos = favList.indexOf(moveFile.path)
                                        if (fPos != -1) {
                                            favList[fPos] = targetFile.path
                                        }
                                    }
                                }
                            }

                        }

                        if (keepLastModified) {
                            updateLastModifiedValues(activity, moveFile, targetFile)
                            activity.rescanPath(targetFile.path)
                        } else {
                            File(targetFile.path).setLastModified(System.currentTimeMillis())
                        }
                        activity.runOnUiThread {
                            progressDialog.setProgress(moveList.size, selectedItem)
                        }
                    } catch (e: FileNotFoundException) {
                    }
                }
            } catch (e: java.lang.Exception) {
                Log.e("printStackTrace.004", "printStackTrace:$e")
            }
            if (favList.isNotEmpty())
                Preferences(activity).setFavoriteList(favList)
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                activity.runOnUiThread {
                    if (!activity.isFinishing && !activity.isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()
                    }
                    moveListener.invoke()
                }
            }
            .onErrorReturn { false }
            .subscribe { _: Boolean? ->
                activity.runOnUiThread {
//                    if (dialog.isShowing)
                    if (!activity.isFinishing && !activity.isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()
                    }
                    moveListener.invoke()
                }
            }
    }

    fun hideFiles(
        activity: AppCompatActivity,
        pictures: ArrayList<MediaData>,
        selectedItem: Int,
        hideListener: (ArrayList<String>) -> Unit,
        customFolder: String = "",
        isFromFav: Boolean = false
    ) {
        Log.e("hideFiles", "pictures:${pictures.size}")
        val deleteList = ArrayList<String>()

        val progressDialog = ProgressDialog(
            activity,
            R.drawable.icon_move_dialog,
            pictures.size,
            activity.getString(
                R.string
                    .hiding
            ),
            ""
        )
        progressDialog.setCancelable(false)
        if (pictures.size > 1) progressDialog.show()

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(activity)
            var hideDirPath = File(Constant.HIDE_PATH)
            for (i in pictures.indices) {
                if (pictures[i] != null)
                    if (pictures[i] is MediaData) {
                        val model = pictures[i] as MediaData
                        deleteList.add(model.filePath)
//                        activity.runOnUiThread {
//                            progressDialog.setTitle(pictures[i].fileName)
//                        }
                        val to = try {
                            File(model.filePath)
                        } catch (e: java.lang.Exception) {
                            Log.e("printStackTrace.005", "printStackTrace:$e")
                            File(model.filePath)
                        }
                        try {
                            Log.e("hideFiles", "001 =========\nto:$to,\nhideDirPath:${hideDirPath}")
                            val hidePath: String? = hideFile(activity, to, hideDirPath)
                            val extension = to.name.substring(to.name.lastIndexOf("."))

                            deleteFromMediaStore(activity, model.filePath)
                            MediaScannerConnection.scanFile(
                                activity, arrayOf<String>(model.filePath), null
                            ) { path: String?, uri: Uri? -> }

                            if (!hidePath.isNullOrEmpty()) {
                                var folder = File(to.parent).name
                                if (customFolder.isNotEmpty()) folder = customFolder
                                var isVideo = 0
                                if (Utils.isVideoFile(to.path)) {
                                    isVideo = 1
                                }
                                Log.e(
                                    "hideFiles",
                                    "002 =========\nhidePath:$hidePath,\nparent:${to.parent},\nisVideo:$isVideo,\nextension:$extension,\nfolder:$folder"
                                )

                                dataBase.vaultDao().hide(
                                    HiddenData(
                                        0,
                                        hidePath,
                                        to.parent,
                                        isVideo,
                                        extension,
                                        folder
                                    )
                                )
                            }

                            if (!hidePath.isNullOrEmpty()) {
                                MediaScannerConnection.scanFile(
                                    activity, arrayOf<String>(hidePath), null
                                ) { path: String?, uri: Uri? -> }
                            }
                            MediaScannerConnection.scanFile(
                                activity, arrayOf<String>(to.path), null
                            ) { path: String?, uri: Uri? -> }

                        } catch (e: IOException) {
                            Log.e("printStackTrace.006", "printStackTrace:$e")
                        }
                        activity.runOnUiThread {
                            if (pictures.size > 1) progressDialog.setProgress(deleteList.size, pictures.size)
                        }
                    }
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { throwable: Throwable? ->
                activity.runOnUiThread {
//                    if (dialog.isShowing)
                    if (!activity.isFinishing && !activity.isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()
                    }
                    hideListener.invoke(deleteList)
                    Log.e("PrivateTag", "HideEvent funCall")
                }
            }
            .subscribe { success: Boolean? ->
                activity.runOnUiThread {
                    if (!activity.isFinishing && !activity.isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()
                    }
                    hideListener.invoke(deleteList)
                    Log.e("PrivateTag", "HideEvent funCall")
                }
            }
    }

    fun deleteFiles(
        activity: AppCompatActivity,
        selectImage: ArrayList<MediaData>,
        isPermanent: Boolean,
        hideListener: (ArrayList<String>) -> Unit,
    ) {
        val deleteList = ArrayList<String>()

        val progressDialog = ProgressDialog(
            activity,
            R.drawable.ic_drawer_delete,
            selectImage.size,
            activity.getString(R.string.Deleting),
            ""
        )
        progressDialog.setCancelable(false)
        progressDialog.show()

//        val scope = CoroutineScope(Dispatchers.IO + CoroutineName("DeleteScope"))
        var deleteCount = 1
//        val split = selectImage.splitIntoParts(Runtime.getRuntime().availableProcessors())
//        val split = selectImage.splitIntoParts(2)
        val dataBase = AppDatabase.getInstance(activity)
//        selectImage.map { list ->
//            scope.async {
//                val cleanList = mutableListOf<PictureData>()

        Observable.fromCallable {
            try {

                for (model in selectImage) {
                    val isDelete = deleteFile(activity, model.filePath, dataBase, isPermanent)
                    deleteFromMediaStore(activity, model.filePath)

                    MediaScannerConnection.scanFile(
                        activity,
                        arrayOf(model.filePath),
                        null
                    ) { path: String?, uri: Uri? -> }

                    if (isDelete) {
                        deleteList.add(model.filePath)
                    }
                    activity.runOnUiThread {
                        progressDialog.setProgress(deleteCount, selectImage.size)
                    }

                    if (deleteCount == selectImage.size) {
                        if (!activity.isFinishing && !activity.isDestroyed) {
                            if (progressDialog.isShowing)
                                progressDialog.dismiss()
                        }
                        hideListener.invoke(deleteList)
                    }

                    deleteCount++
                }
//                MediaScannerConnection.scanFile(
//                    activity, selectImage.map { it.filePath }.toTypedArray(), null
//                ) { path: String?, uri: Uri? -> }

            } catch (e: java.lang.Exception) {
                Log.e("printStackTrace.027", "printStackTrace:$e")
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                activity.runOnUiThread {
                    if (!activity.isFinishing && !activity.isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()
                    }
                    sendEvent("refresh")
                }
            }
            .onErrorReturn { false }
            .subscribe { _: Boolean? ->
                activity.runOnUiThread {
                    if (!activity.isFinishing && !activity.isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()
                    }
                    sendEvent("refresh")
                }
            }

//                deleteList
//            }
//        }

//        hideListener.invoke(deleteList)
//        return asyncClean.awaitAll().flatten()
//        val executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors())
//        executor.execute {
//            val dataBase = AppDatabase.getInstance(activity)
//
//            for (i in selectImage.indices) {
//                if (selectImage[i] != null) if (selectImage[i] is PictureData) {
//                    val model = selectImage[i] as PictureData
//                    val isDelete = deleteFile(activity, model.filePath, dataBase, isPermanent)
//                    if (isDelete) {
//                        deleteCount++
//                        deleteList.add(model.filePath)
//                        progressDialog.setProgress(deleteCount, selectImage.size)
//                    }
//                }
//            }
//
//        }
//        hideListener(deleteList)

//        Observable.fromCallable {
//            val dataBase = AppDatabase.getInstance(activity)
//
//            for (i in selectImage.indices) {
//                if (selectImage[i] != null) if (selectImage[i] is PictureData) {
//                    val model = selectImage[i] as PictureData
//                    val isDelete = deleteFile(activity, model.filePath, dataBase, isPermanent)
//                    if (isDelete) {
//                        deleteCount++
//                        deleteList.add(model.filePath)
//                        progressDialog.setProgress(deleteCount, selectImage.size)
//                    }
//                }
//            }
//            true
//        }.subscribeOn(Schedulers.io())
//            .doOnError { _: Throwable? ->
//                activity.runOnUiThread {
//                    progressDialog.dismiss()
//                    hideListener(deleteList)
//                }
//            }
//            .subscribe { _: Boolean? ->
//                activity.runOnUiThread {
//                    progressDialog.dismiss()
//                    hideListener(deleteList)
//                }
//            }
    }

    fun unHideFiles(
        activity: AppCompatActivity,
        pictures: ArrayList<MediaData>,
        selectedItem: Int,
        hideListener: () -> Unit,
    ) {
        val deleteList = ArrayList<String>()

        val progressDialog = ProgressDialog(
            activity,
            R.drawable.icon_move_dialog,
            pictures.size,
            activity.getString(R.string.UnHiding),
            ""
        )
        progressDialog.setCancelable(false)
        if (pictures.size > 1) progressDialog.show()

        val restoreList: ArrayList<RestoreData> = ArrayList()

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(activity)
            for (i in pictures.indices) {
                if (pictures[i] != null) if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData
                    val dataModel = dataBase.vaultDao().getDataFromPath(model.filePath)

                    val unHideDirPath = File(model.restorePath)
//                    activity.runOnUiThread {
////                        txtTitle.text = pictures[i].fileName
//                        progressDialog.setTitle(pictures[i].fileName)
//                    }
                    val to = try {
                        File(model.filePath)
                    } catch (e: java.lang.Exception) {
                        Log.e("printStackTrace.007", "printStackTrace:$e")
                        File(model.filePath)
                    }
                    try {

                        Log.e("hideFiles", "111 =========\nto:$to,\nunHideDirPath:${unHideDirPath}")
                        var hidePath: String = ""
                        if (dataModel != null)
                            hidePath = unHideFile(activity, to, unHideDirPath, dataModel.extension)

                        addIntoMediaStore(activity, hidePath)
                        if (!hidePath.isNullOrEmpty()) {
                            //dataBase.vaultDao().getDataFromPath(model.filePath)
                            restoreList.add(RestoreData(hidePath, model.filePath))
                            val dataModel = dataBase.vaultDao().getDataFromPath(model.filePath)
                            dataBase.vaultDao().unHide(dataModel)

                        }
                    } catch (e: IOException) {
                        Log.e("printStackTrace.008", "printStackTrace:$e")
                    } catch (e: Exception) {
                        Log.e("printStackTrace.009", "printStackTrace:$e")
                    }
                    deleteList.add(model.filePath)
                    activity.runOnUiThread {
                        if (pictures.size > 1) progressDialog.setProgress(deleteList.size, pictures.size)
//                        txtProgressCount.text =
//                            deleteList.size.toString() + "/" + pictures.size
//                        progressBar.progress = deleteList.size
                    }

//                        val isDelete = Utils.fileDelete(activity, model.filePath)
//                        if (isDelete) {
//                            deleteList.add(model.filePath)
//                            activity.runOnUiThread {
//                                txtProgressCount.text =
//                                    deleteList.size.toString() + "/" + selectedItem
//                                progressBar.progress = deleteList.size
//                            }
//                        }
                }
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                activity.runOnUiThread {
                    if (!activity.isFinishing && !activity.isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()
                    }
//                    EventBus.getDefault().post(RestoreDataEvent(restoreList))
//                    EventBus.getDefault().post(DisplayDeleteEvent(deleteList))
                    hideListener()
                }
            }
            .onErrorReturn { false }
            .subscribe { _: Boolean? ->
                activity.runOnUiThread {
                    if (!activity.isFinishing && !activity.isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()
                    }
//                    EventBus.getDefault().post(RestoreDataEvent(restoreList))
//                    EventBus.getDefault().post(DisplayDeleteEvent(deleteList))
                    hideListener()
                }
            }
    }

    private fun unHideFile(activity: Activity, file: File, dir: File, extension: String): String {
        try {
            if (!dir.exists())
                dir.mkdirs()

//            val newFile: File = getUnHideFileName(0, dir, file.name,extension)
            val name = file.name + "$extension"
            val newFile = File(dir, name)
//            val newFile: File = getUnHideFileName(0, dir, file.name,extension)
            Log.e(
                "hideFiles",
                "222 =========\nfile.path:${file.path},\nfile.name:${file.name},\nnewFile.path:${newFile.path},\nnewFile.name:${newFile.name}"
            )

            FileOutputStream(newFile).channel.use { outputChannel ->
                FileInputStream(file).channel.use { inputChannel ->
                    inputChannel.transferTo(0, inputChannel.size(), outputChannel)
                    inputChannel.close()
                    file.delete()
//                    val deleteUrl = FileProvider.getUriForFile(
//                        activity,
//                        "${activity.packageName}.provider", file
//                    )
//                    val contentResolver = activity.contentResolver
//                    contentResolver.delete(deleteUrl, null, null)

                    MediaScannerConnection.scanFile(
                        activity,
                        arrayOf(file.path),
                        null
                    ) { path: String?, uri: Uri? -> }
                    MediaScannerConnection.scanFile(
                        activity,
                        arrayOf(newFile.path),
                        null
                    ) { path: String?, uri: Uri? -> }
                    return newFile.path
                }
            }
        } catch (e: Exception) {
            Log.e("printStackTrace.010", "printStackTrace:$e")
            return ""
        }
    }

    private fun restoreFile(activity: Activity, file: File, dir: File): String {
        try {
            if (!dir.exists())
                dir.mkdirs()

//            val newFile: File = getHideFileName(0, dir, file.name)
            val newFile: File =
                getUnHideFileName(0, dir, file.name, file.name.getFilenameExtension())
            Log.e(
                "hideFiles",
                "003 =========\nfile.path:${file.path},\nfile.name:${file.name},\nnewFile.path:${newFile.path},\nnewFile.name:${newFile.name}"
            )

            FileOutputStream(newFile).channel.use { outputChannel ->
                FileInputStream(file).channel.use { inputChannel ->
                    inputChannel.transferTo(0, inputChannel.size(), outputChannel)
                    inputChannel.close()
                    file.delete()
                    deleteFromMediaStore(activity, file.path)
                    MediaScannerConnection.scanFile(
                        activity,
                        arrayOf(file.path),
                        null
                    ) { path: String?, uri: Uri? -> }
                    MediaScannerConnection.scanFile(
                        activity,
                        arrayOf(newFile.path),
                        null
                    ) { path: String?, uri: Uri? -> }
                    return newFile.path
                }
            }
        } catch (e: Exception) {
            Log.e("printStackTrace.011", "printStackTrace:$e")
            return ""
        }
    }

    private fun hideFile(activity: Activity, file: File, dir: File): String? {
        try {
            val sourcePath = file.path
            if (!dir.exists())
                dir.mkdirs()

            val newFile: File = getHideFileName(0, dir, file.name)
            Log.e(
                "hideFiles",
                "003 =========\nfile.path:${file.path},\nfile.name:${file.name},\nnewFile.path:${newFile.path},\nnewFile.name:${newFile.name}"
            )

            FileOutputStream(newFile).channel.use { outputChannel ->
                FileInputStream(file).channel.use { inputChannel ->
                    inputChannel.transferTo(0, inputChannel.size(), outputChannel)
                    inputChannel.close()
                    file.delete()

                    MediaScannerConnection.scanFile(
                        activity,
                        arrayOf(sourcePath),
                        null
                    ) { path: String?, uri: Uri? -> }
                    MediaScannerConnection.scanFile(
                        activity,
                        arrayOf(newFile.path),
                        null
                    ) { path: String?, uri: Uri? -> }
                    return newFile.path
                }
            }
        } catch (e: Exception) {
            Log.e("printStackTrace.012", "printStackTrace:$e")
            return null
        }
    }

    private fun getUnHideFileName(count: Int, dir: File, strName: String, extension: String): File {
        var i = count
//        val extension = strName.substring(strName.lastIndexOf("."))
//        var name = strName.replace(extension,"")
//        var name = strName+"$extension"
        var name = strName
        var check = File(dir, name)
        if (check.exists()) {
            i++
            if (name.contains(".")) {
                if (name.indexOf(".") > 0) {
//                    val extension = name.substring(name.lastIndexOf("."))
                    name = name.substring(0, name.lastIndexOf(".")) + "(" + i + ")" + ".$extension"
//                    name = name.substring(0, name.lastIndexOf(".")) + "(" + i + ")" + extension
                }
            } else {
                name = "$name($i)"
            }
            check = getUnHideFileName(i, dir, name, extension)
        }
        return check
    }

    private fun getHideFileName(count: Int, dir: File, strName: String): File {
        var i = count
        val extension = strName.substring(strName.lastIndexOf("."))
        var name = strName.replace(extension, "")
        Log.e("getHideFileName", "strName:$strName, name:$name, extension:$extension")
        var check = File(dir, name)
        if (check.exists()) {
            i++
            if (name.contains(".")) {
                if (name.indexOf(".") > 0) {
                    name = name.substring(0, name.lastIndexOf(".")) + "(" + i + ")"
                }
            } else {
                name = "$name($i)"
            }
            //"${name}${extension}"
            check = getHideFileName(i, dir, "${name}${extension}")
        }
        return check
    }


    fun restoreFiles(
        activity: AppCompatActivity,
        pictures: ArrayList<MediaData>,
        selectedItem: Int,
        hideListener: () -> Unit,
    ) {
        val deleteList = ArrayList<String>()
        val progressDialog = ProgressDialog(
            activity,
            R.drawable.icon_move_dialog,
            pictures.size,
            activity.getString(R.string.Restoring),
            ""
        )
        progressDialog.setCancelable(false)
        progressDialog.show()

        val restoreList: ArrayList<RestoreData> = ArrayList()

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(activity)
            for (i in pictures.indices) {
                if (pictures[i] != null) if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData
                    var unHideDirPath = File(model.restorePath)
                    val restorePath = model.restorePath
//                    activity.runOnUiThread {
//                        progressDialog.setTitle(pictures[i].fileName)
//                    }
                    val sourcePath = ""
                    try {
                        val to = try {
                            File(model.filePath)
                        } catch (e: java.lang.Exception) {
                            Log.e("printStackTrace.013", "printStackTrace:$e")
                            File(model.filePath)
                        }
                        val sourcePath = to.path

                        val hidePath: String = restoreFile(activity, to, unHideDirPath)
                        if (!hidePath.isNullOrEmpty()) {
                            restoreList.add(RestoreData(hidePath, model.filePath))
                            dataBase.dataDao().removeRecentDelete(
                                RecentDeleteData(
                                    model.idDataBase,
                                    model.filePath,
                                    model.restorePath
                                )
                            )
                        }

                        addIntoMediaStore(activity, hidePath!!)

                        MediaScannerConnection.scanFile(activity, arrayOf<String>(sourcePath!!), null) { path: String?, uri: Uri? -> }
                        MediaScannerConnection.scanFile(activity, arrayOf<String>(restorePath), null) { path: String?, uri: Uri? -> }
                        MediaScannerConnection.scanFile(activity, arrayOf<String>(hidePath!!), null) { path: String?, uri: Uri? -> }
                    } catch (e: IOException) {
                        Log.e("printStackTrace.014", "printStackTrace:$e")
                    } finally {
                        MediaScannerConnection.scanFile(activity, arrayOf<String>(sourcePath!!), null) { path: String?, uri: Uri? -> }
                        MediaScannerConnection.scanFile(activity, arrayOf<String>(restorePath), null) { path: String?, uri: Uri? -> }
                    }
                    deleteList.add(model.filePath)
                    activity.runOnUiThread {
                        progressDialog.setProgress(deleteList.size, pictures.size)
                    }
                }
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                activity.runOnUiThread {
//                    if (dialog.isShowing)

                    if (!activity.isFinishing && !activity.isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()
                    }
//                    EventBus.getDefault().post(RestoreDataEvent(restoreList))
                    hideListener()
                }
            }
            .onErrorReturn { false }
            .subscribe { _: Boolean? ->
                activity.runOnUiThread {
//                    if (dialog.isShowing)
                    if (!activity.isFinishing && !activity.isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()
                    }
//                    EventBus.getDefault().post(RestoreDataEvent(restoreList))
                    hideListener()
                }
            }
    }

    fun addIntoMediaStore(
        activity: AppCompatActivity, path: String
    ) {
        Log.e("printStackTrace.0141", "addIntoMediaStore:$path")
        if (path.isEmpty()) return
        try {
            val values = ContentValues()
            values.put(MediaStore.MediaColumns.DATA, path)
            activity.contentResolver.insert(Files.getContentUri("external"), values)
        } catch (e: Exception) {
            Log.e("printStackTrace.0141", "printStackTrace:$e")
        }
    }

    fun deleteFromMediaStore(activity: Context, path: String) {
        try {
            val where = "${MediaStore.MediaColumns.DATA} = ?"
            val args = arrayOf(path)
            val needsRescan = activity.contentResolver.delete(activity.getFileUri(path), where, args) != 1
        } catch (ignored: Exception) {
            Log.e("printStackTrace.0142", "addNoMediaIntoMediaStore:$path")
        }
    }

    fun restoreFile(
        activity: AppCompatActivity,
        model: MediaData,
        dataBase: AppDatabase
    ): ArrayList<RestoreData> {

        val unHideDirPath = File(model.restorePath)
        val progressDialog = ProgressDialog(
            activity,
            R.drawable.icon_move_dialog,
            1,
            activity.getString(R.string.Restoring),
            ""
        )
        progressDialog.setCancelable(false)
        progressDialog.show()
//        progressDialog.isCancelable = false
//        progressDialog.show(activity.supportFragmentManager, progressDialog.tag)

        val to = try {
            File(model.filePath)
        } catch (e: java.lang.Exception) {
            Log.e("printStackTrace.015", "printStackTrace:$e")
            File(model.filePath)
        }
        val restoreList: ArrayList<RestoreData> = ArrayList()
        try {
            val hidePath: String = restoreFile(activity, to, unHideDirPath)
            MediaScannerConnection.scanFile(activity, arrayOf<String>(model.restorePath), null) { path: String?, uri: Uri? -> }
            MediaScannerConnection.scanFile(activity, arrayOf<String>(hidePath!!), null) { path: String?, uri: Uri? -> }
            if (!hidePath.isNullOrEmpty()) {
                restoreList.add(RestoreData(hidePath, model.filePath))
                dataBase.dataDao().removeRecentDelete(
                    RecentDeleteData(
                        model.idDataBase,
                        model.filePath,
                        model.restorePath
                    )
                )
            }
        } catch (e: IOException) {
            Log.e("printStackTrace.016", "printStackTrace:$e")
        }

        activity.runOnUiThread {
            progressDialog.setProgress(1, 1)
//            txtProgressCount!!.text = "1/1"
//            progressBar!!.progress = 1
            if (!activity.isFinishing && !activity.isDestroyed) {
                if (progressDialog.isShowing)
                    progressDialog.dismiss()
            }
        }

//        android.os.Handler(Looper.myLooper()!!).postDelayed({
//            dialog!!.dismiss()
//        }, 300)
        return restoreList
    }


    fun recoverFiles(
        activity: AppCompatActivity,
        pictures: ArrayList<MediaData>,
        selectedItem: Int,
        hideListener: () -> Unit,
    ) {
        val deleteList = ArrayList<String>()

        val progressDialog = ProgressDialog(
            activity,
            R.drawable.icon_move_dialog,
            pictures.size,
            activity.getString(R.string.Restoring),
            ""
        )
        progressDialog.setCancelable(false)
        progressDialog.show()
//        progressDialog.isCancelable = false
//        progressDialog.show(activity.supportFragmentManager, progressDialog.tag)

        val restoreList: ArrayList<RestoreData> = ArrayList()

        Observable.fromCallable {
            for (i in pictures.indices) {
                if (pictures[i] != null) if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData

//                    var unHideDirPath = File(model.restorePath)
                    var unHideDirPath = File(Constant.RECOVER_PATH)

                    val to = try {
                        File(model.filePath)
                    } catch (e: java.lang.Exception) {
                        Log.e("printStackTrace.017", "printStackTrace:$e")
                        File(model.filePath)
                    }
                    try {

                        Log.e("hideFiles", "111 =========\nto:$to,\nunHideDirPath:${unHideDirPath}")
//                        val hidePath: String? = unHideFile(activity, to, unHideDirPath,pictures[i].filePath.getFilenameExtension())
                        val hidePath: String = unHideFile(activity, to, unHideDirPath, "")

                        addIntoMediaStore(activity, hidePath)
                        if (!hidePath.isNullOrEmpty()) {
                            //dataBase.vaultDao().getDataFromPath(model.filePath)
                            restoreList.add(RestoreData(hidePath, model.filePath))
                        }
                    } catch (e: IOException) {
                        Log.e("printStackTrace.018", "printStackTrace:$e")
                    }
                    deleteList.add(model.filePath)
                    activity.runOnUiThread {
                        progressDialog.setProgress(deleteList.size, pictures.size)
//                        txtProgressCount.text =
//                            deleteList.size.toString() + "/" + pictures.size
//                        progressBar.progress = deleteList.size
                    }
                }
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                activity.runOnUiThread {
//                    if (dialog.isShowing)
                    if (!activity.isFinishing && !activity.isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()
                    }
//                    EventBus.getDefault().post(RestoreDataEvent(restoreList))
//                    EventBus.getDefault().post(DisplayDeleteEvent(deleteList))
                    hideListener()
                }
            }
            .onErrorReturn { false }
            .subscribe { _: Boolean? ->
                activity.runOnUiThread {
//                    if (dialog.isShowing)
                    if (!activity.isFinishing && !activity.isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()
                    }
//                    EventBus.getDefault().post(RestoreDataEvent(restoreList))
//                    EventBus.getDefault().post(DisplayDeleteEvent(deleteList))
                    hideListener()
                }
            }
    }

    fun restoreVaultFiles(
        activity: AppCompatActivity,
        pictures: ArrayList<MediaData>,
        selectedItem: Int,
        hideListener: () -> Unit,
    ) {
        val deleteList = ArrayList<String>()
        val progressDialog = ProgressDialog(
            activity,
            R.drawable.icon_move_dialog,
            pictures.size,
            activity.getString(R.string.Restoring),
            ""
        )
        progressDialog.setCancelable(false)
        progressDialog.show()
//        progressDialog.isCancelable = false
//        progressDialog.show(activity.supportFragmentManager, progressDialog.tag)

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(activity)
            for (i in pictures.indices) {
                if (pictures[i] != null) if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData

                    try {

                        val dataModel = dataBase.vaultDao().getDataFromPath(model.filePath)
                        dataModel.isDeleted = false
                        dataBase.vaultDao().update(dataModel)
//                        }
                    } catch (e: IOException) {
                        Log.e("printStackTrace.019", "printStackTrace:$e")
                    }
                    deleteList.add(model.filePath)
                    activity.runOnUiThread {
                        progressDialog.setProgress(deleteList.size, selectedItem)
//                        txtProgressCount.text =
//                            deleteList.size.toString() + "/" + selectedItem
//                        progressBar.progress = deleteList.size
                    }


                }
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                activity.runOnUiThread {
//                    if (dialog.isShowing)
                    if (!activity.isFinishing && !activity.isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()
                    }
//                    EventBus.getDefault().post(RestoreDataEvent(restoreList))
                    hideListener()
                }
            }
            .onErrorReturn { false }
            .subscribe { _: Boolean? ->
                activity.runOnUiThread {
//                    if (dialog.isShowing)
                    if (!activity.isFinishing && !activity.isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()
                    }
//                    EventBus.getDefault().post(RestoreDataEvent(restoreList))
                    hideListener()
                }
            }
    }

}