package com.photogallery.extension

import android.database.Cursor
import org.json.JSONArray

fun Cursor.getStringValue(key: String) = getString(getColumnIndex(key))

fun Cursor.getStringValueOrNull(key: String) = if (isNull(getColumnIndex(key))) null else getString(getColumnIndex(key))

fun Cursor.getIntValue(key: String) = getInt(getColumnIndex(key))

fun Cursor.getIntValueOrNull(key: String) = if (isNull(getColumnIndex(key))) null else getInt(getColumnIndex(key))

fun Cursor.getLongValue(key: String) = getLong(getColumnIndex(key))

fun Cursor.getLongValueOrNull(key: String) = if (isNull(getColumnIndex(key))) null else getLong(getColumnIndex(key))

fun Cursor.getBlobValue(key: String) = getBlob(getColumnIndex(key))

fun JSONArray.toList(): ArrayList<String> {
    val list = ArrayList<String>()
    for (i in 0 until length()) {
        list.add(getString(i))
    }
    return list
}
