package com.photogallery.dialog

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import android.widget.SeekBar
import android.widget.Toast
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.AdmobNative
import com.photogallery.databinding.DialogPdfBrightnessBinding
import com.photogallery.utils.DIALOG_DIM_AMOUNT

class PdfBrightnessDialog(
    val activity: Activity,
    val currentProgress: Float,
    val onProgressChanged: (progress: Int) -> Unit
) : Dialog(activity) {

    lateinit var binding: DialogPdfBrightnessBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        window?.setDimAmount(DIALOG_DIM_AMOUNT)
        window?.attributes?.windowAnimations = android.R.style.Animation_Dialog

        binding = DialogPdfBrightnessBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT
        )
        AdsConfig.isDialogOpen = true


        binding.brightnessSeekBar.progress = (currentProgress * 100).toInt()

        binding.brightnessSeekBar.setOnSeekBarChangeListener(object :
            SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                onProgressChanged.invoke(progress)
//                val brightness = progress.toFloat() / 100
//                layoutParams.screenBrightness = brightness
//                window.attributes = layoutParams
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
//        binding.btnCancel.setOnClickListener {
//            dismiss()
//        }
//        binding.btnOK.setOnClickListener {
//            dismiss()
//        }

    }


}