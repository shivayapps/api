package com.photogallery.jobs

import android.content.Context
import android.database.Cursor
import android.location.Address
import android.location.Geocoder
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import com.photogallery.database.AppDatabase
import com.photogallery.database.Categories
import com.photogallery.utils.MemoryCategoryAppsConfig
import com.photogallery.utils.Preferences
//import gallery.gallerylock.vaultgallery.hidepictures.category.MemoryCategoryAppsConfig
//import gallery.gallerylock.vaultgallery.hidepictures.database.AppDatabase
//import gallery.gallerylock.vaultgallery.hidepictures.database.Categories
//import gallery.gallerylock.vaultgallery.hidepictures.database.LocationEntity
//import gallery.gallerylock.vaultgallery.hidepictures.utils.OnDeviceImageLabeler

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.IOException
import java.util.Locale


fun Context.startCategoryWorker() {
    CategoryWorker(this.applicationContext).doWork()
}

class CategoryWorker(
    val appContext: Context,
) {

    fun doWork() {
        try {
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val preference = Preferences(appContext)
                    val momentCategories = MemoryCategoryAppsConfig.getMomentLists(appContext,preference)
                    val accuracyLevel = MemoryCategoryAppsConfig.getMomentAccuracyLevel(appContext,preference)
                    val subCategoryMap = momentCategories.flatMap { (categoryName, subCategories) ->
                        subCategories.map { subCategory -> subCategory.lowercase() to categoryName }
                    }.toMap()
                    val catList = momentCategories.map { it.name }

                    Log.e("CategoryWorker", "CategoryConfig.momentCategories:$momentCategories")
                    Log.e("CategoryWorker", "CategoryConfig.accuracyLevel:$accuracyLevel")

                    val projection = arrayOf(
                        MediaStore.Images.Media.DATA,
                        MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
                        MediaStore.MediaColumns.DATE_MODIFIED,
                        MediaStore.MediaColumns.DISPLAY_NAME,
                        MediaStore.MediaColumns.DATE_TAKEN,
                        MediaStore.MediaColumns.SIZE
                    )

                    val orderBy = MediaStore.MediaColumns.DATE_MODIFIED
                    val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                    } else {
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                    }

                    val cursor: Cursor = appContext.contentResolver.query(
                        uri,
                        projection,
                        null,
                        null,
                        "$orderBy DESC"
                    )!!

                    val pathIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
                    val dataBase = AppDatabase.getInstance(appContext)
                    while (cursor.moveToNext()) {
                        try {
                            val filePath = cursor.getString(pathIndex)
                            val entity = dataBase.dataDao().getCategoriesEntity(filePath)
                            if (entity == null) {
                                val categories =
                                    getCategory(
                                        appContext,
                                        accuracyLevel,
                                        filePath
                                    )
                                Log.e("CategoryWorker", "CategoryConfig.filePath:$filePath")
                                Log.e("CategoryWorker", "CategoryConfig.categories:$categories")

                                if (categories.isNotEmpty()) {
                                    val mainCatList = ArrayList<String>()
                                    for (category in categories) {
                                        val category = subCategoryMap[category.lowercase()]
                                        if (category != null && catList.contains(category)) {
                                            mainCatList.add(category)
                                        }
                                    }

                                    val updatedItem = Categories(
                                        path = filePath,
                                        mainCategories = mainCatList,
                                        isCategoryFetch = 1,
                                        categories = categories,
                                    )
                                    Log.i(
                                        "CategoryWorker",
                                        "insertCategoriesEntity.mainCatList:$mainCatList"
                                    )
                                    Log.i(
                                        "CategoryWorker",
                                        "insertCategoriesEntity.categories:$categories"
                                    )
                                    dataBase.dataDao().insertCategoriesEntity(updatedItem)
                                }
                            }

                        } catch (e: IOException) {
                            Log.i("CategoryWorker", "IOException:$e")
                        } catch (e: UnsupportedOperationException) {
                            Log.i("CategoryWorker", "UnsupportedOperationException:$e")
                        }
                    }
                    cursor.close()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        } catch (e: Exception) {
            Log.i("CategoryWorker", "Exception:$e")
            e.printStackTrace()
        }
    }

    private suspend fun getCategory(
        context: Context, accuracyLevel: Double, filePath: String
    ): List<String> {
        return OnDeviceImageLabeler.detectLabel(
            context, accuracyLevel, filePath
        )
    }
}