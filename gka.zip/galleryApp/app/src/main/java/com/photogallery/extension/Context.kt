package com.photogallery.extension

import android.annotation.SuppressLint
import android.app.Activity
import android.app.NotificationManager
import android.content.*
import android.content.res.Configuration
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Point
import android.graphics.drawable.Drawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.*
import android.provider.BaseColumns
import android.provider.DocumentsContract
import android.provider.MediaStore.*
import android.provider.OpenableColumns
import android.provider.Settings
import android.telecom.TelecomManager
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.biometric.BiometricManager
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.os.bundleOf
import androidx.exifinterface.media.ExifInterface
import com.bumptech.glide.Glide
import com.bumptech.glide.Priority
import com.bumptech.glide.integration.webp.WebpBitmapFactory
import com.bumptech.glide.integration.webp.decoder.WebpDownsampler
import com.bumptech.glide.integration.webp.decoder.WebpDrawable
import com.bumptech.glide.integration.webp.decoder.WebpDrawableTransformation
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.MultiTransformation
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.load.resource.bitmap.CenterCrop
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.Target
import com.bumptech.glide.request.transition.DrawableCrossFadeFactory
import com.bumptech.glide.request.transition.TransitionFactory
import com.bumptech.glide.signature.ObjectKey
import com.github.ajalt.reprint.core.Reprint
import com.photogallery.R
import com.photogallery.utils.NOMEDIA
import com.photogallery.utils.PicassoRoundedCornersTransformation
import com.photogallery.utils.Preferences
import com.photogallery.utils.isOnMainThread
import com.photogallery.utils.isOreoPlus
import com.photogallery.utils.isRPlus
import com.photogallery.utils.isSPlus
import com.photogallery.utils.isUpsideDownCakePlus
import com.google.android.gms.tasks.Task
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.photogallery.model.LanguageData
import com.squareup.picasso.Picasso
import org.json.JSONException
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
fun getValidLanguageCode(defaultLanguage: String): String {
    Log.i("MainApp", "defaultLanguage:$defaultLanguage")
    if (listOf("en", "es", "fil", "pt", "hi", "in", "ko", "ja", "ar", "fr", "de", "th", "vi", "tr", "ru", "it", "mr", "te", "zh", "ms", "ta", "bn", "ur", "fa").contains(defaultLanguage)) {
        return defaultLanguage
    }
    return "en"
}

fun Context.getLanguageList(defaultLanguage: String): ArrayList<LanguageData> {
//    val defaultLanguage: String = Locale.getDefault().language
    Log.d("LocaleHelper", "Context.getLanguageList.001:$defaultLanguage")

    val languageList: ArrayList<LanguageData> = ArrayList()

    languageList.add(LanguageData(getString(R.string.english), getString(R.string.english), "en"))
    languageList.add(LanguageData(getString(R.string.china), getString(R.string.china), "zh"))
    languageList.add(LanguageData(getString(R.string.hindi), getString(R.string.hindi), "hi"))
    languageList.add(LanguageData(getString(R.string.spanish), getString(R.string.spanish), "es"))
    languageList.add(LanguageData(getString(R.string.arabic), getString(R.string.arabic), "ar"))
    languageList.add(LanguageData(getString(R.string.french), getString(R.string.french), "fr"))
    languageList.add(LanguageData(getString(R.string.bangali), getString(R.string.bangali), "bn"))
    languageList.add(LanguageData(getString(R.string.russian), getString(R.string.russian), "ru"))
    languageList.add(LanguageData(getString(R.string.portuguese), getString(R.string.portuguese), "pt"))
    languageList.add(LanguageData(getString(R.string.indonesian), getString(R.string.indonesian), "in"))
    languageList.add(LanguageData(getString(R.string.japanese), getString(R.string.japanese), "ja"))
    languageList.add(LanguageData(getString(R.string.deutsch), getString(R.string.deutsch), "nl"))
    languageList.add(LanguageData(getString(R.string.korean), getString(R.string.korean), "ko"))
    languageList.add(LanguageData(getString(R.string.turkish), getString(R.string.turkish), "tr"))
    languageList.add(LanguageData(getString(R.string.vietnamese), getString(R.string.vietnamese), "vi"))
    languageList.add(LanguageData(getString(R.string.tamil), getString(R.string.tamil), "ta"))
    languageList.add(LanguageData(getString(R.string.telugu), getString(R.string.telugu), "te"))
    languageList.add(LanguageData(getString(R.string.marathi), getString(R.string.marathi), "mr"))
    languageList.add(LanguageData(getString(R.string.melayu), getString(R.string.melayu), "ms"))
    languageList.add(LanguageData(getString(R.string.philippians), getString(R.string.philippians), "phi"))
    languageList.add(LanguageData(getString(R.string.italian), getString(R.string.italian), "it"))
    languageList.add(LanguageData(getString(R.string.thai), getString(R.string.thai), "th"))


//    languageList.add(LanguageData(getString(R.string.english),getString(R.string.english), "en"))
//    languageList.add(LanguageData(getString(R.string.arabic),getString(R.string.arabic), "ar" ))
//    languageList.add(LanguageData(getString(R.string.french),getString(R.string.french), "fr"))
//    languageList.add(LanguageData(getString(R.string.spanish),getString(R.string.spanish), "es"))
//    languageList.add(LanguageData(getString(R.string.russian),getString(R.string.russian), "ru"))
//    languageList.add(LanguageData(getString(R.string.japanese),getString(R.string.japanese), "ja"))
//    languageList.add(LanguageData(getString(R.string.italian),getString(R.string.italian), "it"))
//    languageList.add(LanguageData(getString(R.string.portuguese),getString(R.string.portuguese), "pt"))
//    languageList.add(LanguageData(getString(R.string.marathi),getString(R.string.marathi), "mr"))
//    languageList.add(LanguageData(getString(R.string.bangali),getString(R.string.bangali), "bn"))
//    languageList.add(LanguageData(getString(R.string.china),getString(R.string.china), "zh"))
//    languageList.add(LanguageData(getString(R.string.deutsch),getString(R.string.deutsch), "nl"))
//    languageList.add(LanguageData(getString(R.string.hindi),getString(R.string.hindi), "hi"))
//    languageList.add(LanguageData(getString(R.string.indonesian),getString(R.string.indonesian), "in"))
//    languageList.add(LanguageData(getString(R.string.korean),getString(R.string.korean), "ko"))
//    languageList.add(LanguageData(getString(R.string.melayu),getString(R.string.melayu), "ms"))
//    languageList.add(LanguageData(getString(R.string.philippians),getString(R.string.philippians), "phi"))
//    languageList.add(LanguageData(getString(R.string.tamil),getString(R.string.tamil), "ta"))
//    languageList.add(LanguageData(getString(R.string.telugu),getString(R.string.telugu), "te"))
//    languageList.add(LanguageData(getString(R.string.thai),getString(R.string.thai), "th"))
//    languageList.add(LanguageData(getString(R.string.turkish),getString(R.string.turkish), "tr"))
//    languageList.add(LanguageData(getString(R.string.vietnamese),getString(R.string.vietnamese), "vi"))


    val defaultLocal: LanguageData? = languageList.firstOrNull { it.languageCode == defaultLanguage }
    if (defaultLocal != null) {
        languageList.add(0, LanguageData(getString(R.string.lang_default), defaultLocal.languageSubTitle, "0"))
    } else {
        languageList.add(0, LanguageData(getString(R.string.lang_default), getString(R.string._default), "en"))
    }

    return languageList
}

fun Context.initFirebaseConfig(successListener: (success: Boolean) -> Unit = {}) {
    Log.e("fireBaseConfigGet", "initFirebaseConfig")

    try {
//        val adsPref = PrefCalls(this)
        val pref = Preferences(this)

        val remoteConfig = FirebaseRemoteConfig.getInstance()

        remoteConfig.setConfigSettingsAsync(
            FirebaseRemoteConfigSettings.Builder()
                .setMinimumFetchIntervalInSeconds(5)
                .setFetchTimeoutInSeconds(5)
                .build()
        )
//            remoteConfig.setDefaultsAsync(R.xml.remote_config_defaults)
        remoteConfig.fetch(0)
            .addOnCompleteListener { task: Task<Void?> ->
                if (task.isSuccessful) {
                    Log.e("fireBaseConfigGet", "Successful")
                    remoteConfig.fetchAndActivate()
                    try {
                        successListener.invoke(true)
                    } catch (e: JSONException) {
                        Log.e("fireBaseConfigGet", "JSONException:$e")
                        successListener.invoke(false)
                    }
                } else {
                    Log.e("fireBaseConfigGet", "Failed:${task.exception}")
                    successListener.invoke(false)
                }
            }
    } catch (e: java.lang.Exception) {
        Log.e("fireBaseConfigGet", "printStackTrace:$e")
        successListener.invoke(false)
    }
}

val Context.isRTLLayout: Boolean get() = resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL

val Context.areSystemAnimationsEnabled: Boolean get() = Settings.Global.getFloat(contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 0f) > 0f

fun Context.toast(id: Int, length: Int = Toast.LENGTH_SHORT) {
    toast(getString(id), length)
}

fun <T> Array<T>.splitIntoParts(partSize: Int): List<Array<T>> {
    val result = mutableListOf<Array<T>>()
    var currentIndex = 0

    while (currentIndex < this.size) {
        val endIndex = kotlin.math.min(currentIndex + partSize, this.size)
        val part = this.copyOfRange(currentIndex, endIndex)
        result.add(part)
        currentIndex = endIndex
    }

    return result
}

//@RequiresApi(Build.VERSION_CODES.N)
//fun Context.saveImageRotation(path: String, degrees: Int): Boolean {
//    if (!needsStupidWritePermissions(path)) {
//        saveExifRotation(ExifInterface(path), degrees)
//        return true
//    } else
//        if (isNougatPlus()) {
//        val documentFile = getSomeDocumentFile(path)
//        if (documentFile != null) {
//            val parcelFileDescriptor = contentResolver.openFileDescriptor(documentFile.uri, "rw")
//            val fileDescriptor = parcelFileDescriptor!!.fileDescriptor
//            saveExifRotation(ExifInterface(fileDescriptor), degrees)
//            return true
//        }
//    }
//    return false
//}

fun Context.saveExifRotation(exif: ExifInterface, degrees: Int) {
    val orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
    val orientationDegrees = (orientation.degreesFromOrientation() + degrees) % 360
    exif.setAttribute(ExifInterface.TAG_ORIENTATION, orientationDegrees.orientationFromDegrees())
    exif.saveAttributes()
}

fun Context.setOrientation(file: File?, degrees: Int) {
//    val orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
//    if (orientation == ExifInterface.ORIENTATION_NORMAL.toString() || orientation == ExifInterface.ORIENTATION_UNDEFINED.toString()) {
//        return
//    }
    val exifInterface = ExifInterface(
        file!!
    )
    val orientation = (degrees.degreesFromOrientation() + degrees) % 360

    exifInterface.setAttribute(ExifInterface.TAG_ORIENTATION, orientation.orientationFromDegrees())
    exifInterface.saveAttributes()
}

fun Context.toast(msg: String, length: Int = Toast.LENGTH_SHORT) {
    try {
        if (isOnMainThread()) {
            doToast(this, msg, length)
        } else {
            Handler(Looper.getMainLooper()).post {
                doToast(this, msg, length)
            }
        }
    } catch (e: Exception) {
    }
}

private fun doToast(context: Context, message: String, length: Int) {
    if (context is Activity) {
        if (!context.isFinishing && !context.isDestroyed) {
            Toast.makeText(context, message, length).show()
        }
    } else {
        Toast.makeText(context, message, length).show()
    }
}

fun Context.showErrorToast(msg: String, length: Int = Toast.LENGTH_LONG) {
    toast(String.format(getString(R.string.error), msg), length)
}

fun Context.showErrorToast(exception: Exception, length: Int = Toast.LENGTH_LONG) {
    showErrorToast(exception.toString(), length)
}


fun Context.isFingerPrintSensorAvailable() = Reprint.isHardwarePresent()

fun Context.isBiometricIdAvailable(): Boolean = when (BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK)) {
    BiometricManager.BIOMETRIC_SUCCESS, BiometricManager.BIOMETRIC_STATUS_UNKNOWN, BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> true
    else -> false
}

fun Context.getLatestMediaId(uri: Uri = Files.getContentUri("external")): Long {
    val projection = arrayOf(
        BaseColumns._ID
    )
    try {
        val cursor = queryCursorDesc(uri, projection, BaseColumns._ID, 1)
        cursor?.use {
            if (cursor.moveToFirst()) {
                return cursor.getLongValue(BaseColumns._ID)
            }
        }
    } catch (ignored: Exception) {
    }
    return 0
}

private fun Context.queryCursorDesc(
    uri: Uri,
    projection: Array<String>,
    sortColumn: String,
    limit: Int,
): Cursor? {
    return if (isRPlus()) {
        val queryArgs = bundleOf(
            ContentResolver.QUERY_ARG_LIMIT to limit,
            ContentResolver.QUERY_ARG_SORT_DIRECTION to ContentResolver.QUERY_SORT_DIRECTION_DESCENDING,
            ContentResolver.QUERY_ARG_SORT_COLUMNS to arrayOf(sortColumn),
        )
        contentResolver.query(uri, projection, queryArgs, null)
    } else {
        val sortOrder = "$sortColumn DESC LIMIT $limit"
        contentResolver.query(uri, projection, null, null, sortOrder)
    }
}

fun Context.getLatestMediaByDateId(uri: Uri = Files.getContentUri("external")): Long {
    val projection = arrayOf(
        BaseColumns._ID
    )
    try {
        val cursor = queryCursorDesc(uri, projection, Images.ImageColumns.DATE_TAKEN, 1)
        cursor?.use {
            if (cursor.moveToFirst()) {
                return cursor.getLongValue(BaseColumns._ID)
            }
        }
    } catch (ignored: Exception) {
    }
    return 0
}

// some helper functions were taken from https://github.com/iPaulPro/aFileChooser/blob/master/aFileChooser/src/com/ipaulpro/afilechooser/utils/FileUtils.java
fun Context.getRealPathFromURI(uri: Uri): String? {
    if (uri.scheme == "file") {
        return uri.path
    }

    if (isDownloadsDocument(uri)) {
        val id = DocumentsContract.getDocumentId(uri)
        if (id.areDigitsOnly()) {
            val newUri = ContentUris.withAppendedId(Uri.parse("content://downloads/public_downloads"), id.toLong())
            val path = getDataColumn(newUri)
            if (path != null) {
                return path
            }
        }
    } else if (isExternalStorageDocument(uri)) {
        val documentId = DocumentsContract.getDocumentId(uri)
        val parts = documentId.split(":")
        if (parts[0].equals("primary", true)) {
            return "${Environment.getExternalStorageDirectory().absolutePath}/${parts[1]}"
        }
    } else if (isMediaDocument(uri)) {
        val documentId = DocumentsContract.getDocumentId(uri)
        val split = documentId.split(":").dropLastWhile { it.isEmpty() }.toTypedArray()
        val type = split[0]

        val contentUri = when (type) {
            "video" -> Video.Media.EXTERNAL_CONTENT_URI
            "audio" -> Audio.Media.EXTERNAL_CONTENT_URI
            else -> Images.Media.EXTERNAL_CONTENT_URI
        }

        val selection = "_id=?"
        val selectionArgs = arrayOf(split[1])
        val path = getDataColumn(contentUri, selection, selectionArgs)
        if (path != null) {
            return path
        }
    }

    return getDataColumn(uri)
}

fun Context.getDataColumn(uri: Uri, selection: String? = null, selectionArgs: Array<String>? = null): String? {
    try {
        val projection = arrayOf(Files.FileColumns.DATA)
        val cursor = contentResolver.query(uri, projection, selection, selectionArgs, null)
        cursor?.use {
            if (cursor.moveToFirst()) {
                val data = cursor.getStringValue(Files.FileColumns.DATA)
                if (data != "null") {
                    return data
                }
            }
        }
    } catch (e: Exception) {
    }
    return null
}

private fun isMediaDocument(uri: Uri) = uri.authority == "com.android.providers.media.documents"

private fun isDownloadsDocument(uri: Uri) = uri.authority == "com.android.providers.downloads.documents"

private fun isExternalStorageDocument(uri: Uri) = uri.authority == "com.android.externalstorage.documents"


fun Context.launchActivityIntent(intent: Intent) {
    try {
        startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        toast(R.string.no_app_found)
    } catch (e: Exception) {
        showErrorToast(e)
    }
}

fun Context.getFilePublicUri(file: File, applicationId: String): Uri {
    var uri = if (file.isMediaFile()) {
        getMediaContentUri(file.absolutePath)
    } else {
        getMediaContent(file.absolutePath, Files.getContentUri("external"))
    }

    if (uri == null) {
        uri = FileProvider.getUriForFile(this, "$applicationId.provider", file)
    }

    return uri!!
}

fun Context.getMediaContentUri(path: String): Uri? {
    val uri = when {
        path.isImageFast() -> Images.Media.EXTERNAL_CONTENT_URI
        path.isVideoFast() -> Video.Media.EXTERNAL_CONTENT_URI
        else -> Files.getContentUri("external")
    }

    return getMediaContent(path, uri)
}

fun Context.getMediaContent(path: String, uri: Uri): Uri? {
    val projection = arrayOf(Images.Media._ID)
    val selection = Images.Media.DATA + "= ?"
    val selectionArgs = arrayOf(path)
    try {
        val cursor = contentResolver.query(uri, projection, selection, selectionArgs, null)
        cursor?.use {
            if (cursor.moveToFirst()) {
                val id = cursor.getIntValue(Images.Media._ID).toString()
                return Uri.withAppendedPath(uri, id)
            }
        }
    } catch (e: Exception) {
    }
    return null
}

fun Context.getNoMediaFoldersSync(): ArrayList<String> {
    val folders = ArrayList<String>()

    val uri = Files.getContentUri("external")
    val projection = arrayOf(Files.FileColumns.DATA)
    val selection = "${Files.FileColumns.MEDIA_TYPE} = ? AND ${Files.FileColumns.TITLE} LIKE ?"
    val selectionArgs = arrayOf(Files.FileColumns.MEDIA_TYPE_NONE.toString(), "%$NOMEDIA%")
    val sortOrder = "${Files.FileColumns.DATE_MODIFIED} DESC"
//    val OTGPath = config.OTGPath

    var cursor: Cursor? = null
    try {
        cursor = contentResolver.query(uri, projection, selection, selectionArgs, sortOrder)
        if (cursor?.moveToFirst() == true) {
            do {
                val path = cursor.getStringValue(Files.FileColumns.DATA) ?: continue
                val noMediaFile = File(path)
                if (getDoesFilePathExist(noMediaFile.absolutePath) && noMediaFile.name == NOMEDIA) {
                    folders.add(noMediaFile.parent)
                }
            } while (cursor.moveToNext())
        }
    } catch (ignored: Exception) {
    } finally {
        cursor?.close()
    }

    return folders
}

@RequiresApi(Build.VERSION_CODES.O)
fun Context.queryCursor(
    uri: Uri,
    projection: Array<String>,
    queryArgs: Bundle,
    showErrors: Boolean = false,
    callback: (cursor: Cursor) -> Unit
) {
    try {
        val cursor = contentResolver.query(uri, projection, queryArgs, null)
        cursor?.use {
            if (cursor.moveToFirst()) {
                do {
                    callback(cursor)
                } while (cursor.moveToNext())
            }
        }
    } catch (e: Exception) {
        if (showErrors) {
            showErrorToast(e)
        }
    }
}

fun Context.getFilenameFromUri(uri: Uri): String {
    return if (uri.scheme == "file") {
        File(uri.toString()).name
    } else {
        getFilenameFromContentUri(uri) ?: uri.lastPathSegment ?: ""
    }
}

fun Context.getMimeTypeFromUri(uri: Uri): String {
    var mimetype = uri.path?.getMimeType() ?: ""
    if (mimetype.isEmpty()) {
        try {
            mimetype = contentResolver.getType(uri) ?: ""
        } catch (e: IllegalStateException) {
        }
    }
    return mimetype
}


fun Context.ensurePublicUri(path: String, applicationId: String): Uri? {
    val uri = Uri.parse(path)
    return if (uri.scheme == "content") {
        uri
    } else {
        val newPath = if (uri.toString().startsWith("/")) uri.toString() else uri.path
        val file = File(newPath)
        getFilePublicUri(file, applicationId)
    }
}

fun Context.ensurePublicUri(uri: Uri, applicationId: String): Uri {
    return if (uri.scheme == "content") {
        uri
    } else {
        val file = File(uri.path)
        getFilePublicUri(file, applicationId)
    }
}

fun Context.getFilenameFromContentUri(uri: Uri): String? {
    val projection = arrayOf(
        OpenableColumns.DISPLAY_NAME
    )

    try {
        val cursor = contentResolver.query(uri, projection, null, null, null)
        cursor?.use {
            if (cursor.moveToFirst()) {
                return cursor.getStringValue(OpenableColumns.DISPLAY_NAME)
            }
        }
    } catch (e: Exception) {
    }
    return null
}

fun Context.getSizeFromContentUri(uri: Uri): Long {
    val projection = arrayOf(OpenableColumns.SIZE)
    try {
        val cursor = contentResolver.query(uri, projection, null, null, null)
        cursor?.use {
            if (cursor.moveToFirst()) {
                return cursor.getLongValue(OpenableColumns.SIZE)
            }
        }
    } catch (e: Exception) {
    }
    return 0L
}

fun Context.getCurrentFormattedDateTime(): String {
    val simpleDateFormat = SimpleDateFormat("yyyy_MM_dd_HH_mm_ss", Locale.ENGLISH)
    return simpleDateFormat.format(Date(System.currentTimeMillis()))
}


fun Context.getUriMimeType(path: String, newUri: Uri): String {
    var mimeType = path.getMimeType()
    if (mimeType.isEmpty()) {
        mimeType = getMimeTypeFromUri(newUri)
    }
    return mimeType
}

//fun Context.isAProApp() = packageName.startsWith("com.photogallery") && packageName.removeSuffix(".debug").endsWith(".pro")


fun Context.isPackageInstalled(pkgName: String): Boolean {
    return try {
        packageManager.getPackageInfo(pkgName, 0)
        true
    } catch (e: Exception) {
        false
    }
}

fun Context.grantReadUriPermission(uriString: String) {
    try {
        // ensure custom reminder sounds play well
        grantUriPermission("com.android.systemui", Uri.parse(uriString), Intent.FLAG_GRANT_READ_URI_PERMISSION)
    } catch (ignored: Exception) {
    }
}

fun Context.getDuration(path: String): Int? {
    val projection = arrayOf(
        MediaColumns.DURATION
    )

    val uri = getFileUri(path)
    val selection = if (path.startsWith("content://")) "${BaseColumns._ID} = ?" else "${MediaColumns.DATA} = ?"
    val selectionArgs = if (path.startsWith("content://")) arrayOf(path.substringAfterLast("/")) else arrayOf(path)

    try {
        val cursor = contentResolver.query(uri, projection, selection, selectionArgs, null)
        cursor?.use {
            if (cursor.moveToFirst()) {
                return Math.round(cursor.getIntValue(MediaColumns.DURATION) / 1000.toDouble()).toInt()
            }
        }
    } catch (ignored: Exception) {
    }

    return try {
        val retriever = MediaMetadataRetriever()
        retriever.setDataSource(path)
        Math.round(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)!!.toInt() / 1000f)
    } catch (ignored: Exception) {
        null
    }
}

fun Context.getTitle(path: String): String? {
    val projection = arrayOf(
        MediaColumns.TITLE
    )

    val uri = getFileUri(path)
    val selection = if (path.startsWith("content://")) "${BaseColumns._ID} = ?" else "${MediaColumns.DATA} = ?"
    val selectionArgs = if (path.startsWith("content://")) arrayOf(path.substringAfterLast("/")) else arrayOf(path)

    try {
        val cursor = contentResolver.query(uri, projection, selection, selectionArgs, null)
        cursor?.use {
            if (cursor.moveToFirst()) {
                return cursor.getStringValue(MediaColumns.TITLE)
            }
        }
    } catch (ignored: Exception) {
    }

    return try {
        val retriever = MediaMetadataRetriever()
        retriever.setDataSource(path)
        retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
    } catch (ignored: Exception) {
        null
    }
}

fun Context.getArtist(path: String): String? {
    val projection = arrayOf(
        Audio.Media.ARTIST
    )

    val uri = getFileUri(path)
    val selection = if (path.startsWith("content://")) "${BaseColumns._ID} = ?" else "${MediaColumns.DATA} = ?"
    val selectionArgs = if (path.startsWith("content://")) arrayOf(path.substringAfterLast("/")) else arrayOf(path)

    try {
        val cursor = contentResolver.query(uri, projection, selection, selectionArgs, null)
        cursor?.use {
            if (cursor.moveToFirst()) {
                return cursor.getStringValue(Audio.Media.ARTIST)
            }
        }
    } catch (ignored: Exception) {
    }

    return try {
        val retriever = MediaMetadataRetriever()
        retriever.setDataSource(path)
        retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
    } catch (ignored: Exception) {
        null
    }
}

fun Context.getAlbum(path: String): String? {
    val projection = arrayOf(
        Audio.Media.ALBUM
    )

    val uri = getFileUri(path)
    val selection = if (path.startsWith("content://")) "${BaseColumns._ID} = ?" else "${MediaColumns.DATA} = ?"
    val selectionArgs = if (path.startsWith("content://")) arrayOf(path.substringAfterLast("/")) else arrayOf(path)

    try {
        val cursor = contentResolver.query(uri, projection, selection, selectionArgs, null)
        cursor?.use {
            if (cursor.moveToFirst()) {
                return cursor.getStringValue(Audio.Media.ALBUM)
            }
        }
    } catch (ignored: Exception) {
    }

    return try {
        val retriever = MediaMetadataRetriever()
        retriever.setDataSource(path)
        retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)
    } catch (ignored: Exception) {
        null
    }
}

fun Context.getMediaStoreLastModified(path: String): Long {
    val projection = arrayOf(
        MediaColumns.DATE_MODIFIED
    )

    val uri = getFileUri(path)
    val selection = "${BaseColumns._ID} = ?"
    val selectionArgs = arrayOf(path.substringAfterLast("/"))

    try {
        val cursor = contentResolver.query(uri, projection, selection, selectionArgs, null)
        cursor?.use {
            if (cursor.moveToFirst()) {
                return cursor.getLongValue(MediaColumns.DATE_MODIFIED) * 1000
            }
        }
    } catch (ignored: Exception) {
    }
    return 0
}

val Context.telecomManager: TelecomManager get() = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
val Context.windowManager: WindowManager get() = getSystemService(Context.WINDOW_SERVICE) as WindowManager
val Context.notificationManager: NotificationManager get() = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
//val Context.shortcutManager: ShortcutManager get() = getSystemService(ShortcutManager::class.java) as ShortcutManager

val Context.portrait get() = resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
val Context.navigationBarOnSide: Boolean get() = usableScreenSize.x < realScreenSize.x && usableScreenSize.x > usableScreenSize.y
val Context.navigationBarOnBottom: Boolean get() = usableScreenSize.y < realScreenSize.y
val Context.navigationBarHeight: Int get() = if (navigationBarOnBottom && navigationBarSize.y != usableScreenSize.y) navigationBarSize.y else 0
val Context.navigationBarWidth: Int get() = if (navigationBarOnSide) navigationBarSize.x else 0

val Context.navigationBarSize: Point
    get() = when {
        navigationBarOnSide -> Point(newNavigationBarHeight, usableScreenSize.y)
        navigationBarOnBottom -> Point(usableScreenSize.x, newNavigationBarHeight)
        else -> Point()
    }

val Context.newNavigationBarHeight: Int
    get() {
        var navigationBarHeight = 0
        val resourceId = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        if (resourceId > 0) {
            navigationBarHeight = resources.getDimensionPixelSize(resourceId)
        }
        return navigationBarHeight
    }

val Context.statusBarHeight: Int
    get() {
        var statusBarHeight = 0
        val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
        if (resourceId > 0) {
            statusBarHeight = resources.getDimensionPixelSize(resourceId)
        }
        return statusBarHeight
    }

val Context.actionBarHeight: Int
    get() {
        val styledAttributes = theme.obtainStyledAttributes(intArrayOf(android.R.attr.actionBarSize))
        val actionBarHeight = styledAttributes.getDimension(0, 0f)
        styledAttributes.recycle()
        return actionBarHeight.toInt()
    }

val Context.usableScreenSize: Point
    get() {
        val size = Point()
        windowManager.defaultDisplay.getSize(size)
        return size
    }

val Context.realScreenSize: Point
    get() {
        val size = Point()
        windowManager.defaultDisplay.getRealSize(size)
        return size
    }

fun Context.isUsingGestureNavigation(): Boolean {
    return try {
        val resourceId = resources.getIdentifier("config_navBarInteractionMode", "integer", "android")
        if (resourceId > 0) {
            resources.getInteger(resourceId) == 2
        } else {
            false
        }
    } catch (e: Exception) {
        false
    }
}

fun Context.getResolution(path: String): Point? {
    return if (path.isImageFast() || path.isImageSlow()) {
        getImageResolution(path)
    } else if (path.isVideoFast() || path.isVideoSlow()) {
        getVideoResolution(path)
    } else {
        null
    }
}

//fun Context.getAndroidSAFUri(path: String): Uri {
//    val treeUri = getAndroidTreeUri(path).toUri()
//    val documentId = createAndroidSAFDocumentId(path)
//    return DocumentsContract.buildDocumentUriUsingTree(treeUri, documentId)
//}

fun Context.getImageResolution(path: String): Point? {
    val options = BitmapFactory.Options()
    options.inJustDecodeBounds = true
//    if (isRestrictedSAFOnlyRoot(path)) {
//        BitmapFactory.decodeStream(contentResolver.openInputStream(getAndroidSAFUri(path)), null, options)
//    } else {
        BitmapFactory.decodeFile(path, options)
//    }

    val width = options.outWidth
    val height = options.outHeight
    return if (width > 0 && height > 0) {
        Point(options.outWidth, options.outHeight)
    } else {
        null
    }
}

fun Context.getVideoResolution(path: String): Point? {
    var point = try {
        val retriever = MediaMetadataRetriever()
//        if (isRestrictedSAFOnlyRoot(path)) {
//            retriever.setDataSource(this, getAndroidSAFUri(path))
//        } else {
            retriever.setDataSource(path)
//        }

        val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)!!.toInt()
        val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)!!.toInt()
        Point(width, height)
    } catch (ignored: Exception) {
        null
    }

    if (point == null && path.startsWith("content://", true)) {
        try {
            val fd = contentResolver.openFileDescriptor(Uri.parse(path), "r")?.fileDescriptor
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(fd)
            val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)!!.toInt()
            val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)!!.toInt()
            point = Point(width, height)
        } catch (ignored: Exception) {
        }
    }

    return point
}


fun Context.queryCursor(
    uri: Uri,
    projection: Array<String>,
    selection: String? = null,
    selectionArgs: Array<String>? = null,
    sortOrder: String? = null,
    showErrors: Boolean = false,
    callback: (cursor: Cursor) -> Unit
) {
    try {
        val cursor = contentResolver.query(uri, projection, selection, selectionArgs, sortOrder)
        cursor?.use {
            if (cursor.moveToFirst()) {
                do {
                    callback(cursor)
                } while (cursor.moveToNext())
            }
        }
    } catch (e: Exception) {
        if (showErrors) {
            showErrorToast(e)
        }
    }
}

fun Context.getCornerRadius() = resources.getDimension(R.dimen.rounded_corner_radius_small)

// we need the Default Dialer functionality only in Simple Dialer and in Simple Contacts for now
//fun Context.getContactsHasMap(withComparableNumbers: Boolean = false, callback: (HashMap<String, String>) -> Unit) {
//    ContactsHelper(this).getContacts(showOnlyContactsWithNumbers = true) { contactList ->
//        val privateContacts: HashMap<String, String> = HashMap()
//        for (contact in contactList) {
//            for (phoneNumber in contact.phoneNumbers) {
//                var number = PhoneNumberUtils.stripSeparators(phoneNumber.value)
//                if (withComparableNumbers) {
//                    number = number.trimToComparableNumber()
//                }
//
//                privateContacts[number] = contact.name
//            }
//        }
//        callback(privateContacts)
//    }
//}

//@TargetApi(Build.VERSION_CODES.N)
//fun Context.getBlockedNumbersWithContact(callback: (ArrayList<BlockedNumber>) -> Unit) {
//    getContactsHasMap(true) { contacts ->
//        val blockedNumbers = ArrayList<BlockedNumber>()
//        if (!isNougatPlus() || !isDefaultDialer()) {
//            callback(blockedNumbers)
//        }
//
//        val uri = BlockedNumbers.CONTENT_URI
//        val projection = arrayOf(
//            BlockedNumbers.COLUMN_ID,
//            BlockedNumbers.COLUMN_ORIGINAL_NUMBER,
//            BlockedNumbers.COLUMN_E164_NUMBER,
//        )
//
//        queryCursor(uri, projection) { cursor ->
//            val id = cursor.getLongValue(BlockedNumbers.COLUMN_ID)
//            val number = cursor.getStringValue(BlockedNumbers.COLUMN_ORIGINAL_NUMBER) ?: ""
//            val normalizedNumber = cursor.getStringValue(BlockedNumbers.COLUMN_E164_NUMBER) ?: number
//            val comparableNumber = normalizedNumber.trimToComparableNumber()
//
//            val contactName = contacts[comparableNumber]
//            val blockedNumber = BlockedNumber(id, number, normalizedNumber, comparableNumber, contactName)
//            blockedNumbers.add(blockedNumber)
//        }
//
//        val blockedNumbersPair = blockedNumbers.partition { it.contactName != null }
//        val blockedNumbersWithNameSorted = blockedNumbersPair.first.sortedBy { it.contactName }
//        val blockedNumbersNoNameSorted = blockedNumbersPair.second.sortedBy { it.number }
//
//        callback(ArrayList(blockedNumbersWithNameSorted + blockedNumbersNoNameSorted))
//    }
//}

//@TargetApi(Build.VERSION_CODES.N)
//fun Context.getBlockedNumbers(): ArrayList<BlockedNumber> {
//    val blockedNumbers = ArrayList<BlockedNumber>()
//    if (!isNougatPlus() || !isDefaultDialer()) {
//        return blockedNumbers
//    }
//
//    val uri = BlockedNumbers.CONTENT_URI
//    val projection = arrayOf(
//        BlockedNumbers.COLUMN_ID,
//        BlockedNumbers.COLUMN_ORIGINAL_NUMBER,
//        BlockedNumbers.COLUMN_E164_NUMBER
//    )
//
//    queryCursor(uri, projection) { cursor ->
//        val id = cursor.getLongValue(BlockedNumbers.COLUMN_ID)
//        val number = cursor.getStringValue(BlockedNumbers.COLUMN_ORIGINAL_NUMBER) ?: ""
//        val normalizedNumber = cursor.getStringValue(BlockedNumbers.COLUMN_E164_NUMBER) ?: number
//        val comparableNumber = normalizedNumber.trimToComparableNumber()
//        val blockedNumber = BlockedNumber(id, number, normalizedNumber, comparableNumber)
//        blockedNumbers.add(blockedNumber)
//    }
//
//    return blockedNumbers
//}

//@TargetApi(Build.VERSION_CODES.N)
//fun Context.addBlockedNumber(number: String): Boolean {
//    ContentValues().apply {
//        put(BlockedNumbers.COLUMN_ORIGINAL_NUMBER, number)
//        if (number.isPhoneNumber()) {
//            put(BlockedNumbers.COLUMN_E164_NUMBER, PhoneNumberUtils.normalizeNumber(number))
//        }
//        try {
//            contentResolver.insert(BlockedNumbers.CONTENT_URI, this)
//        } catch (e: Exception) {
//            showErrorToast(e)
//            return false
//        }
//    }
//    return true
//}

//@TargetApi(Build.VERSION_CODES.N)
//fun Context.deleteBlockedNumber(number: String): Boolean {
//    val selection = "${BlockedNumbers.COLUMN_ORIGINAL_NUMBER} = ?"
//    val selectionArgs = arrayOf(number)
//
//    return if (isNumberBlocked(number)) {
//        val deletedRowCount = contentResolver.delete(BlockedNumbers.CONTENT_URI, selection, selectionArgs)
//
//        deletedRowCount > 0
//    } else {
//        true
//    }
//}

//fun Context.isNumberBlocked(number: String, blockedNumbers: ArrayList<BlockedNumber> = getBlockedNumbers()): Boolean {
//    if (!isNougatPlus()) {
//        return false
//    }
//
//    val numberToCompare = number.trimToComparableNumber()
//
//    return blockedNumbers.any {
//        numberToCompare == it.numberToCompare ||
//            numberToCompare == it.number ||
//            PhoneNumberUtils.stripSeparators(number) == it.number
//    } || isNumberBlockedByPattern(number, blockedNumbers)
//}

//fun Context.isNumberBlockedByPattern(number: String, blockedNumbers: ArrayList<BlockedNumber> = getBlockedNumbers()): Boolean {
//    for (blockedNumber in blockedNumbers) {
//        val num = blockedNumber.number
//        if (num.isBlockedNumberPattern()) {
//            val pattern = num.replace("+", "\\+").replace("*", ".*")
//            if (number.matches(pattern.toRegex())) {
//                return true
//            }
//        }
//    }
//    return false
//}

fun Context.openNotificationSettings() {
    if (isOreoPlus()) {
        val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
        intent.putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
        startActivity(intent)
    } else {
        // For Android versions below Oreo, you can't directly open the app's notification settings.
        // You can open the general notification settings instead.
        val intent = Intent(Settings.ACTION_SETTINGS)
        startActivity(intent)
    }
}

fun Context.getTempFile(folderName: String, filename: String): File? {
    val folder = File(cacheDir, folderName)
    if (!folder.exists()) {
        if (!folder.mkdir()) {
            toast(R.string.unknown_error_occurred)
            return null
        }
    }

    return File(folder, filename)
}

fun Context.openDeviceSettings() {
    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
        data = Uri.fromParts("package", packageName, null)
    }

    try {
        startActivity(intent)
    } catch (e: Exception) {
        showErrorToast(e)
    }
}

@RequiresApi(Build.VERSION_CODES.S)
fun Context.openRequestExactAlarmSettings(appId: String) {
    if (isSPlus()) {
        val uri = Uri.fromParts("package", appId, null)
        val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
        intent.data = uri
        startActivity(intent)
    }
}

fun Context.canUseFullScreenIntent(): Boolean {
    return !isUpsideDownCakePlus() || notificationManager.canUseFullScreenIntent()
}

@RequiresApi(Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
fun Context.openFullScreenIntentSettings(appId: String) {
    if (isUpsideDownCakePlus()) {
        val uri = Uri.fromParts("package", appId, null)
        val intent = Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT)
        intent.data = uri
        startActivity(intent)
    }
}

@SuppressLint("CheckResult")
fun Context.loadImage(
    path: String,
    target: ImageView,
    signature: ObjectKey,
    onError: (() -> Unit)? = null
) {
//    CoroutineScope(Dispatchers.Main).launch {

    val tryLoadingWithPicasso: Boolean = path.isPng()
//        val options = RequestOptions()
//            .signature(signature)
//            .centerCrop()
//            .dontAnimate()
//            .dontTransform()
//            .skipMemoryCache(false)
//            .priority(Priority.LOW)
//            .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
//            .format(DecodeFormat.DEFAULT)

    val options = RequestOptions()
        .signature(signature)
        .skipMemoryCache(false)
        .priority(Priority.LOW)
        .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
        .format(DecodeFormat.PREFER_ARGB_8888)

//    if (cropThumbnails) {
    options.optionalTransform(CenterCrop())
    options.optionalTransform(WebpDrawable::class.java, WebpDrawableTransformation(CenterCrop()))
//    } else {
//        options.optionalTransform(FitCenter())
//        options.optionalTransform(WebpDrawable::class.java, WebpDrawableTransformation(FitCenter()))
//    }
    if (path.isGif() || path.isWebP()) {
        options.decode(Drawable::class.java)
    } else {
        options.dontAnimate()
        options.decode(Bitmap::class.java)
    }

//    val cornerSize = R.dimen.rounded_corner_radius_small
//    val cornerRadius = resources.getDimension(cornerSize).toInt()
//    val roundedCornersTransform = RoundedCorners(cornerRadius)
//    options.optionalTransform(MultiTransformation(CenterCrop(), roundedCornersTransform))
//        options.optionalTransform(
//            WebpDrawable::class.java,
//            MultiTransformation(WebpDrawableTransformation(CenterCrop()), WebpDrawableTransformation(roundedCornersTransform))
//        )
//    }
    WebpBitmapFactory.sUseSystemDecoder = false
    var builder = Glide.with(applicationContext)
        .load(path)
        .apply(options)
        .placeholder(R.drawable.ic_image_placeholder)
        .set(WebpDownsampler.USE_SYSTEM_DECODER, false)
        .transition(getOptionalCrossFadeTransition(150))

    builder = builder.listener(object : RequestListener<Drawable> {

        override fun onLoadFailed(e: GlideException?, model: Any?, targetBitmap: Target<Drawable>, isFirstResource: Boolean): Boolean {
            if (tryLoadingWithPicasso) {
                tryLoadingWithPicasso(path, target, signature)
            } else {
                onError?.invoke()
            }

            return true
        }

        override fun onResourceReady(
            resource: Drawable,
            model: Any,
            targetBitmap: Target<Drawable>,
            dataSource: DataSource,
            isFirstResource: Boolean,
        ) = false

    })
    builder.into(target)
//        }
//    }
}

fun getOptionalCrossFadeTransition(duration: Int): DrawableTransitionOptions {
    return DrawableTransitionOptions.with(
        TransitionFactory { dataSource, isFirstResource ->
            if (dataSource == DataSource.RESOURCE_DISK_CACHE) return@TransitionFactory null
            DrawableCrossFadeFactory.Builder(duration).build().build(dataSource, isFirstResource)
        }
    )
}

fun Context.tryLoadingWithPicasso(path: String, view: ImageView, signature: ObjectKey) {
    var pathToLoad = "file://$path"
    pathToLoad = pathToLoad.replace("%", "%25").replace("#", "%23")

    try {
        var builder = Picasso.get()
            .load(pathToLoad)
            .stableKey(signature.toString())

        builder = builder.centerCrop().fit()

//        if (roundCorners != 1) {
//            val cornerSize = if (roundCorners == 2) R.dimen.rounded_corner_radius_small else R.dimen.rounded_corner_radius_big
//        val cornerSize = R.dimen.rounded_corner_radius_small
//        val cornerRadius = resources.getDimension(cornerSize).toInt()
//        builder = builder.transform(PicassoRoundedCornersTransformation(cornerRadius.toFloat()))
//        }

        builder.into(view)
    } catch (e: Exception) {
    }
}