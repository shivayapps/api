package com.photogallery.activities

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.photogallery.R
import com.photogallery.adapter.AlbumListAdapter
import com.photogallery.base.BaseActivity
import com.photogallery.customview.MyGridLayoutManager
import com.photogallery.database.AppDatabase
import com.photogallery.databinding.ActivityCategoriesListBinding
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.utils.Constant
import com.photogallery.utils.FastScroller
import com.photogallery.utils.Preferences
import com.photogallery.utils.Utils

class CategoriesListActivity : BaseActivity() {

    lateinit var dataBase: AppDatabase
    lateinit var preferences: Preferences
    var albumAdapter: AlbumListAdapter? = null
    var albumList: ArrayList<AlbumData> = ArrayList()

    lateinit var activity: Activity

    lateinit var binding: ActivityCategoriesListBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityCategoriesListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        activity = this@CategoriesListActivity
        preferences = Preferences(this)

        intView()
        getData()
    }

    private fun intView() {
        intListener()
        initAdapter()
    }

    private fun intListener() {
        binding.icBack.setOnClickListener {
            onBackPressed()
        }
    }

        val finalList: ArrayList<AlbumData> = ArrayList()
    fun getData() {
        dataBase = AppDatabase.getInstance(this)
        val categoriesList = dataBase.dataDao().getMediaByCategoryFetchStatus()
        Log.e("CategoriesList", "categoriesList:${categoriesList.size}")
        Log.e("CategoriesList", "categoriesList:${categoriesList}")
        val groupedData = categoriesList.groupBy {
            it.categories.firstOrNull() ?: "Unknown"
        }

        groupedData.forEach { (categoryName, categoryItems) ->

            val mediaList = ArrayList<MediaData>()

            categoryItems.forEach { category ->
                mediaList.add(
                    MediaData(
                        filePath = category.path,
                        fileName = category.path.substringAfterLast("/"),
                        fileUri = Utils.getUriFromPath(this@CategoriesListActivity, category.path).toString(),
                        folderName = category.path.substringBeforeLast("/"),
                        date = 0L,
                        dateTaken = 0L,
                        fileSize = 0L,
                        isVideo = false
                    )
                )
            }

            albumList.add(
                AlbumData(
                    title = categoryName,
                    mediaData = mediaList,
                    folderPath = "",
                    date = 0L,
                    fileSize = mediaList.sumOf { it.fileSize },
                    isCustomAlbum = true
                )
            )
        }

        albumAdapter?.submitList(albumList)

    }

    private fun initAdapter() {
        setRvLayoutManager()

        albumAdapter = AlbumListAdapter(
            activity,
            clickListener = {
                val albumData = albumList[it]
                openImageList(albumData)
            },
            longClickListener = {
            })

        albumAdapter?.submitList(albumList)
        binding.rvCategories.adapter = albumAdapter


        binding.rvCategories.post {
            FastScroller(binding.handleView).bind(binding.rvCategories)
        }
    }


    fun setRvLayoutManager() {
        val gridCount = 3
        val isGridShow = true
        if (isGridShow) {
            val layoutManager = binding.rvCategories.layoutManager as MyGridLayoutManager
            layoutManager.orientation = RecyclerView.VERTICAL
            layoutManager.spanCount = gridCount
            layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int): Int {
                    if (position >= 0 && position < albumList.size) {
                        return if (albumAdapter!!.getItemViewType(position) == albumAdapter!!.ITEM_ALBUM_UTIL_TYPE) {
                            gridCount
                        } else 1
                    } else {
                        return 1
                    }
                }
            }
        } else {
            val layoutManager = binding.rvCategories.layoutManager as MyGridLayoutManager
            layoutManager.spanCount = 1
            layoutManager.orientation = RecyclerView.VERTICAL
//            mZoomListener = null
        }
    }

    public fun openImageList(albumData: AlbumData) {

        Constant.albumData = AlbumData(
            albumData.title,
            albumData.mediaData,
            albumData.folderPath,
            albumData.date,
            albumData.fileSize
        )

        val intent = Intent(activity, ImageGalleryActivity::class.java)
        imageListLauncher.launch(intent)
    }

    private var imageListLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { _ ->
            //removeNonExistingMediaData()
        }


    private fun setEmptyData() {
        if (albumList != null && albumList.size != 0) {
            binding.rvCategories.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
            binding.llAdPlace.beVisible()
        } else {
            binding.rvCategories.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
            binding.llAdPlace.beGone()
        }
    }
}