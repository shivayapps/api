package com.photogallery.views.bottomtab

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.photogallery.R
import com.photogallery.utils.MyBounceInterpolator

class BottomTabItem @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    private val container: LinearLayout
    private val icon: ImageView
    private val title: TextView

    private var normalIconRes: Int = 0
    private var selectedIconRes: Int = 0

    var isSelectedTab = false
        set(value) {
            if (field == value) return   // 🔒 avoid re-trigger
            field = value
            updateState()
        }

    init {
        LayoutInflater.from(context).inflate(R.layout.item_bottom_tab, this, true)
        container = findViewById(R.id.container)
        icon = findViewById(R.id.icon)
        title = findViewById(R.id.title)

        updateState()
    }

    fun setData(
        normalIcon: Int,
        selectedIcon: Int,
        text: String
    ) {
        normalIconRes = normalIcon
        selectedIconRes = selectedIcon
        title.text = text
        updateIcon()
    }

    private fun updateState() {
        if (isSelectedTab) {
//            container.orientation = LinearLayout.HORIZONTAL
//            title.setPadding(8, 0, 0, 0)
            playBounceAnimation()
        } else {
//            container.orientation = LinearLayout.VERTICAL
//            title.setPadding(0, 4, 0, 0)
            icon.clearAnimation()
        }

        updateIcon()
    }

    private fun updateIcon() {
        if (isSelectedTab && selectedIconRes != 0) {
            icon.setImageResource(selectedIconRes)
        } else if (normalIconRes != 0) {
            icon.setImageResource(normalIconRes)
        }
    }

    private fun playBounceAnimation() {
        val anim = AnimationUtils.loadAnimation(context, R.anim.bounce)
        val interpolator = MyBounceInterpolator(0.2, 20.0)
        anim.interpolator = interpolator
        anim.repeatMode = Animation.RESTART
        icon.startAnimation(anim)
    }
}
