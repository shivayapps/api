package com.photogallery.secret.activity

import android.graphics.Color
import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import com.photogallery.R
import com.photogallery.base.BaseActivity
import com.photogallery.base.BaseNoThemeActivity
import com.photogallery.databinding.ActivityLockBinding
import com.photogallery.extension.showBiometricPrompt
import com.photogallery.extension.toast
import com.photogallery.secret.fragment.LockFragment
import com.photogallery.utils.Preferences


class ResetLockActivity : BaseActivity() {

    lateinit var preferences: Preferences

    lateinit var binding: ActivityLockBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLockBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
//        WindowCompat.getInsetsController(window, window.decorView).apply {
//            isAppearanceLightStatusBars = false
//            isAppearanceLightNavigationBars = true
//        }
        //updateStatusBarColor(Color.parseColor("#161616"))

        preferences = Preferences(this)

        intView()

    }

    private fun setPasswordSuccess() {
         //startActivity(Intent(this, PrivateActivity::class.java))
        setResult(RESULT_OK)
        (this@ResetLockActivity).finish()
    }

    private fun startAndroidxBiometricManager() {
//        AuthPromptHost(activity as FragmentActivity)
        showBiometricPrompt(successCallback = { icSuccess ->
            if (icSuccess) {
                setPasswordSuccess()
            }
        }, failureCallback = { icFailed: Boolean, errorCode: Int, errString: CharSequence ->
            Log.e("BiometricManager","\nicFailed:$icFailed,\nerrorCode:$errorCode,errString:$errString")
            toast(R.string.authentication_failed)
        })

    }

    private fun intView() {
//        if (isChangeLockStyle) {
//            loadFragment(LockChangeStyleFragment(this, isLockStyleGrid, lockListener = {
//                setResult(RESULT_OK)
//                finish()
//            }))
//        } else {
            loadFragment(
                LockFragment(
                    this,
                    false,
                    false,
                    lockListener = {
                        if (it) {
                            setPasswordSuccess()
                        } else {
                            finish()
                        }
                    }
                )
            )
//        }
    }

    private fun loadFragment(fragment: Fragment) {
        val fm = this.supportFragmentManager
        val fragmentTransaction = fm.beginTransaction()
        fragmentTransaction.replace(R.id.container_lock, fragment)
        fragmentTransaction.commit()
    }

}