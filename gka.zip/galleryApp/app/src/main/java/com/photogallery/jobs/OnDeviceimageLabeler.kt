package com.photogallery.jobs


import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.annotation.WorkerThread
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ExecutionException
import kotlin.apply
import kotlin.collections.filter
import kotlin.collections.map
import kotlin.run
import kotlin.text.equals
import kotlin.to

class OnDeviceImageLabeler {
    companion object {
        const val OTHERS = ""
//        const val OTHERS = "Others"
        private val options = ImageLabelerOptions.Builder().setConfidenceThreshold(0.8f).build()

        @WorkerThread
        suspend fun detectLabel(
            context: Context,
            accuracyLevel: Double,
            filePath: String
        ): List<String> = withContext(Dispatchers.IO) {
            try {
                val labeler = ImageLabeling.getClient(options)

                return@withContext try {
                    val (screenWidth, screenHeight) = getScreenSize(context)
                    val bitmap = decodeDownsampledBitmap(filePath, screenWidth, screenHeight)
                        ?: return@withContext listOf(OTHERS)
                    val inputImage = InputImage.fromBitmap(bitmap, 0)

                    val labels = synchronized(this) {
                        Tasks.await(labeler.process(inputImage))
                    }
                    if (labels.size == 0) return@withContext listOf(OTHERS)
                    var list = labels.filter { it.confidence > accuracyLevel }.map { it.text }
                    if (list.isEmpty()) {
                        list = labels.filter { it.confidence > accuracyLevel - 5 }.map { it.text }
                    }
                    if (list.isEmpty()) {
                        list = labels.filter { it.confidence > accuracyLevel - 5 }.map { it.text }
                    }
                    (list as ArrayList<String>).removeIf { it.equals(OTHERS, ignoreCase = true) }
                    list
                } catch (e: ExecutionException) {
                    listOf(OTHERS)
                } catch (e: InterruptedException) {
                    listOf(OTHERS)
                } catch (e: Exception) {
                    e.printStackTrace()
                    listOf(OTHERS)
                } finally {
                    labeler.close()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            listOf(OTHERS)
        }

        private fun decodeDownsampledBitmap(
            filePath: String,
            reqWidth: Int,
            reqHeight: Int
        ): Bitmap? {
            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
                BitmapFactory.decodeFile(filePath, this)

                inSampleSize = calculateInSampleSize(this, reqWidth, reqHeight)
                inJustDecodeBounds = false
                inPreferredConfig = Bitmap.Config.RGB_565
            }

            return BitmapFactory.decodeFile(filePath, options)
        }

        private fun calculateInSampleSize(
            options: BitmapFactory.Options,
            reqWidth: Int,
            reqHeight: Int
        ): Int {
            val (height: Int, width: Int) = options.run { outHeight to outWidth }
            var inSampleSize = 1

            if (height > reqHeight || width > reqWidth) {
                val halfHeight: Int = height / 2
                val halfWidth: Int = width / 2

                while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                    inSampleSize *= 2
                }
            }
            return inSampleSize
        }

        fun getScreenSize(context: Context): Pair<Int, Int> {
            val displayMetrics = context.resources.displayMetrics
            return Pair(displayMetrics.widthPixels, displayMetrics.heightPixels)
        }
    }

}