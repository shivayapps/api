package com.photogallery.utils

import android.app.Application
import android.content.Context
import android.util.Log
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.gson.Gson
import com.photogallery.R
import com.photogallery.extension.toList
import com.photogallery.jobs.MomentModel
import org.json.JSONObject
import kotlin.ranges.until
import kotlin.text.isNotEmpty

object MemoryCategoryAppsConfig {

//    fun getConfig(remoteConfig: FirebaseRemoteConfig) {
//        try {
//            val jsonArrayString = remoteConfig.getString("appMemoryCategory")
//            if (jsonArrayString.isNotEmpty()) {
//                GalleryApp.preferences.appMemoryCategory = jsonArrayString
//            }
//            Log.e("MemoryCategoryAppsConfig", "appMemoryCategory:$jsonArrayString")
//        } catch (e: Exception) {
//
//            e.printStackTrace()
//            GalleryApp.preferences.appMemoryCategory = ""
//        }
//    }

    fun getMomentLists(context:Context,preferences: Preferences): ArrayList<MomentModel> {
        val momentModelList = kotlin.collections.ArrayList<MomentModel>()
        try {
//            val jsonObjFamily = JSONObject(preferences.appMemoryCategory)
            val jsonObjFamily = JSONObject(context.getString(R.string.appMemoryCategory))
            val jsonArray = jsonObjFamily.getJSONArray("categories")
            for (i in 0 until jsonArray.length()) {
                val jsonObject = jsonArray.getJSONObject(i)
                momentModelList.add(
                    MomentModel(
                        jsonObject.getString("name"),
                        jsonObject.getJSONArray("sub_categories").toList()
                    )
                )
            }
            Log.e("MemoryCategoryAppsConfig", "categories:${Gson().toJson(jsonArray)}")
            return momentModelList
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return kotlin.collections.ArrayList()
    }

    fun getMomentAccuracyLevel(context:Context,preferences: Preferences): Double {
        try {
//            val jsonObjFamily = JSONObject(preferences.appMemoryCategory)
            val jsonObjFamily = JSONObject(context.getString(R.string.appMemoryCategory))
            Log.e("MemoryCategoryAppsConfig", "getMomentAccuracyLevel:${Gson().toJson(jsonObjFamily)}")
//            return jsonObjFamily.getDouble("accuracyLevel") / 100.0
            return 90 / 100.0
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return 0.90
    }

    fun isMomentEnabled(context:Context,preferences: Preferences): Boolean {
        try {
//            val jsonObjFamily = JSONObject(preferences.appMemoryCategory)
            val jsonObjFamily = JSONObject(context.getString(R.string.appMemoryCategory))
            Log.e("MemoryCategoryAppsConfig", "isMomentEnabled:${Gson().toJson(jsonObjFamily)}")
            return jsonObjFamily.getBoolean("showMoment")
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return true
    }
}