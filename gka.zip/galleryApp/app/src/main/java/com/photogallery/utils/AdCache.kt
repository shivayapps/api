package com.photogallery.utils

import com.google.android.gms.ads.AdView

class AdCache {
    companion object {
        var homeAdView:AdView?=null
        var albumAdView:AdView?=null
        var exploreAlbumAdView:AdView?=null
        var imageListAdView:AdView?=null
        var pdfListAdView:AdView?=null
        var pdfReaderAdView:AdView?=null
        var recentlyDeletedAdView:AdView?=null
        var mapExploreAdView:AdView?=null
        var privateViewerAdView:AdView?=null
        var privateAdView:AdView?=null
        var privateListAdView:AdView?=null
        var photoVideoAdView:AdView?=null
        var favoriteListAdView:AdView?=null
        var cleanerAdView:AdView?=null


    }
}


