package com.photogallery.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters

@Entity(tableName = "categories")
@TypeConverters(DatabaseConverters::class)
data class Categories(
    @PrimaryKey(autoGenerate = true)
    var catId: Long = 0,
    var isCategoryFetch: Int = 0,
    var path: String,
    var categories: List<String> = emptyList(),
    var mainCategories: List<String> = emptyList(),
)
