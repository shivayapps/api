package com.photogallery.utils

import android.content.Context
import android.graphics.*
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.photogallery.R

class GridScaleGestureManager(
    private val recyclerView: RecyclerView,
    context: Context,
    private var currentSpan: Int,
    private val minSpan: Int = 2,
    private val maxSpan: Int = 8,
    private val onSpanUpdated: (Int) -> Unit
) : RecyclerView.ItemDecoration() {

    init {
        recyclerView.addItemDecoration(this)
        recyclerView.setOnTouchListener { _, event ->
            scaleGestureDetector.onTouchEvent(event)

            if (event.action == MotionEvent.ACTION_UP ||
                event.action == MotionEvent.ACTION_CANCEL
            ) {
                if (isScaling) applyTempSpan()
            }
            false
        }
    }

    private var gestureCenterX = -1f
    private var gestureCenterY = -1f

    private var tempSpan = currentSpan
    private var scaleAccumulator = 1f
    private var isScaling = false

    private var overlayVisible = false

    private val scaleGestureDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {

            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                isScaling = true
                overlayVisible = true
//                tempSpan = currentSpan
                tempSpan = currentSpan.coerceIn(minSpan, maxSpan)
                scaleAccumulator = 1f
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                gestureCenterX = detector.focusX
                gestureCenterY = detector.focusY


                scaleAccumulator *= detector.scaleFactor
                val threshold = 1.10f
                val previousSpan = tempSpan

                // Zoom Out → decrease columns = bigger items
                if (scaleAccumulator > threshold) {
                    tempSpan = (tempSpan - 1).coerceAtLeast(minSpan)
                    scaleAccumulator = 1f
                }
                // Zoom In → increase columns = smaller items
                else if (scaleAccumulator < (1f / threshold)) {
                    tempSpan = (tempSpan + 1).coerceAtMost(maxSpan)
                    scaleAccumulator = 1f
                }

                if (tempSpan != previousSpan) {
                    performHaptic()
                }

                tempSpan = tempSpan.coerceIn(minSpan, maxSpan)
                recyclerView.invalidateItemDecorations()
                return true
            }


            override fun onScaleEnd(detector: ScaleGestureDetector) {
                applyTempSpan()
            }
        })

    private fun performHaptic() {
        recyclerView.performHapticFeedback(
            HapticFeedbackConstants.VIRTUAL_KEY,
            HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
        )
    }


    private fun applyTempSpan() {
        isScaling = false
        overlayVisible = false
//        currentSpan = tempSpan
        currentSpan = tempSpan.coerceIn(minSpan, maxSpan)
        onSpanUpdated(currentSpan)

    }

    private val gradientPaint = Paint().apply {
        isAntiAlias = true
    }


    private val gridPaint = Paint().apply {
        color = Color.WHITE
        strokeWidth = 4f
        alpha = 140
    }

    private val capsulePadding = 24f

    private val textBgPaint = Paint().apply {
        color = Color.BLACK
        alpha = 150
        style = Paint.Style.FILL
    }
    private val bgPaint = Paint().apply {
        color = Color.parseColor("#80000000") // semi-black
        isAntiAlias = true
    }

    var titleSize = context.resources.getDimension(com.intuit.sdp.R.dimen._45sdp)
    private val textPaint = Paint().apply {
        color = Color.WHITE
        textSize = titleSize
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }

    fun onDrawOver1(c: Canvas, parent: RecyclerView, state: RecyclerView.State) {
        if (!overlayVisible) return

        val width = parent.width.toFloat()
        val height = parent.height.toFloat()
        val colWidth = width / tempSpan

        // Fill Paint (transparency inside cells)
        val fillPaint = Paint().apply {
            color = Color.WHITE
            alpha = 55 // adjust (40-100 recommended)
            style = Paint.Style.FILL
        }

        // Draw transparent white blocks between lines
        val rowHeight = colWidth
        val rowCount = (height / rowHeight).toInt()

        for (row in 0 until rowCount) {
            for (col in 0 until tempSpan) {
                val left = col * colWidth
                val top = row * rowHeight
                val right = left + colWidth
                val bottom = top + rowHeight
                c.drawRect(left, top, right, bottom, fillPaint)
            }
        }

        // Draw grid lines on top
        for (i in 1 until tempSpan) {
            val x = i * colWidth
            c.drawLine(x, 0f, x, height, gridPaint)
        }

        for (i in 1 until rowCount) {
            val y = i * rowHeight
            c.drawLine(0f, y, width, y, gridPaint)
        }

        //c.drawText("${tempSpan}", width / 2f, height / 2f, textPaint)

        // ------- Draw capsule + text --------
        val text = "$tempSpan"

        // Measure text width/height
        val textBounds = Rect()
        textPaint.getTextBounds(text, 0, text.length, textBounds)

        val textWidth = textBounds.width().toFloat()
        val textHeight = textBounds.height().toFloat()

        // Capsule positioning
        val centerX = width / 2f
        val centerY = height / 2f

        val bgLeft = centerX - (textWidth / 2f) - capsulePadding
        val bgRight = centerX + (textWidth / 2f) + capsulePadding
        val bgTop = centerY - (textHeight / 2f) - capsulePadding
        val bgBottom = centerY + (textHeight / 2f) + capsulePadding

        val capsuleRect = RectF(bgLeft, bgTop, bgRight, bgBottom)

        // Rounded capsule
        c.drawRoundRect(capsuleRect, 40f, 40f, textBgPaint)

        // Draw text vertical alignment fix
        val textCenterY = centerY + textHeight / 3f
        c.drawText(text, centerX, textCenterY, textPaint)


    }

    override fun onDrawOver(c: Canvas, parent: RecyclerView, state: RecyclerView.State) {
        if (!overlayVisible) return

        val width = parent.width
        val height = parent.height

        // ===== GRADIENT CIRCLE AT PINCH CENTER =====
        if (gestureCenterX >= 0 && gestureCenterY >= 0) {

            val radius = 220f // change if needed

            val gradient = RadialGradient(
                gestureCenterX,
                gestureCenterY,
                radius,
                intArrayOf(
                    Color.parseColor("#55FFFFFF"), // center bright
                    Color.parseColor("#00FFFFFF")  // fade to transparent
                ),
                floatArrayOf(0f, 1f),
                Shader.TileMode.CLAMP
            )

            gradientPaint.shader = gradient
            c.drawCircle(gestureCenterX, gestureCenterY, radius, gradientPaint)
        }

        // ===== CENTER CAPSULE WITH SPAN NUMBER =====
        val text = tempSpan.toString()
        val textBounds = Rect()
        textPaint.getTextBounds(text, 0, text.length, textBounds)

        val padding = 36f
        val bgWidth = textBounds.width() + padding * 2
        val bgHeight = textBounds.height() + padding * 2

        val centerX = width / 2f
        val centerY = height / 2f

        val left = centerX - bgWidth / 2
        val top = centerY - bgHeight / 2
        val right = centerX + bgWidth / 2
        val bottom = centerY + bgHeight / 2

        // capsule background
        val bgRect = RectF(left, top, right, bottom)
        c.drawRoundRect(bgRect, 50f, 50f, bgPaint)

        // centered text
        val textX = centerX
        val textY = centerY - textBounds.exactCenterY()
        c.drawText(text, textX, textY, textPaint)

        // ===== GRID (VERTICAL + HORIZONTAL) =====
        val colWidth = width.toFloat() / tempSpan

        // vertical lines
        for (i in 1 until tempSpan) {
            val x = i * colWidth
            c.drawLine(x, 0f, x, height.toFloat(), gridPaint)
        }

        // horizontal lines
        val rowHeight = colWidth
        val rowCount = (height / rowHeight).toInt()
        for (i in 1 until rowCount) {
            val y = i * rowHeight
            c.drawLine(0f, y, width.toFloat(), y, gridPaint)
        }
    }


}
