package com.photogallery.views.bottomnav

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.animation.ValueAnimator
import android.view.animation.DecelerateInterpolator
import android.view.MotionEvent
import android.annotation.SuppressLint
import android.animation.ArgbEvaluator
import android.content.res.XmlResourceParser
import android.graphics.*
import android.graphics.drawable.Drawable
import android.graphics.drawable.StateListDrawable
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.core.graphics.drawable.DrawableCompat
import com.photogallery.R
import com.photogallery.views.bottomnav.Constants.DEFAULT_TEXT_COLOR
import com.photogallery.views.bottomnav.Constants.DEFAULT_TEXT_COLOR_ACTIVE
import com.photogallery.views.bottomnav.Constants.WHITE_COLOR_HEX
import com.photogallery.views.bottomnav.BottomBarItem
import kotlin.math.abs

class NiceBottomBar : View {

    public interface OnItemListener {
        fun onItemLongClick(pos: Int)
        fun onItemReselect(pos: Int)
        fun onItemSelect(pos: Int)
    }

    private var barBackgroundColor = Color.parseColor(WHITE_COLOR_HEX)

    private var itemIconSize = d2p(18f)
    private var itemIconMargin = d2p(3f)
    private var showText = true

    private var itemTextColor = Color.parseColor(DEFAULT_TEXT_COLOR)
    private var itemTextColorActive = Color.parseColor(DEFAULT_TEXT_COLOR_ACTIVE)
    private var itemTextSize = d2p(11.0f)
    private var itemBadgeColor = itemTextColorActive
    private var itemFontFamily = 0
    private var activeItem = 0
    private var iconScale = 1f
    private var iconTranslateY = 0f
    private var textAlpha = 1f
    private var textTranslateY = d2p(0f)
    private var bounceScale = 1f



    private var currentActiveItemColor = itemTextColorActive

    private var longPressTime = 500
    private val titleSideMargins = d2p(12f)

    private var items = listOf<BottomBarItem>()

    private var onItemSelectedListener: OnItemListener? = null

    var onItemSelected: (Int) -> Unit = {}
    var onItemReselected: (Int) -> Unit = {}
    var onItemLongClick: (Int) -> Unit = {}


    private val paintText = Paint().apply {
        isAntiAlias = true
        style = Paint.Style.FILL
        color = itemTextColor
        textSize = itemTextSize
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private val paintBadge = Paint().apply {
        isAntiAlias = true
        style = Paint.Style.FILL
        color = itemBadgeColor
        strokeWidth = 4f
    }

    constructor(context: Context) : super(context)
    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        val typedArray = context.theme.obtainStyledAttributes(attrs, R.styleable.NiceBottomBar, 0, 0)
        barBackgroundColor = typedArray.getColor(R.styleable.NiceBottomBar_backgroundColor, this.barBackgroundColor)
        showText = typedArray.getBoolean(R.styleable.NiceBottomBar_showText, true)

        itemTextColor = typedArray.getColor(R.styleable.NiceBottomBar_textColor, this.itemTextColor)
        itemTextColorActive = typedArray.getColor(R.styleable.NiceBottomBar_textColorActive, this.itemTextColorActive)
        currentActiveItemColor = typedArray.getColor(R.styleable.NiceBottomBar_textColorActive, this.itemTextColorActive)
        itemTextSize = typedArray.getDimension(R.styleable.NiceBottomBar_textSize, this.itemTextSize)
        itemIconSize = typedArray.getDimension(R.styleable.NiceBottomBar_iconSize, this.itemIconSize)
        itemIconMargin = typedArray.getDimension(R.styleable.NiceBottomBar_iconMargin, this.itemIconMargin)
        activeItem = typedArray.getInt(R.styleable.NiceBottomBar_activeItem, this.activeItem)
        itemBadgeColor = typedArray.getColor(R.styleable.NiceBottomBar_badgeColor, this.itemBadgeColor)
        itemFontFamily = typedArray.getResourceId(R.styleable.NiceBottomBar_itemFontFamily, this.itemFontFamily)
//        items = BottomBarParser(context, typedArray.getResourceId(R.styleable.NiceBottomBar_menu, 0)).parse()
        items = parse(typedArray.getResourceId(R.styleable.NiceBottomBar_menu, 0))
        typedArray.recycle()

        setBackgroundColor(barBackgroundColor)

        paintText.color = itemTextColor
        paintText.textSize = itemTextSize
        paintBadge.color = itemBadgeColor

        if (itemFontFamily != 0)
            paintText.typeface = ResourcesCompat.getFont(context, itemFontFamily)
    }


    fun parse(menu: Int): List<BottomBarItem> {
        val parser: XmlResourceParser = context.resources.getXml(menu)
        val items: MutableList<BottomBarItem> = mutableListOf()
        var eventType: Int?

        do {
            eventType = parser.next()

            if (eventType == XmlResourceParser.START_TAG && parser.name == Constants.ITEM_TAG)
                items.add(getTabConfig(parser))

        } while (eventType != XmlResourceParser.END_DOCUMENT)

        return items.toList()
    }

    private fun getTabConfig1(parser: XmlResourceParser): BottomBarItem {
        val attributeCount = parser.attributeCount
        var itemText: String? = null
        var itemDrawable: Drawable? = null

        for (i in 0 until attributeCount)
            when (parser.getAttributeName(i)) {
                Constants.ICON_ATTRIBUTE -> itemDrawable =
                    ContextCompat.getDrawable(context, parser.getAttributeResourceValue(i, 0))

                Constants.TITLE_ATTRIBUTE -> {
                    itemText = try {
                        context.getString(parser.getAttributeResourceValue(i, 0))
                    } catch (e: Exception) {
                        parser.getAttributeValue(i)
                    }
                }
            }

        return BottomBarItem(itemText!!, itemDrawable!!, itemDrawable!!)
    }

    private fun getTabConfig(parser: XmlResourceParser): BottomBarItem {
        val attributeCount = parser.attributeCount
        var itemText: String? = null
        var iconDrawable: Drawable? = null
        var activeDrawable: Drawable? = null

        for (i in 0 until attributeCount) {
            when (parser.getAttributeName(i)) {
                Constants.ICON_ATTRIBUTE -> {
                    val resId = parser.getAttributeResourceValue(i, 0)
                    val drawable = ContextCompat.getDrawable(context, resId)

                    if (drawable is StateListDrawable) {
                        val tempCheckedState = intArrayOf(android.R.attr.state_checked)
                        val tempUncheckedState = intArrayOf(-android.R.attr.state_checked)

                        drawable.state = tempCheckedState
                        activeDrawable = drawable.current?.mutate()

                        drawable.state = tempUncheckedState
                        iconDrawable = drawable.current?.mutate()
                    } else {
                        iconDrawable = drawable?.mutate()
                        activeDrawable = drawable?.mutate()
                    }
                }

                Constants.TITLE_ATTRIBUTE -> {
                    itemText = try {
                        context.getString(parser.getAttributeResourceValue(i, 0))
                    } catch (e: Exception) {
                        parser.getAttributeValue(i)
                    }
                }
            }
        }

        return BottomBarItem(
            title = itemText ?: "",
            icon = iconDrawable ?: error("Missing icon"),
            activeIcon = activeDrawable ?: iconDrawable!!
        )
    }


    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)

        var lastX = 0f
        val itemWidth = width / items.size

        for (item in items) {
            if (showText) {
                var shorted = false
                while (paintText.measureText(item.title) > (itemWidth - titleSideMargins)) {
                    item.title = item.title.dropLast(1)
                    shorted = true
                }
                if (shorted) {
                    item.title = item.title.dropLast(1) + "…"
                }
            }

            item.rect = RectF(lastX, 0f, itemWidth + lastX, height.toFloat())
            lastX += itemWidth
        }

        // Set initial active item
        setActiveItem(activeItem)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val textHeight = (paintText.descent() + paintText.ascent()) / 2

        // Push the item components from the top a bit if the indicator is at the top
//        val additionalTopMargin = if (barIndicatorGravity == 1) 0f else 10f
        val additionalTopMargin = 10f

        val iconCenterY = if (showText) {
            height / 2 - itemIconSize.toInt() / 2 - itemIconMargin.toInt() + additionalTopMargin.toInt()
        } else {
            height / 2 - itemIconSize.toInt() / 2
        }

        for ((i, item) in items.withIndex()) {


            val iconToDraw = if (i == activeItem) item.activeIcon else item.icon

            iconToDraw.mutate()
//            iconToDraw.setBounds(
//                item.rect.centerX().toInt() - itemIconSize.toInt() / 2,
//                height / 2 - itemIconSize.toInt() - itemIconMargin.toInt() / 2 + additionalTopMargin.toInt(),
//                item.rect.centerX().toInt() + itemIconSize.toInt() / 2,
//                height / 2 - itemIconMargin.toInt() / 2 + additionalTopMargin.toInt()
//            )
            iconToDraw.setBounds(
                item.rect.centerX().toInt() - itemIconSize.toInt() / 2,
                iconCenterY,
                item.rect.centerX().toInt() + itemIconSize.toInt() / 2,
                iconCenterY + itemIconSize.toInt()
            )

            DrawableCompat.setTint(iconToDraw, if (i == activeItem) currentActiveItemColor else itemTextColor)

//            val scale = if (i == activeItem) iconScale else 1f
//            val translateY = if (i == activeItem) iconTranslateY else 0f

            val scale = if (i == activeItem) bounceScale else 1f

            canvas.save()
            canvas.scale(
                scale,
                scale,
                item.rect.centerX(),
                (iconCenterY + itemIconSize / 2).toFloat() // icon center
            )

            iconToDraw.draw(canvas)
            canvas.restore()



            // Draw item title
//            if (showText) {
//                paintText.color = if (i == activeItem) currentActiveItemColor else itemTextColor
//                canvas.drawText(
//                    item.title,
//                    item.rect.centerX(),
//                    item.rect.centerY() - textHeight + itemIconSize / 2 + (itemIconMargin / 2) + additionalTopMargin,
//                    paintText
//                )
//            }
            if (showText) {
                paintText.color =
                    if (i == activeItem) currentActiveItemColor else itemTextColor

                paintText.alpha =
                    if (i == activeItem) (255 * textAlpha).toInt() else 120

                val ty = if (i == activeItem) textTranslateY else d2p(4f)

                canvas.drawText(
                    item.title,
                    item.rect.centerX(),
                    item.rect.centerY() + ty - textHeight +
                            itemIconSize / 2 + itemIconMargin / 2 + additionalTopMargin,
                    paintText
                )
            }
            paintText.alpha = 255


//            this.paintText.color = if (i == activeItem) currentActiveItemColor else itemTextColor
//            canvas.drawText(
//                item.title, item.rect.centerX(),
//                item.rect.centerY() - textHeight + itemIconSize / 2 + (this.itemIconMargin / 2) + additionalTopMargin, paintText
//            )

            // Draw item badge
            if (item.badgeSize > 0) drawBadge(canvas, item)

            // Draw capsule background behind active icon
//            if (i == activeItem) {
////                val capsuleWidth = (itemIconSize + d2p(16f)) * capsuleScale
////                val capsuleHeight = (itemIconSize + d2p(8f)) * capsuleScale
//                val capsuleWidth = itemIconSize * 2.3f * capsuleScale
//                val capsuleHeight = itemIconSize * 1.2f * capsuleScale
//
//                val verticalPadding = d2p(3f) // You can adjust this value
//
//                val capsuleRect = RectF(
//                    item.rect.centerX() - capsuleWidth / 2,
//                    height / 2 - itemIconSize - itemIconMargin / 2 + additionalTopMargin - verticalPadding,
//                    item.rect.centerX() + capsuleWidth / 2,
//                    height / 2 - itemIconMargin / 2 + additionalTopMargin + verticalPadding
//                )
//
//                val capsulePaint = Paint().apply {
//                    isAntiAlias = true
//                    style = Paint.Style.FILL
//                    color = currentActiveItemColor
//                    alpha = (255 * 0.3f * capsuleAlpha).toInt()  // Animate 30% opacity
//                }
//
//                canvas.drawRoundRect(capsuleRect, capsuleHeight / 2, capsuleHeight / 2, capsulePaint)
//            }


        }

    }

    // Handle item clicks
    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP && abs(event.downTime - event.eventTime) < longPressTime)
            for ((i, item) in items.withIndex())
                if (item.rect.contains(event.x, event.y))
                    if (i != this.activeItem) {
                        setActiveItem(i)
                        onItemSelected(i)
                        onItemSelectedListener?.onItemSelect(i)
                    } else {
                        onItemReselected(i)
                        onItemSelectedListener?.onItemReselect(i)
                    }

        if (event.action == MotionEvent.ACTION_MOVE || event.action == MotionEvent.ACTION_UP)
            if (abs(event.downTime - event.eventTime) > longPressTime)
                for ((i, item) in items.withIndex())
                    if (item.rect.contains(event.x, event.y)) {
                        onItemLongClick(i)
                        onItemSelectedListener?.onItemLongClick(i)
                    }

        return true
    }

    // Draw item badge
    private fun drawBadge(canvas: Canvas, item: BottomBarItem) {
        paintBadge.style = Paint.Style.FILL
        paintBadge.color = itemTextColorActive

        canvas.drawCircle(
            item.rect.centerX() + itemIconSize / 2 - 4,
            (height / 2).toFloat() - itemIconSize - itemIconMargin / 2 + 10, item.badgeSize, paintBadge
        )

        paintBadge.style = Paint.Style.STROKE
        paintBadge.color = barBackgroundColor

        canvas.drawCircle(
            item.rect.centerX() + itemIconSize / 2 - 4,
            (height / 2).toFloat() - itemIconSize - itemIconMargin / 2 + 10, item.badgeSize, paintBadge
        )
    }

    // Add item badge
    fun setBadge(pos: Int) {
        if (pos > 0 && pos < items.size && items[pos].badgeSize == 0f) {
            val animator = ValueAnimator.ofFloat(0f, 15f)
            animator.duration = 100
            animator.addUpdateListener { animation ->
                items[pos].badgeSize = animation.animatedValue as Float
                invalidate()
            }
            animator.start()
        }
    }

    // Remove item badge
    fun removeBadge(pos: Int) {
        if (pos > 0 && pos < items.size && items[pos].badgeSize > 0f) {
            val animator = ValueAnimator.ofFloat(items[pos].badgeSize, 0f)
            animator.duration = 100
            animator.addUpdateListener { animation ->
                items[pos].badgeSize = animation.animatedValue as Float
                invalidate()
            }
            animator.start()
        }
    }

    fun getActiveItem(): Int {
        return activeItem
    }

    fun setActiveItem(pos: Int) {
        if (activeItem == pos) return

        activeItem = pos
        playBounce()
        invalidate()
    }
    private fun playBounce() {
        ValueAnimator.ofFloat(1f, 1.25f, 1f).apply {
            duration = 220
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                bounceScale = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }


    // Apply transition animation to item color
    private fun setItemColors() {
        val animator = ValueAnimator.ofObject(ArgbEvaluator(), itemTextColor, itemTextColorActive)
        animator.addUpdateListener { currentActiveItemColor = it.animatedValue as Int }
        animator.start()
    }

    private fun d2p(dp: Float): Float {
        return resources.displayMetrics.densityDpi.toFloat() / 160.toFloat() * dp
    }

    fun setOnItemSelectedListener(listener: OnItemListener) {
        this.onItemSelectedListener = listener
    }
}