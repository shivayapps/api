package com.photogallery.secret.activity

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.graphics.PorterDuff
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.photogallery.R
import com.photogallery.adapter.FavoritesAdapter
import com.photogallery.base.BaseActivity
import com.photogallery.base.BaseNoThemeActivity
import com.photogallery.database.AppDatabase
import com.photogallery.databinding.ActivityVaultDeleteBinding
import com.photogallery.dialog.ActionConfirmationDialog
import com.photogallery.dialog.ProgressDialog
import com.photogallery.event.DeleteEvent
import com.photogallery.event.DisplayDeleteEvent
import com.photogallery.event.RestoreDataEvent
import com.photogallery.extension.toast
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences
import com.photogallery.utils.Utils

import com.photogallery.viewpager.PhotoVideoActivity
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Locale

class VaultDeleteActivity : BaseActivity() {

    var allList = ArrayList<MediaData>()
    var pictures = ArrayList<Any>()
    var pictureAdapter: FavoritesAdapter? = null
    lateinit var preferences: Preferences
    lateinit var dataBase: AppDatabase
    var selectedItem = 0
    var isSelectAll = false

    lateinit var binding: ActivityVaultDeleteBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVaultDeleteBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
//        WindowCompat.getInsetsController(window, window.decorView).apply {
//            isAppearanceLightStatusBars = false
//            isAppearanceLightNavigationBars = true
//        }
        //updateStatusBarColor(Color.parseColor("#161616"))

        EventBus.getDefault().register(this)
        intView()
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }

    private fun intView() {

        binding.loutToolbar.txtTitle.text = getString(R.string.recently_deleted)
        preferences = Preferences(this)
        dataBase = AppDatabase.getInstance(this)
        binding.loutToolbar.icMenu.setImageDrawable(
            ContextCompat.getDrawable(
                this,
                R.drawable.ic_restore
            )
        )

        getData()
//        binding.swipeRefreshLayout.setOnRefreshListener {
//            if (binding.swipeRefreshLayout.isEnabled)
//                getData()
//            else
//                binding.swipeRefreshLayout.isRefreshing = false
//        }
        intListener()
    }

    private fun intListener() {
        binding.loutToolbar.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.loutToolbar.icClose.setOnClickListener {
            setCloseToolbar()
        }
        binding.loutToolbar.icSelect.setOnClickListener {
            isSelectAll = !isSelectAll
            setSelectClick(isSelectAll)
            setSelectAllColor()
        }

        binding.loutToolbar.icMenu.setOnClickListener {
            val confirmationDialog = ActionConfirmationDialog(
                this,
                getString(R.string.restore_all),
                getString(R.string.restore_all_msg),
                getString(R.string.ok),
                positiveBtnClickListener = {
                    restoreAllPhoto()
                })
            confirmationDialog.show()
        }


        binding.btnDelete.setOnClickListener {
            showDeleteDialog()
        }

        binding.btnRestore.setOnClickListener {
            setRestoreData()
        }

    }

    private fun notifyAdapter() {
        if (pictureAdapter != null)
            pictureAdapter?.notifyDataSetChanged()
    }

    private fun setData() {
        enableScroll()
//        binding.swipeRefreshLayout.isRefreshing = false
        if (pictureAdapter != null) notifyAdapter() else initAdapter()
        setEmptyData()
    }

    private fun initAdapter() {
        setRvLayoutManager()
        pictureAdapter = FavoritesAdapter(
            this,
            clickListener = {
                if (pictures[it] is MediaData) {
                    val mediaData = pictures[it] as MediaData
                    if (mediaData.isCheckboxVisible) {
                        mediaData.isSelected = !mediaData.isSelected
                        pictureAdapter?.notifyItemChanged(it)
                        setSelectedFile()
                    } else {
                        val dataList = ArrayList<MediaData>()
                        var displayPos = 0
                        for (i in pictures.indices) {
                            if (pictures[i] is MediaData) {
                                dataList.add(pictures[i] as MediaData)
                                if (it == i) {
                                    displayPos = dataList.size - 1
                                }
                            }
                        }
                        Constant.displayImageList = ArrayList()
                        Constant.displayImageList.addAll(dataList)
                        Constant.selectedPosition = displayPos
//                    val intent = Intent(this, ImageViewerActivity::class.java)
                        if (Constant.displayImageList.size > 0) {
                            val intent = Intent(this, PhotoVideoActivity::class.java)
                            intent.putExtra(Constant.EXTRA_DISPLAY_POS, displayPos)
                            intent.putExtra(Constant.EXTRA_IS_OPEN_RECENTLY_DELETE, true)
                            startActivity(intent)
                        }
                    }
                }
            },
            longClickListener = {
                if (pictures[it] is MediaData) {
                    val mediaData = pictures[it] as MediaData
                    for (i in pictures.indices) {
                        if (pictures[i] != null)
                            if (pictures[i] is AlbumData) {
                                val model = pictures[i] as AlbumData
                                model.isCheckboxVisible = true
                            } else if (pictures[i] is MediaData) {
                                val model = pictures[i] as MediaData
                                model.isCheckboxVisible = true
                            }
                    }
                    mediaData.isCheckboxVisible = true
                    mediaData.isSelected = true
                    notifyAdapter()
                    setSelectedFile()
                }
            },
            headerSelectListener = {
                if (pictures[it] is AlbumData) {
                    val albumData = pictures[it] as AlbumData
                    val isSelectAll = !albumData.isSelected
                    albumData.isSelected = isSelectAll
                    var pos = it + 1
                    while (pos < pictures.size) {
                        if (pictures[pos] is MediaData) {
                            val model = pictures[pos] as MediaData
                            model.isSelected = isSelectAll
                            pos++
                        } else if (pictures[pos] is AlbumData) {
                            break
                        }
                    }
                    notifyAdapter()
                    setSelectedFile()
                }
            })

        pictureAdapter?.submitList(pictures)
        binding.pictureRecycler.adapter = pictureAdapter
    }

    private fun setEmptyData() {
        if (pictures.size != 0) {
            binding.pictureRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
            binding.loutToolbar.icMenu.visibility = View.VISIBLE
        } else {
            binding.pictureRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
            binding.loutToolbar.icMenu.visibility = View.INVISIBLE
        }
//        if (pictures != null && pictures.size != 0) {
//            binding.layoutBanner.mFLAd.beVisible()
//        } else {
//            binding.layoutBanner.mFLAd.beGone()
//        }
    }

    fun setRvLayoutManager() {
        val gridCount = preferences.getGridCount()
        val gridLayoutManager =
            GridLayoutManager(this, gridCount, RecyclerView.VERTICAL, false)
        binding.pictureRecycler.layoutManager = gridLayoutManager
        gridLayoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                if (position >= 0 && position < pictures.size) {
                    return if (pictureAdapter!!.getItemViewType(position) === pictureAdapter!!.ITEM_HEADER_TYPE) {
                        gridCount
                    } else 1
                } else {
                    return 1
                }
            }
        }
    }

    override fun onBackPressed() {
        if (binding.loutToolbar.groupToolbarSelectHeader.visibility == View.VISIBLE) {
            setCloseToolbar()
        } else
            super.onBackPressed()
    }

    private fun longClickListener(
        isShowSelection: Boolean,
        selectedItem: Int,
        isAllSelect: Boolean
    ) {
        binding.loutToolbar.groupToolbarSelectHeader.visibility =
            if (isShowSelection) View.VISIBLE else View.GONE
        isSelectAll = isAllSelect
        binding.loutSelectOption.visibility =
            if (isShowSelection && selectedItem != 0) View.VISIBLE else View.GONE
        binding.loutToolbar.groupToolbarHeader.visibility =
            if (isShowSelection) View.GONE else View.VISIBLE
        binding.loutToolbar.txtSelectCount.text =
            "$selectedItem ${getString(R.string.items_selected)}"
        setSelectAllColor()
    }

    private fun setSelectAllColor() {
        val color =
            ContextCompat.getColor(this, if (isSelectAll) R.color.black else R.color.un_check_color)
        binding.loutToolbar.icSelect.setColorFilter(color, PorterDuff.Mode.SRC_IN)
    }

    fun setCloseToolbar() {
        setClose()
        longClickListener(false, 0, false)
    }

    private fun setSelectedFile() {
        var selected = 0
        var allItemCount = 0

        var currentHeaderPos = -1
        var photosCount = 0
        var photosSelectCount = 0

        for (i in pictures.indices) {
            if (pictures[i] is AlbumData) {
                if (i != currentHeaderPos) {
                    if (currentHeaderPos != -1) {
                        val model = pictures[currentHeaderPos] as AlbumData
                        model.isSelected = photosCount == photosSelectCount
                        photosCount = 0
                        photosSelectCount = 0
                        pictureAdapter?.notifyItemChanged(currentHeaderPos)
                    }
                    currentHeaderPos = i
                }
            } else if (pictures[i] is MediaData) {
                val model = pictures[i] as MediaData
                allItemCount++
                photosCount++
                if (model.isSelected) {
                    selected++
                    photosSelectCount++
                }
            }
            if (i == pictures.size - 1) {
                if (currentHeaderPos != -1) {
                    val model = pictures[currentHeaderPos] as AlbumData
                    model.isSelected = photosCount == photosSelectCount
                    photosCount = 0
                    photosSelectCount = 0
                    pictureAdapter?.notifyItemChanged(currentHeaderPos)
                }
            }
        }
//        if (selected == 0) {
//            longClickListener(false, selected, false)
//            setClose()
//        } else {
//            longClickListener(true, selected, allItemCount == selected)
//        }
        longClickListener(true, selected, allItemCount == selected)
        binding.swipeRefreshLayout.isEnabled = false
//        binding.swipeRefreshLayout.isEnabled = selected == 0
        selectedItem = selected
    }

    fun setSelectClick(isSelectAll: Boolean) {
//        if (isSelectAll) {
        var selected = 0
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    if (!model.isCustomAlbum) {
                        model.isSelected = isSelectAll
                    }
                } else if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData
                    model.isSelected = isSelectAll
                    if (isSelectAll)
                        selected++

                }
        }
        notifyAdapter()
        longClickListener(true, selected, isSelectAll)
        selectedItem = selected
//        } else {
//            longClickListener(false, 0, false)
//            setClose()
//        }
    }

    fun setRestoreData() {
        if (selectedItem == 0) {

            toast(getString(R.string.PleaseSelectImage))
        } else {
            val confirmationDialog = ActionConfirmationDialog(
                this,
                getString(R.string.restore),
                getString(R.string.restore_msg),
                getString(R.string.ok),
                positiveBtnClickListener = {
                    restorePhoto()
                })
            confirmationDialog.show()
        }
    }

    fun showDeleteDialog() {
        if (selectedItem == 0) {

            toast(getString(R.string.PleaseSelectImage))
        } else {
            val confirmationDialog = ActionConfirmationDialog(
                this,
                getString(R.string.delete_permanently),
                getString(R.string.permanently_delete_msg),
                getString(R.string.Delete),
                positiveBtnClickListener = {
                    deletePhoto()
                }, true
            )
            confirmationDialog.show()
        }
    }

    private fun setClose() {
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    model.isSelected = false
                    model.isCheckboxVisible = false
                } else if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData
                    model.isCheckboxVisible = false
                    model.isSelected = false
                }
        }
        binding.swipeRefreshLayout.isEnabled = true
        notifyAdapter()
        selectedItem = 0
    }

    private fun restorePhoto() {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is MediaData) {
                    val model: MediaData = pictures[i] as MediaData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }

        Utils.restoreVaultFiles(this, selectImage, selectedItem, hideListener = {

            toast(getString(R.string.restore_successfully))
            selectedItem = 0
            longClickListener(false, 0, false)
            setClose()
        })
    }

    private fun restoreAllPhoto() {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is MediaData) {
                    val model: MediaData = pictures[i] as MediaData
                    selectImage.add(model)
                }
        }


        Utils.restoreVaultFiles(this, selectImage, selectedItem, hideListener = {

            toast(getString(R.string.restore_successfully))
            selectedItem = 0
            allList.clear()
            pictures.clear()
            setData()
            longClickListener(false, 0, false)
        })
    }

    @SuppressLint("CheckResult")
    private fun deletePhoto() {
        val deleteList = ArrayList<String>()

        val progressDialog = ProgressDialog(
            this,
            R.drawable.ic_drawer_delete,
            selectedItem,
            getString(R.string.Deleting),
            ""
        )
        progressDialog.show()

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(this)
            for (i in pictures.indices) {
                if (pictures[i] != null) if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData
                    if (model.isSelected) {
                        val isDelete = Utils.recentlyDeleteHideFile(this, model, dataBase)
                        if (isDelete) {
                            deleteList.add(model.filePath)
                            runOnUiThread {
                                progressDialog.setProgress(deleteList.size, selectedItem)
//                                bindingDialog.txtProgressCount.text =
//                                    deleteList.size.toString() + "/" + selectedItem
//                                bindingDialog.progressBar.progress = deleteList.size
                            }
                        }
                    } else {
                        model.isCheckboxVisible = false
                    }
                } else if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    model.isSelected = false
                    model.isCheckboxVisible = false
                }
            }

            var i = 0
            while (i < pictures.size) {
                if (pictures[i] != null)
                    if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false

                    } else if (pictures[i] is MediaData) {
                        val model = pictures[i] as MediaData
                        if (model.isSelected) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is AlbumData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                        } else {
                            model.isSelected = false
                            model.isCheckboxVisible = false
                        }
                    }
                i++
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
//                    if (dialog.isShowing)
                    progressDialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread {
//                    if (dialog.isShowing)
                    progressDialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
    }

    private fun setBeforeDeleteUpdate(deleteList: ArrayList<String>) {
//        EventBus.getDefault().post(DeleteEvent(1, deleteList))
        selectedItem = 0
        notifyAdapter()
        binding.swipeRefreshLayout.isEnabled = true
        longClickListener(false, 0, false)
        setEmptyData()

        toast(getString(R.string.Delete_successfully))
        deleteMainList(deleteList)
    }

    private fun deleteMainList(deleteList: ArrayList<String>) {
        if (deleteList.size != 0) {
            val favList = preferences.getFavoriteList()
            for (path in deleteList) {
                if (favList.contains(path))
                    favList.remove(path)
                for (pictureData in allList) {
                    if (pictureData.filePath == path) {
                        allList.remove(pictureData)
                        break
                    }
                }
            }

            preferences.setFavoriteList(favList)
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDisplayDeleteEvent(event: DisplayDeleteEvent) {
        displayDeleteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDeleteEvent(event: DeleteEvent) {
        deleteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onRestoreDataEvent(event: RestoreDataEvent) {
        restoreEvent(event)
    }

    private fun deleteEvent(event: DeleteEvent) {
        if (event.deleteList.isNotEmpty() && event.pos != 0)
            if (pictures.isNotEmpty()) {
                updateDeleteImageData(event.deleteList)
                deleteMainList(event.deleteList)
            }
    }

    private fun displayDeleteEvent(event: DisplayDeleteEvent) {
        if (event.deleteList.isNotEmpty())
            if (pictures.isNotEmpty()) {
                updateDeleteImageData(event.deleteList)
                deleteMainList(event.deleteList)
            }
    }

    private fun restoreEvent(event: RestoreDataEvent) {
        if (event.restoreList.isNotEmpty())
            if (pictures.isNotEmpty()) {
                val list: ArrayList<String> = ArrayList()
                for (restoreData in event.restoreList) {
                    list.add(restoreData.deletedPath)
                }
                updateDeleteImageData(list)
                deleteMainList(list)
            }
    }

    private fun updateDeleteImageData(deleteList: ArrayList<String>) {
        if (pictures.isNotEmpty()) {
            for (d in deleteList.indices) {
                var i = 0
                while (i < pictures.size) {
                    if (pictures[i] is MediaData) {
                        val model = pictures[i] as MediaData
                        if (model.filePath == deleteList[d]) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is AlbumData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                            if (d == deleteList.size - 1) {
                                break
                            }
                        }
                    }
                    i++
                }
            }
            notifyAdapter()
            setEmptyData()
        }
    }

    private fun getData() {
        disableScroll()
//        binding.swipeRefreshLayout.isRefreshing = true
        Observable.fromCallable<Boolean> {
            allList.clear()
//            var hiddenList = dataBase.dataDao().getRecentDeleteList()
            var hiddenList = dataBase.vaultDao().getHiddenList(true)

            if (!hiddenList.isNullOrEmpty()) {
                for (hiddenData in hiddenList) {
                    var file = File(hiddenData.hidePath)
                    if (file.exists()) {
                        val isVideo = hiddenData.isVideo == 1
                        val pictureData =
                            MediaData(
                                hiddenData.hidePath,
                                Utils.getUriFromPath(this@VaultDeleteActivity, hiddenData.hidePath).toString(),
                                file.name,
                                file.parentFile.name,
                                file.lastModified(),
                                file.lastModified(),
                                file.length(),
                                isVideo
                            )
                        pictureData.isPrivate = true
                        pictureData.isFavorite = false
                        pictureData.idDataBase = hiddenData.id
                        pictureData.restorePath = hiddenData.restorePath

                        allList.add(pictureData)
                    }
                }

            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    setFilterData()
                }
            }
            .subscribe { result: Boolean? ->
                runOnUiThread {
                    setFilterData()
                }
            }
    }

    private fun disableScroll() {
        binding.pictureRecycler.suppressLayout(true)
    }

    private fun enableScroll() {
        binding.pictureRecycler.suppressLayout(false)
    }

    private fun setFilterData() {
        disableScroll()
//        binding.swipeRefreshLayout.isRefreshing = true
        GlobalScope.launch(Dispatchers.IO) {
            setFilter()

            runOnUiThread {
                setData()
            }
        }
//        Observable.fromCallable<Boolean> {
//            setFilter()
//            true
//        }.subscribeOn(Schedulers.io())
//            .doOnError { _: Throwable? ->
//                runOnUiThread { setData() }
//            }
//            .subscribe { _: Boolean? ->
//                runOnUiThread { setData() }
//            }
    }

    private fun setFilter() {
        val sortType = preferences.getSortType()
        val sortOrder = preferences.getSortOrder()

        Collections.sort(allList, Comparator { p1, p2 ->
            if (sortType == Constant.SORT_NAME) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.fileName.compareTo(p2.fileName, true)
                else
                    p2.fileName.compareTo(p1.fileName, true)
            }
//            else if (sortType == Constant.SORT_PATH) {
//                if (sortOrder == Constant.ORDER_ASCENDING)
//                    p1.filePath.compareTo(p2.filePath, true)
//                else
//                    p2.filePath.compareTo(p1.filePath, true)
//            }
            else if (sortType == Constant.SORT_SIZE) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.fileSize.compareTo(p2.fileSize)
                else
                    p2.fileSize.compareTo(p1.fileSize)
            } else if (sortType == Constant.SORT_DATE) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.date.compareTo(p2.date)
                else
                    p2.date.compareTo(p1.date)
            }
//            else if (sortType == Constant.SORT_DATE_TAKEN) {
//                if (sortOrder == Constant.ORDER_ASCENDING)
//                    p1.dateTaken.compareTo(p2.dateTaken)
//                else
//                    p2.dateTaken.compareTo(p1.dateTaken)
//            }
            else
                p2.date.compareTo(p1.date)
        })

        setList()
    }

    private fun setList() {
        pictures.clear()

        val dateWisePictures = LinkedHashMap<String, ArrayList<MediaData>>()
        val format = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
//        val format = SimpleDateFormat("EEEE, MMM dd yyyy")

        if (allList.size != 0) {
            for (pictureData in allList) {
                val strDate = format.format(pictureData.date)

                var imagesData1: ArrayList<MediaData> = ArrayList()
                if (dateWisePictures.containsKey(strDate)) {
                    val list: ArrayList<MediaData>? = dateWisePictures[strDate]
                    if (!list.isNullOrEmpty())
                        imagesData1.addAll(list)
                } else {
                    imagesData1 = ArrayList()
                }
                imagesData1.add(pictureData)
                dateWisePictures[strDate] = imagesData1
            }

            val keys: Set<String> = dateWisePictures.keys
            val listKeys = ArrayList(keys)

            for (i in listKeys.indices) {
                val imagesData = dateWisePictures[listKeys[i]]
                if (imagesData != null && imagesData.size != 0) {
                    val bucketData = AlbumData(listKeys[i], imagesData)
                    pictures.add(bucketData)
                    pictures.addAll(imagesData)
                }
            }
        }
    }


}