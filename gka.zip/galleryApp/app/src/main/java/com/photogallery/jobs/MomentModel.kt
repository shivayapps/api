package com.photogallery.jobs

data class MomentModel(val name: String, val sub_categories: ArrayList<String>)