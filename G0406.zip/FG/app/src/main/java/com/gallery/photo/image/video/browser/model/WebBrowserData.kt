package com.gallery.photo.image.video.browser.model


data class WebBrowserData(var title : String = null?:"", var imageIcon : Int = 0, var urls:String=null?:"https://www.google.com/")
