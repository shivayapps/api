package com.gallery.photo.image.video.model

import android.graphics.drawable.Drawable
import androidx.annotation.Keep

@Keep
data class LanguageData(
    var name: String, var languageCode: String, var icon: Drawable?
)
