package com.gallery.photo.image.video.calendardaterangepicker.customviews

class InvalidDateException(message: String) : IllegalArgumentException(message)
