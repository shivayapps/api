package com.gallery.photo.image.video.asynctasks

import android.content.Context
import android.os.AsyncTask
import com.gallery.photo.image.video.helper.MediaFetcher
import com.gallery.photo.image.video.model.PictureData
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.Preferences
import com.gallery.photo.image.video.utils.SHOW_ALL


class TrashAsynctask(
    val context: Context,
    val callback: (isComplete: Boolean) -> Unit
) :
    AsyncTask<Void, Void, Boolean>() {

    val config = Preferences(context)

    override fun doInBackground(vararg params: Void): Boolean {


        return true
    }

    override fun onPostExecute(isComplete: Boolean) {
        super.onPostExecute(isComplete)
        callback(isComplete)
    }

    fun stopFetching() {
        cancel(true)
    }
}
