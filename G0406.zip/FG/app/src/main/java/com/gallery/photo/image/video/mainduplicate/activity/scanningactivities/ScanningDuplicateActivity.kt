package com.gallery.photo.image.video.mainduplicate.activity.scanningactivities

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.text.HtmlCompat
import com.adconfig.adsutil.admob.BannerAdHelper
import com.adconfig.adsutil.admob.NativeAdHelper
import com.adconfig.adsutil.admob.NativeLayoutType
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.base.BaseActivity

import com.gallery.photo.image.video.mainduplicate.activity.duplicateactivities.*
import com.gallery.photo.image.video.mainduplicate.asynctask.ReadingAllFilesAsyncTask
import com.gallery.photo.image.video.mainduplicate.callbacks.SearchListener
import com.gallery.photo.image.video.mainduplicate.model.DuplicateFileRemoverSharedPreferences
import com.gallery.photo.image.video.mainduplicate.model.PopUp
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import com.gallery.photo.image.video.databinding.ActivityScanningNewBinding
import com.gallery.photo.image.video.mainduplicate.BaseSimpleActivity
import com.gallery.photo.image.video.mainduplicate.activity.duplicateactivities.DuplicateAudiosDuplicateActivity
import com.gallery.photo.image.video.utils.AdCache
import com.gallery.photo.image.video.utils.Preferences
import com.google.android.gms.ads.AdView

import java.util.*

class ScanningDuplicateActivity : BaseActivity(), SearchListener {

    var mTAG: String = javaClass.simpleName
    var mIsCheckType: String? = null
    var mIsScanningDone = false
    var isFromSettings = false
    var isPause = false

    lateinit var mContext:Activity
    lateinit var binding:ActivityScanningNewBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        binding=ActivityScanningNewBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        setContentView(R.layout.activity_scanning_new)
        mContext=getContext()
//        initViews()
//        initAds()
        initData()
        initActions()

        val dm = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(dm)
//        val x = Math.pow((dm.widthPixels / dm.xdpi).toDouble(), 2.0)
//        val y = Math.pow((dm.heightPixels / dm.ydpi).toDouble(), 2.0)
//        val screenInches = Math.sqrt(x + y)

        loadAds()
    }


    private fun loadAds() {
        NativeAdHelper(
            this,
            binding.layoutBanner.mFLAd,
            binding.llAdPlace,
            NativeLayoutType.NativeBig,
            getString(R.string.native_scanner)
        ).loadAd();
    }

    fun getContext(): Activity {
        return this@ScanningDuplicateActivity
    }

    fun initData() {
        mIsCheckType = intent.extras!!.getString("IsCheckType")

//        Glide.with(applicationContext)
//            .asGif() // make sure the GIF wont animate
//            .load(resources.getDrawable(R.drawable.loading_circle_animation))
//            .into(imgScanning)
        ReadingAllFilesAsyncTask(
            mContext,
            this,
            mIsCheckType
        ).execute()
    }



//    private fun showSettingsDialog() {
//        isUnLockApp = true
//        val alertDialogBuilder = AlertDialog.Builder(this, R.style.MyAlertDialogNew)
//            .setTitle(HtmlCompat.fromHtml("<font color='#0a82f3'>" + getString(R.string.error_permission_required) + "</font>", HtmlCompat.FROM_HTML_MODE_LEGACY))
//            .setMessage(getString(R.string.msg_allow_permission_storage))
//            .setPositiveButton(getString(R.string.ok))
//            { dialog, which ->
//                dialog.dismiss()
//                isFromSettings = true
//                val intent = Intent(
//                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
//                    Uri.fromParts("package", packageName, null)
//                )
//                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
//                launchActivityForResult(intent,2296)
//
////                            Share.isAppOpenAdShow = false
//            }
//            .setNegativeButton(getString(R.string.cancel)) { dialog, which ->
//                dialog.dismiss()
//                finish()
//            }
//            .setCancelable(false)
//        alertDialogBuilder.show()
//    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
        super.onActivityResult(requestCode, resultCode, resultData)
//        if (requestCode == 2296) {
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
//                if (Environment.isExternalStorageManager()) {
//                    ReadingAllFilesAsyncTask(mContext, this, mIsCheckType).execute()
//                    Log.e(mTAG, "onActivityResult: Service Start ")
//                } else {
//                    if (isFromOneSignal) {
//                        startActivity(MainDuplicateActivity.newIntent(this))
//                        finish()
//                        Toast.makeText(mContext, "Permission Required!!", Toast.LENGTH_SHORT).show()
//                    } else {
//                        Toast.makeText(mContext, "Permission Required!!", Toast.LENGTH_SHORT).show()
//                    }
//                }
//            }
//        }

    }

    fun initActions() {
        binding.imgBack.setOnClickListener { onBackPressed() }

//        ReadingAllFilesAsyncTask(mContext, this, mIsCheckType).execute()
    }

    override fun checkScanFinish() {
        Log.e(mTAG, "checkScanFinish ")
        redirectActivity()
        mIsScanningDone = true
    }


    private fun redirectActivity() {
        Log.e(mTAG, "redirectActivity: ==>>> $mIsCheckType")
        mIsScanningDone = false
        val intent: Intent = when (mIsCheckType) {
            "Image" -> Intent(mContext, DuplicateImageDuplicateActivity::class.java)
            "Video" -> Intent(mContext, DuplicateVideosDuplicateActivity::class.java)
            "Audio" -> Intent(mContext, DuplicateAudiosDuplicateActivity::class.java)
            "Document" -> Intent(mContext, DuplicateDocumentsDuplicateActivity::class.java)
            "Other" -> Intent(mContext, DuplicateOthersDuplicateActivity::class.java)
            else -> throw IllegalStateException("Unexpected value: $mIsCheckType")
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        intent.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//        val pi: PendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)
//        pi.send(this, 0, intent)
        startActivity(intent)

        Log.e(mTAG, "redirectActivity: intent ---> $intent")
        Log.e(mTAG, "redirectActivity: $mContext")
        finish()
    }

    override fun updateUi(vararg count: String?) {
        if (!DuplicateFileRemoverSharedPreferences.isScanningStop(mContext)) {
            runOnUiThread {
                if (count[0].equals("scanning", ignoreCase = true)) {
                    binding.tvCount!!.text = count[1]
                    binding.tvScanning2!!.visibility = View.VISIBLE
                } else if (count[0].equals("sorting", ignoreCase = true)) {
                    binding.tvCount!!.visibility = View.INVISIBLE
                    binding.tvScanning1!!.text = count[1]
                    binding.tvScanning2!!.visibility = View.INVISIBLE
                }
            }
        }
    }

    override fun onBackPressed() {
        PopUp(mContext, mContext).showAlertStopScanning(
            com.gallery.photo.image.video.mainduplicate.asynctask.ReadingAllFilesAsyncTask(
                mContext,
                this,
                mIsCheckType
            )
        )
    }

    override fun onResume() {
        super.onResume()
        Log.d("TAG1234", "onResume: Scanning activity ")
        if (isFromSettings) {
            isFromSettings = false
            com.gallery.photo.image.video.mainduplicate.asynctask.ReadingAllFilesAsyncTask(
                mContext,
                this,
                mIsCheckType
            ).execute()

        }
//        if (AdsManager(mContext).isNeedToShowAds() && isOnline()) {
//            mContext.loadOfflineNativeAdvance(flBanner)
//        }


//        if (config.isAppPasswordProtectionOn && config.isEnableLock && isUnLockApp && mIsScanningDone) {
//            redirectActivity()
//        } else {
//        }
        if (mIsScanningDone) {
            redirectActivity()
        }
    }


    override fun onPause() {
        super.onPause()
        isPause = true
    }
}