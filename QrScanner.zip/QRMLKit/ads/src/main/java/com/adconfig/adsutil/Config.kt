package com.adconfig.adsutil

import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd

object Config {

    var mAppOpenAd: AppOpenAd? = null
    var mInterstitialAd: InterstitialAd? = null
    var isLibraryInitialized = false
//    var IS_DEBUG = true
    var isAdsEnable = true

    var isOpenAdEnable: Boolean = true
    var admobInterstitialAdId: String = ""
    var admobAppOpenId: String = ""

}