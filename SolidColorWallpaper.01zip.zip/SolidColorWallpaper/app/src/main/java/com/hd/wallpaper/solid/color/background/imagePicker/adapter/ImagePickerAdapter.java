package com.hd.wallpaper.solid.color.background.imagePicker.adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.hd.wallpaper.solid.color.background.R;
import com.hd.wallpaper.solid.color.background.imagePicker.helper.ImageHelper;
import com.hd.wallpaper.solid.color.background.imagePicker.listener.OnImageClickListener;
import com.hd.wallpaper.solid.color.background.imagePicker.listener.OnImageSelectionListener;
import com.hd.wallpaper.solid.color.background.imagePicker.model.Constant;
import com.hd.wallpaper.solid.color.background.imagePicker.model.Image;
import com.hd.wallpaper.solid.color.background.imagePicker.ui.common.BaseRecyclerViewAdapter;
import com.hd.wallpaper.solid.color.background.imagePicker.ui.imagepicker.ImageLoader;
import com.hd.wallpaper.solid.color.background.imagePicker.ui.imagepicker.ImagePickerPresenter;

import java.util.ArrayList;
import java.util.List;

public class ImagePickerAdapter extends BaseRecyclerViewAdapter<ImagePickerAdapter.ImageViewHolder> {

    private List<Image> images = new ArrayList<>();
    private List<Image> selectedImages = new ArrayList<>();
    private OnImageClickListener itemClickListener;
    private OnImageSelectionListener imageSelectionListener;
    private FragmentManager manager;
    private int lastSelected = -1;
    private ImagePickerPresenter presenter;
    private Context mContext;

    public ImagePickerAdapter(FragmentManager manager, Context context, ImageLoader imageLoader, List<Image> selectedImages, OnImageClickListener itemClickListener) {
        super(context, imageLoader);
        this.itemClickListener = itemClickListener;
        this.manager = manager;
        Constant.selectedImage.clear();
        mContext = context;
        /*if (selectedImages != null && !selectedImages.isEmpty()) {
            this.selectedImages.addAll(selectedImages);
        }*/
        //this.selectedImages.clear();

     /*   presenter = new ImagePickerPresenter(new ImageFileLoader(context));
        presenter.attachView(context);*/
    }

    @Override
    public ImageViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = getInflater().inflate(R.layout.imagepicker_item_image, parent, false);
        return new ImageViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final ImageViewHolder viewHolder, final int position) {

        final Image image = images.get(position);
        final boolean isSelected = isSelected(image);
//        viewHolder.isSelectedImage.setVisibility(View.GONE);
//        System.gc();
//        Runtime.getRuntime().gc();




        Glide.with(mContext)
                .load(images.get(position).getPath())
                .addListener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        Log.d("877894564564563", "onLoadFailed: ");
                        viewHolder.image.setImageDrawable(mContext.getResources().getDrawable(R.drawable.corrupt_file));
//                        Glide.with(mContext).load(R.drawable.corrupt_file).into(viewHolder.image);
                        viewHolder.image.setPadding(50,50,50,50);
                        image.setCorrupted(true);
                        return true;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        Log.d("877894564564563", "onResourceReady: ");
                        viewHolder.image.setPadding(0,0,0,0);
                        image.setCorrupted(false);
                        return false;
                    }
                })
                .transition(DrawableTransitionOptions.withCrossFade())
                .into(viewHolder.image);


//        getImageLoader().loadImage(image, viewHolder.image, BitmapFactory.decodeResource(mContext.getResources(), R.drawable.corrupt_file));

        viewHolder.gifIndicator.setVisibility(ImageHelper.isGifFormat(image) ? View.VISIBLE : View.GONE);
//        viewHolder.alphaView.setAlpha(isSelected ? 0.0f : 0.0f);
     /*   viewHolder.container.setForeground(isSelected
                ? ContextCompat.getDrawable(getContext(), R.drawable.imagepicker_ic_selected)
                : null);*/
//        if (isSelected) {
//            viewHolder.isSelectedImage.setVisibility(View.VISIBLE);
//        } else {
//            viewHolder.isSelectedImage.setVisibility(View.GONE);
//        }
        if (Constant.lastSelectedImage == position) {
            viewHolder.isSelectedImage.setVisibility(View.VISIBLE);
        } else {
            viewHolder.isSelectedImage.setVisibility(View.GONE);
        }


        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("7894561320", "onClick: " + image.isCorrupted());
                if (!image.isCorrupted()) {
                    if (lastSelected != -1) {
                        removeSelected(lastSelected);
                    }
                    lastSelected = position;
                    addSelected(image, position);

                    Constant.viewImagePosition = position;
                    Constant.lastSelectedImage = position;
                    Constant.viewImageList = images;
                } else {
                    new AlertDialog.Builder(mContext)
                            //  .setTitle("Select another image")
                            .setMessage("This image is corrupted. Please select another image.")
                            .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            })
                            .show();
                }
            }
        });
    }

    private boolean isSelected(Image image) {
        for (Image selectedImage : selectedImages) {
            if (selectedImage.getPath().equals(image.getPath())) {
                return true;
            }
        }
        return false;
    }

    public void setOnImageSelectionListener(OnImageSelectionListener imageSelectedListener) {
        this.imageSelectionListener = imageSelectedListener;
    }

    @Override
    public int getItemCount() {
        return images.size();
    }

    public void setData(List<Image> images) {
        if (images != null) {
            this.images.clear();
            this.images.addAll(images);
        }
        notifyDataSetChanged();
    }

    public void addSelected(List<Image> images) {
        selectedImages.addAll(images);
        notifySelectionChanged();
    }

    public void addSelected(Image image, int position) {
        Constant.selectedImage = selectedImages;
        selectedImages.add(image);
        notifyItemChanged(position);
        notifySelectionChanged();
    }

    public void removeSelected(int position) {
       /* Iterator<Image> itr = selectedImages.iterator();
        while (itr.hasNext()) {
            Image itrImage = itr.next();
            if (itrImage.getId() == image.getId()) {
                itr.remove();
                break;
            }
        } */
       if (selectedImages.size()>0) {
           selectedImages.remove(0);
       }
        notifyItemChanged(position);
        notifySelectionChanged();
    }

    public void removeAllSelected() {
        Log.d("781237897815", "removeAllSelected: ");
        if (selectedImages!=null && selectedImages.size()>0) {
          //  selectedImages.clear();
        }
        notifyDataSetChanged();
        notifySelectionChanged();
    }

    private void notifySelectionChanged() {
        if (imageSelectionListener != null) {
            imageSelectionListener.onSelectionUpdate(selectedImages);
        }
    }

    public List<Image> getSelectedImages() {
        return selectedImages;
    }

    static class ImageViewHolder extends RecyclerView.ViewHolder {

        private FrameLayout container;
        private ImageView image;
        private ImageView isSelectedImage;
        private View alphaView;
        private View gifIndicator;

        public ImageViewHolder(View itemView) {
            super(itemView);
            container = (FrameLayout) itemView;
            image = itemView.findViewById(R.id.image_thumbnail);
            isSelectedImage = itemView.findViewById(R.id.isSelectedImage);
            alphaView = itemView.findViewById(R.id.view_alpha);
            gifIndicator = itemView.findViewById(R.id.gif_indicator);

        }

    }

}
