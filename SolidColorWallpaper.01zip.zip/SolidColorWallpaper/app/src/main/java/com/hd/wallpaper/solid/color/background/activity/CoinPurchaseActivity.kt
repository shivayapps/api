package com.hd.wallpaper.solid.color.background.activity

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.wifiproxysettingslibrary.NetworkHelper
import com.example.app.ads.helper.RewardVideoHelper.isShowRewardVideoAd
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.SolidWallpaperApplication

import com.hd.wallpaper.solid.color.background.fragment.NoEnoughCoinDialogFragment
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs
import kotlinx.android.synthetic.main.activity_coin_purchase.*
import java.text.SimpleDateFormat
import java.util.*

class CoinPurchaseActivity : AppCompatActivity(), View.OnClickListener {


    private var productKey500 = "" /*, productKeyMonthDiscount = ""*/
    private var productKey2000: String? = ""
    private var productKey10000: String? = ""
    private var licenseKey = ""
    private var mContext: Context? = null
    var noEnoughCoinDialogFragment:NoEnoughCoinDialogFragment?=null

    var mSelectedKey = ""


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_coin_purchase)
        mContext = this

        initListner()
        initViewAction()


//        liveDataPrice.observe(this, {
//
//            Log.d("1111111", "onCreate: ${it[com.vasundhara.vision.subscription.constants.Constants.FIVE_HUNDRED]}")
//            Log.d("1111111", "onCreate: ${it[com.vasundhara.vision.subscription.constants.Constants.TWO_THOUSAND]}")
//            Log.d("1111111", "onCreate: ${it[com.vasundhara.vision.subscription.constants.Constants.TEN_THOUSAND]}")
//            Log.d("1111111", "onCreate: ${it[com.vasundhara.vision.subscription.constants.Constants.BASIC_SKU]}")
//            Log.d("1111111", "onCreate: ${it[com.vasundhara.vision.subscription.constants.Constants.PREMIUM_SKU]}")
//            Log.d("1111111", "onCreate: ${it[com.vasundhara.vision.subscription.constants.Constants.PREMIUM_SIX_SKU]}")
//
//            txtprice500.text = it[com.vasundhara.vision.subscription.constants.Constants.FIVE_HUNDRED]
//            txtprice2000.text = it[com.vasundhara.vision.subscription.constants.Constants.TWO_THOUSAND]
//            txtprice10000.text = it[com.vasundhara.vision.subscription.constants.Constants.TEN_THOUSAND]
//
//        })
    }

    fun restartActivity(activity: Activity) {

        if (Build.VERSION.SDK_INT >= 16) {
            activity.recreate();
        } else {
            activity.finish();
            activity.startActivity(activity.intent);
        }
//        Constants.isCoin = true
//        finish()

//        startActivity(intent)
//        overridePendingTransition(0, 0);
//        activity.recreate()
//        overridePendingTransition(0, 0);
    }

    private fun isNetworkConnected(): Boolean {
        val cm: ConnectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo()!!.isConnected()
    }


//    override fun onPurchases(orderId: String, str: String) {
//
//
//        var coins = 0
//        if (mSelectedKey == com.vasundhara.vision.subscription.constants.Constants.FIVE_HUNDRED) {
//            Log.e(TAG, "onPurchases: 500")
//            coins = 500
//
//
//
//
//
//        } else if (mSelectedKey == com.vasundhara.vision.subscription.constants.Constants.TWO_THOUSAND) {
//            Log.e(TAG, "onPurchases: 1000")
//
//            coins = 1000
//
//        } else if (mSelectedKey == com.vasundhara.vision.subscription.constants.Constants.TEN_THOUSAND) {
//            Log.e(TAG, "onPurchases: 2500")
//
//            coins = 2500
//
//        }
//
//        if (Constants.isCoin){
//            AdsPrefs.save(this, AdsPrefs.WALLET_COINS, AdsPrefs.getInt(this, AdsPrefs.WALLET_COINS, 100) + coins)
//            txtCoins.text = AdsPrefs.getInt(this, AdsPrefs.WALLET_COINS, 100).toString()
//            Constants.isCoin = false
//        }
//
//
//
////        initViewAction()
//
//    }

    override fun recreate() {
        if (Build.VERSION.SDK_INT >= 16) {
            super.recreate()
        } else {
            startActivity(intent)
            finish()
        }
    }

    override fun onPause() {
        super.onPause()
        try {
            noEnoughCoinDialogFragment!!.dismiss()
        }catch (e:Exception){

        }
    }

    private fun initViewAction() {
        val c = Calendar.getInstance().time
        val df = SimpleDateFormat("dd-MMM-yyyy")
        val formattedDate: String = df.format(c)
        val date = AdsPrefs.getString(this, AdsPrefs.ADS_FREE_DATE, formattedDate)
        Log.d("TAG=====>>>>", "initViewAction: $date  $formattedDate")
        if (date != formattedDate) {
            AdsPrefs.save(this, AdsPrefs.ADS_FREE_COUNT, 0)
            AdsPrefs.save(this, AdsPrefs.ADS_FREE_DATE, formattedDate)
        }
        txtCoins.text = AdsPrefs.getInt(this, AdsPrefs.WALLET_COINS, 100).toString()
    }

    private fun initListner() {
        icClose.setOnClickListener(this)
        ll_get_10_free_coin.setOnClickListener(this)
        ll_buy_500_coins.setOnClickListener(this)
        ll_buy_2000_coins.setOnClickListener(this)
        ll_buy_10000_coins.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when (v!!.id) {
            R.id.icClose -> {
                finish()
            }

//            R.id.ll_buy_500_coins -> {
//                mSelectedKey = com.vasundhara.vision.subscription.constants.Constants.FIVE_HUNDRED
//                onFiveCoin()
//                Constants.isCoin = true
//            }
//            R.id.ll_buy_2000_coins -> {
//                mSelectedKey = com.vasundhara.vision.subscription.constants.Constants.TWO_THOUSAND
//                onTwoCoin()
//                Constants.isCoin = true
//
//            }
//            R.id.ll_buy_10000_coins -> {
//                mSelectedKey = com.vasundhara.vision.subscription.constants.Constants.TEN_THOUSAND
//                onTenCoin()
//                Constants.isCoin = true
//
//            }

            R.id.ll_get_10_free_coin -> {
                val count = AdsPrefs.getInt(this, AdsPrefs.ADS_FREE_COUNT, 0)
                if (!isTimeAutomatic(this)) {
                    Toast.makeText(this, resources.getString(R.string.make_sure_date_settings_automatic), Toast.LENGTH_LONG).show()
                    startActivityForResult(Intent(Settings.ACTION_DATE_SETTINGS), 0)
                    return
                }
                if (count >= 5) {
                    Toast.makeText(this, resources.getString(R.string.you_exhausted_your_daily_limit), Toast.LENGTH_SHORT).show()
                    return
                }

                if (!NetworkHelper.isOnline(this)) {
                    Toast.makeText(this, resources.getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show()
                    return
                }

                 noEnoughCoinDialogFragment = NoEnoughCoinDialogFragment(object : NoEnoughCoinDialogFragment.OnButtonClickListener {
                    override fun onPositive(bottomSheetDialo: NoEnoughCoinDialogFragment) {


                        isShowRewardVideoAd(
                            onStartToLoadRewardVideoAd = {

                            },
                            onUserEarnedReward = { isUserEarnedReward ->
                                if(isUserEarnedReward) {

                                    AdsPrefs.save(this@CoinPurchaseActivity, AdsPrefs.ADS_FREE_COUNT, count + 1)
                                    AdsPrefs.save(this@CoinPurchaseActivity, AdsPrefs.WALLET_COINS, AdsPrefs.getInt(this@CoinPurchaseActivity, AdsPrefs.WALLET_COINS, 100) + 10)
                                    txtCoins.text = AdsPrefs.getInt(this@CoinPurchaseActivity, AdsPrefs.WALLET_COINS, 100).toString()
                                } else {
                                    Toast.makeText(this@CoinPurchaseActivity, resources.getString(R.string.try_again_later), Toast.LENGTH_SHORT).show()
                                }
                            },
                            onAdLoaded = {

                            }
                        )

                        bottomSheetDialo.dismiss()
                    }

                    override fun onNegative(bottomSheetDialog: NoEnoughCoinDialogFragment) {
                        bottomSheetDialog.dismiss()
                    }
                }, resources.getString(R.string.watch_view_to_get_coins))
                noEnoughCoinDialogFragment!!.show(supportFragmentManager, "dialog_no")
            }
        }
    }

    private fun setPlan(key: String) {
//        billingProcessor!!.consumePurchase(key)
//        billingProcessor!!.purchase(this, key, "")
    }

//    override fun onProductPurchased(productId: String, details: TransactionDetails?) {
//        try {
//
//            Log.e(TAG, "onProductPurchased:  developerPayload :: -> " + details!!.purchaseInfo.purchaseData.developerPayload)
//            Log.e(TAG, "onProductPurchased:  orderId :: -> " + details.purchaseInfo.purchaseData.orderId)
//            Log.e(TAG, "onProductPurchased:  packageName :: -> " + details.purchaseInfo.purchaseData.packageName)
//            Log.e(TAG, "onProductPurchased:  purchaseToken :: -> " + details.purchaseInfo.purchaseData.purchaseToken)
//            Log.e(TAG, "onProductPurchased:  autoRenewing :: -> " + details.purchaseInfo.purchaseData.autoRenewing)
//            Log.e(TAG, "onProductPurchased:  purchaseTime :: -> " + details.purchaseInfo.purchaseData.purchaseTime)
//            Log.e(TAG, "onProductPurchased:  purchaseState :: -> " + details.purchaseInfo.purchaseData.purchaseState)
//        } catch (e: java.lang.Exception) {
//
//        }
//        var coins = 0
//        when (productId) {
//            productKey500 -> {
//                coins = 500
//            }
//            productKey2000 -> {
//                coins = 1000
//            }
//            productKey10000 -> {
//                coins = 2500
//            }
//        }
//        billingProcessor?.consumePurchase(productKey500)
//        billingProcessor?.consumePurchase(productKey2000)
//        billingProcessor?.consumePurchase(productKey10000)
//        AdsPrefs.save(this, AdsPrefs.WALLET_COINS, AdsPrefs.getInt(this, AdsPrefs.WALLET_COINS, 100) + coins)
//        initViewAction()
//    }


    fun isTimeAutomatic(c: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            Settings.Global.getInt(c.contentResolver, Settings.Global.AUTO_TIME, 0) == 1
        } else {
            Settings.System.getInt(c.contentResolver, Settings.System.AUTO_TIME, 0) == 1
        }
    }


    companion object {
        private const val TAG = "PremiumAccessActivity"
    }


    override fun onResume() {
        super.onResume()

        SolidWallpaperApplication.staticLanguage.Factory.create(this)

        Log.d("TAG====>>>>", "onResume: " + isTimeAutomatic(this))
        txt_remaining_ads.text = (5 - AdsPrefs.getInt(this, AdsPrefs.ADS_FREE_COUNT, 0)).toString()
        if (isTimeAutomatic(this)) {
            initViewAction()
        }
    }
}