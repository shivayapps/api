package com.hd.wallpaper.solid.color.background.PaintViewFol.shared_preferences;

import android.content.Context;
import android.content.SharedPreferences;

public class MySharedPrefForText {

    private static final String TAG = "MySharedPref";
    Context mContext;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    public static String ADS_REMOVED="AdsRemoved";

    public MySharedPrefForText(Context mContext) {
        if (mContext==null){
            return;
        }
        this.mContext = mContext;
        sharedPreferences=mContext.getSharedPreferences("my_pref",Context.MODE_PRIVATE);
        editor=sharedPreferences.edit();
    }

    public void setImage(String image){
        editor.putString("image",image);
        editor.commit();
    }


/*    public void setAdsRemoved(){
        editor.putBoolean(ADS_REMOVED,true);
        editor.commit();
    }

    public boolean getAdsRemoved(){
        return sharedPreferences.getBoolean(ADS_REMOVED,false);
    }*/

    public String getImage(){
        return sharedPreferences.getString("image",null);
    }

    public void setUri(String image){
        editor.putString("image",image);
        editor.commit();
    }

    public void setCount(int count){
        editor.putInt("count",count);
        editor.commit();
    }

    public void setLanguage(String language){
        editor.putString("language",language);
        editor.commit();
    }

    public String getLanguage(){
        return sharedPreferences.getString("language","English");
    }

    public void setScaleType(String scale){
        editor.putString("scale",scale);
        editor.commit();
    }

    public boolean needToshowLanguage(){
        return sharedPreferences.getBoolean("SHOW_LANGUAGE",true);
    }

    public void noNeedToShowLanguage(){
        editor.putBoolean("SHOW_LANGUAGE",false);
        editor.commit();
    }

    public String getScale(){
        return sharedPreferences.getString("scale","fill");
    }

    public void setVibration(boolean onOff){
        editor.putBoolean("vibrate",onOff);
        editor.commit();
    }

    public boolean getVibration(){
        return sharedPreferences.getBoolean("vibrate",true);
    }

    public int getCount(){
        return sharedPreferences.getInt("count",0);
    }

    public String getUri(){
        return sharedPreferences.getString("image",null);
    }

    public void setIsFirstNotification(){
        editor.putBoolean("isFirst",false);
        editor.commit();
    }
    public boolean getIsFirstNotification(){
        return sharedPreferences.getBoolean("isFirst",true);
    }

    public void setFirstAlarm(){
        editor.putBoolean("isFirstAlarm",false);
        editor.commit();
    }

    public void setVisitPlay(){
        editor.putString("visit_play","visit_play");
        editor.commit();
    }

    public String getVisitPlay(){
        return sharedPreferences.getString("visit_play",null);
    }

    public void setCountExist(int count){
        editor.putInt("count_exist",count);
        editor.commit();
    }

    public int getCountExist(){
        return sharedPreferences.getInt("count_exist",0);
    }

    public void setCountCreated(int count){
        editor.putInt("count_created",count);
        editor.commit();
    }

    public int getCountCreated(){
        return sharedPreferences.getInt("count_created",0);
    }

    public boolean getFirstAlarm(){
        return sharedPreferences.getBoolean("isFirstAlarm",true);
    }


   public void setDoNotAsk(){
       editor.putString("do_not_ask","do_not_ask");
       editor.commit();
   }

    public String getDoNotAsk(){
        return sharedPreferences.getString("do_not_ask",null);
    }

    public Object getScaleType() {
        return sharedPreferences.getString("scale_type","fill");
    }

    public void storeEventWallpaperPosition(int mPosition) {
        editor.putInt("position",mPosition);
        editor.commit();
    }

    public int getPosition(){
        return sharedPreferences.getInt("position",0);
    }

    public boolean isAlarmSet(int id) {
        return sharedPreferences.getBoolean(String.valueOf(id),false);
    }

    public void setAlarm(int id, boolean b) {
        editor.putBoolean(String.valueOf(id),b);
        editor.commit();
    }

    public void setAlarmId(int id){
        editor.putInt("ALARM_ID",id);
        editor.commit();
    }

    public int getAlarmId(){
        return sharedPreferences.getInt("ALARM_ID",-1);
    }

    public void removeAlarm(int id) {
         editor.remove(String.valueOf(id));
         editor.commit();
    }

    public void setDisplayWidth(int i){
        editor.putInt("displaywidth",i);
        editor.commit();
    }

    public void setDisplayHeight(int i){
        editor.putInt("displayheight",i);
        editor.commit();
    }

    public int getDeviceWidth() {
        return  sharedPreferences.getInt("displaywidth",1080);
    }

    public int getDeviceHeight() {
        return  sharedPreferences.getInt("displayheight",1920);
    }
}
