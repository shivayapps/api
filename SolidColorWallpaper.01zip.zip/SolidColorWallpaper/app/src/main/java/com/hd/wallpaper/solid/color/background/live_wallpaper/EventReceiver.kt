package com.auto.wallpaper.live.background.changer.editor.receiver

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.WallpaperManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Point
import android.os.Build
import android.util.Log
import android.view.Display
import android.view.WindowManager
import com.auto.wallpaper.live.background.changer.editor.utils.EglUtils
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.hd.wallpaper.solid.color.background.model.AutoWallpaperModel
import com.hd.wallpaper.solid.color.background.shared_pref.MySharedPref
import com.hd.wallpaper.solid.color.background.sqlite_database.DBHelperAutoWallpaper
import java.lang.Math.sqrt
import java.util.*


class EventReceiver : BroadcastReceiver() {

    private val TAG = "EventReceiver"

    private var wallpaperManager: WallpaperManager? = null
    private var mSharedPreference: MySharedPref? = null
    private var mSQLiteHelper: DBHelperAutoWallpaper? = null
    private var mList: ArrayList<AutoWallpaperModel>? = null
    private var mModel: AutoWallpaperModel? = null

    private var mPosition = 0

    override fun onReceive(context: Context?, intent: Intent?) {

        Log.d("TAG", "onReceive : ")

        if (context == null) {
            return
        }

        wallpaperManager = WallpaperManager.getInstance(context)
        mSQLiteHelper = DBHelperAutoWallpaper(context!!)
        mSharedPreference = MySharedPref(context!!)

        mList = mSQLiteHelper?.allAutoWallpaper

        for (model in mList!!) {

            val gson = Gson()
            val token: TypeToken<Array<String?>?> = object : TypeToken<Array<String?>?>() {}
            val imageList = gson.fromJson<Array<String>>(model.imagespath, token.type)

            val count = imageList.size
            /*   if (count != model.images.count()) {
                   mSQLiteHelper?.updateEvent(model)
               }*/
        }

        mModel = findCurrentModel()

        if (mModel != null) {

            val calendar = Calendar.getInstance()

            val gson = Gson()
            val token: TypeToken<Array<String?>?> = object : TypeToken<Array<String?>?>() {}
            val imageList = gson.fromJson<Array<String>>(mModel!!.imagespath, token.type)
            /* if (imageList!!.size == 0) {
                 cancelAlarm(
                     ("2121${mModel!!.id}").toInt(),
                     context,
                     EventReceiver::class.java
                 )
                 return
             }*/

            if (mPosition >= imageList!!.size) {
                mPosition = 0
            }

            if (imageList.size > 0) {

                mPosition = mSharedPreference!!.position

                Log.d("helllowwww", mPosition.toString())
                 if (mPosition >= imageList!!.size) {
                     mPosition = 0
                 }

                val bitmap = decodeFile(imageList[mPosition], context)
                val scaledBitmap: Bitmap?

                try {


                    //  val arr = getHourOrMin(mModel!!.delaytime)

                    //   calendar[Calendar.SECOND] = 0
                    //   calendar[Calendar.MILLISECOND] = 0

                    val isRepeat = true
                    /*  val formatter: DateFormat = SimpleDateFormat("dd-MM-yyyy")
                      var date: Date? = null
                      try {
                          date = formatter.parse(mModel!!.endDate) as Date
                          var time = 23 * 60 * 60 * 1000 + (59 * 60 * 1000) + (59 * 1000).toLong()
                          time += date.time
                          if (time <= System.currentTimeMillis()) {
                              cancelAlarm(
                                  ("2121${mModel!!.id}").toInt(),
                                  context,
                                  EventReceiver::class.java
                              )

                              Log.d(
                                  TAG,
                                  "onReceive: delete"
                              )
                              mList!!.remove(mModel!!)
                              mSQLiteHelper?.deleteEvent(mModel!!.id)
                              mSharedPreference?.removeAlarm(mModel!!.id)

                              mModel = null
                              mModel = findCurrentModel()
                              isRepeat = false
                          }
                      } catch (e: Exception) {
                          e.printStackTrace()
                      }*/

                    //  if (isRepeat) {
                    var interval=0;
                    val interval1: String = mModel!!.delaytime!!
                    if (interval1 == "Random") {
                        interval = 60 * 1000
                    } else {
                        if (interval1.contains("C")) {
                            interval1.replace("C", "")
                            interval1.trim { it <= ' ' }
                        }
                        val time1 = interval1.split(" ").toTypedArray()
                        if (time1.size == 0) {
                            return
                        }
                        val mTime = time1[0]
                        val intve = mTime.split(":").toTypedArray()
                        if (intve.size == 0) {
                            return
                        }
                        val hr = intve[0].toInt() * 60 * 60 * 1000
                        val mn = intve[1].toInt() * 60 * 1000
                        val sec = intve[2].toInt() * 1000
                        interval = hr + mn + sec
                    }

                 /*   val interval = when (mModel!!.delaytime) {
                        "5 Sec" -> 5 * 1000
                        "15 Sec" -> 15 * 1000
                        "30 Sec" -> 30 * 1000
                        "2 Min" -> 2 * 60 * 1000
                        "5 Min" -> 5 * 60 * 1000
                        "15 Min" -> 15 * 60 * 1000
                        else -> 60 * 1000
                    }*/
                    /*      when (mModel!!.delaytime) {
                              "5 Sec" -> calendar.add(Calendar.SECOND, 5)

                              "15 Sec" -> calendar.add(Calendar.SECOND, 15)
                              "30 Sec" -> calendar.add(Calendar.SECOND, 30)
                              "2 Min" -> calendar.add(Calendar.MINUTE, 1)
                              "5 Min" -> calendar.add(Calendar.MINUTE, 5)
                              "15 Min" -> calendar.add(Calendar.MINUTE, 15)
                              else -> calendar.add(Calendar.MINUTE, 1)
                          }
  */

                    Log.d("helllowwww", (Calendar.getInstance().timeInMillis + interval).toString() + "  " + interval)
                    //  }



                    scaledBitmap = if (mSharedPreference?.scaleType == "fill") {
                        scaledBitmap(bitmap)
                    } else {
                        scaleBitmap1(context, bitmap!!)
                    }

                    if (scaledBitmap != null) {
                        if (mModel!!.screenmode == "Home Screen") {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                                wallpaperManager?.setBitmap(
                                        scaledBitmap,
                                        null,
                                        true,
                                        WallpaperManager.FLAG_SYSTEM
                                )
                            } else {
                                wallpaperManager?.setBitmap(scaledBitmap)
                            }
                        } else if (mModel!!.screenmode == "Both") {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                                wallpaperManager?.setBitmap(
                                        scaledBitmap,
                                        null,
                                        true,
                                        WallpaperManager.FLAG_SYSTEM
                                )
                                wallpaperManager?.setBitmap(
                                        scaledBitmap,
                                        null,
                                        true,
                                        WallpaperManager.FLAG_LOCK
                                )
                            } else {
                                wallpaperManager?.setBitmap(scaledBitmap)
                            }
                        } else {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                                wallpaperManager?.setBitmap(
                                        bitmap,
                                        null,
                                        true,
                                        WallpaperManager.FLAG_LOCK
                                )
                            }
                        }
                    }
                    mPosition++

                    if (mPosition >= imageList.size) {
                        mPosition = 0
                    }
                    mSharedPreference?.storeEventWallpaperPosition(mPosition)

                    Log.d(TAG, "onReceive: ${mSharedPreference!!.isAlarmSet(mModel!!.id)} ")

                    if (!mSharedPreference!!.isAlarmSet(mModel!!.id)) {
                        Log.d(TAG, "onReceive: repeat ")
                        cancelAlarm(
                                ("21210").toInt(),
                                context,
                                EventReceiver::class.java
                        )
                        val myIntent = Intent(
                                context,
                                EventReceiver::class.java
                        )
                        val pendingIntent =
                                PendingIntent.getBroadcast(
                                        context,
                                        ("21210").toInt(),
                                        myIntent,
                                        PendingIntent.FLAG_IMMUTABLE
                                )
                        val alarmManager =
                                context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            if (Build.VERSION.SDK_INT == Build.VERSION_CODES.O_MR1) {
                                alarmManager.setExact(
                                        AlarmManager.RTC_WAKEUP,
                                        calendar.timeInMillis + interval,
                                        pendingIntent
                                )

                            } else
                                alarmManager.setAlarmClock(
                                        AlarmManager.AlarmClockInfo(
                                                calendar.timeInMillis + interval,
                                                pendingIntent
                                        ), pendingIntent
                                )
                            /*alarmManager.setExact(
                                    AlarmManager.RTC_WAKEUP,
                                    Calendar.getInstance().timeInMillis + interval,
                                    pendingIntent
                            )*/
                        } else {
                            Log.d("TAG==>>>","1. ${calendar.timeInMillis}")

                            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.LOLLIPOP_MR1){
                                Log.d("TAG==>>>","2. ${calendar.timeInMillis}")
                                alarmManager.set(
                                        AlarmManager.RTC_WAKEUP,
                                        calendar.timeInMillis + interval,
                                        pendingIntent
                                )
                            }else {
                                alarmManager.setRepeating(
                                        AlarmManager.RTC_WAKEUP,
                                        calendar.timeInMillis,
                                        interval.toLong(),
                                        pendingIntent
                                )
                            }
                            mSharedPreference?.setAlarm(mModel!!.id, true)
                        }
                    }else{
                        val myIntent = Intent(
                                context,
                                EventReceiver::class.java
                        )
                        val pendingIntent =
                                PendingIntent.getBroadcast(
                                        context,
                                        ("21210").toInt(),
                                        myIntent,
                                    PendingIntent.FLAG_IMMUTABLE
                                )
                        val alarmManager =
                                context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.LOLLIPOP_MR1){
                            Log.d("TAG==>>>","2. ${calendar.timeInMillis}")
                            alarmManager.set(
                                    AlarmManager.RTC_WAKEUP,
                                    calendar.timeInMillis,
                                    pendingIntent
                            )
                        }
                    }
                } catch (e: Throwable) {
                    e.printStackTrace()
                }
            } else {
                try {
                    mSharedPreference?.removeAlarm(mModel!!.id)
                    //     mSQLiteHelper?.deleteEvent(mModel!!.id)
                    cancelAlarm(
                            ("21210").toInt(),
                            context,
                            EventReceiver::class.java
                    )
                    mList!!.remove(mModel!!)

                } catch (e: java.lang.Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    companion object {
        fun cancelAlarm(
                id: Int,
                context: Context,
                cls: Class<*>?
        ) {
            try {
                val receiver = ComponentName(context, cls!!)
                val pm = context.packageManager
                pm.setComponentEnabledSetting(
                        receiver,
                        PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                        PackageManager.DONT_KILL_APP
                )
                val intent1 = Intent(context, cls)
                val pendingIntent = PendingIntent.getBroadcast(
                        context,
                        id,
                        intent1,
                        PendingIntent.FLAG_UPDATE_CURRENT
                )
                val am =
                        context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                am.cancel(pendingIntent)
                pendingIntent.cancel()
                Log.d("1223323232","1. "+id)
            } catch (e: Exception) {
                e.printStackTrace()
                Log.d("1223323232",e.message+" 2")
            }
        }
    }

    private fun findCurrentModel(): AutoWallpaperModel? {
        return mSQLiteHelper!!.wallpaperModel
    }

    fun decodeFile(photoPath: String?, context: Context): Bitmap? {
        System.gc()
        Runtime.getRuntime().gc()
        return try {
            var maxImageSize = calculateMaxBitmapSize(context)
            if (maxImageSize == 0) {
                maxImageSize = 1000
            }
            decodeSampledBitmapFromResource(photoPath, maxImageSize, maxImageSize)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun scaledBitmap(bitmap: Bitmap?): Bitmap? {
        System.gc()
        Runtime.getRuntime().gc()
        val width: Int
        val height: Int
        var scaledBitmap: Bitmap? = null
        if (bitmap != null) {
            try {
                width = bitmap.width
                height = bitmap.height
                val y = sqrt(700000 / (width.toDouble() / height))
                val x = y / height * width
                scaledBitmap = Bitmap.createScaledBitmap(bitmap, x.toInt(), y.toInt(), true)
            } catch (e: Exception) {
                e.printStackTrace()
                Log.e("TAGS", "onError ${e.message}")
            }
        }
        return scaledBitmap
    }

    private fun scaleBitmap1(context: Context, bm: Bitmap): Bitmap? {

        var bm = bm
        var width = bm.width
        var height = bm.height


        Log.v("Pictures", "Width and height are $width--$height")
        if (width > height) {
            Log.d("Pictures", "scaleBitmap: l")
            // landscape
            val ratio: Float =
                    width.toFloat() / MySharedPref(context).deviceWidth
            width = MySharedPref(context).deviceWidth
            height = (height / ratio).toInt()
            if (height >= MySharedPref(context).deviceHeight) {
                height = MySharedPref(context).deviceHeight
            }
        } else if (height > width) {
            Log.d("Pictures", "scaleBitmap: p")
            // portrait
            val ratio: Float =
                    height.toFloat() / MySharedPref(context).deviceHeight
            height = MySharedPref(context).deviceHeight
            width = (width / ratio).toInt()
            if (width >= MySharedPref(context).deviceWidth) {
                width = MySharedPref(context).deviceWidth
            }
        } else { // square
            Log.d("Pictures", "scaleBitmap: s")
            height = MySharedPref(context).deviceWidth
            width = MySharedPref(context).deviceWidth
        }
        Log.v(
                "Pictures",
                "after scaling Width and height are $width--$height"
        )
        bm = Bitmap.createScaledBitmap(bm, width, height, true)
        return bm
    }

    private fun decodeSampledBitmapFromResource(
            path: String?,
            reqWidth: Int,
            reqHeight: Int
    ): Bitmap? { // First decode with inJustDecodeBounds=true to check dimensions
        val options =
                BitmapFactory.Options()
        options.inJustDecodeBounds = true
        BitmapFactory.decodeFile(path, options)
        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight)
        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false
        options.inPreferredConfig = Bitmap.Config.RGB_565
        return BitmapFactory.decodeFile(path, options)
    }

    private fun calculateInSampleSize(
            options: BitmapFactory.Options,
            reqWidth: Int,
            reqHeight: Int
    ): Int { // Raw height and width of image
        val height = options.outHeight
        val width = options.outWidth
        var inSampleSize = 1
        if (height > reqHeight || width > reqWidth) { // Calculate the largest inSampleSize value that is a power of 2 and keeps both
            // height and width lower or equal to the requested height and width.
            while (height / inSampleSize > reqHeight || width / inSampleSize > reqWidth) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }

    private fun calculateMaxBitmapSize(context: Context): Int {
        val wm =
                context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val display: Display
        val width: Int
        val height: Int
        val size = Point()
        if (wm != null) {
            display = wm.defaultDisplay
            display.getSize(size)
        }
        width = size.x
        height = size.y
        // Twice the device screen diagonal as default
        var maxBitmapSize = sqrt(
                Math.pow(width.toDouble(), 2.0) + Math.pow(
                        height.toDouble(),
                        2.0
                )
        ).toInt()
        // Check for max texture size via Canvas
        val canvas = Canvas()
        val maxCanvasSize =
                canvas.maximumBitmapWidth.coerceAtMost(canvas.maximumBitmapHeight)
        if (maxCanvasSize > 0) {
            maxBitmapSize = maxBitmapSize.coerceAtMost(maxCanvasSize)
        }
        // Check for max texture size via GL
        val maxTextureSize: Int = EglUtils.maxTextureSize
        if (maxTextureSize > 0) {
            maxBitmapSize = maxBitmapSize.coerceAtMost(maxTextureSize)
        }
        return maxBitmapSize
    }
}