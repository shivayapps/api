package com.hd.wallpaper.solid.color.background.model

class StickerNewModel(var path: String, var isFree: Boolean)