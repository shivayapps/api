package com.hd.wallpaper.solid.color.background.fragment

import android.app.Activity
import android.content.DialogInterface
import android.content.Intent
import android.content.res.Resources
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.PagerSnapHelper
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.SnapHelper
import com.airbnb.lottie.LottieAnimationView
import com.andrefrsousa.superbottomsheet.SuperBottomSheetFragment
import com.wifiproxysettingslibrary.NetworkHelper
import com.wifiproxysettingslibrary.wifi_network.exceptions.ApiNotSupportedException
import com.wifiproxysettingslibrary.wifi_network.exceptions.NullWifiConfigurationException
import com.wifiproxysettingslibrary.wifi_network.wifi_proxy_changing_realisations.api_from_21_to_22.WifiConfiguration
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.app.ads.helper.RewardVideoHelper.isShowRewardVideoAd

import com.google.android.material.tabs.TabLayout
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.activity.CoinPurchaseActivity
import com.hd.wallpaper.solid.color.background.activity.GifLiveWallPaper
import com.hd.wallpaper.solid.color.background.adapter.RecyclerSnapAdapter
import com.hd.wallpaper.solid.color.background.model.api.DataItem
import com.hd.wallpaper.solid.color.background.newModel.ImagesItem
import com.hd.wallpaper.solid.color.background.newModel.WallpaperWeekModelNewResponse
import com.hd.wallpaper.solid.color.background.retrofit.APIClient.client
import com.hd.wallpaper.solid.color.background.retrofit.APIInterface
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs.getBoolean
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs.getInt
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs.save
import com.hd.wallpaper.solid.color.background.shared_pref.MySharedPref
import com.hd.wallpaper.solid.color.background.sqlite_database.DBHelper
import com.hd.wallpaper.solid.color.background.sqlite_database.DBHelperSuscription
import retrofit2.Call
import retrofit2.Callback
import java.lang.reflect.InvocationTargetException
import java.util.*

class BottomsheetForgroundCategoryFragment : SuperBottomSheetFragment {
    private var progressBar: ProgressBar? = null
    private var mTempForgroundList: ArrayList<WallpaperWeekModelNewResponse?>? = null
    private var apiInterface: APIInterface? = null
    private var mDataList: ArrayList<DataItem>? = null
    private var mDataListNew: ArrayList<com.hd.wallpaper.solid.color.background.newModel.DataItem>? = null
    private var path: String? = null
    private var onItemSelected: OnItemSelected? = null
    private var icBack: ImageView? = null
    private var btnShare: ImageView? = null
    private var btnAd: LottieAnimationView? = null
    private var mySharedPref: MySharedPref? = null
    private var dbHelper: DBHelper? = null
    private var dbHelperSuscription: DBHelperSuscription? = null
    private var adLayout: RelativeLayout? = null
    private var mAContext: Activity? = null

    //  private ViewPager viewPagerScreen;
    private var recyclerSnap: RecyclerView? = null
    private var tabLayoutScreen: TabLayout? = null
    private var snapAdapter: RecyclerSnapAdapter? = null
    private var mAllReadyData: ArrayList<ArrayList<WallpaperWeekModelNewResponse?>?>? = null
    private var categoryNameList: ArrayList<String?>? = null

    //   private RewardedAd gameOverRewardedAd, gameOverRewardedAd2, gameOverRewardedAd3;
    private var isAdShow: Boolean = false

    constructor() {
        // Required empty public constructor
    }

    constructor(mDataList: ArrayList<ArrayList<WallpaperWeekModelNewResponse?>?>?, categoryNameList: ArrayList<String?>?, onItemSelected: OnItemSelected?) {
        mAllReadyData = mDataList
        this.onItemSelected = onItemSelected
        this.categoryNameList = categoryNameList
    }

    public override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                                     savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        super.onCreateView(inflater, container, savedInstanceState)
        return inflater.inflate(R.layout.fragment_bottomsheet_forground_category, container, false)
    }

    public override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        mAContext = activity
        dbHelper = DBHelper(mAContext)
        dbHelperSuscription = DBHelperSuscription(mAContext)
        btnAd = view.findViewById(R.id.btnAd)
        icBack = view.findViewById(R.id.icBack)
        btnShare = view.findViewById(R.id.btnShare)
        adLayout = view.findViewById(R.id.adLayout)
        tabLayoutScreen = view.findViewById(R.id.tabLayoutScreen)
        //  viewPagerScreen = view.findViewById(R.id.viewPagerScreen);
        recyclerSnap = view.findViewById(R.id.recyclerSnap)
        mySharedPref = MySharedPref(mAContext)
        if ( /*!mySharedPref.getAdsRemoved() &&*/!getBoolean(mAContext, AdsPrefs.IS_SUBSCRIBED, false)) {
            adLayout!!.visibility = View.GONE
            btnShare!!.visibility = View.VISIBLE
            requireActivity().isShowInterstitialAd{

            }

        } else {
            adLayout!!.visibility = View.GONE
            btnShare!!.visibility = View.VISIBLE
        }
        progressBar = view.findViewById(R.id.progressBar)
        icBack!!.setOnClickListener { dismiss() }
        btnAd!!.setOnClickListener {
            requireActivity().isShowInterstitialAd{

            }
        }
        btnShare!!.setOnClickListener { shareOwnApp() }
        mDataList = ArrayList()
        Handler().postDelayed({
            if (mAllReadyData != null && mAllReadyData!!.size <= 0) {
                mAllReadyData = ArrayList()
                try {
                    checkStatus()
                } catch (e: InvocationTargetException) {
                    e.printStackTrace()
                } catch (e: NoSuchMethodException) {
                    e.printStackTrace()
                } catch (e: ApiNotSupportedException) {
                    e.printStackTrace()
                } catch (e: NoSuchFieldException) {
                    e.printStackTrace()
                } catch (e: IllegalAccessException) {
                    e.printStackTrace()
                } catch (e: NullWifiConfigurationException) {
                    callNewApi()
                    e.printStackTrace()
                }
            } else {
                setData()
            }
        }, 0)
    }

    private fun shareOwnApp() {
        val shareIntent: Intent = Intent(Intent.ACTION_SEND)
        shareIntent.type = "text/plain"
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Solid Color Wallpaper")
        var shareMessage: String = ""
        shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=com.solid.color.wallpaper.hd.image.background"
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
        startActivity(Intent.createChooser(shareIntent, getResources().getString(R.string.choose_one)))
    }

    private fun setData() {
        if (mAllReadyData != null && mAllReadyData!!.size > 0) {
            for (i in categoryNameList!!.indices) {
                tabLayoutScreen!!.addTab(tabLayoutScreen!!.newTab().setText(categoryNameList!!.get(i)))
            }
            tabLayoutScreen!!.tabGravity = TabLayout.GRAVITY_CENTER
            val manager: LinearLayoutManager = object : LinearLayoutManager(mAContext, HORIZONTAL, false) {
                public override fun canScrollHorizontally(): Boolean {
                    return false
                }
            }
            recyclerSnap!!.layoutManager = manager
            val snapHelper: SnapHelper = PagerSnapHelper()
            snapHelper.attachToRecyclerView(recyclerSnap)
            /*    CategoryScreenPagerAdapter pagerAdapter = new CategoryScreenPagerAdapter(getChildFragmentManager(), mAllReadyData);
            viewPagerScreen.setAdapter(pagerAdapter);
            viewPagerScreen.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

                }

                @Override
                public void onPageSelected(int position) {
                    System.gc();
                    Runtime.getRuntime().gc();
                }

                @Override
                public void onPageScrollStateChanged(int state) {

                }
            });
            viewPagerScreen.setOffscreenPageLimit(6);
            tabLayoutScreen.setupWithViewPager(viewPagerScreen);*/
            val onItemChanged: RecyclerSnapAdapter.OnItemChanged = object : RecyclerSnapAdapter.OnItemChanged {
                public override fun onItemChanged(position: Int) {}
                public override fun onItemSelect(model: WallpaperWeekModelNewResponse?) {
                    /* if (model.isPremium()) {
                        path = null;
                        dismiss();
                        startActivity(new Intent(mAContext, PremiumAccessActivity.class));
                    } else*/
                    if (!model!!.isLocked) {
                        path = model.imageItem!!.image
                        dismiss()
                    } else {
                        if (!NetworkHelper.isOnline(mAContext)) {
                            Toast.makeText(mAContext, getResources().getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show()
                            return
                        }
                        showAdDialog(model)

                    }
                }
            }
            tabLayoutScreen!!.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
                public override fun onTabSelected(tab: TabLayout.Tab) {
                    recyclerSnap!!.scrollToPosition(tab.position)
                    /*   if (tabLayoutScreen.getTabAt(tab.getPosition())!=null) {
                        tabLayoutScreen.getTabAt(tab.getPosition()).select();
                    }*/
                }

                public override fun onTabUnselected(tab: TabLayout.Tab) {}
                public override fun onTabReselected(tab: TabLayout.Tab) {}
            })
            snapAdapter = RecyclerSnapAdapter(mAllReadyData!!, mAContext!!, onItemChanged)
            recyclerSnap!!.adapter = snapAdapter
            for (i in mAllReadyData!!.indices) {
                try {
                    tabLayoutScreen!!.getTabAt(i)!!.text = categoryNameList!![i]
                    val view: View = LayoutInflater.from(mAContext).inflate(R.layout.rv_tab, null)
                    tabLayoutScreen!!.getTabAt(i)!!.customView = view
                    val textView: TextView = view.findViewById(R.id.textTab)
                    textView.text = categoryNameList!![i]
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            Handler().postDelayed({
                tabLayoutScreen!!.visibility = View.VISIBLE
                //  viewPagerScreen.setVisibility(View.VISIBLE);
                recyclerSnap!!.visibility = View.VISIBLE
                progressBar!!.visibility = View.GONE
            }, 1000)
        } else {
            try {
                checkStatus()
            } catch (e: InvocationTargetException) {
                e.printStackTrace()
            } catch (e: NoSuchMethodException) {
                e.printStackTrace()
            } catch (e: ApiNotSupportedException) {
                e.printStackTrace()
            } catch (e: NoSuchFieldException) {
                e.printStackTrace()
            } catch (e: IllegalAccessException) {
                e.printStackTrace()
            } catch (e: NullWifiConfigurationException) {
                callNewApi()
                e.printStackTrace()
            }
        }
    }

    private fun showAdDialog(model: WallpaperWeekModelNewResponse) {
        val watchAdDialogFragment: WatchAdDialogFragment = WatchAdDialogFragment(object : WatchAdDialogFragment.OnButtonClickListener {
            public override fun onPositive(bottomSheetDialo: WatchAdDialogFragment, isNoMoreCoin: Boolean) {
                /* if (isNoMoreCoin){
                    startActivity(new Intent(mAContext, CoinPurchaseActivity.class));
                     bottomSheetDialo.dismiss();
                     dismiss();
                    return;
                }*/
                val coins: Int = getInt(activity, AdsPrefs.WALLET_COINS, 100)
                if (coins < model.coins) {
                    val noEnoughCoinDialogFragment: NoEnoughCoinDialogFragment = NoEnoughCoinDialogFragment(object : NoEnoughCoinDialogFragment.OnButtonClickListener {
                        public override fun onPositive(bottomSheetDialo: NoEnoughCoinDialogFragment) {
//                            com.vasundhara.vision.subscription.constants.Constants.subActivity = "coin"
                            startActivity(Intent(mAContext, CoinPurchaseActivity::class.java))
                            bottomSheetDialo.dismiss()
                            dismiss()
                        }

                        public override fun onNegative(bottomSheetDialog: NoEnoughCoinDialogFragment) {
                            bottomSheetDialog.dismiss()
                        }
                    }, getResources().getString(R.string.no_enough_coin))
                    noEnoughCoinDialogFragment.show(activity!!.supportFragmentManager, "dialog_no")
                } else {
                    save(mAContext, AdsPrefs.WALLET_COINS, coins - model.coins)
                    dbHelper!!.insertPath((model.imageItem!!.image)!!)
                    model.isLocked = false
                    path = model.imageItem!!.image
                    dismiss()
                }
                bottomSheetDialo.dismiss()
            }

            public override fun onNegative(bottomSheetDialog: WatchAdDialogFragment, iswatchadavalable: Boolean) {
                bottomSheetDialog.dismiss()

                requireActivity().isShowRewardVideoAd(
                    onStartToLoadRewardVideoAd = {

                    },
                    onUserEarnedReward = { isUserEarnedReward ->
                        if(isUserEarnedReward) {

                            dbHelper!!.insertPath((model.imageItem!!.image)!!)
                            model.isLocked = false
                            path = model.imageItem!!.image
                            dismiss()

                            isAdShow = false
                            Log.d(GifLiveWallPaper.TAG, "User earned the reward.")
                        } else {
                            Toast.makeText(activity, resources.getString(R.string.try_again_later), Toast.LENGTH_SHORT).show()
                        }
                    },
                    onAdLoaded = {

                    }
                )

            }
        }, java.lang.String.valueOf(model.coins))
        watchAdDialogFragment.show(requireActivity().supportFragmentManager, "dialog")

        /* BottomSheetFragment bottomSheetFragment = new BottomSheetFragment(getResources().getString(R.string.watch_video), getResources().getString(R.string.wathch_video_to_unlock_screen), getResources().getString(R.string.watch), getResources().getString(R.string.cancel), R.drawable.ic_video, new BottomSheetFragment.OnButtonClickListener() {
            @Override
            public void onPositive(BottomSheetFragment bottomSheetDialo) {
                bottomSheetDialo.dismiss();

                if (rewardedAd.isLoaded()) {
                    showAdReward(model, rewardedAd);
                } */
        /*else if (gameOverRewardedAd2.isLoaded()) {
                    showAdReward(model, gameOverRewardedAd2);
                } else if (gameOverRewardedAd3.isLoaded()) {
                    showAdReward(model, gameOverRewardedAd3);
                }*/
        /* else {
         */
        /*   assert RewardVideoAds.Companion.getInstence() != null;
                    RewardVideoAds.Companion.getInstence().loadVideoAdMain(getActivity());*/
        /*
                    Toast.makeText(mAContext, getResources().getString(R.string.try_again_later), Toast.LENGTH_SHORT).show();
                }

                //  showAdReward(position,model, gameOverRewardedAd3);
            }

            @Override
            public void onNegative(BottomSheetFragment bottomSheetDialog) {
                bottomSheetDialog.dismiss();
            }
        });
        bottomSheetFragment.show(getActivity().getSupportFragmentManager(), "dialog");*/
    }

    public override fun onPause() {
        super.onPause()
        if (!isAdShow) {
            dismiss()
        }
    }



    public override fun onCancel(dialog: DialogInterface) {
        super.onCancel(dialog)
    }

    public override fun onDismiss(dialog: DialogInterface) {
        super.onDismiss(dialog)
        if (onItemSelected != null) onItemSelected!!.onDismiss()
        if (path != null && onItemSelected != null) {
            onItemSelected!!.onItemSelected(path)
        }
    }

    open interface OnItemSelected {
        fun onItemSelected(path: String?)
        fun onDismiss()
    }

    private fun dpToPx(dp: Int): Int {
        val r: Resources = resources
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), r.displayMetrics))
    }

    @Throws(InvocationTargetException::class, NoSuchMethodException::class, ApiNotSupportedException::class, NoSuchFieldException::class, IllegalAccessException::class, NullWifiConfigurationException::class)
    private fun checkStatus() {
        if (!NetworkHelper.isOnline(mAContext)) {
            tabLayoutScreen!!.visibility = View.GONE
            recyclerSnap!!.visibility = View.GONE
            //viewPagerScreen.setVisibility(View.GONE);
            progressBar!!.visibility = View.GONE
            Toast.makeText(mAContext, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show()
            dismiss()
        } else {
            if (NetworkHelper.isWifiConnected(mAContext)) {
                val proxy: WifiConfiguration = WifiConfiguration(mAContext)
                if (proxy.isProxySetted) {
                    tabLayoutScreen!!.visibility = View.GONE
                    recyclerSnap!!.visibility = View.GONE
                    // viewPagerScreen.setVisibility(View.GONE);
                    progressBar!!.visibility = View.GONE
                    Toast.makeText(mAContext, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show()
                    dismiss()
                    return
                }
            }
            if (NetworkHelper.isVpnRunning()) {
                tabLayoutScreen!!.visibility = View.GONE
                recyclerSnap!!.visibility = View.GONE
                //  viewPagerScreen.setVisibility(View.GONE);
                progressBar!!.visibility = View.GONE
                Toast.makeText(mAContext, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show()
                dismiss()
                return
            }
            callNewApi()
        }
    }

    fun callNewApi() {
        apiInterface = client!!.create(APIInterface::class.java)
        val call: Call<com.hd.wallpaper.solid.color.background.newModel.Response?>? = apiInterface!!.doGetNewListResources()
        call!!.enqueue(object : Callback<com.hd.wallpaper.solid.color.background.newModel.Response?> {

            override fun onResponse(call: Call<com.hd.wallpaper.solid.color.background.newModel.Response?>, response: retrofit2.Response<com.hd.wallpaper.solid.color.background.newModel.Response?>) {
                val model: com.hd.wallpaper.solid.color.background.newModel.Response? = response.body()
                mDataListNew!!.clear()

                if (model?.data != null) {
                    mDataListNew!!.addAll(model.data)
                    updateNewUI()
                } else {
                    Toast.makeText(mAContext, getResources().getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
                    dismiss()
                }
            }

            override fun onFailure(call: Call<com.hd.wallpaper.solid.color.background.newModel.Response?>, t: Throwable) {
                Toast.makeText(mAContext, getResources().getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
                dismiss()
            }
        })
    }

//    fun callApi() {
//        apiInterface = client!!.create(APIInterface::class.java)
//        val call: Call<Response?>? = apiInterface!!.doGetListResources()
//        call!!.enqueue(object : Callback<Response?> {
//            public override fun onResponse(call: Call<Response?>, response: retrofit2.Response<Response?>) {
//                val model: Response? = response.body()
//                mDataList!!.clear()
//                if (model?.data != null) {
//                    mDataList!!.addAll(model.data)
//                    updateUI()
//                } else {
//                    Toast.makeText(mAContext, getResources().getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
//                    dismiss()
//                }
//            }
//
//            public override fun onFailure(call: Call<Response?>, t: Throwable) {
//                Toast.makeText(mAContext, getResources().getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
//                dismiss()
//            }
//        })
//    }

    private fun updateNewUI() {
        mAllReadyData = ArrayList()
        if (mDataListNew!!.size == 0) {
            dismiss()
            return
        }

        categoryNameList = ArrayList()


        for (i in mDataListNew!!.indices) {
            val mForegroundList: ArrayList<ImagesItem?> = ArrayList()

            if (mDataListNew!![i].name!! == "Screen") {
                mForegroundList!!.addAll((mDataListNew!![i].allChilds?.get(i)!!.images)!!)


                for (j in mDataListNew!![i].allChilds!!.indices){
                    categoryNameList!!.add(mDataListNew!![i].allChilds?.get(j)!!.name!!)


                }
                mForegroundList!!.addAll((mDataListNew!![i].allChilds?.get(i)!!.images)!!)

                categoryNameList!!.add(mDataListNew!![i].allChilds?.get(i)!!.name!!)

                val mWallpaperList: ArrayList<WallpaperWeekModelNewResponse?> = ArrayList()
                for (j in mForegroundList.indices) {
                    mWallpaperList.add(WallpaperWeekModelNewResponse(mForegroundList[j], mForegroundList[j]!!.isPremium != 0, mForegroundList[j]!!.coins!!))
                }


                mTempForgroundList = ArrayList()

                if (mAContext != null && getBoolean(mAContext, AdsPrefs.IS_SUBSCRIBED, false)) {
                    for (j in mWallpaperList.indices) {
                        mWallpaperList[j]!!.isLocked = false
                    }
                    mTempForgroundList!!.addAll(mWallpaperList)
                } else {
                    for (k in mWallpaperList.indices) {
                        val model: WallpaperWeekModelNewResponse? = mWallpaperList[k]
                        if (dbHelper!!.checkPathExist((model!!.imageItem!!.image)!!)) {
                            model.isLocked = false
                        }
                        mTempForgroundList!!.add(model)
                    }
                }
                mTempForgroundList!!.shuffle()
                mAllReadyData!!.add(mTempForgroundList!!)

            }

        }
        setData()

    }
//    private fun updateUI() {
//        mAllReadyData = ArrayList()
//        if (mDataList!!.size == 0) {
//            dismiss()
//            return
//        }
//        if (mDataList!!.size > 3) {
//        } else {
//            dismiss()
//            return
//        }
//        categoryNameList = ArrayList()
//        for (i in mDataList!!.indices) {
//            val mForegroundList: ArrayList<ImagesItem> = ArrayList()
//            mForegroundList.addAll((mDataList!![i].image)!!)
//            if (mDataList!![i].name!!.contains("_Screen")) {
//                val name: Array<String> = mDataList!![i].name!!.split("_".toRegex()).toTypedArray()
//                if (name.isEmpty()) {
//                    categoryNameList!!.add(mDataList!![i].name)
//                } else {
//                    categoryNameList!!.add(name[name.size - 1])
//                }
//                val mWallpaperList: ArrayList<WallpaperWeekModelNewResponse> = ArrayList()
//                for (j in mForegroundList.indices) {
//                    mWallpaperList.add(WallpaperWeekModelNewResponse(mForegroundList[j], mForegroundList[j].isPremium != 0, mForegroundList[j].coins!!))
//                }
//
//                /*  if (mDataList.get(i).getName().contains("Popular") || mDataList.get(i).getName().contains("Special")) {
//                    mTempForgroundList = new ArrayList<>();
//
//                    if (AdsPrefs.getBoolean(mAContext, AdsPrefs.IS_SUBSCRIBED, false)) {
//                        mTempForgroundList.addAll(mWallpaperList);
//                    } else {
//                        for (WallpaperWeekModel model :
//                                mWallpaperList) {
//                            model.setFree(false);
//                            model.setPremium(true);
//                            mTempForgroundList.add(model);
//                        }
//                    }
//                } else {*/mTempForgroundList = ArrayList()
//                if (mAContext != null && getBoolean(mAContext, AdsPrefs.IS_SUBSCRIBED, false)) {
//                    mTempForgroundList!!.addAll(mWallpaperList)
//                } else {
//                    dbHelperSuscription!!.deleteAllData()
//
//                    /*  if (mySharedPref.getAdsRemoved()) {
//                Log.d("456as", "updateUI: pur");
//
//                if (mWallpaperList.size() >= 6) {
//                    for (int i = 0; i < 6; i++) {
//                        mTempForgroundList.add(mWallpaperList.get(i));
//                    }
//                   */
//                    /* for (int i = 0; i < 6; i++) {
//                        mWallpaperList.remove(i);
//                    }*/
//                    /*
//                } else {
//                    mTempForgroundList.addAll(mWallpaperList);
//                    mWallpaperList.clear();
//                }
//
//                boolean flag = true;
//                int conter = 0;
//                int counterPrem = 0;
//                for (int i = 6; i < mWallpaperList.size(); i++) {
//                    WallpaperWeekModel model = mWallpaperList.get(i);
//
//                    if (flag) {
//                        model.setLocked(false);
//                        model.setFree(true);
//                        mTempForgroundList.add(model);
//                        conter++;
//                        if (conter > 5) {
//                            flag = false;
//                            conter = 0;
//                        }
//                    } else {
//                        model.setPremium(true);
//                        model.setFree(false);
//                        mTempForgroundList.add(model);
//                        counterPrem++;
//                        if (counterPrem > 2) {
//                            flag = true;
//                            counterPrem = 0;
//                        }
//                    }
//                }
//
//            } else {*/
///*
//                    if (mWallpaperList.size() >= 6) {
//                        for (int l = 0; l < 6; l++) {
//                            mTempForgroundList.add(mWallpaperList.get(l));
//                        }
//
//                    */
//                    /*for (int i = 0; i < 6; i++) {
//                        mWallpaperList.remove(i);
//                    }*/
//                    /*
//                    } else {
//                        mTempForgroundList.addAll(mWallpaperList);
//                        mWallpaperList.clear();
//                    }
//
//                    boolean flag = true;
//                    int conter = 0;
//                    int counterPrem = 0;*/for (k in mWallpaperList.indices) {
//                        val model: WallpaperWeekModelNewResponse = mWallpaperList[k]
//                        if (dbHelper!!.checkPathExist((model.imageItem!!.image)!!)) {
//                            model.isLocked = false
//                        }
//                        mTempForgroundList!!.add(model)
//                        //  }
//                    }
//                }
//                //   }
//                mAllReadyData!!.add(mTempForgroundList!!)
//            }
//        }
//        setData()
//    }
}