package com.hd.wallpaper.solid.color.background.newModel

data class ScreenModelClass(var mName:String?,var mScreenList:ImagesItem?)