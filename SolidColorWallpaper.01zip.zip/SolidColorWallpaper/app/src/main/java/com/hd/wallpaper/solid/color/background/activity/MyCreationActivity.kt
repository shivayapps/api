package com.hd.wallpaper.solid.color.background.activity

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.viewpager.widget.ViewPager
import androidx.viewpager.widget.ViewPager.OnPageChangeListener
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd

import com.hd.wallpaper.solid.color.background.BuildConfig
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.SolidWallpaperApplication
import com.hd.wallpaper.solid.color.background.SolidWallpaperApplication.Companion.instance
import com.hd.wallpaper.solid.color.background.activity.MyCreationActivity

import com.hd.wallpaper.solid.color.background.constants.Constants
import com.hd.wallpaper.solid.color.background.fragment.GradientSavedFragment
import com.hd.wallpaper.solid.color.background.fragment.SolidSavedFragment
import com.hd.wallpaper.solid.color.background.fragment.TextSavedFragment
import com.hd.wallpaper.solid.color.background.model.SavedImageModel
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs.getBoolean
import com.hd.wallpaper.solid.color.background.shared_pref.MySharedPref
import java.io.File
import java.util.*

class MyCreationActivity : AppCompatActivity(), View.OnClickListener {
    private var viewpager: ViewPager? = null
    private var imgBack: ImageView? = null
    private var imgShare: ImageView? = null
    private val img_birthday_ad: ImageView? = null
    private var btnSolid: TextView? = null
    private var btnGradient: TextView? = null
    private var btnText: TextView? = null
    private var solidSavedFragment: SolidSavedFragment? = null
    private var gradientSavedFragment: GradientSavedFragment? = null
    private var textSavedFragment: TextSavedFragment? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_creation)
        System.gc()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted
            startActivity(Intent(this@MyCreationActivity, MainStartActivity::class.java))
            finish()
        } else {
            initViews()
            initViewAction()
            initListner()
        }
    }

    private fun initListner() {
        imgBack!!.setOnClickListener(this)
        imgShare!!.setOnClickListener(this)
        btnGradient!!.setOnClickListener(this)
        btnSolid!!.setOnClickListener(this)
        btnText!!.setOnClickListener(this)
        // img_birthday_ad.setOnClickListener(this);
    }

    private fun initViewAction() {
        if (getBoolean(this, AdsPrefs.IS_SUBSCRIBED, false)) {
            // img_birthday_ad.setVisibility(View.GONE);
        } else {
            isShowInterstitialAd{

            }
        }
        textSavedFragment = TextSavedFragment("TEXT")
        gradientSavedFragment = GradientSavedFragment("GRADIENT")
        solidSavedFragment = SolidSavedFragment("SOLID")
        viewpager!!.adapter = ViewPagerAdapter(supportFragmentManager)
        viewpager!!.currentItem = Constants.viewPagerPage
        viewpager!!.addOnPageChangeListener(object : OnPageChangeListener {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {}
            override fun onPageSelected(position: Int) {
                Constants.viewPagerPage = position
                if (position == 0) {
                    btnSolid!!.setTextColor(resources.getColor(R.color.text_colour_new))
                    btnGradient!!.setTextColor(resources.getColor(R.color.unselected_button))
                    btnText!!.setTextColor(resources.getColor(R.color.unselected_button))
                } else if (position == 1) {
                    btnGradient!!.setTextColor(resources.getColor(R.color.text_colour_new))
                    btnSolid!!.setTextColor(resources.getColor(R.color.unselected_button))
                    btnText!!.setTextColor(resources.getColor(R.color.unselected_button))
                } else {
                    btnGradient!!.setTextColor(resources.getColor(R.color.unselected_button))
                    btnSolid!!.setTextColor(resources.getColor(R.color.unselected_button))
                    btnText!!.setTextColor(resources.getColor(R.color.text_colour_new))
                }
            }

            override fun onPageScrollStateChanged(state: Int) {}
        })
        viewpager!!.offscreenPageLimit = 2

    }

    inner class ViewPagerAdapter(fm: FragmentManager?) : FragmentPagerAdapter(fm!!) {
        override fun getItem(position: Int): Fragment {
            return return when (position) {
                0 -> solidSavedFragment!!
                1 -> gradientSavedFragment!!
        //                2 -> return textSavedFragment!!
                else -> textSavedFragment!!
            }
//            return null
        }

        override fun getCount(): Int {
            return 3
        }
    }

    private fun initViews() {
        viewpager = findViewById(R.id.viewpager)
        imgShare = findViewById(R.id.imgShare)
        imgBack = findViewById(R.id.imgBack)
        btnSolid = findViewById(R.id.btnSolid)
        btnGradient = findViewById(R.id.btnGradient)
        btnText = findViewById(R.id.btnText)
        //img_birthday_ad = findViewById(R.id.img_birthday_ad);
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
//        if (requestCode == 100 && !getBoolean(this, AdsPrefs.IS_SUBSCRIBED, false)) {
//            if (instance!!.requestNewInterstitial()) {
//                instance!!.mInterstitialAd!!.adListener = object : AdListener() {
//                    override fun onAdClosed() {
//                        super.onAdClosed()
//                        loadInterstialAd()
//                    }
//
//                    override fun onAdFailedToLoad(i: Int) {
//                        super.onAdFailedToLoad(i)
//                        loadInterstialAd()
//                    }
//
//                    override fun onAdLoaded() {
//                        super.onAdLoaded()
//                    }
//                }
//            }
//        }
        if (requestCode == 1212) {
            if (MySharedPref(this).getAdsCreationClicked()) {
//                findViewById<View>(R.id.native_ad_container).visibility = View.VISIBLE
//                findViewById<View>(R.id.img_birthday_ad).visibility = View.GONE
            }
        }

    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.imgBack -> onBackPressed()
            R.id.imgShare -> shareApp()
            R.id.btnSolid -> onclickSolid()
            R.id.btnGradient -> onclickGradient()
            R.id.btnText -> onclickText()
        }
    }



    private fun shareApp() {
        if (viewpager!!.currentItem == 0) {
            if (solidSavedFragment != null && solidSavedFragment!!.updatedData != null && solidSavedFragment!!.updatedData!!.size > 0) {
                shareImage(solidSavedFragment!!.updatedData)
            } else {
                shareOwnApp()
            }
        } else if (viewpager!!.currentItem == 1) {
            if (gradientSavedFragment != null && gradientSavedFragment!!.updatedData != null && gradientSavedFragment!!.updatedData!!.size > 0) {
                shareImage(gradientSavedFragment!!.updatedData)
            } else {
                shareOwnApp()
            }
        } else if (viewpager!!.currentItem == 2) {
            if (textSavedFragment != null && textSavedFragment!!.updatedData != null && textSavedFragment!!.updatedData!!.size > 0) {
                shareImage(textSavedFragment!!.updatedData)
            } else {
                shareOwnApp()
            }
        }
    }

    private fun shareImage(updatedData: ArrayList<SavedImageModel>?) {
        val mSharedUri = ArrayList<Uri>()
        for (i in updatedData!!.indices) {
            if (updatedData[i].isDeletedEnable) {
                val uri = FileProvider.getUriForFile(this@MyCreationActivity, BuildConfig.APPLICATION_ID.toString() + ".provider", File(updatedData[i].path))
                mSharedUri.add(uri)
            }
        }
        val intent = Intent(Intent.ACTION_SEND_MULTIPLE)
        intent.type = "image/jpeg"
        intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, mSharedUri)
        var shareMessage = ""
        shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=com.solid.color.wallpaper.hd.image.background"
        intent.putExtra(Intent.EXTRA_TEXT, shareMessage)
        startActivityForResult(Intent.createChooser(intent, resources.getString(R.string.share_wallpaper)), 100)
    }

    private fun shareOwnApp() {
        val shareIntent = Intent(Intent.ACTION_SEND)
        shareIntent.type = "text/plain"
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Solid Color Wallpaper")
        var shareMessage = ""
        shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=com.solid.color.wallpaper.hd.image.background"
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
        startActivity(Intent.createChooser(shareIntent, resources.getString(R.string.choose_one)))
    }

    private fun onclickText() {
        btnText!!.setTextColor(Color.BLACK)
        btnGradient!!.setTextColor(resources.getColor(R.color.unselected_button))
        btnSolid!!.setTextColor(resources.getColor(R.color.unselected_button))
        viewpager!!.currentItem = 2
    }

    private fun onclickSolid() {
        btnSolid!!.setTextColor(Color.BLACK)
        btnGradient!!.setTextColor(resources.getColor(R.color.unselected_button))
        btnText!!.setTextColor(resources.getColor(R.color.unselected_button))
        viewpager!!.currentItem = 0
    }

    private fun onclickGradient() {
        btnGradient!!.setTextColor(Color.BLACK)
        btnSolid!!.setTextColor(resources.getColor(R.color.unselected_button))
        btnText!!.setTextColor(resources.getColor(R.color.unselected_button))
        viewpager!!.currentItem = 1
    }

    override fun onBackPressed() {
        if (viewpager!!.currentItem == 1 && gradientSavedFragment!!.allowBackPressed()) {
            super.onBackPressed()
        } else if (viewpager!!.currentItem == 0 && solidSavedFragment!!.allowBackPressed()) {
            super.onBackPressed()
        } else if (viewpager!!.currentItem == 2 && textSavedFragment!!.allowBackPressed()) {
            super.onBackPressed()
        }
    }

    override fun onResume() {
        super.onResume()
        SolidWallpaperApplication.staticLanguage.Factory.create(this)
    }
}