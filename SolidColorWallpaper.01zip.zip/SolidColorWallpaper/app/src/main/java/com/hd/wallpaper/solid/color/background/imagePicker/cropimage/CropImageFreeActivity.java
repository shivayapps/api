package com.hd.wallpaper.solid.color.background.imagePicker.cropimage;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Toast;

import com.hd.wallpaper.solid.color.background.R;
import com.hd.wallpaper.solid.color.background.imagePicker.model.Constant;
import com.hd.wallpaper.solid.color.background.imagePicker.model.Image;
import com.hd.wallpaper.solid.color.background.imagePicker.ui.imagepicker.ImageFileLoader;
import com.hd.wallpaper.solid.color.background.imagePicker.ui.imagepicker.ImagePickerPresenter;
import com.hd.wallpaper.solid.color.background.imagePicker.ui.imagepicker.ImagePickerView;
import com.hd.wallpaper.solid.color.background.imagePicker.widget.HoverView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class CropImageFreeActivity extends AppCompatActivity {

    private static final String TAG = "CropImageFreeActivity";
    private RelativeLayout mLayout;
    private ImageView cropedImage, mainImage;
    int actionBarHeight;
    int bottombarHeight;
    double bmRatio;
    double viewRatio;
    HoverView mHoverView;
    double mDensity;
    private Bitmap mBitmap;
    int viewWidth;
    int viewHeight;
    int bmWidth;
    int bmHeight;
    private Bitmap bmp;
    private SeekBar seekbarSize, seekbarOffset;
    private ConstraintLayout menuRestoreOffset;
    private ImageView btnPreview;
    private CheckBox checkboxOuter;
    private ImagePickerPresenter presenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_image_free);

        initViews();
        initViewAction();

    }

    private void initViewAction() {

        Window window = getWindow();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.setStatusBarColor(Color.parseColor("#222222"));
        }

        presenter = new ImagePickerPresenter(new ImageFileLoader(this));
        presenter.attachView((ImagePickerView) Constant.activity);

        try {
            mBitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), Uri.fromFile(new File( Constant.selectedImagePathFree)));
        } catch (IOException e) {
            e.printStackTrace();
        }

        bmp = mBitmap;
        if (mBitmap != null) {
            performAction(mBitmap);
            // mainImage.setImageBitmap(mBitmap);
        }else {
            Toast.makeText(this, "Invalid Image.", Toast.LENGTH_SHORT).show();
            finish();
        }
        seekbarSize.setProgress(40);
        seekbarSize.setMax(100);
        seekbarSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                mHoverView.setBrushSize(seekBar.getProgress());
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        seekbarOffset.setProgress(50);
        seekbarOffset.setMax(100);

        seekbarOffset.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                mHoverView.setEraseOffset(seekBar.getProgress());
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


        btnPreview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (HoverView.currentIndex > 0) {
                    FullscreenDialog dialog = new FullscreenDialog(getCropedBitmap(), CropImageFreeActivity.this);
                    dialog.show(getSupportFragmentManager(), "Dialog");
                } else {
                    Toast.makeText(CropImageFreeActivity.this, "Select Area.", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private void initViews() {
        mLayout = findViewById(R.id.mainLayout);
        cropedImage = findViewById(R.id.cropedImage);
        seekbarSize = findViewById(R.id.seekbarSize);
        seekbarOffset = findViewById(R.id.seekbarOffset);
        menuRestoreOffset = findViewById(R.id.menuRestoreOffset);
        btnPreview = findViewById(R.id.btnPreview);
        checkboxOuter = findViewById(R.id.checkboxOuter);
        // mainImage = findViewById(R.id.mainImage);
    }


    public void performAction(Bitmap bitmap) {
        mDensity = getResources().getDisplayMetrics().density;

        actionBarHeight = (int) (110 * mDensity);
        bottombarHeight = (int) (80 * mDensity);

        Log.d(TAG, "performAction: bar:" + actionBarHeight + "  " + bottombarHeight);

        viewWidth = getResources().getDisplayMetrics().widthPixels;
        viewHeight = getResources().getDisplayMetrics().heightPixels - actionBarHeight - bottombarHeight;
        viewRatio = (double) viewHeight / (double) viewWidth;

        bmRatio = (double) bitmap.getHeight() / (double) bitmap.getWidth();
        if (bmRatio < viewRatio) {
            bmWidth = viewWidth;
            bmHeight = (int) (((double) viewWidth) * ((double) (bitmap.getHeight()) / (double) (bitmap.getWidth())));
        } else {
            bmHeight = viewHeight;
            bmWidth = (int) (((double) viewHeight) * ((double) (bitmap.getWidth()) / (double) (bitmap.getHeight())));
        }

        bitmap = Bitmap.createScaledBitmap(bmp, bmWidth, bmHeight, false);

        mBitmap = bitmap;

        mHoverView = new HoverView(this, bitmap, bmWidth, bmHeight, viewWidth, viewHeight);
        mHoverView.setLayoutParams(new ViewGroup.LayoutParams(viewWidth, viewHeight));

        final Bitmap finalBitmap = bitmap;
        mLayout.post(new Runnable() {
            @Override
            public void run() {


                Log.d(TAG, "performAction: main Layout" + mLayout.getWidth() + "=" + mLayout.getHeight());

                mLayout.addView(mHoverView, 0);

            }
        });
        HoverView.inProgress = true;
        mHoverView.switchMode(HoverView.UNERASE_MODE);

    }

    public void onclickDone(View view) {

        if (HoverView.currentIndex > 0) {
            Constant.cropedBitmapFree = getCropedBitmap();
            saveImage();
           // startActivity(new Intent(CropImageFreeActivity.this, ViewCropedImageActivity.class));
        } else {
            new AlertDialog.Builder(this)
                    .setTitle("Crop Image")
                    .setMessage("Select Area To Crop Image.")

                    .setPositiveButton("Select Area", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })

                    .setNegativeButton("Skip", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                            Constant.cropedBitmapFree = mBitmap;
                            saveImage();
                        }
                    })
                    .setIcon(android.R.drawable.ic_dialog_alert)
                    .show();
        }
    }

    private void saveImage() {
        if (Constant.cropedBitmapFree != null) {

            Bitmap finalBitmap = Constant.cropedBitmapFree;

            File myDir = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/.Crop Image");
            if (myDir.isDirectory())
            {
                String[] children = myDir.list();
                for (int i = 0; i < children.length; i++)
                {
                    new File(myDir, children[i]).delete();
                }
            }
            myDir.mkdirs();

                String fname = "Image_" + System.currentTimeMillis() / 1000 + ".jpg";
                File file = new File(myDir, fname);

                if (file.exists()) file.delete();
                try {

                    FileOutputStream out = new FileOutputStream(file);
                    finalBitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                    out.flush();
                    out.close();

                    Image image=Constant.selectedImage.get(0);
                    image.setPath(file.getAbsolutePath());
                    Constant.selectedImage.clear();
                    Constant.selectedImage.add(image);
                    Intent intent=new Intent();
                    intent.setData(Uri.fromFile(file));
                    setResult(11,intent);
                    finish();
                    presenter.onDoneSelectImages(Constant.selectedImage);

                } catch (Exception e) {
                    e.printStackTrace();

                }
        }
    }


    public Bitmap getCropedBitmap() {
        Bitmap mask = makeTransparent(HoverView.getClippedBitmap());
        Bitmap result = Bitmap.createBitmap(mask.getWidth(), mask.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas mCanvas = new Canvas(result);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        mCanvas.drawBitmap(mBitmap, 0, 0, null);
        mCanvas.drawBitmap(mask, 0, 0, paint);
        paint.setXfermode(null);
        return result;
    }


    public Bitmap makeTransparent(Bitmap bit) {
        int width = bit.getWidth();
        int height = bit.getHeight();
        Bitmap myBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        int[] allpixels = new int[myBitmap.getHeight() * myBitmap.getWidth()];
        bit.getPixels(allpixels, 0, myBitmap.getWidth(), 0, 0, myBitmap.getWidth(), myBitmap.getHeight());
        myBitmap.setPixels(allpixels, 0, width, 0, 0, width, height);

        for (int i = 0; i < myBitmap.getHeight() * myBitmap.getWidth(); i++) {
            if (checkboxOuter.isChecked()) {
                if (allpixels[i] == Color.WHITE)
                    allpixels[i] = Color.alpha(Color.TRANSPARENT);
            } else {
                if (allpixels[i] == Color.BLACK)
                    allpixels[i] = Color.alpha(Color.TRANSPARENT);
            }
        }

        myBitmap.setPixels(allpixels, 0, myBitmap.getWidth(), 0, 0, myBitmap.getWidth(), myBitmap.getHeight());
        return myBitmap;
    }

    public void onclickSize(View view) {
        menuRestoreOffset.setVisibility(View.VISIBLE);
        mHoverView.switchMode(HoverView.UNERASE_MODE);
    }

    public void onclickZoom(View view) {
        menuRestoreOffset.setVisibility(View.GONE);
        mHoverView.switchMode(HoverView.MOVING_MODE);
    }

    public void onclickBack(View view) {
        onBackPressed();
    }

    @Override
    public void onBackPressed() {
        Intent intent=new Intent();
        setResult(12,intent);
        finish();
    }

    public void onclickRedo(View view) {
        mHoverView.redo();
    }

    public void onclickUndo(View view) {
        mHoverView.undo();
    }

    public void onclickErase(View view) {
        mHoverView.switchMode(HoverView.ERASE_MODE);
        menuRestoreOffset.setVisibility(View.VISIBLE);
    }

    public void onclickReset(View view) {
        mLayout.removeAllViews();
        performAction(mBitmap);
    }
}
