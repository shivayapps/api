package com.hd.wallpaper.solid.color.background.fragment

import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.activity.HomeActivity
import com.hd.wallpaper.solid.color.background.activity.SetWallpaperActivity
import com.hd.wallpaper.solid.color.background.adapter.GradientColorAdapter
import com.hd.wallpaper.solid.color.background.constants.Constants
import com.hd.wallpaper.solid.color.background.custom.GridSpacingItemDecoration
import com.hd.wallpaper.solid.color.background.model.ColorModel
import java.util.*

class GradientWallpaperFragment : Fragment {
    // TODO: Rename and change types of parameters
    private var mParam1: String? = null
    private var mParam2: String? = null
    private var recyclerColor: RecyclerView? = null
    private var mGradientColors: ArrayList<ColorModel>? = null
    private var mImageList: ArrayList<String>? = null
    private var orientation: GradientDrawable.Orientation = GradientDrawable.Orientation.TOP_BOTTOM
    private var mCurrentOrientation: Int = 0
    private var onScrollChange: onScrollChangeF? = null
    private val orientations: Array<GradientDrawable.Orientation> = arrayOf(
            GradientDrawable.Orientation.TOP_BOTTOM,
            GradientDrawable.Orientation.TR_BL,
            GradientDrawable.Orientation.RIGHT_LEFT,
            GradientDrawable.Orientation.BR_TL,
            GradientDrawable.Orientation.BOTTOM_TOP,
            GradientDrawable.Orientation.BL_TR,
            GradientDrawable.Orientation.LEFT_RIGHT,
            GradientDrawable.Orientation.TL_BR
    )
    private var mListener: OnFragmentInteractionListener? = null

    constructor() {
        // Required empty public constructor
    }

    constructor(onchage: onScrollChangeF?) {
        // Required empty public constructor
        onScrollChange = onchage
    }

    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (arguments != null) {
            mParam1 = arguments!!.getString(ARG_PARAM1)
            mParam2 = arguments!!.getString(ARG_PARAM2)
        }
    }

    public override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                                     savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_gradient_wallpaper, container, false)
    }

    public override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        mImageList = ArrayList()
        mGradientColors = ArrayList()
        val allGColors: Array<String> = resources.getStringArray(R.array.gradient_colors)
        var i: Int = 0
        while (i < allGColors.size) {
            mCurrentOrientation = (mCurrentOrientation + 1) % orientations.size
            orientation = orientations[mCurrentOrientation]
            val model: ColorModel = ColorModel()
            model.color1 = Color.parseColor(allGColors.get(i))
            model.color2 = Color.parseColor(allGColors.get(i + 1))
            model.orientation = orientation
            model.imagePosition = -1
            if (i % 5 == 0) {
                model.circle = true
            } else {
                model.circle = false
            }
            mGradientColors!!.add(model)
            i += 2
        }
        Constants.mEmojiList.clear()


        /*   String[] files = new String[0];
        try {
            files = getActivity().getAssets().list("emoji");
        } catch (IOException e) {
            e.printStackTrace();
        }
        assert files != null;
        for (String name : files) {
            mImageList.add("file:///android_asset/emoji" + File.separator + name);
            Constants.mEmojiList.add("file:///android_asset/emoji" + File.separator + name);
        }

        Log.d("879456154578987", "onViewCreated: ");

        int k=1;
        for (int i = 0; i < allGColors.length; i+=2) {
            mCurrentOrientation = (mCurrentOrientation + 1) % orientations.length;
            orientation = orientations[mCurrentOrientation];
            ColorModel model=new ColorModel();
            model.setColor1(Color.parseColor(allGColors[i]));
            model.setColor2(Color.parseColor(allGColors[i+1]));
            if (k>12){
                k=1;
            }
            */
        /*int textColor = Color.rgb(255-Color.red(model.getColor1()),
                    255-Color.green(model.getColor1()),
                    255-Color.blue(model.getColor1()));*/
        /*
            Log.d("879456154578987", "onViewCreated: "+model.getColor1()+"  "+getContrastVersionForColor(model.getColor1()));
            model.setColorFilterColor(getContrastVersionForColor(model.getColor1()));

            model.setImagePosition(k);
            k++;
            model.setOrientation(orientation);
            if (i%5==0){
                model.setCircle(true);
            }else {
                model.setCircle(false);
            }
            mGradientColors.add(model);
        }

*/recyclerColor = view.findViewById(R.id.recyclerColor)
        recyclerColor!!.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            public override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                if (onScrollChange != null) {
                    onScrollChange!!.onScrollChangeinit(dx, dy)
                }
                super.onScrolled(recyclerView, dx, dy)
            }
        })
        val manager: GridLayoutManager = GridLayoutManager(activity, 3)
        recyclerColor!!.layoutManager = manager
        recyclerColor!!.addItemDecoration(GridSpacingItemDecoration(3, dpToPx(6), true))
        recyclerColor!!.itemAnimator = DefaultItemAnimator()
        setColors()
    }

    open interface onScrollChangeF {
        fun onScrollChangeinit(dx: Int, dy: Int)
    }

    private fun setColors() {
        val listener: GradientColorAdapter.setOnItemClickListener = object : GradientColorAdapter.setOnItemClickListener {
            public override fun OnItemClicked(color: ColorModel?, i: Int) {
                if (HomeActivity.prompt != null) {
                    HomeActivity.prompt!!.dismiss()
                }
                Constants.isGradient = true
                Constants.selectedGWallpaper = color
                Constants.gradientPosition = i
                Constants.mGradientColorWallpapers.clear()
                Constants.mGradientColorWallpapers.addAll((mGradientColors)!!)
                Log.d("78456", "OnItemClicked: " + color!!.imagePosition)
                startActivity(Intent(activity, SetWallpaperActivity::class.java))
            }
        }
        val colorAdepter: GradientColorAdapter = GradientColorAdapter(mGradientColors!!, mImageList!!, activity!!, listener)
        recyclerColor!!.adapter = colorAdepter
    }

    private fun dpToPx(dp: Int): Int {
        val r: Resources = resources
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), r.displayMetrics))
    }

    // TODO: Rename method, update argument and hook method into UI event
    fun onButtonPressed(uri: Uri?) {
        if (mListener != null) {
            mListener!!.onFragmentInteraction(uri)
        }
    }

    public override fun onAttach(context: Context) {
        super.onAttach(context)
    }

    public override fun onResume() {
        super.onResume()
    }

    public override fun onDetach() {
        super.onDetach()
        mListener = null
    }

    open interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        fun onFragmentInteraction(uri: Uri?)
    }

    companion object {
        // TODO: Rename parameter arguments, choose names that match
        // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
        private val ARG_PARAM1: String = "param1"
        private val ARG_PARAM2: String = "param2"

        /* public static int getContrastColor(int color) {
        double y = (299 * Color.red(color) + 587 * Color.green(color) + 114 * Color.blue(color)) / 1000;
        return y >= 128 ? Color.BLACK : Color.WHITE;
    }*/
        fun getContrastVersionForColor(color: Int): Int {
            val hsv: FloatArray = FloatArray(3)
            Color.RGBToHSV(Color.red(color), Color.green(color), Color.blue(color),
                    hsv)
            if (hsv.get(2) < 0.5) {
                hsv[2] = 0.7f
            } else {
                hsv[2] = 0.3f
            }
            hsv[1] = hsv.get(1) * 0.2f
            return Color.HSVToColor(hsv)
        }
    }
}