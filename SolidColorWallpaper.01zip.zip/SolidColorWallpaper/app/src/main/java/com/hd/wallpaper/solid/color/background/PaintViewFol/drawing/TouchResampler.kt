package com.hd.wallpaper.solid.color.background.PaintViewFol.drawing

import android.os.Build.VERSION
import android.util.Log
import android.view.MotionEvent

/**
 * Created by marco.granatiero on 08/08/2014.
 */
abstract class TouchResampler {
    protected open fun addToPath(x: Float, y: Float, t: Long, isMove: Boolean) {
        onTouchMove(x, y, t.toFloat())
    }

    protected fun endPath() {
        onTouchUp()
    }

    fun feedXYT(xyt: FloatArray) {
        startPath(xyt[0], xyt[1], xyt[2].toLong())
        var i = 3
        while (i < xyt.size) {
            addToPath(xyt[i], xyt[i + 1], xyt[i + 2].toLong(), true)
            i += 3
        }
        i -= 3
        addToPath(xyt[i], xyt[i + 1], xyt[i + 2].toLong(), false)
        endPath()
    }

    open fun getXYVAtDistance(distance: Float, xyv: FloatArray?): Boolean {
        return false
    }

    protected abstract fun onTouchDown(f: Float, f2: Float)
    fun onTouchEvent(event: MotionEvent) {
        val x = event.x
        val y = event.y
        val t = event.eventTime - event.downTime
        when (if (VERSION.SDK_INT >= 8) event.actionMasked else event.action and 255) {
            MotionEvent.ACTION_DOWN -> {
                Log.d("TouchResampler", "ACTION_DOWN")
                startPath(x, y, t)
            }
            MotionEvent.ACTION_UP -> {
                Log.d("TouchResampler", "ACTION_UP")
                addToPath(x, y, t, false)
                endPath()
            }
            MotionEvent.ACTION_MOVE -> {
                Log.d("TouchResampler", "ACTION_MOVE")
                var i = 0
                while (i < event.historySize) {
                    addToPath(event.getHistoricalX(i), event.getHistoricalY(i), event.getHistoricalEventTime(i) - event.downTime, true)
                    i++
                }
                addToPath(x, y, t, true)
            }
            else -> {
            }
        }
    }

    protected abstract fun onTouchMove(f: Float, f2: Float, f3: Float)
    protected abstract fun onTouchUp()
    protected open fun startPath(x: Float, y: Float, t: Long) {
        onTouchDown(x, y)
    }

    companion object {
        private const val TAG = "LineBrush"
    }
}