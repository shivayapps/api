package com.hd.wallpaper.solid.color.background.adapter

import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.constants.Constants
import com.hd.wallpaper.solid.color.background.model.ColorModel
import java.util.*

class ViewGradientWallpaperPagerAdapter(private val context: Context, private val mColors: ArrayList<ColorModel>) : PagerAdapter() {
    override fun getCount(): Int {
        return mColors.size
    }

    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return view === `object`
    }

    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        val inflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val view = inflater.inflate(R.layout.rv_view_wallpaper_pager, null)
        val emoji_image = view.findViewById<ImageView>(R.id.mainEmojiImg)
        val mainImage = view.findViewById<ImageView>(R.id.mainImg)
        val model = mColors[position]
        val color = intArrayOf(model.color1, model.color2)
        if (model.circle) {
            val shape = GradientDrawable()
            shape.setColors(color)
            shape.gradientType = GradientDrawable.RADIAL_GRADIENT
            shape.gradientRadius = 600f
            mainImage.setImageDrawable(shape)
        } else {
            val drawable = GradientDrawable(model.orientation, color)
            mainImage.setImageDrawable(drawable)
        }
        if (model.imagePosition != -1) {
            Glide.with(context).asBitmap().load(Constants.mEmojiList[model.imagePosition]).into(object : CustomTarget<Bitmap?>() {
                override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap?>?) {
                    emoji_image.setImageBitmap(resource)
                }

                override fun onLoadCleared(placeholder: Drawable?) {}
            })
        }
        val viewPager = container as ViewPager
        view.tag = "myview$position"
        viewPager.addView(view, 0)
        return view
    }

    override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
        val viewPager = container as ViewPager
        val view = `object` as View
        viewPager.removeView(view)
    }

}