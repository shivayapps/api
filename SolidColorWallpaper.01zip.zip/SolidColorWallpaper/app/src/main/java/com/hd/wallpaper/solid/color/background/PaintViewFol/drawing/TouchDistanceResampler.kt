package com.hd.wallpaper.solid.color.background.PaintViewFol.drawing

import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.PointF
import kotlin.math.sqrt

/**
 * Created by marco.granatiero on 08/08/2014.
 */
abstract class TouchDistanceResampler : TouchResampler() {
    private var mDistance0 = 0f
    private var mDistance1 = 0f
    private var mDistance2 = 0f
    private var mDistance3 = 0f
    private var mLastPathTime = 0f
    private val mPath: Path
    private val mPathBezier1: PointF
    private val mPathMeasure: PathMeasure
    private val mTempPos: FloatArray
    private var mTime0 = 0f
    private var mTime1 = 0f
    private var mTime2 = 0f
    private var mTime3 = 0f

    override fun addToPath(x: Float, y: Float, t: Long, isMove: Boolean) {
        mPath.quadTo(mPathBezier1.x, mPathBezier1.y, (mPathBezier1.x + x) / 2.0f, (mPathBezier1.y + y) / 2.0f)
        mPathBezier1[x] = y
        mPathMeasure.setPath(mPath, false)
        val totalDistance = mPathMeasure.length
        val totalTime = (mLastPathTime + t.toFloat()) / 2.0f
        if (isMove) {
            if (mDistance2 == 0.0f) {
                mDistance0 = 0.0f
                mDistance1 = totalDistance / 4.0f
                mDistance2 = totalDistance / 2.0f
                mTime0 = 0.0f
                mTime1 = totalTime / 4.0f
                mTime2 = totalTime / 2.0f
            } else {
                mDistance0 = mDistance2
                mDistance1 = mDistance3
                mDistance2 = (mDistance1 + totalDistance) / 2.0f
                mTime0 = mTime2
                mTime1 = mTime3
                mTime2 = (mTime1 + totalTime) / 2.0f
            }
            mDistance3 = totalDistance
            mTime3 = totalTime
            super.addToPath(x, y, t, isMove)
        } else {
            mDistance0 = mDistance2
            mDistance1 = mDistance3
            mDistance2 = totalDistance
            mTime0 = mTime2
            mTime1 = mTime3
            mTime2 = mLastPathTime
            super.addToPath(x, y, mLastPathTime.toLong(), isMove)
        }
        mLastPathTime = t.toFloat()
    }

    override fun getXYVAtDistance(distance: Float, xyv: FloatArray?): Boolean {

        if (mDistance2 == 0.0f || distance > mDistance2) {
            return false
        }
        mPathMeasure.getPosTan(distance, mTempPos, null)
        xyv!![0] = mTempPos[0]
        xyv!![1] = mTempPos[1]
        xyv!![2] = calcInstantVelocity(mDistance0, mDistance1, mDistance2, mTime0, mTime1, mTime2, calcRootOfQuadraticBezier(mDistance0, mDistance1, mDistance2, distance))
        return true
    }

    override fun startPath(x: Float, y: Float, t: Long) {
        mPath.reset()
        mPath.moveTo(x, y)
        mPathBezier1[x] = y
        mDistance0 = 0.0f
        mDistance1 = 0.0f
        mDistance2 = 0.0f
        mDistance3 = 0.0f
        mTime0 = 0.0f
        mTime1 = 0.0f
        mTime2 = 0.0f
        mTime3 = 0.0f
        mLastPathTime = 0.0f
        super.startPath(x, y, t)
    }

    companion object {
        private fun calcInstantVelocity(da: Float, db: Float, dc: Float, ta: Float, tb: Float, tc: Float, s: Float): Float {
            return ((da - 2.0f * db + dc) * s - (da - db)) / ((ta - 2.0f * tb + tc) * s - (ta - tb))
        }

        private fun calcRootOfQuadraticBezier(a: Float, b: Float, c: Float, distance: Float): Float {
            val A = a - 2.0f * b + c
            val B = a - b
            val C = a - distance
            return if (A == 0.0f) -C / B else (B + sqrt(B * B - A * C)) / A
        }
    }

    init {
        mPathBezier1 = PointF()
        mTempPos = FloatArray(2)
        mPath = Path()
        mPathMeasure = PathMeasure()
    }
}