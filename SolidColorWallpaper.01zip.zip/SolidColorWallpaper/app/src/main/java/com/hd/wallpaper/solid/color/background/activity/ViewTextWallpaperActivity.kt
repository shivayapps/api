package com.hd.wallpaper.solid.color.background.activity

import android.Manifest
import android.app.ProgressDialog
import android.app.Service
import android.app.WallpaperManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.viewpager.widget.ViewPager
import androidx.viewpager.widget.ViewPager.OnPageChangeListener
import com.auto.wallpaper.live.background.changer.editor.receiver.EventReceiver
import com.auto.wallpaper.live.background.changer.editor.receiver.EventReceiver.Companion.cancelAlarm
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd

import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.snackbar.Snackbar

import com.hd.wallpaper.solid.color.background.BuildConfig
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.SolidWallpaperApplication
import com.hd.wallpaper.solid.color.background.SolidWallpaperApplication.Companion.instance
import com.hd.wallpaper.solid.color.background.activity.ViewTextWallpaperActivity
import com.hd.wallpaper.solid.color.background.adapter.ViewTextWallpaperPagerAdapter
import com.hd.wallpaper.solid.color.background.constants.Constants
import com.hd.wallpaper.solid.color.background.custom.BottomSheetFragment
import com.hd.wallpaper.solid.color.background.live_wallpaper.CustomNewWallpaper
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs.getBoolean
import com.hd.wallpaper.solid.color.background.shared_pref.MySharedPref
import com.hd.wallpaper.solid.color.background.sqlite_database.DBHelperAutoWallpaper
import com.willy.ratingbar.BaseRatingBar
import com.willy.ratingbar.BaseRatingBar.OnRatingChangeListener
import com.willy.ratingbar.ScaleRatingBar
import java.io.File
import java.io.FileFilter
import java.io.FileOutputStream
import java.io.IOException
import java.util.*

class ViewTextWallpaperActivity constructor() : AppCompatActivity(), View.OnClickListener {
    private var mainViewPage: ViewPager? = null
    private var position: Int = 0
    private var mImageList: ArrayList<String>? = null
    private var btnShare: ImageView? = null
    private var btnSave: ImageView? = null
    private var btnHome: ImageView? = null
    private var btnEdit: ImageView? = null
    private var btnSetWallpaper: TextView? = null
    private var enableToSave: Boolean = true
    private var isSetWallpaper: Boolean = false
    private var isShared: Boolean = false
    private var mPermissionGranted: Boolean = false
    private var imagePaths: ArrayList<String>? = null
    private var mBitmap: Bitmap? = null
    private var mySharedPref: MySharedPref? = null
    private var progressBar: ProgressDialog? = null
    private var wallpaperManager: WallpaperManager? = null
    private var vibrator: Vibrator? = null
    var widthD: Int = 0
    private var heightD: Int = 0

    var bottomSheetFragment:BottomSheetFragment?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_text_wallpaper)
        System.gc()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            startActivity(Intent(this@ViewTextWallpaperActivity, MainStartActivity::class.java))
            finish()
        } else {
            Constants.savedPath = null
            progressBar = ProgressDialog(this@ViewTextWallpaperActivity)
            progressBar!!.setMessage(resources.getString(R.string.dialog_msg_please_wait))
            progressBar!!.setCancelable(false)
            mySharedPref = MySharedPref(this)
            if ( /*!mySharedPref.getAdsRemoved() &&*/!getBoolean(this@ViewTextWallpaperActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
//                loadInterstialAd()
                isShowInterstitialAd{

                }
            }
            initViews()
            initListner()
            initViewAction()
        }
    }


    private fun initViewAction() {
        if (mySharedPref!!.vibration) {
            vibrator = getSystemService(Service.VIBRATOR_SERVICE) as Vibrator?
        }
        wallpaperManager = WallpaperManager.getInstance(applicationContext)
        position = intent.extras!!.get("position") as Int
        val metrics: DisplayMetrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(metrics)
        widthD = metrics.widthPixels
        heightD = metrics.heightPixels
        mImageList = ArrayList()
        var files: Array<String?>? = arrayOfNulls(0)
        try {
            files = assets.list("text_image")
        } catch (e: IOException) {
            e.printStackTrace()
        }
        assert(files != null)
        for (name: String? in files!!) {
            mImageList!!.add("file:///android_asset/text_image" + File.separator + name)
        }
        mainViewPage!!.addOnPageChangeListener(object : OnPageChangeListener {
            public override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {}
            public override fun onPageSelected(position1: Int) {
                position = position1
            }

            public override fun onPageScrollStateChanged(state: Int) {}
        })
        setDataToAdapter()
    }

    private fun setDataToAdapter() {
        if (mImageList!!.size > 0) {
            val adapter: ViewTextWallpaperPagerAdapter = ViewTextWallpaperPagerAdapter(this, (mImageList)!!)
            mainViewPage!!.adapter = adapter
            mainViewPage!!.currentItem = position
        }
    }

    private fun initViews() {
        mainViewPage = findViewById(R.id.mainViewPage)
        btnSave = findViewById(R.id.btnSave)
        btnSetWallpaper = findViewById(R.id.btnSetWallpaper)
        btnShare = findViewById(R.id.btnShare)
        btnHome = findViewById(R.id.btnHome)
        btnEdit = findViewById(R.id.btnEdit)
    }

    private fun initListner() {
        btnSave!!.setOnClickListener(this)
        btnShare!!.setOnClickListener(this)
        btnSetWallpaper!!.setOnClickListener(this)
        btnHome!!.setOnClickListener(this)
        btnEdit!!.setOnClickListener(this)
    }

    public override fun onClick(view: View) {
        when (view.getId()) {
            R.id.btnSave -> {
                isShared = false
                isSetWallpaper = false
                if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this@ViewTextWallpaperActivity, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), READ_PERMISSION)
                } else {
                    mPermissionGranted = true
                }
                if (mPermissionGranted) {
                    Constants.savedPath = null
                    enableToSave = true
                    photoes
                    var i: Int = 0
                    while (i < imagePaths!!.size) {
                        if ((((Constants.path + "/Text_" + mainViewPage!!.currentItem + ".jpg") == imagePaths!![i]))) {
                            enableToSave = false
                            break
                        }
                        i++
                    }
                    if (enableToSave) {
                        showSaveDialog()
                    } else {
                        showSnackBar(getResources().getString(R.string.wallpaper_already_exist))
                        //  Toast.makeText(this, "Wallpaper Already Exist.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
            R.id.btnSetWallpaper -> if (mySharedPref!!.scale.equals("fill", ignoreCase = true)) {
                showCustomDialog()
            } else {
                Constants.mWallpaperBitmap = outputBitmap
                try {

                    /*   WallpaperManager myWallpaperManager
                                = WallpaperManager.getInstance(getApplicationContext());
                        try {

                            myWallpaperManager.clear();
                        } catch (IOException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                        */
                    val intent: Intent = Intent()
                    if (Build.VERSION.SDK_INT > 16) {
                        intent.action = WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER
                        intent.putExtra(
                                WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                                ComponentName(this, CustomNewWallpaper::class.java))
                    } else {
                        intent.action = WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER
                    }
                    //   intent.putExtra("SET_LOCKSCREEN_WALLPAPER", true);
                    startActivityForResult(intent, 0)
                } catch (e: Exception) {
                    e.printStackTrace()
                    showSnackBar(getResources().getString(R.string.live_wallpaper_not_supported))
                }
            }
            R.id.btnShare -> {
                isShared = true
                isSetWallpaper = false
                shareWallpaper()
            }
            R.id.btnEdit ->{
                startActivity(Intent(this@ViewTextWallpaperActivity, AddTextActivity::class.java))
            }
            R.id.btnHome -> onBackPressed()
        }
    }

    private fun showSaveDialog() {
         bottomSheetFragment= BottomSheetFragment(getResources().getString(R.string.save), getResources().getString(R.string.do_you_want_to_save), getResources().getString(R.string.save), getResources().getString(R.string.cancel), R.drawable.ic_save_dialog, object : BottomSheetFragment.OnButtonClickListener {
            public override fun onPositive(bottomSheetDialo: BottomSheetFragment?) {
                bottomSheetDialo!!.dismiss()
                onclickSave()
            }

            public override fun onNegative(bottomSheetDialog: BottomSheetFragment?) {
                bottomSheetDialog!!.dismiss()
            }
        })
        bottomSheetFragment!!.show(supportFragmentManager, "dialog")
    }

    override fun onPause() {
        super.onPause()
        try {
            bottomSheetFragment!!.dismiss()
        }catch (e:Exception){

        }
    }

    private fun shareWallpaper() {
        if (Constants.savedPath == null) {
            if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this@ViewTextWallpaperActivity, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), SHARE_PERMISSION)
            } else {
                mPermissionGranted = true
            }
            if (mPermissionGranted) {
                onclickSave()
            }
        } else {
            val uri: Uri? = FileProvider.getUriForFile(this@ViewTextWallpaperActivity, BuildConfig.APPLICATION_ID.toString() + ".provider", File(Constants.savedPath))
            if (uri != null) {
                val intent: Intent = Intent(Intent.ACTION_SEND)
                intent.type = "image/jpeg"
                intent.putExtra(Intent.EXTRA_STREAM, uri)
                var shareMessage: String = ""
                shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=com.solid.color.wallpaper.hd.image.background"
                intent.putExtra(Intent.EXTRA_TEXT, shareMessage)
                startActivityForResult(Intent.createChooser(intent, getResources().getString(R.string.share_wallpaper)), 100)
            }
            Constants.savedPath = null
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
//        if (requestCode == 100 && !getBoolean(this@ViewTextWallpaperActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
//            if (instance!!.requestNewInterstitial()) {
//                instance!!.mInterstitialAd!!.adListener = object : AdListener() {
//                    public override fun onAdClosed() {
//                        super.onAdClosed()
//                        loadInterstialAd()
//                    }
//
//                    public override fun onAdFailedToLoad(i: Int) {
//                        super.onAdFailedToLoad(i)
//                        loadInterstialAd()
//                    }
//
//                    public override fun onAdLoaded() {
//                        super.onAdLoaded()
//                    }
//                }
//            }
//        }
    }

    private fun onclickSave() {
        mBitmap = outputBitmap
        if (mBitmap != null) {
            val myDir: File = File(Constants.path)
            myDir.mkdirs()
            val fname: String
            fname = "Text_" + mainViewPage!!.currentItem + ".jpg"
            val file: File = File(myDir, fname)
            var out: FileOutputStream? = null
            try {
                out = FileOutputStream(file)
                mBitmap!!.compress(Bitmap.CompressFormat.JPEG, 100, out)
                out.flush()
                out.close()
                Constants.savedPath = Constants.path + "/" + fname
                if (!isShared && !isSetWallpaper) {
                    showSnackBar(getResources().getString(R.string.wallpaper_saved))
                    // Toast.makeText(this, "Wallpaper Saved.", Toast.LENGTH_SHORT).show();
                } else if (isSetWallpaper) {
                    showCustomDialog()
                } else {
                    shareWallpaper()
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                val scanIntent: Intent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
                val contentUri: Uri = Uri.fromFile(file)
                scanIntent.setData(contentUri)
                sendBroadcast(scanIntent)
            } else {
                val intent: Intent = Intent(Intent.ACTION_MEDIA_MOUNTED, Uri.parse("file://" + Environment.getExternalStorageDirectory()))
                sendBroadcast(intent)
            }
        }
    }

    private fun showCustomDialog() {
        btnSetWallpaper!!.isEnabled = false
        val builder1: BottomSheetDialog = BottomSheetDialog(this@ViewTextWallpaperActivity, R.style.BottomSheetDialog)
        val v: View = layoutInflater.inflate(R.layout.dialog_setwallpaper, null)
        builder1.setContentView(v)
        builder1.show()
        builder1.setOnDismissListener { btnSetWallpaper!!.isEnabled = true }
        val wallpaper: LinearLayout = v.findViewById(R.id.btnHomeScreen)
        val bothwallpaper: LinearLayout = v.findViewById(R.id.btnBoth)
        val lockscreen: LinearLayout = v.findViewById(R.id.btnLockScreen)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            bothwallpaper.visibility = View.GONE
            lockscreen.visibility = View.GONE
        }
        lockscreen.setOnClickListener {
            mySharedPref!!.countExist = mySharedPref!!.countExist + 1
            builder1.dismiss()
            Log.d("VIEW_TEXT", "showCustomDialog: VIEW_TEXT"+mySharedPref!!.countExist)
            progressBar!!.show()
            Handler().postDelayed({
                Log.d("VIEW_TEXT", "showCustomDialog: VIEW_TEXT INNER"+mySharedPref!!.countExist)
                //  progressBar.dismiss();
                btnSetWallpaper!!.isEnabled = true
                if (mySharedPref!!.countExist >= 3 && mySharedPref!!.visitPlay == null) {
                   // showRateDialog()
                    mySharedPref!!.countExist=0
                }
            }, 3000)
            if (mySharedPref!!.alarmId != -1) {
                DBHelperAutoWallpaper(this@ViewTextWallpaperActivity).updateData()
                cancelAlarm(("2121" + mySharedPref!!.alarmId).toInt(), this@ViewTextWallpaperActivity, EventReceiver::class.java)
            }
            Handler().postDelayed({ lockScreenWallpaper() }, 400)
        }
        wallpaper.setOnClickListener {
            builder1.dismiss()
            //   Toast.makeText(ViewGradientCreatedWallpaperActivity.this, "Please Wait...", Toast.LENGTH_SHORT).show();
            mySharedPref!!.countExist = mySharedPref!!.countExist + 1
            progressBar!!.show()
            Handler().postDelayed({ // progressBar.dismiss();
                btnSetWallpaper!!.isEnabled = true
                if (mySharedPref!!.countExist >= 3 && mySharedPref!!.visitPlay == null) {
                   // showRateDialog()
                    mySharedPref!!.countExist=0
                }
            }, 3000)
            if (mySharedPref!!.alarmId != -1) {
                DBHelperAutoWallpaper(this@ViewTextWallpaperActivity).updateData()
                cancelAlarm(("2121" + mySharedPref!!.alarmId).toInt(), this@ViewTextWallpaperActivity, EventReceiver::class.java)
            }
            Handler().postDelayed({ onclickWallpaper(false) }, 400)
        }
        bothwallpaper.setOnClickListener {
            builder1.dismiss()
            //  Toast.makeText(ViewGradientCreatedWallpaperActivity.this, "Please Wait...", Toast.LENGTH_LONG).show();
            mySharedPref!!.countExist = mySharedPref!!.countExist + 1
            progressBar!!.show()
            Handler().postDelayed({ //   progressBar.dismiss();
                btnSetWallpaper!!.isEnabled = true
                if (mySharedPref!!.countExist >= 3 && mySharedPref!!.visitPlay == null) {
                   // showRateDialog()
                    mySharedPref!!.countExist=0
                }
            }, 3000)
            if (mySharedPref!!.alarmId != -1) {
                DBHelperAutoWallpaper(this@ViewTextWallpaperActivity).updateData()
                cancelAlarm(("2121" + mySharedPref!!.alarmId).toInt(), this@ViewTextWallpaperActivity, EventReceiver::class.java)
            }
            Handler().postDelayed({
                onclickWallpaper(true)
                lockScreenWallpaper()
            }, 400)
        }
    }

//    private fun showRateDialog() {
//        val viewGroup: ViewGroup = findViewById(android.R.id.content)
//        val dialogView: View = LayoutInflater.from(this).inflate(R.layout.dialog_rate_app, viewGroup, false)
//        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
//        builder.setView(dialogView)
//        val alertDialog: AlertDialog = builder.create()
//        Objects.requireNonNull(alertDialog.window)!!.setBackgroundDrawableResource(android.R.color.transparent)
//        alertDialog.setOnCancelListener { alertDialog.dismiss() }
//        val btnClose: ImageView = dialogView.findViewById(R.id.btnClose)
//        btnClose.setOnClickListener { alertDialog.dismiss() }
//        val ratingBar1: ScaleRatingBar = dialogView.findViewById(R.id.ratingBar)
//        ratingBar1.setOnRatingChangeListener { ratingBar, rating, fromUser ->
//            if (rating > 3) {
//                rate_app()
//                Handler().postDelayed({ alertDialog.dismiss() }, 1000)
//            } else {
////                sendMail()
//                Toast.makeText(this, "Thank you for giving review$rating", Toast.LENGTH_SHORT).show()
//                //       Toast.makeText(ViewTextWallpaperActivity.this, getResources().getString(R.string.thanks_for_review), Toast.LENGTH_SHORT).show();
//                Handler().postDelayed({ alertDialog.dismiss() }, 1000)
//            }
//        }
//        dialogView.findViewById<View>(R.id.btnNextTime).setOnClickListener {
//            mySharedPref!!.countExist = 0
//            alertDialog.dismiss()
//        }
//        if (!isFinishing) {
//            alertDialog.show()
//        }
//    }
//
//    private fun sendMail() {
//        mySharedPref!!.setVisitPlay()
//        /*Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
//        emailIntent.setType("text/plain");
//        emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{"profagnesh009@gmail.com"});
//        emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Share your valuable feedback with us to improve app quality and add more features in Solid Color Wallpaper");
//        emailIntent.setType("message/rfc822");
//        try {
//            startActivity(Intent.createChooser(emailIntent,
//                    "Send email using..."));
//        } catch (android.content.ActivityNotFoundException ex) {
//            Toast.makeText(this,
//                    "No email clients installed.",
//                    Toast.LENGTH_SHORT).show();
//        }*/
//        val send: Intent = Intent(Intent.ACTION_SENDTO)
//        val uriText: String = ("mailto:" + Uri.encode("profagnesh009@gmail.com") +
//                "?subject=" + Uri.encode("Share valuable feedback to improve app quality of Solid Color Wallpaper") +
//                "&body=" + Uri.encode(""))
//        val uri: Uri = Uri.parse(uriText)
//        send.setData(uri)
//        startActivity(Intent.createChooser(send, "Send Email..."))
//    }
//
//    private fun rate_app() {
//        mySharedPref!!.setVisitPlay()
//        try {
//            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")))
//        } catch (e: ActivityNotFoundException) {
//            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName")))
//        }
//    }

    private fun lockScreenWallpaper() {

        // if (mySharedPref.getScale().equalsIgnoreCase("fill")) {
        mBitmap = outputBitmap
        //  } else {
        //      mBitmap = scaledFitBitmap(mBitmap);
        //   }
        if (mBitmap != null) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    wallpaperManager!!.setBitmap(mBitmap, null, true, WallpaperManager.FLAG_LOCK) //For Lock screen
                    progressBar!!.dismiss()
                    if (vibrator != null) {
                        if (Build.VERSION.SDK_INT >= 26) {
                            vibrator!!.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
                        } else {
                            vibrator!!.vibrate(200)
                        }
                    }
                    showSnackBar(getResources().getString(R.string.toast_wallpaper_set_seccessfully))
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        } else {
            showSnackBar(getResources().getString(R.string.try_again_later))
            progressBar!!.dismiss()
        }
    }

    private fun scaledFitBitmap(bm: Bitmap): Bitmap {
        var bm: Bitmap = bm
        System.gc()
        Runtime.getRuntime().gc()
        val bm1: Bitmap = bm
        var width: Int = bm1.width
        var height: Int = bm1.height
        val metrics: DisplayMetrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(metrics)
        Log.v("Pictures", "Width and height are \$width--\$height")
        if (width > height) {
            Log.d("Pictures", "scaleBitmap: l")
            // landscape
            val ratio: Float = width.toFloat() / metrics.widthPixels
            width = metrics.widthPixels
            height = (height / ratio).toInt()
            if (height >= metrics.heightPixels) {
                height = metrics.heightPixels
            }
        } else if (height > width) {
            Log.d("Pictures", "scaleBitmap: p")
            // portrait
            val ratio: Float = height.toFloat() / metrics.heightPixels
            height = metrics.heightPixels
            width = (width / ratio).toInt()
            if (width >= metrics.widthPixels) {
                width = metrics.widthPixels
            }
        } else { // square
            Log.d("Pictures", "scaleBitmap: s")
            height = metrics.widthPixels
            width = metrics.widthPixels
        }
        Log.v(
                "Pictures",
                "after scaling Width and height are \$width--\$height"
        )
        bm = Bitmap.createScaledBitmap(bm, width, height, true)
        return bm
    }

    private fun onclickWallpaper(isBoth: Boolean) {
        //  if (mySharedPref.getScale().equalsIgnoreCase("fill")) {
        mBitmap = outputBitmap
        //  } else {
        //       mBitmap = scaledFitBitmap(getOutputBitmap());
        //   }
        if (mBitmap != null) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    wallpaperManager!!.setBitmap(mBitmap, null, true, WallpaperManager.FLAG_SYSTEM)
                } else {
                    wallpaperManager!!.setBitmap(mBitmap)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            if (!isBoth) {
                progressBar!!.dismiss()
                if (vibrator != null) {
                    if (Build.VERSION.SDK_INT >= 26) {
                        vibrator!!.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
                    } else {
                        vibrator!!.vibrate(200)
                    }
                }
                showSnackBar(getResources().getString(R.string.toast_wallpaper_set_seccessfully))
            }
        } else {
            showSnackBar(getResources().getString(R.string.try_again_later))
            progressBar!!.dismiss()
        }
    }

    fun showSnackBar(msg: String?) {
        val snackbar: Snackbar = Snackbar.make(findViewById(R.id.mainContainer), (msg)!!, Snackbar.LENGTH_SHORT)
        val v: View = snackbar.view
        val params: CoordinatorLayout.LayoutParams = v.layoutParams as CoordinatorLayout.LayoutParams
        params.gravity = Gravity.BOTTOM
        params.width = FrameLayout.LayoutParams.MATCH_PARENT
        v.layoutParams = params
        v.setBackgroundColor(Color.WHITE)
        val textView: TextView = v.findViewById(com.google.android.material.R.id.snackbar_text)
        textView.setTextColor(resources.getColor(R.color.text_colour_new))
        snackbar.show()
    }

    // Bitmap MBitmap1=scaleBitmapFix(bitmap);
    //  Log.d("78123317566", "getOutputBitmap: "+MBitmap1.getWidth()+"  "+MBitmap1.getHeight());
    private val outputBitmap: Bitmap
        private get() {
            val v: View = mainViewPage!!.findViewWithTag("myview" + mainViewPage!!.currentItem)
            val bitmap: Bitmap = Bitmap.createBitmap(v.width, v.height, Bitmap.Config.ARGB_8888)
            val canvas: Canvas = Canvas(bitmap)
            v.draw(canvas)
            // Bitmap MBitmap1=scaleBitmapFix(bitmap);
            //  Log.d("78123317566", "getOutputBitmap: "+MBitmap1.getWidth()+"  "+MBitmap1.getHeight());
            return bitmap
        }

    private fun scaleBitmapFix(bm: Bitmap): Bitmap {
        var bm: Bitmap = bm
        var width: Int = bm.width
        var height: Int = bm.height
        if (width > 0 && height > 0) {
            if (width > height) {

                // landscape
                val ratio: Float = width.toFloat() / widthD
                width = widthD
                height = (height / ratio).toInt()
                if (height >= heightD) {
                    height = heightD
                }
            } else if (height > width) {
                Log.d("Pictures", "scaleBitmap: p")
                // portrait
                val ratio: Float = height.toFloat() / heightD
                height = heightD
                width = (width / ratio).toInt()
                if (width >= widthD) {
                    width = widthD
                }
            } else {
                // square
                Log.d("Pictures", "scaleBitmap: s")
                height = heightD
                width = widthD
            }
            try {
                bm = Bitmap.createScaledBitmap(bm, width, height, false)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        return bm
    }

    private val photoes: Unit
        private get() {
            imagePaths = ArrayList()
            val file: File = File(Constants.path)
            if (file.isDirectory) {
                val files: Array<File> = file.listFiles { pathname -> pathname.getPath().endsWith(".jpg") || pathname.getPath().endsWith(".jpeg") || pathname.getPath().endsWith(".png") }
                if (files.isNotEmpty()) {
                    var temp: File
                    for (i in files.indices) {
                        for (j in i + 1 until files.size) {
                            if (files.get(i).lastModified() < files.get(j).lastModified()) {
                                temp = files.get(i)
                                files[i] = files.get(j)
                                files[j] = temp
                            }
                        }
                    }
                    for (value: File in files) {
                        Log.d("789456132", "getPhotoes: " + value.absolutePath)
                        imagePaths!!.add(value.absolutePath)
                    }
                }
            }
        }

    public override fun onBackPressed() {
        if (!getBoolean(this@ViewTextWallpaperActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
            isShowInterstitialAd{
                finish()
            }


        } else {
            finish()
        }
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("787897789", "onRestart: ")
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted
            startActivity(Intent(this@ViewTextWallpaperActivity, MainStartActivity::class.java))
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        SolidWallpaperApplication.staticLanguage.Factory.create(this)
    }

    companion object {
        private val READ_PERMISSION: Int = 101
        private val SHARE_PERMISSION: Int = 102
    }
}