package com.hd.wallpaper.solid.color.background.model.api

import com.google.gson.annotations.SerializedName

class Response {
    @SerializedName("ResponseCode")
    val responseCode: String? = null

    @SerializedName("data")
    val data: List<DataItem>? = null

    @SerializedName("ResponseMessage")
    val responseMessage: String? = null

}