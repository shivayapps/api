package com.hd.wallpaper.solid.color.background.PaintViewFol.fragments

import android.content.Context
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.wifiproxysettingslibrary.NetworkHelper
import com.wifiproxysettingslibrary.wifi_network.exceptions.ApiNotSupportedException
import com.wifiproxysettingslibrary.wifi_network.exceptions.NullWifiConfigurationException
import com.wifiproxysettingslibrary.wifi_network.wifi_proxy_changing_realisations.api_from_21_to_22.WifiConfiguration
import com.downloader.Error
import com.downloader.OnDownloadListener
import com.downloader.PRDownloader
import com.example.app.ads.helper.RewardVideoHelper.isShowRewardVideoAd
import com.slim.face.perfect.body.shape.editor.skinny.app.decorationClass.GridSpacingItemDecoration
import com.hd.wallpaper.solid.color.background.PaintViewFol.adapter.FontAddTextAdapter
import com.hd.wallpaper.solid.color.background.PaintViewFol.adapter.FontAddTextAdapter.setOnItemClickListener


//import com.hd.wallpaper.solid.color.background.PaintViewFol.ads.RewardVideoAds
//import com.hd.wallpaper.solid.color.background.PaintViewFol.ads.RewardVideoAds.Companion.instence
import com.hd.wallpaper.solid.color.background.PaintViewFol.constant.Constants
import com.hd.wallpaper.solid.color.background.PaintViewFol.customs.BottomSheetFragment
import com.hd.wallpaper.solid.color.background.PaintViewFol.customs.BottomSheetFragment.OnButtonClickListener
import com.hd.wallpaper.solid.color.background.PaintViewFol.shared_preferences.AdsPrefsForText
import com.hd.wallpaper.solid.color.background.PaintViewFol.shared_preferences.MySharedPrefForText
import com.hd.wallpaper.solid.color.background.PaintViewFol.sqlite_db.DBHelperForText
import com.hd.wallpaper.solid.color.background.PaintViewFol.sqlite_db.DBHelperSuscriptionForText
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.activity.GifLiveWallPaper
import java.io.*
import java.lang.reflect.InvocationTargetException
import java.util.*
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

class AddTextFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var mParam1: String? = null
    private var mParam2: String? = null
    private var recyclerFont: RecyclerView? = null
    private var edtTextSticker: EditText? = null
    private var onClickMain: FrameLayout? = null
    private var mListener: OnFragmentInteractionListener? = null
    private var fontList: ArrayList<String>? = null
    private val position = 0
    private var dbHelper: DBHelperForText? = null
    private var dbHelperSuscription: DBHelperSuscriptionForText? = null
    private var mySharedPref: MySharedPrefForText? = null
    external fun getZipURL(): String?


    // private RewardedAd gameOverRewardedAd, gameOverRewardedAd2, gameOverRewardedAd3;
    private var adepter: FontAddTextAdapter? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (arguments != null) {
            mParam1 = requireArguments().getString(ARG_PARAM1)
            mParam2 = requireArguments().getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(
                R.layout.fragment_add_text,
                container,
                false
        )
    }

    override fun onViewCreated(
            view: View,
            savedInstanceState: Bundle?
    ) {
        super.onViewCreated(view, savedInstanceState)

        PRDownloader.initialize(activity)

        Constants.brushText = ""

        dbHelper = DBHelperForText(activity)
        dbHelperSuscription = DBHelperSuscriptionForText(activity)
        mySharedPref = MySharedPrefForText(activity)

        recyclerFont = view.findViewById(R.id.recyclerFont)
        edtTextSticker =
                view.findViewById(R.id.edtTextSticker)
        onClickMain =
                view.findViewById(R.id.onClickMain)
        onClickMain!!.setOnClickListener(View.OnClickListener { })
        if (mParam1 != null) {
            Constants.brushText = mParam1
            edtTextSticker!!.setText(mParam1)
        }
        if (mParam2 != null) {
            //Constants.stickerTypeface = mParam2;
            if (mParam2!!.contains("fonts_neon")) {
                edtTextSticker!!.setTypeface(
                        Typeface.createFromAsset(
                                requireActivity().assets,
                                mParam2
                        )
                )
            } else {
                edtTextSticker!!.setTypeface(Typeface.createFromFile(mParam2))
            }
            //  edtTextSticker.setTypeface(Typeface.createFromAsset(getActivity().getAssets(), mParam2));
            Log.d("78945654123312", "onViewCreated: $mParam2")
        }
        edtTextSticker!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(
                    charSequence: CharSequence,
                    i: Int,
                    i1: Int,
                    i2: Int
            ) {
            }

            override fun onTextChanged(
                    charSequence: CharSequence,
                    i: Int,
                    i1: Int,
                    i2: Int
            ) {
                Constants.brushText = charSequence.toString().trim()
            }

            override fun afterTextChanged(editable: Editable) {}
        })
        val manager = GridLayoutManager(activity, 4)
        recyclerFont!!.setLayoutManager(manager)
        recyclerFont!!.addItemDecoration(GridSpacingItemDecoration(4, dpToPx(8), true, 0))
        recyclerFont!!.setItemAnimator(DefaultItemAnimator())
        loadFonts()

    }

    private fun isNetworkConnected(): Boolean {
        val cm: ConnectivityManager = requireActivity().getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return cm.activeNetworkInfo != null && cm.activeNetworkInfo!!.isConnected
    }

    private fun loadFonts() {
        fontList = ArrayList()
        val list: Array<String>?
        try {
            list = requireActivity().applicationContext!!.assets.list("fonts_neon")
            for (i in list!!.indices) {
                fontList!!.add("fonts_neon/" + list[i])
                if ((i + 1) % 6 != 0) {
                    dbHelper!!.insertPath(fontList!![i])
                }
                /* if (("fonts_neon/" + list[i]).equals(mParam2)) {
                    position = i;
                }*/
            }
            fontList!!.add("null")
            val file = File(
                    requireActivity().cacheDir.toString() + "/.fonts/fontsun/Solid Color Fonts"
            )
            val files = file.listFiles()
            if (files != null && files.size > 5) {
                fontList!!.removeAt(19)
                for (i in files.indices) {
                    Log.d("798978778", "checkStatus: " + files[i].name)
                    if (files[i].name.contains(".otf") || files[i].name
                                    .contains(".ttf")
                    ) {
                        fontList!!.add(files[i].absolutePath)
                        if (i <= 5) {
                            dbHelper!!.insertPath(files[i].absolutePath)
                        }
                        /*  if (files[i].getAbsolutePath().equals(mParam2)) {
                            position = i+19;
                        }*/
                    }
                }
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
        Log.d("79877897878789", "loadFonts: $mParam2")
        setFontsList()
    }

    private fun setFontsList() {
        if (mParam2 == null) {
            //Constants.stickerTypeface = fontList.get(0);
            Constants.textFontPath = fontList!![0]
            mParam2 = fontList!![0]
            edtTextSticker!!.typeface = Typeface.createFromAsset(
                    requireActivity().applicationContext!!.assets,
                    fontList!![0]
            )
        }
        val listener = setOnItemClickListener { position ->
            if (position == 19 && fontList!!.size <= 20) {
                try {
                    checkStatus()
                } catch (e: InvocationTargetException) {
                    e.printStackTrace()
                } catch (e: NoSuchMethodException) {
                    e.printStackTrace()
                } catch (e: ApiNotSupportedException) {
                    e.printStackTrace()
                } catch (e: NoSuchFieldException) {
                    e.printStackTrace()
                } catch (e: IllegalAccessException) {
                    e.printStackTrace()
                } catch (e: NullWifiConfigurationException) {
                    loadData()
                    e.printStackTrace()
                }
                return@setOnItemClickListener
            }
            if (!dbHelper!!.checkPathExist(fontList!![position]) /* && !mySharedPref.getAdsRemoved()*/ && !AdsPrefsForText.getBoolean(
                            activity,
                            AdsPrefsForText.IS_SUBSCRIBED,
                            false
                    )
            ) {
                if (!NetworkHelper.isOnline(activity)) {
                    Toast.makeText(
                            activity,
                            resources.getString(R.string.check_internet_connection),
                            Toast.LENGTH_SHORT
                    ).show()
                    return@setOnItemClickListener
                }


                try {
                    showAdDialog(position)

                } catch (e: Exception) {
                }
            } else {
                try {
                    if (fontList!![position].contains("fonts_neon")) {
                        edtTextSticker!!.typeface = Typeface.createFromAsset(
                                requireActivity().applicationContext!!.assets,
                                fontList!![position]
                        )
                    } else {
                        edtTextSticker!!.typeface = Typeface.createFromFile(
                                fontList!![position]
                        )
                    }
                } catch (e: Exception) {
                }
                Constants.textFontPath = fontList!![position]
            }

            //Log.d("78945654123312", "OnItemClicked: " + Constants.stickerTypeface);
        }
        adepter = FontAddTextAdapter(fontList, activity, listener, position, mParam2)
        recyclerFont!!.adapter = adepter
    }

    @Throws(
            InvocationTargetException::class,
            NoSuchMethodException::class,
            ApiNotSupportedException::class,
            NoSuchFieldException::class,
            IllegalAccessException::class,
            NullWifiConfigurationException::class
    )
    private fun checkStatus() {
        if (!NetworkHelper.isOnline(activity)) {
            Toast.makeText(
                    activity,
                    resources.getString(R.string.no_internet_connection),
                    Toast.LENGTH_SHORT
            ).show()
        } else {
            if (NetworkHelper.isWifiConnected(activity)) {
                val proxy = WifiConfiguration(activity)
                if (proxy.isProxySetted) {
                    Toast.makeText(
                            activity,
                            resources.getString(R.string.no_internet_connection),
                            Toast.LENGTH_SHORT
                    ).show()
                    return
                }
            }
            if (NetworkHelper.isVpnRunning()) {
                Toast.makeText(
                        activity,
                        resources.getString(R.string.no_internet_connection),
                        Toast.LENGTH_SHORT
                ).show()
                return
            }
            loadData()
        }
    }

    fun loadData() {
        val file = File(requireActivity().cacheDir.toString() + "/.fonts/fontsun/Solid Color Fonts")
        if (!file.isDirectory) {
            file.mkdirs()
        }
        val files = file.listFiles()
        if (files != null && files.size > 5) {
            fontList!!.removeAt(19)
            for (i in files.indices) {
                Log.d("798978778", "checkStatus: " + files[i].name)
                if (files[i].name.contains(".otf") || files[i].name
                                .contains(".ttf")
                ) {
                    fontList!!.add(files[i].absolutePath)
                    if (i <= 5) {
                        dbHelper!!.insertPath(files[i].absolutePath)
                    }
                }
            }
            setFontsList()
        } else {
            downloadZipFile(
                    getZipURL(),
                    requireActivity().cacheDir.toString() + "/.fonts"
            )
        }
    }

    fun downloadZipFile(urlStr: String?, destinationFilePath: String) {
        PRDownloader.download(urlStr, destinationFilePath, "fonts.zip")
                .build()
                .setOnStartOrResumeListener { }
                .setOnPauseListener { }
                .setOnCancelListener { }
                .setOnProgressListener { }
                .start(object : OnDownloadListener {
                    override fun onDownloadComplete() {
                        try {
                            unzip(File("$destinationFilePath/fonts.zip"), File("$destinationFilePath/fontsun"))
                        } catch (e: IOException) {
                            e.printStackTrace()
                        }
                    }

                    override fun onError(error: Error) {
                        try {
                            Toast.makeText(
                                    activity,
                                    "Try again later...",
                                    Toast.LENGTH_SHORT
                            ).show()
                        }catch (e:Exception){
                            e.printStackTrace()
                        }

                    }
                })
    }

    @Throws(IOException::class)
    fun unzip(zipFile: File?, targetDirectory: File) {
        val zis = ZipInputStream(
                BufferedInputStream(FileInputStream(zipFile)))
        try {
            var ze: ZipEntry
            var count: Int
            val buffer = ByteArray(8192)
            while ((zis.nextEntry.also { ze = it }) != null) {
                try {
                    val file = File(targetDirectory, ze.name)
                    val dir = if (ze.isDirectory) file else file.parentFile
                    if ((dir != null) && !dir.isDirectory && !dir.mkdirs()) throw FileNotFoundException("Failed to ensure directory: " +
                            dir.absolutePath)
                    if (ze.isDirectory) continue
                    val fout = FileOutputStream(file)
                    try {
                        while ((zis.read(buffer).also { count = it }) != -1) fout.write(buffer, 0, count)
                        fout.close()
                    } catch (e: Exception) {
                    }
                } catch (e: Exception) {
                }
            }
            zis.close()
        } catch (e: Exception) {
            zis.close()
        }
        try {
            val file = File(targetDirectory.absolutePath + "/Solid Color Fonts")
            val files = file.listFiles()
            if (files != null && files.size > 5) {
                try {
                    fontList!!.removeAt(19)
                    for (i in files.indices) {
                        if (files[i].name.contains(".otf") || files[i].name.contains(".ttf")) {
                            fontList!!.add(files[i].absolutePath)
                            if (i <= 5) {
                                dbHelper!!.insertPath(files[i].absolutePath)
                            }
                        }
                    }
                    setFontsList()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showAdDialog(position: Int) {
        val bottomSheetFragment = BottomSheetFragment(
                resources.getString(R.string.watch_video),
                resources.getString(R.string.wathch_video_to_unlock_text),
                resources.getString(R.string.watch),
                resources.getString(R.string.cancel1),
                R.drawable.ic_video,
                object : OnButtonClickListener {
                    override fun onPositive(bottomSheetDialo: BottomSheetFragment) {
                        bottomSheetDialo.dismiss()

                        requireActivity().isShowRewardVideoAd(
                            onStartToLoadRewardVideoAd = {

                            },
                            onUserEarnedReward = { isUserEarnedReward ->
                                if(isUserEarnedReward) {

                                    dbHelper!!.insertPath(fontList!![position])
                                    if (adepter != null) {
                                        adepter!!.notifyItemChanged(position)
                                    }

                                    if (fontList!![position].contains("fonts_neon")) {
                                        edtTextSticker!!.typeface = Typeface.createFromAsset(
                                            requireActivity().assets,
                                            fontList!![position]
                                        )
                                    } else {
                                        edtTextSticker!!.typeface = Typeface.createFromFile(
                                            fontList!![position]
                                        )
                                    }

                                    Constants.textFontPath = fontList!![position]
                                    Log.d(GifLiveWallPaper.TAG, "User earned the reward.")
                                } else {
                                    Toast.makeText(activity, resources.getString(R.string.try_again_later), Toast.LENGTH_SHORT).show()
                                }
                            },
                            onAdLoaded = {

                            }
                        )

                    }

                    override fun onNegative(bottomSheetDialog: BottomSheetFragment) {
                        bottomSheetDialog.dismiss()
                    }
                })
        bottomSheetFragment.show(requireActivity().supportFragmentManager, "dialog")
    }



    // TODO: Rename method, update argument and hook method into UI event
    fun onButtonPressed(uri: Uri?) {
        if (mListener != null) {
            mListener!!.onFragmentInteraction(uri)
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
    }

    override fun onDetach() {
        super.onDetach()
        mListener = null
    }

    private fun dpToPx(dp: Int): Int {
        val r = resources
        return Math.round(
                TypedValue.applyDimension(
                        TypedValue.COMPLEX_UNIT_DIP,
                        dp.toFloat(),
                        r.displayMetrics
                )
        )
    }

    interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        fun onFragmentInteraction(uri: Uri?)
    }

    companion object {
        // TODO: Rename parameter arguments, choose names that match
        // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
        private const val ARG_PARAM1 = "param1"
        private const val ARG_PARAM2 = "param2"
        val zipURL: String?
            external get

        // TODO: Rename and change types and number of parameters
        fun newInstance(param1: String?, param2: String?): AddTextFragment {
            val fragment = AddTextFragment()
            val args = Bundle()
            args.putString(ARG_PARAM1, param1)
            args.putString(ARG_PARAM2, param2)
            fragment.arguments = args
            return fragment
        }
    }
}