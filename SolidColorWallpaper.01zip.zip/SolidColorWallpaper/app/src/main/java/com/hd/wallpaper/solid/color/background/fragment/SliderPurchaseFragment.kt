package com.hd.wallpaper.solid.color.background.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.hd.wallpaper.solid.color.background.R
import kotlinx.android.synthetic.main.fragment_slider_purchase.*

class SliderPurchaseFragment : Fragment() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_slider_purchase, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val bundle = arguments

        if (bundle != null) {
            main_image.setImageResource(bundle.getInt("image_id"))
            txt_main_title.text = bundle.getString("title_msg")
            txt_sub_message.text = bundle.getString("sub_msg")
        }
    }

    companion object {

        fun getInstance(bundle: Bundle): SliderPurchaseFragment {
            val fragmentSlider = SliderPurchaseFragment()
            fragmentSlider.arguments = bundle
            return fragmentSlider
        }
    }
}