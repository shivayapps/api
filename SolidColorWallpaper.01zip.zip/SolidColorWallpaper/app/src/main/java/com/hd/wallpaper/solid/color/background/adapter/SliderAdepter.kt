package com.hd.wallpaper.solid.color.background.adapter

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import com.hd.wallpaper.solid.color.background.fragment.SliderPurchaseFragment.Companion.getInstance
import com.hd.wallpaper.solid.color.background.model.SLiderPremiumModel
import java.util.*

class SliderAdepter//    this.isAnim = isAnim; // private boolean isAnim;
(fm: FragmentManager?, private val mList: ArrayList<SLiderPremiumModel>) : FragmentStatePagerAdapter(fm!!) {
    private val integers = ArrayList<Int>()
    private val number = 0
    override fun getItem(position: Int): Fragment {

        /*if (!isAnim) {

            if (position == 0) {
                number = 0;
                integers.clear();
            }

            Random r = new Random();
            int i1 = r.nextInt(mList.size() - 0) + 0;

            if (integers.contains(i1)) {
                int i = r.nextInt(mList.size() - 0) + 0;
                while (integers.contains(i)) {
                    i = r.nextInt(mList.size() - 0) + 0;
                }
                number = i;
                integers.add(i);
            } else {
                number = i1;
                integers.add(i1);
            }
        } else {
            number = position;
        }
*/
        Log.d(TAG, "getItem: position = $position number = $number")
        val bundle = Bundle()
        bundle.putInt("image_id", mList[position].image_id)
        bundle.putString("title_msg", mList[position].title_msg)
        bundle.putString("sub_msg", mList[position].sub_msg)
        return getInstance(bundle)
    }

    override fun getCount(): Int {
        return 5
    }

    companion object {
        private const val TAG = "SliderAdepter"
        private val RANDOM = Random()
    }

}