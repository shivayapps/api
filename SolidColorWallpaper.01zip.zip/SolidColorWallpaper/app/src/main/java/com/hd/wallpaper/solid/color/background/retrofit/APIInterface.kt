package com.hd.wallpaper.solid.color.background.retrofit

import com.hd.wallpaper.solid.color.background.model.api.Response
import retrofit2.Call
import retrofit2.http.GET

interface APIInterface {
    @GET("app/2")
    fun doGetListResources(): Call<Response?>?
    @GET("application/2")
    fun doGetNewListResources(): Call<com.hd.wallpaper.solid.color.background.newModel.Response?>?
}