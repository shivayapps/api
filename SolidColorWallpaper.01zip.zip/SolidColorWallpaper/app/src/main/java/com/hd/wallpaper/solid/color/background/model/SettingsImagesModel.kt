package com.hd.wallpaper.solid.color.background.model

import android.graphics.Bitmap

class SettingsImagesModel(var bitmap: Bitmap, var isDeletable: Boolean)