package com.hd.wallpaper.solid.color.background.shared_pref

import android.content.Context
import android.content.SharedPreferences

//SharedPreferences manager class
object AdsPrefs {
    const val URL_INDEX = "URL_INDEX"
    const val IS_ADS_REMOVED = "is_ads_removed"
    const val DEVICE_ID = "device_id"
    const val SPLASH_AD_DATA = "Ad_data"
    const val FEB_COUNTER = "feb_counter"
    const val HINT_COUNT = "hint_counts"
    const val COINS_COUNT = "coins_count"
    const val CATEGORY_LIST = "category_list"
    const val IS_FIRST_TIME = "is_first_time"
    const val PRICE_YEAR = "price_year"
    const val PRICE_WEEK = "price_week"
    const val PRICE_MONTH_DISCOUNT = "price_month_discount"
    const val PRICE_MONTH = "price_month"
    const val PRICE_MONTH_3 = "price_month_3"
    const val TRAIL_YEAR = "trial_year"
    const val TRAIL_MONTH = "trial_month"
    const val TRAIL_MONTH_DISCOUNT = "trial_month_discount"
    const val TRAIL_YEAR_BTN = "trial_year_btn"
    const val TRAIL_MONTH_BTN = "trial_month_btn"
    const val TRAIL_MONTH_DISCOUNT_BTN = "trial_month_discount_btn"
    const val TRAIL_YEAR_MSG = "trial_year_msg"
    const val TRAIL_MONTH_MSG = "trial_month_msg"
    const val TRAIL_MONTH_DISCOUNT_MSG = "trial_month_discount_msg"
    const val IS_AUTO_RENEW_YEAR = "is_auto_renew_year"
    const val IS_AUTO_RENEW_MONTH = "is_auto_renew_month"
    const val IS_AUTO_RENEW_3_MONTH = "is_auto_renew_3_month"
    const val IS_AUTO_RENEW_WEEK = "is_auto_renew_week"
    const val IS_AUTO_RENEW_MONTH_DISCOUNT = "is_auto_renew_month_discount"
    const val PURCHASED_PLAN_ID = "purchased_plan_id"
    const val PLAN_ID = "plan_id"
    const val PLANE_PRICE = "plane_price"
    const val CLICKED_ITEM_LIST = "clicked_item_list"
    const val EMAIL = "dummy_email"
    const val DEFAULT_PRICE_YEAR = "₹2100.00"
    const val DEFAULT_PRICE_MONTH = "₹350.00"
    const val DEFAULT_PRICE_WEEK = "₹99.00"
    const val IS_SUBSCRIBED = "subscribed"
    const val IS_NEED_TO_SHOW_SPOTLIGHT_GRADIENT = "spotlight_gradient"
    const val IS_NEED_TO_SHOW_SPOTLIGHT_SOLID = "spotlight_solid"
    const val IS_NEED_TO_SHOW_SPOTLIGHT_TEXT = "spotlight_text"
    const val WALLET_COINS = "wallet_coins"
    const val PLAN_500_COIN = "plan_500_coin"
    const val PLAN_2000_COIN = "plan_2000_coin"
    const val PLAN_10000_COIN = "plan_10000_coin"
    const val ADS_FREE_COUNT = "ads_free_count"
    const val ADS_FREE_DATE = "ads_free_date"

    //SharedPreferences file name
    private const val SHARED_PREFS_FILE_NAME = "app_center"
    private fun getPrefs(context: Context?): SharedPreferences {
        assert(context != null)
        return context!!.getSharedPreferences(SHARED_PREFS_FILE_NAME, Context.MODE_PRIVATE)
    }

    fun contain(context: Context?, key: String?): Boolean {
        return getPrefs(context).contains(key)
    }

    fun clearPrefs(context: Context?) {
        val device_id = getString(context, DEVICE_ID)
        getPrefs(context).edit().clear().commit()
        save(context, DEVICE_ID, device_id)
    }

    //Save Booleans
    fun save(context: Context?, key: String?, value: Boolean) {
        getPrefs(context).edit().putBoolean(key, value).commit()
    }

    fun savePref(context: Context?, key: String?, value: Boolean) {
        getPrefs(context).edit().putBoolean(key, value).commit()
    }

    //Get Booleans
    fun getBoolean(context: Context?, key: String?): Boolean {
        return getPrefs(context).getBoolean(key, false)
    }

    //Get Booleans if not found return a predefined default value
    @JvmStatic
    fun getBoolean(context: Context?, key: String?, defaultValue: Boolean): Boolean {
        return getPrefs(context).getBoolean(key, defaultValue)
    }

    //Strings
    fun save(context: Context?, key: String?, value: String?) {
        getPrefs(context).edit().putString(key, value).commit()
    }

    fun getString(context: Context?, key: String?): String? {
        return getPrefs(context).getString(key, "")
    }

    @JvmStatic
    fun getString(context: Context?, key: String?, defaultValue: String?): String? {
        return getPrefs(context).getString(key, defaultValue)
    }

    //Integers
    fun save(context: Context?, key: String?, value: Int) {
        getPrefs(context).edit().putInt(key, value).commit()
    }

    fun getInt(context: Context?, key: String?): Int {
        return getPrefs(context).getInt(key, 0)
    }

    @JvmStatic
    fun getInt(context: Context?, key: String?, defaultValue: Int): Int {
        return getPrefs(context).getInt(key, defaultValue)
    }

    //Floats
    fun save(context: Context?, key: String?, value: Float) {
        getPrefs(context).edit().putFloat(key, value).commit()
    }

    fun getFloat(context: Context?, key: String?): Float {
        return getPrefs(context).getFloat(key, 0f)
    }

    fun getFloat(context: Context?, key: String?, defaultValue: Float): Float {
        return getPrefs(context).getFloat(key, defaultValue)
    }

    //Longs
    fun save(context: Context?, key: String?, value: Long) {
        getPrefs(context).edit().putLong(key, value).commit()
    }

    fun getLong(context: Context?, key: String?): Long {
        return getPrefs(context).getLong(key, 0)
    }

    fun getLong(context: Context?, key: String?, defaultValue: Long): Long {
        return getPrefs(context).getLong(key, defaultValue)
    }

    fun removeKey(context: Context?, key: String?) {
        getPrefs(context).edit().remove(key).commit()
    }
}