package com.hd.wallpaper.solid.color.background.fragment

import android.content.res.Resources
import android.os.Bundle
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.adapter.CreationSelectableAdapter
import com.hd.wallpaper.solid.color.background.constants.Constants
import com.hd.wallpaper.solid.color.background.custom.GridSpacingItemDecoration
import com.hd.wallpaper.solid.color.background.model.SavedImageModel
import java.io.File
import java.io.FileFilter
import java.util.*

class CreationSelectableFragment constructor() : Fragment() {
    private var recyclerWallpaper: RecyclerView? = null
    private var imagePaths: ArrayList<SavedImageModel>? = null
    private var adapter: CreationSelectableAdapter? = null
    private var layoutSubscribe: ConstraintLayout? = null
    private var btnSubscribe: ConstraintLayout? = null
    private var noImages: ConstraintLayout? = null
    public override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                                     savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_creation_selectable, container, false)
    }

    public override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        System.gc()
        Runtime.getRuntime().gc()
        recyclerWallpaper = view.findViewById(R.id.recyclerWallpaper)
        btnSubscribe = view.findViewById(R.id.btnSubscribe)
        layoutSubscribe = view.findViewById(R.id.layoutSubscribe)
        noImages = view.findViewById(R.id.noImages)

        /*    if (!AdsPrefs.getBoolean(getActivity(), AdsPrefs.IS_SUBSCRIBED, false)) {
            layoutSubscribe.setVisibility(View.VISIBLE);
            noImages.setVisibility(View.GONE);
            recyclerWallpaper.setVisibility(View.GONE);

            btnSubscribe.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(getActivity(), PremiumAccessActivity.class));
                }
            });

        } else {*/
        layoutSubscribe!!.visibility = View.GONE
        noImages!!.visibility = View.GONE
        recyclerWallpaper!!.visibility = View.VISIBLE
        val manager: GridLayoutManager = GridLayoutManager(activity, 3)
        recyclerWallpaper!!.layoutManager = manager
        recyclerWallpaper!!.addItemDecoration(GridSpacingItemDecoration(3, dpToPx(8), true))
        recyclerWallpaper!!.itemAnimator = DefaultItemAnimator()
        photoes
        // }
    }

    private val photoes: Unit
        private get() {
            imagePaths = ArrayList()
            val file: File = File(Constants.path)
            if (file.isDirectory) {
                val files: Array<File> = file.listFiles { pathname -> pathname.getPath().endsWith(".jpg") || pathname.getPath().endsWith(".jpeg") || pathname.getPath().endsWith(".png") }
                if (files.isNotEmpty()) {
                    var temp: File
                    for (i in files.indices) {
                        for (j in i + 1 until files.size) {
                            if (files[i].lastModified() < files[j].lastModified()) {
                                temp = files[i]
                                files[i] = files[j]
                                files[j] = temp
                            }
                        }
                    }
                    for (value: File in files) {
                        val model: SavedImageModel = SavedImageModel()
                        model.path = value.absolutePath
                        model.isDeletedEnable = false
                        imagePaths!!.add(model)
                    }
                }
            }
            if (imagePaths!!.size > 0) {
                setDataToAdapter()
                layoutSubscribe!!.visibility = View.GONE
                recyclerWallpaper!!.visibility = View.VISIBLE
                noImages!!.visibility = View.GONE
            } else {
                layoutSubscribe!!.visibility = View.GONE
                recyclerWallpaper!!.visibility = View.GONE
                noImages!!.visibility = View.VISIBLE
            }
        }

    private fun setDataToAdapter() {
        val listener: CreationSelectableAdapter.setOnItemClickListener = object : CreationSelectableAdapter.setOnItemClickListener {
            public override fun OnItemClickedImage(position: Int) {}
            public override fun OnLongClickImage(position: Int) {}
        }
        adapter = CreationSelectableAdapter(imagePaths!!, activity!!, listener)
        recyclerWallpaper!!.adapter = adapter
    }

    /* Glide.with(getActivity()).asBitmap().load(imagePaths.get(i).getPath()).into(new CustomTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                        mList.add(resource);
                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {

                    }
                });*/
    val dataList: ArrayList<SavedImageModel>
        get() {
            val mList: ArrayList<SavedImageModel> = ArrayList()
            if (imagePaths != null) {
                for (i in imagePaths!!.indices) {
                    if (imagePaths!![i].isDeletedEnable) {
                        /* Glide.with(getActivity()).asBitmap().load(imagePaths.get(i).getPath()).into(new CustomTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                        mList.add(resource);
                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {

                    }
                });*/
                        mList.add(imagePaths!!.get(i))
                    }
                }
            }
            return mList
        }

    private fun dpToPx(dp: Int): Int {
        val r: Resources = resources
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), r.displayMetrics))
    }
}