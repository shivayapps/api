package com.hd.wallpaper.solid.color.background.imagePicker.listener;



public interface OnBackAction {
    void onBackToFolder();

    void onFinishImagePicker();
}
