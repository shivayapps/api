package com.hd.wallpaper.solid.color.background.retrofit

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object APIClient {
    private var retrofit: Retrofit? = null
    fun getBaseURL(): String {
        return "https://autolivewallpaper.vasundharaapps.com/api/"
    }


    @JvmStatic
    val client: Retrofit?
        get() {
            if (retrofit == null) {
                retrofit = Retrofit.Builder()
                        .baseUrl("https://autolivewallpaper.vasundharaapps.com/api/")
                        .addConverterFactory(GsonConverterFactory.create())
                        .build()
            }
            return retrofit
        }
}