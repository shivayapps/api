package com.hd.wallpaper.solid.color.background.activity

import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.hd.wallpaper.solid.color.background.R
import kotlinx.android.synthetic.main.activity_gamezop.*

class GamezopActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gamezop)

        webView.settings.javaScriptEnabled = true

        webView.loadUrl("https://www.gamezop.com/?id=Y2_mvlugT")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                lottieAnimation.visibility = View.GONE
                webView.visibility = View.VISIBLE
            }
        }
    }

    override fun onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun applyOverrideConfiguration(overrideConfiguration: Configuration) {
        if (Build.VERSION.SDK_INT in 21..22) {
            return
        }
        super.applyOverrideConfiguration(overrideConfiguration)
    }
}