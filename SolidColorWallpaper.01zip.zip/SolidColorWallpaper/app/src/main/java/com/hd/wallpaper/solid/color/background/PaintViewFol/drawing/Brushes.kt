package com.hd.wallpaper.solid.color.background.PaintViewFol.drawing

import android.content.Context
import android.os.SystemClock
import android.util.Log
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.PaintViewFol.drawing.Brush.Companion.parseStyleData
import kotlin.collections.ArrayList

object Brushes {
    private val BRUSH_STYLES: IntArray
    private var mBrushList: Array<Brush?>?= arrayOf()
    private var mPhotoBrushList: ArrayList<Brush?>? = null
    private var mStylishBrushList: ArrayList<Brush?>? = null
    operator fun get(context: Context?, type: Int): ArrayList<Brush?>? {
        if (mBrushList == null) {
            loadBrushList(context)
        }
        Log.d("type",type.toString())
        return if (type == 0) mStylishBrushList else mPhotoBrushList
    }

    @JvmStatic
    operator fun get(context: Context?): Array<Brush?>? {
        if (mBrushList!!.size==0) {
            loadBrushList(context)
        }
        return mBrushList
    }



    fun loadBrushList(context: Context?) {
        if (mBrushList!!.size==0) {
            val t1 = SystemClock.elapsedRealtime()
            mBrushList = parseStyleData(context!!, BRUSH_STYLES)
            val t2 = SystemClock.elapsedRealtime()
            val arr1 = mBrushList
            val len1 = arr1!!.size
            var i1 = 0
            while (i1 < len1) {
                val brush = arr1[i1]
                if (brush!!.brushType == 0) {
                    mStylishBrushList!!.add(brush)
                } else {
                    mPhotoBrushList!!.add(brush)
                }
                i1++
            }
        }
    }

    init {
        mStylishBrushList = ArrayList<Brush?>()
        mPhotoBrushList = ArrayList<Brush?>()
        /*BRUSH_STYLES = intArrayOf(
            R.style.Brush_Bamboo1, R.style.Brush_Bamboo2, R.style.Brush_AirBrush,
                R.style.Brush_Pen, R.style.Brush_Calligraphy, R.style.Brush_HardPencil,
                R.style.Brush_SoftPencil, R.style.Brush_InkPen, R.style.Brush_BallpointPen,
                R.style.Brush_HardEraser, R.style.Brush_SoftEraser,
                R.style.Brush_AirBrush, R.style.Brush_Oil, R.style.Brush_FeltPen,
                R.style.Brush_WaterColor, R.style.Brush_OilPastel, R.style.Brush_Pastel,
                R.style.Brush_HardPastel, R.style.Brush_Creyon,
                R.style.Brush_Knife1, R.style.Brush_CombKnife, R.style.Brush_ColorlessOil,
                R.style.Brush_Finger, R.style.Brush_InkSpot,
                R.style.Brush_Flowers, R.style.Brush_Fish, R.style.Brush_Sponge)*/
        BRUSH_STYLES = intArrayOf(
            R.style.Brush_Bamboo1, R.style.Brush_Bamboo2, R.style.Brush_AirBrush,
            R.style.Brush_Pen, R.style.Brush_Calligraphy, R.style.Brush_HardPencil,
            R.style.Brush_SoftPencil, R.style.Brush_InkPen, R.style.Brush_BallpointPen,
            R.style.Brush_Oil, R.style.Brush_FeltPen, R.style.Brush_InkSpot,R.style.Brush_HardEraser)
    }
}