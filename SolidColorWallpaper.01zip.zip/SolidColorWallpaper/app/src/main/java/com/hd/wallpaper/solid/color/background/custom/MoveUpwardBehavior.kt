package com.hd.wallpaper.solid.color.background.custom

import android.view.View
import androidx.coordinatorlayout.widget.CoordinatorLayout
import com.google.android.material.snackbar.Snackbar

class MoveUpwardBehavior : CoordinatorLayout.Behavior<View>() {
    private var initialPositionY = 0f
    override fun layoutDependsOn(parent: CoordinatorLayout, child: View, dependency: View): Boolean {
        return SNACKBAR_BEHAVIOR_ENABLED && dependency is Snackbar.SnackbarLayout
    }

    override fun onDependentViewChanged(parent: CoordinatorLayout, child: View, dependency: View): Boolean {
        val translationY = Math.min(0f, dependency.translationY - dependency.height)
        initialPositionY = translationY
        child.translationY = translationY
        return true
    }

    override fun onDependentViewRemoved(parent: CoordinatorLayout, child: View, dependency: View) {
        //  super.onDependentViewRemoved(parent, child, dependency);
        child.translationY = dependency.height / 8.toFloat()
    }

    companion object {
        private const val SNACKBAR_BEHAVIOR_ENABLED = true
    }
}