package com.hd.wallpaper.solid.color.background.activity

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.ProgressDialog
import android.content.*
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import android.text.Layout
import android.util.Base64
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.wifiproxysettingslibrary.NetworkHelper
import com.wifiproxysettingslibrary.wifi_network.exceptions.ApiNotSupportedException
import com.wifiproxysettingslibrary.wifi_network.exceptions.NullWifiConfigurationException
import com.wifiproxysettingslibrary.wifi_network.wifi_proxy_changing_realisations.api_from_21_to_22.WifiConfiguration
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.app.ads.helper.RewardVideoHelper.isShowRewardVideoAd

import com.jaredrummler.android.colorpicker.ColorPickerDialog
import com.jaredrummler.android.colorpicker.ColorPickerDialogListener

import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.SolidWallpaperApplication
import com.hd.wallpaper.solid.color.background.activity.GifLiveWallPaper.Companion.TAG
import com.hd.wallpaper.solid.color.background.adapter.ColorCreateAdepter
import com.hd.wallpaper.solid.color.background.adapter.ColorCreateAdepter.setOnItemClickListener
import com.hd.wallpaper.solid.color.background.adapter.StickerAdapter
import com.hd.wallpaper.solid.color.background.adapter.StickerAdapter.OnItemClickListener
import com.hd.wallpaper.solid.color.background.constants.Constants
import com.hd.wallpaper.solid.color.background.custom.BottomSheetFragment
import com.hd.wallpaper.solid.color.background.custom.BottomSheetFragmentDiscard
import com.hd.wallpaper.solid.color.background.custom.MatrixClonable
import com.hd.wallpaper.solid.color.background.fragment.AddTextFragment
import com.hd.wallpaper.solid.color.background.fragment.AddTextFragment.Companion.newInstance
import com.hd.wallpaper.solid.color.background.fragment.BottomsheetStickerFragment
import com.hd.wallpaper.solid.color.background.imagePicker.ui.imagepicker.ImagePicker
import com.hd.wallpaper.solid.color.background.model.*
import com.hd.wallpaper.solid.color.background.model.StickerModel
import com.hd.wallpaper.solid.color.background.model.api.DataItem
import com.hd.wallpaper.solid.color.background.model.api.ImageItem
import com.hd.wallpaper.solid.color.background.model.api.Response
import com.hd.wallpaper.solid.color.background.newModel.ImagesItem
import com.hd.wallpaper.solid.color.background.newModel.WallpaperWeekModelNewResponse
import com.hd.wallpaper.solid.color.background.retrofit.APIClient.client
import com.hd.wallpaper.solid.color.background.retrofit.APIInterface
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs.getBoolean
import com.hd.wallpaper.solid.color.background.shared_pref.MySharedPref
import com.hd.wallpaper.solid.color.background.sqlite_database.DBHelper
import com.hd.wallpaper.solid.color.background.sqlite_database.DBHelperResolution
import com.hd.wallpaper.solid.color.background.sqlite_database.ResolutionExtractData
import com.xiaopo.flying.sticker.*
import com.xiaopo.flying.sticker.StickerView.OnStickerOperationListener
import retrofit2.Call
import retrofit2.Callback
import java.io.*
import java.lang.reflect.InvocationTargetException
import java.util.*
import kotlin.collections.ArrayList

class AddTextActivity : AppCompatActivity(), View.OnClickListener, ColorPickerDialogListener {
    private var imgColor: CardView? = null
    private var icBack: ImageView? = null
    private var icDone: ImageView? = null
    private var icClose: ImageView? = null
    private var btnNext: ImageView? = null
    private var btnAddColor1: ImageView? = null
    private var btnAddColor2: ImageView? = null
    private var imageRotate: ImageView? = null
    private var imageGradient: ImageView? = null
    private var layoutOpacity: LinearLayout? = null
    private var layoutStickerColor: LinearLayout? = null
    private var layoutSticker: LinearLayout? = null
    private var layoutImage: LinearLayout? = null
    private var layoutText: LinearLayout? = null
    private var btnCenterColor: LinearLayout? = null
    private var btnRotateColor: LinearLayout? = null
    private val colors = IntArray(2)
    private var isColor1 = false
    private var isColor2 = false
    private var orientation: GradientDrawable.Orientation? = GradientDrawable.Orientation.TOP_BOTTOM
    private var mCurrentOrientation = 0
    private var isCenter = false
    private var isCircle = false
    private var layoutRecycler: RelativeLayout? = null
    private var layoutColor: ConstraintLayout? = null
    private var addTextToolbar: ConstraintLayout? = null
    private var toolbar: ConstraintLayout? = null
    private var recyclerColor: RecyclerView? = null
    private var recyclerEmojiImage: RecyclerView? = null
    private var seekBarOpacity: SeekBar? = null
    private var mColors: ArrayList<Int>? = null
    private var progressBar: ProgressDialog? = null
    private var LayoutseekBarOpacity: LinearLayout? = null
    private var mSelectedColor = Color.WHITE
    private var isColor2Selected = false
    private var opacity = 15
    private var isEmojiSelected = false
    private var isColorSelected = false
    private var isimageSelect: Boolean = false
    private var stickerFragment: BottomsheetStickerFragment? = null
    private var receiver: Receiver? = null

    var bottomSheetFragment:BottomSheetFragmentDiscard?=null

    private var selectedColor = Color.parseColor("#EBEBEB")
    private var selectedColor2 = Color.parseColor("#EBEBEB")
    private var isProgressed = false
    private var recyclerSticker: RecyclerView? = null
    private var sticker_view: StickerView? = null
    private var mSelectedSticker: DrawableSticker? = null
    private var imgGradient: ImageView? = null
    private var imgNoneColor: ImageView? = null
    private var layoutStickerRecycler: ConstraintLayout? = null
    private var layoutColorRecycler: ConstraintLayout? = null
    private var btnHeaderText: TextView? = null
    private var layoutColorButton: LinearLayout? = null
    private var addTextFragment: AddTextFragment? = null
    private var isColorOpen=false
    private var isStickerOpen = false
    private var isStickerColorOpen = false
    private var isOpacityOpen = false
    private var colorAdepter: ColorCreateAdepter? = null
    private var layoutMoreAPI: LinearLayout? = null
    private var imgNoneSticker: ImageView? = null
    private var resolutionModel: ResolutionModel? = null
    private var mDataList: ArrayList<DataItem>? = null
    private val orientations = arrayOf(
            GradientDrawable.Orientation.TOP_BOTTOM,
            GradientDrawable.Orientation.TR_BL,
            GradientDrawable.Orientation.RIGHT_LEFT,
            GradientDrawable.Orientation.BR_TL,
            GradientDrawable.Orientation.BOTTOM_TOP,
            GradientDrawable.Orientation.BL_TR,
            GradientDrawable.Orientation.LEFT_RIGHT,
            GradientDrawable.Orientation.TL_BR
    )
    private lateinit var verticalView: View
    private lateinit var horizontalView: View

    private var btnColorLayout: LinearLayout? = null
//    private var cradientCancel: LinearLayout? = null
    private var btnNon: LinearLayout? = null
    private var mainBottomlayoutSelect: LinearLayout? = null

    private var mStickerList: ArrayList<String>? = null
    private var isStickerSelected = false
    private var mSelectedText: TextSticker? = null
    private var mSelectedDrawable: DrawableSticker? = null
    private var mSelectedStckr: Sticker? = null
    private var isFragmentLoaded = false
    private var isStickerEdited = false
    private var imgGallery: ImageView? = null
    private var imgForGallery: LinearLayout? = null

    // private RewardedAd gameOverRewardedAd, gameOverRewardedAd2, gameOverRewardedAd3;
    private var mySharedPref: MySharedPref? = null
    private var dbHelper: DBHelper? = null
    private var stickerAdapter: StickerAdapter? = null
    private var mAllStickers: ArrayList<StickerModel?>? = null
    private var mStickerModelList: ArrayList<StickerNewModel>? = null
    private var categoryNameListSticker: ArrayList<CategoryNameIconModel>? = null
    private var mAllReadyDataSticker: ArrayList<ArrayList<WallpaperWeekModel?>>? = null

    private var mForegroundListNewResponse: ArrayList<ImagesItem?>? = null

    private var mDataListNewResponseMain: ArrayList<com.hd.wallpaper.solid.color.background.newModel.DataItem>? = null

    private var mAllReadyDataStickerNewResponse: ArrayList<ArrayList<WallpaperWeekModelNewResponse?>>? = null


    private var isMoreAPIClicked = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_text)
        System.gc()
        receiver = Receiver()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            startActivity(Intent(this@AddTextActivity, MainStartActivity::class.java))
            finish()
        } else {
            initViews()
            initViewAction()
            initListner()
        }
        registerReceiver(receiver, IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"))
    }

    private fun initListner() {
//        cradientCancel!!.setOnClickListener(this)
        mainBottomlayoutSelect!!.setOnClickListener(this)
        imgGallery!!.setOnClickListener(this)
        btnNon!!.setOnClickListener(this)
        imgForGallery!!.setOnClickListener(this)
        btnColorLayout!!.setOnClickListener(this)
        icBack!!.setOnClickListener(this)
        btnNext!!.setOnClickListener(this)
        btnAddColor1!!.setOnClickListener(this)
        btnAddColor2!!.setOnClickListener(this)
        btnCenterColor!!.setOnClickListener(this)
        btnRotateColor!!.setOnClickListener(this)
        layoutSticker!!.setOnClickListener(this)
        layoutOpacity!!.setOnClickListener(this)
        layoutImage!!.setOnClickListener(this)
        layoutText!!.setOnClickListener(this)
        layoutStickerColor!!.setOnClickListener(this)
        layoutColorButton!!.setOnClickListener(this)
        icDone!!.setOnClickListener(this)
        icClose!!.setOnClickListener(this)
        layoutMoreAPI!!.setOnClickListener(this)
        imgNoneSticker!!.setOnClickListener(this)
        imgNoneColor!!.setOnClickListener(this)
    }

    private fun isNetworkConnected(): Boolean {
        val cm: ConnectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo()!!.isConnected()
    }

    private fun initViewAction() {
        layoutOpacity!!.alpha = 0.5f
        layoutSticker!!.alpha = 0.5f
        layoutText!!.alpha = 0.5f
        layoutStickerColor!!.alpha = 0.5f
//        btnColorLayout!!.alpha=0.5f
        imgForGallery!!.alpha=0.5f
        mAllStickers = ArrayList()
        mySharedPref = MySharedPref(this@AddTextActivity)
        dbHelper = DBHelper(this@AddTextActivity)
        Constants.mGalleryBitmap = null

        if (!getBoolean(this, AdsPrefs.IS_SUBSCRIBED, false)) {
            Constants.isInstrastial1 = false

            if (isNetworkConnected()) {
//                assert(instence != null)
//                Log.e(TAG, "initViewAction: connected")
//                try {
//                    if (instance != null) {
//                        instence!!.loadVideoAdMain(this@AddTextActivity)
//                    }
//                } catch (e: Exception) {
//                    e.printStackTrace()
//                }
            } else {
                Log.e(TAG, "initViewAction: not connected")

            }

        }
        mDataList = ArrayList()
        mDataListNewResponseMain = ArrayList()
        mForegroundListNewResponse = ArrayList()

        addTextFragment = AddTextFragment()
        try {
            checkStatus()
        } catch (e: InvocationTargetException) {
            e.printStackTrace()
        } catch (e: NoSuchMethodException) {
            e.printStackTrace()
        } catch (e: ApiNotSupportedException) {
            e.printStackTrace()
        } catch (e: NoSuchFieldException) {
            e.printStackTrace()
        } catch (e: IllegalAccessException) {
            e.printStackTrace()
        } catch (e: NullWifiConfigurationException) {
            callNewApi()
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        Constants.SOLID_CREATE_SELECTED_EMOJI_IMAGE = null
        Constants.SOLID_CREATE_SELECTED_EMOJI_IMAGE_COLOR = -1
        Constants.SOLID_CREATE_OPACITY = 1f
        MyEmojiList().execute()
        fetchColors()
        layoutColor!!.visibility = View.GONE
        layoutColorButton!!.visibility = View.VISIBLE
        btnHeaderText!!.text = resources.getString(R.string.create)
        layoutColorButton!!.alpha = 0.5f
        setStatusbarColor()
        onColor()
        layoutColor!!.visibility=View.VISIBLE
        btnColorLayout!!.alpha=1f
        val d = changeDrawableColor(this, R.drawable.ic_back_, resources.getColor(R.color.colorPrimary))
        icBack!!.setImageDrawable(d)
        seekBarOpacity!!.max = 255
        seekBarOpacity!!.progress = 255
        seekBarOpacity!!.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                if (isStickerSelected && sticker_view!!.handlingSticker != null) {
                    if (fromUser) {
                        opacity = seekBar.progress
                        if (opacity > 25) {
                            if (mSelectedStckr != null) {
                                if (mSelectedStckr is TextSticker) {
                                    (mSelectedStckr as TextSticker).alpha = opacity
                                } else {
                                    (mSelectedStckr as DrawableSticker).alpha = opacity
                                }
                                sticker_view!!.invalidate()
                            }
                        }
                    }
                } else {
                    Toast.makeText(this@AddTextActivity, resources.getString(R.string.toast_add_text_or_sticker_first), Toast.LENGTH_SHORT).show()
                    onclickSticker()
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })
        // openEmojiList();
        openColorList()
        onStickerChange()
        btnNext!!.isEnabled = false
        if (intent.extras != null) {
            layoutColorButton!!.visibility = View.GONE
            onclickSticker()
            resolutionModel = ResolutionExtractData(this@AddTextActivity).resolutionModelList[intent.extras!!.getInt("position")]
            colors[0] = resolutionModel!!.color1
            colors[1] = resolutionModel!!.color2
            if (resolutionModel!!.isCircle) {
                setCircleGradient(resolutionModel!!.isInner)
            } else {
                setGradientDrawable(resolutionModel!!.orientation)
            }
            addTextStickerNew()
            btnNext!!.alpha = 1f
            btnNext!!.isEnabled = true
            isProgressed = true
            isColorSelected = true
            selectedColor = resolutionModel!!.color1
            selectedColor2 = resolutionModel!!.color2
            isColor2Selected = true
            orientation = resolutionModel!!.orientation
            isCircle = resolutionModel!!.isCircle
        }


        //open by default add
        onClick(mainBottomlayoutSelect as View)

    }

    private fun addTextStickerNew() {
        for (i in resolutionModel!!.getmAllSticker()!!.indices) {
            val model = resolutionModel!!.getmAllSticker()!![i]
            if (model!!.isText) {
                val strk = TextSticker(this@AddTextActivity)
                strk.drawable = ContextCompat.getDrawable(this@AddTextActivity, R.drawable.sticker_transparent_background)!!
                strk.setTypeface(Typeface.createFromAsset(assets, model.typeface))
                strk.setTypeFace(model.typeface!!.split("/".toRegex()).toTypedArray()[1])
                strk.text = model.getText()
                strk.setTextColor(model.textColor)
                strk.setTextAlign(Layout.Alignment.ALIGN_CENTER)
                strk.alpha = model.textAlhpa
                strk.resizeText()
                sticker_view!!.addSticker(strk)
            } else {
                val sticker1 = DrawableSticker(model.drawable)
                sticker1.color = model.drawableColor
                sticker1.alpha = model.drawableAlpha
                sticker_view!!.addSticker(sticker1)
            }
        }
        sticker_view!!.post {
            for (i in sticker_view!!.stickers.indices) {
                val sticker = sticker_view!!.stickers[i]
                sticker.setMatrix(resolutionModel!!.getmAllSticker()!![i]!!.matrix)
            }
            sticker_view!!.invalidate()
            for (i in sticker_view!!.stickers.indices) {
                val sticker = sticker_view!!.stickers[i]
                if (sticker is TextSticker) {
                    val sclH = imgGradient!!.height.toFloat() / resolutionModel!!.mainHeight.toFloat()
                    val sclW = imgGradient!!.width.toFloat() / resolutionModel!!.mainWidth.toFloat()
                    val matrix = MatrixClonable()
                    matrix.set(sticker.getMatrix())
                    matrix.postScale(sclW, sclH)
                    sticker.setMatrix(matrix)
                } else {
                    val sclH = imgGradient!!.height.toFloat() / resolutionModel!!.mainHeight.toFloat()
                    val sclW = imgGradient!!.width.toFloat() / resolutionModel!!.mainWidth.toFloat()
                    val matrix = MatrixClonable()
                    matrix.set(sticker.matrix)
                    matrix.postScale(sclW, sclH)
                    sticker.setMatrix(matrix)
                }
            }
            sticker_view!!.invalidate()
        }
    }

    private fun initViews() {
        btnColorLayout = findViewById(R.id.btnColorLayout)
        imgGallery = findViewById(R.id.imgGallery)
        imgForGallery = findViewById(R.id.imgForGallery)
//        cradientCancel = findViewById(R.id.cradientCancel)
        mainBottomlayoutSelect = findViewById(R.id.mainBottomlayoutSelect)
        icBack = findViewById(R.id.icBack)
        btnNext = findViewById(R.id.btnNext)
        verticalView = findViewById(R.id.verticalView)
        horizontalView = findViewById(R.id.horizontalView)
        icClose = findViewById(R.id.icClose)
        icDone = findViewById(R.id.icDone)
        btnAddColor1 = findViewById(R.id.btnAddColor1)
        btnAddColor2 = findViewById(R.id.btnAddColor2)
        btnCenterColor = findViewById(R.id.btnCenterColor)
        btnRotateColor = findViewById(R.id.btnRotateColor)
        imgColor = findViewById(R.id.imgColor)
        imgColor!!.setCardBackgroundColor(Color.parseColor("#EBEBEB"))
        imageGradient = findViewById(R.id.imageGradient)
        imageRotate = findViewById(R.id.imageRotate)
        layoutRecycler = findViewById(R.id.layoutRecycler)
        layoutColor = findViewById(R.id.layoutColor)
        addTextToolbar = findViewById(R.id.addTextToolbar)
        toolbar = findViewById(R.id.toolbar)
        recyclerColor = findViewById(R.id.recyclerColor)
        recyclerEmojiImage = findViewById(R.id.recyclerEmojiImage)
        seekBarOpacity = findViewById(R.id.seekBarOpacity)
        LayoutseekBarOpacity = findViewById(R.id.LayoutseekBarOpacity)
        recyclerSticker = findViewById(R.id.recyclerSticker)
        layoutStickerRecycler = findViewById(R.id.layoutStickerRecycler)
        layoutColorRecycler = findViewById(R.id.layoutColorRecycler)
        sticker_view = findViewById(R.id.sticker_view)
        btnNon = findViewById(R.id.btnNon)
        imgGradient = findViewById(R.id.imgGradient)
        btnHeaderText = findViewById(R.id.btnHeaderText)
        layoutColorButton = findViewById(R.id.layoutColorButton)
        layoutImage = findViewById(R.id.layoutImage)
        layoutText = findViewById(R.id.layoutText)
        layoutOpacity = findViewById(R.id.layoutOpacity)
        layoutStickerColor = findViewById(R.id.layoutStickerColor)
        layoutSticker = findViewById(R.id.layoutSticker)
        imgNoneSticker = findViewById(R.id.imgNoneSticker)
        layoutMoreAPI = findViewById(R.id.layoutMoreAPI)
        imgNoneColor = findViewById(R.id.imgNoneColor)
    }

    fun changeIconDrawable() {
        val deleteIcon = BitmapStickerIcon(ContextCompat.getDrawable(this,
                com.xiaopo.flying.sticker.R.drawable.sticker_ic_close_white_18dp),
                BitmapStickerIcon.LEFT_TOP, resources.getDimension(R.dimen._12sdp))
        deleteIcon.iconEvent = DeleteIconEvent()
        val zoomIcon = BitmapStickerIcon(ContextCompat.getDrawable(this,
                com.xiaopo.flying.sticker.R.drawable.sticker_ic_scale_white_18dp),
                BitmapStickerIcon.RIGHT_BOTOM, resources.getDimension(R.dimen._12sdp))
        zoomIcon.iconEvent = ZoomIconEvent()
        val flipIcon = BitmapStickerIcon(ContextCompat.getDrawable(this,
                com.xiaopo.flying.sticker.R.drawable.sticker_ic_flip_white_18dp),
                BitmapStickerIcon.RIGHT_TOP, resources.getDimension(R.dimen._12sdp))
        flipIcon.iconEvent = FlipHorizontallyEvent()
        sticker_view!!.icons = Arrays.asList(deleteIcon, zoomIcon, flipIcon)
        sticker_view!!.invalidate()
        /*  Drawable drawable = AppCompatResources.getDrawable(this, R.drawable.team);

        DrawableSticker sticker=new DrawableSticker(drawable);
        sticker_view.addSticker(sticker);
        sticker_view.invalidate();*/
    }

    fun changeIconText() {
        val deleteIcon = BitmapStickerIcon(ContextCompat.getDrawable(this,
                com.xiaopo.flying.sticker.R.drawable.sticker_ic_close_white_18dp),
                BitmapStickerIcon.LEFT_TOP, resources.getDimension(R.dimen._12sdp))
        deleteIcon.iconEvent = DeleteIconEvent()

        val zoomIcon = BitmapStickerIcon(ContextCompat.getDrawable(this,
                com.xiaopo.flying.sticker.R.drawable.sticker_ic_scale_white_18dp),
                BitmapStickerIcon.RIGHT_BOTOM, resources.getDimension(R.dimen._12sdp))
        zoomIcon.iconEvent = ZoomIconEvent()

        val flipIcon = BitmapStickerIcon(ContextCompat.getDrawable(this,
                com.xiaopo.flying.sticker.R.drawable.sticker_ic_flip_white_18dp),
                BitmapStickerIcon.RIGHT_TOP, resources.getDimension(R.dimen._12sdp))
        flipIcon.iconEvent = FlipHorizontallyEvent()

        val editIcon = BitmapStickerIcon(ContextCompat.getDrawable(this,
                com.xiaopo.flying.sticker.R.drawable.ic_edit_sticker),
                BitmapStickerIcon.LEFT_BOTTOM, resources.getDimension(R.dimen._12sdp))
        editIcon.iconEvent = EditIconEvent()
        sticker_view!!.icons = Arrays.asList(deleteIcon, zoomIcon, flipIcon, editIcon)
        sticker_view!!.invalidate()
    }

    @Throws(InvocationTargetException::class, NoSuchMethodException::class, ApiNotSupportedException::class, NoSuchFieldException::class, IllegalAccessException::class, NullWifiConfigurationException::class)
    private fun checkStatus() {
        if (!NetworkHelper.isOnline(this)) {
            Log.d("TAG", "checkStatus: ")
        } else {
            if (NetworkHelper.isWifiConnected(this)) {
                val proxy = WifiConfiguration(this)
                if (proxy.isProxySetted) {
                    return
                }
            }
            if (NetworkHelper.isVpnRunning()) {
                return
            }
            callNewApi()
        }
    }


    fun callNewApi() {
        val apiInterface: APIInterface = client!!.create(APIInterface::class.java)

        val call: Call<com.hd.wallpaper.solid.color.background.newModel.Response?>? = apiInterface.doGetNewListResources()
        call!!.enqueue(object : Callback<com.hd.wallpaper.solid.color.background.newModel.Response?> {
            public override fun onResponse(call: Call<com.hd.wallpaper.solid.color.background.newModel.Response?>, response: retrofit2.Response<com.hd.wallpaper.solid.color.background.newModel.Response?>) {
                val model: com.hd.wallpaper.solid.color.background.newModel.Response? = response.body()
                mDataListNewResponseMain!!.clear()
                mForegroundListNewResponse!!.clear()
                if (model?.data != null) {
                    mDataListNewResponseMain!!.addAll(model.data)
                    dataForegroundNewResponse
                }
            }

            public override fun onFailure(call: Call<com.hd.wallpaper.solid.color.background.newModel.Response?>, t: Throwable) {
                mForegroundListNewResponse!!.clear()
            }
        })
    }

    fun callApi() {
        val apiInterface = client!!.create(APIInterface::class.java)
        val call = apiInterface.doGetListResources()
        call!!.enqueue(object : Callback<Response?> {
            override fun onResponse(call: Call<Response?>, response: retrofit2.Response<Response?>) {
                val model = response.body()
                mDataList!!.clear()
                if (model != null && model.data != null) {
                    mDataList!!.addAll(model.data)
                    dataForeground
                }
            }

            override fun onFailure(call: Call<Response?>, t: Throwable) {}
        })
    }// TODO: 29/02/20 For Sticker


    private val dataForegroundNewResponse: Unit
        private get() {

            for (i in mDataListNewResponseMain!!.indices) {
                if (mDataListNewResponseMain!!.get(i)!!.id == 4) {
                    mForegroundListNewResponse!!.addAll((mDataListNewResponseMain!!.get(i).images!!))
                }
            }

            var mTempForgroundList: ArrayList<WallpaperWeekModelNewResponse?>

            mAllReadyDataStickerNewResponse = ArrayList()
            if (mDataListNewResponseMain!!.size == 0) {
                return
            }
            categoryNameListSticker = ArrayList()


            for (i in mDataListNewResponseMain!!.indices) {
                mForegroundListNewResponse!!.clear()
                if (mDataListNewResponseMain!![i].name!! == "Sticker") {


                    for (j in mDataListNewResponseMain!![i].allChilds!!.indices) {
                        Log.e("TAG", "assaasdasadsas: ${mDataListNewResponseMain!![i].allChilds?.get(j)!!.name} ${mDataListNewResponseMain!![i].allChilds?.get(j)!!.icon}   ")
                        categoryNameListSticker!!.add(CategoryNameIconModel(mDataListNewResponseMain!![i].allChilds?.get(j)!!.name!!, mDataListNewResponseMain!![i].allChilds?.get(j)!!.icon.toString()))
                        mForegroundListNewResponse!!.addAll((mDataListNewResponseMain!![i].allChilds?.get(j)!!.images)!!)

                    }

                    val mWallpaperList1: ArrayList<WallpaperWeekModelNewResponse?> = ArrayList()
                    for (j in mForegroundListNewResponse!!.indices) {
                        mWallpaperList1.add(
                                WallpaperWeekModelNewResponse(
                                        mForegroundListNewResponse!![j],
                                        mForegroundListNewResponse!![j]!!.isPremium != 0,
                                        mForegroundListNewResponse!![j]!!.coins!!
                                )
                        )
                    }

                    mTempForgroundList = ArrayList()

                    if (getBoolean(this, AdsPrefs.IS_SUBSCRIBED, false)) {
                        for (j in mWallpaperList1.indices) {
                            mWallpaperList1[j]!!.isLocked = false
                        }
                        mTempForgroundList.addAll(mWallpaperList1)
                    } else {
                        for (k in mWallpaperList1.indices) {
                            val model: WallpaperWeekModelNewResponse? = mWallpaperList1[k]
                            if (dbHelper!!.checkPathExist((model!!.imageItem!!.image)!!)) {
                                model.isLocked = false
                            }
                            mTempForgroundList.add(model)
                        }
                    }
                    mTempForgroundList.shuffle()
                    mAllReadyDataStickerNewResponse!!.add(mTempForgroundList)

                }

            }

        }

    private val dataForeground: Unit
        private get() {
            var mTempForgroundList: ArrayList<WallpaperWeekModel?>
            mAllReadyDataSticker = ArrayList()
            val mForegroundList = ArrayList<ImageItem>()
            if (mDataList!!.size == 0) {
                return
            }
            categoryNameListSticker = ArrayList()
            for (i in mDataList!!.indices) {
                mForegroundList.clear()
                mForegroundList.addAll(mDataList!![i].image!!)
                val mWallpaperList1 = ArrayList<WallpaperWeekModel?>()
                for (j in mForegroundList.indices) {
                    mWallpaperList1.add(WallpaperWeekModel(mForegroundList[j], mForegroundList[j].isPremium != 0, mForegroundList[j].coins))
                }
                if (mDataList!![i].name!!.contains("_Sticker")) {
                    // TODO: 29/02/20 For Sticker
                    val name = mDataList!![i].name!!.split("_".toRegex()).toTypedArray()
                    if (name.size == 0) {
                        categoryNameListSticker!!.add(CategoryNameIconModel(mDataList!![i].name!!, mDataList!![i].icon.toString()))
                    } else {
                        categoryNameListSticker!!.add(CategoryNameIconModel(name[name.size - 1], mDataList!![i].icon.toString()))
                    }
                    mTempForgroundList = ArrayList()
                    if (getBoolean(this@AddTextActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                        for (j in mWallpaperList1.indices) {
                            mWallpaperList1[j]!!.isLocked = false
                        }
                        mTempForgroundList.addAll(mWallpaperList1)
                    } else {
                        for (k in mWallpaperList1.indices) {
                            val model = mWallpaperList1[k]
                            if (dbHelper!!.checkPathExist(model!!.imageItem!!.image!!)) {
                                model.isLocked = false
                            }
                            mTempForgroundList.add(model)
                        }
                    }
                    Collections.shuffle(mTempForgroundList)
                    mAllReadyDataSticker!!.add(mTempForgroundList)
                }
            }
        }

    private fun onStickerChange() {
        sticker_view!!.setBackgroundColor(Color.TRANSPARENT)
        sticker_view!!.isLocked = false
        sticker_view!!.isConstrained = true
        sticker_view!!.onStickerOperationListener = object : OnStickerOperationListener {
            override fun onStickerAdded(sticker: Sticker) {
                isStickerSelected = true
                btnNext!!.alpha = 1f
                btnNext!!.isEnabled = true
//                isProgressed = true
                seekBarOpacity!!.progress = sticker.alphaS
                if (sticker is TextSticker) {
                    mSelectedText = sticker
                    colorAdepter!!.setColor(mSelectedText!!.color)
                    changeIconText()
                } else {
                    changeIconDrawable()
                    mSelectedDrawable = sticker as DrawableSticker
                    colorAdepter!!.setColor(mSelectedDrawable!!.color)
                }
                mSelectedStckr = sticker
            }

            override fun onStickerClicked(sticker: Sticker) {
                if (verticalView.visibility.equals(View.VISIBLE)) {
                    verticalView.visibility = View.GONE
                }
                if (horizontalView.visibility.equals(View.VISIBLE)) {
                    horizontalView.visibility = View.GONE
                }
            }

            override fun onStickerDeleted(sticker: Sticker) {
                if (sticker_view!!.stickers.size == 0) {
                    isStickerSelected = false
//                    isProgressed = false
                    if (!isEmojiSelected && !isColorSelected) {
//                        btnNext!!.alpha = 0.5f
                        btnNext!!.alpha = 1f
                        btnNext!!.isEnabled = true
                    }
                }
                if (isStickerColorOpen || isOpacityOpen) {
                    layoutColorButton!!.alpha = 0.5f
                    layoutImage!!.alpha = 0.5f
                    layoutText!!.alpha = 0.5f
                    layoutOpacity!!.alpha = 0.5f
                    layoutSticker!!.alpha = 0.5f
                    layoutStickerColor!!.alpha = 0.5f
                    layoutColor!!.visibility = View.GONE
                    layoutRecycler!!.visibility = View.GONE
                    layoutColorRecycler!!.visibility = View.GONE
                    recyclerEmojiImage!!.visibility = View.GONE
                    layoutStickerRecycler!!.visibility = View.GONE
                    LayoutseekBarOpacity!!.visibility = View.GONE
                }
            }

            override fun onStickerDragFinished(sticker: Sticker) {
                verticalView.visibility = View.GONE
                horizontalView.visibility = View.GONE
            }

            override fun onStickerDrag(sticker: Sticker) {
                verticalView.visibility = View.VISIBLE
                horizontalView.visibility = View.VISIBLE
            }

            override fun onStickerTouchedDown(sticker: Sticker) {
                if (sticker is TextSticker) {
                    mSelectedText = sticker
                    try {
                        seekBarOpacity!!.progress = mSelectedText!!.alpha
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                    colorAdepter!!.setColor(mSelectedText!!.color)
                    changeIconText()
                } else {
                    changeIconDrawable()
                    mSelectedDrawable = sticker as DrawableSticker
                    try {
                        seekBarOpacity!!.progress = mSelectedDrawable!!.alpha
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                    colorAdepter!!.setColor(mSelectedDrawable!!.color)
                }
                mSelectedStckr = sticker
                if (isStickerColorOpen) {
                    onclickBrush()
                } else if (isOpacityOpen) {
                    onclickOpacity()
                }
            }

            override fun onStickerZoomFinished(sticker: Sticker) {}
            override fun onStickerFlipped(sticker: Sticker) {}
            override fun onStickerDoubleTapped(sticker: Sticker) {}
            override fun onStickerEditClick(sticker: Sticker) {
                addTextFragment = newInstance((sticker as TextSticker).text, sticker.typeface)
                isStickerEdited = false
                layoutColorButton!!.alpha = 0.5f
                layoutImage!!.alpha = 0.5f
                layoutText!!.alpha = 1f
                layoutOpacity!!.alpha = 0.5f
                layoutSticker!!.alpha = 0.5f
                layoutStickerColor!!.alpha = 0.5f
                isStickerEdited = true
                val ft = supportFragmentManager.beginTransaction()
                ft.add(R.id.frmTextFragment, addTextFragment!!)
                ft.commit()
                isFragmentLoaded = true
                imgColor!!.visibility = View.INVISIBLE
                toolbar!!.visibility = View.INVISIBLE
                addTextToolbar!!.visibility = View.VISIBLE
            }

            override fun onStickerReleased() {
                if (isStickerColorOpen || isOpacityOpen) {
                    layoutColorButton!!.alpha = 0.5f
                    layoutImage!!.alpha = 0.5f
                    layoutText!!.alpha = 0.5f
                    layoutOpacity!!.alpha = 0.5f
                    layoutSticker!!.alpha = 0.5f
                    layoutStickerColor!!.alpha = 0.5f
                    layoutColor!!.visibility = View.GONE
                    layoutRecycler!!.visibility = View.GONE
                    layoutColorRecycler!!.visibility = View.GONE
                    recyclerEmojiImage!!.visibility = View.GONE
                    layoutStickerRecycler!!.visibility = View.GONE
                    LayoutseekBarOpacity!!.visibility = View.GONE
                }
            }
        }
    }

    private fun fetchColors() {
        mColors = ArrayList()
        val allColors = resources.getStringArray(R.array.colors_text)
        for (allColor in allColors) {
            mColors!!.add(Color.parseColor(allColor))
        }
    }

    private fun openColorList() {
        val manager = LinearLayoutManager(this)
        manager.orientation = RecyclerView.HORIZONTAL
        recyclerColor!!.layoutManager = manager
        val listener: setOnItemClickListener = object : setOnItemClickListener {
            override fun OnItemClicked(color: Int, activity: Activity) {
                if (isStickerSelected && sticker_view!!.handlingSticker != null) {
                    mSelectedColor = color
                    if (mSelectedStckr != null) {
                        if (mSelectedStckr is DrawableSticker) {
                            val mSticker = mSelectedStckr as DrawableSticker
                            mSticker.color = color
                        } else {
                            val mStckr = mSelectedStckr as TextSticker
                            mStckr.setTextColor(color)
                        }
                        sticker_view!!.invalidate()
                    }
                } else {
                    Toast.makeText(this@AddTextActivity, resources.getString(R.string.toast_add_text_or_sticker_first), Toast.LENGTH_SHORT).show()
                    onclickSticker()
                }
            }
        }
        colorAdepter = ColorCreateAdepter(mColors!!, this, listener)
        recyclerColor!!.adapter = colorAdepter
    }

    private fun setStatusbarColor() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = Color.WHITE
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = Color.WHITE
        }
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.icBack -> onBackPressed()
            R.id.imgNoneSticker -> {
                sticker_view!!.removeAllStickers()
                sticker_view!!.invalidate()
                isStickerSelected = false
            }
            R.id.layoutMoreAPI -> if (!isMoreAPIClicked) {
                isMoreAPIClicked = true
                onClickMoreAPI()
            }
            R.id.imgNoneColor -> {
                mSelectedColor = Color.WHITE
                colorAdepter!!.setColor(mSelectedColor)
                if (mSelectedStckr != null) {
                    if (mSelectedStckr is DrawableSticker) {
                        val mSticker = mSelectedStckr as DrawableSticker
                        mSticker.color = mSelectedColor
                    } else {
                        val mStckr = mSelectedStckr as TextSticker
                        mStckr.setTextColor(mSelectedColor)
                    }
                    sticker_view!!.invalidate()
                }
            }
            R.id.imgForGallery -> onclickGallery()
            R.id.btnNext ->{
                mySharedPref!!.countExist = mySharedPref!!.countExist + 1
                Log.d("12345", "AddText btnNext : CLICK ${mySharedPref!!.countExist}")

//                    if (mainBottomlayoutSelect!!.visibility == View.VISIBLE) {
//                    findViewById<LinearLayout>(R.id.mainBottomLayout).visibility = View.GONE
                    findViewById<LinearLayout>(R.id.mainBottomlayoutSelect).visibility = View.VISIBLE
//                    findViewById<ConstraintLayout>(R.id.layoutColor).visibility = View.GONE
//                    imgForGallery!!.isEnabled = true
//                    btnColorLayout!!.isEnabled = true
//                    layoutColorButton!!.alpha = 0.5f
//                    layoutImage!!.alpha = 0.5f
//                    layoutOpacity!!.alpha = 0.5f
//                    layoutSticker!!.alpha = 0.5f
//                    layoutText!!.alpha = 0.5f
//                    layoutStickerColor!!.alpha = 0.5f

                 if (isColorSelected || isStickerSelected || isimageSelect) {
                    sticker_view!!.releaseSticker()
                    verticalView.visibility = View.GONE
                    horizontalView.visibility = View.GONE
//                    findViewById<LinearLayout>(R.id.mainBottomLayout).visibility = View.GONE
                    findViewById<LinearLayout>(R.id.mainBottomlayoutSelect).visibility = View.VISIBLE
//                    findViewById<ConstraintLayout>(R.id.layoutColor).visibility = View.GONE
                    Constants.mSavedBitmap = outputBitmap
                    Constants.isTextWallpaper = true
                    Constants.isText = true
                    val realImage = outputBitmap
                    val baos = ByteArrayOutputStream()
                    realImage.compress(Bitmap.CompressFormat.JPEG, 100, baos)
                    val b = baos.toByteArray()
                    val encodedImage = Base64.encodeToString(b, Base64.DEFAULT)
                    mySharedPref!!.image = encodedImage

                    mAllStickers!!.clear()
                    var i = 0
                    while (i < sticker_view!!.stickers.size) {
                        val mSticker = sticker_view!!.stickers[i]
                        var model: StickerModel? = null
                        if (mSticker is TextSticker) {
                            val strk = TextSticker(this@AddTextActivity)
                            //  strk.setMatrix(mSticker.getMatrix());
                            strk.drawable = mSticker.getDrawable()
                            strk.setTypeface(mSticker.originalTypeface)
                            strk.setTypeFace(mSticker.typeface)
                            strk.text = mSticker.text
                            strk.setTextColor(mSticker.color)
                            strk.setTextAlign(Layout.Alignment.ALIGN_CENTER)
                            try {
                                strk.alpha = mSticker.alpha
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                            strk.resizeText()
                            val matrix = MatrixClonable()
                            matrix.set(mSticker.getMatrix())
                            try {
                                model = StickerModel(matrix, true, strk.text, strk.typeface, strk.color, strk.alpha, null, 0, 0)
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        } else {
                            val sticker1 = DrawableSticker(mSticker.drawable)
                            //  sticker1.setMatrix(mSticker.getMatrix());
                            sticker1.color = (mSticker as DrawableSticker).color
                            try {
                                sticker1.alpha = mSticker.alpha
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                            val matrix = MatrixClonable()
                            matrix.set(mSticker.getMatrix())
                            try {
                                model = StickerModel(matrix, false, "", null, 0, 0, sticker1.drawable, sticker1.color, sticker1.alpha)
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }
                        mAllStickers!!.add(model)
                        i++
                    }
                    if (!isColor2Selected) {
                        selectedColor2 = selectedColor
                    }
                    sticker_view!!.isLocked = true
                    Constants.resolutionModel = ResolutionModel(mAllStickers, imgColor!!.width, imgColor!!.height, selectedColor, selectedColor2, isCircle, isCenter, orientation)
                    DBHelperResolution(this@AddTextActivity).insertResolutionModel(Constants.resolutionModel!!)

                    if (!getBoolean(this@AddTextActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                        isShowInterstitialAd{
                            startActivity(Intent(this@AddTextActivity, TextResolutionActivity::class.java))
                        }
                    } else {
                        val intent = Intent(this@AddTextActivity, TextResolutionActivity::class.java)
                        startActivity(intent)
                    }

                } else {
                    Toast.makeText(this, getString(R.string.select_color), Toast.LENGTH_SHORT).show()
                }
            }
            R.id.btnNon -> {
                Constants.mGalleryBitmap = null
                Constants.mGalleryUri = null

                imgGallery!!.setImageBitmap(null)

                selectedColor = Color.parseColor("#EBEBEB")
                selectedColor2 = Color.parseColor("#EBEBEB")

                btnAddColor1!!.setImageDrawable(resources.getDrawable(R.drawable.ic_gradient_select))
                btnAddColor2!!.setImageDrawable(resources.getDrawable(R.drawable.ic_gradient_select))


                colors[0] = selectedColor
                colors[1] = selectedColor2
                val shape: GradientDrawable = GradientDrawable()
                shape.setColor(selectedColor)
                imgGradient!!.setImageDrawable(shape)

                colors[0] = 0
                isProgressed = false
                isimageSelect = false
                isColor2Selected = false
                isColorSelected = false
                imgForGallery!!.isEnabled = true
                btnColorLayout!!.isEnabled = true

//                layoutColor!!.visibility = View.VISIBLE
            }
//            R.id.cradientCancel -> {
//                onBackPressed()
////                if(isProgressed) {
////                layoutColorButton!!.alpha = 0.5f
////                layoutImage!!.alpha = 0.5f
////                layoutOpacity!!.alpha = 0.5f
////                layoutSticker!!.alpha = 0.5f
////                layoutText!!.alpha = 0.5f
////                layoutStickerColor!!.alpha = 0.5f
////                findViewById<LinearLayout>(R.id.mainBottomLayout).visibility = View.VISIBLE
////                findViewById<LinearLayout>(R.id.mainBottomlayoutSelect).visibility = View.GONE
////                findViewById<ConstraintLayout>(R.id.layoutColor).visibility = View.GONE
////                imgForGallery!!.isEnabled = true
////                btnColorLayout!!.isEnabled = true
////                }else{
////                    showToast("Please select color/image")
////                }
//            }
            R.id.btnAddColor1 -> {
                isColor2 = false
                isColor1 = true
                openColorPicker(selectedColor)
            }
            R.id.btnAddColor2 -> if (colors[0] != 0) {
                isColor1 = false
                isColor2 = true
                openColorPicker(selectedColor2)
            } else {
                Toast.makeText(this, resources.getString(R.string.toast_choose_previous_color), Toast.LENGTH_SHORT).show()
            }
            R.id.btnCenterColor -> if (isColor2Selected) {
                setCenterDrawable()
                isCircle = true
            } else {
                Toast.makeText(this, resources.getString(R.string.toast_first_choose_both_colors), Toast.LENGTH_SHORT).show()
            }
            R.id.btnRotateColor -> if (isColor2Selected) {
                onclickRotateColor()
                isCircle = false
            } else {
                Toast.makeText(this, resources.getString(R.string.toast_first_choose_both_colors), Toast.LENGTH_SHORT).show()
            }
            R.id.btnColorLayout ->onColor()
            R.id.layoutStickerColor -> onclickBrush()
            R.id.layoutImage -> oncliEmoji()
            R.id.layoutOpacity -> onclickOpacity()
            R.id.layoutSticker -> onclickSticker()
            R.id.layoutText -> if (!isFragmentLoaded) {
                onclickText()
            }
            R.id.icClose -> {
                removeFragment()
                when {
                    isColorOpen -> {
                        onColor()
                    }
                    isOpacityOpen -> {
                        onclickOpacity()
                    }
                    isStickerOpen -> {
                        onclickSticker()
                    }
                    isStickerColorOpen -> {
                        onclickBrush()
                    }
                    else -> {
                        layoutColorButton!!.alpha = 0.5f
                        layoutImage!!.alpha = 0.5f
                        layoutOpacity!!.alpha = 0.5f
                        layoutSticker!!.alpha = 0.5f
                        layoutText!!.alpha = 0.5f
                        layoutStickerColor!!.alpha = 0.5f
                    }
                }
            }
            R.id.icDone -> if (Constants.stickerText!!.isNotEmpty()) {
                removeFragment()
                addTextSticker()
                when {
                    isColorOpen->{
                        onColor()
                    }
                    isOpacityOpen -> {
                        onclickOpacity()
                    }
                    isStickerOpen -> {
                        onclickSticker()
                    }
                    isStickerColorOpen -> {
                        onclickBrush()
                    }
                    else -> {
                        layoutColorButton!!.alpha = 0.5f
                        layoutImage!!.alpha = 0.5f
                        layoutOpacity!!.alpha = 0.5f
                        layoutSticker!!.alpha = 0.5f
                        layoutText!!.alpha = 0.5f
                        layoutStickerColor!!.alpha = 0.5f
                    }
                }
            } else {
                Toast.makeText(this, resources.getString(R.string.toast_add_some_text), Toast.LENGTH_SHORT).show()
            }

            R.id.layoutColorButton -> {
                removeFragment()
                layoutColorButton!!.alpha = 0.5f
                layoutImage!!.alpha = 0.5f
                layoutOpacity!!.alpha = 0.5f
                layoutSticker!!.alpha = 0.5f
                layoutText!!.alpha = 0.5f
                layoutStickerColor!!.alpha = 0.5f
                isStickerColorOpen = false
                isStickerOpen = false
                isOpacityOpen = false
                isFragmentLoaded = false

                layoutColorRecycler!!.visibility = View.GONE
                recyclerEmojiImage!!.visibility = View.GONE
                layoutStickerRecycler!!.visibility = View.GONE
                LayoutseekBarOpacity!!.visibility = View.GONE
                layoutRecycler!!.visibility = View.GONE
                layoutColor!!.visibility = View.GONE
                imgForGallery!!.isEnabled = true
                btnColorLayout!!.isEnabled = true
                findViewById<LinearLayout>(R.id.mainBottomLayout).visibility = View.GONE
                findViewById<LinearLayout>(R.id.mainBottomlayoutSelect).visibility = View.VISIBLE
            }
        }
    }

    private fun onColor() {
            removeFragment()
            layoutColorButton!!.alpha = 0.5f
            layoutImage!!.alpha = 0.5f
            layoutOpacity!!.alpha = 0.5f
            layoutSticker!!.alpha = 0.5f
            layoutText!!.alpha = 0.5f
            layoutStickerColor!!.alpha = 0.5f
            btnColorLayout!!.alpha=1f
            imgForGallery!!.alpha=0.5f
            imgForGallery!!.isEnabled = true
            btnColorLayout!!.isEnabled = true

            isStickerColorOpen = false
            isStickerOpen = false
            isOpacityOpen = false
            isFragmentLoaded = false
            isColorOpen=true
            layoutColor!!.visibility=View.VISIBLE
//                recyclerColor!!.visibility=View.VISIBLE
            layoutRecycler!!.visibility = View.GONE
            layoutColorRecycler!!.visibility = View.GONE
//                layoutEmojiRecycler!!.visibility = View.GONE
            layoutStickerRecycler!!.visibility = View.GONE
            LayoutseekBarOpacity!!.visibility = View.GONE

//                layoutColor!!.visibility = View.GONE
//                layoutRecycler!!.visibility = View.VISIBLE
//                layoutColorRecycler!!.visibility = View.GONE
//                recyclerEmojiImage!!.visibility = View.GONE
//                layoutStickerRecycler!!.visibility = View.VISIBLE
//                LayoutseekBarOpacity!!.visibility = View.GONE
    }

    private fun onclickGallery() {
//        layoutColor!!.alpha = 0.5f
//        layoutImage!!.alpha = 0.5f
//        layoutOpacity!!.alpha = 0.5f
//        layoutSticker!!.alpha = 0.5f
//        layoutStickerColor!!.alpha = 0.5f
//        btnColorLayout!!.alpha=0.5f
//        imgForGallery!!.alpha=1f

        btnNext!!.alpha = 1f
        btnNext!!.isEnabled = true

        imgForGallery!!.isEnabled = false
        btnColorLayout!!.isEnabled = true
//        layoutColor!!.visibility = View.GONE
//        layoutRecycler!!.visibility = View.GONE
//        layoutStickerRecycler!!.visibility = View.GONE
//        layoutColorRecycler!!.visibility = View.GONE
//        recyclerEmojiImage!!.visibility = View.GONE
//        LayoutseekBarOpacity!!.visibility = View.GONE

//        isColor2Selected = false

        ImagePicker.with(this)
            .setFolderMode(true)
            .setFolderTitle("Album")
            .setMultipleMode(false)
            .setImageCount(1)
            .setMaxSize(10)
            .setBackgroundColor("#ffffff")
            .setAlwaysShowDoneButton(true)
            .setRequestCode(1111)
            .setKeepScreenOn(true)
            .start()
    }

    private fun showFB() {
        if (!getBoolean(this@AddTextActivity, AdsPrefs.IS_SUBSCRIBED, false)) {

            isShowInterstitialAd{
                val intent = Intent(this@AddTextActivity, TextResolutionActivity::class.java)
                startActivity(intent)
            }
        } else {
            val intent = Intent(this@AddTextActivity, TextResolutionActivity::class.java)
            startActivity(intent)
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1111) {
            imgForGallery!!.isEnabled = true
            btnColorLayout!!.isEnabled = true
            if (Constants.mGalleryBitmap != null) {
                try {
                    selectedColor = Color.parseColor("#EBEBEB")
                    selectedColor2 = Color.parseColor("#EBEBEB")
                    colors[0] = selectedColor
                    colors[1] = selectedColor2
                    imgGallery!!.setImageBitmap(Constants.mGalleryBitmap)
                    btnNext!!.isEnabled = true
                    btnNext!!.alpha = 1f
                    isProgressed = true
                    isimageSelect = true
                    btnAddColor1!!.setImageDrawable(resources.getDrawable(R.drawable.ic_gradient_select))
                    btnAddColor2!!.setImageDrawable(resources.getDrawable(R.drawable.ic_gradient_select))
//                    onClick(cradientCancel as View)
                } catch (e: Exception) {

                }

            }
        }
    }

    fun makebyte(modeldata: ResolutionModel?): ByteArray? {
        try {
            val baos = ByteArrayOutputStream()
            val oos = ObjectOutputStream(baos)
            oos.writeObject(modeldata)
            return baos.toByteArray()
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return null
    }

    fun read(data: ByteArray?): ResolutionModel? {
        try {
            val baip = ByteArrayInputStream(data)
            val ois = ObjectInputStream(baip)
            return ois.readObject() as ResolutionModel
        } catch (e: IOException) {
            e.printStackTrace()
        } catch (e: ClassNotFoundException) {
            e.printStackTrace()
        }
        return null
    }

    private fun showGoogleAdHome() {

        isShowInterstitialAd{
            val intent = Intent(this@AddTextActivity, TextResolutionActivity::class.java)
            startActivity(intent)

        }

    }

    private fun onClickMoreAPI() {
/*        BottomsheetStickerFragment.OnItemSelected onItemSelected = new BottomsheetStickerFragment.OnItemSelected() {
            @Override
            public void onItemSelected(String path) {
                if (path != null) {
                    isStickerSelected = true;
                    mSelectedEmojiPosition = -1;
                    Glide.with(AddTextActivity.this).load(path).into(new CustomTarget<Drawable>() {
                        @Override
                        public void onResourceReady(@NonNull Drawable resource, @Nullable Transition<? super Drawable> transition) {
                            mSelectedSticker = new DrawableSticker(resource);
                            mDrawableStickerList.add(mSelectedSticker);
                            mSelectedSticker.setColor(Color.WHITE);
                            sticker_view.addSticker(mSelectedSticker);
                            sticker_view.invalidate();
                        }

                        @Override
                        public void onLoadCleared(@Nullable Drawable placeholder) {

                        }
                    });
                }
            }
        };

        if (selectedColor2 == Color.parseColor("#EBEBEB")) {
            stickerFragment = new BottomsheetStickerFragment(mStickerLiveList, mTempStickerList, selectedColor, selectedColor, orientation, onItemSelected, mSelectedColor);
        } else {
            stickerFragment = new BottomsheetStickerFragment(mStickerLiveList, mTempStickerList, selectedColor, selectedColor2, orientation, onItemSelected, mSelectedColor);
        }*/
        if (!NetworkHelper.isOnline(this)) {
            isMoreAPIClicked = false
            Toast.makeText(this, resources.getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show()
            return
        }
        if (isFinishing) {
            return
        }
        val onItemSelected: BottomsheetStickerFragment.OnItemSelected = object : BottomsheetStickerFragment.OnItemSelected {
            override fun onItemSelected(path: String?) {
                if (path != null) {
                    isStickerSelected = true
                    Glide.with(this@AddTextActivity).load(path).into(object : CustomTarget<Drawable?>() {
                        override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                            mSelectedSticker = DrawableSticker(resource)
                            mSelectedSticker!!.color = Color.WHITE
                            sticker_view!!.addSticker(mSelectedSticker!!)
                            sticker_view!!.invalidate()
                        }

                        override fun onLoadCleared(placeholder: Drawable?) {}
                    })
                }
            }

            override fun onDismiss() {
                isMoreAPIClicked = false
            }
        }
        if (!NetworkHelper.isOnline(this)) {
            isMoreAPIClicked = false
            Toast.makeText(this, resources.getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show()
            return
        }
        else{
            stickerFragment = BottomsheetStickerFragment(this, mAllReadyDataStickerNewResponse, categoryNameListSticker, onItemSelected)
            stickerFragment!!.show(supportFragmentManager, "forground_frag")
        }
    }

    private fun addTextSticker() {
        if (!isStickerEdited) {
            val sticker = TextSticker(this)
            sticker.drawable = ContextCompat.getDrawable(applicationContext, R.drawable.sticker_transparent_background)!!
            sticker.text = Constants.stickerText
            sticker.setTextColor(Color.BLACK)
            if (Constants.stickerTypeface!!.contains("fonts_neon")) {
                sticker.setTypeface(Typeface.createFromAsset(assets, Constants.stickerTypeface))
            } else {
                sticker.setTypeface(Typeface.createFromFile(Constants.stickerTypeface))
            }
            sticker.setTypeFace(Constants.stickerTypeface)
            sticker.setTextAlign(Layout.Alignment.ALIGN_CENTER)
            sticker.resizeText()
            mSelectedText = sticker
            sticker_view!!.addSticker(sticker)
        } else {
            mSelectedText!!.text = Constants.stickerText
            if (Constants.stickerTypeface!!.contains("fonts_neon")) {
                mSelectedText!!.setTypeface(Typeface.createFromAsset(assets, Constants.stickerTypeface))
            } else {
                mSelectedText!!.setTypeface(Typeface.createFromFile(Constants.stickerTypeface))
            }
            mSelectedText!!.setTypeFace(Constants.stickerTypeface)
            mSelectedText!!.resizeText()
            sticker_view!!.replace(mSelectedText)
        }
        sticker_view!!.invalidate()
    }

    private fun onclickText() {
        layoutText!!.isEnabled = true
        isStickerEdited = false
        layoutColorButton!!.alpha = 0.5f
        layoutImage!!.alpha = 0.5f
        layoutText!!.alpha = 1f
        layoutOpacity!!.alpha = 0.5f
        layoutSticker!!.alpha = 0.5f
        layoutStickerColor!!.alpha = 0.5f
        if (isFinishing) {
            return
        }
        addTextFragment = newInstance(null, null)
        val ft = supportFragmentManager.beginTransaction()
        ft.add(R.id.frmTextFragment, addTextFragment!!)
        ft.commit()
        isFragmentLoaded = true
        imgColor!!.visibility = View.INVISIBLE
        toolbar!!.visibility = View.INVISIBLE
        addTextToolbar!!.visibility = View.VISIBLE

        layoutColor!!.visibility = View.INVISIBLE
        layoutRecycler!!.visibility = View.INVISIBLE
        layoutColorRecycler!!.visibility = View.INVISIBLE
        recyclerEmojiImage!!.visibility = View.INVISIBLE
        layoutStickerRecycler!!.visibility = View.INVISIBLE
        LayoutseekBarOpacity!!.visibility = View.INVISIBLE

    }

    private fun removeFragment() {
        try {
            layoutText!!.isEnabled = true
            supportFragmentManager.beginTransaction()
                    .remove(addTextFragment!!)
                    .commitAllowingStateLoss()
            layoutText!!.alpha = 0.5f
            imgColor!!.visibility = View.VISIBLE
            toolbar!!.visibility = View.VISIBLE
            addTextToolbar!!.visibility = View.GONE
            isFragmentLoaded = false
            hideKeyboard(this)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // colorView.draw(canvas);
// sticker_view.draw(canvas);
    private val outputBitmap: Bitmap
        private get() {
            System.gc()
            Runtime.getRuntime().gc()
//            imgColor!!.setCardBackgroundColor(Color.TRANSPARENT)
            imgColor!!.setCardBackgroundColor(Color.parseColor("#EBEBEB"))
            val bitmap = Bitmap.createBitmap(imgColor!!.width, imgColor!!.height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            // colorView.draw(canvas);
            imgColor!!.draw(canvas)
            // sticker_view.draw(canvas);
            return bitmap
        }

    private fun onclickSticker() {
        removeFragment()
        layoutColorButton!!.alpha = 0.5f
        layoutImage!!.alpha = 0.5f
        layoutOpacity!!.alpha = 0.5f
        layoutText!!.alpha = 0.5f
        layoutSticker!!.alpha = 1f
        layoutStickerColor!!.alpha = 0.5f
        btnColorLayout!!.alpha=0.5f
        imgForGallery!!.alpha=0.5f
        isStickerColorOpen = false
        isStickerOpen = true
        isOpacityOpen = false
        isFragmentLoaded = false
        isColorOpen=false
        layoutColor!!.visibility = View.GONE
        layoutRecycler!!.visibility = View.VISIBLE
        layoutColorRecycler!!.visibility = View.GONE
        recyclerEmojiImage!!.visibility = View.GONE
        layoutStickerRecycler!!.visibility = View.VISIBLE
        LayoutseekBarOpacity!!.visibility = View.GONE

//        btnNext!!.alpha = 1f
//        btnNext!!.isEnabled = true
    }

    private fun onclickOpacity() {
        removeFragment()
        if (isStickerSelected && sticker_view!!.handlingSticker != null) {
            layoutColorButton!!.alpha = 0.5f
            layoutImage!!.alpha = 0.5f
            layoutOpacity!!.alpha = 1f
            layoutText!!.alpha = 0.5f
            layoutSticker!!.alpha = 0.5f
            layoutStickerColor!!.alpha = 0.5f
            btnColorLayout!!.alpha=0.5f
            imgForGallery!!.alpha=0.5f
            isStickerColorOpen = false
            isStickerOpen = false
            isOpacityOpen = true
            isFragmentLoaded = false
            layoutColor!!.visibility = View.GONE
            layoutRecycler!!.visibility = View.VISIBLE
            layoutStickerRecycler!!.visibility = View.GONE
            layoutColorRecycler!!.visibility = View.GONE
            recyclerEmojiImage!!.visibility = View.GONE
            LayoutseekBarOpacity!!.visibility = View.VISIBLE
        } else {
            Toast.makeText(this, resources.getString(R.string.toast_add_text_or_sticker_first), Toast.LENGTH_SHORT).show()
            onclickSticker()
        }
    }

    private fun onclickBrush() {
        removeFragment()
        if (isStickerSelected && sticker_view!!.handlingSticker != null) {
            layoutColorButton!!.alpha = 0.5f
            layoutImage!!.alpha = 0.5f
            layoutText!!.alpha = 0.5f
            layoutOpacity!!.alpha = 0.5f
            layoutSticker!!.alpha = 0.5f
            layoutStickerColor!!.alpha = 1f
            btnColorLayout!!.alpha=0.5f
            imgForGallery!!.alpha=0.5f

            layoutColor!!.visibility = View.GONE
            layoutRecycler!!.visibility = View.VISIBLE
            layoutColorRecycler!!.visibility = View.VISIBLE
            recyclerEmojiImage!!.visibility = View.GONE
            layoutStickerRecycler!!.visibility = View.GONE
            LayoutseekBarOpacity!!.visibility = View.GONE
            isStickerColorOpen = true
            isStickerOpen = false
            isOpacityOpen = false
            isFragmentLoaded = false
            isColorOpen=false
        } else {
            Toast.makeText(this, resources.getString(R.string.toast_add_text_or_sticker_first), Toast.LENGTH_SHORT).show()
            onclickSticker()
        }
    }

    private fun oncliEmoji() {
        layoutColorButton!!.alpha = 0.5f
        layoutImage!!.alpha = 1f
        layoutText!!.alpha = 0.5f
        layoutOpacity!!.alpha = 0.5f
        layoutSticker!!.alpha = 0.5f
        layoutStickerColor!!.alpha = 0.5f
        layoutColor!!.visibility = View.GONE
        layoutRecycler!!.visibility = View.VISIBLE
        layoutColorRecycler!!.visibility = View.GONE
        recyclerEmojiImage!!.visibility = View.VISIBLE
        layoutStickerRecycler!!.visibility = View.GONE
        LayoutseekBarOpacity!!.visibility = View.GONE
    }

    private fun setCenterDrawable() {
        if (isCenter) {
            imageRotate!!.setPadding(resources.getDimension(R.dimen._4sdp).toInt(), resources.getDimension(R.dimen._4sdp).toInt(), resources.getDimension(R.dimen._4sdp).toInt(), resources.getDimension(R.dimen._4sdp).toInt())
            imageRotate!!.setImageDrawable(resources.getDrawable(R.drawable.ic_rotate_gradient_new))
        } else {
            imageRotate!!.setPadding(resources.getDimension(R.dimen._4sdp).toInt(), resources.getDimension(R.dimen._4sdp).toInt(), resources.getDimension(R.dimen._4sdp).toInt(), resources.getDimension(R.dimen._4sdp).toInt())
            imageRotate!!.setImageDrawable(resources.getDrawable(R.drawable.ic_circle_gradient_new))
        }
        setCircleGradient(isCenter)
    }

    private fun onclickRotateColor() {
        imageGradient!!.rotation = imageGradient!!.rotation + 45
        mCurrentOrientation = (mCurrentOrientation + 1) % orientations.size
        orientation = orientations[mCurrentOrientation]
        setGradientDrawable(orientation)
    }

    private fun openColorPicker(selectedColor2: Int) {
        if (isColor1) {
            ColorPickerDialog.newBuilder()
                    .setDialogType(ColorPickerDialog.TYPE_PRESETS)
                    .setAllowPresets(false)
                    .setDialogId(0)
                    .setColor(selectedColor2)
                    .setShowAlphaSlider(true)
                    .show(this)
        } else {
            ColorPickerDialog.newBuilder()
                    .setDialogType(ColorPickerDialog.TYPE_PRESETS)
                    .setAllowPresets(false)
                    .setDialogId(1)
                    .setColor(selectedColor2)
                    .setShowAlphaSlider(true)
                    .show(this)
        }
    }

    override fun onBackPressed() {
//           if (mainBottomlayoutSelect!!.visibility == View.VISIBLE) {
//            if(isProgressed) {
            findViewById<LinearLayout>(R.id.mainBottomLayout).visibility = View.GONE
            findViewById<LinearLayout>(R.id.mainBottomlayoutSelect).visibility = View.VISIBLE
//            findViewById<ConstraintLayout>(R.id.layoutColor).visibility = View.GONE
//            imgForGallery!!.isEnabled = true
//            btnNext!!.isEnabled = true
//            btnColorLayout!!.isEnabled = true
//            layoutColorButton!!.alpha = 0.5f
//            layoutImage!!.alpha = 0.5f
//            layoutOpacity!!.alpha = 0.5f
//            layoutSticker!!.alpha = 0.5f
//            layoutText!!.alpha = 0.5f
//            layoutStickerColor!!.alpha = 0.5f
            btnNext!!.alpha = 1f
//            }else{
//                showToast("Please select color/image")
//            }
//        } else {
            if (isFragmentLoaded) {
                removeFragment()
                when {
                    isOpacityOpen -> {
                        onclickOpacity()
                    }
                    isStickerOpen -> {
                        onclickSticker()
                    }
                    isStickerColorOpen -> {
                        onclickBrush()
                    }
                    isColorOpen->
                    {
                        onColor()
                    }
                }
            //                else {
//                    layoutColorButton!!.alpha = 0.5f
//                    layoutImage!!.alpha = 0.5f
//                    layoutOpacity!!.alpha = 0.5f
//                    layoutSticker!!.alpha = 0.5f
//                    layoutText!!.alpha = 0.5f
//                    layoutStickerColor!!.alpha = 0.5f
//                }
            } else if (isProgressed || isEmojiSelected || isStickerSelected) {
                showAlertDialog()
            } else {
                finish()
            }
//        }
//        }
    }

    override fun onColorSelected(dialogId: Int, color: Int) {
        isColorSelected = true
        isProgressed = true
        imgGradient!!.setImageDrawable(null)
        if (Constants.mGalleryBitmap != null && !Constants.mGalleryBitmap!!.isRecycled) {
            Constants.mGalleryBitmap!!.recycle()
            Constants.mGalleryBitmap = null
        }
        imgGallery!!.setImageBitmap(null)
        if (isColor1) {
            selectedColor = color
            colors[0] = color
            if (!isColor2Selected) {
                colors[1] = color
                btnCenterColor!!.alpha = 0.5f
                btnRotateColor!!.alpha = 0.5f
                btnNext!!.alpha = 1f
                btnNext!!.isEnabled = true
            }
            val shape = GradientDrawable()
            shape.shape = GradientDrawable.RECTANGLE
            shape.setColor(color)
            shape.cornerRadius = 18f
            shape.setStroke(3, Color.BLACK)
            btnAddColor1!!.setImageDrawable(shape)
        } else {
            isColor2Selected = true
            selectedColor2 = color
            colors[1] = color
            val shape = GradientDrawable()
            shape.shape = GradientDrawable.RECTANGLE
            shape.setColor(color)
            shape.cornerRadius = 18f
            shape.setStroke(3, Color.BLACK)
            btnAddColor2!!.setImageDrawable(shape)
        }
        btnAddColor2!!.alpha = 1f
        setGradientDrawable(orientation)
        if (isColor2) {
            btnNext!!.isEnabled = true
            btnNext!!.alpha = 1f
            btnRotateColor!!.alpha = 1f
            btnCenterColor!!.alpha = 1f
        }
    }

    private fun setGradientDrawable(orientation: GradientDrawable.Orientation?) {
        val shape = GradientDrawable(orientation, colors)
        shape.shape = GradientDrawable.RECTANGLE
        imgGradient!!.background = shape
    }

    private fun setCircleGradient(isInner: Boolean) {
        if (isInner) {
            val new_colors = intArrayOf(colors[1], colors[0])
            val shape = GradientDrawable()
            shape.shape = GradientDrawable.RECTANGLE
            shape.colors = new_colors
            shape.gradientType = GradientDrawable.RADIAL_GRADIENT
            shape.gradientRadius = imgColor!!.width.toFloat()
            imgGradient!!.background = shape
            isCenter = false
        } else {
            val shape = GradientDrawable()
            shape.shape = GradientDrawable.RECTANGLE
            shape.colors = colors
            shape.gradientType = GradientDrawable.RADIAL_GRADIENT
            shape.gradientRadius = imgColor!!.width.toFloat()
            imgGradient!!.background = shape
            isCenter = true
        }
    }

    override fun onDialogDismissed(dialogId: Int) {}

    @SuppressLint("StaticFieldLeak")
    internal inner class MyEmojiList : AsyncTask<Void?, Void?, Void?>() {
        override fun onPreExecute() {
            super.onPreExecute()
            progressBar = ProgressDialog(this@AddTextActivity)
            progressBar!!.setMessage(resources.getString(R.string.dialog_msg_please_wait))
            progressBar!!.setCancelable(false)
            progressBar!!.show()
        }

        override fun onPostExecute(aVoid: Void?) {
            super.onPostExecute(aVoid)
            Collections.sort(mStickerList)
            mStickerModelList = ArrayList()
            for (i in mStickerList!!.indices) {
                mStickerModelList!!.add(StickerNewModel(mStickerList!![i], true))
            }
            if (!getBoolean(this@AddTextActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                /*for (i in mStickerList!!.indices) {
                    if ((i + 1) % 5 == 0 && !dbHelper!!.checkPathExist(mStickerList!![i])) {
                        mStickerModelList!![i].isFree = false
                    }
                }*/
            }
            openStickerList()
            progressBar!!.dismiss()
        }

        protected override fun doInBackground(vararg params: Void?): Void? {
            mStickerList = ArrayList()
            try {
                val files1 = this@AddTextActivity.assets.list("stickers")!!
                for (name in files1) {
                    mStickerList!!.add("file:///android_asset/stickers" + File.separator + name)
                    Glide.with(this@AddTextActivity).asBitmap().load("file:///android_asset/stickers" + File.separator + name).into(object : CustomTarget<Bitmap?>() {
                        override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap?>?) {}
                        override fun onLoadCleared(placeholder: Drawable?) {}
                    })
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
            return null
        }
    }

    private fun openStickerList() {
        val manager = LinearLayoutManager(this)
        manager.orientation = RecyclerView.HORIZONTAL
        recyclerSticker!!.layoutManager = manager
        val onItemClickListener: OnItemClickListener = label@ object : OnItemClickListener {
            override fun onItemClick(view: View?, position: Int, context: Activity) {
                if (!mStickerModelList!![position].isFree) {
                    if (!NetworkHelper.isOnline(this@AddTextActivity)) {
                        Toast.makeText(this@AddTextActivity, resources.getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show()
                        return
                    }

                    showAdDialog(position)

                } else {
                    isEmojiSelected = false
                    Glide.with(this@AddTextActivity).load(mStickerList!![position]).into(object : CustomTarget<Drawable?>() {
                        override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                            mSelectedSticker = DrawableSticker(resource)
                            mSelectedSticker!!.color = Color.WHITE
                            sticker_view!!.addSticker(mSelectedSticker!!)
                            sticker_view!!.invalidate()
                        }

                        override fun onLoadCleared(placeholder: Drawable?) {}
                    })
                }
            }
        }
        stickerAdapter = StickerAdapter(this@AddTextActivity, mStickerModelList!!, onItemClickListener, true)
        recyclerSticker!!.adapter = stickerAdapter
    }

    private fun showAdDialog(position: Int) {
        val bottomSheetFragment = BottomSheetFragment(resources.getString(R.string.watch_video), resources.getString(R.string.wathch_video_to_unlock_sticker), resources.getString(R.string.watch), resources.getString(R.string.cancel), R.drawable.ic_video, object : BottomSheetFragment.OnButtonClickListener {
            override fun onPositive(bottomSheetDialo: BottomSheetFragment?) {
                bottomSheetDialo!!.dismiss()

                isShowRewardVideoAd(
                    onStartToLoadRewardVideoAd = {

                    },
                    onUserEarnedReward = { isUserEarnedReward ->

                        if(isUserEarnedReward) {

                            isEmojiSelected = false
                            Glide.with(this@AddTextActivity).load(mStickerList!![position]).into(object : CustomTarget<Drawable?>() {
                                override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                                    mSelectedSticker = DrawableSticker(resource)
                                    mSelectedSticker!!.color = Color.WHITE
                                    sticker_view!!.addSticker(mSelectedSticker!!)
                                    sticker_view!!.invalidate()
                                }

                                override fun onLoadCleared(placeholder: Drawable?) {}
                            })
                        } else {
                            Toast.makeText(this@AddTextActivity, resources.getString(R.string.try_again_later), Toast.LENGTH_SHORT).show()
                        }

                    },
                    onAdLoaded = {

                    }
                )

            }

            override fun onNegative(bottomSheetDialog: BottomSheetFragment?) {
                bottomSheetDialog!!.dismiss()
            }
        })
        bottomSheetFragment.show(supportFragmentManager, "dialog")
    }

//    fun showAd(rewardedAd: RewardedAd) {
//        if (rewardedAd !=null) {
//            val adCallback: RewardedAdCallback = object : RewardedAdCallback() {
//                override fun onRewardedAdOpened() {
//                    // Ad opened.
//                    assert(instence != null)
//                    instence!!.loadVideoAdMain(this@AddTextActivity)
//                }
//
//                override fun onRewardedAdClosed() {
//                    // Ad closed.
//                    assert(instence != null)
//                    instence!!.loadVideoAdMain(this@AddTextActivity)
//                }
//
//                override fun onUserEarnedReward(reward: RewardItem) {
//                    /*  // User earned reward.
//                    dbHelper.insertPath(mImageList.get(position));
//                    // imageLock.setVisibility(View.GONE);
//                    if (adapter != null) {
//                        adapter.notifyItemChanged(position);
//                    }*/
//                    assert(instence != null)
//                    instence!!.loadVideoAdMain(this@AddTextActivity)
//                }
//
//                override fun onRewardedAdFailedToShow(errorCode: Int) {
//                    // Ad failed to display.
//                    assert(instence != null)
//                    instence!!.loadVideoAdMain(this@AddTextActivity)
//                    Toast.makeText(this@AddTextActivity, resources.getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
//                }
//            }
//            rewardedAd.show(this@AddTextActivity, adCallback)
//        } else {
//            //  showSnackBar(getResources().getString(R.string.something_went_wrong));
//            Toast.makeText(this@AddTextActivity, resources.getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
//        }
//    }

//    fun createAndLoadRewardedAd(adUnitId: String?): RewardedAd {
//        val rewardedAd = RewardedAd(this, adUnitId)
//        val adLoadCallback: RewardedAdLoadCallback = object : RewardedAdLoadCallback() {
//            override fun onRewardedAdLoaded() {
//                // Ad successfully loaded.
//            }
//
//            override fun onRewardedAdFailedToLoad(errorCode: Int) {
//                // Ad failed to load.
//            }
//        }
//        rewardedAd.loadAd(AdRequest.Builder().build(), adLoadCallback)
//        return rewardedAd
//    }

    inner class Receiver : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            Log.d("dsfsdf", "onReceive: ads ")
            if (!NetworkHelper.isOnline(context)) {
                try {
                    stickerFragment!!.dismiss()
                } catch (e: java.lang.Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    override fun onStop() {
        super.onStop()
//        removeFragment()
        try {
            unregisterReceiver(receiver)
        } catch (e: java.lang.Exception) {

        }
    }

    override fun onPause() {
        super.onPause()

        try {
            bottomSheetFragment!!.dismiss()
        }catch (e:Exception){

        }
    }

    override fun onResume() {
        super.onResume()
        if (sticker_view != null) {
            sticker_view!!.isLocked = false
        }
        imgColor!!.setCardBackgroundColor(Color.parseColor("#EBEBEB"))
        SolidWallpaperApplication.staticLanguage.Factory.create(this)
        if (Constants.isSubscribedW) {
            recreate()
            Constants.isSubscribedW = false
        }

    }

    private fun showAlertDialog() {
         bottomSheetFragment = BottomSheetFragmentDiscard(resources.getString(R.string.discard), resources.getString(R.string.do_you_want_to_discard), resources.getString(R.string.discard), resources.getString(R.string.cancel), R.drawable.ic_discard_dialog, object : BottomSheetFragmentDiscard.OnButtonClickListener {
            override fun onPositive(bottomSheetDialo: BottomSheetFragmentDiscard?) {
                bottomSheetDialo!!.dismiss()
                finish()
            }

            override fun onNegative(bottomSheetDialog: BottomSheetFragmentDiscard?) {
                bottomSheetDialog!!.dismiss()
            }
        })
        bottomSheetFragment!!.show(supportFragmentManager, "dialog")
    }

    companion object {
        fun changeDrawableColor(context: Context?, icon: Int, newColor: Int): Drawable {
            val mDrawable = ContextCompat.getDrawable(context!!, icon)!!.mutate()
            mDrawable.colorFilter = PorterDuffColorFilter(newColor, PorterDuff.Mode.SRC_IN)
            return mDrawable
        }

        fun hideKeyboard(activity: Activity) {
            val imm = activity.getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
            //Find the currently focused view, so we can grab the correct window token from it.
            var view = activity.currentFocus
            //If no view currently has focus, create a new one, just so we can grab a window token from it
            if (view == null) {
                view = View(activity)
            }
            imm.hideSoftInputFromWindow(view.windowToken, 0)
        }
    }
}