package com.hd.wallpaper.solid.color.background.newModel

import android.os.Parcel
import android.os.Parcelable
import com.hd.wallpaper.solid.color.background.model.api.ImageItem

class WallpaperWeekModelNewResponse : Parcelable {
    var imageItem: ImagesItem? = null
    var isLocked: Boolean
    var coins = 0
    var screen:String? = null

    constructor(imageItem: ImagesItem?, isLocked: Boolean, coins: Int) {
        this.imageItem = imageItem
        this.coins = coins
        this.isLocked = isLocked
    }

    constructor(imageItem: ImagesItem?, screen:String?, isLocked: Boolean, coins: Int) {
        this.imageItem = imageItem
        this.coins = coins
        this.isLocked = isLocked
        this.screen = screen
    }

    protected constructor(`in`: Parcel) {
        isLocked = `in`.readByte().toInt() != 0
    }

    override fun describeContents(): Int {
        return 0
    }

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeByte((if (isLocked) 1 else 0).toByte())
    }
//
//    companion object {
//        val CREATOR: Parcelable.Creator<WallpaperWeekModel?> = object : Parcelable.Creator<WallpaperWeekModel?> {
//            override fun createFromParcel(`in`: Parcel): WallpaperWeekModel? {
//                return WallpaperWeekModel(`in`)
//            }
//
//            override fun newArray(size: Int): Array<WallpaperWeekModel?> {
//                return arrayOfNulls(size)
//            }
//        }
//    }
    companion object CREATOR : Parcelable.Creator<WallpaperWeekModelNewResponse> {
        override fun createFromParcel(parcel: Parcel): WallpaperWeekModelNewResponse {
            return WallpaperWeekModelNewResponse(parcel)
        }

        override fun newArray(size: Int): Array<WallpaperWeekModelNewResponse?> {
            return arrayOfNulls(size)
        }
    }
}