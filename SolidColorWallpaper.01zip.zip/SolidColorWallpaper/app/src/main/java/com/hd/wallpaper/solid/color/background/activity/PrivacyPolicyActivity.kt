package com.hd.wallpaper.solid.color.background.activity

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.activity.PrivacyPolicyActivity

class PrivacyPolicyActivity constructor() : AppCompatActivity() {
    private var mWebview: WebView? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_privacy_policy)
        mWebview = findViewById(R.id.webView)
        mWebview!!.settings.javaScriptEnabled = true // enable javascript
        mWebview!!.webViewClient = object : WebViewClient() {
            public override fun onReceivedError(view: WebView, errorCode: Int, description: String, failingUrl: String) {
                Toast.makeText(this@PrivacyPolicyActivity, description, Toast.LENGTH_SHORT).show()
            }
        }
        mWebview!!.loadUrl("https://agneshpipaliya.blogspot.com/2019/03/image-crop-n-wallpaper-changer.html")
        // setContentView(mWebview);
    }

    public override fun onBackPressed() {
        if (mWebview != null && mWebview!!.canGoBack()) {
            mWebview!!.goBack()
        } else {
            super.onBackPressed()
        }
    }
}