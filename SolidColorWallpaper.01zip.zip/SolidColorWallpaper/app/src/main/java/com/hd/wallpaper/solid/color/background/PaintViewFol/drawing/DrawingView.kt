package com.hd.wallpaper.solid.color.background.PaintViewFol.drawing

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.util.Log
import android.view.MotionEvent
import android.view.View

/**
 * Created by marco.granatiero on 07/08/2014.
 */
class DrawingView(context: Context?, attrs: AttributeSet?) : View(context, attrs) {
    enum class MotionMode {
        DRAW_POLY
    }

    private val paint = Paint()
    private val path = Path()

    /**
     * Optimizes painting by invalidating the smallest possible area.
     */
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private val dirtyRect = RectF()

    //    final OnTouchListener selectionAndMoveListener = // not shown;
    //
    //    final OnTouchListener drawRectangleListener = // not shown;
    //
    //    final OnTouchListener drawOvalListener = // not shown;
    val drawPolyLineListener: OnTouchListener = object : OnTouchListener {
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            // Log.d("jabagator", "onTouch: " + event);
            val eventX = event.x
            val eventY = event.y
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    path.moveTo(eventX, eventY)
                    lastTouchX = eventX
                    lastTouchY = eventY
                    // No end point yet, so don't waste cycles invalidating.
                    return true
                }
                MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP -> {
                    // Start tracking the dirty region.
                    resetDirtyRect(eventX, eventY)

                    // When the hardware tracks events faster than
                    // they can be delivered to the app, the
                    // event will contain a history of those skipped points.
                    val historySize = event.historySize
                    var i = 0
                    while (i < historySize) {
                        val historicalX = event.getHistoricalX(i)
                        val historicalY = event.getHistoricalY(i)
                        expandDirtyRect(historicalX, historicalY)
                        path.lineTo(historicalX, historicalY)
                        i++
                    }

                    // After replaying history, connect the line to the touch point.
                    path.lineTo(eventX, eventY)
                }
                else -> {
                    Log.d("jabagator", "Unknown touch event  $event")
                    return false
                }
            }

            // Include half the stroke width to avoid clipping.
            invalidate(
                    (dirtyRect.left - HALF_STROKE_WIDTH).toInt(),
                    (dirtyRect.top - HALF_STROKE_WIDTH).toInt(),
                    (dirtyRect.right + HALF_STROKE_WIDTH).toInt(),
                    (dirtyRect.bottom + HALF_STROKE_WIDTH).toInt())
            lastTouchX = eventX
            lastTouchY = eventY
            return true
        }

        /**
         * Called when replaying history to ensure the dirty region
         * includes all points.
         */
        private fun expandDirtyRect(historicalX: Float, historicalY: Float) {
            if (historicalX < dirtyRect.left) {
                dirtyRect.left = historicalX
            } else if (historicalX > dirtyRect.right) {
                dirtyRect.right = historicalX
            }
            if (historicalY < dirtyRect.top) {
                dirtyRect.top = historicalY
            } else if (historicalY > dirtyRect.bottom) {
                dirtyRect.bottom = historicalY
            }
        }

        /**
         * Resets the dirty region when the motion event occurs.
         */
        private fun resetDirtyRect(eventX: Float, eventY: Float) {

            // The lastTouchX and lastTouchY were set when the ACTION_DOWN
            // motion event occurred.
            dirtyRect.left = Math.min(lastTouchX, eventX)
            dirtyRect.right = Math.max(lastTouchX, eventX)
            dirtyRect.top = Math.min(lastTouchY, eventY)
            dirtyRect.bottom = Math.max(lastTouchY, eventY)
        }
    }

    fun clear() {
        path.reset()

        // Repaints the entire view.
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawPath(path, paint)
    }

    /**
     * Sets the DrawingView into one of several modes, such
     * as "select" mode (e.g., for moving or resizeing objects),
     * or "Draw polyline" (smooth curve), "draw rectangle", etc.
     */
    private fun setMode(motionMode: MotionMode) {
        when (motionMode) {
            MotionMode.DRAW_POLY -> setOnTouchListener(drawPolyLineListener)
            else -> throw IllegalStateException("Unknown MotionMode $motionMode")
        }
    }

    companion object {
        private const val STROKE_WIDTH = 20.0f

        /** Need to track this so the dirty region can accommodate the stroke.  */
        private const val HALF_STROKE_WIDTH = STROKE_WIDTH / 2
    }

    /** DrawingView Constructor  */
    init {
        paint.isAntiAlias = true
        paint.color = Color.BLACK
        paint.style = Paint.Style.STROKE
        paint.strokeJoin = Paint.Join.ROUND
        paint.strokeWidth = STROKE_WIDTH
        setMode(MotionMode.DRAW_POLY)
    }
}