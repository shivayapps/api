package com.hd.wallpaper.solid.color.background.activity

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.hd.wallpaper.solid.color.background.R

class TermsConditionActivity constructor() : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_terms_condition)
        findViewById<View>(R.id.icBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnShare).setOnClickListener { onclickShare() }
    }

    private fun onclickShare() {
        val shareIntent: Intent = Intent(Intent.ACTION_SEND)
        shareIntent.type = "text/plain"
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Solid Color Wallpaper")
        var shareMessage: String = ""
        shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=com.solid.color.wallpaper.hd.image.background"
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
        startActivity(Intent.createChooser(shareIntent, getResources().getString(R.string.choose_one)))
    }
}