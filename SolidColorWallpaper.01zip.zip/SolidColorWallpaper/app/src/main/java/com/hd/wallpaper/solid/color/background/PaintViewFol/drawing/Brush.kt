package com.hd.wallpaper.solid.color.background.PaintViewFol.drawing

import android.content.Context
import android.content.res.TypedArray
import com.hd.wallpaper.solid.color.background.R

/**
 * Created by marco.granatiero on 07/08/2014.
 */
class Brush private constructor(val id: Int) {

    var angle = 0f

    var angleJitter = 0f
    var autoStrokeCount = 0
    var autoStrokeDistribution = 0f
    var autoStrokeJointPitch = 0f
    var autoStrokeLength = 0
    var autoStrokeStraight = 0f

    var colorPatchAlpha = 0f
    var coloringType = 0

    var defaultColor = 0
    var icon: String? = null

    var iconId = 0

    var isEraser = false

    var jitterBrightness = 0f

    var jitterHue = 0f

    var jitterSaturation = 0f

    var lineEndAlphaScale = 0f
    var lineEndFadeLength = 0

    var lineEndSizeScale = 0f

    var lineEndSpeedLength = 0f
    var lineTaperFadeLength = 0
    var lineTaperStartLength = 0
    var maskImageArray: Array<String> = arrayOf()
    var maskImageIdArray: IntArray = intArrayOf()
    var maxSize = 0f
    var minSize = 0f

    var name: String? = null
    var preview: String? = null

    var previewId = 0

    var size = 0f

    var smudgingPatchAlpha = 0f

    var spacing = 0f

    var spread = 0f

    var textureDepth = 0f

    var traceMode = false

    var useDeviceAngle = false

    var useFirstJitter = false

    var useFlowingAngle = false

    var useSmudging = false

    var useSingleLayerStroke = false

    companion object {
        private var BRUSH_MASK_IMAGE_ARRAY_STYLEABLE: IntArray? = null
        const val BRUSH_TYPE_PHOTO = 1
        const val BRUSH_TYPE_STYLISH = 0
        const val COLORING_TYPE_NORMAL = 0
        const val COLORING_TYPE_REF_IMAGE_ALL_TIME = 1
        const val COLORING_TYPE_REF_IMAGE_INIT_TIME = 2
        private const val TAG = "Brush"

        fun parseStyleData(context: Context, styleArray: IntArray): Array<Brush?> {
            val brushes = arrayOfNulls<Brush>(styleArray.size)
            var i = 0
            while (i < brushes.size) {
                val brush = Brush(i)
                val a = context.obtainStyledAttributes(styleArray[i], R.styleable.Brush)
                brush.loadFromTypedArray(a)
                a.recycle()
                brushes[i] = brush
                i++
            }
            return brushes
        }

        init {
            BRUSH_MASK_IMAGE_ARRAY_STYLEABLE = intArrayOf(
                R.styleable.Brush_maskImageArray0,
                    R.styleable.Brush_maskImageArray1, R.styleable.Brush_maskImageArray2,
                    R.styleable.Brush_maskImageArray3, R.styleable.Brush_maskImageArray4,
                    R.styleable.Brush_maskImageArray5, R.styleable.Brush_maskImageArray6,
                    R.styleable.Brush_maskImageArray7, R.styleable.Brush_maskImageArray8,
                    R.styleable.Brush_maskImageArray9)
        }
    }

    private fun loadFromTypedArray(a: TypedArray) {
        angle = a.getFloat(R.styleable.Brush_angle, 0.0f)
        angleJitter = a.getFloat(R.styleable.Brush_angleJitter, 0.0f)
        autoStrokeCount = a.getInt(R.styleable.Brush_autoStrokeCount, 0)
        autoStrokeDistribution = a.getFloat(R.styleable.Brush_autoStrokeDistribution, 0.0f)
        autoStrokeJointPitch = a.getFloat(R.styleable.Brush_autoStrokeJointPitch, 0.0f)
        autoStrokeLength = a.getInt(R.styleable.Brush_autoStrokeLength, 1)
        autoStrokeStraight = a.getFloat(R.styleable.Brush_autoStrokeStraight, 0.0f)
        colorPatchAlpha = a.getFloat(R.styleable.Brush_colorPatchAlpha, 0.0f)
        coloringType = a.getInt(R.styleable.Brush_coloringType, COLORING_TYPE_NORMAL)
        iconId = a.getResourceId(R.styleable.Brush_icon, 0)
        isEraser = a.getBoolean(R.styleable.Brush_isEraser, false)
        jitterBrightness = a.getFloat(R.styleable.Brush_jitterBrightness, 0.0f)
        jitterHue = a.getFloat(R.styleable.Brush_jitterHue, 0.0f)
        jitterSaturation = a.getFloat(R.styleable.Brush_jitterSaturation, 0.0f)
        lineEndAlphaScale = a.getFloat(R.styleable.Brush_lineEndAlphaScale, 0.0f)
        lineEndFadeLength = a.getInt(R.styleable.Brush_lineEndFadeLength, 0)
        lineEndSizeScale = a.getFloat(R.styleable.Brush_lineEndSizeScale, 0.0f)
        lineEndSpeedLength = a.getFloat(R.styleable.Brush_lineEndSpeedLength, 0.0f)
        lineTaperFadeLength = a.getInt(R.styleable.Brush_lineTaperFadeLength, 0)
        lineTaperStartLength = a.getInt(R.styleable.Brush_lineTaperStartLength, 0)
        var i = COLORING_TYPE_NORMAL
        while (i < BRUSH_MASK_IMAGE_ARRAY_STYLEABLE!!.size && a.getResourceId(BRUSH_MASK_IMAGE_ARRAY_STYLEABLE!![i], 0) != 0) {
            i++
        }
        maskImageIdArray = IntArray(i)
        i = 0
        while (i < maskImageIdArray.size) {
            maskImageIdArray[i] = a.getResourceId(BRUSH_MASK_IMAGE_ARRAY_STYLEABLE!![i], 0)
            i++
        }
        maxSize = a.getDimension(R.styleable.Brush_maxSize, 0.0f)
        minSize = a.getDimension(R.styleable.Brush_minSize, 0.0f)
        name = a.getString(R.styleable.Brush_name)
        previewId = a.getResourceId(R.styleable.Brush_preview, 0)
        size = a.getDimension(R.styleable.Brush_size, 0.0f)
        smudgingPatchAlpha = a.getFloat(R.styleable.Brush_smudgingPatchAlpha, 0.0f)
        spacing = a.getFloat(R.styleable.Brush_spacing, 0.0f)
        spread = a.getFloat(R.styleable.Brush_spread, 0.0f)
        textureDepth = a.getFloat(R.styleable.Brush_textureDepth, 0.0f)
        traceMode = a.getBoolean(R.styleable.Brush_traceMode, false)
        useDeviceAngle = a.getBoolean(R.styleable.Brush_useDeviceAngle, false)
        useFirstJitter = a.getBoolean(R.styleable.Brush_useFirstJitter, false)
        useFlowingAngle = a.getBoolean(R.styleable.Brush_useFlowingAngle, false)
        useSmudging = a.getBoolean(R.styleable.Brush_useSmudging, false)
        useSingleLayerStroke = a.getBoolean(R.styleable.Brush_useSingleLayerStroke, false)
        defaultColor = a.getColor(R.styleable.Brush_defaultColor, 0)
    }

    val brushType: Int
        get() = if (coloringType == 0) COLORING_TYPE_NORMAL else COLORING_TYPE_REF_IMAGE_ALL_TIME

    val scaledSize: Float
        get() = (size - minSize) / (maxSize - minSize)

    fun getSizeFromScaledSize(scaledSize: Float): Float {
        return minSize + (maxSize - minSize) * scaledSize
    }

    fun setScaledSize(scaledSize: Float): Boolean {
        var scaledSize = scaledSize
        if (scaledSize < 0.0f) {
            scaledSize = 0.0f
        } else if (scaledSize > 1.0f) {
            scaledSize = 1.0f
        }
        val newSize = getSizeFromScaledSize(scaledSize)
        if (size == newSize) {
            return false
        }
        size = newSize
        return true
    }

    override fun toString(): String {
        return "Brush " + angle + ", " + angleJitter + ", " + autoStrokeCount + ", " + name + ", " + isEraser + ", " + maskImageIdArray.size + ", " + if (maskImageIdArray.size == 1) Integer.valueOf(maskImageIdArray[0]) else maskImageIdArray[0].toString() + "/" + maskImageIdArray[1]
    }

}