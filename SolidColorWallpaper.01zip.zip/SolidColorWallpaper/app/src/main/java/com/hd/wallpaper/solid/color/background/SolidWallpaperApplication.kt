package com.hd.wallpaper.solid.color.background

import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.util.Log
import androidx.multidex.MultiDex
import com.example.app.ads.helper.VasuAdsConfig
import com.example.app.ads.helper.openad.AppOpenApplication
import com.example.app.ads.helper.openad.OpenAdHelper


import com.hd.wallpaper.solid.color.background.PaintViewFol.drawing.Brushes.loadBrushList
import com.hd.wallpaper.solid.color.background.activity.SplashScreenActivity
import com.hd.wallpaper.solid.color.background.constants.Constants
import com.hd.wallpaper.solid.color.background.custom.ApplicationLifecycleManager
import com.hd.wallpaper.solid.color.background.imagePicker.model.Constant.activity
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs
import com.hd.wallpaper.solid.color.background.shared_pref.MySharedPref
import com.onesignal.OneSignal
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException
import java.util.*

class SolidWallpaperApplication : AppOpenApplication(), AppOpenApplication.AppLifecycleListener {
    companion object {
        private var singleton: SolidWallpaperApplication? = null

        @JvmStatic
        val instance: SolidWallpaperApplication?
            get() {
                if (singleton == null) {
                    singleton = SolidWallpaperApplication()
                }
                return singleton
            }

        init {
            System.loadLibrary("native-lib")
        }
    }

//    @JvmField
//    var mInterstitialAdfb: com.facebook.ads.InterstitialAd? = null

//    @JvmField
//    var mInterstitialAd: InterstitialAd? = null

    //lateinit var openManager: AppOpenManager
    override fun onResumeApp(fCurrentActivity: Activity): Boolean {
        if (AdsPrefs.getBoolean(this, AdsPrefs.IS_SUBSCRIBED, false)){
            return false
        }
        return true
    }

//    @JvmField
//    var ins_adRequest: AdRequest? = null
//    override fun attachBaseContext(base: Context) {
//        super.attachBaseContext(base)
//        MultiDex.install(this)
//        loadBrushList(this)
//}


    override fun onCreate() {
        super.onCreate()
//        registerActivityLifecycleCallbacks(ApplicationLifecycleManager())

        // OneSignal Initialization
//        OneSignal.startInit(this)
//            .setNotificationReceivedHandler(ExampleNotificationReceivedHandler())
//            .setNotificationOpenedHandler(ExampleNotificationOpenedHandler())
//            .inFocusDisplaying(OneSignal.OSInFocusDisplayOption.Notification)
//            .unsubscribeWhenNotificationsAreDisabled(true)
//            .init()
        MultiDex.install(this)
//        MobileAds.initialize(this) {
//
//        }
//        AppIDs.init(applicationContext, AppIDs.SOLID_COLOR, false)

        try {
            singleton = this

            setAppLifecycleListener(this)

            VasuAdsConfig.with(applicationContext)
                .isEnableOpenAd(true)
                .needToTakeAllTestAdID(true)
                .setAdmobAppId(getString(R.string.admob_app_id))
                .setAdmobInterstitialAdId(getString(R.string.admob_interstitial_ad_id))
                .setAdmobNativeAdvancedAdId(getString(R.string.admob_native_advanced_ad_id))
                .setAdmobOpenAdId(getString(R.string.admob_open_ad_id))
                .initialize()

            initMobileAds(true)

//            OpenAdHelper.destroy()
            OpenAdHelper.loadOpenAd(applicationContext)

            OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE)
            OneSignal.initWithContext(applicationContext)
            OneSignal.setAppId("642658f3-86ea-4035-b48b-157a06751b85")

            // Test calling play() immediately (before TTS initialization is complete).
            val info = packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES)
            for (signature in info.signatures) {
                val md = MessageDigest.getInstance("SHA")
                md.update(signature.toByteArray())
                //Log.e("TAG", "KeyHash: >>>> " + Base64.encodeToString(md.digest(), Base64.DEFAULT));
            }
        } catch (e: PackageManager.NameNotFoundException) {
        } catch (e: NoSuchAlgorithmException) {
        } catch (e: Exception) {
        }
    }

    class staticLanguage {
        companion object Factory {
            fun create(context: Context) {
                val locale: Locale
                val sharedPref = MySharedPref(context)
                locale = if (sharedPref.language.equals("English", ignoreCase = true)) {
                    Locale("en")
                } else if (sharedPref.language.equals("Española", ignoreCase = true)) {
                    Locale("es")
                } else if (sharedPref.language.equals("Pусский", ignoreCase = true)) {
                    Locale("ru")
                } else if (sharedPref.language.equals("Portuguesa", ignoreCase = true)) {
                    Locale("pt")
                } else if (sharedPref.language.equals("عربى", ignoreCase = true)) {
                    Locale("ar")
                } else {
                    Locale("tr")
                }
                Log.d("staticLanguage", "onResume: " + locale.displayLanguage)
//                //  if (!locale.equals(Locale.getDefault())) {
//                Locale.setDefault(locale)
//                val config1 = Configuration()
//                config1.locale = locale
//                context.resources.updateConfiguration(config1, context.resources.displayMetrics)

                if (locale != Locale.getDefault()) {
                    Locale.setDefault(locale)
                    val config1 = Configuration()
                    config1.locale = locale
                    context.resources.updateConfiguration(config1, context.resources.displayMetrics)
                }
            }
        }
    }

    public fun forLanguafe() {

    }

//    fun requestNewInterstitial(): Boolean {
//        try {
//            if (mInterstitialAd != null) {
//                mInterstitialAd!!.show(activity)
//                return true
//            }else{
//                LoadAds()
//            }
//        } catch (e: Exception) {
//        }
//        return false
//    }

//    inner class ExampleNotificationOpenedHandler : NotificationOpenedHandler {
//        // This fires when a notification is opened by tapping on it.
//        override fun notificationOpened(result: OSNotificationOpenResult) {
//            val actionType = result.action.type
//            val data = result.notification.payload.additionalData
//            val launchUrl = result.notification.payload.launchURL // update docs launchUrl
//            val customKey: String?
//            var openURL: String? = null
//            var activityToLaunch: Any = SplashScreenActivity::class.java
//            if (data != null) {
//                customKey = data.optString("customkey", null)
//                openURL = data.optString("openURL", null)
//                if (customKey != null) Log.i("OneSignalExample", "customkey set with value: $customKey")
//                if (openURL != null) Log.i("OneSignalExample", "openURL to webview with URL value: $openURL")
//            }
//            if (actionType == ActionType.ActionTaken) {
//                Log.i("OneSignalExample", "Button pressed with id: " + result.action.actionID)
//                if (result.action.actionID == "id1") {
//                    Log.i("OneSignalExample", "button id called: " + result.action.actionID)
//                    activityToLaunch = SplashScreenActivity::class.java
//                } else Log.i("OneSignalExample", "button id called: " + result.action.actionID)
//            }
//            if (ApplicationLifecycleManager.isAppVisible) {
//                // App is running
//            } else {
//                // The following can be used to open an Activity of your choice.
//                // Replace - getApplicationContext() - with any Android Context.
//                // Intent intent = new Intent(getApplicationContext(), YourActivity.class);
//                val intent = Intent(applicationContext, activityToLaunch as Class<*>)
//                // intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_NEW_TASK);
//                intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_NEW_TASK
//                intent.putExtra("openURL", openURL)
//                Log.i("OneSignalExample", "openURL = $openURL")
//                // startActivity(intent);
//                applicationContext.startActivity(intent)
//            }
//            // Add the following to your AndroidManifest.xml to prevent the launching of your main Activity
//            //   if you are calling startActivity above.
//            /*
//          <application ...>
//            <meta-data android:name="com.onesignal.NotificationOpened.DEFAULT" android:value="DISABLE" />
//          </application>
//       */
//        }
//    }

}