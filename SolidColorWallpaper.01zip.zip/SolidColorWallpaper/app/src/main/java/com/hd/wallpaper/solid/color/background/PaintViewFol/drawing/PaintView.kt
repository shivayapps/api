package com.hd.wallpaper.solid.color.background.PaintViewFol.drawing

import android.content.Context
import android.content.res.Resources
import android.graphics.*
import android.graphics.drawable.BitmapDrawable
import android.os.Build
import android.text.TextPaint
import android.util.AttributeSet
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.core.content.ContextCompat
import com.airbnb.lottie.LottieAnimationView
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.PaintViewFol.activity.PaintActivity
import com.hd.wallpaper.solid.color.background.PaintViewFol.constant.Constants
import com.hd.wallpaper.solid.color.background.constants.Constants.mBitmapPath
import com.hd.wallpaper.solid.color.background.constants.Constants.mBitmapPathUndo
import java.util.*
import kotlin.collections.ArrayList
import kotlin.math.cos
import kotlin.math.sin


/**
 * Created by marco.granatiero on 07/08/2014.
 */
class PaintView(context: Context?, attrs: AttributeSet?) : View(context, attrs) {
    private var mBrush: Brush? = null
    private var mColor = 0
    private var mLineColor = 0
    var drawingAlpha: Float
    private var mBackgroundLayerColor = 0
    private val mLastDrawDistance = 0f
    private var mSpacing = 0f
    private var mDrawingLayer: Bitmap? = null
    private val mDrawingLayerCanvas: Canvas
    private val mOnDrawCanvasRect: Rect
    private var mPathLayer: Bitmap? = null
    private val mPathLayerCanvas: Canvas
    private var mPathWidth = 0f
    private var mPathWidthHalf = 0f
    var foregroundBitmap: Bitmap? = null
        private set
    private val mMergedLayerCanvas: Canvas
    private var mTextureLayer: Bitmap? = null
    private val mTextureLayerCanvas: Canvas
    private val mTextureDrawable: BitmapDrawable
    private var mTempPathLayer: Bitmap? = null
    private val mTempPathLayerCanvas: Canvas
    private val mLineDirtyRect: RectF
    private val mDirtyRect: RectF
    private val mNormalPaint: Paint
    private val mSrcPaint: Paint
    private val mDstInPaint: Paint
    private val mDstOutPaint: Paint
    private val mCurveDrawingHandler: OnTouchHandler?
    private var mTouchResampler: TouchResampler? = null
    private var mMaxVelocityScale = 0f
    private var mMaskBitmap: Array<Bitmap?>? = arrayOf()
    private var mMaskPadding = 0
    private val mRandom: Random
    private val mMatrix: Matrix
    private val mDeviceAngle = 0f
    private val mOldPt: PointF
    private var mIsJitterColor = false
    private var mDrawingLayerNeedDrawn = false
    private var mIsBatchDraw = false



    private var lottieFile: LottieAnimationView? = null

    var mX: Float? = 0f
    var mY: Float? = 0f

    //Text brush
    val DEFUALT_COLOR = ContextCompat.getColor(context!!, R.color.colorStart)
    val DEFUALT_BG_COLOR = Color.WHITE
    val TOUCH_TOLERANCE = 5

    var BRUSH_TYPE = PAINT

    var str = "Hello"
    var mType = PAINT
    var strb = StringBuilder()

    private var mX1 = 0f
    private var mY1: kotlin.Float = 0f
    private var mPath: Path? = null
    private var mPaint: Paint? = null
    private var paths: ArrayList<FingerPath> = ArrayList<FingerPath>()
    private var subpaths: ArrayList<Path> = ArrayList<Path>()
    private val undopaths: ArrayList<FingerPath> = ArrayList<FingerPath>()
    private var currentcolor = 0

    private var mTextPaint: TextPaint? = null
    private var strokeWidth = 0
    private var mBitmap: Bitmap? = null
    private var mCanvas: Canvas? = null
    private var color: Int = DEFUALT_COLOR
    private var textBrushSize = 70
    private var textFontTypeface: Typeface = Typeface.DEFAULT
    private var textBrushAlpha = 255

    var textWidth = 0f
    private var isFirstTimePath: Boolean = false


    fun setLottieView(v: LottieAnimationView) {
        lottieFile = v
    }

    private fun initMethod() {

        val wm =
                context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val display = wm.defaultDisplay
        val height: Int = display!!.height
        val width: Int = display!!.width
        mBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        mCanvas = Canvas(mBitmap!!)
        currentcolor = color
        strokeWidth = textBrushSize

        strb.append(str)

        mPath = Path()

        initPaint()
    }

    private fun initPaint() {
        mPaint = Paint()
        mPaint!!.isAntiAlias = true
        mPaint!!.isDither = true
        mPaint!!.color = color
        mPaint!!.style = Paint.Style.STROKE
        mPaint!!.strokeJoin = Paint.Join.ROUND
        mPaint!!.strokeCap = Paint.Cap.ROUND
        mPaint!!.xfermode = null
        mPaint!!.alpha = 0xff
        mPaint!!.strokeWidth = textBrushSize.toFloat()

        /* if (mType == ERASER) {
             mPaint!!.setXfermode(PorterDuffXfermode(PorterDuff.Mode.CLEAR))
         } else {*/
        mPaint!!.xfermode = null
        //}

        mTextPaint = TextPaint()
        mTextPaint!!.isAntiAlias = true
        //mTextPaint!!.isDither = true
        //mTextPaint!!.isFilterBitmap = true
        mTextPaint!!.textSize = textBrushSize.toFloat()
        mTextPaint!!.color = color

        textFontTypeface = if (Constants.textFontPath!!.contains("fonts_neon")) {
            Typeface.createFromAsset(context!!.assets, Constants.textFontPath)
        } else {
            Typeface.createFromFile(Constants.textFontPath)
        }

        mTextPaint!!.typeface = textFontTypeface
        mTextPaint!!.alpha = textBrushAlpha
        mTextPaint!!.strokeWidth = textBrushSize.toFloat()
        //mTextPaint!!.xfermode = null


        textWidth = mTextPaint!!.measureText(str)
    }

    fun setBrushType(fBrushType: Int) {
        BRUSH_TYPE = fBrushType
    }

    fun setTexts(str: String) {
        this.str = str
    }

    fun getTexts(): String {
        return str
    }

    fun setTextColor(selectedTextColor: Int) {
        color = selectedTextColor
        mTextPaint!!.setColor(selectedTextColor)
    }

    fun getTextColor(): Int {
        return color
    }

    fun setTextTypeface(selectedTypeface: Typeface) {
        textFontTypeface = selectedTypeface
        mTextPaint!!.typeface = selectedTypeface
    }

    fun getTextFontFamily(): Typeface {
        return textFontTypeface
    }

    fun setTextAlpha(opacity: Float) {
        textBrushAlpha = (opacity * 255.0f).toInt()
        //initPaint()
        mTextPaint!!.alpha = (opacity * 255.0f).toInt()
    }

    fun getTextAlpha(): Int {
        return textBrushAlpha
    }

    fun setTextSize(brushSize: Float) {
        textBrushSize = brushSize.toInt()
        mTextPaint!!.strokeWidth = brushSize
        initPaint()
    }

    fun getTextSize(): Float {
        return textBrushSize.toFloat()
    }

    fun isAnyDrawing(): Boolean {
        if (mBitmapPath.size != 0 || paths.size != 0) {
            return true
        } else {
            return false
        }
    }

    private interface OnTouchHandler {
        fun onTouchEvent(i: Int, motionEvent: MotionEvent?): Boolean
    }

    var brush: Brush?
        get() = mBrush
        set(brush) {
            mBrush = brush
            mPathWidth = brush!!.size
            mPathWidthHalf = brush.size / 2.0f
            mSpacing = brush.spacing * brush.size
            releaseBrushSizeBitmaps()
            mPathLayer =
                    Bitmap.createBitmap(mPathWidth.toInt(), mPathWidth.toInt(), Bitmap.Config.ARGB_8888)
            mPathLayerCanvas.setBitmap(mPathLayer)
            mMaxVelocityScale = brush.size * brush.lineEndSpeedLength / VELOCITY_MAX_SCALE
            mMaskBitmap = arrayOfNulls(brush.maskImageIdArray.size)
            mMaskPadding = (mPathWidth / 3.5f).toInt()
            var i = 0
            while (i < mMaskBitmap!!.size) {
                mMaskBitmap!![i] = decodeScaledExpandResource(
                        resources,
                        brush.maskImageIdArray[i],
                        mPathWidth.toInt(),
                        mPathWidth.toInt(),
                        mMaskPadding
                )
                i++
            }
            mIsJitterColor =
                    if (brush.jitterHue.toDouble() == 0.0 && brush.jitterSaturation.toDouble() == 0.0 && brush.jitterBrightness.toDouble() == 0.0) {
                        false
                    } else {
                        true
                    }
            mTempPathLayer =
                    Bitmap.createBitmap(mPathWidth.toInt(), mPathWidth.toInt(), Bitmap.Config.ARGB_8888)
            mTempPathLayerCanvas.setBitmap(mTempPathLayer)
        }

    fun setDrawingColor(color: Int) {
        mColor = color
    }

    fun setDrawingBgColor(color: Int) {
        mBackgroundLayerColor = color
        invalidate()
    }

    var drawingScaledSize: Float
        get() = mBrush!!.scaledSize
        set(scaledSize) {
            if (mBrush!!.setScaledSize(scaledSize)) {
                brush = mBrush
            }
        }

    //return (this.mBitmapHistoryManager.isEmpty() && this.mBackgroundBitmap == null) ? true : false;
    val isClear: Boolean
        get() =//return (this.mBitmapHistoryManager.isEmpty() && this.mBackgroundBitmap == null) ? true : false;
            false

    fun clear() {
        setDrawingForegroundBitmap(null)
        //setDrawingBackgroundBitmap(null);
    }

    fun setDrawingForegroundBitmap(bitmap: Bitmap?) {
        mDrawingLayerCanvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.SRC)
        mMergedLayerCanvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.SRC)
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        releaseViewSizeBitmaps()
        mDrawingLayer = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        mDrawingLayerCanvas.setBitmap(mDrawingLayer)
        foregroundBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        mMergedLayerCanvas.setBitmap(foregroundBitmap)
        mTextureLayer = Bitmap.createBitmap(w, h, Bitmap.Config.ALPHA_8)
        mTextureLayerCanvas.setBitmap(mTextureLayer)
        mTextureDrawable.setBounds(0, 0, w, h)
        mTextureDrawable.draw(mTextureLayerCanvas)

    }

    override fun onTouchEvent(event: MotionEvent): Boolean {

        mIsBatchDraw = false
        if (mBrush == null) {
            return super.onTouchEvent(event)
        }
        val action = event.actionMasked
        return mCurveDrawingHandler?.onTouchEvent(action, event) ?: false
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

//        canvas!!.drawBitmap(mBitmap!!, 0f, 0f, null)

        // mCanvas!!.drawColor(DEFUALT_BG_COLOR)

        //Normal Draw
        canvas.save()
        canvas.getClipBounds(mOnDrawCanvasRect)
        drawToCanvas(canvas, mOnDrawCanvasRect)
        canvas.restore()
        invalidate(mOnDrawCanvasRect)
    }

    private fun drawToCanvas(canvas: Canvas, rect: Rect?) {
        //canvas.drawColor(mBackgroundLayerColor, PorterDuff.Mode.SRC)
        //if (BRUSH_TYPE == TEXT) {
        if (isFirstTimePath && mPath != null) {
            canvas.drawTextOnPath(str, mPath!!, 0f, 0f, mTextPaint!!)
        }

        // }

        if (rect == null) {
            //canvas.saveLayer(null, null, Canvas.HAS_ALPHA_LAYER_SAVE_FLAG)
            canvas.saveLayer(null, null, Canvas.ALL_SAVE_FLAG)
        } else {
            canvas.saveLayer(
                    (rect.left - 1).toFloat(),
                    (mOnDrawCanvasRect.top - 1).toFloat(),
                    (mOnDrawCanvasRect.right + 1).toFloat(),
                    (mOnDrawCanvasRect.bottom + 1).toFloat(),
                    null,
                    Canvas.ALL_SAVE_FLAG
            )
        }
        // if (BRUSH_TYPE == PAINT) {
        if (mBrush!!.useSingleLayerStroke) {
            //Below 1 condition for undo redo
            if (mBitmapPath.size > 0) {
                canvas.drawBitmap(mBitmapPath[mBitmapPath.size - 1], 0.0f, 0.0f, mSrcPaint)
            }
            //canvas.drawBitmap(foregroundBitmap!!, 0.0f, 0.0f, mSrcPaint)
            if (!mDrawingLayerNeedDrawn) {
                canvas.restore()
            } else {
                val p: Paint
                p = if (!mBrush!!.isEraser) mNormalPaint else mDstOutPaint
                p.alpha = (drawingAlpha * 255.0f).toInt()
                canvas.drawBitmap(mDrawingLayer!!, 0.0f, 0.0f, p)
                canvas.restore()
            }
        } else {
            //Below 1 condition for undo redo
            if (mBitmapPath.size > 0) {
                canvas.drawBitmap(mBitmapPath[mBitmapPath.size - 1], 0.0f, 0.0f, mSrcPaint)
                //canvas.drawBitmap(foregroundBitmap!!, 0.0f, 0.0f, mSrcPaint)
            }
            if (mDrawingLayerNeedDrawn) {
                val p: Paint
                p = if (!mBrush!!.isEraser) mNormalPaint else mDstOutPaint
                canvas.drawBitmap(mDrawingLayer!!, 0.0f, 0.0f, p)
            }
            canvas.restore()
        }
        // }
    }

    private fun moveToThread(x: Float, y: Float) {
        val level = 1.0f
        resetDrawingDirtyRect()
        moveToAction(x, y, level)
    }

    private fun moveToAction(x: Float, y: Float, level: Float) {
        mOldPt[x] = y
        beforeLine(x, y)
    }

    private fun beforeLine(x: Float, y: Float) {
        val brush = mBrush
        mLineColor = mColor
    }

    private fun addSpot(x: Float, y: Float, tipScale: Float, tipAlpha: Float) {
        var drawX = x
        var drawY = y
        val brush = mBrush
        if (brush!!.spread > 0.0f) {
            val spreadAngle = mRandom.nextFloat() * 6.2831855f
            drawX += cos(spreadAngle) * brush.spread * brush.size
            drawY += sin(spreadAngle) * brush.spread * brush.size
        }
        fillBrushWithColor(brush, drawX, drawY, tipAlpha)
        if (brush.useSmudging) {
            smudgingBrush(brush, mOldPt.x - mPathWidthHalf, mOldPt.y - mPathWidthHalf, tipAlpha)
        }
        maskBrushWithAngle(brush, getBrushSpotAngle(brush, mOldPt.x, mOldPt.y, x, y), tipAlpha)
        if (brush.textureDepth > 0.0f) {
            textureBrush(brush, drawX - mPathWidthHalf, drawY - mPathWidthHalf)
        }
        drawBrushWithScale(drawX, drawY, tipScale)
        mOldPt[x] = y
        mDirtyRect.union(
                drawX - mPathWidthHalf, drawY - mPathWidthHalf,
                mPathWidthHalf + drawX, mPathWidthHalf + drawY
        )
    }

    private fun fillBrushWithColor(brush: Brush?, x: Float, y: Float, tipAlpha: Float) {
        //int color = mLineColor;
        val color: Int
        val drawingAlpha: Float
        drawingAlpha = if (mBrush!!.useSingleLayerStroke) {
            1.0f
        } else {
            this.drawingAlpha
        }
        color = if (!mIsJitterColor || brush!!.useFirstJitter) {
            Color.argb(
                    (drawingAlpha * brush!!.colorPatchAlpha * tipAlpha * 255.0f).toInt(),
                    Color.red(mLineColor),
                    Color.green(mLineColor),
                    Color.blue(mLineColor)
            )
        } else {
            val jitterColor = jitterColor(mLineColor)
            Color.argb(
                    (drawingAlpha * tipAlpha * 255.0f).toInt(),
                    Color.red(jitterColor),
                    Color.green(jitterColor),
                    Color.blue(jitterColor)
            )
        }
        mPathLayerCanvas.drawColor(color, PorterDuff.Mode.SRC)
    }

    private fun maskBrushWithAngle(brush: Brush?, angle: Float, tipAlpha: Float) {
        mDstInPaint.alpha = (tipAlpha * tipAlpha * 255.0f).toInt()
        val maskLayer =
                if (mMaskBitmap!!.size == 1) mMaskBitmap!![0] else mMaskBitmap!![mRandom.nextInt(
                        mMaskBitmap!!.size
                )]
        if (angle != 0.0f) {
            mMatrix.setTranslate((-mMaskPadding).toFloat(), (-mMaskPadding).toFloat())
            mMatrix.postRotate(
                    Math.toDegrees(angle.toDouble()).toFloat(),
                    mPathWidthHalf,
                    mPathWidthHalf
            )
            mPathLayerCanvas.drawBitmap(maskLayer!!, mMatrix, mDstInPaint)
        } else {
            mPathLayerCanvas.drawBitmap(
                    maskLayer!!,
                    (-mMaskPadding).toFloat(),
                    (-mMaskPadding).toFloat(),
                    mDstInPaint
            )
        }
    }

    private fun destLineThread() {
        if (mBrush!!.isEraser) {
            mergeWithAlpha(drawingAlpha, mDstOutPaint, mLineDirtyRect)
        } else {
            mergeWithAlpha(drawingAlpha, mNormalPaint, mLineDirtyRect)
        }
    }

    private fun mergeWithAlpha(alpha: Float, paint: Paint, rectF: RectF) {
        if (mBrush!!.useSingleLayerStroke) {
            paint.alpha = (255.0f * alpha).toInt()
        } else {
            paint.alpha = 255
        }
        mMergedLayerCanvas.save()
        mMergedLayerCanvas.clipRect(rectF)

        mMergedLayerCanvas.drawBitmap(mDrawingLayer!!, 0.0f, 0.0f, paint)
        mMergedLayerCanvas.restore()
        clearDrawingLayer(rectF)

        //Below line for undo redo
        mBitmapPath.add(
                Bitmap.createScaledBitmap(
                        foregroundBitmap!!,
                        foregroundBitmap!!.width,
                        foregroundBitmap!!.height,
                        false
                )
        )

        paths.add(FingerPath("", null, null))


        if (!mIsBatchDraw) {
            val rect = Rect()
            rectF.round(rect)
            invalidate(rect)
        }
    }

    private fun clearDrawingLayer(rectF: RectF) {
        mDrawingLayerCanvas.save()
        mDrawingLayerCanvas.clipRect(rectF)
        mDrawingLayerCanvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.SRC)
        mDrawingLayerCanvas.restore()
        mDrawingLayerNeedDrawn = false
    }

    private fun openLine() {
        mDirtyRect[mOldPt.x - mPathWidthHalf, mOldPt.y - mPathWidthHalf, mOldPt.x + mPathWidthHalf] =
                mOldPt.y + mPathWidthHalf
    }

    private fun closeLine() {
        mLineDirtyRect.union(mDirtyRect)
        if (!mIsBatchDraw) {
            val rect = Rect()
            mDirtyRect.round(rect)
            invalidate(rect)
        }
    }

    private fun resetDrawingDirtyRect() {
        mLineDirtyRect.setEmpty()
        mDrawingLayerNeedDrawn = true
    }

    private fun drawBrushWithScale(x: Float, y: Float, tipScale: Float) {
        mNormalPaint.alpha = 255
        if (tipScale == 1.0f) {
            mDrawingLayerCanvas.drawBitmap(
                    mPathLayer!!,
                    x - mPathWidthHalf,
                    y - mPathWidthHalf,
                    mNormalPaint
            )
        } else {
            mDrawingLayerCanvas.save()
            mDrawingLayerCanvas.translate(x, y)
            mDrawingLayerCanvas.scale(tipScale, tipScale)
            mDrawingLayerCanvas.drawBitmap(
                    mPathLayer!!,
                    -mPathWidthHalf,
                    -mPathWidthHalf,
                    mNormalPaint
            )
            mDrawingLayerCanvas.restore()
        }
    }

    private fun getBrushSpotAngle(
            brush: Brush?,
            oldX: Float,
            oldY: Float,
            curX: Float,
            curY: Float
    ): Float {
        var angle = brush!!.angle * 6.2831855f
        if (brush.useDeviceAngle) {
            angle += mDeviceAngle
        }
        if (brush.useFlowingAngle) {
            angle += Math.atan2((curY - oldY).toDouble(), (curX - oldX).toDouble())
                    .toFloat() - 1.5707964f
        }
        return if (brush.angleJitter > 0.0f) angle + (mRandom.nextFloat() - 0.5f) * 6.2831855f * brush.angleJitter else angle
    }

    private fun jitterColor(color: Int): Int {
        if (!mIsJitterColor) {
            return color
        }
        val hsv = FloatArray(3)
        Color.colorToHSV(color, hsv)
        val hue = hsv[0]
        val saturation = hsv[1]
        hsv[0] =
                (hue + (mRandom.nextFloat() - 0.5f) * 360.0f * mBrush!!.jitterHue + 360.0f) % 360.0f
        hsv[1] = saturation + (mRandom.nextFloat() - 0.5f) * mBrush!!.jitterSaturation
        hsv[2] = hsv[2] + (mRandom.nextFloat() - 0.5f) * mBrush!!.jitterBrightness
        return Color.HSVToColor(hsv)
    }

    private fun textureBrush(brush: Brush?, x: Float, y: Float) {
        mDstOutPaint.alpha = (brush!!.textureDepth * 255.0f).toInt()
        mPathLayerCanvas.drawBitmap(mTextureLayer!!, -x, -y, mDstOutPaint)
    }

    private fun smudgingBrush(brush: Brush?, x: Float, y: Float, tipAlpha: Float) {
        var x = x
        var y = y
        x = -x
        y = -y
        mTempPathLayerCanvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.SRC)
        mTempPathLayerCanvas.drawBitmap(foregroundBitmap!!, x, y, null)
        mNormalPaint.alpha = (drawingAlpha * 255.0f).toInt()
        mTempPathLayerCanvas.drawBitmap(mDrawingLayer!!, x, y, mNormalPaint)
        mNormalPaint.alpha = (brush!!.smudgingPatchAlpha * tipAlpha * 255.0f).toInt()
        mPathLayerCanvas.drawBitmap(mTempPathLayer!!, 0.0f, 0.0f, mNormalPaint)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        release()
    }

    fun release() {
        releaseViewSizeBitmaps()
        releaseBrushSizeBitmaps()
        mBitmapPath.forEach {
            it.recycle()
        }
        mBitmapPathUndo.forEach {
            it.recycle()
        }
    }

    private fun releaseBrushSizeBitmaps() {
        mPathLayerCanvas.setBitmap(EMPTY_BITMAP)
        if (mPathLayer != null) {
            mPathLayer!!.recycle()
            mPathLayer = null
        }
        mTempPathLayerCanvas.setBitmap(EMPTY_BITMAP)
        if (mTempPathLayer != null) {
            mTempPathLayer!!.recycle()
            mTempPathLayer = null
        }
        if (mMaskBitmap != null) {
            var i = 0
            while (i < mMaskBitmap!!.size) {
                if (mMaskBitmap!![i] != null) {
                    mMaskBitmap!![i]!!.recycle()
                    mMaskBitmap!![i] = null
                }
                i++
            }
            mMaskBitmap = null
        }
    }

    private fun releaseViewSizeBitmaps() {
        mMergedLayerCanvas.setBitmap(EMPTY_BITMAP)
        if (foregroundBitmap != null) {
            foregroundBitmap!!.recycle()
            foregroundBitmap = null
        }
        mDrawingLayerCanvas.setBitmap(EMPTY_BITMAP)
        if (mDrawingLayer != null) {
            mDrawingLayer!!.recycle()
            mDrawingLayer = null
        }
        mTextureLayerCanvas.setBitmap(EMPTY_BITMAP)
        if (mTextureLayer != null) {
            mTextureLayer!!.recycle()
            mTextureLayer = null
        }
    }

    private inner class MyTouchDistanceResampler : TouchDistanceResampler() {
        private var mLastDrawDistance = 0f
        private val mTempXYV = FloatArray(3)
        override fun onTouchDown(x: Float, y: Float) {
            Log.d("PaintView", "onTouchDown")
            if (lottieFile != null && lottieFile!!.visibility == VISIBLE) {
                lottieFile!!.visibility = GONE
            }
            isFirstTimePath = true
            this.mLastDrawDistance = 0.0f
            if (BRUSH_TYPE == PAINT || BRUSH_TYPE == ERASER1) {
                //Below code for undo redo
                if (mBitmapPath.size > 0 && mBitmapPathUndo.size > 0) {
                    foregroundBitmap = mBitmapPath[mBitmapPath.size - 1]
                    foregroundBitmap = Bitmap.createScaledBitmap(
                            foregroundBitmap!!,
                            foregroundBitmap!!.width,
                            foregroundBitmap!!.height,
                            false
                    )
                    mMergedLayerCanvas.setBitmap(foregroundBitmap)
                } else {
                    if (mBitmapPath.size == 0) {
                        foregroundBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                        mMergedLayerCanvas.setBitmap(foregroundBitmap)
                    }
                }
                mBitmapPathUndo.forEach {
                    it.recycle()
                }






                if (mBitmapPath.size > 0 && mBitmapPathUndo.size > 0) {
                    foregroundBitmap = mBitmapPath[mBitmapPath.size - 1]
                    foregroundBitmap = Bitmap.createScaledBitmap(
                            foregroundBitmap!!,
                            foregroundBitmap!!.width,
                            foregroundBitmap!!.height,
                            false
                    )
                    mMergedLayerCanvas.setBitmap(foregroundBitmap)
                } else {
                    if (mBitmapPath.size == 0) {
                        foregroundBitmap =
                                Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                        mMergedLayerCanvas.setBitmap(foregroundBitmap)
                    } else {
                        foregroundBitmap = mBitmapPath[mBitmapPath.size - 1]
                        foregroundBitmap = Bitmap.createScaledBitmap(
                                foregroundBitmap!!,
                                foregroundBitmap!!.width,
                                foregroundBitmap!!.height,
                                false
                        )
                        mMergedLayerCanvas.setBitmap(foregroundBitmap)
                    }
                }
                mBitmapPathUndo.forEach {
                    it.recycle()
                }
                mBitmapPathUndo.clear()
                //paths.clear()
                undopaths.clear()












                mBitmapPathUndo.clear()

                moveToThread(x, y)
            } else if (BRUSH_TYPE == TEXT) {
                /*if (str == "") {
                    context.showToast("Add text first")
                }*/
                //Below code for undo redo
                if (mBitmapPath.size > 0 && mBitmapPathUndo.size > 0) {
                    foregroundBitmap = mBitmapPath[mBitmapPath.size - 1]
                    foregroundBitmap = Bitmap.createScaledBitmap(
                            foregroundBitmap!!,
                            foregroundBitmap!!.width,
                            foregroundBitmap!!.height,
                            false
                    )
                    mMergedLayerCanvas.setBitmap(foregroundBitmap)
                } else {
                    if (mBitmapPath.size == 0) {
                        foregroundBitmap =
                                Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                        mMergedLayerCanvas.setBitmap(foregroundBitmap)
                    } else {
                        foregroundBitmap = mBitmapPath[mBitmapPath.size - 1]
                        foregroundBitmap = Bitmap.createScaledBitmap(
                                foregroundBitmap!!,
                                foregroundBitmap!!.width,
                                foregroundBitmap!!.height,
                                false
                        )
                        mMergedLayerCanvas.setBitmap(foregroundBitmap)
                    }
                }
                mBitmapPathUndo.forEach {
                    it.recycle()
                }
                mBitmapPathUndo.clear()
                //paths.clear()
                undopaths.clear()
                touchStartForText(x, y)
                //invalidate()
            }
        }

        override fun onTouchMove(x: Float, y: Float, t: Float) {
            Log.d("PaintView", "onTouchMove")
            if (BRUSH_TYPE == PAINT || BRUSH_TYPE == ERASER1) {
                val brush = mBrush
                openLine()
                while (getXYVAtDistance(this.mLastDrawDistance, mTempXYV)) {
                    var tipSpeedScale: Float
                    var tipSpeedAlpha: Float
                    val px = mTempXYV[0]
                    val py = mTempXYV[1]
                    val pv = mTempXYV[2]
                    if (brush!!.lineEndSpeedLength > 0.0f) {
                        var velocityLevel: Float
                        velocityLevel = if (pv > mMaxVelocityScale) 1.0f else pv / mMaxVelocityScale
                        tipSpeedScale =
                                brush.lineEndSizeScale + (1.0f - velocityLevel) * (1.0f - brush.lineEndSizeScale)
                        tipSpeedAlpha =
                                brush.lineEndAlphaScale + (1.0f - velocityLevel) * (1.0f - brush.lineEndAlphaScale)
                    } else {
                        tipSpeedScale = 1.0f
                        tipSpeedAlpha = 1.0f
                    }
                    if (this.mLastDrawDistance > 0.0f) {
                        Log.d("PaintView", "onTouchMove $px, $py")
                        addSpot(px, py, tipSpeedScale, tipSpeedAlpha)
                    }
                    this.mLastDrawDistance += mSpacing * tipSpeedScale
                }
                closeLine()
            } else if (BRUSH_TYPE == TEXT) {
                touchMoveForText(x, y)
                //invalidate()
            }
        }

        override fun onTouchUp() {
            isFirstTimePath = false
            if (BRUSH_TYPE == PAINT || BRUSH_TYPE == ERASER1) {
                destLineThread()
                (context as PaintActivity).checkSomethingIsAddedOnCanvas()
                (context as PaintActivity).checkUndoRedoDisable()
            } else if (BRUSH_TYPE == TEXT) {
                touchUpForText()
                //invalidate()
                (context as PaintActivity).checkSomethingIsAddedOnCanvas()
                (context as PaintActivity).checkUndoRedoDisable()
            }
        }

        private fun touchMoveForText(x: Float, y: Float) {
            val dx = Math.abs(x - mX1)
            val dy = Math.abs(y - mY1)
            Log.d("XY values", "$dx,$dy")

            if (dx >= TOUCH_TOLERANCE || dy >= TOUCH_TOLERANCE) {
                mPath!!.quadTo(mX1, mY1, (x + mX1) / 2, (y + mY1) / 2)
            }

            mX1 = x
            mY1 = y
            /* if (textWidth <= PathMeasure(mPath, false).length) {
                 mPath = Path()
                 //subpaths.add(mPath!!)
                 mPath!!.moveTo(x, y)
             }*/
        }

        fun touchUpForText() {
            mPath!!.lineTo(mX1, mY1)

            val fingerPath = FingerPath(str, mPath!!, mTextPaint!!)
            paths.add(fingerPath)
            // subpaths = ArrayList()

            //for (fp in paths) {
            //mCanvas!!.drawPath(fp.mPath, fp.paint)
            //   for (fp2 in fp.mPath) {
            // }
            if (str != "") {
                mMergedLayerCanvas.drawTextOnPath(str, mPath!!, 0f, 0f, mTextPaint!!)
            }

            /* for (subpath1 in subpaths) {
                 canvas.drawTextOnPath(str, subpath1, 0f, 0f, fp.paint)
             }*/
            //}
            mPath = null

            //Below line for undo redo
            mBitmapPath.add(
                    Bitmap.createScaledBitmap(
                            foregroundBitmap!!,
                            foregroundBitmap!!.width,
                            foregroundBitmap!!.height,
                            false
                    )
            )

            initPaint()

        }

        private fun touchStartForText(x: Float, y: Float) {
            mPath = Path()
            mPath!!.moveTo(x, y)
            mX1 = x
            mY1 = y
            //subpaths.add(mPath!!)
        }
    }


    fun undo() {
        if (mBitmapPath.size > 0) {
            mBitmapPathUndo.add(mBitmapPath.removeAt(mBitmapPath.size - 1))
            undopaths.add(paths.removeAt(paths.size - 1))
            invalidate()
        } else {
            //Toast.makeText(context, "Can't undo more", Toast.LENGTH_SHORT).show()
        }
    }

    fun redo() {
        if (mBitmapPathUndo.size > 0) {
            mBitmapPath.add(mBitmapPathUndo.removeAt(mBitmapPathUndo.size - 1))
            paths.add(undopaths.removeAt(undopaths.size - 1))
            invalidate()
        } else {
            //Toast.makeText(context, "Can't redo more", Toast.LENGTH_SHORT).show()
        }
    }

    fun checkUndo(): Boolean {
        return mBitmapPath.size > 0
    }

    fun checkRedo(): Boolean {
        return mBitmapPathUndo.size > 0
    }

    companion object {
        val PAINT = 0
        val TEXT = 1
        val ADDCOLOR = 2
        val ERASER1 = 3

        private const val VELOCITY_MAX_SCALE = 130.0f
        private val EMPTY_BITMAP = if (Build.VERSION.SDK_INT < 14) Bitmap.createBitmap(
                1,
                1,
                Bitmap.Config.ARGB_8888
        ) else null

        private fun decodeScaledExpandResource(
                res: Resources,
                id: Int,
                width: Int,
                height: Int,
                padding: Int
        ): Bitmap? {
            val src = BitmapFactory.decodeResource(res, id) ?: return null
            val dst = Bitmap.createBitmap(
                    padding * 2 + width,
                    padding * 2 + height,
                    Bitmap.Config.ARGB_8888
            )
            val c = Canvas(dst)
            c.drawBitmap(
                    src,
                    Rect(0, 0, src.width, src.height),
                    Rect(padding, padding, padding + width, padding + height),
                    null
            )
            c.setBitmap(EMPTY_BITMAP)
            if (src == dst) {
                return dst
            }
            src.recycle()
            return dst
        }
    }

    init {
        mTextureDrawable =
                BitmapDrawable(resources, BitmapFactory.decodeResource(resources, R.drawable.texture01))
        mTextureDrawable.setTileModeXY(Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
        mNormalPaint = Paint(Paint.FILTER_BITMAP_FLAG)
        mSrcPaint = Paint(Paint.FILTER_BITMAP_FLAG)
        mDstInPaint = Paint(Paint.FILTER_BITMAP_FLAG)
        mDstOutPaint = Paint(Paint.FILTER_BITMAP_FLAG)

        mNormalPaint.isAntiAlias = true
//        mNormalPaint.setColor(Color.BLACK);
//        paint.setStyle(Paint.Style.STROKE);
//        paint.setStrokeJoin(Paint.Join.ROUND);
//        paint.setStrokeWidth(STROKE_WIDTH);
        mDrawingLayerCanvas = Canvas()
        mPathLayerCanvas = Canvas()
        mMergedLayerCanvas = Canvas()
        mTextureLayerCanvas = Canvas()
        mTempPathLayerCanvas = Canvas()
        mOnDrawCanvasRect = Rect()
        mLineDirtyRect = RectF()
        mDirtyRect = RectF()
        drawingAlpha = 1.0f
        mSrcPaint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC)
        mDstInPaint.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        mDstOutPaint.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        mCurveDrawingHandler = object : OnTouchHandler {
            override fun onTouchEvent(action: Int, event: MotionEvent?): Boolean {

                mX = event!!.x
                mY = event!!.y

                if (!mBrush!!.traceMode) {
                    mTouchResampler!!.onTouchEvent(event!!)
                    return true
                }
                return false
            }
        }
        mTouchResampler = MyTouchDistanceResampler()
        mRandom = Random()
        mMatrix = Matrix()
        mOldPt = PointF()

        initMethod()
    }
}