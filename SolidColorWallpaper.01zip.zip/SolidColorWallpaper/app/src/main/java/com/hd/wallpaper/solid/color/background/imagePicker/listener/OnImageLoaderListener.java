package com.hd.wallpaper.solid.color.background.imagePicker.listener;

import com.hd.wallpaper.solid.color.background.imagePicker.model.Folder;
import com.hd.wallpaper.solid.color.background.imagePicker.model.Image;

import java.util.List;



public interface OnImageLoaderListener {
    void onImageLoaded(List<Image> images, List<Folder> folders);

    void onFailed(Throwable throwable);
}
