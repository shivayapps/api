package com.hd.wallpaper.solid.color.background.adapter

import android.content.Context
import android.graphics.drawable.Drawable
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.model.WallpaperWeekNewModel
import com.hd.wallpaper.solid.color.background.newModel.WallpaperWeekNewModelClass
import java.util.*

class WallpaperOfWeekNewAdapter(private val mImageList: ArrayList<WallpaperWeekNewModelClass?>, private val mContext: Context, var onClickItem: OnClickItem) : RecyclerView.Adapter<WallpaperOfWeekNewAdapter.MyViewHolder>() {

    interface OnClickItem {
        fun onClickWallpaper(wallpaperWeekModel: WallpaperWeekNewModelClass?, pos: Int)
        fun startAnimation()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(LayoutInflater.from(mContext).inflate(R.layout.rv_wallpaper_of_week, parent, false))
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        if (mImageList[position] != null) {
            val wallpaperWeekModel = mImageList[position]

            Log.e("asasasas", "onBindViewHolder: ${wallpaperWeekModel!!.imageItem!!.image}" )

            //  holder.progressContent.setVisibility(View.VISIBLE);
            holder.layoutLock.visibility = View.GONE
            holder.layoutCoin.visibility = View.GONE
            Glide.with(mContext).load(wallpaperWeekModel!!.imageItem!!.image).addListener(object : RequestListener<Drawable?> {
                override fun onLoadFailed(e: GlideException?, model: Any, target: Target<Drawable?>, isFirstResource: Boolean): Boolean {
                    //    holder.progressContent.setVisibility(View.GONE);
                    return true
                }

                override fun onResourceReady(resource: Drawable?, model: Any, target: Target<Drawable?>, dataSource: DataSource, isFirstResource: Boolean): Boolean {
                    holder.imgBack.setImageDrawable(resource)
                    //   holder.progressContent.setVisibility(View.GONE);
                    if (!wallpaperWeekModel.isLocked) {
                        holder.layoutCoin.visibility = View.GONE
                        holder.layoutLock.visibility = View.GONE
                    } else if (wallpaperWeekModel.coins!! <= 10) {
                        holder.layoutCoin.visibility = View.GONE
                        holder.layoutLock.visibility = View.VISIBLE
                    } else {
                        holder.txtCoin.text = wallpaperWeekModel.coins.toString()
                        holder.layoutCoin.visibility = View.VISIBLE
                    }
                    return true
                }
            }).centerCrop().into(holder.imgBack)
            holder.imgBack.setOnClickListener { v: View? -> onClickItem.onClickWallpaper(wallpaperWeekModel, position) }
        }
    }

    override fun getItemCount(): Int {
        return mImageList.size
    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var imgBack: ImageView = itemView.findViewById(R.id.imgBack)
        var layoutLock: RelativeLayout = itemView.findViewById(R.id.layoutLock)
        var layoutCoin: RelativeLayout = itemView.findViewById(R.id.layoutCoin)
        var progressContent: ProgressBar = itemView.findViewById(R.id.progressContent)
        var txtCoin: TextView = itemView.findViewById(R.id.txtCoin)

    }

    fun setDataChanged() {
        notifyDataSetChanged()
    }

    fun setDataPosition() {
        notifyDataSetChanged()
    }

}