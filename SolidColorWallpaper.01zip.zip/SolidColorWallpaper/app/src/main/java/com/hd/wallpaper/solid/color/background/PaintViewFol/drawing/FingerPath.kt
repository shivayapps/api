package com.hd.wallpaper.solid.color.background.PaintViewFol.drawing

import android.graphics.Path
import android.text.TextPaint

data class FingerPath(var text:String,var mPath: Path?, var paint: TextPaint?)
