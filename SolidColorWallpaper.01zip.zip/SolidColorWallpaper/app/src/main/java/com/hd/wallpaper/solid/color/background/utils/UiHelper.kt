package com.social.media.post.graphics.template.card.maker.utils

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import java.util.*

/**
 * UiHelper.kt - A simple helper class to make ui responsive.
 *
 * @author Jignesh N Patel
 * @date 14-11-2019
 */

object UiHelper {
    var SCALE_WIDTH = 1080 // scale width of ui
    var SCALE_HEIGHT = 1920 // scale height of ui
    lateinit var frame:FrameLayout
    /**
     * ToDo.. Set width and height of view
     *
     * @param mContext The context
     * @param view     The view whose width and height are to be set
     * @param v_width  The width to be set
     * @param v_height The height to be set
     */
     fun setscale(twidth:Int,theight:Int,f:FrameLayout){
        SCALE_WIDTH = twidth
        SCALE_HEIGHT = theight
        frame = f
    }

    fun setframe(f:FrameLayout)
    {
        frame = f
    }
    fun setHeightWidth(mContext: Context, view: View, v_width: Int, v_height: Int) {
        val dm = mContext.resources.displayMetrics
        val width = dm.widthPixels * v_width / SCALE_WIDTH
        val height = dm.heightPixels * v_height / SCALE_HEIGHT
        view.layoutParams.width = width
        view.layoutParams.height = height

    }
    fun getsresized(context:Context,v_width: Int, v_height: Int):ViewGroup.LayoutParams{
        val dm = context.resources.displayMetrics
        val width = dm.widthPixels * v_width / SCALE_WIDTH
        val height = dm.heightPixels * v_height / SCALE_HEIGHT
        return ViewGroup.LayoutParams(width.toInt(),height.toInt())
    }
    fun getHeightWidth(mContext: Context, widthView: Int, heightView: Int, v_width: Int, v_height: Int, density: Float):ViewGroup.LayoutParams {
        val dm = mContext.resources.displayMetrics
        var o = mContext.getResources().getConfiguration().orientation
        var width:Float
        var height:Float

        /*if(issquare!!)
        {
            if (density > 3.0) {
                width = ((dm.widthPixels * v_width / SCALE_WIDTH) / (density * ((density / 10) - 0.07))).toFloat()
                height = ((dm.heightPixels * v_height / SCALE_HEIGHT) / (density * ((density / 10) + 0.21))).toFloat()
            } else if (density == 3.0f) {
                width = ((dm.widthPixels * v_width / SCALE_WIDTH) / (density * ((density / 10) + 0.03))).toFloat()
                height = ((dm.heightPixels * v_height / SCALE_HEIGHT) / (density * ((density / 10) + 0.31))).toFloat()
            } else if (density == 2.0f) {
                width = ((dm.widthPixels * v_width / SCALE_WIDTH) / (density * ((density / 10) + 0.30))).toFloat()
                height = ((dm.heightPixels * v_height / SCALE_HEIGHT) / (density * ((density / 10) + 0.52))).toFloat()
            } else if (density == 2.5f) {
                width = ((dm.widthPixels * v_width / SCALE_WIDTH) / (density * ((density / 10) + 0.145))).toFloat()
                height = ((dm.heightPixels * v_height / SCALE_HEIGHT) / (density * ((density / 10) + 0.405))).toFloat()
            } else if (density < 2.5f && density > 2.0f) {
                width = ((dm.widthPixels * v_width / SCALE_WIDTH) / (density * ((density / 10) + 0.22))).toFloat()
                height = ((dm.heightPixels * v_height / SCALE_HEIGHT) / (density * ((density / 10) + 0.57))).toFloat()
            } else if (density == 2.625f) {
                width = ((dm.widthPixels * v_width / SCALE_WIDTH) / (density * ((density / 10) + 0.11))).toFloat()
                height = ((dm.heightPixels * v_height / SCALE_HEIGHT) / (density * ((density / 10) + 0.31))).toFloat()
            } else if (density > 2.5f) {
                width = ((dm.widthPixels * v_width / SCALE_WIDTH) / (density * ((density / 10) + 0.07))).toFloat()
                height = ((dm.heightPixels * v_height / SCALE_HEIGHT) / (density * ((density / 10) + 0.45))).toFloat()
            } else {
                width = ((dm.widthPixels * v_width / SCALE_WIDTH) / (density * ((density / 10) + 0.47))).toFloat()
                height = ((dm.heightPixels * v_height / SCALE_HEIGHT) / (density * ((density / 10) + 1.17))).toFloat()
            }
        }
        else {*/
                if(true/*isportrait!!*/) {
                    if (density > 3.0) {
                        width = (widthView * v_width / SCALE_WIDTH).toFloat()
                        height = (heightView * v_height / SCALE_HEIGHT) / 1.25.toFloat()
                        /* width = ((dm.widthPixels * v_width / SCALE_WIDTH) / (density * ((density / 10)))).toFloat()
                    height = ((dm.heightPixels * v_height / SCALE_HEIGHT) / (density * ((density / 10) - 0.015))).toFloat()*/
                    } else if (density == 3.0f) {
                        /*  width = ((dm.widthPixels * v_width / SCALE_WIDTH) / (density * ((density / 10) + 0.11))).toFloat()
                    height = ((dm.heightPixels * v_height / SCALE_HEIGHT) / (density * ((density / 10) + 0.11))).toFloat()*/
                        width = (widthView * v_width / SCALE_WIDTH).toFloat()
                        height = (heightView * v_height / SCALE_HEIGHT) / 1.4.toFloat()
                    } else if (density == 2.0f) {
                        width = (widthView * v_width / SCALE_WIDTH) .toFloat()
                        height = (heightView * v_height / SCALE_HEIGHT) / (1.1).toFloat()
                    /*    "BeforeWidth::${(dm.widthPixels * v_width / SCALE_WIDTH)}".log()
                        "BeforeHeight::${(dm.heightPixels * v_width / SCALE_HEIGHT)}".log()
                        "AfterWidth::${(frame.width * v_width / SCALE_WIDTH)}".log()
                        "AfterHeight::${(frame.height * v_width / SCALE_HEIGHT)}".log()*/
                    } else if (density == 2.5f) {
                        width = (widthView * v_width / SCALE_WIDTH).toFloat()
                        height = (heightView * v_height / SCALE_HEIGHT) / 1.18.toFloat()
                        /*width = ((dm.widthPixels * v_width / SCALE_WIDTH) / (density * ((density / 10) + 0.245))).toFloat()
                    height = ((dm.heightPixels * v_height / SCALE_HEIGHT) / (density * ((density / 10) + 0.245))).toFloat()*/
                    } else if (density < 2.5f && density > 2.0f) {
                        width = (widthView * v_width / SCALE_WIDTH).toFloat()
                        height = (heightView * v_height / SCALE_HEIGHT).toFloat()
                        /*   width = ((dm.widthPixels * v_width / SCALE_WIDTH) / (density * ((density / 10) + 0.33))).toFloat()
                    height = ((dm.heightPixels * v_height / SCALE_HEIGHT) / (density * ((density / 10) + 0.285))).toFloat()*/
                    } else if (density == 2.625f) {
                        width = (widthView * v_width / SCALE_WIDTH).toFloat()
                        height = (heightView * v_height / SCALE_HEIGHT) / 1.3.toFloat()
                        /*   width = ((dm.widthPixels * v_width / SCALE_WIDTH) / (density * ((density / 10) + 0.21))).toFloat()
                    height = ((dm.heightPixels * v_height / SCALE_HEIGHT) / (density * ((density / 10) + 0.21))).toFloat()*/
                    } else if (density > 2.5f) {
                        width = (widthView * v_width / SCALE_WIDTH).toFloat()
                        height = (heightView * v_height / SCALE_HEIGHT) / 1.13.toFloat()
                        /* width = ((dm.widthPixels * v_width / SCALE_WIDTH) / (density * ((density / 10) + 0.11))).toFloat()
                    height = ((dm.heightPixels * v_height / SCALE_HEIGHT) / (density * ((density / 10) + 0.17))).toFloat()*/
                    } else {
                        width = (widthView * v_width / SCALE_WIDTH) .toFloat()
                        height = (heightView * v_height / SCALE_HEIGHT) / 1.4.toFloat()
                        /*  width = ((dm.widthPixels * v_width / SCALE_WIDTH)) / (density - 0.20).toFloat()
                    height = ((dm.heightPixels * v_height / SCALE_HEIGHT)) / (density - 0.195).toFloat()*/
                    }
                }
        else{

                    if (density > 3.0) {
                        width = (widthView * v_width / SCALE_WIDTH) .toFloat()
                        height = (heightView * v_height / SCALE_HEIGHT).toFloat()
                        /* width = ((dm.widthPixels * v_width / SCALE_WIDTH) / (density * ((density / 10)))).toFloat()
                    height = ((dm.heightPixels * v_height / SCALE_HEIGHT) / (density * ((density / 10) - 0.015))).toFloat()*/
                    } else if (density == 3.0f) {
                        /*  width = ((dm.widthPixels * v_width / SCALE_WIDTH) / (density * ((density / 10) + 0.11))).toFloat()
                    height = ((dm.heightPixels * v_height / SCALE_HEIGHT) / (density * ((density / 10) + 0.11))).toFloat()*/
                        width = (widthView * v_width / SCALE_WIDTH).toFloat()
                        height = (heightView * v_height / SCALE_HEIGHT).toFloat()
                    } else if (density == 2.0f) {
                        width = (widthView * v_width / SCALE_WIDTH).toFloat()
                        height = (heightView * v_height / SCALE_HEIGHT).toFloat()
                     /*   "BeforeWidth::${(dm.widthPixels * v_width / SCALE_WIDTH)}".log()
                        "BeforeHeight::${(dm.heightPixels * v_width / SCALE_HEIGHT)}".log()
                        "AfterWidth::${(frame.width * v_width / SCALE_WIDTH)}".log()
                        "AfterHeight::${(frame.height * v_width / SCALE_HEIGHT)}".log()*/
                    } else if (density == 2.5f) {
                        width = (widthView * v_width / SCALE_WIDTH).toFloat()
                        height = (heightView * v_height / SCALE_HEIGHT).toFloat()
                        /*width = ((dm.widthPixels * v_width / SCALE_WIDTH) / (density * ((density / 10) + 0.245))).toFloat()
                    height = ((dm.heightPixels * v_height / SCALE_HEIGHT) / (density * ((density / 10) + 0.245))).toFloat()*/
                    } else if (density < 2.5f && density > 2.0f) {
                        width = (widthView * v_width / SCALE_WIDTH).toFloat()
                        height = (heightView * v_height / SCALE_HEIGHT).toFloat()
                        /*   width = ((dm.widthPixels * v_width / SCALE_WIDTH) / (density * ((density / 10) + 0.33))).toFloat()
                    height = ((dm.heightPixels * v_height / SCALE_HEIGHT) / (density * ((density / 10) + 0.285))).toFloat()*/
                    } else if (density == 2.625f) {
                        width = (widthView * v_width / SCALE_WIDTH).toFloat()
                        height = (heightView * v_height / SCALE_HEIGHT).toFloat()
                        /*   width = ((dm.widthPixels * v_width / SCALE_WIDTH) / (density * ((density / 10) + 0.21))).toFloat()
                    height = ((dm.heightPixels * v_height / SCALE_HEIGHT) / (density * ((density / 10) + 0.21))).toFloat()*/
                    } else if (density > 2.5f) {
                        width = (widthView * v_width / SCALE_WIDTH).toFloat()
                        height = (heightView * v_height / SCALE_HEIGHT).toFloat()
                        /* width = ((dm.widthPixels * v_width / SCALE_WIDTH) / (density * ((density / 10) + 0.11))).toFloat()
                    height = ((dm.heightPixels * v_height / SCALE_HEIGHT) / (density * ((density / 10) + 0.17))).toFloat()*/
                    } else {
                        width = (widthView * v_width / SCALE_WIDTH).toFloat()
                        height = (heightView * v_height / SCALE_HEIGHT).toFloat()
                        /*  width = ((dm.widthPixels * v_width / SCALE_WIDTH)) / (density - 0.20).toFloat()
                    height = ((dm.heightPixels * v_height / SCALE_HEIGHT)) / (density - 0.195).toFloat()*/
                    }
             }
       /* else {
            //3.5 = 0.38
            //2.0 = 0.83
            //2.5 = 0.295

           if(density>3.0) {
               width = ((dm.widthPixels * v_width / SCALE_WIDTH) / (density * ((density / 10) + 0.03))).toFloat()
               height = ((dm.heightPixels * v_height / SCALE_HEIGHT) / (density * ((density / 10) + 0.03))).toFloat()
           }
           else if(density==3.0f){
               width = ((dm.widthPixels * v_width / SCALE_WIDTH) / (density * ((density / 10) + 0.15))).toFloat()
               height = ((dm.heightPixels * v_height / SCALE_HEIGHT) / (density * ((density / 10) + 0.15))).toFloat()
           }
           else if(density==2.0f){
               width = ((dm.widthPixels * v_width / SCALE_WIDTH) / (density * ((density / 10) + 0.48))).toFloat()
               height = ((dm.heightPixels * v_height / SCALE_HEIGHT) / (density * ((density / 10) + 0.48))).toFloat()
           }
            else if(density==2.5f){
               width = ((dm.widthPixels * v_width / SCALE_WIDTH) / (density * ((density / 10) + 0.295))).toFloat()
               height = ((dm.heightPixels * v_height / SCALE_HEIGHT) / (density * ((density / 10) + 0.295))).toFloat()
           }
            else if(density<2.5f && density>2.0f){
               width = ((dm.widthPixels * v_width / SCALE_WIDTH) / (density * ((density / 10) + 0.45))).toFloat()
               height = ((dm.heightPixels * v_height / SCALE_HEIGHT) / (density * ((density / 10) + 0.375))).toFloat()
           }
            else if(density>2.5f){
               width = ((dm.widthPixels * v_width / SCALE_WIDTH) / (density * ((density / 10) + 0.21))).toFloat()
               height = ((dm.heightPixels * v_height / SCALE_HEIGHT) / (density * ((density / 10) + 0.21))).toFloat()
           }
            else{
               width = ((dm.widthPixels * v_width / SCALE_WIDTH))/ (density-0.1).toFloat()
               height = ((dm.heightPixels * v_height / SCALE_HEIGHT)) / (density-0.1).toFloat()
           }
        }*/
        return ViewGroup.LayoutParams(width.toInt(),height.toInt())
    }




    fun getmargins(mContext: Context, m_left: Int, m_top: Int,density: Float): ArrayList<Int> {
        val dm = mContext.resources.displayMetrics
        // margin
        var left:Double?=null
        var top:Double?=null
        var o = mContext.getResources().getConfiguration().orientation

        if(true/*isportrait!!*/) {
            if (density > 3.0) {
                left = (((frame.width * m_left) / SCALE_WIDTH)).toDouble()
                top = ((frame.height * m_top) / SCALE_HEIGHT) .toDouble()
                /* left = ((dm.widthPixels * m_left) / SCALE_WIDTH) / (density * ((density / 10))).toDouble()
                    top = ((dm.heightPixels * m_top) / SCALE_HEIGHT) / (density * (density / 10)).toDouble()*/
            } else if (density == 3.0f) {
                left = (frame.width * m_left) / SCALE_WIDTH.toDouble()
                top = ((frame.height * m_top) / SCALE_HEIGHT) / 1.3.toDouble()
                /* left = ((dm.widthPixels * m_left) / SCALE_WIDTH) / (density * ((density / 10) + 0.11))
                    top = ((dm.heightPixels * m_top) / SCALE_HEIGHT) / (density * ((density / 10) + 0.11)) */
            } else if (density == 2.0f) {
                left = ((frame.width * m_left) / SCALE_WIDTH).toDouble()
                top = ((frame.height * m_top) / SCALE_HEIGHT) / 1.07.toDouble()
            } else if (density == 2.5f) {
                left = ((frame.width * m_left) / SCALE_WIDTH) / 1.05    .toDouble()
                top = ((frame.height * m_top) / SCALE_HEIGHT) / 1.1.toDouble()
                /*left = ((dm.widthPixels * m_left) / SCALE_WIDTH) / (density * ((density / 10) + 0.245))
                    top = ((dm.heightPixels * m_top) / SCALE_HEIGHT) / (density * ((density / 10) + 0.245))*/
            } else if (density < 2.5f && density > 2.0f) {
                left = (frame.width * m_left) / SCALE_WIDTH.toDouble()
                top = (frame.height * m_top) / SCALE_HEIGHT.toDouble()
                /*  left = ((dm.widthPixels * m_left) / SCALE_WIDTH) / (density * ((density / 10) + 0.33))
                    top = ((dm.heightPixels * m_top) / SCALE_HEIGHT) / (density * ((density / 10) + 0.285))*/
            } else if (density == 2.625f) {
                left = ((frame.width * m_left) / SCALE_WIDTH) / 1.04.toDouble()
                top = ((frame.height * m_top) / SCALE_HEIGHT) / 1.3.toDouble()
                /*left = ((dm.widthPixels * m_left) / SCALE_WIDTH) / (density * ((density / 10) + 0.21))
                    top = ((dm.heightPixels * m_top) / SCALE_HEIGHT) / (density * ((density / 10) + 0.185))*/
            } else if (density > 2.5) {
                left = ((frame.width * m_left) / SCALE_WIDTH) / 1.03.toDouble()
                top = ((frame.height * m_top) / SCALE_HEIGHT) / 1.1.toDouble()
                /* left = ((dm.widthPixels * m_left) / SCALE_WIDTH) / (density * ((density / 10) + 0.15))
                    top = ((dm.heightPixels * m_top) / SCALE_HEIGHT) / (density * ((density / 10) + 0.135))*/
            } else {
                left = ((frame.width * m_left) / SCALE_WIDTH).toDouble()
                top = ((frame.height * m_top) / SCALE_HEIGHT) / 1.35.toDouble()
                /* left = ((dm.widthPixels * m_left) / SCALE_WIDTH) / (density - 0.18)
                    top = ((dm.heightPixels * m_top) / SCALE_HEIGHT) / (density - 0.18)*/
            }
        }
        else{
            if (density > 3.0) {
                left = (((frame.width * m_left) / SCALE_WIDTH)).toDouble()
                top = ((frame.height * m_top) / SCALE_HEIGHT).toDouble()
                /* left = ((dm.widthPixels * m_left) / SCALE_WIDTH) / (density * ((density / 10))).toDouble()
                    top = ((dm.heightPixels * m_top) / SCALE_HEIGHT) / (density * (density / 10)).toDouble()*/
            } else if (density == 3.0f) {
                left = (frame.width * m_left) / SCALE_WIDTH.toDouble()
                top = (frame.height * m_top) / SCALE_HEIGHT.toDouble()
                /* left = ((dm.widthPixels * m_left) / SCALE_WIDTH) / (density * ((density / 10) + 0.11))
                    top = ((dm.heightPixels * m_top) / SCALE_HEIGHT) / (density * ((density / 10) + 0.11)) */
            } else if (density == 2.0f) {
                left = ((frame.width * m_left) / SCALE_WIDTH).toDouble()
                top = ((frame.height * m_top) / SCALE_HEIGHT).toDouble()
            } else if (density == 2.5f) {
                left = ((frame.width * m_left) / SCALE_WIDTH).toDouble()
                top = ((frame.height * m_top) / SCALE_HEIGHT).toDouble()
                /*left = ((dm.widthPixels * m_left) / SCALE_WIDTH) / (density * ((density / 10) + 0.245))
                    top = ((dm.heightPixels * m_top) / SCALE_HEIGHT) / (density * ((density / 10) + 0.245))*/
            } else if (density < 2.5f && density > 2.0f) {
                left = (frame.width * m_left) / SCALE_WIDTH.toDouble()
                top = (frame.height * m_top) / SCALE_HEIGHT.toDouble()
                /*  left = ((dm.widthPixels * m_left) / SCALE_WIDTH) / (density * ((density / 10) + 0.33))
                    top = ((dm.heightPixels * m_top) / SCALE_HEIGHT) / (density * ((density / 10) + 0.285))*/
            } else if (density == 2.625f) {
                left = (frame.width * m_left) / SCALE_WIDTH.toDouble()
                top = (frame.height * m_top) / SCALE_HEIGHT.toDouble()
                /*left = ((dm.widthPixels * m_left) / SCALE_WIDTH) / (density * ((density / 10) + 0.21))
                    top = ((dm.heightPixels * m_top) / SCALE_HEIGHT) / (density * ((density / 10) + 0.185))*/
            } else if (density > 2.5) {
                left = ((frame.width * m_left) / SCALE_WIDTH).toDouble()
                top = ((frame.height * m_top) / SCALE_HEIGHT).toDouble()
                /* left = ((dm.widthPixels * m_left) / SCALE_WIDTH) / (density * ((density / 10) + 0.15))
                    top = ((dm.heightPixels * m_top) / SCALE_HEIGHT) / (density * ((density / 10) + 0.135))*/
            } else {
                left = (frame.width * m_left) / SCALE_WIDTH.toDouble()
                top = (frame.height * m_top) / SCALE_HEIGHT.toDouble()
                /* left = ((dm.widthPixels * m_left) / SCALE_WIDTH) / (density - 0.18)
                    top = ((dm.heightPixels * m_top) / SCALE_HEIGHT) / (density - 0.18)*/
            }
        }
      /*  }
        else {
            if (density > 3.0) {
                left = ((dm.widthPixels * m_left) / SCALE_WIDTH) / (density * ((density / 10) + 0.03))
                top = ((dm.heightPixels * m_top) / SCALE_HEIGHT) / (density * ((density / 10) + 0.03))
            } else if (density == 3.0f) {
                left = ((dm.widthPixels * m_left) / SCALE_WIDTH) / (density * ((density / 10) + 0.15))
                top = ((dm.heightPixels * m_top) / SCALE_HEIGHT) / (density * ((density / 10) + 0.15))
            } else if (density == 2.0f) {
                left = ((dm.widthPixels * m_left) / SCALE_WIDTH) / (density * ((density / 10) + 0.48))
                top = ((dm.heightPixels * m_top) / SCALE_HEIGHT) / (density * ((density / 10) + 0.48))
            } else if (density == 2.5f) {
                left = ((dm.widthPixels * m_left) / SCALE_WIDTH) / (density * ((density / 10) + 0.295))
                top = ((dm.heightPixels * m_top) / SCALE_HEIGHT) / (density * ((density / 10) + 0.295))
            } else if (density < 2.5f && density > 2.0f) {
                left = ((dm.widthPixels * m_left) / SCALE_WIDTH) / (density * ((density / 10) + 0.465))
                top = ((dm.heightPixels * m_top) / SCALE_HEIGHT) / (density * ((density / 10) + 0.40))
            } else if (density > 2.5) {
                left = ((dm.widthPixels * m_left) / SCALE_WIDTH) / (density * ((density / 10) + 0.31))
                top = ((dm.heightPixels * m_top) / SCALE_HEIGHT) / (density * ((density / 10) + 0.21))
            } else {
                left = ((dm.widthPixels * m_left) / SCALE_WIDTH) / (density - 0.1).toDouble()
                top = ((dm.heightPixels * m_top) / SCALE_HEIGHT) / (density - 0.1).toDouble()
            }
        }*/
        var l = ArrayList<Int>()
        l.add(left!!.toInt())
        l.add(top!!.toInt())
        return l
    }


}
