package com.hd.wallpaper.solid.color.background.adapter

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.model.GradientSelectableModel
import java.util.*

class GradientSingleSelctableAdapter(private val mColors: ArrayList<GradientSelectableModel>, private val mContext: Context, private val mListener: setOnItemClickListener) : RecyclerView.Adapter<GradientSingleSelctableAdapter.MyViewHolder>() {
    private var lastSelected = 0
    private var mCurrentOrientation = 0
    private val orientations = arrayOf(
            GradientDrawable.Orientation.TOP_BOTTOM,
            GradientDrawable.Orientation.TR_BL,
            GradientDrawable.Orientation.RIGHT_LEFT,
            GradientDrawable.Orientation.BR_TL,
            GradientDrawable.Orientation.BOTTOM_TOP,
            GradientDrawable.Orientation.BL_TR,
            GradientDrawable.Orientation.LEFT_RIGHT,
            GradientDrawable.Orientation.TL_BR
    )
    private var isLongPressed = false

    interface setOnItemClickListener {
        fun OnItemClicked(color: GradientSelectableModel?, i: Int)
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): MyViewHolder {
        return MyViewHolder(LayoutInflater.from(mContext).inflate(R.layout.rv_gradient_selectable, null))
    }

    override fun onBindViewHolder(myViewHolder: MyViewHolder, i: Int) {
        val colors = intArrayOf(mColors[i].colorModel.color1, mColors[i].colorModel.color2)
        mCurrentOrientation = (mCurrentOrientation + 1) % orientations.size
        if (mColors[i].colorModel.circle) {
            val shape = GradientDrawable()
            shape.shape = GradientDrawable.RECTANGLE
            shape.colors = colors
            shape.cornerRadius = 24f
            shape.gradientType = GradientDrawable.RADIAL_GRADIENT
            shape.gradientRadius = myViewHolder.imgColor.width.toFloat()
            myViewHolder.colorImage.background = shape
        } else {
            val shape = GradientDrawable(mColors[i].colorModel.orientation, colors)
            shape.shape = GradientDrawable.RECTANGLE
            //shape.setColor(mColors.get(i));
            shape.cornerRadius = 24f
            myViewHolder.colorImage.background = shape
        }
        if (isLongPressed) {
            myViewHolder.checkbox.visibility = View.VISIBLE
        } else {
            myViewHolder.checkbox.visibility = View.GONE
        }
        if (mColors[i].isDeletable) {
            myViewHolder.checkbox.isChecked = true
        } else {
            myViewHolder.checkbox.isChecked = false
        }
        myViewHolder.checkbox.setOnClickListener {
            if (mColors[i].isDeletable) {
                myViewHolder.checkbox.isChecked = false
                mColors[i].isDeletable = false
            } else {
                myViewHolder.checkbox.isChecked = true
                mColors[i].isDeletable = true
                if (i != lastSelected) {
                    mColors[lastSelected].isDeletable = false
                    notifyItemChanged(i)
                    notifyItemChanged(lastSelected)
                    lastSelected = i
                }
            }
        }
        myViewHolder.imgColor.setOnClickListener {
            if (myViewHolder.checkbox.visibility == View.VISIBLE) {
                if (myViewHolder.checkbox.isChecked) {
                    myViewHolder.checkbox.isChecked = false
                    mColors[i].isDeletable = false
                } else {
                    myViewHolder.checkbox.isChecked = true
                    mColors[i].isDeletable = true
                    if (i != lastSelected) {
                        mColors[lastSelected].isDeletable = false
                        notifyItemChanged(i)
                        notifyItemChanged(lastSelected)
                        lastSelected = i
                    }
                }
            } else {
                isLongPressed = true
                lastSelected = i
                mColors[i].isDeletable = true
                notifyDataSetChanged()
            }
            mListener.OnItemClicked(mColors[i], i)
        }
    }

    fun setDataChange() {
        mColors[lastSelected].isDeletable = false
        notifyItemChanged(lastSelected)
    }

    override fun getItemCount(): Int {
        return mColors.size
    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var imgColor: CardView = itemView.findViewById(R.id.imgColor)
        val colorImage: ImageView = itemView.findViewById(R.id.colorImage)
        val checkbox: CheckBox = itemView.findViewById(R.id.checkbox)

    }

}