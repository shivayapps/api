package com.hd.wallpaper.solid.color.background.adData

class AdDetailModel(var id: Int, var app_id: Int, var position: Int, var name: String, var thumb_image: String, var app_link: String, var package_name: String, var full_thumb_image: String)