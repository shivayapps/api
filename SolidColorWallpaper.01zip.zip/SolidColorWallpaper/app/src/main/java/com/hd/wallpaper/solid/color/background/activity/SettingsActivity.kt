package com.hd.wallpaper.solid.color.background.activity

import android.animation.Animator
import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.app.ProgressDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.net.Uri
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.widget.ContentLoadingProgressBar
import com.airbnb.lottie.LottieAnimationView
import com.wifiproxysettingslibrary.NetworkHelper
import com.google.android.material.snackbar.Snackbar

import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.SolidWallpaperApplication
import com.hd.wallpaper.solid.color.background.constants.Constants
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs.getBoolean
import com.hd.wallpaper.solid.color.background.shared_pref.MySharedPref
import com.suke.widget.SwitchButton
import org.jsoup.Jsoup
import java.util.*

class SettingsActivity : AppCompatActivity(), View.OnClickListener {
    private var icBack: ImageView? = null
    private var btnShareApp: ImageView? = null
    private var switchVibrate: SwitchButton? = null
    private var lyLanguage: ConstraintLayout? = null
    private var llMoreApps: LinearLayout? = null
    private var llShareApps: LinearLayout? = null
    private var btnFill: ConstraintLayout? = null
    private var btnFit: ConstraintLayout? = null
    private var vibrate: ConstraintLayout? = null
    private var checkUpdate: ConstraintLayout? = null
    private var checkVersion: ConstraintLayout? = null
    private var lySubscribe: ConstraintLayout? = null
    private var lyCoinPurchase: ConstraintLayout? = null
    private var sharedPreferences: MySharedPref? = null
    private var txt121110:TextView?=null
    private var txt1211:TextView?=null
    private var txt221:TextView?=null
    private var radioFit: RadioButton? = null
    private var radioFill: RadioButton? = null
    private var txtVibrate: TextView? = null
    private var languageText: TextView? = null
    private var txtUpdate: TextView? = null
    private var currentVersion: String? = null
    private var contentLoadingUpdate: ContentLoadingProgressBar? = null
    private var successAnimation: LottieAnimationView? = null
    private var isNewversionAvailable = false
    private var isUptodate = false
    private var failureNewVersion: ImageView? = null
    private var ProductKey = ""
    private var LicenseKey = ""
    var dialog:Dialog?=null
    private val mUpgradeDialog: ProgressDialog? = null
    private var mActivity: Activity? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        System.gc()

//        if (Constants.isCoin) {
////            Log.e("121212", "onCreate: onCreate")
//            startActivity(Intent(this, CoinPurchaseActivity::class.java))
//            Constants.isCoin = false
//        }
        initViews()
        initListner()
        initViewAction()
    }

    private fun initViewAction() {
        sharedPreferences = MySharedPref(this@SettingsActivity)
        mActivity = this@SettingsActivity
        ProductKey = getString(R.string.ads_product_key)
        LicenseKey = getString(R.string.licenseKey)
        btnShareApp!!.visibility = View.VISIBLE
//        txt1211!!.visibility=View.VISIBLE
        if (getBoolean(this@SettingsActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
//            lySubscribe!!.visibility = View.GONE
            txt121110!!.visibility=View.VISIBLE
            txt1211!!.visibility=View.INVISIBLE
            txt221!!.visibility=View.INVISIBLE
            lySubscribe!!.isEnabled=false
        }
        else
        {
            txt121110!!.visibility=View.INVISIBLE
            txt1211!!.visibility=View.VISIBLE
            txt221!!.visibility=View.VISIBLE
            lySubscribe!!.isEnabled=true
        }

        switchVibrate!!.isChecked = sharedPreferences!!.vibration

        if (sharedPreferences!!.scale == "fill") {
            radioFill!!.isChecked = true
            radioFit!!.isChecked = false
        } else {
            radioFill!!.isChecked = false
            radioFit!!.isChecked = true
        }
        languageText!!.text = sharedPreferences!!.language
        contentLoadingUpdate!!.hide()
        try {
            currentVersion = packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
        }
        successAnimation!!.addAnimatorListener(object : Animator.AnimatorListener {
            override fun onAnimationStart(animation: Animator) {}
            override fun onAnimationEnd(animation: Animator) {
                successAnimation!!.pauseAnimation()
            }

            override fun onAnimationCancel(animation: Animator) {}
            override fun onAnimationRepeat(animation: Animator) {}
        })
        contentLoadingUpdate!!.show()
        updateChecks()
        switchVibrate!!.setOnCheckedChangeListener { _: SwitchButton?, isChecked: Boolean ->
            sharedPreferences!!.vibration = isChecked
            if (isChecked) {
                txtVibrate!!.text = resources.getString(R.string.vibrate_when_set_wall)
            } else {
                txtVibrate!!.text = resources.getString(R.string.not_vibrate_when_set_wall)
            }
        }
        checkUpdate!!.setOnClickListener { v: View? ->
            Log.d("78451233312", "onClick: ")
            if (isNewversionAvailable) {
                gotoPlayStore()
            } else {
//                updateCheck()
            }
        }

        checkVersion!!.setOnClickListener {
            if (isNewversionAvailable) {
                gotoPlayStore()
            }else{
                Toast.makeText(this@SettingsActivity, "${resources.getString(R.string.version_up_to_date)}", Toast.LENGTH_SHORT).show()
            }
        }



        radioFit!!.setOnCheckedChangeListener { buttonView: CompoundButton?, isChecked: Boolean ->
            if (isChecked) {
                radioFill!!.isChecked = false
                sharedPreferences!!.setScaleType("fit")
                Toast.makeText(mActivity, resources.getString(R.string.toast_fit_message), Toast.LENGTH_SHORT).show()
            } else {
                radioFill!!.isChecked = true
                sharedPreferences!!.setScaleType("fill")
            }
        }
        radioFill!!.setOnCheckedChangeListener { buttonView: CompoundButton?, isChecked: Boolean ->
            if (isChecked) {
                radioFit!!.isChecked = false
                sharedPreferences!!.setScaleType("fill")
            } else {
                radioFit!!.isChecked = true
                sharedPreferences!!.setScaleType("fit")
            }
        }
    }

    private fun gotoPlayStore() {
        val appPackageName = packageName // getPackageName() from Context or Activity object
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$appPackageName")))
        } catch (anfe: ActivityNotFoundException) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$appPackageName")))
        }
    }

    private fun updateChecks() {
        Log.d("78451233312", "updateCheck: ")
        successAnimation!!.visibility = View.GONE
        failureNewVersion!!.visibility = View.GONE
        if (!NetworkHelper.isOnline(this)) {
            txtUpdate!!.text = resources.getString(R.string.no_internet_connection)
            contentLoadingUpdate!!.hide()
        } else {
            txtUpdate!!.text = resources.getString(R.string.dialog_msg_please_wait)
            contentLoadingUpdate!!.show()
            GetVersionCode().execute()
        }
    }

    private fun initListner() {
        icBack!!.setOnClickListener(this)
        lyLanguage!!.setOnClickListener(this)
        btnFill!!.setOnClickListener(this)
        btnFit!!.setOnClickListener(this)
        txtVibrate!!.setOnClickListener(this)
        vibrate!!.setOnClickListener(this)
        btnShareApp!!.setOnClickListener(this)
        lySubscribe!!.setOnClickListener(this)
        lyCoinPurchase!!.setOnClickListener(this)
        llMoreApps!!.setOnClickListener(this)
        llShareApps!!.setOnClickListener(this)
    }

    private fun initViews() {
        icBack = findViewById(R.id.icBack)
        lyLanguage = findViewById(R.id.lyLanguage)
        llMoreApps = findViewById(R.id.llMoreApps)
        llShareApps = findViewById(R.id.llShareApps)
        switchVibrate = findViewById(R.id.switchVibrate)
        btnFit = findViewById(R.id.btnFit)
        btnFill = findViewById(R.id.btnFill)
        radioFit = findViewById(R.id.radioFit)
        radioFill = findViewById(R.id.radioFill)
        txtVibrate = findViewById(R.id.txtVibrate)
        vibrate = findViewById(R.id.vibrate)
        checkUpdate = findViewById(R.id.checkUpdate)
        checkVersion = findViewById(R.id.checkVersion)
        languageText = findViewById(R.id.languageText)
        contentLoadingUpdate = findViewById(R.id.contentLoadingUpdate)
        txtUpdate = findViewById(R.id.txtUpdate)
        successAnimation = findViewById(R.id.successAnimation)
        failureNewVersion = findViewById(R.id.failureNewVersion)
        btnShareApp = findViewById(R.id.btnShareApp)
        lySubscribe = findViewById(R.id.lySubscribe)
        lyCoinPurchase = findViewById(R.id.lyCoinPurchase)
        txt121110=findViewById(R.id.txt121110)
        txt1211=findViewById(R.id.txt1211)
        txt221=findViewById(R.id.txt221)

    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.icBack -> onBackPressed()
            R.id.btnFit -> onClickFit()
            R.id.btnFill -> onClickFill()
            R.id.vibrate -> onClickVibrate()
            R.id.lyLanguage -> onclickLanguage()
            R.id.lySubscribe -> {
//                com.vasundhara.vision.subscription.constants.Constants.subActivity = "sub"
                startActivity(Intent(this@SettingsActivity, PremiumAccessActivity::class.java))
            }
            R.id.btnShareApp -> onclickShareApp()
            R.id.lyCoinPurchase -> {
                Log.e("TAG", "onClick: onClick")
//                com.vasundhara.vision.subscription.constants.Constants.subActivity = "coin"
                openCoinActivity()
//                startActivity(Intent(this@SettingsActivity, CoinPurchaseActivity::class.java))
            }
//            R.id.llMoreApps -> Handler().postDelayed({ startActivity(Intent(this@SettingsActivity, MoreAppActivityNew::class.java)) }, 200)
//            R.id.llMoreApps -> Handler().postDelayed({ startActivity(Intent(this@SettingsActivity, Class.forName("com.scribble.animation.maker.video.effect.myadslibrary.ui.MoreAppActivityNew"))) }, 200)
            R.id.llShareApps -> shareApp()
        }
    }

    fun openCoinActivity() {
        startActivity(Intent(this@SettingsActivity, CoinPurchaseActivity::class.java))

    }

    private fun shareApp() {
        val shareIntent = Intent(Intent.ACTION_SEND)
        shareIntent.type = "text/plain"
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Solid Color Wallpaper")
        var shareMessage = "\nGo with Solid Color Wallpaper and Make Colorful Wallpapers\n\n"
        shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=com.solid.color.wallpaper.hd.image.background"
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
        startActivity(Intent.createChooser(shareIntent, resources.getString(R.string.choose_one)))
    }

    private fun onclickShareApp() {
        val shareIntent = Intent(Intent.ACTION_SEND)
        shareIntent.type = "text/plain"
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Solid Color Wallpaper")
        var shareMessage = ""
        shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=com.solid.color.wallpaper.hd.image.background"
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
        startActivity(Intent.createChooser(shareIntent, resources.getString(R.string.choose_one)))
    }

    /* private void onclickRemoveAds() {
        if (mBillingProcessor != null) {

            mUpgradeDialog = ProgressDialog.show(mActivity, getResources().getString(R.string.dialog_msg_please_wait), "", true);

            */
    /* TODO: for security, generate your payload here for verification. See the comments on
     *        verifyDeveloperPayload() for more info. Since this is a SAMPLE, we just use
     *        an empty string, but on a production app you should carefully generate this. */
    /*
            String payload = "";

            mBillingProcessor.purchase(mActivity, ProductKey, payload);
            mUpgradeDialog.dismiss();

        } else {

            if (mUpgradeDialog != null && mUpgradeDialog.isShowing()) {
                mUpgradeDialog.dismiss();
            }
            showSnackBar(getResources().getString(R.string.something_went_wrong));
            //  Toast.makeText(mActivity, getResources().getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show();
        }
    }*/
    private fun onClickVibrate() {
        if (switchVibrate!!.isChecked) {
            switchVibrate!!.isChecked = false
        } else {
            switchVibrate!!.isChecked = true
        }
        sharedPreferences!!.vibration = switchVibrate!!.isChecked
        if (switchVibrate!!.isChecked) {
            txtVibrate!!.text = resources.getString(R.string.vibrate_when_set_wall)
        } else {
            txtVibrate!!.text = resources.getString(R.string.not_vibrate_when_set_wall)
        }
    }

    private fun onClickFill() {
        radioFill!!.isChecked = true
        radioFit!!.isChecked = false
        sharedPreferences!!.setScaleType("Fill")
    }

    private fun onClickFit() {
        radioFill!!.isChecked = false
        radioFit!!.isChecked = true
        sharedPreferences!!.setScaleType("Fit")
        Toast.makeText(mActivity, resources.getString(R.string.toast_fit_message), Toast.LENGTH_SHORT).show()
    }

    @SuppressLint("SetTextI18n")
    private fun onclickLanguage() {
        dialog = Dialog(this@SettingsActivity)
        dialog!!.setContentView(R.layout.dialog_language_select)
        Objects.requireNonNull(dialog!!.window)!!.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)
        val checkSpanish = dialog!!.findViewById<ImageView>(R.id.checkSpanish)
        val checkEnglish = dialog!!.findViewById<ImageView>(R.id.checkEnglish)
        val checkRussian = dialog!!.findViewById<ImageView>(R.id.checkRussian)
        val checkPortuguese = dialog!!.findViewById<ImageView>(R.id.checkPortuguese)
        val checkTurkish = dialog!!.findViewById<ImageView>(R.id.checkTurkish)
        val checkArabic = dialog!!.findViewById<ImageView>(R.id.checkArabic)
        val txtEnglish = dialog!!.findViewById<TextView>(R.id.txtEnglish)
        val txtTurkish = dialog!!.findViewById<TextView>(R.id.txtTurkish)
        val txtSpanish = dialog!!.findViewById<TextView>(R.id.txtSpanish)
        val txtRussian = dialog!!.findViewById<TextView>(R.id.txtRussian)
        val txtArabic = dialog!!.findViewById<TextView>(R.id.txtArabic)
        val txtPortuguese = dialog!!.findViewById<TextView>(R.id.txtPortuguese)
        val btnPositive = dialog!!.findViewById<Button>(R.id.btnPositive)
        val btnNagative = dialog!!.findViewById<Button>(R.id.btnNagative)
        if (sharedPreferences!!.language.equals("English", ignoreCase = true)) {
            checkEnglish.visibility = View.VISIBLE
            checkRussian.visibility = View.GONE
            checkSpanish.visibility = View.GONE
            checkArabic.visibility = View.GONE
            checkTurkish.visibility = View.GONE
            checkPortuguese.visibility = View.GONE
        } else if (sharedPreferences!!.language.equals("Pусский", ignoreCase = true)) {
            checkEnglish.visibility = View.GONE
            checkRussian.visibility = View.VISIBLE
            checkSpanish.visibility = View.GONE
            checkTurkish.visibility = View.GONE
            checkArabic.visibility = View.GONE
            checkPortuguese.visibility = View.GONE
        } else if (sharedPreferences!!.language.equals("Portuguesa", ignoreCase = true)) {
            checkEnglish.visibility = View.GONE
            checkRussian.visibility = View.GONE
            checkTurkish.visibility = View.GONE
            checkSpanish.visibility = View.GONE
            checkArabic.visibility = View.GONE
            checkPortuguese.visibility = View.VISIBLE
        } else if (sharedPreferences!!.language.equals("Española", ignoreCase = true)) {
            checkEnglish.visibility = View.GONE
            checkRussian.visibility = View.GONE
            checkTurkish.visibility = View.GONE
            checkSpanish.visibility = View.VISIBLE
            checkArabic.visibility = View.GONE
            checkPortuguese.visibility = View.GONE
        } else if (sharedPreferences!!.language.equals("عربى", ignoreCase = true)) {
            checkEnglish.visibility = View.GONE
            checkRussian.visibility = View.GONE
            checkSpanish.visibility = View.GONE
            checkArabic.visibility = View.VISIBLE
            checkTurkish.visibility = View.GONE
            checkPortuguese.visibility = View.GONE
        } else {
            checkEnglish.visibility = View.GONE
            checkRussian.visibility = View.GONE
            checkSpanish.visibility = View.GONE
            checkArabic.visibility = View.GONE
            checkTurkish.visibility = View.VISIBLE
            checkPortuguese.visibility = View.GONE
        }
        txtEnglish.setOnClickListener {
            checkEnglish.visibility = View.VISIBLE
            checkRussian.visibility = View.GONE
            checkSpanish.visibility = View.GONE
            checkTurkish.visibility = View.GONE
            checkArabic.visibility = View.GONE
            checkPortuguese.visibility = View.GONE
        }
        txtSpanish.setOnClickListener { v: View? ->
            checkEnglish.visibility = View.GONE
            checkRussian.visibility = View.GONE
            checkSpanish.visibility = View.VISIBLE
            checkTurkish.visibility = View.GONE
            checkArabic.visibility = View.GONE
            checkPortuguese.visibility = View.GONE
        }
        txtRussian.setOnClickListener { v: View? ->
            checkEnglish.visibility = View.GONE
            checkRussian.visibility = View.VISIBLE
            checkSpanish.visibility = View.GONE
            checkTurkish.visibility = View.GONE
            checkArabic.visibility = View.GONE
            checkPortuguese.visibility = View.GONE
        }
        txtPortuguese.setOnClickListener { v: View? ->
            checkEnglish.visibility = View.GONE
            checkRussian.visibility = View.GONE
            checkSpanish.visibility = View.GONE
            checkTurkish.visibility = View.GONE
            checkArabic.visibility = View.GONE
            checkPortuguese.visibility = View.VISIBLE
        }
        txtArabic.setOnClickListener { v: View? ->
            checkEnglish.visibility = View.GONE
            checkRussian.visibility = View.GONE
            checkTurkish.visibility = View.GONE
            checkSpanish.visibility = View.GONE
            checkArabic.visibility = View.VISIBLE
            checkPortuguese.visibility = View.GONE
        }
        txtTurkish.setOnClickListener { v: View? ->
            checkEnglish.visibility = View.GONE
            checkRussian.visibility = View.GONE
            checkSpanish.visibility = View.GONE
            checkTurkish.visibility = View.VISIBLE
            checkArabic.visibility = View.GONE
            checkPortuguese.visibility = View.GONE
        }
        btnNagative.setOnClickListener { dialog!!.dismiss() }
        btnPositive.setOnClickListener {
            sharedPreferences!!.noNeedToShowLanguage()
            dialog!!.dismiss()
            if (checkEnglish.visibility == View.VISIBLE) {
                if (!sharedPreferences!!.language.equals("English", ignoreCase = true)) {
                    sharedPreferences!!.language = "English"
                    languageText!!.text = "English"
                    val locale = Locale("en")
                    changeLanguage(locale)
                }
            } else if (checkRussian.visibility == View.VISIBLE) {
                if (!sharedPreferences!!.language.equals("Pусский", ignoreCase = true)) {
                    sharedPreferences!!.language = "Pусский"
                    languageText!!.text = "Pусский"
                    val locale = Locale("ru")
                    changeLanguage(locale)
                }
            } else if (checkSpanish.visibility == View.VISIBLE) {
                if (!sharedPreferences!!.language.equals("Española", ignoreCase = true)) {
                    sharedPreferences!!.language = "Española"
                    languageText!!.text = "Española"
                    val locale = Locale("es")
                    changeLanguage(locale)
                }
            } else if (checkPortuguese.visibility == View.VISIBLE) {
                if (!sharedPreferences!!.language.equals("Portuguesa", ignoreCase = true)) {
                    sharedPreferences!!.language = "Portuguesa"
                    languageText!!.text = "Portuguesa"
                    val locale = Locale("pt")
                    changeLanguage(locale)
                }
            } else if (checkArabic.visibility == View.VISIBLE) {
                if (!sharedPreferences!!.language.equals("عربى", ignoreCase = true)) {
                    sharedPreferences!!.language = "عربى"
                    languageText!!.text = "عربى"
                    val locale = Locale("ar")
                    changeLanguage(locale)
                }
            } else if (checkTurkish.visibility == View.VISIBLE) {
                if (!sharedPreferences!!.language.equals("Türkçe", ignoreCase = true)) {
                    sharedPreferences!!.language = "Türkçe"
                    languageText!!.text = "Türkçe"
                    val locale = Locale("tr")
                    changeLanguage(locale)
                }
            }

            SolidWallpaperApplication.staticLanguage.Factory.create(this)
        }
        dialog!!.show()
    }

    override fun onPause() {
        super.onPause()
        try {
            dialog!!.dismiss()
        }catch (e:Exception){

        }
    }

    private fun changeLanguage(locale: Locale) {
        Locale.setDefault(locale)
        val config = Configuration()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            config.setLocale(locale)
        } else {
            config.locale = locale
        }
        resources.updateConfiguration(config, resources.displayMetrics)
        Constants.isLanguageChanged = true

        //  if (Build.VERSION.SDK_INT == 28) {
        /*Intent i = new Intent(SettingsActivity.this, SplashScreenActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            Runtime.getRuntime().exit(0);*/
        //    } else {
        recreate()
        if (Build.VERSION.SDK_INT == 28) {
            recreate()
        }
        //   }
    }
//
//    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        super.onActivityResult(requestCode, resultCode, data)
//        if (mBillingProcessor != null) {
//            if (!mBillingProcessor!!.handleActivityResult(requestCode, resultCode, data)) {
//                super.onActivityResult(requestCode, resultCode, data)
//            }
//        }
//    }

//    override fun onProductPurchased(productId: String, details: TransactionDetails?) {
//        if (mUpgradeDialog != null && mUpgradeDialog.isShowing) {
//            mUpgradeDialog.dismiss()
//        }
//
//        //  Toast.makeText(mActivity, getResources().getString(R.string.successfully_purchased), Toast.LENGTH_SHORT).show();
//        showSnackBar(resources.getString(R.string.successfully_purchased))
//        //  sharedPreferences.setAdsRemoved();
//        startAnimation()
//        Log.d("7871215745", "onProductPurchased: ")
//    }

    fun showSnackBar(msg: String?) {
        val snackbar = Snackbar.make(findViewById(R.id.mainLayout), msg!!, Snackbar.LENGTH_SHORT)
        val v = snackbar.view
        val params = v.layoutParams as CoordinatorLayout.LayoutParams
        params.width = FrameLayout.LayoutParams.MATCH_PARENT
        v.layoutParams = params
        v.setBackgroundColor(Color.WHITE)
        val textView = v.findViewById<TextView>(com.google.android.material.R.id.snackbar_text)
        textView.setTextColor(resources.getColor(R.color.text_colour_new))
        snackbar.show()
    }

    private fun startAnimation() {
        btnShareApp!!.alpha = 0f
        btnShareApp!!.visibility = View.VISIBLE
        btnShareApp!!.animate()
                .alpha(1f)
                .setDuration(500)
                .setListener(null)
    }

//    override fun onPurchaseHistoryRestored() {
//        Log.d("7871215745", "onPurchaseHistoryRestored: ")
//    }
//
//    override fun onBillingError(errorCode: Int, error: Throwable?) {
//        Log.d("7871215745", "onBillingError: ")
//        showSnackBar(resources.getString(R.string.something_went_wrong))
//    }
//
//    override fun onBillingInitialized() {
//        Log.d("7871215745", "onBillingInitialized: ")
//    }

    @SuppressLint("StaticFieldLeak")
    private inner class GetVersionCode : AsyncTask<Void?, String?, String?>() {
        protected override fun doInBackground(vararg params: Void?): String? {
            val newVersion: String
            return try {
                newVersion = Jsoup.connect("https://play.google.com/store/apps/details?id=$packageName&hl=it")
                        .timeout(30000)
                        .userAgent("Mozilla/5.0 (Windows; U; WindowsNT 5.1; en-US; rv1.8.1.6) Gecko/20070725 Firefox/2.0.0.6")
                        .referrer("http://www.google.com")
                        .get()
                        .select(".hAyfc .htlgb")[7]
                        .ownText()
                newVersion
            } catch (e: Exception) {
                null
            }
        }

        override fun onPostExecute(onlineVersion: String?) {
            super.onPostExecute(onlineVersion)
            if (onlineVersion != null && onlineVersion.isNotEmpty()) {
                if (currentVersion != onlineVersion) {
                    isNewversionAvailable = true
                    Log.d("Pankaj", "onPostExecute: version update require")
                    failureNewVersion!!.visibility = View.VISIBLE
                    txtUpdate!!.text = resources.getString(R.string.newer_version_available)

                    val shake: Animation =
                        AnimationUtils.loadAnimation(this@SettingsActivity,R.anim.shake)
                    checkVersion!!.startAnimation(shake)
                } else {
                    isNewversionAvailable = false
                    isUptodate = true
                    checkUpdate!!.isEnabled = false
//                    checkVersion!!.isEnabled = false
                    successAnimation!!.visibility = View.VISIBLE
                    txtUpdate!!.text = resources.getString(R.string.version_up_to_date)
                }
                contentLoadingUpdate!!.hide()
                return
            }
            contentLoadingUpdate!!.hide()
            txtUpdate!!.text = resources.getString(R.string.no_internet_connection)
            Log.d("update", "Current version " + currentVersion + "playstore version " + onlineVersion)
        }
    }


    override fun onResume() {
        super.onResume()


//        if (Constants.isCoin) {
//            initViews()
//            initListner()
//            initViewAction()
//            if (lyCoinPurchase != null) {
//                lyCoinPurchase!!.performClick()
//            }
//            Log.e("TAG", "onResume: onResume" )
//            Constants.isCoin = false
//        }

        SolidWallpaperApplication.staticLanguage.Factory.create(this)
        //  }
        if (getBoolean(this, AdsPrefs.IS_SUBSCRIBED, false)) {
            findViewById<View>(R.id.lyCoinPurchase).visibility = View.GONE
//            findViewById<View>(R.id.lySubscribe).visibility = View.GONE
            txt121110!!.visibility=View.VISIBLE
            txt1211!!.visibility=View.INVISIBLE
            txt221!!.visibility=View.INVISIBLE
            lySubscribe!!.isEnabled=false
        }
        else
        {
            findViewById<View>(R.id.lyCoinPurchase).visibility = View.VISIBLE
//            findViewById<View>(R.id.lySubscribe).visibility = View.GONE
            txt121110!!.visibility=View.INVISIBLE
            txt1211!!.visibility=View.VISIBLE
            txt221!!.visibility=View.VISIBLE
            lySubscribe!!.isEnabled=true
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }
}