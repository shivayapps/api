package com.gallery.photo.image.video.ui.adapter

import android.app.Activity
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.ItemAlbumGridBinding
import com.gallery.photo.image.video.databinding.ItemAlbumListBinding
import com.gallery.photo.image.video.ui.model.AlbumData
import com.gallery.photo.image.video.utils.Preferences

class AlbumAdapter(
    var context: Activity,
    var albumList: ArrayList<AlbumData>,
    val clickListener: (pos: Int) -> Unit
) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    val ITEM_ALBUM_GRID_TYPE = 2
    val ITEM_ALBUM_LIST_TYPE = 1

    var preferences: Preferences = Preferences(context)

    override fun getItemViewType(position: Int): Int {
        return if (preferences.getShowGrid()) {
            ITEM_ALBUM_GRID_TYPE
        } else {
            ITEM_ALBUM_LIST_TYPE
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == ITEM_ALBUM_GRID_TYPE)   {
            val binding =
                ItemAlbumGridBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            AlbumGridViewHolder(binding)
        } else {
            val binding =
                ItemAlbumListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            AlbumListViewHolder(binding)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (getItemViewType(position) == ITEM_ALBUM_GRID_TYPE) {
            val albumGridViewHolder = holder as AlbumGridViewHolder
            val albumData: AlbumData = albumList[position]

            albumGridViewHolder.binding.txtTitle.text = albumData.title
            if (albumData.pictureData.isNotEmpty()) {
                albumGridViewHolder.binding.txtCount.text = "${albumData.pictureData.size}"

                Glide.with(context.applicationContext).load(albumData.pictureData[0].filePath)
                   .into(albumGridViewHolder.binding.image)

            } else {
                albumGridViewHolder.binding.txtCount.text = "0"
            }
            albumGridViewHolder.binding.root.setOnClickListener {
                clickListener(position)
            }
        } else {
            val albumGridViewHolder = holder as AlbumListViewHolder
            val albumData: AlbumData = albumList[position]

            albumGridViewHolder.binding.txtTitle.text = albumData.title
            if (albumData.pictureData.isNotEmpty()) {
                albumGridViewHolder.binding.txtCount.text =
                    "${albumData.pictureData.size} ${context.getString(R.string.items)}"

                Glide.with(context.applicationContext).load(albumData.pictureData[0].filePath)
                   .into(albumGridViewHolder.binding.image)

            } else {
                albumGridViewHolder.binding.txtCount.text = "0 ${context.getString(R.string.items)}"
            }

            albumGridViewHolder.binding.root.setOnClickListener {
                clickListener(position)
            }
        }
    }

    override fun getItemCount(): Int {
        return albumList.size
    }

    class AlbumGridViewHolder(var binding: ItemAlbumGridBinding) :
        RecyclerView.ViewHolder(binding.root) {
            var map = binding.root
        }

    class AlbumListViewHolder(var binding: ItemAlbumListBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }
}