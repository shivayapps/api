package com.gallery.photo.image.video.duplicat_function.utils_duplicat;

import com.gallery.photo.image.video.duplicat_function.flow.Flow;
import com.gallery.photo.image.video.duplicat_function.flow.Predicate;

import java.io.File;
import java.io.FileFilter;
import java.util.Set;


public class DupFileFilter implements FileFilter {
    private static final String TAG = DupFileFilter.class.getSimpleName();
    private final Set<String> lSkipDirs;
    final boolean scanHiddenFile;
    final String scanType;

    public DupFileFilter(String str, boolean z, Set<String> set) {
        this.lSkipDirs = set;
        this.scanHiddenFile = z;
        this.scanType = str;
    }

    @Override
    public boolean accept(File file) {
        if (this.scanHiddenFile || !file.getName().startsWith(".")) {
            if (file.isDirectory()) {
                if (skipDirectory(file.getAbsolutePath())) {
                    return false;
                }
                "Android".equals(file.getName());
                return true;
            } else if (DuplicateConstants.Type.ALL.equals(this.scanType)) {
                return true;
            } else {
                String fileType = DuplicateConstants.getFileType(file.getAbsolutePath());
                if (DuplicateConstants.Type.IMAGE.equals(this.scanType)) {
                    return fileType.equals(DuplicateConstants.Type.IMAGE);
                }
                if (DuplicateConstants.Type.VIDEO.equals(this.scanType)) {
                    return fileType.equals(DuplicateConstants.Type.VIDEO);
                }
                if (DuplicateConstants.Type.AUDIO.equals(this.scanType)) {
                    return fileType.equals(DuplicateConstants.Type.AUDIO);
                }
                if (!DuplicateConstants.Type.OTHER.equals(this.scanType)) {
                    return false;
                }
                return fileType.equals(DuplicateConstants.Type.OTHER);
            }
        }
        return false;
    }

    private boolean skipDirectory(final String str) {
        Flow of = Flow.of(this.lSkipDirs);
        str.getClass();
        return of.anyMatch(new Predicate() {
            @Override
            public final boolean test(Object obj) {
                return str.startsWith((String) obj);
            }
        });
    }
}
