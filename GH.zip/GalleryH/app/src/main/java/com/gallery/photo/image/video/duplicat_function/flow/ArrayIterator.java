package com.gallery.photo.image.video.duplicat_function.flow;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class ArrayIterator<T> implements Iterator<T> {
    private int index = 0;
    private T[] ts;

    ArrayIterator(T[] tArr) {
        this.ts = tArr;
    }

    @Override 
    public boolean hasNext() {
        return this.index < this.ts.length;
    }

    @Override 
    public T next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        T[] tArr = this.ts;
        int i = this.index;
        this.index = i + 1;
        return tArr[i];
    }

    @Override 
    public void remove() {
        throw new UnsupportedOperationException("remove not supported");
    }
}
