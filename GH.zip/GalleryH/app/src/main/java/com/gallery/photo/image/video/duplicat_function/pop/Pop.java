package com.gallery.photo.image.video.duplicat_function.pop;

import android.app.Activity;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.view.ViewGroup;

import androidx.appcompat.app.AlertDialog;

import com.gallery.photo.image.video.R;


public class Pop {
    private Aah aah;
    private int aahButtonName;
    private Activity activity;
    private AlertDialog alertDialog;
    private AlertDialog.Builder builder;
    private android.view.View lView;
    private Nah nah;
    private int nahButtonName;
    private View popView;
    private Yah yah;
    private int yahButtonName;

    
    public interface Aah extends Clickable {
    }

    
    private interface Clickable {
        void clicked(DialogInterface dialogInterface, android.view.View view);
    }

    
    public interface Nah extends Clickable {
    }

    
    public interface View {
        void prepare(android.view.View view);
    }

    
    public interface Yah extends Clickable {
    }

    public Pop with() {
        return this;
    }

    protected Pop(Activity activity) {
        this.activity = activity;
        this.builder = new AlertDialog.Builder(activity);
    }

    public static Pop on(Activity activity) {
        return new Pop(activity);
    }

    public Pop title(int i) {
        this.builder.setTitle(i);
        return this;
    }

    public Pop title(android.view.View view) {
        this.builder.setCustomTitle(view);
        return this;
    }

    public Pop icon(Drawable drawable) {
        this.builder.setIcon(drawable);
        return this;
    }

    public Pop cancelable(boolean z) {
        this.builder.setCancelable(z);
        return this;
    }

    public Pop icon(int i) {
        this.builder.setIcon(i);
        return this;
    }

    public Pop title(CharSequence charSequence) {
        this.builder.setTitle(charSequence);
        return this;
    }

    public Pop body(int i) {
        this.builder.setMessage(i);
        return this;
    }

    public Pop body(android.view.View view) {
        this.builder.setView(view);
        return this;
    }

    public Pop body(CharSequence charSequence) {
        this.builder.setMessage(charSequence);
        return this;
    }

    public Pop layout(int i) {
        android.view.View inflate = this.activity.getLayoutInflater().inflate(i, (ViewGroup) null);
        this.lView = inflate;
        this.builder.setView(inflate);
        return this;
    }

    private void createDialog() {
        if (this.yah != null) {
            int i = this.yahButtonName;
            if (i == 0) {
                i = R.string.ok;
            }
            this.builder.setPositiveButton(i, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i2) {
                    Pop.this.yah.clicked(dialogInterface, Pop.this.lView);
                }
            });
        }
        if (this.nah != null) {
            int i2 = this.nahButtonName;
            if (i2 == 0) {
                i2 = R.string.cancel;
            }
            this.builder.setNegativeButton(i2, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i3) {
                    Pop.this.nah.clicked(dialogInterface, Pop.this.lView);
                }
            });
        }
        if (this.aah != null) {
            int i3 = this.aahButtonName;
            if (i3 == 0) {
                i3 = R.string.neutral;
            }
            this.builder.setNegativeButton(i3, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i4) {
                    Pop.this.aah.clicked(dialogInterface, Pop.this.lView);
                }
            });
        }
        AlertDialog create = this.builder.create();
        this.alertDialog = create;
        create.show();
    }

    public AlertDialog show() {
        createDialog();
        return this.alertDialog;
    }

    public AlertDialog show(View view) {
        view.prepare(this.lView);
        createDialog();
        return this.alertDialog;
    }

    public Pop when(Yah yah) {
        this.yah = yah;
        return this;
    }

    public Pop when(Aah aah) {
        this.aah = aah;
        return this;
    }

    public Pop when(Nah nah) {
        this.nah = nah;
        return this;
    }

    public Pop when(int i, Yah yah) {
        this.yah = yah;
        this.yahButtonName = i;
        return this;
    }

    public Pop when(int i, Aah aah) {
        this.aah = aah;
        this.aahButtonName = i;
        return this;
    }

    public Pop when(int i, Nah nah) {
        this.nah = nah;
        this.nahButtonName = i;
        return this;
    }

    
    public class NahImpl implements Nah {
        public NahImpl() {
        }

        @Override
        public void clicked(DialogInterface dialogInterface, android.view.View view) {
            if (dialogInterface != null) {
                dialogInterface.dismiss();
            }
        }
    }
}
