package com.gallery.photo.image.video.duplicat_function.utils_duplicat;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.webkit.MimeTypeMap;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.util.Locale;


public class FilenameUtil {


    public static int indexOfLastSeparator(String str) {
        if (str == null) {
            return -1;
        }
        return Math.max(str.lastIndexOf(47), str.lastIndexOf(92));
    }

    public static int indexOfExtension(String str) {
        int lastIndexOf;
        if (str != null && indexOfLastSeparator(str) <= (lastIndexOf = str.lastIndexOf(46))) {
            return lastIndexOf;
        }
        return -1;
    }

    public static String getExtension(String str) {
        if (str == null) {
            return null;
        }
        int indexOfExtension = indexOfExtension(str);
        return indexOfExtension == -1 ? "" : str.substring(indexOfExtension + 1).toLowerCase(Locale.US);
    }

    public static void fileViewer(Context context, String str) {
        Uri fromFile;
        if (str == null || "".equals(str)) {
            return;
        }
        String extension = getExtension(str);
        try {
            Intent intent = new Intent("android.intent.action.VIEW");
            if (Build.VERSION.SDK_INT >= 24) {
                fromFile = FileProvider.getUriForFile(context, "com.recoverdata.deletedata.secondduplicatdecodedemo.provider", new File(str));
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } else {
                fromFile = Uri.fromFile(new File(str));
            }
            String mimeTypeFromExtension = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
            if (mimeTypeFromExtension != null) {
                intent.setType(mimeTypeFromExtension);
            }
            intent.setDataAndType(fromFile, mimeTypeFromExtension);
            context.startActivity(intent);
        } catch (ActivityNotFoundException unused) {
            Toast.makeText(context, "not availab app", Toast.LENGTH_SHORT).show();
        } catch (Exception unused2) {
            Toast.makeText(context, "can not open file", Toast.LENGTH_SHORT).show();
        }
    }
}
