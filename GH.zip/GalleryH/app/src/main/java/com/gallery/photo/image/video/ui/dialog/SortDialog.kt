package com.gallery.photo.image.video.ui.dialog

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.firebase.analytics.FirebaseAnalytics
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.DialogSortingBinding
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.Preferences

class SortDialog(val updateListener: () -> Unit) :
    BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogSortingBinding
    lateinit var firebaseAnalytics: FirebaseAnalytics
    lateinit var preferences: Preferences
    var sortType = 0
    var sortOrder = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogSortingBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {
        preferences = Preferences(requireActivity())
        sortType = preferences.getSortType()
        sortOrder = preferences.getSortOrder()

        firebaseAnalytics = FirebaseAnalytics.getInstance(requireActivity())
        val bundle2 = Bundle()
        bundle2.putString("Sorting", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_dialog, bundle2)

        intListener()

        when (sortType) {
            Constant.SORT_NAME -> bindingDialog.rbName.isChecked = true
            Constant.SORT_PATH -> bindingDialog.rbPath.isChecked = true
            Constant.SORT_SIZE -> bindingDialog.rbSize.isChecked = true
            Constant.SORT_LAST_MODIFIED -> bindingDialog.rbLastModified.isChecked = true
            Constant.SORT_DATE_TAKEN -> bindingDialog.rbDateTaken.isChecked = true
        }

        when (sortOrder) {
            Constant.SORT_ASCENDING -> bindingDialog.rbAscending.isChecked = true
            Constant.SORT_DESCENDING -> bindingDialog.rbDescending.isChecked = true
        }
    }

    private fun intListener() {
        bindingDialog.btnCancel.setOnClickListener {
            dismiss()
        }
        bindingDialog.btnOK.setOnClickListener {
            val selectedRadioButtonId: Int = bindingDialog.grpOption.checkedRadioButtonId
            val selectedRadioButtonIdOrder: Int = bindingDialog.grpOrder.checkedRadioButtonId
            var selectedType = -1
            var selectedOrder = -1
            selectedType = when (selectedRadioButtonId) {
                bindingDialog.rbName.id -> Constant.SORT_NAME
                bindingDialog.rbPath.id -> Constant.SORT_PATH
                bindingDialog.rbSize.id -> Constant.SORT_SIZE
                bindingDialog.rbLastModified.id -> Constant.SORT_LAST_MODIFIED
                bindingDialog.rbDateTaken.id -> Constant.SORT_DATE_TAKEN
                else -> -1
            }
            selectedOrder = when (selectedRadioButtonIdOrder) {
                bindingDialog.rbAscending.id -> Constant.SORT_ASCENDING
                bindingDialog.rbDescending.id -> Constant.SORT_DESCENDING
                else -> -1
            }
            if (sortType != selectedType)
                preferences.setSortType(selectedType)
            if (sortOrder != selectedOrder)
                preferences.setSortOrder(selectedOrder)
            dismiss()
            if (sortType != selectedType || sortOrder != selectedOrder) {
                updateListener()

            }
        }
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}