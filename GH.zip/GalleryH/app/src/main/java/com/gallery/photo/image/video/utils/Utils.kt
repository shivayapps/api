package com.gallery.photo.image.video.utils

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.media.MediaScannerConnection
import android.net.Uri
import android.util.Log
import android.view.Gravity
import android.view.Window
import android.webkit.MimeTypeMap
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.database.AppDatabase
import com.gallery.photo.image.video.database.HiddenData
import com.gallery.photo.image.video.database.RecentDeleteData
import com.gallery.photo.image.video.ui.event.CopyMoveEvent
import com.gallery.photo.image.video.ui.event.DisplayDeleteEvent
import com.gallery.photo.image.video.ui.event.HideEvent
import com.gallery.photo.image.video.ui.event.RestoreDataEvent
import com.gallery.photo.image.video.ui.model.PictureData
import com.gallery.photo.image.video.ui.model.RestoreData
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import org.greenrobot.eventbus.EventBus
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.URLConnection

class Utils {
    fun getMimeTypeFromFilePath(filePath: String): String? {
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(getFilenameExtension(filePath))
    }

    fun getFilenameExtension(path: String): String {
        return path.substring(path.lastIndexOf(".") + 1)
    }

    fun isVideoFile(path: String): Boolean {
        val mimeType = URLConnection.guessContentTypeFromName(path)
        return mimeType != null && mimeType.startsWith("video")
    }

    fun shareFilesList(activity: Context, uris: ArrayList<Uri>) {
        val intent = Intent(Intent.ACTION_SEND_MULTIPLE)
        intent.type = "*/*"
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        MyApplication.disabledOpenAds()
        activity.startActivity(
            Intent.createChooser(
                intent,
                activity.getString(R.string.share_with)
            )
        )
    }

    fun shareFile(context: Context, filePath: String) {
        val file = File(filePath)
        val shareUri = FileProvider.getUriForFile(
            context,
            context.packageName + ".provider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND)
        intent.type = getMimeTypeFromFilePath(file.path)
        intent.putExtra(Intent.EXTRA_STREAM, shareUri)
        try {
            MyApplication.disabledOpenAds()
            context.startActivity(
                Intent.createChooser(
                    intent,
                    context.getString(R.string.share_with)
                )
            )
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(
                context,
                context.getString(R.string.no_supported_image),
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    fun fileDelete(context: Context, file: File): Boolean {
        val isDelete = file.delete()
        val deleteUrl = FileProvider.getUriForFile(
            context,
            "${context.packageName}.provider", file
        )
        val contentResolver = context.contentResolver
        contentResolver.delete(deleteUrl, null, null)

        MediaScannerConnection.scanFile(
            context, arrayOf<String>(file.path), null
        ) { path: String?, uri: Uri? -> }
        return isDelete
    }

    fun saveCompressImage(
        context: Context,
        imageFile: File,
        bitmap: Bitmap,
        quality: Int
    ): Boolean {
        val isDelete = fileDelete(context, imageFile)
        if (isDelete)
            try {
                val stream = FileOutputStream(imageFile)
                bitmap.compress(Bitmap.CompressFormat.JPEG, quality, stream)

                val mediaScanIntent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
                val contentUri = Uri.fromFile(imageFile)
                mediaScanIntent.data = contentUri
                context.sendBroadcast(mediaScanIntent)

                stream.flush()
                stream.close()

                MediaScannerConnection.scanFile(
                    context, arrayOf<String>(imageFile.path), null
                ) { path, uri ->
                    // Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
                }
                return true
            } catch (e: IOException) {
                e.printStackTrace()
            }
        return false
    }

    fun deleteFile(context: Context, filePath: String, dataBase: AppDatabase): Boolean {
        val file = File(filePath)
        val copyFileName = file.name
        val targetFolder = File(Constant.DELETE_PATH)
        if (!targetFolder.exists())
            targetFolder.mkdirs()
        val targetPath = targetFolder.path + File.separator + copyFileName
        val targetFile = File(targetPath)
        var deletedPath = ""
        var isDelete = false

        if (targetFile.exists()) {
            val separated =
                file.name.split("\\.".toRegex()).dropLastWhile { it.isEmpty() }
                    .toTypedArray()
            val name = separated[0]
            var type = ""
            if (separated.size != 1)
                type = "." + separated[1]
            val newPath2 =
                targetFolder.path + "/" + name + "_" + System.currentTimeMillis() + type
            val file2 = File(newPath2)
            deletedPath = file2.path
            isDelete = com.gallery.photo.image.video.utils.StorageUtils.moveFile(
                file,
                file2,
                context
            )
        } else {
            deletedPath = targetFile.path
            isDelete = com.gallery.photo.image.video.utils.StorageUtils.moveFile(
                file,
                targetFile,
                context
            )
        }

        if (isDelete)
            dataBase.hideDao().insertRecentDelete(RecentDeleteData(0, deletedPath, file.parent))
//        val isDelete = file.delete()
//        val deleteUrl = FileProvider.getUriForFile(
//            context,
//            "${context.packageName}.provider", file
//        )
//        val contentResolver = context.contentResolver
//        contentResolver.delete(deleteUrl, null, null)

        MediaScannerConnection.scanFile(
            context, arrayOf<String>(file.path), null
        ) { path: String?, uri: Uri? -> }

        return isDelete
    }

    fun deleteHideFile(context: Context, data: PictureData, dataBase: AppDatabase): Boolean {
        val file = File(data.filePath)

        val isDelete = file.delete()
        val deleteUrl = FileProvider.getUriForFile(
            context,
            "${context.packageName}.provider", file
        )
        val contentResolver = context.contentResolver
        contentResolver.delete(deleteUrl, null, null)


        if (isDelete)
            dataBase.hideDao()
                .deleteHide(HiddenData(data.idDataBase, data.filePath, data.restorePath))

        MediaScannerConnection.scanFile(
            context, arrayOf<String>(file.path), null
        ) { path: String?, uri: Uri? -> }

        return isDelete
    }

    fun recentlyDeleteHideFile(
        context: Context,
        data: PictureData,
        dataBase: AppDatabase
    ): Boolean {
        val file = File(data.filePath)

        val isDelete = file.delete()
        val deleteUrl = FileProvider.getUriForFile(
            context,
            "${context.packageName}.provider", file
        )
        val contentResolver = context.contentResolver
        contentResolver.delete(deleteUrl, null, null)


        if (isDelete)
            dataBase.hideDao()
                .removeRecentDelete(
                    RecentDeleteData(
                        data.idDataBase,
                        data.filePath,
                        data.restorePath
                    )
                )

        MediaScannerConnection.scanFile(
            context, arrayOf<String>(file.path), null
        ) { path: String?, uri: Uri? -> }

        return isDelete
    }

    fun copyFiles(
        activity: Activity,
        selectPath: String,
        copyMoveList: ArrayList<PictureData>,
        selectedItem: Int,
        copyListener: () -> Unit,
    ) {
        val targetFolder = File(selectPath)
        val copyFiles = ArrayList<String>()
        val dialog = Dialog(activity, R.style.Dialog)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_delete_progress)
        dialog.setCanceledOnTouchOutside(false)
        dialog.window?.setGravity(Gravity.BOTTOM)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val txtTitle: TextView = dialog.findViewById(R.id.txt_title)
        val txt_top_title: TextView = dialog.findViewById(R.id.txt_top_title)
        val txtProgressCount: TextView = dialog.findViewById(R.id.txt_progress_count)
        val progressBar: ProgressBar = dialog.findViewById(R.id.progress_bar)

        progressBar.max = selectedItem
        txt_top_title.text = activity.getText(R.string.Copying)
        activity.runOnUiThread {
            txtProgressCount.text = copyFiles.size.toString() + "/" + selectedItem
            progressBar.progress = copyFiles.size
        }
        dialog.show()

        Observable.fromCallable {
            try {
                for (i in copyMoveList.indices) {
                    activity.runOnUiThread(Runnable {
                        txtTitle.text = copyMoveList[i].fileName
                    })
                    val copyFile = File(copyMoveList[i].filePath)
                    if (copyFile.exists()) {
                        val copyFileName = copyFile.name
                        val targetPath = targetFolder.path + File.separator + copyFileName
                        val targetFile = File(targetPath)
                        if (targetFile.exists()) {
                            val separated =
                                copyFile.name.split("\\.".toRegex()).dropLastWhile { it.isEmpty() }
                                    .toTypedArray()
                            val name = separated[0]
                            val type = separated[1]
                            val newPath2 =
                                targetFolder.path + "/" + name + "_" + System.currentTimeMillis() + "." + type
                            val file2 = File(newPath2)
                            val isCopied: Boolean =
                                com.gallery.photo.image.video.utils.StorageUtils.copyFile(
                                    copyFile,
                                    file2,
                                    activity
                                )
                            if (isCopied) {
                                copyFiles.add(file2.path)
                            }
                        } else {
                            val isCopied: Boolean =
                                com.gallery.photo.image.video.utils.StorageUtils.copyFile(
                                    copyFile,
                                    targetFile,
                                    activity
                                )
                            if (isCopied) {
                                copyFiles.add(targetFile.path)
                            }

                        }
                        activity.runOnUiThread {
                            txtProgressCount.text = copyFiles.size.toString() + "/" + selectedItem
                            progressBar.progress = copyFiles.size
                        }
                    }
                }
            } catch (e: java.lang.Exception) {
                e.printStackTrace()
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                activity.runOnUiThread {
                    if (dialog.isShowing)
                        dialog.dismiss()
                    copyListener()
                    EventBus.getDefault().post(
                        CopyMoveEvent(
                            copyFiles,
                            targetFolder.name,
                            targetFolder.absolutePath,
                            ArrayList()
                        )
                    )

                }
            }
            .subscribe { _: Boolean? ->
                activity.runOnUiThread {
                    if (dialog.isShowing)
                        dialog.dismiss()
                    copyListener()
                    EventBus.getDefault().post(
                        CopyMoveEvent(
                            copyFiles,
                            targetFolder.name,
                            targetFolder.absolutePath,
                            ArrayList()
                        )
                    )

                }
            }
    }

    fun moveFiles(
        activity: Activity,
        selectPath: String,
        copyMoveList: ArrayList<PictureData>,
        selectedItem: Int,
        copyListener: () -> Unit,
        isOpenFromFavorite: Boolean = false,
        isImportFiles: Boolean = false,
    ) {
        val targetFolder = File(selectPath)
        val moveList = ArrayList<String>()
        val deleteList = ArrayList<String>()
        val dialog = Dialog(activity, R.style.Dialog)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_delete_progress)
        dialog.setCanceledOnTouchOutside(false)
        dialog.window?.setGravity(Gravity.BOTTOM)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val txtTitle: TextView = dialog.findViewById(R.id.txt_title)
        val txt_top_title: TextView = dialog.findViewById(R.id.txt_top_title)
        val txtProgressCount: TextView = dialog.findViewById(R.id.txt_progress_count)
        val progressBar: ProgressBar = dialog.findViewById(R.id.progress_bar)

        progressBar.max = selectedItem
        txt_top_title.text =
            if (isImportFiles) activity.getText(R.string.Importing) else activity.getText(R.string.Moving)
        activity.runOnUiThread {
            txtProgressCount.text = moveList.size.toString() + "/" + selectedItem
            progressBar.progress = moveList.size
        }
        dialog.show()

        Observable.fromCallable {
            val favList = Preferences(activity).getFavoriteList()
            try {
                for (i in copyMoveList.indices) {
                    activity.runOnUiThread(Runnable {
                        txtTitle.text = copyMoveList[i].fileName
                    })
                    val moveFile = File(copyMoveList[i].filePath)
                    if (moveFile.exists()) {
                        val moveFileName = moveFile.name
                        val targetPath = targetFolder.path + File.separator + moveFileName
                        val targetFile = File(targetPath)
                        if (targetFile.exists()) {
                            val separated =
                                moveFile.name.split("\\.".toRegex()).dropLastWhile { it.isEmpty() }
                                    .toTypedArray()
                            val name = separated[0]
                            val type = separated[1]
                            val newPath2 =
                                targetFolder.path + "/" + name + "_" + System.currentTimeMillis() + "." + type
                            val file2 = File(newPath2)
                            val isMove: Boolean =
                                com.gallery.photo.image.video.utils.StorageUtils.moveFile(
                                    moveFile,
                                    file2,
                                    activity
                                )
                            if (isMove) {
                                moveList.add(file2.path)
                                deleteList.add(moveFile.path)
                                if (favList.isNotEmpty()) {
                                    if (favList.contains(moveFile.path)) {
                                        val fPos = favList.indexOf(moveFile.path)
                                        if (fPos != -1) {
                                            favList[fPos] = file2.path
                                        }
                                    }
                                }
                            }
                        } else {
                            val isMove: Boolean =
                                com.gallery.photo.image.video.utils.StorageUtils.moveFile(
                                    moveFile,
                                    targetFile,
                                    activity
                                )
                            if (isMove) {
                                moveList.add(targetFile.path)
                                deleteList.add(moveFile.path)

                                if (favList.isNotEmpty()) {
                                    if (favList.contains(moveFile.path)) {
                                        val fPos = favList.indexOf(moveFile.path)
                                        if (fPos != -1) {
                                            favList[fPos] = targetFile.path
                                        }
                                    }
                                }
                            }

                        }
                        activity.runOnUiThread {
                            txtProgressCount.text = moveList.size.toString() + "/" + selectedItem
                            progressBar.progress = moveList.size
                        }
                    }
                }
            } catch (e: java.lang.Exception) {
                e.printStackTrace()
            }
            if (favList.isNotEmpty())
                Preferences(activity).setFavoriteList(favList)
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                activity.runOnUiThread {
                    if (dialog.isShowing)
                        dialog.dismiss()
                    copyListener()
                    EventBus.getDefault().post(
                        CopyMoveEvent(
                            moveList,
                            targetFolder.name,
                            targetFolder.absolutePath,
                            deleteList
                        )
                    )

                }
            }
            .subscribe { _: Boolean? ->
                activity.runOnUiThread {
                    if (dialog.isShowing)
                        dialog.dismiss()
                    copyListener()
                    EventBus.getDefault().post(
                        CopyMoveEvent(
                            moveList,
                            targetFolder.name,
                            targetFolder.absolutePath,
                            deleteList,
                            isOpenFromFavorite
                        )
                    )
                }
            }
    }

    fun hideFiles(
        activity: Activity,
        pictures: ArrayList<PictureData>,
        selectedItem: Int,
        hideListener: () -> Unit,
         isFromFav:Boolean = false
    ) {
        val deleteList = ArrayList<String>()
        val dialog = Dialog(activity, R.style.Dialog)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_delete_progress)
        dialog.window?.setGravity(Gravity.BOTTOM)
        dialog.setCanceledOnTouchOutside(false)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val txtTitle: TextView = dialog.findViewById(R.id.txt_title)
        val txt_top_title: TextView = dialog.findViewById(R.id.txt_top_title)
        val txtProgressCount: TextView = dialog.findViewById(R.id.txt_progress_count)
        val progressBar: ProgressBar = dialog.findViewById(R.id.progress_bar)

        progressBar.max = selectedItem
        txt_top_title.text = activity.getText(R.string.hiding)
        activity.runOnUiThread {
            txtProgressCount.text = deleteList.size.toString() + "/" + selectedItem
            progressBar.progress = deleteList.size
        }
        dialog.show()


        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(activity)
            var hideDirPath = File(Constant.HIDE_PATH)
            for (i in pictures.indices) {
                if (pictures[i] != null)
                    if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        activity.runOnUiThread {
                            txtTitle.text = pictures[i].fileName
                        }
                        val to = try {
                            File(model.filePath)
                        } catch (e: java.lang.Exception) {
                            e.printStackTrace()
                            File(model.filePath)
                        }
                        try {
                            val hidePath: String? = hideFile(activity, to, hideDirPath)
                            if (!hidePath.isNullOrEmpty())
                                dataBase.hideDao().hide(HiddenData(0, hidePath, to.parent))


                        } catch (e: IOException) {
                            e.printStackTrace()
                        }
                        deleteList.add(model.filePath)
                        activity.runOnUiThread {
                            txtProgressCount.text =
                                deleteList.size.toString() + "/" + selectedItem
                            progressBar.progress = deleteList.size
                        }

//                        val isDelete = Utils().fileDelete(activity, model.filePath)
//                        if (isDelete) {
//                            deleteList.add(model.filePath)
//
//                        }
                    }
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                activity.runOnUiThread {
                    if (dialog.isShowing)
                        dialog.dismiss()
                    hideListener()
                    EventBus.getDefault().post(DisplayDeleteEvent(deleteList,isFromFav))
                    EventBus.getDefault().post(HideEvent())
                    Log.e("PrivateTag", "HideEvent funCall")


                }
            }
            .subscribe { _: Boolean? ->
                activity.runOnUiThread {
                    if (dialog.isShowing)
                        dialog.dismiss()
                    hideListener()
                    EventBus.getDefault().post(DisplayDeleteEvent(deleteList,isFromFav))
                    EventBus.getDefault().post(HideEvent())
                    Log.e("PrivateTag", "HideEvent funCall")
                }
            }
    }

    fun unHideFiles(
        activity: Activity,
        pictures: ArrayList<PictureData>,
        selectedItem: Int,
        hideListener: () -> Unit,
    ) {
        val deleteList = ArrayList<String>()
        val dialog = Dialog(activity, R.style.Dialog)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_delete_progress)
        dialog.window?.setGravity(Gravity.BOTTOM)
        dialog.setCanceledOnTouchOutside(false)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val txtTitle: TextView = dialog.findViewById(R.id.txt_title)
        val txt_top_title: TextView = dialog.findViewById(R.id.txt_top_title)
        val txtProgressCount: TextView = dialog.findViewById(R.id.txt_progress_count)
        val progressBar: ProgressBar = dialog.findViewById(R.id.progress_bar)

        progressBar.max = selectedItem
        txt_top_title.text = activity.getText(R.string.UnHiding)
        activity.runOnUiThread {
            txtProgressCount.text = deleteList.size.toString() + "/" + selectedItem
            progressBar.progress = deleteList.size
        }
        dialog.show()

        val restoreList: ArrayList<RestoreData> = ArrayList()

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(activity)
            for (i in pictures.indices) {
                if (pictures[i] != null) if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    var unHideDirPath = File(model.restorePath)
                    activity.runOnUiThread {
                        txtTitle.text = pictures[i].fileName
                    }
                    val to = try {
                        File(model.filePath)
                    } catch (e: java.lang.Exception) {
                        e.printStackTrace()
                        File(model.filePath)
                    }
                    try {
                        val hidePath: String? = hideFile(activity, to, unHideDirPath)
                        if (!hidePath.isNullOrEmpty()) {
                            restoreList.add(RestoreData(hidePath, model.filePath))
                            dataBase.hideDao().unHide(
                                HiddenData(
                                    model.idDataBase,
                                    model.filePath,
                                    model.restorePath
                                )
                            )
                        }
                    } catch (e: IOException) {
                        e.printStackTrace()
                    }
                    deleteList.add(model.filePath)
                    activity.runOnUiThread {
                        txtProgressCount.text =
                            deleteList.size.toString() + "/" + selectedItem
                        progressBar.progress = deleteList.size
                    }

//                        val isDelete = Utils().fileDelete(activity, model.filePath)
//                        if (isDelete) {
//                            deleteList.add(model.filePath)
//                            activity.runOnUiThread {
//                                txtProgressCount.text =
//                                    deleteList.size.toString() + "/" + selectedItem
//                                progressBar.progress = deleteList.size
//                            }
//                        }
                }
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                activity.runOnUiThread {
                    if (dialog.isShowing)
                        dialog.dismiss()
                    EventBus.getDefault().post(RestoreDataEvent(restoreList))
                    EventBus.getDefault().post(DisplayDeleteEvent(deleteList))
                    hideListener()
                }
            }
            .subscribe { _: Boolean? ->
                activity.runOnUiThread {
                    if (dialog.isShowing)
                        dialog.dismiss()
                    EventBus.getDefault().post(RestoreDataEvent(restoreList))
                    EventBus.getDefault().post(DisplayDeleteEvent(deleteList))
                    hideListener()
                }
            }

    }

    private fun hideFile(activity: Activity, file: File, dir: File): String? {
        try {
            if (!dir.exists())
                dir.mkdirs()

            val newFile: File = getHideFileName(0, dir, file.name)
            FileOutputStream(newFile).channel.use { outputChannel ->
                FileInputStream(file).channel.use { inputChannel ->
                    inputChannel.transferTo(0, inputChannel.size(), outputChannel)
                    inputChannel.close()
                    file.delete()
                    val deleteUrl = FileProvider.getUriForFile(
                        activity,
                        "${activity.packageName}.provider", file
                    )
                    val contentResolver = activity.contentResolver
                    contentResolver.delete(deleteUrl, null, null)

                    MediaScannerConnection.scanFile(
                        activity,
                        arrayOf(file.path),
                        null
                    ) { path: String?, uri: Uri? -> }
                    MediaScannerConnection.scanFile(
                        activity,
                        arrayOf(newFile.path),
                        null
                    ) { path: String?, uri: Uri? -> }
                    return newFile.path
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    private fun getHideFileName(count: Int, dir: File, strName: String): File {
        var i = count
        var name = strName
        var check = File(dir, name)
        if (check.exists()) {
            i++
            if (name.contains(".")) {
                if (name.indexOf(".") > 0) {
                    val extension = name.substring(name.lastIndexOf("."))
                    name = name.substring(0, name.lastIndexOf(".")) + "(" + i + ")" + extension
                }
            } else {
                name = "$name($i)"
            }
            check = getHideFileName(i, dir, name)
        }
        return check
    }

    fun restoreFile(
        activity: Activity,
        model: PictureData,
        dataBase: AppDatabase
    ): ArrayList<RestoreData> {
        var dialog: Dialog? = null
        var txt_top_title: TextView? = null
        var txtProgressCount: TextView? = null
        var progressBar: ProgressBar? = null

        val unHideDirPath = File(model.restorePath)
        activity.runOnUiThread {
            dialog = Dialog(activity, R.style.Dialog)
            dialog!!.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog!!.setCancelable(false)
            dialog!!.setContentView(R.layout.dialog_delete_progress)
            dialog!!.setCanceledOnTouchOutside(false)
            dialog!!.window?.setGravity(Gravity.BOTTOM)
            dialog!!.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

            val txtTitle: TextView = dialog!!.findViewById(R.id.txt_title)
            txt_top_title = dialog!!.findViewById(R.id.txt_top_title)
            txtProgressCount = dialog!!.findViewById(R.id.txt_progress_count)
            progressBar = dialog!!.findViewById(R.id.progress_bar)
            progressBar!!.max = 1
            txt_top_title!!.text = activity.getText(R.string.Restoring)

            txtProgressCount!!.text = "0/1"
            progressBar!!.progress = 0
            txtTitle.text = model.fileName

            dialog!!.show()
        }


        val to = try {
            File(model.filePath)
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
            File(model.filePath)
        }
        val restoreList: ArrayList<RestoreData> = ArrayList()
        try {
            val hidePath: String? = hideFile(activity, to, unHideDirPath)
            if (!hidePath.isNullOrEmpty()) {
                restoreList.add(RestoreData(hidePath, model.filePath))
                dataBase.hideDao().removeRecentDelete(
                    RecentDeleteData(
                        model.idDataBase,
                        model.filePath,
                        model.restorePath
                    )
                )
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }

        activity.runOnUiThread {
            txtProgressCount!!.text = "1/1"
            progressBar!!.progress = 1

            dialog!!.dismiss()
        }
        activity.runOnUiThread {
            dialog!!.dismiss()
        }
//        android.os.Handler(Looper.myLooper()!!).postDelayed({
//            dialog!!.dismiss()
//        }, 300)
        return restoreList
    }

    fun restoreFiles(
        activity: Activity,
        pictures: ArrayList<PictureData>,
        selectedItem: Int,
        hideListener: () -> Unit,
    ) {
        val deleteList = ArrayList<String>()
        val dialog = Dialog(activity, R.style.Dialog)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_delete_progress)
        dialog.setCanceledOnTouchOutside(false)
        dialog.window?.setGravity(Gravity.BOTTOM)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val txtTitle: TextView = dialog.findViewById(R.id.txt_title)
        val txt_top_title: TextView = dialog.findViewById(R.id.txt_top_title)
        val txtProgressCount: TextView = dialog.findViewById(R.id.txt_progress_count)
        val progressBar: ProgressBar = dialog.findViewById(R.id.progress_bar)

        progressBar.max = selectedItem
        txt_top_title.text = activity.getText(R.string.Restoring)
        activity.runOnUiThread {
            txtProgressCount.text = deleteList.size.toString() + "/" + selectedItem
            progressBar.progress = deleteList.size
        }
        dialog.show()

        val restoreList: ArrayList<RestoreData> = ArrayList()

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(activity)
            for (i in pictures.indices) {
                if (pictures[i] != null) if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    var unHideDirPath = File(model.restorePath)
                    activity.runOnUiThread {
                        txtTitle.text = pictures[i].fileName
                    }
                    val to = try {
                        File(model.filePath)
                    } catch (e: java.lang.Exception) {
                        e.printStackTrace()
                        File(model.filePath)
                    }
                    try {
                        val hidePath: String? = hideFile(activity, to, unHideDirPath)
                        if (!hidePath.isNullOrEmpty()) {
                            restoreList.add(RestoreData(hidePath, model.filePath))
                            dataBase.hideDao().removeRecentDelete(
                                RecentDeleteData(
                                    model.idDataBase,
                                    model.filePath,
                                    model.restorePath
                                )
                            )
                        }
                    } catch (e: IOException) {
                        e.printStackTrace()
                    }
                    deleteList.add(model.filePath)
                    activity.runOnUiThread {
                        txtProgressCount.text =
                            deleteList.size.toString() + "/" + selectedItem
                        progressBar.progress = deleteList.size
                    }

//                        val isDelete = Utils().fileDelete(activity, model.filePath)
//                        if (isDelete) {
//                            deleteList.add(model.filePath)
//                            activity.runOnUiThread {
//                                txtProgressCount.text =
//                                    deleteList.size.toString() + "/" + selectedItem
//                                progressBar.progress = deleteList.size
//                            }
//                        }
                }
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                activity.runOnUiThread {
                    if (dialog.isShowing)
                        dialog.dismiss()
                    EventBus.getDefault().post(RestoreDataEvent(restoreList))
                    hideListener()
                }
            }
            .subscribe { _: Boolean? ->
                activity.runOnUiThread {
                    if (dialog.isShowing)
                        dialog.dismiss()
                    EventBus.getDefault().post(RestoreDataEvent(restoreList))
                    hideListener()
                }
            }
    }


}