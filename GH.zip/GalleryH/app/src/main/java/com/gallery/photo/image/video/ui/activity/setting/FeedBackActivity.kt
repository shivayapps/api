package com.gallery.photo.image.video.ui.activity.setting

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.widget.addTextChangedListener
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.ActivityFeedBackBinding
import com.gallery.photo.image.video.databinding.ItemFeedbackImageListBinding
import com.gallery.photo.image.video.ui.activity.BaseActivity
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.MyApplication
import java.io.File


class FeedBackActivity : BaseActivity() {
    lateinit var binding: ActivityFeedBackBinding

    private var message = ""
    private var message1 = ""
    private var message2 = ""
    private var message3 = ""
    private var message4 = ""
    private var message5 = ""
    private var message6 = ""
    private var select1 = false
    private var select2 = false
    private var select3 = false
    private var select4 = false
    private var select5 = false
    private var select6 = false
    lateinit var cameraIntent: Intent
    private val CAMERA_IMAGE_RESULT = 202
    var imageList: ArrayList<String> = ArrayList()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFeedBackBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val bundle2 = Bundle()
        bundle2.putString("FeedBack", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_activity, bundle2)

        binding.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.tvMessage1.setOnClickListener {
            if (select1) {
                select1 = false
                message = ""
                binding.tvMessage1.setBackgroundResource(R.drawable.feedback_un_bg)
                binding.tvMessage1.setTextColor(ContextCompat.getColor(this,R.color.cancel_btn_text))
            } else {
                select1 = true
                message = "\n Tag : " + binding.tvMessage1.text.toString()
                binding.tvMessage1.setBackgroundResource(R.drawable.feedback_select_bg)
                binding.tvMessage1.setTextColor(ContextCompat.getColor(this,R.color.black_text))
            }
            setButtonColor()

        }
        binding.tvMessage2.setOnClickListener {
            if (select2) {
                select2 = false
                message1 = ""
                binding.tvMessage2.setBackgroundResource(R.drawable.feedback_un_bg)
                binding.tvMessage2.setTextColor(ContextCompat.getColor(this,R.color.cancel_btn_text))
            } else {
                select2 = true
                message1 = "\n Tag : " + binding.tvMessage2.text.toString()
                binding.tvMessage2.setBackgroundResource(R.drawable.feedback_select_bg)
                binding.tvMessage2.setTextColor(ContextCompat.getColor(this,R.color.black_text))
            }
            setButtonColor()
        }
        binding.tvMessage3.setOnClickListener {
            if (select3) {
                select3 = false
                message2 = ""
                binding.tvMessage3.setBackgroundResource(R.drawable.feedback_un_bg)
                binding.tvMessage3.setTextColor(ContextCompat.getColor(this,R.color.cancel_btn_text))
            } else {
                select3 = true
                message2 = "\n Tag : " + binding.tvMessage3.text.toString()
                binding.tvMessage3.setBackgroundResource(R.drawable.feedback_select_bg)
                binding.tvMessage3.setTextColor(ContextCompat.getColor(this,R.color.black_text))
            }
            setButtonColor()
        }
        binding.tvMessage4.setOnClickListener {
            if (select4) {
                select4 = false
                message3 = ""
                binding.tvMessage4.setBackgroundResource(R.drawable.feedback_un_bg)
                binding.tvMessage4.setTextColor(ContextCompat.getColor(this,R.color.cancel_btn_text))
            } else {
                select4 = true
                message3 = "\n Tag : " + binding.tvMessage4.text.toString()
                binding.tvMessage4.setBackgroundResource(R.drawable.feedback_select_bg)
                binding.tvMessage4.setTextColor(ContextCompat.getColor(this,R.color.black_text))
            }
            setButtonColor()
        }
        binding.tvMessage5.setOnClickListener {
            if (select5) {
                select5 = false
                message4 = ""
                binding.tvMessage5.setBackgroundResource(R.drawable.feedback_un_bg)
                binding.tvMessage5.setTextColor(ContextCompat.getColor(this,R.color.cancel_btn_text))
            } else {
                select5 = true
                message4 = "\n Tag : " + binding.tvMessage5.text.toString()
                binding.tvMessage5.setBackgroundResource(R.drawable.feedback_select_bg)
                binding.tvMessage5.setTextColor(ContextCompat.getColor(this,R.color.black_text))
            }
            setButtonColor()
        }
        binding.tvMessage6.setOnClickListener {
            if (select6) {
                select6 = false
                message5 = ""
                binding.tvMessage6.setBackgroundResource(R.drawable.feedback_un_bg)
                binding.tvMessage6.setTextColor(ContextCompat.getColor(this,R.color.cancel_btn_text))
            } else {
                select6 = true
                message5 = "\n Tag : " + binding.tvMessage6.text.toString()
                binding.tvMessage6.setBackgroundResource(R.drawable.feedback_select_bg)
                binding.tvMessage6.setTextColor(ContextCompat.getColor(this,R.color.black_text))
            }
            setButtonColor()
        }

        binding.ivAddImage.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT)
            intent.addCategory(Intent.CATEGORY_OPENABLE)
            intent.type = "image/*"
            MyApplication.disabledOpenAds()
            startActivityForResult(
                Intent.createChooser(intent, "Select Picture"),
                CAMERA_IMAGE_RESULT
            )
        }
        binding.etMessage.addTextChangedListener {
            setButtonColor()
        }

        val mailId = getReviewEmail()
        binding.tvSend.setOnClickListener {
            val message_send = binding.etMessage.text.toString()
            if (TextUtils.isEmpty(message_send) && TextUtils.isEmpty(message) && TextUtils.isEmpty(
                    message1
                ) && TextUtils.isEmpty(message2) && TextUtils.isEmpty(message3) && TextUtils.isEmpty(
                    message4
                ) && TextUtils.isEmpty(message5) && TextUtils.isEmpty(message6)
            ) {
                Toast.makeText(
                    this,
                    getString(R.string.feedback_messages_enter_validation),
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                email(
                    this,
                    mailId,
                    getString(R.string.app_name2),
                    message_send + "\n" + message + message1 + message2 + message3 + message4 + message5 + message6 + "",
                    imageList
                )
            }
        }


    }


    @RequiresApi(api = Build.VERSION_CODES.R)
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            CAMERA_IMAGE_RESULT -> {
                if (resultCode == Activity.RESULT_OK) {
                    val selectedImageUri: Uri? = data?.data

                    val filePath = com.gallery.photo.image.video.utils.FileUtils(this).getPath(selectedImageUri)
                    if (selectedImageUri != null && !filePath.isNullOrEmpty()) {
                        imageList.add(filePath)
                        binding.rvImageList.layoutManager =
                            LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
                        binding.rvImageList.adapter = ImageAdapter(imageList, this)
                    }
                }
            }
        }
    }


    class ImageAdapter(var imageList: ArrayList<String>, var context: Context) :
        RecyclerView.Adapter<ImageAdapter.MyHolder>() {
        inner class MyHolder(var binding: ItemFeedbackImageListBinding) :
            RecyclerView.ViewHolder(binding.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyHolder {
            return MyHolder(
                ItemFeedbackImageListBinding.inflate(
                    LayoutInflater.from(parent.context),
                    parent,
                    false
                )
            )
        }

        override fun getItemCount(): Int {
            return imageList.size
        }

        override fun onBindViewHolder(holder: MyHolder, position: Int) {
            with(holder.binding) {
                Glide
                    .with(context)
                    .load(imageList[position])
                    .placeholder(R.color.place_holder)
                    .into(image)
                icClose.setOnClickListener {
                    imageList.removeAt(position)
                    notifyDataSetChanged()
                }
            }

        }
    }

    fun email(
        context: Context, emailTo: String,
        subject: String, emailText: String, filePaths: List<String>
    ) {
        val emailIntent = Intent(Intent.ACTION_SEND_MULTIPLE)
        emailIntent.type = "message/rfc822"
        emailIntent.setPackage("com.google.android.gm")
        emailIntent.putExtra(Intent.EXTRA_EMAIL, arrayOf(emailTo))
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject)
        emailIntent.putExtra(Intent.EXTRA_TEXT, emailText)
        val uris = ArrayList<Uri>()
        for (file in filePaths) {
            val fileIn = File(file)
            val u = FileProvider.getUriForFile(
                applicationContext,
                "$packageName.provider", fileIn
            );
            uris.add(u)
        }
        emailIntent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        MyApplication.disabledOpenAds()
        context.startActivity(Intent.createChooser(emailIntent, "Send mail..."))
    }

    override fun onResume() {
        super.onResume()
    }

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        val view = currentFocus
        val ret = super.dispatchTouchEvent(event)
        if (view is EditText) {
            val w = currentFocus
            val scrcoords = IntArray(2)
            w!!.getLocationOnScreen(scrcoords)
            val x = event.rawX + w.left - scrcoords[0]
            val y = event.rawY + w.top - scrcoords[1]
            if (event.action == 1 && (x < w.left || x >= w.right || y < w.top || y > w.bottom)) {
                val systemService = getSystemService(Context.INPUT_METHOD_SERVICE)
                val imm = systemService as InputMethodManager
                val currentFocus = window.currentFocus
                imm.hideSoftInputFromWindow(currentFocus!!.windowToken, 0)
            }
        }
        return ret
    }

    fun setButtonColor() {
        val message_send = binding.etMessage.text.toString()
        if (TextUtils.isEmpty(message_send) && TextUtils.isEmpty(message) && TextUtils.isEmpty(
                message1
            ) && TextUtils.isEmpty(message2) && TextUtils.isEmpty(message3) && TextUtils.isEmpty(
                message4
            ) && TextUtils.isEmpty(message5) && TextUtils.isEmpty(message6)
        ) {
            binding.tvSend.setTextColor(resources.getColor(R.color.grayText))
        } else {
            binding.tvSend.setTextColor(ContextCompat.getColor(this, R.color.black_text))
        }
    }

}