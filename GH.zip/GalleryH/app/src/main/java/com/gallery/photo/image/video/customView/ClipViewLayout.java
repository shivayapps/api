package com.gallery.photo.image.video.customView;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.RelativeLayout;

public class ClipViewLayout extends RelativeLayout {

    public ImageView f9982a;

    /* renamed from: b  reason: collision with root package name */
    public a f9983b;

    /* renamed from: c  reason: collision with root package name */
    public float f9984c;

//    /* renamed from: d  reason: collision with root package name */
//    public float f9985d;
//    public final Matrix e;
//
//    /* renamed from: f  reason: collision with root package name */
//    public final Matrix f9986f;
//
//    /* renamed from: g  reason: collision with root package name */
//    public int f9987g;
//
//    /* renamed from: h  reason: collision with root package name */
//    public final PointF f9988h;
//    public final PointF i;
//
//    /* renamed from: j  reason: collision with root package name */
//    public float f9989j;
//
//    /* renamed from: k  reason: collision with root package name */
//    public final float[] f9990k;
//
//    /* renamed from: l  reason: collision with root package name */
//    public float f9991l;
//
//    /* renamed from: m  reason: collision with root package name */
//    public final float f9992m;

    /* loaded from: classes2.dex */
    public class a implements ViewTreeObserver.OnGlobalLayoutListener {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ String f9993a;

        public a(String str) {
            this.f9993a = str;
        }

        /* JADX WARN: Code restructure failed: missing block: B:40:0x00c6, code lost:
            if (r2 < r3) goto L25;
         */
        /* JADX WARN: Code restructure failed: missing block: B:43:0x00eb, code lost:
            if (r2 < r3) goto L25;
         */
        /* JADX WARN: Code restructure failed: missing block: B:44:0x00ed, code lost:
            r2 = r3;
         */
        /* JADX WARN: Code restructure failed: missing block: B:45:0x00ee, code lost:
            r3 = r0.e;
            r3.postScale(r2, r2);
            r3.postTranslate((r0.f9982a.getWidth() / 2) - ((int) ((r1.getWidth() * r2) / 2.0f)), (r0.f9982a.getHeight() / 2) - ((int) ((r1.getHeight() * r2) / 2.0f)));
            r0.f9982a.setScaleType(android.widget.ImageView.ScaleType.MATRIX);
            r0.f9982a.setImageMatrix(r3);
            r0.f9982a.setImageBitmap(r1);
         */
        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final void onGlobalLayout() {
            /*
                Method dump skipped, instructions count: 313
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: gallery.hidepictures.photovault.lockgallery.lib.mm.views.ClipViewLayout.a.onGlobalLayout():void");
        }
    }


    public ClipViewLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
//        a.EnumC0139a enumC0139a;
//        this.e = new Matrix();
//        this.f9986f = new Matrix();
//        this.f9987g = 0;
//        this.f9988h = new PointF();
//        this.i = new PointF();
//        this.f9989j = 1.0f;
//        this.f9990k = new float[9];
//        this.f9992m = 8.0f;
//        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, b.e);
//        this.f9984c = obtainStyledAttributes.getDimensionPixelSize(2, (int) TypedValue.applyDimension(1, 1.0f, getResources().getDisplayMetrics()));
//        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(0, (int) TypedValue.applyDimension(1, 1.0f, getResources().getDisplayMetrics()));
//        int i = obtainStyledAttributes.getInt(1, 1);
//        obtainStyledAttributes.recycle();
//        a aVar = new a(context);
//        this.f9983b = aVar;
//        if (i == 1) {
//            enumC0139a = a.EnumC0139a.CIRCLE;
//        } else {
//            enumC0139a = a.EnumC0139a.RECTANGLE;
//        }
//        aVar.setClipType(enumC0139a);
//        this.f9983b.setClipBorderWidth(dimensionPixelSize);
//        this.f9983b.setmHorizontalPadding(this.f9984c);
//        this.f9982a = new ImageView(context);
//        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -1);
//        addView(this.f9982a, layoutParams);
//        addView(this.f9983b, layoutParams);
    }

//    public static float b(MotionEvent motionEvent) {
//        float x10 = motionEvent.getX(0) - motionEvent.getX(1);
//        float y = motionEvent.getY(0) - motionEvent.getY(1);
//        return (float) Math.sqrt((y * y) + (x10 * x10));
//    }
//
//    public final void a() {
//        Drawable drawable;
//        float f10;
//        Matrix matrix = this.e;
//        RectF rectF = new RectF();
//        float f11 = 0.0f;
//        if (this.f9982a.getDrawable() != null) {
//            rectF.set(0.0f, 0.0f, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
//            matrix.mapRect(rectF);
//        }
//        int width = this.f9982a.getWidth();
//        int height = this.f9982a.getHeight();
//        float width2 = rectF.width();
//        float f12 = width;
//        float f13 = this.f9984c;
//        if (width2 >= f12 - (f13 * 2.0f)) {
//            float f14 = rectF.left;
//            if (f14 > f13) {
//                f10 = (-f14) + f13;
//            } else {
//                f10 = 0.0f;
//            }
//            float f15 = rectF.right;
//            if (f15 < f12 - f13) {
//                f10 = (f12 - f13) - f15;
//            }
//        } else {
//            f10 = 0.0f;
//        }
//        float height2 = rectF.height();
//        float f16 = height;
//        float f17 = this.f9985d;
//        if (height2 >= f16 - (2.0f * f17)) {
//            float f18 = rectF.top;
//            if (f18 > f17) {
//                f11 = (-f18) + f17;
//            }
//            float f19 = rectF.bottom;
//            if (f19 < f16 - f17) {
//                f11 = (f16 - f17) - f19;
//            }
//        }
//        matrix.postTranslate(f10, f11);
//    }
//
//    public final float getScale() {
//        Matrix matrix = this.e;
//        float[] fArr = this.f9990k;
//        matrix.getValues(fArr);
//        return fArr[0];
//    }
//
//    @Override // android.view.View
//    public final boolean onTouchEvent(MotionEvent motionEvent) {
//        int action = motionEvent.getAction() & 255;
//        PointF pointF = this.f9988h;
//        Matrix matrix = this.f9986f;
//        Matrix matrix2 = this.e;
//        if (action != 0) {
//            PointF pointF2 = this.i;
//            if (action != 2) {
//                if (action != 5) {
//                    if (action == 6) {
//                        this.f9987g = 0;
//                    }
//                } else {
//                    float b10 = b(motionEvent);
//                    this.f9989j = b10;
//                    if (b10 > 10.0f) {
//                        matrix.set(matrix2);
//                        pointF2.set((motionEvent.getX(1) + motionEvent.getX(0)) / 2.0f, (motionEvent.getY(1) + motionEvent.getY(0)) / 2.0f);
//                        this.f9987g = 2;
//                    }
//                }
//            } else {
//                int i = this.f9987g;
//                if (i == 1) {
//                    matrix2.set(matrix);
//                    float y = motionEvent.getY() - pointF.y;
//                    this.f9985d = this.f9983b.getClipRect().top;
//                    matrix2.postTranslate(motionEvent.getX() - pointF.x, y);
//                    a();
//                } else if (i == 2) {
//                    float b11 = b(motionEvent);
//                    if (b11 > 10.0f) {
//                        float f10 = b11 / this.f9989j;
//                        if (f10 < 1.0f) {
//                            if (getScale() > this.f9991l) {
//                                matrix2.set(matrix);
//                                this.f9985d = this.f9983b.getClipRect().top;
//                                matrix2.postScale(f10, f10, pointF2.x, pointF2.y);
//                                while (getScale() < this.f9991l) {
//                                    matrix2.postScale(1.01f, 1.01f, pointF2.x, pointF2.y);
//                                }
//                            }
//                            a();
//                        } else if (getScale() <= this.f9992m) {
//                            matrix2.set(matrix);
//                            this.f9985d = this.f9983b.getClipRect().top;
//                            matrix2.postScale(f10, f10, pointF2.x, pointF2.y);
//                        }
//                    }
//                }
//                this.f9982a.setImageMatrix(matrix2);
//            }
//        } else {
//            matrix.set(matrix2);
//            pointF.set(motionEvent.getX(), motionEvent.getY());
//            this.f9987g = 1;
//        }
//        return true;
//    }
//
//    public void setImageSrc(String str) {
//        this.f9982a.getViewTreeObserver().addOnGlobalLayoutListener(new a(str));
//    }

}
