package com.gallery.photo.image.video.ui.activity

import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.TextView
import com.google.android.exoplayer2.ExoPlaybackException
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.SimpleExoPlayer
import com.google.android.exoplayer2.source.ConcatenatingMediaSource
import com.google.android.exoplayer2.source.MediaSource
import com.google.android.exoplayer2.source.ProgressiveMediaSource
import com.google.android.exoplayer2.ui.PlayerView
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory
import com.google.android.exoplayer2.util.Log
import com.google.android.exoplayer2.util.Util
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.ui.dialog.DetailsDialog
import com.gallery.photo.image.video.ui.model.PictureData
import com.gallery.photo.image.video.utils.Constant
import java.text.SimpleDateFormat

class VideoPlayerActivity : BaseActivity(), View.OnClickListener {
    var playerView: PlayerView? = null
    var player: SimpleExoPlayer? = null
    var txtTitle: TextView? = null
    var txtTime: TextView? = null
    var videoBack: ImageView? = null
    var lock: ImageView? = null
    var unlock: ImageView? = null
    var scaling: ImageView? = null
    var root: RelativeLayout? = null
    var concatenatingMediaSource: ConcatenatingMediaSource? = null
    var nextButton: ImageView? = null
    var previousButton: ImageView? = null
    var progressBar: ProgressBar? = null
    var imgDisplay: ImageView? = null
    var ivInfo: ImageView? = null
    val format = SimpleDateFormat("dd MMM yyyy")
    val formatTime = SimpleDateFormat("hh:mm aa")
    lateinit var videoData: PictureData

    private var controlsMode: ControlsMode? = null

    enum class ControlsMode {
        LOCK, FULLSCREEN
    }

    var videoPath = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_video_player)
        inits()
    }

    private fun inits() {
        val bundle2 = Bundle()
        bundle2.putString("VideoPlayer", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_activity, bundle2)

        videoPath = intent.getStringExtra("videoPath") ?: ""
        videoData =  Constant.videoData

        playerView = findViewById(R.id.exoplayer_view)
        nextButton = findViewById(R.id.exo_next)
        previousButton = findViewById(R.id.exo_prev)
        txtTitle = findViewById(R.id.txtTitle)
        txtTime = findViewById(R.id.txtTime)
        videoBack = findViewById(R.id.video_back)
        lock = findViewById(R.id.lock)
        unlock = findViewById(R.id.unlock)
        scaling = findViewById(R.id.scaling)
        root = findViewById(R.id.root_layout)
        progressBar = findViewById(R.id.progressBar)
        imgDisplay = findViewById(R.id.imgDisplay)
        ivInfo = findViewById(R.id.ivInfo)
//        txtTitle!!.text = File(videoPath).name

        val strDate = format.format(videoData.date)
        val time = formatTime.format(videoData.date)
        txtTitle!!.text = strDate
        txtTime!!.text = time

        nextButton!!.setOnClickListener(this)
        previousButton!!.setOnClickListener(this)
        videoBack!!.setOnClickListener(this)
        lock!!.setOnClickListener(this)
        unlock!!.setOnClickListener(this)
        scaling!!.setOnClickListener(this)

        ivInfo!!.setOnClickListener {
            if (player!!.isPlaying) {
                player!!.pause()
            }
            val detailsDialog = DetailsDialog(videoData)
            detailsDialog.show(supportFragmentManager, detailsDialog.tag)
        }

        playVideo()
    }

    private fun playVideo() {
        progressBar!!.progress =0
        val uri = Uri.parse(videoPath)
        player = SimpleExoPlayer.Builder(this).build()
        val defaultDataSourceFactory =
            DefaultDataSourceFactory(this, Util.getUserAgent(this, "app"))
        concatenatingMediaSource = ConcatenatingMediaSource()

        val mediaSource: MediaSource =
            ProgressiveMediaSource.Factory(defaultDataSourceFactory).createMediaSource(
                Uri.parse(uri.toString())
            )
        concatenatingMediaSource!!.addMediaSource(mediaSource)

        playerView!!.player = player
        player!!.prepare(concatenatingMediaSource!!)
        playError()
        Log.e("VideoVIEW", "start the video")
        player!!.playWhenReady = true
    }

    private fun playError() {
        player!!.addListener(object : Player.EventListener {
            override fun onPlayerError(error: ExoPlaybackException) {
                Log.e("VideoVIEW", "onPlayerError ${error.toString()}")
                onBackPressed()
            }

            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                super.onPlayWhenReadyChanged(playWhenReady, reason)
                Log.e("VideoVIEW", "onPlayWhenReadyChanged ")
            }

            override fun onPlayerStateChanged(playWhenReady: Boolean, playbackState: Int) {
                Log.e("VideoVIEW", "onPlayerStateChanged $playWhenReady")
                if (playbackState == Player.STATE_BUFFERING) {
                    progressBar!!.visibility = View.VISIBLE
                    imgDisplay!!.visibility = View.VISIBLE

                } else if (playbackState == Player.STATE_READY || playbackState == Player.STATE_ENDED) {

                    progressBar!!.visibility = View.INVISIBLE
                    imgDisplay!!.visibility = View.INVISIBLE
                }
            }

            override fun onIsLoadingChanged(isLoading: Boolean) {
                super.onIsLoadingChanged(isLoading)
                Log.e("VideoVIEW", "onIsLoadingChanged $isLoading")

            }

            override fun onLoadingChanged(isLoading: Boolean) {
                super.onLoadingChanged(isLoading)
                Log.e("VideoVIEW", "onLoadingChanged $isLoading")

            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                super.onMediaItemTransition(mediaItem, reason)
                Log.e("VideoVIEW", "onMediaItemTransition $reason ")
            }
        })
    }

    override fun onBackPressed() {
        if (player!!.isPlaying) {
            player!!.stop()
        }
        super.onBackPressed()
    }

    var isPause = false

    override fun onPause() {
        super.onPause()
        isPause = true
        player!!.playWhenReady = false
        player!!.playbackState
    }


    override fun onResume() {
        super.onResume()
        if (isPause) {
            isPause = false
            player!!.playWhenReady = true
            player!!.playbackState
        }
    }

    override fun onRestart() {
        super.onRestart()
        player!!.playWhenReady = true
        player!!.playbackState
    }

    override fun onClick(v: View) {
        when (v.id) {

            R.id.video_back -> {
                if (player!!.isPlaying) {
                    player!!.stop()
                }
                if (player != null) {
                    player!!.release()
                }

                onBackPressed()
            }

            R.id.lock -> {
                controlsMode = ControlsMode.FULLSCREEN
                root!!.visibility = View.VISIBLE
                lock!!.visibility = View.INVISIBLE
//                Toast.makeText(this, getString(R.string.unlock), Toast.LENGTH_SHORT).show()
            }

            R.id.unlock -> {
                controlsMode = ControlsMode.LOCK
                root!!.visibility = View.INVISIBLE
                lock!!.visibility = View.VISIBLE
//                Toast.makeText(this, getString(R.string.locked), Toast.LENGTH_SHORT).show()
            }

            R.id.root_layout -> {}
            R.id.exo_next -> try {
//                previousButton!!.setImageResource(R.drawable.ic_audio_perv)
                player!!.stop()
//                position++
                playVideo()
//                title!!.text = File(mediadata[position].path).name
            } catch (e: Exception) {
                finish()
            }

            R.id.exo_prev -> try {

//                if (position > 0) {
//                    player!!.stop()
//                    if (position == 1) {
////                        previousButton!!.setImageResource(R.drawable.ic_audio_perv1)
//                    }
//                    position--
//                    playVideo()
//                    title!!.text = File(mediadata[position].path).name
//                } else {
////                    previousButton!!.setImageResource(R.drawable.ic_audio_perv1)
//                    previousButton!!.isEnabled = false
//                }

            } catch (e: Exception) {
                finish()
            }

            R.id.scaling -> if (resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT) {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            } else if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            }
        }
    }
}