package com.gallery.photo.image.video.ui.activity.duplicate

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.lifecycle.Observer
import androidx.work.WorkInfo
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.ActivityScanBinding
import com.gallery.photo.image.video.duplicat_function.core_class.FilesProcessor.pathObserver
import com.gallery.photo.image.video.duplicat_function.utils_duplicat.DuplicateConstants
import com.gallery.photo.image.video.duplicat_function.utils_duplicat.FileScanWorker
import com.gallery.photo.image.video.duplicat_function.viewmodel_class.LandingViewModel
import com.gallery.photo.image.video.ui.activity.BaseActivity
import com.gallery.photo.image.video.utils.Constant

class ScanActivity : BaseActivity() {
    var binding: ActivityScanBinding? = null
    private var modelView: com.gallery.photo.image.video.duplicat_function.viewmodel_class.LandingViewModel? = null
    var stringExtra: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScanBinding.inflate(layoutInflater)
        setContentView(binding!!.root)

        val bundle2 = Bundle()
        bundle2.putString("DuplicateScan", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_activity, bundle2)

        pathObserver.observe(this, Observer {
//            binding!!.tvPaths.doVisible()
            binding!!.tvPaths.setText(getString(R.string.path)+" "+it)
        })

//        val isDarkMode = SharedPref(this).getBoolean(IS_DARK_MODE, false)
//        if (isDarkMode) {
//            binding!!.lottis.setAnimation(R.raw.white)
//        } else {
//        }
        stringExtra = intent.getStringExtra(com.gallery.photo.image.video.duplicat_function.utils_duplicat.DuplicateConstants.SCAN_TYPE)
        val landingViewModel =
            com.gallery.photo.image.video.duplicat_function.viewmodel_class.LandingViewModel(
                application,
                com.gallery.photo.image.video.duplicat_function.utils_duplicat.DuplicateConstants.WORKFLOW_TAG
            )

        modelView = landingViewModel
        startScanning()
        binding!!.llStarts.setOnClickListener { view: View? ->
            startScanning()
        }
    }

    private fun startScanning() {
        modelView?.startDuplicateScan(stringExtra)
        binding!!.llStarts.visibility = View.GONE
        binding!!.llScans.visibility = View.VISIBLE
        modelView!!.outputWorkInfo.observe(this
        ) { t -> moveToDetailScreen(t as List<*>) }
    }

    fun `lambda$onCreate$0$ScanStatusActivity`(view: View?) {
        modelView!!.cancelWork()
    }

   fun moveToDetailScreen(list: List<*>?) {
//        var workInfo: WorkInfo
        var workInfo = list?.get(0) as WorkInfo
        if (list == null || list.isEmpty() ||  { workInfo } == null) {
            return
        }
        if (!workInfo.state.isFinished) {
            val string = workInfo.progress.getString(com.gallery.photo.image.video.duplicat_function.utils_duplicat.DuplicateConstants.FILE_PROCESSING_MESSAGE)
            runOnUiThread {
                Log.d("fdffs", "scansss :: $string")
                `lambda$null$1$ScanStatusActivity`(string)
            }
            return
        }
        val i = workInfo.outputData.getInt(com.gallery.photo.image.video.duplicat_function.utils_duplicat.FileScanWorker.TOTAL_DUPLICATES_FOUND, 0)
        runOnUiThread { `lambda$null$2$ScanStatusActivity`(i) }
        startActivity(
            Intent(this, DetailActivity::class.java).putExtra(
                com.gallery.photo.image.video.duplicat_function.utils_duplicat.DuplicateConstants.SCAN_TYPE,
                stringExtra
            )
        )
        finish()
    }

   fun `lambda$null$1$ScanStatusActivity`(str: String?) {
//        binding.tvPaths.setText(str);
    }

   fun `lambda$null$2$ScanStatusActivity`(i: Int) {
//        if (i == 0) {
//            binding.tvPaths.setText(R.string.no_dupes_msg);
//        } else {
//            binding.tvPaths.setText("DONE");
//        }
    }

}