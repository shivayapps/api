package com.gallery.photo.image.video.ui.model

import android.graphics.drawable.Drawable

data class LanguageData(var name: String, var languageCode: String
//, var icon: Drawable?
)
