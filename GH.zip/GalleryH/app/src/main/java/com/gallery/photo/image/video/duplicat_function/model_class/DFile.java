package com.gallery.photo.image.video.duplicat_function.model_class;


import com.gallery.photo.image.video.duplicat_function.utils_duplicat.DuplicateConstants;
import com.gallery.photo.image.video.duplicat_function.utils_duplicat.DuplicateConstants;

import java.io.File;
import java.util.Date;


public class DFile {
    private String hash;
    private long lastUpdatedAt;
    private String name;
    private String path;
    private long photoTakenAt;
    private long size;
    private String type;
     boolean isSelect;

    public String getPath() {
        return this.path;
    }

    public boolean isSelect() {
        return isSelect;
    }

    public void setSelect(boolean select) {
        isSelect = select;
    }

    public void setPath(String str) {
        this.path = str;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String str) {
        this.name = str;
    }

    public String getType() {
        return this.type;
    }

    public void setType(String str) {
        this.type = str;
    }

    public long getSize() {
        return this.size;
    }

    public void setSize(long j) {
        this.size = j;
    }

    public long getLastUpdatedAt() {
        return this.lastUpdatedAt;
    }

    public void setLastUpdatedAt(long j) {
        this.lastUpdatedAt = j;
    }

    public String getHash() {
        return this.hash;
    }

    public void setHash(String str) {
        this.hash = str;
    }

    public long getPhotoTakenAt() {
        return this.photoTakenAt;
    }

    public void setPhotoTakenAt(long j) {
        this.photoTakenAt = j;
    }

    
    public static class Builder {
        private String hash;
        private long lastUpdatedAt;
        private String name;
        private String path;
        private long photoTakenAt;
        private long size;
        private String type;

        public Builder() {
        }

        Builder(String str, String str2, String str3, long j, long j2, String str4, long j3) {
            this.path = str;
            this.name = str2;
            this.type = str3;
            this.size = j;
            this.lastUpdatedAt = j2;
            this.hash = str4;
            this.photoTakenAt = j3;
        }

        public Builder path(String str) {
            this.path = str;
            return this;
        }

        public Builder name(String str) {
            this.name = str;
            return this;
        }

        public Builder type(String str) {
            this.type = str;
            return this;
        }

        public Builder size(long j) {
            this.size = j;
            return this;
        }

        public Builder lastUpdatedAt(long j) {
            this.lastUpdatedAt = j;
            return this;
        }

        public Builder hash(String str) {
            this.hash = str;
            return this;
        }

        public Builder photoTakenAt(long j) {
            this.photoTakenAt = j;
            return this;
        }

        public DFile build() {
            return new DFile(this);
        }
    }

    private DFile(Builder builder) {
        this.path = builder.path;
        this.name = builder.name;
        this.type = builder.type;
        this.size = builder.size;
        this.lastUpdatedAt = builder.lastUpdatedAt;
        this.hash = builder.hash;
        this.photoTakenAt = builder.photoTakenAt;
    }

    public static DFile toDFile(File file) {
        return toDFile(file, null);
    }

    public static DFile toDFile(File file, Date date) {
        Builder path = new Builder().size(file.length()).lastUpdatedAt(file.lastModified()).name(file.getName()).type(DuplicateConstants.getFileType(file.getAbsolutePath())).path(file.getAbsolutePath());
        if (date != null) {
            path.photoTakenAt(date.getTime());
            path.size = file.length();
        }
        return path.build();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && getClass() == obj.getClass()) {
            return getPath().equals(((DFile) obj).getPath());
        }
        return false;
    }

    public int hashCode() {
        return this.path.hashCode();
    }

    public String toString() {
        return "DFile{path='" + this.path + "', name='" + this.name + "', type='" + this.type + "', size=" + this.size + ", lastUpdatedAt=" + this.lastUpdatedAt + ", hash='" + this.hash + "', photoTakenAt=" + this.photoTakenAt + '}';
    }
}
