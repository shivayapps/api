package com.gallery.photo.image.video.ui.activity

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.Toast
import androidx.appcompat.widget.PopupMenu
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.database.AppDatabase
import com.gallery.photo.image.video.databinding.ActivityImageListBinding
import com.gallery.photo.image.video.databinding.DialogDeleteProgressBinding
import com.gallery.photo.image.video.databinding.PopBottomMenuBinding
import com.gallery.photo.image.video.databinding.PopMenuHomeBinding
import com.gallery.photo.image.video.ui.adapter.FavouriteAdapter
import com.gallery.photo.image.video.ui.dialog.ConfirmationDialog
import com.gallery.photo.image.video.ui.dialog.CreateAlbumDialog
import com.gallery.photo.image.video.ui.dialog.DeleteDialog
import com.gallery.photo.image.video.ui.dialog.SelectAlbumDialog
import com.gallery.photo.image.video.ui.event.CopyMoveEvent
import com.gallery.photo.image.video.ui.event.DeleteEvent
import com.gallery.photo.image.video.ui.event.DisplayDeleteEvent
import com.gallery.photo.image.video.ui.event.RenameEvent
import com.gallery.photo.image.video.ui.event.RestoreDataEvent
import com.gallery.photo.image.video.ui.event.UpdateFavoriteEvent
import com.gallery.photo.image.video.ui.model.AlbumData
import com.gallery.photo.image.video.ui.model.PictureData
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.Preferences
import com.gallery.photo.image.video.utils.Utils
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File
import java.text.SimpleDateFormat
import java.util.Collections
import kotlin.math.roundToInt

class ImageListActivity : BaseActivity() {

    lateinit var binding: ActivityImageListBinding
    lateinit var preferences: Preferences
    var albumData = AlbumData()
    var allList = ArrayList<PictureData>()
    var allBackList = ArrayList<PictureData>()
    var pictures = ArrayList<Any>()
    var pictureAdapter: FavouriteAdapter? = null
    var selectedItem = 0
    var isSearch: Boolean = false
    var isStopSearch: Boolean = false
    var isCheckSearchOn = false
    var isSelectAll = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityImageListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        EventBus.getDefault().register(this)
        intView()
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }

    private fun intView() {
        preferences = Preferences(this)
        val bundle2 = Bundle()
        bundle2.putString("AlbumImageList", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_activity, bundle2)

        val data = Constant.albumData
        albumData =
            AlbumData(data.title, data.pictureData, data.folderPath, data.date, data.fileSize)
        allList.addAll(albumData.pictureData)
        allBackList.addAll(albumData.pictureData)

        binding.txtTitle.text = albumData.title

        if (allList.size != 0)
            loadNativeAdsAlbumImageList(binding.frameNative)

        getData()
        binding.swipeRefreshLayout.setOnRefreshListener {
            if (binding.swipeRefreshLayout.isEnabled)
                getData()
            else
                binding.swipeRefreshLayout.isRefreshing = false
        }
        intListener()
    }


    private fun intListener() {
        binding.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.icClose.setOnClickListener {
            setCloseToolbar()
        }
        binding.icSelect.setOnClickListener {
            isSelectAll = !isSelectAll
            setSelectClick(isSelectAll)
            setSelectAllColor()
        }

        binding.btnShare.setOnClickListener {
            shareImages()

        }
        binding.btnDelete.setOnClickListener {
            showDeleteDialog()
        }
        binding.btnHide.setOnClickListener {
            setHideData()
        }

        binding.btnMore.setOnClickListener {
//            showMoreMenu()
            showDropDown(binding.ivMenuView)
        }
    }

    lateinit var popupWindow: PopupWindow

    private fun showDropDown(view: View) {
        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopBottomMenuBinding.inflate(layoutInflater)
        val popupView = popUpBinding.root
        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        params.setMargins(10, 0, 50, 0)
        popupView.layoutParams = params
        popupWindow = PopupWindow(
            popupView,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        popupWindow.animationStyle = R.style.ShowUpAnimation_BR

        popupWindow.setBackgroundDrawable(BitmapDrawable())
        popupWindow.isOutsideTouchable = true
        val a = IntArray(2)
        view.getLocationInWindow(a)
        Log.e(
            "showDropDown",
            "a0==>> ${a[0]} a1==>> ${a[1]} height==>> ${view.height} frameNative ${binding.frameNative.height}"
        )
        popupWindow.showAtLocation(
            view, Gravity.NO_GRAVITY, a[0],
            (a[1] - view.height - resources.getDimension(com.intuit.sdp.R.dimen._60sdp)).roundToInt()
        )
        popupWindow.update()
        popupWindow.showAsDropDown(view)

        popUpBinding.loutMain.setOnClickListener {
            popupWindow.dismiss()
        }

        popUpBinding.menuCopy.setOnClickListener {
            showAddAlbumDialog(Constant.albumList, true)
            popupWindow.dismiss()
        }
        popUpBinding.menuMove.setOnClickListener {
            showAddAlbumDialog(Constant.albumList, false)
            popupWindow.dismiss()
        }
    }

    private fun showMoreMenu() {
        val popup = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            PopupMenu(this, binding.btnMore, Gravity.END, 0, R.style.BasePopupMenu)
        } else {
            PopupMenu(this, binding.btnMore)
        }
        popup.menuInflater.inflate(R.menu.menu_bottom_option, popup.menu)
        popup.setForceShowIcon(true)

        popup.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.menuCopy -> {
                    showAddAlbumDialog(Constant.albumList, true)
                }

                R.id.menuMove -> {
                    showAddAlbumDialog(Constant.albumList, false)
                }

                R.id.menuCollage -> {

                }
            }
            return@setOnMenuItemClickListener true
        }
        popup.show()
    }

    private fun setData() {
        enableScroll()
        binding.swipeRefreshLayout.isRefreshing = false
        if (pictureAdapter != null) notifyAdapter() else initAdapter()
//        RxBus.getInstance().post(CountShowEvent())
        setEmptyData()
    }

    private fun setEmptyData() {
        if (pictures != null && pictures.size != 0) {
            binding.pictureRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
        } else {
            binding.pictureRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
        }
    }

    fun setRvLayoutManager() {
        val gridCount = preferences.getGridCount()
        val gridLayoutManager =
            GridLayoutManager(this, gridCount, RecyclerView.VERTICAL, false)
        binding.pictureRecycler.layoutManager = gridLayoutManager
        gridLayoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                if (position >= 0 && position < pictures.size) {
                    return if (pictureAdapter!!.getItemViewType(position) === pictureAdapter!!.ITEM_HEADER_TYPE) {
                        gridCount
                    } else 1
                } else {
                    return 1
                }
            }
        }
    }

    private fun initAdapter() {
        setRvLayoutManager()
        pictureAdapter = FavouriteAdapter(this, pictures, clickListener = {
            if (pictures[it] is PictureData) {
                val pictureData = pictures[it] as PictureData
                if (pictureData.isCheckboxVisible && !isCheckSearchOn) {
                    pictureData.isSelected = !pictureData.isSelected
                    pictureAdapter?.notifyItemChanged(it)
                    setSelectedFile()
                } else {
                    val dataList = ArrayList<PictureData>()
                    var displayPos = 0
                    for (i in pictures.indices) {
                        if (pictures[i] is PictureData) {
                            dataList.add(pictures[i] as PictureData)
                            if (it == i) {
                                displayPos = dataList.size - 1
                            }
                        }
                    }
                    Constant.displayImageList = ArrayList()
                    Constant.displayImageList.addAll(dataList)
                    val intent = Intent(this, ImageViewerActivity::class.java)
                    intent.putExtra(Constant.EXTRA_DISPLAY_POS, displayPos)
                    startActivity(intent)
                }
            }
        }, longClickListener = {
            if (!isCheckSearchOn) {
                if (pictures[it] is PictureData) {
                    val pictureData = pictures[it] as PictureData
                    for (i in pictures.indices) {
                        if (pictures[i] != null)
                            if (pictures[i] is AlbumData) {
                                val model = pictures[i] as AlbumData
                                model.isCheckboxVisible = true
                            } else if (pictures[i] is PictureData) {
                                val model = pictures[i] as PictureData
                                model.isCheckboxVisible = true
                            }
                    }
                    pictureData.isCheckboxVisible = true
                    pictureData.isSelected = true
                    notifyAdapter()
                    setSelectedFile()
                }
            }
        }, headerSelectListener = {
            if (pictures[it] is AlbumData) {
                val albumData = pictures[it] as AlbumData
                val isSelectAll = !albumData.isSelected
                albumData.isSelected = isSelectAll
                var pos = it + 1
                while (pos < pictures.size) {
                    if (pictures[pos] is PictureData) {
                        val model = pictures[pos] as PictureData
                        model.isSelected = isSelectAll
                        pos++
                    } else if (pictures[pos] is AlbumData) {
                        break
                    }
                }
                notifyAdapter()
                setSelectedFile()
            }
        })

        binding.pictureRecycler.adapter = pictureAdapter
    }

    fun setCloseToolbar() {
        setClose()
        longClickListener(false, 0, false)
    }

    private fun setSelectedFile() {
        var selected = 0
        var allItemCount = 0

        var currentHeaderPos = -1
        var photosCount = 0
        var photosSelectCount = 0

        for (i in pictures.indices) {
            if (pictures[i] is AlbumData) {
                if (i != currentHeaderPos) {
                    if (currentHeaderPos != -1) {
                        val model = pictures[currentHeaderPos] as AlbumData
                        model.isSelected = photosCount == photosSelectCount
                        photosCount = 0
                        photosSelectCount = 0
                        pictureAdapter?.notifyItemChanged(currentHeaderPos)
                    }
                    currentHeaderPos = i
                }
            } else if (pictures[i] is PictureData) {
                val model = pictures[i] as PictureData
                allItemCount++
                photosCount++
                if (model.isSelected) {
                    selected++
                    photosSelectCount++
                }
            }
            if (i == pictures.size - 1) {
                if (currentHeaderPos != -1) {
                    val model = pictures[currentHeaderPos] as AlbumData
                    model.isSelected = photosCount == photosSelectCount
                    photosCount = 0
                    photosSelectCount = 0
                    pictureAdapter?.notifyItemChanged(currentHeaderPos)
                }
            }
        }
//        if (selected == 0) {
//            longClickListener(false, selected, false)
//            setClose()
//        } else {
//            longClickListener(true, selected, allItemCount == selected)
//        }
        longClickListener(true, selected, allItemCount == selected)
        binding.swipeRefreshLayout.isEnabled = false
//        binding.swipeRefreshLayout.isEnabled = selected == 0
        selectedItem = selected
    }

    override fun onBackPressed() {
        if (isOpenMenu())
            popupWindow.dismiss()
        else if (binding.groupToolbarSelectHeader.visibility == View.VISIBLE) {
            setCloseToolbar()
        } else
            finish()
    }

    private fun isOpenMenu(): Boolean {
        if (::popupWindow.isInitialized) {
            return popupWindow.isShowing
        }
        return false
    }

    private fun longClickListener(
        isShowSelection: Boolean,
        selectedItem: Int,
        isAllSelect: Boolean
    ) {
        binding.groupToolbarSelectHeader.visibility =
            if (isShowSelection) View.VISIBLE else View.GONE
        isSelectAll = isAllSelect
        binding.loutSelectOption.visibility =
            if (isShowSelection && selectedItem != 0) View.VISIBLE else View.GONE
        binding.groupToolbarHeader.visibility =
            if (isShowSelection) View.GONE else View.VISIBLE
        binding.txtSelectCount.text = "$selectedItem ${getString(R.string.items_selected)}"
        setSelectAllColor()
    }

    private fun setSelectAllColor() {
        val color =
            ContextCompat.getColor(this, if (isSelectAll) R.color.black else R.color.un_check_color)
        binding.icSelect.setColorFilter(color, PorterDuff.Mode.SRC_IN)
    }

    fun setSelectClick(isSelectAll: Boolean) {
//        if (isSelectAll) {
        var selected = 0
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    model.isSelected = isSelectAll
                } else if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    model.isSelected = isSelectAll
                    if (isSelectAll)
                        selected++

                }
        }
        notifyAdapter()
        longClickListener(true, selected, isSelectAll)
        selectedItem = selected
//        } else {
//            longClickListener(false, 0, false)
//            setClose()
//        }
    }

    private fun setClose() {
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    model.isSelected = false
                    model.isCheckboxVisible = false
                } else if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    model.isCheckboxVisible = false
                    model.isSelected = false
                }
        }
        binding.swipeRefreshLayout.isEnabled = true
        notifyAdapter()
        selectedItem = 0
    }

    fun shareImages() {
        if (selectedItem == 0) {
            Toast.makeText(
                this,
                this.getString(R.string.PleaseSelectImage),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            val uris = ArrayList<Uri>()
            for (i in pictures.indices) {
                if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    if (model.isSelected) {
                        val uri = FileProvider.getUriForFile(
                            this,
                            this.packageName + ".provider",
                            File(model.filePath)
                        )
                        uris.add(uri)
                    }
                }
            }
            Utils().shareFilesList(this, uris)
        }
    }

    fun setHideData() {
        if (selectedItem == 0) {
            Toast.makeText(
                this,
                this.getString(R.string.PleaseSelectImage),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            val hideDialog = ConfirmationDialog(
                this,
                getString(R.string.Private),
                getString(R.string.hide_msg),
                getString(R.string.hide),
                positiveBtnClickListener = {
                    hidePhoto()
                })
            hideDialog.show(supportFragmentManager, hideDialog.tag)
        }
    }

    fun showDeleteDialog() {
        if (selectedItem == 0) {
            Toast.makeText(
                this,
                this.getString(R.string.PleaseSelectImage),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            val deleteDialog = DeleteDialog(
                this,
                getString(R.string.selected_delete_msg),
                positiveBtnClickListener = {
                    deletePhoto()
                })
            deleteDialog.show(supportFragmentManager, deleteDialog.tag)
        }
    }

    fun showAddAlbumDialog(albumList: ArrayList<AlbumData>, isCopy: Boolean) {
        if (selectedItem == 0) {
            Toast.makeText(
                this,
                getString(R.string.PleaseSelectImage),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            val selectImage: ArrayList<PictureData> = ArrayList()
            for (i in pictures.indices) {
                if (pictures[i] != null)
                    if (pictures[i] is PictureData) {
                        val model: PictureData = pictures[i] as PictureData
                        if (model.isSelected) {
                            selectImage.add(model)
                        }
                    }
            }
            val addAlbumDialog =
                SelectAlbumDialog(this, albumList, isCopy, selectPathListener = { selectPath ->
                    setCopyMove(isCopy, selectPath, selectImage)

                }, createAlbumListener = {
                    val createDialog = CreateAlbumDialog(this, createPathListener = {
                        setCopyMove(isCopy, it, selectImage)
                    })
                    createDialog.show(supportFragmentManager, createDialog.tag)
                })
            addAlbumDialog.show(supportFragmentManager, addAlbumDialog.tag)
        }
    }

    private fun setCopyMove(
        isCopy: Boolean,
        selectPath: String,
        selectImage: java.util.ArrayList<PictureData>
    ) {
        if (isCopy)
            Utils().copyFiles(
                this,
                selectPath,
                selectImage,
                selectedItem,
                copyListener = {
                    Toast.makeText(
                        this,
                        getString(R.string.copy_successfully),
                        Toast.LENGTH_SHORT
                    ).show()
                    selectedItem = 0
                    longClickListener(false, 0, false)
                    setClose()
                })
        else
            Utils().moveFiles(
                this,
                selectPath,
                selectImage,
                selectedItem,
                copyListener = {
                    Toast.makeText(
                        this,
                        getString(R.string.move_successfully),
                        Toast.LENGTH_SHORT
                    ).show()
                    selectedItem = 0
                    longClickListener(false, 0, false)
                    setClose()
                })
    }

    private fun hidePhoto() {
        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }

        Utils().hideFiles(this, selectImage, selectedItem, hideListener = {
            Toast.makeText(
                this,
                getString(R.string.hide_successfully),
                Toast.LENGTH_SHORT
            ).show()
            selectedItem = 0
            longClickListener(false, 0, false)
            setClose()
        })
    }

    @SuppressLint("CheckResult")
    private fun deletePhoto() {
        val deleteList = ArrayList<String>()
        val bindingDialog = DialogDeleteProgressBinding.inflate(layoutInflater)
        val dialog = Dialog(this, R.style.Dialog)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(bindingDialog.root)
        dialog.setCanceledOnTouchOutside(false)
        dialog.window?.setGravity(Gravity.BOTTOM)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        bindingDialog.progressBar.max = selectedItem

        runOnUiThread {
            bindingDialog.txtProgressCount.text = deleteList.size.toString() + "/" + selectedItem
            bindingDialog.progressBar.progress = deleteList.size
        }
        dialog.show()

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(this)
            for (i in pictures.indices) {
                if (pictures[i] != null)
                    if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        if (model.isSelected) {
                            runOnUiThread {
                                bindingDialog.txtTitle.text = model.fileName
                            }

                            val isDelete = Utils().deleteFile(this, model.filePath, dataBase)
                            if (isDelete) {
                                deleteList.add(model.filePath)
                                runOnUiThread {
                                    bindingDialog.txtProgressCount.text =
                                        deleteList.size.toString() + "/" + selectedItem
                                    bindingDialog.progressBar.progress = deleteList.size
                                }
                            }
                        } else {
                            model.isCheckboxVisible = false
                        }
                    } else if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false
                    }
            }

            var i = 0
            while (i < pictures.size) {
                if (pictures[i] != null)
                    if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false

                    } else if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        if (model.isSelected) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is AlbumData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                        } else {
                            model.isSelected = false
                            model.isCheckboxVisible = false
                        }
                    }
                i++
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    if (dialog.isShowing)
                        dialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    if (dialog.isShowing)
                        dialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
    }

    private fun setBeforeDeleteUpdate(deleteList: ArrayList<String>) {
        EventBus.getDefault().post(DeleteEvent(1, deleteList))
        selectedItem = 0
        notifyAdapter()
        binding.swipeRefreshLayout.isEnabled = true
        longClickListener(false, 0, false)
        setEmptyData()
        Toast.makeText(
            this,
            getString(R.string.Delete_successfully),
            Toast.LENGTH_SHORT
        ).show()
        deleteMainList(deleteList)
    }

    private fun deleteMainList(deleteList: ArrayList<String>) {
        if (deleteList.size != 0) {
//            for (path in deleteList) {
//                for (pictureData in filterList) {
//                    if (pictureData.getFilePath().equalsIgnoreCase(path)) {
//                        filterList.remove(pictureData)
//                        break
//                    }
//                }
//            }
            for (path in deleteList) {
                for (pictureData in allList) {
                    if (pictureData.filePath == path) {
                        allList.remove(pictureData)
                        break
                    }
                }
            }
            for (path in deleteList) {
                for (pictureData in allBackList) {
                    if (pictureData.filePath == path) {
                        allBackList.remove(pictureData)
                        break
                    }
                }
            }
        }
    }

    private fun getData() {
        disableScroll()
        binding.swipeRefreshLayout.isRefreshing = true
        Observable.fromCallable<Boolean> {
            setFilter()
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread { setData() }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread { setData() }
            }
    }

    private fun setFilter() {
        Log.e("", "imageVideo size==>> " + allList.size)
        val sortType = preferences.getSortType()
        val sortOrder = preferences.getSortOrder()

        Collections.sort(allList, Comparator { p1, p2 ->
            if (sortType == Constant.SORT_NAME) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.fileName.compareTo(p2.fileName, true)
                else
                    p2.fileName.compareTo(p1.fileName, true)
            } else if (sortType == Constant.SORT_PATH) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.filePath.compareTo(p2.filePath, true)
                else
                    p2.filePath.compareTo(p1.filePath, true)
            } else if (sortType == Constant.SORT_SIZE) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.fileSize.compareTo(p2.fileSize)
                else
                    p2.fileSize.compareTo(p1.fileSize)
            } else if (sortType == Constant.SORT_LAST_MODIFIED) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.date.compareTo(p2.date)
                else
                    p2.date.compareTo(p1.date)
            } else if (sortType == Constant.SORT_DATE_TAKEN) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.dateTaken.compareTo(p2.dateTaken)
                else
                    p2.dateTaken.compareTo(p1.dateTaken)
            } else
                p2.date.compareTo(p1.date)
        })
        Collections.sort(allBackList, Comparator { p1, p2 ->
            if (sortType == Constant.SORT_NAME) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.fileName.compareTo(p2.fileName, true)
                else
                    p2.fileName.compareTo(p1.fileName, true)
            } else if (sortType == Constant.SORT_PATH) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.filePath.compareTo(p2.filePath, true)
                else
                    p2.filePath.compareTo(p1.filePath, true)
            } else if (sortType == Constant.SORT_SIZE) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.fileSize.compareTo(p2.fileSize)
                else
                    p2.fileSize.compareTo(p1.fileSize)
            } else if (sortType == Constant.SORT_LAST_MODIFIED) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.date.compareTo(p2.date)
                else
                    p2.date.compareTo(p1.date)
            } else if (sortType == Constant.SORT_DATE_TAKEN) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.dateTaken.compareTo(p2.dateTaken)
                else
                    p2.dateTaken.compareTo(p1.dateTaken)
            } else
                p2.date.compareTo(p1.date)
        })

        if (!isStopSearch)
            setList()
    }

    private fun notifyAdapter() {
        if (pictureAdapter != null)
            pictureAdapter?.notifyDataSetChanged()
//binding.pictureRecycler.post { pictureAdapter?.notifyDataSetChanged() }
    }

    private fun setList() {
        pictures.clear()
        notifyAdapter()

        if (isSearch)
            runOnUiThread { notifyAdapter() }

        val dateWisePictures = LinkedHashMap<String, ArrayList<PictureData>>()
        val format = SimpleDateFormat("dd MMM yyyy")
//        val format = SimpleDateFormat("EEEE, MMM dd yyyy")

        if (allList.size != 0) {
            for (pictureData in allList) {
                val strDate = format.format(pictureData.date)
                if (isStopSearch) {
                    break
                } else {
                    var imagesData1: ArrayList<PictureData> = ArrayList()
                    if (dateWisePictures.containsKey(strDate)) {
                        val list: ArrayList<PictureData>? = dateWisePictures[strDate]
                        if (!list.isNullOrEmpty())
                            imagesData1.addAll(list)
                    } else {
                        imagesData1 = ArrayList()
                    }
                    imagesData1.add(pictureData)
                    dateWisePictures[strDate] = imagesData1
                }
            }

            val keys: Set<String> = dateWisePictures.keys
            val listKeys = ArrayList(keys)

            for (i in listKeys.indices) {
                if (isStopSearch) {
                    break
                } else {
                    val imagesData = dateWisePictures[listKeys[i]]
                    if (imagesData != null && imagesData.size != 0) {
                        val bucketData = AlbumData(listKeys[i], imagesData)
                        pictures.add(bucketData)
                        pictures.addAll(imagesData)
                    }
                }
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onUpdateFavoriteEvent(event: UpdateFavoriteEvent) {
        updateFavoriteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDisplayDeleteEvent(event: DisplayDeleteEvent) {
        displayDeleteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDeleteEvent(event: DeleteEvent) {
        deleteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onCopyMoveEvent(event: CopyMoveEvent) {
        copyMoveEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onRestoreDataEvent(event: RestoreDataEvent) {
        restoreEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onRenameEvent(event: RenameEvent) {
        renameEvent(event)
    }

    private fun updateFavoriteEvent(event: UpdateFavoriteEvent) {

        if (event.path.isNotEmpty()) {
            if (pictures.isNotEmpty()) {
                for (picture in pictures) {
                    if (picture is PictureData) {
                        val pictureData: PictureData = picture as PictureData
                        if (pictureData.filePath == event.path) {
                            pictureData.isFavorite = event.isFavorite
                            break
                        }
                    }
                }
                notifyAdapter()
            }
            if (allList.isNotEmpty())
                for (pictureData in allList) {
                    if (pictureData.filePath == event.path) {
                        pictureData.isFavorite = event.isFavorite
                        break
                    }
                }
            if (allBackList.isNotEmpty())
                for (pictureData in allBackList) {
                    if (pictureData.filePath == event.path) {
                        pictureData.isFavorite = event.isFavorite
                        break
                    }
                }
        }
        if (event.unFavoriteList.isNotEmpty()) {
            if (pictures.isNotEmpty()) {
                for (favPath in event.unFavoriteList) {
                    for (picture in pictures) {
                        if (picture is PictureData) {
                            val pictureData: PictureData = picture as PictureData
                            if (pictureData.filePath == favPath) {
                                pictureData.isFavorite = event.isFavorite
                                break
                            }
                        }
                    }
                }
                notifyAdapter()
            }
            if (allList.isNotEmpty())
                for (favPath in event.unFavoriteList) {
                    for (pictureData in allList) {
                        if (pictureData.filePath == favPath) {
                            pictureData.isFavorite = event.isFavorite
                            break
                        }
                    }
                }

            if (allBackList.isNotEmpty())
                for (favPath in event.unFavoriteList) {
                    for (pictureData in allBackList) {
                        if (pictureData.filePath == favPath) {
                            pictureData.isFavorite = event.isFavorite
                            break
                        }
                    }
                }
        }

    }

    private fun displayDeleteEvent(event: DisplayDeleteEvent) {
        if (event.deleteList.isNotEmpty())
            if (pictures.isNotEmpty()) {
                updateDeleteImageData(event.deleteList)
                deleteMainList(event.deleteList)
            }
    }

    private fun renameEvent(event: RenameEvent) {
        if (event.oldPath.isNotEmpty() && event.renamePath.isNotEmpty()) {
            if (pictures.isNotEmpty()) {
                for (picture in pictures) {
                    if (picture is PictureData) {
                        val model = pictures as PictureData
                        if (model.filePath == event.oldPath) {
                            model.filePath = event.renamePath
                            model.fileName = File(event.renamePath).name
                            model.fileSize = File(event.renamePath).length()
                            break
                        }
                    }
                }
            }
            pictureAdapter?.notifyDataSetChanged()

            if (allBackList.isNotEmpty()) {
                for (pictureData in allBackList) {
                    if (pictureData.filePath == event.oldPath) {
                        pictureData.filePath = event.renamePath
                        pictureData.fileName = File(event.renamePath).name
                        pictureData.fileSize = File(event.renamePath).length()
                        break
                    }
                }

                for (pictureData in allList) {
                    if (pictureData.filePath == event.oldPath) {
                        pictureData.filePath = event.renamePath
                        pictureData.fileName = File(event.renamePath).name
                        pictureData.fileSize = File(event.renamePath).length()
                        break
                    }
                }

            }
        }
    }

    private fun restoreEvent(event: RestoreDataEvent) {
        if (event.restoreList.isNotEmpty())
            if (pictures.isNotEmpty()) {
                val list: ArrayList<String> = ArrayList()
                val imageList: ArrayList<String> = ArrayList()
                val favList = preferences.getFavoriteList()

                for (restoreData in event.restoreList) {
                    list.add(restoreData.deletedPath)
                    imageList.add(restoreData.path)
                }

                updateDeleteImageData(list)
                deleteMainList(list)

                var isAddData = false
                for (i in imageList.indices) {
                    val file1 = File(imageList[i])
                    if (file1.exists()) {
                        if (albumData.folderPath == file1.parentFile.path) {
                            val pictureData = PictureData(
                                file1.path,
                                file1.name,
                                file1.parentFile.name,
                                file1.lastModified(),
                                file1.lastModified(),
                                file1.length()
                            )
                            pictureData.isFavorite = favList.contains(file1.path)
                            if (Utils().isVideoFile(file1.path)) {
                                pictureData.isVideo = true
                            }
                            isAddData = true
                            allList.add(pictureData)
                            allBackList.add(pictureData)
                        }
                    }
                }
                if (isAddData)
                    setFilterData()
            }
    }

    private fun copyMoveEvent(event: CopyMoveEvent) {
        if (event.copyMoveList.isNotEmpty()) {
            val imageList: ArrayList<String> = ArrayList()
            imageList.addAll(event.copyMoveList)

            val favList = preferences.getFavoriteList()

            if (event.deleteList.isNotEmpty())
                if (pictures.isNotEmpty()) {
                    deleteMainList(event.deleteList)
                }

            if (albumData.folderPath == event.albumPath) {
                val file = File(event.albumPath)
                if (file.exists()) {
                    for (i in imageList.indices) {
                        val file1 = File(imageList[i])
                        if (file1.exists()) {
                            val pictureData = PictureData(
                                file1.path,
                                file1.name,
                                file1.parentFile.name,
                                file1.lastModified(),
                                file1.lastModified(),
                                file1.length()
                            )
                            pictureData.isFavorite = favList.contains(file1.path)
                            if (Utils().isVideoFile(file1.path)) {
                                pictureData.isVideo = true
                            }
                            allList.add(pictureData)
                            allBackList.add(pictureData)
                        }
                    }
                    setFilterData()
                }
            } else {
                updateDeleteImageData(event.deleteList)
            }
        }
    }

    private fun deleteEvent(event: DeleteEvent) {
        if (event.deleteList.isNotEmpty() && event.pos != 0)
            if (pictures.isNotEmpty()) {
                updateDeleteImageData(event.deleteList)
                deleteMainList(event.deleteList)
            }
    }

    private fun updateDeleteImageData(deleteList: ArrayList<String>) {
        if (pictures.isNotEmpty()) {
            for (d in deleteList.indices) {
                var i = 0
                while (i < pictures.size) {
                    if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        if (model.filePath == deleteList[d]) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is AlbumData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                            if (d == deleteList.size - 1) {
                                break
                            }
                        }
                    }
                    i++
                }
            }
            notifyAdapter()
            setEmptyData()
        }
    }

    private fun disableScroll() {
        binding.pictureRecycler.suppressLayout(true)
    }

    private fun enableScroll() {
        binding.pictureRecycler.suppressLayout(false)
    }


    fun setFilterData() {
        disableScroll()
        binding.swipeRefreshLayout.isRefreshing = true
        GlobalScope.launch(Dispatchers.IO) {
            setFilter()

            runOnUiThread {
                setData()
            }
        }
//        Observable.fromCallable<Boolean> {
//            setFilter()
//            true
//        }.subscribeOn(Schedulers.io())
//            .doOnError { _: Throwable? ->
//                runOnUiThread { setData() }
//            }
//            .subscribe { _: Boolean? ->
//                runOnUiThread { setData() }
//            }
    }
}