package com.gallery.photo.image.video.ui.dialog

import android.app.Activity
import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.firebase.analytics.FirebaseAnalytics
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.DialogAddAlbumBinding
import com.gallery.photo.image.video.ui.adapter.AddAlbumAdapter
import com.gallery.photo.image.video.ui.model.AlbumData
import com.gallery.photo.image.video.utils.Constant


class SelectAlbumDialog(
    var mContext: Activity,
    var albumDataList: ArrayList<AlbumData>,
    var isCopy: Boolean,
    val selectPathListener: (path: String) -> Unit,
    val createAlbumListener: () -> Unit,
) :
    BottomSheetDialogFragment() {

    lateinit var binding: DialogAddAlbumBinding
    lateinit var albumAdapter: AddAlbumAdapter
    var albumList: ArrayList<AlbumData> = ArrayList()
    lateinit var firebaseAnalytics: FirebaseAnalytics
    var selectPos = 0


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = DialogAddAlbumBinding.inflate(layoutInflater, container, false)
        intView()
        return binding.root
    }

    private fun intView() {
        firebaseAnalytics = FirebaseAnalytics.getInstance(requireActivity())
        val bundle2 = Bundle()
        bundle2.putString("SelectAlbum", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_dialog, bundle2)

        if (isCopy)
            binding.txtTitle.text = mContext.getString(R.string.copy_to_album)
        else
            binding.txtTitle.text = mContext.getString(R.string.move_to_album)

        albumList.add(AlbumData(mContext.getString(R.string.create_an_album), isCustomAlbum = true))
        albumList.addAll(albumList.size, albumDataList)

        initAdapter()
        initListener()
    }

    private fun initListener() {
        binding.btnClose.setOnClickListener { dismiss() }
    }

    private fun initAdapter() {
        albumAdapter = AddAlbumAdapter(mContext, albumList, clickListener = {
            selectPos = it
            val albumData = albumList[selectPos]
            if (albumData.isCustomAlbum) {
                if (albumData.title == mContext.getString(R.string.create_an_album)) {
                    dismiss()
                    createAlbumListener()
                }
            } else {
                dismiss()
                selectPathListener(albumData.folderPath)
            }
        })
        binding.albumRecycler.adapter = albumAdapter
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)

}