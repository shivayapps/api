package com.gallery.photo.image.video.ui.model

import android.graphics.drawable.Drawable
import jp.co.cyberagent.android.gpuimage.filter.GPUImageFilter

data class FiltersData ( val filter:GPUImageFilter,
                        val name :String= "",var images:Drawable? )