package com.gallery.photo.image.video.ui.activity.duplicate

import com.gallery.photo.image.video.duplicat_function.model_class.DataItem
import com.gallery.photo.image.video.duplicat_function.model_class.Item


interface OnSelectCheck {
    fun setCheckButtons(dataItem: DataItem, position: Int)
    fun noDataFound(lists:List<com.gallery.photo.image.video.duplicat_function.model_class.Item>)
    fun isCicks()
    fun progresssvisibal()
    fun progresssonGone()
}