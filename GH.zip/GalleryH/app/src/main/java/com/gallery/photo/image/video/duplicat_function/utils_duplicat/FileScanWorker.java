package com.gallery.photo.image.video.duplicat_function.utils_duplicat;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.util.Log;

import androidx.work.Data;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.gallery.photo.image.video.R;
import com.gallery.photo.image.video.duplicat_function.core_class.FileHashGrouper;
import com.gallery.photo.image.video.duplicat_function.core_class.FilesProcessor;
import com.gallery.photo.image.video.duplicat_function.model_class.DFile;
import com.gallery.photo.image.video.duplicat_function.model_class.DupFileContainer;

import java.util.List;
import java.util.Set;


public class FileScanWorker extends Worker {

    public static final String TOTAL_DUPLICATES_FOUND = "TOTAL_DUPLICATES_FOUND";
    public static final String KEY_PREF_IMAGE_MATCH_SENSITIVITY = "sensitivity";
    private final Context context;
    private final FileHashGrouper fileHashGrouper;
    private final FilesProcessor filesProcessor;
    private final StorageManager storageManager;

    
    public interface ProgressProgressListener {
        void setProcessedFileCount(int i);
    }

    public FileScanWorker(Context context, WorkerParameters workerParameters) {
        super(context, workerParameters);
        this.context = context;
        context.getSystemService(Context.NOTIFICATION_SERVICE);
        boolean showHiddenFile = false/*false*/;
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        int integer = 4; /*- defaultSharedPreferences.getInt(KEY_PREF_IMAGE_MATCH_SENSITIVITY, 0);*/
        Log.d("sfdsfds"," integer "+ integer + " sss : "+defaultSharedPreferences.getInt(KEY_PREF_IMAGE_MATCH_SENSITIVITY, 0));
        this.filesProcessor = new FilesProcessor(context, Environment.getExternalStorageDirectory().getAbsolutePath(), workerParameters.getInputData().getString(DuplicateConstants.SCAN_TYPE), showHiddenFile);
        this.fileHashGrouper = new FileHashGrouper(integer);
        this.storageManager = new StorageManager(context);
    }

    @Override 
    public Result doWork() {
        this.filesProcessor.setProgressProgressListener(new ProgressProgressListener() {
            @Override
            public final void setProcessedFileCount(int i) {
                FileScanWorker.this.lambda$doWork$0$FileScanWorker(i);
            }
        });
        Set<Set<DFile>> traverse = this.filesProcessor.traverse();
        this.fileHashGrouper.setProgressProgressListener(new ProgressProgressListener() {

            @Override
            public final void setProcessedFileCount(int i) {
                FileScanWorker.this.lambda$doWork$1$FileScanWorker(i);
            }
        });
        DupFileContainer process = this.fileHashGrouper.process(traverse);
        this.storageManager.storeData(process);
        int dupFileCount = getDupFileCount(process);

        this.storageManager.registerScanTime();
        this.storageManager.saveTotalDuplicateFound(dupFileCount);
        return Result.success(new Data.Builder().putInt(TOTAL_DUPLICATES_FOUND, dupFileCount).build());
    }

    public void lambda$doWork$0$FileScanWorker(int i) {
        Data.Builder builder = new Data.Builder();
        setProgressAsync(builder.putString(DuplicateConstants.FILE_PROCESSING_COUNT, i + "").putString(DuplicateConstants.FILE_PROCESSING_MESSAGE, this.context.getString(R.string.scanned_files, Integer.valueOf(i))).build());
    }

    public void lambda$doWork$1$FileScanWorker(int i) {
        Data.Builder builder = new Data.Builder();
        setProgressAsync(builder.putString(DuplicateConstants.FILE_PROCESSING_COUNT, i + "").putString(DuplicateConstants.FILE_PROCESSING_MESSAGE, this.context.getString(R.string.analysed_files, Integer.valueOf(i))).build());
    }

    private int getDupFileCount(DupFileContainer dupFileContainer) {
        int i = 0;
        if (dupFileContainer == null) {
            return 0;
        }
        List<List<DFile>> video = dupFileContainer.getVideo();
        Log.d("fdffs","sizess : "+dupFileContainer.getImage().size());
        video.addAll(dupFileContainer.getImage());
        video.addAll(dupFileContainer.getAudio());
        video.addAll(dupFileContainer.getOther());
        for (List<DFile> list : video) {
            i = (i + list.size()) - 1;
        }
        return i;
    }

    @Override
    public void onStopped() {
        super.onStopped();
        this.filesProcessor.setStopped(true);
        this.fileHashGrouper.setStopped(true);
    }
}
