package com.gallery.photo.image.video.ui.adapter.edit

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import androidx.appcompat.widget.AppCompatImageView
import androidx.core.content.ContextCompat
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.ui.model.edit.EditData

class SelectDoodleAdapter(
    private val context: Context,
    private val optionList: ArrayList<EditData>
) :
    BaseAdapter() {
    override fun getCount(): Int {
        return optionList.size
    }

    override fun getItem(position: Int): Any {
        return optionList[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view: View
        val viewHolder: ViewHolderView

        if (convertView == null) {
            view = LayoutInflater.from(context)
                .inflate(R.layout.item_spinner_doodle, parent, false)
            viewHolder = ViewHolderView(view)
            view.tag = viewHolder
        } else {
            view = convertView
            viewHolder = view.tag as ViewHolderView
        }

        val albumData = optionList[position]
        viewHolder.txtTitle.text = albumData.name
        viewHolder.image.setImageDrawable(albumData.icon)

        viewHolder.divider.visibility = if (position == optionList.size -1) View.GONE else View.VISIBLE

        viewHolder.topView.visibility = if (position == 0) View.VISIBLE else View.GONE
        viewHolder.bottomView.visibility =
            if (position == optionList.size - 1) View.VISIBLE else View.GONE

        return view

    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view: View
        val viewHolder: ViewHolder

        if (convertView == null) {
            view = LayoutInflater.from(context)
                .inflate(R.layout.item_spinner_doodle, parent, false)
            viewHolder = ViewHolder(view)
            view.tag = viewHolder
        } else {
            view = convertView
            viewHolder = view.tag as ViewHolder
        }

        val item = optionList[position]
        viewHolder.itemTextView.text = item.name
        viewHolder.image.visibility = View.GONE
        viewHolder.itemTextView.setTextColor(
            ContextCompat.getColor(
                context,
                R.color.black_text
            )
        )

        viewHolder.itemTextView.visibility = View.VISIBLE

        return view
    }


    private class ViewHolder(view: View) {
        val itemTextView: TextView = view.findViewById(R.id.txtTitle)
        val image: AppCompatImageView = view.findViewById(R.id.image)
    }

    private class ViewHolderView(view: View) {
        val txtTitle: TextView = view.findViewById(R.id.txtTitle)
        val image: AppCompatImageView = view.findViewById(R.id.image)
        val topView: View = view.findViewById(R.id.topView)
        val bottomView: View = view.findViewById(R.id.bottomView)
        val divider: View = view.findViewById(R.id.divider)
    }
}