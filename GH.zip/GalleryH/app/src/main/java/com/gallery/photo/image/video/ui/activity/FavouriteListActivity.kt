package com.gallery.photo.image.video.ui.activity

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.Toast
import androidx.appcompat.widget.PopupMenu
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.database.AppDatabase
import com.gallery.photo.image.video.databinding.ActivityFavouriteListBinding
import com.gallery.photo.image.video.databinding.DialogDeleteProgressBinding
import com.gallery.photo.image.video.databinding.PopBottomMenuBinding
import com.gallery.photo.image.video.ui.adapter.FavouriteAdapter
import com.gallery.photo.image.video.ui.dialog.ConfirmationDialog
import com.gallery.photo.image.video.ui.dialog.CreateAlbumDialog
import com.gallery.photo.image.video.ui.dialog.DeleteDialog
import com.gallery.photo.image.video.ui.dialog.SelectAlbumDialog
import com.gallery.photo.image.video.ui.event.CopyMoveEvent
import com.gallery.photo.image.video.ui.event.DeleteEvent
import com.gallery.photo.image.video.ui.event.DisplayDeleteEvent
import com.gallery.photo.image.video.ui.event.RenameEvent
import com.gallery.photo.image.video.ui.event.UpdateFavoriteEvent
import com.gallery.photo.image.video.ui.model.AlbumData
import com.gallery.photo.image.video.ui.model.PictureData
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.Preferences
import com.gallery.photo.image.video.utils.Utils
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File
import java.text.SimpleDateFormat
import java.util.Collections
import kotlin.math.roundToInt

class FavouriteListActivity : BaseActivity() {

    lateinit var binding: ActivityFavouriteListBinding
    var allList = ArrayList<PictureData>()
    var pictures = ArrayList<Any>()
    var pictureAdapter: FavouriteAdapter? = null
    lateinit var preferences: Preferences
    var selectedItem = 0
    var isSelectAll = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFavouriteListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        EventBus.getDefault().register(this)
        intView()
    }

    private fun intView() {
        val bundle2 = Bundle()
        bundle2.putString("favourite", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_activity, bundle2)

        binding.loutToolbar.txtTitle.text = getString(R.string.favorites)
        preferences = Preferences(this)
        binding.loutToolbar.icMenu.setImageDrawable(
            ContextCompat.getDrawable(
                this,
                R.drawable.ic_fav_remove
            )
        )
        getData()
        binding.swipeRefreshLayout.setOnRefreshListener {
            if (binding.swipeRefreshLayout.isEnabled)
                getData()
            else
                binding.swipeRefreshLayout.isRefreshing = false
        }
        intListener()
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }

    private fun isOpenMenu(): Boolean {
        if (::popupWindow.isInitialized) {
            return popupWindow.isShowing
        }
        return false
    }


    private fun intListener() {
        binding.loutToolbar.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.loutToolbar.icClose.setOnClickListener {
            setCloseToolbar()
        }
        binding.loutToolbar.icSelect.setOnClickListener {
            isSelectAll = !isSelectAll
            setSelectClick(isSelectAll)
            setSelectAllColor()
        }

        binding.loutToolbar.icMenu.setOnClickListener {
            val clearDialog = ConfirmationDialog(
                this,
                getString(R.string.clearFavorites),
                getString(R.string.clearFavoritesMsg),
                getString(R.string.clear),
                positiveBtnClickListener = {
                    clearFav()
                })
            clearDialog.show(supportFragmentManager, clearDialog.tag)
        }

        binding.btnShare.setOnClickListener {
            shareImages()
        }
        binding.btnDelete.setOnClickListener {
            showDeleteDialog()
        }
        binding.btnUnFavorite.setOnClickListener {
            setUnFavoriteData()
        }
        binding.btnHide.setOnClickListener {
            setHideData()
        }

        binding.btnMore.setOnClickListener {
//            showMoreMenu()
            showDropDown(binding.ivMenuView)
        }
    }

    private fun clearFav() {
        val favList = preferences.getFavoriteList()
        preferences.setFavoriteList(ArrayList())
        allList.clear()
        pictures.clear()
        EventBus.getDefault()
            .post(UpdateFavoriteEvent(unFavoriteList = favList, isFavorite = false))
        setData()
    }

    lateinit var popupWindow: PopupWindow
    private fun showDropDown(view: View) {
        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopBottomMenuBinding.inflate(layoutInflater)
        val popupView = popUpBinding.root
        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        params.setMargins(10, 0, 50, 0)
        popupView.layoutParams = params
        popupWindow = PopupWindow(
            popupView,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        popupWindow.animationStyle = R.style.ShowUpAnimation_BR

        popupWindow.setBackgroundDrawable(BitmapDrawable())
        popupWindow.isOutsideTouchable = true
        val a = IntArray(2)
        view.getLocationInWindow(a)
        popupWindow.showAtLocation(
            view, Gravity.NO_GRAVITY, a[0],
            (a[1] - view.height - resources.getDimension(com.intuit.sdp.R.dimen._60sdp)).roundToInt()
        )
        popupWindow.update()
        popupWindow.showAsDropDown(view)

        popUpBinding.loutMain.setOnClickListener {
            popupWindow.dismiss()
        }

        popUpBinding.menuCopy.setOnClickListener {
            popupWindow.dismiss()
            showAddAlbumDialog(Constant.albumList, true)
        }
        popUpBinding.menuMove.setOnClickListener {
            popupWindow.dismiss()
            showAddAlbumDialog(Constant.albumList, false)
        }
    }

    private fun showMoreMenu() {
        val popup = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            PopupMenu(this, binding.btnMore, Gravity.END, 0, R.style.BasePopupMenu)
        } else {
            PopupMenu(this, binding.btnMore)
        }
        popup.menuInflater.inflate(R.menu.menu_bottom_option, popup.menu)
        popup.setForceShowIcon(true)

        popup.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.menuCopy -> {
                    showAddAlbumDialog(Constant.albumList, true)
                }

                R.id.menuMove -> {
                    showAddAlbumDialog(Constant.albumList, false)
                }

                R.id.menuCollage -> {

                }
            }
            return@setOnMenuItemClickListener true
        }
        popup.show()
    }

    private fun notifyAdapter() {
        if (pictureAdapter != null)
            pictureAdapter?.notifyDataSetChanged()
    }

    private fun setData() {
        binding.swipeRefreshLayout.isRefreshing = false
        enableScroll()
        if (pictureAdapter != null) notifyAdapter() else initAdapter()
        setEmptyData()
    }

    private fun setEmptyData() {
        if (pictures.size != 0) {
            binding.pictureRecycler.visibility = View.VISIBLE
            binding.loutToolbar.icMenu.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
        } else {
            binding.pictureRecycler.visibility = View.GONE
            binding.loutToolbar.icMenu.visibility = View.INVISIBLE
            binding.loutNoData.visibility = View.VISIBLE
        }
    }

    private fun initAdapter() {
        setRvLayoutManager()
        pictureAdapter = FavouriteAdapter(this, pictures, clickListener = {
            if (pictures[it] is PictureData) {
                val pictureData = pictures[it] as PictureData
                if (pictureData.isCheckboxVisible) {
                    pictureData.isSelected = !pictureData.isSelected
                    pictureAdapter?.notifyItemChanged(it)
                    setSelectedFile()
                } else {
                    val dataList = ArrayList<PictureData>()
                    var displayPos = 0
                    for (i in pictures.indices) {
                        if (pictures[i] is PictureData) {
                            dataList.add(pictures[i] as PictureData)
                            if (it == i) {
                                displayPos = dataList.size - 1
                            }
                        }
                    }
                    Constant.displayImageList = ArrayList()
                    Constant.displayImageList.addAll(dataList)
                    val intent = Intent(this, ImageViewerActivity::class.java)
                    intent.putExtra(Constant.EXTRA_DISPLAY_POS, displayPos)
                    startActivity(intent)
                }
            }
        }, longClickListener = {
            if (pictures[it] is PictureData) {
                val pictureData = pictures[it] as PictureData
                for (i in pictures.indices) {
                    if (pictures[i] != null)
                        if (pictures[i] is AlbumData) {
                            val model = pictures[i] as AlbumData
                            model.isCheckboxVisible = true
                        } else if (pictures[i] is PictureData) {
                            val model = pictures[i] as PictureData
                            model.isCheckboxVisible = true
                        }
                }
                pictureData.isCheckboxVisible = true
                pictureData.isSelected = true
                notifyAdapter()
                setSelectedFile()
            }
        }, headerSelectListener = {
            if (pictures[it] is AlbumData) {
                val albumData = pictures[it] as AlbumData
                val isSelectAll = !albumData.isSelected
                albumData.isSelected = isSelectAll
                var pos = it + 1
                while (pos < pictures.size) {
                    if (pictures[pos] is PictureData) {
                        val model = pictures[pos] as PictureData
                        model.isSelected = isSelectAll
                        pos++
                    } else if (pictures[pos] is AlbumData) {
                        break
                    }
                }
                notifyAdapter()
                setSelectedFile()
            }
        })

        binding.pictureRecycler.adapter = pictureAdapter
    }

    override fun onBackPressed() {
        if (isOpenMenu())
            popupWindow.dismiss()
        else if (binding.loutToolbar.groupToolbarSelectHeader.visibility == View.VISIBLE) {
            setCloseToolbar()
        } else
            finish()
    }

    private fun longClickListener(
        isShowSelection: Boolean,
        selectedItem: Int,
        isAllSelect: Boolean
    ) {
        binding.loutToolbar.groupToolbarSelectHeader.visibility =
            if (isShowSelection) View.VISIBLE else View.GONE
        isSelectAll = isAllSelect
        binding.loutSelectOption.visibility =
            if (isShowSelection && selectedItem != 0) View.VISIBLE else View.GONE
        binding.loutToolbar.groupToolbarHeader.visibility =
            if (isShowSelection) View.GONE else View.VISIBLE
        binding.loutToolbar.txtSelectCount.text =
            "$selectedItem ${getString(R.string.items_selected)}"
        setSelectAllColor()
    }

    private fun setSelectAllColor() {
        val color =
            ContextCompat.getColor(this, if (isSelectAll) R.color.black else R.color.un_check_color)
        binding.loutToolbar.icSelect.setColorFilter(color, PorterDuff.Mode.SRC_IN)
    }

    fun setCloseToolbar() {
        setClose()
        longClickListener(false, 0, false)
    }

    fun setRvLayoutManager() {
        val gridCount = preferences.getGridCount()
        val gridLayoutManager =
            GridLayoutManager(this, gridCount, RecyclerView.VERTICAL, false)
        binding.pictureRecycler.layoutManager = gridLayoutManager
        gridLayoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                if (position >= 0 && position < pictures.size) {
                    return if (pictureAdapter!!.getItemViewType(position) === pictureAdapter!!.ITEM_HEADER_TYPE) {
                        gridCount
                    } else 1
                } else {
                    return 1
                }
            }
        }
    }

    private fun setSelectedFile() {
        var selected = 0
        var allItemCount = 0

        var currentHeaderPos = -1
        var photosCount = 0
        var photosSelectCount = 0

        for (i in pictures.indices) {
            if (pictures[i] is AlbumData) {
                if (i != currentHeaderPos) {
                    if (currentHeaderPos != -1) {
                        val model = pictures[currentHeaderPos] as AlbumData
                        model.isSelected = photosCount == photosSelectCount
                        photosCount = 0
                        photosSelectCount = 0
                        pictureAdapter?.notifyItemChanged(currentHeaderPos)
                    }
                    currentHeaderPos = i
                }
            } else if (pictures[i] is PictureData) {
                val model = pictures[i] as PictureData
                allItemCount++
                photosCount++
                if (model.isSelected) {
                    selected++
                    photosSelectCount++
                }
            }
            if (i == pictures.size - 1) {
                if (currentHeaderPos != -1) {
                    val model = pictures[currentHeaderPos] as AlbumData
                    model.isSelected = photosCount == photosSelectCount
                    photosCount = 0
                    photosSelectCount = 0
                    pictureAdapter?.notifyItemChanged(currentHeaderPos)
                }
            }
        }
//        if (selected == 0) {
//            longClickListener(false, selected, false)
//            setClose()
//        } else {
//            longClickListener(true, selected, allItemCount == selected)
//        }
        longClickListener(true, selected, allItemCount == selected)
        binding.swipeRefreshLayout.isEnabled = false
//        binding.swipeRefreshLayout.isEnabled = selected == 0
        selectedItem = selected
    }

    fun setSelectClick(isSelectAll: Boolean) {
//        if (isSelectAll) {
        var selected = 0
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    model.isSelected = isSelectAll
                } else if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    model.isSelected = isSelectAll
                    if (isSelectAll)
                        selected++

                }
        }
        notifyAdapter()
        longClickListener(true, selected, isSelectAll)
        selectedItem = selected
//        } else {
//            longClickListener(false, 0, false)
//            setClose()
//        }
    }


    private fun setClose() {
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    model.isSelected = false
                    model.isCheckboxVisible = false
                } else if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    model.isCheckboxVisible = false
                    model.isSelected = false
                }
        }
        binding.swipeRefreshLayout.isEnabled = true
        notifyAdapter()
        selectedItem = 0
    }

    fun shareImages() {
        if (selectedItem == 0) {
            Toast.makeText(
                this,
                this.getString(R.string.PleaseSelectImage),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            val uris = ArrayList<Uri>()
            for (i in pictures.indices) {
                if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    if (model.isSelected) {
                        val uri = FileProvider.getUriForFile(
                            this,
                            this.packageName + ".provider",
                            File(model.filePath)
                        )
                        uris.add(uri)
                    }
                }
            }
            Utils().shareFilesList(this, uris)
        }
    }

    fun showDeleteDialog() {
        if (selectedItem == 0) {
            Toast.makeText(
                this,
                this.getString(R.string.PleaseSelectImage),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            val deleteDialog = DeleteDialog(
                this,
                getString(R.string.selected_delete_msg),
                positiveBtnClickListener = {
                    deletePhoto()
                })
            deleteDialog.show(supportFragmentManager, deleteDialog.tag)
        }
    }

    private fun setUnFavoriteData() {
        if (selectedItem == 0) {
            Toast.makeText(
                this,
                this.getString(R.string.PleaseSelectImage),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            val clearDialog = ConfirmationDialog(
                this,
                getString(R.string.unfavorite),
                getString(R.string.unFavorites_msg),
                getString(R.string.ok),
                positiveBtnClickListener = {
                    setUnFavoriteSelect()
                })
            clearDialog.show(supportFragmentManager, clearDialog.tag)
        }
    }

    fun setHideData() {
        if (selectedItem == 0) {
            Toast.makeText(
                this,
                this.getString(R.string.PleaseSelectImage),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            val hideDialog = ConfirmationDialog(
                this,
                getString(R.string.Private),
                getString(R.string.hide_msg),
                getString(R.string.hide),
                positiveBtnClickListener = {
                    hidePhoto()
                })
            hideDialog.show(supportFragmentManager, hideDialog.tag)
        }
    }

    private fun hidePhoto() {
        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }

        Utils().hideFiles(this, selectImage, selectedItem, hideListener = {
            Toast.makeText(
                this,
                getString(R.string.hide_successfully),
                Toast.LENGTH_SHORT
            ).show()
            selectedItem = 0
            longClickListener(false, 0, false)
            setClose()
        }, true)
    }

    fun showAddAlbumDialog(albumList: ArrayList<AlbumData>, isCopy: Boolean) {
        if (selectedItem == 0) {
            Toast.makeText(
                this,
                getString(R.string.PleaseSelectImage),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            val selectImage: ArrayList<PictureData> = ArrayList()
            for (i in pictures.indices) {
                if (pictures[i] != null)
                    if (pictures[i] is PictureData) {
                        val model: PictureData = pictures[i] as PictureData
                        if (model.isSelected) {
                            selectImage.add(model)
                        }
                    }
            }
            val addAlbumDialog =
                SelectAlbumDialog(this, albumList, isCopy, selectPathListener = { selectPath ->
                    setCopyMove(isCopy, selectPath, selectImage)

                }, createAlbumListener = {
                    val createDialog = CreateAlbumDialog(this, createPathListener = {
                        setCopyMove(isCopy, it, selectImage)
                    })
                    createDialog.show(supportFragmentManager, createDialog.tag)
                })
            addAlbumDialog.show(supportFragmentManager, addAlbumDialog.tag)
        }
    }

    private fun setCopyMove(
        isCopy: Boolean,
        selectPath: String,
        selectImage: java.util.ArrayList<PictureData>
    ) {
        if (isCopy)
            Utils().copyFiles(
                this,
                selectPath,
                selectImage,
                selectedItem,
                copyListener = {
                    Toast.makeText(
                        this,
                        getString(R.string.copy_successfully),
                        Toast.LENGTH_SHORT
                    ).show()
                    selectedItem = 0
                    longClickListener(false, 0, false)
                    setClose()
                })
        else
            Utils().moveFiles(
                this,
                selectPath,
                selectImage,
                selectedItem,
                copyListener = {
                    Toast.makeText(
                        this,
                        getString(R.string.move_successfully),
                        Toast.LENGTH_SHORT
                    ).show()
                    selectedItem = 0
                    longClickListener(false, 0, false)
                    setClose()
                }, true
            )

    }

    private fun setUnFavoriteSelect() {
        val unFavList = ArrayList<String>()
        val favList = preferences.getFavoriteList()
        Observable.fromCallable {
            for (i in pictures.indices) {
                if (pictures[i] != null)
                    if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false

                    } else if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        if (model.isSelected) {
                            if (favList.contains(model.filePath)) {
                                favList.remove(model.filePath)
                                unFavList.add(model.filePath)
                            }
                        } else {
                            model.isCheckboxVisible = false
                        }
                    }
            }

            var index = 0
            while (index < pictures.size) {
                if (pictures[index] != null)
                    if (pictures[index] is AlbumData) {
                        val model = pictures[index] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false

                    } else if (pictures[index] is PictureData) {
                        val model = pictures[index] as PictureData
                        if (model.isSelected) {
                            var isPre = false
                            var isNext = false
                            if (index != 0) {
                                isPre = pictures[index - 1] is AlbumData
                            }
                            if (index < pictures.size - 2) {
                                isNext = pictures[index + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(index)
                                pictures.removeAt(index - 1)
                            } else if (index == pictures.size - 1) {
                                pictures.removeAt(index)
                                if (isPre) {
                                    pictures.removeAt(index - 1)
                                }
                            } else {
                                pictures.removeAt(index)
                            }
                            if (index != 0) {
                                index--
                            }
                        } else {
                            model.isSelected = false
                            model.isCheckboxVisible = false
                        }
                    }
                index++
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    setUpdateFavorite(unFavList)
                }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    setUpdateFavorite(unFavList)
                }
            }
    }

    @SuppressLint("CheckResult")
    private fun deletePhoto() {
        val deleteList = ArrayList<String>()
        val bindingDialog = DialogDeleteProgressBinding.inflate(layoutInflater)
        val dialog = Dialog(this, R.style.Dialog)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(bindingDialog.root)
        dialog.setCanceledOnTouchOutside(false)
        dialog.window?.setGravity(Gravity.BOTTOM)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        bindingDialog.progressBar.max = selectedItem

        runOnUiThread {
            bindingDialog.txtProgressCount.text = deleteList.size.toString() + "/" + selectedItem
            bindingDialog.progressBar.progress = deleteList.size
        }
        dialog.show()

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(this)
            for (i in pictures.indices) {
                if (pictures[i] != null) if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    if (model.isSelected) {
                        runOnUiThread {
                            bindingDialog.txtTitle.text = model.fileName
                        }

                        val isDelete = Utils().deleteFile(this, model.filePath, dataBase)
                        if (isDelete) {
                            deleteList.add(model.filePath)
                            runOnUiThread {
                                bindingDialog.txtProgressCount.text =
                                    deleteList.size.toString() + "/" + selectedItem
                                bindingDialog.progressBar.progress = deleteList.size
                            }
                        }
                    } else {
                        model.isCheckboxVisible = false
                    }
                } else if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    model.isSelected = false
                    model.isCheckboxVisible = false
                }
            }

            var i = 0
            while (i < pictures.size) {
                if (pictures[i] != null)
                    if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false

                    } else if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        if (model.isSelected) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is AlbumData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                        } else {
                            model.isSelected = false
                            model.isCheckboxVisible = false
                        }
                    }
                i++
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    if (dialog.isShowing)
                        dialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    if (dialog.isShowing)
                        dialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
    }

    private fun setBeforeDeleteUpdate(deleteList: ArrayList<String>) {
        EventBus.getDefault().post(DeleteEvent(1, deleteList))
        selectedItem = 0
        notifyAdapter()
        binding.swipeRefreshLayout.isEnabled = true
        longClickListener(false, 0, false)
        setEmptyData()
        Toast.makeText(
            this,
            getString(R.string.Delete_successfully),
            Toast.LENGTH_SHORT
        ).show()
        deleteMainList(deleteList)
    }

    private fun setUpdateFavorite(unFavoriteList: ArrayList<String>) {
        EventBus.getDefault()
            .post(UpdateFavoriteEvent(unFavoriteList = unFavoriteList, isFavorite = false))
        selectedItem = 0
        notifyAdapter()
        longClickListener(false, 0, false)
        setEmptyData()
        Toast.makeText(
            this,
            getString(R.string.FilesUnfavoritesuccessfully),
            Toast.LENGTH_SHORT
        ).show()
        deleteMainList(unFavoriteList)
    }

    private fun deleteMainList(deleteList: ArrayList<String>, isFromFav: Boolean = false) {
        if (deleteList.size != 0) {
//            for (path in deleteList) {
//                for (pictureData in filterList) {
//                    if (pictureData.getFilePath().equalsIgnoreCase(path)) {
//                        filterList.remove(pictureData)
//                        break
//                    }
//                }
//            }
            val favList = preferences.getFavoriteList()
            for (path in deleteList) {
                if (!isFromFav)
                    if (favList.contains(path))
                        favList.remove(path)
                for (pictureData in allList) {
                    if (pictureData.filePath == path) {
                        allList.remove(pictureData)
                        break
                    }
                }
            }

            preferences.setFavoriteList(favList)
        }
    }

    private fun getData() {
        disableScroll()
        binding.swipeRefreshLayout.isRefreshing = true
        Observable.fromCallable<Boolean> {
            allList.clear()
            var favList = preferences.getFavoriteList()
            if (!favList.isNullOrEmpty()) {
//                Collections.sort(favList, Comparator { p1, p2 ->
//                    File(p2).lastModified().compareTo(File(p1).lastModified())
//                })

                for (favPath in favList) {
                    var file = File(favPath)
                    if (file.exists()) {
                        val pictureData =
                            PictureData(
                                favPath,
                                file.name,
                                file.parentFile.name,
                                file.lastModified(),
                                file.lastModified(),
                                file.length(),
                                Utils().isVideoFile(favPath)
                            )
                        pictureData.isFavorite = true
                        allList.add(pictureData)
                    }
                }

            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { throwable: Throwable? ->
                runOnUiThread {
                    setFilterData()
                }
            }
            .subscribe { result: Boolean? ->
                runOnUiThread {
                    setFilterData()
                }
            }
    }

    private fun disableScroll() {
        binding.pictureRecycler.suppressLayout(true)
    }

    private fun enableScroll() {
        binding.pictureRecycler.suppressLayout(false)
    }


    private fun setFilterData() {
        disableScroll()
        binding.swipeRefreshLayout.isRefreshing = true
        GlobalScope.launch(Dispatchers.IO) {
            setFilter()

            runOnUiThread {
                setData()
            }
        }
//        Observable.fromCallable<Boolean> {
//            setFilter()
//            true
//        }.subscribeOn(Schedulers.io())
//            .doOnError { _: Throwable? ->
//                runOnUiThread { setData() }
//            }
//            .subscribe { _: Boolean? ->
//                runOnUiThread { setData() }
//            }
    }

    private fun setFilter() {
        Log.e("", "imageVideo size==>> " + allList.size)
        val sortType = preferences.getSortType()
        val sortOrder = preferences.getSortOrder()

        Collections.sort(allList, Comparator { p1, p2 ->
            if (sortType == Constant.SORT_NAME) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.fileName.compareTo(p2.fileName, true)
                else
                    p2.fileName.compareTo(p1.fileName, true)
            } else if (sortType == Constant.SORT_PATH) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.filePath.compareTo(p2.filePath, true)
                else
                    p2.filePath.compareTo(p1.filePath, true)
            } else if (sortType == Constant.SORT_SIZE) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.fileSize.compareTo(p2.fileSize)
                else
                    p2.fileSize.compareTo(p1.fileSize)
            } else if (sortType == Constant.SORT_LAST_MODIFIED) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.date.compareTo(p2.date)
                else
                    p2.date.compareTo(p1.date)
            } else if (sortType == Constant.SORT_DATE_TAKEN) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.dateTaken.compareTo(p2.dateTaken)
                else
                    p2.dateTaken.compareTo(p1.dateTaken)
            } else
                p2.date.compareTo(p1.date)
        })

        setList()
    }


    private fun setList() {
        pictures.clear()

        val dateWisePictures = LinkedHashMap<String, ArrayList<PictureData>>()
        val format = SimpleDateFormat("dd MMM yyyy")
//        val format = SimpleDateFormat("EEEE, MMM dd yyyy")

        if (allList.size != 0) {
            for (pictureData in allList) {
                val strDate = format.format(pictureData.date)

                var imagesData1: ArrayList<PictureData> = ArrayList()
                if (dateWisePictures.containsKey(strDate)) {
                    val list: ArrayList<PictureData>? = dateWisePictures[strDate]
                    if (!list.isNullOrEmpty())
                        imagesData1.addAll(list)
                } else {
                    imagesData1 = ArrayList()
                }
                imagesData1.add(pictureData)
                dateWisePictures[strDate] = imagesData1
            }

            val keys: Set<String> = dateWisePictures.keys
            val listKeys = ArrayList(keys)

            for (i in listKeys.indices) {
                val imagesData = dateWisePictures[listKeys[i]]
                if (imagesData != null && imagesData.size != 0) {
                    val bucketData = AlbumData(listKeys[i], imagesData)
                    pictures.add(bucketData)
                    pictures.addAll(imagesData)
                }
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onUpdateFavoriteEvent(event: UpdateFavoriteEvent) {
        updateFavoriteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDisplayDeleteEvent(event: DisplayDeleteEvent) {
        displayDeleteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDeleteEvent(event: DeleteEvent) {
        deleteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onCopyMoveEvent(event: CopyMoveEvent) {
        copyMoveEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onRenameEvent(event: RenameEvent) {
        renameEvent(event)
    }


    private fun deleteEvent(event: DeleteEvent) {
        if (event.deleteList.isNotEmpty() && event.pos != 0)
            if (pictures.isNotEmpty()) {
                updateDeleteImageData(event.deleteList)
                deleteMainList(event.deleteList)
            }
    }

    private fun updateFavoriteEvent(event: UpdateFavoriteEvent) {

        if (pictures.isNotEmpty() && event.path.isNotEmpty()) {
            for (picture in pictures) {
                if (picture is PictureData) {
                    val pictureData: PictureData = picture as PictureData
                    if (pictureData.filePath == event.path) {
                        pictureData.isFavorite = event.isFavorite
                        break
                    }
                }
            }
            notifyAdapter()
        }
        if (allList.isNotEmpty() && event.path.isNotEmpty())
            for (pictureData in allList) {
                if (pictureData.filePath == event.path) {
                    pictureData.isFavorite = event.isFavorite
                    break
                }
            }
    }

    private fun displayDeleteEvent(event: DisplayDeleteEvent) {
        if (event.deleteList.isNotEmpty())
            if (pictures.isNotEmpty()) {
                updateDeleteImageData(event.deleteList)
                deleteMainList(event.deleteList, event.isFromFav)
            }
    }

    private fun updateDeleteImageData(deleteList: ArrayList<String>) {
        if (pictures.isNotEmpty()) {
            for (d in deleteList.indices) {
                var i = 0
                while (i < pictures.size) {
                    if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        if (model.filePath == deleteList[d]) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is AlbumData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                            if (d == deleteList.size - 1) {
                                break
                            }
                        }
                    }
                    i++
                }
            }
            notifyAdapter()
            setEmptyData()
        }
    }

    private fun renameEvent(event: RenameEvent) {
        if (event.oldPath.isNotEmpty() && event.renamePath.isNotEmpty()) {
            if (pictures.isNotEmpty()) {
                for (picture in pictures) {
                    if (picture is PictureData) {
                        val model = pictures as PictureData
                        if (model.filePath == event.oldPath) {
                            model.filePath = event.renamePath
                            model.fileName = File(event.renamePath).name
                            model.fileSize = File(event.renamePath).length()
                            break
                        }
                    }
                }
            }
            pictureAdapter?.notifyDataSetChanged()

            for (pictureData in allList) {
                if (pictureData.filePath == event.oldPath) {
                    pictureData.filePath = event.renamePath
                    pictureData.fileName = File(event.renamePath).name
                    pictureData.fileSize = File(event.renamePath).length()
                    break
                }
            }
        }
    }

    private fun copyMoveEvent(event: CopyMoveEvent) {
        if (event.copyMoveList.isNotEmpty()) {
            val imageList: ArrayList<String> = ArrayList()
            imageList.addAll(event.copyMoveList)



            if (event.isOpenFromFavorite) {
                if (event.deleteList.isNotEmpty())
                    if (pictures.isNotEmpty()) {
//                                    deleteMainList(event.deleteList)
                        val favList = preferences.getFavoriteList()
                        var isDataChange = false
                        for (i in event.deleteList.indices) {
                            val deletePath = event.deleteList[i]
                            if (favList.contains(deletePath)) {
                                favList.remove(deletePath)
                                if (i < event.copyMoveList.size) {
                                    val moveFilePath = event.copyMoveList[i]
                                    for (picture in pictures) {
                                        if (picture is PictureData) {
                                            val model = picture as PictureData
                                            if (model.filePath == deletePath) {
                                                model.filePath = moveFilePath
                                                model.folderName = event.albumName
                                                model.date =
                                                    File(moveFilePath).lastModified()
                                                isDataChange = true
                                                break
                                            }
                                        }
                                    }

                                    for (pictureData in allList) {
                                        if (pictureData.filePath == deletePath) {
                                            pictureData.filePath = moveFilePath
                                            pictureData.folderName = event.albumName
                                            pictureData.date =
                                                File(moveFilePath).lastModified()
                                            break
                                        }
                                    }

                                }
                            }
                        }

//                                    setFilterData()
                        setData()
                    }
            }


//                        val file = File(event.albumPath)
//                        if (file.exists()) {
//                            for (i in imageList.indices) {
//                                val file1 = File(imageList[i])
//                                if (file1.exists()) {
//                                    val pictureData = PictureData(
//                                        file1.path,
//                                        file1.name,
//                                        file1.parentFile.name,
//                                        file1.lastModified(),
//                                        file1.lastModified(),
//                                        file1.length()
//                                    )
//                                    if (Utils().isVideoFile(file1.path)) {
//                                        pictureData.isVideo = true
//                                    }
//                                    allList.add(pictureData)
//                                }
//                            }
//                            setFilterData()
//                        }

        }
    }
}