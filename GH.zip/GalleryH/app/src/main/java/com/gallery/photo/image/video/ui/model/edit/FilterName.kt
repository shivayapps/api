package com.gallery.photo.image.video.ui.model.edit

enum class FilterName {
    BRIGHTNESS,
    CONTRAST,
    SATURATION,
    SHARPEN,
    VIGNETTE
}