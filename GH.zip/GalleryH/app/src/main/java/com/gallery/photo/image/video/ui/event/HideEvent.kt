package com.gallery.photo.image.video.ui.event

data class HideEvent(var isUpdate: Boolean = false)
