package com.gallery.photo.image.video.duplicat_function.utils_duplicat;



import com.drew.imaging.ImageMetadataReader;
import com.drew.metadata.exif.ExifSubIFDDirectory;

import java.io.File;
import java.util.Date;


public class ImageMetadataExtractor {

    public static Date getPhotoTakenDateIfAvailable(File file) {
        try {

            ExifSubIFDDirectory exifSubIFDDirectory = ImageMetadataReader.readMetadata(file).getFirstDirectoryOfType(ExifSubIFDDirectory.class);
            if (exifSubIFDDirectory == null) {
                return null;
            }
            return exifSubIFDDirectory.getDateOriginal();
        } catch (Exception unused) {
            return null;
        }
    }
}
