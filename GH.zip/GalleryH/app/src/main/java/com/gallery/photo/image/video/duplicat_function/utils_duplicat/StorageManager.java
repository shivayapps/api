package com.gallery.photo.image.video.duplicat_function.utils_duplicat;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.gallery.photo.image.video.duplicat_function.model_class.DFile;
import com.gallery.photo.image.video.duplicat_function.model_class.DupFileContainer;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


public class StorageManager {
    public static DupFileContainer dupFileContainer;
    private static final String DETAILED_VIEW_LAST_SEEN_AT = "DETAILED_VIEW_LAST_SEEN_AT";
    private static final String LAST_SCANNED_AT = "LAST_SCANNED_AT";
    private static final String LIST_OF_FILES_TO_BE_DELETED = "LIST_OF_FILES_TO_BE_DELETED";
    private static final String TOTAL_DUPLICATE_FOUND = "TOTAL_DUPLICATE_FOUND";

    private SharedPreferences pref;
    private static final String TOTAL_DELETED_IMAGE_FILES_LIFETIME = "TOTAL_DELETED_IMAGE_FILES_LIFETIME";
    private static final String TOTAL_DELETED_VIDEO_FILES_LIFETIME = "TOTAL_DELETED_VIDEO_FILES_LIFETIME";
    private static final String TOTAL_DELETED_AUDIO_FILES_LIFETIME = "TOTAL_DELETED_AUDIO_FILES_LIFETIME";
    private static final String TOTAL_DELETED_OTHER_FILES_LIFETIME = "TOTAL_DELETED_OTHER_FILES_LIFETIME";
    private static final String[] TOTAL_DELETED_FILES_LIFETIME = {TOTAL_DELETED_IMAGE_FILES_LIFETIME, TOTAL_DELETED_VIDEO_FILES_LIFETIME, TOTAL_DELETED_AUDIO_FILES_LIFETIME, TOTAL_DELETED_OTHER_FILES_LIFETIME};
    private static final String TOTAL_RECLAIMED_MEMORY_IMAGE_FILES_LIFETIME = "TOTAL_RECLAIMED_MEMORY_IMAGE_FILES_LIFETIME";
    private static final String TOTAL_RECLAIMED_MEMORY_VIDEO_FILES_LIFETIME = "TOTAL_RECLAIMED_MEMORY_VIDEO_FILES_LIFETIME";
    private static final String TOTAL_RECLAIMED_MEMORY_AUDIO_FILES_LIFETIME = "TOTAL_RECLAIMED_MEMORY_AUDIO_FILES_LIFETIME";
    private static final String TOTAL_RECLAIMED_MEMORY_OTHER_FILES_LIFETIME = "TOTAL_RECLAIMED_MEMORY_OTHER_FILES_LIFETIME";
    private static final String[] TOTAL_RECLAIMED_MEMORY_LIFETIME = {TOTAL_RECLAIMED_MEMORY_IMAGE_FILES_LIFETIME, TOTAL_RECLAIMED_MEMORY_VIDEO_FILES_LIFETIME, TOTAL_RECLAIMED_MEMORY_AUDIO_FILES_LIFETIME, TOTAL_RECLAIMED_MEMORY_OTHER_FILES_LIFETIME};

    public StorageManager(Context context) {
        this.pref = context.getSharedPreferences(DuplicateConstants.SHARED_PREF_FILE_PATH, 0);
    }

    public void storeFilesToBeDeleted(List<String> list) {
        if (list == null || list.isEmpty()) {
            return;
        }
        SharedPreferences.Editor edit = this.pref.edit();
        edit.putStringSet(LIST_OF_FILES_TO_BE_DELETED, new HashSet(list));
        edit.apply();
    }

    public Set<String> getFilesToBeDeleted() {
        return this.pref.getStringSet(LIST_OF_FILES_TO_BE_DELETED, null);
    }

    public void registerScanTime() {
        SharedPreferences.Editor edit = this.pref.edit();
        edit.putLong(LAST_SCANNED_AT, Calendar.getInstance().getTimeInMillis());
        edit.apply();
    }

    public void registerDetailedViewSeenAt() {
        SharedPreferences.Editor edit = this.pref.edit();
        edit.putLong(DETAILED_VIEW_LAST_SEEN_AT, Calendar.getInstance().getTimeInMillis());
        edit.apply();
    }

    public long getDetailedViewLastSeenAt() {
        return this.pref.getLong(DETAILED_VIEW_LAST_SEEN_AT, -1L);
    }

    public void saveTotalDuplicateFound(long j) {
        SharedPreferences.Editor edit = this.pref.edit();
        edit.putLong(TOTAL_DUPLICATE_FOUND, j);
        edit.apply();
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public void addDeletedFilesToLifetimeStats(long j, long j2, String str) {
        char c;
        SharedPreferences.Editor edit = this.pref.edit();
        switch (str.hashCode()) {
            case 93166550:
                if (str.equals(DuplicateConstants.Type.AUDIO)) {
                    c = 2;
                    break;
                }
                c = '\uffff';
                break;
            case 100313435:
                if (str.equals(DuplicateConstants.Type.IMAGE)) {
                    c = 0;
                    break;
                }
                c = '\uffff';
                break;
            case 106069776:
                if (str.equals(DuplicateConstants.Type.OTHER)) {
                    c = 3;
                    break;
                }
                c = '\uffff';
                break;
            case 112202875:
                if (str.equals(DuplicateConstants.Type.VIDEO)) {
                    c = 1;
                    break;
                }
                c = '\uffff';
                break;
            default:
                c = '\uffff';
                break;
        }
        if (c == 0) {
            edit.putLong(TOTAL_DELETED_IMAGE_FILES_LIFETIME, this.pref.getLong(TOTAL_DELETED_IMAGE_FILES_LIFETIME, 0L) + j);
            edit.putLong(TOTAL_RECLAIMED_MEMORY_IMAGE_FILES_LIFETIME, this.pref.getLong(TOTAL_RECLAIMED_MEMORY_IMAGE_FILES_LIFETIME, 0L) + j2);
        } else if (c == 1) {
            edit.putLong(TOTAL_DELETED_VIDEO_FILES_LIFETIME, this.pref.getLong(TOTAL_DELETED_VIDEO_FILES_LIFETIME, 0L) + j);
            edit.putLong(TOTAL_RECLAIMED_MEMORY_VIDEO_FILES_LIFETIME, this.pref.getLong(TOTAL_RECLAIMED_MEMORY_VIDEO_FILES_LIFETIME, 0L) + j2);
        } else if (c == 2) {
            edit.putLong(TOTAL_DELETED_AUDIO_FILES_LIFETIME, this.pref.getLong(TOTAL_DELETED_AUDIO_FILES_LIFETIME, 0L) + j);
            edit.putLong(TOTAL_RECLAIMED_MEMORY_AUDIO_FILES_LIFETIME, this.pref.getLong(TOTAL_RECLAIMED_MEMORY_AUDIO_FILES_LIFETIME, 0L) + j2);
        } else if (c == 3) {
            edit.putLong(TOTAL_DELETED_OTHER_FILES_LIFETIME, this.pref.getLong(TOTAL_DELETED_OTHER_FILES_LIFETIME, 0L) + j);
            edit.putLong(TOTAL_RECLAIMED_MEMORY_OTHER_FILES_LIFETIME, this.pref.getLong(TOTAL_RECLAIMED_MEMORY_OTHER_FILES_LIFETIME, 0L) + j2);
        }
        edit.apply();
    }

    public long getTotalLifetimeFilesDeleted() {
        long j = 0;
        for (String str : TOTAL_DELETED_FILES_LIFETIME) {
            j += this.pref.getLong(str, 0L);
        }
        return j;
    }

    public long getTotalLifetimeMemoryReclaimed() {
        long j = 0;
        for (String str : TOTAL_RECLAIMED_MEMORY_LIFETIME) {
            j += this.pref.getLong(str, 0L);
        }
        return j;
    }

    public long getLastScannedAt() {
        return this.pref.getLong(LAST_SCANNED_AT, -1L);
    }

    public long getTotalDuplicateFound() {
        return this.pref.getLong(TOTAL_DUPLICATE_FOUND, -1L);
    }

    public void storeData(DupFileContainer dupFileContainer) {
        Log.d("fsfsf", "text doWork  starts ::DupFileContainer::   " + dupFileContainer.getImage().size());
        if (dupFileContainer == null) {
            return;
        }
        this.dupFileContainer = dupFileContainer;
    }

    private DupFileContainer getData() {
        if (dupFileContainer == null) {
            return null;
        }
        return dupFileContainer;
    }

    public List<List<DFile>> getData(String str) {
        Log.e("fssf","``1212221  string  "+str);
        DupFileContainer data = getData();
        if (data == null) {
            return new ArrayList();
        }
        char c = '\uffff';
        switch (str.hashCode()) {
            case 93166550:
                if (str.equals(DuplicateConstants.Type.AUDIO)) {
                    c = 2;
                    break;
                }
                break;
            case 100313435:
                if (str.equals(DuplicateConstants.Type.IMAGE)) {
                    c = 0;
                    break;
                }
                break;
            case 106069776:
                if (str.equals(DuplicateConstants.Type.OTHER)) {
                    c = 3;
                    break;
                }
                break;
            case 112202875:
                if (str.equals(DuplicateConstants.Type.VIDEO)) {
                    c = 1;
                    break;
                }
                break;
        }
        if (c == 0) {
            return data.getImage();
        }
        if (c == 1) {
            return data.getVideo();
        }
        if (c == 2) {
            return data.getAudio();
        }
        if (c == 3) {
            return data.getOther();
        }
        return null;
    }
}
