package com.gallery.photo.image.video.duplicat_function.flow;

@FunctionalInterface

public interface Consumer<T> {
    void accept(T t);
}
