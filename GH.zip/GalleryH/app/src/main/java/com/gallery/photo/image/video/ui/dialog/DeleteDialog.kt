package com.gallery.photo.image.video.ui.dialog

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.firebase.analytics.FirebaseAnalytics
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.DialogDeleteBinding
import com.gallery.photo.image.video.utils.Constant

class DeleteDialog(
    var mContext: Context,
    var msg: String,
    val positiveBtnClickListener: () -> Unit
) :
    BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogDeleteBinding
    lateinit var firebaseAnalytics: FirebaseAnalytics

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogDeleteBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {
        bindingDialog.txtMsg.text = msg
        bindingDialog.txtRestoredMsg.visibility = View.GONE

        firebaseAnalytics = FirebaseAnalytics.getInstance(requireActivity())
        val bundle2 = Bundle()
        bundle2.putString("Delete", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_dialog, bundle2)

        bindingDialog.btnCancel.setOnClickListener { dismiss() }
        bindingDialog.btnDelete.setOnClickListener {
            dismiss()
            positiveBtnClickListener()
        }
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}