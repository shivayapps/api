package com.gallery.photo.image.video.utils

import android.content.Context
import android.content.SharedPreferences
import android.util.Log

class Preferences(var context: Context) {

    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences(Constant.PREF_NAME, Context.MODE_PRIVATE)
    private val editor: SharedPreferences.Editor = sharedPreferences.edit()


    fun putStart(isStart: Boolean) {
        editor.putBoolean(Constant.PREF_KEY_START, isStart)
        editor.apply()
    }

    fun isStar(): Boolean {
        return sharedPreferences.getBoolean(Constant.PREF_KEY_START, false)
    }

    fun putFirstTimeInstall(isStart: Boolean) {
        editor.putBoolean(Constant.PREF_KEY_First_TIME_INSTALL, isStart)
        editor.apply()
    }

    fun isFirstTimeInstall(): Boolean {
        return sharedPreferences.getBoolean(Constant.PREF_KEY_First_TIME_INSTALL, true)
    }

    fun putLanguage(isLanguage: Boolean) {
        editor.putBoolean(Constant.PREF_KEY_SET_LANGUAGE, isLanguage)
        editor.apply()
    }

    fun isLanguage(): Boolean {
        return sharedPreferences.getBoolean(Constant.PREF_KEY_SET_LANGUAGE, false)
    }

    fun getAppOpenCounter(): Int {
        return sharedPreferences.getInt(Constant.PREF_KEY_APP_OPEN_COUNTER, 0)
    }

    fun putAppOpenCounter(counter: Int) {
        editor.putInt(Constant.PREF_KEY_APP_OPEN_COUNTER, counter)
        editor.apply()
    }

    fun putTheme(themeValue: Int) {
        editor.putInt(Constant.PREF_KEY_THEME, themeValue)
        editor.apply()
    }

    fun getThemeValue(): Int {
        return sharedPreferences.getInt(Constant.PREF_KEY_THEME, Constant.THEME_DARK)
    }

    fun setSelectLanguage(result: Int) {
        editor.putInt(Constant.PREF_KEY_LANGUAGE, result)
        editor.apply()
    }

    fun getSelectLanguage(): Int {
        return sharedPreferences.getInt(Constant.PREF_KEY_LANGUAGE, 0)
    }

    fun setSortType(result: Int) {
        editor.putInt(Constant.PREFS_SORT_TYPE, result)
        editor.apply()
    }

    fun getSortType(): Int {
        return sharedPreferences.getInt(Constant.PREFS_SORT_TYPE, Constant.SORT_LAST_MODIFIED)
    }

    fun setSortOrder(result: Int) {
        editor.putInt(Constant.PREFS_SORT_ORDER, result)
        editor.apply()
    }

    fun getSortOrder(): Int {
        return sharedPreferences.getInt(Constant.PREFS_SORT_ORDER, Constant.SORT_DESCENDING)
    }

    fun setGridCount(result: Int) {
        editor.putInt(Constant.PREFS_GRID_COUNT, result)
        editor.apply()
    }

    fun getGridCount(): Int {
        return sharedPreferences.getInt(Constant.PREFS_GRID_COUNT, 3)
    }

    fun putShowGrid(result: Boolean) {
        editor.putBoolean(Constant.PREFS_GRID_SHOW, result)
        editor.apply()
    }

    fun getShowGrid(): Boolean {
        return sharedPreferences.getBoolean(Constant.PREFS_GRID_SHOW, true)
    }

    fun putShowPinLock(result: Boolean) {
        editor.putBoolean(Constant.PREFS_LOCK_STYLE, result)
        editor.apply()
    }

    fun getShowPINLock(): Boolean {
        return sharedPreferences.getBoolean(Constant.PREFS_LOCK_STYLE, true)
    }

    fun putSetPass(result: Boolean) {
        editor.putBoolean(Constant.PREF_PASSCODE_SET, result)
        editor.apply()
    }

    fun getSetPass(): Boolean {
        return sharedPreferences.getBoolean(Constant.PREF_PASSCODE_SET, false)
    }

    fun putPass(result: String) {
        editor.putString(Constant.PREF_PASSCODE, result)
        editor.apply()
    }

    fun getPass(): String? {
        return sharedPreferences.getString(Constant.PREF_PASSCODE, "")
    }

    fun putSetPattern(result: Boolean) {
        editor.putBoolean(Constant.PREF_PATTERN_SET, result)
        editor.apply()
    }

    fun getSetPattern(): Boolean {
        return sharedPreferences.getBoolean(Constant.PREF_PATTERN_SET, false)
    }

    fun putPattern(result: String) {
        editor.putString(Constant.PREF_PATTERN, result)
        editor.apply()
    }

    fun getPattern(): String? {
        return sharedPreferences.getString(Constant.PREF_PATTERN, "")
    }

    fun putSetQuestion(result: Boolean) {
        editor.putBoolean(Constant.PREF_SECURITY_SET, result)
        editor.apply()
    }

    fun getSetQuestion(): Boolean {
        return sharedPreferences.getBoolean(Constant.PREF_SECURITY_SET, false)
    }

    fun putSecurityQuestion(result: Int) {
        editor.putInt(Constant.PREF_SECURITY_QUESTION, result)
        editor.apply()
    }

    fun getSecurityQuestion(): Int {
        return sharedPreferences.getInt(Constant.PREF_SECURITY_QUESTION, 0)
    }


    fun putAnswerQuestion(result: String) {
        editor.putString(Constant.PREF_SECURITY_ANS, result)
        editor.apply()
    }

    fun getAnswerQuestion(): String? {
        return sharedPreferences.getString(Constant.PREF_SECURITY_ANS, "")
    }

    fun getFavoriteList(): ArrayList<String> {
        val list: ArrayList<String> = ArrayList()
//        try {
//            val response: String =
//                sharedPreferences.getString(Constant.SHARED_PREFS_FAVORITE_LIST, "")!!
//            if (response.isNotEmpty()) {
//                val gson = Gson()
//                val typeToken: TypeToken<List<String>> = object : TypeToken<List<String>>() {}
//
////                val type = object : TypeToken<List<String>>() {}.type
//                val type = typeToken.type
//                list = gson.fromJson(response, type)
//            }
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
        val response: String =
            sharedPreferences.getString(Constant.SHARED_PREFS_FAVORITE_LIST, "") ?: ""
        if (!response.isNullOrEmpty()) {
            val delimiter = "(,/^)"
            val stringArray = response.split(delimiter)
            if (!stringArray.isNullOrEmpty())
                list.addAll(stringArray)
        }
        return list
    }

    fun setFavoriteList(list: ArrayList<String>) {
//        val editor: SharedPreferences.Editor = sharedPreferences.edit()
//        val gson = Gson()
//        val json = gson.toJson(list)
//        editor.putString(Constant.SHARED_PREFS_FAVORITE_LIST, json)
//        editor.apply()
        val delimiter = "(,/^)"
        val resultString = if (list.isEmpty())
            "" else
            list.joinToString(delimiter)
        Log.e("TAGPREF", "SETResultString $resultString")
        val editor: SharedPreferences.Editor = sharedPreferences.edit()
        editor.putString(Constant.SHARED_PREFS_FAVORITE_LIST, resultString)
        editor.apply()
    }

}