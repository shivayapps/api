package com.gallery.photo.image.video.duplicat_function.model_class;

import java.util.Date;


public class Image implements Img, Comparable<Image> {
    private String path;
    private Date photoTakenAt;

    public Image(String str, Date date) {
        this.path = str;
        this.photoTakenAt = date;
    }

    @Override 
    public String getPath() {
        return this.path;
    }

    public void setPath(String str) {
        this.path = str;
    }

    @Override 
    public Date getPhotoTakenAt() {
        return this.photoTakenAt;
    }

    public void setPhotoTakenAt(Date date) {
        this.photoTakenAt = date;
    }

    @Override 
    public int compareTo(Image image) {
        return this.photoTakenAt.compareTo(image.photoTakenAt);
    }

    public String toString() {
        return "Image{path='" + this.path + "', photoTakenAt=" + this.photoTakenAt + '}';
    }
}
