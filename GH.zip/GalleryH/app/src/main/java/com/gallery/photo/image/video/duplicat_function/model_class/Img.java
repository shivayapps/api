package com.gallery.photo.image.video.duplicat_function.model_class;

import java.util.Date;


public interface Img {
    String getPath();

    Date getPhotoTakenAt();
}
