package com.gallery.photo.image.video.duplicat_function.model_class;


public interface Item {
}
