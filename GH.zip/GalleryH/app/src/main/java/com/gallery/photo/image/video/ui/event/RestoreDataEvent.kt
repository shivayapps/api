package com.gallery.photo.image.video.ui.event

import com.gallery.photo.image.video.ui.model.RestoreData
import java.util.ArrayList

data class RestoreDataEvent(var restoreList: ArrayList<RestoreData>)
