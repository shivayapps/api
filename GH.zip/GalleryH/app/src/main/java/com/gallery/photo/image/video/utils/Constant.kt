package com.gallery.photo.image.video.utils

import android.os.Environment
import com.gallery.photo.image.video.ui.model.AlbumData
import com.gallery.photo.image.video.ui.model.PictureData


object Constant {

    val PREF_NAME: String = "Gallery"
    val PREF_KEY_START: String = "key_star"
    val PREF_KEY_SET_LANGUAGE: String = "isSetLanguage"
    val PREF_KEY_LANGUAGE: String = "language"
    val PREF_KEY_THEME: String = "key_is_theme"
    val PREFS_SORT_TYPE: String = "sort_type"
    val PREFS_SORT_ORDER: String = "sort_order"
    val PREFS_GRID_COUNT: String = "grid_count"
    val PREFS_GRID_SHOW: String = "is_grid"
    val PREFS_LOCK_STYLE: String = "lock_style"
    val SHARED_PREFS_FAVORITE_LIST: String = "Favorite_list"
    val PREF_PASSCODE_SET: String = "passcode_set"
    val PREF_PASSCODE: String = "passcode"
    val PREF_PATTERN_SET: String = "Pattern_set"
    val PREF_PATTERN: String = "Pattern"
    val PREF_SECURITY_SET: String = "security_set"
    val PREF_SECURITY_QUESTION: String = "security_question"
    val PREF_SECURITY_ANS: String = "security_ans"
    val PREF_KEY_First_TIME_INSTALL: String = "key_firstTimeInstall"
    val PREF_KEY_APP_OPEN_COUNTER: String = "key_app_open_counter"

    val EXTRA_IS_OPEN_FROM_SPLASH: String = "extra_isIntroduction"

    val URL_Insta: String = "https://www.instagram.com/accounts/login/"
    val URL_FB: String = "https://www.facebook.com/"

    val SORT_NAME: Int = 1
    val SORT_PATH: Int = 2
    val SORT_SIZE: Int = 3
    val SORT_LAST_MODIFIED: Int = 4
    val SORT_DATE_TAKEN: Int = 5

    val SORT_ASCENDING: Int = 1
    val SORT_DESCENDING: Int = 2

    val THEME_LIGHT: Int = 1
    val THEME_DARK: Int = 2

    var displayImageList: ArrayList<PictureData> = ArrayList()
    var selectedImageList: ArrayList<PictureData> = ArrayList()
    var albumData: AlbumData = AlbumData()
    var albumList: ArrayList<AlbumData> = ArrayList()
    var videoData: PictureData = PictureData("","","",0L,0L,0L)

    val EXTRA_DISPLAY_POS: String = "displayPos"
    val EXTRA_IS_OPEN_CAMERA_PERMISSION: String = "IsOpenCameraPer"
    val EXTRA_OPEN_TYPE_QUE: String = "OPEN_TYPE_QUE"
    val EXTRA_IS_OPEN_PRIVATE: String = "isOpenPrivate"
    val EXTRA_IS_OPEN_RECENTLY_DELETE: String = "isOpenRecentlyDelete"
    val EXTRA_RESET_PASS: String = "resetPass"
    val EXTRA_CHANGE_PASS: String = "ChangePass"
    val EXTRA_CHANGE_LOCK_STYLE: String = "ChangeLockStyle"
    val EXTRA_LOCK_STYLE: String = "LockStyle"
    val EXTRA_WALL_PAPER: String = "wall_paper"
    val EXTRA_IMAGE_PATH: String = "IMAGE_PATH"
    val EXTRA_ALBUM_PATH: String = "album_path"
    val EXTRA_EDIT_IMAGE_PATH: String = "editImagePath"
    val EXTRA_EDIT_IMAGE_NAME: String = "editImageName"
    val EXTRA_EDIT_SAVE_IMAGE: String = "imagePath"
    val EXTRA_OPEN_URL: String = "openUrl"
    val EXTRA_IS_OPEN_HISTORY: String = "IS_OPEN_HISTORY"
    val EXTRA_BROWSER_URL: String = "extra_Browser_url"
    val EXTRA_SELECT_TYPE: String = "select_type"


    const val HIDE_FOLDER_NAME = ".Private"
    const val RECENT_DELETE_FOLDER_NAME = ".RecentlyDeleted"
    val HIDE_PATH = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).path + "/Gallery/" + HIDE_FOLDER_NAME
    val EDIT_PATH = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).path + "/Gallery/Edit"
    val DELETE_PATH = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).path + "/Gallery/" + RECENT_DELETE_FOLDER_NAME
    val SCREEN_SHOT_PATH = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).path + "/Gallery"

    var isChangeLanguage: Boolean = false
    var isReCreateHomeSS: Boolean = false

    const val ASPECT_RATIO_FREE = 0
    const val ASPECT_RATIO_CENTER = 6
    const val ASPECT_RATIO_1_1 = 1
    const val ASPECT_RATIO_4_3 = 2
    const val ASPECT_RATIO_9_16= 3
    const val ASPECT_RATIO_2_3= 4
    const val ASPECT_RATIO_3_2= 5

    const val SELECT_TYPE_CRATE_ALBUM= 1
    const val SELECT_TYPE_HIDE= 2

    const val isInterstitialEveryMinute: String = "isInterstitialEveryMinute"
    const val InterMinutebeforeCount: String = "InterMinutebeforeCount"

    const val event_activity: String = "activity"
    const val event_fragment: String = "fragment"
    const val event_dialog: String = "dialog"
    const val event_open: String = "open"

}