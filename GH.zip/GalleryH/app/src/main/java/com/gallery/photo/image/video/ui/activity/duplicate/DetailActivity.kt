package com.gallery.photo.image.video.ui.activity.duplicate

import android.annotation.SuppressLint
import android.app.Dialog
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.format.Formatter
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.Window
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.view.MotionEventCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.SCROLL_STATE_IDLE
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.database.AppDatabase
import com.gallery.photo.image.video.databinding.ActivityDetailBinding
import com.gallery.photo.image.video.databinding.DialogDeleteProgressBinding
import com.gallery.photo.image.video.duplicat_function.flow.Flow
import com.gallery.photo.image.video.duplicat_function.model_class.DFile
import com.gallery.photo.image.video.duplicat_function.model_class.DataItem
import com.gallery.photo.image.video.duplicat_function.model_class.HeaderItem
import com.gallery.photo.image.video.duplicat_function.model_class.Item
import com.gallery.photo.image.video.duplicat_function.utils_duplicat.DuplicateConstants
import com.gallery.photo.image.video.duplicat_function.utils_duplicat.StorageManager
import com.gallery.photo.image.video.ui.activity.BaseActivity
import com.gallery.photo.image.video.ui.adapter.DuplicateImagesAdapter
import com.gallery.photo.image.video.ui.dialog.DeleteDialog
import com.gallery.photo.image.video.ui.dialog.Details2Dialog
import com.gallery.photo.image.video.ui.dialog.DetailsMultipleDialog
import com.gallery.photo.image.video.ui.event.DeleteEvent
import com.gallery.photo.image.video.ui.model.AlbumData
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.Preferences
import com.gallery.photo.image.video.utils.Utils
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import org.greenrobot.eventbus.EventBus
import java.io.File
import java.text.SimpleDateFormat
import java.util.concurrent.Executors

class DetailActivity : BaseActivity() {
    lateinit var binding: ActivityDetailBinding
    private var imageListData: List<List<com.gallery.photo.image.video.duplicat_function.model_class.DFile>> =
        ArrayList()
    var dateSelection = 0
    var sizeSelection = 0
    var imageAdapter: DuplicateImagesAdapter? = null
    var oneMonth: Long = 0
    var sixMonth: Long = 0
    var twoFourMonth: Long = 0
    var selectedItem = 0
    var selectFileSize = 0L
    var isSelectAll = false
    lateinit var preferences: Preferences
    private var items: ArrayList<com.gallery.photo.image.video.duplicat_function.model_class.Item> =
        java.util.ArrayList()
    val formatDetails = SimpleDateFormat("dd/mm/yyyy, hh:mm aa")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        inits()
        clicks()

    }

    @SuppressLint("SuspiciousIndentation")
    private fun clicks() {
        isBack = false
        binding.toolbar.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.btnDetails.setOnClickListener {
            if (selectedItem == 1) {
                showDetailsDialog()
            } else {
                showMultipleDetailsDialog()
            }
        }
        binding.btnDelete.setOnClickListener {
            showDeleteDialog()
        }

        binding.toolbar.icSelect.setOnClickListener {
            isSelectAll = !isSelectAll
            setSelectClick(isSelectAll)
            setSelectAllColor()
        }
    }

    private fun setEmptyData() {
        if (items.isEmpty()) {
            binding.rvList.visibility = View.GONE
            binding.toolbar.icSelect.visibility = View.GONE
            binding.layoutNoData.visibility = View.VISIBLE
        } else {
            binding.layoutNoData.visibility = View.GONE
            binding.toolbar.icSelect.visibility = View.VISIBLE
        }
    }

    fun showDeleteDialog() {
        if (selectedItem == 0) {
            Toast.makeText(
                this,
                this.getString(R.string.PleaseSelectImage),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            val deleteDialog = DeleteDialog(
                this,
                getString(R.string.selected_delete_msg),
                positiveBtnClickListener = {
                    deletePhoto()
                })
            deleteDialog.show(supportFragmentManager, deleteDialog.tag)
        }
    }

    private fun inits() {
        val bundle2 = Bundle()
        bundle2.putString("DuplicateImageListShow", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_activity, bundle2)

        preferences = Preferences(this)
        binding.loutSelectOption.visibility = View.GONE
        binding.rvList.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                super.onScrollStateChanged(recyclerView, newState)
                when (newState) {
                    SCROLL_STATE_IDLE -> isBack = false
                    RecyclerView.SCROLL_STATE_DRAGGING -> isBack = true
                }
            }

            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                Log.d("dfdfds", "scrolled")
//                isBack = true

            }
        })
        isBack = false
        imageListData =
            com.gallery.photo.image.video.duplicat_function.utils_duplicat.StorageManager(
                this
            )
                .getData(com.gallery.photo.image.video.duplicat_function.utils_duplicat.DuplicateConstants.Type.IMAGE)
        Log.d("fdffs", "sizessd " + imageListData.size)
        binding.toolbar.txtTitle.text = getString(R.string.duplicate_photos)

        setAdapter()
    }

    private fun setAdapterData() {
        if (imageAdapter != null) {
            imageAdapter?.notifyDataSetChanged()
        } else {
            imageAdapter = DuplicateImagesAdapter(
                this,
                items,
                "image",
                headerSelectListener = {
                    if (items[it] is com.gallery.photo.image.video.duplicat_function.model_class.HeaderItem) {
                        val albumData =
                            items[it] as com.gallery.photo.image.video.duplicat_function.model_class.HeaderItem
                        val isSelectAll = !albumData.isSelected
                        albumData.isSelected = isSelectAll
                        var pos = it + 1
                        while (pos < items.size) {
                            if (items[pos] is DataItem) {
                                val model = items[pos] as DataItem
                                model.isSelected = isSelectAll
                                pos++
                            } else if (items[pos] is com.gallery.photo.image.video.duplicat_function.model_class.HeaderItem) {
                                break
                            }
                        }
                        imageAdapter?.notifyDataSetChanged()
                        setSelectedFile()
                    }
                }, clickListener = {
                    if (!isBack) {
                        if (items[it] is DataItem) {
                            val dataItem = items[it] as DataItem
                            dataItem.isSelected = !dataItem.isSelected
                            imageAdapter?.notifyItemChanged(it)
                            setSelectedFile()
                        }
                    }
                }
            )
            val gridCount = preferences.getGridCount()
            val gridLayoutManager =
                GridLayoutManager(this, gridCount, RecyclerView.VERTICAL, false)
            binding.rvList.layoutManager = gridLayoutManager
            gridLayoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int): Int {
                    return if (position >= 0 && position < items.size) {
                        if (imageAdapter!!.getItemViewType(position) == 0) {
                            gridCount
                        } else 1
                    } else {
                        1
                    }
                }
            }
            binding.rvList.adapter = imageAdapter
        }
    }

    private fun setSelectedFile() {
        selectedItem = 0
        selectFileSize = 0L

        var allItemCount = 0

        var currentHeaderPos = -1
        var photosCount = 0
        var photosSelectCount = 0

        for (i in items.indices) {
            if (items[i] is com.gallery.photo.image.video.duplicat_function.model_class.HeaderItem) {
                if (i != currentHeaderPos) {
                    if (currentHeaderPos != -1) {
                        val model =
                            items[currentHeaderPos] as com.gallery.photo.image.video.duplicat_function.model_class.HeaderItem
                        model.isSelected = photosCount == photosSelectCount
                        photosCount = 0
                        photosSelectCount = 0
                        imageAdapter?.notifyItemChanged(currentHeaderPos)
                    }
                    currentHeaderPos = i
                }
            } else if (items[i] is DataItem) {
                val model = items[i] as DataItem
                allItemCount++
                photosCount++
                if (model.isSelected) {
                    selectFileSize += model.fileSizeLong
                    selectedItem++
                    photosSelectCount++
                }
            }
            if (i == items.size - 1) {
                if (currentHeaderPos != -1) {
                    val model =
                        items[currentHeaderPos] as com.gallery.photo.image.video.duplicat_function.model_class.HeaderItem
                    model.isSelected = photosCount == photosSelectCount
                    photosCount = 0
                    photosSelectCount = 0
                    imageAdapter?.notifyItemChanged(currentHeaderPos)
                }
            }
        }

        isSelectAll = allItemCount == selectedItem
        setSelectAllColor()
        binding.loutSelectOption.visibility = if (selectedItem == 0) View.GONE else View.VISIBLE
        Log.e(
            "SelectFileSize",
            "size ${Formatter.formatShortFileSize(this@DetailActivity, selectFileSize)}"
        )
    }

    private fun showMultipleDetailsDialog() {
        val detailsDialog = DetailsMultipleDialog(selectedItem, selectFileSize)
        detailsDialog.show(supportFragmentManager, detailsDialog.tag)
    }

    private fun showDetailsDialog() {
        var dataItem: DataItem? = null
        val list = items.filterIsInstance<DataItem>()
        if (list.isNotEmpty()) {
            val dataList = list.filter { it.isSelected }
            if (dataList.isNotEmpty())
                dataItem = dataList[0]
        }

        if (dataItem != null) {
            val detailsDialog = Details2Dialog(dataItem)
            detailsDialog.show(supportFragmentManager, detailsDialog.tag)
        }
    }

    fun setSelectClick(isSelect: Boolean) {
        selectedItem = 0
        selectFileSize = 0L
        var selected = 0
        for (i in items.indices) {
            if (items[i] != null)
                if (items[i] is com.gallery.photo.image.video.duplicat_function.model_class.HeaderItem) {
                    val model =
                        items[i] as com.gallery.photo.image.video.duplicat_function.model_class.HeaderItem
                    model.isSelected = isSelect
                } else if (items[i] is DataItem) {
                    val model = items[i] as DataItem
                    model.isSelected = isSelect
                    if (isSelect) {
                        selected++
                        selectFileSize += model.fileSizeLong
                    }
                }
        }
        imageAdapter?.notifyDataSetChanged()
        selectedItem = selected
        isSelectAll = isSelect
        binding.loutSelectOption.visibility = if (selectedItem == 0) View.GONE else View.VISIBLE
        Log.e(
            "SelectFileSize",
            "size ${Formatter.formatShortFileSize(this@DetailActivity, selectFileSize)}"
        )
    }

    private fun setSelectAllColor() {
        val color =
            ContextCompat.getColor(this, if (isSelectAll) R.color.black else R.color.un_check_color)
        binding.toolbar.icSelect.setColorFilter(color, PorterDuff.Mode.SRC_IN)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        return when (MotionEventCompat.getActionMasked(event)) {
            MotionEvent.ACTION_DOWN -> {
                true
            }

            else -> super.onTouchEvent(event)
        }
    }


    override fun onResume() {
        super.onResume()
    }

    companion object {
        @JvmField
        var isBack = false
    }

    override fun onBackPressed() {
        if (isBack) {

        } else {
            super.onBackPressed()
        }

    }

    private fun arrangeGroupsForRender(
        list: List<List<com.gallery.photo.image.video.duplicat_function.model_class.DFile>>,
        doAutoSelection: Boolean,
        sizeSelection: Int,
        dateSelection: Int,
    ): List<com.gallery.photo.image.video.duplicat_function.model_class.Item> {
        items.clear()
        Log.d("fffdffgg", " datesizes $dateSelection ,   size  $sizeSelection, $doAutoSelection")
        var groupNo = 0
        selectedItem = 0
        selectFileSize = 0L

//        val seconLists = java.util.ArrayList<MediaModel>()
        for (list2 in list) {
            val list3: List<*> =
                com.gallery.photo.image.video.duplicat_function.flow.Flow.of(list2)
                    .filter { dFile: com.gallery.photo.image.video.duplicat_function.model_class.DFile ->
                        var exists: Boolean
                        exists = File(dFile.path).exists()
                        if (exists) {
                            when (sizeSelection) {
                                0 -> exists = setDateWiseData(dFile.path, dateSelection)
                                1 -> exists = if (File(dFile.path).length() < 1048580) {
                                    setDateWiseData(dFile.path, dateSelection)
                                } else {
                                    false
                                }

                                2 -> exists = if (File(dFile.path)
                                        .length() in 1048581..5242899
                                ) {
                                    setDateWiseData(dFile.path, dateSelection)
                                } else {
                                    false
                                }

                                3 -> exists = if (File(dFile.path).length() > 5242900) {
                                    setDateWiseData(dFile.path, dateSelection)
                                } else {
                                    false
                                }
                            }
                        }
                        exists
                    }.toList()
            if (list3.size > 1) {
                val list4: MutableList<com.gallery.photo.image.video.duplicat_function.model_class.Item> =
                    items
                val sb = StringBuilder()
                sb.append(getString(R.string.group) + " ")
                val i2 = groupNo + 1
                sb.append(i2)
                list4.add(
                    com.gallery.photo.image.video.duplicat_function.model_class.HeaderItem(
                        sb.toString()
                    )
                )
                var position = 0
                while (position < list3.size) {
                    val dataItem = DataItem()
                    val dFile =
                        list3[position] as com.gallery.photo.image.video.duplicat_function.model_class.DFile
                    Log.e("DetailsData", "$sb path=> ${dFile.path}")
                    dataItem.filePath = dFile.path
                    dataItem.fileName = dFile.name
                    dataItem.fileDate = dFile.lastUpdatedAt
                    dataItem.fileSizeLong = dFile.size
                    dataItem.groupId = groupNo
                    dataItem.isSelected = position != 0
                    if (position != 0)
                        selectedItem++
                    selectFileSize += dataItem.fileSizeLong
                    dataItem.fileSizeLong = File(dataItem.filePath).length()

                    items.add(dataItem)
                    position++
                }
                groupNo = i2
            }
//            seconLists.clear()
        }
        return items
    }

    private fun setDateWiseData(path: String?, dateSelection: Int): Boolean {
        var exists = false
        when (dateSelection) {
            0 -> exists = true
            1 -> exists = File(path).lastModified() > oneMonth

            2 -> exists = File(path).lastModified() > sixMonth

            3 -> exists = File(path).lastModified() > twoFourMonth

            4 -> exists =
                File(path).lastModified() >= com.gallery.photo.image.video.duplicat_function.utils_duplicat.DuplicateConstants.date_long
        }
        return exists
    }

    private fun setAdapter() {
        val servicePhotoFolder = Executors.newSingleThreadExecutor()
        servicePhotoFolder.execute {
            runOnUiThread {
                isBack = true
            }
            arrangeGroupsForRender(
                imageListData,
                com.gallery.photo.image.video.duplicat_function.utils_duplicat.DuplicateConstants.isAllSelect,
                sizeSelection,
                dateSelection
            )
            runOnUiThread {
                isBack = false
                binding.searchingLottie.visibility = View.GONE
                if (imageListData.isNotEmpty()) {
                }
                setEmptyData()
                isSelectAll = selectedItem == imageListData.size
                setSelectAllColor()
                binding.loutSelectOption.visibility =
                    if (selectedItem == 0) View.GONE else View.VISIBLE
                Log.e(
                    "SelectFileSize",
                    "size ${Formatter.formatShortFileSize(this@DetailActivity, selectFileSize)}"
                )
                setAdapterData()

                Log.e("DataFetch", "imageSize==>> " + items.size)
                Log.e("DataFetch", "imageData==>> " + items.toString())
                isBack = false
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    @SuppressLint("CheckResult")
    private fun deletePhoto() {
        val deleteList = ArrayList<String>()
        val bindingDialog = DialogDeleteProgressBinding.inflate(layoutInflater)
        val dialog = Dialog(this, R.style.Dialog)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(bindingDialog.root)
        dialog.setCanceledOnTouchOutside(false)
        dialog.window?.setGravity(Gravity.BOTTOM)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        bindingDialog.progressBar.max = selectedItem

        runOnUiThread {
            bindingDialog.txtProgressCount.text = deleteList.size.toString() + "/" + selectedItem
            bindingDialog.progressBar.progress = deleteList.size
        }
        dialog.show()

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(this)
            for (i in items.indices) {
                if (items[i] != null) if (items[i] is DataItem) {
                    val model = items[i] as DataItem
                    if (model.isSelected) {
                        runOnUiThread {
                            bindingDialog.txtTitle.text = model.fileName
                        }

                        val isDelete = Utils().deleteFile(this, model.filePath ?: "", dataBase)
                        if (isDelete) {
                            deleteList.add(model.filePath ?: "")
                            runOnUiThread {
                                bindingDialog.txtProgressCount.text =
                                    deleteList.size.toString() + "/" + selectedItem
                                bindingDialog.progressBar.progress = deleteList.size
                            }
                        }
                    }
                } /*else if (items[i] is AlbumData) {
                    val model = items[i] as AlbumData
                    model.isSelected = false
                    model.isCheckboxVisible = false
                }*/
            }

            var i = 0
            while (i < items.size) {
                if (items[i] != null)
                /*  if (items[i] is HeaderItem) {
                      val model = items[i] as HeaderItem
                      model.isSelected = false
                      model.isCheckboxVisible = false

                  } else */ if (items[i] is DataItem) {
                    val model = items[i] as DataItem
                    if (model.isSelected) {
                        var isPre = false
                        var isNext = false
                        if (i != 0) {
                            isPre =
                                items[i - 1] is com.gallery.photo.image.video.duplicat_function.model_class.HeaderItem
                        }
                        if (i < items.size - 2) {
                            isNext =
                                items[i + 1] is com.gallery.photo.image.video.duplicat_function.model_class.HeaderItem
                        }
                        if (isPre && isNext) {
                            items.removeAt(i)
                            items.removeAt(i - 1)
                        } else if (i == items.size - 1) {
                            items.removeAt(i)
                            if (isPre) {
                                items.removeAt(i - 1)
                            }
                        } else {
                            items.removeAt(i)
                        }
                        if (i != 0) {
                            i--
                        }
                    }
                }
                i++
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    if (dialog.isShowing)
                        dialog.dismiss()
                    setAfterDeleteUpdate(deleteList)
                }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    if (dialog.isShowing)
                        dialog.dismiss()
                    setAfterDeleteUpdate(deleteList)
                }
            }
    }

    private fun setAfterDeleteUpdate(deleteList: java.util.ArrayList<String>) {
        EventBus.getDefault().post(DeleteEvent(1, deleteList))
        imageAdapter?.notifyDataSetChanged()
        Toast.makeText(
            this,
            getString(R.string.Delete_successfully),
            Toast.LENGTH_SHORT
        ).show()
        setEmptyData()
        selectedItem = 0
        selectFileSize = 0L
        binding.loutSelectOption.visibility = if (selectedItem == 0) View.GONE else View.VISIBLE
    }


}