package com.gallery.photo.image.video.duplicat_function.model_class;

import java.util.ArrayList;
import java.util.List;


public class DupFileContainer {
    private List<List<DFile>> image = new ArrayList();
    private List<List<DFile>> video = new ArrayList();
    private List<List<DFile>> audio = new ArrayList();
    private List<List<DFile>> other = new ArrayList();

    public List<List<DFile>> getImage() {
        return this.image;
    }

    public void setImage(List<List<DFile>> list) {
        this.image = list;
    }

    public List<List<DFile>> getVideo() {
        return this.video;
    }

    public void setVideo(List<List<DFile>> list) {
        this.video = list;
    }

    public List<List<DFile>> getAudio() {
        return this.audio;
    }

    public void setAudio(List<List<DFile>> list) {
        this.audio = list;
    }

    public List<List<DFile>> getOther() {
        return this.other;
    }

    public void setOther(List<List<DFile>> list) {
        this.other = list;
    }
}
