package com.gallery.photo.image.video.duplicat_function.flow;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;


public class Flow<T> {
    private final Iterator<? extends T> iterator;

    private Flow(Iterator<? extends T> it) {
        this.iterator = it;
    }

    public static <T> Flow<T> empty() {
        return of(Collections.emptyList());
    }

    public static <T> Flow<T> of(Iterator<? extends T> it) {
        if (it == null) {
            return empty();
        }
        return new Flow<>(it);
    }

    public static <T> Flow<T> of(Iterable<? extends T> iterable) {
        if (iterable == null) {
            return empty();
        }
        return new Flow<>(iterable.iterator());
    }

    public static <T> Flow<T> of(T... tArr) {
        tArr.getClass();
        if (tArr.length == 0) {
            return empty();
        }
        return new Flow<>(new ArrayIterator(tArr));
    }

    public Flow<T> filter(Predicate<? super T> predicate) {
        return new Flow<>(new FilterIterator(this.iterator, predicate));
    }

    public void forEach(Consumer<? super T> consumer) {
        while (this.iterator.hasNext()) {
            consumer.accept((T) this.iterator.next());
        }
    }

    public <R> R reduce(R r, BiFunction<? super R, ? super T, ? extends R> biFunction) {
        while (this.iterator.hasNext()) {
            r = biFunction.apply(r, (T) this.iterator.next());
        }
        return r;
    }

    public T reduce(BiFunction<T, T, T> biFunction) {
        boolean z = false;
        T t = null;
        while (this.iterator.hasNext()) {
            T next = this.iterator.next();
            if (!z) {
                z = true;
                t = next;
            } else {
                t = biFunction.apply(t, next);
            }
        }
        return t;
    }

    public boolean anyMatch(Predicate<? super T> predicate) {
        return firstMatch(predicate) != null;
    }

    public List<T> toList() {
        ArrayList arrayList = new ArrayList();
        while (this.iterator.hasNext()) {
            arrayList.add(this.iterator.next());
        }
        return arrayList;
    }

    /* JADX WARN: Type inference failed for: r0v3, types: [T, java.lang.Object] */
    public T firstMatch(Predicate<? super T> predicate) {
        while (this.iterator.hasNext()) {
            T next = this.iterator.next();
            if (predicate.test(next)) {
                return next;
            }
        }
        return null;
    }

    public <R> Flow<R> map(Function<? super T, ? extends R> function) {
        ArrayList arrayList = new ArrayList();
        while (this.iterator.hasNext()) {
            arrayList.add(function.apply((T) this.iterator.next()));
        }
        return of(arrayList);
    }
}
