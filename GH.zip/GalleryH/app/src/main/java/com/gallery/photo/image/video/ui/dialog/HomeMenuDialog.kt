package com.gallery.photo.image.video.ui.dialog

import android.app.Dialog
import android.graphics.PorterDuff
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.firebase.analytics.FirebaseAnalytics
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.DialogBottomMenuBinding
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.Preferences

class HomeMenuDialog(var isShowAlbumTab: Boolean,  val clickListener: (type: Int) -> Unit) : BottomSheetDialogFragment() {

    lateinit var binding: DialogBottomMenuBinding
    lateinit var firebaseAnalytics: FirebaseAnalytics
    lateinit var preferences: Preferences
    var isShowGrid = false
    var gridCount = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = DialogBottomMenuBinding.inflate(layoutInflater, container, false)
        intView()
        return binding.root
    }

    private fun intView() {
        preferences = Preferences(requireActivity())
        isShowGrid = preferences.getShowGrid()
        gridCount = preferences.getGridCount()
        selectedGrid = gridCount

        binding.btnCreateAlbum.visibility =  if (isShowAlbumTab) View.VISIBLE else View.GONE
        binding.btnChangeViewType.visibility =  if (isShowAlbumTab) View.VISIBLE else View.GONE

        firebaseAnalytics = FirebaseAnalytics.getInstance(requireActivity())
        val bundle2 = Bundle()
        bundle2.putString("HomeMenu", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_dialog, bundle2)

        intListener()
        setView()
        setColumnView()

    }

    var selectedGrid = -1
    private fun intListener() {
        binding.btnSortBy.setOnClickListener {
            dismiss()
            clickListener(1)
        }
//        binding.btnChangeViewType.setOnClickListener {
//            dismiss()
//            clickListener(2)
//        }
//        binding.btnList.setOnClickListener {
//
//            dismiss()
//            clickListener(21)
//        }
//        binding.btnGrid.setOnClickListener {
//            dismiss()
//            clickListener(22)
//        }

        binding.btnGrid.setOnClickListener {
            if (!isShowGrid) {
                isShowGrid = true
                setView()
                preferences.putShowGrid(isShowGrid)
//                updateListener()
                clickListener(21)
                dismiss()
            } else dismiss()
        }
        binding.btnList.setOnClickListener {
            if (isShowGrid) {
                isShowGrid = false
                setView()
                preferences.putShowGrid(isShowGrid)
//                updateListener()
                clickListener(21)
                dismiss()
            } else dismiss()
        }

        binding.btn2x2.setOnClickListener {
            selectedGrid=2
            if (gridCount != selectedGrid) {
                preferences.setGridCount(selectedGrid)
                setColumnView()
//                updateListener()
            }
            dismiss()
            clickListener(22)
        }
        binding.btn3x3.setOnClickListener {
            selectedGrid=3
            if (gridCount != selectedGrid) {
                preferences.setGridCount(selectedGrid)
                setColumnView()
//                updateListener()
            }
            dismiss()
            clickListener(22)
        }
        binding.btn4x4.setOnClickListener {
            selectedGrid=4
            if (gridCount != selectedGrid) {
                preferences.setGridCount(selectedGrid)
                setColumnView()
//                updateListener()
            }
            dismiss()
            clickListener(22)
        }
        binding.btn5x5.setOnClickListener {
            selectedGrid=5
            if (gridCount != selectedGrid) {
                preferences.setGridCount(selectedGrid)
                setColumnView()
//                updateListener()
            }
            dismiss()
            clickListener(22)
        }
        binding.btnCreateAlbum.setOnClickListener {
            dismiss()
            clickListener(3)
        }
//        binding.btnDisplayedColumns.setOnClickListener {
//            dismiss()
//            clickListener(4)
//        }
        binding.btnCollage.setOnClickListener {
            dismiss()
            clickListener(5)
        }
    }

    private fun setView() {
        if (isShowGrid) {
            setSelectView(binding.btnGrid, binding.ivGrid, binding.tvGrid)
            setUnSelectView(binding.btnList, binding.ivList, binding.tvList)
        } else {
            setSelectView(binding.btnList, binding.ivList, binding.tvList)
            setUnSelectView(binding.btnGrid, binding.ivGrid, binding.tvGrid)
        }
    }
    private fun setColumnView() {
        when (selectedGrid) {
            2 -> {
                setSelectView(binding.btn2x2, null, binding.tv2x2)
                setUnSelectView(binding.btn3x3, null, binding.tv3x3)
                setUnSelectView(binding.btn4x4, null, binding.tv4x4)
                setUnSelectView(binding.btn5x5, null, binding.tv5x5)
            }
            3 -> {
                setUnSelectView(binding.btn2x2, null, binding.tv2x2)
                setSelectView(binding.btn3x3, null, binding.tv3x3)
                setUnSelectView(binding.btn4x4, null, binding.tv4x4)
                setUnSelectView(binding.btn5x5, null, binding.tv5x5)
            }
            4 -> {
                setUnSelectView(binding.btn2x2, null, binding.tv2x2)
                setUnSelectView(binding.btn3x3, null, binding.tv3x3)
                setSelectView(binding.btn4x4, null, binding.tv4x4)
                setUnSelectView(binding.btn5x5, null, binding.tv5x5)
            }
            5 -> {
                setUnSelectView(binding.btn2x2, null, binding.tv2x2)
                setUnSelectView(binding.btn3x3, null, binding.tv3x3)
                setUnSelectView(binding.btn4x4, null, binding.tv4x4)
                setSelectView(binding.btn5x5, null, binding.tv5x5)
            }
            else -> {
                setSelectView(binding.btn2x2, null, binding.tv2x2)
                setUnSelectView(binding.btn3x3, null, binding.tv3x3)
                setUnSelectView(binding.btn4x4, null, binding.tv4x4)
                setUnSelectView(binding.btn5x5, null, binding.tv5x5)
            }
        }

    }

    private fun setSelectView(bgLout: LinearLayout, ivIcon: ImageView?, tvText: TextView) {
        val color = ContextCompat.getColor(requireActivity(), R.color.black_text)
        bgLout.background = ContextCompat.getDrawable(requireActivity(), R.drawable.bg_view_type_select)
        tvText.setTextColor(color)
        ivIcon?.setColorFilter(color, PorterDuff.Mode.SRC_IN)
    }

    private fun setUnSelectView(bgLout: LinearLayout, ivIcon: ImageView?, tvText: TextView) {
        val color = ContextCompat.getColor(requireActivity(), R.color.grayText)
        bgLout.background =
            ContextCompat.getDrawable(requireActivity(), R.drawable.bg_view_type_unselect)
        tvText.setTextColor(color)
        ivIcon?.setColorFilter(color, PorterDuff.Mode.SRC_IN)
    }


    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}