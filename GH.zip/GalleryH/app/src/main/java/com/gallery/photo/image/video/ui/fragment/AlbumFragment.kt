package com.gallery.photo.image.video.ui.fragment

import android.app.Activity
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.analytics.FirebaseAnalytics
import com.gallery.photo.image.video.databinding.FragmentAlbumBinding
import com.gallery.photo.image.video.ui.activity.ImageListActivity
import com.gallery.photo.image.video.ui.adapter.AlbumAdapter
import com.gallery.photo.image.video.ui.event.CopyMoveEvent
import com.gallery.photo.image.video.ui.event.DeleteEvent
import com.gallery.photo.image.video.ui.event.DisplayDeleteEvent
import com.gallery.photo.image.video.ui.event.RenameEvent
import com.gallery.photo.image.video.ui.event.RestoreDataEvent
import com.gallery.photo.image.video.ui.event.UpdateFavoriteEvent
import com.gallery.photo.image.video.ui.model.AlbumData
import com.gallery.photo.image.video.ui.model.PictureData
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.Preferences
import com.gallery.photo.image.video.utils.Utils
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File
import java.util.Collections
import java.util.Locale

class AlbumFragment(
    var activity: Activity,
    val albumCountListener: (albumCount: Int) -> Unit
) : Fragment() {

    lateinit var binding: FragmentAlbumBinding
    var albumBackupList: ArrayList<AlbumData> = ArrayList()
    var albumList: ArrayList<AlbumData> = ArrayList()

    var albumWisePictures = LinkedHashMap<String, ArrayList<PictureData>>()
    var albumAdapter: AlbumAdapter? = null
    lateinit var preferences: Preferences
    var albumCount = 0
    lateinit var firebaseAnalytics: FirebaseAnalytics


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        EventBus.getDefault().register(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentAlbumBinding.inflate(layoutInflater, container, false)
        intView()
        return binding.root
    }

    private fun intView() {
        firebaseAnalytics = FirebaseAnalytics.getInstance(requireActivity())
        val bundle2 = Bundle()
        bundle2.putString("AlbumList", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_fragment, bundle2)

        preferences = Preferences(activity)
        getData()
        binding.swipeRefreshLayout.setOnRefreshListener {
            if (binding.swipeRefreshLayout.isEnabled)
                getData()
            else
                binding.swipeRefreshLayout.isRefreshing = false
        }
    }

    public fun setSwipeRefreshEnabled(isEnabled: Boolean) {
        binding.swipeRefreshLayout.isEnabled = isEnabled
    }

    private fun setData() {
        binding.swipeRefreshLayout.isRefreshing = false
        enableScroll()
        if (albumAdapter != null) albumAdapter!!.notifyDataSetChanged() else initAdapter()
        setEmptyData()
    }

    private fun initAdapter() {
        setRvLayoutManager()
        albumAdapter = AlbumAdapter(activity, albumList, clickListener = {
            val albumData = albumList[it]
            Constant.albumData = AlbumData(
                albumData.title,
                albumData.pictureData,
                albumData.folderPath,
                albumData.date,
                albumData.fileSize
            )
            startActivity(Intent(activity, ImageListActivity::class.java))
            setBackAlbumData()
        })
        binding.albumRecycler.adapter = albumAdapter
    }

    public fun setBackAlbumData() {
        Constant.albumList.clear()
        for (albumData in albumBackupList) {
            Constant.albumList.add(
                AlbumData(
                    albumData.title,
                    albumData.pictureData,
                    albumData.folderPath,
                    albumData.date,
                    albumData.fileSize
                )
            )
        }
    }

    fun setRvLayoutManager() {
        val grid = preferences.getGridCount()
        val isGridShow = preferences.getShowGrid()
        if (isGridShow)
            binding.albumRecycler.layoutManager = GridLayoutManager(
                getActivity(),
                grid,
                RecyclerView.VERTICAL,
                false
            )
        else
            binding.albumRecycler.layoutManager = LinearLayoutManager(getActivity())
    }

    fun setListGridData() {
        setRvLayoutManager()
        if (albumAdapter != null) {
            albumAdapter!!.notifyDataSetChanged()
        }
    }

    private fun setEmptyData() {
        if (albumList != null && albumList.size != 0) {
            binding.albumRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
        } else {
            binding.albumRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
        }
    }

    private fun getData() {
        disableScroll()
        binding.swipeRefreshLayout.isRefreshing = true
        Observable.fromCallable {
            getImages()
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                requireActivity().runOnUiThread {
                    setFilterData()
                    getAlbumCount()
                }
            }
            .subscribe { _: Boolean? ->
                requireActivity().runOnUiThread {
                    setFilterData()
                    getAlbumCount()
                }
            }
    }

    private fun getAlbumCount() {
        albumCountListener(albumBackupList.size)
    }

    private fun disableScroll() {
        binding.albumRecycler.suppressLayout(true)
    }

    private fun enableScroll() {
        binding.albumRecycler.suppressLayout(false)
    }

    fun setFilterData() {
        disableScroll()
        binding.swipeRefreshLayout.isRefreshing = true
        GlobalScope.launch(Dispatchers.IO) {
            sortAlbumMain()
            sortPhotos()

            activity.runOnUiThread {
                setData()
            }
        }
//        Observable.fromCallable {
//            sortAlbumMain()
//            sortPhotos()
//            true
//        }.subscribeOn(Schedulers.io())
//            .doOnError { _: Throwable? ->
//                requireActivity().runOnUiThread { setData() }
//            }
//            .subscribe { _: Boolean? ->
//                requireActivity().runOnUiThread { setData() }
//            }
    }

    private fun sortPhotos() {
        val sortType = preferences.getSortType()
        val sortOrder = preferences.getSortOrder()

        for (albumData in albumList) {
            Collections.sort(albumData.pictureData, Comparator { p1, p2 ->
                if (sortType == Constant.SORT_NAME) {
                    if (sortOrder == Constant.SORT_ASCENDING)
                        p1.fileName.compareTo(p2.fileName, true)
                    else
                        p2.fileName.compareTo(p1.fileName, true)
                } else if (sortType == Constant.SORT_PATH) {
                    if (sortOrder == Constant.SORT_ASCENDING)
                        p1.filePath.compareTo(p2.filePath, true)
                    else
                        p2.filePath.compareTo(p1.filePath, true)
                } else if (sortType == Constant.SORT_SIZE) {
                    if (sortOrder == Constant.SORT_ASCENDING)
                        p1.fileSize.compareTo(p2.fileSize)
                    else
                        p2.fileSize.compareTo(p1.fileSize)
                } else if (sortType == Constant.SORT_LAST_MODIFIED) {
                    if (sortOrder == Constant.SORT_ASCENDING)
                        p1.date.compareTo(p2.date)
                    else
                        p2.date.compareTo(p1.date)
                } else if (sortType == Constant.SORT_DATE_TAKEN) {
                    if (sortOrder == Constant.SORT_ASCENDING)
                        p1.dateTaken.compareTo(p2.dateTaken)
                    else
                        p2.dateTaken.compareTo(p1.dateTaken)
                } else
                    p2.date.compareTo(p1.date)
            })


        }

        for (albumData in albumBackupList) {
            Collections.sort(albumData.pictureData, Comparator { p1, p2 ->
                if (sortType == Constant.SORT_NAME) {
                    if (sortOrder == Constant.SORT_ASCENDING)
                        p1.fileName.compareTo(p2.fileName, true)
                    else
                        p2.fileName.compareTo(p1.fileName, true)
                } else if (sortType == Constant.SORT_PATH) {
                    if (sortOrder == Constant.SORT_ASCENDING)
                        p1.filePath.compareTo(p2.filePath, true)
                    else
                        p2.filePath.compareTo(p1.filePath, true)
                } else if (sortType == Constant.SORT_SIZE) {
                    if (sortOrder == Constant.SORT_ASCENDING)
                        p1.fileSize.compareTo(p2.fileSize)
                    else
                        p2.fileSize.compareTo(p1.fileSize)
                } else if (sortType == Constant.SORT_LAST_MODIFIED) {
                    if (sortOrder == Constant.SORT_ASCENDING)
                        p1.date.compareTo(p2.date)
                    else
                        p2.date.compareTo(p1.date)
                } else if (sortType == Constant.SORT_DATE_TAKEN) {
                    if (sortOrder == Constant.SORT_ASCENDING)
                        p1.dateTaken.compareTo(p2.dateTaken)
                    else
                        p2.dateTaken.compareTo(p1.dateTaken)
                } else
                    p2.date.compareTo(p1.date)
            })
        }

    }

    private fun sortAlbumMain() {
        val sortType = preferences.getSortType()
        val sortOrder = preferences.getSortOrder()

        albumList.sortWith(Comparator { p1, p2 ->
            if (sortType == Constant.SORT_NAME) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.title.compareTo(p2.title, true)
                else
                    p2.title.compareTo(p1.title, true)
            } else if (sortType == Constant.SORT_PATH) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.folderPath.compareTo(p2.folderPath, true)
                else
                    p2.folderPath.compareTo(p1.folderPath, true)
            } else if (sortType == Constant.SORT_SIZE) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.fileSize.compareTo(p2.fileSize)
                else
                    p2.fileSize.compareTo(p1.fileSize)
            } else if (sortType == Constant.SORT_LAST_MODIFIED) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.date.compareTo(p2.date)
                else
                    p2.date.compareTo(p1.date)
            } else if (sortType == Constant.SORT_DATE_TAKEN) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.date.compareTo(p2.date)
                else
                    p2.date.compareTo(p1.date)
            } else
                p2.date.compareTo(p1.date)
        })
        albumBackupList.sortWith(Comparator { p1, p2 ->
            if (sortType == Constant.SORT_NAME) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.title.compareTo(p2.title, true)
                else
                    p2.title.compareTo(p1.title, true)
            } else if (sortType == Constant.SORT_PATH) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.folderPath.compareTo(p2.folderPath)
                else
                    p2.folderPath.compareTo(p1.folderPath)
            } else if (sortType == Constant.SORT_SIZE) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.fileSize.compareTo(p2.fileSize)
                else
                    p2.fileSize.compareTo(p1.fileSize)
            } else if (sortType == Constant.SORT_LAST_MODIFIED) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.date.compareTo(p2.date)
                else
                    p2.date.compareTo(p1.date)
            } else if (sortType == Constant.SORT_DATE_TAKEN) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.date.compareTo(p2.date)
                else
                    p2.date.compareTo(p1.date)
            } else
                p2.date.compareTo(p1.date)
        })
    }

    fun setSearch(searchText: String) {
        val strSearch = searchText.lowercase(Locale.getDefault())
        albumList.clear()
        if (strSearch.isEmpty()) {
            albumList.addAll(albumBackupList)
        } else {
            val list = albumBackupList.filter {
                it.title.lowercase(Locale.getDefault()).contains(strSearch)
            }
            if (!list.isNullOrEmpty())
                albumList.addAll(list)
        }

        if (albumAdapter != null) albumAdapter!!.notifyDataSetChanged() else initAdapter()

        setEmptyData()
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onUpdateFavoriteEvent(event: UpdateFavoriteEvent) {
        updateFavoriteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDisplayDeleteEvent(event: DisplayDeleteEvent) {
        displayDeleteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDeleteEvent(event: DeleteEvent) {
        deleteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onCopyMoveEvent(event: CopyMoveEvent) {
        copyMoveEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onRestoreDataEvent(event: RestoreDataEvent) {
        restoreEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onRenameEvent(event: RenameEvent) {
        renameEvent(event)
    }


    private fun updateFavoriteEvent(event: UpdateFavoriteEvent) {
        if (event.path.isNotEmpty()) {
            if (albumList.isNotEmpty()) {
                var isUpdateData = false
                for (albumData in albumList) {
                    if (!isUpdateData)
                        for (pictureData in albumData.pictureData) {
                            if (pictureData.filePath == event.path) {
                                pictureData.isFavorite = event.isFavorite
                                isUpdateData = true
                                break
                            }
                        }
                    else {
                        break
                    }
                }
                if (albumAdapter != null)
                    albumAdapter!!.notifyDataSetChanged()
            }

            if (albumBackupList.isNotEmpty()) {
                var isUpdateData = false
                for (albumData in albumBackupList) {
                    if (!isUpdateData)
                        for (pictureData in albumData.pictureData) {
                            if (pictureData.filePath == event.path) {
                                pictureData.isFavorite = event.isFavorite
                                isUpdateData = true
                                break
                            }
                        }
                    else {
                        break
                    }
                }
            }
        } else if (event.unFavoriteList.isNotEmpty()) {
            if (albumList.isNotEmpty()) {
                var isUpdateData = false
                for (favPath in event.unFavoriteList) {
                    for (albumData in albumList) {
                        if (!isUpdateData)
                            for (pictureData in albumData.pictureData) {
                                if (pictureData.filePath == favPath) {
                                    pictureData.isFavorite = event.isFavorite
                                    isUpdateData = true
                                    break
                                }
                            }
                        else {
                            break
                        }
                    }
                }
                if (albumAdapter != null)
                    albumAdapter?.notifyDataSetChanged()

                for (favPath in event.unFavoriteList) {
                    for (albumData in albumBackupList) {
                        if (!isUpdateData)
                            for (pictureData in albumData.pictureData) {
                                if (pictureData.filePath == favPath) {
                                    pictureData.isFavorite = event.isFavorite
                                    isUpdateData = true
                                    break
                                }
                            }
                        else {
                            break
                        }
                    }
                }
            }
        }
    }

    private fun displayDeleteEvent(event: DisplayDeleteEvent) {
        if (event.deleteList.isNotEmpty())
            updateDeleteImageData(event.deleteList)
    }

    private fun renameEvent(event: RenameEvent) {
        if (event.oldPath.isNotEmpty() && event.renamePath.isNotEmpty()) {
            if (albumBackupList.isNotEmpty()) {
                val file = File(event.renamePath)
                val parentPath = file.parentFile.path
                for (albumData in albumBackupList) {
                    if (albumData.folderPath == parentPath) {
                        for (model in albumData.pictureData) {
                            if (model.filePath == event.oldPath) {
                                model.filePath = event.renamePath
                                model.fileName = File(event.renamePath).name
                                model.fileSize = File(event.renamePath).length()
                                break
                            }
                        }
                    }
                }
            }
            if (albumList.isNotEmpty()) {
                val file = File(event.renamePath)
                val parentPath = file.parentFile.path
                for (albumData in albumList) {
                    if (albumData.folderPath == parentPath) {
                        for (model in albumData.pictureData) {
                            if (model.filePath == event.oldPath) {
                                model.filePath = event.renamePath
                                model.fileName = File(event.renamePath).name
                                model.fileSize = File(event.renamePath).length()
                                break
                            }
                        }
                    }
                }

                albumAdapter?.notifyDataSetChanged()
            }
        }
    }

    private fun restoreEvent(event: RestoreDataEvent) {
        if (event.restoreList.isNotEmpty()) {
            val list: ArrayList<String> = ArrayList()
            val imageList: ArrayList<String> = ArrayList()
            val favList = preferences.getFavoriteList()

            for (restoreData in event.restoreList) {
                list.add(restoreData.deletedPath)
                imageList.add(restoreData.path)
            }

            updateDeleteImageData(list)

            for (i in imageList.indices) {
                val file1 = File(imageList[i])
                if (file1.exists()) {
                    val pictureData = PictureData(
                        file1.path,
                        file1.name,
                        file1.parentFile.name,
                        file1.lastModified(),
                        file1.lastModified(),
                        file1.length()
                    )
                    pictureData.isFavorite = favList.contains(file1.path)
                    if (Utils().isVideoFile(file1.path)) {
                        pictureData.isVideo = true
                    }

                    val file = file1.parentFile
                    var isAdd = false
                    for (albumData in albumList) {
                        if (albumData.title == file.name) {
                            val image: ArrayList<PictureData> = ArrayList()
                            image.addAll(albumData.pictureData)
                            image.add(pictureData)
                            albumData.pictureData = image
                            isAdd = true
                        }
                    }

                    if (!isAdd) {
                        val image: ArrayList<PictureData> = ArrayList()
                        image.add(pictureData)
                        val albumData = AlbumData()
                        albumData.title = file.name
                        albumData.folderPath = file.path
                        albumData.pictureData = image
                        albumData.date = file.lastModified()
                        albumData.fileSize = file.length()
                        albumList.add(albumData)
                        albumBackupList.add(albumData)
                    }

                }
            }
            getAlbumCount()
            setFilterData()
        }
    }

    private fun copyMoveEvent(event: CopyMoveEvent) {
        if (event.copyMoveList.isNotEmpty()) {
            val imageList: ArrayList<String> = ArrayList()
            imageList.addAll(event.copyMoveList)

            val file = File(event.albumPath)

            val favList = preferences.getFavoriteList()

            if (event.deleteList.isNotEmpty())
                updateDeleteImageData(event.deleteList)

            if (file.exists()) {
                val imagesData1 = ArrayList<PictureData>()
                for (i in imageList.indices) {
                    val file1 = File(imageList[i])
                    if (file1.exists()) {
                        val pictureData = PictureData(
                            file1.path,
                            file1.name,
                            file1.parentFile.name,
                            file1.lastModified(),
                            file1.lastModified(),
                            file1.length()
                        )
                        pictureData.isFavorite = favList.contains(file1.path)
                        if (Utils().isVideoFile(file1.path)) {
                            pictureData.isVideo = true
                        }
                        imagesData1.add(pictureData)
                    }
                }

                var isAdd = false
                for (albumData in albumBackupList) {
                    if (albumData.title == file.name) {
                        val image: ArrayList<PictureData> = ArrayList()
                        image.addAll(albumData.pictureData)
                        image.addAll(imagesData1)
                        albumData.pictureData = image
                        isAdd = true
                    }
                }
//                            if (isAdd) {
//                                for (albumData in albumList) {
//                                    if (albumData.title == file.name) {
//                                        val image: ArrayList<PictureData> = ArrayList()
//                                        image.addAll(albumData.pictureData)
//                                        image.addAll(imagesData1)
//                                        albumData.pictureData = image
//                                        isAdd = true
//                                    }
//                                }
//                            }

                if (!isAdd) {
                    val albumData = AlbumData()
                    albumData.title = file.name
                    albumData.folderPath = file.path
                    albumData.pictureData = imagesData1
                    albumData.date = file.lastModified()
                    albumData.fileSize = file.length()
                    albumList.add(albumData)
                    albumBackupList.add(albumData)
                }
                if (activity != null)
                    activity.runOnUiThread {
                        getAlbumCount()
                        setFilterData()
                    }


            }
        }

    }

    private fun deleteEvent(event: DeleteEvent) {
        if (event.deleteList.isNotEmpty())
            updateDeleteImageData(event.deleteList)
    }

    private fun updateDeleteImageData(deleteList: java.util.ArrayList<String>) {
        if (albumList != null && albumList.size != 0) {
            for (d in deleteList.indices) {
                var i = 0
                while (i < albumList.size) {
                    if (albumList[i] != null) {
                        val photoHeader = albumList[i]
                        val photoList: ArrayList<PictureData> = ArrayList()
                        photoList.addAll(photoHeader.pictureData)
                        if (photoList.size != 0) {
                            for (p in photoList.indices) {
                                if (deleteList[d].equals(
                                        photoList[p].filePath,
                                        ignoreCase = true
                                    )
                                ) {
                                    photoList.removeAt(p)
                                    if (photoList.size == 0) {
                                        if (albumList[i].folderPath.isNotEmpty()) {
//                                            val file = File(albumList[i].folderPath)
//                                            file.delete()
//                                            MediaScannerConnection.scanFile(
//                                                requireActivity(), arrayOf(file.path), null
//                                            ) { _: String?, _: Uri? -> }
                                        }
                                        albumList.removeAt(i)
                                        if (i != 0) {
                                            i--
                                        }
                                    } else {
                                        photoHeader.pictureData = photoList
                                        albumList[i] = photoHeader
                                    }
                                    break
                                }
                            }
                        }
                    }
                    i++
                }
            }
            if (albumAdapter != null) {
                albumAdapter!!.notifyDataSetChanged()
            }
            setEmptyData()
        }

        if (albumBackupList != null && albumBackupList.size != 0) {
            for (d in deleteList.indices) {
                var i = 0
                while (i < albumBackupList.size) {
                    if (albumBackupList[i] != null) {
                        val photoHeader = albumBackupList[i]
                        val photoList: ArrayList<PictureData> = ArrayList()
                        photoList.addAll(photoHeader.pictureData)
                        if (photoList.size != 0) {
                            for (p in photoList.indices) {
                                if (deleteList[d].equals(
                                        photoList[p].filePath,
                                        ignoreCase = true
                                    )
                                ) {
                                    photoList.removeAt(p)
                                    if (photoList.size == 0) {
                                        if (albumBackupList[i].folderPath.isNotEmpty()) {
//                                            val file = File(albumList[i].folderPath)
//                                            file.delete()
//                                            MediaScannerConnection.scanFile(
//                                                requireActivity(), arrayOf(file.path), null
//                                            ) { _: String?, _: Uri? -> }
                                        }
                                        albumBackupList.removeAt(i)
                                        if (i != 0) {
                                            i--
                                        }
                                    } else {
                                        photoHeader.pictureData = photoList
                                        albumBackupList[i] = photoHeader
                                    }
                                    break
                                }
                            }
                        }
                    }
                    i++
                }
            }
            getAlbumCount()
        }
    }

    private fun getImages() {
        albumList.clear()
        albumBackupList.clear()
        albumWisePictures.clear()
        activity.runOnUiThread { if (albumAdapter != null) albumAdapter!!.notifyDataSetChanged() }

        val folderList: MutableList<String> = ArrayList()
        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())
        albumCount = 0
        val mCursor: Cursor?
        try {
            val BUCKET_DISPLAY_NAME: String = MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
            val projection = arrayOf(
                MediaStore.Images.Media.DATA,
                BUCKET_DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_MODIFIED,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_TAKEN,
                MediaStore.MediaColumns.SIZE
            )
            val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            } else {
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            }
            mCursor = requireActivity().contentResolver.query(
                uri,  // Uri
                projection,  // Projection
                null,
                null,
                MediaStore.MediaColumns.DATE_MODIFIED + " DESC"
            )
            if (mCursor != null) {
                mCursor.moveToFirst()
                mCursor.moveToFirst()
                while (!mCursor.isAfterLast) {
                    //2sec
                    val path =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))
                    val title =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME))
                    val bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
                    if (!folderList.contains(bucketPath)) {
                        val bucketName =
                            mCursor.getString(mCursor.getColumnIndexOrThrow(BUCKET_DISPLAY_NAME))
                        if (bucketName != null && bucketName.isNotEmpty()) {
                            var d =
                                mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED))
                            d *= 1000
                            val fileSizeLength =
                                mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
                            var dt =
                                mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))
                            dt *= 1000
                            if (dt == 0L)
                                dt = d
                            val pictureData =
                                PictureData(path, title, bucketName, d, dt, fileSizeLength, false)
                            pictureData.isFavorite = favList.contains(path)
                            pictureData.bucketPath = bucketPath

                            var imagesData2: ArrayList<PictureData> = ArrayList()
                            if (albumWisePictures.containsKey(bucketPath)) {
                                val list: ArrayList<PictureData>? = albumWisePictures[bucketPath]
                                if (!list.isNullOrEmpty())
                                    imagesData2.addAll(list)
                            } else {
                                imagesData2 = ArrayList()
                            }
                            imagesData2.add(pictureData)
                            albumWisePictures[bucketPath] = imagesData2
                        }
                    }
                    mCursor.moveToNext()
                }
                mCursor.close()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        getVideos()
    }

    private fun getVideos() {
        var title: String
        var path: String
        val duration: Int
        val folderList: MutableList<String> = ArrayList<String>()
        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())
//        folderList.addAll(preferencesManager.getExcludeFolderList())
        val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Video.VideoColumns.DATA,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.VideoColumns.SIZE,
            MediaStore.Video.VideoColumns.DURATION,
            MediaStore.Video.VideoColumns.DATE_MODIFIED,
            MediaStore.Video.VideoColumns.DATE_TAKEN,
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
        )
        try {
            val cursor = requireActivity().contentResolver.query(
                uri,
                projection,
                null,
                null,
                MediaStore.Video.VideoColumns.DATE_MODIFIED + " DESC"
            )
            if (cursor != null) {
                duration = cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DURATION)
                cursor.moveToFirst()
                while (!cursor.isAfterLast) {
                    path =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA))
                    title =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME))
                    val bucketName =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME))
                    val bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
                    if (!folderList.contains(bucketPath)) {
                        var d =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DATE_MODIFIED))
                        d *= 1000
                        var dt =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))
                        dt *= 1000
                        if (dt == 0L)
                            dt = d
                        val fileSizeLength =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
//                        val pictureData = PictureData()
                        val pictureData = PictureData(
                            path,
                            title,
                            bucketName,
                            d,
                            dt,
                            fileSizeLength,
                            true,
                            cursor.getLong(duration)
                        )
                        pictureData.isVideo = true
                        pictureData.isFavorite = favList.contains(path)
                        pictureData.bucketPath = bucketPath

                        val imagesData2: ArrayList<PictureData> = ArrayList()
                        if (albumWisePictures.containsKey(bucketPath)) {
                            val list2: ArrayList<PictureData>? = albumWisePictures[bucketPath]
                            if (list2 != null)
                                imagesData2.addAll(list2)
                        }
                        imagesData2.add(pictureData)
                        albumWisePictures[bucketPath] = imagesData2
                    }
                    cursor.moveToNext()
                }
                cursor.close()
            }
        } catch (exp: Exception) {
            exp.printStackTrace()
        }
        val folderKeys: Set<String> = albumWisePictures.keys
        val listFolderkeys = java.util.ArrayList(folderKeys)
        for (i in listFolderkeys.indices) {
            val imagesData: java.util.ArrayList<PictureData> = ArrayList()
            val list = albumWisePictures[listFolderkeys[i]]
            if (list != null)
                imagesData.addAll(list)

            if (imagesData.size != 0 && imagesData[0].folderName.isNotEmpty()) {
                val albumData = AlbumData()
                albumCount++
                albumData.title = imagesData[0].folderName
                albumData.pictureData = imagesData

                val folderPath = listFolderkeys[i]
                albumData.folderPath = folderPath
                val file = File(folderPath)
                albumData.date = file.lastModified()
                albumData.fileSize = file.length()
                albumList.add(albumData)
                albumBackupList.add(albumData)
            }
        }
    }

}