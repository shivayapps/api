package com.gallery.photo.image.video.ui.activity.lock

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.Window
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.database.AppDatabase
import com.gallery.photo.image.video.databinding.ActivityPrivateBinding
import com.gallery.photo.image.video.databinding.DialogDeleteProgressBinding
import com.gallery.photo.image.video.ui.activity.BaseActivity
import com.gallery.photo.image.video.ui.activity.ImageViewerActivity
import com.gallery.photo.image.video.ui.adapter.FavouriteAdapter
import com.gallery.photo.image.video.ui.dialog.ConfirmationDialog
import com.gallery.photo.image.video.ui.dialog.DeleteDialog
import com.gallery.photo.image.video.ui.dialog.PrivateMenuDialog
import com.gallery.photo.image.video.ui.event.DeleteEvent
import com.gallery.photo.image.video.ui.event.DisplayDeleteEvent
import com.gallery.photo.image.video.ui.event.HideEvent
import com.gallery.photo.image.video.ui.event.RenameEvent
import com.gallery.photo.image.video.ui.event.RestoreDataEvent
import com.gallery.photo.image.video.ui.model.AlbumData
import com.gallery.photo.image.video.ui.model.PictureData
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.Preferences
import com.gallery.photo.image.video.utils.Utils
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File
import java.text.SimpleDateFormat
import java.util.Collections

class PrivateActivity : BaseActivity() {

    lateinit var binding: ActivityPrivateBinding
    var allList = ArrayList<PictureData>()
    var pictures = ArrayList<Any>()
    var pictureAdapter: FavouriteAdapter? = null
    lateinit var preferences: Preferences
    lateinit var dataBase: AppDatabase
    var selectedItem = 0
    var isSelectAll = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPrivateBinding.inflate(layoutInflater)
        setContentView(binding.root)
        EventBus.getDefault().register(this)
        intView()

    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }


    private fun intView() {
        binding.loutToolbar.txtTitle.text = getString(R.string.Private)
        preferences = Preferences(this)
        dataBase = AppDatabase.getInstance(this)
        getData()
        binding.swipeRefreshLayout.setOnRefreshListener {
            getData()
        }
        intListener()
        binding.loutToolbar.icMenu.visibility = View.VISIBLE
    }

    private fun intListener() {
        binding.loutToolbar.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.loutToolbar.icClose.setOnClickListener {
            setCloseToolbar()
        }
        binding.loutToolbar.icSelect.setOnClickListener {
            isSelectAll = !isSelectAll
            setSelectClick(isSelectAll)
            setSelectAllColor()
        }

        binding.loutToolbar.icMenu.setOnClickListener {
            showPrivateMenu()
        }

        binding.btnShare.setOnClickListener {
            shareImages()
        }
        binding.btnDelete.setOnClickListener {
            showDeleteDialog()
        }

        binding.btnUnhide.setOnClickListener {
            setUnHideData()
        }

        binding.btnCollage.setOnClickListener {

        }
    }

    private fun showPrivateMenu() {
        val dialog = PrivateMenuDialog(clickListener = {
            when (it) {
                1 -> {
                    // menuChangePassword
                    val intent = Intent(this, LockActivity::class.java)
                    intent.putExtra(Constant.EXTRA_CHANGE_PASS, true)
                    startActivity(intent)
                }

                2 -> {
                    // menuChangeQuestion
                    val intent = Intent(this, SecurityQuestionActivity::class.java)
                    intent.putExtra(Constant.EXTRA_CHANGE_PASS, true)
                    intent.putExtra(Constant.EXTRA_OPEN_TYPE_QUE, 1)
                    startActivity(intent)
                }

                3 -> {
                    // ChangeLockStyle
                    showLockStyleDialog()
                }

            }
        })
        dialog.show(supportFragmentManager, dialog.tag)
    }

    private fun showLockStyleDialog() {
//        val viewTypeDialog = ChangLockStyleDialog(updateListener = {
////            albumFragment.setListGridData()
//        })
//        viewTypeDialog.show(supportFragmentManager, viewTypeDialog.tag)
    }


    private fun notifyAdapter() {
        if (pictureAdapter != null)
            pictureAdapter?.notifyDataSetChanged()
    }

    private fun setData() {
        binding.swipeRefreshLayout.isRefreshing = false
        if (pictureAdapter != null) notifyAdapter() else initAdapter()
        setEmptyData()
    }

    private fun initAdapter() {
        setRvLayoutManager()
        pictureAdapter = FavouriteAdapter(this, pictures, clickListener = {
            if (pictures[it] is PictureData) {
                val pictureData = pictures[it] as PictureData
                if (pictureData.isCheckboxVisible) {
                    pictureData.isSelected = !pictureData.isSelected
                    pictureAdapter?.notifyItemChanged(it)
                    setSelectedFile()
                } else {
                    val dataList = ArrayList<PictureData>()
                    var displayPos = 0
                    for (i in pictures.indices) {
                        if (pictures[i] is PictureData) {
                            dataList.add(pictures[i] as PictureData)
                            if (it == i) {
                                displayPos = dataList.size - 1
                            }
                        }
                    }
                    Constant.displayImageList = ArrayList()
                    Constant.displayImageList.addAll(dataList)
                    val intent = Intent(this, ImageViewerActivity::class.java)
                    intent.putExtra(Constant.EXTRA_DISPLAY_POS, displayPos)
                    intent.putExtra(Constant.EXTRA_IS_OPEN_PRIVATE, true)
                    startActivity(intent)
                }
            }
        }, longClickListener = {
            if (pictures[it] is PictureData) {
                val pictureData = pictures[it] as PictureData
                for (i in pictures.indices) {
                    if (pictures[i] != null)
                        if (pictures[i] is AlbumData) {
                            val model = pictures[i] as AlbumData
                            model.isCheckboxVisible = true
                        } else if (pictures[i] is PictureData) {
                            val model = pictures[i] as PictureData
                            model.isCheckboxVisible = true
                        }
                }
                pictureData.isCheckboxVisible = true
                pictureData.isSelected = true
                notifyAdapter()
                setSelectedFile()
            }
        }, headerSelectListener = {
            if (pictures[it] is AlbumData) {
                val albumData = pictures[it] as AlbumData
                val isSelectAll = !albumData.isSelected
                albumData.isSelected = isSelectAll
                var pos = it + 1
                while (pos < pictures.size) {
                    if (pictures[pos] is PictureData) {
                        val model = pictures[pos] as PictureData
                        model.isSelected = isSelectAll
                        pos++
                    } else if (pictures[pos] is AlbumData) {
                        break
                    }
                }
                notifyAdapter()
                setSelectedFile()
            }
        })

        binding.pictureRecycler.adapter = pictureAdapter
    }

    private fun setEmptyData() {
        if (pictures.size != 0) {
            binding.pictureRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
        } else {
            binding.pictureRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
        }
    }

    fun setRvLayoutManager() {
        val gridCount = preferences.getGridCount()
        val gridLayoutManager =
            GridLayoutManager(this, gridCount, RecyclerView.VERTICAL, false)
        binding.pictureRecycler.layoutManager = gridLayoutManager
        gridLayoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                if (position >= 0 && position < pictures.size) {
                    return if (pictureAdapter!!.getItemViewType(position) === pictureAdapter!!.ITEM_HEADER_TYPE) {
                        gridCount
                    } else 1
                } else {
                    return 1
                }
            }
        }
    }

    override fun onBackPressed() {
        if (binding.loutToolbar.groupToolbarSelectHeader.visibility == View.VISIBLE) {
            setCloseToolbar()
        } else
            finish()
    }

    private fun longClickListener(
        isShowSelection: Boolean,
        selectedItem: Int,
        isAllSelect: Boolean
    ) {
        binding.loutToolbar.groupToolbarSelectHeader.visibility =
            if (isShowSelection) View.VISIBLE else View.GONE
        isSelectAll = isAllSelect
        binding.loutSelectOption.visibility =
            if (isShowSelection && selectedItem != 0) View.VISIBLE else View.GONE
        binding.loutToolbar.groupToolbarHeader.visibility =
            if (isShowSelection) View.GONE else View.VISIBLE
        binding.loutToolbar.txtSelectCount.text =
            "$selectedItem ${getString(R.string.items_selected)}"
        setSelectAllColor()
    }

    private fun setSelectAllColor() {
        val color =
            ContextCompat.getColor(this, if (isSelectAll) R.color.black else R.color.un_check_color)
        binding.loutToolbar.icSelect.setColorFilter(color, PorterDuff.Mode.SRC_IN)
    }

    fun setCloseToolbar() {
        setClose()
        longClickListener(false, 0, false)
    }

    private fun setSelectedFile() {
        var selected = 0
        var allItemCount = 0

        var currentHeaderPos = -1
        var photosCount = 0
        var photosSelectCount = 0

        for (i in pictures.indices) {
            if (pictures[i] is AlbumData) {
                if (i != currentHeaderPos) {
                    if (currentHeaderPos != -1) {
                        val model = pictures[currentHeaderPos] as AlbumData
                        model.isSelected = photosCount == photosSelectCount
                        photosCount = 0
                        photosSelectCount = 0
                        pictureAdapter?.notifyItemChanged(currentHeaderPos)
                    }
                    currentHeaderPos = i
                }
            } else if (pictures[i] is PictureData) {
                val model = pictures[i] as PictureData
                allItemCount++
                photosCount++
                if (model.isSelected) {
                    selected++
                    photosSelectCount++
                }
            }
        }
//        if (selected == 0) {
//            longClickListener(false, selected, false)
//            setClose()
//        } else {
//            longClickListener(true, selected, allItemCount == selected)
//        }
        longClickListener(true, selected, allItemCount == selected)
        binding.swipeRefreshLayout.isEnabled = false
//        binding.swipeRefreshLayout.isEnabled = selected == 0
        selectedItem = selected
    }

    fun setSelectClick(isSelectAll: Boolean) {
//        if (isSelectAll) {
        var selected = 0
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    model.isSelected = isSelectAll
                } else if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    model.isSelected = isSelectAll
                    if (isSelectAll)
                        selected++

                }
        }
        notifyAdapter()
        longClickListener(true, selected, isSelectAll)
        selectedItem = selected
//        } else {
//            longClickListener(false, 0, false)
//            setClose()
//        }
    }

    private fun setClose() {
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    model.isSelected = false
                    model.isCheckboxVisible = false
                } else if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    model.isCheckboxVisible = false
                    model.isSelected = false
                }
        }
        binding.swipeRefreshLayout.isEnabled = true
        notifyAdapter()
        selectedItem = 0
    }

    fun shareImages() {
        if (selectedItem == 0) {
            Toast.makeText(
                this,
                this.getString(R.string.PleaseSelectImage),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            val uris = ArrayList<Uri>()
            for (i in pictures.indices) {
                if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    if (model.isSelected) {
                        val uri = FileProvider.getUriForFile(
                            this,
                            this.packageName + ".provider",
                            File(model.filePath)
                        )
                        uris.add(uri)
                    }
                }
            }
            Utils().shareFilesList(this, uris)
        }
    }

    fun showDeleteDialog() {
        if (selectedItem == 0) {
            Toast.makeText(
                this,
                this.getString(R.string.PleaseSelectImage),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            val deleteDialog = DeleteDialog(
                this,
                getString(R.string.selected_delete_msg),
                positiveBtnClickListener = {
                    deletePhoto()
                })
            deleteDialog.show(supportFragmentManager, deleteDialog.tag)
        }
    }

    @SuppressLint("CheckResult")
    private fun deletePhoto() {
        val deleteList = ArrayList<String>()
        val bindingDialog = DialogDeleteProgressBinding.inflate(layoutInflater)
        val dialog = Dialog(this, R.style.Dialog)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(bindingDialog.root)
        dialog.setCanceledOnTouchOutside(false)
        dialog.window?.setGravity(Gravity.BOTTOM)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        bindingDialog.progressBar.max = selectedItem

        runOnUiThread {
            bindingDialog.txtProgressCount.text = deleteList.size.toString() + "/" + selectedItem
            bindingDialog.progressBar.progress = deleteList.size
        }
        dialog.show()

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(this)
            for (i in pictures.indices) {
                if (pictures[i] != null) if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    if (model.isSelected) {
                        runOnUiThread {
                            bindingDialog.txtTitle.text = model.fileName
                        }

                        val isDelete = Utils().deleteHideFile(this, model, dataBase)
                        if (isDelete) {
                            deleteList.add(model.filePath)
                            runOnUiThread {
                                bindingDialog.txtProgressCount.text =
                                    deleteList.size.toString() + "/" + selectedItem
                                bindingDialog.progressBar.progress = deleteList.size
                            }
                        }
                    } else {
                        model.isCheckboxVisible = false
                    }
                }
            }

            var i = 0
            while (i < pictures.size) {
                if (pictures[i] != null)
                    if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false

                    } else if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        if (model.isSelected) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is AlbumData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                        } else {
                            model.isSelected = false
                            model.isCheckboxVisible = false
                        }
                    }
                i++
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    if (dialog.isShowing)
                        dialog.dismiss()
                    setAfterDeleteUpdate(deleteList)
                }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    if (dialog.isShowing)
                        dialog.dismiss()
                    setAfterDeleteUpdate(deleteList)
                }
            }
    }

    fun setUnHideData() {
        if (selectedItem == 0) {
            Toast.makeText(
                this,
                this.getString(R.string.PleaseSelectImage),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            val hideDialog = ConfirmationDialog(
                this,
                getString(R.string.Unhide),
                getString(R.string.unhide_msg),
                getString(R.string.ok),
                positiveBtnClickListener = {
                    unHidePhoto()
                })
            hideDialog.show(supportFragmentManager, hideDialog.tag)
        }
    }

    private fun unHidePhoto() {
        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }

        Utils().unHideFiles(this, selectImage, selectedItem, hideListener = {
            Toast.makeText(
                this,
                getString(R.string.UnHide_successfully),
                Toast.LENGTH_SHORT
            ).show()
            selectedItem = 0
            longClickListener(false, 0, false)
            setClose()
        })
    }

    private fun setAfterDeleteUpdate(deleteList: ArrayList<String>) {
        EventBus.getDefault().post(DeleteEvent(1, deleteList))
        selectedItem = 0
        notifyAdapter()
        longClickListener(false, 0, false)
        setEmptyData()
        Toast.makeText(
            this,
            getString(R.string.Delete_successfully),
            Toast.LENGTH_SHORT
        ).show()
        deleteMainList(deleteList)
    }

    private fun deleteMainList(deleteList: ArrayList<String>) {
        if (deleteList.size != 0) {
            val favList = preferences.getFavoriteList()
            for (path in deleteList) {
                if (favList.contains(path))
                    favList.remove(path)
                for (pictureData in allList) {
                    if (pictureData.filePath == path) {
                        allList.remove(pictureData)
                        break
                    }
                }
            }

            preferences.setFavoriteList(favList)
        }
    }

    private fun renameEvent(event: RenameEvent) {
        if (event.oldPath.isNotEmpty() && event.renamePath.isNotEmpty()) {
            if (pictures.isNotEmpty()) {
                for (picture in pictures) {
                    if (picture is PictureData) {
                        val model = pictures as PictureData
                        if (model.filePath == event.oldPath) {
                            model.filePath = event.renamePath
                            model.fileName = File(event.renamePath).name
                            model.fileSize = File(event.renamePath).length()
                            break
                        }
                    }
                }
            }
            pictureAdapter?.notifyDataSetChanged()

            for (pictureData in allList) {
                if (pictureData.filePath == event.oldPath) {
                    pictureData.filePath = event.renamePath
                    pictureData.fileName = File(event.renamePath).name
                    pictureData.fileSize = File(event.renamePath).length()
                    break
                }
            }

        }
    }

    private fun deleteEvent(event: DeleteEvent) {
        if (event.deleteList.isNotEmpty() && event.pos != 0)
            if (pictures.isNotEmpty()) {
                updateDeleteImageData(event.deleteList)
                deleteMainList(event.deleteList)
            }
    }

    private fun restoreEvent(event: RestoreDataEvent) {
        if (event.restoreList.isNotEmpty())
            if (pictures.isNotEmpty()) {
                val list: ArrayList<String> = ArrayList()
                for (restoreData in event.restoreList) {
                    list.add(restoreData.deletedPath)
                }
                updateDeleteImageData(list)
                deleteMainList(list)
            }
    }

    private fun displayDeleteEvent(event: DisplayDeleteEvent) {
        if (event.deleteList.isNotEmpty())
            if (pictures.isNotEmpty()) {
                updateDeleteImageData(event.deleteList)
                deleteMainList(event.deleteList)
            }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDeleteEvent(event: DeleteEvent) {
        deleteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onRenameEvent(event: RenameEvent) {
        renameEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onRestoreDataEvent(event: RestoreDataEvent) {
        restoreEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onHideEvent(event: HideEvent) {
        getData()
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDisplayDeleteEvent(event: DisplayDeleteEvent) {
        displayDeleteEvent(event)
    }

    private fun updateDeleteImageData(deleteList: ArrayList<String>) {
        if (pictures.isNotEmpty()) {
            for (d in deleteList.indices) {
                var i = 0
                while (i < pictures.size) {
                    if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        if (model.filePath == deleteList[d]) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is AlbumData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                            if (d == deleteList.size - 1) {
                                break
                            }
                        }
                    }
                    i++
                }
            }
            notifyAdapter()
            setEmptyData()
        }
    }

    private fun getData() {
        binding.swipeRefreshLayout.isRefreshing = true
        Observable.fromCallable<Boolean> {
            allList.clear()
            var hiddenList = dataBase.hideDao().getHiddenList()
            if (!hiddenList.isNullOrEmpty()) {
                for (hiddenData in hiddenList) {
                    var file = File(hiddenData.hidePath)
                    if (file.exists()) {
                        val pictureData =
                            PictureData(
                                hiddenData.hidePath,
                                file.name,
                                file.parentFile.name,
                                file.lastModified(),
                                file.lastModified(),
                                file.length(),
                                Utils().isVideoFile(hiddenData.hidePath)
                            )
                        pictureData.isPrivate = true
                        pictureData.isFavorite = false
                        pictureData.idDataBase = hiddenData.id
                        pictureData.restorePath = hiddenData.restorePath

                        allList.add(pictureData)
                    }
                }

            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    setFilterData()
                }
            }
            .subscribe { result: Boolean? ->
                runOnUiThread {
                    setFilterData()
                }
            }
    }

    private fun setFilterData() {
        binding.swipeRefreshLayout.isRefreshing = true
        Observable.fromCallable<Boolean> {
            setFilter()
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread { setData() }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread { setData() }
            }
    }

    private fun setFilter() {
        val sortType = preferences.getSortType()
        val sortOrder = preferences.getSortOrder()

        Collections.sort(allList, Comparator { p1, p2 ->
            if (sortType == Constant.SORT_NAME) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.fileName.compareTo(p2.fileName, true)
                else
                    p2.fileName.compareTo(p1.fileName, true)
            } else if (sortType == Constant.SORT_PATH) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.filePath.compareTo(p2.filePath, true)
                else
                    p2.filePath.compareTo(p1.filePath, true)
            } else if (sortType == Constant.SORT_SIZE) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.fileSize.compareTo(p2.fileSize)
                else
                    p2.fileSize.compareTo(p1.fileSize)
            } else if (sortType == Constant.SORT_LAST_MODIFIED) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.date.compareTo(p2.date)
                else
                    p2.date.compareTo(p1.date)
            } else if (sortType == Constant.SORT_DATE_TAKEN) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.dateTaken.compareTo(p2.dateTaken)
                else
                    p2.dateTaken.compareTo(p1.dateTaken)
            } else
                p2.date.compareTo(p1.date)
        })

        setList()
    }

    private fun setList() {
        pictures.clear()

        val dateWisePictures = LinkedHashMap<String, ArrayList<PictureData>>()
        val format = SimpleDateFormat("dd MMM yyyy")
//        val format = SimpleDateFormat("EEEE, MMM dd yyyy")

        if (allList.size != 0) {
            for (pictureData in allList) {
                val strDate = format.format(pictureData.date)

                var imagesData1: ArrayList<PictureData> = ArrayList()
                if (dateWisePictures.containsKey(strDate)) {
                    val list: ArrayList<PictureData>? = dateWisePictures[strDate]
                    if (!list.isNullOrEmpty())
                        imagesData1.addAll(list)
                } else {
                    imagesData1 = ArrayList()
                }
                imagesData1.add(pictureData)
                dateWisePictures[strDate] = imagesData1
            }

            val keys: Set<String> = dateWisePictures.keys
            val listKeys = ArrayList(keys)

            for (i in listKeys.indices) {
                val imagesData = dateWisePictures[listKeys[i]]
                if (imagesData != null && imagesData.size != 0) {
                    val bucketData = AlbumData(listKeys[i], imagesData)
                    pictures.add(bucketData)
                    pictures.addAll(imagesData)
                }
            }
        }
    }
}