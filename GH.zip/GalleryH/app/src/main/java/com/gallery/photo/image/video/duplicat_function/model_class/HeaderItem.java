package com.gallery.photo.image.video.duplicat_function.model_class;


public class HeaderItem implements Item {
    private String title;
    boolean isSelected = false;

    public HeaderItem(String str) {
        this.title = str;
        this.isSelected = false;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String str) {
        this.title = str;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }
}
