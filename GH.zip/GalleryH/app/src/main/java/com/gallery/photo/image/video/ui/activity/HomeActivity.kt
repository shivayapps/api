package com.gallery.photo.image.video.ui.activity

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.PorterDuff
import android.graphics.drawable.BitmapDrawable
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.widget.PopupMenu
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.GravityCompat
import androidx.core.widget.addTextChangedListener
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
//import com.ads.module.open.AdconfigApplication
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.messaging.FirebaseMessaging
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.ActivityHomeBinding
import com.gallery.photo.image.video.databinding.PopBottomMenuBinding
import com.gallery.photo.image.video.ui.activity.duplicate.ScanActivity
import com.gallery.photo.image.video.ui.activity.edit.SelectImageActivity
import com.gallery.photo.image.video.ui.activity.itro.PermissionActivity
import com.gallery.photo.image.video.ui.activity.lock.LockActivity
import com.gallery.photo.image.video.ui.activity.lock.SecurityQuestionActivity
import com.gallery.photo.image.video.ui.activity.setting.LanguageActivity
import com.gallery.photo.image.video.ui.dialog.ChangLockStyleDialog
import com.gallery.photo.image.video.ui.dialog.ChangeViewTypeDialog
import com.gallery.photo.image.video.ui.dialog.CreateAlbumDialog
import com.gallery.photo.image.video.ui.dialog.DisplayedColumnsDialog
import com.gallery.photo.image.video.ui.dialog.ExitDialog
import com.gallery.photo.image.video.ui.dialog.HomeMenuDialog
import com.gallery.photo.image.video.ui.dialog.PrivateMenuDialog
import com.gallery.photo.image.video.ui.dialog.SortDialog
import com.gallery.photo.image.video.ui.dialog.ThemeDialog
import com.gallery.photo.image.video.ui.event.CopyMoveEvent
import com.gallery.photo.image.video.ui.fragment.AlbumFragment
import com.gallery.photo.image.video.ui.fragment.PhotosFragment
import com.gallery.photo.image.video.ui.fragment.PrivateFragment
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.MyApplication
import com.gallery.photo.image.video.utils.Preferences
import org.greenrobot.eventbus.EventBus
import java.io.File
import java.text.SimpleDateFormat
import kotlin.math.roundToInt


class HomeActivity : BaseActivity() {

    lateinit var binding: ActivityHomeBinding
    lateinit var preferences: Preferences
    lateinit var photosFragment: PhotosFragment
    lateinit var albumFragment: AlbumFragment
    lateinit var privateFragment: PrivateFragment
    var isSelectAll = false
    var imageFilePath = ""
    var tabPos = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        MyApplication.isOpenHomeScreen = true
        intView()
    }

    override fun onDestroy() {
        super.onDestroy()
        MyApplication.isOpenHomeScreen = false
    }

    private fun intView() {
        val bundle2 = Bundle()
        bundle2.putString("Home", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_activity, bundle2)

        preferences = Preferences(this)
        Log.e("RateTag", "intView isReCreateHomeSS ${Constant.isReCreateHomeSS}")
        if (Constant.isReCreateHomeSS) {
            Constant.isReCreateHomeSS = false
        } else {
            var appOpenCounter = preferences.getAppOpenCounter()
            appOpenCounter++
            preferences.putAppOpenCounter(appOpenCounter)
        }

//        checkForAppUpdate(binding.drawerLay)
        setTab()
        setToolbarSelectionMaintain(false, 0, false)
        intListener()
        intDrawerListener()
        loadNativeAdsHome(binding.frameNative)

        binding.drawerContent.tvAppVersion.text = getAppVersion()

        FirebaseMessaging.getInstance().token.addOnCompleteListener(OnCompleteListener { task ->
            if (!task.isSuccessful) {
                Log.w("TAG", "Fetching FCM registration token failed", task.exception)
                return@OnCompleteListener
            }

            // Get new FCM registration token
            val token = task.result

            // Log and toast
            Log.e("TAG", token)
        })
    }

    private fun setTab() {
        binding.icSearchClear.visibility = View.GONE
        binding.groupToolbarHeader.visibility = View.VISIBLE
        setUnselectIcon()
        setSelectTab(binding.ivTab1, binding.tvTab1)
        val adapter = ViewPagerAdapter(this)
        photosFragment =
            PhotosFragment(this, longClickListener = { isShowSelection, selectedItem, isAllSelect ->
                setToolbarSelectionMaintain(isShowSelection, selectedItem, isAllSelect)

            }, imageVideoCount = { imageCount, videoCount ->
                binding.drawerContent.txtCountPhoto.text = "$imageCount"
                binding.drawerContent.txtCountVideo.text = "$videoCount"
            }, selectAlbum = {
                getAlbumListForSelect()
            })
        albumFragment = AlbumFragment(this, albumCountListener = {
            binding.drawerContent.txtCountAlbum.text = "$it"
        })
        privateFragment = PrivateFragment(
            this,
            longClickListener = { isShowSelection, selectedItem, isAllSelect ->
                setToolbarSelectionMaintain(isShowSelection, selectedItem, isAllSelect)
            }, lockScreenListener = {
                binding.loutToolbar.visibility = if (it) View.GONE else View.VISIBLE
            }, swipeListener = {
                binding.viewPager.isUserInputEnabled = it
            })
//        binding.viewPager.isUserInputEnabled =false
        adapter.addFragment(photosFragment)
        adapter.addFragment(albumFragment)
        adapter.addFragment(privateFragment)

        binding.viewPager.offscreenPageLimit = 3
        binding.viewPager.adapter = adapter
//        binding.viewPager.setPageTransformer(SlideTransformer())

        binding.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                if (isSearchShow()) {
                    closeSearch()
                }
                binding.frameNative.visibility = if (position == 2) View.GONE else View.VISIBLE
                if (binding.viewPager.currentItem == 2) {
                    if (privateFragment != null)
                        privateFragment.setUnLockScreen()
                    binding.loutToolbar.visibility =
                        if (!privateFragment.isUnLock) View.GONE else View.VISIBLE
                    binding.groupToolbarSettingHeader.visibility = View.GONE
                    binding.txtTitle.text = getString(R.string.Private)
                } else {
                    binding.viewPager.isUserInputEnabled = true
                    binding.loutToolbar.visibility = View.VISIBLE
                    binding.groupToolbarSettingHeader.visibility = View.VISIBLE
                    binding.txtTitle.text = getString(R.string.app_name2)
                }

                setUnselectIcon()
                when (position) {
                    0 -> {
                        setSelectTab(binding.ivTab1, binding.tvTab1)
                    }

                    1 -> {
                        setSelectTab(binding.ivTab2, binding.tvTab2)
                    }

                    2 -> {
                        setSelectTab(binding.ivTab3, binding.tvTab3)
                    }
                }
                tabPos = position

            }
        })
    }

    private fun setToolbarSelectionMaintain(
        isShowSelection: Boolean,
        selectedItem: Int,
        isAllSelect: Boolean
    ) {
        binding.loutToolbar.visibility = View.VISIBLE
        if (isShowSelection) {
            binding.btnUnhide.visibility =
                if (binding.viewPager.currentItem == 2) View.VISIBLE else View.GONE
            binding.btnCollage.visibility = View.GONE

//            binding.btnCollage.visibility =
//                if (binding.viewPager.currentItem == 2) View.VISIBLE else View.GONE

            binding.btnHide.visibility =
                if (binding.viewPager.currentItem == 2) View.GONE else View.VISIBLE
            binding.btnMore.visibility =
                if (binding.viewPager.currentItem == 2) View.GONE else View.VISIBLE

        }
        if (isShowSelection) setDrawerLock() else setDrawerUnlock()

        binding.groupToolbarSelectHeader.visibility =
            if (isShowSelection) View.VISIBLE else View.GONE

        binding.viewPager.isUserInputEnabled = !isShowSelection
        isSelectAll = isAllSelect

        binding.loutSelectOption.visibility =
            if (isShowSelection && selectedItem != 0) View.VISIBLE else View.GONE


        if (binding.viewPager.currentItem == 2) {
            binding.groupToolbarSettingHeader.visibility = View.GONE
            binding.groupToolbarHeaderPrivate.visibility =
                if (isShowSelection) View.GONE else View.VISIBLE
        } else
            binding.groupToolbarHeader.visibility =
                if (isShowSelection) View.GONE else View.VISIBLE

        binding.loutTab.visibility = if (isShowSelection) View.GONE else View.VISIBLE
        binding.txtSelectCount.text = "$selectedItem ${getString(R.string.items_selected)}"
        setSelectAllColor()
    }

    private fun setSelectAllColor() {
        val color =
            ContextCompat.getColor(this, if (isSelectAll) R.color.black else R.color.un_check_color)
        binding.icSelect.setColorFilter(color, PorterDuff.Mode.SRC_IN)
    }

    private fun setSelectTab(imageView: ImageView, textView: TextView) {
        val selectColor = ContextCompat.getColor(this@HomeActivity, R.color.black_text)
        imageView.setColorFilter(selectColor, PorterDuff.Mode.SRC_IN)
        textView.setTextColor(selectColor)
    }

    private fun setUnselectIcon() {
        val color = ContextCompat.getColor(this, R.color.home_unSelect_tab_icon)
        binding.ivTab1.setColorFilter(color, PorterDuff.Mode.SRC_IN)
        binding.ivTab2.setColorFilter(color, PorterDuff.Mode.SRC_IN)
        binding.ivTab3.setColorFilter(color, PorterDuff.Mode.SRC_IN)

        binding.tvTab1.setTextColor(color)
        binding.tvTab2.setTextColor(color)
        binding.tvTab3.setTextColor(color)

    }

    private fun intDrawerListener() {
        binding.drawerContent.llDwHome.setOnClickListener {
            closeDrawer()
            binding.viewPager.currentItem = 0
        }
        binding.drawerContent.llDwFavourite.setOnClickListener {
            closeDrawer()
            startActivity(Intent(this, FavouriteListActivity::class.java))
            getAlbumListForSelect()

        }

        binding.drawerContent.llDwPrivate.setOnClickListener {
            closeDrawer()
            binding.viewPager.currentItem = 2

        }
        binding.drawerContent.llDwRecentlyDelete.setOnClickListener {
            startActivity(Intent(this, RecentlyDeleteActivity::class.java))
            closeDrawer()
            getAlbumListForSelect()
        }
        binding.drawerContent.llDwDuplicate.setOnClickListener {
            startActivity(
                Intent(this, ScanActivity::class.java).apply {
                    putExtra(
                        com.gallery.photo.image.video.duplicat_function.utils_duplicat.DuplicateConstants.SCAN_TYPE,
                        com.gallery.photo.image.video.duplicat_function.utils_duplicat.DuplicateConstants.Type.IMAGE
                    )
                }
            )
            closeDrawer()
        }
        binding.drawerContent.llDwTheme.setOnClickListener {
            val themeDialog = ThemeDialog(updateListener = {
                val intent = Intent(this, HomeActivity::class.java)
                finish()
                overridePendingTransition(0, 0)
                startActivity(intent)
                overridePendingTransition(0, 0)
            })
            themeDialog.show(supportFragmentManager, themeDialog.tag)
            closeDrawer()
        }
        binding.drawerContent.llDwSetting.setOnClickListener {
            settingLauncher.launch(Intent(this, SettingActivity::class.java))
            closeDrawer()
        }
        binding.drawerContent.llDwLanguage.setOnClickListener {
            languageLauncher.launch(Intent(this, LanguageActivity::class.java))
            closeDrawer()
        }
        binding.drawerContent.llDwPrivacyPolicy.setOnClickListener {
            openPrivacyPolicy()
            closeDrawer()
        }
    }

    private fun getAlbumListForSelect() {
        if (albumFragment != null)
            albumFragment.setBackAlbumData()
    }


    private fun closeDrawer() {
//        binding.drawerLay.closeDrawers()

        if (binding.drawerLay.isDrawerOpen(GravityCompat.START)) {
            binding.drawerLay.closeDrawer(GravityCompat.START)
        }
    }

    private fun intListener() {
        binding.icDrawer.setOnClickListener {
            if (binding.drawerLay.isDrawerOpen(GravityCompat.START))
                binding.drawerLay.closeDrawer(GravityCompat.START)
            else binding.drawerLay.openDrawer(GravityCompat.START)
        }

        binding.drawerContent.loutDrawerMain.setOnClickListener {

        }
        binding.btnTab1.setOnClickListener {
            binding.viewPager.currentItem = 0
        }
        binding.btnTab2.setOnClickListener {
            binding.viewPager.currentItem = 1
        }
        binding.btnTab3.setOnClickListener {
            binding.viewPager.currentItem = 2
        }

        binding.icCamera.setOnClickListener {
            if (checkCameraPermission())
                openCamera()
            else
                cameraActivityResultLauncher.launch(
                    Intent(
                        this,
                        PermissionActivity::class.java
                    ).putExtra(Constant.EXTRA_IS_OPEN_CAMERA_PERMISSION, true)
                )
        }
        binding.icSearch.setOnClickListener {
            binding.icSearchClear.visibility = View.GONE
            setDrawerLock()
            binding.groupToolbarHeader.visibility = View.GONE
            binding.groupSearch.visibility = View.VISIBLE
            binding.edtSearch.setText("")
            showKeyboard(binding.edtSearch)
            if (binding.viewPager.currentItem == 0) {
                if (photosFragment != null) {
                    photosFragment.isCheckSearchOn = true
                    photosFragment.setSwipeRefreshEnabled(false)
                }
            } else if (binding.viewPager.currentItem == 1) {
                if (albumFragment != null)
                    albumFragment.setSwipeRefreshEnabled(false)
            }
        }

        binding.icSearchClear.setOnClickListener {
            binding.edtSearch.setText("")
        }

        binding.icSearchBack.setOnClickListener {
            onBackPressed()
        }

        binding.edtSearch.addTextChangedListener {
            if (it.isNullOrEmpty()) {
                setSearch("")
                binding.icSearchClear.visibility = View.GONE
            } else {
                setSearch(it.toString())
                binding.icSearchClear.visibility = View.VISIBLE
            }
        }

        binding.icMenu.setOnClickListener {
            if (binding.viewPager.currentItem == 2)
                showPrivateMenu()
            else
                showMenu()
//            startActivity(Intent(this, WebBrowserActivity::class.java))
        }

        binding.icClose.setOnClickListener {
            if (binding.viewPager.currentItem == 0) {
                photosFragment.setCloseToolbar()
            } else if (binding.viewPager.currentItem == 2) {
                privateFragment.setCloseToolbar()
            }
        }
        binding.icSelect.setOnClickListener {
            isSelectAll = !isSelectAll
            if (binding.viewPager.currentItem == 0)
                photosFragment.setSelectClick(isSelectAll)
            else if (binding.viewPager.currentItem == 2) {
                privateFragment.setSelectClick(isSelectAll)
            }
            setSelectAllColor()
        }

        binding.btnShare.setOnClickListener {
            if (binding.viewPager.currentItem == 0)
                photosFragment.shareImages()
            else if (binding.viewPager.currentItem == 2) {
                privateFragment.shareImages()
            }
        }
        binding.btnDelete.setOnClickListener {
            if (binding.viewPager.currentItem == 0)
                photosFragment.showDeleteDialog()
            else if (binding.viewPager.currentItem == 2) {
                privateFragment.showDeleteDialog()
            }
        }
        binding.btnHide.setOnClickListener {
            if (binding.viewPager.currentItem == 0)
                photosFragment.setHideData()
        }

        binding.btnUnhide.setOnClickListener {
            if (binding.viewPager.currentItem == 2) {
                privateFragment.setUnHideData()
            }
        }

        binding.btnMore.setOnClickListener {
//            showMoreMenu()
            showDropDown(binding.ivMenuView)
        }
    }

    private fun setDrawerLock() {
        binding.drawerLay.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED)
    }

    private fun setDrawerUnlock() {
        binding.drawerLay.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED)
    }

    private fun setSearch(strSearch: String) {
        Log.e("", "strSearch $strSearch")
        if (tabPos == 0) {
            if (photosFragment != null)
                photosFragment.setSearch(strSearch)
        } else if (tabPos == 1) {
            if (albumFragment != null)
                albumFragment.setSearch(strSearch)
        }
    }

    private fun isOpenMenu(): Boolean {
        if (::popupWindow.isInitialized) {
            return popupWindow.isShowing
        }
        return false
    }


    lateinit var popupWindow: PopupWindow
    private fun showDropDown(view: View) {
        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopBottomMenuBinding.inflate(layoutInflater)
        val popupView = popUpBinding.root
        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        params.setMargins(10, 0, 50, 0)
        popupView.layoutParams = params
        popupWindow = PopupWindow(
            popupView,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        popupWindow.animationStyle = R.style.ShowUpAnimation_BR

        popupWindow.setBackgroundDrawable(BitmapDrawable())
        popupWindow.isOutsideTouchable = true
        val a = IntArray(2)
        view.getLocationInWindow(a)
        popupWindow.showAtLocation(
            view, Gravity.NO_GRAVITY, a[0],
            (a[1] - view.height - resources.getDimension(com.intuit.sdp.R.dimen._60sdp)).roundToInt()
        )
        popupWindow.update()
        popupWindow.showAsDropDown(view)

        popUpBinding.loutMain.setOnClickListener {
            popupWindow.dismiss()
        }

        popUpBinding.menuCopy.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 0)
                photosFragment.showAddAlbumDialog(albumFragment.albumBackupList, true)
        }
        popUpBinding.menuMove.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 0)
                photosFragment.showAddAlbumDialog(albumFragment.albumBackupList, false)
        }
    }

    private fun showMoreMenu() {
        val popup = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            PopupMenu(this@HomeActivity, binding.btnMore, Gravity.END, 0, R.style.BasePopupMenu)
        } else {
            PopupMenu(this@HomeActivity, binding.btnMore)
        }
        popup.menuInflater.inflate(R.menu.menu_bottom_option, popup.menu)
        popup.setForceShowIcon(true)

        popup.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.menuCopy -> {
                    if (binding.viewPager.currentItem == 0)
                        photosFragment.showAddAlbumDialog(albumFragment.albumBackupList, true)
                }

                R.id.menuMove -> {
                    if (binding.viewPager.currentItem == 0)
                        photosFragment.showAddAlbumDialog(albumFragment.albumBackupList, false)
                }

                R.id.menuCollage -> {

                }
            }
            return@setOnMenuItemClickListener true
        }
        popup.show()
    }

    private fun openCamera() {
//        val fileType: String = ".png"
        val fileType: String = ".jpg"
        val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)
            .toString() + File.separator + "Camera"
        val newdir = File(dir)
        val time_stamp = SimpleDateFormat("yyyy_MM_dd_HH_mm_ss").format(System.currentTimeMillis())
        imageFilePath = newdir.path + File.separator + time_stamp + fileType
        if (!newdir.exists()) newdir.mkdirs()
        val uri = FileProvider.getUriForFile(this, "$packageName.provider", File(imageFilePath))

        try {
            val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, uri)
            cameraIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            MyApplication.disabledOpenAds()
            captureImageActivityResultLauncher.launch(cameraIntent)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, getString(R.string.not_found), Toast.LENGTH_SHORT).show()
        }
    }

    var settingLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                Constant.isReCreateHomeSS = true
                val intent = intent
                finish()
                overridePendingTransition(0, 0)
                startActivity(intent)
                overridePendingTransition(0, 0)
                Constant.isChangeLanguage = false
            } else if (Constant.isChangeLanguage) {
                Constant.isReCreateHomeSS = true
                Constant.isChangeLanguage = false
                val intent = intent
                finish()
                overridePendingTransition(0, 0)
                startActivity(intent)
                overridePendingTransition(0, 0)
            }
        }

    var languageLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val intent = intent
                finish()
                overridePendingTransition(0, 0)
                startActivity(intent)
                overridePendingTransition(0, 0)
            }
        }

    var cameraActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
            openCamera()
        }
    }

    var captureImageActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
            MediaScannerConnection.scanFile(
                this@HomeActivity, arrayOf(imageFilePath), null
            ) { path: String?, uri: Uri? -> }
            val list = ArrayList<String>()
            list.add(imageFilePath)
            val file = File(imageFilePath)
            EventBus.getDefault()
                .post(CopyMoveEvent(list, "Camera", file.parentFile.path, ArrayList()))
        }
    }

    override fun onBackPressed() {
        if (binding.drawerLay.isDrawerOpen(GravityCompat.START))
            closeDrawer()
        else if (isOpenMenu())
            popupWindow.dismiss()
        else if (binding.viewPager.currentItem == 0 && binding.groupToolbarSelectHeader.visibility == View.VISIBLE) {
            photosFragment.setCloseToolbar()
        } else if (binding.viewPager.currentItem == 2 && binding.groupToolbarSelectHeader.visibility == View.VISIBLE) {
            privateFragment.setCloseToolbar()
        } else if (isSearchShow()) {
            closeSearch()
        } else if (binding.viewPager.currentItem != 0)
            binding.viewPager.currentItem = 0
        else {
//            if (preferences.isFirstTimeInstall()) {
//                exitDialog()
//            }
//            if (checkShowRateDialog()) {
//                showRateDialog(true)
//            } else {
                exitDialog()
//            }
        }
    }

//    private fun checkShowRateDialog(): Boolean {
//        val appOpenCounter = preferences.getAppOpenCounter()
//        Log.e("RateTag", "appOpenCounter $appOpenCounter")
//        return if (appOpenCounter == 4) {
//            true
//        } else if (appOpenCounter > 4 && getReviewCounter() != 0) {
//            (appOpenCounter - 4) % 3 == 0
//        } else
//            false
//        if (getReviewCounter() != 0) return true
//
//    }

    private fun closeSearch() {
        setDrawerUnlock()
        binding.icSearchClear.visibility = View.GONE
        binding.groupToolbarHeader.visibility = View.VISIBLE
        binding.groupSearch.visibility = View.GONE
        binding.edtSearch.setText("")
        hideKeyboard(binding.edtSearch)
        if (tabPos == 0) {
            if (photosFragment != null) {
                photosFragment.setSwipeRefreshEnabled(true)
                photosFragment.isCheckSearchOn = false
            }
        } else if (tabPos == 1) {
            if (albumFragment != null)
                albumFragment.setSwipeRefreshEnabled(true)
        }
    }

    private fun isSearchShow(): Boolean {
        if (binding.icSearchBack.visibility == View.VISIBLE && binding.edtSearch.visibility == View.VISIBLE)
            return true
        return false
    }

    fun hideKeyboard(view: EditText) {
        view.clearFocus()
        val methodManager = (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.hideSoftInputFromWindow(view.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
    }

    private fun showKeyboard(view: EditText) {
        view.requestFocus()
        val methodManager = (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun exitDialog() {
        val exitDialog = ExitDialog(
            this,
            getString(R.string.close_app),
            getString(R.string.exit),
            positiveBtnClickListener = {
                finishAffinity()
//                AdconfigApplication.adConfigFinishAffinity()
                MyApplication.isAppIsRunning = false
            })
        exitDialog.show(supportFragmentManager, exitDialog.tag)
    }

    private fun showPrivateMenu() {
        val dialog = PrivateMenuDialog(clickListener = {
            when (it) {
                1 -> {
                    // menuChangePassword
                    val intent = Intent(this, LockActivity::class.java)
                    intent.putExtra(Constant.EXTRA_CHANGE_PASS, true)
                    startActivity(intent)
                }

                2 -> {
                    // menuChangeQuestion
                    val intent = Intent(this, SecurityQuestionActivity::class.java)
                    intent.putExtra(Constant.EXTRA_CHANGE_PASS, true)
                    intent.putExtra(Constant.EXTRA_OPEN_TYPE_QUE, 1)
                    startActivity(intent)
                }

                3 -> {
                    // ChangeLockStyle
                    showLockStyleDialog()
                }
            }
        })
        dialog.show(supportFragmentManager, dialog.tag)
    }

    var changeLockStyleActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
            if (privateFragment != null)
                privateFragment.changeLockStyle()
        }
    }

    private fun showLockStyleDialog() {
        val viewTypeDialog = ChangLockStyleDialog(updateListener = {
            val intent = Intent(this, LockActivity::class.java)
            intent.putExtra(Constant.EXTRA_CHANGE_LOCK_STYLE, true)
            intent.putExtra(Constant.EXTRA_LOCK_STYLE, it)
            changeLockStyleActivityResultLauncher.launch(intent)
        })
        viewTypeDialog.show(supportFragmentManager, viewTypeDialog.tag)
    }

    private fun showMenu() {
        val dialog = HomeMenuDialog(binding.viewPager.currentItem != 0, clickListener = {
            when (it) {
                1 -> {
                    showFilterDialog()
                }

                2 -> {
//                    showChangeViewTypeDialog()
                }
                21 -> {
                    albumFragment.setListGridData()
//                    showChangeViewTypeDialog()
                }
                22 -> {
                    photosFragment.setRvLayoutManager()
                    albumFragment.setRvLayoutManager()
//                    showChangeViewTypeDialog()
                }

                3 -> {
                    // albumCreate
                    showCreateAlbum()
                }

                4 -> {
                    // displayed Columns
                    val displayColumnsDialog = DisplayedColumnsDialog(updateListener = {
                        photosFragment.setRvLayoutManager()
                        albumFragment.setRvLayoutManager()
                    })
                    displayColumnsDialog.show(supportFragmentManager, displayColumnsDialog.tag)

                }

                5 -> {
                    // Collage
                }
            }
        })
        dialog.show(supportFragmentManager, dialog.tag)

    }

    private fun showCreateAlbum() {
        val createDialog = CreateAlbumDialog(this, createPathListener = {
            val intent = Intent(this, SelectImageActivity::class.java)
            intent.putExtra(Constant.EXTRA_SELECT_TYPE, Constant.SELECT_TYPE_CRATE_ALBUM)
            intent.putExtra(Constant.EXTRA_ALBUM_PATH, it)
            startActivity(intent)
        }, true)
        createDialog.show(supportFragmentManager, createDialog.tag)
    }

    private fun showChangeViewTypeDialog() {
        val viewTypeDialog = ChangeViewTypeDialog(updateListener = {
            albumFragment.setListGridData()
        })
        viewTypeDialog.show(supportFragmentManager, viewTypeDialog.tag)
    }

    private fun showFilterDialog() {
        val sortDialog = SortDialog(updateListener = {
            photosFragment.setFilterData()
            albumFragment.setFilterData()
        })
        sortDialog.show(supportFragmentManager, sortDialog.tag)

    }

    class ViewPagerAdapter(fragmentActivity: FragmentActivity) :
        FragmentStateAdapter(fragmentActivity) {

        private val fragments = mutableListOf<Fragment>()

        override fun getItemCount(): Int {
            return fragments.size
        }

        override fun createFragment(position: Int): Fragment {
            return fragments[position]
        }

        fun addFragment(fragment: Fragment) {
            fragments.add(fragment)
            notifyDataSetChanged()
        }
    }

}