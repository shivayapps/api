package com.gallery.photo.image.video.ui.dialog

import android.app.Dialog
import android.graphics.PorterDuff
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.firebase.analytics.FirebaseAnalytics
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.DialogChangeViewTypeBinding
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.Preferences

class ChangLockStyleDialog(val updateListener: (isShowGrid:Boolean) -> Unit) :
    BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogChangeViewTypeBinding
    lateinit var firebaseAnalytics: FirebaseAnalytics
    lateinit var preferences: Preferences
    var isShowGrid = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogChangeViewTypeBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {
        firebaseAnalytics = FirebaseAnalytics.getInstance(requireActivity())
        val bundle2 = Bundle()
        bundle2.putString("ChangeLockStyle", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_dialog, bundle2)

        preferences = Preferences(requireActivity())
        bindingDialog.txtTitle.text = getString(R.string.change_lock_style)
        bindingDialog.tvGrid.text = getString(R.string.PIN)
        bindingDialog.tvList.text = getString(R.string.Pattern)
        bindingDialog.ivGrid.setImageDrawable(ContextCompat.getDrawable(requireActivity(),R.drawable.ic_change_pass))
        bindingDialog.ivList.setImageDrawable(ContextCompat.getDrawable(requireActivity(),R.drawable.ic_pattern))
        isShowGrid = preferences.getShowPINLock()

        intListener()
        setView()

    }

    private fun setView() {
        if (isShowGrid) {
            setSelectView(bindingDialog.btnGrid, bindingDialog.ivGrid, bindingDialog.tvGrid)
            setUnSelectView(bindingDialog.btnList, bindingDialog.ivList, bindingDialog.tvList)
        } else {
            setSelectView(bindingDialog.btnList, bindingDialog.ivList, bindingDialog.tvList)
            setUnSelectView(bindingDialog.btnGrid, bindingDialog.ivGrid, bindingDialog.tvGrid)
        }
    }


    private fun intListener() {
        bindingDialog.btnGrid.setOnClickListener {
            if (!isShowGrid) {
                isShowGrid = true
                setView()
//                preferences.putShowPinLock(isShowGrid)
                updateListener(isShowGrid)
                dismiss()
            } else dismiss()
        }
        bindingDialog.btnList.setOnClickListener {
            if (isShowGrid) {
                isShowGrid = false
                setView()
//                preferences.putShowPinLock(isShowGrid)
                updateListener(isShowGrid)
                dismiss()
            } else dismiss()
        }
    }

    private fun setSelectView(bgLout: LinearLayout, ivIcon: ImageView, tvText: TextView) {
        val color = ContextCompat.getColor(requireActivity(), R.color.black_text)
        bgLout.background =
            ContextCompat.getDrawable(requireActivity(), R.drawable.bg_view_type_select)
        tvText.setTextColor(color)
        ivIcon.setColorFilter(color, PorterDuff.Mode.SRC_IN)
    }

    private fun setUnSelectView(bgLout: LinearLayout, ivIcon: ImageView, tvText: TextView) {
        val color = ContextCompat.getColor(requireActivity(), R.color.grayText)
        bgLout.background =
            ContextCompat.getDrawable(requireActivity(), R.drawable.bg_view_type_unselect)
        tvText.setTextColor(color)
        ivIcon.setColorFilter(color, PorterDuff.Mode.SRC_IN)
    }


    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}