package com.gallery.photo.image.video.customView;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.util.AttributeSet;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.RelativeLayout;

public class ClipViewLayoutNew extends RelativeLayout {
    public PointF A;
    public float B;
    public final float[] C;
    public float D;
    public float E;

    /* renamed from: s  reason: collision with root package name */
    public ImageView f7331s;

    /* renamed from: t  reason: collision with root package name */
    public a f7332t;

    /* renamed from: u  reason: collision with root package name */
    public float f7333u;

    /* renamed from: v  reason: collision with root package name */
    public float f7334v;

    /* renamed from: w  reason: collision with root package name */
    public Matrix f7335w;
    public Matrix x;

    /* renamed from: y  reason: collision with root package name */
    public int f7336y;
    public PointF z;


    /* loaded from: classes2.dex */
    public class a implements ViewTreeObserver.OnGlobalLayoutListener {

        /* renamed from: s  reason: collision with root package name */
        public final /* synthetic */ String f7337s;

        public a(String str) {
            this.f7337s = str;
        }


        /* JADX WARN: Code restructure failed: missing block: B:40:0x00e0, code lost:
            if (r3 < r4) goto L25;
         */
        /* JADX WARN: Code restructure failed: missing block: B:43:0x0105, code lost:
            if (r3 < r4) goto L25;
         */
        /* JADX WARN: Code restructure failed: missing block: B:44:0x0107, code lost:
            r3 = r4;
         */
        /* JADX WARN: Code restructure failed: missing block: B:45:0x0108, code lost:
            r2.f7335w.postScale(r3, r3);
            r2.f7335w.postTranslate((r2.f7331s.getWidth() / 2) - ((int) ((r0.getWidth() * r3) / 2.0f)), (r2.f7331s.getHeight() / 2) - ((int) ((r0.getHeight() * r3) / 2.0f)));
            r2.f7331s.setScaleType(android.widget.ImageView.ScaleType.MATRIX);
            r2.f7331s.setImageMatrix(r2.f7335w);
            r2.f7331s.setImageBitmap(r0);
         */
        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final void onGlobalLayout() {
            /*
                Method dump skipped, instructions count: 345
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: gallery.photogallery.pictures.vault.album.widget.clipe.view.ClipViewLayout.a.onGlobalLayout():void");
        }
    }


    public ClipViewLayoutNew(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        this.f7335w = new Matrix();
        this.x = new Matrix();
        this.f7336y = 0;
        this.z = new PointF();
        this.A = new PointF();
        this.B = 1.0f;
        this.C = new float[9];
        this.E = 8.0f;
//        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, i.Z);
//        this.f7333u = obtainStyledAttributes.getDimensionPixelSize(2, (int) TypedValue.applyDimension(1, 1.0f, getResources().getDisplayMetrics()));
//        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(0, (int) TypedValue.applyDimension(1, 1.0f, getResources().getDisplayMetrics()));
//        int i10 = obtainStyledAttributes.getInt(1, 1);
//        obtainStyledAttributes.recycle();
//        a aVar = new a(context);
//        this.f7332t = aVar;
//        aVar.setClipType(i10 == 1 ? a.EnumC0115a.f7344s : a.EnumC0115a.f7345t);
//        this.f7332t.setClipBorderWidth(dimensionPixelSize);
//        this.f7332t.setmHorizontalPadding(this.f7333u);
//        this.f7331s = new ImageView(context);
//        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -1);
//        addView(this.f7331s, layoutParams);
//        addView(this.f7332t, layoutParams);
    }

//    public final void a() {
//        Drawable drawable;
//        float f10;
//        Matrix matrix = this.f7335w;
//        RectF rectF = new RectF();
//        if (this.f7331s.getDrawable() != null) {
//            rectF.set(0.0f, 0.0f, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
//            matrix.mapRect(rectF);
//        }
//        int width = this.f7331s.getWidth();
//        int height = this.f7331s.getHeight();
//        float width2 = rectF.width();
//        float f11 = width;
//        float f12 = this.f7333u;
//        if (width2 >= f11 - (f12 * 2.0f)) {
//            float f13 = rectF.left;
//            f10 = f13 > f12 ? (-f13) + f12 : 0.0f;
//            float f14 = rectF.right;
//            if (f14 < f11 - f12) {
//                f10 = (f11 - f12) - f14;
//            }
//        } else {
//            f10 = 0.0f;
//        }
//        float height2 = rectF.height();
//        float f15 = height;
//        float f16 = this.f7334v;
//        if (height2 >= f15 - (2.0f * f16)) {
//            float f17 = rectF.top;
//            r3 = f17 > f16 ? (-f17) + f16 : 0.0f;
//            float f18 = rectF.bottom;
//            if (f18 < f15 - f16) {
//                r3 = (f15 - f16) - f18;
//            }
//        }
//        this.f7335w.postTranslate(f10, r3);
//    }
//
//    public final Bitmap b() {
//        Bitmap bitmap;
//        this.f7331s.setDrawingCacheEnabled(true);
//        this.f7331s.buildDrawingCache();
//        Rect clipRect = this.f7332t.getClipRect();
//        try {
//            bitmap = Bitmap.createBitmap(this.f7331s.getDrawingCache(), clipRect.left, clipRect.top, clipRect.width(), clipRect.height());
//        } catch (Exception e10) {
//            e10.printStackTrace();
//            bitmap = null;
//            this.f7331s.destroyDrawingCache();
//            return bitmap;
//        } catch (OutOfMemoryError e11) {
//            e11.printStackTrace();
//            bitmap = null;
//            this.f7331s.destroyDrawingCache();
//            return bitmap;
//        }
//        this.f7331s.destroyDrawingCache();
//        return bitmap;
//    }
//
//    public final float c(MotionEvent motionEvent) {
//        float x = motionEvent.getX(0) - motionEvent.getX(1);
//        float y10 = motionEvent.getY(0) - motionEvent.getY(1);
//        return (float) Math.sqrt((y10 * y10) + (x * x));
//    }
//
//    public a getClipView() {
//        return this.f7332t;
//    }
//
//    public final float getScale() {
//        this.f7335w.getValues(this.C);
//        return this.C[0];
//    }
//
//    @Override // android.view.View
//    public final boolean onTouchEvent(MotionEvent motionEvent) {
//        int action = motionEvent.getAction() & 255;
//        if (action == 0) {
//            this.x.set(this.f7335w);
//            this.z.set(motionEvent.getX(), motionEvent.getY());
//            this.f7336y = 1;
//        } else if (action == 2) {
//            int i10 = this.f7336y;
//            if (i10 == 1) {
//                this.f7335w.set(this.x);
//                float x = motionEvent.getX() - this.z.x;
//                float y10 = motionEvent.getY() - this.z.y;
//                this.f7334v = this.f7332t.getClipRect().top;
//                this.f7335w.postTranslate(x, y10);
//                a();
//            } else if (i10 == 2) {
//                float c10 = c(motionEvent);
//                if (c10 > 10.0f) {
//                    float f10 = c10 / this.B;
//                    if (f10 < 1.0f) {
//                        if (getScale() > this.D) {
//                            this.f7335w.set(this.x);
//                            this.f7334v = this.f7332t.getClipRect().top;
//                            Matrix matrix = this.f7335w;
//                            PointF pointF = this.A;
//                            matrix.postScale(f10, f10, pointF.x, pointF.y);
//                            while (getScale() < this.D) {
//                                Matrix matrix2 = this.f7335w;
//                                PointF pointF2 = this.A;
//                                matrix2.postScale(1.01f, 1.01f, pointF2.x, pointF2.y);
//                            }
//                        }
//                        a();
//                    } else if (getScale() <= this.E) {
//                        this.f7335w.set(this.x);
//                        this.f7334v = this.f7332t.getClipRect().top;
//                        Matrix matrix3 = this.f7335w;
//                        PointF pointF3 = this.A;
//                        matrix3.postScale(f10, f10, pointF3.x, pointF3.y);
//                    }
//                }
//            }
//            this.f7331s.setImageMatrix(this.f7335w);
//        } else if (action == 5) {
//            float c11 = c(motionEvent);
//            this.B = c11;
//            if (c11 > 10.0f) {
//                this.x.set(this.f7335w);
//                this.A.set((motionEvent.getX(1) + motionEvent.getX(0)) / 2.0f, (motionEvent.getY(1) + motionEvent.getY(0)) / 2.0f);
//                this.f7336y = 2;
//            }
//        } else if (action == 6) {
//            this.f7336y = 0;
//        }
//        return true;
//    }
//
//    public void setClipView(a aVar) {
//        this.f7332t = aVar;
//    }
//
//    public void setImageSrc(String str) {
//        this.f7331s.getViewTreeObserver().addOnGlobalLayoutListener(new a(str));
//    }

}
