package com.gallery.photo.image.video.ui.dialog

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatDelegate
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.firebase.analytics.FirebaseAnalytics
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.DialogThemeBinding
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.Preferences

class ThemeDialog(val updateListener: () -> Unit) :
    BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogThemeBinding
    lateinit var preferences: Preferences
    lateinit var firebaseAnalytics: FirebaseAnalytics

    var themeValue = 0


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogThemeBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {
        preferences = Preferences(requireActivity())
        themeValue = preferences.getThemeValue()

        firebaseAnalytics = FirebaseAnalytics.getInstance(requireActivity())
        val bundle2 = Bundle()
        bundle2.putString("theme", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_dialog, bundle2)

        intListener()

        when (themeValue) {
            Constant.THEME_LIGHT -> bindingDialog.rbLight.isChecked = true
            Constant.THEME_DARK -> bindingDialog.rbDark.isChecked = true
        }
    }

    private fun intListener() {
        bindingDialog.btnCancel.setOnClickListener {
            dismiss()
        }
        bindingDialog.btnOK.setOnClickListener {
            val selectedRadioButtonIdOrder: Int = bindingDialog.grpTheme.checkedRadioButtonId
            var selectedTheme = -1

            selectedTheme = when (selectedRadioButtonIdOrder) {
                bindingDialog.rbLight.id -> Constant.THEME_LIGHT
                bindingDialog.rbDark.id -> Constant.THEME_DARK
                else -> -1
            }
            if (themeValue != selectedTheme)
                preferences.putTheme(selectedTheme)
            dismiss()
            if (themeValue != selectedTheme) {
                if (themeValue == Constant.THEME_LIGHT) {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                } else {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                }
                updateListener()
            }
        }
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}