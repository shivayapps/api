package com.gallery.photo.image.video.duplicat_function.core_class;

import android.util.Log;

import com.gallery.photo.image.video.duplicat_function.flow.Flow;
import com.gallery.photo.image.video.duplicat_function.flow.Predicate;
import com.gallery.photo.image.video.duplicat_function.model_class.DFile;
import com.gallery.photo.image.video.duplicat_function.model_class.DupFileContainer;
import com.gallery.photo.image.video.duplicat_function.utils_duplicat.DuplicateConstants;
import com.gallery.photo.image.video.duplicat_function.utils_duplicat.FileScanWorker;
import com.gallery.photo.image.video.duplicat_function.model_class.DFile;
import com.gallery.photo.image.video.duplicat_function.model_class.DupFileContainer;
import com.gallery.photo.image.video.duplicat_function.utils_duplicat.DuplicateConstants;
import com.gallery.photo.image.video.duplicat_function.utils_duplicat.FileScanWorker;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
public class FileHashGrouper {
    private static final int NUMBER_OF_CORES = Runtime.getRuntime().availableProcessors();
    private static final String TAG = FileHashGrouper.class.getSimpleName();
    private ThreadPoolExecutor executor;
    private int imageMatchSensitivity;
    private FileScanWorker.ProgressProgressListener progressProgressListener;
    private boolean stopped;
    private int totalFilesToProcess;
    private final AtomicInteger TASK_COMPLETED_TRACKER = new AtomicInteger();

    public FileHashGrouper(int i) {
        int i2 = NUMBER_OF_CORES;
        this.executor = new ThreadPoolExecutor(i2 * 2, i2 * 2, 60L, TimeUnit.SECONDS, new LinkedBlockingQueue());
        this.imageMatchSensitivity = i;
    }

    public void setProgressProgressListener(FileScanWorker.ProgressProgressListener progressProgressListener) {
        this.progressProgressListener = progressProgressListener;
    }

    public boolean isStopped() {
        return this.stopped;
    }

    public void setStopped(boolean z) {
        this.stopped = z;
    }

    public byte[] getFirstXBytes(File file) {
        byte[] bArr = new byte[Math.min((int) file.length(), 100000)];
        FileInputStream fileInputStream = null;

        try {
            try {
                FileInputStream fileInputStream2 = new FileInputStream(file);
                try {
                    fileInputStream2.read(bArr);
                    fileInputStream2.close();
                } catch (IOException e2) {

                    fileInputStream = fileInputStream2;
                    e2.printStackTrace();
                    if (fileInputStream != null) {
                        fileInputStream.close();
                    }
                    return bArr;
                } catch (Throwable th) {
                    th = th;
                    fileInputStream = fileInputStream2;
                    if (fileInputStream != null) {
                        try {
                            fileInputStream.close();
                        } catch (IOException e3) {
                            e3.printStackTrace();
                        }
                    }
                    throw th;
                }
            } catch (IOException e4) {

            }
            return bArr;
        } catch (Throwable th2) {

        }
        return bArr;
    }

    public DupFileContainer process(Set<Set<DFile>> set) {
        if (set == null) {
            return null;
        }
        List<DFile> synchronizedList = Collections.synchronizedList(new ArrayList());

        for (Set<DFile> set2 : set) {
            for (DFile dFile : set2) {
                this.totalFilesToProcess++;
                this.executor.execute(new ChecksumHandler(dFile));
                synchronizedList.add(dFile);
            }
        }
        waitAndTerminalExecutor();
        return group(synchronizedList);
    }

    private DupFileContainer group(List<DFile> list) {
        Set<DFile> set;
        HashMap<String, Set<DFile>> hashMap = new HashMap();
        for (DFile dFile : list) {
            String type = dFile.getType();
            Set hashSet = hashMap.containsKey(type) ? (Set) hashMap.get(type) : new HashSet();
            hashSet.add(dFile);
            hashMap.put(type, hashSet);
        }
        Map<String, Set<DFile>> groupPhotosTakenInSmallTimeIntervals = groupPhotosTakenInSmallTimeIntervals(Flow.of((Iterable) hashMap.get("image")).filter(new Predicate() {
            @Override
            public boolean test(Object o) {
                if (((DFile) o).getPhotoTakenAt() > 0){
                }
                return ((DFile) o).getPhotoTakenAt() > 0;
            }
        }).toList());
        DupFileContainer dupFileContainer = new DupFileContainer();
        HashSet hashSet2 = new HashSet();
        for (String str : hashMap.keySet()) {
            ArrayList arrayList = new ArrayList();
            HashMap<String, Set<DFile>> hashMap2 = new HashMap();
            for (DFile dFile2 :  hashMap.get(str)) {
                String hash = dFile2.getHash();
                Set hashSet3 = hashMap2.containsKey(hash) ? (Set) hashMap2.get(hash) : new HashSet();
                hashSet3.add(dFile2);
                hashMap2.put(hash, hashSet3);
            }
            for (String str2 : hashMap2.keySet()) {
                if (hashMap2.containsKey(str2)) {
                    Set<DFile> set2 = (Set) hashMap2.get(str2);
                    if (set2.iterator().next().getType().equals(DuplicateConstants.Type.IMAGE)) {
                        mergeIfCommonInterSection(set2, groupPhotosTakenInSmallTimeIntervals, hashSet2);
                    }
                    if (set2.size() > 1) {
                        ArrayList arrayList2 = new ArrayList(set2);
                        Collections.sort(arrayList2, new Comparator<Object>() {
                            @Override
                            public int compare(Object o, Object t1) {
                                return lambda$group$1((DFile) o, (DFile) t1);
                            }
                        });
                        arrayList.add(arrayList2);
                    }
                }
            }
            if (DuplicateConstants.Type.IMAGE.equals(str)) {
                for (String str3 : groupPhotosTakenInSmallTimeIntervals.keySet()) {
                    if (!hashSet2.contains(str3) && (set = groupPhotosTakenInSmallTimeIntervals.get(str3)) != null && set.size() > 1) {
                        ArrayList arrayList3 = new ArrayList(set);
                        Collections.sort(arrayList3, new Comparator<Object>() {
                            @Override
                            public int compare(Object o, Object t1) {
                                return lambda$group$2((DFile) o, (DFile) t1);
                            }
                        });
                        arrayList.add(arrayList3);
                    }
                }
            }
            Collections.sort(arrayList, new Comparator<Object>() {
                @Override
                public int compare(Object o, Object t1) {
                    return lambda$group$3((List) o, (List) t1);
                }
            });
            char c = '\uffff';
            switch (str.hashCode()) {
                case 93166550:
                    if (str.equals(DuplicateConstants.Type.AUDIO)) {
                        c = 1;
                        break;
                    }
                    break;
                case 100313435:
                    if (str.equals(DuplicateConstants.Type.IMAGE)) {
                        c = 0;
                        break;
                    }
                    break;
                case 106069776:
                    if (str.equals(DuplicateConstants.Type.OTHER)) {
                        c = 3;
                        break;
                    }
                    break;
                case 112202875:
                    if (str.equals(DuplicateConstants.Type.VIDEO)) {
                        c = 2;
                        break;
                    }
                    break;
            }
            if (c == 0) {
                dupFileContainer.setImage(arrayList);
            } else if (c == 1) {
                dupFileContainer.setAudio(arrayList);
            } else if (c == 2) {
                dupFileContainer.setVideo(arrayList);
            } else if (c == 3) {
                dupFileContainer.setOther(arrayList);
            }
        }
        return dupFileContainer;
    }



    static  int lambda$group$1(DFile dFile, DFile dFile2) {
        if (dFile.getLastUpdatedAt() == dFile2.getLastUpdatedAt()) {
            return 0;
        }
        return dFile.getLastUpdatedAt() < dFile2.getLastUpdatedAt() ? 1 : -1;
    }

    static int lambda$group$2(DFile dFile, DFile dFile2) {
        if (dFile.getLastUpdatedAt() == dFile2.getLastUpdatedAt()) {
            return 0;
        }
        return dFile.getLastUpdatedAt() < dFile2.getLastUpdatedAt() ? 1 : -1;
    }

    static int lambda$group$3(List list, List list2) {
        DFile dFile = (DFile) list.get(0);
        DFile dFile2 = (DFile) list2.get(0);
        if (dFile.getLastUpdatedAt() == dFile2.getLastUpdatedAt()) {
            return 0;
        }
        return dFile.getLastUpdatedAt() < dFile2.getLastUpdatedAt() ? 1 : -1;
    }

    private void mergeIfCommonInterSection(Set<DFile> set, Map<String, Set<DFile>> map, Set<String> set2) {
        Set<DFile> set3;
        for (String str : map.keySet()) {
            if (!set2.contains(str) && (set3 = map.get(str)) != null) {
                Iterator<DFile> it = set3.iterator();
                while (true) {
                    if (!it.hasNext()) {
                        break;
                    } else if (set.contains(it.next())) {
                        set2.add(str);
                        set.addAll(set3);
                        break;
                    }
                }
            }
        }
    }

    private void waitAndTerminalExecutor() {
        while (filedProcessingGap() > 20) {
            try {
                Thread.sleep(1000L);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        if (filedProcessingGap() > 0) {
            try {
                Thread.sleep(1000L);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        this.executor.shutdown();
    }

    private int filedProcessingGap() {
        return this.totalFilesToProcess - this.TASK_COMPLETED_TRACKER.get();
    }

    public boolean isEqual(byte[] bArr, byte[] bArr2) {
        if (bArr.length != bArr2.length) {
            return false;
        }
        for (int i = 0; i < bArr.length; i++) {
            if (bArr[i] != bArr2[i]) {
                return false;
            }
        }
        return true;
    }

   public static FileInputStream fileInputStream;
    public String checkSum(String str) {

        FileInputStream fileInputStream2;
        int read;
        String str2 = null;
        str2 = null;
        str2 = null;
        FileInputStream fileInputStream3 = null;
        try {
            try {
                try {
                    fileInputStream2 = new FileInputStream(str);
                } catch (IOException e) {
                    e = e;
                    fileInputStream2 = null;
                    Log.e(TAG, e.getMessage());
                    if (fileInputStream2 != null) {
                    }
                    return str2;
                } catch (Throwable th) {
                    th = th;
                    if (fileInputStream3 != null) {
                        try {
                            fileInputStream3.close();
                        } catch (IOException e3) {
                            Log.e(TAG, e3.getMessage(), e3);
                        }
                    }
                    throw th;
                }
                try {
                    MessageDigest messageDigest = MessageDigest.getInstance("MD5");
                    byte[] bArr = new byte[1024];
                    int i = 0;
                    while (true) {
                        int i2 = i + 1;
                        if (i >= 5 || (read = fileInputStream2.read(bArr)) <= 0) {
                            break;
                        }
                        messageDigest.update(bArr, 0, read);
                        i = i2;
                    }
                    str2 = new BigInteger(1, messageDigest.digest()).toString(16);
                    fileInputStream2.close();
                } catch (IOException e4) {

                    Log.e(TAG, e4.getMessage());
                    if (fileInputStream2 != null) {
                        fileInputStream2.close();
                    }
                    return str2;
                } catch (NoSuchAlgorithmException e5) {

                    Log.e(TAG, e5.getMessage());
                    if (fileInputStream2 != null) {
                    }
                    return str2;
                }
            } catch (IOException e6) {
                Log.e(TAG, e6.getMessage(), e6);
            }
            return str2;
        } catch (Throwable th2) {

            fileInputStream3 = fileInputStream;
        }
        return str2;
    }

    private Map<String, Set<DFile>> groupPhotosTakenInSmallTimeIntervals(List<DFile> list) {
        HashMap hashMap = new HashMap();
        if (this.imageMatchSensitivity == 0) {
            return hashMap;
        }
        int i = 0;
        Collections.sort(list, new Comparator<DFile>() {
            @Override
            public int compare(DFile dFile, DFile t1) {
                return lambda$groupPhotosTakenInSmallTimeIntervals$4(dFile, t1);
            }
        });
        while (i < list.size()) {
            HashSet hashSet = new HashSet();
            DFile dFile = list.get(i);
            String str = "fakeHash_" + i;
            dFile.setHash(str);
            hashSet.add(dFile);
            while (true) {
                i++;
                if (i >= list.size() || timeDiff(dFile, list.get(i)) > this.imageMatchSensitivity) {
                    break;
                }
                DFile dFile2 = list.get(i);
                dFile2.setHash(str);
                hashSet.add(dFile2);
            }
            if (hashSet.size() > 1) {
                hashMap.put(str, hashSet);
            }
        }
        return hashMap;
    }

    static int lambda$groupPhotosTakenInSmallTimeIntervals$4(DFile dFile, DFile dFile2) {
        if (dFile.getPhotoTakenAt() == dFile2.getPhotoTakenAt()) {
            return 0;
        }
        return dFile.getPhotoTakenAt() < dFile2.getPhotoTakenAt() ? 1 : -1;
    }

    private long timeDiff(DFile dFile, DFile dFile2) {
        return Math.abs((dFile2.getPhotoTakenAt() - dFile.getPhotoTakenAt()) / 1000);
    }


    class ChecksumHandler implements Runnable {
        private final DFile file;

        ChecksumHandler(DFile dFile) {
            this.file = dFile;
        }

        @Override 
        public void run() {
            if (FileHashGrouper.this.isStopped()) {
                FileHashGrouper.this.executor.shutdown();
                return;
            }
            if (FileHashGrouper.this.progressProgressListener != null && (FileHashGrouper.this.TASK_COMPLETED_TRACKER.get() < 20 || FileHashGrouper.this.TASK_COMPLETED_TRACKER.get() % 20 == 0)) {
                FileHashGrouper.this.progressProgressListener.setProcessedFileCount(FileHashGrouper.this.TASK_COMPLETED_TRACKER.get());
            }
            DFile dFile = this.file;
            if (dFile == null) {
                FileHashGrouper.this.TASK_COMPLETED_TRACKER.getAndIncrement();
            } else if (dFile.getHash() != null) {
                FileHashGrouper.this.TASK_COMPLETED_TRACKER.getAndIncrement();
            } else if (this.file.getSize() != 0) {
                String checkSum = FileHashGrouper.this.checkSum(this.file.getPath());
                FileHashGrouper.this.TASK_COMPLETED_TRACKER.getAndIncrement();
                if (checkSum == null) {
                    return;
                }
                DFile dFile2 = this.file;
                dFile2.setHash(checkSum + "_" + this.file.getSize());
            } else {
                this.file.setHash("zero_size_hash");
                FileHashGrouper.this.TASK_COMPLETED_TRACKER.getAndIncrement();
            }
        }
    }

    
    class FileCompareHandler implements Runnable {
        private final String fakeHash;
        private final DFile file1;
        private final DFile file2;

        FileCompareHandler(DFile dFile, DFile dFile2, String str) {
            this.file1 = dFile;
            this.file2 = dFile2;
            this.fakeHash = str;
        }

        @Override 
        public void run() {
            DFile dFile = this.file1;
            if (dFile == null || this.file2 == null) {
                FileHashGrouper.this.TASK_COMPLETED_TRACKER.getAndIncrement();
            } else if (dFile.getSize() != 0 || this.file2.getSize() != 0) {
                if (FileHashGrouper.this.isEqual(FileHashGrouper.this.getFirstXBytes(new File(this.file1.getPath())), FileHashGrouper.this.getFirstXBytes(new File(this.file2.getPath())))) {
                    this.file1.setHash(this.fakeHash);
                    this.file2.setHash(this.fakeHash);
                }
                FileHashGrouper.this.TASK_COMPLETED_TRACKER.getAndIncrement();
            } else {
                FileHashGrouper.this.TASK_COMPLETED_TRACKER.getAndIncrement();
                this.file1.setHash(this.fakeHash);
                this.file2.setHash(this.fakeHash);
            }
        }
    }
}
