package com.gallery.photo.image.video.ui.activity.lock

import android.os.Bundle
import androidx.fragment.app.Fragment
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.ActivityLockBinding
import com.gallery.photo.image.video.ui.activity.BaseActivity
import com.gallery.photo.image.video.ui.fragment.LockChangeStyleFragment
import com.gallery.photo.image.video.ui.fragment.LockFragment
import com.gallery.photo.image.video.utils.Constant

class LockActivity : BaseActivity() {

    lateinit var binding: ActivityLockBinding
    var isResetPass = false
    var isChangePass = false
    var isOpenPrivate = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLockBinding.inflate(layoutInflater)
        setContentView(binding.root)
        intView()
    }

    private fun intView() {
        isOpenPrivate = intent.getBooleanExtra(Constant.EXTRA_IS_OPEN_PRIVATE, false)
        isResetPass = intent.getBooleanExtra(Constant.EXTRA_RESET_PASS, false)
        isChangePass = intent.getBooleanExtra(Constant.EXTRA_CHANGE_PASS, false)
        val isChangeLockStyle = intent.getBooleanExtra(Constant.EXTRA_CHANGE_LOCK_STYLE, false)
        val isLockStyleGrid = intent.getBooleanExtra(Constant.EXTRA_LOCK_STYLE, false)

        if (isChangeLockStyle) {
            loadFragment(LockChangeStyleFragment(this, isLockStyleGrid, lockListener = {
                setResult(RESULT_OK)
                finish()
            }))
        } else
            loadFragment(
                LockFragment(
                    this,
                    isOpenPrivate,
                    isResetPass,
                    isChangePass,
                    lockListener = {
                        if (it) {
                            setResult(RESULT_OK)
                            finish()
                        }
                    }, swipeListener = {

                    })
            )
    }

    private fun loadFragment(fragment: Fragment) {
        val fm = this.supportFragmentManager
        val fragmentTransaction = fm.beginTransaction()
        fragmentTransaction.replace(R.id.browser_frame, fragment)
        fragmentTransaction.commit()
    }

}