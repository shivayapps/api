package com.gallery.photo.image.video.ui.event

import java.util.ArrayList

data class DeleteEvent(var pos: Int, var deleteList: ArrayList<String>)
