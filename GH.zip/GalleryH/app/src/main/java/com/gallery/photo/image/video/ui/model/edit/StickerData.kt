package com.gallery.photo.image.video.ui.model.edit

import android.content.res.TypedArray

data class StickerData(var name: String, var stickerList: TypedArray)
