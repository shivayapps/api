package com.gallery.photo.image.video.ui.fragment

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.database.Cursor
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.GridLayoutManager.SpanSizeLookup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.firebase.analytics.FirebaseAnalytics
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.database.AppDatabase
import com.gallery.photo.image.video.databinding.DialogDeleteProgressBinding
import com.gallery.photo.image.video.databinding.FragmentPhotosBinding
import com.gallery.photo.image.video.ui.activity.ImageViewerActivity
import com.gallery.photo.image.video.ui.adapter.PictureAdapter
import com.gallery.photo.image.video.ui.dialog.ConfirmationDialog
import com.gallery.photo.image.video.ui.dialog.CreateAlbumDialog
import com.gallery.photo.image.video.ui.dialog.DeleteDialog
import com.gallery.photo.image.video.ui.dialog.SelectAlbumDialog
import com.gallery.photo.image.video.ui.event.CopyMoveEvent
import com.gallery.photo.image.video.ui.event.DeleteEvent
import com.gallery.photo.image.video.ui.event.DisplayDeleteEvent
import com.gallery.photo.image.video.ui.event.RenameEvent
import com.gallery.photo.image.video.ui.event.RestoreDataEvent
import com.gallery.photo.image.video.ui.event.UpdateFavoriteEvent
import com.gallery.photo.image.video.ui.model.AlbumData
import com.gallery.photo.image.video.ui.model.PictureData
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.FileCursorHelper
import com.gallery.photo.image.video.utils.Preferences
import com.gallery.photo.image.video.utils.Utils
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Locale

class PhotosFragment(
    val activity: Activity,
    val longClickListener: (isShowSelection: Boolean, selected: Int, isAllSelect: Boolean) -> Unit,
    val imageVideoCount: (imageCount: Int, videoCount: Int) -> Unit,
    val selectAlbum: () -> Unit
) : Fragment() {

    lateinit var binding: FragmentPhotosBinding
    lateinit var firebaseAnalytics: FirebaseAnalytics
    var allList = ArrayList<PictureData>()
    var allBackList = ArrayList<PictureData>()
    var pictures = ArrayList<Any>()
    var pictureAdapter: PictureAdapter? = null
    lateinit var preferences: Preferences
    var selectedItem = 0
    var isSearch: Boolean = false
    var isStopSearch: Boolean = false
    var isCheckSearchOn = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        EventBus.getDefault().register(this)
//        updateFavoriteEvent()
//        displayDeleteEvent()
//        deleteEvent()
//        copyMoveEvent()
//        restoreEvent()
//        renameEvent()
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPhotosBinding.inflate(layoutInflater, container, false)
        intView()
        return binding.root
    }

    private fun intView() {
        firebaseAnalytics = FirebaseAnalytics.getInstance(requireActivity())
        val bundle2 = Bundle()
        bundle2.putString("PhotoList", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_fragment, bundle2)

        preferences = Preferences(activity)
        setRvLayoutManager()
        getData()
        binding.swipeRefreshLayout.setOnRefreshListener {
            if (binding.swipeRefreshLayout.isEnabled)
                getData()
            else
                binding.swipeRefreshLayout.isRefreshing = false
        }

//        binding.pictureRecycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
//            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
//                super.onScrollStateChanged(recyclerView, newState)
//
//                when (newState) {
//                    RecyclerView.SCROLL_STATE_IDLE -> {
//                        // The RecyclerView is not currently scrolling
//                        // Add your code to handle this state
//                        Log.e("RecyclerViewScrollTag", "List is not scrolling")
//                        setSwipeRefreshEnabled(true)
//                    }
//
//                    RecyclerView.SCROLL_STATE_DRAGGING -> {
//                        // The RecyclerView is currently being dragged by user
//                        // Add your code to handle this state
//                        setSwipeRefreshEnabled(false)
//                        Log.e("RecyclerViewScrollTag", "List is scroll")
//                    }
//
//                    RecyclerView.SCROLL_STATE_SETTLING -> {
//                        // The RecyclerView is currently settling into a final position
//                        // Add your code to handle this state
//                        setSwipeRefreshEnabled(true)
//                        Log.e("RecyclerViewScrollTag", "List is settling into a final position")
//                    }
//                }
//            }
//        })
    }

    private fun setData() {
        Log.e("gettingListPhoto", "Data is show")
        isUpadteList = false
        binding.swipeRefreshLayout.isRefreshing = false
        enableScroll()
        if (pictureAdapter != null) notifyAdapter() else initAdapter()
//        RxBus.getInstance().post(CountShowEvent())
        setEmptyData()
    }


    private fun setEmptyData() {
        if (pictures != null && pictures.size != 0) {
            binding.pictureRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
        } else {
            binding.pictureRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
        }
    }

    private fun initAdapter() {
        setRvLayoutManager()
        pictureAdapter = PictureAdapter(activity, pictures, clickListener = {
            if (pictures[it] is PictureData) {
                val pictureData = pictures[it] as PictureData
                if (pictureData.isCheckboxVisible && !isCheckSearchOn) {
                    pictureData.isSelected = !pictureData.isSelected
                    pictureAdapter?.notifyItemChanged(it)
                    setSelectedFile()
                } else {
                    val dataList = ArrayList<PictureData>()
                    var displayPos = 0
                    for (i in pictures.indices) {
                        if (pictures[i] is PictureData) {
                            dataList.add(pictures[i] as PictureData)
                            if (it == i) {
                                displayPos = dataList.size - 1
                            }
                        }
                    }
                    Constant.displayImageList = ArrayList()
                    Constant.displayImageList.addAll(dataList)
                    val intent = Intent(activity, ImageViewerActivity::class.java)
                    intent.putExtra(Constant.EXTRA_DISPLAY_POS, displayPos)
                    startActivity(intent)
                    selectAlbum()
                }
            }
        }, longClickListener = {
//            binding.swipeRefreshLayout.isRefreshing = false
//            binding.swipeRefreshLayout.isEnabled = false
            if (!isCheckSearchOn) {
                if (pictures[it] is PictureData) {
                    val pictureData = pictures[it] as PictureData
                    for (i in pictures.indices) {
                        if (pictures[i] != null)
                            if (pictures[i] is AlbumData) {
                                val model = pictures[i] as AlbumData
                                model.isCheckboxVisible = true
                            } else if (pictures[i] is PictureData) {
                                val model = pictures[i] as PictureData
                                model.isCheckboxVisible = true
                            }
                    }
                    pictureData.isCheckboxVisible = true
                    pictureData.isSelected = true
                    notifyAdapter()
                    setSelectedFile()
                }
            }
        }, headerSelectListener = {
            if (pictures[it] is AlbumData) {
                val albumData = pictures[it] as AlbumData
                val isSelectAll = !albumData.isSelected
                albumData.isSelected = isSelectAll
                var pos = it + 1
                while (pos < pictures.size) {
                    if (pictures[pos] is PictureData) {
                        val model = pictures[pos] as PictureData
                        model.isSelected = isSelectAll
                        pos++
                    } else if (pictures[pos] is AlbumData) {
                        break
                    }
                }
                notifyAdapter()
                setSelectedFile()
            }
        })


        binding.pictureRecycler.adapter = pictureAdapter

//        val snapHelper: SnapHelper = LinearSnapHelper()
//        snapHelper.attachToRecyclerView(binding.pictureRecycler)
    }

    fun setRvLayoutManager() {
        val gridCount = preferences.getGridCount()
        val gridLayoutManager =
            GridLayoutManager(getActivity(), gridCount, RecyclerView.VERTICAL, false)
        binding.pictureRecycler.layoutManager = gridLayoutManager
        gridLayoutManager.spanSizeLookup = object : SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                if (position >= 0 && position < pictures.size) {
                    return if (pictureAdapter!!.getItemViewType(position) === pictureAdapter!!.ITEM_HEADER_TYPE) {
                        gridCount
                    } else 1
                } else {
                    return 1
                }
            }
        }
    }

    private fun setSelectedFile() {
        var selected = 0
        var allItemCount = 0

        var currentHeaderPos = -1
        var photosCount = 0
        var photosSelectCount = 0

        for (i in pictures.indices) {
            if (pictures[i] is AlbumData) {
                if (i != currentHeaderPos) {
                    if (currentHeaderPos != -1) {
                        val model = pictures[currentHeaderPos] as AlbumData
                        model.isSelected = photosCount == photosSelectCount
                        photosCount = 0
                        photosSelectCount = 0
                        pictureAdapter?.notifyItemChanged(currentHeaderPos)
                    }
                    currentHeaderPos = i
                }
            } else if (pictures[i] is PictureData) {
                val model = pictures[i] as PictureData
                allItemCount++
                photosCount++
                if (model.isSelected) {
                    selected++
                    photosSelectCount++
                }
            }
            if (i == pictures.size - 1) {
                if (currentHeaderPos != -1) {
                    val model = pictures[currentHeaderPos] as AlbumData
                    model.isSelected = photosCount == photosSelectCount
                    photosCount = 0
                    photosSelectCount = 0
                    pictureAdapter?.notifyItemChanged(currentHeaderPos)
                }
            }
        }


//        if (selected == 0) {
//            longClickListener(false, selected, false)
//            setClose()
//        } else {
//            longClickListener(true, selected, allItemCount == selected)
//        }
        longClickListener(true, selected, allItemCount == selected)
        binding.swipeRefreshLayout.isEnabled = false
//        binding.swipeRefreshLayout.isEnabled = selected == 0
        selectedItem = selected
    }

    public fun setSwipeRefreshEnabled(isEnabled: Boolean) {
        binding.swipeRefreshLayout.isEnabled = isEnabled
    }

    fun setSelectClick(isSelectAll: Boolean) {
//        if (isSelectAll) {
        var selected = 0
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    model.isSelected = isSelectAll
                } else if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    model.isSelected = isSelectAll
                    if (isSelectAll)
                        selected++

                }
        }
        notifyAdapter()
        longClickListener(true, selected, isSelectAll)
        selectedItem = selected
//        } else {
//            longClickListener(false, 0, false)
//            setClose()
//        }
    }

    fun setCloseToolbar() {
        setClose()
        longClickListener(false, 0, false)
    }

    private fun setClose() {
        Log.e("", "setClose==>> pictures size ${pictures.size} ")
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    model.isSelected = false
                    model.isCheckboxVisible = false
                    Log.e("", "setClose==>> AlbumData selection false")
                } else if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    model.isCheckboxVisible = false
                    model.isSelected = false
                    Log.e("", "setClose==>> PictureData selection false")
                }
        }
        binding.swipeRefreshLayout.isEnabled = true
        notifyAdapter()
        selectedItem = 0
    }

    fun shareImages() {
        if (selectedItem == 0) {
            Toast.makeText(
                activity,
                activity.getString(R.string.PleaseSelectImage),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            val uris = ArrayList<Uri>()
            for (i in pictures.indices) {
                if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    if (model.isSelected) {
                        val uri = FileProvider.getUriForFile(
                            activity,
                            activity.packageName + ".provider",
                            File(model.filePath)
                        )
                        uris.add(uri)
                    }
                }
            }
            Utils().shareFilesList(activity, uris)
        }
    }

    fun setHideData() {
        if (selectedItem == 0) {
            Toast.makeText(
                activity,
                activity.getString(R.string.PleaseSelectImage),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            val hideDialog = ConfirmationDialog(
                activity,
                getString(R.string.Private),
                getString(R.string.hide_msg),
                getString(R.string.hide),
                positiveBtnClickListener = {
                    hidePhoto()
                })
            hideDialog.show(childFragmentManager, hideDialog.tag)
        }
    }

    fun showDeleteDialog() {
        if (selectedItem == 0) {
            Toast.makeText(
                activity,
                activity.getString(R.string.PleaseSelectImage),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            val deleteDialog = DeleteDialog(
                activity,
                getString(R.string.selected_delete_msg),
                positiveBtnClickListener = {
                    deletePhoto()
                })
            deleteDialog.show(childFragmentManager, deleteDialog.tag)
        }
    }

    fun showAddAlbumDialog(albumList: ArrayList<AlbumData>, isCopy: Boolean) {
        if (selectedItem == 0) {
            Toast.makeText(
                activity,
                activity.getString(R.string.PleaseSelectImage),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            val selectImage: ArrayList<PictureData> = ArrayList()
            for (i in pictures.indices) {
                if (pictures[i] != null)
                    if (pictures[i] is PictureData) {
                        val model: PictureData = pictures[i] as PictureData
                        if (model.isSelected) {
                            selectImage.add(model)
                        }
                    }
            }
            val addAlbumDialog =
                SelectAlbumDialog(activity, albumList, isCopy, selectPathListener = { selectPath ->
                    setCopyMove(isCopy, selectPath, selectImage)
                }, createAlbumListener = {
                    val createDialog = CreateAlbumDialog(activity, createPathListener = {
                        setCopyMove(isCopy, it, selectImage)
                    })
                    createDialog.show(childFragmentManager, createDialog.tag)
                })
            addAlbumDialog.show(childFragmentManager, addAlbumDialog.tag)
        }
    }

    private fun setCopyMove(
        isCopy: Boolean,
        selectPath: String,
        selectImage: java.util.ArrayList<PictureData>
    ) {
        if (isCopy)
            Utils().copyFiles(
                activity,
                selectPath,
                selectImage,
                selectedItem,
                copyListener = {
                    Toast.makeText(
                        getActivity(),
                        getString(R.string.copy_successfully),
                        Toast.LENGTH_SHORT
                    ).show()
                    selectedItem = 0
                    longClickListener(false, 0, false)
                    setClose()
                })
        else
            Utils().moveFiles(
                activity,
                selectPath,
                selectImage,
                selectedItem,
                copyListener = {
                    Toast.makeText(
                        getActivity(),
                        getString(R.string.move_successfully),
                        Toast.LENGTH_SHORT
                    ).show()
                    selectedItem = 0
                    longClickListener(false, 0, false)
                    setClose()
                })

    }

    private fun hidePhoto() {
        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }

        Utils().hideFiles(activity, selectImage, selectedItem, hideListener = {
            Toast.makeText(
                getActivity(),
                getString(R.string.hide_successfully),
                Toast.LENGTH_SHORT
            ).show()
            selectedItem = 0
            longClickListener(false, 0, false)
            setClose()
        })
    }

    @SuppressLint("CheckResult")
    private fun deletePhoto() {
        val deleteList = ArrayList<String>()
        val bindingDialog = DialogDeleteProgressBinding.inflate(layoutInflater)
        val dialog = Dialog(activity, R.style.Dialog)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(bindingDialog.root)
        dialog.setCanceledOnTouchOutside(false)
        dialog.window?.setGravity(Gravity.BOTTOM)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        bindingDialog.progressBar.max = selectedItem

        activity.runOnUiThread {
            bindingDialog.txtProgressCount.text = deleteList.size.toString() + "/" + selectedItem
            bindingDialog.progressBar.progress = deleteList.size
        }
        dialog.show()

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(activity)
            for (i in pictures.indices) {
                if (pictures[i] != null) if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    if (model.isSelected) {
                        activity.runOnUiThread {
                            bindingDialog.txtTitle.text = model.fileName
                        }

                        val isDelete = Utils().deleteFile(activity, model.filePath, dataBase)
                        if (isDelete) {
                            deleteList.add(model.filePath)
                            activity.runOnUiThread {
                                bindingDialog.txtProgressCount.text =
                                    deleteList.size.toString() + "/" + selectedItem
                                bindingDialog.progressBar.progress = deleteList.size
                            }
                        }
                    } else {
                        model.isCheckboxVisible = false
                    }
                } else if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    model.isSelected = false
                    model.isCheckboxVisible = false
                }
            }

            var i = 0
            while (i < pictures.size) {
                if (pictures[i] != null)
                    if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false

                    } else if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        if (model.isSelected) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is AlbumData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                        } else {
                            model.isSelected = false
                            model.isCheckboxVisible = false
                        }
                    }
                i++
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                activity.runOnUiThread {
                    if (dialog.isShowing)
                        dialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
            .subscribe { _: Boolean? ->
                activity.runOnUiThread {
                    if (dialog.isShowing)
                        dialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
    }

    private fun setBeforeDeleteUpdate(deleteList: ArrayList<String>) {
        EventBus.getDefault().post(DeleteEvent(0, deleteList))
        selectedItem = 0
        notifyAdapter()
//        enableScroll()
        binding.swipeRefreshLayout.isEnabled = true
        longClickListener(false, 0, false)
        setEmptyData()
        Toast.makeText(
            getActivity(),
            getString(R.string.Delete_successfully),
            Toast.LENGTH_SHORT
        ).show()
        deleteMainList(deleteList)
    }


    private fun getData() {
//        binding.pictureRecycler.isNestedScrollingEnabled = false
//        ViewCompat.setNestedScrollingEnabled( binding.pictureRecycler, false)
//        binding.pictureRecycler.isLayoutFrozen = true
        disableScroll()
        isUpadteList = true
        binding.swipeRefreshLayout.isRefreshing = true
        Glide.get(activity).clearMemory()
        Observable.fromCallable {
            Glide.get(activity).clearDiskCache()
            allList.clear()
            allBackList.clear()
//            videoCount = 0
//            imageCount = 0
            getImages()
            getVideos()

            true
        }.subscribeOn(Schedulers.io())
            .doOnError { throwable: Throwable? ->
                activity.runOnUiThread {
                    setFilterData()
//                    getFindCount()
                }
            }
            .subscribe { result: Boolean? ->
                activity.runOnUiThread {
                    setFilterData()
//                    getFindCount()
                }
            }
    }

    private fun disableScroll() {
        binding.pictureRecycler.suppressLayout(true)
    }

    private fun enableScroll() {
        binding.pictureRecycler.suppressLayout(false)
    }


    private fun getFindCount() {
        var imageCount = 0
        var videoCount = 0

        try {
            if (allBackList.size != 0) {
                val videoList = allBackList.filter { it.isVideo }
                val imageList = allBackList.filter { !it.isVideo }

                if (videoList.isNotEmpty())
                    videoCount = videoList.size

                if (imageList.isNotEmpty())
                    imageCount = imageList.size
            }
        } catch (e: Exception) {

        }
        imageVideoCount(imageCount, videoCount)
    }

    var isUpadteList = false
    fun setFilterData() {
        isUpadteList = true
        disableScroll()
        binding.swipeRefreshLayout.isRefreshing = true
        GlobalScope.launch(Dispatchers.IO) {
            setFilter()
            activity.runOnUiThread {
                setData()
                getFindCount()
            }
        }

//        Observable.fromCallable {
//            setFilter()
//            true
//        }.subscribeOn(Schedulers.io())
//            .doOnError { _: Throwable? ->
//                activity.runOnUiThread { setData() }
//            }
//            .subscribe { _: Boolean? ->
//                activity.runOnUiThread { setData() }
//            }
    }

    private fun setFilter() {
        Log.e("", "imageVideo size==>> " + allList.size)
        val sortType = preferences.getSortType()
        val sortOrder = preferences.getSortOrder()

        Collections.sort(allList, Comparator { p1, p2 ->
            if (sortType == Constant.SORT_NAME) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.fileName.compareTo(p2.fileName, true)
                else
                    p2.fileName.compareTo(p1.fileName, true)
            } else if (sortType == Constant.SORT_PATH) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.filePath.compareTo(p2.filePath, true)
                else
                    p2.filePath.compareTo(p1.filePath, true)
            } else if (sortType == Constant.SORT_SIZE) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.fileSize.compareTo(p2.fileSize)
                else
                    p2.fileSize.compareTo(p1.fileSize)
            } else if (sortType == Constant.SORT_LAST_MODIFIED) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.date.compareTo(p2.date)
                else
                    p2.date.compareTo(p1.date)
            } else if (sortType == Constant.SORT_DATE_TAKEN) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.dateTaken.compareTo(p2.dateTaken)
                else
                    p2.dateTaken.compareTo(p1.dateTaken)
            } else
                p2.date.compareTo(p1.date)
        })
        Collections.sort(allBackList, Comparator { p1, p2 ->
            if (sortType == Constant.SORT_NAME) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.fileName.compareTo(p2.fileName, true)
                else
                    p2.fileName.compareTo(p1.fileName, true)
            } else if (sortType == Constant.SORT_PATH) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.filePath.compareTo(p2.filePath, true)
                else
                    p2.filePath.compareTo(p1.filePath, true)
            } else if (sortType == Constant.SORT_SIZE) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.fileSize.compareTo(p2.fileSize)
                else
                    p2.fileSize.compareTo(p1.fileSize)
            } else if (sortType == Constant.SORT_LAST_MODIFIED) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.date.compareTo(p2.date)
                else
                    p2.date.compareTo(p1.date)
            } else if (sortType == Constant.SORT_DATE_TAKEN) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.dateTaken.compareTo(p2.dateTaken)
                else
                    p2.dateTaken.compareTo(p1.dateTaken)
            } else
                p2.date.compareTo(p1.date)
        })

        if (!isStopSearch)
            setList()
    }

    private fun setList() {
        pictures.clear()
        activity.runOnUiThread { notifyAdapter() }

        if (isSearch)
            activity.runOnUiThread { notifyAdapter() }

        val dateWisePictures = LinkedHashMap<String, ArrayList<PictureData>>()
        val format = SimpleDateFormat("dd MMM yyyy")
//        val format = SimpleDateFormat("EEEE, MMM dd yyyy")

        if (allList.size != 0) {
            for (pictureData in allList) {
                val strDate = format.format(pictureData.date)
                if (isStopSearch) {
                    break
                } else {
                    var imagesData1: ArrayList<PictureData> = ArrayList()
                    if (dateWisePictures.containsKey(strDate)) {
                        val list: ArrayList<PictureData>? = dateWisePictures[strDate]
                        if (!list.isNullOrEmpty())
                            imagesData1.addAll(list)
                    } else {
                        imagesData1 = ArrayList()
                    }
                    imagesData1.add(pictureData)
                    dateWisePictures[strDate] = imagesData1
                }
            }

            val keys: Set<String> = dateWisePictures.keys
            val listKeys = ArrayList(keys)

            for (i in listKeys.indices) {
                if (isStopSearch) {
                    break
                } else {
                    val imagesData = dateWisePictures[listKeys[i]]
                    if (imagesData != null && imagesData.size != 0) {
                        val bucketData = AlbumData(listKeys[i], imagesData)
                        pictures.add(bucketData)
                        pictures.addAll(imagesData)
                    }
                }
            }
        }
    }

    private fun notifyAdapter() {
        if (pictureAdapter != null)
            pictureAdapter?.notifyDataSetChanged()
//binding.pictureRecycler.post { pictureAdapter?.notifyDataSetChanged() }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onUpdateFavoriteEvent(event: UpdateFavoriteEvent) {
        updateFavoriteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDisplayDeleteEvent(event: DisplayDeleteEvent) {
        displayDeleteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDeleteEvent(event: DeleteEvent) {
        deleteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onCopyMoveEvent(event: CopyMoveEvent) {
        copyMoveEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onRestoreDataEvent(event: RestoreDataEvent) {
        restoreEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onRenameEvent(event: RenameEvent) {
        renameEvent(event)
    }

    private fun updateFavoriteEvent(event: UpdateFavoriteEvent) {
        if (event.path.isNotEmpty()) {
            if (pictures.isNotEmpty()) {
                for (picture in pictures) {
                    if (picture is PictureData) {
                        val pictureData: PictureData = picture as PictureData
                        if (pictureData.filePath == event.path) {
                            pictureData.isFavorite = event.isFavorite
                            break
                        }
                    }
                }
                notifyAdapter()
            }
            if (allList.isNotEmpty())
                for (pictureData in allList) {
                    if (pictureData.filePath == event.path) {
                        pictureData.isFavorite = event.isFavorite
                        break
                    }
                }
            if (allBackList.isNotEmpty())
                for (pictureData in allBackList) {
                    if (pictureData.filePath == event.path) {
                        pictureData.isFavorite = event.isFavorite
                        break
                    }
                }
        }
        if (event.unFavoriteList.isNotEmpty()) {
            if (pictures.isNotEmpty()) {
                for (favPath in event.unFavoriteList) {
                    for (picture in pictures) {
                        if (picture is PictureData) {
                            val pictureData: PictureData = picture as PictureData
                            if (pictureData.filePath == favPath) {
                                pictureData.isFavorite = event.isFavorite
                                break
                            }
                        }
                    }
                }
                notifyAdapter()
            }
            if (allList.isNotEmpty())
                for (favPath in event.unFavoriteList) {
                    for (pictureData in allList) {
                        if (pictureData.filePath == favPath) {
                            pictureData.isFavorite = event.isFavorite
                            break
                        }
                    }
                }

            if (allBackList.isNotEmpty())
                for (favPath in event.unFavoriteList) {
                    for (pictureData in allBackList) {
                        if (pictureData.filePath == favPath) {
                            pictureData.isFavorite = event.isFavorite
                            break
                        }
                    }
                }
        }
    }

    private fun deleteMainList(deleteList: ArrayList<String>) {
        if (deleteList.size != 0) {
//            for (path in deleteList) {
//                for (pictureData in filterList) {
//                    if (pictureData.getFilePath().equalsIgnoreCase(path)) {
//                        filterList.remove(pictureData)
//                        break
//                    }
//                }
//            }
            for (path in deleteList) {
                for (pictureData in allList) {
                    if (pictureData.filePath == path) {
                        allList.remove(pictureData)
                        break
                    }
                }
            }
            for (path in deleteList) {
                for (pictureData in allBackList) {
                    if (pictureData.filePath == path) {
                        allBackList.remove(pictureData)
                        break
                    }
                }
            }

            getFindCount()
        }
    }


    private fun displayDeleteEvent(event: DisplayDeleteEvent) {
        if (event.deleteList.isNotEmpty())
            if (pictures.isNotEmpty()) {
                updateDeleteImageData(event.deleteList)
                deleteMainList(event.deleteList)
            }
    }

    private fun restoreEvent(event: RestoreDataEvent) {

        if (event.restoreList.isNotEmpty()) {
//            if (pictures.isNotEmpty()) {
            val list: ArrayList<String> = ArrayList()
            val imageList: ArrayList<String> = ArrayList()
            val favList = preferences.getFavoriteList()

            for (restoreData in event.restoreList) {
                list.add(restoreData.deletedPath)
                imageList.add(restoreData.path)
            }

            updateDeleteImageData(list)
            deleteMainList(list)

            for (i in imageList.indices) {
                val file1 = File(imageList[i])
                if (file1.exists()) {
                    val pictureData = PictureData(
                        file1.path,
                        file1.name,
                        file1.parentFile.name,
                        file1.lastModified(),
                        file1.lastModified(),
                        file1.length()
                    )
                    pictureData.isFavorite = favList.contains(file1.path)
                    if (Utils().isVideoFile(file1.path)) {
                        pictureData.isVideo = true
                    }
                    allList.add(pictureData)
                    allBackList.add(pictureData)
                }
            }
            setFilterData()
            getFindCount()
        }

    }

    private fun renameEvent(event: RenameEvent) {
        if (event.oldPath.isNotEmpty() && event.renamePath.isNotEmpty()) {
            if (pictures.isNotEmpty()) {
                for (picture in pictures) {
                    if (picture is PictureData) {
                        val model = pictures as PictureData
                        if (model.filePath == event.oldPath) {
                            model.filePath = event.renamePath
                            model.fileName = File(event.renamePath).name
                            model.fileSize = File(event.renamePath).length()
                            break
                        }
                    }
                }
            }
            pictureAdapter?.notifyDataSetChanged()

            if (allBackList.isNotEmpty()) {
                for (pictureData in allBackList) {
                    if (pictureData.filePath == event.oldPath) {
                        pictureData.filePath = event.renamePath
                        pictureData.fileName = File(event.renamePath).name
                        pictureData.fileSize = File(event.renamePath).length()
                        break
                    }
                }

                for (pictureData in allList) {
                    if (pictureData.filePath == event.oldPath) {
                        pictureData.filePath = event.renamePath
                        pictureData.fileName = File(event.renamePath).name
                        pictureData.fileSize = File(event.renamePath).length()
                        break
                    }
                }

            }
        }

    }

    private fun copyMoveEvent(event: CopyMoveEvent) {
        if (event.copyMoveList.isNotEmpty()) {
            val imageList: ArrayList<String> = ArrayList()
            imageList.addAll(event.copyMoveList)

            val favList = preferences.getFavoriteList()
            val file = File(event.albumPath)

            if (event.deleteList.isNotEmpty())
                if (pictures.isNotEmpty()) {
                    deleteMainList(event.deleteList)
                }

            if (file.exists()) {
                for (i in imageList.indices) {
                    val file1 = File(imageList[i])
                    if (file1.exists()) {
                        val pictureData = PictureData(
                            file1.path,
                            file1.name,
                            file1.parentFile.name,
                            file1.lastModified(),
                            file1.lastModified(),
                            file1.length()
                        )
                        pictureData.isFavorite = favList.contains(file1.path)
                        if (Utils().isVideoFile(file1.path)) {
                            pictureData.isVideo = true
                        }
                        if (!isUpadteList) {
                            allList.add(pictureData)
                            allBackList.add(pictureData)
                        }
                    }
                }
                if (!isUpadteList) {
                    setFilterData()
                    getFindCount()
                }
            }
        }
    }

    private fun deleteEvent(event: DeleteEvent) {
        if (event.deleteList.isNotEmpty() && event.pos != 0)
            if (pictures.isNotEmpty()) {
                updateDeleteImageData(event.deleteList)
                deleteMainList(event.deleteList)
            }
    }

    private fun updateDeleteImageData(deleteList: ArrayList<String>) {
        if (pictures.isNotEmpty()) {
            for (d in deleteList.indices) {
                var i = 0
                while (i < pictures.size) {
                    if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        if (model.filePath == deleteList[d]) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is AlbumData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                            if (d == deleteList.size - 1) {
                                break
                            }
                        }
                    }
                    i++
                }
            }
            notifyAdapter()
            setEmptyData()
        }
    }

    fun setSearch(searchText: String) {
        val strSearch = searchText.lowercase(Locale.getDefault())
        if (isSearch) isStopSearch = true

        Observable.fromCallable<Boolean> {
            isSearch = true
            allList.clear()
            if (strSearch.isEmpty()) {
                allList.addAll(allBackList)
            } else {
                var list = allBackList.filter {
                    it.fileName.lowercase(Locale.getDefault()).contains(strSearch)
                }

                if (!isStopSearch) {
                    if (!list.isNullOrEmpty())
                        allList.addAll(list)
                }
            }
            if (!isStopSearch)
                setList()

            true
        }.subscribeOn(Schedulers.io())
            .doOnError { throwable: Throwable? ->
                requireActivity().runOnUiThread {
                    isSearch = false
                    isStopSearch = false
                    setData()
                }
            }
            .subscribe { result: Boolean? ->
                requireActivity().runOnUiThread {
                    isStopSearch = false
                    isSearch = false
                    setData()
                }
            }
    }

//    private fun getImages() {
//        Log.e("gettingListPhoto", "getImages")
//        val mCursor: Cursor?
//        val folderList: MutableList<String> = ArrayList<String>()
////        folderList.addAll(preferencesManager.getExcludeFolderList())
//        val favList: ArrayList<String> = ArrayList()
//        favList.addAll(preferences.getFavoriteList())
//        var mediaType = "image/*"
//
//        val projection = arrayOf(
//            MediaStore.MediaColumns.DATA,
//            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
//            MediaStore.MediaColumns.DATE_MODIFIED,
//            MediaStore.MediaColumns.DATE_TAKEN,
//            MediaStore.MediaColumns.DISPLAY_NAME,
//            MediaStore.MediaColumns.SIZE
//        )
//
//        val selection = "${MediaStore.MediaColumns.MIME_TYPE}=?"
//        val selectionArgs = arrayOf(mediaType)
//
//        val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
//            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
//        } else {
//            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
//        }
//
//        activity.contentResolver.query(
//            uri,
//            projection,
//            selection,
//            selectionArgs,
//            "${MediaStore.MediaColumns.DATE_ADDED} DESC"
//        )?.use { cursor ->
//            val pathColumn = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA)
//            val bucketColumn =
//                cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME)
//            val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
//            val dateColumn = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)
//            val dateTakenColumn = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)
//            val sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
////            try {
//            while (cursor.moveToNext()) {
//                val path = cursor.getString(pathColumn)
//                val bucketName = cursor.getString(bucketColumn)
//                val title = cursor.getString(nameColumn)
//                var d = cursor.getLong(dateColumn)
//                var dt = cursor.getLong(dateTakenColumn)
//                val fileSizeLength = cursor.getLong(sizeColumn)
//
//
//                var bucketPath = ""
//                bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
//
//                if (!folderList.contains(bucketPath) && !bucketName.isNullOrEmpty()) {
//                    d *= 1000
//                    dt *= 1000
//                    if (dt == 0L)
//                        dt = d
//
//                    val pictureData =
//                        PictureData(path, title, bucketName, d, dt, fileSizeLength, false)
//                    pictureData.isFavorite = favList.contains(path)
//                    allList.add(pictureData)
//                    allBackList.add(pictureData)
//                }
//            }
//        }
////        } catch (e: Exception) {
////            e.printStackTrace()
////        }
//
//    }

    private fun getImages() {
        Log.e("gettingListPhoto", "getImages")
        val mCursor: Cursor?
        val folderList: MutableList<String> = ArrayList<String>()
//        folderList.addAll(preferencesManager.getExcludeFolderList())
        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())
        try {
            val BUCKET_DISPLAY_NAME: String
            BUCKET_DISPLAY_NAME = MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
            val projection = arrayOf(
                MediaStore.Images.Media.DATA,
                BUCKET_DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_MODIFIED,
                MediaStore.MediaColumns.DATE_TAKEN,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.SIZE,
            )
            val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            } else {
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            }

            mCursor = activity.contentResolver.query(
                uri,  // Uri
                projection,  // Projection
                null,
                null,
                MediaStore.MediaColumns.DATE_MODIFIED + " DESC"
            )
            if (mCursor != null) {
                mCursor.moveToFirst()
                val photoDataArrayList: ArrayList<PictureData> = ArrayList<PictureData>()
                mCursor.moveToFirst()
                while (!mCursor.isAfterLast) {
                    //2sec
                    val path =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))
                    val title =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME))
                    var bucketPath = ""
                    bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
                    val bucketName =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(BUCKET_DISPLAY_NAME))

                    val fileSizeLength =
                        mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))

//                    val width = mCursor.getInt(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.WIDTH))
//                    val height = mCursor.getInt(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.HEIGHT))

                    Log.e(
                        "getImages",
                        "fileSize $fileSizeLength title $title "
                    )

                    if (!folderList.contains(bucketPath) && !bucketName.isNullOrEmpty()) {
                        var d =
                            mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED))
                        d *= 1000
                        var dt =
                            mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))
                        dt *= 1000
                        if (dt == 0L)
                            dt = d

                        val pictureData =
                            PictureData(path, title, bucketName, d, dt, fileSizeLength, false)
                        pictureData.isFavorite = favList.contains(path)
                        allList.add(pictureData)
                        allBackList.add(pictureData)
//                        imageCount++
                    }
                    mCursor.moveToNext()
                }
                mCursor.close()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun getVideos() {
        Log.e("gettingListPhoto", "getVideos")
        var title: String
        var path: String
        val duration: Int
        val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Video.VideoColumns.DATA,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.VideoColumns.SIZE,
            MediaStore.Video.VideoColumns.DURATION,
            MediaStore.Video.VideoColumns.DATE_MODIFIED,
            MediaStore.Video.VideoColumns.DATE_TAKEN,
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
        )
        val folderList: MutableList<String> = ArrayList<String>()
//        folderList.addAll(preferencesManager.getExcludeFolderList())
        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())
        try {
            val cursor = activity.contentResolver.query(
                uri,
                projection,
                null,
                null,
                MediaStore.Video.VideoColumns.DATE_MODIFIED + " DESC"
            )
            if (cursor != null) {
                duration = cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DURATION)
                cursor.moveToFirst()
                while (!cursor.isAfterLast) {
                    path =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA))
                    title =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME))
                    val bucketName =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME))
                    var bucketPath = ""
                    bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
                    if (!folderList.contains(bucketPath)) {
                        var d =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DATE_MODIFIED))
                        d *= 1000
                        val fileSizeLength =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
                        var dt =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))
                        dt *= 1000
                        if (dt == 0L)
                            dt = d
                        val pictureData = PictureData(
                            path,
                            title,
                            bucketName,
                            d,
                            dt,
                            fileSizeLength,
                            true,
                            cursor.getLong(duration)
                        )
                        pictureData.isFavorite = favList.contains(path)
                        pictureData.isVideo = true
                        allList.add(pictureData)
                        allBackList.add(pictureData)
//                        videoCount++
                    }
                    cursor.moveToNext()
                }
                cursor.close()
            }
        } catch (exp: java.lang.Exception) {
            exp.printStackTrace()
        }
    }

}