package com.gallery.photo.image.video.duplicat_function.model_class

data class DataItem(
    var isAudioPlaying : Boolean= false,
    var filePath: String? = null,
    var fileType: String? = null,
    var fileName: String? = null,
    var groupId : Int = 0,
    var isSelected : Boolean = false,
    var fileSize: String? = null,
    var fileSizeLong: Long = 0L,
    var fileDate: Long = 0L,
) : com.gallery.photo.image.video.duplicat_function.model_class.Item {}