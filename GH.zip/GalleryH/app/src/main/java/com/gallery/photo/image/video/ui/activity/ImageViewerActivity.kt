package com.gallery.photo.image.video.ui.activity

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.widget.PopupMenu
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.viewpager2.widget.ViewPager2
import com.adconfig.AdsConfig
import com.adconfig.adsutil.utils.isInterstitialAdShow
//import com.ads.module.adutills.AdLoaderClass
//import com.ads.module.adutills.ClickCallback
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.database.AppDatabase
import com.gallery.photo.image.video.database.HiddenData
import com.gallery.photo.image.video.databinding.ActivityImageViewerBinding
import com.gallery.photo.image.video.databinding.PopMenuHomeBinding
import com.gallery.photo.image.video.databinding.PopMenuImageBinding
import com.gallery.photo.image.video.ui.activity.edit.CompressActivity
import com.gallery.photo.image.video.ui.activity.edit.EditImageActivity
import com.gallery.photo.image.video.ui.adapter.ImageViewerAdapter
import com.gallery.photo.image.video.ui.dialog.ConfirmationDialog
import com.gallery.photo.image.video.ui.dialog.CreateAlbumDialog
import com.gallery.photo.image.video.ui.dialog.DeleteDialog
import com.gallery.photo.image.video.ui.dialog.DetailsDialog
import com.gallery.photo.image.video.ui.dialog.RenameDialog
import com.gallery.photo.image.video.ui.dialog.SelectAlbumDialog
import com.gallery.photo.image.video.ui.event.DisplayDeleteEvent
import com.gallery.photo.image.video.ui.event.RestoreDataEvent
import com.gallery.photo.image.video.ui.event.UpdateFavoriteEvent
import com.gallery.photo.image.video.ui.model.AlbumData
import com.gallery.photo.image.video.ui.model.PictureData
import com.gallery.photo.image.video.ui.model.RestoreData
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.MyApplication
import com.gallery.photo.image.video.utils.Preferences
import com.gallery.photo.image.video.utils.Utils
import com.skydoves.powermenu.CircularEffect
import com.skydoves.powermenu.MenuAnimation
import com.skydoves.powermenu.OnDismissedListener
import com.skydoves.powermenu.OnMenuItemClickListener
import com.skydoves.powermenu.PowerMenu
import com.skydoves.powermenu.PowerMenuItem
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import java.io.File
import java.text.SimpleDateFormat


class ImageViewerActivity : BaseActivity() {

    lateinit var binding: ActivityImageViewerBinding
    var displayImageList: ArrayList<PictureData> = ArrayList()
    lateinit var adapter: ImageViewerAdapter
    lateinit var preferences: Preferences
    var selectedPosition = 0
    val format = SimpleDateFormat("dd MMM yyyy")
    val formatTime = SimpleDateFormat("hh:mm aa")
    var favList: ArrayList<String> = ArrayList()
    var isFromPrivate = false
    var isFromRecentlyDelete = false
    var slideShowTime = 3000
    var isSlideShow = false
    var mHandler = Handler(Looper.myLooper()!!)
    var isFileExists: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityImageViewerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        intView()
    }

    private fun intView() {
        val bundle2 = Bundle()
        bundle2.putString("ImageDisplay", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_activity, bundle2)

        preferences = Preferences(this)
        selectedPosition = intent.getIntExtra(Constant.EXTRA_DISPLAY_POS, 0)
        isFromPrivate = intent.getBooleanExtra(Constant.EXTRA_IS_OPEN_PRIVATE, false)
        isFromRecentlyDelete = intent.getBooleanExtra(Constant.EXTRA_IS_OPEN_RECENTLY_DELETE, false)
        displayImageList.addAll(Constant.displayImageList)

        setBottomVisible()

        binding.btnFavourite.visibility = if (isFromPrivate) View.GONE else View.VISIBLE
        binding.btnUnhide.visibility = if (isFromPrivate) View.VISIBLE else View.GONE

        getFavList()
        viewPagerSetup()
        intListener()
    }

    private fun setBottomVisible() {
        binding.loutBottomMainOption.visibility =
            if (isFromRecentlyDelete) View.GONE else View.VISIBLE
        binding.loutReCentDeleteOption.visibility =
            if (isFromRecentlyDelete) View.VISIBLE else View.GONE
    }


    private fun startSlideShow() {
        isSlideShow = true
        binding.loutToolbar.setVisibility(View.GONE)
        binding.loutBottomMainOption.visibility = View.GONE
        binding.loutReCentDeleteOption.visibility = View.GONE

        if (mHandler != null) mHandler.removeCallbacks(slideShowTask)
        mHandler.postDelayed(slideShowTask, slideShowTime.toLong())
    }

    private val slideShowTask: Runnable = object : Runnable {
        override fun run() {
            var pos: Int = binding.viewPager.currentItem
            if (pos < displayImageList.size - 1) {
                pos++
                binding.viewPager.currentItem = pos
                mHandler.postDelayed(this, slideShowTime.toLong())
            } else {
                stopSlideShow()
            }
        }
    }

    private fun stopSlideShow() {
        isSlideShow = false
        if (mHandler != null) mHandler.removeCallbacks(slideShowTask)
        binding.loutToolbar.visibility = View.VISIBLE
        setBottomVisible()
    }

    private fun getFavList() {
        favList.clear()
        favList.addAll(preferences.getFavoriteList())
        if (favList.isNotEmpty())
            for (pictureData in displayImageList) {
                pictureData.isFavorite = favList.contains(pictureData.filePath)
            }
    }

    override fun onBackPressed() {

        MyApplication.clickCount++
        if (MyApplication.remoteConfig.getBoolean(Constant.isInterstitialEveryMinute)) {
//            Log.e("ImageViewBackTAG", "if clickEventAtMinute")
            clickEventAtMinute()
        } else {
//            Log.e("ImageViewBackTAG", "else ads show")
            AdsConfig.showInterstitialAd(this) {
                finish()
            }
        }
    }

    private fun clickEventAtMinute() {
        val variableCount = MyApplication.remoteConfig.getString(Constant.InterMinutebeforeCount).toInt()
//        Log.w("msg", "clickEventAtMinute: " + Myapplication.remoteConfig.getString(Constant.InterMinutebeforeCount).toInt())
//        Log.w("msg", "clickEventAtMinute:clickCount " + clickCount)
//        Log.w("msg", "clickEventAtMinute:boolean " + (variableCount <= clickCount))
        if (variableCount >= MyApplication.clickCount) {
//            Log.e("ImageViewBackTAG", "if finish screen")
            finish()
        } else {
            val currentTime = System.currentTimeMillis()
            val elapsedTimeSinceLastClick = currentTime - MyApplication.lastClickTime

//            Log.w("msg", "clickEventAtMinute:currentTime " + currentTime)
//            Log.w("msg", "clickEventAtMinute:elapsedTimeSinceLastClick " + elapsedTimeSinceLastClick)
            if (elapsedTimeSinceLastClick >= MyApplication.clickInterval) {
//                Log.e("ImageViewBackTAG", "else if ads show")
                AdsConfig.showInterstitialAd(this) {
                    finish()
                }
//                AdLoaderClass().showAlwaysInterWithCallback(this, object : ClickCallback {
//                    override fun clickNext() {
//                        finish()
//                    }
//                })
                MyApplication.lastClickTime = currentTime
            } else {
//                Log.e("ImageViewBackTAG", "else else finish screen")
                finish()
            }
        }
    }

    private fun intListener() {
        binding.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.ivInfo.setOnClickListener {
            showDetailsDialog()
        }
        binding.btnEdit.setOnClickListener {
            if (isFileExists) {
                startActivity(
                    Intent(
                        this,
                        EditImageActivity::class.java
                    ).putExtra(
                        Constant.EXTRA_EDIT_IMAGE_PATH,
                        displayImageList[binding.viewPager.currentItem].filePath
                    )
                )
            } else {
                showToastMsg(getString(R.string.corrupted_image_edit))
            }
        }
        binding.btnDelete.setOnClickListener {
            if (isFileExists)
                showDeleteDialog()
            else
                showToastMsg(
                    if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_delete)
                    else getString(R.string.corrupted_image_delete)
                )
        }
        binding.btnUnhide.setOnClickListener {
            if (isFileExists)
                setUnHideData()
            else
                showToastMsg(
                    if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_unhide)
                    else getString(R.string.corrupted_image_unhide)
                )
        }
        binding.btnMore.setOnClickListener {
//            showMenu()
            showDropDown(binding.ivMenuView)
//            getPowerMenu(this, binding.btnMore)
        }
        binding.btnShare.setOnClickListener {
            Utils().shareFile(
                this@ImageViewerActivity,
                displayImageList[binding.viewPager.currentItem].filePath
            )
        }
        binding.btnFavourite.setOnClickListener {
            if (displayImageList[binding.viewPager.currentItem].isFavorite) {
                displayImageList[binding.viewPager.currentItem].isFavorite = false
                setFavImages(binding.viewPager.currentItem)
                setUnFavorite(displayImageList[binding.viewPager.currentItem].filePath)
            } else {
                displayImageList[binding.viewPager.currentItem].isFavorite = true
                setFavImages(binding.viewPager.currentItem)
                setFavorite(displayImageList[binding.viewPager.currentItem].filePath)
            }
        }
        binding.btnRestore.setOnClickListener {
            if (isFileExists) {
                val hideDialog = ConfirmationDialog(
                    this,
                    getString(R.string.restore),
                    getString(R.string.restore_msg_single),
                    getString(R.string.ok),
                    positiveBtnClickListener = {
                        restorePhoto()

                    })
                hideDialog.show(supportFragmentManager, hideDialog.tag)
            } else
                showToastMsg(
                    if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_restore)
                    else getString(R.string.corrupted_image_restore)
                )
        }
        binding.btnRecentDelete.setOnClickListener {
            if (isFileExists) {
                val deleteDialog = ConfirmationDialog(
                    this,
                    getString(R.string.delete_permanently),
                    getString(R.string.permanently_delete_msg_single),
                    getString(R.string.Delete),
                    positiveBtnClickListener = {
                        recentDeletePhoto()
                    }, true
                )
                deleteDialog.show(supportFragmentManager, deleteDialog.tag)
            } else
                showToastMsg(
                    if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_delete)
                    else getString(R.string.corrupted_image_delete)
                )
        }

        binding.btnRename.setOnClickListener {
            if (isFileExists)
                showRenameDialog()
            else
                showToastMsg(
                    if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_rename)
                    else getString(R.string.corrupted_image_rename)
                )
        }
    }

    private fun showToastMsg(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT)
            .show()
    }


    private fun showDropDown(view: View) {
        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopMenuImageBinding.inflate(layoutInflater)
        val popupView = popUpBinding.root
        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        params.setMargins(10, 0, 50, 60)
        popupView.layoutParams = params
        val popupWindow = PopupWindow(
            popupView,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT, true
        )
        popupWindow.animationStyle = R.style.ShowUpAnimation_BR

        popUpBinding.loutMain.setOnClickListener {
            popupWindow.dismiss()
        }
        popUpBinding.menuCopy.visibility = if (isFromPrivate) View.GONE else View.VISIBLE
        popUpBinding.menuMove.visibility = if (isFromPrivate) View.GONE else View.VISIBLE
        popUpBinding.menuPrivate.visibility = if (isFromPrivate) View.GONE else View.VISIBLE
        popUpBinding.menuRename.visibility =
            if (!displayImageList[binding.viewPager.currentItem].isVideo) View.VISIBLE else View.GONE
        popUpBinding.menuCompress.visibility =
            if (!displayImageList[binding.viewPager.currentItem].isVideo) View.VISIBLE else View.GONE
        popUpBinding.menuResize.visibility =
            if (!displayImageList[binding.viewPager.currentItem].isVideo) View.VISIBLE else View.GONE
        popUpBinding.menuSetWallpaper.visibility =
            if (!displayImageList[binding.viewPager.currentItem].isVideo) View.VISIBLE else View.GONE

        if (!displayImageList[binding.viewPager.currentItem].isVideo) {
            val oneMBInBytes = 1000000
            popUpBinding.menuCompress.visibility =
                if (displayImageList[binding.viewPager.currentItem].fileSize > oneMBInBytes) View.VISIBLE else View.GONE
        }

        popupWindow.setBackgroundDrawable(BitmapDrawable())
        popupWindow.isOutsideTouchable = true
        val a = IntArray(2)
        view.getLocationInWindow(a)
        Log.e("showDropDown", "a0==>> ${a[0]} a1==>> ${a[1]} height==>> ${view.height}")
        popupWindow.showAtLocation(view, Gravity.NO_GRAVITY, a[0], a[1] - view.height)
        popupWindow.update()
        popupWindow.showAsDropDown(view)

        popUpBinding.menuCopy.setOnClickListener {
            popupWindow.dismiss()
            if (isFileExists)
                showAddAlbumDialog(Constant.albumList, true)
            else
                showToastMsg(
                    if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_copy)
                    else getString(R.string.corrupted_image_copy)
                )
        }
        popUpBinding.menuMove.setOnClickListener {
            popupWindow.dismiss()
            if (isFileExists)
                showAddAlbumDialog(Constant.albumList, false)
            else
                showToastMsg(
                    if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_move)
                    else getString(R.string.corrupted_image_move)
                )
        }
        popUpBinding.menuSetWallpaper.setOnClickListener {
            popupWindow.dismiss()
            if (isFileExists)
                startActivity(
                    Intent(this@ImageViewerActivity, WallpaperActivity::class.java)
                        .putExtra(
                            Constant.EXTRA_WALL_PAPER,
                            displayImageList[binding.viewPager.currentItem].filePath
                        )
                )
            else
                showToastMsg(getString(R.string.corrupted_image_wallpaper))
        }

        popUpBinding.menuCompress.setOnClickListener {
            popupWindow.dismiss()
            if (isFileExists) {
                val compressDialog = ConfirmationDialog(
                    this,
                    getString(R.string.compress),
                    getString(R.string.compress_msg),
                    getString(R.string.ok),
                    positiveBtnClickListener = {
                        compressActivityResultLauncher.launch(
                            Intent(this, CompressActivity::class.java)
                                .putExtra(
                                    Constant.EXTRA_IMAGE_PATH,
                                    displayImageList[binding.viewPager.currentItem].filePath
                                )
                        )
                    })
                compressDialog.show(supportFragmentManager, compressDialog.tag)
            } else
                showToastMsg(getString(R.string.corrupted_image_compress))
        }
        popUpBinding.menuPrivate.setOnClickListener {
            popupWindow.dismiss()
            if (isFileExists)
                setHideData()
            else
                showToastMsg(
                    if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_hide)
                    else getString(R.string.corrupted_image_hide)
                )
        }
        popUpBinding.menuRename.setOnClickListener {
            popupWindow.dismiss()
            if (isFileExists)
                showRenameDialog()
            else
                showToastMsg(
                    if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_rename)
                    else getString(R.string.corrupted_image_rename)
                )
        }
        popUpBinding.menuResize.setOnClickListener {
            popupWindow.dismiss()
            if (isFileExists)
                showRenameDialog(true)
            else
                showToastMsg(getString(R.string.corrupted_image_resize))
        }
        popUpBinding.menuStartSlideshow.setOnClickListener {
            popupWindow.dismiss()
            startSlideShow()
        }
    }


//
//    private fun showDropDown(view: View) {
//
//        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
//        var popUpBinding = DropDownLayoutBinding.inflate(layoutInflater)
//        val popupView = popUpBinding.root
//        val params = LinearLayout.LayoutParams(
//            ViewGroup.LayoutParams.WRAP_CONTENT,
//            ViewGroup.LayoutParams.WRAP_CONTENT
//        )
//        params.setMargins(10, 0, 50, 0)
//        popupView.layoutParams = params
//        var popupWindow = PopupWindow(
//            popupView,
//            ViewGroup.LayoutParams.WRAP_CONTENT,
//            ViewGroup.LayoutParams.WRAP_CONTENT
//        )
////        binding.imageViewDropDown.rotateView(180f)
//        popupWindow.animationStyle = R.style.popup_window_animation;
//        popupWindow.width = 500
//
////        popupWindow.height = 1500
//        popupWindow.setBackgroundDrawable(BitmapDrawable())
//        popupWindow.isOutsideTouchable = true
//        val a = IntArray(2)
//        view.getLocationInWindow(a)
//        popupWindow.showAtLocation(window.decorView, Gravity.NO_GRAVITY, a[0], a[1])
//        popupWindow.update()
//        popupWindow.showAsDropDown(view)
//    }

    private fun showMenu() {
        val popup = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            PopupMenu(
                this@ImageViewerActivity,
                binding.btnMore,
                Gravity.END,
                0,
                R.style.BasePopupMenu
            )
        } else {
            PopupMenu(this@ImageViewerActivity, binding.btnMore)
        }
        popup.menuInflater.inflate(R.menu.menu_image_view, popup.menu)
        popup.setForceShowIcon(true)

        popup.menu.findItem(R.id.menuCopy).isVisible = !isFromPrivate
        popup.menu.findItem(R.id.menuMove).isVisible = !isFromPrivate
        popup.menu.findItem(R.id.menuPrivate).isVisible = !isFromPrivate
        popup.menu.findItem(R.id.menuRename).isVisible =
            !displayImageList[binding.viewPager.currentItem].isVideo

        popup.menu.findItem(R.id.menuCompress).isVisible =
            !displayImageList[binding.viewPager.currentItem].isVideo
        popup.menu.findItem(R.id.menuResize).isVisible =
            !displayImageList[binding.viewPager.currentItem].isVideo
        popup.menu.findItem(R.id.menuSetWallpaper).isVisible =
            !displayImageList[binding.viewPager.currentItem].isVideo

        if (!displayImageList[binding.viewPager.currentItem].isVideo) {
            val oneMBInBytes = 1000000
            popup.menu.findItem(R.id.menuCompress).isVisible =
                displayImageList[binding.viewPager.currentItem].fileSize > oneMBInBytes
        }

        popup.setOnDismissListener {
//            val alphaAnimation = AlphaAnimation(1.0f, 0.0f)
//            alphaAnimation.duration = 1000
//            binding.btnMore.startAnimation(alphaAnimation)
        }

        popup.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.menuCopy -> {
                    if (isFileExists)
                        showAddAlbumDialog(Constant.albumList, true)
                    else
                        showToastMsg(
                            if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_copy)
                            else getString(R.string.corrupted_image_copy)
                        )
                }

                R.id.menuMove -> {
                    if (isFileExists)
                        showAddAlbumDialog(Constant.albumList, false)
                    else
                        showToastMsg(
                            if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_move)
                            else getString(R.string.corrupted_image_move)
                        )
                }

                R.id.menuSetWallpaper -> {
                    if (isFileExists)
                        startActivity(
                            Intent(this@ImageViewerActivity, WallpaperActivity::class.java)
                                .putExtra(
                                    Constant.EXTRA_WALL_PAPER,
                                    displayImageList[binding.viewPager.currentItem].filePath
                                )
                        )
                    else
                        showToastMsg(getString(R.string.corrupted_image_wallpaper))
                }

                R.id.menuPrivate -> {
                    if (isFileExists)
                        setHideData()
                    else
                        showToastMsg(
                            if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_hide)
                            else getString(R.string.corrupted_image_hide)
                        )
                }

                R.id.menuCompress -> {
                    if (isFileExists) {
                        val compressDialog = ConfirmationDialog(
                            this,
                            getString(R.string.compress),
                            getString(R.string.compress_msg),
                            getString(R.string.ok),
                            positiveBtnClickListener = {
                                compressActivityResultLauncher.launch(
                                    Intent(this, CompressActivity::class.java)
                                        .putExtra(
                                            Constant.EXTRA_IMAGE_PATH,
                                            displayImageList[binding.viewPager.currentItem].filePath
                                        )
                                )
                            })
                        compressDialog.show(supportFragmentManager, compressDialog.tag)
                    } else
                        showToastMsg(getString(R.string.corrupted_image_compress))

                }

                R.id.menuRename -> {
                    if (isFileExists)
                        showRenameDialog()
                    else
                        showToastMsg(
                            if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_rename)
                            else getString(R.string.corrupted_image_rename)
                        )
                }

                R.id.menuResize -> {
                    if (isFileExists)
                        showRenameDialog(true)
                    else
                        showToastMsg(getString(R.string.corrupted_image_resize))
                }

                R.id.menuStartSlideshow -> {
                    startSlideShow()
                }

            }
            return@setOnMenuItemClickListener true
        }
        popup.show()

    }

    var compressActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
            val filepath = displayImageList[binding.viewPager.currentItem].filePath
            val file = File(filepath)
            displayImageList[binding.viewPager.currentItem].fileSize = file.length()
            adapter.notifyDataSetChanged()
        }
    }

    private fun showRenameDialog(isResize: Boolean = false) {
        val pictureData = displayImageList[binding.viewPager.currentItem]
        val renameDialog =
            RenameDialog(
                this,
                pictureData,
                isResize,
                positiveBtnClickListener = { renamePath, oldPath ->
                    val file = File(renamePath)
                    displayImageList[binding.viewPager.currentItem].filePath = renamePath
                    displayImageList[binding.viewPager.currentItem].fileName = file.name
                    adapter.notifyDataSetChanged()
                    if (isFromPrivate) {
                        val dataBase = AppDatabase.getInstance(this)
                        val model = displayImageList[binding.viewPager.currentItem]
                        GlobalScope.launch {
                            dataBase.hideDao().update(
                                HiddenData(
                                    model.idDataBase,
                                    model.filePath,
                                    model.restorePath
                                )
                            )
                        }
                    }
                }, updateImageListener = {
                    adapter.notifyDataSetChanged()
                })
        renameDialog.show(supportFragmentManager, renameDialog.tag)
    }

    private fun setHideData() {
        val hideDialog = ConfirmationDialog(
            this,
            getString(R.string.Private),
            getString(R.string.hide_msg_single),
            getString(R.string.hide),
            positiveBtnClickListener = {
                hidePhoto()
            })
        hideDialog.show(supportFragmentManager, hideDialog.tag)
    }

    private fun hidePhoto() {
        val selectImage: ArrayList<PictureData> = ArrayList()
        val pictureData = displayImageList[binding.viewPager.currentItem]
        val i = binding.viewPager.currentItem
        selectImage.add(pictureData)
        Utils().hideFiles(this, selectImage, selectImage.size, hideListener = {
            Toast.makeText(
                this,
                getString(R.string.hide_successfully),
                Toast.LENGTH_SHORT
            ).show()
            displayImageList.removeAt(i)
//            if (displayImageList.size != 0)
//                adapter.notifyDataSetChanged()
            Log.e("", "displaySize " + displayImageList.size)
            if (displayImageList.size == 0) {
                finish()
            } else if (i < displayImageList.size - 1) {
                selectedPosition = i
//                binding.viewPager.currentItem = selectedPosition
                viewPagerSetup()
//                setTitles(selectedPosition)
//                setFavImages(selectedPosition)
            } else {
                if (i != 0)
                    selectedPosition = i - 1
//                binding.viewPager.currentItem = selectedPosition
                viewPagerSetup()
//                setTitles(selectedPosition)
//                setFavImages(selectedPosition)
            }
        })
    }

    private fun showAddAlbumDialog(albumList: java.util.ArrayList<AlbumData>, isCopy: Boolean) {
        val selectImage: ArrayList<PictureData> = ArrayList()
        val pictureData = displayImageList[binding.viewPager.currentItem]
        selectImage.add(pictureData)

        val addAlbumDialog =
            SelectAlbumDialog(this, albumList, isCopy, selectPathListener = { selectPath ->
                setCopyMove(isCopy, selectPath, selectImage)
            }, createAlbumListener = {
                val createDialog = CreateAlbumDialog(this, createPathListener = {
                    setCopyMove(isCopy, it, selectImage)
                })
                createDialog.show(supportFragmentManager, createDialog.tag)
            })
        addAlbumDialog.show(supportFragmentManager, addAlbumDialog.tag)
    }

    private fun setCopyMove(
        isCopy: Boolean,
        selectPath: String,
        selectImage: java.util.ArrayList<PictureData>
    ) {
        val i = binding.viewPager.currentItem
        if (isCopy)
            Utils().copyFiles(
                this,
                selectPath,
                selectImage,
                selectImage.size,
                copyListener = {
                    Toast.makeText(
                        this,
                        getString(R.string.copy_successfully1),
                        Toast.LENGTH_SHORT
                    ).show()
                })
        else
            Utils().moveFiles(
                this,
                selectPath,
                selectImage,
                selectImage.size,
                copyListener = {
                    Toast.makeText(
                        this,
                        getString(R.string.move_successfully1),
                        Toast.LENGTH_SHORT
                    ).show()
                    displayImageList.removeAt(binding.viewPager.currentItem)
//                    if (displayImageList.size != 0)
//                        adapter.notifyDataSetChanged()
                    if (displayImageList.size == 0) {
                        finish()
                    } else if (i < displayImageList.size - 1) {
                        selectedPosition = i
                        viewPagerSetup()
//                        binding.viewPager.currentItem = selectedPosition
//                        setTitles(selectedPosition)
//                        setFavImages(selectedPosition)
                    } else {
                        if (i != 0)
                            selectedPosition = i - 1
                        viewPagerSetup()
//                        binding.viewPager.currentItem = selectedPosition
//                        setTitles(selectedPosition)
//                        setFavImages(selectedPosition)
                    }

                })
    }

    private fun restorePhoto() {
        val pictureData = displayImageList[binding.viewPager.currentItem]
        val i = binding.viewPager.currentItem
        val dataBase = AppDatabase.getInstance(this)
        val restoreList: ArrayList<RestoreData> = ArrayList()
        Observable.fromCallable {
            val list = Utils().restoreFile(this, pictureData, dataBase)
            restoreList.addAll(list)
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    if (restoreList.size != 0) {
                        EventBus.getDefault().post(RestoreDataEvent(restoreList))
                        displayImageList.removeAt(i)
                        Log.e("restorePhoto", "size==>>  ${displayImageList.size}")
//                        if (displayImageList.size != 0)
//                            adapter.notifyDataSetChanged()
                        if (displayImageList.size == 0) {
                            Log.e("restorePhoto", "size == 0 ")
                            finish()
                        } else if (i < displayImageList.size - 1) {
                            selectedPosition = i
                            Log.e("restorePhoto", "size - 1  selectedPosition $selectedPosition")
                            viewPagerSetup()
//                            binding.viewPager.currentItem = selectedPosition
//                            setTitles(selectedPosition)
//                            setFavImages(selectedPosition)
                        } else {
                            if (i != 0)
                                selectedPosition = i - 1
                            Log.e("restorePhoto", "i - 1  selectedPosition $selectedPosition")
                            viewPagerSetup()
//                            binding.viewPager.currentItem = selectedPosition
//                            setTitles(selectedPosition)
//                            setFavImages(selectedPosition)
                        }
                    }
                }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    if (restoreList.size != 0) {
                        EventBus.getDefault().post(RestoreDataEvent(restoreList))
                        displayImageList.removeAt(binding.viewPager.currentItem)
//                        if (displayImageList.size != 0)
//                            adapter.notifyDataSetChanged()
                        Log.e("restorePhoto", "size==>>  ${displayImageList.size}")
                        if (displayImageList.size == 0) {
                            Log.e("restorePhoto", "size == 0 ")
                            finish()
                        } else if (i < displayImageList.size - 1) {
                            selectedPosition = i
                            Log.e("restorePhoto", "size - 1  selectedPosition $selectedPosition")
                            viewPagerSetup()
//                            binding.viewPager.currentItem = selectedPosition
//                            setTitles(selectedPosition)
//                            setFavImages(selectedPosition)
                        } else {
                            if (i != 0)
                                selectedPosition = i - 1
                            Log.e("restorePhoto", "i - 1  selectedPosition $selectedPosition")
                            viewPagerSetup()
//                            binding.viewPager.currentItem = selectedPosition
//                            setTitles(selectedPosition)
//                            setFavImages(selectedPosition)
                        }
                    }
                }
            }
    }

    private fun recentDeletePhoto() {
        val pictureData = displayImageList[binding.viewPager.currentItem]
        val i = binding.viewPager.currentItem
        val deleteList = ArrayList<String>()
        val dataBase = AppDatabase.getInstance(this)
        var isDelete = false
        Observable.fromCallable {
            isDelete = Utils().recentlyDeleteHideFile(this, pictureData, dataBase)
            isDelete
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    if (isDelete) {
                        deleteList.add(pictureData.filePath)
                        EventBus.getDefault().post(DisplayDeleteEvent(deleteList))
                        displayImageList.removeAt(binding.viewPager.currentItem)
//                        if (displayImageList.size != 0)
//                            adapter.notifyDataSetChanged()
                        if (displayImageList.size == 0) {
                            finish()
                        } else if (i < displayImageList.size - 1) {
                            selectedPosition = i
                            viewPagerSetup()
//                            binding.viewPager.currentItem = selectedPosition
//                            setTitles(selectedPosition)
//                            setFavImages(selectedPosition)
                        } else {
                            if (i != 0)
                                selectedPosition = i - 1
                            viewPagerSetup()
//                            binding.viewPager.currentItem = selectedPosition
//                            setTitles(selectedPosition)
//                            setFavImages(selectedPosition)
                        }
                    }
                }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    if (isDelete) {
                        deleteList.add(pictureData.filePath)
                        EventBus.getDefault().post(DisplayDeleteEvent(deleteList))
                        displayImageList.removeAt(binding.viewPager.currentItem)
//                        if (displayImageList.size != 0)
//                            adapter.notifyDataSetChanged()
                        if (displayImageList.size == 0) {
                            finish()
                        } else if (i < displayImageList.size - 1) {
                            selectedPosition = i
                            viewPagerSetup()
//                            binding.viewPager.currentItem = selectedPosition
//                            setTitles(selectedPosition)
//                            setFavImages(selectedPosition)
                        } else {
                            if (i != 0)
                                selectedPosition = i - 1
                            viewPagerSetup()
//                            binding.viewPager.currentItem = selectedPosition
//                            setTitles(selectedPosition)
//                            setFavImages(selectedPosition)
                        }
                    }
                }
            }
    }

    fun setUnHideData() {
        val pictureData = displayImageList[binding.viewPager.currentItem]
        val hideDialog = ConfirmationDialog(
            this,
            getString(R.string.Unhide),
            if (pictureData.isVideo) getString(R.string.unhide_msg_video_single) else getString(R.string.unhide_msg_image_single),
            getString(R.string.ok),
            positiveBtnClickListener = {
                unHidePhoto()
            })
        hideDialog.show(supportFragmentManager, hideDialog.tag)
    }

    private fun unHidePhoto() {
        val selectImage: ArrayList<PictureData> = ArrayList()
        val pictureData = displayImageList[binding.viewPager.currentItem]
        selectImage.add(pictureData)
        val i = binding.viewPager.currentItem

        Utils().unHideFiles(this, selectImage, selectImage.size, hideListener = {
            Toast.makeText(
                this,
                getString(R.string.UnHide_successfully),
                Toast.LENGTH_SHORT
            ).show()
            displayImageList.removeAt(binding.viewPager.currentItem)
            Log.e("", "displaySize ${displayImageList.size} pos==>> $i")
//            if (displayImageList.size != 0)
//                adapter.notifyDataSetChanged()

            if (displayImageList.size == 0) {
                finish()
            } else if (i < displayImageList.size - 1) {
                selectedPosition = i
                viewPagerSetup()
//                binding.viewPager.currentItem = selectedPosition
//                setTitles(selectedPosition)
//                setFavImages(selectedPosition)
            } else {
                if (i != 0)
                    selectedPosition = i - 1
                viewPagerSetup()
//                binding.viewPager.currentItem = selectedPosition
//                setTitles(selectedPosition)
//                setFavImages(selectedPosition)
            }
        })
    }

    private fun showDeleteDialog() {
        val pictureData = displayImageList[binding.viewPager.currentItem]
        val deleteDialog = DeleteDialog(
            this,
            if (pictureData.isVideo) getString(R.string.delete_msg_video_single) else getString(R.string.delete_msg_image_single),
            positiveBtnClickListener = {
                deleteFiles(pictureData)
            })
        deleteDialog.show(supportFragmentManager, deleteDialog.tag)
    }

    private fun deleteFiles(pictureData: PictureData) {
        val i = binding.viewPager.currentItem
        val deleteList = ArrayList<String>()
        val dataBase = AppDatabase.getInstance(this)
        var isDelete = false
        Observable.fromCallable {
            isDelete = Utils().deleteFile(this, pictureData.filePath, dataBase)
            isDelete
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    if (isDelete) {
                        deleteList.add(pictureData.filePath)
                        EventBus.getDefault().post(DisplayDeleteEvent(deleteList))
                        displayImageList.removeAt(binding.viewPager.currentItem)
//                        if (displayImageList.size != 0)
//                            adapter.notifyDataSetChanged()

                        if (displayImageList.size == 0) {
                            finish()
                        } else if (i < displayImageList.size - 1) {
                            selectedPosition = i
//                            binding.viewPager.currentItem = selectedPosition
                            viewPagerSetup()
                        } else {
                            if (i != 0)
                                selectedPosition = i - 1
//                            binding.viewPager.currentItem = selectedPosition
                            viewPagerSetup()
                        }
                    }
                }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    if (isDelete) {
                        deleteList.add(pictureData.filePath)
                        EventBus.getDefault().post(DisplayDeleteEvent(deleteList))
                        displayImageList.removeAt(binding.viewPager.currentItem)
//                        if (displayImageList.size != 0)
//                            adapter.notifyDataSetChanged()
                        if (displayImageList.size == 0) {
                            finish()
                        } else if (i < displayImageList.size - 1) {
                            selectedPosition = i
//                            binding.viewPager.currentItem = selectedPosition
                            viewPagerSetup()
                        } else {
                            if (i != 0)
                                selectedPosition = i - 1
//                            binding.viewPager.currentItem = selectedPosition
                            viewPagerSetup()
                        }
                    }
                }
            }
    }

    private fun setFavImages(position: Int) {
        binding.btnRename.visibility =
            if (displayImageList[position].isVideo) View.VISIBLE else View.GONE
        binding.btnEdit.visibility =
            if (!displayImageList[position].isVideo) View.VISIBLE else View.GONE

        binding.icFavourite.setImageDrawable(
            ContextCompat.getDrawable(
                this@ImageViewerActivity,
                if (displayImageList[position].isFavorite) R.drawable.ic_favourite_checked else R.drawable.ic_favourite_uncheck
            )
        )
    }

    private fun setTitles(position: Int) {
        if (position < displayImageList.size) {
            val strDate = format.format(displayImageList[position].date)
            val time = formatTime.format(displayImageList[position].date)
            binding.txtTitle.text = strDate
            binding.txtTime.text = time
        }
    }

    private fun showDetailsDialog() {
        val detailsDialog = DetailsDialog(displayImageList[binding.viewPager.currentItem])
        detailsDialog.show(supportFragmentManager, detailsDialog.tag)
    }


    private fun viewPagerSetup() {
        binding.viewPager.orientation = ViewPager2.ORIENTATION_HORIZONTAL
        binding.viewPager.offscreenPageLimit = 1
//        binding.viewPager.setPageTransformer(SlideTransformer())

        setTitles(selectedPosition)
        setFavImages(selectedPosition)
        adapter = ImageViewerAdapter(this, displayImageList, clickListener = {
            if (isFileExists) {
                Constant.videoData = displayImageList[it]
                startActivity(
                    Intent(this, VideoPlayerActivity::class.java).putExtra(
                        "videoPath",
                        displayImageList[it].filePath
                    )
                )
            } else {
                showToastMsg(getString(R.string.corrupted_video_play))
            }
        }, clickImageListener = {
            if (isSlideShow) {
                stopSlideShow()
            }
        })

        binding.viewPager.adapter = adapter
        binding.viewPager.setCurrentItem(selectedPosition, false)
        binding.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int,
            ) {
                super.onPageScrolled(position, positionOffset, positionOffsetPixels)
                Log.e("viewPagerImageDisplay", "onPageScrolled")
                selectedPosition = position
                setTitles(position)
                setFavImages(position)
                isFileExists = File(displayImageList[position].filePath).exists()
            }

            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                Log.e("viewPagerImageDisplay", "onPageSelected")
                selectedPosition = position
                setTitles(position)
                setFavImages(position)
                isFileExists = File(displayImageList[position].filePath).exists()
            }
        })
    }

    private fun setFavorite(filePath: String) {
        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())
        if (!favList.contains(filePath)) {
            favList.add(0, filePath)
            preferences.setFavoriteList(favList)
            EventBus.getDefault().post(UpdateFavoriteEvent(filePath, true))
        }
    }

    private fun setUnFavorite(filePath: String) {
        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())

        favList.remove(filePath)
        preferences.setFavoriteList(favList)
        EventBus.getDefault().post(UpdateFavoriteEvent(filePath, false))
    }

    override fun onDestroy() {
        super.onDestroy()
//        Constant.displayImageList.clear()
        if (mHandler != null) mHandler.removeCallbacks(slideShowTask)
    }


}