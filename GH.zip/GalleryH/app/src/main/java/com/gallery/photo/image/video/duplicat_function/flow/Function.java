package com.gallery.photo.image.video.duplicat_function.flow;

@FunctionalInterface

public interface Function<T, R> {
    R apply(T t);
}
