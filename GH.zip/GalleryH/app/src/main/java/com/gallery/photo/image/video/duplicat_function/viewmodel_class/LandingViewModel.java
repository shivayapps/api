package com.gallery.photo.image.video.duplicat_function.viewmodel_class;

import android.app.Application;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;
import androidx.work.Data;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkInfo;
import androidx.work.WorkManager;

import com.gallery.photo.image.video.duplicat_function.core_class.FileDeleteWorker;
import com.gallery.photo.image.video.duplicat_function.utils_duplicat.DuplicateConstants;
import com.gallery.photo.image.video.duplicat_function.utils_duplicat.FileScanWorker;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;


public class LandingViewModel extends ViewModel {
    private static final String TAG = LandingViewModel.class.getSimpleName();

    private final WorkManager mWorkManager;
    private final LiveData<List<WorkInfo>> workInfo;
    private UUID workUUID;
    private String workflowTag;

    public LandingViewModel(Application application, String str) {
        this.workflowTag = DuplicateConstants.WORKFLOW_TAG;
        WorkManager workManager = WorkManager.getInstance(application);
        this.mWorkManager = workManager;
        this.workflowTag = str;
        this.workInfo = workManager.getWorkInfosByTagLiveData(str);
    }
    public UUID getWorkUUID() {
        return this.workUUID;
    }

    public void deleteItems(List<String> list) {
        if (list == null || list.isEmpty() || isAnyWorkflowRunning()) {
            return;
        }
        this.mWorkManager.pruneWork();
        this.mWorkManager.enqueueUniqueWork(this.workflowTag, ExistingWorkPolicy.REPLACE, new OneTimeWorkRequest.Builder(FileDeleteWorker.class).addTag(this.workflowTag).build());
    }

    public void startDuplicateScan(String str) {
        if (isAnyWorkflowRunning()) {
            return;
        }
        OneTimeWorkRequest build = new OneTimeWorkRequest.Builder(FileScanWorker.class).setInputData(new Data.Builder().putString(DuplicateConstants.SCAN_TYPE, str).build()).addTag(DuplicateConstants.WORKFLOW_TAG).build();
        this.workUUID = build.getId();
        this.mWorkManager.pruneWork();
        this.mWorkManager.enqueueUniqueWork(DuplicateConstants.WORKFLOW_TAG, ExistingWorkPolicy.KEEP, build);
    }

    public void startOrStopPeriodicScan(int i, boolean z) {
        if (i == 0) {
            this.mWorkManager.cancelAllWorkByTag(DuplicateConstants.WORKFLOW_TAG_PERIODIC);
            return;
        }
        this.mWorkManager.enqueueUniquePeriodicWork(DuplicateConstants.WORKFLOW_TAG_PERIODIC, z ? ExistingPeriodicWorkPolicy.KEEP : ExistingPeriodicWorkPolicy.REPLACE, new PeriodicWorkRequest.Builder(FileScanWorker.class, i, TimeUnit.DAYS, 1L, TimeUnit.HOURS).setInputData(new Data.Builder().putString(DuplicateConstants.SCAN_TYPE, DuplicateConstants.Type.ALL).build()).setInitialDelay(1L, TimeUnit.HOURS).addTag(DuplicateConstants.WORKFLOW_TAG_PERIODIC).build());
    }

    public LiveData<List<WorkInfo>> getOutputWorkInfo() {
        return this.workInfo;
    }

    public void cancelWork() {
        this.mWorkManager.cancelWorkById(this.workUUID);
    }

    void cancelWorkByTag() {
        this.mWorkManager.cancelAllWorkByTag(this.workflowTag);
    }

    boolean isAnyWorkflowRunning() {
        try {
            List<WorkInfo> list = this.mWorkManager.getWorkInfosByTag(this.workflowTag).get();
            if (list.isEmpty()) {
                return false;
            }
            for (WorkInfo workInfo : list) {
                if (!workInfo.getState().isFinished()) {
                    return true;
                }
            }
            return false;
        } catch (InterruptedException e) {
            e.printStackTrace();
            return false;
        } catch (ExecutionException e2) {
            e2.printStackTrace();
            return false;
        }
    }
}
