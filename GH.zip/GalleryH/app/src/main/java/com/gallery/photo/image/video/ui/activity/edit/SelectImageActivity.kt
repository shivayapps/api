package com.gallery.photo.image.video.ui.activity.edit

import android.app.Activity
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.view.View.OnTouchListener
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.AdapterView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.ActivitySelectImageBinding
import com.gallery.photo.image.video.ui.activity.BaseActivity
import com.gallery.photo.image.video.ui.adapter.SelectAlbumAdapter
import com.gallery.photo.image.video.ui.adapter.SelectImageAdapter
import com.gallery.photo.image.video.ui.adapter.SelectImageListAdapter
import com.gallery.photo.image.video.ui.dialog.ConfirmationDialog
import com.gallery.photo.image.video.ui.model.AlbumData
import com.gallery.photo.image.video.ui.model.PictureData
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.Preferences
import com.gallery.photo.image.video.utils.Utils
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import java.io.File
import java.text.SimpleDateFormat
import java.util.Collections


class SelectImageActivity : BaseActivity() {

    lateinit var binding: ActivitySelectImageBinding
    lateinit var preferences: Preferences
    var albumList: ArrayList<AlbumData> = ArrayList()
    val allImages: ArrayList<PictureData> = ArrayList()
    val selectedImageList: ArrayList<PictureData> = ArrayList()
    var spinnerAdapter: SelectAlbumAdapter? = null
    var pictures = ArrayList<Any>()
    var pictureAdapter: SelectImageAdapter? = null
    var selectImageAdapter: SelectImageListAdapter? = null
    var selectAlbumPath: String = ""
    var spinnerPos = -1
    var openType = 0
    lateinit var dropdownAnimation: Animation

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySelectImageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        intView()
        intListener()
        setRvLayoutManager()
    }

    private fun intView() {

        binding.loutBottomSelect.visibility = View.GONE
        openType = intent.getIntExtra(Constant.EXTRA_SELECT_TYPE, 0)

        if (openType == Constant.SELECT_TYPE_CRATE_ALBUM) {
            selectAlbumPath = intent.getStringExtra(Constant.EXTRA_ALBUM_PATH) ?: ""

            val bundle2 = Bundle()
            bundle2.putString("SelectImageForCreateAlbum", Constant.event_open)
            firebaseAnalytics.logEvent(Constant.event_activity, bundle2)
        }

        if (openType == Constant.SELECT_TYPE_HIDE) {
            binding.btDone.text = getString(R.string.hide)

            val bundle2 = Bundle()
            bundle2.putString("SelectImageForHide", Constant.event_open)
            firebaseAnalytics.logEvent(Constant.event_activity, bundle2)
        }



        preferences = Preferences(this)
        dropdownAnimation = AnimationUtils.loadAnimation(this, R.anim.dropdown_animation)
        getData()
        setSelectAdapter()
    }

    private fun setSelectAdapter() {
        selectImageAdapter = SelectImageListAdapter(this, selectedImageList, deleteListener = {
            selectedImageList.removeAt(it)
            selectImageAdapter?.notifyDataSetChanged()
            pictureAdapter?.notifyDataSetChanged()
            checkSelectionEmpty()
        })
        binding.rvSelect.adapter = selectImageAdapter
    }

    private fun checkSelectionEmpty() {
        binding.loutBottomSelect.visibility =
            if (selectedImageList.isEmpty()) View.GONE else View.VISIBLE
        binding.tvImageSelect.text = "${selectedImageList.size} ${getString(R.string.selected)}"
    }

    var isSpinnerOpen = false
    var rotationAngle = 0f

    private fun intListener() {
        binding.icBack.setOnClickListener { finish() }
        binding.icDelete.setOnClickListener {
            val confirmationDialog = ConfirmationDialog(
                this,
                getString(R.string.clear_all),
                getString(R.string.clear_all_msg),
                getString(R.string.yes),
                positiveBtnClickListener = {
                    selectedImageList.clear()
                    selectImageAdapter?.notifyDataSetChanged()
                    pictureAdapter?.notifyDataSetChanged()
                    checkSelectionEmpty()
                },
                false,
                getString(R.string.no)
            )
            confirmationDialog.show(supportFragmentManager, confirmationDialog.tag)
        }

        binding.btDone.setOnClickListener {
            if (selectedImageList.isNotEmpty()) {
                if (openType == Constant.SELECT_TYPE_CRATE_ALBUM) {
                    val file = File(selectAlbumPath)
                    if (!file.exists())
                        file.mkdirs()

                    Utils().moveFiles(
                        this,
                        selectAlbumPath,
                        selectedImageList,
                        selectedImageList.size,
                        copyListener = {
                            Toast.makeText(
                                this,
                                getString(R.string.import_successfully),
                                Toast.LENGTH_SHORT
                            ).show()
                            finish()
                        }, false, true
                    )
                } else if (openType == Constant.SELECT_TYPE_HIDE) {
                    hidePhoto()
                }
            }
        }

//        binding.spinner.onPopUpOpenedListener = { spinner: CustomSpinner ->
//            // called when the pop-up is opened
//            Log.e("SpinnerTag", "onPopUp Opened")
//            rotationAngle = if (rotationAngle == 0f) 180f else 0f
//            binding.ivDropDown.animate().rotation(rotationAngle).setDuration(500).start()
//        }
//
//        binding.spinner.onPopUpClosedListener = { spinner: CustomSpinner ->
//            // called when the pop-up is closed
//            Log.e("SpinnerTag", "onPopUp Closed")
//            rotationAngle = if (rotationAngle == 0f) 180f else 0f
//            binding.ivDropDown.animate().rotation(rotationAngle).setDuration(500).start()
//        }

//        binding.spinner.setOnTouchListener { view, motionEvent ->
//            Log.e("spinnerTag","setOnTouchListener")
//            true
//        }
//        binding.spinner.setOnTouchListener(OnTouchListener { v, event ->
//            if (event.action == MotionEvent.ACTION_DOWN) {
//                Log.e("spinnerTag", "setOnTouchListener ACTION_DOWN")
////                Toast.makeText(this@MapActivity, "down", Toast.LENGTH_LONG).show()
//                // Load your spinner here
//            } else if (event.action == MotionEvent.ACTION_UP) {
//                Log.e("spinnerTag", "setOnTouchListener ACTION_UP")
//            } else
//                Log.e("spinnerTag", "setOnTouchListener ")
//            false
//        })
        binding.spinner.viewTreeObserver?.addOnWindowFocusChangeListener { hasFocus -> //This updates the arrow icon up/down depending on Spinner opening/closing
            Log.e("spinnerTag", "addOnWindowFocusChangeListener $hasFocus ")
            if (hasFocus) {
                // spinner close
                rotationAngle = if (rotationAngle == 0f) 180f else 0f
                binding.ivDropDown.animate().rotation(rotationAngle).setDuration(500).start()
            } else {
                // spinner open
                rotationAngle = if (rotationAngle == 0f) 180f else 0f
                binding.ivDropDown.animate().rotation(rotationAngle).setDuration(500).start()
            }
        }
        binding.spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                Log.e("spinnerTag", "onItemSelected")
                if (position != -1)
                    binding.txtItemSpinner.text = albumList[position].title

                if (spinnerPos != position)
                    setImageAdapter(position)
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                Log.e("spinnerTag", "onNothingSelected")
            }

        }
    }

    private fun hidePhoto() {
        Constant.selectedImageList = ArrayList()
        Constant.selectedImageList.addAll(selectedImageList)
        setResult(Activity.RESULT_OK)
        finish()
    }

    private fun setImageAdapter(position: Int) {
        pictures.clear()
        pictures.addAll(albumList[position].folderImageList)
        pictureAdapter = SelectImageAdapter(this, pictures, selectedImageList, clickListener = {
            if (pictures[it] is PictureData) {
                val pictureData = pictures[it] as PictureData
                if (selectedImageList.contains(pictureData)) {
                    selectedImageList.remove(pictureData)
                } else {
                    selectedImageList.add(pictureData)
                }
                pictureAdapter?.notifyItemChanged(it)
                selectImageAdapter?.notifyDataSetChanged()
                checkSelectionEmpty()
            }
        })

        binding.pictureRecycler.adapter = pictureAdapter
    }


    fun setRvLayoutManager() {
        val gridCount = preferences.getGridCount()
        val gridLayoutManager =
            GridLayoutManager(this, gridCount, RecyclerView.VERTICAL, false)
        binding.pictureRecycler.layoutManager = gridLayoutManager
        gridLayoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                if (position >= 0 && position < pictures.size) {
                    return if (pictureAdapter!!.getItemViewType(position) === pictureAdapter!!.ITEM_HEADER_TYPE) {
                        gridCount
                    } else 1
                } else {
                    return 1
                }
            }
        }
    }

    private fun setData() {
        binding.progressBar.visibility = View.GONE
        setEmptyData()
        checkSelectionEmpty()

        if (albumList.isNotEmpty()) {
            spinnerAdapter = SelectAlbumAdapter(this, albumList)
            binding.spinner.adapter = spinnerAdapter
            binding.spinner.setSelection(0)
//            setImageAdapter(0)
        }
    }

    private fun setEmptyData() {
        if (albumList != null && albumList.size != 0) {
            binding.pictureRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
        } else {
            binding.pictureRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
        }
    }

    private fun getData() {
        binding.progressBar.visibility = View.VISIBLE
        Observable.fromCallable<Boolean> {
            albumList.clear()
            allImages.clear()
            getImages()
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { throwable: Throwable? ->
                runOnUiThread {
                    setFilterData()
                }
            }
            .subscribe { result: Boolean? ->
                runOnUiThread {
                    setFilterData()
                }
            }
    }

    fun setFilterData() {
        binding.progressBar.visibility = View.VISIBLE
        Observable.fromCallable {
            sortAlbumMain()
            sortPhotos()
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread { setDataList() }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread { setDataList() }
            }
    }

    private fun setDataList() {
        Observable.fromCallable {
            setList()
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread { setData() }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread { setData() }
            }
    }

    private fun setList() {
        if (allImages.isNotEmpty()) {
            val albumData = AlbumData()
            albumData.title = "All"
            albumData.pictureData = allImages
            albumList.add(0, albumData)
        }
        val format = SimpleDateFormat("dd MMM yyyy")

        if (albumList.isNotEmpty()) {
            for (a in albumList.indices) {

                val dateWisePictures = LinkedHashMap<String, ArrayList<PictureData>>()
                val picturesList: ArrayList<Any> = ArrayList()
                for (pictureData in albumList[a].pictureData) {
                    val strDate = format.format(pictureData.date)
                    var imagesData1: ArrayList<PictureData> = ArrayList()
                    if (dateWisePictures.containsKey(strDate)) {
                        val list: ArrayList<PictureData>? = dateWisePictures[strDate]
                        if (!list.isNullOrEmpty())
                            imagesData1.addAll(list)
                    } else {
                        imagesData1 = ArrayList()
                    }
                    imagesData1.add(pictureData)
                    dateWisePictures[strDate] = imagesData1

                }
                val keys: Set<String> = dateWisePictures.keys
                val listKeys = ArrayList(keys)

                for (i in listKeys.indices) {
                    val imagesData = dateWisePictures[listKeys[i]]
                    if (imagesData != null && imagesData.size != 0) {
                        val bucketData = AlbumData(listKeys[i], imagesData)
                        picturesList.add(bucketData)
                        picturesList.addAll(imagesData)
                    }
                }


                albumList[a].folderImageList = picturesList
            }
        }
    }

    private fun sortAlbumMain() {
        val sortType = preferences.getSortType()
        val sortOrder = preferences.getSortOrder()

        albumList.sortWith(Comparator { p1, p2 ->
            if (sortType == Constant.SORT_NAME) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.title.compareTo(p2.title, true)
                else
                    p2.title.compareTo(p1.title, true)
            } else if (sortType == Constant.SORT_PATH) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.folderPath.compareTo(p2.folderPath, true)
                else
                    p2.folderPath.compareTo(p1.folderPath, true)
            } else if (sortType == Constant.SORT_SIZE) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.fileSize.compareTo(p2.fileSize)
                else
                    p2.fileSize.compareTo(p1.fileSize)
            } else if (sortType == Constant.SORT_LAST_MODIFIED) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.date.compareTo(p2.date)
                else
                    p2.date.compareTo(p1.date)
            } else if (sortType == Constant.SORT_DATE_TAKEN) {
                if (sortOrder == Constant.SORT_ASCENDING)
                    p1.date.compareTo(p2.date)
                else
                    p2.date.compareTo(p1.date)
            } else
                p2.date.compareTo(p1.date)
        })
    }

    private fun sortPhotos() {
        val sortType = preferences.getSortType()
        val sortOrder = preferences.getSortOrder()

        for (albumData in albumList) {
            Collections.sort(albumData.pictureData, Comparator { p1, p2 ->
                if (sortType == Constant.SORT_NAME) {
                    if (sortOrder == Constant.SORT_ASCENDING)
                        p1.fileName.compareTo(p2.fileName, true)
                    else
                        p2.fileName.compareTo(p1.fileName, true)
                } else if (sortType == Constant.SORT_PATH) {
                    if (sortOrder == Constant.SORT_ASCENDING)
                        p1.filePath.compareTo(p2.filePath, true)
                    else
                        p2.filePath.compareTo(p1.filePath, true)
                } else if (sortType == Constant.SORT_SIZE) {
                    if (sortOrder == Constant.SORT_ASCENDING)
                        p1.fileSize.compareTo(p2.fileSize)
                    else
                        p2.fileSize.compareTo(p1.fileSize)
                } else if (sortType == Constant.SORT_LAST_MODIFIED) {
                    if (sortOrder == Constant.SORT_ASCENDING)
                        p1.date.compareTo(p2.date)
                    else
                        p2.date.compareTo(p1.date)
                } else if (sortType == Constant.SORT_DATE_TAKEN) {
                    if (sortOrder == Constant.SORT_ASCENDING)
                        p1.dateTaken.compareTo(p2.dateTaken)
                    else
                        p2.dateTaken.compareTo(p1.dateTaken)
                } else
                    p2.date.compareTo(p1.date)
            })


        }
    }

    private fun getImages() {
        Log.e("gettingListPhoto", "getImages")
        val mCursor: Cursor?
        val folderList: MutableList<String> = ArrayList<String>()
//        folderList.addAll(preferencesManager.getExcludeFolderList())

        val albumWisePictures = LinkedHashMap<String, ArrayList<PictureData>>()

        try {
            val BUCKET_DISPLAY_NAME = MediaStore.MediaColumns.BUCKET_DISPLAY_NAME

            val projection = arrayOf(
                MediaStore.Images.Media.DATA,
                BUCKET_DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_MODIFIED,
                MediaStore.MediaColumns.DATE_TAKEN,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.SIZE
            )
            val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            } else {
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            }

            mCursor = contentResolver.query(
                uri,  // Uri
                projection,  // Projection
                null,
                null,
                MediaStore.MediaColumns.DATE_MODIFIED + " DESC"
            )
            if (mCursor != null) {
                mCursor.moveToFirst()
                while (!mCursor.isAfterLast) {
                    //2sec
                    val path =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))
                    val title =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME))
                    val bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
                    if (!folderList.contains(bucketPath)) {
                        val bucketName =
                            mCursor.getString(mCursor.getColumnIndexOrThrow(BUCKET_DISPLAY_NAME))
                        var d =
                            mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED))
                        d *= 1000
                        var dt =
                            mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))
                        dt *= 1000
                        if (dt == 0L)
                            dt = d
                        val fileSizeLength =
                            mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
                        val pictureData =
                            PictureData(path, title, bucketName, d, dt, fileSizeLength, false)
                        pictureData.bucketPath = bucketPath
                        pictureData.isCheckboxVisible = true

                        var imagesData2: ArrayList<PictureData> = ArrayList()
                        if (albumWisePictures.containsKey(bucketPath)) {
                            val list: ArrayList<PictureData>? = albumWisePictures[bucketPath]
                            if (!list.isNullOrEmpty())
                                imagesData2.addAll(list)
                        } else {
                            imagesData2 = ArrayList()
                        }
                        imagesData2.add(pictureData)
                        allImages.add(pictureData)
                        albumWisePictures[bucketPath] = imagesData2
                    }
                    mCursor.moveToNext()
                }
                mCursor.close()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }


        if (albumWisePictures.size != 0) {
            val folderKeys: Set<String> = albumWisePictures.keys
            val listFolderkeys = java.util.ArrayList(folderKeys)
            for (i in listFolderkeys.indices) {
                val imagesData: java.util.ArrayList<PictureData> = ArrayList()
                val list = albumWisePictures[listFolderkeys[i]]
                if (list != null)
                    imagesData.addAll(list)

                if (imagesData.size != 0 && imagesData[0].folderName.isNotEmpty()) {
                    val albumData = AlbumData()
                    albumData.title = imagesData[0].folderName
                    albumData.pictureData = imagesData

                    val folderPath = listFolderkeys[i]
                    albumData.folderPath = folderPath
                    val file = File(folderPath)
                    albumData.date = file.lastModified()
                    albumData.fileSize = file.length()
                    albumList.add(albumData)
                }
            }
        }

    }
}