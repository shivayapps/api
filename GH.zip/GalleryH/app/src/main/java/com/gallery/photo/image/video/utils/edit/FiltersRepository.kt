package com.gallery.photo.image.video.utils.edit

import android.content.Context
import androidx.core.content.ContextCompat
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.ui.model.FiltersData
import jp.co.cyberagent.android.gpuimage.filter.*

class FiltersRepository(context: Context) {


    private val retroFilter: GPUImageFilter = GPUImageColorMatrixFilter(
        1.0f,
        floatArrayOf(
            1.0f, 0.0f, 0.0f, 0.0f,
            0.0f, 1.0f, 0.2f, 0.0f,
            0.1f, 0.1f, 1.0f, 0.0f,
            1.0f, 0.0f, 0.0f, 1.0f
        )
    )

    private val justFilter = GPUImageColorMatrixFilter(
        0.9f,
        floatArrayOf(
            0.4f, 0.6f, 0.5f, 0.0f,
            0.0f, 0.4f, 1.0f, 0.0f,
            0.05f, 0.1f, 0.4f, 0.4f,
            1.0f, 1.0f, 1.0f, 1.0f
        )
    )

    private val humeFilter = GPUImageColorMatrixFilter(
        1.0f,
        floatArrayOf(
            1.25f, 0.0f, 0.2f, 0.0f,
            0.0f, 1.0f, 0.2f, 0.0f,
            0.0f, 0.3f, 1.0f, 0.3f,
            0.0f, 0.0f, 0.0f, 1.0f
        )
    )

    private val desertFilter = GPUImageColorMatrixFilter(
        1.0f,
        floatArrayOf(
            0.6f, 0.4f, 0.2f, 0.05f,
            0.0f, 0.8f, 0.3f, 0.05f,
            0.3f, 0.3f, 0.5f, 0.08f,
            0.0f, 0.0f, 0.0f, 1.0f
        )
    )

    private val oldTimesFilter =
        GPUImageColorMatrixFilter(
            1.0f,
            floatArrayOf(
                1.0f, 0.05f, 0.0f, 0.0f,
                -0.2f, 1.1f, -0.2f, 0.11f,
                0.2f, 0.0f, 1.0f, 0.0f,
                0.0f, 0.0f, 0.0f, 1.0f
            )
        )


    private val limoFilter =
        GPUImageColorMatrixFilter(
            1.0f,
            floatArrayOf(
                1.0f, 0.0f, 0.08f, 0.0f,
                0.4f, 1.0f, 0.0f, 0.0f,
                0.0f, 0.0f, 1.0f, 0.1f,
                0.0f, 0.0f, 0.0f, 1.0f
            )
        )

    private val solarFilter = GPUImageColorMatrixFilter(
        1.0f,
        floatArrayOf(
            1.5f, 0f, 0f, 0f,
            0f, 1f, 0f, 0f,
            0f, 0f, 1f, 0f,
            0f, 0f, 0f, 1f
        )
    )

    private val neutronFilter = GPUImageColorMatrixFilter(
        1.0f,
        floatArrayOf(
            0f, 1f, 0f, 0f,
            0f, 1f, 0f, 0f,
            0f, 0.6f, 1f, 0f,
            0f, 0f, 0f, 1f
        )
    )

    private val milkFilter = GPUImageColorMatrixFilter(
        1.0f,
        floatArrayOf(
            0.0f, 1.0f, 0.0f, 0.0f,
            0.0f, 1.0f, 0.0f, 0.0f,
            0.0f, 0.64f, 0.5f, 0.0f,
            0.0f, 0.0f, 0.0f, 1.0f
        )
    )

    /**
     * Black Filter
     */

    private val clueFilter = GPUImageColorMatrixFilter(
        1.0f,
        floatArrayOf(
            0.0f, 0.0f, 1.0f, 0.0f,
            0.0f, 0.0f, 1.0f, 0.0f,
            0.0f, 0.0f, 1.0f, 0.0f,
            0.0f, 0.0f, 0.0f, 1.0f
        )
    )

    /**
     * Black Filter
     */
    private val muliFilter = GPUImageColorMatrixFilter(
        1.0f,
        floatArrayOf(
            1.0f, 0.0f, 0.0f, 0.0f,
            1.0f, 0.0f, 0.0f, 0.0f,
            1.0f, 0.0f, 0.0f, 0.0f,
            0.0f, 0.0f, 0.0f, 1.0f
        )
    )

    private val aeroFilter = GPUImageColorMatrixFilter(
        1.0f,
        floatArrayOf(
            0f, 0f, 1f, 0f,
            1f, 0f, 0f, 0f,
            0f, 1f, 0f, 0f,
            0f, 0f, 0f, 1f
        )
    )

    private val classicFilters = GPUImageColorMatrixFilter(
        1.0f,
        floatArrayOf(
            0.763f, 0.0f, 0.2062f, 0f,
            0.0f, 0.9416f, 0.0f, 0f,
            0.1623f, 0.2614f, 0.8052f, 0f,
            0f, 0f, 0f, 1f
        )
    )

    private val atomFilter = GPUImageColorMatrixFilter(
        1.0f,
        floatArrayOf(
            0.5162f, 0.3799f, 0.3247f, 0f,
            0.039f, 1.0f, 0f, 0f,
            -0.4773f, 0.461f, 1.0f, 0f,
            0f, 0f, 0f, 1f
        )
    )

    val marsFilter = GPUImageColorMatrixFilter(
        1.0f,
        floatArrayOf(
            0.0f, 0.0f, 0.5183f, 0.3183f,
            0.0f, 0.5497f, 0.5416f, 0f,
            0.5237f, 0.5269f, 0.0f, 0f,
            0f, 0f, 0f, 1f
        )
    )

    private val yeliFilter = GPUImageColorMatrixFilter(
        1.0f,
        floatArrayOf(
            1.0f, -0.3831f, 0.3883f, 0.0f,
            0.0f, 1.0f, 0.2f, 0f,
            -0.1961f, 0.0f, 1.0f, 0f,
            0f, 0f, 0f, 1f
        )
    )


    /**
     * [brightnessFilter] is Brightness Filter
     */

    private val brightnessFilter = GPUImageBrightnessFilter(.15f)
//    private val brightnessFilter = GPUImageBrightnessFilter(.20f)

//    private val contrastFilter = GPUImageContrastFilter(1.6f)
    private val contrastFilter = GPUImageContrastFilter(1.5f)

//    private val saturationFilter = GPUImageSaturationFilter(1.8f)
    private val saturationFilter = GPUImageSaturationFilter(1.4f)

//    private val exposureFilter = GPUImageExposureFilter(.30f)
    private val exposureFilter = GPUImageExposureFilter(.20f)

//    private val rgbFilterFilter = GPUImageRGBFilter(1.1f, 1.3f, 1.6f)
    private val rgbFilterFilter = GPUImageRGBFilter(1.1f, 1.3f, 1.6f)

    private val hueFilter = GPUImageHueFilter(46f)

    private val sharpenFilter = GPUImageSharpenFilter(2.0f)


    private val embossFilter = GPUImageEmbossFilter()

    private val toonFilter = GPUImageToonFilter()

    private val posterizeFilter = GPUImagePosterizeFilter()

    /**
     * Blur
     */
    private val gaussianBlurFilter = GPUImageGaussianBlurFilter(5.0f)

    private val monochromeFilter = GPUImageMonochromeFilter()


    private val imageColorInvertFilter = GPUImageColorInvertFilter()

    /**
     * Black Filters
     */

    private val luminanceFilter = GPUImageLuminanceFilter()

    private val luminanceThresholdFilter = GPUImageLuminanceThresholdFilter()


    val filtersList = listOf<FiltersData>(
        FiltersData(brightnessFilter, "None",ContextCompat.getDrawable(context, R.drawable.ic_filter_none)),
        FiltersData(retroFilter, "Retro",ContextCompat.getDrawable(context, R.drawable.ic_filter_retro)),
        FiltersData(hueFilter, "Hue",ContextCompat.getDrawable(context, R.drawable.ic_filter_hue)),
        FiltersData(posterizeFilter, "Posterize",ContextCompat.getDrawable(context, R.drawable.ic_filter_posterize)),
        FiltersData(justFilter, "Just",ContextCompat.getDrawable(context, R.drawable.ic_filter_just)),
        FiltersData(humeFilter, "Hume",ContextCompat.getDrawable(context, R.drawable.ic_filter_hume)),
        FiltersData(limoFilter, "Limo",ContextCompat.getDrawable(context, R.drawable.ic_filter_limo)),
        FiltersData(solarFilter, "Solar",ContextCompat.getDrawable(context, R.drawable.ic_filter_solar)),
        FiltersData(neutronFilter, "Neutron",ContextCompat.getDrawable(context, R.drawable.ic_filter_neutron)),
        FiltersData(milkFilter, "Milk",ContextCompat.getDrawable(context, R.drawable.ic_filter_milk)),
//        FiltersData(aeroFilter, "Aero",ContextCompat.getDrawable(context, R.drawable.ic_filter_aero)),
        FiltersData(brightnessFilter, "Brightness",ContextCompat.getDrawable(context, R.drawable.ic_filter_brightness)),
        FiltersData(contrastFilter, "contrast",ContextCompat.getDrawable(context, R.drawable.ic_filter_contrast)),
//        FiltersData(saturationFilter, "Saturation",ContextCompat.getDrawable(context, R.drawable.ic_filter_saturat)),
        FiltersData(exposureFilter, "Exposure",ContextCompat.getDrawable(context, R.drawable.ic_filter_rgb_filter)),
        FiltersData(rgbFilterFilter, "RGBFilter",ContextCompat.getDrawable(context, R.drawable.ic_filter_rgb_filter)),
        FiltersData(classicFilters, "Classic",ContextCompat.getDrawable(context, R.drawable.ic_filter_classic)),
        FiltersData(atomFilter, "Atom",ContextCompat.getDrawable(context, R.drawable.ic_filter_atom)),
        FiltersData(yeliFilter, "Sunny",ContextCompat.getDrawable(context, R.drawable.ic_filter_yeli)),
        FiltersData(marsFilter, "Mars",ContextCompat.getDrawable(context, R.drawable.ic_filter_mars)),
        FiltersData(desertFilter, "Desert",ContextCompat.getDrawable(context, R.drawable.ic_filter_desert)),
        FiltersData(oldTimesFilter, "OldTimes",ContextCompat.getDrawable(context, R.drawable.ic_filter_old_times)),
        FiltersData(monochromeFilter, "Monochrome",ContextCompat.getDrawable(context, R.drawable.ic_filter_monochrome)),
        FiltersData(sharpenFilter, "Sharpen",ContextCompat.getDrawable(context, R.drawable.ic_filter_sharpen)),
        FiltersData(embossFilter, "Emboss",ContextCompat.getDrawable(context, R.drawable.ic_filter_emboss)),
        FiltersData(toonFilter, "Toon",ContextCompat.getDrawable(context, R.drawable.ic_filter_toon)),
//        FiltersData(imageColorInvertFilter, "Invert",ContextCompat.getDrawable(context, R.drawable.ic_filter_invert)),
        FiltersData(luminanceThresholdFilter, "Threshold",ContextCompat.getDrawable(context, R.drawable.ic_filter_threshold)),
        FiltersData(clueFilter, "Clue",ContextCompat.getDrawable(context, R.drawable.ic_filter_clue)),
        FiltersData(luminanceFilter, "Luminance",ContextCompat.getDrawable(context, R.drawable.ic_filter_luminance)),
        FiltersData(muliFilter, "Muli",ContextCompat.getDrawable(context, R.drawable.ic_filter_muli))
    )
    val filters = listOf<GPUImageFilter>(
        brightnessFilter,
        contrastFilter,
        saturationFilter,
        exposureFilter,
        retroFilter,
        rgbFilterFilter,
        hueFilter,
        posterizeFilter,
        justFilter,
        humeFilter,
        limoFilter,
        solarFilter,
        neutronFilter,
        milkFilter,
        aeroFilter,
        classicFilters,
        atomFilter,
        yeliFilter,
        marsFilter,
        desertFilter,
        oldTimesFilter,
        monochromeFilter,


        sharpenFilter,
        embossFilter,
        toonFilter,

        imageColorInvertFilter,

        /**
         * Black Filters
         */

        luminanceThresholdFilter,
        clueFilter,
        luminanceFilter,
        muliFilter

    )


}