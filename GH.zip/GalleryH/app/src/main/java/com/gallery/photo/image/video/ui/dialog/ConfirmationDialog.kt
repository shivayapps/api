package com.gallery.photo.image.video.ui.dialog

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.firebase.analytics.FirebaseAnalytics
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.DialogDeleteBinding
import com.gallery.photo.image.video.utils.Constant

class ConfirmationDialog(
    var mContext: Context,
    var title: String,
    var msg: String,
    var actionPositive: String,
    val positiveBtnClickListener: () -> Unit,
    var isPermanentlyDelete: Boolean = false,
    var actionCancel: String = "",
) : BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogDeleteBinding
    lateinit var firebaseAnalytics: FirebaseAnalytics

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogDeleteBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {
        firebaseAnalytics = FirebaseAnalytics.getInstance(requireActivity())
        val bundle2 = Bundle()
        val open = when (title) {
            getString(R.string.Private) -> "PrivateConfirmation"
            getString(R.string.Unhide) -> "UnHideConfirmation"
            getString(R.string.restore) -> "RestoreConfirmation"
            getString(R.string.restore_all) -> "RestoreAllConfirmation"
            getString(R.string.delete_permanently) -> "DeletePermanentlyConfirmation"
            getString(R.string.compress) -> "CompressConfirmation"
            getString(R.string.clearFavorites) -> "clearFavoritesConfirmation"
            getString(R.string.unfavorite) -> "UnFavoriteConfirmation"
            getString(R.string.clear_all) -> "BrowserClearConfirmation"
            else -> "Confirmation"
        }
        bundle2.putString(open, Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_dialog, bundle2)


        bindingDialog.txtTitle.text = title
        bindingDialog.txtMsg.text = msg
        bindingDialog.btnDelete.text = actionPositive
        if (actionCancel.isNotEmpty())
            bindingDialog.btnCancel.text = actionCancel

        bindingDialog.txtRestoredMsg.visibility =
            if (isPermanentlyDelete) View.VISIBLE else View.GONE

        bindingDialog.btnCancel.setOnClickListener { dismiss() }
        bindingDialog.btnDelete.setOnClickListener {
            dismiss()
            positiveBtnClickListener()
        }
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)

}