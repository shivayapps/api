package com.gallery.photo.image.video.ui.dialog

import android.app.Dialog
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Bundle
import android.text.format.Formatter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.firebase.analytics.FirebaseAnalytics
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.DialogDeatilsBinding
import com.gallery.photo.image.video.duplicat_function.model_class.DataItem
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.Utils
import java.text.SimpleDateFormat
import java.util.Objects

class Details2Dialog(var dataItem: DataItem) : BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogDeatilsBinding
    lateinit var firebaseAnalytics: FirebaseAnalytics

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogDeatilsBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {

        firebaseAnalytics = FirebaseAnalytics.getInstance(requireActivity())
        val bundle2 = Bundle()
        bundle2.putString("Details", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_dialog, bundle2)

        intListener()
        bindingDialog.loutDetails.visibility = View.VISIBLE
        bindingDialog.loutMultipleDetails.visibility = View.GONE

        val formatDetails = SimpleDateFormat("dd/MM/yyyy, hh:mm aa")
        bindingDialog.txtName.text = dataItem.fileName
        bindingDialog.txtPath.text = dataItem.filePath
        val strDate = formatDetails.format(dataItem.fileDate)
        bindingDialog.txtTime.text = strDate
        bindingDialog.txtFormat.text = Utils().getFilenameExtension(dataItem.filePath ?: "")
        bindingDialog.txtSize.text = Formatter.formatShortFileSize(requireActivity(), dataItem.fileSizeLong)

        var resolution = ""
        if (Utils().isVideoFile(dataItem.filePath ?: "")) {
            resolution = try {
                val metaRetriever = MediaMetadataRetriever()
                metaRetriever.setDataSource(dataItem.filePath)
                val height =
                    Objects.requireNonNull(metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT))!!
                        .toInt()
                val width =
                    Objects.requireNonNull(metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH))!!
                        .toInt()
                "$width X $height"
            } catch (e: Exception) {
                e.printStackTrace()
                "--"
            }
        } else {
            resolution = try {
                val options = BitmapFactory.Options()
                options.inJustDecodeBounds = true
                BitmapFactory.decodeFile(dataItem.filePath, options)
                val imageHeight = options.outHeight
                val imageWidth = options.outWidth
                "$imageWidth X $imageHeight"
            } catch (e: Exception) {
                e.printStackTrace()
                "--"
            }
        }

        bindingDialog.txtResolution.text = resolution
    }

    private fun intListener() {

        bindingDialog.btnOK.setOnClickListener {
            dismiss()
        }
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}