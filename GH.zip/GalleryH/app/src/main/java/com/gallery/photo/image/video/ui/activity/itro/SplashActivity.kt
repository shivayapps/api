package com.gallery.photo.image.video.ui.activity.itro

import android.content.Intent
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.Window
import android.view.WindowManager
//import com.ads.module.open.AdconfigApplication
//import com.ads.module.open.AdconfigApplication.Companion.isNeedSplashCalled
import com.gallery.photo.image.video.BuildConfig
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.ui.activity.BaseActivity
import com.gallery.photo.image.video.ui.activity.HomeActivity
import com.gallery.photo.image.video.ui.activity.setting.LanguageActivity
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.MyApplication
import com.gallery.photo.image.video.utils.Preferences


class SplashActivity : BaseActivity() {

    lateinit var preferences: Preferences

    override fun onCreate(savedInstanceState: Bundle?) {
        Log.e("SplashTag", "onCreate")
//        isNeedSplashCalled = true
//        if (MyApplication.isAppIsRunning) {
//            AdconfigApplication.adConfigFinishAffinity()
//        } else
//            MyApplication.isAppIsRunning = true
//        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        setContentView(R.layout.activity_splash)
        intiView()
    }

    private fun intiView() {
        preferences = Preferences(this)

        val bundle2 = Bundle()
        bundle2.putString("splash", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_activity, bundle2)

        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(nextScreen())
            finish()
        },2500)
//        splashAPICalling(
//            nextScreen(),
//            if (BuildConfig.DEBUG) "com.testing.json" else "${BuildConfig.APPLICATION_ID}.json",
//            BuildConfig.VERSION_NAME,
//            false
//        )
//        Handler(Looper.myLooper()!!).postDelayed(Runnable { startActivity(nextScreen()) }, 2000)
    }

    private fun nextScreen(): Intent {
        Log.e("SplashTag", "nextScreen call")
        return if (!preferences.isLanguage())
            Intent(this, LanguageActivity::class.java)
                .putExtra(Constant.EXTRA_IS_OPEN_FROM_SPLASH, true)
        else if (!preferences.isStar())
            Intent(this, StartActivity::class.java)
        else if (!checkStoragePermission())
            Intent(this, PermissionActivity::class.java)
        else
            Intent(this, HomeActivity::class.java)
    }

}