package com.gallery.photo.image.video.ui.event

import java.util.ArrayList

data class DisplayDeleteEvent(var deleteList: ArrayList<String> , var isFromFav:Boolean = false)
