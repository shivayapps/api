package com.gallery.photo.image.video.ui.dialog

import android.app.Dialog
import android.os.Bundle
import android.text.format.Formatter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.firebase.analytics.FirebaseAnalytics
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.DialogDeatilsBinding
import com.gallery.photo.image.video.utils.Constant

class DetailsMultipleDialog(var selectedItem: Int, var selectFileSize: Long) : BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogDeatilsBinding
    lateinit var firebaseAnalytics: FirebaseAnalytics

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogDeatilsBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {
        firebaseAnalytics = FirebaseAnalytics.getInstance(requireActivity())
        val bundle2 = Bundle()
        bundle2.putString("Details", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_dialog, bundle2)

        intListener()
        bindingDialog.loutMultipleDetails.visibility = View.VISIBLE
        bindingDialog.loutDetails.visibility = View.GONE

        bindingDialog.txtContains.text = "$selectedItem ${getString(R.string.files)}"
        bindingDialog.txtTotalSize.text = Formatter.formatShortFileSize(requireActivity(), selectFileSize)
    }

    private fun intListener() {

        bindingDialog.btnOK.setOnClickListener {
            dismiss()
        }
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}