package com.gallery.photo.image.video.ui.activity.lock

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableString
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.text.style.UnderlineSpan
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.ActivitySecurityQuestionBinding
import com.gallery.photo.image.video.ui.activity.BaseActivity
import com.gallery.photo.image.video.ui.adapter.SpinnerQueAdapter
import com.gallery.photo.image.video.ui.event.CopyMoveEvent
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.Preferences
import org.greenrobot.eventbus.EventBus
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


class SecurityQuestionActivity : BaseActivity() {

    lateinit var binding: ActivitySecurityQuestionBinding
    lateinit var preferences: Preferences
    var isOpenPrivate: Boolean = false
    var isChangePass = false
    var type = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySecurityQuestionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        intView()
    }

    private fun intView() {
        val bundle2 = Bundle()
        bundle2.putString("SecurityQuestion", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_activity, bundle2)

        type = intent.getIntExtra(Constant.EXTRA_OPEN_TYPE_QUE, 0)
        isOpenPrivate = intent.getBooleanExtra(Constant.EXTRA_IS_OPEN_PRIVATE, false)
        isChangePass = intent.getBooleanExtra(Constant.EXTRA_CHANGE_PASS, false)
        preferences = Preferences(this)
        binding.loutToolbar.txtTitle.text = getString(R.string.set_Security_Question)
        intListener()

        val adapter = SpinnerQueAdapter(this, resources.getStringArray(R.array.security_question))
        binding.questionSpinner.adapter = adapter

        if (type == 1) {
            binding.questionSpinner.setSelection(preferences.getSecurityQuestion())
        }
        if (isChangePass) {
            binding.securityAnswer.setText(preferences.getAnswerQuestion())
        }

        val fulltext =
            "${getString(R.string.Hard_to_Remember)} ${getString(R.string.take_a_Screenshot)}";
//        binding.txtScreenshot.setText(fulltext, TextView.BufferType.SPANNABLE)
        val i: Int = fulltext.indexOf(getString(R.string.take_a_Screenshot))
//        view.getText()
//            .setSpan(
//                ForegroundColorSpan(color),
//                i,
//                i + subtext.length(),
//                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
//            )
        val WordtoSpan: Spannable =
            SpannableString(fulltext)
        WordtoSpan.setSpan(
            ForegroundColorSpan(ContextCompat.getColor(this, R.color.black_text)),
            i,
            fulltext.length,
            Spannable.SPAN_INCLUSIVE_EXCLUSIVE
        )
        WordtoSpan.setSpan(
            UnderlineSpan(), i,
            fulltext.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        binding.txtScreenshot.text = WordtoSpan

        binding.txtScreenshot.setOnClickListener {
            val imagePath = tackScreenshot(binding.loutMain)
            if (imagePath.isNotEmpty()) {
                val storageDir = Constant.SCREEN_SHOT_PATH
                val file = File(storageDir)
                EventBus.getDefault().post(
                    CopyMoveEvent(
                        arrayListOf(imagePath),
                        file.name,
                        file.absolutePath,
                        ArrayList()
                    )
                )
                Toast.makeText(
                    this,
                    getString(R.string.take_Screenshot_successfully),
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun intListener() {
        binding.loutToolbar.icBack.setOnClickListener {
            finish()
        }
        binding.btnConfirm.setOnClickListener {
            val answer = binding.securityAnswer.text.toString()
            if (binding.questionSpinner.selectedItemPosition == 0)
                Toast.makeText(
                    this,
                    getString(R.string.PleaseSelectQue),
                    Toast.LENGTH_SHORT
                ).show()
            else if (TextUtils.isEmpty(answer)) {
                Toast.makeText(
                    this,
                    getString(R.string.PleaseSelectQue),
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                hideSoftKeyboard()
                if (isChangePass) {
                    preferences.putSecurityQuestion(binding.questionSpinner.selectedItemPosition)
                    preferences.putAnswerQuestion(answer)
                    Toast.makeText(
                        this,
                        getString(R.string.Question_change_successfully),
                        Toast.LENGTH_SHORT
                    ).show()
                    setResult(RESULT_OK)
                    finish()
                } else if (!preferences.getSetQuestion()) {
                    preferences.putSetQuestion(true)
                    preferences.putSecurityQuestion(binding.questionSpinner.selectedItemPosition)
                    preferences.putAnswerQuestion(answer)
                    if (preferences.getShowPINLock())
                        preferences.putSetPass(true)
                    else
                        preferences.putSetPattern(true)
                    if (isOpenPrivate) startActivity(Intent(this, PrivateActivity::class.java))
                    setResult(RESULT_OK)
                    finish()
                } else {
                    if (binding.questionSpinner.selectedItemPosition == preferences.getSecurityQuestion()) {
                        if (preferences.getAnswerQuestion().equals(answer)) {
                            if (preferences.getShowPINLock()) {
                                preferences.putSetPass(false)
                                preferences.putPass("")
                            } else {
                                preferences.putSetPattern(false)
                                preferences.putPattern("")
                            }

                            lockActivityResultLauncher.launch(
                                Intent(
                                    this,
                                    LockActivity::class.java
                                ).putExtra(Constant.EXTRA_RESET_PASS, true)
                                    .putExtra(Constant.EXTRA_IS_OPEN_PRIVATE, isOpenPrivate)
                            )

                        } else {
                            Toast.makeText(
                                this,
                                R.string.msg_security_ans,
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } else Toast.makeText(
                        this,
                        R.string.msg_security_que,
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    var lockActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
            setResult(RESULT_OK)
            finish()
        }
    }

    fun hideSoftKeyboard() {
        val inputMethodManager = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        inputMethodManager.hideSoftInputFromWindow(binding.securityAnswer.windowToken, 0)
    }

    fun tackScreenshot(view: View): String {
        val bitmap = captureView(view)
        val path = saveBitmapToFile(bitmap)
        return path ?: ""
    }

    fun captureView(view: View): Bitmap {
        val bitmap = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        view.draw(canvas)
        return bitmap
    }

    fun saveBitmapToFile(bitmap: Bitmap): String? {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val fileName = "ScreenShot_SecurityQuestion_$timeStamp.jpg"

        val storageDir = Constant.SCREEN_SHOT_PATH
        val file = File(storageDir)
        if (!file.exists())
            file.mkdirs()

        val imageFile = File(storageDir, fileName)

//        var out: FileOutputStream? = null
//        try {
//            out = FileOutputStream(imageFile)
//            bitmap.compress(Bitmap.CompressFormat.PNG, 80, out)
//            val mediaScanIntent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
//            val contentUri = Uri.fromFile(imageFile)
//            mediaScanIntent.data = contentUri
//            sendBroadcast(mediaScanIntent)
//            MediaScannerConnection.scanFile(
//                this@SecurityQuestionActivity, arrayOf(imageFile.path), null
//            ) { path, uri ->
//
//            }
//            return imageFile.path
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }

        try {
            val stream = FileOutputStream(imageFile)
            bitmap.compress(Bitmap.CompressFormat.PNG, 80, stream)

            val mediaScanIntent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
            val contentUri = Uri.fromFile(imageFile)
            mediaScanIntent.data = contentUri
            sendBroadcast(mediaScanIntent)


            MediaScannerConnection.scanFile(
                this, arrayOf<String>(imageFile.path), null
            ) { path, uri ->
                // Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
            }
//            stream.flush()
            stream.close()
            return imageFile.absolutePath
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return null
    }
}