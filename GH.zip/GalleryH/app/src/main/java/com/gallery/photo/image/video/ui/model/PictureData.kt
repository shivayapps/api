package com.gallery.photo.image.video.ui.model

data class PictureData(
    var filePath: String,
    var fileName: String,
    var folderName: String= "",
    var date: Long,
    var dateTaken: Long,
    var fileSize: Long,
    var isVideo: Boolean = false,
    var videoDuration: Long = 0,
    var bucketPath: String = "",
    var isSelected: Boolean = false,
    var isCheckboxVisible: Boolean = false,
    var isFavorite: Boolean = false,
    var isPrivate: Boolean = false,
    var restorePath: String = "",
    var idDataBase: Long = 0L
)