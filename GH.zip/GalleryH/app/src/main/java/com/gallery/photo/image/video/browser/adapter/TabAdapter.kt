package com.gallery.photo.image.video.browser.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.browser.model.BrowserTab
import com.gallery.photo.image.video.databinding.ItemTabLayoutBinding

class TabAdapter(
    var context: Context,
    var tabList: ArrayList<BrowserTab>,
    var selectPos: Int,
    val clickListener: (color: Int) -> Unit,
    val deleteListener: (color: Int) -> Unit
) :
    RecyclerView.Adapter<TabAdapter.ViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemTabLayoutBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return tabList.size
    }

//    fun setSelectPos(pos: Int) {
//        selectPos = pos
//        notifyDataSetChanged()
//    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

//        holder.binding.viewSelect.visibility =
//            if (selectPos == position) View.VISIBLE else View.GONE

        if (tabList[position].tab != null) {
            holder.binding.tvUrlTitle.text =
                tabList[position].tab?.title ?: tabList[position].tabTitle
            if (tabList[position].tab?.getIcon(context) != null)
                holder.binding.ivIcon.setImageDrawable(tabList[position].tab?.getIcon(context))
            else
                holder.binding.ivIcon.setImageDrawable(
                    ContextCompat.getDrawable(
                        context,
                        R.drawable.ic_google_browser
                    )
                )

        } else {
            holder.binding.tvUrlTitle.text = tabList[position].tabTitle
            holder.binding.ivIcon.setImageDrawable(
                ContextCompat.getDrawable(
                    context,
                    R.drawable.ic_google_browser
                )
            )
        }

        if (selectPos == position)
            holder.binding.loutMain.setBackgroundColor(
                ContextCompat.getColor(
                    context,
                    R.color.divider2
                )
            )
        else
            holder.binding.loutMain.setBackgroundColor(
                ContextCompat.getColor(
                    context,
                    R.color.dialogBg
                )
            )


        holder.binding.ivDelete.setOnClickListener {
            deleteListener(position)
        }
        holder.binding.root.setOnClickListener {
            val p = selectPos
            selectPos = position
            clickListener(position)
            notifyItemChanged(selectPos)
            if (p != -1)
                notifyItemChanged(p)
        }
    }

    class ViewHolder(var binding: ItemTabLayoutBinding) : RecyclerView.ViewHolder(binding.root) {

    }
}