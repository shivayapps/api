package com.adconfig.adsutil.admob

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.util.Log
import com.adconfig.R
import android.view.WindowManager
import com.adconfig.adsutil.Config
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

class RewardedAdClass(var context: Activity) {
    companion object {
        private var rewardedAds: RewardedAd? = null
    }

    fun loadRewardedAd() {
        if (context.isOnline && rewardedAds == null && Config.isAdsEnable) {

            val adId: String = AdmobIdUtils.processAdId(
                Config.admobRewardId,
                AdmobAds.REWARD
            )

            RewardedAd.load(context, adId, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
                    override fun onAdFailedToLoad(adError: LoadAdError) {
                        Log.i("ADCONFIG_RewardedAd", "onAdFailedToLoad:${adError.code}:${adError.responseInfo}")
//                       loadRewardedAdMedium()
                    }

                    override fun onAdLoaded(rewardedAd: RewardedAd) {
                        rewardedAds = rewardedAd
                        Log.i("ADCONFIG_RewardedAd", "onAdLoaded")
                    }
                })
        }
    }

    fun displayRewardAds(callback: ClickCallback){
        if(!context.isOnline && !Config.isAdsEnable){
            callback.clickNext()
            return
        }
//        if ( SessionHelper(context).getStringData(SessionHelper.IS_REWARD_ON) != "1"){
//            callback.clickNext()
//            return
//        }
        val dialog = Dialog(context)
        dialog.setContentView(R.layout.progress_dialog)
        dialog.setCanceledOnTouchOutside(false)
        dialog.window!!.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()

        if (rewardedAds == null) {
            Log.d("TAG", "The rewarded ad wasn't ready yet.")
            dialog.dismiss()
            callback.clickNext()
            if (context.isOnline ) {
                loadRewardedAd()
            }
            return
        }
        dialog.dismiss()
        rewardedAds!!.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                // Called when ad is shown.
                Log.d("RewardedAd", "onAdShowedFullScreenContent")
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                // Called when ad fails to show.
                Log.d(
                    "RewardedAd",
                    "onAdFailedToShowFullScreenContent"
                )
                // Don't forget to set the ad reference to null so you
                // don't show the ad a second time.
                rewardedAds = null
                dialog.dismiss()
                callback.clickNext()
            }

            override fun onAdDismissedFullScreenContent() {
                // Called when ad is dismissed.
                // Don't forget to set the ad reference to null so you
                // don't show the ad a second time.
                rewardedAds = null
                Log.d("RewardedAd", "onAdDismissedFullScreenContent")
                // Preload the next rewarded ad.
                loadRewardedAd()
                dialog.dismiss()
                callback.clickNext()

            }

            override fun onAdClicked() {
                super.onAdClicked()
            }
        }
        rewardedAds!!.show(context) { rewardItem -> // Handle the reward.
            Log.d("RewardedAd", "The user earned the reward.")
            val rewardAmount = rewardItem.amount
            val rewardType = rewardItem.type
        }
    }


    private inline val Context.isOnline: Boolean
        get() {
            (getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).let { connectivityManager ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    connectivityManager.getNetworkCapabilities(connectivityManager.activeNetwork)?.let {
                        return it.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                    }
                } else {
                    try {
                        connectivityManager.activeNetworkInfo?.let {
                            if (it.isConnected && it.isAvailable) {
                                return true
                            }
                        }
                    } catch (e: Exception) {
                    }
                }
            }
            return false
        }


}