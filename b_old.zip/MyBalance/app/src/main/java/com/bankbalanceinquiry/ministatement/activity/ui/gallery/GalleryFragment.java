package com.bankbalanceinquiry.ministatement.activity.ui.gallery;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.bankbalanceinquiry.ministatement.R;


public class GalleryFragment extends Fragment {



    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_gallery, container, false);

        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/developer?id=shivayapps&hl=en"));
        startActivity(intent);


        onbackPressed();


        return root;
    }

    public  void onbackPressed()
    {
        super.getActivity().onBackPressed();
    }
}