package com.bankbalanceinquiry.ministatement.model;

public class mbalance  {

    int avaBalance;

    public int getAvaBalance() {
        return avaBalance;
    }

    public void setAvaBalance(int avaBalance) {
        this.avaBalance = avaBalance;
    }
}
