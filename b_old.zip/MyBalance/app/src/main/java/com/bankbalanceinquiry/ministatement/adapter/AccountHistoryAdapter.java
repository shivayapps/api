package com.bankbalanceinquiry.ministatement.adapter;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bankbalanceinquiry.ministatement.utils.TextDrawable;
import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.model.AllAccountModelHistory;
import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;
import com.marcoscg.dialogsheet.DialogSheet;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class AccountHistoryAdapter extends
        RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private ArrayList<HomeAccoutList> dataSet;

    private Context mContext;
    private Activity activity;
    private int total_types;
    private int bgColor;

    public ClickHistory ApkDetails;

    public interface ClickHistory {
        public void ClickValue(AllAccountModelHistory callNumber);
    }

    public void RegisterInterface(ClickHistory photoInterface) {
        this.ApkDetails = photoInterface;
    }

    public static class TypeTitle extends RecyclerView.ViewHolder {
        private TextView tvTitle;
        private TextView tvCreditedAmount;
        private TextView tvDebitedAmount;

        public TypeTitle(View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvCreditedAmount = itemView.findViewById(R.id.tvCreditedAmount);
            tvDebitedAmount = itemView.findViewById(R.id.tvDebitedAmount);
        }
    }

    public static class TypeData extends RecyclerView.ViewHolder {
        private ImageView micName;
        private TextView tvDDate;
        private TextView tvAmount;
        private TextView tvSenderName;
        private TextView tvUnknown;
        private LinearLayout mMainLayout;

        public TypeData(View itemView) {
            super(itemView);
            micName = itemView.findViewById(R.id.micName);
            tvDDate = itemView.findViewById(R.id.tvDDate);
            tvAmount = itemView.findViewById(R.id.tvAmount);
            tvSenderName = itemView.findViewById(R.id.tvSenderName);
            tvUnknown = itemView.findViewById(R.id.tvUnknown);
            mMainLayout = itemView.findViewById(R.id.mainLayout);
        }
    }

    public AccountHistoryAdapter(Activity context, ArrayList<HomeAccoutList> data, int color) {
        this.activity = context;
        this.dataSet = data;
        this.bgColor = color;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        switch (viewType) {
            case 0:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.raw_history_title, parent, false);
                return new TypeTitle(view);
            case 1:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.raw_history_data, parent, false);
                return new TypeData(view);
        }
        return null;
    }

    @Override
    public int getItemViewType(int position) {
        switch (dataSet.get(position).GetTitleType) {
            case 0:
                return 0;
            case 1:
                return 1;
            default:
                return -1;
        }
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder,
                                 final int listPosition) {
        HomeAccoutList object = dataSet.get(listPosition);
        if (object != null) {
            switch (object.GetTitleType) {
                case 0:
                    CallTitleType(((TypeTitle) holder), object);
                    break;
                case 1:
                    CallDataType(((TypeData) holder), object, listPosition);
                    break;
            }
        }
    }

    private void CallDataType(TypeData holder, final HomeAccoutList object, final int listPosition) {
        ImageView micName = holder.micName;
        TextView tvDDate = holder.tvDDate;
        TextView tvAmount = holder.tvAmount;
        TextView tvSenderName = holder.tvSenderName;
        TextView tvUnknown = holder.tvUnknown;
       /* String FirstName = object.getSenderName();
        String FirstLetter = FirstName.substring(0, 1);*/


        Date date = new Date(System.currentTimeMillis());
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy", Locale.US);
        String year = simpleDateFormat.format(date);
        String dateVal = object.dateValHistory;
        if (object.dateValHistory.contains(year)) {
            dateVal = object.dateValHistory.replace(" " + year, "");
        }

        tvDDate.setText(dateVal);
        String Amout = object.amount;
        if (TextUtils.isEmpty(Amout)) {
            Amout = "0";
        }
        if (object.isDebited) {
            tvAmount.setTextColor(ContextCompat.getColor(activity, R.color.google_red));
            holder.mMainLayout.setBackgroundColor(ContextCompat.getColor(activity, R.color.google_red_light));
        } else {
            tvAmount.setTextColor(ContextCompat.getColor(activity, R.color.google_green));
        }
        if (Amout.contains(",")) {
            Amout = Amout.replace(",","");
        }
        Amout = Amout.replaceAll("[^\\d.]", "");
        double d = Double.parseDouble(Amout);
        if (Amout.contains(".")) {
            String afterPoint = Amout.substring(Amout.indexOf(".") + 1);
            if (afterPoint.length() > 2) {
                DecimalFormat decim = new DecimalFormat("#,##,###.##");
                Amout = decim.format(d);
            }
        }
        DecimalFormat decim = new DecimalFormat("#,##,###.##");
        Amout = decim.format(d);


        tvAmount.setText(activity.getString(R.string.Rs) + " " + Amout);
        tvSenderName.setText(object.transactionDesc);
        final int drawable = getTransactionImage(object.transactionDesc);
        if (drawable != -1) {
            micName.setImageResource(drawable);
        } else {
            String FirstName = object.transactionDesc.replaceAll(" ", "");
            if (!TextUtils.isEmpty(FirstName)) {
                String FirstLetter = FirstName.substring(0, 1);
                TextDrawable drawable1 = TextDrawable.builder()
                        .buildRound(FirstLetter, ContextCompat.getColor(activity, R.color.app_color));
                micName.setImageDrawable(drawable1);
            }
        }
        if (!TextUtils.isEmpty(object.finalTransactionDesc)) {
            tvUnknown.setText(object.finalTransactionDesc);
        } else {
            tvUnknown.setVisibility(View.GONE);
        }

        holder.mMainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent i = new Intent(activity, TransactionDetailsActivity.class);
//                i.putExtra("OBJ", object);
//                i.putExtra("color", bgColor);
//                i.putExtra("icon", drawable);
//                activity.startActivity(i);

                new DialogSheet(activity)
                        .setTitle("Account no" + (object.FinalAccountNo.length() < 4 ? " - X" : " - ") + object.FinalAccountNo)
                        .setMessage(object.body)
                        .setColoredNavigationBar(true)
                        .setTitleTextSize(20)
                        .setButtonsTextSize(15)
                        .setBackgroundColor(Color.WHITE)
                        .show();
            }
        });

    }

    private void CallTitleType(TypeTitle holder, HomeAccoutList object) {
        holder.tvTitle.setText(object.DateTransactionHistory);

//        Log.e("WWWWW==>", object.getCreditedData().size() + "");

        String AmoutCredited = CallAccountBalanceTesting(object.CreditedData);
        String AmoutDebited = CallAccountBalanceTesting(object.DebitedData);
        holder.tvCreditedAmount.setText(activity.getString(R.string.Rs) + " " + AmoutCredited);
        holder.tvDebitedAmount.setText(activity.getString(R.string.Rs) + " " + AmoutDebited);
    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }

    private String CallAccountBalanceTesting(ArrayList<String> tempList) {
//        StringBuilder finalallbalance = new StringBuilder();
        double sum = 0;
        for (int i = 0; i < tempList.size(); i++) {
            String AmoutValue = tempList.get(i);
            if (!TextUtils.isEmpty(AmoutValue)) {
                double value = Double.parseDouble(AmoutValue);
                sum += value;
//                finalallbalance.append(AmoutValue);
            }
        }
        String s = String.valueOf(sum);
        if (s.contains(".")) {
            String afterPoint = s.substring(s.indexOf(".") + 1);
            if (afterPoint.length() > 2) {
                DecimalFormat decim = new DecimalFormat("#,##,###.##");
                return decim.format(sum);
            }
        }
        DecimalFormat decim = new DecimalFormat("#,##,###.##");
        return decim.format(sum);
//        return String.valueOf(CommonFun.findSum(finalallbalance.toString()));
    }

    private int getTransactionImage(String transactionType) {
        switch (transactionType) {
            case "Your Account Balance":
                return R.drawable.ic_your_account_balance;
            case "UPI Transaction":
                return R.drawable.ic_upi_transaction;
            case "Debit Card Transaction":
                return R.drawable.ic_debit_card_transaction;
            case "Net Banking":
                return R.drawable.ic_net_banking;
            case "Credited to your Account":
                return R.drawable.ic_credited_to_your_account;
            case "Cheque Transaction":
                return R.drawable.ic_cheque_transaction;
            case "ATM withdrawal":
                return R.drawable.ic_atm_withdrawal;
            case "Credit Card Transaction":
                return R.drawable.ic_credit_card_transaction;
            case "Credit Card Bill":
                return R.drawable.ic_credit_card_bill;
            case "Loan EMI":
                return R.drawable.ic_loan_emi;
            case "Mobile Bill":
                return R.drawable.ic_mobile_bill;
            case "Prepaid Debit Card Transaction":
                return R.drawable.ic_prepaid_debit_card_transaction;
            case "Bill":
                return R.drawable.ic_bill;
            case "Internet Bill":
                return R.drawable.ic_internet_bill;
            case "Electricity Bill":
                return R.drawable.ic_electricity_bill;
            case "Insurance Premium":
                return R.drawable.ic_insurance_premium;
            case "Gas Bill":
                return R.drawable.ic_gas_bill;
        }
        return -1;
    }
}
