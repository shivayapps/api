package com.bankbalanceinquiry.ministatement.fragment;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.common.CommonFun;
import com.bankbalanceinquiry.ministatement.inapp.AdsManager;
import com.bankbalanceinquiry.ministatement.utils.NetworkManager;
import com.example.app.ads.helper.AdMobAdsUtilsKt;
import com.example.app.ads.helper.NativeAdsSize;
import com.example.app.ads.helper.NativeAdvancedModelHelper;

import static android.content.Intent.ACTION_DIAL;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;

public class sendMoneyFragment extends Fragment {
    public static String money_from;

    LinearLayout to_mobile, to_payment, to_saved, to_ifsc, to_mmid, c_bank, c_language, my_bankl, my_payment, manage_b, reset_pin, change_pin;
    RelativeLayout send_moeny_rel, profile_rel, upi_pin_rel;

    CardView to_native_ad,reset_ad,native_ad;
    FrameLayout fl_adplaceholder_send, fl_adplaceholder_profile, fl_adplaceholder_pin;
    Context mContext;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_sendmoney, container, false);

        mContext = getActivity();
        send_moeny_rel = (RelativeLayout) view.findViewById(R.id.send_moeny_rel);
        profile_rel = (RelativeLayout) view.findViewById(R.id.profile_rel);
        upi_pin_rel = (RelativeLayout) view.findViewById(R.id.upi_pin_rel);


        to_mobile = (LinearLayout) view.findViewById(R.id.to_mobile);
        to_payment = (LinearLayout) view.findViewById(R.id.to_payment);
        to_saved = (LinearLayout) view.findViewById(R.id.to_beneficiary);
        to_ifsc = (LinearLayout) view.findViewById(R.id.to_ifsc);
        to_mmid = (LinearLayout) view.findViewById(R.id.to_mmid);

        c_bank = (LinearLayout) view.findViewById(R.id.c_bank);
        c_language = (LinearLayout) view.findViewById(R.id.c_language);
        my_bankl = (LinearLayout) view.findViewById(R.id.my_bankl);
        my_payment = (LinearLayout) view.findViewById(R.id.my_payment);
        manage_b = (LinearLayout) view.findViewById(R.id.manage_b);

        reset_pin = (LinearLayout) view.findViewById(R.id.reset_pin);
        change_pin = (LinearLayout) view.findViewById(R.id.change_upi);
        money_from = ussdBankingFragment.money;

        fl_adplaceholder_send = (FrameLayout) view.findViewById(R.id.fl_adplaceholder_send_money);
        to_native_ad = (CardView) view.findViewById(R.id.to_native_ad);
        fl_adplaceholder_profile = (FrameLayout) view.findViewById(R.id.fl_adplaceholder_profile);
        native_ad = (CardView) view.findViewById(R.id.native_ad);
        fl_adplaceholder_pin = (FrameLayout) view.findViewById(R.id.fl_adplaceholder_pin);
        reset_ad = (CardView) view.findViewById(R.id.reset_ad);
//        refreshAd();
        if (!TextUtils.isEmpty(money_from)) {
            if (money_from.matches("send")) {
                send_moeny_rel.setVisibility(View.VISIBLE);
                profile_rel.setVisibility(View.GONE);
                upi_pin_rel.setVisibility(View.GONE);

                if (new AdsManager(getActivity()).isNeedToShowAds() && NetworkManager.isInternetConnected(getActivity())) {

                    new NativeAdvancedModelHelper(getActivity()).loadNativeAdvancedAd(
                            AdMobAdsUtilsKt.getSendMoneyFragAd(),
                            fl_adplaceholder_send,
                            null, true, true, new Function1<Boolean, Unit>() {
                                @Override
                                public Unit invoke(Boolean aBoolean) {
                                    to_native_ad.setVisibility(View.VISIBLE);
                                    return null;
                                }
                            }, new Function0<Unit>() {
                                @Override
                                public Unit invoke() {
                                    return null;
                                }
                            });
                }

            } else if (money_from.matches("profile")) {
                upi_pin_rel.setVisibility(View.GONE);
                send_moeny_rel.setVisibility(View.GONE);
                profile_rel.setVisibility(View.VISIBLE);


                if (new AdsManager(getActivity()).isNeedToShowAds() && NetworkManager.isInternetConnected(getActivity())) {

                    new NativeAdvancedModelHelper(getActivity()).loadNativeAdvancedAd(
                            AdMobAdsUtilsKt.getSendMoneyFragAd(),
                            fl_adplaceholder_profile,
                            null, true, true, new Function1<Boolean, Unit>() {
                                @Override
                                public Unit invoke(Boolean aBoolean) {
                                    native_ad.setVisibility(View.VISIBLE);
                                    return null;
                                }
                            }, new Function0<Unit>() {
                                @Override
                                public Unit invoke() {
                                    return null;
                                }
                            });
                }

            } else if (money_from.matches("upi")) {
                upi_pin_rel.setVisibility(View.VISIBLE);
                send_moeny_rel.setVisibility(View.GONE);
                profile_rel.setVisibility(View.GONE);

                if (new AdsManager(getActivity()).isNeedToShowAds() && NetworkManager.isInternetConnected(getActivity())) {

                    new NativeAdvancedModelHelper(getActivity()).loadNativeAdvancedAd(
                            AdMobAdsUtilsKt.getSendMoneyFragAd(),
                            fl_adplaceholder_pin,
                            null, true, true, new Function1<Boolean, Unit>() {
                                @Override
                                public Unit invoke(Boolean aBoolean) {
                                    reset_ad.setVisibility(View.VISIBLE);
                                    return null;
                                }
                            }, new Function0<Unit>() {
                                @Override
                                public Unit invoke() {
                                    return null;
                                }
                            });
                }
            }
        }
        to_mobile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Uri number = Uri.parse("tel:" + Uri.encode("*99*1*1#"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
//                startActivity(callIntent);
                CommonFun.invokeCall(getActivity(),callIntent);

            }
        });
        to_payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Uri number = Uri.parse("tel:" + Uri.encode("*99*1*2#"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
//                startActivity(callIntent);
                CommonFun.invokeCall(getActivity(),callIntent);
            }
        });
        to_saved.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Uri number = Uri.parse("tel:" + Uri.encode("*99*1*3#"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
//                startActivity(callIntent);
                CommonFun.invokeCall(getActivity(),callIntent);
            }
        });
        to_ifsc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Uri number = Uri.parse("tel:" + Uri.encode("*99*1*4#"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
//                startActivity(callIntent);
                CommonFun.invokeCall(getActivity(),callIntent);
            }
        });
        to_mmid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Uri number = Uri.parse("tel:" + Uri.encode("*99*1*5#"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
//                startActivity(callIntent);
                CommonFun.invokeCall(getActivity(),callIntent);
            }
        });


        c_bank.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Uri number = Uri.parse("tel:" + Uri.encode("*99*4*1#"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
//                startActivity(callIntent);
                CommonFun.invokeCall(getActivity(),callIntent);
            }
        });
        c_language.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Uri number = Uri.parse("tel:" + Uri.encode("*99*4*2#"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
//                startActivity(callIntent);
                CommonFun.invokeCall(getActivity(),callIntent);
            }
        });
        my_bankl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Uri number = Uri.parse("tel:" + Uri.encode("*99*4*3#"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
//                startActivity(callIntent);
                CommonFun.invokeCall(getActivity(),callIntent);
            }
        });
        my_payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Uri number = Uri.parse("tel:" + Uri.encode("*99*4*4#"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
//                startActivity(callIntent);
                CommonFun.invokeCall(getActivity(),callIntent);
            }
        });
        manage_b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Uri number = Uri.parse("tel:" + Uri.encode("*99*4*5#"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
//                startActivity(callIntent);
                CommonFun.invokeCall(getActivity(),callIntent);
            }
        });

        reset_pin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Uri number = Uri.parse("tel:" + Uri.encode("*99*7*1#"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
//                startActivity(callIntent);
                CommonFun.invokeCall(getActivity(),callIntent);
            }
        });
        change_pin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri number = Uri.parse("tel:" + Uri.encode("*99*7*2#"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
//                startActivity(callIntent);
                CommonFun.invokeCall(getActivity(),callIntent);

            }
        });
        return view;
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
