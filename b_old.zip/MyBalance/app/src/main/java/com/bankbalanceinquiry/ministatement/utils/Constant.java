package com.bankbalanceinquiry.ministatement.utils;

public class Constant {

    public static String AD_URL = "https://raw.githubusercontent.com/Mahendra-Gohil/api/main/ads.json";
//    public static String AD_URL = "https://raw.githubusercontent.com/shivayapps/api/main/ads_checkbalance.json";
    public static String PRODUCT_REMOVEADS = "com.bankbalanceinquiry.ministatement.removeads";
    public static String IS_FULLPRO = "is_fullpro";
    public static String LIVE_AD = "admob";
    public static String G_APP_ID = "g_app_id";
    public static String G_NATIVE_ID = "g_native_id";
    public static String G_INTERSTITIAL_ID = "g_interstitial_id";
    public static String G_BANNER_ID = "g_banner_id";
    public static String G_APPOPEN_ID = "g_appopen_id";

    public static String F_NATIVE_ID = "f_native_id";
    public static String F_INTERSTITIAL_ID = "f_interstitial_id";
    public static String F_BANNER_ID = "f_banner_id";
    public static String G_NATIVE_BANNER_ID = "g_nativebanner_id";

    public static String IS_FROM_NOTIFICATION = "isfromnotification";
    public static String IS_FROM_NOTIFICATION_MESSAGE = "isfromnotificationmessage";
    public static String IS_FROM_NOTIFICATION_type = "isfromnotificationtype";

    public static String LOGIN_PREF = "login_pref";
    public static String TRACK_PREF = "track_pref";

    public static String[] TRACK_TITLE = new String[]{"YOUR MONEY\nMADE SIMPLE", "BILL\nREMINDERS", "ATM CASH\nDETAILS", "KNOW\nYOUR EXPENSES"};
    public static String[] TRACK_DESCRIPTION = new String[]{"Transform your SMS inbox into a daily interactive report", "Automatic bill detection. No more late fees", "See All your Withdrawals in one place", "Calculate Your budget according your expenses"};

    public static String PREF_SHOW_PLATEFORM_ID = "show_plateform_id";
    public static String PREF_NATIVE_AD_ID = "native_ad_id";
    public static String PREF_BANNER_AD_ID = "banner_ad_id";
    public static String PREF_INTERSIAL_AD_ID = "intersial_ad_id";
    public static String PREF_ADMOB_UNIT_ID = "admob_unit_id";

    public static String NATIVE_AD_KEY = "native_id";
    public static String INTERSIAL_AD_KEY = "interstitial_id";
    public static String BANNER_AD_KEY = "banner_id";
    public static String UNIT_AD_KEY = "app_id";

    public static String ADMOB_AD_KEY = "admob";
    public static String SHOW_PLATEFORM_AD_KEY = "showplatform";

    public static String Last_Time_Show_Interstitial = "lastTimeShowInterstitial";
}
