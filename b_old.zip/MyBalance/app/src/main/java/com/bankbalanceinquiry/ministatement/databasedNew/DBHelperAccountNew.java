package com.bankbalanceinquiry.ministatement.databasedNew;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.text.TextUtils;

import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DBHelperAccountNew extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "MyDBNameNew.db";
    public final String CONTACTS_TABLE_NAME = "transactionData";
    private HashMap hp;

    public DBHelperAccountNew(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        if (!checkForTableExists("transactionData", db)) {
            db.execSQL("create table transactionData " +
                    "(id integer primary key,FinalAccountNo,FinalAccountBalance,full_name,finalTransactionDesc" +
                    ",account_type" +
                    ",sms_type" +
                    ",body" +
                    ",transactionDescs" +
                    ",dates" +
                    ",dateFormats" +
                    ",amounts" +
                    ",eventNames" +
                    ",eventLocations" +
                    ",eventInfos" +
                    ",panValue" +
                    ",mTransactionType" +
                    ",transactionDesc" +
                    ",transactionPos" +
                    ",date" +
                    ",amount" +
                    ",eventName" +
                    ",eventLocation" +
                    ",eventInfo" +
                    ",txn_type" +
                    ",isDebited" +
                    ",isAtmWithDraw" +
                    ",use_sms_time" +
                    ",dateValAccount, DateTransactionHistory, dateValHistory)"
            );
        }
        if (!checkForTableExists("accountsData", db)) {
            db.execSQL("create table accountsData " +
                    "(id integer primary key,FinalAccountNo,FinalAccountBalance,full_name,account_type,dateValAccount)"
            );
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS transactionData");
        onCreate(db);
    }

    public void InsertTransaction(HomeAccoutList homeAccount) {
        Gson gson = new Gson();
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("FinalAccountNo", homeAccount.FinalAccountNo);
        contentValues.put("FinalAccountBalance", homeAccount.FinalAccountBalance);
        contentValues.put("full_name", homeAccount.full_name);
        contentValues.put("finalTransactionDesc", homeAccount.finalTransactionDesc);
        contentValues.put("account_type", homeAccount.account_type);
        contentValues.put("sms_type", homeAccount.sms_type);
        contentValues.put("body", homeAccount.body);
        contentValues.put("transactionDescs", homeAccount.transactionDescs.size() != 0 ? gson.toJson(homeAccount.transactionDescs) : "");
        contentValues.put("dates", homeAccount.dates.size() != 0 ? gson.toJson(homeAccount.dates) : "");
        contentValues.put("dateFormats", homeAccount.dateFormats.size() != 0 ? gson.toJson(homeAccount.dateFormats) : "");
        contentValues.put("amounts", homeAccount.amounts.size() != 0 ? gson.toJson(homeAccount.amounts) : "");
        contentValues.put("eventNames", homeAccount.eventNames.size() != 0 ? gson.toJson(homeAccount.eventNames) : "");
        contentValues.put("eventLocations", homeAccount.eventLocations.size() != 0 ? gson.toJson(homeAccount.eventLocations) : "");
        contentValues.put("eventInfos", homeAccount.eventInfos.size() != 0 ? gson.toJson(homeAccount.eventInfos) : "");
        contentValues.put("panValue", homeAccount.panValue);
        contentValues.put("mTransactionType", homeAccount.mTransactionType);
        contentValues.put("transactionDesc", homeAccount.transactionDesc);
        contentValues.put("transactionPos", homeAccount.transactionPos);
        contentValues.put("date", homeAccount.date);
        contentValues.put("amount", homeAccount.amount);
        contentValues.put("eventName", homeAccount.eventName);
        contentValues.put("eventLocation", homeAccount.eventLocation);
        contentValues.put("eventInfo", homeAccount.eventInfo);
        contentValues.put("txn_type", homeAccount.txn_type);
        contentValues.put("isDebited", String.valueOf(homeAccount.isDebited));
        contentValues.put("isAtmWithDraw", String.valueOf(homeAccount.isAtmWithDraw));
        contentValues.put("use_sms_time", String.valueOf(homeAccount.use_sms_time));
        contentValues.put("dateValAccount", homeAccount.dateValAccount);
        contentValues.put("DateTransactionHistory", homeAccount.DateTransactionHistory);
        contentValues.put("dateValHistory", homeAccount.dateValHistory);
        db.insert("transactionData", null, contentValues);
    }

    public void InsertAccount(HomeAccoutList homeAccount) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("FinalAccountNo", homeAccount.FinalAccountNo);
        contentValues.put("FinalAccountBalance", homeAccount.FinalAccountBalance);
        contentValues.put("full_name", homeAccount.full_name);
        contentValues.put("dateValAccount", homeAccount.dateValAccount);
        contentValues.put("account_type", homeAccount.account_type);
        db.insert("accountsData", null, contentValues);
    }

    public Cursor getData(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from transactionData where id=" + id + "", null);
        return res;
    }

    public int numberOfRows() {
        SQLiteDatabase db = this.getReadableDatabase();
        return (int) DatabaseUtils.queryNumEntries(db, CONTACTS_TABLE_NAME);
    }


    public ArrayList<HomeAccoutList> GetAllAccountNew() {
        ArrayList<HomeAccoutList> ownerDetails = new ArrayList<HomeAccoutList>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from accountsData", null);
        if (res != null && res.getCount() != 0) {
            while (res.moveToNext()) {
                HomeAccoutList homeAccount = new HomeAccoutList();
                homeAccount.FinalAccountNo = res.getString(res.getColumnIndex("FinalAccountNo"));
                homeAccount.FinalAccountBalance = res.getString(res.getColumnIndex("FinalAccountBalance"));
                homeAccount.full_name = res.getString(res.getColumnIndex("full_name"));
                homeAccount.dateValAccount = res.getString(res.getColumnIndex("dateValAccount"));
                homeAccount.account_type = res.getString(res.getColumnIndex("account_type"));
                ownerDetails.add(homeAccount);
            }
            res.close();
        }
        return ownerDetails;
    }
    public ArrayList<HomeAccoutList> GetAllAccountAdp() {
        ArrayList<HomeAccoutList> ownerDetails = new ArrayList<HomeAccoutList>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from accountsData", null);

        //HomeAccoutList temp = new HomeAccoutList();
        //temp.FinalAccountNo = "00";
        //temp.FinalAccountBalance = "00";
        //temp.full_name = "Change Bank";
        //temp.dateValAccount = "00";

        //ownerDetails.add(temp);

        if (res != null && res.getCount() != 0) {
            while (res.moveToNext()) {
                //boolean isAdded=false;
                HomeAccoutList homeAccount = new HomeAccoutList();
                homeAccount.FinalAccountNo = res.getString(res.getColumnIndex("FinalAccountNo"));
                homeAccount.FinalAccountBalance = res.getString(res.getColumnIndex("FinalAccountBalance"));
                homeAccount.full_name = res.getString(res.getColumnIndex("full_name"));
                homeAccount.dateValAccount = res.getString(res.getColumnIndex("dateValAccount"));
                homeAccount.account_type = res.getString(res.getColumnIndex("account_type"));
                /*for(int i=0;i<ownerDetails.size();i++) {
                    if(ownerDetails.get(i).full_name.equalsIgnoreCase(homeAccount.full_name)) {
                        isAdded=true;
                    }
                }*/
                //if(!isAdded)
                    ownerDetails.add(homeAccount);
            }
            res.close();
        }
        return ownerDetails;
    }

    public ArrayList<HomeAccoutList> GetAllTransaction() {
        Gson gson = new Gson();
        ArrayList<HomeAccoutList> ownerDetails = new ArrayList<>();
        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from transactionData", null);
        if (res != null && res.getCount() != 0) {
            while (res.moveToNext()) {
                HomeAccoutList homeAccount = getItem(res, gson);
                ownerDetails.add(homeAccount);
            }
            res.close();
        }
        return ownerDetails;
    }


    public ArrayList<HomeAccoutList> GetTransactions(String accountNo, String accountName) {
        Gson gson = new Gson();
        ArrayList<HomeAccoutList> ownerDetails = new ArrayList<>();
        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res;
        if (TextUtils.isEmpty(accountNo)) {
            res = db.rawQuery("select * from transactionData where full_name='" + accountName + "'", null);
        } else if (TextUtils.isEmpty(accountName)) {
            res = db.rawQuery("select * from transactionData where FinalAccountNo='" + accountNo + "'", null);
        } else {
            res = db.rawQuery("select * from transactionData where FinalAccountNo='" + accountNo + "' AND full_name='" + accountName + "'", null);
        }

        if (res != null && res.getCount() != 0) {
            while (res.moveToNext()) {
                HomeAccoutList homeAccount = getItem(res, gson);
                ownerDetails.add(homeAccount);
            }
            res.close();
        }
        return ownerDetails;
    }

    public ArrayList<HomeAccoutList> GetSpecificBills(String key) {
        Gson gson = new Gson();
        ArrayList<HomeAccoutList> ownerDetails = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from transactionData  where account_type = ?",
                new String[]{key});
        if (res != null && res.getCount() != 0) {
            while (res.moveToNext()) {
                HomeAccoutList homeAccount = getItem(res, gson);
                if (homeAccount.account_type.equalsIgnoreCase("credit_card")) {
                    if (homeAccount.mTransactionType.equalsIgnoreCase("credit_card_bill")) {
                        ownerDetails.add(homeAccount);
                    }
                } else {
                    ownerDetails.add(homeAccount);
                }

            }
            res.close();
        }
        return ownerDetails;
    }

    public ArrayList<HomeAccoutList> GetAllBills() {
        Gson gson = new Gson();
        ArrayList<HomeAccoutList> ownerDetails = new ArrayList<HomeAccoutList>();
        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
//        Cursor res = db.rawQuery("select * from transactionData ", null);
        Cursor res = db.rawQuery("select * from transactionData  where account_type = ? OR account_type = ? OR  account_type = ? OR" +
                        " account_type = ?" + "OR account_type = ? OR  account_type = ? OR account_type = ? OR" +
                        " account_type = ?",
                new String[]{"loan", "prepaid", "phone", "credit_card", "generic", "electricity", "insurance", "gas"});
        if (res != null && res.getCount() != 0) {
            while (res.moveToNext()) {
                HomeAccoutList homeAccount = getItem(res, gson);
                if (homeAccount.account_type.equalsIgnoreCase("credit_card")) {
                    if (homeAccount.mTransactionType.equalsIgnoreCase("credit_card_bill")) {
                        ownerDetails.add(homeAccount);
                    }
                } else {
                    ownerDetails.add(homeAccount);
                }

            }
            res.close();
        }
        return ownerDetails;
    }

    public ArrayList<HomeAccoutList> GetAllAtmWithdraw() {
        Gson gson = new Gson();
        ArrayList<HomeAccoutList> ownerDetails = new ArrayList<HomeAccoutList>();
        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
//        Cursor res = db.rawQuery("select * from transactionData ", null);
        Cursor res = db.rawQuery("select * from transactionData  where isAtmWithDraw = ? OR mTransactionType = ?",
                new String[]{"true","cheque"});
        if (res != null && res.getCount() != 0) {
            while (res.moveToNext()) {
                HomeAccoutList homeAccount = getItem(res, gson);
                ownerDetails.add(homeAccount);
            }
            res.close();
        }
        return ownerDetails;
    }


    private HomeAccoutList getItem(Cursor res, Gson gson) {
        HomeAccoutList homeAccount = new HomeAccoutList();
        homeAccount.FinalAccountNo = res.getString(res.getColumnIndex("FinalAccountNo"));
        homeAccount.FinalAccountBalance = res.getString(res.getColumnIndex("FinalAccountBalance"));
        homeAccount.full_name = res.getString(res.getColumnIndex("full_name"));
        homeAccount.finalTransactionDesc = res.getString(res.getColumnIndex("finalTransactionDesc"));

        homeAccount.account_type = res.getString(res.getColumnIndex("account_type"));
        homeAccount.sms_type = res.getString(res.getColumnIndex("sms_type"));
        homeAccount.body = res.getString(res.getColumnIndex("body"));
        String transactionDescs = res.getString(res.getColumnIndex("transactionDescs"));
        if (!TextUtils.isEmpty(transactionDescs)) {
            homeAccount.transactionDescs = gson.fromJson(transactionDescs, new TypeToken<List<String>>() {
            }.getType());
        }
        String dates = res.getString(res.getColumnIndex("dates"));
        if (!TextUtils.isEmpty(dates)) {
            homeAccount.dates = gson.fromJson(dates, new TypeToken<List<String>>() {
            }.getType());
        }
        String dateFormats = res.getString(res.getColumnIndex("dateFormats"));
        if (!TextUtils.isEmpty(dateFormats)) {
            homeAccount.dateFormats = gson.fromJson(dateFormats, new TypeToken<List<String>>() {
            }.getType());
        }
        String amounts = res.getString(res.getColumnIndex("amounts"));
        if (!TextUtils.isEmpty(amounts)) {
            homeAccount.amounts = gson.fromJson(amounts, new TypeToken<List<String>>() {
            }.getType());
        }
        String eventNames = res.getString(res.getColumnIndex("eventNames"));
        if (!TextUtils.isEmpty(eventNames)) {
            homeAccount.eventNames = gson.fromJson(eventNames, new TypeToken<List<String>>() {
            }.getType());
        }
        String eventLocations = res.getString(res.getColumnIndex("eventLocations"));
        if (!TextUtils.isEmpty(eventLocations)) {
            homeAccount.eventLocations = gson.fromJson(eventLocations, new TypeToken<List<String>>() {
            }.getType());
        }
        String eventInfos = res.getString(res.getColumnIndex("eventInfos"));
        if (!TextUtils.isEmpty(eventInfos)) {
            homeAccount.eventInfos = gson.fromJson(eventInfos, new TypeToken<List<String>>() {
            }.getType());
        }

        homeAccount.panValue = res.getString(res.getColumnIndex("panValue"));
        homeAccount.mTransactionType = res.getString(res.getColumnIndex("mTransactionType"));
        homeAccount.transactionDesc = res.getString(res.getColumnIndex("transactionDesc"));
        homeAccount.transactionPos = res.getString(res.getColumnIndex("transactionPos"));

        homeAccount.date = res.getString(res.getColumnIndex("date"));
        homeAccount.amount = res.getString(res.getColumnIndex("amount"));
        homeAccount.eventName = res.getString(res.getColumnIndex("eventName"));
        homeAccount.eventLocation = res.getString(res.getColumnIndex("eventLocation"));
        homeAccount.eventInfo = res.getString(res.getColumnIndex("eventInfo"));
        homeAccount.txn_type = res.getString(res.getColumnIndex("txn_type"));
        String s = res.getString(res.getColumnIndex("isDebited"));
        homeAccount.isDebited = Boolean.parseBoolean(s);
        homeAccount.isAtmWithDraw = Boolean.parseBoolean(res.getString(res.getColumnIndex("isAtmWithDraw")));
        homeAccount.use_sms_time = Boolean.parseBoolean(res.getString(res.getColumnIndex("use_sms_time")));
        homeAccount.dateValAccount = res.getString(res.getColumnIndex("dateValAccount"));
        homeAccount.DateTransactionHistory = res.getString(res.getColumnIndex("DateTransactionHistory"));
        homeAccount.dateValHistory = res.getString(res.getColumnIndex("dateValHistory"));

        return homeAccount;
    }

    public boolean checkForTableExists(String tableName, SQLiteDatabase db) {
        String sql = "SELECT name FROM sqlite_master WHERE type='table' AND name='" + tableName + "'";
        Cursor mCursor = db.rawQuery(sql, null);
        if (mCursor != null && mCursor.getCount() > 0) {
            mCursor.close();
            return true;
        }
        return false;
    }

}
