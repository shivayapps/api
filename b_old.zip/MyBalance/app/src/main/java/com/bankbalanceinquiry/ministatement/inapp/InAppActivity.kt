package com.bankbalanceinquiry.ministatement.inapp

import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.Purchase
import com.bankbalanceinquiry.ministatement.R
import com.bankbalanceinquiry.ministatement.activity.drawerActivity
import com.bankbalanceinquiry.ministatement.financialcalculator.helper.PreferenceManager
import com.bankbalanceinquiry.ministatement.utils.NetworkManager
import kotlinx.android.synthetic.main.activity_in_app.*


class InAppActivity : AppCompatActivity(), ProductPurchaseHelper.ProductPurchaseListener {

    private var TAG = "InAppActivity"
    private var isFrom = ""
//    private var pro_app_key = ""
    
//    private lateinit var progress : ProgressBar
//    private lateinit var toolbarMain : RelativeLayout
//    private lateinit var backRelLayout : RelativeLayout
//    private lateinit var layTryLimited : TextView
//    private lateinit var skipLay : TextView
//    private lateinit var closeLay : ImageView
//    private lateinit var introSubscriptionText : TextView
//    private lateinit var relStart : LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_in_app);
//        Utils.addEvent(this@InAppActivity, "subscription_enter", "click", "startup_overview")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = getColor(R.color.app_color)
        }

//        progress = findViewById(R.id.progress);
//        toolbarMain = findViewById(R.id.toolbarMain);
//        backRelLayout = findViewById(R.id.back_rel_layout);
//        layTryLimited = findViewById(R.id.lay_try_limited);
//        introSubscriptionText = findViewById(R.id.intro_subscription_text);
//        relStart = findViewById(R.id.rel_start);
//        skipLay = findViewById(R.id.skip_lay);
//        closeLay = findViewById(R.id.close_lay);
        
        setupView()
        setClickListener()

        if (NetworkManager.isInternetConnected(this@InAppActivity)) {
            progress.visibility = View.VISIBLE
//            val key = FirebaseConfig_var.remoteConfig.getString(FirebaseConfig_var.inAppSubscriptionKey)
//            pro_app_key = FirebaseConfig_var.pro_app_key
//            if (key.isNotEmpty()) pro_app_key = key
            initINP()
        } else {
            showNetworkLay()
        }
    }

    private fun setupView() {
        if (intent.hasExtra("isFrom")) {
            isFrom = intent.getStringExtra("isFrom")!!
        }

        if (isFrom == "splash") {
            toolbarMain.visibility = View.GONE
            val firstTimeScreen = PreferenceManager(this@InAppActivity).getBooleanData( "subscriprion_first_time", true)
            if (!firstTimeScreen) {
                Log.w("msg", "inits :: $firstTimeScreen")
                lay_try_limited.visibility = View.GONE
                skip_lay.visibility = View.GONE
                close_lay.visibility = View.VISIBLE
            } else {
                Log.w("msg", "inits ::: $firstTimeScreen")
                PreferenceManager(this@InAppActivity).addBooleanPreference("subscriprion_first_time", false)
                lay_try_limited.visibility = View.VISIBLE
                skip_lay.visibility = View.VISIBLE
                close_lay.visibility = View.GONE
            }
        } else {
            toolbarMain.visibility = View.VISIBLE
            lay_try_limited.visibility = View.GONE
            skip_lay.visibility = View.GONE
            close_lay.visibility = View.GONE
        }
    }

    private fun showNetworkLay() {
        noInternet.visibility = View.VISIBLE
        main_lay.visibility = View.GONE
    }

    private fun initINP() {
//        ProductPurchaseHelper.setSubscriptionKey(pro_app_key,"one_year")
        ProductPurchaseHelper.setLifeTimeProductKey(PRODUCT_PURCHASED)
        ProductPurchaseHelper.initBillingClient(this@InAppActivity, this)
    }

    private fun alert(message: String) {
        try {
            if (!isFinishing) {
                val bld = AlertDialog.Builder(this@InAppActivity)
                bld.setMessage(message)
                bld.setNeutralButton(R.string.ok, null)
                Log.w(TAG, "inAppPurchase Showing alert dialog: $message")
                bld.create().show()
            }
        } catch (e: java.lang.Exception) {
            Log.e(TAG, "Exception: $e")
        }
    }

    private fun setClickListener() {
        close_lay.setOnClickListener {
//            Utils.addEvent(this@InAppActivity,  "close","click", "subscription")
//            startActivity(Intent(this@InAppActivity, ListOnlineThemeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            finish()
        }
        skip_lay.setOnClickListener {
//            Utils.addEvent(this@InAppActivity,  "skip","click", "subscription")
//            startActivity(Intent(this@InAppActivity, ListOnlineThemeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            finish()
        }
        rel_start.setOnClickListener {
            launchPurchaseFlow()
        }
//        binding.ivStart.setOnClickListener {
//            launchPurchaseFlow()
//        }
        lay_try_limited.setOnClickListener {
//            startActivity(Intent(this@InAppActivity, ListOnlineThemeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            finish()
        }
        back_rel_layout.setOnClickListener {
            onBackPressed()
        }
        intro_subscription_text.setOnClickListener {
//            PreferenceManager.saveData(this@InAppActivity, PreferenceKeys.SystemDialogOpened, true)

            try {
                val customIntent = CustomTabsIntent.Builder()
                customIntent.setToolbarColor(ContextCompat.getColor(this@InAppActivity, R.color.colorPrimary))
                //showRateDailog();
//                        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(getResources().getString(R.string.privacy_policy)));
//                        if (i.resolveActivity(getPackageManager()) != null) {
//                            startActivity(i);
//                        }
                CustomTabsIntent.Builder()
                    .build()
                    .launchUrl(this@InAppActivity, Uri.parse(getString(R.string.privacy_policy)))

            } catch (e: ActivityNotFoundException) {
                Toast.makeText(this@InAppActivity, R.string.No_application_request_install_web_browser, Toast.LENGTH_LONG).show()
            } catch (e1: Exception) {
                Toast.makeText(this@InAppActivity, R.string.error_try_again_later, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun launchPurchaseFlow() {

//        Utils.addEvent(this@InAppActivity,  "$pro_app_key","click", "subscription")
//        PreferenceManager.saveData(this@InAppActivity, PreferenceKeys.SystemDialogOpened, true);
        if (AdsManager(this@InAppActivity).isNeedToShowAds()) {
            try {
                if (NetworkManager.isInternetConnected(this@InAppActivity)
                    && !PreferenceManager(this@InAppActivity).getBooleanData("in_app_subscription_setup_failed")
                ) {
                    ProductPurchaseHelper.purchaseProduct(this@InAppActivity, PRODUCT_PURCHASED)
                } else {
                    Toast.makeText(this@InAppActivity, R.string.network_try_again, Toast.LENGTH_SHORT).show()
                }

            } catch (e: Exception) {
                Toast.makeText(this@InAppActivity, R.string.something_went_wrong_please_try_again_later, Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this@InAppActivity, R.string.package_already_bought, Toast.LENGTH_SHORT).show()
        }
    }

    private fun verifyDeveloperPayload(p: Purchase): Boolean {
        Log.w(TAG, "Purchase_time== " + p.purchaseTime)
        return true
    }

    override fun onPurchasedSuccess(purchase: Purchase) {
        if (purchase.products.get(0).equals(PRODUCT_PURCHASED)) {

            if (!verifyDeveloperPayload(purchase)) {
//                Utils.addEvent(this@InAppActivity, "onPurchasedSuccess", "onPurchasedFailed:$pro_app_key", "subscription")

                Toast.makeText(
                    this@InAppActivity,
                    getString(R.string.something_went_wrong_please_try_again_later),
                    Toast.LENGTH_SHORT
                ).show()
                return
            }

//            Utils.addEvent(this@InAppActivity, "onPurchasedSuccess", "onPurchasedSuccess:$pro_app_key", "subscription")
            Log.w(TAG, "inAppPurchase Delaroy subscription purchased.")
            //alert(getString(R.string.thank_you_for_subscribing))

//            PreferenceManager.saveData(this@InAppActivity, PreferenceKeys.inAppSubscriptionenabled, purchase.isAutoRenewing)
//            PreferenceManager.saveData(this@InAppActivity, FirebaseConfig_var.is_remove_ads, true)
            AdsManager(this@InAppActivity).onProductPurchased()
//            if(purchase.products.size>0) {
//                PreferenceManager.saveData(this@InAppActivity, FirebaseConfig_var.purchased_sku, purchase.products[0])
//            }

            Toast.makeText(this@InAppActivity, getString(R.string.remove_ads_msg), Toast.LENGTH_SHORT).show()

            val i = Intent(this@InAppActivity, drawerActivity::class.java)
            i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(i)
            finish()
        }
    }

    override fun onPurchasedFound(productType: String, purchaseList: MutableList<Purchase>?) {
        //PreferenceManager.saveData(this@InAppActivity, FirebaseConfig_var.is_remove_ads, true)
        AdsManager(this@InAppActivity).onProductPurchased()
    }

    override fun onBillingSetupFinished(billingResult: BillingResult) {
        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
//            PreferenceManager.saveData(this@InAppActivity, PreferenceKeys.in_app_subscription_setup_failed, false)
        } else {
//            PreferenceManager.saveData(this@InAppActivity, PreferenceKeys.in_app_subscription_setup_failed, true)
        }

        ProductPurchaseHelper.initSubscriptionKeys(
            context = this@InAppActivity,
            onInitializationComplete = {
                Log.e("TAG", "onBillingSetupFinished:")

                val product = ProductPurchaseHelper.getProductInfo(PRODUCT_PURCHASED)
//                logE(tag = "MainActivity", message = "getProductInfo: =>> ++++++++++++++++++++++++++++++++++")
//                logE(tag = "MainActivity", message = "getProductInfo: =>> productID -> ${product?.id}")
//                logE(tag = "MainActivity", message = "getProductInfo: =>> formattedPrice -> ${product?.formattedPrice}")
//                logE(tag = "MainActivity", message = "getProductInfo: =>> priceAmountMicros -> ${product?.priceAmountMicros}")
//                logE(tag = "MainActivity", message = "getProductInfo: =>> priceCurrencyCode -> ${product?.priceCurrencyCode}")
//                logE(tag = "MainActivity", message = "getProductInfo: =>> billingPeriod -> ${product?.billingPeriod}")
//                logE(tag = "MainActivity", message = "getProductInfo: =>> freeTrialPeriod -> ${product?.freeTrialPeriod}")
//                logE(tag = "MainActivity", message = "getProductInfo: =>> productDetail -> ${product?.productDetail}")

                progress.setVisibility(View.GONE)
                rel_start.setVisibility(View.VISIBLE)
                price_period.setText("${product?.formattedPrice}/${product?.billingPeriod.toString().trim()}")

                if (product?.freeTrialPeriod.equals("Not Found")) {
                    trial_period.visibility = View.GONE
                    txtThen.visibility = View.GONE
//                    binding.tvStart.setText("${product?.formattedPrice} / ${product?.billingPeriod.toString().toLowerCase().trim()}")
                } else {
                    trial_period.setText("${product?.freeTrialPeriod?.replace(" ", "-")} Trial")
                }
            }
        )
    }

    override fun onBillingKeyNotFound(productId: String) {

    }

    override fun onBackPressed() {
        super.onBackPressed()
//        Utils.addEvent(this@InAppActivity, "subscription_exit", "click", "startup_overview")
//        if (isFrom == "splash") {
//            startActivity(Intent(this@InAppActivity, ListOnlineThemeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
//            finish()
//        } else {
//            finish()
//        }
    }
}