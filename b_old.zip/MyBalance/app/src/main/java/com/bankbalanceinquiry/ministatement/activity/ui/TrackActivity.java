package com.bankbalanceinquiry.ministatement.activity.ui;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.bankbalanceinquiry.ministatement.Events.SmsProgress;
import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.activity.drawerActivity;
import com.bankbalanceinquiry.ministatement.utils.Constant;
import com.bankbalanceinquiry.ministatement.utils.PreferenceHelper;
import com.bankbalanceinquiry.ministatement.utils.SmsService;
import com.daimajia.numberprogressbar.NumberProgressBar;
import com.daimajia.numberprogressbar.OnProgressBarListener;
import com.zhpan.indicator.IndicatorView;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class TrackActivity extends AppCompatActivity implements OnProgressBarListener {


    ViewPager viewPager;
    ScreenSlidePagerAdapter pagerAdapter;
    private IndicatorView worm_dots_indicator;
    private ImageView previous;
    private TextView next;
    private TextView done;

    private NumberProgressBar progress;
    private TextView count;
    private LinearLayout progress_lay;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_track);

        if (!EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().register(this);

        progress = findViewById(R.id.progress);
        count = findViewById(R.id.count);
        progress_lay = findViewById(R.id.progress_lay);
        progress.setOnProgressBarListener(this);

        progress_lay.setVisibility(View.VISIBLE);


        viewPager = findViewById(R.id.viewPager);
        worm_dots_indicator = findViewById(R.id.worm_dots_indicator);
        previous = findViewById(R.id.previous);
        next = findViewById(R.id.next);
        done = findViewById(R.id.done);
        pagerAdapter = new ScreenSlidePagerAdapter(getSupportFragmentManager());
        viewPager.setAdapter(pagerAdapter);
        viewPager.setOffscreenPageLimit(4);
        worm_dots_indicator.setupWithViewPager(viewPager);
        if (!isMyServiceRunning(SmsService.class)) {
            ContextCompat.startForegroundService(this, new Intent(TrackActivity.this, SmsService.class));
        }
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                if (position == 3) {
                    next.setText("Done");
                } else {
                    next.setText("Next");
                }
                if (position == 0) {
                    previous.setVisibility(View.INVISIBLE);
                } else {
                    previous.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (next.getText().equals("Next")) {
                    viewPager.setCurrentItem(viewPager.getCurrentItem() + 1);
                } else if (next.getText().equals("Done")) {
                    PreferenceHelper.saveToUserDefaults(getApplicationContext(), Constant.TRACK_PREF, "1");
                    Intent i = new Intent(TrackActivity.this, drawerActivity.class);
                    startActivity(i);
                    finish();
                }
            }
        });
        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PreferenceHelper.saveToUserDefaults(getApplicationContext(), Constant.TRACK_PREF, "1");
                Intent i = new Intent(TrackActivity.this, drawerActivity.class);
                startActivity(i);
                finish();
            }
        });
        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (previous.getVisibility() == View.VISIBLE) {
                    viewPager.setCurrentItem(viewPager.getCurrentItem() - 1);
                }
            }
        });

//        setAdMobData();
    }


//    private void setAdMobData() {
//
//        RequestQueue queue = Volley.newRequestQueue(this);
//        StringRequest request = new StringRequest(Request.Method.GET, Constant.AD_URL,
//                new Response.Listener<String>() {
//                    @Override
//                    public void onResponse(String response) {
//                        //Log.e("setAdMobData","response:"+response);
//                        //textView.setText(response.toString());
//                        //Toast.makeText(MainActivity.this, response.toString(), Toast.LENGTH_LONG).show();
//                        try {
//                            JSONObject jsonObject=new JSONObject(response);
//                            String liveAd=jsonObject.getString("live_ad");
//
//                            SharedPreferenceClass.setString(TrackActivity.this,Constant.LIVE_AD,liveAd.trim());
//                            //JSONArray jsonAdmob=jsonObject.getJSONArray("admob");
//                            //JSONArray jsonFacebook=jsonObject.getJSONArray("facebook");
//
//                            JSONObject jsonAdmob=jsonObject.getJSONObject("admob");
//                            String g_AppId=jsonAdmob.getString("app_id");
//                            String g_NativeId=jsonAdmob.getString("native_advance");
//                            String g_InterstitialId=jsonAdmob.getString("interstitial");
//                            String g_BannerId=jsonAdmob.getString("banner");
//                            String g_AppOpen=jsonAdmob.getString("app_open");
//
//                            Log.e("setAdMobData","g_AppId:"+g_AppId);
//                            Log.e("setAdMobData","g_NativeId:"+g_NativeId);
//                            Log.e("setAdMobData","g_InterstitialId:"+g_InterstitialId);
//                            Log.e("setAdMobData","g_BannerId:"+g_BannerId);
//                            Log.e("setAdMobData","g_AppOpen:"+g_AppOpen);
//
//                            SharedPreferenceClass.setString(TrackActivity.this,Constant.G_APP_ID,g_AppId.trim());
//                            SharedPreferenceClass.setString(TrackActivity.this,Constant.G_NATIVE_ID,g_NativeId.trim());
//                            SharedPreferenceClass.setString(TrackActivity.this,Constant.G_INTERSTITIAL_ID,g_InterstitialId.trim());
//                            SharedPreferenceClass.setString(TrackActivity.this,Constant.G_APPOPEN_ID,g_AppOpen.trim());
//                            SharedPreferenceClass.setString(TrackActivity.this,Constant.G_BANNER_ID,g_BannerId.trim());
//
//                            JSONObject jsonFacebook=jsonObject.getJSONObject("facebook");
//                            String f_NativeId=jsonFacebook.getString("native_advance");
//                            String f_InterstitialId=jsonFacebook.getString("interstitial");
//                            String f_BannerId=jsonFacebook.getString("banner");
//                            String f_NativeBannerId=jsonFacebook.getString("native_banner");
//
//                            Log.e("setAdMobData","f_NativeId:"+f_NativeId);
//                            Log.e("setAdMobData","f_InterstitialId:"+f_InterstitialId);
//                            Log.e("setAdMobData","f_BannerId:"+f_BannerId);
//                            Log.e("setAdMobData","f_NativeBannerId:"+f_NativeBannerId);
//
//                            SharedPreferenceClass.setString(TrackActivity.this,Constant.F_NATIVE_ID,f_NativeId.trim());
//                            SharedPreferenceClass.setString(TrackActivity.this,Constant.F_INTERSTITIAL_ID,f_InterstitialId.trim());
//                            SharedPreferenceClass.setString(TrackActivity.this,Constant.F_NATIVE_ID,f_NativeBannerId.trim());
//                            SharedPreferenceClass.setString(TrackActivity.this,Constant.F_BANNER_ID,f_BannerId.trim());
//
//                            //preferenceManager.setITimeInterval("3");
//
//                            if (SharedPreferenceClass.getString(TrackActivity.this,Constant.LIVE_AD,"admob").equalsIgnoreCase("admob")) {
//                                setAppId(g_AppId);
//                            }
//                        } catch (JSONException e) {
//                            Log.e("setAdMobData","JSONException:"+e);
//                            e.printStackTrace();
//                        }
//
//                        if (SharedPreferenceClass.getString(TrackActivity.this,Constant.LIVE_AD,"admob").equalsIgnoreCase("admob")) {
//                            AdmobAdManager admobAdManager = new AdmobAdManager(TrackActivity.this);
//                            admobAdManager.loadInterstitialAd(TrackActivity.this,SharedPreferenceClass.getString(TrackActivity.this,Constant.G_INTERSTITIAL_ID,""));
//                        } else {
//                            FacebookAdsManager facebookAdsManager = new FacebookAdsManager(TrackActivity.this);
//                            facebookAdsManager.loadInterstitialAd(TrackActivity.this,SharedPreferenceClass.getString(TrackActivity.this,Constant.F_INTERSTITIAL_ID,""));
//                        }
//                    }
//                },
//                new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        Log.e("setAdMobData","onErrorResponse:"+error.networkResponse.statusCode);
//                        Log.e("setAdMobData","onErrorResponse:"+error.getMessage());
//
//                    }
//                });
//        queue.add(request);
//    }

    private void setAppId(String appId) {
        try {
            ApplicationInfo ai = getPackageManager().getApplicationInfo(getPackageName(), PackageManager.GET_META_DATA);
            Bundle bundle = ai.metaData;
            String myApiKey = bundle.getString("com.google.android.gms.ads.APPLICATION_ID");
            Log.d("TAG", "Name Found: " + myApiKey);
            ai.metaData.putString("com.google.android.gms.ads.APPLICATION_ID", appId);//you can replace your key APPLICATION_ID here
            String ApiKey = bundle.getString("com.google.android.gms.ads.APPLICATION_ID");
            Log.d("TAG", "ReNamed Found: " + ApiKey);
        } catch (PackageManager.NameNotFoundException e) {
            Log.e("TAG", "Failed to load meta-data, NameNotFound: " + e.getMessage());
        } catch (NullPointerException e) {
            Log.e("TAG", "Failed to load meta-data, NullPointer: " + e.getMessage());
        }
    }

    @Subscribe
    public void OnSmsProgress(final SmsProgress smsProgress) {
        if (!isFinishing()) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    count.setText(SmsService.smsCount + "/" + SmsService.TotalCount);
                    progress.setMax(SmsService.TotalCount);
                    progress.setProgress(smsProgress.getProgress());
                    if (SmsService.smsCount == (SmsService.TotalCount - 1)) {
                        PreferenceHelper.saveToUserDefaults(TrackActivity.this, Constant.TRACK_PREF, "1");
                        progress_lay.setVisibility(View.GONE);


                        PreferenceHelper.saveToUserDefaults(getApplicationContext(), Constant.TRACK_PREF, "1");
                        Intent i = new Intent(TrackActivity.this, drawerActivity.class);
                        startActivity(i);
                        finish();

                    }
                }
            });
        }
    }

    private boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        if (manager != null) {
            for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
                if (serviceClass.getName().equals(service.service.getClassName())) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    protected void onDestroy() {
        EventBus.getDefault().unregister(this);
        super.onDestroy();
    }

    @Override
    public void onProgressChange(int current, int max) {

    }

    private class ScreenSlidePagerAdapter extends FragmentStatePagerAdapter {
        public ScreenSlidePagerAdapter(FragmentManager fm) {
            super(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        }

        @Override
        public Fragment getItem(int position) {
            return new IntroFragment(position);
        }

        @Override
        public int getCount() {
            return 4;
        }
    }
}
