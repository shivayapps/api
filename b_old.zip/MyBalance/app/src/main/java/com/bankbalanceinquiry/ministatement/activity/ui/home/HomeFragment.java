package com.bankbalanceinquiry.ministatement.activity.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.adapter.listBankAdapter;
import com.bankbalanceinquiry.ministatement.model.bankname;

import java.util.List;


public class HomeFragment extends Fragment {


    public static ListView custom_list_view;
    listBankAdapter listBankAdapter;
    List<bankname> mData;


    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View root = inflater.inflate(R.layout.fragment_home, container, false);
//        custom_list_view=(ListView)root.findViewById(R.id.custom_list_view);
//
//        DatabaseAccess databaseAccess = DatabaseAccess.getInstance(getActivity());
//        databaseAccess.open();
//        mData=databaseAccess.getList();
//        databaseAccess.close();
//
//        listBankAdapter=new listBankAdapter(getActivity(),mData);
//        custom_list_view.setAdapter(listBankAdapter);

        return root;
    }

}