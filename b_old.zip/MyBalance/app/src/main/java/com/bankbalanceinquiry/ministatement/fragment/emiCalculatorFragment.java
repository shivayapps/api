package com.bankbalanceinquiry.ministatement.fragment;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.database.DatabaseAccess;
import com.bankbalanceinquiry.ministatement.databasedNew.DBHelperAccountNew;
import com.bankbalanceinquiry.ministatement.inapp.AdsManager;
import com.bankbalanceinquiry.ministatement.model.bankname;
import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;
import com.bankbalanceinquiry.ministatement.utils.NetworkManager;
import com.example.app.ads.helper.AdMobAdsUtilsKt;
import com.example.app.ads.helper.NativeAdsSize;
import com.example.app.ads.helper.NativeAdvancedModelHelper;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import static android.content.Context.INPUT_METHOD_SERVICE;
import static android.content.Context.MODE_PRIVATE;
import static com.bankbalanceinquiry.ministatement.activity.drawerActivity.navController;
import static com.bankbalanceinquiry.ministatement.activity.drawerActivity.toolbar;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;

public class emiCalculatorFragment extends Fragment {

    EditText amount, rate, period_text, date;
    Spinner spMonth;
    ImageView calendar;
    TextView calculate, reset, monthly_emi, total_interest, total_payment, details;
    String[] arraySpinner = new String[]{"Month", "Year"};
    public static String loan_period_month;

    public static long loan_amount;
    public static float loan_interest;
    long loan_month;
    LinearLayout loan_calculate_linear;
    public static String click, static_emi, static_rate, static_payment, start_date;
    public static double intreset;
    public static double total_emi;
    public static String month_text;
    public static int year_digit;

    Context mContext;


    private FrameLayout frameLayout;
    private FrameLayout adLayout;
    private CardView adcard;

    String bank_name="No Bank";
    List<bankname> MDetail;
    //Spinner spChangeBank;
    private DBHelperAccountNew mydbAccountNew;
    DatabaseAccess databaseAccess;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editorBank;

    @Nullable
    @Override
    public View onCreateView(@NonNull final LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_emicalculator, container, false);

        toolbar.setTitle("EMI Calculator");
        mContext = getActivity();

        amount = (EditText) view.findViewById(R.id.amount);
        rate = (EditText) view.findViewById(R.id.interest);
        period_text = (EditText) view.findViewById(R.id.loan_period_text);
        date = (EditText) view.findViewById(R.id.date);

        spMonth = (Spinner) view.findViewById(R.id.spMonth);

        calendar = (ImageView) view.findViewById(R.id.cal);
        calculate = (TextView) view.findViewById(R.id.calculate);
        details = (TextView) view.findViewById(R.id.details);
        monthly_emi = (TextView) view.findViewById(R.id.monthly_emi);
        total_interest = (TextView) view.findViewById(R.id.total_interest);
        total_payment = (TextView) view.findViewById(R.id.total_payment);
        //spChangeBank = (Spinner) view.findViewById(R.id.spChangeBank);

        reset = (TextView) view.findViewById(R.id.reset);
        loan_calculate_linear = (LinearLayout) view.findViewById(R.id.loan_calculate_linear);


        frameLayout = view.findViewById(R.id.fl_adplaceholder);

        final Calendar cal = Calendar.getInstance();
        SimpleDateFormat month_date = new SimpleDateFormat("MMM-yyyy");
        String ma = month_date.format(cal.getTime());
        date.setText(ma);

        //set Spinner data
        ArrayAdapter<String> monthAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, arraySpinner);
        monthAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spMonth.setAdapter(monthAdapter);
        spMonth.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                loan_period_month = period_text.getText().toString();

                if (i == 0) {
                    click = "month";
                    loan_period_month = period_text.getText().toString();
                } else {
                    click = "year";

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

//        refreshAd();
        calendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogFragment newFragment = new DatePickerFragment();
                newFragment.show(getFragmentManager(), "Date Picker");
            }
        });

        calculate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if (TextUtils.isEmpty(amount.getText().toString()) || TextUtils.isEmpty(rate.getText().toString()) || TextUtils.isEmpty(period_text.getText().toString())) {
                    Toast.makeText(getActivity(), "Please First Fill the Value", Toast.LENGTH_SHORT).show();

                    // Toast.makeText(getActivity()," "+month_digit,Toast.LENGTH_SHORT).show();
                } else {
                    InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(INPUT_METHOD_SERVICE);
                    if (imm != null) {
                        imm.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(), 0);
                    }

                    Calendar calender = Calendar.getInstance();
                    start_date = date.getText().toString();

                    //get Month and year From Calender
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMM-yyyy");
                    try {
                        String newDateStr = simpleDateFormat.format(simpleDateFormat.parse(start_date));
                        String str[] = newDateStr.split("-");

                        month_text = str[0];
                        year_digit = Integer.parseInt(str[1]);

                    } catch (ParseException e) {
                        e.printStackTrace();
                    }

                    loan_calculate_linear.setVisibility(View.VISIBLE);
                    Log.e("chcek", " " + click);

                    if (click.matches("month")) {
                        loan_period_month = period_text.getText().toString();
                        Log.e("period_m", " " + loan_period_month);
                    } else if (click.matches("year")) {
                        int year = Integer.parseInt(period_text.getText().toString());
                        int month = year * 12;

                        loan_period_month = String.valueOf(month);
                        Log.e("period", " " + loan_period_month);
                    }


                    loan_amount = Long.parseLong(amount.getText().toString());
                    loan_interest = Float.parseFloat(rate.getText().toString());
                    loan_month = Long.parseLong(loan_period_month);
                    Log.e("month", " " + loan_month);


                    intreset = loan_interest / 12 / 100;

                    Log.e("Detail---)", " " + loan_amount + " " + (1 + intreset) + " " + loan_month);

                    double up_interest = Math.pow((1 + intreset), loan_month);

                    Log.e("Detail_up", " " + up_interest);


                    total_emi = (loan_amount * intreset * (up_interest / ((up_interest) - 1)));

                    double format = Double.parseDouble((new DecimalFormat("##.##").format(total_emi)));
                    double total_pay = format * loan_month;
                    double total_intrest = total_pay - loan_amount;

                    Log.e("total_emi", " " + total_emi);
                    Log.e("total_emi", " " + total_pay);
                    Log.e("total_emi", " " + total_intrest);

                    monthly_emi.setText(new DecimalFormat("##.##").format(total_emi) + " \u20B9");
                    total_interest.setText(new DecimalFormat("##.##").format(total_intrest) + " \u20B9");
                    total_payment.setText(new DecimalFormat("##.##").format(total_pay) + " \u20B9");

                    static_emi = monthly_emi.getText().toString();
                    static_rate = total_interest.getText().toString();
                    static_payment = total_payment.getText().toString();

                }

            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                loan_calculate_linear.setVisibility(View.GONE);

                amount.setText("");
                rate.setText("");
                period_text.setText("");

                amount.setHint("500000");
                rate.setHint("0.5");
                period_text.setHint("12");

                Calendar cal = Calendar.getInstance();
                SimpleDateFormat month_date = new SimpleDateFormat("");
                String ma = month_date.format(cal.getTime());
                date.setText(ma);
            }
        });

        details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                navController.navigate(R.id.nav_full_emi);
            }
        });
        adLayout = view.findViewById(R.id.adLayout);
        adcard = view.findViewById(R.id.adcard);
        int colors = ContextCompat.getColor(getActivity(), R.color.colorAccent);


        if (new AdsManager(getActivity()).isNeedToShowAds() && NetworkManager.isInternetConnected(getActivity())) {

            new NativeAdvancedModelHelper(getActivity()).loadNativeAdvancedAd(
                    AdMobAdsUtilsKt.getEmiCalcFragAd(),
                    adLayout,
                    null, true, true, new Function1<Boolean, Unit>() {
                        @Override
                        public Unit invoke(Boolean aBoolean) {
                            return null;
                        }
                    }, new Function0<Unit>() {
                        @Override
                        public Unit invoke() {
                            return null;
                        }
                    });
        }

        sharedPreferences = getActivity().getSharedPreferences("bank_select", MODE_PRIVATE);
        editorBank = sharedPreferences.edit();

        bank_name = sharedPreferences.getString("bank_name", "No Bank");

        databaseAccess = DatabaseAccess.getInstance(getActivity());
        databaseAccess.open();
        mydbAccountNew=new DBHelperAccountNew(getActivity());
        final ArrayList<HomeAccoutList> homeAccoutListArrayList = mydbAccountNew.GetAllAccountNew();

        ArrayAdapter<HomeAccoutList> adapter = new ArrayAdapter<HomeAccoutList>(getActivity(),  android.R.layout.simple_spinner_dropdown_item, homeAccoutListArrayList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        return view;
    }


}
