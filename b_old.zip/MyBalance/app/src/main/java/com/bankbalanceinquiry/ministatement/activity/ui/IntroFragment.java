package com.bankbalanceinquiry.ministatement.activity.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.bankbalanceinquiry.ministatement.R;
import com.daimajia.numberprogressbar.OnProgressBarListener;

import static com.bankbalanceinquiry.ministatement.utils.Constant.TRACK_DESCRIPTION;
import static com.bankbalanceinquiry.ministatement.utils.Constant.TRACK_TITLE;

public class IntroFragment extends Fragment implements OnProgressBarListener {


    int position;
    private TextView track_title;
    private TextView track_description;

    public IntroFragment(int position) {
        this.position = position;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_intro, container, false);

        track_title = root.findViewById(R.id.track_title);
        track_description = root.findViewById(R.id.track_description);

        track_title.setText(TRACK_TITLE[position]);
        track_description.setText(TRACK_DESCRIPTION[position]);
        return root;
    }



    @Override
    public void onDestroy() {
        super.onDestroy();
    }


    @Override
    public void onProgressChange(int current, int max) {

    }
}
