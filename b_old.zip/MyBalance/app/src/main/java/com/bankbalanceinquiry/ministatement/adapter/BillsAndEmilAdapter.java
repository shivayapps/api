package com.bankbalanceinquiry.ministatement.adapter;

import android.app.Activity;
import android.graphics.Color;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bankbalanceinquiry.ministatement.utils.TextDrawable;
import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.model.BilsEmiModel;
import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;
import com.marcoscg.dialogsheet.DialogSheet;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

public class BillsAndEmilAdapter extends
        RecyclerView.Adapter<BillsAndEmilAdapter.MyViewHolder> {
    private Activity activity;
    private ArrayList<HomeAccoutList> bilsEmiModels;

    public ClickApkList ApkDetails;

    public interface ClickApkList {
        void ClickValue(int position, BilsEmiModel alldata);
    }

    public void RegisterInterface(ClickApkList photoInterface) {
        this.ApkDetails = photoInterface;
    }

    public BillsAndEmilAdapter(Activity activity, ArrayList<HomeAccoutList> listOfAllImages) {
        this.activity = activity;
        this.bilsEmiModels = listOfAllImages;
    }

    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(activity).inflate(R.layout.raw_bills_emi, viewGroup, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {
        final HomeAccoutList alldata = bilsEmiModels.get(position);
        String mMonth = null, mDate = null, mYear = null;
        String Accountno = alldata.FinalAccountNo;
        if (!TextUtils.isEmpty(Accountno)) {
            if (alldata.account_type.equalsIgnoreCase("electricity") || alldata.account_type.equalsIgnoreCase("insurance") || alldata.account_type.equalsIgnoreCase("gas")) {
                holder.tvAccountNo.setText(Accountno);
            } else {
                holder.tvAccountNo.setText("xxx" + Accountno);
            }
        } else {
            holder.mDot.setVisibility(View.GONE);
            holder.tvAccountNo.setVisibility(View.GONE);
        }

        holder.tvBankName.setText(alldata.full_name);
        String Amount = alldata.amount;
        if (TextUtils.isEmpty(Amount)) {
            Amount = "0";
        }

        String FirstName = alldata.full_name;
        Random rnd = new Random();

        final int drawable1 = getTransactionImage(alldata.transactionDesc);
        if (drawable1 != -1) {
            holder.ivBankLogo.setImageResource(drawable1);
        } else {
            int color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));
            if (!TextUtils.isEmpty(FirstName) && !FirstName.equalsIgnoreCase("")) {
                String FirstLetter = FirstName.substring(0, 1);
                TextDrawable drawable = TextDrawable.builder()
                        .buildRound(FirstLetter, color);
                holder.ivBankLogo.setImageDrawable(drawable);
            } else {
                TextDrawable drawable = TextDrawable.builder()
                        .buildRound("U", color);
                holder.ivBankLogo.setImageDrawable(drawable);
            }
        }


        String PayNowPaid = "0";

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MMM-yy");

        DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
        Date date = new Date();

        String TodayDatefind = dateFormat.format(date);
        String TodayDate = TodayDatefind.toUpperCase();
        Date date1 = null, date2 = null;
        try {
            date1 = simpleDateFormat.parse(TodayDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        if (alldata.dateFormats.size() != 0) {
            if (TextUtils.isEmpty(alldata.date)) {
                if (alldata.dates.size() != 0) {
                    alldata.date = alldata.dates.get(0);
                }
            }
            if (!TextUtils.isEmpty(alldata.date)) {
                for (String format : alldata.dateFormats) {
                    SimpleDateFormat format1 = new SimpleDateFormat(format, Locale.US);
                    try {
                        date2 = format1.parse(alldata.date);
                        SimpleDateFormat monthFormate = new SimpleDateFormat("MMM", Locale.US);
                        SimpleDateFormat dateFormate = new SimpleDateFormat("dd", Locale.US);
                        SimpleDateFormat yearFormate = new SimpleDateFormat("yyyy", Locale.US);
                        mMonth = monthFormate.format(date2);
                        mDate = dateFormate.format(date2);
                        mYear = yearFormate.format(date2);
                        break;
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        if (TextUtils.isEmpty(alldata.date)) {
            if (alldata.use_sms_time) {
                alldata.date = alldata.dateValHistory;
            }
        }


        if (TextUtils.isEmpty(mMonth) && TextUtils.isEmpty(mDate) && TextUtils.isEmpty(mYear)) {
            SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("dd MMM yyyy", Locale.US);
            SimpleDateFormat monthFormate = new SimpleDateFormat("MMM", Locale.US);
            SimpleDateFormat dateFormate = new SimpleDateFormat("dd", Locale.US);
            SimpleDateFormat yearFormate = new SimpleDateFormat("yyyy", Locale.US);
            try {
                Date date3 = simpleDateFormat1.parse(alldata.date);
                if (date3 != null) {
                    mMonth = monthFormate.format(date3);
                    mDate = dateFormate.format(date3);
                    mYear = yearFormate.format(date3);
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }


        if (!TextUtils.isEmpty(mMonth) && !TextUtils.isEmpty(mDate) && !TextUtils.isEmpty(mYear)) {
            holder.tvDateMonth.setText(mMonth);
            holder.tvDate.setText(mDate);
            holder.tvDate_year.setText(mYear);
        }


        String FinalPendingDay = null;
        if (date1 != null && date2 != null) {
            FinalPendingDay = String.valueOf(printDifference(date1, date2));
        }

        if (!TextUtils.isEmpty(FinalPendingDay)) {
            try {
                double value = Double.parseDouble(FinalPendingDay);
                if (value < 0) {
                    PayNowPaid = "0";
                } else {
                    PayNowPaid = FinalPendingDay;
                }
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }

        if (TextUtils.equals("0", PayNowPaid)) {
            holder.llPayNowPaid.setVisibility(View.GONE);
//            holder.tvPaidUnPaid.setText("Paid");
//            holder.tvDate.setText("Paid on: " + alldata.date);
//            holder.tvDate.setTextColor(ContextCompat.getColor(activity, R.color.rs_emi_paid));
            holder.tvAmount.setTextColor(ContextCompat.getColor(activity, R.color.rs_emi_paid));
            holder.ivDayToPay.setVisibility(View.GONE);
//            holder.ivPaid.setImageResource(R.drawable.ic_bill_emi_done);
            holder.ivPaid.setVisibility(View.GONE);
            //
        } else {
            holder.llPayNowPaid.setVisibility(View.GONE);
//            holder.tvPaidUnPaid.setText("Day to pay");
//            holder.tvDate.setText("Due on: " + alldata.date);
//            holder.tvDate.setTextColor(ContextCompat.getColor(activity, R.color.colorPrimary));
            holder.tvAmount.setTextColor(ContextCompat.getColor(activity, R.color.rs_emi_due));

            if (!TextUtils.isEmpty(FinalPendingDay)) {
                //String FirstLetter = FirstName.substring(0, 1);
                TextDrawable drawable = TextDrawable.builder()
                        .buildRound(FinalPendingDay, Color.parseColor("#faa43a"));
                holder.ivPaid.setImageDrawable(drawable);
            } else {
                TextDrawable drawable = TextDrawable.builder()
                        .buildRound("0", Color.parseColor("#faa43a"));
                holder.ivPaid.setImageDrawable(drawable);
            }

        }
        if (!TextUtils.isEmpty(alldata.transactionPos)) {
            holder.txt_pos.setText(alldata.transactionPos);
        } else {
            holder.txt_pos.setVisibility(View.GONE);
        }
        holder.txt_desc.setText(alldata.transactionDesc);
        holder.tvAmount.setText(activity.getString(R.string.Rs) + " " + Amount);


        holder.llMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DialogSheet(activity)
                        .setTitle("Account no" + (alldata.FinalAccountNo.length() < 4 ? " - X" : " - ") + alldata.FinalAccountNo)
                        .setMessage(alldata.body)
                        .setColoredNavigationBar(true)
                        .setTitleTextSize(20)
                        .setButtonsTextSize(15)
                        .setBackgroundColor(Color.WHITE)
                        .show();
            }
        });
    }

    private int getTransactionImage(String transactionType) {
        switch (transactionType) {
            case "Your Account Balance":
                return R.drawable.your_account_balance_1;
            case "UPI Transaction":
                return R.drawable.upi_transaction_1;
            case "Debit Card Transaction":
                return R.drawable.debit_card_transaction_1;
            case "Net Banking":
                return R.drawable.net_banking_1;
            case "Credited to your Account":
                return R.drawable.credited_to_your_account_1;
            case "Cheque Transaction":
                return R.drawable.cheque_transaction_1;
            case "ATM withdrawal":
                return R.drawable.atm_withdrawal_1;
            case "Credit Card Transaction":
                return R.drawable.credit_card_transaction_1;
            case "Credit Card Bill":
                return R.drawable.credit_card_bill_1;
            case "Loan EMI":
                return R.drawable.loan_emi_1;
            case "Mobile Bill":
                return R.drawable.mobile_bill_1;
            case "Prepaid Debit Card Transaction":
                return R.drawable.prepaid_debit_card_transaction_1;
            case "Bill":
                return R.drawable.bill_1;
            case "Internet Bill":
                return R.drawable.internet_bill_1;
            case "Electricity Bill":
                return R.drawable.electricity_bill_1;
            case "Insurance Premium":
                return R.drawable.insurance_premium_1;
            case "Gas Bill":
                return R.drawable.gas_bill_1;
        }
        return -1;
    }

    @Override
    public int getItemCount() {
        return bilsEmiModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private LinearLayout llMain, llPayNowPaid;
        private TextView tvAccountNo, mDot;
        private ImageView ivBankLogo;
        private TextView tvBankName;
        private ImageView ivDayToPay;
        private ImageView ivPaid;
        //        private TextView tvPaidUnPaid;
        private TextView tvAmount;
        private TextView txt_pos, tvDate, tvDateMonth, tvDate_year, txt_desc;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            llMain = itemView.findViewById(R.id.llMain);
            ivBankLogo = itemView.findViewById(R.id.ivBankLogo);
            tvBankName = itemView.findViewById(R.id.tvBankName);
            tvAccountNo = itemView.findViewById(R.id.tvAccountNo);
            tvDateMonth = itemView.findViewById(R.id.tvDate_month);
            mDot = itemView.findViewById(R.id.dot);
            ivDayToPay = itemView.findViewById(R.id.ivDayToPay);
            ivPaid = itemView.findViewById(R.id.ivPaid);
            tvDate_year = itemView.findViewById(R.id.tvDate_year);
//            tvPaidUnPaid = itemView.findViewById(R.id.tvPaidUnPaid);
            tvAmount = itemView.findViewById(R.id.tvAmount);
            tvDate = itemView.findViewById(R.id.tvDate);
            llPayNowPaid = itemView.findViewById(R.id.llPayNowPaid);
            txt_desc = itemView.findViewById(R.id.txt_desc);
            txt_pos = itemView.findViewById(R.id.txt_pos);
        }
    }


    public long printDifference(Date startDate, Date endDate) {
        //milliseconds
        Log.e("DateDifference==<", " \n TodayDateStart" + startDate + "" +
                " \n DudateDateendDate" + endDate + ""
        );
        long different = endDate.getTime() - startDate.getTime();
        System.out.println("startDate : " + startDate);
        System.out.println("endDate : " + endDate);
        System.out.println("different : " + different);

        long secondsInMilli = 1000;
        long minutesInMilli = secondsInMilli * 60;
        long hoursInMilli = minutesInMilli * 60;
        long daysInMilli = hoursInMilli * 24;

        long elapsedDays = different / daysInMilli;
        different = different % daysInMilli;

        long elapsedHours = different / hoursInMilli;
        different = different % hoursInMilli;

        long elapsedMinutes = different / minutesInMilli;
        different = different % minutesInMilli;

        long elapsedSeconds = different / secondsInMilli;

        Log.e("DayyyPending", elapsedDays + "");
        System.out.printf(
                "%d days, %d hours, %d minutes, %d seconds%n",
                elapsedDays, elapsedHours, elapsedMinutes, elapsedSeconds);
        return elapsedDays;
    }
}
