package com.bankbalanceinquiry.ministatement.common;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.IOException;
import java.io.InputStream;

public class ReadJsonFile {

    public static JSONArray GetAssetsFileGetDataJsonArray(Context activity, String FileName) {
        if (activity == null) {
            return null;
        }
        InputStream inName = null;
        try {
            inName = activity.getAssets().open(FileName + ".json");
            try {
                JSONArray jsonArray = new JSONArray(readJSONFromAsset(inName));
                return jsonArray;
            } catch (JSONException e) {
                e.printStackTrace();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    public static String readJSONFromAsset(InputStream is) {
        String json = null;
        try {
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }

}
