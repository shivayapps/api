package com.bankbalanceinquiry.ministatement.fragment;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.activity.drawerActivity;
import com.bankbalanceinquiry.ministatement.common.CommonFun;
import com.bankbalanceinquiry.ministatement.database.DatabaseAccess;
import com.bankbalanceinquiry.ministatement.inapp.AdsManager;
import com.bankbalanceinquiry.ministatement.model.bankname;
import com.bankbalanceinquiry.ministatement.utils.NetworkManager;
import com.example.app.ads.helper.AdMobAdsUtilsKt;
import com.example.app.ads.helper.NativeAdsSize;
import com.example.app.ads.helper.NativeAdvancedModelHelper;

import java.util.List;

import static android.content.Context.MODE_PRIVATE;
import static android.content.Intent.*;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;

public class bankBalanceFragment extends Fragment {

    String bank_name="No Bank";
    TextView balance_number, statment_number, care_number;
    CardView statment_card;
    int check = 0;

    LinearLayout care_call, statement_call, balance_call;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editorBank;
    //    FrameLayout fl_adplaceholder_bal;
    View root;
    Context context;

    private FrameLayout frameLayout;
    private FrameLayout adLayout;
    private CardView adcard;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        root = inflater.inflate(R.layout.fragment_bankbalance, container, false);
        context = getActivity();

        balance_number = (TextView) root.findViewById(R.id.balance_number);
        statment_number = (TextView) root.findViewById(R.id.statment_number);
        care_number = (TextView) root.findViewById(R.id.care_number);
        statment_card = (CardView) root.findViewById(R.id.statment_card);
        care_call = (LinearLayout) root.findViewById(R.id.care_call);
        statement_call = (LinearLayout) root.findViewById(R.id.statment_call);
        balance_call = (LinearLayout) root.findViewById(R.id.balance_call);

        //getActivity().getActionBar().setDisplayHomeAsUpEnabled(false);
        //drawerActivity.toolbar.setTitle("");

//        fl_adplaceholder_bal = (FrameLayout) root.findViewById(R.id.fl_adplaceholder_balance);

        frameLayout = root.findViewById(R.id.fl_adplaceholder);

//        refreshAd();
        sharedPreferences = getActivity().getSharedPreferences("bank_select", MODE_PRIVATE);
        editorBank = sharedPreferences.edit();

        bank_name = sharedPreferences.getString("bank_name", "No Bank");
        //bank_name=bank_n;

        //Check preference


        refreshData();

        /*
        DatabaseAccess databaseAccess = DatabaseAccess.getInstance(getActivity());
        databaseAccess.open();
        MDetail = databaseAccess.getBalance_details(bank_name);
        databaseAccess.close();

        if (MDetail != null && MDetail.size() != 0) {
            balance_number.setText(MDetail.get(0).getB_inquiry());
            care_number.setText(MDetail.get(0).getB_care());
            if (MDetail.get(0).getB_mini() != null) {
                statment_card.setVisibility(View.VISIBLE);
                statment_number.setText(MDetail.get(0).getB_mini());
            } else {
                statment_card.setVisibility(View.GONE);
            }
        }
        */
        balance_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri number = Uri.parse("tel:" + balance_number.getText().toString());
                Intent callIntent = new Intent(ACTION_DIAL, number);
//                if (getActivity() != null && callIntent.resolveActivity(getActivity().getPackageManager()) != null) {
//                    startActivity(callIntent);
//                }
                CommonFun.invokeCall(getActivity(),callIntent);
            }
        });

        statement_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri number = Uri.parse("tel:" + statment_number.getText().toString());
                Intent callIntent = new Intent(ACTION_DIAL, number);
//                if (getActivity() != null && callIntent.resolveActivity(getActivity().getPackageManager()) != null) {
//                    startActivity(callIntent);
//                }
                CommonFun.invokeCall(getActivity(),callIntent);
            }
        });

        care_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri number = Uri.parse("tel:" + care_number.getText().toString());
                Intent callIntent = new Intent(ACTION_DIAL, number);
//                if (getActivity() != null && callIntent.resolveActivity(getActivity().getPackageManager()) != null) {
//                    startActivity(callIntent);
//                }
                CommonFun.invokeCall(getActivity(),callIntent);
            }
        });
        adLayout = root.findViewById(R.id.adLayout);
        adcard = root.findViewById(R.id.adcard);
        int colors = ContextCompat.getColor(getActivity(), R.color.colorAccent);


        if (new AdsManager(getActivity()).isNeedToShowAds() && NetworkManager.isInternetConnected(getActivity())) {

            new NativeAdvancedModelHelper(getActivity()).loadNativeAdvancedAd(
                    AdMobAdsUtilsKt.getBankBalanceFragAd(),
                    adLayout,
                    null, true, true, new Function1<Boolean, Unit>() {
                        @Override
                        public Unit invoke(Boolean aBoolean) {
                            return null;
                        }
                    }, new Function0<Unit>() {
                        @Override
                        public Unit invoke() {
                            return null;
                        }
                    });
        }

        return root;
    }

    private void refreshData() {

        drawerActivity.toolbar.setTitle(bank_name);

        DatabaseAccess databaseAccess = DatabaseAccess.getInstance(getActivity());
        databaseAccess.open();
        List<bankname> MDetail = databaseAccess.getBalance_details(bank_name);
        databaseAccess.close();

        balance_number.setText(MDetail.get(0).getB_inquiry());
        care_number.setText(MDetail.get(0).getB_care());
        if (MDetail.get(0).getB_mini() != null) {
            statment_card.setVisibility(View.VISIBLE);
            statment_number.setText(MDetail.get(0).getB_mini());
        } else {
            statment_card.setVisibility(View.GONE);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
