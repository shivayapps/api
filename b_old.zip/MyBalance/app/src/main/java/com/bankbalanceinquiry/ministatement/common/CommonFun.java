package com.bankbalanceinquiry.ministatement.common;

import static android.content.Intent.ACTION_DIAL;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bankbalanceinquiry.ministatement.inapp.AdsManager;
import com.bankbalanceinquiry.ministatement.model.AllAccountModel;
import com.bankbalanceinquiry.ministatement.model.BilsEmiModel;
import com.bankbalanceinquiry.ministatement.model.CashModelHistory;
import com.bankbalanceinquiry.ministatement.model.FirstTimeSmsModel;
import com.bankbalanceinquiry.ministatement.utils.NetworkManager;
import com.example.app.ads.helper.InterstitialAdHelper;

import java.util.ArrayList;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;

public class CommonFun {

    public static ArrayList<AllAccountModel> allAccountModelsFun = new ArrayList<>();

    public static ArrayList<FirstTimeSmsModel> firstTimeSmsModels = new ArrayList<>();

    public static ArrayList<CashModelHistory> CashModelHistoriesTmp = new ArrayList<>();

    public static ArrayList<BilsEmiModel> BilsEmiModels = new ArrayList<>();

    public static String IsAllSmsmFill = "";
    public static String isIncommingSmsNotify = "";

    public static void RecyclerViewGridLayout(Activity activity, RecyclerView recyclerView, int SpanCount) {
        GridLayoutManager layoutManager = new GridLayoutManager(activity, SpanCount);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
    }


    public static void RecyclerViewLinearLayout(Activity activity, RecyclerView recyclerView) {
        LinearLayoutManager layoutManager = new LinearLayoutManager(activity);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
    }


    public static void invokeCall(Activity activity, Intent callIntent) {

        if (activity != null) {
            if (new AdsManager(activity).isNeedToShowAds() && NetworkManager.isInternetConnected(activity)) {
                InterstitialAdHelper.INSTANCE.isShowInterstitialAd((FragmentActivity) activity, false, new Function1<Boolean, Unit>() {
                    @Override
                    public Unit invoke(Boolean aBoolean) {

//                        Uri number = Uri.parse("tel:" + Uri.encode("01122901406"));
//                        Intent callIntent = new Intent(ACTION_DIAL, number);
                        try {
                            if (callIntent.resolveActivity(activity.getPackageManager()) != null) {
                                activity.startActivity(callIntent);
                            } else {
                                Toast.makeText(activity,"No Application Found to handle.",Toast.LENGTH_SHORT).show();
                            }
                        } catch (Exception e) {
                            Toast.makeText(activity,"No Application Found to handle.",Toast.LENGTH_SHORT).show();
                        }
                        return null;
                    }
                });
            } else {
                try {
                    if (callIntent.resolveActivity(activity.getPackageManager()) != null) {
                        activity.startActivity(callIntent);
                    } else {
                        Toast.makeText(activity,"No Application Found to handle.",Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(activity,"No Application Found to handle.",Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    public static int findSum(String str) {
        int sum = 0;
        String temp = "";
        try {
            if (TextUtils.isEmpty(str)) {
                return 0;
            }
            for (int i = 0; i < str.length(); i++) {
                char ch = str.charAt(i);
                if (Character.isDigit(ch))
                    temp += ch;
                else {
                    sum += Integer.parseInt(temp);
                    temp = "0";
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (TextUtils.isEmpty(temp)) {
            temp = "0";
        }
        return sum + Integer.parseInt(temp);
    }
}
