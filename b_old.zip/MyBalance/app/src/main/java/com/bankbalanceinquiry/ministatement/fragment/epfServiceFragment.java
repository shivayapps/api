package com.bankbalanceinquiry.ministatement.fragment;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.common.CommonFun;
import com.bankbalanceinquiry.ministatement.database.DatabaseAccess;
import com.bankbalanceinquiry.ministatement.databasedNew.DBHelperAccountNew;
import com.bankbalanceinquiry.ministatement.inapp.AdsManager;
import com.bankbalanceinquiry.ministatement.model.bankname;
import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;
import com.bankbalanceinquiry.ministatement.utils.NetworkManager;
import com.example.app.ads.helper.AdMobAdsUtilsKt;
import com.example.app.ads.helper.NativeAdsSize;
import com.example.app.ads.helper.NativeAdvancedModelHelper;

import java.util.ArrayList;
import java.util.List;

import static android.content.Context.MODE_PRIVATE;
import static android.content.Intent.ACTION_DIAL;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;

public class epfServiceFragment extends Fragment {

    CardView balance_detail_sms, balance_detail_call, balance_details_online;
    FrameLayout fl_adplaceholder;
    Context context;
    private FrameLayout adLayout;
    private CardView adcard,balance_detail_frame;


    String bank_name="No Bank";
    List<bankname> MDetail;
    int check = 0;
    private DBHelperAccountNew mydbAccountNew;
    DatabaseAccess databaseAccess;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editorBank;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_epfservice, container, false);

        context = getActivity();
        //refreshAd();
        balance_detail_sms = (CardView) view.findViewById(R.id.balance_detail_sms);
        balance_detail_call = (CardView) view.findViewById(R.id.balance_detail_call);
        balance_details_online = (CardView) view.findViewById(R.id.balance_details_online);

        fl_adplaceholder = (FrameLayout) view.findViewById(R.id.fl_adplaceholder);
        sharedPreferences = getActivity().getSharedPreferences("bank_select", MODE_PRIVATE);
        editorBank = sharedPreferences.edit();

        bank_name = sharedPreferences.getString("bank_name", "No Bank");

        databaseAccess = DatabaseAccess.getInstance(getActivity());
        databaseAccess.open();
        mydbAccountNew=new DBHelperAccountNew(getActivity());
        final ArrayList<HomeAccoutList> homeAccoutListArrayList = mydbAccountNew.GetAllAccountNew();

        ArrayAdapter<HomeAccoutList> adapter = new ArrayAdapter<HomeAccoutList>(getActivity(),  android.R.layout.simple_spinner_dropdown_item, homeAccoutListArrayList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        balance_detail_sms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String phone = "7738299899";
                Uri uri = Uri.parse("smsto:" + phone);
                Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
                intent.putExtra("sms_body", "EPFOHO UAN ENG");
                if (getActivity() != null && intent.resolveActivity(getActivity().getPackageManager()) != null) {
                    startActivity(intent);
                }
            }
        });

        balance_detail_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri number = Uri.parse("tel:" + Uri.encode("01122901406"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
//                if (getActivity() != null && callIntent.resolveActivity(getActivity().getPackageManager()) != null) {
//                startActivity(callIntent);}
                CommonFun.invokeCall(getActivity(),callIntent);
            }
        });

        balance_details_online.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (getActivity() != null) {
                    String url = "https://passbook.epfindia.gov.in/MemberPassBook/Login";
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
//                    if (i.resolveActivity(getActivity().getPackageManager()) != null) {
//                        startActivity(i);
//                    }

                    CommonFun.invokeCall(getActivity(),i);
                }
            }
        });

        adLayout = view.findViewById(R.id.adLayout);
        adcard = view.findViewById(R.id.adcard);

        balance_detail_frame = view.findViewById(R.id.balance_detail_frame);
        fl_adplaceholder = view.findViewById(R.id.fl_adplaceholder);
        int colors = ContextCompat.getColor(getActivity(), R.color.colorAccent);

        /*FacebookAdsManager facebookAdsManager = new FacebookAdsManager(context);
        facebookAdsManager.loadNativeAd(context, fl_adplaceholder, false, new AdEventListener() {
            @Override
            public void onAdLoaded() {
                balance_detail_frame.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {

            }

            @Override
            public void onLoadError(String errorCode) {
                Log.e("errorCode---->", "onLoadError: " + errorCode);
                balance_detail_frame.setVisibility(View.GONE);
            }
        });
        facebookAdsManager.loadNativeAd(context, adLayout, true, new AdEventListener() {
            @Override
            public void onAdLoaded() {
                adcard.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {

            }

            @Override
            public void onLoadError(String errorCode) {
                Log.e("errorCode---->", "onLoadError: " + errorCode);
                adcard.setVisibility(View.GONE);
            }
        });
*/

        if (new AdsManager(getActivity()).isNeedToShowAds() && NetworkManager.isInternetConnected(getActivity())) {

            new NativeAdvancedModelHelper(getActivity()).loadNativeAdvancedAd(
                    AdMobAdsUtilsKt.getEpfServiceFragAd(),
                    adLayout,
                    null, true, true, new Function1<Boolean, Unit>() {
                        @Override
                        public Unit invoke(Boolean aBoolean) {
                            return null;
                        }
                    }, new Function0<Unit>() {
                        @Override
                        public Unit invoke() {
                            return null;
                        }
                    });
//            new NativeAdvancedModelHelper(getActivity()).loadNativeAdvancedAd(
//                    NativeAdsSize.Big,
//                    fl_adplaceholder,
//                    null, true, true, new Function1<Boolean, Unit>() {
//                        @Override
//                        public Unit invoke(Boolean aBoolean) {
//                            return null;
//                        }
//                    }, new Function0<Unit>() {
//                        @Override
//                        public Unit invoke() {
//                            return null;
//                        }
//                    });

        }

        return view;
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
