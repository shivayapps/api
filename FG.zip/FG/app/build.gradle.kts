import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

plugins {
    alias(libs.plugins.android)
    alias(libs.plugins.kotlinAndroid)
    alias(libs.plugins.ksp)
    alias(libs.plugins.kotlinSerialization)
    alias(libs.plugins.parcelize)
    alias(libs.plugins.google.service)
    alias(libs.plugins.crashlytics)
    id("kotlin-kapt")
//    id("AndResGuard")
//    id("com.google.firebase.crashlytics")
//    id("com.google.gms.google-services")
}

fun getTimeStamp(): String {
//    val format = SimpleDateFormat("HH-mm-dd-MM-yyyy")
    val format = SimpleDateFormat("'D'ddMM'T'HHmm", Locale.ENGLISH)
    return format.format(Date())
}

android {
    namespace = libs.versions.app.version.appId.get()
    compileSdk = project.libs.versions.app.build.compileSDKVersion.get().toInt()
//    signingConfigs {
//        create("release") {
//            storeFile = rootProject.file("app/exploregallery.jks")
//            storePassword = "123456"
//            keyAlias = "exploregallery"
//            keyPassword = "123456"
//        }
//    }

    defaultConfig {
        applicationId = libs.versions.app.version.appId.get()

        minSdk = project.libs.versions.app.build.minimumSDK.get().toInt()
        targetSdk = project.libs.versions.app.build.targetSDK.get().toInt()

        versionCode = project.libs.versions.app.version.versionCode.get().toInt()
        versionName = project.libs.versions.app.version.versionName.get()

        vectorDrawables.useSupportLibrary = true
        ksp {
            arg("room.schemaLocation", "$projectDir/schemas")
        }
//        setProperty("archivesBaseName", "Gallery-$versionName${getTimeStamp()}")
        setProperty("archivesBaseName", "Gallery-$versionName")

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildFeatures {
        buildConfig = true
        viewBinding = true
//        dataBinding = true
    }

    bundle {
        language {
            enableSplit = false
        }
    }

    buildTypes {
        debug {
//            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            isShrinkResources = true
//            isUseProguard = false
//            isDebuggable = true

            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )

            resValue("string","ads_application_id", "ca-app-pub-3940256099942544~3347511713")

            resValue("string","b_albumActivity","ca-app-pub-3940256099942544/9214589741")
            resValue("string","b_exploreAlbumActivity","ca-app-pub-3940256099942544/9214589741")
            resValue("string","b_homeActivity","ca-app-pub-3940256099942544/9214589741")
            resValue("string","b_imageListActivity","ca-app-pub-3940256099942544/9214589741")
            resValue("string","b_recentlyDeletedActivity","ca-app-pub-3940256099942544/9214589741")
            resValue("string","b_mapExploreActivity","ca-app-pub-3940256099942544/9214589741")
            resValue("string","b_recoverMediaActivity","ca-app-pub-3940256099942544/9214589741")
            resValue("string","b_privateViewerActivity","ca-app-pub-3940256099942544/9214589741")
            resValue("string","b_privateActivity","ca-app-pub-3940256099942544/9214589741")
            resValue("string","b_privateListActivity","ca-app-pub-3940256099942544/9214589741")
            resValue("string","b_selectImageActivity","ca-app-pub-3940256099942544/9214589741")
            resValue("string","b_editActivity","ca-app-pub-3940256099942544/9214589741")
            resValue("string","b_photoVideoActivity","ca-app-pub-3940256099942544/9214589741")
            resValue("string","b_favoriteListActivity","ca-app-pub-3940256099942544/9214589741")
            resValue("string","b_dirsActivity","ca-app-pub-3940256099942544/9214589741")

            resValue("string","native_language","ca-app-pub-3940256099942544/2247696110")
            resValue("string","native_exit","ca-app-pub-3940256099942544/2247696110")

            resValue("string","inter_language","ca-app-pub-3940256099942544/1033173712")
            resValue("string","inter_all","ca-app-pub-3940256099942544/1033173712")

            resValue("string","open_splash","ca-app-pub-3940256099942544/9257395921")
            resValue("string","open_all","ca-app-pub-3940256099942544/9257395921")

        }
        release {
//            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )

//            resValue("string","ads_application_id", "ca-app-pub-2750800778809761~3158178081")
//            resValue("string","b_callerActivity","ca-app-pub-2750800778809761/1463197190")
//
//            resValue("string","b_albumActivity","ca-app-pub-2750800778809761/9520971100")
//            resValue("string","b_exploreAlbumActivity","ca-app-pub-2750800778809761/2007696482")
//            resValue("string","b_homeActivity","ca-app-pub-2750800778809761/8424097888")

//            resValue("string","b_imageListActivity","ca-app-pub-2750800778809761/8541315242")
//            resValue("string","b_recentlyDeletedActivity","ca-app-pub-2750800778809761/7263892599")
//            resValue("string","b_privateActivity","ca-app-pub-2750800778809761/7622985245")
//            resValue("string","b_privateListActivity","ca-app-pub-2750800778809761/2335919412")
//            resValue("string","b_photoVideoActivity","ca-app-pub-2750800778809761/6309903579")
//            resValue("string","b_favoriteListActivity","ca-app-pub-2750800778809761/4206484418")
//            resValue("string","b_dirsActivity","ca-app-pub-2750800778809761/4637729250")
//            resValue("string","b_editActivity","ca-app-pub-2750800778809761/7996444826")
//            resValue("string","b_mapExploreActivity","ca-app-pub-2750800778809761/111111111")
//            resValue("string","b_recoverMediaActivity","ca-app-pub-2750800778809761/11111111")
//            resValue("string","b_selectImageActivity","ca-app-pub-2750800778809761/1111111111")
//
//            resValue("string","native_language","ca-app-pub-2750800778809761/6413916871")
//            resValue("string","native_exit","ca-app-pub-2750800778809761/8268147222")
//
//            resValue("string","inter_language","ca-app-pub-2750800778809761/5363724930")
//            resValue("string","inter_all","ca-app-pub-2750800778809761/9581228898")
//
//            resValue("string","open_splash","ca-app-pub-2750800778809761/6983873762")
//            resValue("string","open_all","ca-app-pub-2750800778809761/6894807762")

//            <TestId>
            resValue("string","ads_application_id", "ca-app-pub-3940256099942544~3347511713")

            resValue("string","b_albumActivity","ca-app-pub-3940256099942544/9214589741")
            resValue("string","b_exploreAlbumActivity","ca-app-pub-3940256099942544/9214589741")
            resValue("string","b_homeActivity","ca-app-pub-3940256099942544/9214589741")
            resValue("string","b_imageListActivity","ca-app-pub-3940256099942544/9214589741")
            resValue("string","b_recentlyDeletedActivity","ca-app-pub-3940256099942544/9214589741")
            resValue("string","b_privateActivity","ca-app-pub-3940256099942544/9214589741")
            resValue("string","b_privateListActivity","ca-app-pub-3940256099942544/9214589741")
            resValue("string","b_photoVideoActivity","ca-app-pub-3940256099942544/9214589741")
            resValue("string","b_favoriteListActivity","ca-app-pub-3940256099942544/9214589741")
            resValue("string","b_dirsActivity","ca-app-pub-3940256099942544/9214589741")
            resValue("string","b_editActivity","ca-app-pub-3940256099942544/9214589741")
//            resValue("string","b_mapExploreActivity","ca-app-pub-3940256099942544/9214589741")
//            resValue("string","b_recoverMediaActivity","ca-app-pub-3940256099942544/9214589741")
//            resValue("string","b_selectImageActivity","ca-app-pub-3940256099942544/9214589741")

            resValue("string","native_language","ca-app-pub-3940256099942544/2247696110")
            resValue("string","native_exit","ca-app-pub-3940256099942544/2247696110")

            resValue("string","inter_language","ca-app-pub-3940256099942544/1033173712")
            resValue("string","inter_all","ca-app-pub-3940256099942544/1033173712")

            resValue("string","open_splash","ca-app-pub-3940256099942544/9257395921")
            resValue("string","open_all","ca-app-pub-3940256099942544/9257395921")
//            </TestId>

        }
    }

    sourceSets {
        getByName("main").java.srcDirs("src/main/kotlin")
    }

    compileOptions {
        val currentJavaVersionFromLibs =
            JavaVersion.valueOf(libs.versions.app.build.javaVersion.get().toString())
        sourceCompatibility = currentJavaVersionFromLibs
        targetCompatibility = currentJavaVersionFromLibs
    }

    tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile> {
        kotlinOptions.jvmTarget = project.libs.versions.app.build.kotlinJVMTarget.get()
        kotlinOptions.freeCompilerArgs = listOf(
            "-opt-in=kotlin.RequiresOptIn",
            "-opt-in=com.bumptech.glide.integration.compose.ExperimentalGlideComposeApi",
            "-Xcontext-receivers"
        )
    }

//    compileOptions {
//        sourceCompatibility = JavaVersion.VERSION_1_8
//        targetCompatibility = JavaVersion.VERSION_1_8
//    }
//    kotlinOptions {
//        jvmTarget = "1.8"
//    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    packaging {
        resources {
            excludes += "META-INF/library_release.kotlin_module"
        }
    }

}

//andResGuard {
//    //mappingFile = file("./app-release-resource_mapping.txt")
//    mappingFile = null
//
//    use7zip = true
//    useSign = true
//
//    keepRoot = false
//    whiteList = listOf(
//        "R.mipmap.ic_launcher",
//        "R.id.*",
//        "R.string.com.crashlytics.*",
//        "R.string.google_app_id",
//        "R.string.gcm_defaultSenderId",
//        "R.string.default_web_client_id",
//        "R.string.ga_trackingId",
//        "R.string.firebase_database_url",
//        "R.string.google_api_key",
//        "R.string.google_crash_reporting_api_key",
//        "R.string.ssdk*",
//        "R.drawable.ssdk*"
//    )
//    compressFilePattern = listOf(
//        "*.9.png",
//        "*.png",
//        "*.jpg",
//        "*.jpeg",
//        "*.gif",
//        "resources.arsc"
//    )
////    sevenzip {
////        artifact = "com.tencent.mm:SevenZip:${ANDRESGUARD_VERSION}"
////        //path = "/usr/local/bin/7za"
////    }
//
//    finalApkBackupPath = "${buildDir}/outputs/apk/useless.apk"
//
//    digestalg = "SHA-256"
//}

dependencies {
//    implementation("androidx.core:core-ktx:1.12.0")
//    implementation("androidx.appcompat:appcompat:1.6.1")
//    implementation("com.google.android.material:material:1.11.0")
//    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
//    testImplementation("junit:junit:4.13.2")
//    androidTestImplementation("androidx.test.ext:junit:1.1.5")
//    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")

    implementation(libs.multidex)
    implementation(libs.android.image.cropper)
    implementation(libs.exif)
    implementation(libs.android.gif.drawable)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.media3.exoplayer)
    implementation(libs.sanselan)
    implementation(libs.imagefilters)
    implementation(libs.androidsvg.aar)
    implementation(libs.gestureviews)
    implementation(libs.android.splashscreen)

//    implementation(libs.subsamplingscaleimageview)
    implementation(libs.androidx.swiperefreshlayout)
    implementation(libs.awebp)
    implementation(libs.apng)
    implementation(libs.okio)
    implementation(libs.picasso) {
        exclude(group = "com.squareup.okhttp3", module = "okhttp")
    }
    implementation(libs.androidx.browser)
    implementation(libs.androidx.window)
    compileOnly(libs.okhttp)

    implementation(libs.zjupure.webpdecoder)
    implementation(libs.parkdatetimepicker)

    implementation(libs.bundles.room)
    ksp(libs.androidx.room.compiler)

    implementation(libs.android.sdp)
    implementation(libs.android.ssp)
    implementation(libs.eventbus)
    implementation(libs.dexter)

    implementation("androidx.navigation:navigation-fragment-ktx:2.7.7")
    implementation("androidx.navigation:navigation-ui-ktx:2.7.7")
    
    implementation(libs.mail)
    implementation(libs.mail.activation)
    implementation(libs.services.maps)
    implementation(libs.services.location)

    implementation("androidx.startup:startup-runtime:1.1.1")

    //Firebase Auth
//    implementation("com.google.firebase:firebase-auth:22.3.1")
    implementation("com.google.android.gms:play-services-auth:21.0.0")
    implementation("com.google.android.gms:play-services-ads:23.0.0")
    implementation("com.google.ads.mediation:facebook:6.17.0.0")
    implementation("com.google.ads.mediation:applovin:12.4.2.0")

    implementation(libs.review.ktx)
    implementation(libs.app.update)

    implementation(libs.gpuimage.plus)
//    implementation("org.wysaid:gpuimage-plus:3.0.0-min")

//    implementation(libs.listenablefuture)

    implementation(platform(libs.firebase.bom))
    implementation(libs.firebase.analytics)
    implementation(libs.firebase.auth)
    implementation(libs.firebase.perf)
    implementation(libs.firebase.messaging)
    implementation(libs.firebase.config)
    implementation(libs.firebase.crashlytics)

    //from common >>>>
    implementation(libs.kotlinx.serialization.json)
    api(libs.kotlin.immutable.collections)

    implementation(libs.androidx.documentfile)
    implementation(libs.androidx.exifinterface)
    implementation(libs.androidx.biometric.ktx)
    implementation(libs.ez.vcard)

    implementation(libs.bundles.lifecycle)
//    implementation(libs.bundles.compose)
//    implementation(libs.compose.view.binding)
//    debugImplementation(libs.bundles.compose.preview)

    api(libs.joda.time)
    api(libs.recyclerView.fastScroller)
    api(libs.reprint)
    api(libs.rtl.viewpager)
    api(libs.patternLockView)

//    api(libs.themeChanger)
    api(libs.androidx.core.ktx)
    api(libs.androidx.appcompat)
    api(libs.material)
    api(libs.gson)

    implementation(libs.glide.compose)
    api(libs.glide)
    ksp(libs.glide.ksp)
//    ksp(libs.glide.compiler)

    implementation(libs.blurview)
    implementation(libs.lottie)

    implementation(project(":ads"))
    implementation(project(":imagestopdf"))
//    implementation(project(":callsdk"))

}