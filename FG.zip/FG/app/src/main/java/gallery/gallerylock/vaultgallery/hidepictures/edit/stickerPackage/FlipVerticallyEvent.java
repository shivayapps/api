package gallery.gallerylock.vaultgallery.hidepictures.edit.stickerPackage;

public class FlipVerticallyEvent extends AbstractFlipEvent {

  @Override @ StickerView.Flip protected int getFlipDirection() {
    return  StickerView.FLIP_VERTICALLY;
  }
}
