package gallery.gallerylock.vaultgallery.hidepictures.interfaces;

public interface OnImageScanListener {
    void onImageScan(int value);
    void onScanCompleted();
}