package gallery.gallerylock.vaultgallery.hidepictures.calendardaterangepicker.models

internal enum class DateTiming {
    NONE,
    START,
    END
}
