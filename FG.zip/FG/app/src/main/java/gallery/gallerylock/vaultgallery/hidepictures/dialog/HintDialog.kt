package gallery.gallerylock.vaultgallery.hidepictures.dialog

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import gallery.gallerylock.vaultgallery.hidepictures.databinding.DialogHintBinding

class HintDialog(
//    var mContext: Activity,
    var title: String,
    var resId: Int,
    val updateListener: () -> Unit
) : DialogFragment() {

    override fun onResume() {
        super.onResume()
        dialog!!.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = super.onCreateDialog(savedInstanceState)
        val window = dialog.window
        val attributes = window?.attributes
//        attributes?.gravity = Gravity.BOTTOM
        window?.attributes = attributes
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        return dialog
    }

    lateinit var bindingDialog: DialogHintBinding
//    var preferences: Preferences = Preferences(mContext)

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogHintBinding.inflate(layoutInflater, container, false)
        intView()
        intListener()
        return bindingDialog.root
    }


    private fun intView() {
        bindingDialog.tvtitle.text=title
        bindingDialog.ivHint.setImageResource(resId)
    }

    private fun intListener() {
//        bindingDialog.btnCancel.setOnClickListener { dismiss() }

        bindingDialog.btnPositive.setOnClickListener {
            dismiss()
            updateListener.invoke()

        }
    }


//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)
}

