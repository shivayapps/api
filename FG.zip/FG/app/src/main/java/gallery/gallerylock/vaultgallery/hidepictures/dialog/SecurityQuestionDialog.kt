package gallery.gallerylock.vaultgallery.hidepictures.dialog

import android.app.Activity
import android.app.Dialog
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.adapter.SpinnerQueAdapter
import gallery.gallerylock.vaultgallery.hidepictures.databinding.DialogSecurityQuestionBinding
//import gallery.gallerylock.vaultgallery.hidepictures.secret.PrivateActivity
import gallery.gallerylock.vaultgallery.hidepictures.utils.Preferences

class SecurityQuestionDialog(
    var mContext: Activity,
    var type: Int=0,
    var isChangePass: Boolean=false,
    val updateListener: (isSuccess:Boolean) -> Unit,
    val useDarkMode:Boolean?=false
) : BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogSecurityQuestionBinding
    var preferences: Preferences = Preferences(mContext)
    var isShowPinLock = false


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogSecurityQuestionBinding.inflate(layoutInflater, container, false)
        intView()
        intListener()
        return bindingDialog.root
    }


    private fun intView() {
        isShowPinLock = preferences.getShowPINLock()

        val adapter = SpinnerQueAdapter(mContext, resources.getStringArray(R.array.security_question))
        bindingDialog.questionSpinner.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#222222"))
        bindingDialog.questionSpinner.adapter = adapter

        if (type == 1) {
            bindingDialog.questionSpinner.setSelection(preferences.getSecurityQuestion())
        }
        if (isChangePass) {
            bindingDialog.securityAnswer.setText(preferences.getAnswerQuestion())
        }
    }

    private fun intListener() {
        bindingDialog.btnCancel.setOnClickListener {
            preferences.putIgnoreQuestion(true)
            updateListener.invoke(false)
            dismiss()
        }

//        bindingDialog.btnOK.setOnClickListener {
//            val answer = bindingDialog.securityAnswer.text.toString()
//            if (bindingDialog.questionSpinner.selectedItemPosition == 0)
//                Toast.makeText(
//                    mContext,
//                    getString(R.string.PleaseSelectQue),
//                    Toast.LENGTH_SHORT
//                ).show()
//            else if (TextUtils.isEmpty(answer)) {
//                Toast.makeText(
//                    mContext,
//                    getString(R.string.PleaseSelectQue),
//                    Toast.LENGTH_SHORT
//                ).show()
//            } else {
//                hideSoftKeyboard()
//                if (isChangePass) {
//                    preferences.putSecurityQuestion(bindingDialog.questionSpinner.selectedItemPosition)
//                    preferences.putAnswerQuestion(answer)
//                    Toast.makeText(
//                        mContext,
//                        getString(R.string.Question_change_successfully),
//                        Toast.LENGTH_SHORT
//                    ).show()
////                    setResult(RESULT_OK)
////                    finish()
//                    updateListener.invoke(true)
//                    dismiss()
//                } else if (!preferences.getSetQuestion()) {
//                    preferences.putSetQuestion(true)
//                    preferences.putSecurityQuestion(bindingDialog.questionSpinner.selectedItemPosition)
//                    preferences.putAnswerQuestion(answer)
//                    if (preferences.getShowPINLock())
//                        preferences.putSetPass(true)
//                    else
//                        preferences.putSetPattern(true)
//
////                    if (isOpenPrivate) startActivity(Intent(this, PrivateActivity::class.java))
////                    setResult(RESULT_OK)
////                    finish()
//                    updateListener.invoke(true)
//                    dismiss()
//                } else {
//                    if (bindingDialog.questionSpinner.selectedItemPosition == preferences.getSecurityQuestion()) {
//                        if (preferences.getAnswerQuestion().equals(answer)) {
//                            if (preferences.getShowPINLock()) {
//                                preferences.putSetPass(false)
//                                preferences.putPass("")
//                            } else {
//                                preferences.putSetPattern(false)
//                                preferences.putPattern("")
//                            }
//                            updateListener.invoke(true)
//                            dismiss()
//
//
//                        } else {
//                            Toast.makeText(
//                                mContext,
//                                R.string.msg_security_ans,
//                                Toast.LENGTH_SHORT
//                            ).show()
//                        }
//                    } else Toast.makeText(
//                        mContext,
//                        R.string.msg_security_que,
//                        Toast.LENGTH_SHORT
//                    ).show()
//                }
//            }
//        }

        bindingDialog.btnOK.setOnClickListener {

            val answer = bindingDialog.securityAnswer.text.toString()
            if (bindingDialog.questionSpinner.selectedItemPosition == 0)
                Toast.makeText(
                    mContext,
                    getString(R.string.PleaseSelectQue),
                    Toast.LENGTH_SHORT
                ).show()
            else if (TextUtils.isEmpty(answer)) {
                Toast.makeText(
                    mContext,
                    getString(R.string.PleaseSelectQue),
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                hideSoftKeyboard()
                if (isChangePass) {
                    preferences.putSecurityQuestion(bindingDialog.questionSpinner.selectedItemPosition)
                    preferences.putAnswerQuestion(answer)
                    Toast.makeText(
                        mContext,
                        getString(R.string.Question_change_successfully),
                        Toast.LENGTH_SHORT
                    ).show()

                    updateListener.invoke(true)
                    dismiss()
//                    setResult(AppCompatActivity.RESULT_OK)
//                    finish()
                } else if (!preferences.getSetQuestion()) {
                    preferences.putSetQuestion(true)
                    preferences.putIgnoreQuestion(false)
                    preferences.putSecurityQuestion(bindingDialog.questionSpinner.selectedItemPosition)
                    preferences.putAnswerQuestion(answer)

//                    if (preferences.getShowPINLock())
//                        preferences.putSetPass(true)
//                    else
//                        preferences.putSetPattern(true)

                    updateListener.invoke(true)
                    dismiss()
//                    if (isOpenPrivate) startActivity(Intent(mContext, PrivateActivity::class.java))
//                    setResult(AppCompatActivity.RESULT_OK)
//                    finish()
                } else {
                    if (bindingDialog.questionSpinner.selectedItemPosition == preferences.getSecurityQuestion()) {
                        if (preferences.getAnswerQuestion().equals(answer)) {
                            if (preferences.getShowPINLock()) {
                                preferences.putSetPass(false)
                                preferences.putPass("")
                            } else {
                                preferences.putSetPattern(false)
                                preferences.putPattern("")
                            }

                            updateListener.invoke(true)
                            dismiss()


                        } else {
                            Toast.makeText(
                                mContext,
                                R.string.msg_security_ans,
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } else Toast.makeText(
                        mContext,
                        R.string.msg_security_que,
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            dismiss()
            updateListener.invoke(true)
        }

    }

    fun hideSoftKeyboard() {
        val inputMethodManager = mContext.getSystemService(AppCompatActivity.INPUT_METHOD_SERVICE) as InputMethodManager
        inputMethodManager.hideSoftInputFromWindow(bindingDialog.securityAnswer.windowToken, 0)
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}

