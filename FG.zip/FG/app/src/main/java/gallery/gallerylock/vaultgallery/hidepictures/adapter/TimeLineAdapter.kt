package gallery.gallerylock.vaultgallery.hidepictures.adapter

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.LatLng
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.databinding.ItemAlbumBinding
import gallery.gallerylock.vaultgallery.hidepictures.extension.beGone
import gallery.gallerylock.vaultgallery.hidepictures.extension.beVisible
import gallery.gallerylock.vaultgallery.hidepictures.model.AlbumData
import gallery.gallerylock.vaultgallery.hidepictures.utils.Preferences


class TimeLineAdapter(
    var context: Context,
    val albumList: ArrayList<AlbumData>,
    val savedInstance: Bundle?=null,
    val clickListener: (albumData: AlbumData) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var preferences: Preferences = Preferences(context)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = ItemAlbumBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return AlbumGridViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        holder.itemView.tag = holder

        val albumGridViewHolder = holder as AlbumGridViewHolder
        val albumData: AlbumData = albumList[position] as AlbumData

        albumGridViewHolder.binding.viewFront.setOnClickListener {
            clickListener(albumList[position])
        }
//        albumGridViewHolder.binding.cardImage.setOnClickListener {
//            clickListener(albumList[position])
//        }
//        albumGridViewHolder.binding.mapImage.setOnClickListener {
//            clickListener(albumList[position])
//        }

        albumGridViewHolder.binding.txtTitle.text = albumData.title
        if (albumData.pictureData.isNotEmpty()) {
            albumGridViewHolder.binding.txtCount.text = "${albumData.pictureData.size}"
            if(albumData.lati>0 && albumData.long>0) {
                albumGridViewHolder.binding.mapImage.onCreate(savedInstance)
                albumGridViewHolder.binding.mapImage.getMapAsync(object :OnMapReadyCallback{
                    override fun onMapReady(googleMap: GoogleMap) {
                        val latlng=LatLng(albumData.lati.toDouble(), albumData.long.toDouble())
//                        googleMap.addMarker(MarkerOptions().position(latlng))
                        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latlng, 10f))
                        googleMap.uiSettings.setAllGesturesEnabled(false)
//                        googleMap.mapType=GoogleMap.MAP_TYPE_SATELLITE
                        albumGridViewHolder.binding.mapImage.onResume()
//                        googleMap.setOnMarkerClickListener {
//                            clickListener(albumList[position])
//                            true
//                        }
                    }
                })
                albumGridViewHolder.binding.mapImage.setPadding(-60,-60,-60,-60)
                albumGridViewHolder.binding.image.beGone()
                albumGridViewHolder.binding.mapImage.beVisible()
            } else {
                albumGridViewHolder.binding.mapImage.beGone()
                albumGridViewHolder.binding.image.beVisible()
                Glide.with(context.applicationContext)
                    .load(albumData.pictureData[0].filePath)
                    .into(albumGridViewHolder.binding.image)
            }
        } else {
            albumGridViewHolder.binding.txtCount.text = "0"
            albumGridViewHolder.binding.image.setImageDrawable(
                ContextCompat.getDrawable(
                    context,
                    R.drawable.ic_image_placeholder
                )
            )
        }

    }

    override fun getItemCount(): Int {
        return albumList.size
    }

    class AlbumGridViewHolder(var binding: ItemAlbumBinding) :
        RecyclerView.ViewHolder(binding.root)



}