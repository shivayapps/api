package gallery.gallerylock.vaultgallery.hidepictures.secret.activity

import android.Manifest
import android.accounts.AccountManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.util.Patterns
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.TextView
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException

//import com.google.firebase.FirebaseApp
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.base.BaseNoThemeActivity
import gallery.gallerylock.vaultgallery.hidepictures.databinding.ActivitySecurityEmailBinding
import gallery.gallerylock.vaultgallery.hidepictures.dialog.SecurityQuestionDialog
import gallery.gallerylock.vaultgallery.hidepictures.extension.toast
import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant
import gallery.gallerylock.vaultgallery.hidepictures.utils.Preferences

class SecurityEmailActivity : BaseNoThemeActivity() {

    lateinit var binding: ActivitySecurityEmailBinding
    lateinit var preferences: Preferences

    var isChangePass = false
    var isChangeMail = false

    //    lateinit var mAuth: FirebaseAuth
    private lateinit var googleSignInClient: GoogleSignInClient

    override fun onCreate(savedInstanceState: Bundle?) {
//        forceDarkMode=true
        super.onCreate(savedInstanceState)
        binding = ActivitySecurityEmailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Configure Google Sign In
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken("933603671374-r5k82ki4poldu9sh9bl0n2hlngd3t4k8.apps.googleusercontent.com")
            .requestEmail()
            .build()
        googleSignInClient = GoogleSignIn.getClient(this, gso)
//        mAuth = FirebaseAuth.getInstance()

        intView()
    }

    private fun intView() {
        isChangePass = intent.getBooleanExtra(Constant.EXTRA_CHANGE_PASS, false)
        isChangeMail = intent.getBooleanExtra(Constant.EXTRA_CHANGE_EMAIL, false)
        preferences = Preferences(this)
        binding.txtTitle.text = getString(R.string.set_Security_email)
//        if (isChangeMail) {
//            binding.recoveryEmail.setText(preferences.securityEmail)
//        }
        intListener()

    }

    private fun signIn() {
        val signInIntent = googleSignInClient.signInIntent
//        val signInIntent = googleSignInClient.silentSignIn()
//        signInIntent.addOnCompleteListener(this) { task ->
//            if (task.isSuccessful) {
//                Log.d("SignInActivity", "signIn.Success")
//                val account = task.result
//                if (account != null) {
//                    Log.d("SignInActivity", "firebaseAuthWithGoogle:" + account.email)
//                    binding.recoveryEmail.setText(account.email)
//                    googleSignInClient.signOut()
//                } else
//                Log.d("SignInActivity", "account null")
//            } else {
//                Log.d("SignInActivity", "signIn.failed")
//            }
//        }
//        startActivityForResult(signInIntent,101)
        signInResultLauncher.launch(signInIntent)
    }

    val requestUsernamePermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { map ->
        if (
            map[Manifest.permission.GET_ACCOUNTS] == true
//            && map[Manifest.permission.READ_CONTACTS] == true
        ) {
//        if (map[Manifest.permission.GET_ACCOUNTS] == true) {
            // Permission is granted.
            // You can use the API that requires the permission.
        } else {
            // Permission is not granted.
            val text = "Cannot assign UID since permissions not granted"
            toast(text)
        }
    }

    fun isPermissionGranted(permission: String): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M)
            return checkCallingOrSelfPermission(permission) == PackageManager.PERMISSION_GRANTED
        val hasPermission = ContextCompat.checkSelfPermission(this, permission)
        return hasPermission == PackageManager.PERMISSION_GRANTED
    }


//    val emailAccounts: List<String>
//        get() {
//            requestUsernamePermissions.launch(
//                arrayOf(
//                    Manifest.permission.GET_ACCOUNTS
//                    //, Manifest.permission.READ_CONTACTS
//                )
//            )
//
//            val emails = HashSet<String>()
//            val emailPattern = Patterns.EMAIL_ADDRESS
////            val accounts = AccountManager.get(this).getAccountsByType("com.google");
//            val accounts = AccountManager.get(this).accounts
//            for (account in accounts) {
//                Log.e("selectEmail", "account.type:${account.type}")
//                if (account.type == "com.google") {
//                    Log.e("selectEmail", "account.name:${account.name}")
//                    if (emailPattern.matcher(account.name).matches()) {
//                        emails.add(account.name)
//                    }
//                }
//            }
//            return ArrayList(LinkedHashSet(emails))
//        }


    fun isValidEmail(target: String): Boolean {
        val emailPattern = Patterns.EMAIL_ADDRESS
        return !TextUtils.isEmpty(target) && emailPattern.matcher(target).matches()
    }

    fun hideKeyboard(view: EditText) {
        view.clearFocus()
        val methodManager = (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.hideSoftInputFromWindow(view.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
    }

    private fun intListener() {

        binding.icBack.setOnClickListener {
            finish()
        }
        binding.selectEmail.setOnClickListener {
            signIn()
//            val items: ArrayList<RadioItem> = ArrayList()
//            for (account in emailAccounts) {
//                items.add(RadioItem(0, account))
//            }
//            if (items.size > 0) {
//                val radioGroupDialog = RadioGroupDialog(items, preferences.screenRotation) {
//                    binding.recoveryEmail.setText(items.get(it).title)
//                }
//                radioGroupDialog.show(supportFragmentManager, radioGroupDialog.tag)
//            }
        }

        binding.recoveryEmail.setOnEditorActionListener(object : TextView.OnEditorActionListener {
            override fun onEditorAction(v: TextView?, actionId: Int, event: KeyEvent?): Boolean {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    hideKeyboard(binding.recoveryEmail)
                }
                return true
            }
        })

        binding.btnConfirm.setOnClickListener {
            val strInput = binding.recoveryEmail.text.toString().trim()

            if (strInput.isNotEmpty() && isValidEmail(strInput)) {
//                preferences.securityEmail = strInput
                if (preferences.getShowPINLock())
                    preferences.putSetPass(true)
                else
                    preferences.putSetPattern(true)

                if (isChangeMail) {
                    gotoNextScreen()
                } else {
                    val securityQuestionDialog =
                        SecurityQuestionDialog(this@SecurityEmailActivity, updateListener = {
//                            if (it) {

                            gotoNextScreen()
//                            }
                        })
                    securityQuestionDialog.show(supportFragmentManager, securityQuestionDialog.tag)
                }
            } else {
                binding.recoveryEmail.error = "Please enter valid email."
                toast("Please enter valid email.")
            }
        }
    }


    var signInResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->

        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        //val exception = task.exception
        if (task.isSuccessful) {
            try {
                // Google Sign In was successful, authenticate with Firebase
                val account = task.result
                if (account != null) {
                    Log.d("SignInActivity", "firebaseAuthWithGoogle:" + account.email)
                    binding.recoveryEmail.setText(account.email)
                    googleSignInClient.signOut()
                } else
                    Log.d("SignInActivity", "account null")
//                    firebaseAuthWithGoogle(account.idToken!!)
            } catch (e: ApiException) {
                // Google Sign In failed, update UI appropriately
                Log.w("SignInActivity", "Google sign in failed", e)
            }
        } else {
            Log.w(
                "SignInActivity", "SignIn Failed:\n}" +
                        "message:${task.exception!!.message}"
            )
        }
    }

    fun gotoNextScreen() {
        if (isChangePass) {
            setResult(AppCompatActivity.RESULT_OK)
            finish()
//        } else if (isOpenPrivate) {
////            startActivity(Intent(this, PrivateActivity::class.java))
//            setResult(AppCompatActivity.RESULT_OK)
//            finish()
        } else {
            setResult(AppCompatActivity.RESULT_OK)
            finish()

        }
    }


}