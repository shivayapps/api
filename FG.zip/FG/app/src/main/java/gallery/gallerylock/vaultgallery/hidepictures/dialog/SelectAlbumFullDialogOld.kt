package gallery.gallerylock.vaultgallery.hidepictures.dialog

import android.app.Activity
import android.app.Dialog
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.window.layout.WindowMetricsCalculator
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.adapter.AddAlbumAdapter
import gallery.gallerylock.vaultgallery.hidepictures.databinding.DialogAddAlbumFullBinding
import gallery.gallerylock.vaultgallery.hidepictures.model.AlbumData


class SelectAlbumFullDialogOld(
    var mContext: Activity,
    var albumDataList: ArrayList<AlbumData>,
    var isCopy: Boolean,
    val selectPathListener: (path: String) -> Unit,
    val createAlbumListener: () -> Unit,
) :
    BottomSheetDialogFragment() {

    lateinit var binding: DialogAddAlbumFullBinding
    lateinit var albumAdapter: AddAlbumAdapter
    var albumList: ArrayList<AlbumData> = ArrayList()
    var selectPos = 0


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = DialogAddAlbumFullBinding.inflate(layoutInflater, container, false)

        intView()

        val windowMetrics = WindowMetricsCalculator.getOrCreate().computeCurrentWindowMetrics(mContext)
        val height = windowMetrics.bounds.height()
        dialog?.findViewById<FrameLayout>(com.google.android.material.R.id.design_bottom_sheet)?.let { bs ->
            BottomSheetBehavior.from(bs).peekHeight = height
            BottomSheetBehavior.from(bs).state = BottomSheetBehavior.STATE_EXPANDED
        }

        return binding.root
    }


    private fun intView() {

        if (isCopy)
            binding.txtTitle.text = mContext.getString(R.string.copy_to_album)
        else
            binding.txtTitle.text = mContext.getString(R.string.move_to_album)

        albumList.addAll(albumList.size, albumDataList)
        albumList.add(AlbumData(mContext.getString(R.string.add), isCustomAlbum = true))

        initAdapter()
        initListener()
    }

    private fun initListener() {
        binding.btnClose.setOnClickListener { dismiss() }
    }

    private fun initAdapter() {
        albumAdapter = AddAlbumAdapter(mContext, albumList, clickListener = {
            selectPos = it
            val albumData = albumList[selectPos]
            if (albumData.isCustomAlbum) {
                if (albumData.title == mContext.getString(R.string.add)) {
                    dismiss()
                    createAlbumListener()
                } else if(albumData.folderPath.isNotEmpty()) {
                    dismiss()
                    selectPathListener(albumData.folderPath)
                }
            } else {
                dismiss()
                selectPathListener(albumData.folderPath)
            }
        })
        val gridLayoutManager = GridLayoutManager(mContext, 3, RecyclerView.VERTICAL, false)
        binding.albumRecycler.layoutManager = gridLayoutManager
        binding.albumRecycler.adapter = albumAdapter
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)

}