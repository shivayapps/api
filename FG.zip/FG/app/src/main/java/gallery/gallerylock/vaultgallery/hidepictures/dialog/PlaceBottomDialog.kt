package gallery.gallerylock.vaultgallery.hidepictures.dialog

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.activities.ImageListActivity
import gallery.gallerylock.vaultgallery.hidepictures.adapter.PlaceAdapter
import gallery.gallerylock.vaultgallery.hidepictures.databinding.DialogPlaceBottomBinding
import gallery.gallerylock.vaultgallery.hidepictures.model.AlbumData
import gallery.gallerylock.vaultgallery.hidepictures.model.PlaceData
import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant

class PlaceBottomDialog(val mContext:Context,var albumList: ArrayList<PlaceData>) : BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogPlaceBottomBinding

    var albumAdapter: PlaceAdapter? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogPlaceBottomBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {
        albumAdapter = PlaceAdapter(mContext, albumList,
            clickListener = {
                val albumData = albumList[it]
                openImageList(albumData)
            })

        bindingDialog.recyclerViewPlace.layoutManager =
            GridLayoutManager(mContext, 1, GridLayoutManager.HORIZONTAL, false)
        bindingDialog.recyclerViewPlace.setHasFixedSize(false)
        bindingDialog.recyclerViewPlace.adapter = albumAdapter
    }
    private fun openImageList(placeList: PlaceData) {

        Constant.albumData = AlbumData(
            placeList.place,
            placeList.pictureData,
            "",
            0,
            0,
            isCustomAlbum = true
        )
        startActivity(Intent(mContext, ImageListActivity::class.java))
    }

    private fun intListener() {

//        bindingDialog.btnOK.setOnClickListener {
//            dismiss()
//        }
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}