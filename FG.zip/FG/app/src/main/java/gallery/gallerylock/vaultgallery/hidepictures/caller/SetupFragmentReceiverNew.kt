package gallery.gallerylock.vaultgallery.hidepictures.caller

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.media.AudioManager
import android.provider.Settings
import android.telephony.TelephonyManager
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
//import com.example.mycallstate.R
//import com.example.mycallstate.activity.CallerActivity
//import com.example.mycallstate.activity.CallerActivity.Companion.binding
//import com.example.mycallstate.activity.CallerActivity.Companion.callStartTime
//import com.example.mycallstate.activity.CallerActivity.Companion.floatWindowLayoutParam
//import com.example.mycallstate.activity.CallerActivity.Companion.isWindowShowing
//import com.example.mycallstate.activity.CallerActivity.Companion.seconds
//import com.example.mycallstate.activity.CallerActivity.Companion.timer
//import com.example.mycallstate.activity.CallerActivity.Companion.windowManager
//import com.example.mycallstate.adapter.ColorAdapter
//import com.example.mycallstate.databinding.OverlayLayoutBinding
//import com.example.mycallstate.preferences.PrefCalls
//import com.example.mycallstate.types.CallState
import gallery.gallerylock.vaultgallery.hidepictures.utils.LogEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Calendar
import java.util.Locale
import java.util.Timer
import java.util.TimerTask


//class SetupFragmentReceiverNew : BroadcastReceiver() {
//
//    private lateinit var mContext: Context
//
//    private val colorAdapter: ColorAdapter by lazy {
//        ColorAdapter(object : ColorAdapter.ClickListeners {
//            override fun onClick(color: String) {
//
//            }
//        })
//    }
//
//    override fun onReceive(context: Context, intent: Intent) {
//
//        if (intent.action == TelephonyManager.ACTION_PHONE_STATE_CHANGED) {
//            this.mContext = context
//            val preferences = PrefCalls(context)
//            if (preferences.isShowCallInfo) {
//                when (intent.getStringExtra(TelephonyManager.EXTRA_STATE)) {
//                    TelephonyManager.EXTRA_STATE_IDLE -> {
//                        // Phone is in an idle state (no calls)
//                        Log.d("PhoneStateReceiver", "Phone is idle 1")
//                        if (isWindowShowing) {
//                            floatWindowLayoutParam?.windowAnimations = R.style.enterAnim
//                            floatWindowLayoutParam?.gravity =  Gravity.CENTER
//                            val animSlideIn = AnimatorSet()
//                            animSlideIn.playTogether(
//                                ObjectAnimator.ofFloat(binding?.root, "translationX", 250f)
//                            )
//                            animSlideIn.duration = 5000
//                            animSlideIn.start()
//                            if (Settings.canDrawOverlays(mContext)) {
//                                floatWindowLayoutParam?.let {
//                                    windowManager?.updateViewLayout(
//                                        binding?.root,
//                                        it
//                                    )
//                                }
//                            }
//                            stopCounter()
//                            if (Settings.canDrawOverlays(mContext)) {
//                                windowManager?.removeViewImmediate(binding!!.root)
//                            }
//                            val calendar = Calendar.getInstance()
//                            val format = SimpleDateFormat("dd/mm/yy", Locale.ENGLISH)
//                            val today = format.format(calendar.timeInMillis)
//                            LogEvent.logEvent("callercad_open","$today")
//
//                            isWindowShowing = false
////                            AdsConfig.isSystemDialogOpen=true
//
//                            val mIntent = Intent(mContext, CallerActivity::class.java)
//                            mIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
//                            mIntent.putExtra("fromwhere", "ser")
//                            mContext.startActivity(mIntent)
//                        }
//                    }
//
//                    TelephonyManager.EXTRA_STATE_RINGING -> {
//
////                        val serviceIntent = Intent(
////                            context,
////                            PhoneStateForegroundService::class.java
////                        )
////                        context.startService(serviceIntent)
//
//                        // Phone is ringing
//                        Log.d("PhoneStateReceiver", "Phone is ringing 1")
//                        if (!isWindowShowing) {
//                            displayWindow(CallState.STATE_RINGING)
//                            val calendar = Calendar.getInstance()
//                            val hourOfDay = calendar.get(Calendar.HOUR_OF_DAY)
//                            val minute = calendar.get(Calendar.MINUTE)
//                            callStartTime = "$hourOfDay:$minute"
//                            isWindowShowing = true
//                        }
//                    }
//
//                    TelephonyManager.EXTRA_STATE_OFFHOOK -> {
//
//                        // Phone is in an off-hook state (call in progress)
//                        Log.d("PhoneStateReceiver", "Call in progress 1")
//                        if (!isWindowShowing) {
//                            displayWindow(CallState.STATE_OFFHOOK)
//                            if (callStartTime == "") {
//                                val calendar = Calendar.getInstance()
//                                val hourOfDay = calendar.get(Calendar.HOUR_OF_DAY)
//                                val minute = calendar.get(Calendar.MINUTE)
//                                callStartTime = "$hourOfDay:$minute"
//                            }
//                            isWindowShowing = true
//                        }
//                    }
//                }
//            }
//        }
//    }
//
//    private fun displayWindow(state: CallState) {
//        val metrics = mContext.resources.displayMetrics
//
//        val height = metrics.heightPixels
//        windowManager = mContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
////        floatView = LayoutInflater.from(mContext).inflate(R.layout.overlay_layout, null)
//        binding = OverlayLayoutBinding.inflate(LayoutInflater.from(mContext))
//
//        val layoutFlag: Int =
//            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
//
//        floatWindowLayoutParam = WindowManager.LayoutParams(
//            WindowManager.LayoutParams.MATCH_PARENT,
//            WindowManager.LayoutParams.WRAP_CONTENT,
//            layoutFlag,
//            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
//                    or WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
//                    or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
//                    or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
//            PixelFormat.TRANSLUCENT
//        )
//
//        if (isWindowShowing) {
//            if (Settings.canDrawOverlays(mContext)) {
//                windowManager?.removeViewImmediate(binding!!.root)
//            }
//        }
//
//
//        floatWindowLayoutParam?.gravity =  Gravity.CENTER
//        floatWindowLayoutParam?.windowAnimations = R.style.enterAnim
//        floatWindowLayoutParam?.x = 0
//        floatWindowLayoutParam?.y = 0
//
//        val animSlideIn = AnimatorSet()
//        animSlideIn.playTogether(
//            ObjectAnimator.ofFloat(binding!!.root, "translationX", 0f),
//            ObjectAnimator.ofFloat(binding!!.root, "translationY", 0f)
//        )
//        animSlideIn.duration = 5000
//        animSlideIn.start()
//
//
//
//        val colorList =
//            arrayListOf("#6044CC", "#9285CA", "#6F9DFF", "#C0985B", "#FF9798", "#CC8245", "#0CCA98")
//        val formatter = DateTimeFormatter.ofPattern("E, d MMM")
//        val today = LocalDate.now()
//        val tomorrow = today.plusDays(1)
//        val datesList = generateDateList(today, 28, formatter, today, tomorrow)
//
//        val hourList = generateHourList()
//        val currentHour = java.time.LocalDateTime.now().hour
//        val currentHourPosition = hourList.indexOf(currentHour.toString())
//        Log.d("TAG", "onViewCreated: currentHour => $currentHourPosition")
//
//        val minuteList = generateTimeIntervals()
//        val currentMinute = java.time.LocalDateTime.now().minute
//        val currentMinutePosition = minuteList.indexOf(currentMinute.toString())
//        Log.d("TAG", "onViewCreated: currentMinute => $currentMinutePosition")
//
//        binding?.icClose?.setOnClickListener {
//          //  windowManager?.removeViewImmediate(binding!!.root)
//         //   windowManager?.removeView(binding!!.root)
//            binding!!.root.visibility = View.GONE
//        }
//
//        colorAdapter.submitList(colorList)
//
//
////        val taskDao = TaskDatabase.getDatabase(mContext).taskDao()
////        val repository = TaskRepository(taskDao)
////        val task = repository.allTasksList
//////
////        adapter.submitList(task)
//
//        val audioManager = mContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
//
//        windowManager?.let { window ->
//            Log.d("TAG", "displayWindow: windowManager $windowManager")
//            binding?.let {
//                Log.d("TAG", "displayWindow: binding $binding")
//                if (Settings.canDrawOverlays(mContext)) {
//                    window.addView(
//                        it.root,
//                        floatWindowLayoutParam
//                    )
//                }
//
//            }
//
//        }
//
//
//
//
//      //  windowManager?.addView(binding?.root, layoutParams)
//
//        binding?.root?.setOnTouchListener { _, event ->
//            when (event.action) {
//                MotionEvent.ACTION_DOWN -> {
//                    initialX = floatWindowLayoutParam?.x!!
//                    initialY = floatWindowLayoutParam?.y!!
//                    initialTouchX = event.rawX
//                    initialTouchY = event.rawY
//                    true
//                }
//                MotionEvent.ACTION_MOVE -> {
//                    // Calculate the X and Y coordinates of the view.
//                    floatWindowLayoutParam?.x = (initialX + (event.rawX - initialTouchX)).toInt()
//                    floatWindowLayoutParam?.y = (initialY + (event.rawY - initialTouchY)).toInt()
//
//                    // Update the layout with new X and Y coordinates
//                    windowManager?.updateViewLayout(binding?.root, floatWindowLayoutParam)
//                    true
//                }
//                else -> false
//            }
//        }
//
//
//        if (state == CallState.STATE_RINGING || state == CallState.STATE_OFFHOOK) {
//            binding?.mTVDuration?.let { startCounter(it) }
//        }
//    }
//
//
//    private var initialTouchX = 0.0f
//    private var initialTouchY = 0.0f
//    private var initialX = 0
//    private var initialY = 0
//
//
//
//    private fun startCounter(duration: TextView) {
//        timer = Timer()
//        seconds = 0
//        timer?.scheduleAtFixedRate(object : TimerTask() {
//            override fun run() {
//                seconds++
//                val minutes = seconds / 60
//                val remainingSeconds = seconds % 60
//
//                val formattedTime = String.format("%02d:%02d", minutes, remainingSeconds)
//                Log.d("TAG", "duration: $formattedTime")
//                CoroutineScope(Dispatchers.Main).launch {
//                    duration.text = "duration: $formattedTime"
//                    Log.d("TAG", "formattedTime: $formattedTime\n ${CallerActivity.formattedTime}")
//                    CallerActivity.formattedTime = formattedTime
//                }
//            }
//        }, 0, 1000)
//    }
//
//    private fun stopCounter() {
//        timer?.cancel()
//    }
//
//    private fun generateDateList(
//        startDate: LocalDate,
//        numberOfDays: Int,
//        formatter: DateTimeFormatter,
//        today: LocalDate,
//        tomorrow: LocalDate
//    ): List<String> {
//        val dateList = mutableListOf<String>()
//
//        repeat(numberOfDays) {
//            val currentDate = startDate.plusDays(it.toLong())
//            val formattedDate = currentDate.format(formatter)
//            when (currentDate) {
//                today -> dateList.add("Today")
//                tomorrow -> dateList.add("Tomorrow")
//                else -> dateList.add(formattedDate)
//            }
//        }
//
//        return dateList
//    }
//
//    private fun generateHourList(): List<String> {
//        val hourList = mutableListOf<String>()
//
//        for (hour in 0..23) {
//            hourList.add("$hour")
//        }
//        return hourList
//    }
//
//    private fun generateTimeIntervals(): List<String> {
//        val timeIntervals = mutableListOf<String>()
//
//        var hour = 0
//        var minute = 0
//
//        while (hour < 24) {
//            val formattedTime = minute
//            timeIntervals.add("$formattedTime")
//
//            minute += 5
//            if (minute == 60) {
//                minute = 0
//                hour++
//            }
//        }
//
//        return timeIntervals
//    }
//
//}