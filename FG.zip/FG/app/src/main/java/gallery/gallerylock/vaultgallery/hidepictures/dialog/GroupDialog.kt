package gallery.gallerylock.vaultgallery.hidepictures.dialog

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.databinding.DialogGroupBinding
import gallery.gallerylock.vaultgallery.hidepictures.extension.beGone
import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant
import gallery.gallerylock.vaultgallery.hidepictures.utils.Preferences

class GroupDialog(val folderPath:String?="",val updateListener: () -> Unit) :
    BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogGroupBinding
    lateinit var preferences: Preferences
    var groupBy = 0
    var groupOrder = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogGroupBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
    }

    private fun intView() {
        preferences = Preferences(requireActivity())
        groupBy = preferences.getGroupBy(folderPath)
        groupOrder = preferences.getGroupOrderBy(folderPath)

        intListener()

        val groupBtn = when (groupBy) {
            Constant.GROUP_BY_NONE -> bindingDialog.groupingDialogRadioNone
            Constant.GROUP_BY_LAST_MODIFIED_DAILY -> bindingDialog.groupingDialogRadioLastModifiedDaily
            Constant.GROUP_BY_DATE_TAKEN_DAILY -> bindingDialog.groupingDialogRadioDateTakenDaily
            Constant.GROUP_BY_FILE_TYPE -> bindingDialog.groupingDialogRadioFileType
            Constant.GROUP_BY_EXTENSION -> bindingDialog.groupingDialogRadioExtension
            Constant.GROUP_BY_FOLDER -> bindingDialog.groupingDialogRadioFolder
            Constant.GROUP_BY_LAST_MODIFIED_MONTHLY -> bindingDialog.groupingDialogRadioLastModifiedMonthly
            Constant.GROUP_BY_DATE_TAKEN_MONTHLY -> bindingDialog.groupingDialogRadioDateTakenMonthly
            else -> bindingDialog.groupingDialogRadioNone
        }
        groupBtn.isChecked = true

        if (preferences.getShowFileCount()) {
            bindingDialog.cbShowFileCount.isChecked = true
        }

        if(folderPath.isNullOrEmpty()) {
            bindingDialog.cbFolderOnly.beGone()
//            bindingDialog.dividerFolder.beGone()
        }

        when (groupOrder) {
            Constant.ORDER_ASCENDING -> bindingDialog.rbAscending.isChecked = true
            Constant.ORDER_DESCENDING -> bindingDialog.rbDescending.isChecked = true
        }
    }

    private fun intListener() {
        bindingDialog.btnCancel.setOnClickListener {
            dismiss()
        }
        bindingDialog.btnOK.setOnClickListener {
            val selectedRadioButtonId: Int = bindingDialog.grpOption.checkedRadioButtonId
            val selectedRadioButtonIdOrder: Int = bindingDialog.grpOrder.checkedRadioButtonId
            var selectedType = -1
            var selectedOrder = -1
            selectedType = when (selectedRadioButtonId) {
                bindingDialog.groupingDialogRadioNone.id -> Constant.GROUP_BY_NONE
                bindingDialog.groupingDialogRadioLastModifiedDaily.id -> Constant.GROUP_BY_LAST_MODIFIED_DAILY
                bindingDialog.groupingDialogRadioDateTakenDaily.id -> Constant.GROUP_BY_DATE_TAKEN_DAILY
                bindingDialog.groupingDialogRadioFileType.id -> Constant.GROUP_BY_FILE_TYPE
                bindingDialog.groupingDialogRadioExtension.id -> Constant.GROUP_BY_EXTENSION
                bindingDialog.groupingDialogRadioFolder.id -> Constant.GROUP_BY_FOLDER
                bindingDialog.groupingDialogRadioLastModifiedMonthly.id -> Constant.GROUP_BY_LAST_MODIFIED_MONTHLY
                bindingDialog.groupingDialogRadioDateTakenMonthly.id -> Constant.GROUP_BY_DATE_TAKEN_MONTHLY
                else -> -1
            }
            selectedOrder = when (selectedRadioButtonIdOrder) {
                bindingDialog.rbAscending.id -> Constant.ORDER_ASCENDING
                bindingDialog.rbDescending.id -> Constant.ORDER_DESCENDING
                else -> -1
            }
//            if (sortType != selectedType)
//            if (bindingDialog.cbFolderOnly.isChecked)
//                preferences.setAlbumGroupType(selectedType)
//            else {
//                preferences.setAlbumGroupType(selectedType)
//                preferences.setGroupBy(selectedType)
//            }

            if (bindingDialog.cbFolderOnly.isChecked) {
                preferences.setGroupBy(selectedType,folderPath)
                preferences.setGroupOrderBy(selectedOrder,folderPath)
            } else {
                preferences.setGroupBy(selectedType,folderPath)
                preferences.setGroupOrderBy(selectedOrder,folderPath)

                preferences.setGroupBy(selectedType)
                preferences.setGroupOrderBy(selectedOrder)
            }


            preferences.putShowFileCount(bindingDialog.cbShowFileCount.isChecked)

//            if (sortOrder != selectedOrder)
//            if (bindingDialog.cbFolderOnly.isChecked)
//                preferences.setAlbumGroupOrder(selectedOrder)
//            else {
//                preferences.setAlbumGroupOrder(selectedOrder)
//                preferences.setGroupOrderBy(selectedOrder)
//            }

            dismiss()

//            if (sortType != selectedType || sortOrder != selectedOrder) {
            updateListener()
//            }
        }
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}