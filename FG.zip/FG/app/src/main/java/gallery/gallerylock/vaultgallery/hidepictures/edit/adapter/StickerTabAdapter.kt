package gallery.gallerylock.vaultgallery.hidepictures.edit.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.databinding.ItemStickerTabBinding
import gallery.gallerylock.vaultgallery.hidepictures.edit.model.StickerData


class StickerTabAdapter(
    var context: Context,
    var editList: ArrayList<StickerData>,
    val clickListener: (pos: Int) -> Unit
) :
    RecyclerView.Adapter<StickerTabAdapter.ViewHolder>() {

    var selectPos = 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemStickerTabBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return editList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.tvOption.text = editList[position].name

        if (selectPos == position)
            setSelectTab(holder.binding.tvOption)
        else
            setUnSelectTab(holder.binding.tvOption)

        holder.binding.root.setOnClickListener {
            if (selectPos != position) {
                val p = selectPos
                selectPos = position
                notifyItemChanged(selectPos)
                if (p != -1)
                    notifyItemChanged(p)
                clickListener(position)
            }
        }
    }

    class ViewHolder(var binding: ItemStickerTabBinding) : RecyclerView.ViewHolder(binding.root) {

    }

    private fun setSelectTab(textView: TextView) {
        val selectColor = ContextCompat.getColor(context, R.color.black_text)
        textView.setTextColor(selectColor)
    }

    private fun setUnSelectTab(textView: TextView) {
        val selectColor = ContextCompat.getColor(context, R.color.home_unSelect_tab_icon)
        textView.setTextColor(selectColor)
    }
}