package gallery.gallerylock.vaultgallery.hidepictures.helper

data class RadioItem(val id: Int, val title: String, val value: Any = id)
