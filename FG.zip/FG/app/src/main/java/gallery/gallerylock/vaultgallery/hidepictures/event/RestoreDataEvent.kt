package gallery.gallerylock.vaultgallery.hidepictures.event

import gallery.gallerylock.vaultgallery.hidepictures.model.RestoreData
import java.util.ArrayList

data class RestoreDataEvent(var restoreList: ArrayList<RestoreData>)
