package gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.model

import android.content.Context

class SingleTonDbHandler(var singleTonDbHandlerContext: Context) {
    val instance: DBHandler?
        get() {
            if (mInstance == null) {
                mInstance = DBHandler(singleTonDbHandlerContext)
            }
            return mInstance
        }

    companion object {
        var mInstance: DBHandler? = null
    }
}