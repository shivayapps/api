package gallery.gallerylock.vaultgallery.hidepictures.activities

import android.Manifest
import android.app.Activity
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.widget.AppCompatButton
import androidx.biometric.BiometricManager
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
//import com.example.mycallstate.preferences.PrefCalls
import com.google.android.material.imageview.ShapeableImageView
import com.karumi.dexter.Dexter
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionDeniedResponse
import com.karumi.dexter.listener.PermissionGrantedResponse
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.single.PermissionListener
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.activities.setup.LanguageActivity
import gallery.gallerylock.vaultgallery.hidepictures.base.BaseActivity
import gallery.gallerylock.vaultgallery.hidepictures.database.AppDatabase
import gallery.gallerylock.vaultgallery.hidepictures.databinding.ActivitySettingBinding
import gallery.gallerylock.vaultgallery.hidepictures.dialog.BiometricErrorDialog
import gallery.gallerylock.vaultgallery.hidepictures.dialog.ChangLockStyleDialog
import gallery.gallerylock.vaultgallery.hidepictures.dialog.ConfirmationDialog
import gallery.gallerylock.vaultgallery.hidepictures.dialog.DateTimeDialog
import gallery.gallerylock.vaultgallery.hidepictures.dialog.HintDialog
import gallery.gallerylock.vaultgallery.hidepictures.dialog.RadioConfirmationDialog
import gallery.gallerylock.vaultgallery.hidepictures.dialog.RadioGroupDialog
import gallery.gallerylock.vaultgallery.hidepictures.dialog.RatingDialog
import gallery.gallerylock.vaultgallery.hidepictures.extension.beGone
import gallery.gallerylock.vaultgallery.hidepictures.extension.beVisible
import gallery.gallerylock.vaultgallery.hidepictures.extension.beVisibleIf
import gallery.gallerylock.vaultgallery.hidepictures.extension.isVisible
import gallery.gallerylock.vaultgallery.hidepictures.extension.isBiometricIdAvailable
import gallery.gallerylock.vaultgallery.hidepictures.extension.isSupportWithErrorInfo
import gallery.gallerylock.vaultgallery.hidepictures.extension.toast
import gallery.gallerylock.vaultgallery.hidepictures.helper.RadioItem
import gallery.gallerylock.vaultgallery.hidepictures.secret.activity.LockActivity
import gallery.gallerylock.vaultgallery.hidepictures.utils.ClearCacheUtils
import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant
import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant.ALWAYS_ASK
import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant.ROTATE_BY_ASPECT_RATIO
import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant.ROTATE_BY_DEVICE_ROTATION
import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant.ROTATE_BY_SYSTEM_SETTING
import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant.SAVE_AND_REPLACE
import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant.SAVE_AS_COPY
import gallery.gallerylock.vaultgallery.hidepictures.utils.Preferences
import gallery.gallerylock.vaultgallery.hidepictures.views.SwitchButton

class SettingActivity : BaseActivity() {

    //    var themeType = 0
    lateinit var preferences: Preferences
//    lateinit var adsPref: PrefCalls

    lateinit var binding: ActivitySettingBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        if(preferences.isNeedInterAd) {
            AdmobIntersAdImpl().load(this)
        }
        binding = ActivitySettingBinding.inflate(layoutInflater)
        setContentView(binding.root)

//        adsPref = PrefCalls(this)
//        themeType = preferences.getThemeValue()

        initView()
        intListener()
    }

    private fun initView() {
        binding.cbTheme.isChecked = preferences.getThemeValue() == Constant.THEME_DARK
        binding.txtTitle.text = getString(R.string.settings)

        val selectLanguage = preferences.getSelectLanguage()
        val langStr=getLanguage(selectLanguage)
        binding.tvLanguage.text=langStr
    }

    fun getLanguage(langPos: Int): String {
        val langStr: String = when (langPos) {
            0 -> getString(R.string.english)
            1  -> getString(R.string.arabic)
            2  -> getString(R.string.french)
            3  -> getString(R.string.spanish)
            4  -> getString(R.string.russian)
            5  -> getString(R.string.japanese)
            6  -> getString(R.string.italian)
            7  -> getString(R.string.portuguese_br)
            8  -> getString(R.string.portuguese_pt)
            9  -> getString(R.string.marathi)
            10 -> getString(R.string.bangali)
            11 -> getString(R.string.china)
            12 -> getString(R.string.deutsch)
            13 -> getString(R.string.hindi)
            14 -> getString(R.string.indonesian)
            15 -> getString(R.string.korean)
            16 -> getString(R.string.melayu)
            17 -> getString(R.string.philippians)
            18 -> getString(R.string.tamil)
            19 -> getString(R.string.telugu)
            20 -> getString(R.string.thai)
            21 -> getString(R.string.turkish)
            22 -> getString(R.string.vietnamese)
            else -> getString(R.string.english)
        }
        return langStr
    }

//    var needDialog = true
//    private fun checkCaller() {
//        Log.e("checkCaller", "001")
//        val readPhoneState =
//            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == 0
//        val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//            Settings.canDrawOverlays(this)
//        } else {
//            true
//        }
//
//        Log.e("checkCaller", "readPhoneState:$readPhoneState")
//        Log.e("checkCaller", "canDrawOverlays:$canDrawOverlays")
//
//        if (readPhoneState && canDrawOverlays) {
//            adsPref.isShowCallInfo = true
//            binding.cbCall.isChecked = true
//            Log.e("checkCaller", "readPhoneState && canDrawOverlays")
//        } else {
//            Log.e(
//                "checkCaller",
//                "preferences.needToShowCallerCad:${adsPref.needToShowCallerCad}"
//            )
//            Log.e(
//                "checkCaller",
//                "preferences.isCallDialogClosable:${adsPref.isCallDialogClosable}"
//            )
//            if (adsPref.needToShowCallerCad) {
//                if (!adsPref.isCallDialogClosable) {
//                    showCallPermissionDialog()
//                } else if (needDialog) {
//                    adsPref.firstTimeDialog = false
//                    showCallPermissionDialog()
//                }
//            }
//        }
//    }

//    private fun requestSystemOverlayPermission() {
//        AdsConfig.isSystemDialogOpen = true
//
//        val intent = Intent(
//            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
//            Uri.parse("package:" + applicationContext.packageName)
//        )
//
////        val countDownTimerOverlay = object : CountDownTimer(50000L, 1) {
////            override fun onTick(l: Long) {
////                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
////                    if (Settings.canDrawOverlays(this@SettingActivity)) {
//////                    customPermissionEvent("home_draw_over_granted")
////
////                        val readPhoneState =
////                            ContextCompat.checkSelfPermission(this@SettingActivity, Manifest.permission.READ_PHONE_STATE) == 0
////                        val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
////                            Settings.canDrawOverlays(this@SettingActivity)
////                        } else {
////                            true
////                        }
////                        if (readPhoneState && canDrawOverlays) {
////                            adsPref.isShowCallInfo = true
////                            binding.cbCall.isChecked = true
////                        }
////                        binding.icCall.beVisibleIf(!adsPref.isShowCallInfo)
////                        val intentHome = Intent(this@SettingActivity, HomeActivity::class.java)
////                        intentHome.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK
////                        startActivity(intentHome)
////                        cancel()
////                    } else {
//////                    customPermissionEvent("home_draw_over_denied")
////                    }
////                }
////            }
////
////            override fun onFinish() {
////
////            }
////        }
////        countDownTimerOverlay.start()
//
//        try {
//            AdsConfig.isSystemDialogOpen = true
//            startActivityForResult(intent, 101)
//        } catch (e: Exception) {
//            Log.e("printStackTrace","printStackTrace:$e")
//        }
//
//        Handler(Looper.getMainLooper()).postDelayed({
//            val intent1 = Intent(this@SettingActivity, SettingPermissionActivity::class.java)
//            intent1.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
//            startActivity(intent1)
//        }, 500)
//
//    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
//        if (requestCode == 101) {
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
////                if (Settings.canDrawOverlays(this@SettingActivity)) {
////                    customPermissionEvent("home_draw_over_granted")
//                        AdsConfig.isSystemDialogOpen = true
//                val readPhoneState =
//                    ContextCompat.checkSelfPermission(this@SettingActivity, Manifest.permission.READ_PHONE_STATE) == 0
//                val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//                    Settings.canDrawOverlays(this@SettingActivity)
//                } else {
//                    true
//                }
//                if (readPhoneState && canDrawOverlays) {
//                    adsPref.isShowCallInfo=true
//                    binding.cbCall.isChecked=true
//
//                    if (adsPref.isShowCallInfo) {
//                        binding.icCall.visibility = View.GONE
//                    } else {
//                        binding.icCall.visibility = View.VISIBLE
//                    }
//                } else {
//                    if (!adsPref.isCallDialogClosable) {
//                        checkCaller()
//                    }
//                }
//
////                    val intentHome = Intent(this@MainActivity, MainActivity::class.java)
////                    intentHome.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK
////                    startActivity(intentHome)
////                    cancel()
////                } else {
//////                    customPermissionEvent("home_draw_over_denied")
////                }
//            }
//
//        }
    }
//    private fun showCallPermissionDialog() {
//        Log.e("checkCaller", "preferences.showCallPermissionDialog")
//        val dialogBuilder = androidx.appcompat.app.AlertDialog.Builder(this@SettingActivity)
//        val view = layoutInflater.inflate(
//            R.layout.dialog_call_permission,
//            null
//        )
//        dialogBuilder.setView(view)
//        val dialog = dialogBuilder.create()
//
//        dialog.setCanceledOnTouchOutside(false)
//        val btnPermission =
//            view.findViewById<AppCompatButton>(R.id.btnPermission)
//        val imgClose =
//            view.findViewById<ShapeableImageView>(R.id.imgClose)
//
//        if (adsPref.isCallDialogClosable) {
//            imgClose.visibility = View.VISIBLE
//        } else {
//            imgClose.visibility = View.GONE
//        }
//
//        imgClose.setOnClickListener { view1: View? ->
//            dialog.dismiss()
//        }
//
//        btnPermission.setOnClickListener { view1: View? ->
//            AdsConfig.isSystemDialogOpen=true
//            Dexter.withContext(this@SettingActivity).withPermission(
//                Manifest.permission.READ_PHONE_STATE
//            ).withListener(object : PermissionListener {
//                override fun onPermissionGranted(permissionGrantedResponse: PermissionGrantedResponse) {
//                    if (Settings.canDrawOverlays(this@SettingActivity)) {
//                        dialog.dismiss()
//                    } else {
//                        dialog.dismiss()
//                        requestSystemOverlayPermission()
//                    }
//                }
//
//                override fun onPermissionDenied(permissionDeniedResponse: PermissionDeniedResponse) {
//                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
//                    val uri = Uri.fromParts("package", packageName, null)
//                    intent.data = uri
//                    callerLauncher.launch(intent)
//                    AdsConfig.isSystemDialogOpen=true
//                    Toast.makeText(
//                        view.getContext(),
//                        "Please allow phone permission to enable feature",
//                        Toast.LENGTH_SHORT
//                    ).show();
//                    dialog.dismiss()
//                }
//
//                override fun onPermissionRationaleShouldBeShown(
//                    permissionRequest: PermissionRequest,
//                    permissionToken: PermissionToken,
//                ) {
//                    permissionToken.continuePermissionRequest()
//                }
//            }).check()
//
//        }
//        dialog.setOnDismissListener { dialogInterface: DialogInterface? ->
//            val readPhoneState =
//                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == 0
//            val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//                Settings.canDrawOverlays(this)
//            } else {
//                true
//            }
//            if (readPhoneState && canDrawOverlays) {
//                adsPref.isShowCallInfo = true
//                binding.cbCall.isChecked = true
//                if (adsPref.isShowCallInfo) {
//                    binding.icCall.visibility = View.GONE
//                } else {
//                    binding.icCall.visibility = View.VISIBLE
//                }
//                Log.e("checkCaller", "readPhoneState && canDrawOverlays")
//            } else {
//
//                adsPref.isShowCallInfo = false
//                binding.cbCall.isChecked = false
//            }
//
//            if (!adsPref.isCallDialogClosable) {
////                customEvent("main_back_pressed_exit", false)
//                AdsConfig.isSystemDialogOpen = true
////                ApplicationClass.isNeedToShowAppOpen = false
//                dialog.dismiss()
////                finishAffinity()
//            } else {
//                dialog.dismiss()
//            }
//        }
////        dialog.window?.attributes?.windowAnimations = R.style.FullScreenDialog_Slide
//        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//        if (!isFinishing && !isDestroyed) {
//            AdsConfig.isSystemDialogOpen = true
//            dialog.show()
//        }
//    }

//    private fun showCallPermissionDialog1() {
//        Log.e("checkCaller", "preferences.showCallPermissionDialog")
//        val dialogBuilder = androidx.appcompat.app.AlertDialog.Builder(this@SettingActivity)
//        val view = layoutInflater.inflate(
//            R.layout.dialog_call_permission,
//            null
//        )
//        dialogBuilder.setView(view)
//        val dialog = dialogBuilder.create()
//
//        dialog.setCanceledOnTouchOutside(false)
//        val btnPermission =
//            view.findViewById<AppCompatButton>(R.id.btnPermission)
//        val imgClose =
//            view.findViewById<ShapeableImageView>(R.id.imgClose)
//
//        if (adsPref.isCallDialogClosable) {
//            imgClose.visibility = View.VISIBLE
//        } else {
//            imgClose.visibility = View.GONE
//        }
//
//        imgClose.setOnClickListener { view1: View? ->
//            dialog.dismiss()
//        }
//
//        btnPermission.setOnClickListener { view1: View? ->
//            Dexter.withContext(this@SettingActivity).withPermission(
//                Manifest.permission.READ_PHONE_STATE
//            ).withListener(object : PermissionListener {
//                override fun onPermissionGranted(permissionGrantedResponse: PermissionGrantedResponse) {
//                    if (Settings.canDrawOverlays(this@SettingActivity)) {
//                        dialog.dismiss()
//                    } else {
//                        requestSystemOverlayPermission()
//                    }
//                }
//
//                override fun onPermissionDenied(permissionDeniedResponse: PermissionDeniedResponse) {
//                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
//                    val uri = Uri.fromParts("package", packageName, null)
//                    intent.data = uri
//                    callerLauncher.launch(intent)
//                    AdsConfig.isSystemDialogOpen = true
//                    toast("Please allo phone permission to enable feature")
//                }
//
//                override fun onPermissionRationaleShouldBeShown(
//                    permissionRequest: PermissionRequest,
//                    permissionToken: PermissionToken,
//                ) {
//                    permissionToken.continuePermissionRequest()
//                }
//            }).check()
//
//        }
//        dialog.setOnDismissListener { dialogInterface: DialogInterface? ->
//            val readPhoneState =
//                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == 0
//            val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//                Settings.canDrawOverlays(this)
//            } else {
//                true
//            }
//            if (readPhoneState && canDrawOverlays) {
//                adsPref.isShowCallInfo = true
//                binding.cbCall.isChecked = true
//                Log.e("checkCaller", "readPhoneState && canDrawOverlays")
//            } else {
//
//                adsPref.isShowCallInfo = false
//                binding.cbCall.isChecked = false
//            }
//
//            if (!adsPref.isCallDialogClosable) {
////                customEvent("main_back_pressed_exit", false)
//                AdsConfig.isSystemDialogOpen = true
//                finishAffinity()
//            } else {
//                dialog.dismiss()
//            }
//        }
////        dialog.window?.attributes?.windowAnimations = R.style.FullScreenDialog_Slide
//        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//        if (!isFinishing && !isDestroyed) {
//            AdsConfig.isSystemDialogOpen = true
//            dialog.show()
//        }
//    }

//    var callerLauncher =
//        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { _ ->
//            if (Settings.canDrawOverlays(this@SettingActivity)) {
////                dialog.dismiss()
//            } else {
//                requestSystemOverlayPermission()
//            }
//        }

    fun toggleExpand(mainView: View, actionView: View) {
        if (mainView.isVisible()) {
            mainView.beGone()
            actionView.animate()
                .rotation(0f)
                .setDuration(500).start()
        } else {
            mainView.beVisible()
            actionView.animate()
                .rotation(180f)
                .setDuration(500).start()
        }
    }

    var isFingerprintAvailable = Pair(false, "")
    private fun intListener() {

        binding.icBack.setOnClickListener {
            finish()
        }

//        binding.llActionGeneral.setOnClickListener {
//            toggleExpand(binding.llGeneral, binding.ivActionGeneral)
////            binding.llGeneral.beVisibleIf(binding.llGeneral.isGone())
//        }
//        binding.llActionVideo.setOnClickListener {
//            toggleExpand(binding.llVideo, binding.ivActionVideo)
////            binding.llVideo.beVisibleIf(binding.llVideo.isGone())
//        }
//        binding.llActionFullScreen.setOnClickListener {
//            toggleExpand(binding.llFullScreen, binding.ivActionFullScreen)
////            binding.llFullScreen.beVisibleIf(binding.llFullScreen.isGone())
//        }
//        binding.llActionDeepZoom.setOnClickListener {
//            toggleExpand(binding.llDeepZoom, binding.ivActionDeepZoom)
////            binding.llDeepZoom.beVisibleIf(binding.llDeepZoom.isGone())
//        }
//        binding.llActionSecurity.setOnClickListener {
//            toggleExpand(binding.llSecurity, binding.ivActionSecurity)
////            binding.llSecurity.beVisibleIf(binding.llSecurity.isGone())
//        }
//        binding.llActionFileOperation.setOnClickListener {
//            toggleExpand(binding.llFileOperation, binding.ivActionFileOperation)
////            binding.llFileOperation.beVisibleIf(binding.llFileOperation.isGone())
//        }
//        binding.llActionVisibility.setOnClickListener {
//            toggleExpand(binding.llVisibility, binding.ivActionVisibility)
////            binding.llVisibility.beVisibleIf(binding.llVisibility.isGone())
//        }
//        binding.llActionRecycleBin.setOnClickListener {
//            toggleExpand(binding.llRecycleBin, binding.ivActionRecycleBin)
////            binding.llRecycleBin.beVisibleIf(binding.llRecycleBin.isGone())
//        }
//        binding.llActionMore.setOnClickListener {
//            toggleExpand(binding.llMore, binding.ivActionMore)
////            binding.llMore.beVisibleIf(binding.llMore.isGone())
//        }

        binding.cbTheme.setOnCheckedChangeListener(object : SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                themeType = if (isChecked) {
                    Constant.THEME_DARK
                } else {
                    Constant.THEME_LIGHT
                }
                preferences.putTheme(themeType)

                val intent = Intent(this@SettingActivity, SettingActivity::class.java)
                setResult(RESULT_OK)
                finish()
                overridePendingTransition(0, 0)
                startActivity(intent)
                overridePendingTransition(0, 0)
//                ThemeChanger(this@SettingActivity, binding.cbTheme).switchTheme()
//                if(com.anter.library_circular_reveal_theme_changer.utils.ThemeUtilsImpl().isDarkTheme(this@SettingActivity)) {
//                    preferences.putTheme(Constant.THEME_DARK)
//                } else {
//                    preferences.putTheme(Constant.THEME_LIGHT)
//                }
//                val intent = Intent(this@SettingActivity, SettingActivity::class.java)
//                setResult(RESULT_OK)
//                finish()
//                overridePendingTransition(0, 0)
//                startActivity(intent)
//                overridePendingTransition(0, 0)
            }
        })

        binding.cbDeleteAfter30Days.isChecked = preferences.deleteAfter30Days
        binding.cbDeleteAfter30Days.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.deleteAfter30Days = isChecked
            }
        })
        binding.llClearRecycleBin.setOnClickListener {
            val clearDialog = ConfirmationDialog(
                this,
                getString(R.string.clear_recycle_bin),
                getString(R.string.are_you_sure_you_want_to_clear_recycle_bin),
                getString(R.string.clear),
                positiveBtnClickListener = {
                    AppDatabase.getInstance(this@SettingActivity).dataDao().removeAllRecentDelete()
                })
            clearDialog.show(supportFragmentManager, clearDialog.tag)
        }
//        binding.cbCall.isChecked = adsPref.isShowCallInfo
//        binding.hintCall.beVisibleIf(!adsPref.isShowCallInfo)
//        binding.icCall.beVisibleIf(!adsPref.isShowCallInfo)
//
//        binding.cbCall.setOnCheckedChangeListener(object :
//            SwitchButton.OnCheckedChangeListener {
//            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
//                if (isChecked) {
//                    checkCaller()
//                } else {
//                    adsPref.isShowCallInfo = isChecked
//                }
//            }
//        })

        binding.cbRememberLast.isChecked = preferences.rememberLastVideoPosition
        binding.cbRememberLast.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.rememberLastVideoPosition = isChecked
            }
        })

        binding.cbAutoPlay.isChecked = preferences.autoplayVideos
        binding.cbAutoPlay.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.autoplayVideos = isChecked
            }
        })
        binding.cbLoopVideos.isChecked = preferences.loopVideos
        binding.cbLoopVideos.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.loopVideos = isChecked
            }
        })
        binding.cbVerticalGestures.isChecked = preferences.allowVideoGestures
        binding.cbVerticalGestures.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.allowVideoGestures = isChecked
            }
        })

        binding.cbDeleteEmptyFolder.isChecked = preferences.deleteEmptyFolders
        binding.cbDeleteEmptyFolder.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.deleteEmptyFolders = isChecked
            }
        })
        binding.cbAllowDownGesture.isChecked = preferences.allowDownGesture
        binding.cbAllowDownGesture.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.allowDownGesture = isChecked
            }
        })
        binding.cbAllowRotatingGestures.isChecked = preferences.allowRotatingWithGestures
        binding.cbAllowRotatingGestures.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.allowRotatingWithGestures = isChecked
            }
        })
        binding.cbAllowDoubleTaps.isChecked = preferences.allowOneToOneZoom
        binding.cbAllowDoubleTaps.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.allowOneToOneZoom = isChecked
            }
        })
        binding.cbAllowInstantChange.isChecked = preferences.allowInstantChange
        binding.cbAllowInstantChange.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.allowInstantChange = isChecked
            }
        })
        binding.cbAllowDeepZooming.isChecked = preferences.allowZoomingImages
        binding.cbAllowDeepZooming.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.allowZoomingImages = isChecked
            }
        })
        binding.cbAllowBrightnessGesture.isChecked = preferences.allowPhotoGestures
        binding.cbAllowBrightnessGesture.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.allowPhotoGestures = isChecked
            }
        })


        binding.cbHighestQuality.isChecked = preferences.showHighestQuality
        binding.cbHighestQuality.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.showHighestQuality = isChecked
            }
        })
        binding.cbBlackBackground.isChecked = preferences.blackBackground
        binding.cbBlackBackground.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.blackBackground = isChecked
            }
        })
        binding.cbShowNotch.isChecked = preferences.showNotch
        binding.cbShowNotch.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.showNotch = isChecked
            }
        })
        binding.cbKeepLastModified.isChecked = preferences.keepLastModified
        binding.cbKeepLastModified.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.keepLastModified = isChecked
            }
        })

        binding.llEditedBehavior.setOnClickListener {
            val items = arrayListOf(
                RadioItem(
                    SAVE_AS_COPY,
                    getString(R.string.save_copy)
                ),
                RadioItem(
                    SAVE_AND_REPLACE,
                    getString(R.string.replace_file)
                ),
                RadioItem(ALWAYS_ASK, getString(R.string.always_ask))
            )

            val radioGroupDialog = RadioConfirmationDialog(items, preferences.saveEditAction) {
                preferences.saveEditAction=it
                if(it==ALWAYS_ASK) {
                    preferences.isConfirmEditAction=false
                }
                else {
                    preferences.isConfirmEditAction=true
                }
            }
            radioGroupDialog.show(supportFragmentManager, radioGroupDialog.tag)
        }


        binding.cbMaxBrightness.isChecked = preferences.maxBrightness
        binding.cbMaxBrightness.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.maxBrightness = isChecked
            }
        })
        binding.cbHideSystemUi.isChecked = preferences.hideSystemUI
        binding.cbHideSystemUi.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.hideSystemUI = isChecked
            }
        })
        val isSupportFingerprint = isBiometricIdAvailable()
        Log.e("BiometricManager", "\nisSupportFingerprint:$isSupportFingerprint")

        isFingerprintAvailable =
            isSupportWithErrorInfo(this, BiometricManager.Authenticators.BIOMETRIC_STRONG)

        binding.llFingerprint.beVisibleIf(isSupportFingerprint)
        binding.cbFingerprint.isChecked =
            preferences.enableFingerprint && isFingerprintAvailable.first

        binding.cbFingerprint.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                if (isChecked) {
                    if (isFingerprintAvailable.first) {
                        preferences.enableFingerprint = true
                    } else {
                        val biometricErrorDialog =
                            BiometricErrorDialog(this@SettingActivity) { isEnable ->
                                if (isEnable) {
                                    val enrollIntent = Intent(Settings.ACTION_BIOMETRIC_ENROLL)
                                    enrollIntent.putExtra(
                                        Settings.EXTRA_BIOMETRIC_AUTHENTICATORS_ALLOWED,
                                        BiometricManager.Authenticators.BIOMETRIC_STRONG
                                    )
                                    AdsConfig.isSystemDialogOpen = true
                                    biomatricLauncher.launch(enrollIntent)
                                } else {
                                    binding.cbFingerprint.isChecked = false
                                }

                            }
                        preferences.enableFingerprint = false
                        biometricErrorDialog.show(supportFragmentManager, biometricErrorDialog.tag)

                    }
                } else {
                    preferences.enableFingerprint = false
                }

            }
        })


//        binding.cbVaultVisibility.isChecked = preferences.hideVault
//        binding.cbVaultVisibility.setOnCheckedChangeListener(object :
//            SwitchButton.OnCheckedChangeListener {
//            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
//                preferences.hideVault = isChecked
//                if (isChecked) {
//                    val hintDialog = HintDialog(
//                        getString(R.string.hide_hidden_album),
//                        R.drawable.ic_hint_vault,
//                        updateListener = {
//                            //preferences.hideVault=true
//                        })
//                    hintDialog.show(supportFragmentManager, hintDialog.tag)
//                }
//            }
//        })

//        binding.llCameraVisibility.setOnClickListener {
//            val hintDialog = HintDialog(
//                getString(R.string.hide_camera),
//                R.drawable.ic_hint_camera,
//                updateListener = {
//                    //preferences.hideCamera=true
//                })
//            hintDialog.show(supportFragmentManager, hintDialog.tag)
//        }
//        binding.cbCameraVisibility.isChecked = preferences.hideCamera
//        binding.cbCameraVisibility.setOnCheckedChangeListener(object :
//            SwitchButton.OnCheckedChangeListener {
//            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
//                preferences.hideCamera = isChecked
//                if (isChecked) {
//                    val hintDialog = HintDialog(
//                        getString(R.string.hide_camera),
//                        R.drawable.ic_hint_camera,
//                        updateListener = {
//                            //preferences.hideCamera=true
//                        })
//                    hintDialog.show(supportFragmentManager, hintDialog.tag)
//                }
//            }
//        })

        binding.tvRotateFullscreen.text = getScreenRotationText()
        binding.llRotateFullscreen.setOnClickListener {

            val items = arrayListOf(
                RadioItem(
                    ROTATE_BY_SYSTEM_SETTING,
                    getString(R.string.screen_rotation_system_setting)
                ),
                RadioItem(
                    ROTATE_BY_DEVICE_ROTATION,
                    getString(R.string.screen_rotation_device_rotation)
                ),
                RadioItem(ROTATE_BY_ASPECT_RATIO, getString(R.string.screen_rotation_aspect_ratio))
            )

            val radioGroupDialog = RadioGroupDialog(items, preferences.screenRotation) {
                preferences.screenRotation = it
                binding.tvRotateFullscreen.text = getScreenRotationText()
            }
            radioGroupDialog.show(supportFragmentManager, radioGroupDialog.tag)
        }

        binding.llLanguage.setOnClickListener {
            languageLauncher.launch(Intent(this, LanguageActivity::class.java))
//                .putExtra(Constant.EXTRA_IS_OPEN_FROM_SPLASH, false)
        }

        binding.llDateTime.setOnClickListener {
            val dateTimeDialog = DateTimeDialog(this, updateListener = {

            })
            dateTimeDialog.show(supportFragmentManager, dateTimeDialog.tag)

        }

//        binding.tvClearCache.text = application.cacheDir.totalSize().formatSize()
        binding.tvClearCache.text = ClearCacheUtils.getAppCacheSize(this)
        binding.llClearCache.setOnClickListener {
            ClearCacheUtils.clearCache(this)
            binding.tvClearCache.text = ClearCacheUtils.getAppCacheSize(this)
//            System.runFinalization()
//            Runtime.getRuntime().gc()
//            System.gc()
        }

//        binding.llIncludedFolder.setOnClickListener {
//            dirsActivityResultLauncher.launch(
//                Intent(this, DirsActivity::class.java)
//                    .putExtra("dirType", Constant.TYPE_INCLUDED)
//            )
//        }


        binding.llRateUs.setOnClickListener {
            val rateDialog = RatingDialog(this)
            rateDialog.show(supportFragmentManager, rateDialog.tag)
        }

        binding.llExcludedFolder.setOnClickListener {
            dirsActivityResultLauncher.launch(
                Intent(this, DirsActivity::class.java)
                    .putExtra("dirType", Constant.TYPE_EXCLUDED)
            )
        }

        binding.llChangePassword.setOnClickListener {
            val intent = Intent(this, LockActivity::class.java)
            intent.putExtra(Constant.EXTRA_CHANGE_PASS, true)
            startActivity(intent)
        }

        binding.llFeedbackSuggestions.setOnClickListener {

            val intent = Intent(this, FeedbackActivity::class.java)
            startActivity(intent)
        }

        binding.llPrivacyPolicy.setOnClickListener {
            openPrivacyPolicy()
        }
        binding.llShareApp.setOnClickListener {

            try {
                val sendIntent = Intent()
                sendIntent.action = Intent.ACTION_SEND
                sendIntent.putExtra(
                    Intent.EXTRA_TEXT,
                    "Check out the App at: https://play.google.com/store/apps/details?id=$packageName"
                )
                sendIntent.type = "text/plain"
                AdsConfig.isSystemDialogOpen = true
                startActivity(sendIntent)
            } catch (e: Exception) {

            }
        }

        binding.llUnlockMethod.setOnClickListener {
            val viewTypeDialog = ChangLockStyleDialog(this@SettingActivity, updateListener = {
                val intent = Intent(this@SettingActivity, LockActivity::class.java)
                intent.putExtra(Constant.EXTRA_CHANGE_LOCK_STYLE, true)
                intent.putExtra(Constant.EXTRA_LOCK_STYLE, it)
                startActivity(intent)
//                changeLockStyleActivityResultLauncher.launch(intent)
            })
            viewTypeDialog.show(supportFragmentManager, viewTypeDialog.tag)

        }
    }


    var languageLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                setResult(RESULT_OK)
                recreate()
                Constant.isChangeLanguage = true
            }
        }
    var biomatricLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
//            if (result.resultCode == Activity.RESULT_OK) {
//            val isFingerprintAvailable = isBiometricIdAvailable()
            isFingerprintAvailable =
                isSupportWithErrorInfo(this, BiometricManager.Authenticators.BIOMETRIC_STRONG)
            if (isFingerprintAvailable.first) {
                preferences.enableFingerprint = true
                binding.cbFingerprint.isChecked = true
            } else {
                preferences.enableFingerprint = false
                binding.cbFingerprint.isChecked = false
            }
//            }
        }

    fun openPrivacyPolicy() {
        val url = getPrivacyPolicy()
        if (url != null && url.isNotEmpty()) {
            try {
                val builder: CustomTabsIntent.Builder = CustomTabsIntent.Builder()
                builder.setToolbarColor(ContextCompat.getColor(this, R.color.color_primary))
                AdsConfig.isSystemDialogOpen = true
                val customTabsIntent: CustomTabsIntent = builder.build()
                customTabsIntent.intent.setPackage("com.android.chrome")
                customTabsIntent.launchUrl(this, Uri.parse(url))

            } catch (e: Exception) {
                val i = Intent(Intent.ACTION_VIEW)
                i.data = Uri.parse(url)
                AdsConfig.isSystemDialogOpen = true
                startActivity(i)
            }
        }
    }

    override fun onBackPressed() {
        if (preferences.isNeedInterAd) {

            AdsConfig.showInterstitialAd(this@SettingActivity) {
                if(it) preferences.isNeedInterAd = false
                finish()
            }
        } else {
            super.onBackPressed()
        }
    }

    private fun getScreenRotationText() = getString(
        when (preferences.screenRotation) {
            ROTATE_BY_SYSTEM_SETTING -> R.string.screen_rotation_system_setting
            ROTATE_BY_DEVICE_ROTATION -> R.string.screen_rotation_device_rotation
            else -> R.string.screen_rotation_aspect_ratio
        }
    )

    var dirsActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {

//            photosFragment.getData()
//            albumFragment.getData()
        }
    }
}