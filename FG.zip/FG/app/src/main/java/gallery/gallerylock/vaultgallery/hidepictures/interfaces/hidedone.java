package gallery.gallerylock.vaultgallery.hidepictures.interfaces;

public interface hidedone {
        void hideComplete();
    }