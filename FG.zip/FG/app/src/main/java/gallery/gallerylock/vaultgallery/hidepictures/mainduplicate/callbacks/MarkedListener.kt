package gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.callbacks

import java.io.Serializable

interface MarkedListener : Serializable {
    fun cleaned(numberOfPhotosCleaned: Int)
    fun updateDuplicateFound(duplicateFound: Int)
    fun updateMarked()
    fun updatePageDetails(str1: String?, str2: String?, int1: Int, obj: Any?)
}