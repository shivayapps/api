package gallery.gallerylock.vaultgallery.hidepictures.edit

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.Toast
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.base.BaseActivity
import gallery.gallerylock.vaultgallery.hidepictures.databinding.ActivityStickerBinding
import gallery.gallerylock.vaultgallery.hidepictures.dialog.EditTextDialog
import gallery.gallerylock.vaultgallery.hidepictures.dialog.ProgressDialog
import gallery.gallerylock.vaultgallery.hidepictures.edit.adapter.ColorAdapter
import gallery.gallerylock.vaultgallery.hidepictures.edit.stickerPackage.TextSticker
import gallery.gallerylock.vaultgallery.hidepictures.extension.updateStatusBarColor
import gallery.gallerylock.vaultgallery.hidepictures.utils.AdCache
import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant
import gallery.gallerylock.vaultgallery.hidepictures.utils.Preferences


class StickerActivity : BaseActivity() {

    lateinit var binding: ActivityStickerBinding
//    var stickerTabList: ArrayList<StickerData> = ArrayList()
//    lateinit var tabAdapter: StickerTabAdapter
    var imagePath = ""
    var saveImageName = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStickerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateStatusBarColor(Color.parseColor("#131624"))

        intView()
        loadBanner()
    }

    var isAdLoaded=false
    var mAdView: AdView?=null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }
    private fun loadBanner() {
//        val isFirstSession= Preferences(this).splashCounter==1
//        val adId=if(isFirstSession) getString(R.string.b_editActivity) else getString(R.string.b_editActivity2)
//        BannerAdHelper.showBanner(this, binding.layoutBanner.mFLAd,binding.llAdPlace,adId,
//            AdCache.editAdView,{ isLoaded, adView, message ->
//                mAdView=adView
//                AdCache.editAdView=adView
//            isAdLoaded=isLoaded
//        })
    }
    private fun intView() {

        binding.txtTitle.text = getString(R.string.Sticker)

        imagePath = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_PATH) ?: ""
        saveImageName = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_NAME) ?: ""

//        Glide.with(this)
//            .load(imagePath)
//            .diskCacheStrategy(DiskCacheStrategy.NONE)
//            .skipMemoryCache(true)
//            .into(binding.mainImg)

        val bitmap = getBitmapFromFilePath(imagePath)
        binding.mainImg.setImageBitmap(bitmap)
        binding.stickerView.setMainImage(binding.mainImg)
        binding.stickerView.setMainBitmap(bitmap)

        binding.btnAdd.setOnClickListener {
            val progressDialog = EditTextDialog(
                this@StickerActivity,
                "",{stringText ->
                    addNewSticker(stringText)
                }
            )
            progressDialog.show(supportFragmentManager, progressDialog.tag)
        }

        setColorAdapter()
        intListener()

    }

    private fun setColorAdapter() {
        val colorAdapter = ColorAdapter(this, clickListener = {
            onColorChanged(it)
        })
        binding.recyclerView.adapter = colorAdapter
        onColorChanged(colorAdapter.colorList[0])
    }

    fun onColorChanged(colorCode: Int) {
        val sticker=binding.stickerView.currentSticker
        if(sticker is TextSticker) {
            sticker.setTextColor(colorCode)
            sticker.resizeText()
        }
//        mPhotoEditor.setShape(mShapeBuilder.withShapeColor(colorCode))
    }

    fun hideKeyboard(view: EditText) {
        view.clearFocus()
        val methodManager = (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.hideSoftInputFromWindow(view.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
    }

    private fun showKeyboard(view: EditText) {
        view.requestFocus()
        val methodManager = (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun intListener() {
        binding.icBack.setOnClickListener { onBackPressed() }
        binding.ivDone.setOnClickListener {
            val progressDialog = ProgressDialog(
                this@StickerActivity,
                0,
                0,
                getString(R.string.saving),
                ""
            )
            progressDialog.show(supportFragmentManager, progressDialog.tag)
            Thread {
                try {
                    val bitmap = binding.stickerView.createBitmap()
                    val imagePath = saveEditImage(bitmap, saveImageName)
                    runOnUiThread {
                        if (imagePath != null) {
                            val intent = Intent()
                            intent.putExtra(Constant.EXTRA_EDIT_SAVE_IMAGE, imagePath)
                            setResult(RESULT_OK, intent)
                        }
                        progressDialog.dismiss()
                        finish()
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        progressDialog.dismiss()
                        Toast.makeText(
                            this,
                            getString(R.string.image_editing_failed),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }.start()
        }
    }


    private fun addNewSticker(text:String) {
        val sticker = TextSticker(this)
        sticker.text=text
        sticker.resizeText()
        binding.stickerView.addSticker(sticker)
    }

}