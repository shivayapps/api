package gallery.gallerylock.vaultgallery.hidepictures.event

import kotlin.collections.ArrayList

data class UpdateFavoriteEvent(var path: String = "", var isFavorite: Boolean = false, var unFavoriteList: ArrayList<String> = ArrayList())
