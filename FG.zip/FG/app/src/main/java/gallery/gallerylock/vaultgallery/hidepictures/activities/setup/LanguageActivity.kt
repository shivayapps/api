package gallery.gallerylock.vaultgallery.hidepictures.activities.setup

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.NativeAdHelper
import com.adconfig.adsutil.admob.NativeLayoutType
import com.adconfig.adsutil.utils.isAnyAdShowing
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.activities.HomeActivity
import gallery.gallerylock.vaultgallery.hidepictures.adapter.LanguageAdapter
import gallery.gallerylock.vaultgallery.hidepictures.base.BaseActivity
import gallery.gallerylock.vaultgallery.hidepictures.databinding.ActivityLanguageBinding
import gallery.gallerylock.vaultgallery.hidepictures.extension.beGone
import gallery.gallerylock.vaultgallery.hidepictures.extension.beVisible
import gallery.gallerylock.vaultgallery.hidepictures.model.LanguageData
import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant
import gallery.gallerylock.vaultgallery.hidepictures.utils.LogEvent
import gallery.gallerylock.vaultgallery.hidepictures.utils.MyBounceInterpolator
import gallery.gallerylock.vaultgallery.hidepictures.utils.Preferences
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class LanguageActivity : BaseActivity() {

    lateinit var binding: ActivityLanguageBinding
    var selectPos = 0
    lateinit var adapter: LanguageAdapter
    var isOpenFromSplash: Boolean = false
    lateinit var preferences: Preferences
    var languageList: ArrayList<LanguageData> = ArrayList()
    override fun onResume() {
        Handler(Looper.getMainLooper()).postDelayed({
            isShowingOpenAd(isAnyAdShowing)
        }, 1500)
        super.onResume()
    }

    fun isShowingOpenAd(showingAd: Boolean) {
        Log.e("LanguageActivity", "isShowingOpenAd:$showingAd")
        if (showingAd) {
            binding.frameNative.beGone()
        } else {
            binding.frameNative.beVisible()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        if(preferences.isNeedInterAd) {
            AdmobIntersAdImpl().load(this)
        }
        binding = ActivityLanguageBinding.inflate(layoutInflater)
        setContentView(binding.root)
        inti()
        loadAd()
    }

    private fun loadAd() {
        NativeAdHelper(
            this,
            binding.frameNative,
            binding.llBottom,
            NativeLayoutType.NativeBig,
            getString(R.string.native_language)
        ).loadAd();
    }

    private fun inti() {
        preferences.isSetLanguage=true
        binding.loutToolbar.txtTitle.text = getString(R.string.language)
        binding.loutToolbar.ivDone.visibility = View.VISIBLE

        if (intent != null)
            isOpenFromSplash = intent.getBooleanExtra(Constant.EXTRA_IS_OPEN_FROM_SPLASH, false)


        val calendar = Calendar.getInstance()
        val format = SimpleDateFormat("dd/mm/yy", Locale.ENGLISH)
        val today = format.format(calendar.timeInMillis)
        LogEvent.logEvent("LanguageActivity","FromSplash:$today")

        getLanList()
        intiListener()

        binding.loutToolbar.icBack.visibility =
            if (isOpenFromSplash) View.INVISIBLE else View.VISIBLE

        selectPos = preferences.getSelectLanguage()
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = LanguageAdapter(this,
            languageList,
            clickListener = {
                selectPos = it
            })
        adapter.selectPos = selectPos
        binding.recyclerView.adapter = adapter
        binding.recyclerView.scrollToPosition(selectPos)


        val myAnim = AnimationUtils.loadAnimation(this, R.anim.bounce);
        val interpolator = MyBounceInterpolator(0.2, 20.0)
        myAnim.setInterpolator(interpolator)
        myAnim.repeatMode= Animation.RESTART
        binding.loutToolbar.ivDone.startAnimation(myAnim)


    }

    private fun updateViews(languageCode: String) {
        gallery.gallerylock.vaultgallery.hidepictures.utils.LocaleHelper.setLocale(
            this,
            languageCode
        )
    }

    private fun intiListener() {
        binding.loutToolbar.icBack.setOnClickListener {
            finish()
        }

        binding.loutToolbar.ivDone.setOnClickListener {
            preferences.setSelectLanguage(selectPos)
            updateViews(languageList[selectPos].languageCode)
            if (isOpenFromSplash) {
                val intent = if (!checkStoragePermission())
                    Intent(this, PermissionActivity::class.java)
                else
                    Intent(this, HomeActivity::class.java)

                if (preferences.isNeedInterAd) {
                    AdsConfig.showInterstitialAd(this@LanguageActivity) {
                        if(it) preferences.isNeedInterAd = false
                        startActivity(intent)
                        finish()
                    }
                } else {
                    startActivity(intent)
                    finish()
                }

            } else {
                setResult(RESULT_OK)
                finish()
            }

        }
    }

    private fun getLanList() {

        //strings
        languageList.add(LanguageData(getString(R.string.english), "en", ContextCompat.getDrawable(this, R.drawable.lang_english)))
        languageList.add(LanguageData(getString(R.string.arabic), "ar", ContextCompat.getDrawable(this, R.drawable.lang_arabic)))
        languageList.add(LanguageData(getString(R.string.french), "fr", ContextCompat.getDrawable(this, R.drawable.lang_francais)))
        languageList.add(LanguageData(getString(R.string.spanish), "es", ContextCompat.getDrawable(this, R.drawable.lang_spanish)))
        languageList.add(LanguageData(getString(R.string.russian), "ru", ContextCompat.getDrawable(this, R.drawable.lang_russia)))
        languageList.add(LanguageData(getString(R.string.japanese), "ja", ContextCompat.getDrawable(this, R.drawable.lang_japanese)))
        languageList.add(LanguageData(getString(R.string.italian), "it", ContextCompat.getDrawable(this, R.drawable.lang_italiano)))
        languageList.add(LanguageData(getString(R.string.portuguese_br), "pt-rBR", ContextCompat.getDrawable(this, R.drawable.lang_portuguese_br)))
        languageList.add(LanguageData(getString(R.string.portuguese_pt), "pt-rPT", ContextCompat.getDrawable(this, R.drawable.lang_portuguese_pt)))
        languageList.add(LanguageData(getString(R.string.marathi), "mr", ContextCompat.getDrawable(this, R.drawable.lang_marathi)))
        languageList.add(LanguageData(getString(R.string.bangali), "bn", ContextCompat.getDrawable(this, R.drawable.lang_bangla)))
        languageList.add(LanguageData(getString(R.string.china), "zh", ContextCompat.getDrawable(this, R.drawable.lang_china)))
        languageList.add(LanguageData(getString(R.string.deutsch), "nl", ContextCompat.getDrawable(this, R.drawable.lang_deutsch)))
        languageList.add(LanguageData(getString(R.string.hindi), "hi", ContextCompat.getDrawable(this, R.drawable.lang_hindi)))
        languageList.add(LanguageData(getString(R.string.indonesian), "in", ContextCompat.getDrawable(this, R.drawable.lang_indonesian)))
        languageList.add(LanguageData(getString(R.string.korean), "ko", ContextCompat.getDrawable(this, R.drawable.lang_korean)))
        languageList.add(LanguageData(getString(R.string.melayu), "ms", ContextCompat.getDrawable(this, R.drawable.lang_melayu)))
        languageList.add(LanguageData(getString(R.string.philippians), "phi", ContextCompat.getDrawable(this, R.drawable.lang_philippians)))
        languageList.add(LanguageData(getString(R.string.tamil), "ta", ContextCompat.getDrawable(this, R.drawable.lang_tamil)))
        languageList.add(LanguageData(getString(R.string.telugu), "te", ContextCompat.getDrawable(this, R.drawable.lang_telugu)))
        languageList.add(LanguageData(getString(R.string.thai), "th", ContextCompat.getDrawable(this, R.drawable.lang_thai)))
        languageList.add(LanguageData(getString(R.string.turkish), "tr", ContextCompat.getDrawable(this, R.drawable.lang_turkish)))
        languageList.add(LanguageData(getString(R.string.vietnamese), "vi", ContextCompat.getDrawable(this, R.drawable.lang_vietnamese)))

    }

}