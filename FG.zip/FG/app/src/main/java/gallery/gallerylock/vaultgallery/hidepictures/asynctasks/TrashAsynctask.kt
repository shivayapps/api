package gallery.gallerylock.vaultgallery.hidepictures.asynctasks

import android.content.Context
import android.os.AsyncTask
import gallery.gallerylock.vaultgallery.hidepictures.helper.MediaFetcher
import gallery.gallerylock.vaultgallery.hidepictures.model.PictureData
import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant
import gallery.gallerylock.vaultgallery.hidepictures.utils.Preferences
import gallery.gallerylock.vaultgallery.hidepictures.utils.SHOW_ALL


class TrashAsynctask(
    val context: Context,
    val callback: (isComplete: Boolean) -> Unit
) :
    AsyncTask<Void, Void, Boolean>() {

    val config = Preferences(context)

    override fun doInBackground(vararg params: Void): Boolean {


        return true
    }

    override fun onPostExecute(isComplete: Boolean) {
        super.onPostExecute(isComplete)
        callback(isComplete)
    }

    fun stopFetching() {
        cancel(true)
    }
}
