package gallery.gallerylock.vaultgallery.hidepictures.model

data class RestoreData(var path: String, var deletedPath: String)