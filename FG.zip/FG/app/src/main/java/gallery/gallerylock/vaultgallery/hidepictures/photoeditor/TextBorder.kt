package gallery.gallerylock.vaultgallery.hidepictures.photoeditor

class TextBorder(
    var corner: Float,
    var backGroundColor: Int,
    var strokeWidth: Int,
    var strokeColor: Int
)