package gallery.gallerylock.vaultgallery.hidepictures.utils

import android.os.Bundle
import gallery.gallerylock.vaultgallery.hidepictures.GalleryApp

object LogEvent {

    fun logEvent(key:String,value: String) {
        val mBundle = Bundle().apply {
            putString("key", value)
        }
        GalleryApp.mFirebaseAnalytics.logEvent(key, mBundle)
    }

    fun logEvent(key: String,mBundle:Bundle) {
//        val mBundle = Bundle().apply {
//            putString("key", value)
//        }
        GalleryApp.mFirebaseAnalytics.logEvent(key, mBundle)
    }

    fun logEvent(mBundle:Bundle) {
//        val mBundle = Bundle().apply {
//            putString("key", value)
//        }
        GalleryApp.mFirebaseAnalytics.logEvent("gallery_custom_events", mBundle)
    }


}