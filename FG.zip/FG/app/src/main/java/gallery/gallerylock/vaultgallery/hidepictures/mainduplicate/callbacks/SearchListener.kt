package gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.callbacks

interface SearchListener {
    fun checkScanFinish()
    fun updateUi(vararg count: String?)
}