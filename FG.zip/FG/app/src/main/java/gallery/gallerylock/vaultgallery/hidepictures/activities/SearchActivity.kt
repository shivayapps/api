package gallery.gallerylock.vaultgallery.hidepictures.activities

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import androidx.core.widget.addTextChangedListener
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.bumptech.glide.Glide
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.activities.exploremap.MapExploreActivity
import gallery.gallerylock.vaultgallery.hidepictures.adapter.PictureAdapter
import gallery.gallerylock.vaultgallery.hidepictures.adapter.TimeLineAdapter
import gallery.gallerylock.vaultgallery.hidepictures.base.BaseActivity
import gallery.gallerylock.vaultgallery.hidepictures.customview.MyGridLayoutManager
import gallery.gallerylock.vaultgallery.hidepictures.database.AppDatabase
import gallery.gallerylock.vaultgallery.hidepictures.database.LocationEntity
import gallery.gallerylock.vaultgallery.hidepictures.databinding.ActivitySearchBinding
import gallery.gallerylock.vaultgallery.hidepictures.dialog.CalendarDialog
import gallery.gallerylock.vaultgallery.hidepictures.extension.beGone
import gallery.gallerylock.vaultgallery.hidepictures.extension.beGoneIf
import gallery.gallerylock.vaultgallery.hidepictures.extension.beVisible
import gallery.gallerylock.vaultgallery.hidepictures.extension.getParentFolder
import gallery.gallerylock.vaultgallery.hidepictures.model.AlbumData
import gallery.gallerylock.vaultgallery.hidepictures.model.PictureData
import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant
import gallery.gallerylock.vaultgallery.hidepictures.utils.Preferences
import gallery.gallerylock.vaultgallery.hidepictures.utils.TYPE_GIFS
import gallery.gallerylock.vaultgallery.hidepictures.utils.TYPE_IMAGES
//import gallery.gallerylock.vaultgallery.hidepictures.utils.TYPE_PORTRAITS
//import gallery.gallerylock.vaultgallery.hidepictures.utils.TYPE_RAWS
//import gallery.gallerylock.vaultgallery.hidepictures.utils.TYPE_SVGS
import gallery.gallerylock.vaultgallery.hidepictures.utils.TYPE_VIDEOS
import gallery.gallerylock.vaultgallery.hidepictures.utils.photoExtensions
import gallery.gallerylock.vaultgallery.hidepictures.utils.rawExtensions
import gallery.gallerylock.vaultgallery.hidepictures.utils.videoExtensions
import gallery.gallerylock.vaultgallery.hidepictures.viewpager.PhotoVideoActivity
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale


class SearchActivity : BaseActivity() {

    var allList = ArrayList<Any>()
    var allBackList = ArrayList<PictureData>()
    lateinit var dataBase: AppDatabase

    var timeList: ArrayList<AlbumData> = ArrayList()
    var albumWisePictures = LinkedHashMap<String, ArrayList<PictureData>>()

    var timeLineAdapter: TimeLineAdapter? = null
    var searchAdapter: PictureAdapter? = null

    var placeList: ArrayList<AlbumData> = ArrayList()

    lateinit var preferences: Preferences
    var isSearch: Boolean = false
    var isStopSearch: Boolean = false
    var startDate = 0L
    var endDate = 0L

    lateinit var binding: ActivitySearchBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        if(preferences.isNeedInterAd) {
            AdmobIntersAdImpl().load(this)
        }
        binding = ActivitySearchBinding.inflate(layoutInflater)
        setContentView(binding.root)
        dataBase = AppDatabase.getInstance(this)
        initView()
    }

    private fun initView() {
        binding.icBack.setOnClickListener {
            onBackPressed()
        }
//        binding.tvFav.setOnClickListener {
//            startActivity(Intent(this, FavouriteListActivity::class.java))
//        }
//        binding.tvRecent.setOnClickListener {
//            startActivity(Intent(this, MediaActivity::class.java))
//        }
//        binding.tvDownload.setOnClickListener {
//            startActivity(Intent(this, MediaActivity::class.java))
//        }
//        binding.tvVideos.setOnClickListener {
//            startActivity(Intent(this, MediaActivity::class.java))
//        }

        binding.icSearchClear.setOnClickListener {
            binding.edtSearch.setText("")
            hideKeyboard(binding.edtSearch)
        }
        binding.edtSearch.addTextChangedListener {str->
            if (str.toString().isEmpty()) {
                setSearch(str.toString())
                binding.icSearchClear.visibility = View.GONE
            } else {
                setSearch(str.toString())
                binding.icSearchClear.visibility = View.VISIBLE
            }
        }
        binding.edtSearch.setOnEditorActionListener { v, actionId, event ->
            hideKeyboard(binding.edtSearch)
            true
        }

        binding.txtStartDate.setOnClickListener {

            val c = Calendar.getInstance()
            if (startDate > 0) c.timeInMillis = startDate

            val y = c.get(Calendar.YEAR)
            val m = c.get(Calendar.MONTH)
            val d = c.get(Calendar.DAY_OF_MONTH)

            val datePickerDialog = CalendarDialog(updateListener = { startDate, endDate ->

                val strStartDate = SimpleDateFormat(
                    "dd MMM yyyy",
                    Locale.ENGLISH
                ).format(startDate.timeInMillis)

                val strEndDate = SimpleDateFormat(
                    "dd MMM yyyy", Locale.ENGLISH
                ).format(endDate.timeInMillis)

                binding.txtStartDate.text = "$strStartDate - $strEndDate"

                setListTimeRange(startDate.timeInMillis, endDate.timeInMillis)

            })
            datePickerDialog.show(supportFragmentManager, datePickerDialog.tag)
        }

        binding.txtAllRange.setOnClickListener {
            openImageList()
        }
//        binding.txtAllSearch.setOnClickListener {
//            openImageList()
//        }
//        binding.txtAllTimeLine.setOnClickListener {
//            openAlbumList(getString(R.string.time),timeList)
//        }
//        binding.txtAllPlace.setOnClickListener {
//            openAlbumList(getString(R.string.places),placeList)
//        }



        initAdapters()

        setPlaceData()
        getData()

    }

    override fun onBackPressed() {
        if (preferences.isNeedInterAd) {

            AdsConfig.showInterstitialAd(this) {
                if(it) preferences.isNeedInterAd = false
                finish()
            }
        } else {
            super.onBackPressed()
        }
    }

    fun hideKeyboard(view: EditText) {
        view.clearFocus()
        val methodManager = (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.hideSoftInputFromWindow(view.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
    }

    private fun showKeyboard(view: EditText) {
        view.requestFocus()
        val methodManager = (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun openImageList(albumData: AlbumData) {
        Constant.albumData = AlbumData(
            albumData.title,
            albumData.pictureData,
            "",
            0,
            0,
            isCustomAlbum = true
        )
        val intent=Intent(this, ImageListActivity::class.java)
        if(albumData.lati>0 && albumData.long>0) {
            intent.putExtra("isFromMap",true)
            intent.putExtra("lati",albumData.lati)
            intent.putExtra("long",albumData.long)
        }
        startActivity(intent)
    }

    private fun openImageList() {

        val pictureData = allList.filter { it is PictureData }
        var title = binding.txtStartDate.text.toString()
        if (binding.edtSearch.text.toString().trim().isNotEmpty()) {
            title = binding.edtSearch.text.toString()
        }

        Constant.albumData = AlbumData(
            title,
            pictureData as ArrayList<PictureData>,
            "",
            0,
            0,
            isCustomAlbum = true
        )
        startActivity(Intent(this, ImageListActivity::class.java))
    }


    fun initAdapters() {

//        placeAdapter = TimeLineAdapter(this, placeList,
//            clickListener = {albumData->
//                openImageList(albumData)
//            })
//        binding.placesRecycler.layoutManager = GridLayoutManager(this, 1, GridLayoutManager.HORIZONTAL, false)
//        binding.placesRecycler.setHasFixedSize(false)
//        binding.placesRecycler.adapter = placeAdapter

//        timeLineAdapter = TimeLineAdapter(this, timeList, clickListener = { albumData ->
//            openImageList(albumData)
//        })
//        binding.timeLineRecycler.layoutManager =
//            GridLayoutManager(this, 1, GridLayoutManager.HORIZONTAL, false)
//        binding.timeLineRecycler.setHasFixedSize(false)
//        binding.timeLineRecycler.adapter = timeLineAdapter
//
//        //Init TimeRangeAdapter
//        timeRangeAdapter = PictureAdapter(
//            this, timeRangeList,
//            clickListener = {
//                if (timeRangeList[it] is PictureData) {
//                    val pictureData = timeRangeList[it] as PictureData
//                    if (pictureData.isCheckboxVisible) {
//                        pictureData.isSelected = !pictureData.isSelected
//                        timeRangeAdapter?.notifyItemChanged(it)
////                        setSelectedFile()
//                    } else {
//                        val dataList = ArrayList<PictureData>()
//                        var displayPos = 0
//                        for (i in timeRangeList.indices) {
//                            if (timeRangeList[i] is PictureData) {
//                                dataList.add(timeRangeList[i] as PictureData)
//                                if (it == i) {
//                                    displayPos = dataList.size - 1
//                                }
//                            }
//                        }
//                        Constant.displayImageList = ArrayList()
//                        Constant.displayImageList.addAll(dataList)
//
//                        val intent = Intent(this@SearchActivity, PhotoVideoActivity::class.java)
//                        intent.putExtra(Constant.EXTRA_DISPLAY_POS, displayPos)
//                        startActivity(intent)
////                        selectAlbum()
//                    }
//                }
//            },
//            longClickListener = {
//
//            },
//            headerSelectListener = {
//
//            }, true, 9
//        )

//        binding.timeRangeRecycler.layoutManager = GridLayoutManager(this, 3)
//        binding.timeRangeRecycler.setHasFixedSize(false)
//        binding.timeRangeRecycler.adapter = timeRangeAdapter


        //Init Time & Place Adapter
//        timePlaceList = ArrayList()
//        adpTimePlaceAdapter = MultiImageAdapter(this, timePlaceList,
//            clickListener = { key, albumData ->
//                openAlbumList(key, albumData)
//            }
//        )
//        binding.timePlacesRecycler.layoutManager =
//            GridLayoutManager(this, 1, GridLayoutManager.HORIZONTAL, false)
//        binding.timePlacesRecycler.setHasFixedSize(false)
//        binding.timePlacesRecycler.adapter = adpTimePlaceAdapter


        //Init Search Adapter
        allList = ArrayList()
        searchAdapter = PictureAdapter(
            this, allList,
            clickListener = {
                if (allList[it] is PictureData) {
                    val pictureData = allList[it] as PictureData
                    if (pictureData.isCheckboxVisible) {
                        pictureData.isSelected = !pictureData.isSelected
                        searchAdapter?.notifyItemChanged(it)
//                        setSelectedFile()
                    } else {
                        val dataList = ArrayList<PictureData>()
                        var displayPos = 0
                        for (i in allList.indices) {
                            if (allList[i] is PictureData) {
                                dataList.add(allList[i] as PictureData)
                                if (it == i) {
                                    displayPos = dataList.size - 1
                                }
                            }
                        }
                        Constant.displayImageList = ArrayList()
                        Constant.displayImageList.addAll(dataList)
                        Constant.selectedPosition= displayPos
//                        val intent = Intent(this@SearchActivity, ImageViewerActivity::class.java)
                        if(Constant.displayImageList.size>0) {
                            val intent = Intent(this@SearchActivity, PhotoVideoActivity::class.java)
                            intent.putExtra(Constant.EXTRA_DISPLAY_POS, displayPos)
                            startActivity(intent)
                        }
//                        selectAlbum()
                    }
                }
            },
            longClickListener = {

            },
            headerSelectListener = {

            },true,100
        )

//        val gridCount = preferences.getGridCount()
        val layoutManager = binding.searchRecycler.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = 3
        layoutManager.orientation = RecyclerView.VERTICAL
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                if (position >= 0 && position < allList.size) {
                    return if (searchAdapter!!.getItemViewType(position) === searchAdapter!!.ITEM_HEADER_TYPE) {
                        3
                    } else 1
                } else {
                    return 1
                }
            }
        }
        binding.searchRecycler.adapter = searchAdapter
    }

    fun setPlaceData() {
        val place = dataBase.dataDao().getLocationEntityList()
        if (place.isNotEmpty()) {
            sortPlace(place)
        }
        //else binding.llPlace.beGone()
    }

    private fun sortPlace(places: List<LocationEntity>) {
        Log.e("MapExploreActivity", "sortImage:::placeList.${placeList.size}")

        places.forEach { data ->
            val strKey = data.title

            var imagesData1: ArrayList<PictureData> = ArrayList()

            val file = File(data.path)
            val pictureData = PictureData(
                file.path,
                file.name,
                file.parentFile.name,
                file.lastModified(),
                file.lastModified(),
                file.length()
            )
            for (i in placeList.indices) {
//                if (placeList[i] is AlbumData) {
                if (placeList[i].title == strKey) {
                    placeList[i].pictureData.add(pictureData)
                }
//                }
            }

            if (placeList.filter { it.title == strKey }.isNullOrEmpty()) {
                imagesData1.add(pictureData)
//                val placeData = PlaceData(imagesData1, data.title, data.latitude, data.longitude)
                val placeData = AlbumData(
                    title = data.title,
                    pictureData = imagesData1,
                    lati = data.latitude,
                    long = data.longitude
                )
                placeList.add(placeData)
            }
        }

//        timePlaceList["Places"] = placeList
        setData()
//        runOnUiThread {
//            if (adpTimePlaceAdapter != null)
//                adpTimePlaceAdapter?.notifyDataSetChanged()
//        }
//        getImageOnMap()
    }

    @SuppressLint("CheckResult")
    fun setSearch(searchText: String) {
//        val strSearch = searchText.lowercase(Locale.getDefault())
        val strSearch = searchText.lowercase()
        if (isSearch) isStopSearch = true

        Observable.fromCallable<Boolean> {
            isSearch = true
            allList.clear()
            if (strSearch.isEmpty()) {
                allList.clear()
            } else {

                val list = allBackList.filter {
                    it.fileName.lowercase().contains(strSearch)
                            || it.folderName.lowercase().contains(strSearch)
                }

                if (!isStopSearch) {
                    if (list.isNotEmpty()) {
                        allList.addAll(list)
                    }
                }
            }
            //if (!isStopSearch) setList()

            true
        }.subscribeOn(Schedulers.io())
            .doOnError { throwable: Throwable? ->
                runOnUiThread {
                    isSearch = false
                    isStopSearch = false
//                    if (pictureAdapter != null)
//                        pictureAdapter?.notifyDataSetChanged()
                    setData()
                }
            }
            .subscribe { result: Boolean? ->
                runOnUiThread {
                    isStopSearch = false
                    isSearch = false
//                    if (pictureAdapter != null)
//                        pictureAdapter?.notifyDataSetChanged()
                    setData()
                }
            }
    }

    private fun setData() {
        Log.e("gettingListPhoto", "Data is show")
        isUpadteList = false
//        enableScroll()

        runOnUiThread {
            //if (searchAdapter != null)
            notifyAdapter()
            setEmptyData()
        }

    }


    private fun setEmptyData() {
        if (allList != null && allList.size != 0) {
            binding.searchRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
        } else {
            binding.searchRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
        }
    }


    private fun openAlbumList(key: String, albumData: ArrayList<AlbumData>) {
        Constant.albumList = albumData
//        setBackAlbumData()
//        intent.putExtra("title","TimeLine")
        val intent = Intent(this, ExploreAlbumActivity::class.java)
        intent.putExtra("title", "$key")
        intent.putExtra("showTimeline", true)
        startActivity(intent)
    }

    private fun setBackAlbumData() {
        Constant.albumList.clear()
        for (albumData in timeList) {
            if (albumData is AlbumData) {
                Constant.albumList.add(
                    AlbumData(
                        albumData.title,
                        albumData.pictureData,
                        albumData.folderPath,
                        albumData.date,
                        albumData.fileSize
                    )
                )
            }
        }
    }

    var isUpadteList = false
    fun setFilterData() {
        isUpadteList = true
//        disableScroll()
        GlobalScope.launch(Dispatchers.IO) {
//            setList()
//            runOnUiThread {
//                setData()
            getTimeLine()
//            }
        }
    }

    public fun getData() {

        isUpadteList = true
        Glide.get(this).clearMemory()
        Observable.fromCallable {
            Glide.get(this).clearDiskCache()
            allList.clear()

//            videoCount = 0
//            imageCount = 0
            getImages()
            getVideos()
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { throwable: Throwable? ->
//                runOnUiThread {
                setFilterData()
//                    getFindCount()
//                }
            }
            .subscribe { result: Boolean? ->
//                runOnUiThread {
                setFilterData()
//                    getFindCount()
//                }
            }
    }

    private fun getImages() {
        Log.e("gettingListPhoto", "getImages")
        val mCursor: Cursor?
        val folderList: MutableList<String> = ArrayList<String>()
//        folderList.addAll(preferencesManager.getExcludeFolderList())
        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())
        try {
            val BUCKET_DISPLAY_NAME: String
            BUCKET_DISPLAY_NAME = MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
            val projection = arrayOf(
                MediaStore.Images.Media.DATA,
                BUCKET_DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_MODIFIED,
                MediaStore.MediaColumns.DATE_TAKEN,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.SIZE,
            )
            val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            } else {
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            }

            val filterMedia = preferences.getFilterMedia()
            val selection = getSelectionQuery(filterMedia)
            val selectionArgs = getSelectionArgsQuery(filterMedia).toTypedArray()

            mCursor = contentResolver.query(
                uri,  // Uri
                projection,  // Projection
                selection,
                selectionArgs,
                MediaStore.MediaColumns.DATE_MODIFIED + " DESC"
            )
            if (mCursor != null) {
                mCursor.moveToFirst()
                val photoDataArrayList: ArrayList<PictureData> = ArrayList<PictureData>()
                mCursor.moveToFirst()
                while (!mCursor.isAfterLast) {
                    //2sec
                    val path =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))
                    val title =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME))
                    var bucketPath = ""
                    bucketPath = path.substring(0, path.lastIndexOf(title) - 1)

                    var bucketName =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(BUCKET_DISPLAY_NAME))
                    if (bucketName == null) bucketName = path.getParentFolder()

                    val fileSizeLength =
                        mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))


                    if (!folderList.contains(bucketPath) && !bucketName.isNullOrEmpty()) {
                        var d =
                            mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED))
                        d *= 1000
                        var dt =
                            mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))
                        dt *= 1000
                        if (dt == 0L)
                            dt = d

                        val pictureData =
                            PictureData(path, title, bucketName, d, dt, fileSizeLength, false)
                        pictureData.isFavorite = favList.contains(path)
//                        allList.add(pictureData)
                        allBackList.add(pictureData)

//                        imageCount++
                    }
                    mCursor.moveToNext()
                }
                mCursor.close()
            }
        } catch (e: Exception) {
            Log.e("printStackTrace","printStackTrace:$e")
        }
    }

    private fun getVideos() {
        Log.e("gettingListPhoto", "getVideos")
        var title: String
        var path: String
        val duration: Int
        val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Video.VideoColumns.DATA,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.VideoColumns.SIZE,
            MediaStore.Video.VideoColumns.DURATION,
            MediaStore.Video.VideoColumns.DATE_MODIFIED,
            MediaStore.Video.VideoColumns.DATE_TAKEN,
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
        )
        val folderList: MutableList<String> = ArrayList<String>()
//        folderList.addAll(preferencesManager.getExcludeFolderList())
        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())
        try {
            val filterMedia = preferences.getFilterMedia()
            val selection = getSelectionQuery(filterMedia)
            val selectionArgs = getSelectionArgsQuery(filterMedia).toTypedArray()

            val cursor = contentResolver.query(
                uri,
                projection,
                selection,
                selectionArgs,
                MediaStore.Video.VideoColumns.DATE_MODIFIED + " DESC"
            )
            if (cursor != null) {
                duration = cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DURATION)
                cursor.moveToFirst()
                while (!cursor.isAfterLast) {
                    path =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA))
                    title =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME))
                    var bucketName =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME))
                    if (bucketName == null) bucketName = path.getParentFolder()

                    var bucketPath = ""
                    bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
                    if (!folderList.contains(bucketPath)) {
                        var d =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DATE_MODIFIED))
                        d *= 1000
                        val fileSizeLength =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
                        var dt =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))
                        dt *= 1000
                        if (dt == 0L)
                            dt = d
                        val pictureData = PictureData(
                            path,
                            title,
                            bucketName,
                            d,
                            dt,
                            fileSizeLength,
                            true,
                            cursor.getLong(duration)
                        )
                        pictureData.isFavorite = favList.contains(path)
                        pictureData.isVideo = true
//                        allList.add(pictureData)
                        allBackList.add(pictureData)

//                        videoCount++
                    }
                    cursor.moveToNext()
                }
                cursor.close()
            }
        } catch (exp: java.lang.Exception) {
            exp.printStackTrace()
        }
    }

    private fun notifyAdapter() {

        if (searchAdapter != null) {
//            binding.txtCount.text = "${allList.size} ${getString(R.string.photos)}"
            searchAdapter?.notifyDataSetChanged()
        }

//        if (timeLineAdapter != null)
//            timeLineAdapter?.notifyDataSetChanged()
    }


    private fun getSelectionQuery(filterMedia: Int): String {
        val query = StringBuilder()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")

            rawExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }

//        if (filterMedia and TYPE_RAWS != 0) {
//            rawExtensions.forEach {
//                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//            }
//        }

//        if (filterMedia and TYPE_SVGS != 0) {
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//        }
//        if (filterMedia and TYPE_PORTRAITS != 0) {
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
        }


        if (filterMedia and TYPE_GIFS != 0) {
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }


        return query.toString().trim().removeSuffix("OR")
    }

    private fun getSelectionArgsQuery(filterMedia: Int): ArrayList<String> {
        val args = ArrayList<String>()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.jpg")
            args.add("%.jpeg")
            rawExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.svg")
        }

//        if (filterMedia and TYPE_RAWS != 0) {
//            rawExtensions.forEach {
//                args.add("%$it")
//            }
//        }
//
//        if (filterMedia and TYPE_SVGS != 0) {
//            args.add("%.svg")
//        }
//        if (filterMedia and TYPE_PORTRAITS != 0) {
//            args.add("%.jpg")
//            args.add("%.jpeg")
//        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                args.add("%$it")
            }
        }

        if (filterMedia and TYPE_GIFS != 0) {
            args.add("%.gif")
        }


        return args
    }

//    fun setList1() {
////        binding.swipeRefreshLayout.isRefreshing = true
//        //allList.clear()
//        runOnUiThread { notifyAdapter() }
//
//        if (isSearch) runOnUiThread { notifyAdapter() }
//
//        val dateWisePictures = LinkedHashMap<String, ArrayList<PictureData>>()
//        var format = SimpleDateFormat("MMM yyyy")
//
//
////        val currentGrouping = preferences.getGroupBy()
////        format = when (currentGrouping) {
////            Constant.GROUP_BY_LAST_MODIFIED_DAILY -> SimpleDateFormat("dd MMM yyyy")
////            Constant.GROUP_BY_DATE_TAKEN_DAILY -> SimpleDateFormat("dd MMM yyyy")
////            Constant.GROUP_BY_LAST_MODIFIED_MONTHLY -> SimpleDateFormat("MMMM yyyy")
////            Constant.GROUP_BY_DATE_TAKEN_MONTHLY -> SimpleDateFormat("MMMM yyyy")
////            else -> SimpleDateFormat("dd MMM yyyy")
////        }
//
//        if (allList.size != 0) {
//            for (pictureData in allList) {
////                val strKey = format.format(pictureData.date)
//                var strKey = format.format(pictureData.date)
//
//                var imagesData1: ArrayList<PictureData> = ArrayList()
//                if (dateWisePictures.containsKey(strKey)) {
//                    val list: ArrayList<PictureData>? = dateWisePictures[strKey]
//                    if (!list.isNullOrEmpty())
//                        imagesData1.addAll(list)
//                } else {
//                    imagesData1 = ArrayList()
//                }
//                imagesData1.add(pictureData)
//                dateWisePictures[strKey] = imagesData1
//            }
//
//            val keys: Set<String> = dateWisePictures.keys
//            val listKeys = ArrayList(keys)
//
//            for (i in listKeys.indices) {
//                val imagesData = dateWisePictures[listKeys[i]]
//                if (imagesData != null && imagesData.size != 0) {
//                    val bucketData = AlbumData(listKeys[i], imagesData)
//                    pictures.add(bucketData)
//                    pictures.addAll(imagesData)
//                }
//            }
//        }
//    }

    private fun getTimeLine() {

        val dateWisePictures = LinkedHashMap<String, ArrayList<PictureData>>()

        val weekFormat = SimpleDateFormat("EEE", Locale.ENGLISH)
        val monthFormat = SimpleDateFormat("MMM", Locale.ENGLISH)
        val yearFormat = SimpleDateFormat("yyyy", Locale.ENGLISH)
        val monthYearFormat = SimpleDateFormat("MMM yyyy", Locale.ENGLISH)

        val calendar = Calendar.getInstance()
        val thisMonth = monthYearFormat.format(calendar.timeInMillis)
        val thisYear = monthYearFormat.format(calendar.timeInMillis)

        Log.e("setList", "setList.thisMonth:$thisMonth")

        calendar.set(Calendar.MONTH, calendar.get(Calendar.MONTH) - 1)
//        val lastMonth = monthFormat.format(calendar.timeInMillis)
        val lastMonth = monthYearFormat.format(calendar.timeInMillis)

        calendar.set(Calendar.MONTH, calendar.get(Calendar.MONTH) + 1)
        calendar.set(Calendar.YEAR, calendar.get(Calendar.YEAR) - 1)
//        val lastYear = yearFormat.format(calendar.timeInMillis)
        val lastYear = monthYearFormat.format(calendar.timeInMillis)

        Log.e("setList", "setList.lastMonth:$lastMonth")
        Log.e("setList", "setList.thisYear:$thisYear")
        Log.e("setList", "setList.lastYear:$lastYear")

        dateWisePictures.put(thisMonth.format(monthFormat), ArrayList<PictureData>())
        dateWisePictures.put(lastMonth.format(monthFormat), ArrayList<PictureData>())
        dateWisePictures.put(thisYear.format(monthFormat), ArrayList<PictureData>())
        dateWisePictures.put(lastYear.format(monthFormat), ArrayList<PictureData>())

        if (allBackList.size != 0) {
            for (pictureData in allBackList) {

                if (pictureData is PictureData) {

                    var strKey = monthYearFormat.format(pictureData.date)

                    Log.e("setList", "setList.monthYearFormat:$strKey")
                    if (thisMonth.equals(strKey)) {
                        strKey = "This Month"
                    } else if (lastMonth.equals(strKey)) {
                        strKey = "Last Month"
                    } else if (thisYear.equals(strKey)) {
                        strKey = "This Year"
                    } else if (lastYear.equals(strKey)) {
                        strKey = "Last Year"
                    } else {
                        strKey = yearFormat.format(pictureData.date)
                    }

                    var imagesData1: ArrayList<PictureData> = ArrayList()
                    if (strKey.isNotEmpty() && dateWisePictures.containsKey(strKey)) {
                        val list: ArrayList<PictureData>? = dateWisePictures[strKey]
                        if (!list.isNullOrEmpty())
                            imagesData1.addAll(list)
                    } else {
                        imagesData1 = ArrayList()
                    }
                    imagesData1.add(pictureData)

                    if (strKey.isNotEmpty()) dateWisePictures[strKey] = imagesData1
                }
            }

            val keys: Set<String> = dateWisePictures.keys
            val listKeys = ArrayList(keys)

//            if (listKeys.size == 0) pictures.addAll(allList)
            if (listKeys.size == 0) {
//                allList.addAll(allList)
                timeList.clear()
            }
            for (i in listKeys.indices) {
                val imagesData = dateWisePictures[listKeys[i]]
                if (imagesData != null && imagesData.size != 0) {

                    val bucketData = AlbumData(listKeys[i], imagesData)

                    timeList.add(bucketData)
                }
            }
        }

        runOnUiThread {
            if (timeLineAdapter != null)
                timeLineAdapter?.notifyDataSetChanged()
        }

//        timePlaceList["Time"] = timeList
//        runOnUiThread {
//            if (adpTimePlaceAdapter != null)
//                adpTimePlaceAdapter?.notifyDataSetChanged()
//        }

    }


    private fun setListTimeRange(startDate: Long, endDate: Long) {
        Log.e("setList", "setListTimeRange.startDate:$startDate")
        Log.e("setList", "setListTimeRange.endDate:$endDate")
//        timeRangeList.clear()
        allList.clear()
        if (startDate > 0 && endDate > 0) {
//            timeRangeList.addAll(allBackList.filter { it.date in (startDate + 1)..<endDate })
            allList.addAll(allBackList.filter { it.date in (startDate + 1)..<endDate })
        } else if (startDate == 0L) {
//            timeRangeList.addAll(allBackList.filter { it.date > startDate })
            allList.addAll(allBackList.filter { it.date > startDate })
        } else if (endDate == 0L) {
//            timeRangeList.addAll(allBackList.filter { it.date < endDate })
            allList.addAll(allBackList.filter { it.date < endDate })
        } else {
//            timeRangeList.clear()
            allList.clear()
        }

        Log.e("setList", "ListTimeRange.size:${allList.size}")
//        binding.txtAllRange.beGoneIf(timeRangeList.size == 0)
        binding.txtAllRange.beGoneIf(allList.size == 0)
//        binding.llSearch.beGone()

        setData()
//        runOnUiThread {
//            if (searchAdapter != null)
//                searchAdapter?.notifyDataSetChanged()
////            if (timeRangeAdapter != null)
////                timeRangeAdapter?.notifyDataSetChanged()
//        }
    }

}