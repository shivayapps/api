package gallery.gallerylock.vaultgallery.hidepictures.interfaces

interface RecyclerScrollCallback {
    fun onScrolled(scrollY: Int)
}
