package gallery.gallerylock.vaultgallery.hidepictures

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.adconfig.adsutil.AdsParameters
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.openad.OpenAdHelper
import com.adconfig.adsutil.openad.OpenAdHelper.isShowOpenAd
//import com.adconfig.adsutil.openad.OpenAdHelper.showOpenAd
import gallery.gallerylock.vaultgallery.hidepictures.activities.HomeActivity
import gallery.gallerylock.vaultgallery.hidepictures.activities.setup.PermissionActivity
import gallery.gallerylock.vaultgallery.hidepictures.activities.setup.StartActivity
import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant
import gallery.gallerylock.vaultgallery.hidepictures.utils.Preferences


@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {

    var themeType = 0
    lateinit var preferences: Preferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation =
            if (Build.VERSION.SDK_INT < 9)
                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT

        themeType = Preferences(this).getThemeValue()

        setAppTheme()
        installSplashScreen()
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        initAdSize()
        intiView()
    }

    public fun setAppTheme() {
//        themeType = Preferences(this).getThemeValue()
        when (themeType) {
            Constant.THEME_LIGHT -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }

            Constant.THEME_DARK -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            }
        }
    }

    private lateinit var countDownTimer: CountDownTimer
    private fun intiView() {

        Log.e("SplashTag", "intiView")
        preferences = Preferences(this)

        preferences.isNeedInterAd = true

        Log.e("SplashTag", "isFirstTimeInstall:${preferences.isFirstTimeInstall}")
        if (preferences.isFirstTimeInstall) {
            gotoMainScreen()
        } else {
            var splashCounter = preferences.splashCounter
            splashCounter++
            preferences.splashCounter = splashCounter

            Log.e("SplashTag", "appOpenCounter:${splashCounter}")
            val AdmobAppOpenId = getString(R.string.open_splash)
            Log.e("SplashTag", "AdmobAppOpenId:${AdmobAppOpenId}")
            if (splashCounter % 7 == 0) {
                Log.e("SplashTag", "appOpenCounter%7-true")
                createTimerSec()
                OpenAdHelper.loadOpenAdId(this, { isLoaded ->
                    countDownTimer.cancel()
                    if (isLoaded) {
                        isShowOpenAd { isShow ->
                            if (isShow) preferences.isNeedInterAd = false
                            else {
                                splashCounter--
                                preferences.splashCounter = splashCounter
                            }
                            startActivity(nextScreen())
//                            overridePendingTransition(0, 0);
//                            finish()
                        }
                    } else {
                        splashCounter--
                        preferences.splashCounter = splashCounter
                        startActivity(nextScreen())
//                        overridePendingTransition(0, 0);
//                        finish()
                    }
                }, AdmobAppOpenId)
            } else {
                Log.e("SplashTag", "appOpenCounter%2-else")
                gotoMainScreen()
            }
        }
//        launchActivity()
    }

    private fun initAdSize() {
        val display = windowManager.defaultDisplay
        val outMetrics = DisplayMetrics()
        display.getMetrics(outMetrics)
        val widthPixels = outMetrics.widthPixels.toFloat()

        val density = outMetrics.density
        val adWidth = (widthPixels / density).toInt()

        AdsParameters(this@SplashActivity).adWidth=adWidth
    }
    private fun createTimerSec() {

        val totalTimeMillis = 6

        countDownTimer = object : CountDownTimer(totalTimeMillis * 1000L, 1000) {

            override fun onTick(l: Long) {

            }

            override fun onFinish() {
                gotoMainScreen()
            }
        }
        countDownTimer.start()
    }

    private fun gotoMainScreen() {
        Log.e("SplashTag", "gotoMainScreen")

        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(nextScreen())
//            overridePendingTransition(0, 0);
//            finish()
        }, 100)
    }

    private fun nextScreen(): Intent {
        Log.e("SplashTag", "nextScreen call")
        Log.e("SplashTag", "nextScreen ${preferences.isSetLanguage}")

        var intent = Intent(this, HomeActivity::class.java)
        if (!preferences.isSetLanguage) {
//            intent = Intent(this, LanguageActivity::class.java)
            intent = Intent(this, StartActivity::class.java)
                .putExtra(Constant.EXTRA_IS_OPEN_FROM_SPLASH, true)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        } else if (!checkStoragePermission()) {
            intent = Intent(
                this,
                PermissionActivity::class.java
            ).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        } else {
            intent = Intent(
                this,
                HomeActivity::class.java
            ).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        return intent
    }

    fun checkStoragePermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            val result = ContextCompat.checkSelfPermission(
                this, Manifest.permission.READ_EXTERNAL_STORAGE
            )
            val result1 = ContextCompat.checkSelfPermission(
                this, Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
            result == PackageManager.PERMISSION_GRANTED && result1 == PackageManager.PERMISSION_GRANTED
        }
    }

//    private fun launchActivity() {
//        Handler(Looper.getMainLooper()).postDelayed({
//            startActivity(Intent(this, HomeActivity::class.java))
//            finish()
//        },2500)
//    }
}
