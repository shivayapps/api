package gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.model

import android.app.Activity
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.util.Log
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityOptionsCompat
import androidx.core.text.HtmlCompat
import androidx.core.view.ViewCompat
import gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.activity.scanningactivities.ScanningDuplicateActivity
import gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.callbacks.MarkedListener
import gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.model.DuplicateFileRemoverSharedPreferences.setStopScan
import gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.model.DuplicateFoundAndSize.totalDuplicateAudios
import gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.model.DuplicateFoundAndSize.totalDuplicateDocuments
import gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.model.DuplicateFoundAndSize.totalDuplicateOthers
import gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.model.DuplicateFoundAndSize.totalDuplicatePhotos
import gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.model.DuplicateFoundAndSize.totalDuplicateVideos
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.activities.HomeActivity

import gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.GlobalVarsAndFunctions
import gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.activity.duplicateactivities.*
import gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.asynctask.DeleteDuplicateFileAsyncTask
import gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.asynctask.ReadingAllFilesAsyncTask
import gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.utils.RatingDialog

import java.util.*

@Suppress("DEPRECATION")
class PopUp(var popUpContext: Context, var popUpActivity: Activity) {

    fun showAlertStopScanning(readingAllFiles: ReadingAllFilesAsyncTask) {
        val builder = AlertDialog.Builder(popUpActivity, R.style.MyAlertDialogNew)
        builder.setMessage(popUpContext.getString(R.string.msg_stop_scanning)).setCancelable(false)
            .setPositiveButton(popUpContext.getString(R.string.yes)) { _: DialogInterface?, _: Int ->
                setStopScan(popUpContext, true)
                readingAllFiles.stopAsyncTask()

                popUpActivity.finish()
                popUpActivity.overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            }.setNegativeButton(popUpContext.getString(R.string.no)) { dialog: DialogInterface, _: Int -> dialog.dismiss() }
        val alert = builder.create()
        alert.setTitle(HtmlCompat.fromHtml("<font color='#0a82f3'>" + popUpContext.getString(R.string.label_exit_scanning)+ "</font>", HtmlCompat.FROM_HTML_MODE_LEGACY))
        alert.show()
//        val bgDrawable = popUpContext.resources.getColoredDrawableWithColor(gallery.gallerylock.vaultgallery.R.drawable.dialog_bg, popUpContext.baseConfig.backgroundColor)
//        alert.window?.setBackgroundDrawable(bgDrawable)
//        alert.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(popUpContext.resources.getColor(gallery.gallerylock.vaultgallery.R.color.color_primary))
//        alert.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(popUpContext.resources.getColor(gallery.gallerylock.vaultgallery.R.color.color_primary))
//        alert.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(popUpContext.resources.getColor(gallery.gallerylock.vaultgallery.R.color.color_primary))
    }

    fun showSpaceRecoveredPopUp(isType: String?, str1: String?, str2: String?, imagesMarkedListener: MarkedListener, deletedFileCount: Int) {
        Log.e("TAG", "photosCleaned showSpaceRecoveredPopUp: ")
        val dialogBuilder = AlertDialog.Builder(popUpActivity)
        val dialogView = popUpActivity.layoutInflater.inflate(R.layout.memory_regained_popup, null)
        dialogBuilder.setView(dialogView)
        dialogBuilder.setCancelable(false)
        val tv1 = dialogView.findViewById<TextView>(R.id.cleaned_photo)
        tv1.setTextColor(ViewCompat.MEASURED_STATE_MASK)
        tv1.text = str1
        val tv2 = dialogView.findViewById<TextView>(R.id.cleaned_memory)
        tv2.setTextColor(ViewCompat.MEASURED_STATE_MASK)
        tv2.text = str2
        val b = dialogBuilder.create()
        dialogView.findViewById<View>(R.id.dialogButtonok).setOnClickListener {
            var updateMainDuplicateFound = 0
            val numberOfFiles: Int = deletedFileCount
            when (isType) {
                "Photo" -> {
                    if (DuplicateImageDuplicateActivity.groupOfDupes != null) {
                        updateMainDuplicateFound = DuplicateImageDuplicateActivity.groupOfDupes!!.size - numberOfFiles
                    }
                    totalDuplicatePhotos -= numberOfFiles
                }
                "Video" -> {
                    if (DuplicateVideosDuplicateActivity.groupOfDupes != null) {
                        updateMainDuplicateFound = DuplicateVideosDuplicateActivity.groupOfDupes!!.size - numberOfFiles
                    }
                    totalDuplicateVideos -= numberOfFiles
                }
                "Audio" -> {
                    if (DuplicateAudiosDuplicateActivity.groupOfDupes != null) {
                        updateMainDuplicateFound = DuplicateAudiosDuplicateActivity.groupOfDupes!!.size - numberOfFiles
                    }
                    totalDuplicateAudios -= numberOfFiles
                }
                "Document" -> {
                    if (DuplicateDocumentsDuplicateActivity.groupOfDupes != null) {
                        updateMainDuplicateFound = DuplicateDocumentsDuplicateActivity.groupOfDupes!!.size - numberOfFiles
                    }
                    totalDuplicateDocuments -= numberOfFiles
                }
                "Other" -> {
                    if (DuplicateOthersDuplicateActivity.groupOfDupes != null) {
                        updateMainDuplicateFound = DuplicateOthersDuplicateActivity.groupOfDupes!!.size - numberOfFiles
                    }
                    totalDuplicateOthers -= numberOfFiles
                }
            }
            imagesMarkedListener.updateDuplicateFound(updateMainDuplicateFound)
            imagesMarkedListener.cleaned(numberOfFiles)
            imagesMarkedListener.updatePageDetails(null, null, 0, null)
            imagesMarkedListener.updateMarked()
            GlobalVarsAndFunctions.resetDeleteClickAction_temp = GlobalVarsAndFunctions.resetDeleteClickAction
            GlobalVarsAndFunctions.resetDeleteClickAction++
            /*if (GlobalVarsAndFunctions.resetDeleteClickAction_temp == 0) {
                if (getMandatoryRateUsPopUsFlag(popUpContext)) {
                    setMandatoryRateUsPopUsFlag(popUpContext, false)
                } else if (getRateUsPopUpLimit(popUpContext) <= 2) {
                    setMandatoryRateUsPopUsFlag(popUpContext, true)
                    setRateUsPopUpLimit(popUpContext, getRateUsPopUpLimit(popUpContext) + 1)
                }
            }*/
//            setMandatoryRateUsPopUsFlag(popUpContext, false)
//            val isRated = ExitSPHelper(popUpContext).isRated()
//            if (!isRated) {
//                if (SharedPrefsConstant.getInt(popUpContext, ShareConstants.RATE_DUPLICATE_COUNT) >= 4) {
//                RatingDialog.smileyRatingDialog(popUpActivity)
//                } else {
//                    SharedPrefsConstant.save(popUpContext, ShareConstants.RATE_DUPLICATE_COUNT, SharedPrefsConstant.getInt(popUpContext, ShareConstants.RATE_DUPLICATE_COUNT) + 1)
//                }
//            }
            b.dismiss()
        }
        dialogView.findViewById<View>(R.id.dialogButtonrescan).setOnClickListener {
            val numberOfFiles = 0
            val intent = Intent(popUpActivity, ScanningDuplicateActivity::class.java)
            when (isType) {
                "Photo" -> {
                    GlobalVarsAndFunctions.file_to_be_deleted_images.clear()
                    GlobalVarsAndFunctions.size_Of_File_images = 0
                    totalDuplicatePhotos = 0
                    intent.putExtra("IsCheckType", "Image")
                }
                "Video" -> {
                    GlobalVarsAndFunctions.file_to_be_deleted_videos.clear()
                    GlobalVarsAndFunctions.size_Of_File_videos = 0
                    totalDuplicateVideos = 0
                    intent.putExtra("IsCheckType", "Video")
                }
                "Audio" -> {
                    GlobalVarsAndFunctions.file_to_be_deleted_audios.clear()
                    GlobalVarsAndFunctions.size_Of_File_audios = 0
                    totalDuplicateAudios = 0
                    intent.putExtra("IsCheckType", "Audio")
                }
                "Document" -> {
                    GlobalVarsAndFunctions.file_to_be_deleted_documents.clear()
                    GlobalVarsAndFunctions.size_Of_File_documents = 0
                    totalDuplicateDocuments = 0
                    intent.putExtra("IsCheckType", "Document")
                }
                "Other" -> {
                    GlobalVarsAndFunctions.file_to_be_deleted_others.clear()
                    GlobalVarsAndFunctions.size_Of_File_others = 0
                    totalDuplicateOthers = 0
                    intent.putExtra("IsCheckType", "Other")
                }
            }
            imagesMarkedListener.cleaned(numberOfFiles)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            popUpActivity.startActivity(intent, ActivityOptionsCompat.makeCustomAnimation(popUpContext, R.anim.slide_from_left, R.anim.slide_from_right).toBundle())
            popUpActivity.finish()
            b.dismiss()
        }
        b.show()
//        val bgDrawable = popUpContext.resources.getColoredDrawableWithColor(gallery.gallerylock.vaultgallery.R.drawable.dialog_bg, popUpContext.baseConfig.backgroundColor)
//        b.window?.setBackgroundDrawable(bgDrawable)
//        b.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(popUpContext.resources.getColor(gallery.gallerylock.vaultgallery.R.color.color_primary))
//        b.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(popUpContext.resources.getColor(gallery.gallerylock.vaultgallery.R.color.color_primary))
//        b.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(popUpContext.resources.getColor(gallery.gallerylock.vaultgallery.R.color.color_primary))
    }

    fun deleteAlertPopUp(
        mType: String?,
        alertMessage: String?,
        dialogMessage: String,
        fileToBeDeleted: ArrayList<ItemDuplicateModel>?,
        deletingFileSize: Long,
        groupOfDuplicates: List<IndividualGroupModel>,
        imagesMarkedListener: MarkedListener
    ) {
        val builder = AlertDialog.Builder(popUpActivity, R.style.MyAlertDialogNew)
        builder.setMessage(alertMessage).setCancelable(false)
            .setPositiveButton(popUpContext.getString(R.string.yes)) { dialog: DialogInterface, _: Int ->
                dialog.dismiss()
//                popUpContext.addEvent("Duplicate${mType}Delete")

                if (fileToBeDeleted != null) {
                    DeleteDuplicateFileAsyncTask(mType, popUpContext, popUpActivity, imagesMarkedListener, dialogMessage, fileToBeDeleted, deletingFileSize, groupOfDuplicates).execute()
                }
            }.setNegativeButton(popUpContext.getString(R.string.no)) { dialog: DialogInterface, _: Int -> dialog.dismiss() }
        val alert = builder.create()
        alert.setTitle(HtmlCompat.fromHtml("<font color='#0a82f3'>" + popUpContext.getString(R.string.label_confirm_delete) + "</font>", HtmlCompat.FROM_HTML_MODE_LEGACY))

        alert.show()
//        val bgDrawable = popUpContext.resources.getColoredDrawableWithColor(gallery.gallerylock.vaultgallery.R.drawable.dialog_bg, popUpContext.baseConfig.backgroundColor)
//        alert.window?.setBackgroundDrawable(bgDrawable)
//        alert.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(popUpContext.resources.getColor(gallery.gallerylock.vaultgallery.R.color.color_primary))
//        alert.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(popUpContext.resources.getColor(gallery.gallerylock.vaultgallery.R.color.color_primary))
//        alert.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(popUpContext.resources.getColor(gallery.gallerylock.vaultgallery.R.color.color_primary))
    }

    companion object {
        @JvmStatic
        fun sortByPhotosDateAscending(listOfIndividualGroups: List<IndividualGroupModel>?): List<IndividualGroupModel>? {
            if (listOfIndividualGroups != null) {
                for (i in listOfIndividualGroups.indices) {
                    val imageItems = listOfIndividualGroups[i].individualGrpOfDupes
                    if (imageItems != null) {
                        @Suppress("JavaCollectionsStaticMethodOnImmutableList")
                        Collections.sort(imageItems) { lhs: ItemDuplicateModel, rhs: ItemDuplicateModel ->
                            Date(rhs.fileDateAndTime).compareTo(
                                Date(lhs.fileDateAndTime)
                            )
                        }
                    }
                    listOfIndividualGroups[i].individualGrpOfDupes = imageItems
                }
            }
            return listOfIndividualGroups
        }
    }
}