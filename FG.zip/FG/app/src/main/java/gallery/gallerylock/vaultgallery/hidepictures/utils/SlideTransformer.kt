package gallery.gallerylock.vaultgallery.hidepictures.utils

import android.view.View
import androidx.viewpager2.widget.ViewPager2

class SlideTransformer : ViewPager2.PageTransformer {
    override fun transformPage(page: View, position: Float) {
        // Set a translationX for both left and right slides
        val translationX = page.width * -position
        page.translationX = translationX

        // Apply fading effect
        page.alpha = 1 - Math.abs(position)
    }
}