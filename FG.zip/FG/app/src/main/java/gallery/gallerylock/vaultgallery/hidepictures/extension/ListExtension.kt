package gallery.gallerylock.vaultgallery.hidepictures.extension


fun <T> List<T>.splitIntoParts(parts: Int): List<List<T>> {
    require(parts > 0) {
        "Parts should be greater than zero (was $parts)"
    }

    val partsList = buildList<MutableList<T>> {
        repeat(parts) {
            add(mutableListOf())
        }
    }

    for ((index, value) in this.withIndex()) {
        val partIndex = index % parts
        partsList[partIndex].add(value)
    }

    return partsList.filter { it.isNotEmpty() }
}

/**
 * Remove empty lines at the end of list
 */
fun List<String>.trimEmptyEndLines(): List<String> {
    var emptyLinesCount = 0
    for (line in reversed()) {
        if (line.isEmpty()) {
            emptyLinesCount++
        } else {
            break

        }
    }

    return slice(0 until (size - emptyLinesCount))
}