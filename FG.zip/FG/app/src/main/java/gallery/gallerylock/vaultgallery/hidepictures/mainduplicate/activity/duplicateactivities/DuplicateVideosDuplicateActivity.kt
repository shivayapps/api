package gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.activity.duplicateactivities

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.text.Html
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityOptionsCompat
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.activity.scanningactivities.ScanningDuplicateActivity
import gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.adapter.IndividualVideosAdapter
import gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.callbacks.MarkedListener
import gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.model.DuplicateFileRemoverSharedPreferences
import gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.model.IndividualGroupModel
import gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.model.ItemDuplicateModel
import gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.model.PopUp
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.activities.HomeActivity
import gallery.gallerylock.vaultgallery.hidepictures.databinding.ActivityDuplicateVideosBinding
import gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.BaseSimpleActivity
import gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.GlobalVarsAndFunctions
import gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.utils.MyUtils
import gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.utils.RatingDialog
import gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.utils.ShareConstants
import gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.utils.SharedPrefsConstant

import java.util.*

@SuppressLint("StaticFieldLeak", "SetTextI18n")
class DuplicateVideosDuplicateActivity : AppCompatActivity(), MarkedListener,
    View.OnClickListener {
    var mTAG: String = javaClass.simpleName
    var adapterList: List<IndividualGroupModel>? = null
    var individualVideosAdapter: IndividualVideosAdapter? = null
    var mLayoutManager: LinearLayoutManager? = null
    var mDuplicateFound = 0
    var index = -1
    var tempGroupOfDupes: List<IndividualGroupModel>? = null
    var top = -1

    companion object {
        @JvmField
        var filterListVideos = HashMap<String, Boolean>()

        @JvmField
        var groupOfDupes: List<IndividualGroupModel>? = null

        @JvmField
        var recyclerViewForIndividualGrp: RecyclerView? = null
    }

    lateinit var mContext:Activity
    lateinit var binding:ActivityDuplicateVideosBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
        binding=ActivityDuplicateVideosBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        setContentView(R.layout.activity_duplicate_videos)

        mContext=getContext()
//        initViews()
//        initAds()
        initData()
        initActions()
        Log.e(mTAG, "onCreate: ")
    }



    fun getContext(): Activity {
        return this@DuplicateVideosDuplicateActivity
    }

    fun initData() {
        recyclerViewForIndividualGrp = findViewById(R.id.recycler_view_videos)
        setSupportActionBar(binding.toolbar)
        mLayoutManager = LinearLayoutManager(mContext)
        recyclerViewForIndividualGrp!!.layoutManager = mLayoutManager
        recyclerViewForIndividualGrp!!.setHasFixedSize(true)
        initiateDataInPage()
    }

    fun initActions() {
        binding.delete.setOnClickListener(this)
        binding.backpressVideo.setOnClickListener(this)
    }

    @SuppressLint("NonConstantResourceId")
    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
            return
        }
        ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
        when (view.id) {
            R.id.backpress_video -> onBackPressed()
            R.id.delete -> deleteDuplicate()
        }
    }

    private fun initiateDataInPage() {
        try {
            StartScan().execute("")
        } catch (e: Exception) {
            Log.e(mTAG, "initiateDataInPage: " + e.message)
        }
    }

    inner class StartScan : AsyncTask<String?, String?, String?>() {
        override fun doInBackground(vararg params: String?): String? {
            if (DuplicateFileRemoverSharedPreferences.isInitiateRescanAndEnterVidePageFirstTimeAfterScan(mContext)) {
                DuplicateFileRemoverSharedPreferences.setInitiateRescanAndEnterVideoPageFirstTimeAfterScan(mContext, false)
                groupOfDupes = PopUp.sortByPhotosDateAscending(GlobalVarsAndFunctions.listOfGroupedDuplicatesVideos)
                tempGroupOfDupes = PopUp.sortByPhotosDateAscending(GlobalVarsAndFunctions.listOfGroupedDuplicatesVideos)
                adapterList = setCheckBox(true)
            } else {
                applyFilterIntDuplicates()
                if (DuplicateFileRemoverSharedPreferences.isInitiateVideoPageAfterApplyFilter(mContext)) {
                    DuplicateFileRemoverSharedPreferences.setInitiateVideoPageAfterApplyFilter(mContext, false)
                    adapterList = setCheckBox(true)
                } else {
                    adapterList = reassignWithDefaultSelection()
                    updateMarked()
                }
            }
            return null
        }

        override fun onPostExecute(s: String?) {
            super.onPostExecute(s)
            updatePageDetails(null, null, 0, null)
            if (adapterList!!.isNotEmpty()) {
                recyclerViewForIndividualGrp!!.visibility = View.VISIBLE
                binding.llNoDuplicate.visibility = View.GONE
                binding.deleteExceptionFrameLayout.visibility = View.VISIBLE
                invalidateOptionsMenu()
                individualVideosAdapter = IndividualVideosAdapter(
                    mContext, this@DuplicateVideosDuplicateActivity,
                    adapterList!!
                )
                recyclerViewForIndividualGrp!!.adapter = individualVideosAdapter
                individualVideosAdapter!!.notifyDataSetChanged()
                SharedPrefsConstant.save(mContext, ShareConstants.RATE_DUPLICATE_COUNT, SharedPrefsConstant.getInt(mContext, ShareConstants.RATE_DUPLICATE_COUNT) + 1)
                return
            }
            recyclerViewForIndividualGrp!!.visibility = View.GONE
            binding.deleteExceptionFrameLayout.visibility = View.GONE
            binding.llNoDuplicate.visibility = View.VISIBLE
            invalidateOptionsMenu()
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
        super.onActivityResult(requestCode, resultCode, resultData)
        if (requestCode == GlobalVarsAndFunctions.REQUEST_CODE_OPEN_DOCUMENT_TREE && resultCode == -1) {
            if (MyUtils.isSelectedStorageAccessFrameWorkPathIsProper(mContext, DocumentFile.fromTreeUri(mContext, resultData!!.data!!)!!.name)) {
                DuplicateFileRemoverSharedPreferences.setStorageAccessFrameWorkURIPermission(mContext, resultData.data.toString())
                showDeleteDialog()
                return
            }
            Toast.makeText(mContext, "Please Select Parent External Storage Dir", Toast.LENGTH_SHORT).show()
            startActivityForResult(Intent("android.intent.action.OPEN_DOCUMENT_TREE"), GlobalVarsAndFunctions.REQUEST_CODE_OPEN_DOCUMENT_TREE)
        }
    }

    private fun showDeleteDialog() {
        if (GlobalVarsAndFunctions.file_to_be_deleted_videos.size == 1) {
            PopUp(mContext, mContext).deleteAlertPopUp(
                "Video",
                getString(R.string.msg_delete_alert_message_video_single),
                getString(R.string.msg_delete_dialog_message_video_single),
                GlobalVarsAndFunctions.file_to_be_deleted_videos,
                GlobalVarsAndFunctions.size_Of_File_videos,
                GlobalVarsAndFunctions.listOfGroupedDuplicatesVideos,
                this
            )
        } else {
            PopUp(mContext, mContext).deleteAlertPopUp(
                "Video",
                getString(R.string.msg_delete_alert_message_videos),
                getString(R.string.msg_delete_dialog_message_videos),
                GlobalVarsAndFunctions.file_to_be_deleted_videos,
                GlobalVarsAndFunctions.size_Of_File_videos,
                GlobalVarsAndFunctions.listOfGroupedDuplicatesVideos,
                this
            )
        }
    }

    private fun deleteDuplicate() {
        if( GlobalVarsAndFunctions.file_to_be_deleted_videos.size <= 0) {
            MyUtils.showToastMsg(mContext, getString(R.string.error_please_select_one_item))
        } else
            showDeleteDialog()
//        when {
//            GlobalVarsAndFunctions.file_to_be_deleted_videos.size <= 0 -> {
//                MyUtils.showToastMsg(mContext, getString(R.string.error_please_select_one_item))
//            }
//            Build.VERSION.SDK_INT >= 20 -> {
//                showDeleteDialog()
//            }
//            MyUtils.getSDCardPath(mContext) == null -> {
//                showDeleteDialog()
//            }
//            DuplicateFileRemoverSharedPreferences.getStorageAccessFrameWorkURIPermission(mContext) != null -> {
//                showDeleteDialog()
//            }
//            else -> {
//                grantPermissionWithAlertDialog()
//            }
//        }
    }

//    private fun grantPermissionWithAlertDialog() {
//        val builder = AlertDialog.Builder(mContext)
//        builder.setView(layoutInflater.inflate(R.layout.dialog_saf_permission, null))
//        builder.setCancelable(false)
//        builder.setPositiveButton("Allow Permission" as CharSequence, PermissionYes())
//        builder.setNegativeButton("Cancel" as CharSequence) { dialog: DialogInterface, _: Int -> dialog.dismiss() }
//        val dialog = builder.create()
//        dialog.show()
//        val pButton = dialog.getButton(-1)
//        pButton.setTextColor(ContextCompat.getColor(mContext.baseContext, R.color.colorPrimary))
//        pButton.isAllCaps = false
//        dialog.getButton(-2).isAllCaps = false
//    }

    internal inner class PermissionYes : DialogInterface.OnClickListener {
        override fun onClick(dialog: DialogInterface, which: Int) {
            dialog.dismiss()
            startActivityForResult(Intent("android.intent.action.OPEN_DOCUMENT_TREE"), GlobalVarsAndFunctions.REQUEST_CODE_OPEN_DOCUMENT_TREE)
        }
    }

    private fun applyFilterIntDuplicates() {
        when {
            filterListVideos.size == GlobalVarsAndFunctions.uniqueVideosExtension.size -> {
                groupOfDupes = tempGroupOfDupes
            }
            filterListVideos.size > 0 -> {
                val newIndividualGroupVideos: MutableList<IndividualGroupModel> = ArrayList()
                for ((key) in filterListVideos) {
                    for (j in tempGroupOfDupes!!.indices) {
                        val individualGroupVideos1 = tempGroupOfDupes!![j]
                        if (individualGroupVideos1.groupExtension.equals(key, ignoreCase = true)) {
                            newIndividualGroupVideos.add(individualGroupVideos1)
                        }
                    }
                }
                groupOfDupes = newIndividualGroupVideos
            }
            else -> {
                groupOfDupes = tempGroupOfDupes
            }
        }
    }

    public override fun onPause() {
        var i = 0
        super.onPause()
        index = mLayoutManager!!.findFirstVisibleItemPosition()
        val v = recyclerViewForIndividualGrp!!.getChildAt(0)
        if (v != null) {
            i = v.top - recyclerViewForIndividualGrp!!.paddingTop
        }
        top = i
    }

    public override fun onResume() {
        super.onResume()
        if (index != -1) {
            mLayoutManager!!.scrollToPositionWithOffset(index, top)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.settings_1, menu)
        if (mDuplicateFound == 0) {
            menu.findItem(R.id.action_selectall).isEnabled = false
            menu.findItem(R.id.action_deselectall).isEnabled = false
            menu.findItem(R.id.action_selectall).title = Html.fromHtml("<font color='#ABABAB'>" + getString(R.string.label_menu_select_all) + "</font>")
            menu.findItem(R.id.action_deselectall).title = Html.fromHtml("<font color='#ABABAB'>" + getString(R.string.label_menu_deselect_all) + "</font>")
        } else {
            menu.findItem(R.id.action_selectall).isEnabled = true
            menu.findItem(R.id.action_deselectall).isEnabled = true
            menu.findItem(R.id.action_selectall).title = Html.fromHtml("<font color='#000000'>" + getString(R.string.label_menu_select_all) + "</font>")
            menu.findItem(R.id.action_deselectall).title = Html.fromHtml("<font color='#000000'>" + getString(R.string.label_menu_deselect_all) + "</font>")
        }
        invalidateOptionsMenu()
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        if (mDuplicateFound == 0) {
            menu.findItem(R.id.action_selectall).isEnabled = false
            menu.findItem(R.id.action_deselectall).isEnabled = false
            menu.findItem(R.id.action_selectall).title = Html.fromHtml("<font color='#ABABAB'>" + getString(R.string.label_menu_select_all) + "</font>")
            menu.findItem(R.id.action_deselectall).title = Html.fromHtml("<font color='#ABABAB'>" + getString(R.string.label_menu_deselect_all) + "</font>")
        } else {
            menu.findItem(R.id.action_selectall).isEnabled = true
            menu.findItem(R.id.action_deselectall).isEnabled = true
            menu.findItem(R.id.action_selectall).title = Html.fromHtml("<font color='#000000'>" + getString(R.string.label_menu_select_all) + "</font>")
            menu.findItem(R.id.action_deselectall).title = Html.fromHtml("<font color='#000000'>" + getString(R.string.label_menu_deselect_all) + "</font>")
        }
        invalidateOptionsMenu()
        return super.onPrepareOptionsMenu(menu)
    }

    @SuppressLint("WrongConstant")
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        val intent: Intent
        when (id) {
            R.id.action_home -> {
                intent = Intent(mContext, HomeActivity::class.java)
                intent.addFlags(335544320)
                startActivity(intent)
                finish()
                return true
            }
            R.id.action_rescan -> {
                GlobalVarsAndFunctions.resetOneTimePopUp()
                filterListVideos.clear()
                intent = Intent(mContext, ScanningDuplicateActivity::class.java)
                intent.putExtra("IsCheckType", "Video")
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent, ActivityOptionsCompat.makeCustomAnimation(mContext, R.anim.slide_from_left, R.anim.slide_from_right).toBundle())
                onBackPressed()
                return true
            }
            R.id.action_selectall -> {
                if (mDuplicateFound == 0) {
                    Toast.makeText(mContext, "No Duplicate Data Found", Toast.LENGTH_SHORT).show()
                } else {
                    imagesSelectAllAndDeselectAll(true)
                }
                return true
            }
            R.id.action_deselectall -> {
                if (mDuplicateFound == 0) {
                    Toast.makeText(mContext, "No Duplicate Data Found", Toast.LENGTH_SHORT).show()
                } else {
                    imagesSelectAllAndDeselectAll(false)
                }
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    private fun imagesSelectAllAndDeselectAll(b: Boolean) {
        individualVideosAdapter = IndividualVideosAdapter(mContext,this, setCheckBox(b))
        recyclerViewForIndividualGrp!!.adapter = individualVideosAdapter
        individualVideosAdapter!!.notifyDataSetChanged()
        updatePageDetails(null, null, 0, null)
    }

    private fun reassignWithDefaultSelection(): List<IndividualGroupModel> {
        val listOfDupes: MutableList<IndividualGroupModel> = ArrayList()
        GlobalVarsAndFunctions.file_to_be_deleted_videos.clear()
        GlobalVarsAndFunctions.size_Of_File_videos = 0
        if (groupOfDupes != null) {
            for (i in groupOfDupes!!.indices) {
                val individualGroup = groupOfDupes!![i]
                individualGroup.isCheckBox = individualGroup.isCheckBox
                val list: MutableList<ItemDuplicateModel> = ArrayList()
                for (j in individualGroup.individualGrpOfDupes!!.indices) {
                    val videoItem = individualGroup.individualGrpOfDupes!![j]
                    if (j == 0) {
                        videoItem.isFileCheckBox = false
                    } else {
                        if (individualGroup.isCheckBox) {
                            GlobalVarsAndFunctions.file_to_be_deleted_videos.add(videoItem)
                            GlobalVarsAndFunctions.addSizeVideos(videoItem.sizeOfTheFile)
                        }
                        updateMarked()
                        videoItem.isFileCheckBox = individualGroup.isCheckBox
                    }
                    list.add(videoItem)
                }
                individualGroup.individualGrpOfDupes = list
                listOfDupes.add(individualGroup)
            }
        }
        updateDuplicateFound(listOfDupes.size)
        updateMarked()
        return listOfDupes
    }

    private fun setCheckBox(value: Boolean): List<IndividualGroupModel> {
        val listOfDupes: MutableList<IndividualGroupModel> = ArrayList()
        GlobalVarsAndFunctions.file_to_be_deleted_videos.clear()
        GlobalVarsAndFunctions.size_Of_File_videos = 0
        if (groupOfDupes != null) {
            for (i in groupOfDupes!!.indices) {
                val individualGroup = groupOfDupes!![i]
                individualGroup.isCheckBox = value
                val list: MutableList<ItemDuplicateModel> = ArrayList()
                for (j in individualGroup.individualGrpOfDupes!!.indices) {
                    val videoItem = individualGroup.individualGrpOfDupes!![j]
                    if (j == 0) {
                        videoItem.isFileCheckBox = false
                    } else {
                        if (value) {
                            GlobalVarsAndFunctions.file_to_be_deleted_videos.add(videoItem)
                            GlobalVarsAndFunctions.addSizeVideos(videoItem.sizeOfTheFile)
                        }
                        updateMarked()
                        videoItem.isFileCheckBox = value
                    }
                    list.add(videoItem)
                }
                individualGroup.individualGrpOfDupes = list
                listOfDupes.add(individualGroup)
            }
        }
        updateDuplicateFound(listOfDupes.size)
        updateMarked()
        return listOfDupes
    }

    override fun updateDuplicateFound(duplicateFound: Int) {
        try {
            runOnUiThread {
                (findViewById<View>(R.id.dupes_found) as TextView).text = resources.getString(R.string.duplicate_found) + duplicateFound
            }
            mDuplicateFound = duplicateFound
        } catch (e: Exception) {
            Log.e(mTAG, "updateDuplicateFound: " + e.message)
        }
    }

    override fun updateMarked() {
        try {
            runOnUiThread(SetBottomMark())
        } catch (e: Exception) {
            Log.e(mTAG, "updateMarked: " + e.message)
        }
    }

    internal inner class SetBottomMark : Runnable {
        override fun run() {
            val tvMarked = findViewById<TextView>(R.id.marked)
            tvMarked.visibility = View.VISIBLE
            tvMarked.text = getString(R.string.label_duplicate_size, ShareConstants.getReadableFileSize(GlobalVarsAndFunctions.size_Of_File_videos))
        }
    }

    override fun cleaned(numberOfPhotosCleaned: Int) {
        Log.e(mTAG, "photosCleanedVideos: ")
        try {
            runOnUiThread {
                val filesCleaned = DuplicateFileRemoverSharedPreferences.getFilesCleaned(mContext) + numberOfPhotosCleaned
                DuplicateFileRemoverSharedPreferences.setFilesCleaned(mContext, filesCleaned)
            }
        } catch (e: Exception) {
            Log.e(mTAG, "Cleaned: " + e.message)
        }
    }

    override fun updatePageDetails(str1: String?, str2: String?, int1: Int, obj: Any?) {
        if (str1 == null) {
            var duplicateCount = 0
            if (groupOfDupes != null) {
                for (i in groupOfDupes!!.indices) {
                    val individualGroup = groupOfDupes!![i]
                    if (individualGroup.individualGrpOfDupes!!.size > 1) {
                        duplicateCount =
                            individualGroup.individualGrpOfDupes!!.size + duplicateCount - 1
                    }
                }
                updateDuplicateFound(duplicateCount)
            }
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }
}