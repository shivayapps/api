package gallery.gallerylock.vaultgallery.hidepictures.edit.model

import android.graphics.drawable.Drawable

data class EditData(var name: String, var icon: Drawable? , var isSelected: Boolean = true)
