package gallery.gallerylock.vaultgallery.hidepictures.mainduplicate

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.SystemClock
import android.util.Log
import android.view.View
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.databinding.ActivityDuplicateFinderBinding
import gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.activity.scanningactivities.ScanningDuplicateActivity

class DuplicateFinderActivity : AppCompatActivity(), View.OnClickListener {

    lateinit var mBinding:ActivityDuplicateFinderBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding= ActivityDuplicateFinderBinding.inflate(layoutInflater)
        setContentView(mBinding.root)
//        setContentView(R.layout.activity_duplicate_finder)


        initActions()

        mBinding.imgBack.setOnClickListener {
            onBackPressed()
        }
    }
    fun initActions() {
        mBinding.llScanImages.setOnClickListener(this)
        mBinding.llScanAudio.setOnClickListener(this)
        mBinding.llScanVideo.setOnClickListener(this)
        mBinding.llScanDocument.setOnClickListener(this)
        mBinding.llScanOther.setOnClickListener(this)
    }

    override fun onClick(view: View) {

        when (view.id) {
            R.id.llScanImages -> {
                var intent = Intent(this, ScanningDuplicateActivity::class.java)
                intent.putExtra("IsCheckType", "Image")
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
            }
            R.id.llScanAudio -> {
                var intent = Intent(this, ScanningDuplicateActivity::class.java)
                intent.putExtra("IsCheckType", "Audio")
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
            }
            R.id.llScanVideo -> {
                var intent = Intent(this, ScanningDuplicateActivity::class.java)
                intent.putExtra("IsCheckType", "Video")
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
            }
            R.id.llScanDocument -> {
                var intent = Intent(this, ScanningDuplicateActivity::class.java)
                intent.putExtra("IsCheckType", "Document")
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
            }
            R.id.llScanOther -> {
                var intent = Intent(this, ScanningDuplicateActivity::class.java)
                intent.putExtra("IsCheckType", "Other")
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
            }
        }
    }
}