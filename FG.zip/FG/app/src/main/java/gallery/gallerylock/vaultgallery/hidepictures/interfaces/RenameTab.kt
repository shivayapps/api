package gallery.gallerylock.vaultgallery.hidepictures.interfaces

import android.app.Activity


interface RenameTab {

    fun initTab(activity: Activity, paths: ArrayList<String>)

    fun dialogConfirmed(useMediaFileExtension: Boolean, callback: (success: Boolean) -> Unit)
}
