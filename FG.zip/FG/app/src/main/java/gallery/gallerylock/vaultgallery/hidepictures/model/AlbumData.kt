package gallery.gallerylock.vaultgallery.hidepictures.model

data class AlbumData(
    var title: String = "",
    var pictureData: ArrayList<PictureData> = ArrayList(),
    var folderPath: String = "",
    var date: Long = 0L,
    var fileSize: Long = 0L,
    var isSelected: Boolean = false,
    var isCheckboxVisible: Boolean = false,
    var isCustomAlbum: Boolean = false,
    var folderImageList: ArrayList<Any> = ArrayList(),
    var lati: Float = 0F,
    var long: Float = 0F,
)