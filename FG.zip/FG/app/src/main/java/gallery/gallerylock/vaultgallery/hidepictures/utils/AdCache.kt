package gallery.gallerylock.vaultgallery.hidepictures.utils

import android.os.Build
import android.os.Environment
import android.os.Looper
import androidx.annotation.ChecksSdkIntAtLeast
import com.google.android.gms.ads.AdView
import gallery.gallerylock.vaultgallery.hidepictures.model.AlbumData
import gallery.gallerylock.vaultgallery.hidepictures.model.PictureData

class AdCache {
    companion object {
        var homeAdView:AdView?=null
        var editAdView:AdView?=null
        var albumAdView:AdView?=null
        var exploreAlbumAdView:AdView?=null
        var imageListAdView:AdView?=null
        var recentlyDeletedAdView:AdView?=null
        var mapExploreAdView:AdView?=null
        var recoverMediaAdView:AdView?=null
        var privateViewerAdView:AdView?=null
        var privateAdView:AdView?=null
        var privateListAdView:AdView?=null
        var photoVideoAdView:AdView?=null
        var favoriteListAdView:AdView?=null
        var dirsAdView:AdView?=null
        var selectImageAdView:AdView?=null

    }
}


