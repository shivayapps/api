package gallery.gallerylock.vaultgallery.hidepictures.mainduplicate.model

import java.io.Serializable

class ItemDuplicateModel : Serializable {
    var filePath: String? = null
    var isFileCheckBox = false
    var fileItemGrpTag = 0
    var fileDateAndTime: Long = 0
    var filePosition = 0
    var sizeOfTheFile: Long = 0
    var imageResolution: String? = null
    var fileDuration: String? = null
}