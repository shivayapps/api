package gallery.gallerylock.vaultgallery.hidepictures.picker

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.ViewPager
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.google.android.material.tabs.TabLayoutMediator
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.activities.HomeActivity
import gallery.gallerylock.vaultgallery.hidepictures.base.BaseActivity
import gallery.gallerylock.vaultgallery.hidepictures.customview.MyGridLayoutManager
import gallery.gallerylock.vaultgallery.hidepictures.databinding.ActivityImagePickerBinding
import gallery.gallerylock.vaultgallery.hidepictures.model.AlbumData
import gallery.gallerylock.vaultgallery.hidepictures.model.PictureData

class ImagePickerActivity : BaseActivity() {

    lateinit var binding: ActivityImagePickerBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityImagePickerBinding.inflate(layoutInflater)
        setContentView(binding.root)


        val fragmentAll = MediaFragment.newInstance(0)
        val fragmentPhotos = MediaFragment.newInstance(1)
        val fragmentVideo = MediaFragment.newInstance(2)

        val pagerAdapter = ViewPagerAdapter(this, supportFragmentManager)
        pagerAdapter.addFragment(fragmentAll)
        pagerAdapter.addFragment(fragmentPhotos)
        pagerAdapter.addFragment(fragmentVideo)

        binding.mainViewPager.adapter = pagerAdapter
        binding.mainViewPager.isSaveEnabled = false
        binding.mainViewPager.offscreenPageLimit = 2

        binding.tab0.setOnClickListener { binding.mainViewPager.currentItem = 0 }
        binding.tab1.setOnClickListener { binding.mainViewPager.currentItem = 1 }
        binding.tab2.setOnClickListener { binding.mainViewPager.currentItem = 2 }

//        val selected = ContextCompat.getColor(this, R.color.tab_selected)
//        val unselected = ContextCompat.getColor(this, R.color.tab_unselected)
//        binding.tabLayout.setTabTextColors(unselected, selected)

        binding.mainViewPager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {
            }

            override fun onPageSelected(position: Int) {

                when (position) {
                    0 -> {
                        binding.tab0.backgroundTintList =
                            ColorStateList.valueOf(resources.getColor(R.color.color_accent))
                        binding.tab1.backgroundTintList =
                            ColorStateList.valueOf(resources.getColor(R.color.black_overlay))
                        binding.tab2.backgroundTintList =
                            ColorStateList.valueOf(resources.getColor(R.color.black_overlay))
                    }

                    1 -> {
                        binding.tab0.backgroundTintList =
                            ColorStateList.valueOf(resources.getColor(R.color.black_overlay))
                        binding.tab1.backgroundTintList =
                            ColorStateList.valueOf(resources.getColor(R.color.color_accent))
                        binding.tab2.backgroundTintList =
                            ColorStateList.valueOf(resources.getColor(R.color.black_overlay))
                    }

                    2 -> {
                        binding.tab0.backgroundTintList =
                            ColorStateList.valueOf(resources.getColor(R.color.black_overlay))
                        binding.tab1.backgroundTintList =
                            ColorStateList.valueOf(resources.getColor(R.color.black_overlay))
                        binding.tab2.backgroundTintList =
                            ColorStateList.valueOf(resources.getColor(R.color.color_accent))
                    }
                }

//                binding.tabLayout.selectTab()=position
            }

            override fun onPageScrollStateChanged(state: Int) {
            }
        })
//        TabLayoutMediator(binding.tabLayout, binding.mainViewPager) { tab, position ->
//            tab.text = when (position) {
//                0 -> getString(R.string.all)
//                1 -> getString(R.string.imagens)
//                2 -> getString(R.string.videos)
//                else -> ""
//            }
//        }.attach()

        binding.icClose.setOnClickListener {
            setResult(Activity.RESULT_CANCELED)
            finish()
//            onBackPressedDispatcher.onBackPressed()
        }
        binding.btnImport.setOnClickListener {

//            var selectedItem:ArrayList<String>=ArrayList()
            var selectedItem: ArrayList<String> = ArrayList()

            if (binding.mainViewPager.currentItem == 0) {
                selectedItem = fragmentAll.getSelected()
            } else if (binding.mainViewPager.currentItem == 1) {
                selectedItem = fragmentPhotos.getSelected()
            } else if (binding.mainViewPager.currentItem == 2) {
                selectedItem = fragmentVideo.getSelected()
            }
            sendResult(selectedItem)
//            onBackPressedDispatcher.onBackPressed()
        }
        setToolbarSelectionMaintain(
            true,
            0,
            false
        )
    }

    private fun sendResult(mediaList: ArrayList<String>) {
        val intent = Intent()
        intent.putExtra("selection", mediaList)
        intent.putExtra("type", 0)
//        intent.putExtra("position", position)
        setResult(RESULT_OK, intent)
        finish()
    }

    fun getAlbumListForSelect() {
//        if (albumFragment != null)
//            albumFragment.setBackAlbumData()
    }

    fun longClickListener(isShowSelection: Boolean, selected: Int, isAllSelect: Boolean) {
        setToolbarSelectionMaintain(
            isShowSelection,
            selected,
            isAllSelect
        )
    }

    var isSelectAll = false
    var mSelectedItem = 0
    private fun setToolbarSelectionMaintain(
        isShowSelection: Boolean,
        selectedItem: Int,
        isAllSelect: Boolean
    ) {
        mSelectedItem = selectedItem
//        binding.loutToolbar.visibility = View.VISIBLE

        binding.mainViewPager.setPagingEnabled(selectedItem > 0)

        if (isShowSelection) {
            binding.btnImport.alpha = if (mSelectedItem > 0) 1.0F else 0.5F
        }

//        binding.mainViewPager.setPagingEnabled(!isShowSelection)
        isSelectAll = isAllSelect


//        binding.loutSelectOption.visibility =
//            if (isShowSelection && selectedItem != 0) View.VISIBLE else View.GONE


//        if (binding.viewPager.currentItem == 2) {
//            binding.groupToolbarSettingHeader.visibility = View.GONE
//            binding.groupToolbarHeaderPrivate.visibility =
//                if (isShowSelection) View.GONE else View.VISIBLE
//        } else
//            binding.groupToolbarHeader.visibility =
//                if (isShowSelection) View.GONE else View.VISIBLE

//        binding.loutTab.visibility = if (isShowSelection) View.GONE else View.VISIBLE
//        binding.cardLoutTab.visibility = if (isShowSelection) View.GONE else View.VISIBLE
//        binding.bottomNavigation.visibility = if (isShowSelection) View.GONE else View.VISIBLE
        binding.txtSelectCount.text = "$selectedItem ${getString(R.string.items_selected)}"
//        setSelectAllColor()
    }

    class ViewPagerAdapter(val activity: Activity, fm: FragmentManager) :
        FragmentStatePagerAdapter(fm) {
//    class ViewPagerAdapter(fragmentActivity: FragmentActivity) : FragmentStateAdapter(fragmentActivity) {

        private val fragments = mutableListOf<Fragment>()

//        override fun getItemCount(): Int {
//            return fragments.size
//        }
//
//        override fun createFragment(position: Int): Fragment {
//            return fragments[position]
//        }

        fun addFragment(fragment: Fragment) {
            fragments.add(fragment)
            notifyDataSetChanged()
        }

        override fun getCount(): Int {
            return fragments.size
        }

        override fun getItem(position: Int): Fragment {
            return fragments[position]
        }
    }

}