package gallery.gallerylock.vaultgallery.hidepictures.secret.activity

import android.app.ProgressDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.base.BaseNoThemeActivity
import gallery.gallerylock.vaultgallery.hidepictures.databinding.ActivityOtpBinding
import gallery.gallerylock.vaultgallery.hidepictures.extension.beGone
import gallery.gallerylock.vaultgallery.hidepictures.extension.beVisible
import gallery.gallerylock.vaultgallery.hidepictures.extension.toast
import gallery.gallerylock.vaultgallery.hidepictures.otpview.OTPListener
import gallery.gallerylock.vaultgallery.hidepictures.secret.MailUtil
import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant
import gallery.gallerylock.vaultgallery.hidepictures.utils.Preferences
import java.util.Calendar

class OtpActivity : BaseNoThemeActivity() {

    lateinit var binding: ActivityOtpBinding
    lateinit var preferences: Preferences


    override fun onCreate(savedInstanceState: Bundle?) {
//        forceDarkMode=true
        super.onCreate(savedInstanceState)
        binding = ActivityOtpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        intView()
    }

    var veriCode=""
    var codeTimeOut=0L
    lateinit var animation: Animation
    private fun intView() {
        animation = AnimationUtils.loadAnimation(this, R.anim.anim_shake)
        preferences = Preferences(this)
        binding.txtTitle.text = getString(R.string.reset_password)

        veriCode=preferences.getVeriCode()
        codeTimeOut=preferences.getOtpTimeOut()

//        binding.txtHint.text = getString(R.string.check_otp_message,preferences.securityEmail)


//        cal.add(Calendar.MINUTE,cal.get(Calendar.MINUTE))
//        val timeAfter30=cal.timeInMillis

        intListener()
    }

    private fun startTimer() {
        binding.txtResend.setTextColor(Color.parseColor("#898F9B"))
        binding.txtTimer.beVisible()
        binding.txtTimer.setUnits(null, null, null, "s")
        binding.txtTimer.setCountTime(40)
        binding.txtTimer.startCount()
        binding.txtTimer.setOnCountOverListener {
            binding.txtTimer.beGone()
            binding.txtResend.setTextColor(ColorStateList.valueOf(resources.getColor(R.color.color_primary)))
        }
    }

    private fun setErrorAnimation(view: View) {
        view.startAnimation(animation)
    }

    private fun intListener() {

        binding.icBack.setOnClickListener {
            onBackPressed()
        }
        startTimer()
//        val progressDialog = ProgressDialog(this)
        binding.llResend.setOnClickListener {

//            val clientMail = preferences.securityEmail
            val clientMail = ""
            val progressDialog = ProgressDialog(this,ProgressDialog.THEME_DEVICE_DEFAULT_DARK)
            progressDialog.show()
//                        MailUtil.requestOtp(activity,clientMail, subject, content, mailListener = {
            MailUtil.requestOtp(this, mailListener = {
                progressDialog.dismiss()
                if(it) {
                    runOnUiThread { startTimer() }
                    toast("Reset password send to $clientMail")
//                    val intent=Intent(this, OtpActivity::class.java)
//                    startActivity(intent)
//                    invoke(false)
                } else {
                    toast("Something went wron please try again latter.")
                }
            })
        }

        binding.edtVeriCode.otpListener=object :OTPListener{
            override fun onInteractionListener(otp: String) {
                if(otp.length==4) {
                    binding.btnConfirm.backgroundTintList= ColorStateList.valueOf(resources.getColor(R.color.color_primary))
                } else {
                    binding.btnConfirm.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#1F2337"))
                }
            }

            override fun onOTPComplete(otp: String) {
            }
        }

        binding.btnConfirm.setOnClickListener {

            val cal1= Calendar.getInstance()
            val cal2= Calendar.getInstance()
            cal2.timeInMillis=codeTimeOut

            val diff: Long = cal1.timeInMillis - cal2.timeInMillis
            val seconds = diff / 1000
            val minutes = seconds / 60
            val hours = minutes / 60
            val days = hours / 24
            Log.e("OtpTimeOut","========\nseconds:$seconds,\nminutes:$minutes,\nhours:$hours,\ndays:$days")

            if(minutes<30 && hours<=0 && days<=0) {
                val strInput = binding.edtVeriCode.otp.toString().trim()
                if(strInput==veriCode) {
                    preferences.putSetPass(false)
                    preferences.putShowPinLock(true)
                    preferences.putSetPattern(false)
                    resetLockResultLauncher.launch(
                        Intent(
                            this,
                            ResetLockActivity::class.java
                        ).putExtra(Constant.EXTRA_RESET_PASS, true)
                    )
                } else {
                    setErrorAnimation(binding.edtVeriCode)
                    toast("Verification Code doesn't match, please check your mail.")
                }
            } else {
                toast("Verification Code expired, please try again.")
            }
        }

    }

    var resetLockResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == AppCompatActivity.RESULT_OK) {
            val intent=Intent(this, PrivateActivity::class.java)
            startActivity(intent)
            (this@OtpActivity).finish()
        } else {
            Log.e("LockFragment", "lockActivityResultLauncher:intView")
        }
    }

}