package gallery.gallerylock.vaultgallery.hidepictures.dialog

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
//import com.google.firebase.analytics.FirebaseAnalytics
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.databinding.DialogPrivateMenuBinding

class PrivateMenuDialog(val clickListener: (type: Int) -> Unit) : BottomSheetDialogFragment() {

    lateinit var binding: DialogPrivateMenuBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = DialogPrivateMenuBinding.inflate(layoutInflater, container, false)
        intView()
        return binding.root
    }

    private fun intView() {
        intListener()
    }

    private fun intListener() {
        binding.btnChangePass.setOnClickListener {
            dismiss()
            clickListener(1)
        }
        binding.btnChangeEmail.setOnClickListener {
            dismiss()
            clickListener(2)
        }
        binding.btnChangeQue.setOnClickListener {
            dismiss()
            clickListener(3)
        }
        binding.btnChangeLockStyle.setOnClickListener {
            dismiss()
            clickListener(4)
        }
        binding.btnFeedback.setOnClickListener {
//            val intent = Intent(activity, FeedbackActivity::class.java)
//            startActivity(intent)
            dismiss()
            clickListener(5)
        }
        binding.btnSetting.setOnClickListener {
            dismiss()
            clickListener(6)
        }
        binding.btnRecycleBin.setOnClickListener {
            dismiss()
            clickListener(7)
        }
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}