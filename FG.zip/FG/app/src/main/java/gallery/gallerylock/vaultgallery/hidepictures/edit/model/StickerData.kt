package gallery.gallerylock.vaultgallery.hidepictures.edit.model

import android.content.res.TypedArray

data class StickerData(var name: String, var stickerList: TypedArray)
