package gallery.gallerylock.vaultgallery.hidepictures.edit

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.view.doOnPreDraw
import com.adconfig.adsutil.admob.BannerAdHelper
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.google.android.gms.ads.AdView
import gallery.gallerylock.vaultgallery.hidepictures.R

import gallery.gallerylock.vaultgallery.hidepictures.base.BaseActivity
import gallery.gallerylock.vaultgallery.hidepictures.databinding.ActivityAdjustBinding
import gallery.gallerylock.vaultgallery.hidepictures.dialog.ProgressDialog
import gallery.gallerylock.vaultgallery.hidepictures.edit.model.AdjustModel
import gallery.gallerylock.vaultgallery.hidepictures.extension.updateStatusBarColor
import gallery.gallerylock.vaultgallery.hidepictures.utils.AdCache
import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant
import gallery.gallerylock.vaultgallery.hidepictures.utils.Preferences
import org.wysaid.view.ImageGLSurfaceView


class AdjustActivity : BaseActivity() {

    lateinit var binding: ActivityAdjustBinding
    private var imagePath = ""
    private var saveImageName = ""
    private var sourceImgBitmap: Bitmap? = null
    private var adjustList: ArrayList<AdjustModel> = ArrayList()
    private lateinit var adjustModel: AdjustModel
    private var currentPos = -1
    private val brightnessPos = 0
    private val contrastPos = 1
    private val saturationPos = 2
    private val sharpenPos = 3

    val BASIC_FILTER_CONFIG =
        "@adjust brightness 0 @adjust contrast 1 @adjust saturation 1 @adjust sharpen 0"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAdjustBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateStatusBarColor(Color.parseColor("#131624"))

        intView()
        loadBanner()
    }

    var isAdLoaded=false
    var mAdView: AdView?=null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }
    private fun loadBanner() {


    }
    private fun intView() {


        imagePath = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_PATH) ?: ""
        saveImageName = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_NAME) ?: ""

        binding.txtTitle.text = getString(R.string.Contrast)
        adjustList.add(AdjustModel(
                1,
                0.1f,
                1.0f,
                3.0f
            )
        )  //contrast
        adjustList.add(AdjustModel(
            0,
            -1.0f,
            0.0f,
            1.0f
        )
        )   //brightness
        adjustList.add(AdjustModel(
                2,
                0.0f,
                1.0f,
                3.0f
            )
        )  //saturation
        adjustList.add(AdjustModel(
                3,
                -1.0f,
                0.0f,
                10.0f
            )
        )   //sharpen


        intListener()
        binding.mainImageView.holder.setFormat(PixelFormat.TRANSLUCENT)
        binding.mainImageView.setZOrderOnTop(true)
        binding.mainImageView.setSurfaceCreatedCallback {
            Log.e("EDITTAG", "setSurfaceCreatedCallback")
            Glide
                .with(this)
                .asBitmap()
                .load(imagePath)
                .into(object : CustomTarget<Bitmap>() {
                    override fun onResourceReady(
                        resource: Bitmap,
                        transition: Transition<in Bitmap>?
                    ) {
                        sourceImgBitmap = resource
                        binding.mainImageView.setImageBitmap(sourceImgBitmap)
                        binding.mainImageView.setFilterWithConfig(BASIC_FILTER_CONFIG)
                        binding.mainImageView.displayMode =
                            ImageGLSurfaceView.DisplayMode.DISPLAY_ASPECT_FIT

                    }

                    override fun onLoadCleared(placeholder: Drawable?) {

                    }
                })
        }
        binding.mainImageView.doOnPreDraw {
            Log.e("EDITTAG", "doOnPreDraw")
        }

        updateAdjustSelected(0)
    }

    private fun intListener() {
        binding.icBack.setOnClickListener { onBackPressed() }
        binding.ivDone.setOnClickListener {
            binding.mainImageView.getResultBitmap {
                runOnUiThread {
                    if (it != null) {
                        val progressDialog = ProgressDialog(
                            this@AdjustActivity,
                            0,
                            0,
                            getString(R.string.saving),
                            ""
                        )
                        progressDialog.show(supportFragmentManager, progressDialog.tag)
                        Thread {
                            val imagePath = saveEditImage(it, saveImageName)
                            runOnUiThread {
                                if (imagePath != null) {
                                    val intent = Intent()
                                    intent.putExtra(Constant.EXTRA_EDIT_SAVE_IMAGE, imagePath)
                                    setResult(RESULT_OK, intent)
                                }
                                progressDialog.dismiss()
                                finish()
                            }
                        }.start()
                    } else {
                        Toast.makeText(
                            this,
                            getString(R.string.image_editing_failed),
                            Toast.LENGTH_SHORT
                        )
                            .show()
                    }
                }
            }
        }

        binding.adjustLevel.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, i: Int, z: Boolean) {
                if (::adjustModel.isInitialized)
                    adjustModel.setIntensity(
                        binding.mainImageView,
                        i / seekBar!!.max.toFloat(), true
                    )
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {

            }

            override fun onStopTrackingTouch(p0: SeekBar?) {

            }

        })
        binding.btnBrightness.setOnClickListener { updateAdjustSelected(brightnessPos) }
        binding.btnContrast.setOnClickListener { updateAdjustSelected(contrastPos) }
        binding.btnSaturation.setOnClickListener { updateAdjustSelected(saturationPos) }
        binding.btnSharpen.setOnClickListener { updateAdjustSelected(sharpenPos) }

    }

    private fun updateAdjustSelected(pos: Int) {
        if (currentPos != pos) {
            currentPos = pos
            adjustModel = adjustList[currentPos]
            binding.adjustLevel.progress =
                (adjustModel.slierIntensity * (binding.adjustLevel.max.toFloat())).toInt()
            when (currentPos) {
                brightnessPos -> {
                    unSelectAll()
                    setSelectTab(binding.ivBrightness, binding.tvBrightness)
                }

                saturationPos -> {
                    unSelectAll()
                    setSelectTab(binding.ivSaturation, binding.tvSaturation)
                }

                contrastPos -> {
                    unSelectAll()
                    setSelectTab(binding.ivContrast, binding.tvContrast)
                }

                sharpenPos -> {
                    unSelectAll()
                    setSelectTab(binding.ivSharpen, binding.tvSharpen)
                }
            }
        }
    }

    private fun unSelectAll() {
//        val selectColor = ContextCompat.getColor(this, R.color.home_unSelect_tab_icon)
        val selectColor = Color.parseColor("#A1A2A7")
        binding.ivBrightness.setColorFilter(selectColor, PorterDuff.Mode.SRC_IN)
        binding.ivSaturation.setColorFilter(selectColor, PorterDuff.Mode.SRC_IN)
        binding.ivContrast.setColorFilter(selectColor, PorterDuff.Mode.SRC_IN)
        binding.ivSharpen.setColorFilter(selectColor, PorterDuff.Mode.SRC_IN)

        binding.tvBrightness.setTextColor(selectColor)
        binding.tvSaturation.setTextColor(selectColor)
        binding.tvContrast.setTextColor(selectColor)
        binding.tvSharpen.setTextColor(selectColor)

    }

    private fun setSelectTab(imageView: ImageView, textView: TextView) {
        val selectColor = ContextCompat.getColor(this, R.color.color_primary)
        imageView.setColorFilter(selectColor, PorterDuff.Mode.SRC_IN)
        textView.setTextColor(selectColor)
    }

}