package gallery.gallerylock.vaultgallery.hidepictures.dialog

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.os.Environment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.core.widget.addTextChangedListener
import androidx.viewbinding.ViewBinding
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.databinding.DialogCreateAlbumBinding
import gallery.gallerylock.vaultgallery.hidepictures.databinding.DialogCreateAlbumDarkBinding
import gallery.gallerylock.vaultgallery.hidepictures.extension.toast
import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant
import gallery.gallerylock.vaultgallery.hidepictures.utils.Preferences
import java.io.File

class CreateAlbumDialog(
    var mContext: Context,
    val createPathListener: (path: String) -> Unit,
    var isOpenFromMenu: Boolean = false,
    val useDarkMode:Boolean?=false
) :
    BottomSheetDialogFragment() {

    var preferences: Preferences = Preferences(mContext)
//    lateinit var bindingDialog: DialogCreateAlbumBinding
    lateinit var bindingDialog: ViewBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogCreateAlbumBinding.inflate(layoutInflater, container, false)
        if(useDarkMode!!) bindingDialog = DialogCreateAlbumDarkBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {
//        bindingDialog.icClear.visibility = View.GONE
        bindingDialog.root.findViewById<ImageView>(R.id.icClear).visibility = View.GONE
        intListener()
    }

    private fun intListener() {
//        bindingDialog.edtAlbumName.addTextChangedListener {
        bindingDialog.root.findViewById<EditText>(R.id.edtAlbumName).addTextChangedListener {
//            bindingDialog.icClear.visibility =
            bindingDialog.root.findViewById<ImageView>(R.id.icClear).visibility =
//                if (bindingDialog.edtAlbumName.text?.trim().toString()
                if (bindingDialog.root.findViewById<EditText>(R.id.edtAlbumName).text?.trim().toString()
                        .isNotEmpty()
                ) View.VISIBLE else View.GONE
        }

//        bindingDialog.icClear.setOnClickListener {
        bindingDialog.root.findViewById<ImageView>(R.id.icClear).setOnClickListener {
            bindingDialog.root.findViewById<EditText>(R.id.edtAlbumName).setText("")
//            bindingDialog.edtAlbumName.setText("")
        }
//        bindingDialog.btnCreate.setOnClickListener {
        bindingDialog.root.findViewById<TextView>(R.id.btnCreate).setOnClickListener {
            val albumName = bindingDialog.root.findViewById<EditText>(R.id.edtAlbumName).text.trim()
            if (albumName.isNotEmpty()) {

                var file = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).path + File.separator + albumName)

                if(useDarkMode!!) {
                    file = File(Constant.HIDE_PATH+ File.separator + albumName)
                }
                if (!file.exists()) {
                    if (!isOpenFromMenu)
                        file.mkdirs()
                    dismiss()
//                    preferences.setLastAlBumCreated(file.path)
                    createPathListener(file.path)
                } else
                    mContext.toast(getString(R.string.create_validation2))
            } else

                mContext.toast(getString(R.string.create_validation))
        }
//        bindingDialog.btnCancel.setOnClickListener {
        bindingDialog.root.findViewById<TextView>(R.id.btnCancel).setOnClickListener {
            dismiss()
        }
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}