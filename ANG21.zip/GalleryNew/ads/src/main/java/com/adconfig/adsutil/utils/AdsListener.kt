package com.adconfig.adsutil.utils

import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardItem
import com.google.android.gms.ads.rewarded.RewardedAd


data class AdsError(
    val code: Int,
    val error: String
)

interface AdsListener {
    fun onAdClicked()

    fun onAdDismissed()

    fun onAdLoaded(appOpenAd: Any)

    fun onAdLoaded()

    fun onAdFailedToShow(adsError: AdsError)
    fun onAdImpression()

    fun onAdShowed()

}

interface RewardAdCallBack {
    fun onAdImpression()
    fun onAdClicked()
    fun onAdLoaded(rewardedAd: Any)//RewardedInterstitialAd OR RewardedAd
    fun onAdClose()
    fun onAdFailedToShow(adsError: AdError)
    fun onAdFailedToLoad(adsError: LoadAdError)
    fun onUserEarnedReward(rewardItem: RewardItem?)
    fun onRewardShow()
}