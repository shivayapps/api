package com.adconfig.adsutil.reward

import android.app.Activity
import android.content.Context
import com.adconfig.adsutil.utils.RewardAdCallBack

import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback
import kotlin.collections.get

object RewardedInterstitialAdHelper {

    fun requestRewardAd(context: Context, adId: String, adCallback: RewardAdCallBack) {
        RewardedInterstitialAd.load(context, adId, AdRequest.Builder().build(), object : RewardedInterstitialAdLoadCallback() {
            override fun onAdLoaded(rewardedAd: RewardedInterstitialAd) {
                adCallback.onAdLoaded(rewardedAd)
            }

            override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                adCallback.onAdFailedToLoad(loadAdError)
            }
//            override fun onAdLoaded(rewardedAd: RewardedAd) {
//                adCallback.onAdLoaded(rewardedAd)
//            }
//
//            override fun onAdFailedToLoad(loadAdError: LoadAdError) {
//                adCallback.onAdFailedToLoad(loadAdError)
//            }
        })
    }


    fun showRewardAd(
        activity: Activity,
        rewardedAd: RewardedInterstitialAd,
        adCallback: RewardAdCallBack
    ) {

        rewardedAd.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                super.onAdDismissedFullScreenContent()
                adCallback.onAdClose()
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                super.onAdFailedToShowFullScreenContent(adError)
                adCallback.onAdFailedToShow(adError)
            }

            override fun onAdShowedFullScreenContent() {
                super.onAdShowedFullScreenContent()
                adCallback.onRewardShow()
            }

            override fun onAdClicked() {
                super.onAdClicked()
                adCallback.onAdClicked()
            }

            override fun onAdImpression() {
                super.onAdImpression()
                adCallback.onAdImpression()
            }
        }
        rewardedAd.show(activity) { rewardItem ->
            adCallback.onUserEarnedReward(rewardItem)
        }
    }


}