package com.photogallery.activities

import android.annotation.SuppressLint
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.AdsConfig
import com.adconfig.adsutil.Config.checkReInter
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.bumptech.glide.Glide
import com.photogallery.R
import com.photogallery.adapter.PhotoAdapter
import com.photogallery.adapter.TimeLineAdapter
import com.photogallery.base.BaseActivity
import com.photogallery.customview.MyGridLayoutManager
import com.photogallery.model.AlbumData
import com.photogallery.databinding.ActivityTimelineBinding
import com.photogallery.extension.getParentFolder
import com.photogallery.model.MediaData
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences
import com.photogallery.utils.TYPE_GIFS
import com.photogallery.utils.TYPE_IMAGES
import com.photogallery.utils.TYPE_VIDEOS
import com.photogallery.utils.photoExtensions
import com.photogallery.utils.rawExtensions
import com.photogallery.utils.videoExtensions
import com.photogallery.viewpager.PhotoVideoActivity
import com.google.android.material.datepicker.MaterialDatePicker
import com.photogallery.jobs.TimeLineLoaderX
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale


class TimeLineActivity : BaseActivity() {

//    var albumWisePictures = LinkedHashMap<String, ArrayList<MediaData>>()
    var allBackList = ArrayList<MediaData>()

    var allList = ArrayList<Any>()
    var timeList: ArrayList<AlbumData> = ArrayList()

    var timeLineAdapter: TimeLineAdapter? = null
    var searchAdapter: PhotoAdapter? = null

    var startDate = 0L
    var endDate = 0L

    var timeLineLoader: TimeLineLoaderX? = null

    lateinit var preferences: Preferences
    lateinit var binding: ActivityTimelineBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        if (preferences.isNeedInterAd) {
            AdmobIntersAdImpl().load(this, getString(R.string.inter_all))
        } else {
            checkReInter {
                if (it) {
                    AdmobIntersAdImpl().load(this, getString(R.string.inter_all))
                    preferences.isNeedInterAd = true
                }
            }
        }
        binding = ActivityTimelineBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        initView()
    }

    private fun initView() {
        binding.txtTitle.text = getString(R.string.timeline)
        binding.icBack.setOnClickListener {
            onBackPressed()
        }

        binding.icMenu.setOnClickListener {

            val dateRangePicker = MaterialDatePicker.Builder
                .dateRangePicker()
                .setTitleText("Select Date")
                .build()

            dateRangePicker.show(
                supportFragmentManager,
                dateRangePicker.tag
            )
            dateRangePicker.addOnPositiveButtonClickListener { dateSelected ->

                val startDate = dateSelected.first
                val endDate = dateSelected.second

                if (startDate != null && endDate != null) {
                    val strStartDate = SimpleDateFormat(
                        "dd MMM yyyy",
                        Locale.ENGLISH
                    ).format(startDate)

                    val strEndDate = SimpleDateFormat(
                        "dd MMM yyyy", Locale.ENGLISH
                    ).format(endDate)

                    binding.txtSearchDate.text = "$strStartDate - $strEndDate"

                    setListTimeRange(startDate, endDate)
                    //binding.tvRangeDate.text = "Reserved\nStartDate: ${convertLongToTime(startDate)}\nEndDate: ${convertLongToTime(endDate)}"
                }
            }
        }

        initAdapters()

        getTimeLineData()
    }


    override fun onBackPressed() {
        if (preferences.isNeedInterAd) {

            AdsConfig.showInterstitialAd(this) {
                if (it) preferences.isNeedInterAd = false
                finish()
            }
        } else {
            super.onBackPressed()
        }
    }


    fun hideKeyboard(view: EditText) {
        view.clearFocus()
        val methodManager = (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.hideSoftInputFromWindow(view.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
    }

    private fun showKeyboard(view: EditText) {
        view.requestFocus()
        val methodManager = (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun openCutomImageList(albumData: AlbumData) {
        Constant.albumData = AlbumData(
            albumData.title,
            albumData.mediaData,
            "",
            0,
            0,
            isCustomAlbum = true
        )
        val intent = Intent(this, ImageGalleryActivity::class.java)
        if (albumData.lati > 0 && albumData.long > 0) {
            intent.putExtra("isFromMap", true)
            intent.putExtra("lati", albumData.lati)
            intent.putExtra("long", albumData.long)
        }
        startActivity(intent)
    }

    private fun initAdapters() {
        Log.e("timeLine", "initAdapters.001")

        timeLineAdapter = TimeLineAdapter(this, clickListener = { albumData ->
            openCutomImageList(albumData)
        })
        timeLineAdapter?.submitList(timeList)
        binding.timeLineRecycler.layoutManager =
            GridLayoutManager(this, 1, GridLayoutManager.HORIZONTAL, false)
        binding.timeLineRecycler.setHasFixedSize(false)
        binding.timeLineRecycler.adapter = timeLineAdapter

        //Init Search Adapter
        allList = ArrayList()
        searchAdapter = PhotoAdapter(
            this,
            clickListener = {
                if (allList[it] is MediaData) {
                    val mediaData = allList[it] as MediaData
                    if (mediaData.isCheckboxVisible) {
                        mediaData.isSelected = !mediaData.isSelected
                        searchAdapter?.notifyItemChanged(it)
//                        setSelectedFile()
                    } else {
                        val dataList = ArrayList<MediaData>()
                        var displayPos = 0
                        for (i in allList.indices) {
                            if (allList[i] is MediaData) {
                                dataList.add(allList[i] as MediaData)
                                if (it == i) {
                                    displayPos = dataList.size - 1
                                }
                            }
                        }
                        Constant.displayImageList = ArrayList()
                        Constant.displayImageList.addAll(dataList)
                        Constant.selectedPosition = displayPos
//                        val intent = Intent(this@SearchActivity, ImageViewerActivity::class.java)
                        if (Constant.displayImageList.size > 0) {
                            val intent = Intent(this@TimeLineActivity, PhotoVideoActivity::class.java)
                            intent.putExtra(Constant.EXTRA_DISPLAY_POS, displayPos)
                            startActivity(intent)
                        }
//                        selectAlbum()
                    }
                }
            },
            longClickListener = {

            },
            headerSelectListener = {

            }, needShowMore = true, showMoreAfter = 100
        )
        searchAdapter?.submitList(allList)
        val layoutManager = binding.searchRecycler.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = 3
        layoutManager.orientation = RecyclerView.VERTICAL
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                if (position >= 0 && position < allList.size) {
                    return if (searchAdapter!!.getItemViewType(position) === searchAdapter!!.ITEM_HEADER_TYPE) {
                        3
                    } else 1
                } else {
                    return 1
                }
            }
        }
        binding.searchRecycler.adapter = searchAdapter
    }

    private fun setTimeLineData() {
        Log.e("timeLine", "setData.001")
//        isUpadteList = false

        runOnUiThread {
            Log.e("timeLine", "setData.002")
            notifyAdapter()
            setEmptyData()
        }

    }


    private fun setEmptyData() {
        if (allList != null && allList.size != 0) {
            binding.searchRecycler.visibility = View.VISIBLE
//            binding.loutNoData.visibility = View.GONE
        } else {
            binding.searchRecycler.visibility = View.GONE
//            binding.loutNoData.visibility = View.VISIBLE
        }
    }


    private fun openAlbumList(key: String, albumData: ArrayList<AlbumData>) {
        Constant.albumList = albumData
//        setBackAlbumData()
//        intent.putExtra("title","TimeLine")
        val intent = Intent(this, AlbumExplorerActivity::class.java)
        intent.putExtra("title", "$key")
        intent.putExtra("showTimeline", true)
        startActivity(intent)
    }

    private fun setBackAlbumData() {
        Constant.albumList.clear()
        for (albumData in timeList) {
            if (albumData is AlbumData) {
                Constant.albumList.add(
                    AlbumData(
                        albumData.title,
                        albumData.mediaData,
                        albumData.folderPath,
                        albumData.date,
                        albumData.fileSize
                    )
                )
            }
        }
    }

//    var isUpadteList = false
//    fun setFilterData() {
//        isUpadteList = true
////        disableScroll()
//        GlobalScope.launch(Dispatchers.IO) {
////            setList()
////            runOnUiThread {
////                setData()
//            getTimeLine()
////            }
//        }
//    }

    public fun getTimeLineData() {
//        isUpadteList = true

        timeLineLoader = TimeLineLoaderX(
            this,
            sortOrder = preferences.getSortOrder("frag_0"),
            sortType = preferences.getSortType("frag_0"),
            prefKey = "frag_0"
        )
        timeLineLoader?.destroyLoader()
        timeLineLoader?.getAllData({ groupedMediaList, mediaList, customAlbumList ->
            timeList.clear()
            timeList.addAll(customAlbumList)

            allBackList.clear()
            allBackList.addAll(mediaList)

            Log.e("AlbumRenameDialog", "albumList.size:${timeList.size}")

            runOnUiThread {
                timeLineAdapter?.notifyDataSetChanged()
//                binding.searchTab.timeLineRecycler.suppressLayout(false)
                //binding.searchTab.swipeRefreshAlbum.isRefreshing = false
//                setSearchData()
            }
        })


//        Glide.get(this).clearMemory()
//        Observable.fromCallable {
//            Glide.get(this).clearDiskCache()
//            allList.clear()
//
////            videoCount = 0
////            imageCount = 0
//            getImages()
//            getVideos()
//            true
//        }.subscribeOn(Schedulers.io())
//            .doOnError { throwable: Throwable? ->
////                runOnUiThread {
//                setFilterData()
////                    getFindCount()
////                }
//            }
//            .subscribe { result: Boolean? ->
////                runOnUiThread {
//                setFilterData()
////                    getFindCount()
////                }
//            }
    }


//    private fun getImages() {
//        Log.e("gettingListPhoto", "getImages")
//        val mCursor: Cursor?
//        val folderList: MutableList<String> = ArrayList<String>()
////        folderList.addAll(preferencesManager.getExcludeFolderList())
//        val favList: ArrayList<String> = ArrayList()
//        favList.addAll(preferences.getFavoriteList())
//        try {
//            val BUCKET_DISPLAY_NAME: String
//            BUCKET_DISPLAY_NAME = MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
//            val projection = arrayOf(
//                MediaStore.Images.Media._ID,
//                MediaStore.Images.Media.DATA,
//                BUCKET_DISPLAY_NAME,
//                MediaStore.MediaColumns.DATE_MODIFIED,
//                MediaStore.MediaColumns.DATE_TAKEN,
//                MediaStore.MediaColumns.DISPLAY_NAME,
//                MediaStore.MediaColumns.SIZE,
//            )
//            val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
//                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
//            } else {
//                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
//            }
//
//            val filterMedia = preferences.getFilterMedia()
//            val selection = getSelectionQuery(filterMedia)
//            val selectionArgs = getSelectionArgsQuery(filterMedia).toTypedArray()
//
//            mCursor = contentResolver.query(
//                uri,  // Uri
//                projection,  // Projection
//                selection,
//                selectionArgs,
//                MediaStore.MediaColumns.DATE_MODIFIED + " DESC"
//            )
//            if (mCursor != null) {
//                mCursor.moveToFirst()
//                val photoDataArrayList: ArrayList<MediaData> = ArrayList<MediaData>()
//                mCursor.moveToFirst()
//                while (!mCursor.isAfterLast) {
//                    //2sec
//                    val path =
//                        mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))
//                    val title =
//                        mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME))
//                    var bucketPath = ""
//                    bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
//
//                    var bucketName =
//                        mCursor.getString(mCursor.getColumnIndexOrThrow(BUCKET_DISPLAY_NAME))
//                    if (bucketName == null) bucketName = path.getParentFolder()
//
//                    val fileSizeLength =
//                        mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
//
//                    val idColumn = mCursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
//                    val id = mCursor.getLong(idColumn)
//                    val contentUri = ContentUris.withAppendedId(uri, id)
//
//
//                    if (!folderList.contains(bucketPath) && !bucketName.isNullOrEmpty()) {
//                        var d =
//                            mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED))
//                        d *= 1000
//                        var dt =
//                            mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))
//                        dt *= 1000
//                        if (dt == 0L)
//                            dt = d
//
//                        val pictureData =
//                            MediaData(path, contentUri.toString(), title, bucketName, d, dt, fileSizeLength, false)
//                        pictureData.isFavorite = favList.contains(path)
////                        allList.add(pictureData)
//                        allBackList.add(pictureData)
//
////                        imageCount++
//                    }
//                    mCursor.moveToNext()
//                }
//                mCursor.close()
//            }
//        } catch (e: Exception) {
//            Log.e("printStackTrace", "printStackTrace:$e")
//        }
//    }

//    private fun getVideos() {
//        Log.e("gettingListPhoto", "getVideos")
//        var title: String
//        var path: String
//        val duration: Int
//        val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
//            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
//        } else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
//        val projection = arrayOf(
//            MediaStore.Video.VideoColumns._ID,
//            MediaStore.Video.VideoColumns.DATA,
//            MediaStore.Video.Media.DISPLAY_NAME,
//            MediaStore.Video.VideoColumns.SIZE,
//            MediaStore.Video.VideoColumns.DURATION,
//            MediaStore.Video.VideoColumns.DATE_MODIFIED,
//            MediaStore.Video.VideoColumns.DATE_TAKEN,
//            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
//        )
//        val folderList: MutableList<String> = ArrayList<String>()
////        folderList.addAll(preferencesManager.getExcludeFolderList())
//        val favList: ArrayList<String> = ArrayList()
//        favList.addAll(preferences.getFavoriteList())
//        try {
//            val filterMedia = preferences.getFilterMedia()
//            val selection = getSelectionQuery(filterMedia)
//            val selectionArgs = getSelectionArgsQuery(filterMedia).toTypedArray()
//
//            val cursor = contentResolver.query(
//                uri,
//                projection,
//                selection,
//                selectionArgs,
//                MediaStore.Video.VideoColumns.DATE_MODIFIED + " DESC"
//            )
//            if (cursor != null) {
//                duration = cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DURATION)
//                cursor.moveToFirst()
//                while (!cursor.isAfterLast) {
//                    path =
//                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA))
//                    title =
//                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME))
//                    var bucketName =
//                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME))
//                    if (bucketName == null) bucketName = path.getParentFolder()
//                    val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns._ID)
//                    val id = cursor.getLong(idColumn)
//                    val contentUri = ContentUris.withAppendedId(uri, id)
//
//                    var bucketPath = ""
//                    bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
//                    if (!folderList.contains(bucketPath)) {
//                        var d =
//                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DATE_MODIFIED))
//                        d *= 1000
//                        val fileSizeLength =
//                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
//                        var dt =
//                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))
//                        dt *= 1000
//                        if (dt == 0L)
//                            dt = d
//                        val pictureData = MediaData(
//                            path,
//                            contentUri.toString(),
//                            title,
//                            bucketName,
//                            d,
//                            dt,
//                            fileSizeLength,
//                            true,
//                            cursor.getLong(duration)
//                        )
//                        pictureData.isFavorite = favList.contains(path)
//                        pictureData.isVideo = true
////                        allList.add(pictureData)
//                        allBackList.add(pictureData)
//
////                        videoCount++
//                    }
//                    cursor.moveToNext()
//                }
//                cursor.close()
//            }
//        } catch (exp: java.lang.Exception) {
//            exp.printStackTrace()
//        }
//    }

    @SuppressLint("NotifyDataSetChanged")
    private fun notifyAdapter() {

        Log.e("timeLine", "notifyAdapter.001-${allList.size}")
        if (searchAdapter != null) {
            Log.e("timeLine", "notifyAdapter.002")
//            searchAdapter?.pictures=allList
//            searchAdapter?.notifyDataSetChanged()
            CoroutineScope(Dispatchers.IO).launch {
//                val data = fetchDataFromNetworkOrDatabase() // heavy operation
                withContext(Dispatchers.Main) {
//                    searchAdapter.updateData(data) // update adapter data
                    searchAdapter?.notifyDataSetChanged()
                }
            }
        } else initAdapters()

//        if (timeLineAdapter != null)
//            timeLineAdapter?.notifyDataSetChanged()
    }


    private fun getSelectionQuery(filterMedia: Int): String {
        val query = StringBuilder()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")

            rawExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }

//        if (filterMedia and TYPE_RAWS != 0) {
//            rawExtensions.forEach {
//                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//            }
//        }

//        if (filterMedia and TYPE_SVGS != 0) {
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//        }
//        if (filterMedia and TYPE_PORTRAITS != 0) {
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
        }


        if (filterMedia and TYPE_GIFS != 0) {
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }


        return query.toString().trim().removeSuffix("OR")
    }

    private fun getSelectionArgsQuery(filterMedia: Int): ArrayList<String> {
        val args = ArrayList<String>()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.jpg")
            args.add("%.jpeg")
            rawExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.svg")
        }

//        if (filterMedia and TYPE_RAWS != 0) {
//            rawExtensions.forEach {
//                args.add("%$it")
//            }
//        }
//
//        if (filterMedia and TYPE_SVGS != 0) {
//            args.add("%.svg")
//        }
//        if (filterMedia and TYPE_PORTRAITS != 0) {
//            args.add("%.jpg")
//            args.add("%.jpeg")
//        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                args.add("%$it")
            }
        }

        if (filterMedia and TYPE_GIFS != 0) {
            args.add("%.gif")
        }


        return args
    }

    //    fun setList1() {
////        binding.swipeRefreshLayout.isRefreshing = true
//        //allList.clear()
//        runOnUiThread { notifyAdapter() }
//
//        if (isSearch) runOnUiThread { notifyAdapter() }
//
//        val dateWisePictures = LinkedHashMap<String, ArrayList<PictureData>>()
//        var format = SimpleDateFormat("MMM yyyy")
//
//
////        val currentGrouping = preferences.getGroupBy()
////        format = when (currentGrouping) {
////            Constant.GROUP_BY_LAST_MODIFIED_DAILY -> SimpleDateFormat("dd MMM yyyy")
////            Constant.GROUP_BY_DATE_TAKEN_DAILY -> SimpleDateFormat("dd MMM yyyy")
////            Constant.GROUP_BY_LAST_MODIFIED_MONTHLY -> SimpleDateFormat("MMMM yyyy")
////            Constant.GROUP_BY_DATE_TAKEN_MONTHLY -> SimpleDateFormat("MMMM yyyy")
////            else -> SimpleDateFormat("dd MMM yyyy")
////        }
//
//        if (allList.size != 0) {
//            for (pictureData in allList) {
////                val strKey = format.format(pictureData.date)
//                var strKey = format.format(pictureData.date)
//
//                var imagesData1: ArrayList<PictureData> = ArrayList()
//                if (dateWisePictures.containsKey(strKey)) {
//                    val list: ArrayList<PictureData>? = dateWisePictures[strKey]
//                    if (!list.isNullOrEmpty())
//                        imagesData1.addAll(list)
//                } else {
//                    imagesData1 = ArrayList()
//                }
//                imagesData1.add(pictureData)
//                dateWisePictures[strKey] = imagesData1
//            }
//
//            val keys: Set<String> = dateWisePictures.keys
//            val listKeys = ArrayList(keys)
//
//            for (i in listKeys.indices) {
//                val imagesData = dateWisePictures[listKeys[i]]
//                if (imagesData != null && imagesData.size != 0) {
//                    val bucketData = AlbumData(listKeys[i], imagesData)
//                    pictures.add(bucketData)
//                    pictures.addAll(imagesData)
//                }
//            }
//        }
//    }
    private fun getTimeLine() {
        val dateWisePictures = LinkedHashMap<String, ArrayList<MediaData>>()

        val monthYearFormat = SimpleDateFormat("MMM yyyy", Locale.ENGLISH)
        val yearFormat = SimpleDateFormat("yyyy", Locale.ENGLISH)

        val calendar = Calendar.getInstance()
        val thisMonth = monthYearFormat.format(calendar.time)
        val thisYear = yearFormat.format(calendar.time)

        calendar.add(Calendar.MONTH, -1)
        val lastMonth = monthYearFormat.format(calendar.time)

        if (allBackList.isNotEmpty()) {
            for (pictureData in allBackList) {
                var strKey = monthYearFormat.format(pictureData.date)

                strKey = when {
                    strKey == thisMonth -> "This Month"
                    strKey == lastMonth -> "Last Month"
                    yearFormat.format(pictureData.date) == thisYear -> "This Year"
                    else -> yearFormat.format(pictureData.date)
                }

                val imagesData = dateWisePictures.getOrPut(strKey) { ArrayList() }
                imagesData.add(pictureData)
            }

            timeList.clear()
            for ((key, imagesData) in dateWisePictures) {
                if (imagesData.isNotEmpty()) {
                    val bucketData = AlbumData(
                        title = key,
                        mediaData = imagesData
                    )
                    timeList.add(bucketData)
                }
            }
        } else {
            timeList.clear()
        }

        runOnUiThread {
            timeLineAdapter?.notifyDataSetChanged()
        }
    }

    private fun setListTimeRange(startDate: Long, endDate: Long) {
        Log.e("timeLine", "setListTimeRange.startDate:$startDate")
        Log.e("timeLine", "setListTimeRange.endDate:$endDate")
//        timeRangeList.clear()
        allList.clear()
        if (startDate > 0 && endDate > 0) {
//            timeRangeList.addAll(allBackList.filter { it.date in (startDate + 1)..<endDate })
            allList.addAll(allBackList.filter { it.date in (startDate + 1)..<endDate })
        } else if (startDate == 0L) {
//            timeRangeList.addAll(allBackList.filter { it.date > startDate })
            allList.addAll(allBackList.filter { it.date > startDate })
        } else if (endDate == 0L) {
//            timeRangeList.addAll(allBackList.filter { it.date < endDate })
            allList.addAll(allBackList.filter { it.date < endDate })
        } else {
//            timeRangeList.clear()
            allList.clear()
        }

        Log.e("timeLine", "ListTimeRange.size:${allList.size}")

        setTimeLineData()

    }

}