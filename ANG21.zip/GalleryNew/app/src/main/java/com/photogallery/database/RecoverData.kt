package com.photogallery.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "recoverData")
data class RecoverData(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0
    , var path: String
    , var isVideo: Int=0
)