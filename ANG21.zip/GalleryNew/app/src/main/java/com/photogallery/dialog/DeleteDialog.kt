package com.photogallery.dialog

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import com.photogallery.databinding.DialogDeleteBinding
import com.photogallery.extension.beGoneIf
import com.photogallery.extension.beVisibleIf


class DeleteDialog(
    var mContext: Context,
    var showPermanentOnly: Boolean = true
) : Dialog(mContext) {

    var btnClickListener: ((isPermanent: Boolean) -> Unit)? = null
    var useDarkMode: Boolean? = false

    companion object {
        fun newInstance(mContext: Context, btnClickListener: ((isPermanent: Boolean) -> Unit)?, darkMode: Boolean? = true, showPermanent: Boolean = true): DeleteDialog {
            val deleteDialog = DeleteDialog(mContext, showPermanent)
            deleteDialog.btnClickListener = btnClickListener
            deleteDialog.useDarkMode = darkMode
            return deleteDialog
        }
    }

    lateinit var bindingDialog: DialogDeleteBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        window?.attributes?.windowAnimations = android.R.style.Animation_Dialog
//        window?.decorView!!.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        bindingDialog = DialogDeleteBinding.inflate(layoutInflater)
//        bindingDialog.root.setPadding(0, 0, 0, mContext.navigationBarHeight)
//        if (useDarkMode!!) bindingDialog = DialogDeleteDarkBinding.inflate(layoutInflater)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
    }

//    override fun onCreateView(
//        inflater: LayoutInflater, container: ViewGroup?,
//        savedInstanceState: Bundle?
//    ): View {
//        bindingDialog = DialogDeleteBinding.inflate(layoutInflater, container, false)
//        if (useDarkMode!!) bindingDialog = DialogDeleteDarkBinding.inflate(layoutInflater, container, false)
//        intView()
//        return bindingDialog.root
//    }

    private fun intView() {
        bindingDialog.btnDelete.beVisibleIf(showPermanentOnly)
        bindingDialog.txtRestoredMsg.beGoneIf(showPermanentOnly)

        bindingDialog.btnCancel.setOnClickListener { dismiss() }
        bindingDialog.btnDelete.setOnClickListener {
            dismiss()
            btnClickListener?.invoke(false)
        }
        bindingDialog.btnPermanent.setOnClickListener {
            dismiss()
            btnClickListener?.invoke(true)
        }
    }

//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)
}