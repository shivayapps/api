package com.photogallery.secret.fragment

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.Toast
import androidx.appcompat.widget.AppCompatImageView
import androidx.core.content.ContextCompat
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.Fragment
import com.andrognito.patternlockview.PatternLockView
import com.andrognito.patternlockview.listener.PatternLockViewListener
import com.andrognito.patternlockview.utils.PatternLockUtils
//import com.google.firebase.analytics.FirebaseAnalytics
import com.photogallery.R
import com.photogallery.databinding.FragmentLockBinding
import com.photogallery.utils.Preferences

class LockChangeStyleFragment(
    var activity: Activity,
    private val isShowPinLock: Boolean = false,
    val lockListener: (icUnLock: Boolean) -> Unit
) : Fragment() {

    lateinit var binding: FragmentLockBinding
    lateinit var preferences: Preferences
    var temp = 0
    var passcode = ""
    //lateinit var firebaseAnalytics: FirebaseAnalytics

    //    var isShowPinLock = false
    lateinit var animation: Animation


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLockBinding.inflate(layoutInflater, container, false)
        preferences = Preferences(activity)
        animation = AnimationUtils.loadAnimation(activity, R.anim.anim_shake)
        intView()
        initListener()
        return binding.root
    }

    private fun setErrorAnimation(view: View) {
        view.startAnimation(animation)
    }

    fun intView() {
        if (::binding.isInitialized) {
            binding.pass.setText("")
            binding.patterLockView.clearPattern()

            setLockViewUpdate()
            binding.btnSwitch.visibility = View.GONE
            binding.forgot.visibility = View.GONE

            if (isShowPinLock) {
                binding.title.text = getString(R.string.set_your_pin)
            } else {
                binding.title.text = getString(R.string.draw_an_unlock_pattern)
            }
        }
    }

    private fun setLockViewUpdate() {
        if (isShowPinLock) {
            binding.patterLockView.visibility = View.GONE
            binding.tvErrorMsg.visibility = View.GONE
            binding.loutPinNumber.visibility = View.VISIBLE
            binding.loutPinDots.visibility = View.VISIBLE
            binding.txtSwitch.text = getString(R.string.switch_to_pattern)

        } else {
            binding.patterLockView.visibility = View.VISIBLE
            binding.tvErrorMsg.visibility = View.INVISIBLE
            binding.loutPinNumber.visibility = View.INVISIBLE
            binding.loutPinDots.visibility = View.GONE
            binding.txtSwitch.text = getString(R.string.switch_to_pin)
        }
    }

    private fun inputTextData(s: String) {
        binding.pass.setText("${binding.pass.text.toString().trim()}$s")
    }

    private fun initListener() {
        binding.btnNo0.setOnClickListener {
            inputTextData("0")
        }
        binding.btnNo1.setOnClickListener {
            inputTextData("1")
        }
        binding.btnNo2.setOnClickListener {
            inputTextData("2")
        }
        binding.btnNo3.setOnClickListener {
            inputTextData("3")
        }
        binding.btnNo4.setOnClickListener {
            inputTextData("4")
        }
        binding.btnNo5.setOnClickListener {
            inputTextData("5")
        }
        binding.btnNo6.setOnClickListener {
            inputTextData("6")
        }
        binding.btnNo7.setOnClickListener {
            inputTextData("7")
        }
        binding.btnNo8.setOnClickListener {
            inputTextData("8")
        }
        binding.btnNo9.setOnClickListener {
            inputTextData("9")
        }

        binding.clear.setOnClickListener {
            if (binding.pass.text.isNotEmpty()) {
                binding.pass.setText(
                    binding.pass.text.toString().substring(0, binding.pass.length() - 1)
                )
                binding.pass.setSelection(binding.pass.text.length)
            }
        }

        binding.patterLockView.addPatternLockListener(object : PatternLockViewListener {
            override fun onStarted() {
                Log.d("TAGPATTERN", "onStarted ")
                binding.tvErrorMsg.visibility = View.INVISIBLE
            }

            override fun onProgress(progressPattern: MutableList<PatternLockView.Dot>?) {

            }

            override fun onComplete(pattern: MutableList<PatternLockView.Dot>?) {
                val strPattern = PatternLockUtils.patternToString(binding.patterLockView, pattern)
                Log.d(
                    "TAGPATTERN", "Pattern complete: $strPattern"
                )
                if (strPattern.length < 4)
                    setPatterErrorMsg(getString(R.string.patter_validation))
                else
                    setNextPatternScreen(strPattern)


            }

            override fun onCleared() {
                Log.d("TAGPATTERN", "onCleared ")
            }
        })

        binding.pass.addTextChangedListener {
            val length = it?.length
            when (length) {
                0 -> {
                    unSelectDot(binding.p1)
                    unSelectDot(binding.p2)
                    unSelectDot(binding.p3)
                    unSelectDot(binding.p4)
                }

                1 -> {
                    selectDot(binding.p1)
                    unSelectDot(binding.p2)
                    unSelectDot(binding.p3)
                    unSelectDot(binding.p4)
                }

                2 -> {
                    selectDot(binding.p1)
                    selectDot(binding.p2)
                    unSelectDot(binding.p3)
                    unSelectDot(binding.p4)
                }

                3 -> {
                    selectDot(binding.p1)
                    selectDot(binding.p2)
                    selectDot(binding.p3)
                    unSelectDot(binding.p4)
                }

                4 -> {
                    selectDot(binding.p1)
                    selectDot(binding.p2)
                    selectDot(binding.p3)
                    selectDot(binding.p4)
                }
            }
            if (length == 4) {
                setNextScreen()
            }
        }
    }


    private fun setNextPatternScreen(strPattern: String) {
        if (temp == 0) {
            passcode = strPattern
            temp = 1
            binding.patterLockView.setViewMode(PatternLockView.PatternViewMode.CORRECT)
            Handler(Looper.myLooper()!!).postDelayed({
                binding.title.text = getString(R.string.draw_pattern_again)
                binding.patterLockView.clearPattern()
            }, 20)
        } else {
            if (passcode == strPattern) {
                preferences.putPattern(passcode)
                Log.e("LockFragment","pattern_change_successfully-001")
                binding.patterLockView.setViewMode(PatternLockView.PatternViewMode.CORRECT)
                Toast.makeText(
                    activity, getString(
                        R.string.pattern_set_successfully
                    ),
                    Toast.LENGTH_SHORT
                ).show()
                setPasswordSuccess()
            } else
                setPatterErrorMsg(getString(R.string.pattern_not_match))
        }
    }

    private fun setPatterErrorMsg(errorMsg: String) {
        binding.patterLockView.setViewMode(PatternLockView.PatternViewMode.WRONG)
        binding.tvErrorMsg.visibility = View.VISIBLE
        binding.tvErrorMsg.text = errorMsg
        setErrorAnimation(binding.tvErrorMsg)
    }

    private fun setNextScreen() {
        if (temp == 0) {
            passcode = binding.pass.text.trim().toString()
            temp = 1
            Handler(Looper.myLooper()!!).postDelayed({
                binding.title.text = getString(R.string.confirm_your_pin)
                binding.pass.setText("")
            }, 30)
        } else {
            if (passcode == binding.pass.text.trim().toString()) {
                preferences.putPass(passcode)
                Toast.makeText(
                    activity, getString(R.string.pin_set_successfully),
                    Toast.LENGTH_SHORT
                ).show()
                setPasswordSuccess()
            } else {
                Handler(Looper.myLooper()!!).postDelayed({
                    binding.pass.setText("")
                }, 30)
                Toast.makeText(
                    activity,
                    R.string.pin_not_match,
                    Toast.LENGTH_SHORT
                ).show()
                setErrorAnimation(binding.loutPinDots)
            }
        }
    }

    private fun setPasswordSuccess() {
        if (isShowPinLock)
            preferences.putSetPass(true)
        else
            preferences.putSetPattern(true)

        preferences.putShowPinLock(isShowPinLock)
        lockListener(true)
    }

    private fun unSelectDot(image: AppCompatImageView) {
        image.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.ic_pass_dot_unfill))
    }

    private fun selectDot(image: AppCompatImageView) {
        image.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.ic_pass_dot_fill))
    }

}