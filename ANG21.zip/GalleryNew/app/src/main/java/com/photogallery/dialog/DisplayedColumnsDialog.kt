package com.photogallery.dialog

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import androidx.core.content.ContextCompat
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.photogallery.R
import com.photogallery.databinding.DialogDisplayColumnsBinding
import com.photogallery.extension.beGone
import com.photogallery.utils.Preferences

class DisplayedColumnsDialog(val mContext: Context, val folderPath: String? = "", var isShowAlbumTab: Boolean, val updateListener: () -> Unit) :
    Dialog(mContext) {

    lateinit var bindingDialog: DialogDisplayColumnsBinding
    lateinit var preferences: Preferences
    var gridCount = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        window?.attributes?.windowAnimations = android.R.style.Animation_Dialog
//        window?.decorView!!.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        bindingDialog = DialogDisplayColumnsBinding.inflate(layoutInflater)
//        bindingDialog.root.setPadding(0, 0, 0, mContext.navigationBarHeight)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
    }

    private fun intView() {

        preferences = Preferences(mContext)
        gridCount = preferences.getGridCount(folderPath)
        if (isShowAlbumTab)
            gridCount = preferences.getAlbumGridCount()

        intListener()

//        when (gridCount) {
//            2 -> bindingDialog.rb2Columns.isChecked = true
//            3 -> bindingDialog.rb3Columns.isChecked = true
//            4 -> bindingDialog.rb4Columns.isChecked = true
//            5 -> bindingDialog.rb5Columns.isChecked = true
//            6 -> bindingDialog.rb6Columns.isChecked = true
//            else -> bindingDialog.rb3Columns.isChecked = true
//        }

//        if (isShowAlbumTab) {
////            bindingDialog.rb6Columns.visibility=View.GONE
//            bindingDialog.rb7Columns.visibility = View.GONE
//            bindingDialog.rb8Columns.visibility = View.GONE
//        }

//        if (folderPath.isNullOrEmpty()) {
//            bindingDialog.cbFolderOnly.beGone()
//            bindingDialog.dividerFolder.beGone()
//        }
    }

    private fun intListener() {
//        bindingDialog.btnCancel.setOnClickListener {
//            dismiss()
//        }

        //gridCount must in 2 to 6
        bindingDialog.btnMinus.setOnClickListener {
            if (gridCount > 2) {
                gridCount -= 1
            }
            bindingDialog.edtValue.setText("$gridCount")
            bindingDialog.btnMinus.isEnabled = gridCount > 1
            bindingDialog.btnPlus.isEnabled = gridCount < 5
        }

        bindingDialog.btnPlus.setOnClickListener {
            if (gridCount < 5) {
                gridCount += 1
            }
            bindingDialog.edtValue.setText("$gridCount")
            bindingDialog.btnMinus.isEnabled = gridCount > 1
            bindingDialog.btnPlus.isEnabled = gridCount < 5

        }


        bindingDialog.btnOK.setOnClickListener {
//            val selectedRadioButtonId: Int = bindingDialog.grpOption.checkedRadioButtonId
            val selectedGrid: Int = bindingDialog.edtValue.getText().toString().toInt()

            if (isShowAlbumTab) {
                if (selectedGrid <= 6) preferences.setAlbumGridCount(selectedGrid)
                else preferences.setAlbumGridCount(6)
                updateListener.invoke()
            } else {

//                if (bindingDialog.cbFolderOnly.isChecked) {
//                    if (gridCount != selectedGrid) {
//                        preferences.setGridCount(selectedGrid, folderPath)
////                    if(selectedGrid<=6) preferences.setAlbumGridCount(selectedGrid)
////                    else preferences.setAlbumGridCount(6)
//                        updateListener.invoke()
//                    }
//                } else {
                if (gridCount != selectedGrid) {
                    preferences.setGridCount(selectedGrid, folderPath)
                    preferences.setGridCount(selectedGrid)
//                    if(selectedGrid<=6) preferences.setAlbumGridCount(selectedGrid)
//                    else  preferences.setAlbumGridCount(6)
                    updateListener.invoke()
                }
//                }
            }
            dismiss()
        }
    }

//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)
}