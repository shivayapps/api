package com.photogallery.views

import android.view.View
import android.view.ViewGroup
import androidx.annotation.IdRes
import androidx.viewpager.widget.PagerAdapter


class CommonPagerAdapter : PagerAdapter() {
    private val pageIds: ArrayList<Int> = ArrayList()
    fun insertViewId(@IdRes pageId: Int) {
        pageIds.add(pageId)
    }
    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        return container.findViewById(pageIds[position])
    }

    override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
        container.removeView(`object` as View?)
    }

    override fun getCount(): Int {
        return pageIds.size
    }

    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return view === `object`
    }

}