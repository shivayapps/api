package com.photogallery.spananimation

import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.util.Log
import android.view.animation.Interpolator
import android.widget.ImageView
import androidx.core.view.drawToBitmap
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.photogallery.spananimation.SpanAnimationDrawable
import com.photogallery.spananimation.SpanAnimationRunner
import com.photogallery.spananimation.SpanScaleGestureHandler
import com.photogallery.spananimation.clearSpanAnimationDrawable
import com.photogallery.spananimation.resetSpanAnimationDrawable

class SpanAnimationController(rv: RecyclerView) {
    private var rv: RecyclerView? = rv
    private var spanCounts = emptyList<Int>()
    private var handler: SpanScaleGestureHandler? = null
    private var provider: (ViewHolder.() -> CapturedResult) = defaultProvider
    private val drawable = SpanAnimationDrawable()
    private val layoutManager: GridLayoutManager?
        get() = rv?.layoutManager as? GridLayoutManager

    init {
        rv.resetSpanAnimationDrawable(drawable)
    }

    val isRunning: Boolean
        get() = drawable.isRunning

    fun setCapturedProvider(provider: ViewHolder.() -> CapturedResult) {
        this.provider = provider
    }

    fun setDrawingProvider(provider: ViewHolder.() -> Bitmap?) {
        val rv = rv ?: return
        drawable.drawingProvider = { provider(rv.getChildViewHolder(it)) }
    }

    fun setAnimationDuration(duration: Long) {
        drawable.animationDuration = duration
    }

    fun setAnimationInterpolator(interpolator: Interpolator) {
        drawable.animationInterpolator = interpolator
    }

    fun setScaleCompleteInterpolator(interpolator: Interpolator) {
        drawable.completeInterpolator = interpolator
    }

    fun setScaleGestureEnabled(isEnabled: Boolean) {
        val rv = rv ?: return
        if (isEnabled && handler == null) {
            handler = SpanScaleGestureHandler(rv, drawable, ::capture, ::getSpanCount)
            rv.addOnItemTouchListener(handler!!)
        }
        handler?.isEnabled = isEnabled
    }

    private var onSpanCountChanged: ((Int, Boolean) -> Unit)? = null

    fun setOnSpanCountChangedListener(listener: (Int, Boolean) -> Unit) {
        onSpanCountChanged = listener
    }

    fun setSpanRange(min: Int, max: Int) {
        require(min > 0 && max >= min) { "Invalid span range" }
        setSpanCounts(*(min..max).toList().toIntArray())
    }
//    fun setInitialSpanCount(count: Int) {
//        val lm = layoutManager ?: return
//        if (count > 0) {
//            lm.spanCount = count
//        }
//    }

    fun setSpanCounts(vararg spanCounts: Int) {
        spanCounts.sort()
        this.spanCounts = spanCounts.filter { it > 0 }.distinct()
    }

//    fun go(spanCount: Int) {
//        val rv = rv
//        val lm = layoutManager
//        if (rv == null || lm == null) return
//        if (lm.spanCount == spanCount || spanCount < 1) return
//
//        Log.d("SpanChange", "go:$spanCount")
//        SpanAnimationRunner(spanCount, rv, lm, drawable, provider).start()
//    }

//    fun increase() {
//        layoutManager?.let { go(getSpanCount(it.spanCount, sign = 1)) }
//    }
//
//    fun decrease() {
//        layoutManager?.let { go(getSpanCount(it.spanCount, sign = -1)) }
//    }

    fun dispose() {
        val rv = rv ?: return
        handler?.let(rv::removeOnItemTouchListener)
        drawable.end()
        rv.clearSpanAnimationDrawable(drawable)
        handler = null
        this.rv = null
    }

    //    private fun getSpanCount(spanCount: Int, sign: Int): Int {
//        require(sign == 1 || sign == -1)
//        var index = spanCounts.indexOf(spanCount)
//        if (index == -1) return (spanCount + sign)
//        index += sign
//        var newSpanCount = spanCounts.getOrNull(index) ?: spanCount
////        if (newSpanCount == 5) {
////            newSpanCount = 1
////        }
//        onSpanCountChanged?.invoke(newSpanCount)
//        return newSpanCount
//    }
    private fun getSpanCount(spanCount: Int, sign: Int): Int {
        require(sign == 1 || sign == -1)

        val order = listOf(2, 3, 4, 1) // fixed order

        var index = order.indexOf(spanCount)
        if (index == -1) return spanCount // if not in order list, do nothing

        index += sign

        // Clamp instead of looping
        if (index < 0) index = 0
        if (index >= order.size) index = order.size - 1

        val newSpanCount = order[index]

        val isOneTwoChange =
            (spanCount == 1 && newSpanCount == 2) ||
                    (spanCount == 2 && newSpanCount == 1)

        onSpanCountChanged?.invoke(newSpanCount, isOneTwoChange)

        return newSpanCount
    }



    private fun capture(spanCount: Int) {
        val rv = rv
        val lm = layoutManager
        if (rv == null || lm == null) return
        if (lm.spanCount == spanCount || spanCount < 1) return
        SpanAnimationRunner(spanCount, rv, lm, drawable, provider).capture()
    }

    private companion object {
        val defaultProvider: ViewHolder.() -> CapturedResult = {
            CapturedResult(this.itemView.drawToBitmap(), canRecycle = true)
        }
    }
}

data class CapturedResult(val bitmap: Bitmap, val canRecycle: Boolean)

inline fun SpanAnimationController.setImageViewProvider(crossinline provider: ViewHolder.() -> ImageView?) {
    setCapturedProvider {
        val imageView = provider(this)
        var bitmap = (imageView?.drawable as? BitmapDrawable)?.bitmap
        var canRecycle = bitmap == null
        if (bitmap == null) {
            bitmap = (imageView ?: itemView).drawToBitmap()
            canRecycle = true
        }
        CapturedResult(bitmap, canRecycle)
    }
    setDrawingProvider { (provider(this)?.drawable as? BitmapDrawable)?.bitmap }
}