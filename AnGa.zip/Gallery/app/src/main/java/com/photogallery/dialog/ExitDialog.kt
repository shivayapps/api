package com.photogallery.dialog

import android.app.Activity
import android.app.Dialog
import android.content.DialogInterface
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import androidx.core.content.ContextCompat
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.AdmobNative
import com.adconfig.adsutil.utils.isAnyAdShowing
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.material.bottomsheet.BottomSheetDialog
//import com.example.customview.AppOpenManager
//import com.example.customview.adconfig.NativeAdHelper.mMainNative
//import com.example.customview.adconfig.NativeAdHelper.showMainNativeAd
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.photogallery.R
import com.photogallery.databinding.DialogExitBinding

class ExitDialog(
    val activity: Activity,
    val clickListener: (isExit: Boolean) -> Unit
) : Dialog(activity) {

    lateinit var binding: DialogExitBinding
    lateinit var mAdmobNative: AdmobNative
    var isExitDialogOpen = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
//        window?.decorView!!.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        binding = DialogExitBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT
        )
        AdsConfig.isSystemDialogOpen = true
        binding.btnExit.setOnClickListener {
            dismiss()
            clickListener.invoke(true)
        }
//        isExitDialogOpen = true
        loadNativeAd()
    }

//    override fun onCancel(dialog: DialogInterface) {
//        super.onCancel(dialog)
//        Handler(Looper.getMainLooper()).postDelayed({
//            isExitDialogOpen=false
//        },500)
//    }
//    override fun onDismiss(dialog: DialogInterface) {
//        super.onDismiss(dialog)
//        Handler(Looper.getMainLooper()).postDelayed({
//            isExitDialogOpen=false
//        },500)
//    }

    private fun loadNativeAd() {
        mAdmobNative = AdmobNative()
//        mAdmobNative.showNativeAd(requireActivity(),binding.nativeTemplate,mNativeAd,getString(R.string.native_exit))
//        NativeAdHelper(requireActivity(), binding.nativeTemplate, NativeLayoutType.NativeBig).loadAd();
    }

//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)

}