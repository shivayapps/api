package com.photogallery.spananimation

import android.animation.ValueAnimator
import android.graphics.*
import android.graphics.drawable.Drawable
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.Interpolator
import androidx.core.animation.addListener
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.photogallery.spananimation.SpanAnimationInfo

private val SPAN_DRAWABLE_TAG_KEY = View.generateViewId()

internal fun RecyclerView.resetSpanAnimationDrawable(drawable: SpanAnimationDrawable) {
//    val id = R.id.tag_span_animation_drawable
//    val existed = getTag(id) as? SpanAnimationDrawable
    val existed = getTag(SPAN_DRAWABLE_TAG_KEY) as? SpanAnimationDrawable
    existed?.end()
    if (existed != null) {
        existed.end()
        overlay.remove(existed)
    }
    overlay.add(drawable)
    setTag(id, drawable)
}

internal fun RecyclerView.clearSpanAnimationDrawable(drawable: SpanAnimationDrawable) {
//    val id = R.id.tag_span_animation_drawable
//    val existed = getTag(id) as? SpanAnimationDrawable
    val existed = getTag(SPAN_DRAWABLE_TAG_KEY) as? SpanAnimationDrawable
    if (existed === drawable) {
        existed.end()
        overlay.remove(existed)
        setTag(id, null)
    }
}

internal class SpanAnimationDrawable : Drawable() {
    private val dstRectF = RectF()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var startInfo: SpanAnimationInfo? = null
    private var endInto: SpanAnimationInfo? = null
    private var allowClear = true
    private var animator: ValueAnimator? = null

    var fraction = -1f
        private set
    val isRunning: Boolean
        get() = animator?.isRunning == true
    val isInitialized: Boolean
        get() = startInfo != null && endInto != null

    var animationDuration = 500L
    var animationInterpolator: Interpolator = AccelerateDecelerateInterpolator()
    var completeInterpolator: Interpolator = DecelerateInterpolator()
    var drawingProvider: ((child: View) -> Bitmap?)? = null

    fun begin(startInfo: SpanAnimationInfo, endInto: SpanAnimationInfo, start: Boolean) {
        endAnimation(allowClear = true)
        this.startInfo = startInfo
        this.endInto = endInto
        setChildVisible(isVisible = false)
        if (!start) return
        runAnimation {
            duration = animationDuration
            interpolator = animationInterpolator
            setFloatValues(0f, 1f)
        }
    }

    fun end() {
        endAnimation(allowClear = true)
    }

    fun setFraction(fraction: Float) {
        endAnimation(allowClear = false)
        val safeFraction = fraction
            .coerceAtLeast(0f)
            .coerceAtMost(1f)
        when {
            this.fraction == safeFraction -> return
            safeFraction == 1f -> {
                setChildVisible(isVisible = true)
                clear()
            }

            else -> {
                this.fraction = safeFraction
                invalidateSelf()
            }
        }
    }

    fun completeToStart(action: (() -> Unit)? = null) {
        complete(toEnd = false, action)
    }

    fun completeToEnd(action: (() -> Unit)? = null) {
        complete(toEnd = true, action)
    }

    private fun complete(toEnd: Boolean, action: (() -> Unit)? = null) {
        if (!isInitialized) return
        val startFraction = fraction
        endAnimation(allowClear = false)
        runAnimation {
            interpolator = completeInterpolator
            duration = if (toEnd) {
                (animationDuration * (1f - startFraction)).toLong()
            } else {
                (animationDuration * startFraction).toLong()
            }
            if (action != null) {
                addListener(
                    onCancel = { action() },
                    onEnd = { action() }
                )
            }
            setFloatValues(startFraction, if (toEnd) 1f else 0f)
        }
    }

    //    override fun draw(canvas: Canvas) {
//        val startValues = startInfo?.values ?: return
//        val endValues = endInto?.values ?: return
//        val fraction = fraction
//            .coerceAtLeast(0f)
//            .coerceAtMost(1f)
//
//        val boundsWidth = bounds.width()
//        val boundsHeight = bounds.height()
//        for (index in startValues.indices) {
//            val start = startValues[index]
//            val end = endValues[index]
//            var bitmap = (start.bitmap ?: end.bitmap) ?: continue
//            val child = start.child ?: end.child
//            if (child != null && drawingProvider != null) {
//                bitmap = drawingProvider!!.invoke(child) ?: bitmap
//            }
//            if (bitmap.isRecycled) continue
//
//            val left = start.left + (end.left - start.left) * fraction
//            val top = start.top + (end.top - start.top) * fraction
//            val width = start.width + (end.width - start.width) * fraction
//            val height = start.height + (end.height - start.height) * fraction
//            val right = left + width
//            val bottom = top + height
//            if (left > boundsWidth || top > boundsHeight || right < 0 || bottom < 0) {
//                // 超出drawable的绘制范围
//                continue
//            }
//            dstRectF.set(left, top, right, bottom)
//            canvas.drawBitmap(bitmap, null, dstRectF, paint)
//        }
//    }
//    override fun draw(canvas: Canvas) {
//        val startValues = startInfo?.values ?: return
//        val endValues = endInto?.values ?: return
//        val fraction = fraction.coerceIn(0f, 1f)
//
//        val boundsWidth = bounds.width()
//        val boundsHeight = bounds.height()
//
//        for (index in startValues.indices) {
//            val start = startValues[index]
//            val end = endValues[index]
//            var bitmap = (start.bitmap ?: end.bitmap) ?: continue
//            val child = start.child ?: end.child
//            if (child != null && drawingProvider != null) {
//                bitmap = drawingProvider!!.invoke(child) ?: bitmap
//            }
//            if (bitmap.isRecycled) continue
//
//            val left = start.left + (end.left - start.left) * fraction
//            val top = start.top + (end.top - start.top) * fraction
//            val width = start.width + (end.width - start.width) * fraction
//            val height = start.height + (end.height - start.height) * fraction
//            val right = left + width
//            val bottom = top + height
//
//            if (left > boundsWidth || top > boundsHeight || right < 0 || bottom < 0) {
//                continue
//            }
//
//            // --- Maintain aspect ratio ---
//            val aspectRatio = bitmap.width.toFloat() / bitmap.height.toFloat()
//            var drawWidth = width
//            var drawHeight = height
//
//            if (aspectRatio > 1f) {
//                // wider than tall → fit width
//                drawHeight = drawWidth / aspectRatio
//            } else {
//                // taller than wide → fit height
//                drawWidth = drawHeight * aspectRatio
//            }
//
//            val dx = (width - drawWidth) / 2f
//            val dy = (height - drawHeight) / 2f
//
//            dstRectF.set(
//                left + dx,
//                top + dy,
//                left + dx + drawWidth,
//                top + dy + drawHeight
//            )
//            canvas.drawBitmap(bitmap, null, dstRectF, paint)
////            dstRectF.set(left, top, right, bottom)
////            canvas.drawBitmap(bitmap, null, dstRectF, paint)
//        }
//    }

    override fun draw(canvas: Canvas) {
        val startValues = startInfo?.values ?: return
        val endValues = endInto?.values ?: return
        val fraction = fraction.coerceAtLeast(0f).coerceAtMost(1f)

        val boundsWidth = bounds.width()
        val boundsHeight = bounds.height()

        for (index in startValues.indices) {
            val start = startValues[index]
            val end = endValues[index]
            var bitmap = (start.bitmap ?: end.bitmap) ?: continue

            val child = start.child ?: end.child
            if (child != null && drawingProvider != null) {
                drawingProvider?.invoke(child)?.let { bitmap = it }
            }
            if (bitmap.isRecycled) continue

            val isSingleToDouble =
                (start.spanSize == 1 && end.spanSize == 2) ||
                        (start.spanSize == 2 && end.spanSize == 1)

            // Interpolated positions
            val top = start.top + (end.top - start.top) * fraction
            val viewWidth = start.width + (end.width - start.width) * fraction
            val viewHeight = start.height + (end.height - start.height) * fraction

            val left = if (isSingleToDouble) {
                // Slide from left for 1↔2
                start.left + (if (start.spanSize < end.spanSize) {
                    (end.left - start.left) * fraction
                } else {
                    0f
                })
            } else {
                // Default center interpolation
                start.left + (end.left - start.left) * fraction
            }

            val right = left + viewWidth
            val bottom = top + viewHeight

            if (left > boundsWidth || top > boundsHeight || right < 0 || bottom < 0) {
                continue
            }

            // Keep bitmap 1:1 inside destination rect
            val bmpWidth = bitmap.width.toFloat()
            val bmpHeight = bitmap.height.toFloat()
            val scale = minOf(viewWidth / bmpWidth, viewHeight / bmpHeight)

            val drawWidth = bmpWidth * scale
            val drawHeight = bmpHeight * scale

            val drawLeft = if (isSingleToDouble && start.spanSize > end.spanSize) {
                // Shrinking 2 → 1: keep anchored to left
                left
            } else {
                left + (viewWidth - drawWidth) / 2f
            }
            val drawTop = top + (viewHeight - drawHeight) / 2f

            dstRectF.set(drawLeft, drawTop, drawLeft + drawWidth, drawTop + drawHeight)
            canvas.drawBitmap(bitmap, null, dstRectF, paint)
        }
    }


    private inline fun runAnimation(block: ValueAnimator.() -> Unit) {
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            addUpdateListener {
                fraction = it.animatedValue as Float
                invalidateSelf()
            }
            addListener(
                onStart = { setChildVisible(false) },
                onCancel = { setChildVisible(true).clear() },
                onEnd = { setChildVisible(true).clear() }
            )
            block(this)
        }
        animator!!.start()
    }

    private fun endAnimation(allowClear: Boolean) {
        if (!isRunning) return
        this.allowClear = allowClear
        animator?.end()
        animator = null
        this.allowClear = true
    }

    private fun setChildVisible(isVisible: Boolean) = apply {
        val endValues = endInto?.values ?: return@apply
        for (index in endValues.indices) {
            val child = endValues[index].child
            if (child != null && child.isVisible != isVisible) {
                child.isVisible = isVisible
            }
        }
    }

    private fun clear() {
        if (!allowClear) return
        startInfo?.clear()
        endInto?.clear()
        startInfo = null
        endInto = null
        fraction = -1f
        dstRectF.setEmpty()
        animator = null
    }

    override fun setAlpha(alpha: Int) = Unit

    override fun setColorFilter(colorFilter: ColorFilter?) = Unit

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}