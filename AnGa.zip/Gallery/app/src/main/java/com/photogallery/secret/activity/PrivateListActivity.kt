package com.photogallery.secret.activity

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.graphics.PorterDuff
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.AdsConfig
import com.adconfig.adsutil.Config.checkReInter
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.photogallery.R
import com.photogallery.activities.SettingActivity
import com.photogallery.base.BaseNoThemeActivity
import com.photogallery.customview.MyGridLayoutManager
import com.photogallery.customview.MyRecyclerView
import com.photogallery.database.AppDatabase
import com.photogallery.databinding.ActivityPrivateListBinding
import com.photogallery.databinding.PopBottomMenuBinding

import com.photogallery.dialog.ChangLockStyleDialog
import com.photogallery.dialog.ConfirmationDialog
import com.photogallery.dialog.DeleteDialog
import com.photogallery.dialog.PrivateMenuDialog
import com.photogallery.dialog.ProgressDialog
import com.photogallery.dialog.SecurityQuestionDialog
import com.photogallery.event.DeleteEvent
import com.photogallery.event.DisplayDeleteEvent
import com.photogallery.event.HideEvent
import com.photogallery.event.RenameEvent
import com.photogallery.event.RestoreDataEvent
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.extension.toast
import com.photogallery.extension.updateStatusBarColor
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.secret.adapter.PrivateAdapter
import com.photogallery.utils.AdCache
import com.photogallery.utils.Constant
import com.photogallery.utils.MAX_COLUMN_COUNT_PICTURE
import com.photogallery.utils.Preferences
import com.photogallery.utils.Utils
import com.photogallery.viewpager.PhotoVideoActivity
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File
import java.text.SimpleDateFormat
import java.util.ArrayList
import java.util.Collections
import java.util.Locale

class PrivateListActivity : BaseNoThemeActivity() {

    var albumData = AlbumData()
    var allList = ArrayList<MediaData>()
    var pictures = ArrayList<Any>()
    var pictureAdapter: PrivateAdapter? = null
    lateinit var preferences: Preferences
    lateinit var dataBase: AppDatabase
    lateinit var activity: AppCompatActivity
    var selectedItem = 0

    private var lastLongPressedItem = -1
    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mDragListener: MyRecyclerView.MyDragListener? = null

    lateinit var binding: ActivityPrivateListBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        if(preferences.isNeedInterAd) {
            AdmobIntersAdImpl().load(this,getString(R.string.inter_all))
        } else {
            checkReInter {
                if (it) {
                    AdmobIntersAdImpl().load(this, getString(R.string.inter_all))
                    preferences.isNeedInterAd = true
                }
            }
        }
        binding = ActivityPrivateListBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = true
        }
        updateStatusBarColor(Color.parseColor("#161616"))
        loadBanner()

        activity = this@PrivateListActivity
        intView()

    }


    private fun intView() {

        dataBase = AppDatabase.getInstance(activity)

        getData()
        binding.swipeRefreshLayout.setOnRefreshListener {
            if (binding.swipeRefreshLayout.isEnabled)
                getData()
            else
                binding.swipeRefreshLayout.isRefreshing = false
        }
        intListener()
    }

    private fun initZoomListener() {
        val isGridShow = preferences.getShowGrid()
        if (isGridShow) {
            val layoutManager = binding.pictureRecycler.layoutManager as MyGridLayoutManager
            mZoomListener = object : MyRecyclerView.MyZoomListener {
                override fun zoomIn() {
                    if (layoutManager.spanCount > 2) {
                        reduceColumnCount()
                    }
                }

                override fun zoomOut() {
                    if (layoutManager.spanCount < MAX_COLUMN_COUNT_PICTURE) {
                        increaseColumnCount()
                    }
                }
            }
        } else {
            mZoomListener = null
        }
    }

    private fun reduceColumnCount() {
        val selectedGrid = preferences.getGridCount()
        if (selectedGrid > 2) {
            preferences.setGridCount(selectedGrid - 1)
        }
        setColumnView()
    }

    private fun increaseColumnCount() {
        val selectedGrid = preferences.getGridCount()
        if (selectedGrid < MAX_COLUMN_COUNT_PICTURE) {
            preferences.setGridCount(selectedGrid + 1)
        }
        setColumnView()
    }

    var isAdLoaded = false
    var mAdView: AdView? = null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }

    private fun loadBanner() {

        if (!isAdLoaded) {
            val isFirstSession = preferences.splashCounter == 1
            val adId = getString(R.string.b_privateListActivity)
            BannerAdHelper.showBanner(this, binding.layoutBanner.mFLAd, binding.llAdPlace, adId,
                AdCache.privateListAdView, { isLoaded, adView, message ->
                    mAdView = adView
                    AdCache.privateListAdView = adView
                    isAdLoaded = isLoaded
                })
        }
    }

    private fun setColumnView() {
        (binding.pictureRecycler.layoutManager as MyGridLayoutManager).spanCount =
            preferences.getGridCount()
        pictureAdapter?.apply {
            notifyItemRangeChanged(0, pictures.size)
        }
        setRvLayoutManager()
    }

    fun setupZoomListener(zoomListener: MyRecyclerView.MyZoomListener?) {
        binding.pictureRecycler.setupZoomListener(zoomListener)
    }

    private fun initDragListener() {

        mDragListener = object : MyRecyclerView.MyDragListener {
            override fun selectItem(position: Int) {
                toggleItemSelection(true, position, true)
            }

            override fun selectRange(
                initialSelection: Int,
                lastDraggedIndex: Int,
                minReached: Int,
                maxReached: Int
            ) {
                selectItemRange(
                    initialSelection,
                    Math.max(0, lastDraggedIndex),
                    Math.max(0, minReached),
                    maxReached
                )
                if (minReached != maxReached) {
                    lastLongPressedItem = -1
                }
            }

        }
    }

    fun setupDragListener(dragListener: MyRecyclerView.MyDragListener?) {
        binding.pictureRecycler.setupDragListener(dragListener)
    }

    protected fun selectItemRange(from: Int, to: Int, min: Int, max: Int) {
        if (from == to) {
            (min..max).filter { it != from }.forEach { toggleItemSelection(false, it, true) }
            return
        }

        if (to < from) {
            for (i in to..from) {
                toggleItemSelection(true, i, true)
            }

            if (min > -1 && min < to) {
                (min until to).filter { it != from }
                    .forEach { toggleItemSelection(false, it, true) }
            }

            if (max > -1) {
                for (i in from + 1..max) {
                    toggleItemSelection(false, i, true)
                }
            }
        } else {
            for (i in from..to) {
                toggleItemSelection(true, i, true)
            }

            if (max > -1 && max > to) {
                (to + 1..max).filter { it != from }.forEach { toggleItemSelection(false, it, true) }
            }

            if (min > -1) {
                for (i in min until from) {
                    toggleItemSelection(false, i, true)
                }
            }
        }
    }

    protected fun toggleItemSelection(select: Boolean, pos: Int, updateTitle: Boolean = true) {
//        pictureAdapter.getItemViewType(pos)
//        if (select && !getIsItemSelectable(pos)) {
        if (select && pictures[pos] is AlbumData) {
            return
        }

        if (pictures[pos] is MediaData) {

            if (select) {
                (pictures[pos] as MediaData).isSelected = true
//                (pictures[pos] as PictureData).isCheckboxVisible = true
//                selectedKeys.add(itemKey)
            } else {
                (pictures[pos] as MediaData).isSelected = false
//                (pictures[pos] as PictureData).isCheckboxVisible = false
//                selectedKeys.remove(itemKey)
            }
        }
        pictureAdapter?.notifyItemChanged(pos)
        setSelectedFile()
    }

    var isSelectAll = false
    private fun setToolbarSelectionMaintain(
        isShowSelection: Boolean,
        selectedItem: Int,
        isAllSelect: Boolean
    ) {
        binding.loutToolbar.visibility = View.VISIBLE
        if (isShowSelection) {
            binding.btnUnhide.visibility = View.VISIBLE
            binding.btnHide.visibility = View.GONE
            binding.btnMore.visibility = View.GONE
        }

        binding.groupToolbarSelectHeader.visibility =
            if (isShowSelection) View.VISIBLE else View.GONE

        isSelectAll = isAllSelect

        binding.loutSelectOption.visibility =
            if (isShowSelection && selectedItem != 0) View.VISIBLE else View.GONE

        binding.groupToolbarHeader.visibility = if (isShowSelection) View.GONE else View.VISIBLE
        binding.icImport.visibility = if (isShowSelection) View.GONE else View.VISIBLE

//        binding.loutTab.visibility = if (isShowSelection) View.GONE else View.VISIBLE
        binding.txtSelectCount.text = "$selectedItem ${getString(R.string.items_selected)}"
        setSelectAllColor()
    }

    private fun setSelectAllColor() {
        val color = if (isSelectAll) Color.parseColor("#FFFFFF") else Color.parseColor("#717171")
        binding.icSelect.setColorFilter(color, PorterDuff.Mode.SRC_IN)
    }

    private fun getData() {
        disableScroll()
        binding.swipeRefreshLayout.isRefreshing = true

        val data = Constant.albumData
        albumData = AlbumData(data.title, data.mediaData, data.folderPath, data.date, data.fileSize)
//        allList.clear()
//        allList.addAll(albumData.pictureData)
        Log.e("getData", "AlbumData title:${data.title}, size:${albumData.mediaData.size}")

        val hiddenList = dataBase.vaultDao().getHiddenFolderList(data.title,false)
        allList.clear()
        if (!hiddenList.isNullOrEmpty()) {
            for (hiddenData in hiddenList) {
                val file = File(hiddenData.hidePath)
                if (file.exists()) {
                    val pictureData =
                        MediaData(
                            hiddenData.hidePath,
                            Utils.getUriFromPath(this@PrivateListActivity,hiddenData.hidePath).toString(),
                            file.name,
                            hiddenData.folder,
                            file.lastModified(),
                            file.lastModified(),
                            file.length(),
                            Utils.isVideoFile(hiddenData.hidePath)
                        )
                    pictureData.isPrivate = true
                    pictureData.isFavorite = false
                    pictureData.isVideo = hiddenData.isVideo == 1
                    pictureData.idDataBase = hiddenData.id
                    pictureData.restorePath = hiddenData.restorePath

                    allList.add(pictureData)
                }
            }

        }

        binding.txtTitle.text = albumData.title
        setFilterData()
    }

    private fun setFilterData() {
        disableScroll()
        binding.swipeRefreshLayout.isRefreshing = true
        GlobalScope.launch(Dispatchers.IO) {
            setFilter()

            activity.runOnUiThread {
                setData()
            }
        }
//        Observable.fromCallable<Boolean> {
//            setFilter()
//            true
//        }.subscribeOn(Schedulers.io())
//            .doOnError { _: Throwable? ->
//                activity.runOnUiThread { setData() }
//            }
//            .subscribe { _: Boolean? ->
//                activity.runOnUiThread { setData() }
//            }
    }

    private fun setFilter() {
        val sortType = preferences.getSortType()
        val sortOrder = preferences.getSortOrder()

        Collections.sort(allList, Comparator { p1, p2 ->
            if (sortType == Constant.SORT_NAME) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.fileName.compareTo(p2.fileName, true)
                else
                    p2.fileName.compareTo(p1.fileName, true)
            } else if (sortType == Constant.SORT_PATH) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.filePath.compareTo(p2.filePath, true)
                else
                    p2.filePath.compareTo(p1.filePath, true)
            } else if (sortType == Constant.SORT_SIZE) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.fileSize.compareTo(p2.fileSize)
                else
                    p2.fileSize.compareTo(p1.fileSize)
            } else if (sortType == Constant.SORT_LAST_MODIFIED) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.date.compareTo(p2.date)
                else
                    p2.date.compareTo(p1.date)
            } else if (sortType == Constant.SORT_DATE_TAKEN) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.dateTaken.compareTo(p2.dateTaken)
                else
                    p2.dateTaken.compareTo(p1.dateTaken)
            } else
                p2.date.compareTo(p1.date)
        })

        setList()
    }

    private fun setList() {
        val albumWisePictures = LinkedHashMap<String, ArrayList<MediaData>>()
        val format = SimpleDateFormat(preferences.dateFormat, Locale.ENGLISH)

        pictures.clear()
        if (allList.size != 0) {
            for (pictureData in allList) {
                val strDate = format.format(pictureData.date)

                var imagesData1: ArrayList<MediaData> = ArrayList()
                if (albumWisePictures.containsKey(strDate)) {
                    val list: ArrayList<MediaData>? = albumWisePictures[strDate]
                    if (!list.isNullOrEmpty())
                        imagesData1.addAll(list)
                } else {
                    imagesData1 = ArrayList()
                }
                imagesData1.add(pictureData)

                albumWisePictures[strDate] = imagesData1
            }

            val keys: Set<String> = albumWisePictures.keys
            val listFolderkeys = ArrayList(keys)

            for (i in listFolderkeys.indices) {
                val imagesData = albumWisePictures[listFolderkeys[i]]
                if (imagesData != null && imagesData.size != 0) {
                    val bucketData = AlbumData(listFolderkeys[i], imagesData)
                    Log.e("setList", "bucketData:$bucketData, ${imagesData.size}")
                    pictures.add(bucketData)
                    pictures.addAll(imagesData)
                }
            }
        }


    }

    override fun onBackPressed() {
        if (binding.groupToolbarSelectHeader.visibility == View.VISIBLE) {
            setCloseToolbar()
        } else if (preferences.isNeedInterAd) {
            AdsConfig.showInterstitialAd(this) {
                if (it) preferences.isNeedInterAd = false
                finish()
            }
        } else {
            super.onBackPressed()
        }
    }

    private fun intListener() {
        binding.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.icImport.setOnClickListener {
            val intent = Intent(activity, SelectImageActivity::class.java)
            intent.putExtra(Constant.EXTRA_SELECT_TYPE, Constant.SELECT_TYPE_HIDE)
            selectImageActivityResultLauncher.launch(intent)
        }

        binding.icMenu.setOnClickListener {
            showPrivateMenu()
        }

        binding.icClose.setOnClickListener {
            setCloseToolbar()
        }
        binding.icSelect.setOnClickListener {
            isSelectAll = !isSelectAll
            setSelectClick(isSelectAll)

            setSelectAllColor()
        }

//        binding.btnShare.setOnClickListener {
//            shareImages()
//        }
        binding.btnDelete.setOnClickListener {
            showDeleteDialog()
        }
//        binding.btnHide.setOnClickListener {
//            if (binding.viewPager.currentItem == 0)
//                photosFragment.setHideData()
//        }

        binding.btnUnhide.setOnClickListener {
            setUnHideData()

        }

//        binding.btnMore.setOnClickListener {
//            showDropDown(binding.btnMore)
//        }
    }

    private fun showDropDown(view: View) {
        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopBottomMenuBinding.inflate(layoutInflater)
        val popupWindow =
            com.photogallery.utils.PopupWindowHelper(popUpBinding.root)

        popUpBinding.loutMain.setOnClickListener {
            popupWindow.dismiss()
        }

        popUpBinding.menuCopy.setOnClickListener {
            popupWindow.dismiss()
//            if (binding.viewPager.currentItem == 0)
//                photosFragment.showAddAlbumDialog(albumFragment.albumBackupList, true)
        }
        popUpBinding.menuMove.setOnClickListener {
            popupWindow.dismiss()
//            if (binding.viewPager.currentItem == 0)
//                photosFragment.showAddAlbumDialog(albumFragment.albumBackupList, false)
        }
        popupWindow.showAsPopUp(view)
    }

    var lockActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == AppCompatActivity.RESULT_OK) {
//            activity.setResult(AppCompatActivity.RESULT_OK)
//            if (isForgotPassOpen) {
//                isForgotPassOpen = false
//                changeLockStyle()
//                checkSwipe()
//            } else
//                lockListener(true)
        } else {
            intView()
        }
//        activity.finish()
    }

    private fun showPrivateMenu() {

        val dialog = PrivateMenuDialog(this,clickListener = {
            when (it) {
                1 -> {
                    // ChangePassword
                    val intent = Intent(this, LockActivity::class.java)
                    intent.putExtra(Constant.EXTRA_CHANGE_PASS, true)
                    startActivity(intent)
                }

                2 -> {
                    //ChangeEmail
//                    val intent = Intent(this, SecurityEmailActivity::class.java)
////                    intent.putExtra(Constant.EXTRA_OPEN_TYPE_QUE, 0)
//                    intent.putExtra(Constant.EXTRA_CHANGE_EMAIL, true)
////                    intent.putExtra(Constant.EXTRA_IS_OPEN_PRIVATE, false)
//                    lockActivityResultLauncher.launch(intent)
                }

                3 -> {
                    // ChangeQuestion
                    val securityQuestionDialog =
                        SecurityQuestionDialog(this@PrivateListActivity,isChangePass=true, updateListener = {
                            if (it) {
                                toast("Security question changed")
//                                if (isChangePass) {
//                                    setResult(RESULT_OK)
//                                    finish()
//                                } else if (isOpenPrivate) {
//                                    startActivity(Intent(this, PrivateActivity::class.java))
//                                    setResult(RESULT_OK)
//                                    finish()
//                                }
//                                else {
//                                    setResult(RESULT_OK)
//                                    finish()
//                                }
                            }
                        })
                    securityQuestionDialog.show()
                }

                4 -> {
                    //ChangeLockStyle
                    showLockStyleDialog()
                }

//                5 -> {
//                    //Feedback
//                    val intent = Intent(this, FeedbackActivity::class.java)
//                    startActivity(intent)
//
//                }

                6 -> {
                    //Setting
                    settingLauncher.launch(Intent(this, SettingActivity::class.java))
                }

                7 -> {
                    //RecycleBin
                    vaultLauncher.launch(Intent(this, VaultDeleteActivity::class.java))
                }

            }
        })
        dialog.show()
    }


    var vaultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            intView()
        }

    private fun showLockStyleDialog() {

        val viewTypeDialog = ChangLockStyleDialog(this@PrivateListActivity, updateListener = {
            val intent = Intent(this@PrivateListActivity, LockActivity::class.java)
            intent.putExtra(Constant.EXTRA_CHANGE_LOCK_STYLE, true)
            intent.putExtra(Constant.EXTRA_LOCK_STYLE, it)
            startActivity(intent)
//                changeLockStyleActivityResultLauncher.launch(intent)
        }, true)
        viewTypeDialog.show()

    }

    private fun disableScroll() {
        binding.pictureRecycler.suppressLayout(true)
    }

    private fun enableScroll() {
        binding.pictureRecycler.suppressLayout(false)
    }

    private fun notifyAdapter() {
        if (pictureAdapter != null) {
            pictureAdapter?.notifyDataSetChanged()
            Log.e("PrivateTag", "notifyAdapter called")
        }
//        binding.icImport.visibility= View.VISIBLE
    }

    private fun setData() {
        binding.swipeRefreshLayout.isRefreshing = false
        enableScroll()
        if (pictureAdapter != null) notifyAdapter() else initAdapter()
        setEmptyData()
    }

    fun longClickListener(isShowSelection: Boolean, selected: Int, isAllSelect: Boolean) {
        setToolbarSelectionMaintain(isShowSelection, selected, isAllSelect)
    }

    private fun initAdapter() {
        setRvLayoutManager()

        pictureAdapter = PrivateAdapter(activity, pictures,
            clickListener = {
                if (pictures[it] is MediaData) {
                    val pictureData = pictures[it] as MediaData
                    if (pictureData.isCheckboxVisible) {
                        pictureData.isSelected = !pictureData.isSelected
                        pictureAdapter?.notifyItemChanged(it)
                        setSelectedFile()
                    } else {
                        val dataList = ArrayList<MediaData>()
                        var displayPos = 0
                        for (i in pictures.indices) {
                            if (pictures[i] is MediaData) {
                                dataList.add(pictures[i] as MediaData)
                                if (it == i) {
                                    displayPos = dataList.size - 1
                                }
                            }
                        }
                        Constant.displayImageList = ArrayList()
                        Constant.displayImageList.addAll(dataList)
                        Constant.selectedPosition = displayPos
//                    val intent = Intent(activity, ImageViewerActivity::class.java)
                        if (Constant.displayImageList.size > 0) {
                            val intent = Intent(activity, PhotoVideoActivity::class.java)
                            intent.putExtra(Constant.EXTRA_DISPLAY_POS, displayPos)
                            intent.putExtra("isFromPrivate", true)
                            startActivity(intent)
                        }
                    }
                }
            },
            longClickListener = {
                if (pictures[it] is MediaData) {
                    val pictureData = pictures[it] as MediaData
                    for (i in pictures.indices) {
                        if (pictures[i] != null)
                            if (pictures[i] is AlbumData) {
                                val model = pictures[i] as AlbumData
                                model.isCheckboxVisible = true
                            } else if (pictures[i] is MediaData) {
                                val model = pictures[i] as MediaData
                                model.isCheckboxVisible = true
                            }
                    }
                    pictureData.isCheckboxVisible = true
                    pictureData.isSelected = true
                    notifyAdapter()
                    setSelectedFile()
                }
            },
            headerSelectListener = {
                if (pictures[it] is AlbumData) {
                    val albumData = pictures[it] as AlbumData
                    val isSelectAll = !albumData.isSelected
                    albumData.isSelected = isSelectAll
                    var pos = it + 1
                    while (pos < pictures.size) {
                        if (pictures[pos] is MediaData) {
                            val model = pictures[pos] as MediaData
                            model.isSelected = isSelectAll
                            pos++
                        } else if (pictures[pos] is AlbumData) {
                            break
                        }
                    }
                    notifyAdapter()
                    setSelectedFile()
                }
            })

        binding.pictureRecycler.adapter = pictureAdapter

        initZoomListener()
        setupZoomListener(mZoomListener)
        initDragListener()
        setupDragListener(mDragListener)
    }

    private fun setEmptyData() {
        if (pictures.size != 0) {
            binding.pictureRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
            binding.layoutBottom.beVisible()
        } else {
            binding.pictureRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
            binding.layoutBottom.beGone()
        }
    }

    fun setRvLayoutManager() {
        val gridCount = preferences.getGridCount()
        val layoutManager = binding.pictureRecycler.layoutManager as MyGridLayoutManager
        layoutManager.orientation = RecyclerView.VERTICAL
        layoutManager.spanCount = gridCount
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                if (position >= 0 && position < pictures.size) {
                    return if (pictureAdapter!!.getItemViewType(position) === pictureAdapter!!.ITEM_HEADER_TYPE) {
                        gridCount
                    } else 1
                } else {
                    return 1
                }
            }
        }

    }

    fun setCloseToolbar() {
        setClose()
        longClickListener(false, 0, false)
    }

    private fun setSelectedFile() {
        var selected = 0
        var allItemCount = 0

        var currentHeaderPos = -1
        var photosCount = 0
        var photosSelectCount = 0

        for (i in pictures.indices) {
            if (pictures[i] is AlbumData) {
                if (i != currentHeaderPos) {
                    if (currentHeaderPos != -1) {
                        val model = pictures[currentHeaderPos] as AlbumData
                        model.isSelected = photosCount == photosSelectCount
                        photosCount = 0
                        photosSelectCount = 0
                        pictureAdapter?.notifyItemChanged(currentHeaderPos)
                    }
                    currentHeaderPos = i
                }
            } else if (pictures[i] is MediaData) {
                val model = pictures[i] as MediaData
                allItemCount++
                photosCount++
                if (model.isSelected) {
                    selected++
                    photosSelectCount++
                }
            }
            if (i == pictures.size - 1) {
                if (currentHeaderPos != -1) {
                    val model = pictures[currentHeaderPos] as AlbumData
                    model.isSelected = photosCount == photosSelectCount
                    photosCount = 0
                    photosSelectCount = 0
                    pictureAdapter?.notifyItemChanged(currentHeaderPos)
                }
            }
        }
//        if (selected == 0) {
//            longClickListener(false, selected, false)
//            setClose()
//        } else {
//            longClickListener(true, selected, allItemCount == selected)
//        }

        longClickListener(true, selected, allItemCount == selected)
//        binding.icImport.visibility= View.GONE
        binding.swipeRefreshLayout.isEnabled = false
//        binding.swipeRefreshLayout.isEnabled = selected == 0
        selectedItem = selected
    }

    fun setSelectClick(isSelectAll: Boolean) {
//        if (isSelectAll) {
        var selected = 0
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    if (!model.isCustomAlbum) {
                        model.isSelected = isSelectAll
                    }
                } else if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData
                    model.isSelected = isSelectAll
                    if (isSelectAll)
                        selected++

                }
        }
        notifyAdapter()
        longClickListener(true, selected, isSelectAll)
        selectedItem = selected
//        } else {
//            longClickListener(false, 0, false)
//            setClose()
//        }
    }

    private fun setClose() {
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    model.isSelected = false
                    model.isCheckboxVisible = false
                } else if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData
                    model.isCheckboxVisible = false
                    model.isSelected = false
                }
        }

        binding.swipeRefreshLayout.isEnabled = true
        notifyAdapter()
        selectedItem = 0
//        binding.icImport.visibility= View.VISIBLE
    }

    fun shareImages() {
        if (selectedItem == 0) {
            Toast.makeText(
                activity,
                activity.getString(R.string.PleaseSelectImage),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            val uris = ArrayList<Uri>()
            for (i in pictures.indices) {
                if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData
                    if (model.isSelected) {
                        val uri = FileProvider.getUriForFile(
                            activity,
                            activity.packageName + ".provider",
                            File(model.filePath)
                        )
                        uris.add(uri)
                    }
                }
            }
            Utils.shareFilesList(activity, uris)
        }
    }

    fun showDeleteDialog() {
        if (selectedItem == 0) {
            Toast.makeText(
                activity,
                activity.getString(R.string.PleaseSelectImage),
                Toast.LENGTH_SHORT
            ).show()
        } else {

            val deleteDialog = DeleteDialog.newInstance(
                activity,
//                getString(R.string.selected_delete_msg),
                btnClickListener = {
                    deletePhoto(it)
                })
            deleteDialog.show()
        }
    }

    @SuppressLint("CheckResult")
    private fun deletePhoto(isPermanent: Boolean) {
        val deleteList = ArrayList<String>()

        val progressDialog = ProgressDialog(
            activity,
            R.drawable.ic_drawer_delete,
            selectedItem,
            getString(R.string.Deleting),
            ""
        )
        progressDialog.show()
        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(activity)
            for (i in pictures.indices) {
                if (pictures[i] != null) if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData
                    if (model.isSelected) {
                        val isDelete = Utils.deleteHideFile(activity, model, dataBase, isPermanent)
                        if (isDelete) {
                            deleteList.add(model.filePath)
                            activity.runOnUiThread {
                                progressDialog.setProgress(deleteList.size, selectedItem)
                            }
                        }
                    } else {
                        model.isCheckboxVisible = false
                    }
                } else if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    model.isSelected = false
                    model.isCheckboxVisible = false
                }
            }

            var i = 0
            while (i < pictures.size) {
                if (pictures[i] != null)
                    if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false

                    } else if (pictures[i] is MediaData) {
                        val model = pictures[i] as MediaData
                        if (model.isSelected) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is AlbumData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                        } else {
                            model.isSelected = false
                            model.isCheckboxVisible = false
                        }
                    }
                i++
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                activity.runOnUiThread {
                    progressDialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
            .subscribe { _: Boolean? ->
                activity.runOnUiThread {
                    progressDialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
    }

    fun setUnHideData() {
        if (selectedItem == 0) {
            Toast.makeText(
                activity,
                activity.getString(R.string.PleaseSelectImage),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            val confirmationDialog = ConfirmationDialog(
                activity,
                getString(R.string.Unhide),
                getString(R.string.unhide_msg),
                getString(R.string.ok),
                positiveBtnClickListener = {
                    unHidePhoto()
                })
            confirmationDialog.show()
        }
    }

    private fun unHidePhoto() {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is MediaData) {
                    val model: MediaData = pictures[i] as MediaData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }

        Utils.unHideFiles(activity, selectImage, selectImage.size, hideListener = {
            Toast.makeText(
                activity,
                getString(R.string.UnHide_successfully),
                Toast.LENGTH_SHORT
            ).show()
            selectedItem = 0
            pictures.removeAll(selectImage)
            Constant.albumData.mediaData.removeAll(selectImage)

            if (Constant.albumData.mediaData.size == 0) {
                Constant.albumData = AlbumData()
            }
            longClickListener(false, 0, false)
            setClose()
            getData()
        })
    }

    private fun setBeforeDeleteUpdate(deleteList: ArrayList<String>) {
//        EventBus.getDefault().post(DeleteEvent(1, deleteList))
        selectedItem = 0
        notifyAdapter()
        binding.swipeRefreshLayout.isEnabled = true
        longClickListener(false, 0, false)
        setEmptyData()
        Toast.makeText(
            activity,
            getString(R.string.Delete_successfully),
            Toast.LENGTH_SHORT
        ).show()
        deleteMainList(deleteList)
    }

    private fun deleteMainList(deleteList: ArrayList<String>) {
        if (deleteList.size != 0) {
//            val favList = preferences.getFavoriteList()
            for (path in deleteList) {
//                if (favList.contains(path)) {
//                    Log.e("","favList is remove")
//                    favList.remove(path)
//                }
                for (pictureData in allList) {
                    if (pictureData.filePath == path) {
                        allList.remove(pictureData)
                        break
                    }
                }
            }

//            preferences.setFavoriteList(favList)
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDeleteEvent(event: DeleteEvent) {
        deleteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onRenameEvent(event: RenameEvent) {
        renameEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onRestoreDataEvent(event: RestoreDataEvent) {
        restoreEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onHideEvent(event: HideEvent) {
        getData()
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDisplayDeleteEvent(event: DisplayDeleteEvent) {
        displayDeleteEvent(event)
    }

    private fun renameEvent(event: RenameEvent) {
        if (event.oldPath.isNotEmpty() && event.renamePath.isNotEmpty()) {
            if (pictures.isNotEmpty()) {
                for (picture in pictures) {
                    if (picture is MediaData) {
                        val model = pictures as MediaData
                        if (model.filePath == event.oldPath) {
                            model.filePath = event.renamePath
                            model.fileName = File(event.renamePath).name
                            model.fileSize = File(event.renamePath).length()
                            break
                        }
                    }
                }
            }
            pictureAdapter?.notifyDataSetChanged()

            for (pictureData in allList) {
                if (pictureData.filePath == event.oldPath) {
                    pictureData.filePath = event.renamePath
                    pictureData.fileName = File(event.renamePath).name
                    pictureData.fileSize = File(event.renamePath).length()
                    break
                }
            }

        }
    }

    private fun deleteEvent(event: DeleteEvent) {
        if (event.deleteList.isNotEmpty() && event.pos != 0)
            if (pictures.isNotEmpty()) {
                updateDeleteImageData(event.deleteList)
                deleteMainList(event.deleteList)
            }
    }

    private fun restoreEvent(event: RestoreDataEvent) {
        if (event.restoreList.isNotEmpty())
            if (pictures.isNotEmpty()) {
                val list: ArrayList<String> = ArrayList()
                for (restoreData in event.restoreList) {
                    list.add(restoreData.deletedPath)
                }
                updateDeleteImageData(list)
                deleteMainList(list)
            }
    }

    private fun displayDeleteEvent(event: DisplayDeleteEvent) {
        if (event.deleteList.isNotEmpty())
            if (pictures.isNotEmpty()) {
                updateDeleteImageData(event.deleteList)
                deleteMainList(event.deleteList)
            }
    }

    private fun updateDeleteImageData(deleteList: ArrayList<String>) {
        if (pictures.isNotEmpty()) {
            for (d in deleteList.indices) {
                var i = 0
                while (i < pictures.size) {
                    if (pictures[i] is MediaData) {
                        val model = pictures[i] as MediaData
                        if (model.filePath == deleteList[d]) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is AlbumData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                            if (d == deleteList.size - 1) {
                                break
                            }
                        }
                    }
                    i++
                }
            }
            notifyAdapter()
            setEmptyData()
        }
    }

    var selectImageActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == AppCompatActivity.RESULT_OK) {
            Utils.hideFiles(
                activity,
                Constant.selectedImageList,
                Constant.selectedImageList.size,
                hideListener = {
                    getData()
                    Toast.makeText(
                        activity,
                        getString(R.string.hide_successfully),
                        Toast.LENGTH_SHORT
                    ).show()
                }, albumData.title
            )
        }
    }


}