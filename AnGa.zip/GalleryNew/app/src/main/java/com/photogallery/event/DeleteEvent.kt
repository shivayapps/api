package com.photogallery.event

import java.util.ArrayList

data class DeleteEvent(var pos: Int, var deleteList: ArrayList<String>)
