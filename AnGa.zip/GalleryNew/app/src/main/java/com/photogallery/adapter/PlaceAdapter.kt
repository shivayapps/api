package com.photogallery.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.photogallery.R
import com.photogallery.databinding.ItemAlbumPlaceGridBinding
import com.photogallery.databinding.ItemAlbumPlaceListBinding
import com.photogallery.databinding.ItemHeaderBinding
import com.photogallery.model.PlaceData
import com.photogallery.utils.Preferences

class PlaceAdapter(
    var context: Context,
    var albumList: ArrayList<PlaceData>,
    val isGrid: Boolean = false,
    val clickListener: (pos: Int) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {


    var preferences: Preferences = Preferences(context)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        if (isGrid) {
            val binding = ItemAlbumPlaceGridBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return AlbumGridViewHolder(binding)
        } else {
            val binding = ItemAlbumPlaceListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return AlbumListViewHolder(binding)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        holder.itemView.tag = holder

        if (holder is AlbumGridViewHolder) {
            val albumData: PlaceData = albumList[position] as PlaceData

            holder.binding.txtTitle.text = albumData.place
            if (albumData.pictureData.isNotEmpty()) {
                Glide.with(context.applicationContext)
                    .load(albumData.pictureData[0].filePath)
                    .into(holder.binding.image)

                holder.binding.txtCount.text = "${albumData.pictureData.size}"
            } else {
                holder.binding.txtCount.text = "0"
                holder.binding.image.setImageDrawable(
                    ContextCompat.getDrawable(
                        context,
                        R.drawable.ic_image_placeholder
                    )
                )
            }

            holder.binding.root.setOnClickListener {
                clickListener(position)
            }
        } else if (holder is AlbumListViewHolder) {
            val albumData: PlaceData = albumList[position] as PlaceData

            holder.binding.txtTitle.text = albumData.place
            if (albumData.pictureData.isNotEmpty()) {
                Glide.with(context.applicationContext)
                    .load(albumData.pictureData[0].filePath)
                    .into(holder.binding.image)

                holder.binding.txtCount.text = "${albumData.pictureData.size}"
            } else {
                holder.binding.txtCount.text = "0"
                holder.binding.image.setImageDrawable(
                    ContextCompat.getDrawable(
                        context,
                        R.drawable.ic_image_placeholder
                    )
                )
            }

            holder.binding.root.setOnClickListener {
                clickListener(position)
            }
        }
    }

    override fun getItemCount(): Int {
        return albumList.size
    }

//    class HeaderViewHolder(var binding: ItemHeaderBinding) : RecyclerView.ViewHolder(binding.root)

    class AlbumGridViewHolder(var binding: ItemAlbumPlaceGridBinding) :
        RecyclerView.ViewHolder(binding.root)

    class AlbumListViewHolder(var binding: ItemAlbumPlaceListBinding) :
        RecyclerView.ViewHolder(binding.root)

}