package com.photogallery.spananimation

import androidx.recyclerview.widget.RecyclerView.NO_POSITION
import com.photogallery.spananimation.SpanAnimationValue
import com.photogallery.spananimation.SpanAnimationValues

internal class SpanAnimationInfo(private val source: SpanAnimationValues) {
    var minLayoutPosition = Int.MAX_VALUE
        private set

    var maxLayoutPosition = Int.MIN_VALUE
        private set

    val values: List<SpanAnimationValue>

    init {
        source.calculateMinMaxLayoutPositions().also {
            minLayoutPosition = it[0]
            maxLayoutPosition = it[1]
        }
        val size = when {
            maxLayoutPosition < minLayoutPosition -> 0
            else -> maxLayoutPosition - minLayoutPosition + 1
        }
        values = if (size != 0) {
            ArrayList<SpanAnimationValue>(size).apply {
                for (layoutPosition in minLayoutPosition..maxLayoutPosition) {
                    source[layoutPosition]?.let(::add)
                }
            }
        } else {
            minLayoutPosition = NO_POSITION
            maxLayoutPosition = NO_POSITION
            emptyList()
        }
    }

    fun clear() {
        source.clear()
    }
}