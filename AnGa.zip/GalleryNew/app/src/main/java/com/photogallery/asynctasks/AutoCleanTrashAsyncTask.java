package com.photogallery.asynctasks;

import static android.content.Context.NOTIFICATION_SERVICE;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.provider.MediaStore;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;


public class AutoCleanTrashAsyncTask extends AsyncTask<Void, Void, Void> {

    Context deleteContext;
    long deleteFileSize;
    int FileDeletingCount = 0;
    String mRootPath;
    long daysToDelete ;


    public AutoCleanTrashAsyncTask(Context context, String path, long days) {
        mRootPath = path;
        deleteContext = context;
        deleteFileSize = 0;
        daysToDelete = days;
    }

    protected void onPreExecute() {
        super.onPreExecute();

    }

    protected Void doInBackground(Void... params) {
        Log.e("junkReminder", "AutoCleanTrash doInBackground");

        List<File> fList = getListAllFiles(mRootPath);
        Calendar calendar = Calendar.getInstance();
        long currentTime = calendar.getTimeInMillis();

        for(File fileToDelete : fList) {
            Date date1=new Date();
            date1.setTime(currentTime);
            long daysOld = printDifference(fileToDelete.lastModified(),currentTime);
            Log.e("junkReminder", "doInBackground-daysOld:" + daysOld);
            try {

                if(daysOld>=daysToDelete) {
//                    fileToDelete.deleteOnExit();
//                    if(fileToDelete.exists()) {
//
//                        boolean del=fileToDelete.delete();
//                        Log.e("junkReminder", "doInBackground-del:" + del);
//                        deleteFileFromMediaStore(deleteContext,fileToDelete.getAbsolutePath());
//                    }
                }
            } catch (Exception e) {
                Log.e("junkReminder", "doInBackground-Exception:" + e);
            }

        }

        return null;
    }

    private void notifyReminder(
            Context context,
            int id,
            String title,
            String body,
            int icon,
            PendingIntent pendingIntent
    ) {

        NotificationManager notificationManager = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);

        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(context, channel())
                .setSmallIcon(icon)
                .setContentTitle(title)
                .setContentText(body)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true);

        notificationManager.notify(id, notificationBuilder.build());

    }
    private String channel()  {
        String channelId = "";
        NotificationManager notificationManager = (NotificationManager)deleteContext.getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            channelId = "Channel Reminder";
            String channelName = "channel is created to remind preferences set by user in this application";
            NotificationChannel channel = new NotificationChannel(
                    channelId, channelName,
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            notificationManager.createNotificationChannel(channel);
        }
        return channelId;
    }

    private void deleteFileFromMediaStore(Context context,String path) {
        try {
//            context.getContentResolver().delete(FilesProtectionContentProvider.a, "trash_path = ? ", new String[]{String.valueOf(path)});

            String[] projection = new String[]{MediaStore.Images.Media._ID};
            String selection = MediaStore.Images.Media.DATA + " = ?";
            String[] selectionArgs = new String[]{path};
            Uri queryUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
            Cursor c = context.getContentResolver().query(queryUri, projection, selection, selectionArgs, null);
            if (c.moveToFirst()) {
                long id = c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media._ID));
                Uri deleteUri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id);
                context.getContentResolver().delete(deleteUri, null, null);
            }
            c.close();
        } catch (Exception e) {
            Log.e("printStackTrace","printStackTrace:$e");
        }
        System.gc();
    }

    public void deleteFileFromMediaStore1(Context context, final File file) {
        String canonicalPath;
        try {
            canonicalPath = file.getCanonicalPath();
        } catch (IOException e) {
            canonicalPath = file.getAbsolutePath();
        }
        final Uri uri = MediaStore.Files.getContentUri("external");
        if (context != null) {
            final int result = context.getContentResolver().delete(uri,
                    MediaStore.Files.FileColumns.DATA + "=?", new String[]{canonicalPath});
            if (result == 0) {
                final String absolutePath = file.getAbsolutePath();
                if (!absolutePath.equals(canonicalPath)) {
                    context.getContentResolver().delete(uri,
                            MediaStore.Files.FileColumns.DATA + "=?", new String[]{absolutePath});
                }
            }
        }
    }

    public long printDifference(long startDate, long endDate) {
        //milliseconds
//        long different = endDate.getTime() - startDate.getTime();
        long different = endDate - startDate;

        long secondsInMilli = 1000;
        long minutesInMilli = secondsInMilli * 60;
        long hoursInMilli = minutesInMilli * 60;
        long daysInMilli = hoursInMilli * 24;

        long elapsedDays = different / daysInMilli;
        different = different % daysInMilli;

        long elapsedHours = different / hoursInMilli;
        different = different % hoursInMilli;

        long elapsedMinutes = different / minutesInMilli;
        different = different % minutesInMilli;

        long elapsedSeconds = different / secondsInMilli;

        Log.e("AutoCleanTrash","Days:"+elapsedDays);
        Log.e("AutoCleanTrash","Hours:"+elapsedHours);
        Log.e("AutoCleanTrash","Minutes:"+elapsedMinutes);
        Log.e("AutoCleanTrash","Seconds:"+elapsedSeconds);

        return elapsedDays;
    }

    public static List<File> getListAllFiles(String path) {
        Log.e("Utils", "getListAllFiles:"+path);
        File fold = new File(path);
        List<File> docList = new ArrayList<>();
        File[] mlist = fold.listFiles();
        File[] mFilelist = fold.listFiles();
        if (mlist != null) {
            for (File f : mlist) {
                if (f.isDirectory()) {
                    List<File> fList = getListAllFiles(f.getAbsolutePath());
                    docList.addAll(fList);
                }
            }
            if (mFilelist != null) {
                for (File f : mFilelist) {
                    if(!f.getName().isEmpty()) {
                        if (f.length() > 0) {
                            docList.add(f);
                        }
                    }
                }
            }
        }
        return docList;
    }

    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
    }

}
