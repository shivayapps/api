package com.photogallery.jobs

import android.content.Context
import android.database.Cursor
import android.location.Address
import android.location.Geocoder
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import com.photogallery.database.AppDatabase
import com.photogallery.database.LocationEntity
import com.photogallery.extension.isRawFast
import com.photogallery.utils.Utils
import com.photogallery.utils.sendEvent

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.IOException
import java.util.Locale

fun Context.startPlacesFetcher() {
    Log.i("PlacesWorker", "startPlacesFetcher")
    PlacesWorker(this.applicationContext).doWork()
}

class PlacesWorker(
    val appContext: Context,
) {

    fun doWork() {
        try {
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val projection = arrayOf(
                        MediaStore.Images.Media.DATA,
                        MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
                        MediaStore.MediaColumns.DATE_MODIFIED,
                        MediaStore.MediaColumns.DISPLAY_NAME,
                        MediaStore.MediaColumns.DATE_TAKEN,
                        MediaStore.MediaColumns.SIZE
                    )

                    val orderBy = MediaStore.MediaColumns.DATE_MODIFIED
                    val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                    } else {
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                    }

                    val cursor: Cursor = appContext.contentResolver.query(
                        uri,
                        projection,
                        null,
                        null,
                        "$orderBy DESC"
                    )!!

                    val pathIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
                    val dataBase = AppDatabase.getInstance(appContext)
                    while (cursor.moveToNext()) {
                        try {
                            val filePath = cursor.getString(pathIndex)
//                        var latLong = DoubleArray(2)
                            val entity = dataBase.dataDao().getLocationEntity(filePath)
                            if (entity == null) {
                                updateLocation(filePath, dataBase)
                            }

                        } catch (e: IOException) {
                            Log.i("PlacesWorker", "IOException:$e")
                        } catch (e: UnsupportedOperationException) {
                            Log.i("PlacesWorker", "UnsupportedOperationException:$e")
                        }
                    }
                    cursor.close()
                } catch (e: Exception) {
                    Log.i("PlacesWorker", "Exception:$e")
                    e.printStackTrace()
                }
            }
        } catch (e: Exception) {
            Log.i("PlacesWorker", "Exception:$e")
            e.printStackTrace()
        }
    }

    suspend fun updateLocation(filePath: String, dataBase: AppDatabase) {
//        if (DatabaseObjectBox.PlaceMediaStore == null) return

        val latLong = FloatArray(2)
        try {
            if (!filePath.isRawFast()) {
                val exifInterface = ExifInterface(filePath)
                exifInterface.getLatLong(latLong)
            }
        } catch (e: Exception) {
            Log.i("PlacesWorker", "updateLocation.exception:$e")

        }

        if (latLong[0] != 0f && latLong[1] != 0f) {
            Log.i("PlacesWorker", "updateLocation.filePath:$filePath")

            var latLongToAddressString = ""
            latLongToAddressString = latLongToAddressString(
                latLong[0].toDouble(),
                latLong[1].toDouble()
            )

            dataBase.dataDao().insertLocationEntity(
                LocationEntity(
                    0,
                    latLongToAddressString,
                    filePath,
                    Utils.getUriFromPath(appContext,filePath).toString(),
                    latLong[0].toFloat(),
                    latLong[1].toFloat()
                )
            )
            Log.i("PlacesWorker", "latLongToAddressString:$latLongToAddressString")
            sendEvent("refresh_map")
        }

    }

    fun latLongToAddressString(latitude: Double, longitude: Double): String {
        var addressString = ""
        val geocoder = Geocoder(appContext, Locale.getDefault())
        try {
            val addresses: List<Address>? = geocoder.getFromLocation(latitude.toDouble(), longitude.toDouble(), 1)
            if (addresses != null) {
                val returnedAddress: Address = addresses[0]
                val strReturnedAddress = StringBuilder("")
                if (returnedAddress.subLocality != null) {
                    strReturnedAddress.append(returnedAddress.subLocality)
                } else if (returnedAddress.locality != null) {
                    strReturnedAddress.append(returnedAddress.locality)
                }

                addressString = strReturnedAddress.toString()
            }
        } catch (e: Exception) {
            Log.i("PlacesWorker", "latLongToAddressString.exception:$e")
        }
        return addressString
    }
}