package com.photogallery.model

import android.graphics.drawable.Drawable
import androidx.annotation.Keep

//@Keep
//data class LanguageData(
//    var name: String, var languageCode: String, var icon: Drawable?
//)
data class LanguageData(
    var languageTitle: String,
    var languageSubTitle: String,
    var languageCode: String,
    //var icon: Int
)