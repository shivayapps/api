package com.photogallery.filepicker

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import com.photogallery.databinding.DialogFilePickerBinding
import com.photogallery.filepicker.controller.DialogSelectionListener
import com.photogallery.filepicker.model.DialogProperties
import com.photogallery.utils.Preferences

class FilePickerDialog(
    val properties: com.photogallery.filepicker.model.DialogProperties,
    val callbacks: () -> com.photogallery.filepicker.controller.DialogSelectionListener
) :
    DialogFragment() {

    lateinit var bindingDialog: DialogFilePickerBinding
    lateinit var preferences: Preferences

//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setStyle(STYLE_NORMAL, R.style.FullScreenDialog)
//    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogFilePickerBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {
        preferences = Preferences(requireActivity())

        intListener()



    }

    private fun intListener() {
        bindingDialog.btnCancel.setOnClickListener {
            dismiss()
        }
    }

}