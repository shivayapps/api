package com.photogallery.activities

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PorterDuff
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.PopupWindow
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.doOnPreDraw
import androidx.media3.common.util.UnstableApi
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.AdsConfig
import com.adconfig.adsutil.Config.checkReInter
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.photogallery.BuildConfig
import com.photogallery.R
import com.photogallery.adapter.PictureAdapter
import com.photogallery.base.BaseActivity
import com.photogallery.customview.MyGridLayoutManager
import com.photogallery.customview.MyRecyclerView
import com.photogallery.database.AppDatabase
import com.photogallery.databinding.ActivityImageListBinding
import com.photogallery.databinding.PopBottomMenuBinding
import com.photogallery.dialog.ConfirmationDialog
import com.photogallery.dialog.CreateAlbumDialog
import com.photogallery.dialog.DeleteDialog
import com.photogallery.dialog.DetailsDialog
import com.photogallery.dialog.DisplayedColumnsDialog
import com.photogallery.dialog.FilterMediaDialog
import com.photogallery.dialog.GroupDialog
import com.photogallery.dialog.MainMenuDialog
import com.photogallery.dialog.ProgressDialog
import com.photogallery.dialog.RenameDialog

import com.photogallery.dialog.SelectAlbumFullDialog
import com.photogallery.dialog.SortDialog
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.extension.beVisibleIf
import com.photogallery.extension.delayExecution
import com.photogallery.extension.getFilenameExtension
import com.photogallery.extension.getFinalUriFromPath
import com.photogallery.extension.getParentFolder
import com.photogallery.extension.getUriMimeType
import com.photogallery.extension.isApng
import com.photogallery.extension.isGif
import com.photogallery.extension.isImageFast
import com.photogallery.extension.isPng
import com.photogallery.extension.isPortrait
import com.photogallery.extension.isSvg
import com.photogallery.extension.isVideoFast
import com.photogallery.extension.openEditorIntent
import com.photogallery.extension.scanPathRecursively
import com.photogallery.extension.showErrorToast
import com.photogallery.extension.toast
import com.photogallery.jobs.MediaLoaderX
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.utils.AdCache
import com.photogallery.utils.Constant
import com.photogallery.utils.FastScroller
import com.photogallery.utils.MAX_COLUMN_COUNT_PICTURE
import com.photogallery.utils.MessageEvent
import com.photogallery.utils.PopupWindowHelper
import com.photogallery.utils.Preferences

import com.photogallery.utils.Utils
import com.photogallery.utils.ensureBackgroundThread
import com.photogallery.utils.sendEvent
import com.photogallery.viewpager.PhotoVideoActivity
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Collections
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class ImageListActivity : BaseActivity() {

    lateinit var preferences: Preferences
    var albumData = AlbumData()
    var allList = ArrayList<MediaData>()
    var allBackList = ArrayList<MediaData>()
    var pictures = ArrayList<Any>()

    var imageListAdapter: PictureAdapter? = null
    var selectedItem = 0
    var isSearch: Boolean = false
    var isStopSearch: Boolean = false
    var isCheckSearchOn = false
    var isSelectAll = false

    var mediaLoader: MediaLoaderX? = null

    //    private var googleMap: GoogleMap? = null
//    private var photoLocation: LatLng? = null
    private var folderPath: String = ""
    var isFromMap = false

    private var lastLongPressedItem = -1
    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mDragListener: MyRecyclerView.MyDragListener? = null

    lateinit var binding: ActivityImageListBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityImageListBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        preferences = Preferences(this)
        if (preferences.isNeedInterAd) {
            AdmobIntersAdImpl().load(this, getString(R.string.inter_all))
        } else {
            checkReInter {
                if (it) {
                    AdmobIntersAdImpl().load(this, getString(R.string.inter_all))
                    preferences.isNeedInterAd = true
                }
            }
        }

        loadBanner()

        if (!EventBus.getDefault().isRegistered(this)) EventBus.getDefault().register(this)
        if (intent.hasExtra("folderPath")) {
            folderPath = intent.getStringExtra("folderPath")!!
            folderPath.getParentFolder()
        }
        Log.e("ImageListActivity", "folderPath:$folderPath")

        if (intent.hasExtra("isFromMap")) {
            isFromMap = true
            val lati = intent.getFloatExtra("lati", 0f)
            val long = intent.getFloatExtra("long", 0f)
//            binding.map.onCreate(savedInstanceState)
            initMap(lati, long)
        } else {
            isFromMap = false
//            binding.guideline.setGuidelinePercent(0f)
        }
        intView()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (EventBus.getDefault().isRegistered(this)) EventBus.getDefault().unregister(this)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        if (event.type.equals("refresh")) {
            preferences.refreshMedia = false
            preferences.scanMedia = false
//            binding.swipeRefreshLayout.isRefreshing = true
            refreshData()
        }
        if (event.type.equals("refresh_map")) {
            if (isFromMap) {
                try {
                    scanPathRecursively(folderPath) {}
                } catch (e: Exception) {
                }
                //sendEvent("refresh")
                preferences.refreshMedia = false
                preferences.scanMedia = false
                refreshData()
            }
        }
    }

    private fun intView() {

        val data = Constant.albumData
        albumData = AlbumData(data.title, data.mediaData, data.folderPath, data.date, data.fileSize)

        allList.clear()
        allBackList.clear()

        for (model in allList) {
            Log.e("pictureData.add.001", "intView.pictureData.add:${model.filePath}")
        }
        allList.addAll(albumData.mediaData)
        allBackList.addAll(albumData.mediaData)

        binding.txtTitle.text = albumData.title
//        binding.txtPlace.text = albumData.title
//        binding.txtCount.text = "${albumData.mediaData.size}"

        mediaLoader = MediaLoaderX(
            this,
            sortOrder = preferences.getSortOrder(folderPath),
            sortType = preferences.getSortType(folderPath),
            prefKey = folderPath
        )
        mediaLoader?.refreshLoader(folderPath)
//        binding.swipeRefreshLayout.isRefreshing = true
        getData()

//        binding.swipeRefreshLayout.setOnRefreshListener {
//            if (binding.swipeRefreshLayout.isEnabled) getData()
//            else binding.swipeRefreshLayout.isRefreshing = false
//        }

        binding.root.doOnPreDraw {
            binding.pictureRecycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    var firstPositon = (binding.pictureRecycler.layoutManager as MyGridLayoutManager).findFirstVisibleItemPosition()

                    if (firstPositon > 0) {
                        setBubbleText(imageListAdapter?.getBubbleText(firstPositon)!!)
                        binding.bubble.beVisible()
                    } else {
                        binding.bubble.beGone()
                    }
                }
            })
        }
        intListener()
    }

    var isAdLoaded = false
    var mAdView: AdView? = null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()

    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }

    private fun loadBanner() {
        if (!isAdLoaded) {

            val adId = getString(R.string.b_imageListActivity)
            BannerAdHelper.showBanner(
                this,
                binding.layoutBanner.mFLAd,
                binding.layoutBottomAd,
                adId,
                AdCache.imageListAdView,
                { isLoaded, adView, message ->
                    if (!isDestroyed) {
                        mAdView = adView
                        AdCache.imageListAdView = adView
                        isAdLoaded = isLoaded
                    }
                })
        }
    }

    private fun initMap(lati: Float, long: Float) {
        //binding.guideline.setGuidelinePercent(0.35f)

//        photoLocation = LatLng(lati.toDouble(), long.toDouble());
//        binding.map.getMapAsync { map ->
//            googleMap = map
//            googleMap?.setPadding(0, 0, 0, binding.llLable.getHeight());
//
//            if (
//                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
//                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
//            ) {
//                googleMap?.isMyLocationEnabled = true
//            }
//            addMarker(lati, long)
//
//        }

    }


//    private fun addMarker(lati: Float, long: Float) {
//        val lat = lati.toDouble()
//        val lng = long.toDouble()
//        if (lat != null && lng != null) {
//            val location = LatLng(lat, lng)
//
//            Log.e("MapExploreActivity", "getImageOnMap:::addMarker==>lat:${lat}, lng:${lng}")
//
//            if (googleMap != null) {
//
//                if (albumData.mediaData.size > 0) {
//                    val data = albumData.mediaData[0]
//                    val marker = googleMap?.addMarker(
//                        MarkerOptions()
//                            .position(location)
//                            .anchor(0.5f, 0.5f)
//                            .icon(
//                                BitmapDescriptorFactory.fromBitmap(
//                                    getMarkerBitmapFromView(
//                                        data.filePath,
//                                        albumData.mediaData.size
//                                    )
//                                )
//                            )
//                    )
//                    marker?.tag = albumData.title
//                }
//            }
//
//            googleMap?.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 15f));
//            googleMap?.animateCamera(CameraUpdateFactory.zoomIn());
//            googleMap?.animateCamera(CameraUpdateFactory.zoomTo(15f), 800, null);
//        }
//    }

    private fun getMarkerBitmapFromView(photoPath: String, size: Int): Bitmap {
        val customMarkerView: View =
            (getSystemService(AppCompatActivity.LAYOUT_INFLATER_SERVICE) as LayoutInflater).inflate(
                R.layout.custom_marker,
                null
            )
        val markerImageView = customMarkerView.findViewById<View>(R.id.profile_image) as ImageView
        val markerCounter = customMarkerView.findViewById<View>(R.id.txtCount) as TextView
        markerCounter.text = "$size"

        val options = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }

        val bitmap = BitmapFactory.decodeFile(photoPath, options)
        markerImageView.setImageBitmap(bitmap)

        customMarkerView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        customMarkerView.layout(
            0,
            0,
            customMarkerView.measuredWidth,
            customMarkerView.measuredHeight
        )
        customMarkerView.buildDrawingCache()
        val returnedBitmap = Bitmap.createBitmap(
            customMarkerView.measuredWidth, customMarkerView.measuredHeight,
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(returnedBitmap)
        canvas.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN)
        val drawable = customMarkerView.background
        drawable?.draw(canvas)
        customMarkerView.draw(canvas)
        return returnedBitmap
    }

    private fun initZoomListener() {
//        val isGridShow = preferences.getShowGrid()
//        if (isGridShow) {
        val layoutManager = binding.pictureRecycler.layoutManager as MyGridLayoutManager
        mZoomListener = object : MyRecyclerView.MyZoomListener {
            override fun zoomIn() {
                if (layoutManager.spanCount > 2) {
                    reduceColumnCount()
//                        getRecyclerAdapter()?.finishActMode()
                }
            }

            override fun zoomOut() {
                if (layoutManager.spanCount < MAX_COLUMN_COUNT_PICTURE) {
                    increaseColumnCount()
//                        getRecyclerAdapter()?.finishActMode()
                }
            }
        }
//        } else {
//            mZoomListener = null
//        }
    }

    fun setupZoomListener(zoomListener: MyRecyclerView.MyZoomListener?) {
        binding.pictureRecycler.setupZoomListener(zoomListener)
    }

    private fun initDragListener() {

        mDragListener = object : MyRecyclerView.MyDragListener {
            override fun selectItem(position: Int) {
                toggleItemSelection(true, position, true)
            }

            override fun selectRange(
                initialSelection: Int,
                lastDraggedIndex: Int,
                minReached: Int,
                maxReached: Int,
            ) {
                selectItemRange(
                    initialSelection,
                    Math.max(0, lastDraggedIndex),
                    Math.max(0, minReached),
                    maxReached
                )
                if (minReached != maxReached) {
                    lastLongPressedItem = -1
                }
            }

        }
    }

    fun setupDragListener(dragListener: MyRecyclerView.MyDragListener?) {
        binding.pictureRecycler.setupDragListener(dragListener)
    }

    protected fun selectItemRange(from: Int, to: Int, min: Int, max: Int) {
        if (from == to) {
            (min..max).filter { it != from }.forEach { toggleItemSelection(false, it, true) }
            return
        }

        if (to < from) {
            for (i in to..from) {
                toggleItemSelection(true, i, true)
            }

            if (min > -1 && min < to) {
                (min until to).filter { it != from }
                    .forEach { toggleItemSelection(false, it, true) }
            }

            if (max > -1) {
                for (i in from + 1..max) {
                    toggleItemSelection(false, i, true)
                }
            }
        } else {
            for (i in from..to) {
                toggleItemSelection(true, i, true)
            }

            if (max > -1 && max > to) {
                (to + 1..max).filter { it != from }.forEach { toggleItemSelection(false, it, true) }
            }

            if (min > -1) {
                for (i in min until from) {
                    toggleItemSelection(false, i, true)
                }
            }
        }
    }

    protected fun toggleItemSelection(select: Boolean, pos: Int, updateTitle: Boolean = true) {
//        pictureAdapter.getItemViewType(pos)
//        if (select && !getIsItemSelectable(pos)) {
        try {
            if (select && pictures[pos] is AlbumData) {
                return
            }

            if (pictures[pos] is MediaData) {

                if (select) {
                    (pictures[pos] as MediaData).isSelected = true
//                (pictures[pos] as PictureData).isCheckboxVisible = true
//                selectedKeys.add(itemKey)
                } else {
                    (pictures[pos] as MediaData).isSelected = false
//                (pictures[pos] as PictureData).isCheckboxVisible = false
//                selectedKeys.remove(itemKey)
                }
            }
        } catch (e: Exception) {

        }

//        if (::binding.isInitialized)
//            binding.pictureRecycler.recycledViewPool.clear()
        imageListAdapter?.notifyItemChanged(pos)
        setSelectedFile()
    }

    private fun intListener() {
        binding.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.icClose.setOnClickListener {
            setCloseToolbar()
        }
        binding.icSelect.setOnClickListener {
            isSelectAll = !isSelectAll
            setSelectClick(isSelectAll)
            setSelectAllColor()
        }
        binding.btnShare.setOnClickListener {
            shareImages()
        }
        binding.btnDelete.setOnClickListener {
//            requestStoragePermission(app_delete_AFA_allow_nf, app_delete_AFA_denied_nf, getActivityName()) {
//                if (it) {
            showDeleteDialog(getSelectedMedia())
//                }
//            }
        }
        binding.btnHide.setOnClickListener {
//            requestStoragePermission(app_private_AFA_allow_nf, app_private_AFA_denied_nf, getActivityName()) {
//                if (it) {
            setHideData()
//                }
//            }
        }
        binding.btnMore.setOnClickListener {
            showDropDown(binding.btnMore)
        }
        binding.icMenu.setOnClickListener {
            showMenu()
        }

    }

    private fun reduceColumnCount() {
        val selectedGrid = preferences.getGridCount(albumData.folderPath)
        if (selectedGrid > 2) {
            preferences.setGridCount(selectedGrid - 1, albumData.folderPath)
        }
        setColumnView()
    }

    private fun increaseColumnCount() {
        val selectedGrid = preferences.getGridCount(albumData.folderPath)
        if (selectedGrid < MAX_COLUMN_COUNT_PICTURE) {
            preferences.setGridCount(selectedGrid + 1, albumData.folderPath)
        }
        setColumnView()
    }

    /*  private fun setColumnView() {
          (binding.pictureRecycler.layoutManager as MyGridLayoutManager).spanCount =
              preferences.getGridCount(albumData.folderPath)
          imageListAdapter?.apply {
              notifyItemRangeChanged(0, pictures.size)
          }
          setRvLayoutManager()
      }*/

    private fun setColumnView() {

        sendEvent("refresh_layoutmanager")
        val newSpanCount = preferences.getGridCount(albumData.folderPath)
        (binding.pictureRecycler.layoutManager as MyGridLayoutManager).spanCount = newSpanCount

        // Update adapter data based on the new span count (if necessary)
        // ... (Logic to adjust your 'pictures' data based on newSpanCount)
        imageListAdapter?.apply {
            // notifyItemRangeChanged(0, pictures.size)
            if (::binding.isInitialized)
                binding.pictureRecycler.recycledViewPool.clear()
//            imageListAdapter?.notifyDataSetChanged()
            imageListAdapter?.submitList(pictures)
            imageListAdapter?.notifyItemRangeChanged(0, pictures.size)
        }

        setRvLayoutManager()
    }

    private fun showMenu() {
        val dialog = MainMenuDialog(this, 0, clickListener = {
            when (it) {
                1 -> {//show sort
                    showSortDialog()
                }

                2 -> {//show group
                    showGroupByDialog()
                }

                3 -> {//show filter
                    val filterMediaDialog = FilterMediaDialog(this@ImageListActivity, updateListener = {
                        getData()
                    })
                    filterMediaDialog.show()
                }

                4 -> {
                    // displayed Columns
                    val displayColumnsDialog = DisplayedColumnsDialog(
                        this, albumData.folderPath,
                        false,
                        updateListener = {
                            sendEvent("refresh_layoutmanager")
                            setRvLayoutManager()
//                            photosFragment.setRvLayoutManager()
//                            albumFragment.setRvLayoutManager()
                        })
                    displayColumnsDialog.show()
                }


                21 -> {
                    setRvLayoutManager()
                    sendEvent("refresh_layoutmanager")
                }

                22 -> {
                    setRvLayoutManager()
                    setListGridData()
                    sendEvent("refresh_layoutmanager")
                }

                5 -> {
                    recycleLauncher.launch(Intent(this, RecentlyDeleteActivity::class.java))
                }

                6 -> {
                    settingLauncher.launch(Intent(this, SettingActivity::class.java))
                }
            }
        })
        dialog.show()

    }

    var recycleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->

        }

    private fun showSortDialog() {
        val sortDialog = SortDialog(this, albumData.folderPath, updateListener = {
            getData()
//            photosFragment.setFilterData()
//            albumFragment.setFilterData()
        })
        sortDialog.show()
    }

    private fun showGroupByDialog() {
        val groupDialog = GroupDialog(this,albumData.folderPath, updateListener = {
            getData()
        })
        groupDialog.show()
    }

    lateinit var popupWindow: PopupWindow

    private fun showDropDown(view: View) {
        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopBottomMenuBinding.inflate(layoutInflater)
        val popupWindow = PopupWindowHelper(popUpBinding.root)

        var needToAddFav = false
        var needToRemoveFav = false
        var isVideoSelected = false

        for (i in pictures.indices) {
            if (pictures[i] is MediaData) {
                val model: MediaData = pictures[i] as MediaData
                if (model.isSelected) {
                    if (model.isVideo || model.filePath.isGif()) isVideoSelected = true

                    if (model.isFavorite)
                        needToRemoveFav = true
                    else
                        needToAddFav = true
                }
            }
        }

        popUpBinding.menuEdit.beVisibleIf(selectedItem == 1 && !isVideoSelected)
        popUpBinding.menuSetAs.beVisibleIf(selectedItem == 1 && !isVideoSelected)
//        popUpBinding.menuResize.beVisibleIf(selectedItem == 1 && !isVideoSelected)
        popUpBinding.menuRename.beVisibleIf(selectedItem == 1)
        popUpBinding.menuInfo.beVisibleIf(selectedItem == 1)
        popUpBinding.menuAddFavourite.beVisibleIf(needToAddFav)
        popUpBinding.menuRemoveFavourite.beVisibleIf(needToRemoveFav)
        popUpBinding.menuPdf.beVisibleIf(!isVideoSelected)

        popUpBinding.menuPdf.setOnClickListener {
            popupWindow.dismiss()
            if (selectedItem == 0) {
                toast(getString(R.string.PleaseSelectImage))
            } else {
                val selectImage = ArrayList<MediaData>() // Use a set to avoid duplicates
                pictures.filterIsInstance<MediaData>() // Filter only MediaData objects
                    .filter { it.isSelected } // Filter selected MediaData objects
                    .forEach { selectImage.add(it) } // Add to the set

                Utils.generatePdf(this@ImageListActivity, selectImage)
            }
        }

//        popUpBinding.menuCover.beGone()
//        popUpBinding.menuExclude.beGone()

        popUpBinding.loutMain.setOnClickListener {
            popupWindow.dismiss()
        }
        popUpBinding.menuRename.setOnClickListener {
            popupWindow.dismiss()
            if (selectedItem == 1) {
//                requestStoragePermission(app_rename_AFA_allow_nf, app_rename_AFA_denied_nf, getActivityName()) {
//                    if (it) {
                showRenameDialog()
//                    }
//                }
            } //else showBatchRenameDialog()
        }
        popUpBinding.menuSetAs.setOnClickListener {
            popupWindow.dismiss()
            setAs()
        }
//        popUpBinding.menuResize.setOnClickListener {
//            popupWindow.dismiss()
//            showResizeDialog()
//        }
        popUpBinding.menuAddFavourite.setOnClickListener {
            popupWindow.dismiss()
            setFavorite(true)
        }

        popUpBinding.menuRemoveFavourite.setOnClickListener {
            popupWindow.dismiss()
            setFavorite(false)
        }
        popUpBinding.menuEdit.setOnClickListener {
            popupWindow.dismiss()
//            requestStoragePermission(app_edit_AFA_allow_nf, app_edit_AFA_denied_nf, getActivityName()) {
//                if (it) {
            try {
                openEditor()
            } catch (e: Exception) {
                e.printStackTrace()
            }
//                }
//            }

        }
        popUpBinding.menuInfo.setOnClickListener {
            popupWindow.dismiss()
            showDetailsDialog()
        }

        popUpBinding.menuCopy.setOnClickListener {
//            showAddAlbumDialog(Constant.albumList, true)

            val selectedAlbum = ArrayList<String>()
            val selectImage = ArrayList<MediaData>() // Use a set to avoid duplicates
            pictures.filterIsInstance<MediaData>() // Filter only MediaData objects
                .filter { it.isSelected } // Filter selected MediaData objects
                .forEach { selectImage.add(it) } // Add to the set
            showAddAlbumDialog(
                Constant.deviceAlbumList,
                selectImage,
                selectedAlbum,
                true
            )
            popupWindow.dismiss()
        }
        popUpBinding.menuMove.setOnClickListener {
            popupWindow.dismiss()
//            requestStoragePermission(app_move_to_AFA_allow_nf, app_move_to_AFA_denied_nf, getActivityName()) {
//                if (it) {

            val selectedAlbum = ArrayList<String>()
            val selectImage = ArrayList<MediaData>() // Use a set to avoid duplicates
            pictures.filterIsInstance<MediaData>() // Filter only MediaData objects
                .filter { it.isSelected } // Filter selected MediaData objects
                .forEach { selectImage.add(it) } // Add to the set
            showAddAlbumDialog(
                Constant.deviceAlbumList,
                selectImage,
                selectedAlbum,
                false
            )
//                }
//            }
        }
        popupWindow.showAsPopUp(view)
    }

    fun showDetailsDialog() {

        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is MediaData) {
                    val model: MediaData = pictures[i] as MediaData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }
        try {
            val pictureData = selectImage[0]

            val detailsDialog = DetailsDialog(this, pictureData, false)
            detailsDialog.show()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun openEditor() {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is MediaData) {
                    val model: MediaData = pictures[i] as MediaData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }
        val pictureData = selectImage[0]
        val path = pictureData.filePath
        val newPath = path.removePrefix("file://")
        openEditorIntent(newPath)
    }

    fun setAs() {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is MediaData) {
                    val model: MediaData = pictures[i] as MediaData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }

        try {
            val pictureData = selectImage[0]

            ensureBackgroundThread {
                val newUri =
                    getFinalUriFromPath(pictureData.filePath, BuildConfig.APPLICATION_ID)
                        ?: return@ensureBackgroundThread
                Intent().apply {
                    action = Intent.ACTION_ATTACH_DATA
                    setDataAndType(newUri, getUriMimeType(pictureData.filePath, newUri))
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    val chooser = Intent.createChooser(this, getString(R.string.set_as))

                    try {
                        startActivityForResult(chooser, 101)
                    } catch (e: ActivityNotFoundException) {
                        toast(R.string.no_app_found)
                    } catch (e: Exception) {
                        showErrorToast(e)
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

//    fun showResizeDialog() {
//        val selectImage: ArrayList<MediaData> = ArrayList()
//        for (i in pictures.indices) {
//            if (pictures[i] != null)
//                if (pictures[i] is MediaData) {
//                    val model: MediaData = pictures[i] as MediaData
//                    if (model.isSelected) {
//                        selectImage.add(model)
//                    }
//                }
//        }
//        try {
//            val pictureData = selectImage[0]
//
//            val resizeDialog =
//                ResizeDialog(
//                    this,
//                    pictureData,
//                    updateImageListener = { path ->
//                        val file = File(path)
//                        pictures.add(
//                            0,
//                            MediaData(
//                                path,
//                                Utils.getUriFromPath(this@ImageListActivity, path).toString(),
//                                file.name,
//                                file.parentFile.path,
//                                file.lastModified(),
//                                file.lastModified(),
//                                file.length()
//                            )
//                        )
//                        setCloseToolbar()
//
//                    })
//            resizeDialog.show()
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
//    }

    fun setFavorite(isFavorite: Boolean) {

        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())
        for (i in pictures.indices) {
            if (pictures[i] is MediaData) {
                val model: MediaData = pictures[i] as MediaData
//                (pictures[i] as PictureData).isFavorite=isFavorite
                if (model.isSelected) {
                    if (isFavorite) {
                        if (!favList.contains(model.filePath))
                            favList.add(model.filePath)
                    } else {
                        if (favList.contains(model.filePath))
                            favList.remove(model.filePath)
                    }
                }
            }
        }
        preferences.setFavoriteList(favList)
        preferences.refreshMedia = true
//        refreshData(allList)
        runOnUiThread {
            setCloseToolbar()
//            refreshData()
            getData()
        }

//        setData()
//        pictures.removeAll(allList.toSet())
//        getData()
//        setList()
    }


    fun showRenameDialog() {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is MediaData) {
                    val model: MediaData = pictures[i] as MediaData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }


        try {
            val pictureData = selectImage[0]
            val renameDialog =
                RenameDialog(
                    this,
                    pictureData,
                    positiveBtnClickListener = { renamePath, oldPath ->
                        notifyAdapter()
                    })
            renameDialog.show()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setData() {
        enableScroll()
//        binding.swipeRefreshLayout.isRefreshing = false
        if (imageListAdapter != null) notifyAdapter() else initAdapter()
//        RxBus.getInstance().post(CountShowEvent())
        setEmptyData()
    }

    private fun setEmptyData() {
        if (pictures != null && pictures.size != 0) {
            binding.pictureRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
            binding.layoutBottomAd.beVisible()
//            loadBanner()
        } else {
            binding.pictureRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
            binding.layoutBottomAd.beGone()
        }
    }

    fun setListGridData() {
        setRvLayoutManager()
        if (imageListAdapter != null) {
//            albumAdapter!!.notifyDataSetChanged()
            imageListAdapter?.notifyItemRangeChanged(0, pictures.size)
        }
    }

    fun setRvLayoutManager() {
        val gridCount = preferences.getGridCount(albumData.folderPath)
//        val layoutManager = MyGridLayoutManager(this, gridCount, RecyclerView.VERTICAL, false)
        val layoutManager = binding.pictureRecycler.layoutManager as MyGridLayoutManager
//        binding.pictureRecycler.layoutManager = layoutManager
        layoutManager.spanCount = gridCount
        layoutManager.orientation = RecyclerView.VERTICAL
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                if (position >= 0 && position < pictures.size) {
                    return if (imageListAdapter!!.getItemViewType(position) == imageListAdapter!!.ITEM_HEADER_TYPE) {
                        gridCount
                    } else 1
                } else {
                    return 1
                }
            }
        }

        binding.pictureRecycler.post {
            FastScroller(binding.handleView).bind(binding.pictureRecycler)
        }

    }

    @OptIn(UnstableApi::class)
    private fun initAdapter() {
        setRvLayoutManager()
        imageListAdapter = PictureAdapter(
            this,
            clickListener = {
                if (pictures[it] is MediaData) {
                    val pictureData = pictures[it] as MediaData
                    if (pictureData.isCheckboxVisible && !isCheckSearchOn) {
                        pictureData.isSelected = !pictureData.isSelected
//                    if (::binding.isInitialized)
//                        binding.pictureRecycler.recycledViewPool.clear()
                        imageListAdapter?.notifyItemChanged(it)
                        setSelectedFile()
                    } else {
                        val dataList = ArrayList<MediaData>()
                        var displayPos = 0
                        for (i in pictures.indices) {
                            if (pictures[i] is MediaData) {
                                dataList.add(pictures[i] as MediaData)
                                if (it == i) {
                                    displayPos = dataList.size - 1
                                }
                            }
                        }
                        Constant.displayImageList = ArrayList()
                        Constant.displayImageList.addAll(dataList)
                        Constant.selectedPosition = displayPos

                        if (Constant.displayImageList.size > 0) {

                            val intent = Intent(this, PhotoVideoActivity::class.java)
                            intent.putExtra(Constant.EXTRA_DISPLAY_POS, displayPos)
                            photoVideoLauncher.launch(intent)
//                            photoVideoLauncher.launch(intent,ActivityOptionsCompat.makeSceneTransitionAnimation(this))

                        }
                    }
                }
            },
            longClickListener = {

                lastLongPressedItem = it
                binding.pictureRecycler.setDragSelectActive(it)
                lastLongPressedItem = if (lastLongPressedItem == -1) {
                    it
                } else {
                    val min = min(lastLongPressedItem, it)
                    val max = max(lastLongPressedItem, it)
                    for (i in min..max) {
                        toggleItemSelection(true, i, false)
                    }
//                    updateTitle()
                    it
                }

                if (!isCheckSearchOn) {
                    if (pictures[it] is MediaData) {
                        val pictureData = pictures[it] as MediaData
                        for (i in pictures.indices) {
                            if (pictures[i] != null)
                                if (pictures[i] is AlbumData) {
                                    val model = pictures[i] as AlbumData
                                    model.isCheckboxVisible = true
                                } else if (pictures[i] is MediaData) {
                                    val model = pictures[i] as MediaData
                                    model.isCheckboxVisible = true
                                }
                        }
                        pictureData.isCheckboxVisible = true
                        pictureData.isSelected = true
                        notifyAdapter()
                        setSelectedFile()
                    }
                }
            },
            headerSelectListener = {
                if (pictures[it] is AlbumData) {
                    val albumData = pictures[it] as AlbumData
                    val isSelectAll = !albumData.isSelected
                    albumData.isSelected = isSelectAll
                    var pos = it + 1
                    while (pos < pictures.size) {
                        if (pictures[pos] is MediaData) {
                            val model = pictures[pos] as MediaData
                            model.isSelected = isSelectAll
                            pos++
                        } else if (pictures[pos] is AlbumData) {
                            break
                        }
                    }
                    notifyAdapter()
                    setSelectedFile()
                }
            })

        imageListAdapter?.submitList(pictures)
        binding.pictureRecycler.itemAnimator = null
        binding.pictureRecycler.adapter = imageListAdapter
//        val primaryColor = resources.getColor(R.color.color_primary)
//        binding.imageListFastscroller.updateColors(primaryColor)


        binding.pictureRecycler.post {
            FastScroller(binding.handleView).bind(binding.pictureRecycler)
        }

        initZoomListener()
        setupZoomListener(mZoomListener)
        initDragListener()
        setupDragListener(mDragListener)

    }

    var photoVideoLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { _ ->
            delayExecution(500) {
                if (isFromMap) sendEvent("refresh_map")
                Log.e("ImageListActivity", "photoVideoLauncher.refreshMedia:${preferences.refreshMedia}")
                if (preferences.refreshMedia) {
                    try {
                        scanPathRecursively(folderPath) {}
                    } catch (e: Exception) {
                    }
                    sendEvent("refresh")
                    preferences.refreshMedia = false
                    preferences.scanMedia = false
//                    binding.swipeRefreshLayout.isRefreshing = true
//                delayExecution(750) {
                    refreshData()
//                }
                }
            }
        }

    fun setBubbleText(str: String) {
        Log.e("BubbleListener", "setBubbleText:$str")
//        binding.bubble.beGoneIf(str.isEmpty())
        if (str.isNotEmpty()) binding.bubbleText.text = str
    }

    fun setCloseToolbar() {
        setClose()
        longClickListener(false, 0, false)
    }

    private fun setSelectedFile() {
        var selected = 0
        var allItemCount = 0

        var currentHeaderPos = -1
        var photosCount = 0
        var photosSelectCount = 0

        try {

            for (i in pictures.indices) {
                if (pictures[i] is AlbumData) {
                    if (i != currentHeaderPos) {
                        if (currentHeaderPos != -1) {
                            val model = pictures[currentHeaderPos] as AlbumData
                            model.isSelected = photosCount == photosSelectCount
                            photosCount = 0
                            photosSelectCount = 0
                            imageListAdapter?.notifyItemChanged(currentHeaderPos)
                        }
                        currentHeaderPos = i
                    }
                } else if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData
                    allItemCount++
                    photosCount++
                    if (model.isSelected) {
                        selected++
                        photosSelectCount++
                    }
                }
                if (i == pictures.size - 1) {
                    if (currentHeaderPos != -1) {
                        val model = pictures[currentHeaderPos] as AlbumData
                        model.isSelected = photosCount == photosSelectCount
                        photosCount = 0
                        photosSelectCount = 0
//                    if (::binding.isInitialized)
//                        binding.pictureRecycler.recycledViewPool.clear()
                        imageListAdapter?.notifyItemChanged(currentHeaderPos)
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        longClickListener(true, selected, allItemCount == selected)
        binding.swipeRefreshLayout.isEnabled = false
//        binding.imageListFastscroller.isEnabled=false
//        binding.swipeRefreshLayout.isEnabled = selected == 0
        selectedItem = selected
    }

    override fun onBackPressed() {
        if (isOpenMenu())
            popupWindow.dismiss()
        else if (binding.groupToolbarSelectHeader.visibility == View.VISIBLE) {
            setCloseToolbar()
        } else
            if (preferences.isNeedInterAd) {
                try {
                    AdsConfig.showInterstitialAd(this) {
                        if (it) preferences.isNeedInterAd = false
                        finish()
                    }
                } catch (e: Exception) {
                    finish()
                }
            } else {
                finish()
            }
    }

    private fun isOpenMenu(): Boolean {
        if (::popupWindow.isInitialized) {
            return popupWindow.isShowing
        }
        return false
    }

    private fun longClickListener(
        isShowSelection: Boolean,
        selectedItem: Int,
        isAllSelect: Boolean,
    ) {
//        binding.swipeRefreshLayout.isEnabled = !isShowSelection
//        binding.imageListFastscroller.isEnabled = isShowSelection

        binding.groupToolbarSelectHeader.visibility =
            if (isShowSelection) View.VISIBLE else View.GONE
        isSelectAll = isAllSelect
        binding.loutSelectOption.visibility =
            if (isShowSelection && selectedItem != 0) View.VISIBLE else View.GONE
        binding.groupToolbarHeader.visibility = if (isShowSelection) View.GONE else View.VISIBLE

        binding.txtSelectCount.text = "$selectedItem ${getString(R.string.items_selected)}"
//        binding.swipeRefreshLayout.isEnabled = false
//        binding.swipeRefreshLayout.isEnabled = (isShowSelection && selectedItem != 0)

        setSelectAllColor()
    }

    private fun setSelectAllColor() {
        val color =
            ContextCompat.getColor(this, if (isSelectAll) R.color.black else R.color.un_check_color)
        binding.icSelect.setColorFilter(color, PorterDuff.Mode.SRC_IN)
    }

    fun setSelectClick(isSelectAll: Boolean) {
//        if (isSelectAll) {
        var selected = 0
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    if (!model.isCustomAlbum) {
                        model.isSelected = isSelectAll
                    }
                } else if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData
                    model.isSelected = isSelectAll
                    if (isSelectAll)
                        selected++

                }
        }
        notifyAdapter()
        longClickListener(true, selected, isSelectAll)
        selectedItem = selected
//        } else {
//            longClickListener(false, 0, false)
//            setClose()
//        }
    }

    private fun setClose() {
        try {
            for (i in pictures.indices) {
                if (pictures[i] != null)
                    if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false
                    } else if (pictures[i] is MediaData) {
                        val model = pictures[i] as MediaData
                        model.isCheckboxVisible = false
                        model.isSelected = false
                    }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        binding.swipeRefreshLayout.isEnabled = true
        notifyAdapter()
        selectedItem = 0
    }

    fun shareImages() {
        if (selectedItem == 0) {

            toast(getString(R.string.PleaseSelectImage))
        } else {
            ensureBackgroundThread {
                val uris = ArrayList<Uri>()
                for (i in pictures.indices) {
                    if (pictures[i] is MediaData) {
                        val model = pictures[i] as MediaData
                        if (model.isSelected) {
                            val uri = FileProvider.getUriForFile(
                                this,
                                this.packageName + ".provider",
                                File(model.filePath)
                            )
                            uris.add(uri)
                        }
                    }
                }
                runOnUiThread {
                    Utils.shareFilesList(this, uris)
                }
            }
        }
    }

    fun setHideData() {
        if (selectedItem == 0) {
            toast(
                this.getString(R.string.PleaseSelectImage)
            )
        } else {
            val hideDialog = ConfirmationDialog(
                this,
                getString(R.string.Private),
                getString(R.string.hide_msg),
                getString(R.string.hide),
                positiveBtnClickListener = {
                    hidePhoto()
                })
            hideDialog.show()


        }
    }


    private fun getSelectedMedia(): ArrayList<MediaData> {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is MediaData) {
                    val model: MediaData = pictures[i] as MediaData
                    if (model.isSelected) {
                        selectImage.add(model)
//                        favList.add(model.filePath)
                    }
                }
        }
        return selectImage
    }

    private fun showDeleteDialog(selectImage: ArrayList<MediaData>) {
        if (selectImage.size == 0) {
            toast(getString(R.string.PleaseSelectImage))
        } else {
            val deleteDialog = DeleteDialog.newInstance(this@ImageListActivity, btnClickListener = {
                deletePhoto(selectImage, it)
            })
            deleteDialog.show()
        }
    }

    private fun showAddAlbumDialog(
        albums: ArrayList<AlbumData>,
        selectedMedia: ArrayList<MediaData>,
        selectedAlbum: ArrayList<String>,
//        selectedAlbum: ArrayList<AlbumData>,
        isCopy: Boolean
    ) {
//        val selectedAlbum = ArrayList<AlbumData>()
//        val selectImage = mutableSetOf<MediaData>() // Use a set to avoid duplicates
//        albumList.filter { it.isSelected }.forEach { album ->
//            selectedAlbum.add(album) // Add selected album
//            album.mediaData.forEach { picture ->
//                if (picture is MediaData) {
//                    selectImage.add(picture) // Add MediaData to the set (duplicates automatically avoided)
//                }
//            }
//        }

//        pictures.filterIsInstance<MediaData>() // Filter only MediaData objects
//            .filter { it.isSelected } // Filter selected MediaData objects
//            .forEach { selectImage.add(it) } // Add to the set

        val uniqueSelectImage = ArrayList(selectedMedia.distinctBy { it.filePath })

        for (media in uniqueSelectImage) {
            Log.e("uniqueSelectImage", "uniqueSelectImage-->:${media.filePath}")
        }

//        val addAlbumDialog =
//            SelectAlbumFullDialog(
//                this@HomeActivity,
//                albums,
//                selectedAlbum,
//                isCopy,
//                selectPathListener = { selectPath ->
//                    setCopyMove(isCopy, selectPath, uniqueSelectImage)
//                },
//                createAlbumListener = {
////                    requestStoragePermission(app_create_album_AFA_allow_nf, app_create_album_AFA_denied_nf, getActivityName()) { value ->
////                        if (value) {
//                    val createDialog = CreateAlbumDialog(this@HomeActivity, createPathListener = {
//                        setCopyMove(isCopy, it, uniqueSelectImage)
//                    })
//                    createDialog.show()
////                        }
////                    }
//                })
//        addAlbumDialog.show(supportFragmentManager, addAlbumDialog.tag)

        isCopyForResult = isCopy
        selectImageForResult = uniqueSelectImage
        val selectAlbumIntent = Intent(this, SelectAlbumFullActivity::class.java)
        selectAlbumIntent.putExtra("selectedAlbum", selectedAlbum)
        selectAlbumIntent.putExtra("isCopy", isCopy)
        addAlbumLauncher.launch(selectAlbumIntent)

    }

    private var isCopyForResult: Boolean = false
    private lateinit var selectImageForResult: ArrayList<MediaData>
    private val addAlbumLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                val data = result.data
                when (data?.getStringExtra("action")) {
                    "create" -> {
                        val createDialog = CreateAlbumDialog(this, createPathListener = { path ->
                            setCopyMove(isCopyForResult, path, selectImageForResult)
                        })
                        createDialog.show()
                    }

                    else -> {
                        data?.getStringExtra("selectedPath")?.let { path ->
                            setCopyMove(isCopyForResult, path, selectImageForResult)
                        }
                    }
                }
            }
        }

    private fun setCopyMove(
        isCopy: Boolean,
        selectPath: String,
        selectImage: java.util.ArrayList<MediaData>,
    ) {
        Log.e("ImageListActivity", "setCopyMove.selectPath:$selectPath")
        if (isCopy)
            Utils.copyFiles(
                this,
                selectPath,
                selectImage,
                selectImage.size,
                copyListener = {
                    toast(getString(R.string.copy_successfully))
                    MediaScannerConnection.scanFile(this, arrayOf<String>(selectPath), null) { path, uri -> }
                    refreshData()
                    selectedItem = 0
                    preferences.refreshMedia = true
                    preferences.scanMedia = true
//                    setList()
                    longClickListener(false, 0, false)
                    setClose()
                    sendEvent("refresh")
                })
        else
            Utils.moveFiles(
                this,
                selectPath,
                selectImage,
                selectImage.size,
                moveListener = {
                    toast(getString(R.string.move_successfully))
                    MediaScannerConnection.scanFile(this, arrayOf<String>(selectPath), null) { path, uri -> }
                    refreshData()
                    selectedItem = 0
                    preferences.refreshMedia = true
                    preferences.scanMedia = true
//                    setList()
                    longClickListener(false, 0, false)
                    setClose()
                    sendEvent("refresh")
                })

//        if(pictures.size == 0) {
//            finish()
//        }
    }

    private fun refreshData() {
        if (folderPath.isNotEmpty()) {

            allList.clear()
            allBackList.clear()

            disableScroll()

            Log.e("MediaLoaderX", "startMediaLoader")
            mediaLoader?.destroyLoader()
            mediaLoader?.refreshLoader(folderPath)
            mediaLoader?.getAllMedia(folderPath = folderPath, { groupedMediaList, mediaList ->
                allList.clear()
                allBackList.clear()

                allList.addAll(mediaList)
                allBackList.addAll(mediaList)

                pictures.clear()
                pictures.addAll(groupedMediaList)

                runOnUiThread {
                    enableScroll()
//                    binding.swipeRefreshLayout.isRefreshing = false
                    setData()
                }
            })

        } else {
            Log.e("ImageListActivity", "getData.folderPath:$folderPath")
            getData()
        }
    }

    private fun hidePhoto() {
        val selectImage: ArrayList<MediaData> = ArrayList()
        val deleteList = ArrayList<String>()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is MediaData) {
                    val model: MediaData = pictures[i] as MediaData
                    if (model.isSelected) {
                        selectImage.add(model)
                        deleteList.add(model.filePath)
                    }
                }
        }

        Utils.hideFiles(this, selectImage, selectedItem, hideListener = {
            toast(getString(R.string.hide_successfully))
            selectedItem = 0
            preferences.refreshMedia = true
            sendEvent("refresh")
            longClickListener(false, 0, false)
            setClose()
            deleteMainList(deleteList)
//            refreshData(selectImage)
            refreshData()
        })
    }


    private fun deletePhoto(selectImage: ArrayList<MediaData>, isPermanent: Boolean) {

        val deleteList = ArrayList<String>()
        val progressDialog = ProgressDialog(
            this,
            R.drawable.ic_drawer_delete,
            selectImage.size,
            getString(R.string.Deleting),
            ""
        )
        progressDialog.setCancelable(false)
        progressDialog.show()

        preferences.refreshMedia = true
        preferences.scanMedia = true

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(this)
            selectImage.forEach { model ->

                val entity = dataBase.dataDao().getLocationEntity(model.filePath)
                if (entity != null) {
                    dataBase.dataDao().deleteLocationEntity(entity)
                }
                val isDelete = Utils.deleteFile(this, model.filePath, dataBase, isPermanent)
                MediaScannerConnection.scanFile(this, arrayOf<String>(model.filePath), null) { path: String?, uri: Uri? -> }
                if (isDelete) {
                    deleteList.add(model.filePath)
                    runOnUiThread {
                        progressDialog.setProgress(deleteList.size, selectImage.size)
                    }
                }
            }

            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    progressDialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
            .onErrorReturn { false }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    progressDialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
    }

    private fun setBeforeDeleteUpdate(deleteList: ArrayList<String>) {
//        EventBus.getDefault().post(DeleteEvent(1, deleteList))
        selectedItem = 0
        deleteMainList(deleteList)
        notifyAdapter()
        binding.swipeRefreshLayout.isEnabled = true
        longClickListener(false, 0, false)
        setEmptyData()
        setCloseToolbar()

        Log.e("refresh_map", "send_event")
        sendEvent("refresh_map")
        sendEvent("refresh")
        toast(getString(R.string.Delete_successfully))
//        if(pictures.size == 0) {
//            finish()
//        }
    }

    private fun deleteMainList(deleteList: ArrayList<String>) {
        try {
            if (deleteList.size != 0) {
                allList.iterator().let { iterator ->
                    while (iterator.hasNext()) {
                        if (iterator.next().filePath in deleteList) {
                            iterator.remove()
                        }
                    }
                }

                allBackList.iterator().let { iterator ->
                    while (iterator.hasNext()) {
                        if (iterator.next().filePath in deleteList) {
                            iterator.remove()
                        }
                    }
                }

                try {
                    Constant.albumData.mediaData = allList
                    albumData.fileSize = allList.sumOf { it.fileSize }
                    albumData.date = allList.maxOfOrNull { it.date } ?: 0L
                } catch (e: Exception) {
                    e.printStackTrace()
                }

                notifyAdapter()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


    private fun getData() {
        disableScroll()
        mediaLoader?.getConstantList(folderPath = folderPath, { groupedMediaList, mediaList ->
            allList.clear()
            allBackList.clear()

            allList.addAll(mediaList)
            allBackList.addAll(mediaList)

            pictures.clear()
            pictures.addAll(groupedMediaList)

            runOnUiThread {
                enableScroll()
//                binding.swipeRefreshLayout.isRefreshing = false
                setData()
            }
        })

    }

    private fun setFilter() {
        Log.e("ImageListActivity", "imageVideo size==>> " + allList.size)
        val sortType = preferences.getSortType(albumData.folderPath)
        val sortOrder = preferences.getSortOrder(albumData.folderPath)

        Collections.sort(allList, Comparator { p1, p2 ->
            if (p1 == null || p2 == null) -1
            else if (sortType == Constant.SORT_NAME) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.fileName.compareTo(p2.fileName, true)
                else
                    p2.fileName.compareTo(p1.fileName, true)
            }
//            else if (sortType == Constant.SORT_PATH) {
//                if (sortOrder == Constant.ORDER_ASCENDING)
//                    p1.filePath.compareTo(p2.filePath, true)
//                else
//                    p2.filePath.compareTo(p1.filePath, true)
//            }
            else if (sortType == Constant.SORT_SIZE) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.fileSize.compareTo(p2.fileSize)
                else
                    p2.fileSize.compareTo(p1.fileSize)
            }
            else if (sortType == Constant.SORT_DATE) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.date.compareTo(p2.date)
                else
                    p2.date.compareTo(p1.date)
            }
//            else if (sortType == Constant.SORT_DATE_TAKEN) {
//                if (sortOrder == Constant.ORDER_ASCENDING)
//                    p1.dateTaken.compareTo(p2.dateTaken)
//                else
//                    p2.dateTaken.compareTo(p1.dateTaken)
//            }
            else
                p2.date.compareTo(p1.date)
        })
        Collections.sort(allBackList, Comparator { p1, p2 ->
            if (p1 == null || p2 == null) -1
            else if (sortType == Constant.SORT_NAME) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.fileName.compareTo(p2.fileName, true)
                else
                    p2.fileName.compareTo(p1.fileName, true)
            }
//            else if (sortType == Constant.SORT_PATH) {
//                if (sortOrder == Constant.ORDER_ASCENDING)
//                    p1.filePath.compareTo(p2.filePath, true)
//                else
//                    p2.filePath.compareTo(p1.filePath, true)
//            }
            else if (sortType == Constant.SORT_SIZE) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.fileSize.compareTo(p2.fileSize)
                else
                    p2.fileSize.compareTo(p1.fileSize)
            }
            else if (sortType == Constant.SORT_DATE) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.date.compareTo(p2.date)
                else
                    p2.date.compareTo(p1.date)
            }
//            else if (sortType == Constant.SORT_DATE_TAKEN) {
//                if (sortOrder == Constant.ORDER_ASCENDING)
//                    p1.dateTaken.compareTo(p2.dateTaken)
//                else
//                    p2.dateTaken.compareTo(p1.dateTaken)
//            }
            else
                p2.date.compareTo(p1.date)
        })

        if (!isStopSearch)
            setList()
    }

    private fun notifyAdapterRemove(pos: Int) {
//        if (imageListAdapter != null) {
//            imageListAdapter?.notifyItemRemoved(pos)
//        }
    }

    private fun notifyAdapter() {
        if (imageListAdapter != null) {
//            if (::binding.isInitialized)
//                binding.pictureRecycler.recycledViewPool.clear()
            binding.pictureRecycler.post {
                if (isFromMap && imageListAdapter?.getCurruentListData() != pictures) {
                    imageListAdapter?.submitList(pictures)
                    imageListAdapter?.notifyItemRangeChanged(0, pictures.size)
                } else {
                    imageListAdapter?.submitList(pictures)
                    imageListAdapter?.notifyItemRangeChanged(0, pictures.size)
                }

//                imageListAdapter?.notifyDataSetChanged()
            }
//            imageListAdapter?.notifyDataSetChanged()
        }
    }

    private fun setList() {
        try {
            pictures.clear()
            val favList = preferences.getFavoriteList()
            val dateWisePictures: LinkedHashMap<String, ArrayList<MediaData>> = linkedMapOf()

//        var format = preferences.dateFormat
//        val currentGrouping = context.config.getFolderGrouping(pathToCheck)
            val currentGrouping = preferences.getGroupBy(albumData.folderPath)
            val groupOrder = preferences.getGroupOrderBy(albumData.folderPath)

            Log.e("ImageList", "setList.folderPath:${albumData.folderPath},currentGrouping:$currentGrouping,groupOrder:$groupOrder")

            val format = when (currentGrouping) {
                Constant.GROUP_BY_DATE_DAILY -> SimpleDateFormat(preferences.dateFormat, Locale.ENGLISH)
//            Constant.GROUP_BY_DATE_TAKEN_DAILY -> SimpleDateFormat(preferences.dateFormat, Locale.ENGLISH)
                Constant.GROUP_BY_DATE_MONTHLY -> SimpleDateFormat("MMMM yyyy", Locale.ENGLISH)
//            Constant.GROUP_BY_DATE_TAKEN_MONTHLY -> SimpleDateFormat("MMMM yyyy", Locale.ENGLISH)
                else -> SimpleDateFormat(preferences.dateFormat, Locale.ENGLISH)
            }

            mediaLoader?.applyMediaGrouping(allList, currentGrouping, groupOrder, { groupedMediaList ->
                pictures.clear()
                pictures.addAll(groupedMediaList)
            })
            if (allList.size != 0) {
                for (pictureData in allList) {
                    val strDate = format.format(pictureData.date)
                    var strKey = format.format(pictureData.date)

                    when (currentGrouping) {
                        Constant.GROUP_BY_NONE -> strKey = ""
                        Constant.GROUP_BY_DATE_DAILY -> {
                            strKey = format.format(getDayStartTS(pictureData.date, false))
                        }

//                        Constant.GROUP_BY_DATE_TAKEN_DAILY -> {
//                            strKey = format.format(getDayStartTS(pictureData.dateTaken, false))
//                        }

                        Constant.GROUP_BY_DATE_MONTHLY -> {
                            strKey = format.format(getDayStartTS(pictureData.date, true))
                        }

//                        Constant.GROUP_BY_DATE_TAKEN_MONTHLY -> {
//                            strKey = format.format(getDayStartTS(pictureData.dateTaken, true))
//                        }

//                        Constant.GROUP_BY_EXTENSION -> {
//                            strKey = pictureData.fileName.getFilenameExtension()
//                                .lowercase(Locale.getDefault())
//
//                        }

//                        Constant.GROUP_BY_FOLDER -> {
//                            strKey =
//                                pictureData.filePath.getParentFolder().lowercase(Locale.getDefault())
//                        }
//
//                        Constant.GROUP_BY_FILE_TYPE -> {
//                            strKey = getFileTypeString(
//                                pictureData.fileName
//                            )
//                        }

                        else -> {
                            strKey = format.format(getDayStartTS(pictureData.date, false))
                        }
                    }

                    if (isStopSearch) {
                        break
                    } else {
                        Log.e("ImageList", "setList.strKey:${strKey}")
                        var imagesData1: ArrayList<MediaData> = ArrayList()
                        if (strKey.isNotEmpty() && dateWisePictures.containsKey(strKey)) {
                            val list: ArrayList<MediaData>? = dateWisePictures[strKey]
                            if (!list.isNullOrEmpty())
                                imagesData1.addAll(list)
                        } else {
                            imagesData1 = ArrayList()
                        }
                        imagesData1.add(pictureData)
                        if (strKey.isNotEmpty()) dateWisePictures[strKey] = imagesData1
                    }
                }

                val keys: Set<String> = dateWisePictures.keys
                val listKeys = ArrayList(keys)

                if (groupOrder == Constant.ORDER_DESCENDING) {
                    listKeys.reverse()
                }

                if (listKeys.size == 0) {
                    pictures.addAll(allList)
                    binding.pictureRecycler.setPadding(0, 50, 0, 0)
                }
                for (i in listKeys.indices) {
                    if (isStopSearch) {
                        break
                    } else {
                        val imagesData = dateWisePictures[listKeys[i]]
                        if (imagesData != null && imagesData.size != 0) {
                            val bucketData = AlbumData(listKeys[i], imagesData)
                            pictures.add(bucketData)
                            pictures.addAll(imagesData)
                        }
                    }
                }
                for (i in pictures.indices) {
                    val model = pictures[i]
                    if (model is MediaData) {
                        if (favList.contains((pictures[i] as MediaData).filePath)) {
                            (pictures[i] as MediaData).isFavorite = true
                        } else {
                            (pictures[i] as MediaData).isFavorite = false
                        }
                    }
                }

            }
        } catch (e: Exception) {
            Log.e("printStackTrace", "printStackTrace:$e")
        } finally {
//            imageListAdapter?.submitList(pictures)
            notifyAdapter()
        }
    }


    private fun getFileTypeString(fileName: String): String {
        Log.e("getFileTypeString", "getFileTypeString.001:$fileName")
        var stringId = R.string.images
        if (fileName.isImageFast() || fileName.isApng() || fileName.isPng()) stringId =
            R.string.images
        else if (fileName.isVideoFast()) stringId = R.string.videos
        else if (fileName.isPortrait()) stringId = R.string.portraits
        else if (fileName.isSvg()) stringId = R.string.svgs
        else if (fileName.isGif()) stringId = R.string.gifs

        return getString(stringId)
    }

    private fun getDayStartTS(ts: Long, resetDays: Boolean): Long {
        val calendar = Calendar.getInstance(Locale.ENGLISH).apply {
            timeInMillis = ts
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)

            if (resetDays) {
                set(Calendar.DAY_OF_MONTH, 1)
            }
        }

        return calendar.timeInMillis
    }

    private fun disableScroll() {
        binding.pictureRecycler.suppressLayout(true)
    }

    private fun enableScroll() {
        binding.pictureRecycler.suppressLayout(false)
    }

}