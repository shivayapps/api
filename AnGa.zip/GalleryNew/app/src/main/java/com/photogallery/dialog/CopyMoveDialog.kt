package com.photogallery.dialog

import android.app.Activity
import android.app.Dialog
import android.app.ProgressDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Point
import android.graphics.drawable.ColorDrawable
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.widget.addTextChangedListener
import com.bumptech.glide.Glide
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.photogallery.R
import com.photogallery.databinding.DialogCopyMoveBinding
import com.photogallery.databinding.DialogResizeBinding
import com.photogallery.extension.getMimeType
import com.photogallery.extension.toast
import com.photogallery.model.MediaData
import com.photogallery.utils.Preferences
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class CopyMoveDialog(
    var mContext: Activity,
    val clickListener: (option: Int) -> Unit
) : Dialog(mContext) {

    lateinit var bindingDialog: DialogCopyMoveBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.CENTER)
//        window?.decorView!!.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        bindingDialog = DialogCopyMoveBinding.inflate(layoutInflater)
//        bindingDialog.root.setPadding(0, 0, 0, mContext.navigationBarHeight)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
        intListener()
        setCancelable(false)
        setCanceledOnTouchOutside(false)
    }


    private fun intView() {

    }

    private fun intListener() {

        bindingDialog.btMove.setOnClickListener {
            clickListener.invoke(0)
            dismiss()
        }
        bindingDialog.btCopy.setOnClickListener {
            clickListener.invoke(1)
            dismiss()
        }

    }


}

