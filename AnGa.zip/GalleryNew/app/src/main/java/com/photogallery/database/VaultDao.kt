package com.photogallery.database

import android.content.ContentValues
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface VaultDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun hide(data: HiddenData)

    @Query("SELECT * FROM hiddenData WHERE isDeleted = :isFromRecycle")
    fun getHiddenList(isFromRecycle:Boolean): List<HiddenData>
    @Query("SELECT * FROM hiddenData WHERE folder = :folder AND isDeleted = :isFromRecycle")
    fun getHiddenFolderList(folder:String,isFromRecycle:Boolean): List<HiddenData>

    @Update
    fun update(data: HiddenData)

//    @Update("SET FROM hiddenAlbum WHERE id = :id AND type = :type")
    @Query("UPDATE hiddenData SET folder=:newFolder WHERE folder = :folder")
    fun updateFolder(newFolder: String,folder: String)

    @Delete
    fun unHide(data: HiddenData)

    @Delete
    fun deleteHide(data: HiddenData)

    @Query("SELECT hidePath FROM hiddenData WHERE id = :id")
    fun getMediaPath(id: String): String

//    @Query("SELECT duration FROM hiddenData WHERE id = :id")
//    fun getDuration(id: String): Int

//    @Query("UPDATE hiddenData SET duration=:millSecond WHERE id = :name")
//    fun updateVideoDuration(name: String, millSecond: Int): Int

    @Query("DELETE FROM hiddenData WHERE id = :id")
    fun deleteMediaData(id: String)

//    @Insert(onConflict = OnConflictStrategy.REPLACE)
//    fun addAlbum(data: HiddenAlbum)

//    @Insert(onConflict = OnConflictStrategy.REPLACE)
//    fun updateAlbumName(data: HiddenAlbum)

//    fun updateAlbumName(id: String, name: String, type: String) {
//        val values = ContentValues().apply {
//            put("name", name)
//            put("type", type)
//        }
//        writableDatabase.update(AlbumDatabase.ALBUM_TABLE_NAME, values, "id = ?", arrayOf(id))
//        writableDatabase.close()
//    }

//    @Query("SELECT * FROM hiddenAlbum")
//    fun getHiddenAlbumList(): List<HiddenAlbum>

//    @Delete
//    fun deleteHiddenAlbum(data: HiddenAlbum)

//    @Query("SELECT id FROM hiddenAlbum WHERE name = :name AND type = :type")
//    fun getAlbumIdFromName(name: String,type:String): String

//    @Query("SELECT id FROM hiddenAlbum WHERE name = :name")
//    fun getAlbumIdFromName(name: String): String

//    @Query("SELECT name FROM hiddenAlbum WHERE id = :id AND type = :type")
//    fun getAlbumName(id: String, type: String): String

//    @Query("SELECT name FROM hiddenAlbum WHERE id = :id")
//    fun getAlbumName(id: String): String

//    @Query("DELETE FROM hiddenAlbum WHERE id = :id AND type = :type")
//    fun deleteAlbum(id: String, type: String)

//    @Query("DELETE FROM hiddenAlbum WHERE id = :id")
//    fun deleteAlbum(id: String)

//    @Query("SELECT * FROM hiddenAlbum WHERE name = :id AND type = :type")
//    fun getAlbumIdFromId(id: String,type:String): HiddenAlbum
//    @Query("SELECT * FROM hiddenAlbum WHERE name = :id")
//    fun getAlbumFromId(id: String): HiddenAlbum
    @Query("SELECT * FROM hiddenData WHERE hidePath = :hidePath")
    fun getDataFromPath(hidePath: String): HiddenData

}