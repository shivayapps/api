package com.photogallery.extension

//fun Activity.getThemeId(showTransparentTop: Boolean = false) =
//    when {
//        baseConfig.isUsingSystemTheme -> if (isUsingSystemDarkTheme()) R.style.Base_Theme_Gallery else R.style.Base_Theme_Gallery
//        isBlackAndWhiteTheme() -> when {
//            showTransparentTop -> R.style.AppTheme_BlackAndWhite_NoActionBar
////            baseConfig.primaryColor.getContrastColor() == DARK_GREY -> R.style.AppTheme_BlackAndWhite_DarkTextColor
//            else -> R.style.AppTheme_BlackAndWhite
//        }
//
//        isWhiteTheme() -> when {
//            showTransparentTop -> R.style.AppTheme_White_NoActionBar
////            baseConfig.primaryColor.getContrastColor() == Color.WHITE -> R.style.AppTheme_White_LightTextColor
//            else -> R.style.Base_Theme_Gallery
//        }
//    }
