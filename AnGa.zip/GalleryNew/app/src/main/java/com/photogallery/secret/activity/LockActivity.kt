package com.photogallery.secret.activity

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.biometric.BiometricManager
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import com.photogallery.R
import com.photogallery.base.BaseNoThemeActivity
import com.photogallery.databinding.ActivityLockBinding
import com.photogallery.extension.isSupportWithErrorInfo
import com.photogallery.extension.showBiometricPrompt
import com.photogallery.extension.toast
import com.photogallery.extension.updateStatusBarColor
import com.photogallery.secret.fragment.LockChangeStyleFragment
import com.photogallery.secret.fragment.LockFragment
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences


class LockActivity : BaseNoThemeActivity() {

    var isResetPass = false
    var isChangePass = false
//    var isOpenPrivate = false
    var isOpenAlbum = false

    lateinit var preferences: Preferences

    lateinit var binding: ActivityLockBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLockBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = true
        }
        updateStatusBarColor(Color.parseColor("#161616"))

        preferences = Preferences(this)

        intView()

    }

    private fun setPasswordSuccess() {
        setResult(RESULT_OK)
        (this@LockActivity).finish()
    }

    private fun startAndroidxBiometricManager() {

        showBiometricPrompt(successCallback = { icSuccess ->
            if (icSuccess) {
                setPasswordSuccess()
            }
        }, failureCallback = { icFailed: Boolean, errorCode: Int, errString: CharSequence ->
            Log.e("BiometricManager","\nicFailed:$icFailed,\nerrorCode:$errorCode,errString:$errString")
            toast(R.string.authentication_failed)
        })

    }

    private fun intView() {
//        isOpenPrivate = intent.getBooleanExtra(Constant.EXTRA_IS_OPEN_PRIVATE, false)
        isOpenAlbum = intent.getBooleanExtra(Constant.EXTRA_IS_OPEN_ALBUM, false)
        isResetPass = intent.getBooleanExtra(Constant.EXTRA_RESET_PASS, false)
        isChangePass = intent.getBooleanExtra(Constant.EXTRA_CHANGE_PASS, false)

        val isChangeLockStyle = intent.getBooleanExtra(Constant.EXTRA_CHANGE_LOCK_STYLE, false)
        val isLockStyleGrid = intent.getBooleanExtra(Constant.EXTRA_LOCK_STYLE, false)

        try {
            if (isChangeLockStyle) {
                loadFragment(LockChangeStyleFragment(this, isLockStyleGrid, lockListener = {
                    setResult(RESULT_OK)
                    finish()
                }))
            } else {
                loadFragment(
                    LockFragment(
                        this,
//                    isOpenPrivate,
                        isResetPass,
                        isChangePass,
                        lockListener = {
                            if (it) {
                                setPasswordSuccess()
                            } else {
                                (this@LockActivity).finish()
                            }
                        }
                    )
                )

                val isFingerprintAvailable = isSupportWithErrorInfo(this, BiometricManager.Authenticators.BIOMETRIC_STRONG)
                if (preferences.enableFingerprint && isFingerprintAvailable.first && !isChangePass && !isResetPass) {
                    Handler(Looper.getMainLooper()).postDelayed({
                        startAndroidxBiometricManager()
                    }, 700)
                }
            }
        } catch (e:Exception) {
            Log.e("printStackTrace","printStackTrace:$e")
        }
    }

    private fun loadFragment(fragment: Fragment) {
        try {
            val fm = this.supportFragmentManager
            val fragmentTransaction = fm.beginTransaction()
            fragmentTransaction.replace(R.id.container_lock, fragment)
            fragmentTransaction.commit()
        } catch (e:Exception) {
            Log.e("printStackTrace","printStackTrace:$e")
        }
    }

}