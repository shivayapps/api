package com.photogallery.activities


import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge

import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.photogallery.base.BaseActivity

import com.photogallery.databinding.ActivityStartBinding
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences

class StartActivity : BaseActivity() {

    lateinit var binding: ActivityStartBinding
    lateinit var preferences: Preferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStartBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        preferences = Preferences(this)
        init()
    }

    private fun init() {
//        binding.txtMsg.text = getString(R.string.permission_msg)
        binding.btnAllow.setOnClickListener {
            startActivity(nextScreen())
        }
    }

    private fun nextScreen(): Intent {
        Log.e("SplashTag", "nextScreen call")
        Log.e("SplashTag", "nextScreen ${preferences.isSetLanguage}")

        var intent = Intent(this, HomeActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (!checkStoragePermission()) {
            intent = Intent(
                this,
                PermissionActivity::class.java
            ).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        } else if (!preferences.isSetLanguage) {
            intent = Intent(this, LanguageActivity::class.java)
//            intent = Intent(this, StartActivity::class.java)
                .putExtra(Constant.EXTRA_IS_OPEN_FROM_SPLASH, true)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        } else  {
            intent = Intent(
                this,
                HomeActivity::class.java
            ).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        return intent
    }



}