package com.photogallery.messaging

import android.app.ActivityManager
import android.app.Notification.VISIBILITY_PUBLIC
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.service.notification.StatusBarNotification
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.legacy.content.WakefulBroadcastReceiver
import com.photogallery.R
import com.photogallery.SplashActivity
import com.photogallery.activities.HomeActivity
import com.photogallery.activities.JunkScanActivity
import com.photogallery.activities.SettingActivity
import com.photogallery.activities.MapAlbumActivity
import com.photogallery.activities.LanguageActivity
import com.photogallery.recover.RecoverMediaActivity
import java.util.Random


class FireBaseMessageReceiver : WakefulBroadcastReceiver() {
    private val TAG = "FireBaseMessageReceiver"

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.extras != null) {
            for (key in intent.extras!!.keySet()) {
                val value = intent.extras!!.get(key)
                Log.e(TAG, " MessagingAlarmReceiver-value:key:$key==>${value.toString()}")
            }

            Log.e(TAG, " MessagingAlarmReceiver-data-->" + intent.extras?.get("activity").toString())
            Log.e(TAG, " MessagingAlarmReceiver-google.c.a.c_l-->" + intent.extras?.get("google.c.a.c_l").toString())
            Log.e(TAG, " MessagingAlarmReceiver-title-->" + intent.extras?.getString("title").toString())
            Log.e(TAG, " MessagingAlarmReceiver-body-->" + intent.extras?.get("gcm.notification.body").toString())
            val activity_name: String = intent.extras?.get("activity").toString()
            val title: String = intent.extras?.get("google.c.a.c_l").toString()
            val body: String = intent.extras?.get("gcm.notification.body").toString()

            Handler(Looper.getMainLooper()).postDelayed({
                if (activity_name != null && !activity_name.equals("null") && activity_name.isNotEmpty() &&
                    title != null && !title.equals("null") && title.isNotEmpty() &&
                    body != null && !body.equals("null") && body.isNotEmpty()
                ) {
                    cancelFCMDefaultNotification(context)
                    sendNotification(context, title, body, activity_name)
                }
            }, 2000)
        }
    }

    private fun cancelFCMDefaultNotification(context: Context) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notifications: Array<StatusBarNotification> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            notificationManager.activeNotifications
        } else {
            emptyArray()
        }


        Log.e(TAG, "notifications Size: " + notifications.size)
        notifications.forEach {
            val channelId= if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                it.notification.channelId
            } else {
                ""
            }
            Log.e(
                TAG,
                "data : ${it.id} -- ${it.key} -- ${it.tag} -- ${it.notification.extras} -- ${it.notification.extras["title"]}" + " channelid --> " + channelId
            )
            if ((it.tag != null && it.tag.contains(
                    "fcm",
                    ignoreCase = true
                )) || channelId.equals(
                    "silentFirebase",
                    ignoreCase = true
                ) || channelId.equals(
                    "fcm_fallback_notification_channel",
                    ignoreCase = true
                ) || channelId.equals(
                    "fcm_notification",
                    ignoreCase = true
                )
            ) {
                notificationManager.cancel(it.tag, it.id)
            }
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                notificationManager.deleteNotificationChannel("fcm_fallback_notification_channel")
            }
        } catch (_: Exception) {
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                notificationManager.deleteNotificationChannel("silentFirebase")
            }
        } catch (_: Exception) {
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                notificationManager.deleteNotificationChannel("fcm")
            }
        } catch (_: Exception) {
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                notificationManager.deleteNotificationChannel("fcm_notification")
            }
        } catch (_: Exception) {
        }
    }

    private fun sendNotification(context: Context, title: String, body: String, mActivityName: String) {
        try {
            Log.e(TAG, "onMessageReceived title==>> ${mActivityName}")
            var intent = Intent(context, SplashActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            //Background work here
            if (!isAppInBackground(context)) {
                try {
                    intent = if (mActivityName.contains("setting")) {
                        Intent(context, SettingActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    } else if (mActivityName.contains("language")) {
                        Intent(context, LanguageActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    } else if (mActivityName.contains("cleaner")) {
                        Intent(context, JunkScanActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    } else if (mActivityName.contains("map")) {
                        Intent(context, MapAlbumActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    } else if (mActivityName.contains("recover")) {
                        Intent(context, RecoverMediaActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    } else {
                        Intent(context, HomeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Exception.002:$e")
                }
            } else {
                intent.putExtra("isFromNotification", true)
                intent.putExtra("activity", mActivityName)
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val pendingIntent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_IMMUTABLE)
            } else {
                PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_IMMUTABLE)
            }

            val notificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val notificationBuilder = NotificationCompat.Builder(context, context.getString(R.string.default_notification_channel_id))
                .setContentTitle(title)
                .setContentText(body)
                .setSmallIcon(R.drawable.ic_notification_logo)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setAutoCancel(true)

            notificationBuilder.setVibrate(LongArray(0))

            try {

                notificationBuilder.setChannelId(context.getString(R.string.default_notification_channel_id))
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val mChannel = NotificationChannel(
                        context.getString(R.string.default_notification_channel_id),
                        context.getString(R.string.default_notification_channel_id),
                        NotificationManager.IMPORTANCE_HIGH
                    )
                    mChannel.description = "Notifications are info related."
                    mChannel.lockscreenVisibility = VISIBILITY_PUBLIC
                    mChannel.enableLights(true)
                    mChannel.lightColor = Color.RED
                    mChannel.enableVibration(true)
                    mChannel.setShowBadge(true)
                    mChannel.vibrationPattern = longArrayOf(100, 200, 300, 400, 500, 400, 300, 200, 400)
                    notificationManager.createNotificationChannel(mChannel)
                } else {
                }
                notificationBuilder.setBadgeIconType(NotificationCompat.BADGE_ICON_SMALL)
                notificationManager.notify(Random().nextInt(), notificationBuilder.build())
            } catch (e: IllegalStateException) {
                Log.e("NotificationError", "Failed to send notification:$e")
            }
        } catch (e: Exception) {
        }

    }

//    fun isAppInBackground(context: Context): Boolean {
//        var isInBackground = true
//        try {
//            val am = (context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager)
//            val runningProcesses = am.runningAppProcesses
//            for (processInfo in runningProcesses) {
//                if (processInfo.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
//                    for (activeProcess in processInfo.pkgList) {
//                        if (activeProcess == context.getPackageName()) {
//                            isInBackground = false
//                        }
//                    }
//                }
//            }
//        } catch (e: java.lang.Exception) {
//            e.printStackTrace()
//            return true
//        }
//        return isInBackground
//    }

    private fun isAppInBackground(context: Context): Boolean {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val appProcesses = activityManager.runningAppProcesses ?: return true

        for (process in appProcesses) {
            if (process.processName == context.packageName) {
                return process.importance != ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND
            }
        }
        return true
    }
}