package com.photogallery.activities

import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isVisible
import com.adconfig.adsutil.Config.checkReInter
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.BannerAdHelper
import com.canhub.cropper.parcelable
import com.github.barteksc.pdfviewer.scroll.DefaultScrollHandle
import com.google.android.gms.ads.AdView
import com.photogallery.R
import com.photogallery.base.BaseActivity
import com.photogallery.base.BaseNoThemeActivity
import com.photogallery.databinding.ActivityPdfReaderBinding
import com.photogallery.extension.getFilenameFromPath
import com.photogallery.utils.AdCache
import com.photogallery.utils.MessageEvent
import com.photogallery.utils.Preferences
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File

class PdfReaderActivity : BaseNoThemeActivity() {

    private var pdfPath: String? = null
    private var pdfName: String? = null
    private var pdfUri: Uri? = null
    private var isOutside = false

    private val fullScreenFlags =
        View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

    private val normalFlags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE

    var isDarkMode = false
    var currentPage = 0

    lateinit var preferences: Preferences
    lateinit var binding: ActivityPdfReaderBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityPdfReaderBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        preferences = Preferences(this)
        if (preferences.isNeedInterAd) {
            AdmobIntersAdImpl().load(this, getString(R.string.inter_all))
        } else {
            checkReInter {
                if (it) {
                    AdmobIntersAdImpl().load(this, getString(R.string.inter_all))
                    preferences.isNeedInterAd = true
                }
            }
        }

        pdfPath = intent.getStringExtra("pdfPath")
        pdfName = intent.getStringExtra("pdfName")

        pdfUri = intent.parcelable("pdfUri")
        isOutside = intent.getBooleanExtra("isOutside", false)

        loadBanner()
        if (!EventBus.getDefault().isRegistered(this)) EventBus.getDefault().register(this)

        if (savedInstanceState != null) {
            currentPage = savedInstanceState.getInt("CURRENT_PAGE", 0)
        }
        intView()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (EventBus.getDefault().isRegistered(this)) EventBus.getDefault().unregister(this)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        if (event.type.equals("refresh")) {
        }
    }

    var isAdLoaded = false
    var mAdView: AdView? = null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()

    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }

    private fun loadBanner() {
        if (!isAdLoaded) {

            val adId = getString(R.string.b_imageListActivity)
            BannerAdHelper.showBanner(
                this,
                binding.layoutBanner.mFLAd,
                binding.layoutBottomAd,
                adId,
                AdCache.imageListAdView,
                { isLoaded, adView, message ->
                    if (!isDestroyed) {
                        mAdView = adView
                        AdCache.imageListAdView = adView
                        isAdLoaded = isLoaded
                    }
                })
        }
    }

    fun changeMode(isDarkMode: Boolean) {
        if (isDarkMode) {
            binding.customPdfView.setNightMode(false)
            binding.root.setBackgroundColor(
                Color.parseColor("#F1F1F1")
            )
            binding.loutSelectOption.setBackgroundColor(
                Color.parseColor("#FFFFFFFF")
            )
            binding.ivDarkMode.setImageResource(R.drawable.ic_dark_mode)

            binding.ivDarkMode.setColorFilter(Color.parseColor("#FF0E1217"))
            binding.ivSwipe.setColorFilter(Color.parseColor("#FF0E1217"))
            binding.icBack.setColorFilter(Color.parseColor("#FF0E1217"))

        } else {
            binding.customPdfView.setNightMode(true)
            binding.root.setBackgroundColor(
                Color.parseColor("#161616")
            )
            binding.loutSelectOption.setBackgroundColor(
                Color.parseColor("#1F1F1F")
            )
            binding.ivDarkMode.setImageResource(R.drawable.ic_light_mode)

            binding.ivDarkMode.setColorFilter(Color.parseColor("#FFFFFF"))
            binding.ivSwipe.setColorFilter(Color.parseColor("#FFFFFF"))
            binding.icBack.setColorFilter(Color.parseColor("#FFFFFF"))
        }

    }

    fun intView() {
        binding.icBack.setOnClickListener {
            onBackPressed()
        }
        changeMode(isDarkMode)

        if (pdfName != null && pdfPath != null) {
            setupPdfViewWithFile()
        } else if (pdfUri != null) {
            setupPdfViewWithUri()
        } else {
            Toast.makeText(this, "Error Occurred", Toast.LENGTH_SHORT).show()
            finish()
        }

    }

    private fun setUpViewActions() {
        binding.btnDarkMode.setOnClickListener {
            isDarkMode = !isDarkMode
            changeMode(isDarkMode)
        }


        binding.btnRotate.setOnClickListener {
            requestedOrientation = if (resources.configuration.orientation == 1) {
                ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            } else {
                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            }

        }

        binding.btnBrightness.setOnClickListener {
            showBrightnessDialog()
        }


        binding.btnSwipe.setOnClickListener {
            if (binding.customPdfView.isPageFlingEnabled) {
                binding.customPdfView.setPageFling(false)
                binding.ivSwipe.setImageResource(R.drawable.ic_multi_swipe)
                Toast.makeText(this, "Multi Swipe Enabled", Toast.LENGTH_SHORT).show()
            } else {
                binding.customPdfView.setPageFling(true)
                binding.ivSwipe.setImageResource(R.drawable.ic_single_swipe)
                Toast.makeText(this, "Single Swipe Enabled", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnJump.setOnClickListener {
            showJumpDialog()
        }

    }

    private fun setupPdfViewWithUri() {

        binding.customPdfView
            .fromUri(pdfUri)
            .onTap {
                if (binding.loutToolbar.isVisible) {
                    hideActionUI()
                } else {
                    showActionUI()
                }
                true
            }
            .enableSwipe(true)
            .swipeHorizontal(false)
            .enableDoubletap(true)
            .defaultPage(currentPage)
            .enableAnnotationRendering(true)
            .password(null)
            .scrollHandle(DefaultScrollHandle(this))
            .enableAntialiasing(true)
            .nightMode(isDarkMode)
            .spacing(0)
            .load()

        val contentResolver = contentResolver
        val projection = {
            arrayOf(
                android.provider.MediaStore.Files.FileColumns._ID,
                android.provider.MediaStore.Files.FileColumns.DISPLAY_NAME,
                android.provider.MediaStore.Files.FileColumns.SIZE,
                android.provider.MediaStore.Files.FileColumns.DATE_ADDED
            )
        }
        val cursor = contentResolver.query(
            pdfUri!!,
            projection(),
            null,
            null,
            null
        )
        var title: String? = null

        if (cursor != null) {
            cursor.moveToFirst()

            title =
                cursor.getString(cursor.getColumnIndexOrThrow(android.provider.MediaStore.Files.FileColumns.DISPLAY_NAME))

            cursor.close()
        }

        binding.txtTitle.text = resizeName(title!!)
        binding.icMenu.visibility = View.GONE

        setUpViewActions()

    }

    private fun setupPdfViewWithFile() {

        binding.txtTitle.text = pdfPath?.getFilenameFromPath()
        val file = File(pdfPath!!)

        binding.customPdfView
            .fromFile(file)
            .onTap {
                if (binding.loutToolbar.isVisible) {
                    hideActionUI()
                } else {
                    showActionUI()
                }
                true
            }
            .enableSwipe(true)
            .swipeHorizontal(false)
            .enableDoubletap(true)
            .defaultPage(currentPage)
            .nightMode(isDarkMode)
            .enableAnnotationRendering(true)
            .password(null)
            .scrollHandle(DefaultScrollHandle(this))
            .enableAntialiasing(true)
            .spacing(0)
            .load()

        binding.icMenu.setOnClickListener {
            showOptionPopup()
        }

        setUpViewActions()

    }

    fun showActionUI() {
        binding.loutToolbar.visibility = View.VISIBLE
        binding.loutBottom.visibility = View.VISIBLE
        window.decorView.systemUiVisibility = normalFlags
    }

    fun hideActionUI() {
        binding.loutToolbar.visibility = View.GONE
        binding.loutBottom.visibility = View.GONE
        window.decorView.systemUiVisibility = fullScreenFlags
    }

    fun resizeName(s: String): String {
        if (s.length <= 32) {
            return s
        }
        val first = s.substring(0, 18)
        val last = s.substring(s.length - 10, s.length)
        return "$first...$last"
    }

    private fun showOptionPopup() {

    }

    private fun showJumpDialog() {

    }

    private fun showBrightnessDialog() {

    }

    override fun onBackPressed() {
        if (isOutside) {
            startActivity(Intent(this, HomeActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            })
            finish()
        } else {
            super.onBackPressed()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("CURRENT_PAGE", binding.customPdfView.currentPage)
    }

}