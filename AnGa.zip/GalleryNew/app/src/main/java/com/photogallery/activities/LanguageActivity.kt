package com.photogallery.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.flexbox.AlignItems
import com.google.android.flexbox.FlexDirection
import com.google.android.flexbox.FlexboxLayoutManager
import com.adconfig.AdsConfig
import com.adconfig.adsutil.Config.checkReInter
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.NativeAdHelper
import com.adconfig.adsutil.admob.NativeLayoutType
import com.google.android.flexbox.FlexWrap
import com.photogallery.R
import com.photogallery.adapter.LanguageAdapter
import com.photogallery.base.BaseActivity
import com.photogallery.databinding.ActivityLanguageBinding
import com.photogallery.extension.getLanguageList
import com.photogallery.model.LanguageData
import com.photogallery.utils.Constant
import com.photogallery.utils.LogEvent
import com.photogallery.utils.Preferences
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class LanguageActivity : BaseActivity() {

    lateinit var binding: ActivityLanguageBinding

    lateinit var adapter: LanguageAdapter
    var selectedLang = "en"
    var isOpenFromSplash: Boolean = false
    lateinit var preferences: Preferences
    var languageList: ArrayList<LanguageData> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        if (preferences.isNeedInterAd) {
            AdmobIntersAdImpl().load(this, getString(R.string.inter_language))
        } else {
            checkReInter {
                if (it) {
                    AdmobIntersAdImpl().load(this, getString(R.string.inter_language))
                    preferences.isNeedInterAd = true
                }
            }
        }
        binding = ActivityLanguageBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        inti()
        loadAd()
    }

    private fun loadAd() {
        NativeAdHelper(
            this,
            binding.frameNative,
            binding.llBottom,
            NativeLayoutType.NativeBig,
            getString(R.string.native_language)
        ).loadAd();
    }

    private fun inti() {
        preferences.isSetLanguage = true
        binding.txtTitle.text = getString(R.string.select_language)
        binding.ivDone.visibility = View.VISIBLE

        if (intent != null)
            isOpenFromSplash = intent.getBooleanExtra(Constant.EXTRA_IS_OPEN_FROM_SPLASH, false)


        val calendar = Calendar.getInstance()
        val format = SimpleDateFormat("dd/mm/yy", Locale.ENGLISH)
        val today = format.format(calendar.timeInMillis)
        LogEvent.logEvent("LanguageActivity", "FromSplash:$today")

        //getLanList()
        languageList = getLanguageList(preferences.systemLocalLanguage)
        intiListener()

        binding.icBack.visibility = if (isOpenFromSplash) View.INVISIBLE else View.VISIBLE

        selectedLang = preferences.selectLanguageCode
        var selectPos = languageList.indexOfFirst { it.languageCode == selectedLang }

        val defaultLanguage: String = Locale.getDefault().language
        preferences.systemLocalLanguage = defaultLanguage
        if (selectPos <= 0) selectPos = 0
        if (selectedLang == "0") selectedLang = preferences.systemLocalLanguage

        Log.e("LanguageActivity", "systemLocalLanguage:${preferences.systemLocalLanguage}")
        Log.e("LanguageActivity", "defaultLanguage:$defaultLanguage")
        Log.e("LanguageActivity", "selectedLang:$selectedLang")
        Log.e("LanguageActivity", "selectPos:$selectPos")

//        val gridLayoutManager = GridLayoutManager(this, 2, RecyclerView.VERTICAL, false)
//        binding.recyclerView.layoutManager = gridLayoutManager
        binding.recyclerView.layoutManager = FlexboxLayoutManager(this@LanguageActivity).apply {
            flexDirection = FlexDirection.ROW
            flexWrap = FlexWrap.WRAP
            alignItems = AlignItems.FLEX_START
        }

        adapter = LanguageAdapter(
            this,
            languageList,
            clickListener = {
                //selectPos = it
                selectedLang = it
            })
        adapter.selectPos = selectPos
        adapter.selectLang = selectedLang
        binding.recyclerView.adapter = adapter
        binding.recyclerView.scrollToPosition(selectPos)
        if (selectPos >= 0) {
            binding.recyclerView.scrollToPosition(selectPos)
            enableNext()
        }


//        val myAnim = AnimationUtils.loadAnimation(this, R.anim.bounce);
//        val interpolator =
//            com.photogallery.utils.MyBounceInterpolator(0.2, 20.0)
//        myAnim.setInterpolator(interpolator)
//        myAnim.repeatMode= Animation.RESTART
//        binding.loutToolbar.ivDone.startAnimation(myAnim)


    }

    fun enableNext() {
//        binding.loutToolbar.ivDone.beVisible()
//        val myAnim = AnimationUtils.loadAnimation(this, R.anim.bounce);
//        val interpolator = MyBounceInterpolator(0.2, 20.0)
//        myAnim.setInterpolator(interpolator)
//        myAnim.repeatMode = Animation.RESTART
//        binding.loutToolbar.ivDone.startAnimation(myAnim)
    }

    private fun updateViews(languageCode: String) {
        com.photogallery.utils.LocaleHelper.setLocale(
            this,
            languageCode
        )
    }

    private var lastClickTime = 0L
    private fun intiListener() {
        binding.icBack.setOnClickListener {
            finish()
        }
        binding.ivDone.setOnClickListener {
            val currentTime = System.currentTimeMillis()
            if (currentTime - lastClickTime >= 800) {
                lastClickTime = currentTime

                preferences.isSetLanguage = true
                preferences.selectLanguageCode = selectedLang

                if (selectedLang == "0") {
                    updateViews(preferences.systemLocalLanguage)
                } else {
                    updateViews(selectedLang)
                }
                if (isOpenFromSplash) {
                    val intent = if (!checkStoragePermission())
                        Intent(this, PermissionActivity::class.java)
                    else
                        Intent(this, HomeActivity::class.java)

                    if (preferences.isNeedInterAd) {
                        AdsConfig.showInterstitialAd(this@LanguageActivity) {
                            if (it) preferences.isNeedInterAd = false
                            startActivity(intent)
                            finish()
                        }
                    } else {
                        startActivity(intent)
                        finish()
                    }
                } else {

                    if (preferences.isNeedInterAd) {
                        AdsConfig.showInterstitialAd(this@LanguageActivity) {
                            if (it) preferences.isNeedInterAd = false
                            setResult(RESULT_OK)
                            finish()
                        }
                    } else {
                        setResult(RESULT_OK)
                        finish()
                    }
                }
            }
        }
//        binding.loutToolbar.ivDone.setOnClickListener {
//            preferences.setSelectLanguage(selectPos)
//            updateViews(languageList[selectPos].languageCode)
//            if (isOpenFromSplash) {
//                val intent = if (!checkStoragePermission())
//                    Intent(this, PermissionActivity::class.java)
//                else
//                    Intent(this, HomeActivity::class.java)
//
//                if (preferences.isNeedInterAd) {
//                    AdsConfig.showInterstitialAd(this@LanguageActivity) {
//                        if(it) preferences.isNeedInterAd = false
//                        startActivity(intent)
//                        finish()
//                    }
//                } else {
//                    startActivity(intent)
//                    finish()
//                }
//
//            } else {
//                setResult(RESULT_OK)
//                finish()
//            }
//
//        }
    }

//    private fun getLanList() {
//        //strings
//        languageList.add(LanguageData(getString(R.string.english), "en", ContextCompat.getDrawable(this, R.drawable.ic_app_logo)))
//        languageList.add(LanguageData(getString(R.string.arabic), "ar", ContextCompat.getDrawable(this, R.drawable.ic_app_logo)))
//        languageList.add(LanguageData(getString(R.string.french), "fr", ContextCompat.getDrawable(this, R.drawable.ic_app_logo)))
//        languageList.add(LanguageData(getString(R.string.spanish), "es", ContextCompat.getDrawable(this, R.drawable.ic_app_logo)))
//        languageList.add(LanguageData(getString(R.string.russian), "ru", ContextCompat.getDrawable(this, R.drawable.ic_app_logo)))
//        languageList.add(LanguageData(getString(R.string.japanese), "ja", ContextCompat.getDrawable(this, R.drawable.ic_app_logo)))
//        languageList.add(LanguageData(getString(R.string.italian), "it", ContextCompat.getDrawable(this, R.drawable.ic_app_logo)))
//        languageList.add(LanguageData(getString(R.string.portuguese), "pt", ContextCompat.getDrawable(this, R.drawable.ic_app_logo)))
//        languageList.add(LanguageData(getString(R.string.marathi), "mr", ContextCompat.getDrawable(this, R.drawable.ic_app_logo)))
//        languageList.add(LanguageData(getString(R.string.bangali), "bn", ContextCompat.getDrawable(this, R.drawable.ic_app_logo)))
//        languageList.add(LanguageData(getString(R.string.china), "zh", ContextCompat.getDrawable(this, R.drawable.ic_app_logo)))
//        languageList.add(LanguageData(getString(R.string.deutsch), "nl", ContextCompat.getDrawable(this, R.drawable.ic_app_logo)))
//        languageList.add(LanguageData(getString(R.string.hindi), "hi", ContextCompat.getDrawable(this, R.drawable.ic_app_logo)))
//        languageList.add(LanguageData(getString(R.string.indonesian), "in", ContextCompat.getDrawable(this, R.drawable.ic_app_logo)))
//        languageList.add(LanguageData(getString(R.string.korean), "ko", ContextCompat.getDrawable(this, R.drawable.ic_app_logo)))
//        languageList.add(LanguageData(getString(R.string.melayu), "ms", ContextCompat.getDrawable(this, R.drawable.ic_app_logo)))
//        languageList.add(LanguageData(getString(R.string.philippians), "phi", ContextCompat.getDrawable(this, R.drawable.ic_app_logo)))
//        languageList.add(LanguageData(getString(R.string.tamil), "ta", ContextCompat.getDrawable(this, R.drawable.ic_app_logo)))
//        languageList.add(LanguageData(getString(R.string.telugu), "te", ContextCompat.getDrawable(this, R.drawable.ic_app_logo)))
//        languageList.add(LanguageData(getString(R.string.thai), "th", ContextCompat.getDrawable(this, R.drawable.ic_app_logo)))
//        languageList.add(LanguageData(getString(R.string.turkish), "tr", ContextCompat.getDrawable(this, R.drawable.ic_app_logo)))
//        languageList.add(LanguageData(getString(R.string.vietnamese), "vi", ContextCompat.getDrawable(this, R.drawable.ic_app_logo)))
//
//    }

}