package com.photogallery.dialog

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.format.Formatter
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import androidx.core.content.ContextCompat
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.photogallery.R
import com.photogallery.databinding.DialogAlbumDeatilsBinding
import com.photogallery.extension.beGoneIf
import com.photogallery.model.AlbumData
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale

class AlbumDetailsDialog(var mContext: Context, var pictureData: AlbumData, val isFromPrivate: Boolean = false) :
    Dialog(mContext) {

    lateinit var bindingDialog: DialogAlbumDeatilsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
//        window?.decorView!!.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        bindingDialog = DialogAlbumDeatilsBinding.inflate(layoutInflater)
//        bindingDialog.root.setPadding(0, 0, 0, mContext.navigationBarHeight)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
    }

    private fun intView() {

        intListener()
        bindingDialog.llPath.beGoneIf(isFromPrivate)

        val formatDetails = SimpleDateFormat("dd/MM/yyyy, hh:mm aa", Locale.ENGLISH)
        bindingDialog.txtName.text = pictureData.title
        bindingDialog.txtPath.text = pictureData.folderPath
        val strDate = formatDetails.format(pictureData.date)

        bindingDialog.txtTime.text = strDate
        val size = getFolderSize(File(pictureData.folderPath))
        bindingDialog.txtSize.text = Formatter.formatShortFileSize(mContext, size)
        bindingDialog.txtFileCount.text = "${pictureData.mediaData.size}"

    }


    fun getFolderSize(dir: File): Long {
        var size: Long = 0
        dir.listFiles()?.let {
            for (file in it) {
                size += if (file.isFile) {
                    // System.out.println(file.getName() + " " + file.length());
                    file.length()
                } else getFolderSize(file)
            }
        }

        return size
    }

    private fun intListener() {

        bindingDialog.btnOK.setOnClickListener {
            dismiss()
        }
    }

//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)
}