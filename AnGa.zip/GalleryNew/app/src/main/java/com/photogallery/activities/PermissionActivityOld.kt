package com.photogallery.activities


import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.activity.enableEdgeToEdge
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.adconfig.AdsConfig
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.photogallery.R
import com.photogallery.base.BaseActivity
import com.photogallery.databinding.ActivityPermissionBinding
import com.photogallery.extension.toast
import com.photogallery.utils.Constant
import com.photogallery.utils.LogEvent
import com.photogallery.utils.Preferences
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class PermissionActivityOld : BaseActivity() {

    private lateinit var binding: ActivityPermissionBinding
    private lateinit var preferences: Preferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPermissionBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        preferences = Preferences(this)
        init()
    }

    private fun init() {
        binding.txtMsg.text = getString(R.string.permission_msg)
        if (checkStoragePermission()) startNextScreen()

        binding.btnAllow.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                requestNotificationAndMediaPermissions()
            } else {
                requestLegacyPermissions()
            }
        }
        binding.rlToggle.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                requestNotificationAndMediaPermissions()
            } else {
                requestLegacyPermissions()
            }
        }
    }

    private fun requestNotificationAndMediaPermissions() {
        val list = mutableListOf<String>()

        // Notification (Android 13+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            list.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        // Media permissions
        list.add(Manifest.permission.READ_MEDIA_IMAGES)
        list.add(Manifest.permission.READ_MEDIA_VIDEO)
        list.add(Manifest.permission.READ_MEDIA_AUDIO)

        Dexter.withContext(this)
            .withPermissions(list)
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport?) {
                    if (checkStoragePermission()) startNextScreen()
                    else toast(getString(R.string.permission_toast_msg))
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: MutableList<PermissionRequest>?, token: PermissionToken?
                ) {
                    token?.continuePermissionRequest()
                }
            }).check()
    }

    private fun requestLegacyPermissions() {
        val list = mutableListOf<String>()

        list.add(Manifest.permission.READ_EXTERNAL_STORAGE)

        Dexter.withContext(this)
            .withPermissions(list)
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport?) {
                    if (report?.areAllPermissionsGranted() == true) {
                        startNextScreen()
                    } else if (report?.isAnyPermissionPermanentlyDenied == true) {
                        openAppSettings()
                    } else {
                        toast(getString(R.string.permission_toast_msg))
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: MutableList<PermissionRequest>?, token: PermissionToken?
                ) {
                    token?.continuePermissionRequest()
                }
            }).check()
    }

    private fun startNextScreen() {
        val today = SimpleDateFormat("dd/MM/yy", Locale.ENGLISH)
            .format(Calendar.getInstance().time)
        LogEvent.logEvent("PermissionActivity", "startNextScreen:$today")

        val intent = if (!preferences.isSetLanguage) {
            Intent(this, LanguageActivity::class.java)
                .putExtra(Constant.EXTRA_IS_OPEN_FROM_SPLASH, true)
        } else {
            Intent(this, HomeActivity::class.java)
        }

        intent.addFlags(
            Intent.FLAG_ACTIVITY_CLEAR_TASK or
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
        )
        startActivity(intent)
    }

    private fun openAppSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        intent.data = Uri.fromParts("package", packageName, null)
        startActivity(intent)
    }
}
