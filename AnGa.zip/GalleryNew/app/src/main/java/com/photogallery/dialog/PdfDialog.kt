package com.photogallery.dialog

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import com.photogallery.databinding.DialogPdfBinding
import com.photogallery.utils.Constant


class PdfDialog(
    val activity: Activity,
    val txtTitle: String,
    val txtMessage: String,
    val positiveListener: () -> Unit,
) : Dialog(activity) {

    lateinit var bindingDialog: DialogPdfBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)

        bindingDialog = DialogPdfBinding.inflate(layoutInflater)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )

        intView()
    }

    private fun intView() {
        bindingDialog.txtTitle.text = txtTitle
        bindingDialog.txtMsg.text = txtMessage

        bindingDialog.btnPositive.setOnClickListener {
            dismiss()
            positiveListener.invoke()
        }
        bindingDialog.btnNegative.setOnClickListener {
            dismiss()
        }
    }

}