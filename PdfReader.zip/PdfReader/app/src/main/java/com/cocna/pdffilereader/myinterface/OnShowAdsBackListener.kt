package com.cocna.pdffilereader.myinterface

interface OnShowAdsBackListener {
    fun onShowAds()
}