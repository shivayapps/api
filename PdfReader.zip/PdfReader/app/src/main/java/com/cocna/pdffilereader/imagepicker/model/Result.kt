package com.cocna.pdffilereader.imagepicker.model

data class Result(val status: CallbackStatus, val images: ArrayList<Image>)