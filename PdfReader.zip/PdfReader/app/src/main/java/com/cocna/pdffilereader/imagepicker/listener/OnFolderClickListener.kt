package com.cocna.pdffilereader.imagepicker.listener

import com.cocna.pdffilereader.imagepicker.model.Folder

interface OnFolderClickListener {
    fun onFolderClick(folder: Folder)
}