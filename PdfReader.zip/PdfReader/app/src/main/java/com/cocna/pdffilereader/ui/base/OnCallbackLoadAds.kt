package com.cocna.pdffilereader.ui.base

/**
 * Created by Thuytv on 25/06/2022.
 */
interface OnCallbackLoadAds {
    fun onCallbackActionLoadAds(isSuccess: Boolean)
}