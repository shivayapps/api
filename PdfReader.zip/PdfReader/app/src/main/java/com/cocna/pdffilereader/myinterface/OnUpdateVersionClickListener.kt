package com.cocna.pdffilereader.myinterface

interface OnUpdateVersionClickListener {
    fun onClickButtonDialog(isUpdateNow: Boolean)
}