package com.cocna.pdffilereader.myinterface

import android.view.MenuItem

interface OnPopupMenuItemClickListener {
    fun onClickItemPopupMenu(menuItem: MenuItem?)
}