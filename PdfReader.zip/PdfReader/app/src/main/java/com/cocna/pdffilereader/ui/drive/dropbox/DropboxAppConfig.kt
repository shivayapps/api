package com.cocna.pdffilereader.ui.drive.dropbox


class DropboxAppConfig(
    val apiKey: String ="hafccwtf4y7s383",
    val clientIdentifier: String = "db-hafccwtf4y7s383"
)