package com.adconfig.adsutil

object SmSession {

    var isLibraryInitialized = false
    var IS_DEBUG = true
    var admobInterstitialAdId: String = ""
    var admobAppOpenId: String = ""
    var admobBannerId: String = ""
    var admobNativeId: String = ""
    var admobRewardId: String = ""
    var adNetwork: AdNetwork = AdNetwork.ADMOB

}