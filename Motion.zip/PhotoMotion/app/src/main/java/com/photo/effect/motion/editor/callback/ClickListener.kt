package com.photo.effect.motion.editor.callback

import com.photo.effect.motion.editor.model.EffectData

interface ClickListener {
    fun onClick(effectData: EffectData?, i: Int)
}