package com.photo.effect.motion.editor.permission;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.util.Log;


import com.nabinbhandari.android.permissions.PermissionHandler;
import com.nabinbhandari.android.permissions.Permissions;
import com.photo.effect.motion.editor.MyApp;
import com.photo.effect.motion.editor.R;

import java.util.ArrayList;

public class PermissionManager {
    static boolean isAllowClick = false;

    public interface callBack {
        void doNext();

        void noPermission(boolean hasAndroidPermissions);
    }

    public interface callBackWithDismiss {
        void doNext();

        void noPermission(boolean hasAndroidPermissions);

        void onDismiss();

    }

    public static String getHeaderText(String permission) {
        if (permission.matches(Manifest.permission.READ_MEDIA_IMAGES)) {
            return "Media & Storage";
        } else if (permission.matches(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            return "Media & Storage";
        } else if (permission.matches(Manifest.permission.READ_CONTACTS)) {
            return "Contacts";
        } else if (permission.matches(Manifest.permission.CAMERA)) {
            return "Camera";
        } else if (permission.matches(Manifest.permission.RECORD_AUDIO)) {
            return "Record Audio";
        } else {
            return "Other";
        }
    }

    public static String getSubText(String permission) {
        if (permission.matches(Manifest.permission.READ_MEDIA_IMAGES)) {
            return "Allowing us to access files enables you to save keyboard data.";
        } else if (permission.matches(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            return "Allowing us to access files enables you to save keyboard data.";
        } else if (permission.matches(Manifest.permission.READ_CONTACTS)) {
            return "Allowing us to access contacts for you show as typing suggestion";
        } else if (permission.matches(Manifest.permission.CAMERA)) {
            return "Allowing us to access camera functionality";
        } else if (permission.matches(Manifest.permission.RECORD_AUDIO)) {
            return "Allowing us to access record audio for voice typing";
        } else {
            return "Allowing us to access this functionality";
        }
    }

    public static int getIcon(String permission) {
        if (permission.matches(Manifest.permission.READ_MEDIA_IMAGES)) {
            return R.drawable.ic_storage;
        } else if (permission.matches(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            return R.drawable.ic_storage;
        } else if (permission.matches(Manifest.permission.READ_CONTACTS)) {
            return R.drawable.ic_contact;
        } else if (permission.matches(Manifest.permission.CAMERA)) {
            return R.drawable.ic_photo_camera;
        } else if (permission.matches(Manifest.permission.RECORD_AUDIO)) {
            return R.drawable.ic_audio;
        }
        return R.drawable.ic_shield;
    }

    public static void doPermissionTask(Context context, callBack mcallback, String[] permissions) {
//        PreferenceManager.saveData(context, PreferenceKeys.SystemDialogOpened, true);
        MyApp.isDialogOpen=true;
//        String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
        isAllowClick = false;
        if (context != null) {
            boolean hasAndroidPermissions = hasPermissions(context, permissions);
            Activity activity = ((Activity) context);
            if (!hasAndroidPermissions /*&& !activity.isFinishing()*/) {
//                StaticMethod.isPermiationDialogOpen = true;
                MyApp.isDialogOpen=true;
                PromptDialog pd = new PromptDialog(context)
                        .setDialogType(3)
                        .setAnimationEnable(true)
                        .setIcon(getIcon(permissions[0]))
                        .setTitleText("Permission Required")
                        .setContentText(getHeaderText(permissions[0]))
                        .setOtherContentText(getSubText(permissions[0]))
                        .setPositiveListener("Grant Access", new PromptDialog.OnPositiveListener() {
                            @Override
                            public void onClick(PromptDialog dialog) {
                                dialog.dismiss();
                                isAllowClick = true;
                                Permissions.check(context, permissions, null/*rationale*/, null/*options*/, new PermissionHandler() {
                                    @Override
                                    public void onGranted() {
                                        mcallback.doNext();
                                    }

                                    @Override
                                    public void onDenied(Context context, ArrayList<String> deniedPermissions) {
                                        super.onDenied(context, deniedPermissions);
                                        boolean hasAndroidPermissions = hasPermissions(context, permissions);
                                        mcallback.noPermission(hasAndroidPermissions);
                                    }
                                });
                            }
                        })
                        .setNegativeListener("Not now", new PromptDialog.OnNegativeListener() {
                            @Override
                            public void onClick(PromptDialog dialog) {
                                dialog.dismiss();
                                mcallback.noPermission(false);
                            }
                        });
                pd.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialog) {
//                        StaticMethod.isPermiationDialogOpen = false;
                        MyApp.isDialogOpen=false;
                        mcallback.noPermission(isAllowClick);
                    }
                });
                if (!activity.isFinishing()) {
                    pd.show();
                }
            } else {
                mcallback.doNext();
            }
        }
    }

    public static void doPermissionTask(Context context, callBackWithDismiss mcallback, String[] permissions) {
//        PreferenceManager.saveData(context, PreferenceKeys.SystemDialogOpened, true);
        MyApp.isDialogOpen=true;
//        String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
        isAllowClick = false;
        if (context != null) {
            boolean hasAndroidPermissions = hasPermissions(context, permissions);
            if (!hasAndroidPermissions) {
//                StaticMethod.isPermiationDialogOpen = true;
                MyApp.isDialogOpen=true;
                PromptDialog pd = new PromptDialog(context)
                        .setDialogType(3)
                        .setAnimationEnable(true)
                        .setIcon(getIcon(permissions[0]))
                        .setTitleText("Permission Required")
                        .setContentText(getHeaderText(permissions[0]))
                        .setOtherContentText(getSubText(permissions[0]))
                        .setPositiveListener("Grant Access", new PromptDialog.OnPositiveListener() {
                            @Override
                            public void onClick(PromptDialog dialog) {
                                dialog.dismiss();
                                isAllowClick = true;
                                Permissions.check(context, permissions, null/*rationale*/, null/*options*/, new PermissionHandler() {
                                    @Override
                                    public void onGranted() {
//                                        PreferenceManager.saveData(context, PreferenceKeys.SystemDialogOpened, true);
                                        MyApp.isDialogOpen=true;
                                        mcallback.doNext();
                                    }

                                    @Override
                                    public void onDenied(Context context, ArrayList<String> deniedPermissions) {
                                        super.onDenied(context, deniedPermissions);
                                        boolean hasAndroidPermissions = hasPermissions(context, permissions);
//                                        PreferenceManager.saveData(context, PreferenceKeys.SystemDialogOpened, true);
                                        MyApp.isDialogOpen=true;
                                        mcallback.noPermission(hasAndroidPermissions);
                                    }
                                });
                            }
                        })
                        .setNegativeListener("Not now", new PromptDialog.OnNegativeListener() {
                            @Override
                            public void onClick(PromptDialog dialog) {
                                dialog.dismiss();
                                mcallback.noPermission(false);
                            }
                        });
                pd.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialog) {
//                        StaticMethod.isPermiationDialogOpen = false;
                        MyApp.isDialogOpen=false;
                        mcallback.onDismiss();
                    }
                });
                pd.show();
            } else {
                mcallback.doNext();
            }
        }
    }

    public static boolean hasPermissions(Context context, String... permissions) {

        boolean hasAllPermissions = true;

        for (String permission : permissions) {
            //you can return false instead of assigning, but by assigning you can log all permission values
            if (!hasPermission(context, permission)) {
                hasAllPermissions = false;
            }
        }

        return hasAllPermissions;

    }

    public static boolean hasPermission(Context context, String permission) {
        if (context != null) {
            int res = context.checkCallingOrSelfPermission(permission);

            Log.v("msg", "permission: " + permission + " = \t\t" +
                    (res == PackageManager.PERMISSION_GRANTED ? "GRANTED" : "DENIED"));

            return res == PackageManager.PERMISSION_GRANTED;
        } else {
            return false;
        }

    }
}
