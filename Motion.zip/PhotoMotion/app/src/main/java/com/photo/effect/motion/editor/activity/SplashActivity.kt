package com.photo.effect.motion.editor.activity

import android.content.Intent
import android.os.*
import androidx.appcompat.app.AppCompatActivity
import com.adconfig.AdsConfig.Companion.showInterstitialAd
import com.photo.effect.motion.editor.R

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(1024, 1024)
        setContentView(R.layout.activity_splash_screen)

//        InterstitialAdHelper.loadAd(this,object : AdMobAdsListener{
//
//        })
        delayEnter()
    }

    private fun delayEnter() {
        object : CountDownTimer(4000, 500) {
            override fun onTick(l: Long) {}
            override fun onFinish() {
//                if (AppUtil.check_internet(this@SplashActivity)) {
//                    interstitialAd()
//                } else {
                    enter()
//                }
            }
        }.start()
    }

    private fun enter() {
        showInterstitialAd(this@SplashActivity) {

            val intent = Intent(applicationContext, MainActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(intent)
            //startActivity(Intent(this@SplashActivity, MainActivity::class.java))
            this@SplashActivity.finish()
        }
    }

}