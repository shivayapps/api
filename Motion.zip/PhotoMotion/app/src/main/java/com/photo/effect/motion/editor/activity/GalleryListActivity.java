package com.photo.effect.motion.editor.activity;

import android.app.Activity;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentTransaction;

import com.adconfig.adsutil.admob.NativeAdHelper;
import com.adconfig.adsutil.admob.NativeLayoutType;

import com.photo.effect.motion.editor.fragment.PhotoFragment;
import com.photo.effect.motion.editor.R;
import com.photo.effect.motion.editor.utils.Share;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;


public class GalleryListActivity extends FragmentActivity implements OnClickListener {
    private static GalleryListActivity galleryActivity;
    public Activity mContext;
    public TextView tv_title;
    private ImageView iv_close;
    private long mLastClickTime = 0;

    public static GalleryListActivity getGalleryActivity() {
        return galleryActivity;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_gallery_album);
        galleryActivity = this;
        mContext = this;
        initView();
        initViewAction();

    }

    private void initView() {
        tv_title =  findViewById(R.id.tv_title);
        iv_close =  findViewById(R.id.iv_close);

        FrameLayout mAdView = findViewById(R.id.adView);

        new NativeAdHelper(this, mAdView, NativeLayoutType.NativeBanner,null,"").loadAd();

    }


    private void initViewAction() {
        iv_close.setOnClickListener(this);
        updateFragment(PhotoFragment.newInstance());
    }


    public void updateFragment(Fragment fragment) {
        FragmentTransaction beginTransaction = getSupportFragmentManager().beginTransaction();
        beginTransaction.replace(R.id.simpleFrameLayout, fragment);
        beginTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        beginTransaction.commit();
    }

    public void onBackPressed() {
        Share.lst_album_image.clear();
        finish();
        overridePendingTransition(R.anim.left_in, R.anim.right_out);
    }

    public void onClick(View view) {
        if (SystemClock.elapsedRealtime() - mLastClickTime >= 1000) {
            mLastClickTime = SystemClock.elapsedRealtime();
            int id = view.getId();
            if (id == R.id.iv_close) {
                onBackPressed();
            }
        }
    }




    public void onPause() {

        super.onPause();
    }

    public void onResume() {
        super.onResume();
        findViewById(R.id.fl_adplaceholder).setVisibility(View.GONE);
    }

    public void onDestroy() {
        super.onDestroy();
    }
}
