package com.photo.effect.motion.editor.activity;

import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.FrameLayout;

import androidx.fragment.app.Fragment;

import com.adconfig.AdsConfig;
import com.adconfig.adsutil.admob.NativeAdHelper;
import com.adconfig.adsutil.admob.NativeLayoutType;

import com.photo.effect.motion.editor.MyApp;
import com.photo.effect.motion.editor.fragment.MainFragment;
import com.photo.effect.motion.editor.R;
import com.photo.effect.motion.editor.utils.Share;

import static android.content.Intent.FLAG_RECEIVER_FOREGROUND;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;

public class CropActivity extends BaseParentActivity {

    private static final String TAG = "CropImageAct";
    public static CropActivity activity;

    private Uri mUri;


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_crop);
        String str = TAG;
        StringBuilder sb = new StringBuilder();
        sb.append("CropImageAct==>  ");
        sb.append(Share.imageUrl);
        Log.e(str, sb.toString());
        if (bundle == null) {
            getSupportFragmentManager().beginTransaction().add(R.id.container, (Fragment) MainFragment.getInstance()).commitAllowingStateLoss();
        }

        FrameLayout mAdView = findViewById(R.id.adView);

        new NativeAdHelper(this, mAdView, NativeLayoutType.NativeBanner,null,"").loadAd();

    }



    public void onPause() {
        super.onPause();
    }

    public void onResume() {
        super.onResume();
    }


    public void onDestroy() {
        super.onDestroy();
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
    }

    public void onBackPressed() {
        finish();
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS", Uri.fromParts("package", getPackageName(), null));
        intent.addFlags(FLAG_RECEIVER_FOREGROUND);
        startActivity(intent);

    }

    public void startResultActivity(Uri uri) {
        this.mUri = uri;


        Intent intent = new Intent(this, MotionEditActivity.class);
        intent.setData(uri);

        if (MyApp.getApplication().needToShowAd()) {
            AdsConfig.Companion.showInterstitialAd(CropActivity.this, new Function0<Unit>() {
                @Override
                public Unit invoke() {

                    startActivity(intent);
                    overridePendingTransition(R.anim.left_in, R.anim.right_out);
                    CropActivity.this.finish();
                    return null;
                }
            });


        } else {
            startActivity(intent);
            overridePendingTransition(R.anim.left_in, R.anim.right_out);
            CropActivity.this.finish();
        }
        return;
    }

    public void onClosed() {
        Intent intent = new Intent(this, MotionEditActivity.class);
        intent.setData(this.mUri);
        startActivity(intent);
        overridePendingTransition(R.anim.left_in, R.anim.right_out);
        finish();
    }
}
