package com.photo.effect.motion.editor.callback

interface ProgressUpdateListener {
    fun onImageProgressFrameUpdate(f: Float)
}