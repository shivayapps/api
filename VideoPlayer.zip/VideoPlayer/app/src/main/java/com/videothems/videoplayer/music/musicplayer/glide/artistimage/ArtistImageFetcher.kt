package com.videothems.videoplayer.music.musicplayer.glide.artistimage

import android.content.Context
import android.util.Log
import com.bumptech.glide.Priority
import com.bumptech.glide.integration.okhttp3.OkHttpStreamFetcher
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.data.DataFetcher
import com.videothems.videoplayer.music.musicplayer.model.DeezerResponse
import com.videothems.videoplayer.music.musicplayer.network.DeezerService
import com.videothems.videoplayer.music.musicplayer.util.MusicUtil
import okhttp3.OkHttpClient
import retrofit2.Call
import java.io.FileNotFoundException
import java.io.InputStream


class ArtistImageFetcher(
    private val context: Context,
    private val deezerService: DeezerService,
    val model: ArtistImage,
    private val okhttp: OkHttpClient
) : DataFetcher<InputStream> {

    private var streamFetcher: OkHttpStreamFetcher? = null
    private var response: Call<DeezerResponse>? = null
    private var isCancelled: Boolean = false

    override fun getDataClass(): Class<InputStream> {
        return InputStream::class.java
    }

    override fun getDataSource(): DataSource {
        return DataSource.REMOTE
    }

    override fun loadData(priority: Priority, callback: DataFetcher.DataCallback<in InputStream>) {
        try {

            callback.onDataReady(getFallbackAlbumImage())
//            if (!MusicUtil.isArtistNameUnknown(model.artist.name) &&
//                PreferenceUtil.isAllowedToDownloadMetadata()
//            ) {
//                val artists = model.artist.name.split(",", "&")
//                val m = ArtistDatabase.getInstance(context)
//                val image = m.artistDao().getArtist(artists[0])
//              if (image != null)
//              {
//                  val data = Data(image.id.toString(),image.name,image.picture)
//                  val deezerResponse = DeezerResponse(data)
//                  val imageUrl = deezerResponse.data.picture
//                  if (imageUrl.isNotEmpty()) {
//                      Log.e("TAG", "loadData: $imageUrl", )
//                      streamFetcher = OkHttpStreamFetcher(okhttp, GlideUrl(imageUrl))
//                      streamFetcher?.loadData(priority, callback)
//                  } else {
//                      callback.onDataReady(getFallbackAlbumImage())
//                  }
            //  }


            //response = deezerService.getArtistImage(artists[0])


//                response?.enqueue(object : Callback<DeezerResponse> {
//                    override fun onResponse(
//                        call: Call<DeezerResponse>,
//                        response: Response<DeezerResponse>
//                    ) {
//                        if (!response.isSuccessful) {
//                            throw IOException("Request failed with code: " + response.code())
//                        }
//
//                        if (isCancelled) {
//                            callback.onDataReady(null)
//                            return
//                        }
//
//                        try {
//                            val deezerResponse = response.body()
//                        //    val imageUrl = deezerResponse?.data?.get(0)?.let { getHighestQuality(it) }
//
//                            val m = ArtistDatabase.getInstance(context)
//
//                            val image = m.artistDao().getArtist(artists[0])
//                            val imageUrl = image.picture
//                            if (imageUrl.isNotEmpty()) {
//                                Log.e("TAG", "loadData: $imageUrl", )
//                                streamFetcher = OkHttpStreamFetcher(okhttp, GlideUrl(imageUrl))
//                                streamFetcher?.loadData(priority, callback)
//                            } else {
//                                callback.onDataReady(getFallbackAlbumImage())
//                            }
//
//
//                          //  Log.e("TAG", "onResponse: ${deezerResponse!!.data}", )
//
////                            val placeHolder = imageUrl?.contains("/images/artist//") ?: false
////                            if (!placeHolder) {
////                                streamFetcher = OkHttpStreamFetcher(okhttp, GlideUrl(imageUrl))
////                                streamFetcher?.loadData(priority, callback)
////                            } else {
//                               // callback.onDataReady(getFallbackAlbumImage())
//                           // }
//
//
//                        } catch (e: Exception) {
//                            callback.onDataReady(getFallbackAlbumImage())
//                        }
//                    }
//
//                    override fun onFailure(call: Call<DeezerResponse>, t: Throwable) {
//                        callback.onDataReady(getFallbackAlbumImage())
//                    }
//                })
            // } else callback.onDataReady(null)
        } catch (e: Exception) {
            callback.onLoadFailed(e)
        }
    }

    private fun getFallbackAlbumImage(): InputStream? {
        model.artist.safeGetFirstAlbum().id.let { id ->
            return if (id != -1L) {
                val imageUri =
                    MusicUtil.getMediaStoreAlbumCoverUri(model.artist.safeGetFirstAlbum().id)
                Log.e("TAG", "getFallbackAlbumImage: $imageUri")
                try {
                    context.contentResolver.openInputStream(imageUri)

                } catch (e: FileNotFoundException) {
                    null
                } catch (e: UnsupportedOperationException) {
                    null
                }
            } else {
                null
            }
        }
    }

//    private fun getHighestQuality(imageUrl: Data): String {
//        return when {
//            imageUrl.pictureXl.isNotEmpty() -> imageUrl.pictureXl
//            imageUrl.pictureBig.isNotEmpty() -> imageUrl.pictureBig
//            imageUrl.pictureMedium.isNotEmpty() -> imageUrl.pictureMedium
//            imageUrl.pictureSmall.isNotEmpty() -> imageUrl.pictureSmall
//            imageUrl.picture.isNotEmpty() -> imageUrl.picture
//            else -> ""
//        }
//    }

    override fun cleanup() {
        streamFetcher?.cleanup()
    }

    override fun cancel() {
        isCancelled = true
        response?.cancel()
        streamFetcher?.cancel()
    }
}
