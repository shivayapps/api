@file:Suppress("unused")

package com.videothems.videoplayer.music.common.utils

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.Editable
import android.text.Html
import android.text.Spanned
import android.util.DisplayMetrics
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.Toast
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
import com.bumptech.glide.util.Util
import com.videothems.videoplayer.music.R
import com.videothems.videoplayer.music.common.utils.AppConstant.Companion.NOMEDIA
import java.io.File
import kotlin.math.roundToInt

const val DELETE_REQUEST_CODE = 111
const val RENAME_REQUEST_CODE = 222
const val REQUEST_CODE_URIS = 333

inline val Context.isOnline: Boolean
    get() {
        (getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).let { connectivityManager ->
            connectivityManager.getNetworkCapabilities(connectivityManager.activeNetwork)?.let {
                return it.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            }
        }
        return false
    }

fun convertFilePathsToUris(filePaths: List<String>): List<Uri> {
    val uriList = mutableListOf<Uri>()
    for (filePath in filePaths) {
        val file = File(filePath)
        if (file.exists()) {
            val uri = Uri.fromFile(file)
            uriList.add(uri)
        }
    }
    return uriList
}

fun Context.shareApp() {
    val intent = Intent("android.intent.action.SEND")
    intent.type = "text/plain"
    intent.putExtra(
        "android.intent.extra.SUBJECT", resources.getString(R.string.app_name)
    )
    val sb = StringBuilder()
    sb.append(getString(R.string.share_msg))
    val sb2 = sb.toString()
    val sb3 = StringBuilder()
    sb3.append(sb2)
    sb3.append("https://play.google.com/store/apps/details?id=")
    sb3.append(com.videothems.videoplayer.music.BuildConfig.APPLICATION_ID)
    sb3.append("\n\n")
    intent.putExtra("android.intent.extra.TEXT", sb3.toString())
    startActivity(Intent.createChooser(intent, "Choose one"))
}

fun Context.redirectPlayStore(mPackageName: String? = com.videothems.videoplayer.music.BuildConfig.APPLICATION_ID) {
    val webpage = Uri.parse("https://play.google.com/store/apps/details?id=$mPackageName")
    val i = Intent(Intent.ACTION_VIEW, webpage)
    if (i.resolveActivity(packageManager) != null) {
        startActivity(i)
    }
}

fun Context.openURL(fURL: String) {
    val uri = Uri.parse(fURL)
    try {
        val builder = CustomTabsIntent.Builder()
        builder.setToolbarColor(
            ContextCompat.getColor(
                this, R.color.purple_500
            )
        )
        val customTabsIntent = builder.build()
        customTabsIntent.launchUrl(this, uri)
    } catch (e: Exception) {
        try {
            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = uri
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(
                this,
                "No application can handle this request." + " Please install a web browser",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}


fun View.visible(b: Boolean) {
    if (b) {
        visibility = View.VISIBLE
    } else {
        visibility = View.GONE
    }
}

/**
 * Show the view  (visibility = View.VISIBLE)
 */
inline val View.visible: View
    get() {
        if (visibility != View.VISIBLE) {
            visibility = View.VISIBLE
        }
        return this
    }

/**
 * Hide the view. (visibility = View.INVISIBLE)
 */
inline val View.invisible: View
    get() {
        if (visibility != View.INVISIBLE) {
            visibility = View.INVISIBLE
        }
        return this
    }

/**
 * Remove the view (visibility = View.GONE)
 */
inline val View.gone: View
    get() {
        if (visibility != View.GONE) {
            visibility = View.GONE
        }
        return this
    }

/**
 * Remove the view (View.setEnable(true))
 */
inline val View.enable: View
    get() {
        isEnabled = true
        return this
    }

/**
 * Remove the view (View.setEnable(false))
 */
inline val View.disable: View
    get() {
        isEnabled = false
        return this
    }

/**
 * Extension method to get LayoutInflater
 */
inline val Context.inflater: LayoutInflater get() = LayoutInflater.from(this)
//</editor-fold>

//<editor-fold desc="For get Display Data">
/**
 * Extension method to get theme for Context.
 */
//inline val Context.isDarkTheme: Boolean get() = resources.configuration.uiMode.and(Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

/**
 * Extension method to find a device width in pixels
 */
inline val Context.displayWidth: Int get() = resources.displayMetrics.widthPixels

/**
 * Extension method to find a device height in pixels
 */
inline val Context.displayHeight: Int get() = resources.displayMetrics.heightPixels

/**
 * Extension method to find a device density
 */
inline val Context.displayDensity: Float get() = resources.displayMetrics.density

/**
 * Extension method to find a device density in DPI
 */
inline val Context.displayDensityDpi: Int get() = resources.displayMetrics.densityDpi

/**
 * Extension method to find a device DisplayMetrics
 */
inline val Context.displayMetrics: DisplayMetrics get() = resources.displayMetrics
//</editor-fold>

//<editor-fold desc="For Text Entity">
inline val String.toEditable: Editable get() = Editable.Factory.getInstance().newEditable(this)

inline val String.removeMultipleSpace: String get() = this.trim().replace("\\s+".toRegex(), " ")

inline val String.getFromHtml: Spanned
    get() {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Html.fromHtml(this, Html.FROM_HTML_MODE_COMPACT)
        } else {
            @Suppress("DEPRECATION") Html.fromHtml(this)
        }
    }

inline val View.hideKeyBord: Unit
    get() {
        this.clearFocus()
        (this.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(
            this.windowToken,
            0
        )
    }

inline val EditText.hideKeyBordWithOutClearFocus: Unit
    get() {
        this.requestFocus()

        (this.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(
            this.windowToken,
            0
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            this.showSoftInputOnFocus = false
        } else {
            this.setTextIsSelectable(true)
        }
    }

inline val View.showKeyBord: Unit
    get() {
        this.requestFocus()
        (this.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(
            this,
            0
        )
    }

inline val Activity.statusBarHeight: Int
    get() {
        val resourceId =
            baseContext.resources.getIdentifier("status_bar_height", "dimen", "android")
        return resources.getDimensionPixelSize(resourceId)
    }

inline val Activity.navigationBarHeight: Int
    get() {
        val resourceId =
            baseContext.resources.getIdentifier("navigation_bar_height", "dimen", "android")
        return resources.getDimensionPixelSize(resourceId)
    }

inline val isSDKBelow21: Boolean get() = Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP

inline val Double.roundToHalf: Double get() = ((this * 2).roundToInt() / 2.0)

inline val Context.isValidContextForGlide: Boolean
    get() {
        return !(this is Activity && this.isFinishing)
    }


var DATABASE_PATH =
    Environment.getExternalStorageDirectory().path + File.separator + ".videoplayer" + File.separator

fun Activity.shareDeepLink(deepLink: String) {
    val intent = Intent(Intent.ACTION_SEND)
    intent.type = "text/plain"
    intent.putExtra(Intent.EXTRA_TEXT, deepLink)
    startActivity(intent)
}

fun ensureBackgroundThread(callback: () -> Unit) {
    if (Util.isOnMainThread()) {
        try {
            Thread {
                callback()
            }.start()
        } catch (_: Exception) {

        }
    } else {
        callback()
    }
}

fun Activity.addNoMedia(path: String, callback: () -> Unit) {
    val file = File(path, NOMEDIA)
    if (getDoesFilePathExist(file.absolutePath)) {
        callback()
        return
    }
    try {
        if (file.createNewFile()) {
            ensureBackgroundThread {
                addNoMediaIntoMediaStore(file.absolutePath)
            }
        }
    } catch (_: Exception) {

    }
    callback()

}

fun Activity.addNoMediaIntoMediaStore(path: String) {
    try {
        val content = ContentValues().apply {
            put(MediaStore.Files.FileColumns.TITLE, NOMEDIA)
            put(MediaStore.Files.FileColumns.DATA, path)
            put(
                MediaStore.Files.FileColumns.MEDIA_TYPE,
                MediaStore.Files.FileColumns.MEDIA_TYPE_NONE
            )
        }
        contentResolver.insert(MediaStore.Files.getContentUri("external"), content)
    } catch (_: Exception) {

    }
}

fun getDoesFilePathExist(path: String): Boolean {
    return File(path).exists()
}

fun Context.getFilePathFromUri(uri: Uri): String? {
    var cursor: Cursor? = null
    val column = "_data"
    val projection = arrayOf(column)

    try {
        cursor = contentResolver.query(uri, projection, null, null, null)
        if (cursor != null && cursor.moveToFirst()) {
            val columnIndex = cursor.getColumnIndexOrThrow(column)
            return cursor.getString(columnIndex)
        }
    } catch (e: Exception) {
        println(e.message)
    } finally {
        cursor?.close()
    }
    return null
}

fun String.getFilenameFromPath() = substring(lastIndexOf("/") + 1)
fun String.getParentPath() = removeSuffix("/${getFilenameFromPath()}")
fun String.containsNoMedia() = File(this).containsNoMedia()

fun File.containsNoMedia(): Boolean {
    return if (!isDirectory) {
        false
    } else {
        File(this, NOMEDIA).exists()
    }
}

fun File.isPublicDire(): Boolean {
    return when (this.absolutePath) {
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).absolutePath -> {
            true
        }

        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).absolutePath -> {
            true
        }

        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS).absolutePath -> {
            true
        }

        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath -> {
            true
        }

        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PODCASTS).absolutePath -> {
            true
        }

        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES).absolutePath -> {
            true
        }

        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC).absolutePath -> {
            true
        }

        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_RINGTONES).absolutePath -> {
            true
        }

        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_ALARMS).absolutePath -> {
            true
        }

        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_AUDIOBOOKS).absolutePath -> {
            true
        }

        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_NOTIFICATIONS).absolutePath -> {
            true
        }

        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_SCREENSHOTS).absolutePath -> {
            true
        }

        else -> {
            false
        }
    }
}