package com.videothems.videoplayer.music.musicplayer.glide

import android.graphics.drawable.Drawable
import android.widget.ImageView
import com.bumptech.glide.request.transition.Transition
import com.videothems.videoplayer.music.musicplayer.App

abstract class RetroMusicColoredTarget(view: ImageView) : com.videothems.videoplayer.music.musicplayer.glide.palette.BitmapPaletteTarget(view) {

    abstract fun onColorReady(colors: com.videothems.videoplayer.music.musicplayer.util.color.MediaNotificationProcessor)

    override fun onLoadFailed(errorDrawable: Drawable?) {
        super.onLoadFailed(errorDrawable)
        onColorReady(com.videothems.videoplayer.music.musicplayer.util.color.MediaNotificationProcessor.errorColor(App.getContext()))
    }

    override fun onResourceReady(
        resource: com.videothems.videoplayer.music.musicplayer.glide.palette.BitmapPaletteWrapper,
        transition: Transition<in com.videothems.videoplayer.music.musicplayer.glide.palette.BitmapPaletteWrapper>?
    ) {
        super.onResourceReady(resource, transition)
        com.videothems.videoplayer.music.musicplayer.util.color.MediaNotificationProcessor(App.getContext())
            .getPaletteAsync({
            onColorReady(it)
        }, resource.bitmap)
    }
}
