package com.videothems.videoplayer.music.musicplayer.interfaces

import android.view.View
import com.videothems.videoplayer.music.musicplayer.model.Genre

interface IGenreClickListener {
    fun onClickGenre(genre: Genre, view: View)
}