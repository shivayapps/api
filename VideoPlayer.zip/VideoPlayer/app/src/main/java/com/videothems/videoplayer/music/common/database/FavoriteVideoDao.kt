package com.videothems.videoplayer.music.common.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query


@Dao
interface FavoriteVideoDao {

    @Query("Select * from favorite_video")
    fun getFavoriteVideoLive(): LiveData<List<FavoriteVideo>>

    @Query("Select * from favorite_video")
    fun getFavoriteVideo(): List<FavoriteVideo>

    @Insert
    fun insertFavoriteVideo(recent: FavoriteVideo)

    @Query("DELETE FROM favorite_video")
    fun deleteFavoriteVideo()

    @Query("DELETE from favorite_video WHERE path = :filepath")
    fun deleteFavoriteVideo(filepath: String?)

    @Query("Select count(*) from favorite_video WHERE path = :filepath")
    fun isFavoriteVideo(filepath: String?): Int
}