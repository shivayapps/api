package com.videothems.videoplayer.music.adloaders

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.videothems.videoplayer.music.R
import com.videothems.videoplayer.music.common.utils.isOnline
import com.videothems.videoplayer.music.musicplayer.App

class InterstitialAdLoader(val context: Activity) {

    companion object {
        private var instance: InterstitialAdLoader? = null
        private var mAdmobInterstitialAd: InterstitialAd? = null

        fun getInstance(context: Activity): InterstitialAdLoader {
            return instance ?: synchronized(this) {
                instance ?: InterstitialAdLoader(context).also { instance = it }
            }
        }

        private var isAdLoading = false
    }

    fun showFullScreenAds(
        activity: Activity,
        listener: AdFinishWithControlListener
    ) {
        if (activity.isOnline) {
            if (mAdmobInterstitialAd != null) {
                showInterstitialAd(activity, listener)
            } else {
                listener.adFinished()
            }
        } else {
            listener.adFinished()
        }
    }

    fun loadFullScreenAds(context: Context) {
        if (context.isOnline && PrefsAds(context).isInterstitialAdEnable) {
            if (mAdmobInterstitialAd == null && !isAdLoading) {
                loadAdmobInt(context)
            }
        }
    }

    private fun isAdLoaded(): Boolean {
        return if (!PrefsAds(context).isInterstitialAdEnable) {
            mAdmobInterstitialAd != null
        } else {
            false
        }
    }

    private fun loadAdmobInt(context: Context) {
        if (context.isOnline && mAdmobInterstitialAd == null) {
            isAdLoading = true
            InterstitialAd.load(
                context,
                context.getString(R.string.admob_interstitial),
                AdRequest.Builder().build(),
                object : InterstitialAdLoadCallback() {
                    override fun onAdLoaded(interstitialAd: InterstitialAd) {
                        // The mInterstitialAd reference will be null until
                        // an ad is loaded.
                        mAdmobInterstitialAd = interstitialAd
                        isAdLoading = false
                    }

                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        mAdmobInterstitialAd = null
                        loadAdmobIntReload(context)
                    }
                })
        }
    }


    interface AdFinishWithControlListener {
        fun adFinished()
    }

    private fun showInterstitialAd(
        activity: Activity,
        adFinishWithControlListener: AdFinishWithControlListener
    ) {
        if (mAdmobInterstitialAd != null) {
            mAdmobInterstitialAd!!.fullScreenContentCallback =
                object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
                        App.isOpenAdHideInterstitial = false
                        mAdmobInterstitialAd = null
                        loadFullScreenAds(activity)
                        adFinishWithControlListener.adFinished()
                    }

                    override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                        mAdmobInterstitialAd = null
                        App.isOpenAdHideInterstitial = false
                        adFinishWithControlListener.adFinished()
                    }

                    override fun onAdShowedFullScreenContent() {
                        App.isOpenAdHideInterstitial = true
                    }
                }
            mAdmobInterstitialAd!!.show(activity)
        } else {
            adFinishWithControlListener.adFinished()
        }
    }

    private fun loadAdmobIntReload(context: Context) {
        if (context.isOnline && mAdmobInterstitialAd == null) {
            InterstitialAd.load(
                context,
                context.getString(R.string.admob_interstitial_2),
                AdRequest.Builder().build(),
                object : InterstitialAdLoadCallback() {
                    override fun onAdLoaded(interstitialAd: InterstitialAd) {
                        mAdmobInterstitialAd = interstitialAd
                        isAdLoading = false
                    }

                    override fun onAdFailedToLoad(errorCode: LoadAdError) {
                        mAdmobInterstitialAd = null
                        isAdLoading = false
                    }
                })
        }
    }
}