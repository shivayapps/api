package com.videothems.videoplayer.music.musicplayer.activities

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.appcompat.content.res.AppCompatResources
import androidx.navigation.NavController
import androidx.navigation.NavDestination
import androidx.preference.PreferenceManager
import code.name.monkey.appthemehelper.ThemeStore
import code.name.monkey.appthemehelper.util.VersionUtils
import com.afollestad.materialdialogs.MaterialDialog
import com.afollestad.materialdialogs.color.ColorCallback
import com.videothems.videoplayer.music.R
import com.videothems.videoplayer.music.adloaders.BannerAds
import com.videothems.videoplayer.music.adloaders.InterstitialAdLoader
import com.videothems.videoplayer.music.adloaders.NativeAdSize
import com.videothems.videoplayer.music.adloaders.PreLoadNativeAds
import com.videothems.videoplayer.music.adloaders.PrefsAds
import com.videothems.videoplayer.music.common.utils.isOnline
import com.videothems.videoplayer.music.databinding.ActivitySettingsBinding
import com.videothems.videoplayer.music.musicplayer.App
import com.videothems.videoplayer.music.musicplayer.GENERAL_THEME
import com.videothems.videoplayer.music.musicplayer.IMAGE_THEME
import com.videothems.videoplayer.music.musicplayer.activities.base.AbsThemeActivity
import com.videothems.videoplayer.music.musicplayer.appshortcuts.DynamicShortcutManager
import com.videothems.videoplayer.music.musicplayer.extensions.extra
import com.videothems.videoplayer.music.musicplayer.extensions.findNavController
import com.videothems.videoplayer.music.musicplayer.extensions.makeStatusBarTransparent
import com.videothems.videoplayer.music.musicplayer.extensions.resolveColor
import com.videothems.videoplayer.music.musicplayer.extensions.setDrawBehindSystemBars
import com.videothems.videoplayer.music.musicplayer.extensions.setImmersiveFullscreen
import com.videothems.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.videothems.videoplayer.music.musicplayer.util.PreferenceUtil
import org.jetbrains.anko.backgroundColor

class SettingsActivity : AbsThemeActivity(), ColorCallback, OnThemeChangedListener {
    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        val mSavedInstanceState = extra<Bundle>(TAG).value ?: savedInstanceState
        super.onCreate(mSavedInstanceState)

        binding = ActivitySettingsBinding.inflate(layoutInflater)

        setContentView(binding.root)

        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        } else {
            setImmersiveFullscreen()
        }

        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            IMAGE_THEME, ""
        )

        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getInt(
            GENERAL_THEME, 0
        )

        makeStatusBarTransparent()

        if (editors == "theme_image") {
            binding.root.background = RetroGlideExtension.getUserImageTheme(this@SettingsActivity)
            binding.constraintLayout.background = null
        } else if (editors == "theme_gradient") {
            binding.root.background =
                AppCompatResources.getDrawable(this, RetroGlideExtension.getUserGradientTheme())
            binding.constraintLayout.background = null
        } else if (edit >= 0) {
            binding.root.background = null
            binding.root.backgroundColor = resolveColor(R.attr.mainBackgroundColor)
        }

        setupToolbar()

        binding.ivBack.setOnClickListener {
            onBackPressed()
        }
        setNative()
    }

    private val clickInterval: Long = 60 * 1000 // 40 second in milliseconds
    private var lastClickTime: Long = 0

    private fun clickEventAtMinute() {
        val currentTime = System.currentTimeMillis()
        val elapsedTimeSinceLastClick = currentTime - lastClickTime
        if (elapsedTimeSinceLastClick >= clickInterval) {
            InterstitialAdLoader(this).showFullScreenAds(
                this,
                object :
                    InterstitialAdLoader.AdFinishWithControlListener {
                    override fun adFinished() {
                        onBack()
                    }
                })
            lastClickTime = currentTime
        } else {
            onBack()
        }
    }

    private fun setNative() {
        if (isOnline) {
            binding.frameLayout.visibility = View.VISIBLE
            if (PrefsAds(this).isNative3() == "1") {
                val nativeADs = PreLoadNativeAds(this)
                nativeADs.showLoadingLayoutForNative(binding.frameLayout, NativeAdSize.Medium)
                App.nativeAdsFiles.observe(this) { native ->
                    if (native != null) {
                        nativeADs.showNative(binding.frameLayout, native, NativeAdSize.Medium)
                    } else {
                        if (nativeADs.checkAdsIsOn() && App.isNativeLoading)
                            binding.frameLayout.visibility = View.VISIBLE
                        else
                            binding.frameLayout.visibility = View.GONE
                    }
                }
            } else if (PrefsAds(this).isNative3() == "0") {
                BannerAds().loadAdmobBannerAds(
                    this@SettingsActivity, binding.frameLayout, ""
                )
            }
        } else {
            binding.frameLayout.visibility = View.GONE
        }
    }

    override fun onBackPressed() {
        clickEventAtMinute()
    }

    fun onBack() {
        if (findNavController(R.id.contentFrame).navigateUp() || super.onSupportNavigateUp()) {
            findNavController(R.id.contentFrame).navigateUp() || super.onSupportNavigateUp()
        } else {
            super.onBackPressed()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
    }

    private fun setupToolbar() {
        val navController: NavController = findNavController(R.id.contentFrame)
        navController.addOnDestinationChangedListener { _, _, _ ->
            binding.tvFolderName.text =
                navController.currentDestination?.let { getStringFromDestination(it) }
        }
    }

    private fun getStringFromDestination(currentDestination: NavDestination): String {
        val idRes = when (currentDestination.id) {
            R.id.mainSettingsFragment -> R.string.action_settings
            R.id.audioSettings -> R.string.pref_header_audio
            R.id.imageSettingFragment -> R.string.pref_header_images
            R.id.notificationSettingsFragment -> R.string.notification
            R.id.nowPlayingSettingsFragment -> R.string.now_playing
            R.id.otherSettingsFragment -> R.string.others
            R.id.personalizeSettingsFragment -> R.string.personalize
            R.id.themeSettingsFragment -> R.string.general_settings_title
            else -> R.id.action_settings
        }
        return getString(idRes)
    }

    override fun onSupportNavigateUp(): Boolean {
        return findNavController(R.id.contentFrame).navigateUp() || super.onSupportNavigateUp()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressedDispatcher.onBackPressed()
        }
        return super.onOptionsItemSelected(item)
    }

    override fun invoke(dialog: MaterialDialog, color: Int) {
        ThemeStore.editTheme(this).accentColor(color).commit()
        if (VersionUtils.hasNougatMR())
            DynamicShortcutManager(this).updateDynamicShortcuts()
        restart()
    }

    override fun onThemeValuesChanged() {
        restart()
    }

    private fun restart() {
        val savedInstanceState = Bundle().apply {
            onSaveInstanceState(this)
        }
        finish()
        val intent = Intent(this, this::class.java).putExtra(TAG, savedInstanceState)
        startActivity(intent)
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    companion object {
        val TAG: String = SettingsActivity::class.java.simpleName
    }
}

interface OnThemeChangedListener {
    fun onThemeValuesChanged()
}
