package com.videothems.videoplayer.music.musicplayer.service.notification

import android.annotation.SuppressLint
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Build
import android.support.v4.media.session.MediaSessionCompat
import androidx.core.app.NotificationCompat
import androidx.core.text.HtmlCompat
import androidx.media.app.NotificationCompat.MediaStyle
import code.name.monkey.appthemehelper.util.VersionUtils
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.videothems.videoplayer.music.R
import com.videothems.videoplayer.music.musicplayer.activities.MusicPlayerActivity
import com.videothems.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.videothems.videoplayer.music.musicplayer.model.Song
import com.videothems.videoplayer.music.musicplayer.service.MusicService
import com.videothems.videoplayer.music.musicplayer.service.MusicService.Companion.ACTION_QUIT
import com.videothems.videoplayer.music.musicplayer.service.MusicService.Companion.ACTION_REWIND
import com.videothems.videoplayer.music.musicplayer.service.MusicService.Companion.ACTION_SKIP
import com.videothems.videoplayer.music.musicplayer.service.MusicService.Companion.ACTION_TOGGLE_PAUSE
import com.videothems.videoplayer.music.musicplayer.service.MusicService.Companion.TOGGLE_FAVORITE
import com.videothems.videoplayer.music.musicplayer.util.MusicUtil
import com.videothems.videoplayer.music.musicplayer.util.PreferenceUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@SuppressLint("RestrictedApi")
class PlayingNotificationImpl24(
    val context: Context,
    mediaSessionToken: MediaSessionCompat.Token
) : PlayingNotification(context) {

    init {

        val action = Intent(context, MusicPlayerActivity::class.java)
        action.putExtra("Click", true)
        // action.putExtra(MainActivity.EXPAND_PANEL, PreferenceUtil.isExpandPanel)
        action.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        val clickIntent =
            PendingIntent.getActivity(
                context,
                0,
                action,
                PendingIntent.FLAG_UPDATE_CURRENT or if (VersionUtils.hasMarshmallow())
                    PendingIntent.FLAG_IMMUTABLE
                else 0
            )

        val serviceName = ComponentName(context, MusicService::class.java)
        val intent = Intent(ACTION_QUIT)
        intent.component = serviceName
        val deleteIntent = PendingIntent.getService(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (VersionUtils.hasMarshmallow())
                PendingIntent.FLAG_IMMUTABLE
            else 0)
        )
        val toggleFavorite = buildFavoriteAction(false)
        val playPauseAction = buildPlayAction(true)
        val previousAction = NotificationCompat.Action(
            R.drawable.ic_skip_previous_round_white_32dp,
            context.getString(R.string.action_previous),
            retrievePlaybackAction(ACTION_REWIND)
        )
        val nextAction = NotificationCompat.Action(
            R.drawable.ic_skip_next_round_white_32dp,
            context.getString(R.string.action_next),
            retrievePlaybackAction(ACTION_SKIP)
        )
        val dismissAction = NotificationCompat.Action(
            R.drawable.ic_close,
            context.getString(R.string.action_cancel),
            retrievePlaybackAction(ACTION_QUIT)
        )
        setSmallIcon(R.drawable.ic_notification_i)
        setContentIntent(clickIntent)
        setDeleteIntent(deleteIntent)
        setShowWhen(false)
        addAction(toggleFavorite)
        addAction(previousAction)
        addAction(playPauseAction)
        addAction(nextAction)
        if (VersionUtils.hasS()) {
            addAction(dismissAction)
        }

        setStyle(
            MediaStyle()
                .setMediaSession(mediaSessionToken)
                .setShowActionsInCompactView(1, 2, 3)
        )
        setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
        if (Build.VERSION.SDK_INT <=
            Build.VERSION_CODES.O && PreferenceUtil.isColoredNotification
        ) {
            this.color = color
        }
    }

    override fun updateMetadata(song: Song, onUpdate: () -> Unit) {
        setContentTitle(song.title)
        setContentText(
            HtmlCompat.fromHtml(
                "<b>" + song.albumName + "</b>",
                HtmlCompat.FROM_HTML_MODE_LEGACY
            )
        )
        val bigNotificationImageSize = context.resources
            .getDimensionPixelSize(R.dimen.notification_big_image_size)
        com.videothems.videoplayer.music.musicplayer.glide.GlideApp.with(context).asBitmapPalette().songCoverOptions(song)
            .load(RetroGlideExtension.getSongModel(song))
            //.checkIgnoreMediaStore()
            .centerCrop()
            .into(object : CustomTarget<com.videothems.videoplayer.music.musicplayer.glide.palette.BitmapPaletteWrapper>(
                bigNotificationImageSize,
                bigNotificationImageSize
            ) {
                override fun onResourceReady(
                    resource: com.videothems.videoplayer.music.musicplayer.glide.palette.BitmapPaletteWrapper,
                    transition: Transition<in com.videothems.videoplayer.music.musicplayer.glide.palette.BitmapPaletteWrapper>?
                ) {
                    setLargeIcon(
                        resource.bitmap
                    )
                    if (Build.VERSION.SDK_INT <=
                        Build.VERSION_CODES.O && PreferenceUtil.isColoredNotification
                    ) {
                        color = com.videothems.videoplayer.music.musicplayer.util.RetroColorUtil.getColor(resource.palette, Color.TRANSPARENT)
                    }
                    onUpdate()
                }

                override fun onLoadFailed(errorDrawable: Drawable?) {
                    super.onLoadFailed(errorDrawable)
                    setLargeIcon(
                        BitmapFactory.decodeResource(
                            context.resources,
                            R.drawable.default_audio_art
                        )
                    )
                    onUpdate()
                }

                override fun onLoadCleared(placeholder: Drawable?) {
                    setLargeIcon(
                        BitmapFactory.decodeResource(
                            context.resources,
                            R.drawable.default_audio_art
                        )
                    )
                    onUpdate()
                }
            })
        updateFavorite(song, onUpdate)
    }

    private fun buildPlayAction(isPlaying: Boolean): NotificationCompat.Action {
        val playButtonResId =
            if (isPlaying) R.drawable.ic_play_white_64dp else R.drawable.ic_pause_white_64dp
        return NotificationCompat.Action.Builder(
            playButtonResId,
            context.getString(R.string.action_play_pause),
            retrievePlaybackAction(ACTION_TOGGLE_PAUSE)
        ).build()
    }

    private fun buildFavoriteAction(isFavorite: Boolean): NotificationCompat.Action {
        val favoriteResId =
            if (isFavorite) R.drawable.ic_favorite else R.drawable.ic_favorite_border_notification
        return NotificationCompat.Action.Builder(
            favoriteResId,
            context.getString(R.string.action_toggle_favorite),
            retrievePlaybackAction(TOGGLE_FAVORITE)
        ).build()
    }

    override fun setPlaying(isPlaying: Boolean, onUpdate: () -> Unit) {
        mActions[2] = buildPlayAction(isPlaying)
        onUpdate()
    }

    override fun updateFavorite(song: Song, onUpdate: () -> Unit) {
        GlobalScope.launch(Dispatchers.IO) {
            val isFavorite = MusicUtil.repository.isSongFavorite(song.id)
            withContext(Dispatchers.Main) {
                mActions[0] = buildFavoriteAction(isFavorite)
                onUpdate()
            }
        }
    }

    private fun retrievePlaybackAction(action: String): PendingIntent {
        val serviceName = ComponentName(context, MusicService::class.java)
        val intent = Intent(action)
        intent.component = serviceName
        return PendingIntent.getService(
            context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or
                    if (VersionUtils.hasMarshmallow()) PendingIntent.FLAG_IMMUTABLE
                    else 0
        )
    }

    companion object {

        fun from(
            context: Context,
            notificationManager: NotificationManager,
            mediaSession: MediaSessionCompat
        ): PlayingNotification {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                createNotificationChannel(context, notificationManager)
            }
            return PlayingNotificationImpl24(context, mediaSession.sessionToken)
        }
    }
}