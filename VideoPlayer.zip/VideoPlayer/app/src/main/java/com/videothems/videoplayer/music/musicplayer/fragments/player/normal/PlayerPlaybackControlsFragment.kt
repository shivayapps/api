package com.videothems.videoplayer.music.musicplayer.fragments.player.normal

import android.os.Bundle
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.ImageButton
import android.widget.SeekBar
import android.widget.TextView
import code.name.monkey.appthemehelper.ThemeStore
import code.name.monkey.appthemehelper.util.ATHUtil
import code.name.monkey.appthemehelper.util.ColorUtil
import code.name.monkey.appthemehelper.util.MaterialValueHelper
import com.videothems.videoplayer.music.R
import com.videothems.videoplayer.music.databinding.FragmentPlayerPlaybackControlsBinding
import com.videothems.videoplayer.music.musicplayer.extensions.applyColor
import com.videothems.videoplayer.music.musicplayer.extensions.getSongInfo
import com.videothems.videoplayer.music.musicplayer.extensions.hide
import com.videothems.videoplayer.music.musicplayer.extensions.ripAlpha
import com.videothems.videoplayer.music.musicplayer.extensions.show
import com.videothems.videoplayer.music.musicplayer.fragments.base.AbsPlayerControlsFragment
import com.videothems.videoplayer.music.musicplayer.fragments.base.goToAlbum
import com.videothems.videoplayer.music.musicplayer.fragments.base.goToArtist
import com.videothems.videoplayer.music.musicplayer.helper.MusicPlayerRemote
import com.videothems.videoplayer.music.musicplayer.util.PreferenceUtil

class PlayerPlaybackControlsFragment :
    AbsPlayerControlsFragment(R.layout.fragment_player_playback_controls) {

    private var _binding: FragmentPlayerPlaybackControlsBinding? = null
    private val binding get() = _binding!!

    override val progressSlider: SeekBar
        get() = binding.progressSlider

    override val shuffleButton: ImageButton
        get() = binding.shuffleButton

    override val repeatButton: ImageButton
        get() = binding.repeatButton

    override val nextButton: ImageButton
        get() = binding.nextButton

    override val previousButton: ImageButton
        get() = binding.previousButton

    override val songTotalTime: TextView
        get() = binding.songTotalTime

    override val songCurrentProgress: TextView
        get() = binding.songCurrentProgress

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentPlayerPlaybackControlsBinding.bind(view)

        setUpPlayPauseFab()
        binding.title.isSelected = true
        binding.text.isSelected = true
        binding.title.setOnClickListener {
            goToAlbum(requireActivity())
        }
        binding.text.setOnClickListener {
            goToArtist(requireActivity())
        }
    }

    //    var colorFinal: Int= Color.BLACK
    override fun setColor(color: com.videothems.videoplayer.music.musicplayer.util.color.MediaNotificationProcessor) {
        val colorBg = ATHUtil.resolveColor(requireContext(), android.R.attr.colorBackground)
        if (ColorUtil.isColorLight(colorBg)) {
            lastPlaybackControlsColor =
                MaterialValueHelper.getSecondaryTextColor(requireContext(), true)
            lastDisabledPlaybackControlsColor =
                MaterialValueHelper.getSecondaryDisabledTextColor(requireContext(), true)
        } else {
            lastPlaybackControlsColor =
                MaterialValueHelper.getPrimaryTextColor(requireContext(), false)
            lastDisabledPlaybackControlsColor =
                MaterialValueHelper.getPrimaryDisabledTextColor(requireContext(), false)
        }

        val colorFinal = if (PreferenceUtil.isAdaptiveColor) {
            color.primaryTextColor
        } else {
            ThemeStore.accentColor(requireContext())
        }.ripAlpha()

//        TintHelper.setTintAuto(
//            binding.playPauseButton,
//            MaterialValueHelper.getPrimaryTextColor(
//                requireContext(),
//                ColorUtil.isColorLight(colorFinal)
//            ),
//            false
//        )

//        TintHelper.setTintAuto(binding.playPauseButton, colorFinal, true)

        binding.progressSlider.applyColor(colorFinal)
        volumeFragment?.setTintable(colorFinal)
        updateRepeatState()
        updateShuffleState()
        updatePrevNextColor()
    }

    private fun updateSong() {
        val song = MusicPlayerRemote.currentSong
        binding.title.text = song.title
        binding.text.text = song.artistName

        if (PreferenceUtil.isSongInfo) {
            binding.songInfo.text = getSongInfo(song)
            binding.songInfo.show()
        } else {
            binding.songInfo.hide()
        }
    }


    override fun onServiceConnected() {
        updatePlayPauseDrawableState()
        updateRepeatState()
        updateShuffleState()
        updateSong()
    }

    override fun onPlayingMetaChanged() {
        super.onPlayingMetaChanged()
        updateSong()
    }

    override fun onPlayStateChanged() {
        updatePlayPauseDrawableState()
    }

    override fun onRepeatModeChanged() {
        updateRepeatState()
    }

    override fun onShuffleModeChanged() {
        updateShuffleState()
    }

    private fun setUpPlayPauseFab() {
        binding.playPauseButton.setOnClickListener {
            if (MusicPlayerRemote.isPlaying) {
                MusicPlayerRemote.pauseSong()
            } else {
                MusicPlayerRemote.resumePlaying()
            }
            it.showBounceAnimation()
        }
    }

    private fun updatePlayPauseDrawableState() {
        if (MusicPlayerRemote.isPlaying) {
            binding.playPauseButton.setImageResource(R.drawable.ic_play_white_64dp)
        } else {
            binding.playPauseButton.setImageResource(R.drawable.ic_pause_white_64dp)
        }

//        if (MusicPlayerRemote.isPlaying) {
//            binding.playPauseButton.setImageResource(R.drawable.ic_pause_24dp)
//        } else {
//            binding.playPauseButton.setImageResource(R.drawable.ic_play_arrow)
//        }
//        val colorFinal = if (PreferenceUtil.isAdaptiveColor) {
//            color.primaryTextColor
//        } else {
//            ThemeStore.accentColor(requireContext())
//        }.ripAlpha()

//        TintHelper.setTintAuto(
//            binding.playPauseButton,
//            MaterialValueHelper.getPrimaryTextColor(
//                requireContext(),
//                ColorUtil.isColorLight(colorFinal)
//            ),
//            false
//        )
//
//        TintHelper.setTintAuto(binding.playPauseButton, colorFinal, true)
    }

    public override fun show() {
        binding.playPauseButton.animate()
            .scaleX(1f)
            .scaleY(1f)
            .rotation(360f)
            .setInterpolator(DecelerateInterpolator())
            .start()
    }

    public override fun hide() {
        binding.playPauseButton.apply {
            scaleX = 0f
            scaleY = 0f
            rotation = 0f
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
