package com.videothems.videoplayer.music.musicplayer.interfaces

import android.view.View

interface IArtistClickListener {
    fun onArtist(artistId: Long, view: View)
}
