package com.videothems.videoplayer.music.musicplayer.extensions

import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.Fragment
import com.afollestad.materialdialogs.MaterialDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.videothems.videoplayer.music.R

fun DialogFragment.materialDialog(title: Int): MaterialAlertDialogBuilder {
    return MaterialAlertDialogBuilder(
        requireContext(), R.style.MaterialAlertDialogTheme
    ).setTitle(title)
}

fun DialogFragment.materialDialog1(): MaterialAlertDialogBuilder {
    return MaterialAlertDialogBuilder(
        requireContext(), R.style.MaterialAlertDialogTheme
    )
}

fun AlertDialog.colorButtons(): AlertDialog {
    return this
}

fun Fragment.materialDialog(): MaterialDialog {
    return MaterialDialog(requireContext())
        .cornerRadius(res = R.dimen.m3_dialog_corner_size)
}
