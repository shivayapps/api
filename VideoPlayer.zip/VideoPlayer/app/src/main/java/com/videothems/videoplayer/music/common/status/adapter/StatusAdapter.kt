package com.videothems.videoplayer.music.common.status.adapter

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.videothems.videoplayer.music.common.status.FullScreenActivity
import com.videothems.videoplayer.music.common.utils.AppConstant
import com.videothems.videoplayer.music.common.utils.fileFromContentUri
import com.videothems.videoplayer.music.common.utils.fileShare
import com.videothems.videoplayer.music.common.utils.saveFiles
import com.videothems.videoplayer.music.databinding.DeleteDialogBinding
import com.videothems.videoplayer.music.databinding.StatusItemLayoutBinding
import com.videothems.videoplayer.music.musicplayer.extensions.hide
import com.videothems.videoplayer.music.musicplayer.extensions.show
import com.videothems.videoplayer.music.musicplayer.util.FileUtils
import com.videothems.videoplayer.music.videoplayer.model.VideoData
import java.io.File

class StatusAdapter(
    private var arrayList: ArrayList<VideoData>,
    var activity: Activity,
    var context: Context,
    var flag: Int, private var nodata: () -> Unit
) :
    RecyclerView.Adapter<StatusAdapter.MyViewHolder>() {
    inner class MyViewHolder(var binding: StatusItemLayoutBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(
            StatusItemLayoutBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun getItemCount(): Int {
        return arrayList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        with(holder.binding) {
            with(arrayList[position]) {
                when (flag) {
                    1 -> {
                        ivPlay.show()
                        ivDelete.hide()
                        ivDownload.show()
                    }

                    2 -> {
                        ivPlay.show()
                        ivDelete.show()
                        ivDownload.hide()
                    }

                    3 -> {
                        ivPlay.hide()
                        ivDelete.show()
                        ivDownload.hide()
                    }

                    else -> {
                        ivPlay.hide()
                        ivDelete.hide()
                        ivDownload.show()
                    }
                }

                Glide.with(context).load(path).into(image)

                ivShare.setOnClickListener {
                    when (flag) {
                        2 -> {
                            fileShare(context, path)
                        }

                        3 -> {
                            fileShare(context, path)
                        }

                        else -> {
                            fileShare(
                                context,
                                fileFromContentUri(context, Uri.parse(path)).path
                            )
                        }
                    }
                }

                ivDownload.setOnClickListener {
                    saveFiles(path, activity)
                }

                ivDelete.setOnClickListener {
                    val dialog = Dialog(activity)
                    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
                    dialog.setCancelable(false)
                    val dialogBinding = DeleteDialogBinding.inflate(LayoutInflater.from(activity))
                    dialog.setContentView(dialogBinding.root)

                    val lp = WindowManager.LayoutParams()
                    lp.copyFrom(dialog.window!!.attributes)
                    lp.width = WindowManager.LayoutParams.MATCH_PARENT
                    lp.height = WindowManager.LayoutParams.WRAP_CONTENT
                    lp.gravity = Gravity.CENTER

                    dialog.window!!.attributes = lp
                    dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                    dialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)

                    dialogBinding.ivCloseDelete.setOnClickListener {
                        dialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
                        dialog.cancel()
                        dialog.dismiss()
                    }

                    dialogBinding.btnDelete.setOnClickListener {
                        dialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            FileUtils.deleteWithoutManageExternalStorage(
                                path, activity
                            )
                        } else {
                            val file1 = File(path)
                            val d = file1.delete()
                            if (d) {
                                arrayList.removeAt(position)
                                if (arrayList.size == 0) {
                                    nodata
                                }
                                notifyDataSetChanged()
                            }
                        }
                        dialog.cancel()
                        dialog.dismiss()
                    }
                    dialog.show()
                }

                holder.itemView.setOnClickListener {
                    FullScreenActivity.allArrayList.removeAll(FullScreenActivity.allArrayList.toSet())
                    FullScreenActivity.allArrayList.addAll(arrayList)
                    when (flag) {
                        0 -> {
                            activity.startActivity(
                                Intent(activity, FullScreenActivity::class.java)
                                    .putExtra("INTENT_POSITION", position)
                                    .putExtra("INTENT_TYPE", flag)
                                    .putExtra("INTENT_KEY", "VALUE_STATUS")
                            )
                        }

                        1 -> {
                            if (com.videothems.videoplayer.music.videoplayer.player.PlayerActivity.mActivity != null) {
                                com.videothems.videoplayer.music.videoplayer.player.PlayerActivity.mActivity!!.finish()
                            }
                            AppConstant.mVideoData.clear()
                            AppConstant.mVideoData.addAll(arrayList)
                            val intent = Intent(activity, com.videothems.videoplayer.music.videoplayer.player.PlayerActivity::class.java)
                            intent.putExtra(AppConstant.POSITION, position)
                            intent.putExtra("INTENT_KEY", "VALUE_STATUS")
                            activity.startActivity(intent)
                        }

                        2 -> {
                            if (com.videothems.videoplayer.music.videoplayer.player.PlayerActivity.mActivity != null) {
                                com.videothems.videoplayer.music.videoplayer.player.PlayerActivity.mActivity!!.finish()
                            }
                            AppConstant.mVideoData.clear()
                            AppConstant.mVideoData.addAll(arrayList)
                            val intent = Intent(activity, com.videothems.videoplayer.music.videoplayer.player.PlayerActivity::class.java)
                            intent.putExtra(AppConstant.POSITION, position)
                            intent.putExtra("INTENT_KEY", "VALUE_STATUS")
                            activity.startActivity(intent)
                        }

                        3 -> {
                            activity.startActivity(
                                Intent(activity, FullScreenActivity::class.java)
                                    .putExtra("INTENT_POSITION", position)
                                    .putExtra("INTENT_TYPE", flag)
                                    .putExtra("INTENT_KEY", "VALUE_STATUS")
                            )
                        }

                        else -> {
                            activity.startActivity(
                                Intent(activity, FullScreenActivity::class.java)
                                    .putExtra("INTENT_POSITION", position)
                                    .putExtra("INTENT_TYPE", flag)
                                    .putExtra("INTENT_KEY", "VALUE_DOWNLOAD")
                            )
                        }
                    }
                }
            }
        }
    }
}