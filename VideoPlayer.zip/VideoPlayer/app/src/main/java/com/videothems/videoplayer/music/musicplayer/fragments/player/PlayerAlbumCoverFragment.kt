package com.videothems.videoplayer.music.musicplayer.fragments.player

import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.view.View
import androidx.core.animation.doOnEnd
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import androidx.preference.PreferenceManager
import androidx.viewpager.widget.ViewPager
import code.name.monkey.appthemehelper.util.MaterialValueHelper
import com.videothems.videoplayer.music.R
import com.videothems.videoplayer.music.databinding.FragmentPlayerAlbumCoverBinding
import com.videothems.videoplayer.music.musicplayer.LYRICS_TYPE
import com.videothems.videoplayer.music.musicplayer.SHOW_LYRICS
import com.videothems.videoplayer.music.musicplayer.adapter.album.AlbumCoverPagerAdapter
import com.videothems.videoplayer.music.musicplayer.adapter.album.AlbumCoverPagerAdapter.AlbumCoverFragment
import com.videothems.videoplayer.music.musicplayer.extensions.isColorLight
import com.videothems.videoplayer.music.musicplayer.extensions.surfaceColor
import com.videothems.videoplayer.music.musicplayer.fragments.NowPlayingScreen.*
import com.videothems.videoplayer.music.musicplayer.fragments.base.AbsMusicServiceFragment
import com.videothems.videoplayer.music.musicplayer.fragments.base.goToLyrics
import com.videothems.videoplayer.music.musicplayer.helper.MusicPlayerRemote
import com.videothems.videoplayer.music.musicplayer.helper.MusicProgressViewUpdateHelper
import com.videothems.videoplayer.music.musicplayer.lyrics.CoverLrcView
import com.videothems.videoplayer.music.musicplayer.transform.CarousalPagerTransformer
import com.videothems.videoplayer.music.musicplayer.transform.ParallaxPagerTransformer
import com.videothems.videoplayer.music.musicplayer.util.LyricUtil
import com.videothems.videoplayer.music.musicplayer.util.LyricsType
import com.videothems.videoplayer.music.musicplayer.util.PreferenceUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PlayerAlbumCoverFragment : AbsMusicServiceFragment(R.layout.fragment_player_album_cover),
    ViewPager.OnPageChangeListener, MusicProgressViewUpdateHelper.Callback,
    SharedPreferences.OnSharedPreferenceChangeListener {

    private var _binding: FragmentPlayerAlbumCoverBinding? = null
    private val binding get() = _binding!!
    private var callbacks: Callbacks? = null
    private var currentPosition: Int = 0
    val viewPager get() = binding.viewPager

    private val colorReceiver = object : AlbumCoverFragment.ColorReceiver {
        override fun onColorReady(color: com.videothems.videoplayer.music.musicplayer.util.color.MediaNotificationProcessor, request: Int) {
            if (currentPosition == request) {
                notifyColorChange(color)
            }
        }
    }

    private var progressViewUpdateHelper: MusicProgressViewUpdateHelper? = null

    private val lrcView: CoverLrcView get() = binding.lyricsView

    var lyrics: com.videothems.videoplayer.music.musicplayer.model.lyrics.Lyrics? = null

    fun removeSlideEffect() {
        val transformer = ParallaxPagerTransformer(R.id.player_image)
        transformer.setSpeed(0.3f)
    }

    private fun updateLyrics() {
        binding.lyricsView.setLabel(context?.getString(R.string.no_lyrics_found))
        val song = MusicPlayerRemote.currentSong
        lifecycleScope.launch(Dispatchers.IO) {
            val lrcFile = LyricUtil.getSyncedLyricsFile(song)
            if (lrcFile != null) {
                withContext(Dispatchers.Main) {
                    binding.lyricsView.loadLrc(lrcFile)
                }
            } else {
                val embeddedLyrics = LyricUtil.getEmbeddedSyncedLyrics(song.data)
                withContext(Dispatchers.Main) {
                    if (embeddedLyrics != null) {
                        binding.lyricsView.loadLrc(embeddedLyrics)
                    } else {
                        binding.lyricsView.reset()
                    }
                }
            }
        }
    }

    override fun onUpdateProgressViews(progress: Int, total: Int) {
        binding.lyricsView.updateTime(progress.toLong())
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentPlayerAlbumCoverBinding.bind(view)
        binding.viewPager.addOnPageChangeListener(this)
        val nps = PreferenceUtil.nowPlayingScreen

        val metrics = resources.displayMetrics
        val ratio = metrics.heightPixels.toFloat() / metrics.widthPixels.toFloat()

        if (nps == Full || nps == Classic || nps == Fit || nps == Gradient) {
//        if (nps == Full || nps == Classic || nps == Fit ) {
            binding.viewPager.offscreenPageLimit = 2
        } else if (PreferenceUtil.isCarouselEffect) {
            binding.viewPager.clipToPadding = false
            val padding =
                if (ratio >= 1.777f) {
                    40
                } else {
                    100
                }
            binding.viewPager.setPadding(padding, 0, padding, 0)
            binding.viewPager.pageMargin = 0
            binding.viewPager.setPageTransformer(false, CarousalPagerTransformer(requireContext()))
        } else {
            binding.viewPager.offscreenPageLimit = 2
            binding.viewPager.setPageTransformer(
                true,
                PreferenceUtil.albumCoverTransform
            )
        }
        progressViewUpdateHelper = MusicProgressViewUpdateHelper(this, 500, 1000)
        maybeInitLyrics()
        lrcView.apply {
            setDraggable(true) { time ->
                MusicPlayerRemote.seekTo(time.toInt())
                MusicPlayerRemote.resumePlaying()
                true
            }
            setOnClickListener {
                goToLyrics(requireActivity())
            }
        }
    }

    override fun onResume() {
        super.onResume()
        maybeInitLyrics()
        PreferenceManager.getDefaultSharedPreferences(requireContext())
            .registerOnSharedPreferenceChangeListener(this)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        PreferenceManager.getDefaultSharedPreferences(requireContext())
            .unregisterOnSharedPreferenceChangeListener(this)
        binding.viewPager.removeOnPageChangeListener(this)
        progressViewUpdateHelper?.stop()
        _binding = null
    }

    override fun onServiceConnected() {
        updatePlayingQueue()
        updateLyrics()
    }

    override fun onPlayingMetaChanged() {
        binding.viewPager.currentItem = MusicPlayerRemote.position
        updateLyrics()
    }

    override fun onQueueChanged() {
        updatePlayingQueue()
    }

    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences, key: String?) {
        if (key == SHOW_LYRICS) {
            if (sharedPreferences.getBoolean(key, false)) {
                maybeInitLyrics()
            } else {
                showLyrics(false)
                progressViewUpdateHelper?.stop()
            }
        } else if (key == LYRICS_TYPE) {
            maybeInitLyrics()
        }
    }

    private fun setLRCViewColors(backgroundColor: Int) {
        val primaryColor = MaterialValueHelper.getPrimaryTextColor(
            requireContext(),
            backgroundColor.isColorLight
        )
        val secondaryColor = MaterialValueHelper.getSecondaryDisabledTextColor(
            requireContext(),
            backgroundColor.isColorLight
        )
        lrcView.apply {
            setCurrentColor(primaryColor)
            setTimeTextColor(primaryColor)
            setTimelineColor(primaryColor)
            setNormalColor(secondaryColor)
            setTimelineTextColor(primaryColor)
        }
    }

    private fun showLyrics(visible: Boolean) {
        binding.coverLyrics.isVisible = false
        binding.lyricsView.isVisible = false
        binding.viewPager.isVisible = true
        val lyrics: View = if (PreferenceUtil.lyricsType == LyricsType.REPLACE_COVER) {
            ObjectAnimator.ofFloat(viewPager, View.ALPHA, if (visible) 0F else 1F).start()
            lrcView
        } else {
            ObjectAnimator.ofFloat(viewPager, View.ALPHA, 1F).start()
            binding.coverLyrics
        }
        ObjectAnimator.ofFloat(lyrics, View.ALPHA, if (visible) 1F else 0F).apply {
            doOnEnd {
                lyrics.isVisible = visible
            }
            start()
        }
    }

    private fun maybeInitLyrics() {
        val nps = PreferenceUtil.nowPlayingScreen
        // Don't show lyrics container for below conditions
        if (lyricViewNpsList.contains(nps) && PreferenceUtil.showLyrics) {
            showLyrics(true)
            if (PreferenceUtil.lyricsType == LyricsType.REPLACE_COVER) {
                progressViewUpdateHelper?.start()
            }
        } else {
            showLyrics(false)
            progressViewUpdateHelper?.stop()
        }
    }

    private fun updatePlayingQueue() {
        binding.viewPager.apply {
            adapter = AlbumCoverPagerAdapter(childFragmentManager, MusicPlayerRemote.playingQueue)
            adapter?.notifyDataSetChanged()
            currentItem = MusicPlayerRemote.position
            onPageSelected(MusicPlayerRemote.position)
        }
    }

    override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {

    }

    override fun onPageSelected(position: Int) {
        currentPosition = position
        if (binding.viewPager.adapter != null) {
            (binding.viewPager.adapter as AlbumCoverPagerAdapter).receiveColor(
                colorReceiver,
                position
            )
        }
        if (position != MusicPlayerRemote.position) {
            MusicPlayerRemote.playSongAt(position)
        }
    }

    override fun onPageScrollStateChanged(state: Int) {
    }


    private fun notifyColorChange(color: com.videothems.videoplayer.music.musicplayer.util.color.MediaNotificationProcessor) {
        callbacks?.onColorChanged(color)
        setLRCViewColors(
            when (PreferenceUtil.nowPlayingScreen) {
//                Adaptive, Fit, Plain, Simple -> surfaceColor()
                Adaptive, Fit -> surfaceColor()
                Flat, Normal -> if (PreferenceUtil.isAdaptiveColor) {
                    color.backgroundColor
                } else {
                    surfaceColor()
                }

                Color, Classic -> color.backgroundColor
                Blur -> Color.BLACK
                else -> surfaceColor()
            }
        )
    }

    fun setCallbacks(listener: Callbacks) {
        callbacks = listener
    }

    interface Callbacks {

        fun onColorChanged(color: com.videothems.videoplayer.music.musicplayer.util.color.MediaNotificationProcessor)

        fun onFavoriteToggled()
    }

    companion object {
        val TAG: String = PlayerAlbumCoverFragment::class.java.simpleName
    }

    private val lyricViewNpsList =
        listOf(Blur, Classic, Color, Flat, Material, Normal, Plain, Simple)
//        listOf(Blur, Classic, Color, Flat,Material, Normal)
}
