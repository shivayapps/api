package com.videothems.videoplayer.music.musicplayer.fragment

import android.view.LayoutInflater
import android.view.ViewGroup
import com.videothems.videoplayer.music.common.base.BaseBindingFragment
import com.videothems.videoplayer.music.databinding.FragmentPlaylistBinding

class PlaylistFragment : BaseBindingFragment<FragmentPlaylistBinding>() {
    override fun setBinding(
        layoutInflater: LayoutInflater,
        container: ViewGroup?
    ): FragmentPlaylistBinding {

        return FragmentPlaylistBinding.inflate(layoutInflater)
    }

    companion object {
        fun newInstance(): PlaylistFragment {
            return PlaylistFragment()
        }
    }
}