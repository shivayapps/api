package com.videothems.videoplayer.music.common.status

import android.view.LayoutInflater
import android.view.ViewGroup
import com.videothems.videoplayer.music.common.base.BaseBindingFragment
import com.videothems.videoplayer.music.common.status.adapter.StatusAdapter
import com.videothems.videoplayer.music.databinding.FragmentPhotoStatusBinding
import com.videothems.videoplayer.music.musicplayer.extensions.hide
import com.videothems.videoplayer.music.musicplayer.extensions.show
import com.videothems.videoplayer.music.videoplayer.model.VideoData


class PhotoStatusFragment : BaseBindingFragment<FragmentPhotoStatusBinding>() {
    private var photoStatusAdapter: StatusAdapter? = null

    override fun setBinding(
        layoutInflater: LayoutInflater,
        container: ViewGroup?
    ): FragmentPhotoStatusBinding {
        return FragmentPhotoStatusBinding.inflate(layoutInflater, container, false)
    }

    override fun initView() {
        super.initView()
        setNoData()
    }

    fun setAdapters(photoList: ArrayList<VideoData>) {
        if (isAdded) {
            if (photoList.size == 0) {
                mBinding.nodata.show()
                mBinding.rvPhotoStatusList.hide()
            } else {
                mBinding.nodata.hide()
                mBinding.rvPhotoStatusList.show()
                photoStatusAdapter =
                    StatusAdapter(photoList, requireActivity(), requireContext(), 0) {}
                mBinding.rvPhotoStatusList.adapter = photoStatusAdapter
            }
        }
    }

    private fun setNoData() {
        mBinding.nodata.show()
        mBinding.rvPhotoStatusList.hide()
    }

}