
package com.videothems.videoplayer.music.common.gallery.entity;

import android.annotation.SuppressLint;
import android.content.ContentUris;
import android.database.Cursor;
import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import android.provider.MediaStore;

import androidx.annotation.Nullable;

import com.videothems.videoplayer.music.common.gallery.utils.MimeType;


public class Item implements Parcelable {
    public static final Creator<Item> CREATOR = new Creator<Item>() {
        @Override
        @Nullable
        public Item createFromParcel(Parcel source) {
            return new Item(source);
        }

        @Override
        public Item[] newArray(int size) {
            return new Item[size];
        }
    };
    public static final long ITEM_ID_CAPTURE = -1;
    public static final String ITEM_DISPLAY_NAME_CAPTURE = "Capture";
    public final long id;
    public final String mimeType;
    public final String path;
    public final String pathID;
    public final String name;
    public final Long date;
    public final int width;
    public final int height;
    public final Uri uri;
    public final String bucketName;
    public final long size;
    public final long duration; // only for video, in ms

    private Item(long id, String mimeType, String pathID, String path, String bucketName, String name, long date, int width, int height, long size, long duration) {
        this.id = id;
        this.mimeType = mimeType;
        Uri contentUri;
        if (isImage()) {
            contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        } else if (isVideo()) {
            contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        } else {
            // ?
            contentUri = MediaStore.Files.getContentUri("external");
        }
        this.uri = ContentUris.withAppendedId(contentUri, id);
        this.size = size;
        this.duration = duration;
        this.path = path;
        this.pathID = pathID;
        this.name = name;
        this.date = date;
        this.width = width;
        this.height = height;
        this.bucketName = bucketName;
    }

    private Item(Parcel source) {
        id = source.readLong();
        mimeType = source.readString();
        pathID = source.readString();
        path = source.readString();
        bucketName = source.readString();
        name = source.toString();
        date = source.readLong();
        width = source.readInt();
        height = source.readInt();
        uri = source.readParcelable(Uri.class.getClassLoader());
        size = source.readLong();
        duration = source.readLong();
    }

    @SuppressLint("Range")
    public static Item valueOf(Cursor cursor) {
        return new Item(cursor.getLong(cursor.getColumnIndex(MediaStore.Files.FileColumns._ID)),
                cursor.getString(cursor.getColumnIndex(MediaStore.MediaColumns.MIME_TYPE)),
                cursor.getString(cursor.getColumnIndex(MediaStore.MediaColumns._ID)),
                cursor.getString(cursor.getColumnIndex(MediaStore.MediaColumns.DATA)),
                cursor.getString(cursor.getColumnIndex(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME)),
                cursor.getString(cursor.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME)),
                cursor.getLong(cursor.getColumnIndex(MediaStore.MediaColumns.DATE_MODIFIED)),
                cursor.getInt(cursor.getColumnIndex(MediaStore.MediaColumns.WIDTH)),
                cursor.getInt(cursor.getColumnIndex(MediaStore.MediaColumns.HEIGHT)),
                cursor.getLong(cursor.getColumnIndex(MediaStore.MediaColumns.SIZE)),
                cursor.getLong(cursor.getColumnIndex("duration")));
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(id);
        dest.writeString(mimeType);
        dest.writeString(path);
        dest.writeString(bucketName);
        dest.writeString(name);
        dest.writeLong(date);
        dest.writeInt(width);
        dest.writeInt(height);
        dest.writeParcelable(uri, 0);
        dest.writeLong(size);
        dest.writeLong(duration);
    }

    public Uri getContentUri() {
        return uri;
    }

    public boolean isCapture() {
        return id == ITEM_ID_CAPTURE;
    }

    public boolean isImage() {
        return MimeType.isImage(mimeType);
    }

    public boolean isGif() {
        return MimeType.isGif(mimeType);
    }

    public boolean isVideo() {
        return MimeType.isVideo(mimeType);
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Item)) {
            return false;
        }

        Item other = (Item) obj;
        return id == other.id
                && (mimeType != null && mimeType.equals(other.mimeType)
                || (mimeType == null && other.mimeType == null))
                && (path != null && path.equals(other.path)
                || (path == null && other.path == null))
                && (bucketName != null && bucketName.equals(other.bucketName)
                || (bucketName == null && other.bucketName == null))
                && (name != null && name.equals(other.name)
                || (name == null && other.name == null))
                && date == other.date
                && width == other.width
                && height == other.height
                && (uri != null && uri.equals(other.uri)
                || (uri == null && other.uri == null))
                && size == other.size
                && duration == other.duration;
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = 31 * result + Long.valueOf(id).hashCode();
        if (mimeType != null) {
            result = 31 * result + mimeType.hashCode();
        }
        result = 31 * result + uri.hashCode();
        result = 31 * result + Long.valueOf(size).hashCode();
        result = 31 * result + Long.valueOf(duration).hashCode();
        return result;
    }
}
