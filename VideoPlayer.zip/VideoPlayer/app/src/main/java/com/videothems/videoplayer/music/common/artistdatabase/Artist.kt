package com.videothems.videoplayer.music.common.artistdatabase

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "artist")
data class Artist(
    @PrimaryKey var id: Int?,
    @ColumnInfo(name = "name") var name: String,
    @ColumnInfo(name = "picture") var picture: String
) : Serializable
