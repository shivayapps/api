package com.videothems.videoplayer.music.common.utils

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import com.videothems.videoplayer.music.R

data class ControlInfo(
    val controlInfo: PlayerControls,
    var isActivated: Boolean
)

enum class PlayerControls(
    val id: String,
    @StringRes val stringRes: Int,
    @DrawableRes val icon: Int,
    @DrawableRes val iconActivated: Int
) {
    Speed("speed", R.string.speed, R.drawable.ic_speed_1x, R.drawable.ic_speed_1x),
    BgPlay("bgplay", R.string.background_play, R.drawable.ic_bg_play, R.drawable.ic_bg_play_on),
    AudioTrack("audiotrack", R.string.track_list, R.drawable.ic_tracks, R.drawable.ic_tracks),
    Playlist("playlist", R.string.playlist, R.drawable.ic_playlist, R.drawable.ic_playlist),
    Rotate("rotate", R.string.button_rotate, R.drawable.ic_rotate, R.drawable.ic_rotate_on),
    Equalizer(
        "equalizer",
        R.string.equalizer,
        R.drawable.ic_equalizer_menu,
        R.drawable.ic_equalizer_on
    ),
    ShuffleVideo(
        "shufflevideo",
        R.string.shuffle,
        R.drawable.ic_shuffle_video,
        R.drawable.ic_shuffle_video_on
    ),
    SleepTimer(
        "sleeptimer",
        R.string.sleep_timer,
        R.drawable.ic_sleep_timer,
        R.drawable.ic_sleep_timer
    ),
    NightMode("nightmode", R.string.dark_mode, R.drawable.ic_night_mode, R.drawable.ic_night_mode),
    Mute("mute", R.string.mute, R.drawable.ic_vol_off, R.drawable.ic_vol_on),
    DETAIL("detail", R.string.mute, R.drawable.ic_player_detail, R.drawable.ic_player_detail),
    Slide("slide", R.string.mute, R.drawable.ic_control_slide, R.drawable.ic_control_slide),
    Empty("empty", R.string._blank_space, R.drawable.blank, R.drawable.blank)
}