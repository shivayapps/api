package com.videothems.videoplayer.music.musicplayer.model

import android.os.Parcel
import android.os.Parcelable
import com.google.gson.annotations.SerializedName


class Contributor(
    @SerializedName("name") val name: String = "",
    @SerializedName("summary") val summary: String = "",
    @SerializedName("link") val link: String = "",
    @SerializedName("image") val image: String = ""
) : Parcelable {

    override fun describeContents(): Int {
        return 0;
    }

    override fun writeToParcel(dest: Parcel, flags: Int) {
    }

}