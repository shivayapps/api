package com.videothems.videoplayer.music.common.base

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context

class MyApplication : Application() {

    companion object {
        @SuppressLint("StaticFieldLeak")
        var context: Context? = null

        @SuppressLint("StaticFieldLeak")
        lateinit var mInstance: MyApplication

        @Synchronized
        fun getInstance(): MyApplication {
            return mInstance
        }
    }

    override fun onCreate() {
        super.onCreate()
        context = applicationContext
        mInstance = this
    }
}