package com.videothems.videoplayer.music.musicplayer.interfaces

import android.view.View
import com.videothems.videoplayer.music.musicplayer.db.PlaylistWithSongs

interface IPlaylistClickListener {
    fun onPlaylistClick(playlistWithSongs: PlaylistWithSongs, view: View)
}