package com.videothems.videoplayer.music.musicplayer.extensions

import com.videothems.videoplayer.music.musicplayer.model.Song
import com.videothems.videoplayer.music.musicplayer.util.MusicUtil

val Song.uri get() = MusicUtil.getSongFileUri(songId = id)