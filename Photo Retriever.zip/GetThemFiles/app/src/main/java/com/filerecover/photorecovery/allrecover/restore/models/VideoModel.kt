package com.filerecover.photorecovery.allrecover.restore.models

class VideoModel(var pathVideo: String, var lastModifiedVideo: Long, var sizeVideo: Long) {
    var isCheck = false

}