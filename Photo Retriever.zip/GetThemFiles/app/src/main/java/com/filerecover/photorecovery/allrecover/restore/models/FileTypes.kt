package com.filerecover.photorecovery.allrecover.restore.models

enum class FileTypes {
    IMAGE,
    VIDEO,
    AUDIO,
    DOCUMENT,
    APK,
    SYSTEM,
    OTHER
}