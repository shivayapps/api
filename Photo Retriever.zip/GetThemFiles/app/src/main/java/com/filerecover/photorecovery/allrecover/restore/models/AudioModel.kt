package com.filerecover.photorecovery.allrecover.restore.models

class AudioModel(var pathAudio: String, var lastModifiedAudio: Long, var sizeAudio: Long) {
    var isCheck = false

}