package albums.gallery.photo.folder.picasa.app.web.gallery.activities

import album.gallery.photo.folder.picasa.app.web.gallery.commons.extensions.*
import album.gallery.photo.folder.picasa.app.web.gallery.commons.helpers.APP_NAME
import album.gallery.photo.folder.picasa.app.web.gallery.commons.helpers.INVALID_NAVIGATION_BAR_COLOR
import album.gallery.photo.folder.picasa.app.web.gallery.commons.helpers.isMarshmallowPlus
import album.gallery.photo.folder.picasa.app.web.gallery.commons.helpers.isOreoPlus
import album.gallery.photo.folder.picasa.app.web.gallery.commons.views.*
import albums.gallery.photo.folder.picasa.app.web.gallery.FirebaseConfigHelper
import albums.gallery.photo.folder.picasa.app.web.gallery.R
import albums.gallery.photo.folder.picasa.app.web.gallery.extensions.config
import albums.gallery.photo.folder.picasa.app.web.gallery.extensions.setOnSingleClickListener
import albums.gallery.photo.folder.picasa.app.web.gallery.helpers.Config
import albums.gallery.photo.folder.picasa.app.web.gallery.preference.PreferenceKeys
import android.annotation.SuppressLint
import android.app.ActivityManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.tabs.TabLayout
import kotlinx.android.synthetic.main.activity_about.*
import java.util.*

class AboutActivity : AppCompatActivity() {
    private var appName = ""


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)
//        supportActionBar!!.hide()
//        supportActionBar!!.setElevation(0F)
        about_header.setColors(config.textColor, config.accentColor, config.backgroundColor)
        about_back.applyColorFilter(config.textColor)
        appName = intent.getStringExtra(APP_NAME) ?: ""
        var pInfo: PackageInfo? = null
        try {
            pInfo = this.packageManager.getPackageInfo(packageName, 0)
        } catch (e: PackageManager.NameNotFoundException) {
        }
        val theme = config.theme
        if (theme == false) {
            getTheme().applyStyle(R.style.ToolbarThemeDark, true)
        } else {
            getTheme().applyStyle(R.style.ToolbarThemeLight, true)
        }
        toggleThemeInit(theme)

        val version = pInfo!!.versionName
        app_version.text = "Version : $version"
        getStringValueInstaller()

        rate_lay.setOnClickListener {
            setupRateUs()
        }

        about_invite_us.setOnSingleClickListener {
            Config(this@AboutActivity).saveData(this@AboutActivity, PreferenceKeys.SystemDialogOpened, true);
            setupInvite()
        }

        about_back.setOnClickListener {
            onBackPressed()
        }
    }

    @SuppressLint("SetTextI18n")
    fun getStringValueInstaller() {
        val is_downloaded_from_val = verifyInstallerId(this@AboutActivity)
        Log.w("msg", "is_downloaded_from_val== $is_downloaded_from_val")
        if (is_downloaded_from_val) {
            text_downloaded.setText("Download Source : Play-Store")
        } else {
            text_downloaded.setText("Download Source : Unknown Sources")
        }
    }

    fun verifyInstallerId(context: Context): Boolean {
        val validInstallers: List<String> =
            ArrayList(Arrays.asList("com.android.vending", "com.google.android.feedback"))
        val installer = context.packageManager.getInstallerPackageName(context.packageName)
        return installer != null && validInstallers.contains(installer)
    }

    private fun setupInvite() {
        val text = String.format(getString(R.string.share_text), appName, getStoreUrl())
        Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_SUBJECT, appName)
            putExtra(Intent.EXTRA_TEXT, text)
            type = "text/plain"
            startActivity(Intent.createChooser(this, getString(R.string.invite_via)))
        }
    }

    private fun setupRateUs() {
        Config(this).saveData(this, PreferenceKeys.SystemDialogOpened, true)
        if (!FirebaseConfigHelper.verifyInstallerId(this@AboutActivity) && Build.MANUFACTURER.equals("samsung")) {
            val uri = Uri.parse("https://apps.samsung.com/appquery/AppRating.as?appId=" + packageName)
            val myAppLinkToMarket = Intent(Intent.ACTION_VIEW, uri)
            try {
                startActivity(myAppLinkToMarket)
            } catch (e: ActivityNotFoundException) {
//         Toast.makeText(this, "Impossible to find an application for the market", Toast.LENGTH_LONG).show()
            }
        } else {
            val uri = Uri.parse("market://details?id=" + packageName)
            val myAppLinkToMarket = Intent(Intent.ACTION_VIEW, uri)
            try {
                startActivity(myAppLinkToMarket)
            } catch (e: ActivityNotFoundException) {
//         Toast.makeText(this, "Impossible to find an application for the market", Toast.LENGTH_LONG).show()
            }
        }
    }

    fun toggleThemeInit(dark: Boolean) {

        val textColor = if (dark) 0xFF333333.toInt() else Color.parseColor("#FFFFFF")
        val accentColor = if (dark) Color.parseColor("#D6D6D6") else Color.parseColor("#303030")
        val backgroundColor = if (dark) Color.parseColor("#FFFFFF") else Color.parseColor("#000000")
        val primaryColor = if (dark) Color.parseColor("#FFFFFF") else Color.parseColor("#000000")
        val navigationColor = if (dark) Color.parseColor("#FFFFFF") else Color.parseColor("#000000")

        window.decorView.setBackgroundColor(backgroundColor)
        updateActionbarColor0(primaryColor)
        updateNavigationBarColor0(navigationColor)
        updateTextColors0(about_holder1, textColor, accentColor)
    }

    fun updateActionbarColor0(color: Int = baseConfig.primaryColor) {

        supportActionBar?.setBackgroundDrawable(ColorDrawable(color))
        updateActionBarTitle(supportActionBar?.title.toString(), color)
        updateStatusbarColor(color)
        setTaskDescription(ActivityManager.TaskDescription(null, null, color))

    }


    fun updateNavigationBarColor0(color: Int = baseConfig.navigationBarColor) {
        if (baseConfig.navigationBarColor != INVALID_NAVIGATION_BAR_COLOR) {
            try {
                val colorToUse = if (color == -2) -1 else color
                window.navigationBarColor = colorToUse

                if (isOreoPlus()) {
                    if (color.getContrastColor() == 0xFF333333.toInt()) {
                        window.decorView.systemUiVisibility = window.decorView.systemUiVisibility.addBit(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
                    } else {
                        window.decorView.systemUiVisibility = window.decorView.systemUiVisibility.removeBit(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
                    }
                }
            } catch (ignored: Exception) {
            }
        }
    }

    fun updateStatusbarColor(color: Int) {
        window.statusBarColor = color.darkenColor()

        if (isMarshmallowPlus()) {
            if (color.getContrastColor() == 0xFF333333.toInt()) {
                window.decorView.systemUiVisibility = window.decorView.systemUiVisibility.addBit(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)
            } else {
                window.decorView.systemUiVisibility = window.decorView.systemUiVisibility.removeBit(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)
            }
        }
    }

    fun updateTextColors0(viewGroup: ViewGroup, tmpTextColor: Int = 0, tmpAccentColor: Int = 0) {
        val textColor = if (tmpTextColor == 0) baseConfig.textColor else tmpTextColor
        val backgroundColor = baseConfig.backgroundColor
        val accentColor = if (tmpAccentColor == 0) {
            when {
                isWhiteTheme() || isBlackAndWhiteTheme() -> baseConfig.accentColor
                else -> baseConfig.accentColor
            }
        } else {
            tmpAccentColor
        }

        val cnt = viewGroup.childCount
        (0 until cnt).map { viewGroup.getChildAt(it) }.forEach {
            when (it) {
                is TabLayout -> it.setTabTextColors(textColor, Color.parseColor("#007AFF"))
                is TextView -> it.setTextColor(textColor)
                is MyTextView -> it.setColors(textColor, accentColor, backgroundColor)
                is MyAppCompatSpinner -> it.setColors(textColor, accentColor, backgroundColor)
                is MySwitchCompat -> it.setColors(textColor, accentColor, backgroundColor)
                is MyCompatRadioButton -> it.setColors(textColor, accentColor, backgroundColor)
                is MyAppCompatCheckbox -> it.setColors(textColor, accentColor, backgroundColor)
                is MyEditText -> it.setColors(textColor, accentColor, backgroundColor)
                is MyAutoCompleteTextView -> it.setColors(textColor, accentColor, backgroundColor)
                is MyFloatingActionButton -> it.setColors(textColor, accentColor, backgroundColor)
                is MySeekBar -> it.setColors(textColor, accentColor, backgroundColor)
                is MyButton -> it.setColors(textColor, accentColor, backgroundColor)
                is MyTextInputLayout -> it.setColors(textColor, accentColor, backgroundColor)
                is ViewGroup -> updateTextColors(it, textColor, accentColor)
            }
        }
    }
}
