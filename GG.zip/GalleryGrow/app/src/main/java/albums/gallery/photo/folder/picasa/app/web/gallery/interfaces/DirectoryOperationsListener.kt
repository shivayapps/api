package albums.gallery.photo.folder.picasa.app.web.gallery.interfaces

import albums.gallery.photo.folder.picasa.app.web.gallery.models.Directory
import java.io.File

interface DirectoryOperationsListener {
    fun refreshItems()

    fun deleteFolders(folders: ArrayList<File>)

    fun recheckPinnedFolders()

    fun updateDirectories(directories: ArrayList<Directory>)
}
