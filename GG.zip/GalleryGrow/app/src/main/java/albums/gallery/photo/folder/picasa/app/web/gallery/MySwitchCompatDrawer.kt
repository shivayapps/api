package albums.gallery.photo.folder.picasa.app.web.gallery

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import androidx.appcompat.widget.SwitchCompat
import androidx.core.graphics.drawable.DrawableCompat


class MySwitchCompatDrawer : SwitchCompat {
    constructor(context: Context) : super(context) {
        init()
    }

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        init()
    }

    constructor(context: Context, attrs: AttributeSet, defStyle: Int) : super(context, attrs, defStyle) {
        init()
    }

    fun setColors(textColor: Int, accentColor: Int) {
        setTextColor(textColor)
        val states = arrayOf(intArrayOf(-android.R.attr.state_checked), intArrayOf(android.R.attr.state_checked))
        val thumbColors = intArrayOf(resources.getColor(R.color.md_white), resources.getColor(R.color.md_white))
        val trackColors = intArrayOf(resources.getColor(R.color.md_bleck_light),resources.getColor(R.color.mdyellow))


        DrawableCompat.setTintList(DrawableCompat.wrap(thumbDrawable), ColorStateList(states, thumbColors))
        DrawableCompat.setTintList(DrawableCompat.wrap(trackDrawable), ColorStateList(states, trackColors))
    }

    @SuppressLint("WrongConstant")
    private fun init() {
        val tf = Typeface.createFromAsset(context.assets, "Montserrat.ttf")
        setTypeface(tf, 1)
    }
}
