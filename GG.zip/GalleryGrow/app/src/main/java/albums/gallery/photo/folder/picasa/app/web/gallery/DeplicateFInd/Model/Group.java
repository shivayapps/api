package albums.gallery.photo.folder.picasa.app.web.gallery.DeplicateFInd.Model;

import java.util.List;

public class Group {


    List<Photo> f5694a;

    public List<Photo> getPhotos() {
        return this.f5694a;
    }

    public void setPhotos(List<Photo> list) {
        this.f5694a = list;
    }
}
