package albums.gallery.photo.folder.picasa.app.web.gallery.extensions

import album.gallery.photo.folder.picasa.app.web.gallery.commons.helpers.SORT_DESCENDING

fun Int.isSortingAscending() = this and SORT_DESCENDING == 0
