package albums.gallery.photo.folder.picasa.app.web.gallery.activities

import albums.gallery.photo.folder.picasa.app.web.gallery.R
import albums.gallery.photo.folder.picasa.app.web.gallery.views.StatusActivity
import albums.gallery.photo.folder.picasa.app.web.gallery.adapters.RecentImageAdapter
import albums.gallery.photo.folder.picasa.app.web.gallery.models.GalleryData
import albums.gallery.photo.folder.picasa.app.web.gallery.models.GalleryImageModel
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.activity_notification_stories.*
import java.lang.reflect.Type

class NotificationStoriesActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notification_stories)

        onNewIntent(intent)


    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        val extras = intent!!.extras

        Log.d("msg","------------------" + extras?.getString("arrayList")!!)
        val gson = Gson()
        val type: Type = object : TypeToken<ArrayList<GalleryData>>() { }.type
        val pictures: ArrayList<GalleryData> = gson.fromJson(intent.getStringExtra("arrayList")!!, type)

        val pictures_adapter : ArrayList<GalleryImageModel> = ArrayList<GalleryImageModel>()
        Log.d("msg","------------------" + pictures)

        for(i in pictures) {
            pictures_adapter?.add(GalleryImageModel(i.path!!,i.path!!,i.date!!))
        }
        recycler_view_notification.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, true)
        val statusAdapter = RecentImageAdapter(this, this,  pictures_adapter)
        recycler_view_notification.adapter = statusAdapter

        val inew = Intent(this, StatusActivity::class.java)
        inew.putExtra("status_view", 0)
        inew.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(inew)
        finish()
    }
}
