package albums.gallery.photo.folder.picasa.app.web.gallery.fragments

import album.gallery.photo.folder.picasa.app.web.gallery.commons.activities.BaseSimpleActivity
import album.gallery.photo.folder.picasa.app.web.gallery.commons.extensions.*
import album.gallery.photo.folder.picasa.app.web.gallery.commons.helpers.*
import album.gallery.photo.folder.picasa.app.web.gallery.commons.models.FileDirItem
import album.gallery.photo.folder.picasa.app.web.gallery.commons.views.MyGridLayoutManager
import album.gallery.photo.folder.picasa.app.web.gallery.commons.views.MyRecyclerView
import albums.gallery.photo.folder.picasa.app.web.gallery.FirebaseConfigHelper
import albums.gallery.photo.folder.picasa.app.web.gallery.GalleryMainApplication
import albums.gallery.photo.folder.picasa.app.web.gallery.GoogleAnalyticsEvent
import albums.gallery.photo.folder.picasa.app.web.gallery.R
import albums.gallery.photo.folder.picasa.app.web.gallery.activities.*
import albums.gallery.photo.folder.picasa.app.web.gallery.adapters.MediaAdapter
import albums.gallery.photo.folder.picasa.app.web.gallery.asynctasks.GetMediaAsynctask
import albums.gallery.photo.folder.picasa.app.web.gallery.databases.GalleryDatabase
import albums.gallery.photo.folder.picasa.app.web.gallery.dialogs.ChangeGroupingDialog
import albums.gallery.photo.folder.picasa.app.web.gallery.dialogs.ChangeSortingDialog
import albums.gallery.photo.folder.picasa.app.web.gallery.dialogs.ChangeViewTypeDialog
import albums.gallery.photo.folder.picasa.app.web.gallery.dialogs.FilterMediaDialog
import albums.gallery.photo.folder.picasa.app.web.gallery.extensions.*
import albums.gallery.photo.folder.picasa.app.web.gallery.helpers.*
import albums.gallery.photo.folder.picasa.app.web.gallery.interfaces.MediaOperationsListener
import albums.gallery.photo.folder.picasa.app.web.gallery.models.Medium
import albums.gallery.photo.folder.picasa.app.web.gallery.models.ThumbnailItem
import albums.gallery.photo.folder.picasa.app.web.gallery.models.ThumbnailSection
import albums.gallery.photo.folder.picasa.app.web.gallery.startLikePro.Activity.SubScription_RemoveAdsActivity
import android.annotation.SuppressLint
import android.app.Activity
import android.app.SearchManager
import android.app.WallpaperManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.provider.MediaStore
import android.util.Log
import android.view.*
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.view.menu.MenuBuilder
import androidx.appcompat.widget.SearchView
import androidx.core.view.MenuItemCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.SimpleTarget
import com.bumptech.glide.request.transition.Transition
import com.example.admob.adLoader.BannerAds

import com.google.vr.cardboard.ThreadUtils.runOnUiThread
import kotlinx.android.synthetic.main.fragment_all_media.view.*
import java.io.File
import java.io.IOException

/*Changes By Arti V1.0.32 Change Context Call onAttach Method use use that context*/
class AllMediaFragment : Fragment(), MediaOperationsListener {
    private val LAST_MEDIA_CHECK_PERIOD = 3000L

    private var mPath = ""
    private var mIsGetImageIntent = false
    private var mIsGetVideoIntent = false
    private var mIsGetAnyIntent = false
    private var mIsGettingMedia = false
    private var mAllowPickingMultiple = false
    private var mShowAll = false
    private var mLoadedInitialPhotos = false
    private var mIsSearchOpen = false
    private var mLastSearchedText = ""
    private var mDateFormat = ""
    private var mTimeFormat = ""
    private var mLatestMediaId = 0L
    private var mLatestMediaDateId = 0L
    private var mLastMediaHandler = Handler()
    private var mTempShowHiddenHandler = Handler()
    private var mCurrAsyncTask: GetMediaAsynctask? = null
    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mSearchMenuItem: MenuItem? = null


    private var mStoredAnimateGifs = true
    private var mStoredCropThumbnails = true
    private var mStoredScrollHorizontally = true
    private var mStoredShowFileTypes = true
    private var mStoredRoundedCorners = false
    private var mStoredTextColor = 0
    private var mStoredAdjustedPrimaryColor = 0
    private var mStoredThumbnailSpacing = 0
    private var TAG = "ALL_MEDIA"
    lateinit var mView: View;
    var mContext: Context? = null


    companion object {
        var operationRunning: Boolean = false
        var mMedia = ArrayList<ThumbnailItem>()
        fun newInstance() = AllMediaFragment()
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mContext = context;
    }

    override fun onDetach() {
        super.onDetach()
        mContext = null
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view: View = inflater.inflate(R.layout.fragment_all_media, container, false)
        mView = view
        if (mView != null && mContext != null) {
            setHasOptionsMenu(true)

            if (!FirebaseConfigHelper.getIsAppAdFree(mContext)) {
                if (FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.is_home_screen_banner_enabled)) {
                    forBannerAds()
                }
            }
        }

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        mView = view

        if (mView != null && mContext != null) {
            mView.all_media_progessbar_fragment.visibility = View.VISIBLE
            val activity: Activity? = activity
            if (activity != null) {
                activity?.intent?.apply {
                    mIsGetImageIntent = getBooleanExtra(GET_IMAGE_INTENT, false)
                    mIsGetVideoIntent = getBooleanExtra(GET_VIDEO_INTENT, false)
                    mIsGetAnyIntent = getBooleanExtra(GET_ANY_INTENT, false)
                    mAllowPickingMultiple = getBooleanExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
                }
            }

            mView.media_refresh_layout_fragment.setOnRefreshListener { getMedia() }
//            val activity: Activity? = activity
            if (activity != null) {
                try {
                    mPath = activity?.intent?.getStringExtra(DIRECTORY) ?: ""
                } catch (e: Exception) {
                    //    mContext?. showErrorToast(e)
                    activity?.finish()
                    return
                }
            }

            storeStateVariables()

            if (mShowAll) {
                val activity: Activity? = activity
                if (activity != null) {
                    (activity as AppCompatActivity).supportActionBar?.setDisplayHomeAsUpEnabled(false)
                }
                registerFileUpdateListener()
            }

            mView.media_empty_text_placeholder_2_fragment.setOnClickListener {
                showFilterMediaDialog()
            }

            mContext?.updateWidgets()
        }

    }

    override fun onStart() {
        super.onStart()
        mTempShowHiddenHandler.removeCallbacksAndMessages(null)
    }

    override fun onResume() {
        super.onResume()
        if (!FirebaseConfigHelper.getIsAppAdFree(activity)) {
            BannerAds.resumeAd();
        }

        operationRunning = true
        if (mView != null && mContext != null && mContext?.config != null) {
            Log.d(TAG, "ENTERED INTO ALL MEDIA")
            mDateFormat = mContext?.config?.dateFormat.toString()
            mTimeFormat = mContext?.getTimeFormat().toString()

            if (mStoredAnimateGifs != mContext?.config?.animateGifs) {
                getMediaAdapter()?.updateAnimateGifs(mContext?.config?.animateGifs!!)
                getMediaAdapter()?.updateAnimateGifs(mContext?.config?.animateGifs!!)
            }

            if (mStoredCropThumbnails != mContext?.config?.cropThumbnails) {
                getMediaAdapter()?.updateCropThumbnails(mContext?.config?.cropThumbnails!!)
            }

            if (mStoredScrollHorizontally != mContext?.config?.scrollHorizontally) {
                mLoadedInitialPhotos = false
                mView.media_grid_fragment.adapter = null
                getMedia()
            }

            if (mStoredShowFileTypes != mContext?.config?.showThumbnailFileTypes) {
                getMediaAdapter()?.updateShowFileTypes(mContext?.config?.showThumbnailFileTypes!!)
            }

            if (mStoredTextColor != mContext?.config?.textColor) {
                getMediaAdapter()?.updateTextColor(mContext?.config?.textColor!!)
            }

            val adjustedPrimaryColor = mContext?.getAdjustedPrimaryColor()
            if (mStoredAdjustedPrimaryColor != adjustedPrimaryColor) {
                getMediaAdapter()?.updatePrimaryColor(mContext?.config?.primaryColor!!)
                mView.media_horizontal_fastscroller_fragment.updatePrimaryColor(adjustedPrimaryColor!!)
                mView.media_vertical_fastscroller_fragment.updatePrimaryColor(adjustedPrimaryColor!!)
            }

            if (mStoredThumbnailSpacing != mContext?.config?.thumbnailSpacing) {
                mView.media_grid_fragment.adapter = null

                setupAdapter()
            }

            if (mStoredRoundedCorners != mContext?.config?.fileRoundedCorners) {
                mView.media_grid_fragment.adapter = null
                setupAdapter()
            }

            mView.media_horizontal_fastscroller_fragment.updateBubbleColors()
            mView.media_vertical_fastscroller_fragment.updateBubbleColors()
            mView.media_refresh_layout_fragment.isEnabled = mContext?.config?.enablePullToRefresh!!
            mView.media_empty_text_placeholder_fragment.setTextColor(mContext?.config?.textColor!!)
            mView.media_empty_text_placeholder_2_fragment.setTextColor(mContext?.getAdjustedPrimaryColor()!!)

            if (!mIsSearchOpen) {
                (mContext as AppCompatActivity).invalidateOptionsMenu()
            }

            if (mMedia.isEmpty() || mContext?.config?.getFolderSorting(mPath)!! and SORT_BY_RANDOM == 0) {
                if (shouldSkipAuthentication()!!) {
                    tryLoadGallery()
                } else {
                    val activity1: Activity? = activity
                    if (activity1 != null) {
                        activity?.handleLockedFolderOpening(mPath) { success ->
                            if (success) {
                                if (mContext?.hasPermission(PERMISSION_WRITE_STORAGE)!!) {
                                    tryLoadGallery()
                                } else {
                                    mView.permission_txt_.visibility = View.VISIBLE
                                    mView.line1_.setColors(mContext?.config?.textColor!!, mContext?.config?.textColor!!, mContext?.config?.backgroundColor!!)
                                    mView.line2_.setColors(mContext?.config?.textColor!!, mContext?.config?.textColor!!, mContext?.config?.backgroundColor!!)
                                    mView.all_media_progessbar_fragment.visibility = View.GONE
                                    mView.media_empty_text_placeholder_2_fragment.visibility = View.GONE
                                    mView.media_empty_text_placeholder_fragment.visibility = View.GONE
                                }
                            } else {
                                activity1?.finish()
                            }
                        }
                    }
                }
            }

        }

    }

    override fun onPause() {
        super.onPause()
        if (!FirebaseConfigHelper.getIsAppAdFree(activity)) {
            BannerAds.pauseAd();
        }
        // Deselected Selected Items
        if (operationRunning) {
            getMediaAdapter()?.removeAllSelections()
        }

        if (mView != null) {
            if (mSearchMenuItem != null) {
                mSearchMenuItem?.collapseActionView()
            }

            mIsGettingMedia = false
            mView.media_refresh_layout_fragment.isRefreshing = false
            storeStateVariables()
            mLastMediaHandler.removeCallbacksAndMessages(null)

            if (!mMedia.isEmpty()) {
                mCurrAsyncTask?.stopFetching()
            }
        }

    }

    override fun onStop() {
        super.onStop()

        if (mView != null && mContext != null && mContext?.config != null) {
            if (mContext?.config?.temporarilyShowHidden!! || mContext?.config?.tempSkipDeleteConfirmation!!) {
                mTempShowHiddenHandler.postDelayed({
                    mContext?.config?.temporarilyShowHidden = false
                    mContext?.config?.tempSkipDeleteConfirmation = false
                }, SHOW_TEMP_HIDDEN_DURATION)
            } else {
                mTempShowHiddenHandler.removeCallbacksAndMessages(null)
            }
        }

    }

    override fun onDestroy() {
        if (!FirebaseConfigHelper.getIsAppAdFree(activity)) {
            BannerAds.destroyAd();
        }
        super.onDestroy()
        if (mView != null && mContext != null && mContext?.config != null) {
            val activity: Activity? = activity
            if (activity != null) {
                if (mContext?.config?.showAll!! && !activity?.isChangingConfigurations!!) {
                    mContext?.config?.temporarilyShowHidden = false
                    mContext?.config?.tempSkipDeleteConfirmation = false
                    (mContext as SimpleActivity).unregisterFileUpdateListener()
                    GalleryDatabase.destroyInstance()
                }

                mTempShowHiddenHandler.removeCallbacksAndMessages(null)

                mMedia.clear()
            }
        }

    }

    @SuppressLint("RestrictedApi")
    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        inflater.inflate(R.menu.menu_media, menu)
        val menuBuilder: MenuBuilder = menu as MenuBuilder
        menuBuilder.setOptionalIconsVisible(true)
//        val isDefaultFolder = !mContext?.config?.defaultFolder?.isEmpty()!! && File(mContext?.config?.defaultFolder!!).compareTo(File(mPath)) == 0
        if (mContext != null && mContext?.config != null) {
            menu.apply {
                findItem(R.id.group).isVisible = !mContext?.config?.scrollHorizontally!!

                // findItem(R.id.empty_recycle_bin).isVisible = mPath == RECYCLE_BIN
                // findItem(R.id.empty_disable_recycle_bin).isVisible = mPath == RECYCLE_BIN
                // findItem(R.id.restore_all_files).isVisible = mPath == RECYCLE_BIN

                // findItem(R.id.folder_view).isVisible = mShowAll
                findItem(R.id.open_camera).isVisible = true/*mShowAll*/
                // findItem(R.id.about).isVisible = mShowAll
                // findItem(R.id.create_new_folder).isVisible = false/*!mShowAll && mPath != RECYCLE_BIN && mPath != FAVORITES*/

                findItem(R.id.temporarily_show_hidden).isVisible = !mContext?.config?.shouldShowHidden!!
                findItem(R.id.stop_showing_hidden).isVisible = mContext?.config?.temporarilyShowHidden!!

                // findItem(R.id.set_as_default_folder).isVisible = false/*!isDefaultFolder*/
                // findItem(R.id.unset_as_default_folder).isVisible = false/*isDefaultFolder*/

                val viewType = mContext?.config?.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
                findItem(R.id.increase_column_count).isVisible = viewType == VIEW_TYPE_GRID && mContext?.config?.mediaColumnCnt!! < MAX_COLUMN_COUNT
                findItem(R.id.reduce_column_count).isVisible = viewType == VIEW_TYPE_GRID && mContext?.config?.mediaColumnCnt!! > 2
                findItem(R.id.toggle_filename).isVisible = viewType == VIEW_TYPE_GRID
            }
        }
        if (activity != null) {
            (activity as MainActivity).closeDrawer()
        }
        setupSearch(menu)
        updateMenuItemColors(menu)
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.sort -> {
                val activity: FragmentActivity? = activity
                if (activity != null) {
                    GoogleAnalyticsEvent.logAdapter(GoogleAnalyticsEvent.mainScreen, GoogleAnalyticsEvent.click, GoogleAnalyticsEvent.all_media_sort_by)
                    (activity as MainActivity).closeDrawer()
                }
                showSortingDialog()
            }
            R.id.filter -> {
                val activity: FragmentActivity? = activity
                if (activity != null) {
                    GoogleAnalyticsEvent.logAdapter(GoogleAnalyticsEvent.mainScreen, GoogleAnalyticsEvent.click, GoogleAnalyticsEvent.all_media_filter_media)
                    (activity as MainActivity).closeDrawer()
                }
                showFilterMediaDialog()
            }
            // R.id.empty_recycle_bin -> emptyRecycleBin()
            // R.id.empty_disable_recycle_bin -> emptyAndDisableRecycleBin()
            // R.id.restore_all_files -> restoreAllFiles()
            R.id.toggle_filename -> {
                val activity: FragmentActivity? = activity
                if (activity != null) {
                    GoogleAnalyticsEvent.logAdapter(
                        GoogleAnalyticsEvent.mainScreen,
                        GoogleAnalyticsEvent.click,
                        GoogleAnalyticsEvent.all_media_file_visibility
                    )
                    (activity as MainActivity).closeDrawer()
                }
                Log.w("msg", "Toggle_File_Name== ")
                toggleFilenameVisibility()
            }
            R.id.open_camera -> {
                val activity: FragmentActivity? = activity
                if (activity != null) {
                    GoogleAnalyticsEvent.logAdapter(
                        GoogleAnalyticsEvent.mainScreen,
                        GoogleAnalyticsEvent.click,
                        GoogleAnalyticsEvent.openCamera
                    )
                    (activity as MainActivity).closeDrawer()
                    activity?.launchCamera()
                }
            }
            // R.id.folder_view -> switchToFolderView()
            R.id.change_view_type -> {
                val activity: FragmentActivity? = activity
                if (activity != null) {
                    GoogleAnalyticsEvent.logAdapter(
                        GoogleAnalyticsEvent.mainScreen,
                        GoogleAnalyticsEvent.click,
                        GoogleAnalyticsEvent.all_media_change_view_type
                    )
                    (activity as MainActivity).closeDrawer()
                }
                changeViewType()
            }
            R.id.group -> {
                val activity: FragmentActivity? = activity
                if (activity != null) {
                    GoogleAnalyticsEvent.logAdapter(GoogleAnalyticsEvent.mainScreen, GoogleAnalyticsEvent.click, GoogleAnalyticsEvent.all_media_group_by)
                    (activity as MainActivity).closeDrawer()
                }
                showGroupByDialog()
            }
            // R.id.create_new_folder -> createNewFolder()
            R.id.temporarily_show_hidden -> {
                val activity: FragmentActivity? = activity
                if (activity != null) {
                    GoogleAnalyticsEvent.logAdapter(
                        GoogleAnalyticsEvent.mainScreen,
                        GoogleAnalyticsEvent.click,
                        GoogleAnalyticsEvent.all_media_temporarily_show_hidden
                    )
                    (activity as MainActivity).closeDrawer()
                }
                tryToggleTemporarilyShowHidden()
            }
            R.id.stop_showing_hidden -> {
                val activity: FragmentActivity? = activity
                if (activity != null) {
                    GoogleAnalyticsEvent.logAdapter(
                        GoogleAnalyticsEvent.mainScreen,
                        GoogleAnalyticsEvent.click,
                        GoogleAnalyticsEvent.all_media_stop_show_hidden
                    )
                    (activity as MainActivity).closeDrawer()
                }
                tryToggleTemporarilyShowHidden()
            }
            R.id.increase_column_count -> {
                val activity: FragmentActivity? = activity
                if (activity != null) {
                    GoogleAnalyticsEvent.logAdapter(
                        GoogleAnalyticsEvent.mainScreen,
                        GoogleAnalyticsEvent.click,
                        GoogleAnalyticsEvent.all_media_increase_column_count
                    )
                    (activity as MainActivity).closeDrawer()
                }
                increaseColumnCount()
            }
            R.id.reduce_column_count -> {
                val activity: FragmentActivity? = activity
                if (activity != null) {
                    GoogleAnalyticsEvent.logAdapter(
                        GoogleAnalyticsEvent.mainScreen,
                        GoogleAnalyticsEvent.click,
                        GoogleAnalyticsEvent.all_media_reduce_column_count
                    )
                    (activity as MainActivity).closeDrawer()
                }
                reduceColumnCount()
            }
            // R.id.set_as_default_folder -> setAsDefaultFolder()
            // R.id.unset_as_default_folder -> unsetAsDefaultFolder()
            R.id.slideshow -> {
                val activity: FragmentActivity? = activity
                if (activity != null) {
                    GoogleAnalyticsEvent.logAdapter(
                        GoogleAnalyticsEvent.mainScreen,
                        GoogleAnalyticsEvent.click, GoogleAnalyticsEvent.all_media_slideshow
                    )
                    (activity as MainActivity).closeDrawer()
                }
                startSlideshow()
            }
            R.id.settings -> {
                val activity: FragmentActivity? = activity
                if (activity != null) {
                    GoogleAnalyticsEvent.logAdapter(
                        GoogleAnalyticsEvent.mainScreen,
                        GoogleAnalyticsEvent.click,
                        GoogleAnalyticsEvent.all_media_settings
                    )
                    (activity as MainActivity).closeDrawer()
                }
                if (mContext != null) {
                    mContext?.launchSettings()



                }

            }
            R.id.remove_ads -> {
                GoogleAnalyticsEvent.logAdapter(
                    GoogleAnalyticsEvent.mainScreen,
                    GoogleAnalyticsEvent.click,
                    GoogleAnalyticsEvent.remove_ads
                )
                if (FirebaseConfigHelper.isNetworkConnected(activity)) {
                    startActivity(Intent(activity, SubScription_RemoveAdsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } else {
                    Toast.makeText(activity, "No Internet !, please try again later.", Toast.LENGTH_SHORT).show()
                }
            }
            R.id.about -> {
                GoogleAnalyticsEvent.logAdapter(
                    GoogleAnalyticsEvent.mainScreen,
                    GoogleAnalyticsEvent.click,
                    GoogleAnalyticsEvent.about_us
                )
                val activity: Activity? = activity
                if (activity != null) {
                    (activity as MainActivity).closeDrawer()
                }
                openAbout()
            }
            R.id.search -> {
                GoogleAnalyticsEvent.logAdapter(
                    GoogleAnalyticsEvent.mainScreen,
                    GoogleAnalyticsEvent.click,
                    GoogleAnalyticsEvent.search
                )
                val activity: Activity? = activity
                if (activity != null) {
                    (activity as MainActivity).closeDrawer()
                    GoogleAnalyticsEvent.logAdapter(GoogleAnalyticsEvent.mainScreen, GoogleAnalyticsEvent.click, GoogleAnalyticsEvent.all_media_search)
                }
            }
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    fun openAbout() {
        val activity: Activity? = activity
        if (activity != null) {
            val intent = Intent(activity, AboutActivity::class.java)
            startActivity(intent)
        } else if (mContext != null) {
            Toast.makeText(mContext, "Something Went Wrong..", Toast.LENGTH_SHORT).show()
        }
    }


    private fun showSortingDialog() {
        if (mView != null && mContext != null) {
            ChangeSortingDialog(mContext as BaseSimpleActivity, false, true, mPath) {
                mLoadedInitialPhotos = false
                mView.media_grid_fragment.adapter = null
                getMedia()
            }
        }
    }

    /*private fun emptyRecycleBin() {
        (activity as BaseSimpleActivity).showRecycleBinEmptyingDialog {
            (activity as BaseSimpleActivity).emptyTheRecycleBin {
                activity?.finish()
            }
        }
    }

    private fun emptyAndDisableRecycleBin() {
        (activity as BaseSimpleActivity).showRecycleBinEmptyingDialog {
            (activity as BaseSimpleActivity).emptyAndDisableTheRecycleBin {
                activity?.finish()
            }
        }
    }*/

/*    private fun restoreAllFiles() {
        val paths = mMedia.filter { it is Medium }.map { (it as Medium).path } as ArrayList<String>
        (activity as BaseSimpleActivity).restoreRecycleBinPaths(paths) {
            ensureBackgroundThread {
                mContext?.directoryDao?.deleteDirPath(RECYCLE_BIN)
            }
            activity?.finish()
        }
    }*/

    private fun toggleFilenameVisibility() {
        try {

            if (mContext != null && mContext?.config != null) {
                Log.w("msg", "Toggle_File_Name1== " + mContext?.config?.displayFileNames)

                mContext?.config?.displayFileNames = !mContext?.config?.displayFileNames!!
                getMediaAdapter()?.updateDisplayFilenames(mContext?.config?.displayFileNames!!)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


    private fun changeViewType() {
        if (mView != null && mContext != null) {
            ChangeViewTypeDialog(mContext as BaseSimpleActivity, false, mPath) {
                (mContext as AppCompatActivity).invalidateOptionsMenu()
                setupLayoutManager()
                mView.media_grid_fragment.adapter = null
                setupAdapter()
            }
        }
    }

    /*   private fun setAsDefaultFolder() {
           mContext?.config?.defaultFolder = mPath
           (activity as AppCompatActivity).invalidateOptionsMenu()
       }*/

    private fun showGroupByDialog() {
        if (mView != null && mContext != null) {
            ChangeGroupingDialog(mContext as BaseSimpleActivity, mPath) {
                mLoadedInitialPhotos = false
                mView.media_grid_fragment.adapter = null
                getMedia()
            }
        }
    }


    private fun tryToggleTemporarilyShowHidden() {
        if (mContext != null && mContext?.config != null) {
            if (mContext?.config?.temporarilyShowHidden!!) {
                toggleTemporarilyShowHidden(false)
            } else {
                val activity1: Activity? = activity
                if (activity1 != null) {
                    activity?.handleHiddenFolderPasswordProtection {
                        toggleTemporarilyShowHidden(true)
                    }
                }
            }
        }
    }

    /* private fun unsetAsDefaultFolder() {
         mContext?.config?.defaultFolder = ""
         (activity as AppCompatActivity).invalidateOptionsMenu()
     }*/

    private fun startSlideshow() {
        if (mContext != null && mMedia.isNotEmpty()) {
            // By Parth
            val intent = Intent(mContext, ViewPagerActivity::class.java).apply {
                val item = mMedia.firstOrNull { it is Medium } as? Medium ?: return
                putExtra(SKIP_AUTHENTICATION, shouldSkipAuthentication())
                putExtra(PATH, item.path)
                putExtra(SHOW_ALL, mShowAll)
                putExtra(SLIDESHOW_START_ON_ENTER, true)
                putExtra("COMPONENT", true)
                putExtra("ISFROMALLMEDIA", true)


            }
            startActivity(intent)

        }
    }

    private fun toggleTemporarilyShowHidden(show: Boolean) {
        if (mContext != null) {
            mLoadedInitialPhotos = false
            mContext?.config?.temporarilyShowHidden = show
            getMedia()
            val activity: Activity? = activity
            if (activity != null) {
                (activity as AppCompatActivity).invalidateOptionsMenu()
            }
        }
    }

    fun updateMenuItemColors(menu: Menu?, useCrossAsBack: Boolean = false, baseColor: Int = mContext?.baseConfig?.primaryColor!!) {
        if (menu == null) {
            return
        }

        val color = baseColor.getContrastColor()
        for (i in 0 until menu.size()) {
            try {
                if (i > 1) {
                    menu.getItem(i)?.icon?.setTint(Color.parseColor("#007AFF"))
                } else {
                    menu.getItem(i)?.icon?.setTint(color)
                }
            } catch (ignored: Exception) {
            }
        }
    }

    private fun setupSearch(menu: Menu) {
        val activity: Activity? = activity
        if (activity != null) {
            val searchManager = activity?.getSystemService(Context.SEARCH_SERVICE) as SearchManager
            mSearchMenuItem = menu.findItem(R.id.search)

            (mSearchMenuItem?.actionView as SearchView).findViewById<EditText>(R.id.search_src_text).apply {

                if (context?.config?.theme!!) {
                    this.setHintTextColor(resources.getColor(R.color.dark_hint))
                    this.alpha = 0.8F
                } else {
                    this.setHintTextColor(resources.getColor(R.color.light_hint))
                    this.alpha = 0.8F
                }
            }


            (mSearchMenuItem?.actionView as? SearchView)?.apply {
                setSearchableInfo(searchManager.getSearchableInfo(activity?.componentName))
                isSubmitButtonEnabled = false
                setOnQueryTextListener(object : SearchView.OnQueryTextListener {
                    override fun onQueryTextSubmit(query: String?): Boolean {
                        return false
                    }

                    override fun onQueryTextChange(newText: String?): Boolean {
                        if (mIsSearchOpen) {
                            mLastSearchedText = newText!!
                            searchQueryChanged(newText)
                        } else {
                            mView.media_empty_text_placeholder_fragment_search.beGone()
                            mView.media_grid_fragment.beVisible()
                        }
                        return true
                    }
                })
            }
        }


        MenuItemCompat.setOnActionExpandListener(mSearchMenuItem, object : MenuItemCompat.OnActionExpandListener {
            override fun onMenuItemActionExpand(item: MenuItem?): Boolean {
                mIsSearchOpen = true
                mView.media_refresh_layout_fragment.isEnabled = false
                return true
            }

            // this triggers on device rotation too, avoid doing anything
            override fun onMenuItemActionCollapse(item: MenuItem?): Boolean {
                if (mIsSearchOpen) {
                    mIsSearchOpen = false
                    mLastSearchedText = ""
                    if (mContext != null && mContext?.config != null) {
                        mView.media_refresh_layout_fragment.isEnabled = mContext?.config?.enablePullToRefresh!!
                    }
                    // searchQueryChanged("")
                }
                return true
            }
        })
    }


    private fun tryLoadGallery() {
        if (mView != null && mContext != null && mContext?.config != null) {

            FirebaseConfigHelper.logMethod("allMedia ", "Pemision try load gallery ")
            mView.permission_txt_.visibility = View.GONE

//        (activity as BaseSimpleActivity).handlePermission(PERMISSION_WRITE_STORAGE) {
//            if ( mContext?.hasPermission(PERMISSION_WRITE_STORAGE)!!) {
            val dirName = when {
                mPath == FAVORITES -> getString(R.string.favorites)
                mPath == RECYCLE_BIN -> getString(R.string.recycle_bin)
                mPath == mContext?.config?.OTGPath -> getString(R.string.app_name)
                else -> mContext?.getHumanizedFilename(mPath)
            }
            (activity as AppCompatActivity).updateActionBarTitle((if (mShowAll) resources.getString(R.string.all_folders) else dirName)!!)
            getMedia()
            setupLayoutManager()
//                    } else {
//                permission_txt_.visibility = View.VISIBLE
//                all_media_progessbar_fragment.visibility = View.GONE
            // mContext?.toast(R.string.no_storage_permissions)
            // activity?.finish()
//            }
//        }
        }
    }

    private fun storeStateVariables() {
        if (mContext != null && mContext?.config != null) {
            mContext?.config?.apply {
                mStoredAnimateGifs = animateGifs
                mStoredCropThumbnails = cropThumbnails
                mStoredScrollHorizontally = scrollHorizontally
                mStoredShowFileTypes = showThumbnailFileTypes
                mStoredTextColor = textColor
                mStoredThumbnailSpacing = thumbnailSpacing
                mStoredRoundedCorners = fileRoundedCorners
                mShowAll = showAll
            }
            mStoredAdjustedPrimaryColor = mContext?.getAdjustedPrimaryColor()!!
        }
    }

    fun registerFileUpdateListener() {
        try {
            mContext?.contentResolver?.registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, (mContext as SimpleActivity).observer)
            mContext?.contentResolver?.registerContentObserver(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, (mContext as SimpleActivity).observer)
        } catch (ignored: Exception) {
        }
    }

    private fun showFilterMediaDialog() {
        if (mView != null && mContext != null) {
            FilterMediaDialog(mContext as BaseSimpleActivity) {
                mLoadedInitialPhotos = false
                mView.media_refresh_layout_fragment.isRefreshing = true
                mView.media_grid_fragment.adapter = null
                getMedia()
            }
        }
    }

    private fun getMedia() {
        if (mContext != null && mView != null) {

            if (mIsGettingMedia) {
                return
            }
            mIsGettingMedia = true
            if (mLoadedInitialPhotos) {
                startAsyncTask()
            } else {
                if (mContext != null) {
                    mContext?.getCachedMedia(mPath, mIsGetVideoIntent, mIsGetImageIntent) {
                        if (it.isEmpty()) {
                            runOnUiThread {
                                mView.media_refresh_layout_fragment.isRefreshing = true
                            }
                        } else {
                            gotMedia(it, true)
                        }
                        // By Parth
                        startAsyncTask()
                    }
                }
            }
            mLoadedInitialPhotos = true
        }
    }

    private fun startAsyncTask() {
        Log.d("TRACING", "startAsyncTask()")
        getMedia()
        if (mContext != null) {
            mCurrAsyncTask?.stopFetching()
            mCurrAsyncTask = GetMediaAsynctask(mContext!!, mPath, mIsGetImageIntent, mIsGetVideoIntent, true) {
                ensureBackgroundThread {
                    val oldMedia = mMedia.clone() as ArrayList<ThumbnailItem>
                    if (oldMedia == null) {
                        return@ensureBackgroundThread
                    }
                    val newMedia = it
                    try {
                        gotMedia(newMedia, false)
                        oldMedia.filter { !newMedia.contains(it) }.mapNotNull { it as? Medium }.filter { !mContext?.getDoesFilePathExist(it.path)!! }.forEach {
                            mContext?.mediaDB?.deleteMediumPath(it.path)
                        }
                    } catch (e: Exception) {
                    }
                }
            }
            mCurrAsyncTask!!.execute()
        }
    }

    private fun gotMedia(media: ArrayList<ThumbnailItem>, isFromCache: Boolean) {
        // By Parth Crash Solving v29
        try {
            if (mView != null) {
                mIsGettingMedia = false
                checkLastMediaChanged()
                mMedia = media
                runOnUiThread {
                    try {
                        mView.media_refresh_layout_fragment.isRefreshing = false
                        mView.media_empty_text_placeholder_fragment.beVisibleIf(media.isEmpty() && !isFromCache)
                        mView.media_empty_text_placeholder_2_fragment.beVisibleIf(media.isEmpty() && !isFromCache)

                        if (mView.media_empty_text_placeholder_fragment.isVisible()) {
                            mView.media_empty_text_placeholder_fragment.text = getString(R.string.no_media_with_filters)

                            val activity: Activity? = activity
                            if (activity != null) {
                                if (!activity.hasPermission(PERMISSION_WRITE_STORAGE)) {
                                    mView.all_media_progessbar_fragment.visibility = View.GONE
                                    mView.media_empty_text_placeholder_2_fragment.visibility = View.GONE
                                    mView.media_empty_text_placeholder_fragment.visibility = View.GONE
                                    mView.permission_txt_.visibility = View.VISIBLE
                                }
                            }
                        }
                        mView.media_grid_fragment.beVisibleIf(mView.media_empty_text_placeholder_fragment.isGone())
                        if (mContext != null && mContext?.config != null) {
                            val viewType = mContext?.config?.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
                            val allowHorizontalScroll = mContext?.config?.scrollHorizontally == true && viewType == VIEW_TYPE_GRID
                            mView.media_vertical_fastscroller_fragment.beVisibleIf(mView.media_grid_fragment.isVisible() && !allowHorizontalScroll)
                            mView.media_horizontal_fastscroller_fragment.beVisibleIf(mView.media_grid_fragment.isVisible() && allowHorizontalScroll)
                        }
                        setupAdapter()
                    } catch (e: Exception) {
                    }
                }

                // Change by Pradip - v1.0.30
                if (mContext != null) {
                    mLatestMediaId = mContext?.getLatestMediaId()!!
                    mLatestMediaDateId = mContext?.getLatestMediaByDateId()!!
                }

                if (!isFromCache) {
                    val mediaToInsert = (mMedia).filter { it is Medium && it.deletedTS == 0L }.map { it as Medium }
                    // Change by Pradip - v1.0.30
                    val activity: Activity? = activity
                    if (activity != null) {
                        if (activity != null && activity?.mediaDB != null && mediaToInsert.isNotEmpty()) {
                            activity?.mediaDB?.insertAll(mediaToInsert)
                        }
                    }
                }
            }
        } catch (e: Exception) {
        }
    }

    private fun checkLastMediaChanged() {
        Log.d("TRACING", "checkLastMediaChanged()")
        try {
            val activity: Activity? = activity
            if (activity != null) {
                if (mContext != null) {
                    if (activity?.isDestroyed!! || mContext?.config?.getFolderSorting(mPath)!! and SORT_BY_RANDOM != 0) {
                        return
                    }
                    mLastMediaHandler.removeCallbacksAndMessages(null)
                    mLastMediaHandler.postDelayed({
                        ensureBackgroundThread {
                            try {
                                val mediaId = mContext?.getLatestMediaId()
                                val mediaDateId = mContext?.getLatestMediaByDateId()
                                if (mLatestMediaId != mediaId || mLatestMediaDateId != mediaDateId) {
                                    mLatestMediaId = mediaId!!
                                    mLatestMediaDateId = mediaDateId!!
                                    runOnUiThread {
                                        getMedia()
                                    }
                                } else {
                                    // checkLastMediaChanged()
                                }
                            } catch (e: Exception) {
                            }
                        }
                    }, LAST_MEDIA_CHECK_PERIOD)
                }
            }
        } catch (e: Exception) {
        }
    }

    private fun setupAdapter() {
        if (mView != null && mContext != null && mContext?.config != null) {
            if (!mShowAll && isDirEmpty()) {
                return
            }

            val currAdapter = mView.media_grid_fragment.adapter
            if (currAdapter == null) {

                initZoomListener()
                val fastscroller =
                    if (mContext?.config?.scrollHorizontally!!) mView.media_horizontal_fastscroller_fragment else mView.media_vertical_fastscroller_fragment
                val activity: Activity? = activity
                if (activity != null) {
                    MediaAdapter(
                        mContext as BaseSimpleActivity,
                        mMedia.clone() as ArrayList<ThumbnailItem>,
                        this,
                        mIsGetImageIntent || mIsGetVideoIntent || mIsGetAnyIntent,
                        mAllowPickingMultiple,
                        mPath,
                        mView.media_grid_fragment,
                        fastscroller, GoogleAnalyticsEvent.allMediaFrag
                    ) {
                        if (it is Medium && !activity.isFinishing!!) {
                            itemClicked(it.path)
                        }
                    }.apply {
                        setupZoomListener(mZoomListener)
                        mView.media_grid_fragment.adapter = this
                    }
                }
                val viewType = mContext?.config?.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
                if (viewType == VIEW_TYPE_LIST) {
                    mView.media_grid_fragment.scheduleLayoutAnimation()
                }

                setupLayoutManager()
                handleGridSpacing()
                measureRecyclerViewContent(mMedia)
            } else if (mLastSearchedText.isEmpty()) {
                (currAdapter as MediaAdapter).updateMedia(mMedia)
                handleGridSpacing()
                measureRecyclerViewContent(mMedia)
            } else {

                // searchQueryChanged(mLastSearchedText)
            }

            setupScrollDirection()
            refreshItems()
            mView.all_media_progessbar_fragment.visibility = View.GONE
        }
    }

    private fun setupLayoutManager() {
        if (mContext != null && mContext?.config != null) {
            val viewType = mContext?.config?.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
            if (viewType == VIEW_TYPE_GRID) {
                setupGridLayoutManager()
            } else {
                setupListLayoutManager()
            }
        }
    }

    private fun setupListLayoutManager() {
        if (mView != null) {
            val layoutManager = mView.media_grid_fragment.layoutManager as MyGridLayoutManager
            layoutManager.spanCount = 1
            layoutManager.orientation = RecyclerView.VERTICAL
            mView.media_refresh_layout_fragment.layoutParams =
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            val smallMargin = resources.getDimension(R.dimen.small_margin).toInt()
            (mView.media_grid_fragment.layoutParams as RelativeLayout.LayoutParams).apply {
                topMargin = smallMargin
                bottomMargin = smallMargin
            }
            mZoomListener = null
        }
    }

    private fun setupGridLayoutManager() {
        if (mContext != null && mView != null) {
            val layoutManager = mView.media_grid_fragment.layoutManager as MyGridLayoutManager
            (mView.media_grid_fragment.layoutParams as RelativeLayout.LayoutParams).apply {
                topMargin = 0
                bottomMargin = 0
            }

            if (mContext?.config?.scrollHorizontally!!) {
                layoutManager.orientation = RecyclerView.HORIZONTAL
                mView.media_refresh_layout_fragment.layoutParams =
                    FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT)
            } else {
                layoutManager.orientation = RecyclerView.VERTICAL
                mView.media_refresh_layout_fragment.layoutParams =
                    FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            }

            layoutManager.spanCount = mContext?.config?.mediaColumnCnt!!
            val adapter = getMediaAdapter()
            layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int): Int {
                    return if (adapter?.isASectionTitle(position) == true) {
                        layoutManager.spanCount
                    } else {
                        1
                    }
                }
            }
        }

    }

    private fun searchQueryChanged(text: String) {
        ensureBackgroundThread {
            try {
                val filtered = mMedia.filter { it is Medium && it.name.contains(text, true) } as ArrayList
                filtered.sortBy { it is Medium && !it.name.startsWith(text, true) }
                val grouped = MediaFetcher(activity?.applicationContext!!).groupMedia(filtered as ArrayList<Medium>, mPath)
                runOnUiThread {
                    if (grouped.isEmpty()) {
                        mView.media_empty_text_placeholder_fragment_search.apply {
                            beVisible()
                            if (context?.config?.theme!!) {
                                this.setTextColor(resources.getColor(R.color.dark_))
                                this.alpha = 0.8F
                            } else {
                                this.setTextColor(resources.getColor(R.color.light_))
                                this.alpha = 0.8F
                            }
                        }
                        mView.media_grid_fragment.beGone()
                    } else {
                        mView.media_empty_text_placeholder_fragment_search.beGone()
                        mView.media_grid_fragment.beVisible()
                    }

                    handleGridSpacing(grouped)
                    getMediaAdapter()?.updateMedia(grouped)
                }
            } catch (ignored: Exception) {
            }
        }
    }

    private fun itemClicked(path: String) {
        if (mContext != null) {
            if (isSetWallpaperIntent()!!) {
                mContext?.toast(R.string.setting_wallpaper)

                val wantedWidth = mContext?.wallpaperDesiredMinimumWidth
                val wantedHeight = mContext?.wallpaperDesiredMinimumHeight
                val ratio = wantedWidth?.toFloat()!! / wantedHeight!!

                val options = RequestOptions()
                    .override((wantedWidth * ratio).toInt(), wantedHeight)
                    .fitCenter()

                Glide.with(this)
                    .asBitmap()
                    .load(File(path))
                    .apply(options)
                    .into(object : SimpleTarget<Bitmap>() {
                        override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                            try {
                                val activity: Activity? = activity
                                if (activity != null) {
                                    WallpaperManager.getInstance(activity).setBitmap(resource)
                                    activity?.setResult(Activity.RESULT_OK)
                                    activity?.finish()
                                }
                            } catch (ignored: IOException) {
                            }
                        }
                    })
            } else if (mIsGetImageIntent || mIsGetVideoIntent || mIsGetAnyIntent) {
                val activity: Activity? = activity
                if (activity != null) {
                    Intent().apply {
                        data = Uri.parse(path)

                        activity?.setResult(Activity.RESULT_OK, this)
                    }
                    activity?.finish()
                }
            } else {
                Log.d("VIDEO___", "CLICKED")
                val isVideo = path.isVideoFast()
                if (isVideo) {
                    Log.d("VIDEO___1", "CLICKED")
                    val extras = HashMap<String, Boolean>()
                    extras[SHOW_FAVORITES] = mPath == FAVORITES
                    // By Parth
                    extras["COMPONENT"] = true
                    if (shouldSkipAuthentication()!!) {
                        extras[SKIP_AUTHENTICATION] = true
                    }

                    //activity?.openPath(path, false, extras)
                    Intent(mContext, ViewPagerActivity::class.java).apply {
                        putExtra(SKIP_AUTHENTICATION, shouldSkipAuthentication())
                        putExtra(PATH, path)
                        putExtra(SHOW_ALL, mShowAll)
                        putExtra(SHOW_FAVORITES, mPath == FAVORITES)
                        putExtra(SHOW_RECYCLE_BIN, mPath == RECYCLE_BIN)
                        putExtra("COMPONENT", true)
                        startActivity(this)
                    }

                } else {
                    Log.d("VIDEO___2", "CLICKED")
                    Intent(mContext, ViewPagerActivity::class.java).apply {
                        putExtra(SKIP_AUTHENTICATION, shouldSkipAuthentication())
                        putExtra(PATH, path)
                        putExtra(SHOW_ALL, mShowAll)
                        putExtra(SHOW_FAVORITES, mPath == FAVORITES)
                        putExtra(SHOW_RECYCLE_BIN, mPath == RECYCLE_BIN)
                        putExtra("COMPONENT", true)
                        startActivity(this)
                    }
                }
            }
        }
    }

    private fun isSetWallpaperIntent(): Boolean? {
        try {
            val activity: Activity? = activity
            if (activity != null) {
                return activity?.intent?.getBooleanExtra(SET_WALLPAPER_INTENT, false)
            } else {
                return false
            }
        } catch (e: Exception) {
            return false
        }
    }

    private fun shouldSkipAuthentication(): Boolean? {
        val activity: Activity? = activity
        if (activity != null) {
            return activity?.intent?.getBooleanExtra(SKIP_AUTHENTICATION, false)
        } else {
            return false
        }
    }

    private fun initZoomListener() {
        if (mContext != null && mView != null && mContext?.config != null) {

            val viewType = mContext?.config?.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
            if (viewType == VIEW_TYPE_GRID) {
                val layoutManager = mView.media_grid_fragment.layoutManager as MyGridLayoutManager
                mZoomListener = object : MyRecyclerView.MyZoomListener {
                    override fun zoomIn() {
                        if (layoutManager.spanCount > 1) {
                            reduceColumnCount()
                            getMediaAdapter()?.finishActMode()
                        }
                    }

                    override fun zoomOut() {
                        if (layoutManager.spanCount < MAX_COLUMN_COUNT) {
                            increaseColumnCount()
                            getMediaAdapter()?.finishActMode()
                        }
                    }
                }
            } else {
                mZoomListener = null
            }
        }
    }

    private fun columnCountChanged() {
        handleGridSpacing()
        if (mContext != null) {
            (mContext as AppCompatActivity).invalidateOptionsMenu()
        }
        getMediaAdapter()?.apply {
            notifyItemRangeChanged(0, media.size)
            measureRecyclerViewContent(media)
        }
    }

    private fun measureRecyclerViewContent(media: ArrayList<ThumbnailItem>) {
        // By Parth Crash Solving v29
        try {
            if (mView != null && media != null && mContext != null && mContext?.config != null) {  // Change by Priyanka - v1.0.30
                mView.media_grid_fragment.onGlobalLayout {
                    if (mContext?.config?.scrollHorizontally!!) {
                        calculateContentWidth(media)
                    } else {
                        calculateContentHeight(media)
                    }
                }
            }
        } catch (e: Exception) {
        }
    }

    private fun calculateContentWidth(media: ArrayList<ThumbnailItem>) {
        try {
            if (mView != null && mContext != null && mContext?.config != null) {
                val layoutManager = mView.media_grid_fragment.layoutManager as MyGridLayoutManager
                val thumbnailWidth = layoutManager.getChildAt(0)?.width ?: 0
                val spacing = mContext?.config?.thumbnailSpacing
                val fullWidth = ((media.size - 1) / layoutManager.spanCount + 1) * (thumbnailWidth + spacing!!) - spacing!!
                mView.media_horizontal_fastscroller_fragment.setContentWidth(fullWidth)
                mView.media_horizontal_fastscroller_fragment.setScrollToX(mView.media_grid_fragment.computeHorizontalScrollOffset())
            }
        } catch (e: Exception) {
        }
    }

    private fun calculateContentHeight(media: ArrayList<ThumbnailItem>) {
        try {
            if (mView != null && mContext != null && mContext?.config != null) {

                val layoutManager = mView.media_grid_fragment.layoutManager as MyGridLayoutManager
                val pathToCheck = if (mPath.isEmpty()) SHOW_ALL else mPath
                val hasSections = mContext?.config?.getFolderGrouping(pathToCheck)!! and GROUP_BY_NONE == 0 && !mContext?.config?.scrollHorizontally!!
                val sectionTitleHeight = if (hasSections) layoutManager.getChildAt(0)?.height ?: 0 else 0
                val thumbnailHeight = if (hasSections) layoutManager.getChildAt(1)?.height ?: 0 else layoutManager.getChildAt(0)?.height ?: 0

                var fullHeight = 0
                var curSectionItems = 0
                media.forEach {
                    if (it is ThumbnailSection) {
                        fullHeight += sectionTitleHeight
                        if (curSectionItems != 0) {
                            val rows = ((curSectionItems - 1) / layoutManager.spanCount + 1)
                            fullHeight += rows * thumbnailHeight
                        }
                        curSectionItems = 0
                    } else {
                        curSectionItems++
                    }
                }

                val spacing = mContext?.config?.thumbnailSpacing
                fullHeight += ((curSectionItems - 1) / layoutManager.spanCount + 1) * (thumbnailHeight + spacing!!) - spacing!!
                mView.media_vertical_fastscroller_fragment.setContentHeight(fullHeight)
                mView.media_vertical_fastscroller_fragment.setScrollToY(mView.media_grid_fragment.computeVerticalScrollOffset())
            }
        } catch (e: Exception) {
        }
    }

    private fun handleGridSpacing(media: ArrayList<ThumbnailItem> = mMedia) {
        if (mView != null && mContext != null && mContext?.config != null) {
            val viewType = mContext?.config?.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
            if (viewType == VIEW_TYPE_GRID) {
                val spanCount = mContext?.config?.mediaColumnCnt
                val spacing = mContext?.config?.thumbnailSpacing
                val useGridPosition = media.firstOrNull() is ThumbnailSection

                var currentGridDecoration: GridSpacingItemDecoration? = null
                if (mView.media_grid_fragment.itemDecorationCount > 0) {
                    currentGridDecoration = mView.media_grid_fragment.getItemDecorationAt(0) as GridSpacingItemDecoration
                    currentGridDecoration.items = media
                }

                val newGridDecoration = GridSpacingItemDecoration(
                    spanCount!!,
                    spacing!!,
                    mContext?.config?.scrollHorizontally!!,
                    mContext?.config?.fileRoundedCorners!!,
                    media,
                    useGridPosition
                )
                if (currentGridDecoration.toString() != newGridDecoration.toString()) {
                    if (currentGridDecoration != null) {
                        mView.media_grid_fragment.removeItemDecoration(currentGridDecoration)
                    }
                    mView.media_grid_fragment.addItemDecoration(newGridDecoration)
                }
            }
        }
    }


    private fun increaseColumnCount() {
        if (mContext != null && mContext?.config != null) {
            mContext?.config?.mediaColumnCnt = ++(mView.media_grid_fragment.layoutManager as MyGridLayoutManager).spanCount
            columnCountChanged()
        }
    }

    private fun reduceColumnCount() {
        if (mContext != null && mContext?.config != null) {
            mContext?.config?.mediaColumnCnt = --(mView.media_grid_fragment.layoutManager as MyGridLayoutManager).spanCount
            columnCountChanged()
        }
    }


    private fun isDirEmpty(): Boolean {
        if (mContext != null && mContext?.config != null) {
            return if (mMedia.size <= 0 && mContext?.config?.filterMedia!! > 0) {
                if (mPath != FAVORITES && mPath != RECYCLE_BIN) {
                    deleteDirectoryIfEmpty()
                    deleteDBDirectory()
                }

                if (mPath == FAVORITES) {
                    ensureBackgroundThread {
                        mContext?.directoryDao?.deleteDirPath(FAVORITES)
                    }
                }
                // By Parth
                // activity?.finish()
                true
            } else {
                false
            }
        } else {
            return false
        }
    }

    private fun deleteDBDirectory() {
        ensureBackgroundThread {
            try {
                if (mContext != null) {
                    mContext?.directoryDao?.deleteDirPath(mPath)
                }
            } catch (ignored: Exception) {
            }
        }
    }

    private fun forBannerAds() {
        val back_id_required = FirebaseConfigHelper.isBackIdRequired(mContext)
        val admobBanner = FirebaseConfigHelper.getAdmobBanner(mContext)
        val admobBackBanner = FirebaseConfigHelper.getAdmobBackBanner(mContext)
        Log.w("msg", "banner Ads admob_native " + FirebaseConfigHelper.remoteConfig.getString(
            FirebaseConfigHelper.admob_banner_control_home))


            BannerAds.loadAdmob_BannerADs(
                activity, mView.admob_banner_ads, admobBanner, admobBackBanner,
                back_id_required, FirebaseConfigHelper.remoteConfig.getString(
                    FirebaseConfigHelper.admob_banner_control_home), false,
                object : BannerAds.AdFinishedCallback {
                    override fun adFinished() {

                    }

                    override fun adFailedtoshow() {

                    }

                },GoogleAnalyticsEvent.allMediaFrag,
                GalleryMainApplication.getInstance()?.firebaseAnalytics
            )

    }

    private fun deleteDirectoryIfEmpty() {
        if (mContext != null && mContext?.config != null) {
            if (mContext?.config?.deleteEmptyFolders!!) {
                val fileDirItem = FileDirItem(mPath, mPath.getFilenameFromPath(), true)
                if (!fileDirItem.isDownloadsFolder() && fileDirItem.isDirectory) {
                    ensureBackgroundThread {
                        try {
                            if (mContext != null) {
                                if (fileDirItem.getProperFileCount(mContext!!, true) == 0) {
                                    (mContext as BaseSimpleActivity).tryDeleteFileDirItem(fileDirItem, true, true)
                                }
                            }
                        } catch (e: Exception) {
                        }
                    }
                }
            }
        }
    }

    private fun setupScrollDirection() {
        if (mView != null && mContext != null && mContext?.config != null) {

            val viewType = mContext?.config?.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
            val allowHorizontalScroll = mContext?.config?.scrollHorizontally!! && viewType == VIEW_TYPE_GRID
            mView.media_vertical_fastscroller_fragment.isHorizontal = false
            mView.media_vertical_fastscroller_fragment.beGoneIf(allowHorizontalScroll)

            mView.media_horizontal_fastscroller_fragment.isHorizontal = true
            mView.media_horizontal_fastscroller_fragment.beVisibleIf(allowHorizontalScroll)

            val sorting = mContext?.config?.getFolderSorting(if (mShowAll) SHOW_ALL else mPath)
            if (allowHorizontalScroll) {
                mView.media_horizontal_fastscroller_fragment.setViews(mView.media_grid_fragment, mView.media_refresh_layout_fragment) {
                    mView.media_horizontal_fastscroller_fragment.updateBubbleText(getBubbleTextItem(it, sorting!!))
                }
            } else {
                mView.media_vertical_fastscroller_fragment.setViews(mView.media_grid_fragment, mView.media_refresh_layout_fragment) {
                    mView.media_vertical_fastscroller_fragment.updateBubbleText(getBubbleTextItem(it, sorting!!))
                }
            }
        }
    }

    private fun getBubbleTextItem(index: Int, sorting: Int): String {
        var realIndex = index
        val mediaAdapter = getMediaAdapter()
        if (mediaAdapter?.isASectionTitle(index) == true) {
            realIndex++
        }
        return mediaAdapter?.getItemBubbleText(realIndex, sorting, mDateFormat, mTimeFormat) ?: ""
    }

    private fun getMediaAdapter() = mView.media_grid_fragment.adapter as? MediaAdapter


    override fun refreshItems() {
        getMedia()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
        super.onActivityResult(requestCode, resultCode, resultData)



        if (requestCode == REQUEST_EDIT_IMAGE) {
            if (resultCode == Activity.RESULT_OK && resultData != null) {
                mMedia.clear()
                refreshItems()
            }
        }
        if (requestCode == REQUEST_EDIT_IMAGE) {
            if (resultCode == Activity.RESULT_OK && resultData != null) {
                MediaActivity.mMedia.clear()
                refreshItems()
            }
        } else if (requestCode == 4466 && resultCode == Activity.RESULT_OK) {
            Log.d("MEDIA_ACTIVITY_RESULT", "RESULT All Media Fragment____________________________________________________________ 1")
            val uris: ArrayList<Uri> = activity?.intent?.getParcelableArrayListExtra<Uri>("uriPaths")!!
            val activity: Activity? = activity
            if (activity != null) {
                for (i in uris) {
                    Log.d("MEDIA_ACTIVITY_RESULT", uris.toString())
                    activity?.renameFile(i, ".${File(i.path).name}")
                }
            }
        } else if (requestCode == 4455 && resultCode == Activity.RESULT_OK) {
            Log.d("MEDIA_ACTIVITY_RESULT", "RESULT ALL MEDIA____________________________________________________________ 2")
            try {
                val activity: Activity? = activity
                if (activity != null) {
                    // Log.d("INTENTNULLORONOT","=sdgs===" + (resultData?.getStringExtra("newName")==null).toString() + " +++ "+ intent.getStringExtra("newName"))
                    activity?.renameFile(Uri.parse(activity?.intent?.getStringExtra(CURRENT_PATH)), activity?.intent?.getStringExtra(NEW_NAME))
                }
            } catch (e: Exception) {
            }
        } else if (requestCode == 4489) {
            if (resultCode == Activity.RESULT_OK) {
                Log.d("MOVE_INTENT", "-------------------------------ALLOW")
                getMediaAdapter()?.moveMultipleFiles()

            } else {
                Log.d("MOVE_INTENT", "-------------------------------DENY")
            }
        }
    }

    override fun tryDeleteFiles(fileDirItems: ArrayList<FileDirItem>) {
        if (mContext != null && mContext?.config != null) {

            val filtered = fileDirItems.filter { !mContext?.getIsPathDirectory(it.path)!! && it.path.isMediaFile() } as ArrayList
            if (filtered.isEmpty()) {
                return
            }

            if (mContext?.config?.useRecycleBin!! && !filtered.first().path.startsWith(mContext?.recycleBinPath!!)) {
                val movingItems = resources.getQuantityString(R.plurals.moving_items_into_bin, filtered.size, filtered.size)
                mContext?.toast(movingItems)

                (mContext as BaseSimpleActivity).movePathsInRecycleBin(filtered.map { it.path } as ArrayList<String>) {
                    if (it) {
                        deleteFilteredFiles(filtered)
                    } else {
                        mContext?.toast(R.string.unknown_error_occurred)
                    }
                }
            } else {
                val deletingItems = resources.getQuantityString(R.plurals.deleting_items, filtered.size, filtered.size)
                mContext?.toast(deletingItems)
                deleteFilteredFiles(filtered)
            }
        }
    }

    private fun deleteFilteredFiles(filtered: ArrayList<FileDirItem>) {
        if (mContext != null) {

            (mContext as BaseSimpleActivity).deleteFiles(filtered) {
                if (!it) {
                    mContext?.toast(R.string.unknown_error_occurred)
                    return@deleteFiles
                }

                mMedia.removeAll { filtered.map { it.path }.contains((it as? Medium)?.path) }

                ensureBackgroundThread {
                    val useRecycleBin = mContext?.config?.useRecycleBin
                    filtered.forEach {
                        if (it.path.startsWith(mContext?.recycleBinPath!!) || !useRecycleBin!!) {
                            mContext?.deleteDBPath(it.path)
                        }
                    }
                }

                if (mMedia.isEmpty()) {
                    deleteDirectoryIfEmpty()
                    deleteDBDirectory()
                    val activity: Activity? = activity
                    if (activity != null) {
                        activity?.finish()
                    }
                }
            }
        }
    }

    override fun selectedPaths(paths: ArrayList<String>) {
        val activity: Activity? = activity
        if (activity != null) {
            Intent().apply {
                putExtra(PICKED_PATHS, paths)
                activity?.setResult(Activity.RESULT_OK, this)
            }
            activity?.finish()
        }
    }

    override fun updateMediaGridDecoration(media: ArrayList<ThumbnailItem>) {
        if (mView != null) {
            var currentGridPosition = 0
            media.forEach {
                if (it is Medium) {
                    it.gridPosition = currentGridPosition++
                } else if (it is ThumbnailSection) {
                    currentGridPosition = 0
                }
            }

            if (mView.media_grid_fragment.itemDecorationCount > 0) {
                val currentGridDecoration = mView.media_grid_fragment.getItemDecorationAt(0) as GridSpacingItemDecoration
                currentGridDecoration.items = media
            }
        }
    }
}
