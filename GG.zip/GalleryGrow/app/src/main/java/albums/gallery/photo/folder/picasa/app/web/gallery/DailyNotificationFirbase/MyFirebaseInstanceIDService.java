package albums.gallery.photo.folder.picasa.app.web.gallery.DailyNotificationFirbase;

public class MyFirebaseInstanceIDService extends MyFirebaseMessagingService {
    public void onNewToken(String str) {
        super.onNewToken(str);
    }
}
