package albums.gallery.photo.folder.picasa.app.web.gallery.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
//import com.android.billingclient.api.SkuDetails
import com.bumptech.glide.Glide
import albums.gallery.photo.folder.picasa.app.web.gallery.R
import albums.gallery.photo.folder.picasa.app.web.gallery.billing_client.SkuDetails
import kotlinx.android.synthetic.main.item_donation.view.*

// By Parth [ Pending ]
class AdapterDonate(val context: Context, val skuDetailsList: List<SkuDetails>/*, val donateClient: DonateClient, val positionClickListener: ActivityDonate.PositionClickListener*/): RecyclerView.Adapter<AdapterDonate.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_donation, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return  skuDetailsList.size
    }

    private fun getIcon(i: Int): Int {
        return when (i) {
            0 -> R.drawable.ic_cookie
            1 -> R.drawable.ic_take_away
            2 -> R.drawable.ic_food
            3 -> R.drawable.ic_beer
            4 -> R.drawable.ic_fastfood
            5 -> R.drawable.ic_popcorn
            6 -> R.drawable.ic_card
            7 -> R.drawable.ic_smile
            else -> R.drawable.ic_card
        }
    }

    private fun getName(i:Int):String{
        return when (i) {
            0 -> "Cookies"
            1 -> "Coke"
            2 -> "cold drink"
            3 -> "Beer"
            4 -> "Food"
            5 -> "Popcorn"
            6 -> "Gift"
            7 -> "Smile"
            else ->"Cookies"
        }
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.price.setText(skuDetailsList[position].price)
        holder.title.setText(getName(position))
        Glide.with(context).load(getIcon(position)).into(holder.image)

        holder.itemView.setOnClickListener{
//            donateClient.makePurchase(skuDetailsList[position],context)

//                donateClient.makePurchase(listdata.get(position), activity);
            // by Parth [ Pending ]
            /*positionClickListener.itemClicked(position)*/
        }
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val price=view.price
        val image=view.image
        val title=view.title
    }

}
