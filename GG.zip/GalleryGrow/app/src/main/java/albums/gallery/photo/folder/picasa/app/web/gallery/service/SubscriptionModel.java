package albums.gallery.photo.folder.picasa.app.web.gallery.service;

public class SubscriptionModel {
    String inappPurchaseKey;
    String base64EncodedPublicKey;

    public SubscriptionModel(String inappPurchaseKey, String base64EncodedPublicKey) {
        this.inappPurchaseKey = inappPurchaseKey;
        this.base64EncodedPublicKey = base64EncodedPublicKey;
    }

    public String getInappPurchaseKey() {
        return inappPurchaseKey;
    }

    public void setInappPurchaseKey(String inappPurchaseKey) {
        this.inappPurchaseKey = inappPurchaseKey;
    }

    public String getBase64EncodedPublicKey() {
        return base64EncodedPublicKey;
    }

    public void setBase64EncodedPublicKey(String base64EncodedPublicKey) {
        this.base64EncodedPublicKey = base64EncodedPublicKey;
    }
}
