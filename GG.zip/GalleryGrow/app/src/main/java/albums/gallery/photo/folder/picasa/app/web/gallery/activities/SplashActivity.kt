package albums.gallery.photo.folder.picasa.app.web.gallery.activities

import album.gallery.photo.folder.picasa.app.web.gallery.commons.activities.BaseSplashActivity
import album.gallery.photo.folder.picasa.app.web.gallery.commons.helpers.ensureBackgroundThread
import albums.gallery.photo.folder.picasa.app.web.gallery.FirebaseConfigHelper
import albums.gallery.photo.folder.picasa.app.web.gallery.GalleryMainApplication
import albums.gallery.photo.folder.picasa.app.web.gallery.GalleryMainApplication.Companion.isMobileAdsIntilized
import albums.gallery.photo.folder.picasa.app.web.gallery.GoogleAnalyticsEvent
import albums.gallery.photo.folder.picasa.app.web.gallery.R
import albums.gallery.photo.folder.picasa.app.web.gallery.extensions.config
import albums.gallery.photo.folder.picasa.app.web.gallery.extensions.favoritesDB
import albums.gallery.photo.folder.picasa.app.web.gallery.extensions.getFavoriteFromPath
import albums.gallery.photo.folder.picasa.app.web.gallery.extensions.mediaDB
import albums.gallery.photo.folder.picasa.app.web.gallery.helpers.Config
import albums.gallery.photo.folder.picasa.app.web.gallery.helpers.SHOW_INT_AD
import albums.gallery.photo.folder.picasa.app.web.gallery.models.Favorite
import albums.gallery.photo.folder.picasa.app.web.gallery.models.InAppPurchaseModel
import albums.gallery.photo.folder.picasa.app.web.gallery.preference.PreferenceKeys
import albums.gallery.photo.folder.picasa.app.web.gallery.service.CallAPIAppPurchase
import albums.gallery.photo.folder.picasa.app.web.gallery.service.CallAPIAppPurchase.callBack
import albums.gallery.photo.folder.picasa.app.web.gallery.service.SubscriptionModel
import albums.gallery.photo.folder.picasa.app.web.gallery.startLikePro.Activity.SubScriptionActivity
import albums.gallery.photo.folder.picasa.app.web.gallery.startLikePro.inappsubscription.IabBroadcastReceiver
import albums.gallery.photo.folder.picasa.app.web.gallery.startLikePro.inappsubscription.IabHelper
import albums.gallery.photo.folder.picasa.app.web.gallery.startLikePro.inappsubscription.IabHelper.QueryInventoryFinishedListener
import albums.gallery.photo.folder.picasa.app.web.gallery.startLikePro.inappsubscription.IabResult
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.android.billingclient.api.*
import com.example.admob.adLoader.InterstitialAdLoader
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.RequestConfiguration
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.appopen.AppOpenAd.AppOpenAdLoadCallback
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.android.synthetic.main.activity_splesh.*
import retrofit2.Response
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException
import java.util.*


class SplashActivity : BaseSplashActivity(), IabBroadcastReceiver.IabBroadcastListener, PurchasesUpdatedListener, PurchaseHistoryResponseListener {

    private var loadCallback: AppOpenAdLoadCallback? = null
    private var appOpenAd: AppOpenAd? = null
    private var isResume = false
    private var isAdProcessDone = false
    private var handler = Handler(Looper.getMainLooper())

    var isCheckUpdate = false

    // Subscription
    var mHelper: IabHelper? = null
    var mBroadcastReceiver: IabBroadcastReceiver? = null

    var onCreateCounter = 0

    // INAppPuchase
    private var billingClient: BillingClient? = null
    private var skuDetails: MutableList<com.android.billingclient.api.SkuDetails>? = java.util.ArrayList()
    private val skuList: ArrayList<String> = ArrayList()
    private var mSelectedSubscriptionPeriod = ""

    private val objKeyList: ArrayList<SubscriptionModel> = ArrayList()


    private val exitSplashFromHome = "exitSplashFromHome"
    private val exitSplashFromBackPress = "BackPress_From_Splash"
    private val splashEnter = "Enter_on_Splash"
    private val splashOpenAdDismiss = "Splash_openAd_dismiss"

    companion object {
        @JvmStatic
        var isAdLoading = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_splesh)
        FirebaseApp.initializeApp(this)
        GoogleAnalyticsEvent.logAdapter(GoogleAnalyticsEvent.SplashOpenAds, "view", splashEnter)

        Log.w("msg", "Admob Splash oncreate")

        if (!isTaskRoot()) {
            finish();
            return;
        }
        onCreateCounter = Config(this@SplashActivity).getStringData(this@SplashActivity, PreferenceKeys.openAdVar, "0")?.toInt()!!


        forCourrptedAct();
        try {
            version.text =
                "Version" + packageManager.getPackageInfo(getPackageName(), 0).versionName
        } catch (e: Exception) {
        }
        // initAppPurchase(this).
        GetInAppPurchaseData_Service()
        setRequestConfigurationMobileAds()
        FirebaseMessaging.getInstance().token.addOnCompleteListener(OnCompleteListener { task ->
            if (!task.isSuccessful) {
                Log.w("msg", "Fetching FCM registration token failed", task.exception)
                return@OnCompleteListener
            }

            // Get new FCM registration token
            val token = task.result


            Log.w("msg", "token---  $token")

        })

        try {
            Log.d("msg", " - - - - - - - " + FirebaseConfigHelper.isNetworkConnected(this@SplashActivity))
            if (FirebaseConfigHelper.isNetworkConnected(this@SplashActivity)
                && FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.splash_interstitial_enable) && isMobileAdsIntilized
            ) {
                LoadFirstInterstialAd()
//                }
            } else {
                handler = Handler(Looper.getMainLooper())
                handler.postDelayed({
                    launchActivity()
                }, 1500)
            }
        } catch (e: Exception) {
            e.printStackTrace()

        }

    }

    private fun setRequestConfigurationMobileAds() {
        try {
            val testDeviceIds = Arrays.asList(
                "B57CDDF6A2BD8DE97EAEEB2C653B3EED",
                "6AD0CDF90FC1CE327C5A7A889741626C",
                "5810F1D492F24E8DC063EB504B74F83B",
                "B57CDDF6A2BD8DE97EAEEB2C653B3EED", "2F0F6F99B1F1B9A504C566E3B55FB489"
            )
            val configuration = RequestConfiguration.Builder().setTestDeviceIds(testDeviceIds).build()
            MobileAds.setRequestConfiguration(configuration)

        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }

    fun md5(s: String): String? {
        try {
            // Create MD5 Hash
            val digest: MessageDigest = MessageDigest.getInstance("MD5")
            digest.update(s.toByteArray())
            val messageDigest: ByteArray = digest.digest()
            // Create Hex String
            val hexString = StringBuffer()
            for (i in messageDigest.indices) {
                var h = Integer.toHexString(0xFF and messageDigest[i].toInt())
                //                 hexString.append();
                while (h.length < 2) {
                    h = "0$h"
                }
                hexString.append(h)
            }
            return hexString.toString()
        } catch (e: NoSuchAlgorithmException) {
            e.printStackTrace()
        }
        return ""
    }

    override fun onPause() {
        super.onPause()
        try {
            isResume = false;
            if (handler != null)
                handler.removeCallbacks(Runnable { })
            if (mBroadcastReceiver != null) {
                unregisterReceiver(mBroadcastReceiver);
                mBroadcastReceiver = null;
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        Log.w("msg", "Admob Splash onpause--")


    }

    override fun onResume() {
        super.onResume()
        Log.w("msg", "Admob Splash onResue ")
        isResume = true
        if (isAdProcessDone) {
            callFirstActivity()
        }

//        if (!handlerflag) {
//            handlerflag = true;
////            loadOpenAd()
//            loadFirstInterStitialAd()
//        }

    }

    private fun forCourrptedAct() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                getDrawable(R.drawable.title_bg)
                getDrawable(R.drawable.pixel)
            }
        } catch (e: java.lang.Exception) {
            val start = Intent(this@SplashActivity, CorruptedActivity::class.java)
            startActivity(start)
            finish()
        }
    }

//    fun startActivityWithHandler() {
//        Handler(Looper.getMainLooper()).postDelayed({
//            callFirstActivity()
//        }, 3000)
//    }

    fun callFirstActivity() {
        FirebaseConfigHelper.logMethod("splash ", " go to Next activity")
        isCheckUpdate = true


        // check if previously selected favorite items have been properly migrated into the new Favorites table
        Log.w("msg", "Admob Splash callFirstActivity call ")

        if (config.wereFavoritesMigrated) {
            launchActivity()
        } else {
            if (config.appRunCount == 0) {
                config.wereFavoritesMigrated = true
                launchActivity()
            } else {
                config.wereFavoritesMigrated = true
                ensureBackgroundThread {
                    val favorites = ArrayList<Favorite>()
                    val favoritePaths = mediaDB.getFavorites().map { it.path }.toMutableList() as ArrayList<String>
                    favoritePaths.forEach {
                        favorites.add(getFavoriteFromPath(it))
                    }
                    favoritesDB.insertAll(favorites)
                    runOnUiThread {
                        launchActivity()
                    }
                }
            }
        }
    }

    private fun launchActivity() {
        isAdLoading = true
        val sharedpreferences = getSharedPreferences(getString(R.string.app_name), MODE_PRIVATE)
        if (sharedpreferences.getBoolean("launchAct_yes", false)) {
            FirebaseConfigHelper.logMethod("splash ", " First Time Launch")
            val editor = sharedpreferences.edit()
            editor.putBoolean("launchAct_yes", java.lang.Boolean.TRUE)
            editor.commit()
            gotoNextActivity();
        } else {
            FirebaseConfigHelper.logMethod("splash ", " Second Time Launch")
            gotoNextActivity()
        }
    }

    private fun gotoNextActivity() {

        FirebaseConfigHelper.logMethod("splash ", " SubScriptionActivity Launch")
            if (!FirebaseConfigHelper.getIsAppAdFree(this@SplashActivity)
                && !Config(this@SplashActivity).getBooleanData(this@SplashActivity, PreferenceKeys.in_app_subscription_setup_failed)
                && FirebaseConfigHelper.isNetworkConnected(this@SplashActivity) && FirebaseConfigHelper.verifyInstallerId(this)
                && FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.inAppSubscriptionenabled)
            ) {
                val intent = Intent(this@SplashActivity, SubScriptionActivity::class.java)
                intent.putExtra("isFrom", this.javaClass.simpleName)
                startActivity(intent)
                finish()
            } else {
                startActivity(Intent(this@SplashActivity, MainActivity::class.java).putExtra(SHOW_INT_AD, true))
                finish()
            }



    }

    fun LoadFirstInterstialAd() {
        try {
            if (!FirebaseConfigHelper.getIsAppAdFree(this@SplashActivity) && FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.splash_interstitial_enable)) {
                val admob_int = FirebaseConfigHelper.getAdmob_intSplash(this@SplashActivity)
                val admob_back_int = FirebaseConfigHelper.getAdmobBack_intSplash(this@SplashActivity)
                val admob_rewarded = FirebaseConfigHelper.getAdmobRewared(this@SplashActivity)
                val admob_back_rewarded = FirebaseConfigHelper.getAdmobBackRewared(this@SplashActivity)
                val admob_rewarded_int = FirebaseConfigHelper.getAdmobRewaredInt(this@SplashActivity)
                val admob_back_rewarded_int = FirebaseConfigHelper.getAdmobBackRewaredInt(this@SplashActivity)
                Log.w("msg", "Admob Splash FirebaseConfig== ")
                //  GalleryMainApplication.getInstance()?.firebaseAnalytics?.let {

                val adFinished = InterstitialAdLoader.adfinishSplash() {
                    showFirstInterStitialAd();
                }

                InterstitialAdLoader.loadAdWithCallback(
                    this,
                    FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_interstitial_control),
                    admob_int,
                    admob_back_int,
                    FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.back_id_required),
                    admob_rewarded,
                    admob_back_rewarded,
                    admob_rewarded_int,
                    admob_back_rewarded_int,
                    "SplashActivity",
                    GoogleAnalyticsEvent.splashActivity,
                    GalleryMainApplication.getInstance()?.firebaseAnalytics,
                    adFinished
                )
                //  }


                Log.d(
                    "msg",
                    " - - - - - - - - - - - - - - - - " + Config(this@SplashActivity).getStringData(this@SplashActivity, PreferenceKeys.openAdVar)
                )


            } else {
                handler = Handler(Looper.getMainLooper())
                handler.postDelayed({
                    callFirstActivity()
                }, 1500)

            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showFirstInterStitialAd() {
        if (!FirebaseConfigHelper.getIsAppAdFree(this@SplashActivity) && FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.splash_interstitial_enable)
        ) {
            val admob_int = FirebaseConfigHelper.getAdmob_intSplash(this@SplashActivity)
            val admob_back_int = FirebaseConfigHelper.getAdmobBack_intSplash(this@SplashActivity)
            val admob_rewared = FirebaseConfigHelper.getAdmobRewared(this@SplashActivity)
            val admob_back_rewared = FirebaseConfigHelper.getAdmobBackRewared(this@SplashActivity)
            val admob_rewared_int = FirebaseConfigHelper.getAdmobRewaredInt(this@SplashActivity)
            val admob_back_rewared_int = FirebaseConfigHelper.getAdmobBackRewaredInt(this@SplashActivity)
            Log.w("msg", "Admob Splash loadFirstInterStitialAd")

            InterstitialAdLoader.showAdWithControl(
                this@SplashActivity,
                FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_interstitial_control),
                false,
                object : InterstitialAdLoader.adfinishwithControl {
                    override fun adfinished() {
                        Log.w("msg", "Admob Splash loadFirstInterStitialAd showAdWithControl  ")
                        FirebaseConfigHelper.logMethod("nativeshow  ", "loadFirstInterStitialAd ")
                        isAdProcessDone = true
                        if (isResume) {
                            callFirstActivity()
                        }
                    }

                    override fun rewaredfailed() {
                        Log.w("msg", "Admob Splash loadFirstInterStitialAd rewaredfailed  ")
                        FirebaseConfigHelper.logMethod("nativeshow  ", "loadFirstInterStitialAd ")
                        isAdProcessDone = true
                        if (isResume) {
                            callFirstActivity()
                        }
                    }
                },
                admob_int,
                admob_back_int,
                admob_rewared,
                admob_back_rewared,
                admob_rewared_int,
                admob_back_rewared_int,
                FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.back_id_required), GoogleAnalyticsEvent.splashActivity,
                GalleryMainApplication.getInstance()?.firebaseAnalytics,

                )
        } else {
            Log.w("msg", "Admob Splash loadFirstInterStitialAd callFirstActivity  ")
            callFirstActivity()
        }
    }


    private fun GetInAppPurchaseData_Service() {
        CallAPIAppPurchase.callApiDataForIAP(this@SplashActivity, object : callBack {
            override fun onLoaded(response: Response<InAppPurchaseModel>) {
                try {
                    if (response != null) {
                        val objInAppPurchaseModelList = response.body()!!.getObjInAppKeyList()
                        Log.w("msg", "objInAppPurchaseModelList== ${objInAppPurchaseModelList.size}")
                        if (objInAppPurchaseModelList.size > 0) {
                            for (i in objInAppPurchaseModelList.indices) {
                                //                            JSONObject c = keyList.getJSONObject(i);
                                val key = objInAppPurchaseModelList[i].inappPurchaseKey
                                val gallery_base64EncodedPublicKey = objInAppPurchaseModelList[i].gallery_base64EncodedPublicKey
                                FirebaseConfigHelper.logMethod(
                                    "SplashAct   ",
                                    "key--" + key + "gallery_base64EncodedPublicKey  " + gallery_base64EncodedPublicKey
                                )

                                objKeyList.add(SubscriptionModel(key, gallery_base64EncodedPublicKey))
                            }
                            if (objKeyList.size > 0) {
                                Log.w("msg", "pro_app_key_from_server== " + objKeyList[0].inappPurchaseKey)
                                initINP(this@SplashActivity)
                                mSelectedSubscriptionPeriod = objKeyList[0].inappPurchaseKey
                            } else {
                                loadAgainData()
                            }
                        } else {
                            objKeyList.add(SubscriptionModel(FirebaseConfigHelper.pro_app_key, FirebaseConfigHelper.gallery_base64EncodedPublicKey))
                            Log.w("msg", "pro_app_key_from_app2== " + objKeyList[0].base64EncodedPublicKey)
                            initINP(this@SplashActivity)
                            mSelectedSubscriptionPeriod = objKeyList[0].inappPurchaseKey
                        }
                    } else {
                        loadAgainData()
                    }
                } catch (e: java.lang.Exception) {
                    loadAgainData()
                }
            }

            override fun onServerError() {
                loadAgainData()
            }

            override fun onNetworkError() {
                loadAgainData()
            }
        })
    }

    private fun loadAgainData() {
        objKeyList.add(SubscriptionModel(FirebaseConfigHelper.pro_app_key, FirebaseConfigHelper.gallery_base64EncodedPublicKey))

        FirebaseConfigHelper.logMethod(
            "Splash loadAgainData   ",
            "key ---" + FirebaseConfigHelper.pro_app_key + "gallery_base64EncodedPublicKey --- " + FirebaseConfigHelper.gallery_base64EncodedPublicKey
        )
        initINP(this@SplashActivity)
        mSelectedSubscriptionPeriod = objKeyList[0].inappPurchaseKey
    }


    override fun onBackPressed() {
        loadCallback = null
        GoogleAnalyticsEvent.logAdapter(GoogleAnalyticsEvent.SplashOpenAds, "view", exitSplashFromBackPress)
        super.onBackPressed()
        appOpenAd = null
//        finishAffinity()
    }


    fun initINP(context: Context?) {
        if (context != null) {
            mHelper = IabHelper(context, objKeyList.get(0).base64EncodedPublicKey, this@SplashActivity)
            mHelper!!.enableDebugLogging(true)
            Config(this@SplashActivity).saveDataSubString(this@SplashActivity, PreferenceKeys.start_like_pro, objKeyList.get(0).inappPurchaseKey)
            Log.w("msg", "key===_splash= " + Config(this@SplashActivity).getStringDataSub(this@SplashActivity, PreferenceKeys.start_like_pro))
            mHelper!!.startSetup(object : IabHelper.OnIabSetupFinishedListener {
                override fun onIabSetupFinished(result: IabResult) {
                    Log.w("msg", "Splash onIabSetupFinished." + result.isSuccess)
                    if (!result.isSuccess) {
                        // Oh noes, there was a problem.

//                        complain("Problem setting up in-app billing: " + result);
                        Config(this@SplashActivity).saveDataSubBool(this@SplashActivity, PreferenceKeys.in_app_subscription_setup_failed, true)
                        return
                    }

                    Config(this@SplashActivity).saveDataSubBool(this@SplashActivity, PreferenceKeys.in_app_subscription_setup_failed, false)


                    // Have we been disposed of in the meantime? If so, quit.
                    if (mHelper == null) return
                    try {
                        mBroadcastReceiver = IabBroadcastReceiver(this@SplashActivity)
                        val broadcastFilter = IntentFilter(IabBroadcastReceiver.ACTION)
                        context.registerReceiver(mBroadcastReceiver, broadcastFilter)
                        // IAB is fully set up. Now, let's get an inventory of stuff we own.
                        Log.w("msg", "Splash Setup successful. Querying inventory.")
                        try {
                            mHelper!!.queryInventoryAsync(mGotInventoryListener)
                        } catch (e: java.lang.Exception) {
                            //complain("Error querying inventory. Another async operation in progress.");
                        }
                    } catch (e: java.lang.Exception) {
                    }
                }
            })
        }
    }

    var mGotInventoryListener =
        QueryInventoryFinishedListener { result, inventory ->
            Log.w("msg", "Query inventory finished.")

            // Have we been disposed of in the meantime? If so, quit.
            if (mHelper == null) return@QueryInventoryFinishedListener

            // Is it a failure?
            if (result.isFailure) {
                //                complain("Failed to query inventory: " + result);
                return@QueryInventoryFinishedListener
            }
            Log.w("msg", "Splash Query inventory was successful.")
            // First find out which subscription is auto renewing
//            val start_like_pro = inventory.getPurchase(Config(this@SplashActivity).getStringDataSub(this@SplashActivity, "remove_ads"))
            val start_like_pro = inventory.getPurchase(Config(this@SplashActivity).getStringDataSub(this@SplashActivity, PreferenceKeys.start_like_pro))
            Log.w("msg", "Splash Query inventory was successful remove_ads ." + start_like_pro)

            if (start_like_pro != null && start_like_pro.isAutoRenewing) {
                Log.w("msg", "Splash Query inventory was successful remove_ads ." + start_like_pro.isAutoRenewing)
                Config(this@SplashActivity).saveDataSubBool(this@SplashActivity, FirebaseConfigHelper.is_remove_ads, true)
            } else {
                Config(this@SplashActivity).saveDataSubBool(this@SplashActivity, FirebaseConfigHelper.is_remove_ads, false)
            }
        }

    override fun receivedBroadcast() {
        Log.w("msg", "Splash Received broadcast notification. Querying inventory.")
        try {
            mHelper!!.queryInventoryAsync(mGotInventoryListener)
        } catch (e: java.lang.Exception) {
        }
    }


    override fun onPurchaseHistoryResponse(billingResult: BillingResult, purchaseHistoryList: MutableList<PurchaseHistoryRecord>?) {
        try {
            Log.w("msg", "onPurchaseHistoryResponse purchaseHistoryList :" + purchaseHistoryList!!.size);
            Log.w("msg", "onPurchaseHistoryResponse responseCode :" + billingResult?.responseCode);

            if (billingResult?.responseCode == BillingClient.BillingResponseCode.OK) {
                if (purchaseHistoryList != null && purchaseHistoryList.size > 0) {
                    for (purchase in purchaseHistoryList!!) {
                        Log.w("msg", "onPurchaseHistoryResponse purchase :" + purchase.skus.get(0));
                        Log.w("msg", "onPurchaseHistoryResponse skuDetails :" + skuDetails!!.get(0).getSku());
                        Log.w("msg", "onPurchaseHistoryResponse check :" + purchase.skus.get(0).equals(skuDetails!!.get(0).getSku()));
                        if (purchase.skus.get(0).equals(skuDetails!!.get(0).getSku())) {
                            Config(this@SplashActivity).saveDataSubBool(this@SplashActivity, FirebaseConfigHelper.is_remove_ads, true)
                        } else {
                            Config(this@SplashActivity).saveDataSubBool(this@SplashActivity, FirebaseConfigHelper.is_remove_ads, false)
                            GetInAppPurchaseData_Service()
                        }
                    }
                } else {
                    Log.w("msg", "onPurchaseHistoryResponse else :");
                    GetInAppPurchaseData_Service()
                }
            } else {
                Log.w("msg", "onPurchaseHistoryResponse responseCode else :");
                GetInAppPurchaseData_Service()
            }
        } catch (e: Exception) {
        }
    }

    override fun onPurchasesUpdated(billingResult: BillingResult, list: MutableList<Purchase>?) {
        try {
            Log.w("msg", "onPurchasesUpdated billingResult :" + billingResult.responseCode);
            Log.w("msg", "onPurchasesUpdated list :" + list!!.size);
        } catch (e: Exception) {
        }
    }


    override fun onDestroy() {
        // Change by Priyanka - v1.0.30
        try {
            if (mBroadcastReceiver != null) {
                unregisterReceiver(mBroadcastReceiver);
                mBroadcastReceiver = null;
            }
        } catch (e: Exception) {
        }
        super.onDestroy()
    }


    override fun onStop() {
        super.onStop()
        Log.w("msg", "OnStop_Splash== ")
        appOpenAd = null
        GalleryMainApplication().destroyAd()

    }

}
