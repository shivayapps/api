package albums.gallery.photo.folder.picasa.app.web.gallery.models

data class AlbumCover(val path: String, val tmb: String)
