package albums.gallery.photo.folder.picasa.app.web.gallery.DeplicateFInd.Helper;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.provider.MediaStore;
import android.util.Log;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

import albums.gallery.photo.folder.picasa.app.web.gallery.DeplicateFInd.GroupActivity;
import albums.gallery.photo.folder.picasa.app.web.gallery.DeplicateFInd.Model.Group;
import albums.gallery.photo.folder.picasa.app.web.gallery.DeplicateFInd.Model.Photo;

public class SimilarPhoto {
    private static final String TAG = "SimilarPhoto";

    private static void calculateFingerPrint(Context context, List<Photo> list) {
        for (Photo next : list) {
            Bitmap thumbnail = MediaStore.Images.Thumbnails.getThumbnail(context.getContentResolver(), next.getId(), 3, (BitmapFactory.Options) null);
            try {
                Matrix matrix = new Matrix();
                matrix.postScale(8.0f / ((float) thumbnail.getWidth()), 8.0f / ((float) thumbnail.getHeight()));
                Bitmap createBitmap = Bitmap.createBitmap(thumbnail, 0, 0, thumbnail.getWidth(), thumbnail.getHeight(), matrix, false);
                next.setFinger(getFingerPrint(createBitmap));
                thumbnail.recycle();
                createBitmap.recycle();
            } catch (Exception unused) {
            }
        }
    }

    private static double computeGrayValue(int i) {
        double d = (double) ((i >> 16) & 255);
        Double.isNaN(d);
        double d2 = (double) ((i >> 8) & 255);
        Double.isNaN(d2);
        double d3 = (d * 0.3d) + (d2 * 0.59d);
        double d4 = (double) (i & 255);
        Double.isNaN(d4);
        return d3 + (d4 * 0.11d);
    }

    public static List<Group> find(Context context, List<Photo> list) {
        calculateFingerPrint(context, list);
        ArrayList arrayList = new ArrayList();
        int i = 0;
        Log.w("msg", "duplicate list -- " + list);
        Log.w("msg", "duplicate list size-- " + list.size());
        GroupActivity.deleteData += list.size();

        while (i < list.size()) {
            Photo photo = list.get(i);
            ArrayList arrayList2 = new ArrayList();
            Log.w("msg", "duplicate photo -- " + photo);

            arrayList2.add(photo);
            i++;
            int i2 = i;

            while (i2 < list.size()) {
                Photo photo2 = list.get(i2);
                if (hamDist(photo.getFinger(), photo2.getFinger()) < 5) {
                    Log.w("msg", "duplicate photo2 -- " + photo2.getPath());

                    arrayList2.add(photo2);
                    list.remove(photo2);
                    i2--;
                }
                i2++;
            }
            Group group = new Group();
            group.setPhotos(arrayList2);
            arrayList.add(group);
        }
        return arrayList;
    }

    private static long getFingerPrint(Bitmap bitmap) {
        double[][] grayPixels = getGrayPixels(bitmap);
        return getFingerPrint(grayPixels, getGrayAvg(grayPixels));
    }

    private static long getFingerPrint(double[][] dArr, double d) {
        String str;
        int length = dArr[0].length;
        int length2 = dArr.length;
        byte[] bArr = new byte[(length2 * length)];
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            for (int i2 = 0; i2 < length2; i2++) {
                if (dArr[i][i2] >= d) {
                    bArr[(i * length2) + i2] = 1;
                    str = "1";
                } else {
                    bArr[(i * length2) + i2] = 0;
                    str = "0";
                }
                sb.append(str);
            }
        }
        String str2 = TAG;
        Log.d(str2, "getFingerPrint: " + sb.toString());
        long j = 0;
        long j2 = 0;
        for (int i3 = 0; i3 < 64; i3++) {
            if (i3 < 32) {
                j2 += (long) (bArr[63 - i3] << i3);
            } else {
                j += (long) (bArr[63 - i3] << (i3 - 31));
            }
        }
        return (j << 32) + j2;
    }

    private static double getGrayAvg(double[][] dArr) {
        int length = dArr[0].length;
        int length2 = dArr.length;
        int i = 0;
        int i2 = 0;
        while (i < length) {
            int i3 = i2;
            for (int i4 = 0; i4 < length2; i4++) {
                double d = (double) i3;
                double d2 = dArr[i][i4];
                Double.isNaN(d);
                i3 = (int) (d + d2);
            }
            i++;
            i2 = i3;
        }
        return (double) (i2 / (length * length2));
    }

    private static double[][] getGrayPixels(Bitmap bitmap) {
        double[][] dArr = (double[][]) Array.newInstance(double.class, new int[]{8, 8});
        for (int i = 0; i < 8; i++) {
            for (int i2 = 0; i2 < 8; i2++) {
                dArr[i][i2] = computeGrayValue(bitmap.getPixel(i, i2));
            }
        }
        return dArr;
    }

    private static int hamDist(long j, long j2) {
        int i = 0;
        for (long j3 = j ^ j2; j3 != 0; j3 &= j3 - 1) {
            i++;
        }
        return i;
    }
}
