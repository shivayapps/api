package albums.gallery.photo.folder.picasa.app.web.gallery.DeplicateFInd;

import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import albums.gallery.photo.folder.picasa.app.web.gallery.DeplicateFInd.Helper.SimilarPhoto;
import albums.gallery.photo.folder.picasa.app.web.gallery.DeplicateFInd.Model.Group;
import albums.gallery.photo.folder.picasa.app.web.gallery.DeplicateFInd.Model.Photo;
import albums.gallery.photo.folder.picasa.app.web.gallery.DeplicateFInd.Util.PhotoRepository;
import albums.gallery.photo.folder.picasa.app.web.gallery.DeplicateFInd.lib.SimpleSectionedGridAdapter;
import albums.gallery.photo.folder.picasa.app.web.gallery.DeplicateFInd.lib.SquareImageView_width;
import albums.gallery.photo.folder.picasa.app.web.gallery.R;
import albums.gallery.photo.folder.picasa.app.web.gallery.helpers.Config;
import albums.gallery.photo.folder.picasa.app.web.gallery.preference.PreferenceKeys;


public class GroupActivityBlack extends AppCompatActivity implements View.OnClickListener {

    static ArrayList<Photo> f5660d = new ArrayList<>();

    ProgressDialog f5661a;
    TextView txt_noofphotos;
    ArrayList<SimpleSectionedGridAdapter.Section> f5662b = new ArrayList<>();
    //    ArrayList<SimpleSectionedGridAdapter.Section> f5662b = new ArrayList<>();
    String getImage;
    SimpleSectionedGridAdapter f5663c;

    //  PinnedSectionGridView f5664e;
    public static int deleteData = 0;
    GridView f5664e;
    SharedPreferences.Editor editor;
    SharedPreferences sharedPref;


    ImageAdepters f5665f;
    LinearLayout rootview_loading_view, dupview_loading_view;
    RelativeLayout duplicate_image_lay, back_rel_layout2, back_rel_layout3, back_rel_layout, dp_background, toolbar;
    TextView tv_title, rootview_text, root_scan, root_depend_num, dup_text, dup_scan, txt_noofphotos_dup, dup_find_no;
    RelativeLayout f5667h;
    RelativeLayout f5668i;
    List<Group> f5669j;

    CheckBox f5666g;


    private CheckBox chk;
    private RelativeLayout f5666g1;

    class ImageAdepters extends BaseAdapter {
        Activity f5674a;
        LayoutInflater f5675b;
        SparseBooleanArray f5676c = new SparseBooleanArray();
        ArrayList<Photo> f5677d;
        ViewHolder f5678e;
        View f5679f;

        class ViewHolder {
            SquareImageView_width f5683a;
            ImageView f5684b;

            ViewHolder() {
            }
        }

        ImageAdepters(Activity activity, ArrayList<Photo> arrayList) {
            this.f5674a = activity;
            this.f5675b = LayoutInflater.from(this.f5674a);
            this.f5679f = this.f5675b.inflate(R.layout.dp_item_grid_duplictae_image, (ViewGroup) null);
            this.f5677d = arrayList;
        }


        @SuppressLint("WrongConstant")
        public void mo29395a() {
            try {
                this.f5676c = new SparseBooleanArray();
                notifyDataSetChanged();
                f5668i.setVisibility(8);
            } catch (Exception e) {
//                // e.printStackTrace();
            }
        }


        @SuppressLint("WrongConstant")
        public void mo29396b() {
            for (int i = 0; i < this.f5677d.size(); i++) {
                this.f5676c.put(i, true);
            }
            for (int i2 = 0; i2 < f5662b.size(); i2++) {
                this.f5676c.put(f5662b.get(i2).getFirstPosition(), false);
            }
            notifyDataSetChanged();
            f5668i.setVisibility(0);
        }


        public ArrayList<Photo> mo29397c() {
            ArrayList<Photo> arrayList = new ArrayList<>();
            int i = 0;
            while (i < this.f5677d.size()) {
                try {
                    if (this.f5676c.get(i)) {
                        arrayList.add(this.f5677d.get(i));
                    }
                    i++;
                } catch (Exception e) {
//                    // e.printStackTrace();
                }
            }
            return arrayList;
        }

        public void delete(ArrayList<String> arrayList) {
            int i = 0;
            while (i < arrayList.size()) {
                try {
                    File file = new File(arrayList.get(i));
                    if (file.exists()) {
                        file.delete();
                        if (Build.VERSION.SDK_INT >= 19) {
                            Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                            intent.setData(Uri.fromFile(file));
                            this.f5674a.sendBroadcast(intent);
                        } else {
                            this.f5674a.sendBroadcast(new Intent("android.intent.action.MEDIA_MOUNTED", Uri.parse("file://" + Environment.getExternalStorageDirectory())));
                        }
                    }
                    i++;
                } catch (Exception unused) {
                }
            }
            notifyDataSetChanged();
        }

        public int getCount() {
            return this.f5677d.size();
        }

        public Object getItem(int i) {
            return this.f5677d.get(i);
        }

        public long getItemId(int i) {
            return (long) i;
        }

        public View getView(final int i, View view, ViewGroup viewGroup) {
            ImageView imageView;
            int i2;
            if (view == null) {
                view = this.f5675b.inflate(R.layout.dp_item_grid_duplictae_image, (ViewGroup) null);
                this.f5678e = new ViewHolder();
//                this.f5678e.f5683a = (RoundedImageView) view.findViewById(R.id.image);
                this.f5678e.f5683a = (SquareImageView_width) view.findViewById(R.id.image);

                this.f5678e.f5684b = (ImageView) view.findViewById(R.id.checkbox);
                view.setTag(this.f5678e);
            } else {
                this.f5678e = (ViewHolder) view.getTag();
            }
            try {
                Glide.with(this.f5674a).load(this.f5677d.get(i).getPath()).into((ImageView) this.f5678e.f5683a);
            } catch (Exception unused) {
            }
            if (this.f5676c.get(i)) {
                imageView = this.f5678e.f5684b;
                i2 = R.drawable.dp_check;
            } else {
                imageView = this.f5678e.f5684b;
                i2 = R.drawable.dp_uncheck;
            }
            imageView.setImageResource(i2);
            view.setOnClickListener(new View.OnClickListener() {
                @SuppressLint("WrongConstant")
                public void onClick(View view) {
                    try {
                        boolean z = ImageAdepters.this.f5676c.get(i);
                        if (z) {
                            ImageAdepters.this.f5678e.f5684b.setImageResource(R.drawable.dp_uncheck);
                        }
                        if (!z) {
                            ImageAdepters.this.f5678e.f5684b.setImageResource(R.drawable.dp_check);
                        }
                        ImageAdepters.this.f5676c.put(i, !z);
                        ImageAdepters.this.notifyDataSetChanged();
                        if (ImageAdepters.this.mo29397c().size() == 0) {
                            f5668i.setVisibility(8);
                        } else {
                            f5668i.setVisibility(0);
                        }
                    } catch (Exception e) {
//                        // e.printStackTrace();
                    }
                }
            });
            return view;
        }
    }

    @SuppressLint({"StaticFieldLeak"})
    public class ReplaceData extends AsyncTask<String, String, String> {
        ArrayList<Photo> f5686a = new ArrayList<>();

        ReplaceData(ArrayList<Photo> arrayList) {
            this.f5686a = arrayList;
        }

        public String doInBackground(String... strArr) {
            try {
                f5660d = new ArrayList<>();
                int i = 0;
                while (i < this.f5686a.size()) {
                    try {
                        for (int i2 = 0; i2 < f5669j.size(); i2++) {
                            int i3 = 0;
                            while (i3 < f5669j.get(i2).getPhotos().size()) {
                                try {
                                    try {
                                        if (f5669j.get(i2).getPhotos().get(i3).getId() == this.f5686a.get(i).getId()) {
                                            try {
                                                f5669j.get(i2).getPhotos().remove(this.f5686a.get(i));
                                                if (f5669j.get(i2).getPhotos().size() == 1) {
                                                    try {
                                                        f5669j.remove(i2);
                                                    } catch (Exception e) {
//                                                        // e.printStackTrace();
                                                    }
                                                }
                                            } catch (Exception e2) {
//                                                e2.printStackTrace();
                                            }
                                        }
                                    } catch (Exception e3) {
//                                        e3.printStackTrace();
                                    }
                                    i3++;
                                } catch (Exception e4) {
//                                    e4.printStackTrace();
                                }
                            }
                        }
                        i++;
                    } catch (Exception e5) {
//                        e5.printStackTrace();
                    }
                }
                f5662b = new ArrayList<>();

                for (int i4 = 0; i4 < f5669j.size(); i4++) {
                    try {
                        Log.w("msg", "group  ----" + "Group: " + (i4 + 1));
                        f5662b.add(new SimpleSectionedGridAdapter.Section(f5660d.size(), "Group: " + (i4 + 1) + " (" + f5669j.get(i4).getPhotos().size() + " duplicates photos)"));
//                        txt_noofphotos.setText("Group: " + (i4 + 1));
                        f5660d.addAll(f5669j.get(i4).getPhotos());
                    } catch (Exception e6) {
//                        e6.printStackTrace();
                    }
                }
                return null;
            } catch (Exception e7) {
//                e7.printStackTrace();
                return null;
            }
        }


        @SuppressLint("WrongConstant")
        public void onPostExecute(String str) {
            if (f5661a != null && !isFinishing()) {
                f5661a.dismiss();
            }
            try {
                if (f5660d.size() == 0) {
                    try {
//                        By Parth
//                        dupview_loading_view.setVisibility(View.VISIBLE);
//                        duplicate_image_lay.setVisibility(View.GONE);

//                        GroupActivity.this.onBackPressed();
                        return;
                    } catch (Exception e) {
                        e = e;
                    }
                } else {
                    try {
                        f5665f = new ImageAdepters(GroupActivityBlack.this, f5660d);
                        f5663c = new SimpleSectionedGridAdapter(GroupActivityBlack.this, f5665f, R.layout.dp_grid_item_header1, R.id.header_layout, R.id.header);
                        f5663c.setGridView(f5664e);
                        f5663c.setSections((SimpleSectionedGridAdapter.Section[]) f5662b.toArray(new SimpleSectionedGridAdapter.Section[0]));
                        f5664e.setAdapter(f5663c);
//                        GroupActivity.this.f5664e.setAdapter((ListAdapter) GroupActivity.this.f5663c);
                        return;
                    } catch (Exception e2) {
                    }
                }
            } catch (Exception e3) {
//                e3.printStackTrace();
            }
        }

        public void onPreExecute() {
            try {
                f5661a = new ProgressDialog(GroupActivityBlack.this);
                f5661a.setMessage("Wait... ");
                f5662b.clear();
                f5661a.setCancelable(false);
                try {            // Change by Priyanka - v1.0.30
                    if(!isFinishing()){
                        f5661a.show();
                    }
                } catch (WindowManager.BadTokenException e) {
                    //use a log message
                }
            } catch (Exception e) {
//                // e.printStackTrace();
            }
        }
    }

    @SuppressLint({"StaticFieldLeak"})
    private class deleteData extends AsyncTask<String, String, String> {
        ArrayList<String> f5688a = new ArrayList<>();

        Uri f5689b = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;

        ArrayList<Photo> f5690c;

        ArrayList<Photo> f5691d = new ArrayList<>();

        deleteData(ArrayList<Photo> arrayList) {
            this.f5690c = arrayList;
        }

        ArrayList<Uri> f5691e = new ArrayList<>();

        public String doInBackground(String... strArr) {
            int i = 0;
            while (i < this.f5690c.size()) {
                try {
                    Uri parse = Uri.parse(this.f5689b + "/" + this.f5690c.get(i).getId());
                    File file = new File(parse.getPath());
                    if (file.exists()) {
                        file.delete();
//                        deleteFile(parse.getPath());
                    }
                    this.f5691d.add(this.f5690c.get(i));
                    this.f5691e.add(parse);

                    // By Parth
                    try {
                        getApplicationContext().getContentResolver().delete(parse, (String) null, (String[]) null);
                    } catch (Exception e) {

                    }

                    /*try {
                        Log.d("DELETE_OP009","DELETE OPERATION TRY");
                        getApplicationContext().getContentResolver().delete(parse, null, null);

                    } catch (SecurityException e) {
                        Log.d("DELETE_OP009","DELETE OPERATION CATCH");
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R ){
                            Log.d("DELETE_OP009","DELETE OPERATION CATCH R");
                            IntentSender intentSender =  MediaStore.createDeleteRequest(getApplicationContext().getContentResolver(), listOf(parse)).getIntentSender();
                            new  IntentSenderRequest.Builder(intentSender).build();
                        }else if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            Log.d("DELETE_OP009","DELETE OPERATION CATCH Q");
                            RecoverableSecurityException recoverableSecurityException = (RecoverableSecurityException) e;
                            IntentSender intentSender =  recoverableSecurityException.getUserAction().getActionIntent().getIntentSender();
                            new  IntentSenderRequest.Builder(intentSender).build();
                        }
                    }*/
                    i++;
                } catch (Exception e) {
                    // e.printStackTrace();
                }
            }
            // By Parth
            try {
                requestDeletePermission(this.f5691e);
            } catch (Exception e) {
                Log.d("DELETE_PER","--------------------" + e.getMessage());
            }
            return null;
        }

        public void onPostExecute(String str) {
            if (f5661a != null && !isFinishing()) {
                f5661a.dismiss();
            }
            new ReplaceData(this.f5691d).execute(new String[0]);
        }

        public void onPreExecute() {
            f5661a = new ProgressDialog(GroupActivityBlack.this);
            f5661a.setMessage("Wait... Deleting Duplicate photos....");
            try {
                if(!isFinishing()){  // Change by Priyanka - v1.0.30
                    f5661a.show();
                }
            } catch (WindowManager.BadTokenException e) {
                //use a log message
            }
            this.f5688a.clear();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 7740) {
            if(resultCode == Activity.RESULT_OK) {
                Toast.makeText(getApplicationContext(), "All the duplicate Photos has been deleted!", 0).show();
                dupview_loading_view.setVisibility(View.VISIBLE);
                duplicate_image_lay.setVisibility(View.GONE);
                Log.d("QWERT","------------------ OK");
            } else {
                f5666g.setChecked(false);
                duplicate_image_lay.setVisibility(View.GONE);
                new loadData().execute(new List[0]);
                Log.d("QWERT","------------------ NO");

            }
        }
    }

    private void requestDeletePermission(List<Uri> uriList) throws Exception{
        new Config(GroupActivityBlack.this).saveData(GroupActivityBlack.this, PreferenceKeys.SystemDialogOpened, true);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            PendingIntent pi = MediaStore.createDeleteRequest(this.getContentResolver(), uriList);
            try {
                startIntentSenderForResult(pi.getIntentSender(), 7740, null, 0, 0, PendingIntent.FLAG_MUTABLE);
            } catch (IntentSender.SendIntentException e) { }
        }
    }

    @SuppressLint({"StaticFieldLeak"})
    class loadData extends AsyncTask<List<Photo>, Integer, List<Group>> {

        private loadData() {
        }


//        @Override
//        protected void onProgressUpdate(Integer... values) {
//            super.onProgressUpdate(values);
//
//        }

        public List<Group> doInBackground(List<Photo>... listArr) {

            try {
                f5660d = new ArrayList<>();
                new ArrayList();
                try {
                    List<Group> find = SimilarPhoto.find(GroupActivityBlack.this, PhotoRepository.getPhoto(GroupActivityBlack.this));
                    f5669j = new ArrayList();
                    Log.w("msg", "group find ----" + find.size());
                    for (int i = 0; i < find.size(); i++) {
                        try {
                            if (find.get(i).getPhotos().size() > 1) {
                                try {
                                    find.get(i).getPhotos().get(0).setFristPosition(true);
                                    f5669j.add(find.get(i));
                                } catch (Exception e) {
//                                    // e.printStackTrace();
                                }
                            }
                        } catch (Exception e2) {
//                            e2.printStackTrace();
                        }
                    }
                    f5662b = new ArrayList<>();
//                    for (int i3 = 0; i3 < deleteData; i3++) {
//                        publishProgress(i3);
//                    }
                    for (int i2 = 0; i2 < f5669j.size(); i2++) {
                        try {
                            Log.w("msg", "group  ----" + "Group: " + (i2 + 1));
                            f5662b.add(new SimpleSectionedGridAdapter.Section(f5660d.size(), "Group: " + (i2 + 1) + " (" + f5669j.get(i2).getPhotos().size() + " duplicates photos)"));
                            f5660d.addAll(f5669j.get(i2).getPhotos());
                        } catch (Exception e3) {
//                            e3.printStackTrace();
                        }
                    }
                    return null;
                } catch (Exception e4) {
//                    e4.printStackTrace();
                    return null;
                }
            } catch (Exception e5) {
//                e5.printStackTrace();
                return null;
            }
        }


        @SuppressLint("WrongConstant")
        public void onPostExecute(List<Group> list) {
            Log.w("msg", "group  onPostExecute----");
//            if (GroupActivity.this.f5661a != null && !GroupActivity.this.isFinishing()) {
//                GroupActivity.this.f5661a.dismiss();
//            }
            rootview_loading_view.setVisibility(View.GONE);
            duplicate_image_lay.setVisibility(View.VISIBLE);

            try {
                if (f5660d.size() == 0) {
                    try {
                        Toast.makeText(getApplicationContext(), "Duplicate Photo not Found!", 0).show();
                        dupview_loading_view.setVisibility(View.VISIBLE);
                        duplicate_image_lay.setVisibility(View.GONE);

//                        GroupActivity.this.onBackPressed();
                        return;
                    } catch (Exception e) {
                    }
                } else {
                    try {
                        f5665f = new ImageAdepters(GroupActivityBlack.this, f5660d);
                        f5663c = new SimpleSectionedGridAdapter(GroupActivityBlack.this, f5665f, R.layout.dp_grid_item_header1, R.id.header_layout, R.id.header);
                        f5663c.setGridView(f5664e);
                        f5663c.setSections((SimpleSectionedGridAdapter.Section[]) f5662b.toArray(new SimpleSectionedGridAdapter.Section[0]));
                        f5664e.setAdapter(f5663c);
                        return;
                    } catch (Exception e2) {
                    }
                }
            } catch (Exception e3) {
//                e3.printStackTrace();
            }
        }


        public void onPreExecute() {
            Log.w("msg", "group  onPreExecute----");

//            GroupActivity.this.f5661a = new ProgressDialog(GroupActivity.this);
//            GroupActivity.this.f5661a.setMessage("Wait... Finding Duplicate Photos");
//            GroupActivity.this.f5662b.clear();
//            GroupActivity.this.f5661a.setCancelable(true);
            ValueAnimator animator = new ValueAnimator();
            Log.w("msg", " progreess getImage val -- " + getImage);
            if (!getImage.equals("")) {
                animator.setObjectValues(0, Integer.valueOf(getImage));
            } else {
                animator.setObjectValues(0, 100);
            }
            animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                public void onAnimationUpdate(ValueAnimator animation) {
                    txt_noofphotos.setText(String.valueOf(animation.getAnimatedValue()));
                }
            });
            animator.setDuration(10000); // here you set the duration of the anim
            animator.start();
            rootview_loading_view.setVisibility(View.VISIBLE);
            duplicate_image_lay.setVisibility(View.GONE);
//            GroupActivity.this.f5661a.show();
        }
    }

    @SuppressLint("WrongConstant")
    public void onClick(View view) {
        try {
//            if (view.getId() == R.id.tv_auto_select) {
//                try {
//                    this.f5665f.mo29396b();
//                    this.f5665f.notifyDataSetChanged();
//                } catch (Exception e) {
//                }
//            } else if (view.getId() == R.id.tv_clear_lay) {
//                try {
//                    this.f5665f.mo29395a();
//
//                } catch (Exception e2) {
//                }
//            } else
            if (view.getId() == R.id.imagebtn_delete_layout) {

                try {
                    if (this.f5665f.mo29397c() == null || this.f5665f.mo29397c().size() <= 0) {
                        Toast.makeText(this, "Select Atleast Single Image", 0).show();
                        return;
                    }
                    try {
                        AlertDialog.Builder builder = new AlertDialog.Builder(this);
                        builder.setTitle((CharSequence) "Delete");
                        builder.setMessage((CharSequence) "Do you really want to Delete Duplicate Photo?");
                        builder.setPositiveButton((CharSequence) "Delete", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialogInterface, int i) {
                                try {
                                    new deleteData(f5665f.mo29397c()).execute(new String[0]);
                                    f5665f.notifyDataSetChanged();
                                } catch (Exception e) {
//                                    // e.printStackTrace();
                                }
                                if (dialogInterface != null && !isFinishing()) {
                                    dialogInterface.dismiss();
                                }
                            }
                        });
                        builder.setNegativeButton((CharSequence) "cancel", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialogInterface, int i) {
                                if (dialogInterface != null) {
                                    try {
                                        if (!isFinishing()) {
                                            dialogInterface.dismiss();
                                        }
                                    } catch (Exception e) {
//                                        // e.printStackTrace();
                                    }
                                }
                            }
                        });
                        try {
                            if(!isFinishing()) {
                                builder.show();
                            }
                        } catch (WindowManager.BadTokenException e) {

                        }
                    } catch (Exception e3) {
//                        e3.printStackTrace();
                    }
                } catch (Exception e4) {
//                    e4.printStackTrace();
                }
            }
        } catch (Exception e5) {
//            e5.printStackTrace();
        }
    }


    public void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.dp_activity_group_black);
        this.f5664e = (GridView) findViewById(R.id.grid);
        this.f5664e.setNumColumns(4);
        this.f5661a = new ProgressDialog(this);
        this.f5661a.setMessage("Wait... Finding Duplicate Photos");
        this.f5662b.clear();
        rootview_loading_view = (LinearLayout) findViewById(R.id.rootview_loading_view);
        dupview_loading_view = (LinearLayout) findViewById(R.id.dupview_loading_view);
        duplicate_image_lay = (RelativeLayout) findViewById(R.id.duplicate_image_lay);
        dp_background = (RelativeLayout) findViewById(R.id.dp_background);
        tv_title = (TextView) findViewById(R.id.tv_title);
        rootview_text = (TextView) findViewById(R.id.rootview_text);
        root_depend_num = (TextView) findViewById(R.id.root_depend_num);
        dup_text = (TextView) findViewById(R.id.dup_text);
        dup_scan = (TextView) findViewById(R.id.dup_scan);
        txt_noofphotos_dup = (TextView) findViewById(R.id.txt_noofphotos_dup);
        dup_find_no = (TextView) findViewById(R.id.dup_find_no);
        root_scan = (TextView) findViewById(R.id.root_scan);
        back_rel_layout2 = (RelativeLayout) findViewById(R.id.back_rel_layout2);
        back_rel_layout = (RelativeLayout) findViewById(R.id.back_rel_layout);
        toolbar = (RelativeLayout) findViewById(R.id.toolbar);
        sharedPref = getSharedPreferences("Prefs", Context.MODE_PRIVATE);
        editor = sharedPref.edit();
        this.txt_noofphotos = (TextView) findViewById(R.id.txt_noofphotos);
        getImage = getIntent().getStringExtra("image_count");

        this.f5661a.setCancelable(false);
        new loadData().execute(new List[0]);

        back_rel_layout3 = (RelativeLayout) findViewById(R.id.back_rel_layout3);

        this.f5668i = (RelativeLayout) findViewById(R.id.imagebtn_delete_layout);
        this.f5668i.setOnClickListener(this);
        chk = (CheckBox) findViewById(R.id.tv_auto_select);
        chk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkClick(v);

            }
        });
        this.f5666g1 = (RelativeLayout) findViewById(R.id.tv_auto_select_lay);
        this.f5666g1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    if (chk.isChecked()) {
                        f5665f.mo29396b();
                        f5665f.notifyDataSetChanged();

                        Log.w("msg", " duplicate check   ");
                    } else {
                        Log.w("msg", " duplicate check noew  ");
                        f5665f.mo29395a();

                    }
                } catch (Exception e) {

                }

            }
        });

        back_rel_layout3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        back_rel_layout2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        back_rel_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_duplicate, menu);
//        if (this.f5665f.mo29397c() == null || this.f5665f.mo29397c().size() <= 0) {
        menu.findItem(R.id.delete_action).setVisible(true);
//        } else {
        menu.findItem(R.id.delete_action).setVisible(false);
//        }
        return true;
    }

    private void checkClick(View v) {
        boolean checked = ((CheckBox) v).isChecked();
        try {
            if (checked) {
                f5665f.mo29396b();
                f5665f.notifyDataSetChanged();
                Log.w("msg", " duplicate check   ");
            } else {
                Log.w("msg", " duplicate check noew  ");
                f5665f.mo29395a();

            }
        } catch (Exception e) {

        }
    }

    @SuppressLint("WrongConstant")
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        try {
            if (menuItem.getItemId() == R.id.clear_all) {
                try {
                    this.f5665f.mo29395a();
                } catch (Exception e) {
                }
                return super.onOptionsItemSelected(menuItem);
            } else if (menuItem.getItemId() == R.id.auto_select) {
                try {
                    this.f5665f.mo29396b();
                    this.f5665f.notifyDataSetChanged();
                } catch (Exception e2) {
                }
                return super.onOptionsItemSelected(menuItem);
            } else {
                if (menuItem.getItemId() == R.id.delete_action) {
                    try {
                        if (this.f5665f.mo29397c() == null || this.f5665f.mo29397c().size() <= 0) {
                            Toast.makeText(this, "Select atleast single image", 0).show();
                        } else {
                            try {
                                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                                builder.setTitle((CharSequence) "Delete");
                                builder.setMessage((CharSequence) "Do you really want to Delete Duplicate Photos?");
                                builder.setPositiveButton((CharSequence) "Delete", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        new deleteData(f5665f.mo29397c()).execute(new String[0]);
                                        f5665f.notifyDataSetChanged();
                                        if (dialogInterface != null && !isFinishing()) {
                                            dialogInterface.dismiss();
                                        }
                                    }
                                });
                                builder.setNegativeButton((CharSequence) "cancel", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        if (dialogInterface != null && !isFinishing()) {
                                            dialogInterface.dismiss();
                                        }
                                    }
                                });
                                builder.setCancelable(false);
                                try {
                                    if(!isFinishing()) {
                                        builder.show();
                                    }
                                } catch (WindowManager.BadTokenException e) {
                                }
                            } catch (Exception e3) {
//                                e3.printStackTrace();
                            }
                        }
                    } catch (Exception e4) {
//                        e4.printStackTrace();
                        return super.onOptionsItemSelected(menuItem);
                    }
                }
                return super.onOptionsItemSelected(menuItem);
            }
        } catch (Exception e5) {
//            e5.printStackTrace();
        }
        return false;
    }
    @Override
    protected void onDestroy() {
        if(!isFinishing() && f5661a!=null && f5661a.isShowing()){   // Change by Priyanka - v1.0.30
            f5661a.dismiss();
            f5661a=null;
        }
        super.onDestroy();
    }

    public boolean onPrepareOptionsMenu(Menu menu) {
        return true;
    }
}
