package albums.gallery.photo.folder.picasa.app.web.gallery.fragments

import album.gallery.photo.folder.picasa.app.web.gallery.commons.activities.BaseSimpleActivity
import album.gallery.photo.folder.picasa.app.web.gallery.commons.dialogs.ConfirmationDialog
import album.gallery.photo.folder.picasa.app.web.gallery.commons.dialogs.CreateNewFolderDialog
import album.gallery.photo.folder.picasa.app.web.gallery.commons.dialogs.FilePickerDialog
import album.gallery.photo.folder.picasa.app.web.gallery.commons.extensions.*
import album.gallery.photo.folder.picasa.app.web.gallery.commons.helpers.*
import album.gallery.photo.folder.picasa.app.web.gallery.commons.models.FileDirItem
import album.gallery.photo.folder.picasa.app.web.gallery.commons.views.MyGridLayoutManager
import album.gallery.photo.folder.picasa.app.web.gallery.commons.views.MyRecyclerView
import albums.gallery.photo.folder.picasa.app.web.gallery.*
import albums.gallery.photo.folder.picasa.app.web.gallery.activities.*
import albums.gallery.photo.folder.picasa.app.web.gallery.adapters.*
import albums.gallery.photo.folder.picasa.app.web.gallery.databases.GalleryDatabase
import albums.gallery.photo.folder.picasa.app.web.gallery.dialogs.ChangeSortingDialog
import albums.gallery.photo.folder.picasa.app.web.gallery.dialogs.ChangeViewTypeDialog
import albums.gallery.photo.folder.picasa.app.web.gallery.dialogs.FilterMediaDialog
import albums.gallery.photo.folder.picasa.app.web.gallery.extensions.*
import albums.gallery.photo.folder.picasa.app.web.gallery.helpers.*
import albums.gallery.photo.folder.picasa.app.web.gallery.interfaces.DirectoryOperationsListener
import albums.gallery.photo.folder.picasa.app.web.gallery.jobs.NewPhotoFetcher
import albums.gallery.photo.folder.picasa.app.web.gallery.models.AlbumCover
import albums.gallery.photo.folder.picasa.app.web.gallery.models.Directory
import albums.gallery.photo.folder.picasa.app.web.gallery.models.GalleryImageModel
import albums.gallery.photo.folder.picasa.app.web.gallery.models.Medium
import albums.gallery.photo.folder.picasa.app.web.gallery.preference.PreferenceKeys
import albums.gallery.photo.folder.picasa.app.web.gallery.startLikePro.Activity.SubScription_RemoveAdsActivity
import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.ProgressDialog
import android.app.SearchManager
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Color
import android.media.ExifInterface
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.util.Log
import android.view.*
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.view.menu.MenuBuilder
import androidx.appcompat.widget.SearchView
import androidx.core.content.ContextCompat
import androidx.core.view.MenuItemCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.admob.adLoader.BannerAds
import com.example.admob.adLoader.InterstitialAdLoader
import com.google.vr.cardboard.ThreadUtils.runOnUiThread
import kotlinx.android.synthetic.main.fragment_album.*
import kotlinx.android.synthetic.main.fragment_album.view.*
import java.io.*
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.*


typealias ViewGroup1 = ViewGroup

/*Changes By Arti V1.0.32 Change Context Call onAttach Method use use that context*/
class AlbumFragment : Fragment(), DirectoryOperationsListener, PopupMenu.OnMenuItemClickListener {
    private val PICK_MEDIA = 2
    private val PICK_WALLPAPER = 3
    private val LAST_MEDIA_CHECK_PERIOD = 3000L
    private var mLastClickTime: Long = 0
    private var fromThePauseState = false
    private var permissionDeny = false


    var isPlaceholderVisible: Boolean? = false;
    private var mIsPickImageIntent = false
    private var mIsPickVideoIntent = false
    private var mIsGetImageContentIntent = false
    private var mIsGetVideoContentIntent = false
    private var mIsGetAnyContentIntent = false
    private var mIsSetWallpaperIntent = false
    private var mAllowPickingMultiple = false
    private var mIsThirdPartyIntent = false
    private var mIsGettingDirs = false
    private var mLoadedInitialPhotos = false
    private var mIsPasswordProtectionPending = false
    private var mWasProtectionHandled = false
    private var mShouldStopFetching = false
    private var mIsSearchOpen = false
    private var mWasDefaultFolderChecked = false
    private var mLatestMediaId = 0L
    private var mLatestMediaDateId = 0L
    private var mCurrentPathPrefix = ""                 // used at "Group direct subfolders" for navigation
    private var mOpenedSubfolders = arrayListOf("")     // used at "Group direct subfolders" for navigating Up with the back button
    private var mDateFormat = ""
    private var mTimeFormat = ""
    private var mLastMediaHandler = Handler()
    private var mTempShowHiddenHandler = Handler()
    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mSearchMenuItem: MenuItem? = null
    private var mLastMediaFetcher: MediaFetcher? = null
    private var mDirs = ArrayList<Directory>()
    private var mStoredAnimateGifs = true
    private var mStoredCropThumbnails = true
    private var mStoredScrollHorizontally = true
    private var mStoredTextColor = 0
    private var mStoredAdjustedPrimaryColor = 0
    private var mStoredStyleString = ""
    var progressDialog: ProgressDialog? = null
    private val TAG = "msg"
    lateinit var mView: View
    var mContext: Context? = null

    companion object {
        fun newInstance() = AlbumFragment()
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mContext = context;
    }

    override fun onDetach() {
        super.onDetach()
        mContext = null
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view: View = inflater.inflate(R.layout.fragment_album, container, false)
        setHasOptionsMenu(true)
        mView = view
        Log.w(TAG, " Album Fragment onCreateView: ${mView != null} ${mContext != null}  ${FirebaseConfigHelper.getIsAppAdFree(mContext)}" )
        if (mView != null && mContext != null) {
            if (!FirebaseConfigHelper.getIsAppAdFree(mContext)) {
                Log.w(TAG, " Album Fragment onCreateView: " )
                if (FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.isHomeScreenAlbumItemClickAdEnable)) {
                    loadInterstitalForAlbumAd()
                }
                if (FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.is_home_screen_banner_enabled)) {
                    forBannerAds()
                }
            }
        }
        return view
    }


    private fun progressDialogDismiss() {
        if (progressDialog != null && progressDialog!!.isShowing) {
            progressDialog!!.dismiss()
        }
    }

    private fun loadInterstitalForAlbumAd() {
        val admob_int = FirebaseConfigHelper.getAdmob_intAlbumClick(activity)
        val admob_back_int = FirebaseConfigHelper.getAdmobBack_int(activity)
        val admob_rewarded = FirebaseConfigHelper.getAdmobRewared(activity)
        val admob_back_rewarded = FirebaseConfigHelper.getAdmobBackRewared(activity)
        val admob_rewarded_int = FirebaseConfigHelper.getAdmobRewaredInt(activity)
        val admob_back_rewarded_int = FirebaseConfigHelper.getAdmobBackRewaredInt(activity)
        InterstitialAdLoader.loadAd(
            activity, FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_interstitial_control), admob_int, admob_back_int,
            FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.back_id_required),
            admob_rewarded,
            admob_back_rewarded,
            admob_rewarded_int,
            admob_back_rewarded_int,
            GoogleAnalyticsEvent.albumFragment,
            GoogleAnalyticsEvent.albumFragment,
            GalleryMainApplication.getInstance()?.firebaseAnalytics,{}
        )
    }

    @RequiresApi(Build.VERSION_CODES.N)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        mView = view;
        if (mView != null && mContext != null) {

            activity?.let { Config(it).saveData(activity, PreferenceKeys.SystemDialogOpened, true) };
            mView.album_progessbar_fragment.visibility = View.VISIBLE
            /*if (savedInstanceState == null) {*/

            FirebaseConfigHelper.logMethod("album ", " onViewCreated")


            (mContext as BaseSimpleActivity).handlePermission(PERMISSION_WRITE_STORAGE) {

                if (it) {
                    FirebaseConfigHelper.logMethod("album ", "Pemision Allow ")
                    try {
                        getStories(mView as ViewGroup1)
                    } catch (e: Exception) {
                        // e.printStackTrace()
                    }
                    mView.permission_txt.visibility = View.GONE
                    tryLoadGallery()
//                    if (arguments?.getBoolean(SHOW_INT_AD)!! && Utils.remoteConfig.getBoolean(Utils.is_homescreen_interstitial_enable)) {
//                        loadFirstAd()
//                    }
                } else {
                    FirebaseConfigHelper.logMethod("album ", "Pemision Deny")
                    val toast = Toast.makeText(mContext, "Allow the permission to access.", Toast.LENGTH_SHORT)
                    toast.show()
//                    if (arguments?.getBoolean(SHOW_INT_AD)!! && Utils.remoteConfig.getBoolean(Utils.is_homescreen_interstitial_enable)) {
//                        loadFirstAd()
//                    }

                    permissionDeny = true
                    permission_txt.visibility = View.VISIBLE
                    myButton.visibility = View.GONE
                }
            }

            mContext?.config?.temporarilyShowHidden = false
            mContext?.config?.tempSkipDeleteConfirmation = false
            removeTempFolder()
            checkRecycleBinItems()
            startNewPhotoFetcher()


            mView.create_album.setOnClickListener {
                val activity: FragmentActivity? = activity
                if (activity != null) {
//                    GoogleAnalyticsEvent.passEvent_forFragment(activity, GoogleAnalyticsEvent.main_screen, GoogleAnalyticsEvent.floating_button,)
                    GoogleAnalyticsEvent.logAdapter(GoogleAnalyticsEvent.mainScreen, GoogleAnalyticsEvent.click, GoogleAnalyticsEvent.floating_button)
                }
                if (mContext != null) {
                    createNewFolder()

                }
            }
            mIsPickImageIntent = isPickImageIntent(activity?.intent!!)
            mIsPickVideoIntent = isPickVideoIntent(activity?.intent!!)
            mIsGetImageContentIntent = isGetImageContentIntent(activity?.intent!!)
            mIsGetVideoContentIntent = isGetVideoContentIntent(activity?.intent!!)
            mIsGetAnyContentIntent = isGetAnyContentIntent(activity?.intent!!)
            mIsSetWallpaperIntent = isSetWallpaperIntent(activity?.intent!!)
            mAllowPickingMultiple = activity?.intent!!.getBooleanExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
            mIsThirdPartyIntent = mIsPickImageIntent || mIsPickVideoIntent || mIsGetImageContentIntent || mIsGetVideoContentIntent ||
                mIsGetAnyContentIntent || mIsSetWallpaperIntent

            mView.directories_refresh_layout_fragment.setOnRefreshListener { getDirectories() }
            storeStateVariables()
            // checkWhatsNewDialog()

            mIsPasswordProtectionPending = mContext?.config?.isAppPasswordProtectionOn!!
            setupLatestMediaId()

            if (!mContext?.config?.wereFavoritesPinned!!) {
                mContext?.config?.addPinnedFolders(hashSetOf(FAVORITES))
                mContext?.config?.wereFavoritesPinned = true
            }

            if (!mContext?.config?.wasRecycleBinPinned!!) {
                mContext?.config?.addPinnedFolders(hashSetOf(RECYCLE_BIN))
                mContext?.config?.wasRecycleBinPinned = true
                mContext?.config?.saveFolderGrouping(SHOW_ALL, GROUP_BY_DATE_TAKEN_DAILY or GROUP_DESCENDING)
            }

            if (!mContext?.config?.wasSVGShowingHandled!!) {
                mContext?.config?.wasSVGShowingHandled = true
                if (mContext?.config?.filterMedia!! and TYPE_SVGS == 0) {
                    requireContext().config.filterMedia += TYPE_SVGS
                }
            }

            if (!mContext?.config?.wasSortingByNumericValueAdded!!) {
                mContext?.config?.wasSortingByNumericValueAdded = true
                mContext?.config?.sorting = mContext?.config?.sorting!! or SORT_USE_NUMERIC_VALUE
            }

            mContext?.updateWidgets()
            (activity as SimpleActivity).registerFileUpdateListener()

            mView.directories_switch_searching_fragment.setOnClickListener {
                launchSearchActivity()
            }

//        // just request the permission, tryLoadGallery will then trigger in onResume
//        (activity as BaseSimpleActivity).handlePermission(PERMISSION_WRITE_STORAGE) {
//            if (!it) {
//                // mContext?.toast(R.string.no_storage_permissions)
//                directories_empty_placeholder_fragment.visibility = View.GONE
//                permission_txt.visibility = View.VISIBLE
//                line1.visibility = View.VISIBLE
//                line2.visibility = View.VISIBLE
//                Log.w("msg","Finish allow-------------------------------------------------------------------------------------------------------------------------------------------------------")
//                // activity?.finish()
//            } else {
//                Log.w("msg","Finish dny-------------------------------------------------------------------------------------------------------------------------------------------------------")
//
////                permission_txt.visibility = View.GONE
//            }
//        }

        }

    }

    override fun onStart() {
        super.onStart()
        if (mView != null) {
            mView.visibility = View.VISIBLE
            mTempShowHiddenHandler.removeCallbacksAndMessages(null)
        }
    }

    fun Context.toast(id: Int, length: Int = Toast.LENGTH_SHORT) {
        toast(getString(id), length)
    }

    @RequiresApi(Build.VERSION_CODES.N)
    override fun onResume() {
        super.onResume()
        if (mView != null && mContext != null && mContext?.config != null) {
            // By Parth for checking the permission is given while app is in the PAUSE State
            val requiredPermission = Manifest.permission.WRITE_EXTERNAL_STORAGE
            val checkVal = context?.checkCallingOrSelfPermission(requiredPermission)
            if (checkVal == PackageManager.PERMISSION_GRANTED) {
                permission_txt.visibility = View.GONE
                if (fromThePauseState == true && permissionDeny == true) {
                    fromThePauseState = false
                    permissionDeny = false
                    getStories(mView as ViewGroup1)
                }
            } else {
                permission_txt.visibility = View.VISIBLE
            }

            if (getDefaultFileFilter() == 0) {
                mView.directories_empty_placeholder_fragment_filter.beVisible()
                mView.directories_empty_placeholder_2_fragment_filter.beVisible()
            } else {
                mView.directories_empty_placeholder_fragment_filter.beGone()
                mView.directories_empty_placeholder_2_fragment_filter.beGone()
            }

//        if (mContext?.hasPermission(PERMISSION_WRITE_STORAGE)!!) {
//            Utils.logMethod("album ", " onResume permission")
//
//            permission_txt.visibility = View.GONE
//            myButton.visibility = View.VISIBLE
//
//        }
            getDirectories()
            mContext?.config?.isThirdPartyIntent = false
            mDateFormat = mContext?.config?.dateFormat.toString()
            mTimeFormat = mContext?.getTimeFormat().toString()

            if (mStoredAnimateGifs != mContext?.config?.animateGifs) {
                getRecyclerAdapter()?.updateAnimateGifs(mContext?.config?.animateGifs!!)
            }

            if (mStoredCropThumbnails != mContext?.config?.cropThumbnails) {
                getRecyclerAdapter()?.updateCropThumbnails(mContext?.config?.cropThumbnails!!)
            }

            if (mStoredScrollHorizontally != mContext?.config?.scrollHorizontally) {
                mLoadedInitialPhotos = false
                mView.directories_grid_fragment.adapter = null
                getDirectories()
            }

            if (mStoredTextColor != mContext?.config?.textColor) {
                getRecyclerAdapter()?.updateTextColor(mContext?.config?.textColor!!)
            }

            val adjustedPrimaryColor = mContext?.getAdjustedPrimaryColor()
            if (mStoredAdjustedPrimaryColor != adjustedPrimaryColor) {
                getRecyclerAdapter()?.updatePrimaryColor(mContext?.config?.primaryColor!!)
                mView.directories_vertical_fastscroller_fragment.updatePrimaryColor(adjustedPrimaryColor!!)
                mView.directories_horizontal_fastscroller_fragment.updatePrimaryColor(adjustedPrimaryColor!!)
            }

            val styleString = "${mContext?.config?.folderStyle}${mContext?.config?.showFolderMediaCount}${mContext?.config?.limitFolderTitle}"
            if (mStoredStyleString != styleString) {
                setupAdapter(mDirs, forceRecreate = true)
            }

            mView.directories_horizontal_fastscroller_fragment.updateBubbleColors()
            mView.directories_vertical_fastscroller_fragment.updateBubbleColors()
            mView.directories_refresh_layout_fragment.isEnabled = mContext?.config?.enablePullToRefresh!!

            mView.directories_empty_placeholder_fragment.setTextColor(mContext?.config?.textColor!!)
            mView.directories_empty_placeholder_2_fragment.setTextColor(adjustedPrimaryColor)
            mView.directories_switch_searching_fragment.setTextColor(adjustedPrimaryColor)
            mView.directories_switch_searching_fragment.underlineText()


            if (!mIsSearchOpen) {
                // [ WEIRED ]
                (activity as AppCompatActivity).invalidateOptionsMenu()
                if (mIsPasswordProtectionPending && !mWasProtectionHandled) {
                    activity?.handleAppPasswordProtection {
                        mWasProtectionHandled = it
                        if (it) {
                            mIsPasswordProtectionPending = false
                            tryLoadGallery()
                        } else {

                            val startMain = Intent(Intent.ACTION_MAIN)
                            startMain.addCategory(Intent.CATEGORY_HOME)
                            startMain.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            startActivity(startMain)
                            requireActivity().finishAffinity()
                            //System.exit(0)
                        }
                    }
                } else {
                    tryLoadGallery()
                }
            }

//        if (!mIsSearchOpen) {
//            (activity as AppCompatActivity).invalidateOptionsMenu()
//            if (mIsPasswordProtectionPending && !mWasProtectionHandled) {
//                activity?.handleAppPasswordProtection {
//                    mWasProtectionHandled = it
//                    if (it) {
//                        mIsPasswordProtectionPending = false
//                        try {
//                            getStories(mView as ViewGroup)
//                        } catch (e: Exception) {
//                            e.printStackTrace()
//                        }
//                    } else {
//
//                        Log.w(
//                            "msg",
//                            "finish001-------------------------------------------------------------------------------------------------------------------------------------------------------"
//                        )
//                        activity?.finish()
//                    }
//                }
//            } else {
//                if (mContext?.hasPermission(PERMISSION_WRITE_STORAGE)!!) {
//                    Utils.logMethod("album ", "Pemision Allow by user")
//                    try {
//                        getStories(mView as ViewGroup)
//                    } catch (e: Exception) {
//                        e.printStackTrace()
//                    }
//                    tryLoadGallery()
//                    permission_txt.visibility = View.GONE
//                } else {
//                    Utils.logMethod("album ", "Pemision Allow by user else ")
//
//                    (activity as BaseSimpleActivity).handlePermission(PERMISSION_WRITE_STORAGE) {
//                        if (it) {
//                            Utils.logMethod("album ", "Pemision Allow ")
//                            try {
//                                getStories(mView as ViewGroup)
//                            } catch (e: Exception) {
//                                e.printStackTrace()
//                            }
//                            tryLoadGallery()
//                            permission_txt.visibility = View.GONE
//                        } else {
//                            Utils.logMethod("album ", "Pemision Deny")
//                            permission_txt.visibility = View.VISIBLE
//                        }
//                    }
//                }
//            }
//        }
        }

    }

    override fun onPause() {
        super.onPause()
        if (!FirebaseConfigHelper.getIsAppAdFree(activity)) {
            BannerAds.pauseAd();
        }

        fromThePauseState = true

        if (mView != null) {
            if (mSearchMenuItem != null) {
                mSearchMenuItem?.collapseActionView()
            }
            mView.directories_refresh_layout_fragment.isRefreshing = false
            mIsGettingDirs = false
            storeStateVariables()
            mLastMediaHandler.removeCallbacksAndMessages(null)
        }

    }

    override fun onStop() {
        super.onStop()
        if (mView != null && mContext != null && mContext?.config != null) {
            if (mContext?.config?.temporarilyShowHidden!! || mContext?.config?.tempSkipDeleteConfirmation!!) {
                mTempShowHiddenHandler.postDelayed({
                    mContext?.config?.temporarilyShowHidden = false
                    mContext?.config?.tempSkipDeleteConfirmation = false
                }, SHOW_TEMP_HIDDEN_DURATION)
            } else {
                mTempShowHiddenHandler.removeCallbacksAndMessages(null)
            }
        }

    }

    override fun onDestroy() {
        super.onDestroy()
        if (mView != null && mContext != null && mContext?.config != null) {
            if (!activity?.isChangingConfigurations!!) {
                mContext?.config?.temporarilyShowHidden = false
                mContext?.config?.tempSkipDeleteConfirmation = false
                mTempShowHiddenHandler.removeCallbacksAndMessages(null)
                removeTempFolder()
                (activity as SimpleActivity).unregisterFileUpdateListener()

                if (!mContext?.config?.showAll!!) {
                    if (mLastMediaFetcher != null) {
                        mLastMediaFetcher?.shouldStop = true
                    }
                    GalleryDatabase.destroyInstance()
                }
            }

            try {
                progressDialogDismiss()
            } catch (e: Exception) {
            }
        }
        if (!FirebaseConfigHelper.getIsAppAdFree(activity)) {
            BannerAds.destroyAd();
        }

    }

    @SuppressLint("RestrictedApi")
    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        if (mIsThirdPartyIntent) {
            inflater.inflate(R.menu.menu_main_intent, menu)
        } else {
            inflater.inflate(R.menu.menu_main, menu)
            val menuBuilder: MenuBuilder = menu as MenuBuilder
            menuBuilder.setOptionalIconsVisible(true)

            if (mContext != null && mContext?.config != null) {
                menu.apply {
                    findItem(R.id.increase_column_count).isVisible =
                        mContext?.config?.viewTypeFolders == VIEW_TYPE_GRID && mContext?.config?.dirColumnCnt!! < MAX_COLUMN_COUNT
                    findItem(R.id.reduce_column_count).isVisible = mContext?.config?.viewTypeFolders == VIEW_TYPE_GRID && mContext?.config?.dirColumnCnt!! > 2
                    setupSearch(this)
                }
            }
        }
        if (mContext != null && mContext?.config != null) {
            menu.findItem(R.id.temporarily_show_hidden).isVisible = !mContext?.config?.shouldShowHidden!!
            menu.findItem(R.id.stop_showing_hidden).isVisible = mContext?.config?.temporarilyShowHidden!!
            (mContext as MainActivity).closeDrawer()
        }
        updateMenuItemColors(menu)
    }

    fun updateMenuItemColors(menu: Menu?, useCrossAsBack: Boolean = false, baseColor: Int = mContext?.baseConfig?.primaryColor!!) {
        if (menu == null) {
            return
        }
        val color = baseColor.getContrastColor()
        for (i in 0 until menu.size()) {
            try {
                if (i > 2) {
                    menu.getItem(i)?.icon?.setTint(Color.parseColor("#007AFF"))
                } else {
                    menu.getItem(i)?.icon?.setTint(color)
                }
            } catch (ignored: Exception) {
            }
        }
    }

    private fun setupSearch(menu: Menu) {
        val activity: Activity? = activity

        if (mView != null) {
            val searchManager = activity?.getSystemService(Context.SEARCH_SERVICE) as SearchManager
            mSearchMenuItem = menu.findItem(R.id.search)
            (mSearchMenuItem?.actionView as SearchView).findViewById<EditText>(R.id.search_src_text).apply {

                if (context?.config?.theme!!) {
                    this.setHintTextColor(resources.getColor(R.color.dark_hint))
                    this.alpha = 0.8F
                } else {
                    this.setHintTextColor(resources.getColor(R.color.light_hint))
                    this.alpha = 0.8F
                }
            }

            if (activity != null) {
                (mSearchMenuItem?.actionView as? SearchView)?.apply {

                    setSearchableInfo(searchManager.getSearchableInfo(activity?.componentName))
                    isSubmitButtonEnabled = false
                    setOnQueryTextListener(object : SearchView.OnQueryTextListener {
                        override fun onQueryTextSubmit(query: String) = false

                        override fun onQueryTextChange(newText: String): Boolean {
                            if (mIsSearchOpen) {
                                setupAdapter(mDirs, newText)
                            }
                            return true
                        }
                    })
                }
            }

            MenuItemCompat.setOnActionExpandListener(mSearchMenuItem, object : MenuItemCompat.OnActionExpandListener {
                override fun onMenuItemActionExpand(item: MenuItem?): Boolean {
//                directories_switch_searching_fragment.beVisible()
                    mIsSearchOpen = true
                    mView.directories_refresh_layout_fragment.isEnabled = false
                    return true
                }


                // this triggers on device rotation too, avoid doing anything
                override fun onMenuItemActionCollapse(item: MenuItem?): Boolean {
                    if (mIsSearchOpen) {
                        mView.directories_switch_searching_fragment.beGone()
                        mIsSearchOpen = false
                        mView.directories_refresh_layout_fragment.isEnabled = mContext?.config?.enablePullToRefresh!!
                        setupAdapter(mDirs, "")
                    }
                    return true
                }
            })
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item.itemId) {
            R.id.sort -> {
                val activity: FragmentActivity? = activity
                if (activity != null) {
//                    GoogleAnalyticsEvent.passEvent_forFragment(activity, GoogleAnalyticsEvent.main_screen, GoogleAnalyticsEvent.album_sort_by)
                    GoogleAnalyticsEvent.logAdapter(GoogleAnalyticsEvent.mainScreen, GoogleAnalyticsEvent.click, GoogleAnalyticsEvent.album_sort_by)

                    (activity as MainActivity).closeDrawer()
                }
                showSortingDialog()
            }
            R.id.filter -> {
                val activity: FragmentActivity? = activity
                if (activity != null) {
//                    GoogleAnalyticsEvent.passEvent_forFragment(activity, GoogleAnalyticsEvent.main_screen, GoogleAnalyticsEvent.album_filter_media)
                    GoogleAnalyticsEvent.logAdapter(GoogleAnalyticsEvent.mainScreen, GoogleAnalyticsEvent.click, GoogleAnalyticsEvent.album_filter_media)
                    (activity as MainActivity).closeDrawer()
                }
                showFilterMediaDialog()
            }
            R.id.open_camera -> {
                if (SystemClock.elapsedRealtime() - mLastClickTime > 700) {
                    val activity: FragmentActivity? = activity
                    if (activity != null) {
                        /* GoogleAnalyticsEvent.passEvent_forFragment(
                             activity,
                             GoogleAnalyticsEvent.mainScreen,
                             GoogleAnalyticsEvent.album_camera
                         )*/
                        GoogleAnalyticsEvent.logAdapter(
                            GoogleAnalyticsEvent.mainScreen, GoogleAnalyticsEvent.click, GoogleAnalyticsEvent.album_camera
                        )
                        (activity as MainActivity).closeDrawer()
                        activity?.launchCamera()
                    }
                }
                mLastClickTime = SystemClock.elapsedRealtime();

            }
            R.id.remove_ads -> {
                if (FirebaseConfigHelper.isNetworkConnected(activity)) {
                    GoogleAnalyticsEvent.logAdapter(GoogleAnalyticsEvent.drawer, GoogleAnalyticsEvent.click, GoogleAnalyticsEvent.remove_ads)
                    val intent = Intent(activity, SubScription_RemoveAdsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    intent.putExtra("isFrom", "Popup menu")
                    startActivity(intent)
                } else {
                    Toast.makeText(activity, "No Internet !, please try again later.", Toast.LENGTH_SHORT).show()
                }
            }
            // R.id.show_all -> showAllMedia()
            R.id.change_view_type -> {
                val activity: FragmentActivity? = activity
                if (activity != null) {
                    GoogleAnalyticsEvent.logAdapter(

                        GoogleAnalyticsEvent.mainScreen,
                        GoogleAnalyticsEvent.click,
                        GoogleAnalyticsEvent.album_change_view_type
                    )/*                   GoogleAnalyticsEvent.passEvent_forFragment(
                        activity,
                        GoogleAnalyticsEvent.mainScreen,
                        GoogleAnalyticsEvent.album_change_view_type
                    )*/
                    (activity as MainActivity).closeDrawer()
                }
                changeViewType()
            }
            R.id.temporarily_show_hidden -> {
                val activity: FragmentActivity? = activity
                if (activity != null) {
                    GoogleAnalyticsEvent.logAdapter(
                        GoogleAnalyticsEvent.mainScreen, GoogleAnalyticsEvent.click,
                        GoogleAnalyticsEvent.album_temporarily_show_hidden
                    )
                    /*                    GoogleAnalyticsEvent.passEvent_forFragment(
                        activity,
                        GoogleAnalyticsEvent.mainScreen,
                        GoogleAnalyticsEvent.album_temporarily_show_hidden
                    )*/
                    (activity as MainActivity).closeDrawer()
                }
                tryToggleTemporarilyShowHidden()
            }
            R.id.stop_showing_hidden -> {
                val activity: FragmentActivity? = activity
                if (activity != null) {
                    GoogleAnalyticsEvent.logAdapter(
                        GoogleAnalyticsEvent.mainScreen, GoogleAnalyticsEvent.click, GoogleAnalyticsEvent.album_stop_show_hidden
                    )/*                    GoogleAnalyticsEvent.passEvent_forFragment(
                        activity,
                        GoogleAnalyticsEvent.mainScreen,
                        GoogleAnalyticsEvent.album_stop_show_hidden
                    )*/
                    (activity as MainActivity).closeDrawer()
                }
                tryToggleTemporarilyShowHidden()
            }
            // R.id.create_new_folder -> createNewFolder()
            // R.id.show_the_recycle_bin -> toggleRecycleBin(true)
            // R.id.hide_the_recycle_bin -> toggleRecycleBin(false)
            R.id.increase_column_count -> {
                val activity: FragmentActivity? = activity
                if (activity != null) {
//                    GoogleAnalyticsEvent.passEvent_forFragment(activity, GoogleAnalyticsEvent.mainScreen, GoogleAnalyticsEvent.album_increase_column_count)
                    GoogleAnalyticsEvent.logAdapter(
                        GoogleAnalyticsEvent.mainScreen,
                        GoogleAnalyticsEvent.click,
                        GoogleAnalyticsEvent.album_increase_column_count
                    )
                    (activity as MainActivity).closeDrawer()
                }
                increaseColumnCount()
            }
            R.id.reduce_column_count -> {
                val activity: FragmentActivity? = activity
                if (activity != null) {
                    GoogleAnalyticsEvent.logAdapter(
                        GoogleAnalyticsEvent.mainScreen, GoogleAnalyticsEvent.click, GoogleAnalyticsEvent.album_reduce_column_count
                    )/*                    GoogleAnalyticsEvent.passEvent_forFragment(
                        activity,
                        GoogleAnalyticsEvent.mainScreen,
                        GoogleAnalyticsEvent.album_reduce_column_count
                    )*/
                    (activity as MainActivity).closeDrawer()
                }
                reduceColumnCount()
            }
            // R.id.set_as_default_folder -> setAsDefaultFolder()
            R.id.settings -> {
                val activity: FragmentActivity? = activity
                if (activity != null) {
                    GoogleAnalyticsEvent.logAdapter(
                        GoogleAnalyticsEvent.mainScreen, GoogleAnalyticsEvent.click, GoogleAnalyticsEvent.album_settings
                    )
                    /*                    GoogleAnalyticsEvent.passEvent_forFragment(
                        activity,
                        GoogleAnalyticsEvent.mainScreen,
                        GoogleAnalyticsEvent.album_settings
                    )*/
                    (activity as MainActivity).closeDrawer()
                }


                if (mContext != null) {
                    mContext?.launchSettings()
                }


            }
            R.id.about -> {
                val activity: FragmentActivity? = activity
                if (activity != null) {
                    GoogleAnalyticsEvent.logAdapter(
                        GoogleAnalyticsEvent.mainScreen, GoogleAnalyticsEvent.click, GoogleAnalyticsEvent.album_about
                    )
/*
                    GoogleAnalyticsEvent.passEvent_forFragment(
                        activity,
                        GoogleAnalyticsEvent.mainScreen,
                        GoogleAnalyticsEvent.album_about
                    )*/
                    (activity as MainActivity).closeDrawer()
                }
                openAbout()
            }
            R.id.search -> {
                val activity: FragmentActivity? = activity
                if (activity != null) {
//                    GoogleAnalyticsEvent.passEvent_forFragment(activity, GoogleAnalyticsEvent.mainScreen, GoogleAnalyticsEvent.album_search)
                    GoogleAnalyticsEvent.logAdapter(GoogleAnalyticsEvent.mainScreen, GoogleAnalyticsEvent.click, GoogleAnalyticsEvent.album_search)
                    (activity as MainActivity).closeDrawer()
                }
            }
            else -> return super.onOptionsItemSelected(item)
        }
        return super.onOptionsItemSelected(item)
        return true
    }

    fun openAbout() {
        if (mContext != null) {
            val intent = Intent(mContext, AboutActivity::class.java)
            startActivity(intent)
        }
    }

    private fun createNewFolder() {
        if (mContext != null && mContext?.config != null) {
            FilePickerDialog(
                mContext as BaseSimpleActivity,
                mContext?.internalStoragePath!!,
                false,
                mContext?.config?.shouldShowHidden!!,
                false,
                true
            ) {
                CreateNewFolderDialog(mContext as BaseSimpleActivity, it) {
                    mContext?.config?.tempFolderPath = it
                    ensureBackgroundThread {
                        if (mContext != null) {
                            gotDirectories(mContext?.addTempFolderIfNeeded(getCurrentlyDisplayedDirs())!!)
                        }
                    }

                }
            }
        }
    }


    private fun tryToggleTemporarilyShowHidden() {
        if (mContext != null && mContext?.config != null) {

            if (mContext?.config?.temporarilyShowHidden!!) {
                toggleTemporarilyShowHidden(false)
            } else {
                try {
                    activity?.handleHiddenFolderPasswordProtection {
                        toggleTemporarilyShowHidden(true)
                    }
                } catch (e: Exception) {
                }
            }
        }
    }

    private fun toggleTemporarilyShowHidden(show: Boolean) {
        if (mContext != null && mView != null && mContext?.config != null) {
            mLoadedInitialPhotos = false
            mContext?.config?.temporarilyShowHidden = show
            mView.directories_grid_fragment.adapter = null
            getDirectories()
            (mContext as AppCompatActivity).invalidateOptionsMenu()
        }
    }

    /*   private fun toggleRecycleBin(show: Boolean) {
           mContext?.config?.showRecycleBinAtFolders = show
           (activity as AppCompatActivity).invalidateOptionsMenu()
           ensureBackgroundThread {
               var dirs = getCurrentlyDisplayedDirs()
               if (!show) {
                   dirs = dirs.filter { it.path != RECYCLE_BIN } as ArrayList<Directory>
               }
               gotDirectories(dirs)
           }
       }*/

    private fun changeViewType() {
        if (mView != null && mContext != null) {
            ChangeViewTypeDialog(mContext as BaseSimpleActivity, true) {
                (mContext as AppCompatActivity).invalidateOptionsMenu()
                setupLayoutManager()
                mView.directories_grid_fragment.adapter = null
                setupAdapter(getRecyclerAdapter()?.dirs ?: mDirs)
            }
        }
    }

    fun showSortingDialog() {
        try {
            if (mContext != null && mView != null && mContext?.config != null) {
                ChangeSortingDialog(mContext as BaseSimpleActivity, true, false) {
                    mView.directories_grid_fragment.adapter = null
                    if (mContext?.config?.directorySorting!! and SORT_BY_DATE_MODIFIED != 0 || mContext?.config?.directorySorting!! and SORT_BY_DATE_TAKEN != 0) {
                        getDirectories()
                    } else {
                        ensureBackgroundThread {
                            gotDirectories(getCurrentlyDisplayedDirs())
                        }
                    }
                }
            }
        } catch (e: Exception) {
        }
    }

    private fun getCurrentlyDisplayedDirs() = getRecyclerAdapter()?.dirs ?: ArrayList()


    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean(WAS_PROTECTION_HANDLED, mWasProtectionHandled)
    }

    override fun onViewStateRestored(savedInstanceState: Bundle?) {
        super.onViewStateRestored(savedInstanceState)
        if (savedInstanceState != null) {
            mWasProtectionHandled = savedInstanceState.getBoolean(WAS_PROTECTION_HANDLED, false)
        }
    }

    @RequiresApi(Build.VERSION_CODES.N)
    private fun getStories(mView: ViewGroup) {
        if (mView != null) {

            Log.w("STORIES", "galleryImageModel getStrories : ")
            FirebaseConfigHelper.logMethod("album", "try to load getStories")

            val recyclerView: RecyclerView = mView.findViewById(R.id.current_image)
            val recyclerView_recen_image: RecyclerView = mView.findViewById(R.id.recen_image)
            val recyclerView_oneyear_image: RecyclerView = mView.findViewById(R.id.oneyear_image)
            val recyclerView_fiveyear_image: RecyclerView = mView.findViewById(R.id.fiveyear_image)
            val recyclerView_randpom_image: RecyclerView = mView.findViewById(R.id.randpom_image)
            Log.w("msg", "version : " + Build.VERSION.SDK_INT)
            if (Build.VERSION.SDK_INT == Build.VERSION_CODES.N_MR1) {
                mView.expand_view.visibility = View.VISIBLE
                mView.myView.visibility = View.VISIBLE
            }
            val activity: Activity? = activity
            if (activity != null) {
//                val statusAdapter =
//                    RecentImageAdapter(activity, activity, getAllRecentImagesPath(recyclerView))
//                if (getAllRecentImagesPath() != null) {
////            Log.w("msg", "getAllRecentImagesPath itemCount" + statusAdapter.itemCount)
//                    recyclerView.adapter = statusAdapter
//                }
                getAllRecentImagesPath(recyclerView)
//                val statusAdapter1 = OneYearImageAdapter(
//                    activity,
//                    activity,
                getLastOneYearImagesPath(1, "ASC", recyclerView_oneyear_image)
//                )
//                val statusAdapter2 = ThreeYearImageAdapter(
//                    activity,
//                    activity,
                getLastThreeYearImagesPath(3, "ASC", recyclerView_fiveyear_image)
//                )
                getRandomImage(recyclerView_randpom_image)
//                val statusAdapter3 =
//                    RandomImageAdapter(activity, activity, getRandomImage())

                recyclerView.setHasFixedSize(true)
                recyclerView_oneyear_image.setHasFixedSize(true)
                recyclerView_fiveyear_image.setHasFixedSize(true)
                recyclerView_randpom_image.setHasFixedSize(true)
                recyclerView_recen_image.setHasFixedSize(true)
                recyclerView.layoutManager =
                    LinearLayoutManager(activity, LinearLayoutManager.HORIZONTAL, true)
                recyclerView_oneyear_image.layoutManager =
                    LinearLayoutManager(activity, LinearLayoutManager.HORIZONTAL, true)
                recyclerView_fiveyear_image.layoutManager =
                    LinearLayoutManager(activity, LinearLayoutManager.HORIZONTAL, true)
                recyclerView_randpom_image.layoutManager =
                    LinearLayoutManager(activity, LinearLayoutManager.HORIZONTAL, true)
                recyclerView_recen_image.layoutManager =
                    LinearLayoutManager(activity, LinearLayoutManager.HORIZONTAL, true)
                recyclerView.itemAnimator = DefaultItemAnimator()
//        Log.w("msg", "getAllRecentImagesPath itemCount :: " + statusAdapter.itemCount)
//        Log.w("msg", "getAllRecentImagesPath itemCount :: " + statusAdapter.itemCount)


//                if (getLastOneYearImagesPath(1, "ASC") != null) {
//                recyclerView_oneyear_image.adapter = statusAdapter1
//                }
//                if (getLastThreeYearImagesPath(3, "ASC") != null) {
//                recyclerView_fiveyear_image.adapter = statusAdapter2
//                }
//                if (getRandomImage(recyclerView_randpom_image) != null) {
//                    recyclerView_randpom_image.adapter = statusAdapter3
//                }
            }
        }
    }

    private fun getRandomImage(recyclerView_randpom_image: RecyclerView) {
//        val mainLooper = Looper.getMainLooper()
        var array_org: ArrayList<GalleryImageModel> = ArrayList<GalleryImageModel>()
//        GlobalScope.launch {
        val uri: Uri
        val cursor: Cursor?
        val listOfAllImages: java.util.ArrayList<GalleryImageModel> =
            java.util.ArrayList<GalleryImageModel>()
        val listOfAllImages_random: java.util.ArrayList<GalleryImageModel> =
            java.util.ArrayList<GalleryImageModel>()

        val column_index_data: Int
        var absolutePathOfImage: String? = null
        uri =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            } else {
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            }
        val projection = arrayOf(
            MediaStore.Images.ImageColumns._ID,
            MediaStore.Images.ImageColumns.DATA,
            MediaStore.Images.ImageColumns.BUCKET_DISPLAY_NAME,
            MediaStore.Images.ImageColumns.DATE_TAKEN,
            MediaStore.Images.ImageColumns.MIME_TYPE
        )
        val sortOrder = "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"


        try {

            cursor = mContext?.contentResolver?.query(uri, projection, null, null, sortOrder)
            column_index_data = cursor!!.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA)
            var pos: Int = 0
            var x = 0
            try {
                while (cursor.moveToNext() && x <= 15) {
                    x++
                    absolutePathOfImage = cursor.getString(column_index_data)

                    val format = SimpleDateFormat("dd-MMM-yyyy")
                    val date = format.format(Date(File(absolutePathOfImage).lastModified()))
                    listOfAllImages.add(
                        GalleryImageModel(
                            absolutePathOfImage,
                            File(absolutePathOfImage).name,
                            date
                        )
                    )
                }
            } catch (e: Exception) {

            } finally {
                // By Parth Crash Solving 1.0.35 21
                cursor.close()
            }
            try {
                for (i in 0..15) {
                    pos++;
                    //Removed  Native ad code  Ad at Stories(1258-1262) by hardik V 1.47
//                        if (pos % 5 == 0 && !Utils.getIsAppAdFree(activity)) {
//                            listOfAllImages_random.add(GalleryImageModel("", "AD", ""))
//                        } else {
                    if (listOfAllImages.size > 0) {
                        listOfAllImages_random.add(
                            GalleryImageModel(
                                listOfAllImages.get(Random().nextInt(listOfAllImages!!.size)).path,
                                listOfAllImages.get(Random().nextInt(listOfAllImages!!.size)).name,
                                listOfAllImages.get(Random().nextInt(listOfAllImages!!.size)).date
                            )
                        )
                    }
//                        }
                }
            } catch (e: Exception) {
            }
//            if (cursor != null) {
//                cursor.close();
//            }
        } catch (e: Exception) {

        }
//            Handler(mainLooper).post {
        val statusAdapter3 =
            RandomImageAdapter(activity, activity, listOfAllImages_random)
        recyclerView_randpom_image.adapter = statusAdapter3
//            }
//        }
    }

    @SuppressLint("Recycle")
    private fun getAllRecentImagesPath(recyclerView: RecyclerView) {
//        val mainLooper = Looper.getMainLooper()
//        GlobalScope.launch {
        var cursor: Cursor?
        val listOfAllImages_fiveyear: java.util.ArrayList<GalleryImageModel> =
            java.util.ArrayList<GalleryImageModel>()
        val listOfAllImages_fiveyear_oo: java.util.ArrayList<GalleryImageModel> =
            java.util.ArrayList<GalleryImageModel>()
        var absolutePathOfImage: String? = null
        val projection = arrayOf(
            MediaStore.Images.ImageColumns._ID,
            MediaStore.Images.ImageColumns.DATA,
            MediaStore.Images.ImageColumns.BUCKET_DISPLAY_NAME,
            MediaStore.Images.ImageColumns.DATE_TAKEN,
            MediaStore.Images.ImageColumns.MIME_TYPE
        )
        val calendar1 = Calendar.getInstance()
        val date2: Date = calendar1.getTime()
        Log.w("msg", "ThreeeeYear dialog date2  " + date2)
        calendar1.add(Calendar.YEAR, -1);
        val date1: Date = calendar1.getTime()
        Log.w("msg", "ThreeeeYear dialog date1  " + date1)


        val Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        }
        cursor = mContext?.contentResolver?.query(
            Uri,
            projection,
            MediaStore.MediaColumns.DATE_ADDED + ">=? and " + MediaStore.MediaColumns.DATE_ADDED + "<=?",
            arrayOf("" + date1.getTime() / 1000, "" + date2.getTime() / 1000),
            MediaStore.Images.ImageColumns.DATE_TAKEN + " DESC"
        )
        Log.w("msg", " cursor == " + cursor)
        val column_index_data = cursor?.getColumnIndexOrThrow(MediaStore.Images.ImageColumns.DATA)!!
        var pos: Int = 0
        Log.d("CURSOR", "absolutePathOfImage" + "-------------------")
        var x = 0
        try {
            while (cursor!!.moveToNext() && x <= 15) {
                x++
                absolutePathOfImage = cursor.getString(column_index_data)
                Log.d("CURSOR", "absolutePathOfImage" + "-------------------")
                val format = SimpleDateFormat("dd-MMM-yyyy")
                val date = format.format(Date(File(absolutePathOfImage).lastModified()))
                listOfAllImages_fiveyear_oo.add(
                    GalleryImageModel(
                        absolutePathOfImage,
                        File(absolutePathOfImage).name,
                        date
                    )
                )
            }
        } catch (e: Exception) {
        } finally {
            // By Parth Crash Solving 1.0.35
            cursor.close()
        }

        for (i in 0..15) {
            // By Parth Crash Solving v1.0.40
            if (i < listOfAllImages_fiveyear_oo.size) {
                pos++;
                if (mContext != null) {
                    //Removed  Native ad code  Ad at Stories(1358-1362) by hardik V 1.47
//                        if (pos % 5 == 0 && !Utils.getIsAppAdFree(mContext)) {
//                            listOfAllImages_fiveyear.add(GalleryImageModel("", "AD", ""))
//                        } else {
                    listOfAllImages_fiveyear.add(
                        GalleryImageModel(
                            listOfAllImages_fiveyear_oo.get(i).path,
                            listOfAllImages_fiveyear_oo.get(i).name,
                            listOfAllImages_fiveyear_oo.get(i).date
                        )
                    )
//                        }
                }
            }
        }
//            Handler(mainLooper).post {
        val statusAdapter =
            RecentImageAdapter(activity, activity, listOfAllImages_fiveyear)
        if (listOfAllImages_fiveyear != null) {
            recyclerView.adapter = statusAdapter
        }
//            }
//        }
    }

    private fun getOneYearImagesPath(
        minusYear: Int,
        order: String
    ): java.util.ArrayList<GalleryImageModel> {
        val arr = ArrayList<SharedStoragePhoto>()
        val array_org: java.util.ArrayList<GalleryImageModel> =
            java.util.ArrayList<GalleryImageModel>()
        val calendar = Calendar.getInstance()

        val date2: Date = calendar.getTime()
        Log.w("msg", "----------" + date2)

        calendar.add(Calendar.YEAR, -minusYear);

        val date1: Date = calendar.getTime()
        Log.w("msg", "----------" + date1)

        try {

            val cursor = mContext?.contentResolver?.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                arrayOf(
                    MediaStore.Images.Media._ID,
                    MediaStore.Images.Media.DATA,
                    MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
                    MediaStore.Images.Media.DATE_TAKEN,
                    MediaStore.Images.Media.MIME_TYPE,
                    MediaStore.Images.Media.DATE_ADDED
                ),
                MediaStore.Images.Media.DATE_TAKEN + ">= ? and " + MediaStore.Images.Media.DATE_TAKEN + "<= ?",
                arrayOf("" + date1.getTime(), "" + date2.getTime()),
                MediaStore.Images.Media.DATE_TAKEN + " " + order,
                null
            )

            try {
                if (cursor == null) Log.d("NO IMAGES", "NO IMAGES")
                var x = 0
                while (cursor!!.moveToNext() && x <= 20) {
                    x++
                    val absolutePathOfImage =
                        cursor?.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))
                    var mili_store =
                        (cursor?.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)))?.toLong()
                    Log.d("MILISTORE", "-------" + mili_store)

                    val exif = ExifInterface(absolutePathOfImage!!)
                    val datetime = exif.getAttribute(ExifInterface.TAG_DATETIME)

                    //arr.add(SharedStoragePhoto(absolutePathOfImage,mili_store))

                    val date_exif = datetime?.split(" ")
                    val date_complete = date_exif?.get(0)?.split(":")
                    val year = date_complete?.get(0)?.toInt()
                    val month = date_complete?.get(1)?.toInt()
                    val day = date_complete?.get(2)?.toInt()
                    val month_word = when (month) {
                        1 -> "Jan"
                        2 -> "Feb"
                        3 -> "Mar"
                        4 -> "Apr"
                        5 -> "May"
                        6 -> "Jun"
                        7 -> "Jul"
                        8 -> "Aug"
                        9 -> "Sep"
                        10 -> "Oct"
                        11 -> "Nov"
                        12 -> "Dec"
                        else -> "-"
                    }
                    val date_format = "" + day + " " + month_word + " " + year
                    val time_complete = date_exif?.get(1)?.split(":")
                    var mili_exif: Long = 0;

                    if (date_exif != null) {
                        Log.d("DATE_EXIF", "-----" + date_exif)

                        val cal: Calendar = Calendar.getInstance()
                        if (day != null && month != null && year != null) {
                            cal.set(year, month, day)
                            mili_exif = cal.timeInMillis;
                        }
                    }
                    if (date_exif != null) {
                        if (date1.time / 1000 < mili_exif / 1000) {
                            arr.add(
                                SharedStoragePhoto(
                                    absolutePathOfImage!!,
                                    mili_exif / 1000,
                                    date_format
                                )
                            )
                        }
                    } else {
                        arr.add(
                            SharedStoragePhoto(
                                absolutePathOfImage!!,
                                mili_store!!,
                                DateFormat.getDateInstance().format(mili_store * 1000)
                            )
                        )
                    }
                }
            } catch (e: Exception) {

            } finally {
                // By Parth Crash Solving 1.0.35 21
                cursor?.close()
            }
        } catch (e: Exception) {
        }
        arr.sortBy { it.ms }
        for (i in 0..12) {
            try {
                //Removed  Native ad code  Ad at Stories(1498-1509) by hardik V 1.47
//                if (i % 5 == 0 && i != 0 && !Utils.getIsAppAdFree(activity)) {
//                    array_org.add(GalleryImageModel("", "AD", ""))
//                    if (array_org != null) {
//                        array_org.add(
//                            GalleryImageModel(
//                                arr[i].path,
//                                File(arr[i].path).name,
//                                arr[i].date
//                            )
//                        )
//                    }
//                } else {
                if (array_org != null) {
                    array_org.add(
                        GalleryImageModel(
                            arr[i].path,
                            File(arr[i].path).name,
                            arr[i].date
                        )
                    )
                }
//                }
            } catch (e: Exception) {
            }

        }
        return array_org
    }

    private fun getThreeYearImagesPath(
        minusYear: Int,
        order: String
    ): java.util.ArrayList<GalleryImageModel> {
        val arr = ArrayList<SharedStoragePhoto>()
        val array_org: java.util.ArrayList<GalleryImageModel> =
            java.util.ArrayList<GalleryImageModel>()
        val calendar = Calendar.getInstance()

        val date2: Date = calendar.getTime()
        Log.w("msg", "----------" + date2)

        calendar.add(Calendar.YEAR, -minusYear);

        val date1: Date = calendar.getTime()
        Log.w("msg", "----------" + date1)

        try {

            val cursor = mContext?.contentResolver?.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                arrayOf(
                    MediaStore.Images.Media._ID,
                    MediaStore.Images.Media.DATA,
                    MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
                    MediaStore.Images.Media.DATE_TAKEN,
                    MediaStore.Images.Media.MIME_TYPE,
                    MediaStore.Images.Media.DATE_ADDED
                ),
                MediaStore.Images.Media.DATE_TAKEN + ">= ? and " + MediaStore.Images.Media.DATE_TAKEN + "<= ?",
                arrayOf("" + date1.getTime(), "" + date2.getTime()),
                MediaStore.Images.Media.DATE_TAKEN + " " + order,
                null
            )

            try {
                if (cursor == null) Log.d("NO IMAGES", "NO IMAGES")
                var x = 0
                while (cursor!!.moveToNext() && x <= 20) {
                    x++
                    val absolutePathOfImage =
                        cursor?.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))
                    var mili_store =
                        (cursor?.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)))?.toLong()
                    Log.d("MILISTORE", "-------" + mili_store)

                    val exif: ExifInterface = ExifInterface(absolutePathOfImage!!)
                    val datetime = exif.getAttribute(ExifInterface.TAG_DATETIME)

                    //arr.add(SharedStoragePhoto(absolutePathOfImage,mili_store))

                    val date_exif = datetime?.split(" ")
                    val date_complete = date_exif?.get(0)?.split(":")
                    val year = date_complete?.get(0)?.toInt()
                    val month = date_complete?.get(1)?.toInt()
                    val day = date_complete?.get(2)?.toInt()
                    val month_word = when (month) {
                        1 -> "Jan"
                        2 -> "Feb"
                        3 -> "Mar"
                        4 -> "Apr"
                        5 -> "May"
                        6 -> "Jun"
                        7 -> "Jul"
                        8 -> "Aug"
                        9 -> "Sep"
                        10 -> "Oct"
                        11 -> "Nov"
                        12 -> "Dec"
                        else -> "-"
                    }
                    val date_format = "" + day + " " + month_word + " " + year
                    val time_complete = date_exif?.get(1)?.split(":")
                    var mili_exif: Long = 0;

                    if (date_exif != null) {
                        Log.d("DATE_EXIF", "-----" + date_exif)

                        val cal: Calendar = Calendar.getInstance()
                        if (day != null && month != null && year != null) {
                            cal.set(year, month, day)
                            mili_exif = cal.timeInMillis;
                        }
                    }
                    if (date_exif != null) {
                        if (date1.time / 1000 < mili_exif / 1000) {
                            arr.add(
                                SharedStoragePhoto(
                                    absolutePathOfImage!!,
                                    mili_exif / 1000,
                                    date_format
                                )
                            )
                        }
                    } else {
                        arr.add(
                            SharedStoragePhoto(
                                absolutePathOfImage!!,
                                mili_store!!,
                                DateFormat.getDateInstance().format(mili_store * 1000)
                            )
                        )
                    }
                }
            } catch (e: Exception) {

            } finally {
                // By Parth Crash Solving 1.0.35 21
                cursor?.close()
            }
        } catch (e: Exception) {
        }
        arr.sortBy { it.ms }
        for (i in 0..12) {
            try {
                //Removed  Native ad code  Ad at Stories(1639-1650) by hardik V 1.47
//                if (i % 5 == 0 && i != 0 && !Utils.getIsAppAdFree(activity)) {
//                    array_org.add(GalleryImageModel("", "AD", ""))
//                    if (array_org != null) {
//                        array_org.add(
//                            GalleryImageModel(
//                                arr[i].path,
//                                File(arr[i].path).name,
//                                arr[i].date
//                            )
//                        )
//                    }
//                } else {
                if (array_org != null) {
                    array_org.add(
                        GalleryImageModel(
                            arr[i].path,
                            File(arr[i].path).name,
                            arr[i].date
                        )
                    )
                }
//                }
            } catch (e: Exception) {
            }

        }
        return array_org
    }

    @RequiresApi(Build.VERSION_CODES.N)
    private fun getLastThreeYearImagesPath(
        minusYear: Int,
        order: String,
        recyclerView_fiveyear_image: RecyclerView
    ) {
//        val mainLooper = Looper.getMainLooper()
//        GlobalScope.launch {
        val statusAdapter2 = ThreeYearImageAdapter(
            activity,
            activity,
            getThreeYearImagesPath(minusYear, order)
        )
//            Handler(mainLooper).post {
        recyclerView_fiveyear_image.adapter = statusAdapter2
//            }
//        }
    }

    @RequiresApi(Build.VERSION_CODES.N)
    private fun getLastOneYearImagesPath(
        minusYear: Int,
        order: String,
        recyclerView_oneyear_image: RecyclerView
    ) {
//        val mainLooper = Looper.getMainLooper()
//        GlobalScope.launch {
        val statusAdapter1 = OneYearImageAdapter(
            activity,
            activity,
            getOneYearImagesPath(minusYear, order)
        )
//            Handler(mainLooper).post {
        recyclerView_oneyear_image.adapter = statusAdapter1
//            }
//        }
    }

    data class SharedStoragePhoto(
        val path: String,
        val ms: Long,
        val date: String
    )


    private fun removeTempFolder() {
        if (mContext != null && mContext?.config != null) {
            if (mContext?.config?.tempFolderPath?.isNotEmpty()!!) {
                val newFolder = File(mContext?.config?.tempFolderPath)
                if (mContext?.getDoesFilePathExist(newFolder.absolutePath)!! && newFolder.isDirectory) {
                    if (newFolder.list()?.isEmpty() == true && newFolder.getProperSize(true) == 0L && newFolder.getFileCount(true) == 0) {
                        mContext?.toast(String.format(getString(R.string.deleting_folder), mContext?.config?.tempFolderPath), Toast.LENGTH_LONG)
                        val activity: FragmentActivity? = activity
                        if (activity != null) {
                            (mContext as BaseSimpleActivity).tryDeleteFileDirItem(newFolder.toFileDirItem(activity), true, true)
                        }
                    }
                }
                mContext?.config?.tempFolderPath = ""
            }
        }
    }

    private fun checkRecycleBinItems() {
        if (mContext != null && mContext?.config != null) {
            if (mContext?.config?.useRecycleBin!! && mContext?.config?.lastBinCheck!! < System.currentTimeMillis() - DAY_SECONDS * 1000) {
                mContext?.config?.lastBinCheck = System.currentTimeMillis()
                Handler().postDelayed({
                    ensureBackgroundThread {
                        try {
                            if (mContext != null) {
                                mContext?.mediaDB?.deleteOldRecycleBinItems(System.currentTimeMillis() - MONTH_MILLISECONDS)
                            }
                        } catch (e: Exception) {
                        }
                    }
                }, 3000L)
            }
        }
    }

    private fun startNewPhotoFetcher() {
        if (isNougatPlus()) {
            val activity: Activity? = activity
            if (activity != null) {
                val photoFetcher = NewPhotoFetcher()
                if (!photoFetcher.isScheduled(activity)) {
                    photoFetcher.scheduleJob(activity)
                }
            }
        }
    }

    /* @RequiresApi(Build.VERSION_CODES.N)
     private fun setupStories() {
         if (activity != null) {
             ensureBackgroundThread {
                 if (activity.hasPermission(PERMISSION_READ_STORAGE)) {
                     getStories(mView as ViewGroup)
                 }
             }
         }
     }*/

    private fun isPickImageIntent(intent: Intent) = isPickIntent(intent) && (hasImageContentData(intent) || isImageType(intent))

    private fun isPickVideoIntent(intent: Intent) = isPickIntent(intent) && (hasVideoContentData(intent) || isVideoType(intent))

    private fun isPickIntent(intent: Intent) = intent.action == Intent.ACTION_PICK

    private fun isGetContentIntent(intent: Intent) = intent.action == Intent.ACTION_GET_CONTENT && intent.type != null

    private fun isGetImageContentIntent(intent: Intent) = isGetContentIntent(intent) &&
        (intent.type!!.startsWith("image/") || intent.type == MediaStore.Images.Media.CONTENT_TYPE)

    private fun isGetVideoContentIntent(intent: Intent) = isGetContentIntent(intent) &&
        (intent.type!!.startsWith("video/") || intent.type == MediaStore.Video.Media.CONTENT_TYPE)

    private fun isGetAnyContentIntent(intent: Intent) = isGetContentIntent(intent) && intent.type == "*/*"

    private fun isSetWallpaperIntent(intent: Intent?) = intent?.action == Intent.ACTION_SET_WALLPAPER

    private fun hasImageContentData(intent: Intent) = (intent.data == uriImages ||
        intent.data == MediaStore.Images.Media.INTERNAL_CONTENT_URI)

    val uriVideos =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }

    val uriImages =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        }

    private fun hasVideoContentData(intent: Intent) = (intent.data == uriVideos ||
        intent.data == MediaStore.Video.Media.INTERNAL_CONTENT_URI)

    private fun isImageType(intent: Intent) = (intent.type?.startsWith("image/") == true || intent.type == MediaStore.Images.Media.CONTENT_TYPE)

    private fun isVideoType(intent: Intent) = (intent.type?.startsWith("video/") == true || intent.type == MediaStore.Video.Media.CONTENT_TYPE)

    override fun onActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == PICK_MEDIA && resultData != null) {
                val resultIntent = Intent()
                var resultUri: Uri? = null
                if (mIsThirdPartyIntent) {
                    val activity: Activity? = activity
                    if (activity != null) {
                        when {
                            activity?.intent?.extras?.containsKey(MediaStore.EXTRA_OUTPUT) == true && activity?.intent?.flags!! and Intent.FLAG_GRANT_WRITE_URI_PERMISSION != 0 -> {
                                resultUri = fillExtraOutput(resultData)
                            }
                            resultData.extras?.containsKey(PICKED_PATHS) == true -> fillPickedPaths(resultData, resultIntent)
                            else -> fillIntentPath(resultData, resultIntent)
                        }
                    }
                }

                if (resultUri != null) {
                    resultIntent.data = resultUri
                    resultIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                val activity: Activity? = activity
                if (activity != null) {
                    activity?.setResult(Activity.RESULT_OK, resultIntent)
                    Log.w(
                        "msg",
                        "finish3-------------------------------------------------------------------------------------------------------------------------------------------------------"
                    )
                    activity?.finish()
                }
            } else if (requestCode == PICK_WALLPAPER) {
                val activity: Activity? = activity
                if (activity != null) {
                    activity?.setResult(Activity.RESULT_OK)
                    Log.w(
                        "msg",
                        "finish4-------------------------------------------------------------------------------------------------------------------------------------------------------"
                    )

                    activity?.finish()
                }
            }
        }
        super.onActivityResult(requestCode, resultCode, resultData)
    }

    private fun fillExtraOutput(resultData: Intent): Uri? {
        val file = File(resultData.data!!.path!!)
        var inputStream: InputStream? = null
        var outputStream: OutputStream? = null
        try {
            val activity: Activity? = activity
            if (activity != null) {
                val output = activity?.intent?.extras!!.get(MediaStore.EXTRA_OUTPUT) as Uri
                inputStream = FileInputStream(file)
                outputStream = activity?.contentResolver?.openOutputStream(output)
                inputStream.copyTo(outputStream!!)
            }
        } catch (e: SecurityException) {
            //  mContext?.showErrorToast(e)
        } catch (ignored: FileNotFoundException) {
            //return getFilePublicUri(file, BuildConfig.APPLICATION_ID)
        } finally {
            inputStream?.close()
            outputStream?.close()
        }

        return null
    }

    private fun fillIntentPath(resultData: Intent, resultIntent: Intent) {
        val data = resultData.data
        val path = if (data.toString().startsWith("/")) data.toString() else data!!.path
        if (mContext != null) {
            val uri = mContext?.getFilePublicUri(File(path!!), BuildConfig.APPLICATION_ID)
            val type = path?.getMimeType()
            if (uri != null) {
                resultIntent.setDataAndTypeAndNormalize(uri, type)
            }
            resultIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    private fun fillPickedPaths(resultData: Intent, resultIntent: Intent) {
        val paths = resultData.extras!!.getStringArrayList(PICKED_PATHS)
        if (mContext != null) {
            val uris = paths!!.map { mContext?.getFilePublicUri(File(it), BuildConfig.APPLICATION_ID) } as ArrayList
            val clipData = ClipData("Attachment", arrayOf("image/*", "video/*"), ClipData.Item(uris.removeAt(0)))

            uris.forEach {
                clipData.addItem(ClipData.Item(it))
            }

            resultIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            resultIntent.clipData = clipData
        }
    }

    private fun getDirectories() {
        if (mIsGettingDirs) {
            return
        }

        mShouldStopFetching = true
        mIsGettingDirs = true
        val getImagesOnly = mIsPickImageIntent || mIsGetImageContentIntent
        val getVideosOnly = mIsPickVideoIntent || mIsGetVideoContentIntent
        if (mContext != null) {
            mContext?.getCachedDirectories(getVideosOnly, getImagesOnly) {
                try {
                    gotDirectories(mContext?.addTempFolderIfNeeded(it)!!)
                } catch (e: Exception) {
                }
            }
        }
        Log.d(TAG, "-+-+- getDirectories()")
    }


    private fun gotDirectories(newDirs: ArrayList<Directory>) {
        if (mView != null && mContext != null && mContext?.config != null) {
            mIsGettingDirs = false
            mShouldStopFetching = false

            // if hidden item showing is disabled but all Favorite items are hidden, hide the Favorites folder
            if (!mContext?.config?.shouldShowHidden!!) {
                val favoritesFolder = newDirs.firstOrNull { it.areFavorites() }
                if (favoritesFolder != null && favoritesFolder.tmb.getFilenameFromPath().startsWith('.')) {
                    newDirs.remove(favoritesFolder)
                }
            }

            val dirs = mContext?.getSortedDirectories(newDirs)
            if (mContext?.config?.groupDirectSubfolders!!) {
                if (dirs != null) {
                    mDirs = dirs.clone() as ArrayList<Directory>
                }
            }


            // By Parth Crash Solving v29
            isPlaceholderVisible = dirs?.isEmpty()

            runOnUiThread {
                if (dirs != null) {
                    // checkPlaceholderVisibility(dirs)
                }

                // Changes By Arti V1.0.32 -- check mContext null
                if (mView != null && mContext != null && mContext?.config != null) {
                    val allowHorizontalScroll = mContext?.config?.scrollHorizontally!! && mContext?.config?.viewTypeFolders!! == VIEW_TYPE_GRID
                    mView.directories_vertical_fastscroller_fragment.beVisibleIf(mView.directories_grid_fragment.isVisible() && !allowHorizontalScroll)
                    mView.directories_horizontal_fastscroller_fragment.beVisibleIf(mView.directories_grid_fragment.isVisible() && allowHorizontalScroll)
                }
            }

            setupAdapter(dirs?.clone() as ArrayList<Directory>)
            // cached folders have been loaded, recheck folders one by one starting with the first displayed
            //Change by Pradip
            if (mLastMediaFetcher != null) {
                mLastMediaFetcher?.shouldStop = true
            }
            val getImagesOnly: Boolean
            val getVideosOnly: Boolean
            val hiddenString: String
            val albumCovers: java.util.ArrayList<AlbumCover>?
            val includedFolders: MutableSet<String>?
            val noMediaFolders: ArrayList<String>?
            val tempFolderPath: String?
            val getProperFileSize: Boolean
            val favoritePaths: ArrayList<String>?
            val dirPathsToRemove: ArrayList<String>
            val lastModifieds: HashMap<String, Long>
            val dateTakens: HashMap<String, Long>
            try {
                mLastMediaFetcher = MediaFetcher(mContext!!)
                getImagesOnly = mIsPickImageIntent || mIsGetImageContentIntent
                getVideosOnly = mIsPickVideoIntent || mIsGetVideoContentIntent
                hiddenString = getString(R.string.hidden)
                albumCovers = mContext?.config?.parseAlbumCovers()
                includedFolders = mContext?.config?.includedFolders
                noMediaFolders = mContext?.getNoMediaFoldersSync()
                tempFolderPath = mContext?.config?.tempFolderPath
                getProperFileSize = mContext?.config?.directorySorting!! and SORT_BY_SIZE != 0
                favoritePaths = mContext?.getFavoritePaths()
                dirPathsToRemove = ArrayList<String>()
                lastModifieds = mLastMediaFetcher!!.getLastModifieds()
                dateTakens = mLastMediaFetcher!!.getDateTakens()
                for (directory in dirs!!) {
                    if (mShouldStopFetching || activity?.isDestroyed!! || activity?.isFinishing!!) {
                        return
                    }
                    val sorting = mContext?.config?.getFolderSorting(directory.path)
                    val grouping = mContext?.config?.getFolderGrouping(directory.path)
                    val getProperDateTaken = mContext?.config?.directorySorting!! and SORT_BY_DATE_TAKEN != 0 ||
                        sorting!! and SORT_BY_DATE_TAKEN != 0 ||
                        grouping!! and GROUP_BY_DATE_TAKEN_DAILY != 0 ||
                        grouping!! and GROUP_BY_DATE_TAKEN_MONTHLY != 0

                    val getProperLastModified = mContext?.config?.directorySorting!! and SORT_BY_DATE_MODIFIED != 0 ||
                        sorting!! and SORT_BY_DATE_MODIFIED != 0 ||
                        grouping!! and GROUP_BY_LAST_MODIFIED_DAILY != 0 ||
                        grouping!! and GROUP_BY_LAST_MODIFIED_MONTHLY != 0

                    val curMedia = mLastMediaFetcher!!.getFilesFrom(
                        directory.path, getImagesOnly, getVideosOnly, getProperDateTaken, getProperLastModified,
                        getProperFileSize, favoritePaths!!, false, lastModifieds, dateTakens
                    )

                    val newDir = if (curMedia.isEmpty()) {
                        if (directory.path != tempFolderPath) {
                            dirPathsToRemove.add(directory.path)
                        }
                        directory
                    } else {
                        mContext?.createDirectoryFromMedia(
                            directory.path,
                            curMedia,
                            albumCovers!!,
                            hiddenString,
                            includedFolders!!,
                            getProperFileSize,
                            noMediaFolders!!
                        )
                    }

                    // we are looping through the already displayed folders looking for changes, do not do anything if nothing changed
                    if (directory.copy(subfoldersCount = 0, subfoldersMediaCount = 0) == newDir) {
                        continue
                    }

                    directory.apply {
                        tmb = newDir?.tmb!!
                        name = newDir?.name!!
                        mediaCnt = newDir?.mediaCnt!!
                        modified = newDir?.modified!!
                        taken = newDir?.taken!!
                        this@apply.size = newDir?.size!!
                        types = newDir?.types!!
                        sortValue = mContext?.getDirectorySortingValue(curMedia, path, name, size)!!
                    }
                    try {
                        setupAdapter(dirs)
                    } catch (e: Exception) {
                    }


                    // update directories and media files in the local db, delete invalid items. Intentionally creating a new thread
                    mContext?.updateDBDirectory(directory)
                    if (!directory.isRecycleBin()) {
                        Thread {
                            try {
                                mContext?.mediaDB?.insertAll(curMedia)
                            } catch (ignored: Exception) {
                            }
                        }.start()
                    }

                    if (!directory.isRecycleBin()) {
                        mContext?.getCachedMedia(directory.path, getVideosOnly, getImagesOnly) {
                            val mediaToDelete = ArrayList<Medium>()
                            it.forEach {
                                if (!curMedia.contains(it)) {
                                    val medium = it as? Medium
                                    val path = medium?.path
                                    if (path != null) {
                                        mediaToDelete.add(medium)
                                    }
                                }
                            }
                            mContext?.mediaDB?.deleteMedia(*mediaToDelete.toTypedArray())
                        }
                    }
                }

                if (dirPathsToRemove.isNotEmpty()) {
                    val dirsToRemove = dirs.filter { dirPathsToRemove.contains(it.path) }
                    dirsToRemove.forEach {
                        mContext?.directoryDao?.deleteDirPath(it.path)
                    }
                    dirs.removeAll(dirsToRemove)
                    setupAdapter(dirs)
                }


                val foldersToScan = mLastMediaFetcher!!.getFoldersToScan()

//        foldersToScan.add(FAVORITES)
//        if (mContext?.config?.showRecycleBinAtFolders!!) {
//            foldersToScan.add(RECYCLE_BIN)
//        } else {
//            foldersToScan.remove(RECYCLE_BIN)
//        }

                dirs?.forEach {
                    foldersToScan.remove(it.path)
                }

                // check the remaining folders which were not cached at all yet
                for (folder in foldersToScan) {

                    if (mShouldStopFetching || activity?.isDestroyed!! || activity?.isFinishing!!) {
                        return
                    }

                    val sorting = mContext?.config?.getFolderSorting(folder)
                    val grouping = mContext?.config?.getFolderGrouping(folder)

                    val getProperDateTaken = mContext?.config?.directorySorting!! and SORT_BY_DATE_TAKEN != 0 ||
                        sorting!! and SORT_BY_DATE_TAKEN != 0 ||
                        grouping!! and GROUP_BY_DATE_TAKEN_DAILY != 0 ||
                        grouping!! and GROUP_BY_DATE_TAKEN_MONTHLY != 0

                    val getProperLastModified = mContext?.config?.directorySorting!! and SORT_BY_DATE_MODIFIED != 0 ||
                        sorting!! and SORT_BY_DATE_MODIFIED != 0 ||
                        grouping!! and GROUP_BY_LAST_MODIFIED_DAILY != 0 ||
                        grouping!! and GROUP_BY_LAST_MODIFIED_MONTHLY != 0

                    val newMedia = mLastMediaFetcher!!.getFilesFrom(
                        folder, getImagesOnly, getVideosOnly, getProperDateTaken, getProperLastModified,
                        getProperFileSize, favoritePaths!!, false, lastModifieds, dateTakens
                    )
                    if (newMedia.isEmpty()) {
                        continue
                    }

                    if (isPlaceholderVisible!!) {
                        isPlaceholderVisible = false
                        runOnUiThread {
                            mView.directories_empty_placeholder_2_fragment.beGone()
                            mView.directories_empty_placeholder_2_fragment.beGone()
                            mView.directories_grid_fragment.beVisible()
                        }
                    }

                    val newDir =
                        mContext?.createDirectoryFromMedia(
                            folder,
                            newMedia,
                            albumCovers!!,
                            hiddenString,
                            includedFolders!!,
                            getProperFileSize,
                            noMediaFolders!!
                        )
                    dirs?.add(newDir!!)
                    setupAdapter(dirs!!)

                    // make sure to create a new thread for these operations, dont just use the common bg thread
                    Thread {
                        try {
                            mContext?.directoryDao?.insert(newDir!!)
                            if (folder != RECYCLE_BIN) {
                                mContext?.mediaDB?.insertAll(newMedia)
                            }
                        } catch (ignored: Exception) {
                        }
                    }.start()
                }
            } catch (e: Exception) {
            }
            mLoadedInitialPhotos = true
            // [ WEIRED ]
            // checkLastMediaChanged()

            runOnUiThread {
                mView.directories_refresh_layout_fragment.isRefreshing = false
                checkPlaceholderVisibility(dirs!!)
            }
            if (requireContext() != null) {
                checkInvalidDirectories(dirs!!)
            }


            if (mDirs.size > 50) {
                try {
                    excludeSpamFolders()
                } catch (e: Exception) {
                }
            }

            val excludedFolders = mContext?.config?.excludedFolders
            val everShownFolders = mContext?.config?.everShownFolders?.toMutableSet() as HashSet<String>

            // do not add excluded folders and their subfolders at everShownFolders
            dirs.filter { dir ->
                if (excludedFolders?.any { dir.path.startsWith(it) }!!) {
                    Log.w(
                        "msg",
                        "1-------------------------------------------------------------------------------------------------------------------------------------------------------"
                    )
                    return@filter false
                }
                return@filter true
            }.mapTo(everShownFolders) { it.path }

            try {
                // scan the internal storage from time to time for new folders
                if (mContext?.config?.appRunCount == 1 || mContext?.config?.appRunCount!! % 30 == 0) {
                    everShownFolders.addAll(getFoldersWithMedia(mContext?.config?.internalStoragePath!!))
                }
                // catch some extreme exceptions like too many everShownFolders for storing, shouldnt really happen
                mContext?.config?.everShownFolders = everShownFolders
            } catch (e: Exception) {
                mContext?.config?.everShownFolders = HashSet()
            }

            mDirs = dirs.clone() as ArrayList<Directory>
        }

    }

    private fun forBannerAds() {

        val back_id_required = FirebaseConfigHelper.isBackIdRequired(activity)
        val admobBanner = FirebaseConfigHelper.getAdmobBanner(activity)
        val admobBackBanner = FirebaseConfigHelper.getAdmobBackBanner(activity)
        Log.w(
            "msg", "banner Ads admob_native " + FirebaseConfigHelper.remoteConfig.getString(
                FirebaseConfigHelper.admob_banner_control_home
            )
        )


        BannerAds.loadAdmob_BannerADs(
            activity, mView.admob_banner_ads, admobBanner, admobBackBanner,
            back_id_required, FirebaseConfigHelper.remoteConfig.getString(
                FirebaseConfigHelper.admob_banner_control_home
            ), false,
            object : BannerAds.AdFinishedCallback {
                override fun adFinished() {

                }

                override fun adFailedtoshow() {

                }

            }, GoogleAnalyticsEvent.albumFragment,
            GalleryMainApplication.getInstance()?.firebaseAnalytics
        )

    }

    private fun getFoldersWithMedia(path: String): HashSet<String> {
        val folders = HashSet<String>()
        try {
            val files = File(path).listFiles()
            if (files != null) {
                files.sortBy { !it.isDirectory }
                if (mContext != null && mContext?.config != null) {
                    for (file in files) {
                        if (file.isDirectory && !file.startsWith("${mContext?.config?.internalStoragePath}/Android")) {
                            folders.addAll(getFoldersWithMedia(file.absolutePath))
                        } else if (file.isFile && file.isMediaFile()) {
                            folders.add(file.parent ?: "")
                            break
                        }
                    }
                }
            }
        } catch (ignored: Exception) {
        }

        return folders
    }

    private fun checkInvalidDirectories(dirs: ArrayList<Directory>) {
        try {
            if (dirs != null) {
                val invalidDirs = ArrayList<Directory>()
                if (mContext != null && mContext?.config != null) {
                    val OTGPath = mContext?.config?.OTGPath
                    dirs.filter { !it.areFavorites() && !it.isRecycleBin() }.forEach {
                        if (mContext != null) {
                            if (!mContext?.getDoesFilePathExist(it.path, OTGPath)!!) {
                                invalidDirs.add(it)
                            } else if (it.path != mContext?.config?.tempFolderPath) {
                                val children =
                                    if (mContext?.isPathOnOTG(it.path)!!) mContext?.getOTGFolderChildrenNames(it.path) else File(it.path).list()?.asList()
                                val hasMediaFile = children?.any {
                                    it != null && (it.isMediaFile() || (it.startsWith("img_", true) && File(it).isDirectory))
                                } ?: false

                                if (!hasMediaFile) {
                                    invalidDirs.add(it)
                                }
                            }
                        }
                    }

                    if (mContext?.getFavoritePaths()?.isEmpty()!!) {
                        val favoritesFolder = dirs.firstOrNull { it.areFavorites() }
                        if (favoritesFolder != null) {
                            invalidDirs.add(favoritesFolder)
                        }
                    }

                    if (mContext?.config?.useRecycleBin!!) {
                        try {
                            val binFolder = dirs.firstOrNull { it.path == RECYCLE_BIN }
                            if (binFolder != null && mContext?.mediaDB?.getDeletedMedia()?.isEmpty()!!) {
                                invalidDirs.add(binFolder)
                            }
                        } catch (ignored: Exception) {
                        }
                    }

                    if (invalidDirs.isNotEmpty()) {
                        dirs.removeAll(invalidDirs)

                        setupAdapter(dirs)
                        invalidDirs.forEach {
                            try {
                                mContext?.directoryDao?.deleteDirPath(it.path)
                            } catch (ignored: Exception) {
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
        }
    }

    private fun excludeSpamFolders() {
        ensureBackgroundThread {
            try {
                if (mContext != null) {
                    val internalPath = mContext?.internalStoragePath
                    val checkedPaths = ArrayList<String>()
                    val oftenRepeatedPaths = ArrayList<String>()
                    val paths = mDirs.map { it.path.removePrefix(internalPath!!) }.toMutableList() as ArrayList<String>
                    paths.forEach {
                        val parts = it.split("/")
                        var currentString = ""
                        for (i in 0 until parts.size) {
                            currentString += "${parts[i]}/"

                            if (!checkedPaths.contains(currentString)) {
                                val cnt = paths.count { it.startsWith(currentString) }
                                if (cnt > 50 && currentString.startsWith("/Android/data", true)) {
                                    oftenRepeatedPaths.add(currentString)
                                }
                            }

                            checkedPaths.add(currentString)
                        }
                    }

                    val substringToRemove = oftenRepeatedPaths.filter {
                        val path = it
                        it == "/" || oftenRepeatedPaths.any { it != path && it.startsWith(path) }
                    }

                    oftenRepeatedPaths.removeAll(substringToRemove)
                    if (mContext?.config != null) {
                        val OTGPath = mContext?.config?.OTGPath
                        oftenRepeatedPaths.forEach {
                            val file = File("$internalPath/$it")
                            if (mContext?.getDoesFilePathExist(file.absolutePath, OTGPath)!!) {
                                mContext?.config?.addExcludedFolder(file.absolutePath)
                            }
                        }
                    }
                }
            } catch (e: Exception) {
            }
        }
    }

    /* private fun checkLastMediaChanged() {
         if (activity?.isDestroyed!!) {
             return
         }

         mLastMediaHandler.postDelayed({
             ensureBackgroundThread {
                 val mediaId = mContext?.getLatestMediaId()
                 val mediaDateId = mContext?.getLatestMediaByDateId()
                 if (mLatestMediaId != mediaId || mLatestMediaDateId != mediaDateId) {
                     mLatestMediaId = mediaId!!
                     mLatestMediaDateId = mediaDateId!!
                     runOnUiThread {
                         getDirectories()
                     }
                 } else {
                     mLastMediaHandler.removeCallbacksAndMessages(null)
                     // [ WEIRED ]
                     // checkLastMediaChanged()
                 }
             }
         }, LAST_MEDIA_CHECK_PERIOD)
     }*/


    private fun storeStateVariables() {
        if (mContext != null && mContext?.config != null) {
            mContext?.config?.apply {
                mStoredAnimateGifs = animateGifs
                mStoredCropThumbnails = cropThumbnails
                mStoredScrollHorizontally = scrollHorizontally
                mStoredTextColor = textColor
                mStoredStyleString = "$folderStyle$showFolderMediaCount$limitFolderTitle"
            }
            mStoredAdjustedPrimaryColor = mContext?.getAdjustedPrimaryColor()!!
        }
    }

    /* private fun checkWhatsNewDialog() {
         arrayListOf<Release>().apply {
             add(Release(213, R.string.release_213))
             add(Release(217, R.string.release_217))
             add(Release(220, R.string.release_220))
             add(Release(221, R.string.release_221))
             add(Release(225, R.string.release_225))
             add(Release(258, R.string.release_258))
             add(Release(277, R.string.release_277))
             add(Release(295, R.string.release_295))
             add(Release(327, R.string.release_327))

             (mContext as BaseSimpleActivity).checkWhatsNew(this, BuildConfig.VERSION_CODE);
         }
     }
 */
    private fun setupLatestMediaId() {

        ensureBackgroundThread {
            // Change by Pradip - v1.0.30
            try {
                val activity: Activity? = activity
                if (mContext != null && activity != null) {
                    if (ContextCompat.checkSelfPermission(
                            activity,
                            Manifest.permission.READ_EXTERNAL_STORAGE
                        ) == PackageManager.PERMISSION_GRANTED
                    ) {
                        mLatestMediaId = mContext?.getLatestMediaId()!!
                        mLatestMediaDateId = mContext?.getLatestMediaByDateId()!!
                    }
                }
            } catch (e: Exception) {

            }
        }
    }

    private fun launchSearchActivity() {
        if (mContext != null) {
            Intent(mContext, SearchActivity::class.java).apply {
                startActivity(this)
            }
        }
    }

    private fun getRecyclerAdapter() = mView.directories_grid_fragment.adapter as? DirectoryAdapter

    private fun setupAdapter(dirs: ArrayList<Directory>, textToSearch: String = "", forceRecreate: Boolean = false) {
        if (mView != null && mContext != null && mContext?.config != null) {
            val currAdapter = mView.directories_grid_fragment.adapter
            val distinctDirs = dirs.distinctBy { it.path.getDistinctPath() }.toMutableList() as ArrayList<Directory>
            val sortedDirs = mContext?.getSortedDirectories(distinctDirs)!!
            var dirsToShow = mContext?.getDirsToShow(sortedDirs, mDirs, mCurrentPathPrefix)!!.clone() as ArrayList<Directory>

            if (currAdapter == null || forceRecreate) {
                initZoomListener()
                val fastscroller =
                    if (mContext?.config?.scrollHorizontally!!) mView.directories_horizontal_fastscroller_fragment else mView.directories_vertical_fastscroller_fragment
                val activity: Activity? = activity
                if (activity != null) {
                    DirectoryAdapter(
                        mContext as BaseSimpleActivity,
                        dirsToShow,
                        this,
                        mView.directories_grid_fragment,
                        isPickIntent(activity?.intent!!) || isGetAnyContentIntent(activity?.intent!!),
                        mView.directories_refresh_layout_fragment,
                        fastscroller
                    ) {
                        val clickedDir = it as Directory
                        val path = clickedDir.path
                        if (clickedDir.subfoldersCount == 1 || !mContext?.config?.groupDirectSubfolders!!) {
                            if (path != mContext?.config?.tempFolderPath) {
                                itemClicked(path)
                            }
                        } else {
                            mCurrentPathPrefix = path
                            mOpenedSubfolders.add(path)
                            setupAdapter(mDirs, "")
                        }
                    }.apply {
                        setupZoomListener(mZoomListener)
                        runOnUiThread {
                            mView.directories_grid_fragment.adapter = this
                            setupScrollDirection()

                            if (mContext?.config?.viewTypeFolders == VIEW_TYPE_LIST) {
                                mView.directories_grid_fragment.scheduleLayoutAnimation()
                            }
                        }
                    }
                    measureRecyclerViewContent(dirsToShow)
                }
            } else {
                runOnUiThread {
                    if (textToSearch.isNotEmpty()) {
                        dirsToShow = dirsToShow.filter { it.name.contains(textToSearch, true) }.sortedBy { !it.name.startsWith(textToSearch, true) }
                            .toMutableList() as ArrayList

                        if (dirsToShow.isEmpty()) {
                            mView.directories_empty_placeholder_fragment_search.apply {
                                beVisible()
                                if (context?.config?.theme!!) {
                                    this.setTextColor(resources.getColor(R.color.dark_))
                                    this.alpha = 0.8F
                                } else {
                                    this.setTextColor(resources.getColor(R.color.light_))
                                    this.alpha = 0.8F
                                }
                            }
                        } else {
                            // By Parth Crash Solving 1.0.35 4
                            mView.directories_empty_placeholder_fragment_search.beGone()
                        }
                    } else {
                        // By Parth Crash Solving 1.0.35 4
                        mView.directories_empty_placeholder_fragment_search.beGone()
                    }
                    runOnUiThread {
                        checkPlaceholderVisibility(dirsToShow)
                    }
                    if (mView.directories_grid_fragment != null) {
                        (mView.directories_grid_fragment.adapter as? DirectoryAdapter)?.updateDirs(dirsToShow)
                    }
                    measureRecyclerViewContent(dirsToShow)
                }
            }

            // recyclerview sometimes becomes empty at init/update, triggering an invisible refresh like this seems to work fine
            try {
                mView.directories_grid_fragment?.postDelayed({
                    mView.directories_grid_fragment?.scrollBy(0, 0)
                }, 500)
            } catch (e: Exception) {

            }
            runOnUiThread {
                mView.album_progessbar_fragment.visibility = View.GONE
            }
        }
    }

    private fun initZoomListener() {
        if (mContext != null && mContext?.config != null) {
            if (mContext?.config?.viewTypeFolders == VIEW_TYPE_GRID) {
                val layoutManager = mView.directories_grid_fragment?.layoutManager!! as MyGridLayoutManager
                mZoomListener = object : MyRecyclerView.MyZoomListener {
                    override fun zoomIn() {
                        if (layoutManager.spanCount > 1) {
                            reduceColumnCount()
                            getRecyclerAdapter()?.finishActMode()
                        }
                    }

                    override fun zoomOut() {
                        if (layoutManager.spanCount < MAX_COLUMN_COUNT) {
                            increaseColumnCount()
                            getRecyclerAdapter()?.finishActMode()
                        }
                    }
                }
            } else {
                mZoomListener = null
            }
        }
    }

    private fun reduceColumnCount() {
        if (mContext != null && mView != null && mContext?.config != null) {
            mContext?.config?.dirColumnCnt = --(mView.directories_grid_fragment.layoutManager as MyGridLayoutManager).spanCount
            columnCountChanged()
        }
    }

    private fun increaseColumnCount() {
        if (mContext != null && mView != null) {
            mContext?.config?.dirColumnCnt = ++(mView.directories_grid_fragment.layoutManager as MyGridLayoutManager).spanCount
            columnCountChanged()
        }
    }

    private fun columnCountChanged() {
        val activity: Activity? = activity
        if (activity != null) {
            (activity as AppCompatActivity).invalidateOptionsMenu()
            getRecyclerAdapter()?.apply {
                notifyItemRangeChanged(0, dirs.size)
                measureRecyclerViewContent(dirs)
            }
        }
    }

    private fun measureRecyclerViewContent(directories: ArrayList<Directory>) {
        if (mView != null && mContext != null && mContext?.config != null) {
            if (directories != null) {
                // By Parth Crash Solving v29
                try {
                    mView.directories_grid_fragment.onGlobalLayout {
                        //Change by pradip
                        if (mContext?.config?.scrollHorizontally == true) {
                            calculateContentWidth(directories)
                        } else {
                            calculateContentHeight(directories)
                        }
                    }
                } catch (e: Exception) {
                }
            }
        }
    }

    private fun calculateContentWidth(directories: ArrayList<Directory>) {
        if (mView != null && mContext != null && mContext?.config != null) {
            val layoutManager = mView.directories_grid_fragment.layoutManager as MyGridLayoutManager

            val fullWidth = if (mContext?.config?.folderStyle == FOLDER_STYLE_SQUARE) {
                val thumbnailWidth = layoutManager.getChildAt(0)?.width ?: 0
                ((directories.size - 1) / layoutManager.spanCount + 1) * thumbnailWidth
            } else {
                val thumbnailWidth = (layoutManager.getChildAt(0)?.width ?: 0) + resources.getDimension(R.dimen.medium_margin).toInt() * 2
                val columnCount = (directories.size - 1) / layoutManager.spanCount + 1
                columnCount * thumbnailWidth
            }

            mView.directories_horizontal_fastscroller_fragment.setContentWidth(fullWidth)
            mView.directories_horizontal_fastscroller_fragment.setScrollToX(mView.directories_grid_fragment.computeHorizontalScrollOffset())
        }
    }

    private fun calculateContentHeight(directories: ArrayList<Directory>) {
        if (mView != null) {
            val layoutManager = mView.directories_grid_fragment.layoutManager as MyGridLayoutManager
            if (mContext != null && mContext?.config != null) {
                val fullHeight = if (mContext?.config?.folderStyle == FOLDER_STYLE_SQUARE) {
                    val thumbnailHeight = layoutManager.getChildAt(0)?.height ?: 0
                    ((directories.size - 1) / layoutManager.spanCount + 1) * thumbnailHeight
                } else {
                    var thumbnailHeight = (layoutManager.getChildAt(0)?.height ?: 0)
                    if (mContext != null && mContext?.config != null) {
                        if (mContext?.config?.viewTypeFolders == VIEW_TYPE_GRID) {
                            thumbnailHeight += resources.getDimension(R.dimen.medium_margin).toInt() * 2
                        }
                    }
                    val rowCount = (directories.size - 1) / layoutManager.spanCount + 1
                    rowCount * thumbnailHeight
                }
                mView.directories_vertical_fastscroller_fragment.setContentHeight(fullHeight)
                mView.directories_vertical_fastscroller_fragment.setScrollToY(mView.directories_grid_fragment.computeVerticalScrollOffset())
            }


        }
    }

    private fun checkPlaceholderVisibility(dirs: ArrayList<Directory>) {

        if (dirs != null && mView != null && mContext != null) {
            if (mIsSearchOpen) {
                mView.directories_empty_placeholder_fragment.text = getString(R.string.no_items_found)
                mView.directories_empty_placeholder_2_fragment.beGone()
            } else if (dirs.isEmpty() && mContext?.config != null && mContext?.config?.filterMedia == getDefaultFileFilter()) {
                mView.directories_empty_placeholder_fragment.text = getString(R.string.no_media_add_included)
                mView.directories_empty_placeholder_2_fragment.text = getString(R.string.add_folder)

                mView.directories_empty_placeholder_2_fragment.setOnClickListener {
                    (mContext as SimpleActivity).showAddIncludedFolderDialog {
                        refreshItems()
                    }
                }
            } else {
                directories_empty_placeholder_fragment_search.beGone()
//            Changes By Arti V1.0.28
                try {
                    val activity: Activity? = activity
                    if (activity != null) {
                        if (!activity.isFinishing && isAdded) {
                            mView.directories_empty_placeholder_fragment.text = getString(R.string.no_media_with_filters)
                            mView.directories_empty_placeholder_2_fragment.text = getString(R.string.change_filters_underlined)

                            mView.directories_empty_placeholder_2_fragment_filter.setOnClickListener {
                                showFilterMediaDialog()
                            }
                        }
                    }
                } catch (e: Exception) {
                }
            }

            mView.directories_empty_placeholder_2_fragment.underlineText()
            mView.directories_grid_fragment.beVisibleIf(mView.directories_empty_placeholder_fragment.isGone())
        }
    }


    override fun refreshItems() {
        getDirectories()
    }

    override fun deleteFolders(folders: ArrayList<File>) {
        if (mContext != null && mContext?.config != null) {
            val fileDirItems =
                folders.asSequence().filter { it.isDirectory }.map { FileDirItem(it.absolutePath, it.name, true) }.toMutableList() as ArrayList<FileDirItem>
            when {
                fileDirItems.isEmpty() -> return
                fileDirItems.size == 1 -> {
                    try {
                        mContext?.toast(String.format(getString(R.string.deleting_folder), fileDirItems.first().name))
                    } catch (e: Exception) {
                        //mContext?. showErrorToast(e)
                    }
                }
                else -> {
                    if (mContext?.config != null) {
                        val baseString = if (mContext?.config?.useRecycleBin!!) R.plurals.moving_items_into_bin else R.plurals.delete_items
                        val deletingItems = resources.getQuantityString(baseString, fileDirItems.size, fileDirItems.size)
                        mContext?.toast(deletingItems)
                    }
                }
            }

            val itemsToDelete = ArrayList<FileDirItem>()
            val filter = mContext?.config?.filterMedia!!
            val showHidden = mContext?.config?.shouldShowHidden!!
            val activity: Activity? = activity
            if (activity != null) {
//                GlobalScope.launch {
                fileDirItems.filter { it.isDirectory }.forEach {
                    val files = File(it.path).listFiles()
                    files?.filter {
                        it.absolutePath.isMediaFile() && (showHidden || !it.name.startsWith('.')) &&
                            ((it.isImageFast() && filter and TYPE_IMAGES != 0) ||
                                (it.isVideoFast() && filter and TYPE_VIDEOS != 0) ||
                                (it.isGif() && filter and TYPE_GIFS != 0) ||
                                (it.isRawFast() && filter and TYPE_RAWS != 0) ||
                                (it.isSvg() && filter and TYPE_SVGS != 0))
                    }?.mapTo(itemsToDelete) { it.toFileDirItem(activity) }
                }
            }
//            }
            if (mContext?.config?.useRecycleBin!!) {
                val pathsToDelete = ArrayList<String>()
                itemsToDelete.mapTo(pathsToDelete) { it.path }

                (activity as BaseSimpleActivity).movePathsInRecycleBin(pathsToDelete) {
                    if (it) {
                        deleteFilteredFileDirItems(itemsToDelete, folders)
                    } else {
                        mContext?.toast(R.string.unknown_error_occurred)
                    }
                }
            } else {
                deleteFilteredFileDirItems(itemsToDelete, folders)
            }
        }
    }

    override fun recheckPinnedFolders() {
        if (mContext != null) {

            ensureBackgroundThread {
                gotDirectories(mContext?.movePinnedDirectoriesToFront(getCurrentlyDisplayedDirs())!!)
            }
        }
    }

    override fun updateDirectories(directories: ArrayList<Directory>) {
        ensureBackgroundThread {
            if (mContext != null) {
                mContext?.storeDirectoryItems(directories)
                mContext?.removeInvalidDBDirectories()
            }
        }
    }

    private fun deleteFilteredFileDirItems(fileDirItems: ArrayList<FileDirItem>, folders: ArrayList<File>) {
        try {
            if (mContext != null && mContext?.config != null) {

                val OTGPath = mContext?.config?.OTGPath
                // By Parth v27
                (mContext as? BaseSimpleActivity)?.deleteFiles(fileDirItems) {
                    runOnUiThread {
                        refreshItems()
                    }

                    ensureBackgroundThread {
                        try {
                            if (mContext != null && mContext?.config != null) {
                                folders.filter { !mContext?.getDoesFilePathExist(it.absolutePath, OTGPath)!! }.forEach {
                                    mContext?.directoryDao?.deleteDirPath(it.absolutePath)
                                }

                                if (mContext?.config?.deleteEmptyFolders!!) {
                                    val activity: Activity? = activity
                                    if (activity != null) {
                                        folders.filter {
                                            !it.absolutePath.isDownloadsFolder() && it.isDirectory && it.toFileDirItem(activity)
                                                .getProperFileCount(activity, true) == 0
                                        }
                                            .forEach {
                                                (activity as? BaseSimpleActivity)?.tryDeleteFileDirItem(it.toFileDirItem(activity), true, true)
                                            }
                                    }
                                }
                            }
                        } catch (e: Exception) {
                        }
                    }
                }
            }
        } catch (e: Exception) {

        }
    }

    private fun showFilterMediaDialog() {
        if (mView != null && mContext != null) {
            // [ WEIRED ]
            FilterMediaDialog(mContext as SimpleActivity) {
                if (it == 0) {
                    mView.directories_empty_placeholder_fragment_filter.beVisible()
                    mView.directories_empty_placeholder_2_fragment_filter.beVisible()
                } else {
                    mView.directories_empty_placeholder_fragment_filter.beGone()
                    mView.directories_empty_placeholder_2_fragment_filter.beGone()
                }
                mShouldStopFetching = true
                mView.directories_refresh_layout_fragment.isRefreshing = true
                mView.directories_grid_fragment.adapter = null
                getDirectories()
            }
        }
    }

    private fun setupScrollDirection() {
        if (mView != null && mContext != null && mContext?.config != null) {
            //Change by pradip
            val activity: Activity? = activity
            if (activity != null) {
                val allowHorizontalScroll = activity?.config?.scrollHorizontally == true && mContext?.config?.viewTypeFolders == VIEW_TYPE_GRID
                mView.directories_vertical_fastscroller_fragment.isHorizontal = false
                mView.directories_vertical_fastscroller_fragment.beGoneIf(allowHorizontalScroll)

                mView.directories_horizontal_fastscroller_fragment.isHorizontal = true
                mView.directories_horizontal_fastscroller_fragment.beVisibleIf(allowHorizontalScroll)
                try {
                    if (mContext != null && mContext?.config != null) {
                        if (allowHorizontalScroll) {
                            mView.directories_horizontal_fastscroller_fragment.setViews(
                                mView.directories_grid_fragment,
                                mView.directories_refresh_layout_fragment
                            ) {
                                mView.directories_horizontal_fastscroller_fragment.updateBubbleText(getBubbleTextItem(it))
                            }
                        } else {
                            mView.directories_vertical_fastscroller_fragment.setViews(
                                mView.directories_grid_fragment,
                                mView.directories_refresh_layout_fragment
                            ) {
                                mView.directories_vertical_fastscroller_fragment.updateBubbleText(getBubbleTextItem(it))
                            }
                        }
                    }
                } catch (e: Exception) {
                }
            }
        }
    }

    private fun getBubbleTextItem(index: Int) =
        // [ WEIRED ]
        getRecyclerAdapter()?.dirs?.getOrNull(index)?.getBubbleText(mContext?.config?.directorySorting!!, mContext!!, mDateFormat, mTimeFormat)
            ?: ""


    private fun itemClicked(path: String) {
        val activity1: Activity? = activity
        if (activity1 != null) {
            activity?.handleLockedFolderOpening(path) { success ->
                if (success) {
                    if (!FirebaseConfigHelper.getIsAppAdFree(activity1) && FirebaseConfigHelper.isNetworkConnected(activity1) && FirebaseConfigHelper.remoteConfig.getBoolean(
                            FirebaseConfigHelper.isHomeScreenAlbumItemClickAdEnable
                        )
                    ) {
                        val admob_int = FirebaseConfigHelper.getAdmob_intAlbumClick(activity1)
                        val admob_back_int = FirebaseConfigHelper.getAdmobBack_int(activity1)
                        val admob_rewared = FirebaseConfigHelper.getAdmobRewared(activity1)
                        val admob_back_rewared = FirebaseConfigHelper.getAdmobBackRewared(activity1)
                        val admob_rewared_int = FirebaseConfigHelper.getAdmobRewaredInt(activity1)
                        val admob_back_rewared_int = FirebaseConfigHelper.getAdmobBackRewaredInt(activity1)
                        InterstitialAdLoader.showAdWithControl(
                            activity1,
                            FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_interstitial_control),
                            false,
                            object : InterstitialAdLoader.adfinishwithControl {
                                override fun adfinished() {
                                    FirebaseConfigHelper.logMethod("nativeshow  ", "Theme Dark")
                                    Intent(activity1, MediaActivity::class.java).apply {
                                        putExtra(SKIP_AUTHENTICATION, true)
                                        putExtra(INT_AD_ON_BACK_ENABLE, false)
                                        putExtra(DIRECTORY, path)
                                        handleMediaIntent(this)
                                    }
                                }


                                override fun rewaredfailed() {
                                    FirebaseConfigHelper.logMethod("nativeshow  ", "Theme Dark")
                                    Intent(activity1, MediaActivity::class.java).apply {
                                        putExtra(SKIP_AUTHENTICATION, true)
                                        putExtra(INT_AD_ON_BACK_ENABLE, false)
                                        putExtra(DIRECTORY, path)
                                        handleMediaIntent(this)
                                    }
                                }
                            },
                            admob_int,
                            admob_back_int,
                            admob_rewared,
                            admob_back_rewared,
                            admob_rewared_int,
                            admob_back_rewared_int,
                            FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.back_id_required),
                            GoogleAnalyticsEvent.themeActivity + "_album_item_click",
                            GalleryMainApplication.getInstance()?.firebaseAnalytics,


                            )

                    } else {
                        Intent(activity1, MediaActivity::class.java).apply {
                            putExtra(SKIP_AUTHENTICATION, true)
                            putExtra(INT_AD_ON_BACK_ENABLE, false)
                            putExtra(DIRECTORY, path)
                            handleMediaIntent(this)
                        }
                    }

                }
            }
        }
    }


    private fun handleMediaIntent(intent: Intent) {
        intent.apply {
            if (mIsSetWallpaperIntent) {
                putExtra(SET_WALLPAPER_INTENT, true)
                startActivityForResult(this, PICK_WALLPAPER)
            } else {
                FirebaseConfigHelper.logMethod("rewaredfailed  ", " 5 Item click else")

                putExtra(GET_IMAGE_INTENT, mIsPickImageIntent || mIsGetImageContentIntent)
                putExtra(GET_VIDEO_INTENT, mIsPickVideoIntent || mIsGetVideoContentIntent)
                putExtra(GET_ANY_INTENT, mIsGetAnyContentIntent)
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, mAllowPickingMultiple)
                startActivityForResult(intent, PICK_MEDIA)
            }

        }
    }

    private fun tryLoadGallery() {
        FirebaseConfigHelper.logMethod("album", "try to load Gallery")
        if (mContext != null && mContext?.config != null) {

            /*(activity as BaseSimpleActivity).handlePermission(PERMISSION_WRITE_STORAGE) {
    //            if (it) {*/
            if (!mWasDefaultFolderChecked) {
                openDefaultFolder()
                mWasDefaultFolderChecked = true
            }

            if (!mContext?.config?.wasUpgradedFromFreeShown!! && mContext?.isPackageInstalled("albums.gallery.photo.folder.picasa.app.web.gallery.gallery")!!) {
                // [ WEIRED ]
                val activity: Activity? = activity
                if (activity != null) {
                    ConfirmationDialog(activity, "", R.string.upgraded_from_free, R.string.ok, 0, false) {}
                }
                mContext?.config?.wasUpgradedFromFreeShown = true
            }

            checkOTGPath()
            checkDefaultSpamFolders()

            if (mContext?.config?.showAll!!) {
                showAllMedia()
            } else {
                getDirectories()
            }

            setupLayoutManager()
        }
    } /*else {
                permission_txt.visibility = View.VISIBLE
                directories_empty_placeholder_fragment.visibility = View.GONE
                directories_empty_placeholder_2_fragment.visibility = View.GONE
                // mContext?.toast(R.string.no_storage_permissions)
                // activity?.finish()
            }
        }
    }*/

    private fun setupLayoutManager() {
        if (mContext != null && mContext?.config != null) {
            if (mContext?.config?.viewTypeFolders == VIEW_TYPE_GRID) {
                setupGridLayoutManager()
            } else {
                setupListLayoutManager()
            }
        }
    }

    private fun setupGridLayoutManager() {
        if (mView != null && mContext != null && mContext?.config != null) {
            val layoutManager = mView.directories_grid_fragment.layoutManager as MyGridLayoutManager
            (mView.directories_grid_fragment.layoutParams as RelativeLayout.LayoutParams).apply {
                topMargin = 0
                bottomMargin = 0
            }

            if (mContext?.config?.scrollHorizontally!!) {
                layoutManager.orientation = RecyclerView.HORIZONTAL
                mView.directories_refresh_layout_fragment.layoutParams =
                    FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT)
            } else {
                layoutManager.orientation = RecyclerView.VERTICAL
                mView.directories_refresh_layout_fragment.layoutParams =
                    FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            }

            layoutManager.spanCount = mContext?.config?.dirColumnCnt!!
        }
    }

    private fun setupListLayoutManager() {
        if (mView != null) {
            val layoutManager = mView.directories_grid_fragment.layoutManager as MyGridLayoutManager
            layoutManager.spanCount = 1
            layoutManager.orientation = RecyclerView.VERTICAL
            mView.directories_refresh_layout_fragment.layoutParams =
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

            val smallMargin = resources.getDimension(R.dimen.small_margin).toInt()
            (mView.directories_grid_fragment.layoutParams as RelativeLayout.LayoutParams).apply {
                topMargin = smallMargin
                bottomMargin = smallMargin
            }

            mZoomListener = null
        }
    }

    private fun openDefaultFolder() {
        if (mContext != null && mContext?.config != null) {
            if (mContext?.config?.defaultFolder?.isEmpty()!!) {
                return
            }

            val defaultDir = File(mContext?.config?.defaultFolder!!)

            if ((!defaultDir.exists() || !defaultDir.isDirectory) && (mContext?.config?.defaultFolder != RECYCLE_BIN && mContext?.config?.defaultFolder != FAVORITES)) {
                mContext?.config?.defaultFolder = ""
                return
            }

            Intent(mContext, MediaActivity::class.java).apply {
                putExtra(DIRECTORY, mContext?.config?.defaultFolder)
                handleMediaIntent(this)
            }
        }
    }

    private fun checkOTGPath() {
        Log.w("msg", " permession checkOTGPath--------------------------")
        if (mContext != null && mView != null && mContext?.config != null) {

            ensureBackgroundThread {
                if (!mContext?.config?.wasOTGHandled!! && /*mContext?.hasPermission(PERMISSION_WRITE_STORAGE)!! &&*/ mContext?.hasOTGConnected()!! && mContext?.config?.OTGPath?.isEmpty()!!) {
                    mContext?.getStorageDirectories()
                        ?.firstOrNull { it.trimEnd('/') != mContext?.internalStoragePath && it.trimEnd('/') != mContext?.sdCardPath }
                        ?.apply {
                            mContext?.config?.wasOTGHandled = true
                            val otgPath = trimEnd('/')
                            mContext?.config?.OTGPath = otgPath
                            mContext?.config?.addIncludedFolder(otgPath)
                        }
                    runOnUiThread {
                        Log.w("msg", " allow--------------------------")

//                    permission_txt.visibility = View.GONE
                    }

                } else {
                    runOnUiThread {
                        Log.w("msg", "Deny--------------------------")
//                    permission_txt.visibility = View.VISIBLE

                        if (mView.directories_empty_placeholder_fragment != null && mView.directories_empty_placeholder_2_fragment != null) {       // Change by Priyanka - v1.0.30
                            mView.directories_empty_placeholder_fragment.visibility = View.GONE
                            mView.directories_empty_placeholder_2_fragment.visibility = View.GONE    // Change by Priyanka - v1.0.30
                        }


                    }
                }
            }
        }
    }

    private fun checkDefaultSpamFolders() {
        if (mContext != null && mContext?.config != null) {
            if (!mContext?.config?.spamFoldersChecked!!) {
                val spamFolders = arrayListOf(
                    "/storage/emulated/0/Android/data/com.facebook.orca/files/stickers"
                )

                val OTGPath = mContext?.config?.OTGPath
                spamFolders.forEach {
                    if (mContext?.getDoesFilePathExist(it, OTGPath)!!) {
                        mContext?.config?.addExcludedFolder(it)
                    }
                }
                mContext?.config?.spamFoldersChecked = true
            }
        }
    }

    private fun showAllMedia() {
        if (mContext != null && mContext?.config != null) {
            mContext?.config?.showAll = true
            Intent(mContext, MediaActivity::class.java).apply {
                putExtra(DIRECTORY, "")

                if (mIsThirdPartyIntent) {
                    handleMediaIntent(this)
                } else {
                    startActivity(this)
                    val activity: Activity? = activity
                    if (activity != null) {
                        activity?.finish()
                    }
                }
            }
        }
    }

    override fun onMenuItemClick(item: MenuItem?): Boolean {
        return true
    }

}
