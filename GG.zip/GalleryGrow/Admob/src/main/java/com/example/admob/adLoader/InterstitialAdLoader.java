

package com.example.admob.adLoader;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;

import com.example.admob.utils.PreferenceManager;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.firebase.analytics.FirebaseAnalytics;

public class InterstitialAdLoader {
    private static adfinish myadfinish;
    private static InterstitialAd mAdmobInterstitialAd = null;
    private static final String TAG = "IntertitialAdLoader";
    private static boolean isAdLoading = false;

    private static String F_Request = "f_request";
    private static String F_Load = "f_load";
    private static String F_Fail_Load = "f_fail_load";
    private static String F_Show = "f_show";
    private static String F_Dismiss = "f_dismiss";
    private static String F_Show_Fail = "f_show_fail";
    private static String F_Click = "f_click";

    private static String B_Request = "b_request";
    private static String B_Load = "b_load";
    private static String B_Fail_Load = "b_fail_load";


    private static String eventName = "Admob_Interstitial";



    public static void showAdWithControl(Activity activity, String admob_interstitial_control, boolean isLast, adfinishwithControl myadfinish1
        , String admob_int, String admob_back_int, String admob_rewared, String admob_back_rewared, String admob_rewared_int,
                                         String admob_back_rewared_int, String admob_back_id_required, String activityName,
                                         FirebaseAnalytics analytics) {


        Log.w("msg", "Admob loadAdWithControl admob_interstitial_control : " + admob_interstitial_control);
        if (admob_interstitial_control.equals("admob_int")) {
            if (InterstitialAdLoader.isAdLoaded()) {
                InterstitialAdLoader.
                    showInterstitialAd(activity, admob_int, admob_back_int, admob_back_id_required, isLast, () -> {
                        Log.w("msg", "Admob loadAdWithControl IntertitialAdLoader showAd adfinished : ");
                        myadfinish1.adfinished();
                    }, activityName, analytics, null);
            } else {
                myadfinish1.adfinished();
            }
        } else if (admob_interstitial_control.equals("admob_rewared")) {
            RewardedAdLoader.showVideoAd(activity, new RewardedAdLoader.mCallBack() {
                @SuppressLint("WrongConstant")
                @Override
                public void done(boolean isReworded) {

                    RewardedAdLoader.loadRewardedVideoAd(activity, admob_rewared, admob_back_rewared, admob_back_id_required,activityName,analytics);
                    myadfinish1.adfinished();
                }

                @Override
                public void failed(boolean isReworded) {
                    myadfinish1.rewaredfailed();
                }
            },activityName,analytics);
        } else if (admob_interstitial_control.equals("admob_rewared_int")) {
            RewardedInterstrialAdLoader.showRewardedIntAd(activity, myadfinish1, admob_rewared_int, admob_back_rewared_int, admob_back_id_required,activityName,analytics);
        }
    }


    public static void loadAd(Context context, String admob_interstitial_control,
                              String admob_int, String admob_back_int, String admob_back_id_required, String admob_rewarded, String admob_back_rewarded,
                              String admob_rewarded_int, String admob_back_rewarded_int, String from, String activityName,
                              FirebaseAnalytics analytics, adfinishSplash myadfinish1) {
        if (admob_interstitial_control.equals("admob_int")) {
            if (!InterstitialAdLoader.isAdLoaded()) {
                Log.w(TAG, "Load From== " + from);
                loadAdmobInt(context, admob_int, admob_back_int, admob_back_id_required, activityName, analytics,myadfinish1);
            } else {
                if (myadfinish1 != null) {
                    myadfinish1.adfinished();
                }

            }
        } else if (admob_interstitial_control.equals("admob_rewared")) {
            RewardedAdLoader.loadAd(context, admob_rewarded, admob_back_rewarded, admob_back_id_required,activityName,analytics);
        } else if (admob_interstitial_control.equals("admob_rewared_int")) {
            RewardedInterstrialAdLoader.loadAd(context, admob_rewarded_int,
                admob_back_rewarded_int, admob_back_id_required,activityName,analytics);
        } else {
            loadAdmobInt(context, admob_int, admob_back_int, admob_back_id_required, activityName, analytics, myadfinish1);
        }
    }

    public static void loadAdWithCallback(Context context, String admob_interstitial_control,
                                          String admob_int, String admob_back_int, String admob_back_id_required, String admob_rewarded, String admob_back_rewarded,
                                          String admob_rewarded_int, String admob_back_rewarded_int, String from, String activityName,
                                          FirebaseAnalytics analytics, adfinishSplash myadfinish1) {
        Log.w("msg", "Admob loadAdWithCallback " + admob_interstitial_control);
        if (admob_interstitial_control.equals("admob_int")) {
            if (!InterstitialAdLoader.isAdLoaded()) {
                Log.w("msg", "Admob Load From== " + from);
                loadAdmobInt(context, admob_int, admob_back_int, admob_back_id_required, activityName, analytics, myadfinish1);
            } else {
                if (myadfinish1 != null)
                    myadfinish1.adfinished();

            }
        } else if (admob_interstitial_control.equals("admob_rewared")) {
            RewardedAdLoader.loadAd(context, admob_rewarded, admob_back_rewarded, admob_back_id_required,activityName,analytics);
        } else if (admob_interstitial_control.equals("admob_rewared_int")) {
            RewardedInterstrialAdLoader.loadAd(context, admob_rewarded_int,
                admob_back_rewarded_int, admob_back_id_required,activityName,analytics);
        } else {
            loadAdmobInt(context, admob_int, admob_back_int, admob_back_id_required, activityName, analytics,  myadfinish1);
        }
    }

    public static boolean isAdLoaded() {
        if (mAdmobInterstitialAd != null) {
            return true;
        } else {
            return false;
        }
    }


    public static void loadAdmobInt(final Context context, String admob_interestial, String admob_back_interestial,
                                    String back_id_required, String activityName, FirebaseAnalytics analytics,
                                    adfinishSplash myadfinish1) {
        Log.w("msg", "Admob loadAdmobInt  admob_interestial" + admob_interestial);
        Log.w("msg", "Admob loadAdmobInt  admob_back_interestial" + admob_back_interestial);


        if (mAdmobInterstitialAd == null && !isAdLoading) {
            Bundle bundle = new Bundle();
            bundle.putString(F_Request, activityName);
            if (analytics != null) {
                analytics.logEvent(eventName, bundle);

            }
            Log.w("msg", "Admob --- " + eventName + " + " + F_Request + " + " + activityName + " " + admob_interestial);
            isAdLoading = true;

            InterstitialAd.load(context, admob_interestial, new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {

                    mAdmobInterstitialAd = interstitialAd;
                    Log.w("msg", "Admob loadAdmobInt  onAdLoaded");
                    isAdLoading = false;
                    PreferenceManager.Companion.saveData(context, "adContantShow", false);
                    if (myadfinish1 != null) {
                        myadfinish1.adfinished();
                    }
                    Bundle bundle = new Bundle();
                    bundle.putString(F_Load, activityName);
                    if (analytics != null) {
                        analytics.logEvent(eventName, bundle);
                    }

                    Log.w("msg", "Admob --- " + eventName + " + " + F_Load + " + " + activityName + " " + admob_interestial);

                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    mAdmobInterstitialAd = null;
                    Bundle bundle = new Bundle();
                    bundle.putString(F_Fail_Load, activityName);
                    if (analytics != null) {
                        analytics.logEvent(eventName, bundle);
                    }
                    Log.w("msg", "Admob --- " + eventName + " + " + F_Fail_Load + " + " + activityName + " " + admob_interestial + " Error : " + loadAdError.getCode());
                    if (back_id_required.equals("true")) {
                        loadAdmobIntReLload(context, admob_back_interestial, activityName, analytics, myadfinish1);

                    }


                }
            });
        }
    }

    public interface adfinishSplash {
        void adfinished();

    }

    public interface adfinish {
        void adfinished();

    }


    public interface adfinishwithControl {
        void adfinished();

        void rewaredfailed();
    }


    public static void showInterstitialAd(Activity activity, String admob_int, String admob_back_int,
                                          String back_id_required, boolean isLast, adfinish myadfinish1, String activityName,
                                          FirebaseAnalytics analytics, adfinishSplash adfinishSplash) {

        myadfinish = myadfinish1;
        if (mAdmobInterstitialAd != null && PreferenceManager.Companion.getBooleanData(activity, PreferenceManager.Companion.getSHOW_OPEN_AD(), true)) {
            mAdmobInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override
                public void onAdDismissedFullScreenContent() {
                    PreferenceManager.Companion.saveData(activity, "adContantShow", false);
                    Bundle bundle = new Bundle();
                    bundle.putString(F_Dismiss, activityName);
                    if (analytics != null) {
                        analytics.logEvent(eventName, bundle);
                    }
                    Log.w("msg", "Admob --- " + eventName + " + " + F_Dismiss + " + " + activityName + " ");
                    if (!isLast) {
                        loadAdmobInt(activity, admob_int, admob_back_int, back_id_required, activityName, analytics, null);
                    }
                    myadfinish.adfinished();
                    PreferenceManager.Companion.saveToShowOpenAd(activity, true);

                    F_Show = "f_show";
                    F_Dismiss = "f_dismiss";
                    F_Show_Fail = "f_show_fail";
                    F_Click = "f_click";
                }

                @Override
                public void onAdFailedToShowFullScreenContent(AdError adError) {
                    PreferenceManager.Companion.saveData(activity, "adContantShow", false);
                    myadfinish.adfinished();
                    PreferenceManager.Companion.saveToShowOpenAd(activity, true);
                    Bundle bundle = new Bundle();
                    bundle.putString(F_Show_Fail, activityName);
                    if (analytics != null) {
                        analytics.logEvent(eventName, bundle);
                    }
                    Log.w("msg", "Admob --- " + eventName + " + " + F_Show_Fail + " + " + activityName + " ");
                    F_Show = "f_show";
                    F_Dismiss = "f_dismiss";
                    F_Show_Fail = "f_show_fail";
                    F_Click = "f_click";                }

                @Override
                public void onAdShowedFullScreenContent() {
                    PreferenceManager.Companion.saveToShowOpenAd(activity, false);
                    mAdmobInterstitialAd = null;
                    PreferenceManager.Companion.saveData(activity, "adContantShow", true);
                    Bundle bundle = new Bundle();
                    bundle.putString(F_Show, activityName);
                    if (analytics != null) {
                        analytics.logEvent(eventName, bundle);
                    }
                    Log.w("msg", "Admob --- " + eventName + " + " + F_Show + " + " + activityName + " ");

                }
                @Override
                public void onAdClicked() {
                    super.onAdClicked();
                    Bundle bundle = new Bundle();
                    bundle.putString(F_Click, activityName);
                    if (analytics != null) {
                        analytics.logEvent(eventName, bundle);
                    }
                    Log.w("msg", "Admob --- " + eventName + " + " + F_Click + " + " + activityName + " ");

                }

                @Override
                public void onAdImpression() {
                    super.onAdImpression();

                }

            });
            Log.w("msg", "Admob showAd Show AD:");

            mAdmobInterstitialAd.show(activity);
        } else {
            Log.w("msg", "Admob showAd else  :");

            myadfinish.adfinished();
        }
    }

    public static void loadAdmobIntReLload(final Context context, String admob_back_interestial, String activityName,
                                           FirebaseAnalytics analytics, adfinishSplash myadfinish1) {



        if (mAdmobInterstitialAd == null) {
            F_Show = "b_show";
            F_Dismiss = "b_dismiss";
            F_Show_Fail = "b_show_fail";
            F_Click = "b_click";

            Bundle bundle = new Bundle();
            bundle.putString(B_Request, activityName);
            if (analytics != null) {

                analytics.logEvent(eventName, bundle);
            }
            Log.w("msg", "Admob --- " + eventName + " + " + B_Request + " + " + activityName + " " + admob_back_interestial);
            InterstitialAd.load(context, admob_back_interestial, new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {

                    PreferenceManager.Companion.saveData(context, "adContantShow", false);

                    mAdmobInterstitialAd = interstitialAd;
                    isAdLoading = false;
                    Bundle bundle = new Bundle();
                    bundle.putString(B_Load, activityName);
                    if (analytics != null) {
                        analytics.logEvent(eventName, bundle);
                    }
                    Log.w("msg", "Admob --- " + eventName + " + " + B_Load + " + " + activityName + " " + admob_back_interestial);
                    if (myadfinish1 != null) {
                        myadfinish1.adfinished();
                    }
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    Bundle bundle = new Bundle();
                    bundle.putString(B_Fail_Load, activityName);
                    if (analytics != null) {
                        analytics.logEvent(eventName, bundle);
                    }
                    Log.w("msg", "Admob --- " + eventName + " + " + B_Fail_Load + " + " + activityName + " " + admob_back_interestial + " Error : " + loadAdError.getCode());
                    mAdmobInterstitialAd = null;
                    Log.w("msg", "Admob loadAdmobIntReLload admob_back_interestial onAdFailedToLoad  :" + loadAdError.getCode());
                    isAdLoading = false;
                    PreferenceManager.Companion.saveData(context, "adContantShow", false);
                    if (myadfinish1 != null) {
                        myadfinish1.adfinished();
                    }
                }
            });
        }
    }
}
