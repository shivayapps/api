package com.example.admob.adLoader;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.example.admob.utils.PreferenceManager;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd;
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback;
import com.google.firebase.analytics.FirebaseAnalytics;

public class RewardedInterstrialAdLoader {
    public static RewardedInterstitialAd rewardedInterstitialAd;
    public static boolean isRewardedInterstitialAdLoaded;
    private static String F_Request = "f_request";
    private static String F_Load = "f_load";
    private static String F_Fail_Load = "f_fail_load";
    private static String F_Show = "f_show";
    private static String F_Dismiss = "f_dismiss";
    private static String F_Impression = "f_impression";
    private static String F_Show_Fail = "f_show_fail";
    private static String F_Click = "f_click";


    private static String B_Request = "b_request";
    private static String B_Load = "b_load";
    private static String B_Fail_Load = "b_fail_load";
    private static String eventName = "Admob_RewardInterstitial";

    public static void loadAd(Context context, String rewarded_Ad, String reload_rewarded_Ad, String back_id_required,String activityName,FirebaseAnalytics analytics) {
        Log.w("msg", "RewardedInterstrialAdLoader loadAd");
        loadRewardedVideoAd(context, rewarded_Ad, reload_rewarded_Ad, back_id_required,activityName,analytics);
    }

    public static boolean isAdLoaded() {
        return rewardedInterstitialAd != null;
    }

    public static void showRewardedIntAd(Activity activity, InterstitialAdLoader.adfinishwithControl myadfinish1, String admob_rewared_int, String admob_back_rewared_int, String admob_back_id_required,String activityName,FirebaseAnalytics analytics) {
        if (RewardedInterstrialAdLoader.isAdLoaded()) {
            Log.w("msg", "RewardedInterstrialAdLoader myCrea isAdLoaded if ");
            RewardedInterstrialAdLoader.rewardedInterstitialAd.show(activity, new OnUserEarnedRewardListener() {
                @Override
                public void onUserEarnedReward(@NonNull RewardItem rewardItem) {
                    myadfinish1.adfinished();
                }
            });
            RewardedInterstrialAdLoader.rewardedInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override
                public void onAdFailedToShowFullScreenContent(AdError adError) {
                    PreferenceManager.Companion.saveToShowOpenAd(activity, true);
                    Toast.makeText(activity, "Video AD is not available ... please try again", Toast.LENGTH_LONG).show();
                    myadfinish1.rewaredfailed();
                    Bundle bundle = new Bundle();
                    bundle.putString(F_Show_Fail, activityName);
                    if (analytics != null) {
                        analytics.logEvent(eventName, bundle);
                    }
                    Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + F_Show_Fail + " + " + activityName + " " + " Error : " + adError.getCode());
                    F_Show = "f_show";
                    F_Dismiss = "f_dismiss";
                    F_Impression = "f_impression";
                    F_Show_Fail = "f_show_fail";
                    F_Click = "f_click";
                }

                @Override
                public void onAdShowedFullScreenContent() {
                    PreferenceManager.Companion.saveToShowOpenAd(activity, false);
                    Bundle bundle = new Bundle();
                    bundle.putString(F_Show, activityName);
                    if (analytics != null) {
                        analytics.logEvent(eventName, bundle);
                    }
                    Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + F_Show + " + " + activityName + " ");
                }
                @Override
                public void onAdClicked() {
                    super.onAdClicked();
                    Bundle bundle = new Bundle();
                    bundle.putString(F_Click, activityName);
                    if (analytics != null) {
                        analytics.logEvent(eventName, bundle);
                    }
                    Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + F_Click + " + " + activityName + " ");

                }
                @Override
                public void onAdImpression() {
                    super.onAdImpression();
                    Bundle bundle = new Bundle();
                    bundle.putString(F_Dismiss, activityName);
                    if (analytics != null) {
                        analytics.logEvent(eventName, bundle);
                    }
                    Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + F_Impression + " + " + activityName + " ");
                }


                @Override
                public void onAdDismissedFullScreenContent() {
                    PreferenceManager.Companion.saveToShowOpenAd(activity, true);
                    RewardedInterstrialAdLoader.loadAd(activity, admob_rewared_int,
                        admob_back_rewared_int, admob_back_id_required,activityName,analytics);
                    myadfinish1.adfinished();
                    Bundle bundle = new Bundle();
                    if (analytics != null) {
                        analytics.logEvent(eventName, bundle);
                    }
                    Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + F_Dismiss + " + " + activityName + " ");

                    F_Show = "f_show";
                    F_Dismiss = "f_dismiss";
                    F_Impression = "f_impression";
                    F_Show_Fail = "f_show_fail";
                    F_Click = "f_click";
                }
            });
        } else {
            myadfinish1.rewaredfailed();
        }
    }

    public static void loadRewardedVideoAd(Context context, String rewarded_Ad, String reload_rewarded_Ad, String back_id_required,String activityName,FirebaseAnalytics analytics
    ) {
        Bundle bundle = new Bundle();
        bundle.putString(F_Request, activityName);
        if (analytics != null) {
            analytics.logEvent(eventName, bundle);
        }
        Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + F_Request + " + " + activityName + " " + eventName);
        if (!isAdLoaded()) {
            RewardedInterstitialAd.load(context, rewarded_Ad,
                new AdRequest.Builder().build(), new RewardedInterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(RewardedInterstitialAd ad) {
                        isRewardedInterstitialAdLoaded = true;
                        rewardedInterstitialAd = ad;
                        Bundle bundle = new Bundle();
                        bundle.putString(F_Load, activityName);
                        if (analytics != null) {
                            analytics.logEvent(eventName, bundle);

                        }
                        Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + F_Load + " + " + activityName + " " + eventName);
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        isRewardedInterstitialAdLoaded = false;
                        Bundle bundle = new Bundle();
                        bundle.putString(F_Fail_Load, activityName);
                        if (analytics != null) {
                            analytics.logEvent(eventName, bundle);

                        }
                        Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + F_Fail_Load + " " + loadAdError.getCode() +" "+ activityName + " " + eventName );
                        if (back_id_required.equals("true")) {
                            Log.w("msg", "RewardedInterstrialAdLoader ReLoad " + reload_rewarded_Ad);
                            reloadRewardedVideoAd(context, reload_rewarded_Ad,activityName,analytics);
                        }
                    }
                });
        }
    }

    public static void reloadRewardedVideoAd(Context context, String reload_rewarded_Ad, String activityName, FirebaseAnalytics analytics) {
        Bundle bundle = new Bundle();
        bundle.putString(B_Request, activityName);
        if (analytics != null) {
            analytics.logEvent(eventName, bundle);
        }
        Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + F_Request + " + " + activityName + " " + eventName);
        if (!isAdLoaded()) {
            RewardedInterstitialAd.load(context, reload_rewarded_Ad,
                new AdRequest.Builder().build(), new RewardedInterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(RewardedInterstitialAd ad) {
                        rewardedInterstitialAd = ad;
                        isRewardedInterstitialAdLoaded = true;

                        F_Show = "b_show";
                        F_Dismiss = "b_dismiss";
                        F_Impression = "b_impression";
                        F_Show_Fail = "b_show_fail";
                        F_Click = "b_click";
                        Bundle bundle = new Bundle();
                        bundle.putString(F_Load, activityName);
                        if (analytics != null) {
                            analytics.logEvent(eventName, bundle);

                        }
                        Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + B_Load + " "+ " " + activityName + " " + eventName);
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        Bundle bundle = new Bundle();
                        bundle.putString(B_Fail_Load, activityName);
                        if (analytics != null) {
                            analytics.logEvent(eventName, bundle);

                        }
                        Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + B_Fail_Load + " "+ loadAdError.getCode()+" " + activityName + " " + eventName);


                        isRewardedInterstitialAdLoaded = false;
                    }
                });
        }
    }
}
