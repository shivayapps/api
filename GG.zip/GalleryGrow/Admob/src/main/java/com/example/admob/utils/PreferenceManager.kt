package com.example.admob.utils

import android.content.Context


class PreferenceManager {
    companion object {
        // Constants
        @JvmStatic
        val THEME_PREFS = "THEME_PREFS";
        @JvmStatic
        val SHOW_OPEN_AD = "show_open_ad"
        @JvmStatic
        var SystemDialogOpened = "SystemDialogOpened"

        // By Parth for saving bool shared prefs
        fun saveData(context: Context?, key: String?, value: Boolean?) {
            if (context == null) return
            if (value != null) {
                context.getSharedPreferences(THEME_PREFS, Context.MODE_PRIVATE).edit().putBoolean(key, value).apply()
            }
        }

        fun saveToShowOpenAd(context: Context?, value: Boolean?) {
            saveData(context, SHOW_OPEN_AD, value)
        }


        fun getBooleanData(context: Context?, key: String?): Boolean {
            return try {
                context?.getSharedPreferences("THEME_PREFS", Context.MODE_PRIVATE)?.getBoolean(key, false) ?: false
            } catch (e: Exception) {
                false
            }
        }

        fun getBooleanData(context: Context?, key: String?, defValue: Boolean?): Boolean {
            return try {
                context?.getSharedPreferences("THEME_PREFS", Context.MODE_PRIVATE)?.getBoolean(key, defValue!!) ?: false
            } catch (e: Exception) {
                false
            }
        }
    }
}
