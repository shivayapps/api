package com.gallery.photo.image.video.notes

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.SearchView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.gallery.photo.image.video.notes.adapter.NotesAdapter
import com.gallery.photo.image.video.notes.database.NotesDataBase
import com.gallery.photo.image.video.notes.entities.Notes
import com.gallery.photo.image.video.databinding.ActivityNotesBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Locale

class NotesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNotesBinding
    var arrNotes = ArrayList<Notes>()
    var notesAdapter: NotesAdapter = NotesAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNotesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recyclerView.setHasFixedSize(true)
        binding.recyclerView.layoutManager = StaggeredGridLayoutManager(
            2,
            StaggeredGridLayoutManager.VERTICAL
        )


        initNotes()

        notesAdapter!!.setOnClickListener(onClicked)


        // Find View By ID
//        val fabCreateNoteBtn = findViewById<FloatingActionButton>(R.id.fabCreateNoteBtn)

        // FAB CREATE NOTE FRAGMENT
        binding.fabCreateNoteBtn.setOnClickListener {
            activityLauncher.launch(Intent(this, CreateNoteActivity::class.java))
        }

        binding.icBack.setOnClickListener {
            onBackPressed()
        }

        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener,
            androidx.appcompat.widget.SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(p0: String?): Boolean {
                return true
            }

            override fun onQueryTextChange(p0: String?): Boolean {

                var tempArr = ArrayList<Notes>()

                for (arr in arrNotes) {
                    if (arr.title!!.toLowerCase(Locale.getDefault()).contains(p0.toString())) {
                        tempArr.add(arr)
                    }
                }
                notesAdapter.setData(tempArr)
                notesAdapter.notifyDataSetChanged()
                return true
            }

        })

        supportActionBar?.hide()
//        replaceFragment(HomeFragment.newInstance(),true)
    }

    private fun initNotes() {
//        CoroutineScope(Dispatchers.IO).launch {
//
//        }
        val notes = NotesDataBase.getDataBase(this@NotesActivity).noteDao().getAllNotes()
        notesAdapter.setData(notes)
        arrNotes = notes as ArrayList<Notes>
        binding.recyclerView.adapter = notesAdapter

    }

    var activityLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            initNotes()
        }

    private val onClicked = object : NotesAdapter.onItemClickListener {
        override fun onClicked(notesId: Int) {
            startActivity(
                Intent(
                    this@NotesActivity,
                    CreateNoteActivity::class.java
                ).putExtra("noteId", notesId)
            )
//            var fragment : Fragment
//            var bundle = Bundle()
//            bundle.putInt("noteId", notesId)
//            fragment = CreateNoteFragment.newInstance()
//            fragment.arguments = bundle
//
//            replaceFragment(fragment,true)
        }

    }

//    fun replaceFragment(fragment: Fragment, istransition: Boolean) {
//
//        val fragmentTransition = supportFragmentManager.beginTransaction()
//
//        if (istransition) {
//            fragmentTransition.setCustomAnimations(
//                android.R.anim.slide_out_right,
//                android.R.anim.slide_in_left
//            )
//        }
//        fragmentTransition.replace(R.id.flFragmenet, fragment).addToBackStack(fragment.javaClass.simpleName)
//        fragmentTransition.commit()
//    }


}