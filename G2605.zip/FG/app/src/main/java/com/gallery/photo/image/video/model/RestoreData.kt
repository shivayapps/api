package com.gallery.photo.image.video.model

data class RestoreData(var path: String, var deletedPath: String)