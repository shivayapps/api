package com.gallery.photo.image.video.activities

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.PorterDuff
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.PopupWindow
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.adapter.AlbumAdapter
import com.gallery.photo.image.video.base.BaseActivity
import com.gallery.photo.image.video.customview.MyGridLayoutManager
import com.gallery.photo.image.video.customview.MyRecyclerView
import com.gallery.photo.image.video.database.AppDatabase
import com.gallery.photo.image.video.databinding.ActivityVideoAlbumBinding
import com.gallery.photo.image.video.model.AlbumData
import com.gallery.photo.image.video.model.PictureData
import com.gallery.photo.image.video.utils.Preferences
import com.gallery.photo.image.video.databinding.PopBottomMenuBinding
import com.gallery.photo.image.video.dialog.AlbumDetailsDialog

import com.gallery.photo.image.video.dialog.ConfirmationDialog
import com.gallery.photo.image.video.dialog.CreateAlbumDialog
import com.gallery.photo.image.video.dialog.DeleteDialog
import com.gallery.photo.image.video.dialog.DisplayedColumnsDialog
import com.gallery.photo.image.video.dialog.FilterMediaDialog
import com.gallery.photo.image.video.dialog.GroupDialog

import com.gallery.photo.image.video.dialog.MainMenuDialog
import com.gallery.photo.image.video.dialog.ProgressDialog
import com.gallery.photo.image.video.dialog.RenameFolderDialog
import com.gallery.photo.image.video.dialog.SelectAlbumDialog
import com.gallery.photo.image.video.dialog.SelectAlbumFullDialog
import com.gallery.photo.image.video.dialog.SelectAlbumImageFullDialog
import com.gallery.photo.image.video.dialog.SortDialog
import com.gallery.photo.image.video.event.CopyMoveEvent
import com.gallery.photo.image.video.event.DeleteEvent
import com.gallery.photo.image.video.event.DisplayDeleteEvent
import com.gallery.photo.image.video.event.RenameEvent
import com.gallery.photo.image.video.event.RestoreDataEvent
import com.gallery.photo.image.video.event.UpdateFavoriteEvent
import com.gallery.photo.image.video.extension.beGone
import com.gallery.photo.image.video.extension.beVisible
import com.gallery.photo.image.video.extension.beVisibleIf
import com.gallery.photo.image.video.extension.getParentFolder
import com.gallery.photo.image.video.extension.toast
import com.gallery.photo.image.video.utils.AdCache
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.MAX_COLUMN_COUNT_ALBUM
import com.gallery.photo.image.video.utils.PopupWindowHelper
import com.gallery.photo.image.video.utils.TYPE_GIFS
import com.gallery.photo.image.video.utils.TYPE_IMAGES
//import com.gallery.photo.image.video.utils.TYPE_PORTRAITS
//import com.gallery.photo.image.video.utils.TYPE_RAWS
//import com.gallery.photo.image.video.utils.TYPE_SVGS
import com.gallery.photo.image.video.utils.TYPE_VIDEOS
import com.gallery.photo.image.video.utils.Utils
import com.gallery.photo.image.video.utils.photoExtensions
import com.gallery.photo.image.video.utils.rawExtensions
import com.gallery.photo.image.video.utils.videoExtensions

import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File
import kotlin.math.max
import kotlin.math.min

class VideoAlbumActivity : BaseActivity() {

    var albumList: ArrayList<AlbumData> = ArrayList()
    var videoList: ArrayList<PictureData> = ArrayList()

    var albumWisePictures = LinkedHashMap<String, ArrayList<PictureData>>()
    var albumAdapter: AlbumAdapter? = null
    lateinit var preferences: Preferences
    var albumCount = 0

    private var lastLongPressedItem = -1
    var selectedItem = 0
    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mDragListener: MyRecyclerView.MyDragListener? = null

    lateinit var activity: AppCompatActivity

    lateinit var binding: ActivityVideoAlbumBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        if(preferences.isNeedInterAd) {
            AdmobIntersAdImpl().load(this)
        }
        binding = ActivityVideoAlbumBinding.inflate(layoutInflater)
        setContentView(binding.root)
        loadBanner()
        activity = this@VideoAlbumActivity
//        EventBus.getDefault().register(this)
        initView()
    }

    private fun initView() {
        if (intent.hasExtra("title")) {
            binding.txtTitle.text = intent.getStringExtra("title")
        }

        getData()
        binding.swipeRefreshLayout.setOnRefreshListener {
            if (binding.swipeRefreshLayout.isEnabled)
                getData()
            else
                binding.swipeRefreshLayout.isRefreshing = false
        }

        intListener()
    }

    var isAdLoaded=false
    var mAdView: AdView?=null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }
    private fun loadBanner() {
        if (!isAdLoaded) {
            val isFirstSession = preferences.splashCounter == 1
            val adId = getString(R.string.b_albumActivity)
            BannerAdHelper.showBanner(this, binding.layoutBanner.mFLAd, binding.llAdplace, adId,
                AdCache.albumAdView, { isLoaded, adView, message ->
                    mAdView = adView
                    AdCache.albumAdView = adView
                    isAdLoaded = isLoaded
                })
        }
    }

    private fun intListener() {

        binding.icBack.setOnClickListener {
            onBackPressed()
        }

        binding.icMenu.setOnClickListener {
            showMenu()
        }

        binding.icClose.setOnClickListener {
            setCloseToolbar()
        }
        binding.icSelect.setOnClickListener {
            isSelectAll = !isSelectAll

            setSelectClick(isSelectAll)
            setSelectAllColor()
        }

        binding.btnDelete.setOnClickListener {
            showDeleteDialog()
        }
        binding.btnHide.setOnClickListener {
//            if (binding.viewPager.currentItem == 1)
                setHideData()
        }

        binding.btnMore.setOnClickListener {
//            showMoreMenu()
            showDropDown(binding.btnMore)
        }
    }

    fun setHideData() {
        if (selectedItem == 0) {
            Toast.makeText(
                activity,
                activity.getString(R.string.PleaseSelectImage),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            val hideDialog = ConfirmationDialog(
                activity,
                getString(R.string.Private),
                getString(R.string.hide_msg),
                getString(R.string.hide),
                positiveBtnClickListener = {
                    hidePhoto()
                })
            hideDialog.show(supportFragmentManager, hideDialog.tag)
        }
    }

    private fun hidePhoto() {
        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in albumList.indices) {
            if (albumList[i] != null)
                if (albumList[i].isSelected) {
                    val pictureList = albumList[i].pictureData
                    selectImage.addAll(pictureList)
                }
        }

        Utils.hideFiles(activity, selectImage, selectedItem, hideListener = {
            Toast.makeText(
                activity,
                getString(R.string.hide_successfully),
                Toast.LENGTH_SHORT
            ).show()
            selectedItem = 0
            longClickListener(false, 0, false)
            setCloseToolbar()
        })
    }

    override fun onDestroy() {
        super.onDestroy()
//        EventBus.getDefault().unregister(this)
    }


    private fun showMenu() {
        val dialog = MainMenuDialog(clickListener = {
            when (it) {
                1 -> {//btnSortBy
                    showSortDialog()
                }

                2 -> {//btnGroup
                    showGroupByDialog()
                }

                3 -> {//btnFilterMedia

                    val filterMediaDialog = FilterMediaDialog(updateListener = {
                        getData()
                    })
                    filterMediaDialog.show(supportFragmentManager, filterMediaDialog.tag)
                }

                4 -> {
                    // displayed Columns
                    val displayColumnsDialog = DisplayedColumnsDialog("",
                        true,
                        updateListener = {
                            setRvLayoutManager()
                        })
                    displayColumnsDialog.show(supportFragmentManager, displayColumnsDialog.tag)
                }

                5 -> {
                    startActivity(Intent(this, RecentlyDeleteActivity::class.java))
                }

                6 -> {
                    settingLauncher.launch(Intent(this, SettingActivity::class.java))
                }
            }
        })
        dialog.show(supportFragmentManager, dialog.tag)
    }

    private fun showSortDialog() {
        val sortDialog = SortDialog(updateListener = {
            getData()
        })
        sortDialog.show(supportFragmentManager, sortDialog.tag)
    }

    private fun showGroupByDialog() {
        val groupDialog = GroupDialog(updateListener = {
            getData()
        })
        groupDialog.show(supportFragmentManager, groupDialog.tag)
    }

    private fun showDropDown(view: View) {

        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopBottomMenuBinding.inflate(layoutInflater)
        val popupWindow =
            com.gallery.photo.image.video.utils.PopupWindowHelper(popUpBinding.root)

        popUpBinding.menuRename.beVisibleIf(mSelectedItem == 1)
        popUpBinding.menuCover.beVisibleIf(mSelectedItem == 1)

        popUpBinding.menuEdit.beGone()
        popUpBinding.menuSetAs.beGone()
        popUpBinding.menuResize.beGone()
        popUpBinding.menuExclude.beVisible()


        popUpBinding.menuAddFavourite.beGone()
        popUpBinding.menuRemoveFavourite.beGone()

        popUpBinding.menuInfo.beVisibleIf(mSelectedItem == 1)

        popUpBinding.loutMain.setOnClickListener {
            popupWindow.dismiss()
        }

        popUpBinding.menuRename.setOnClickListener {
            popupWindow.dismiss()
            showRenameDialog()
        }

        popUpBinding.menuCover.setOnClickListener {
            popUpBinding.llMain.beGone()
            popUpBinding.llCover.beVisible()
//            popupWindow.update()
            popupWindow.dismiss()
            popupWindow.showAsPopUp(view)

        }
        popUpBinding.selectPhoto.setOnClickListener {
            popupWindow.dismiss()
            if (mSelectedItem == 1) setCoverImage()

        }
        popUpBinding.useDefault.setOnClickListener {
            popupWindow.dismiss()
            if (mSelectedItem == 1) setDefaultCoverImage()
        }


        popUpBinding.menuExclude.setOnClickListener {
            popupWindow.dismiss()
            addToExclude()
        }


        popUpBinding.menuInfo.setOnClickListener {
            popupWindow.dismiss()
            showDetailsDialog()
        }

        popUpBinding.menuCopy.setOnClickListener {
            popupWindow.dismiss()
            showAddAlbumDialog(
                Constant.deviceAlbumList,
//                albumList.filter { it.isCustomAlbum == false } as ArrayList<AlbumData>,
                true
            )
        }

        popUpBinding.menuMove.setOnClickListener {
            popupWindow.dismiss()
            showAddAlbumDialog(
                Constant.deviceAlbumList,
//                albumList.filter { it.isCustomAlbum == false } as ArrayList<AlbumData>,
                false
            )
        }
        popupWindow.showAsPopUp(view)

    }

    fun showDetailsDialog() {
        val albumData = albumList.filter { it.isSelected }
        val detailsDialog =
            AlbumDetailsDialog(albumData[0], false)
        detailsDialog.show(supportFragmentManager, detailsDialog.tag)
    }
    fun setDefaultCoverImage() {
        val albumData = albumList.firstOrNull { it.isSelected }
        preferences?.setCoverImage(albumData!!.folderPath, "")
        setCloseToolbar()
    }

    fun setCoverImage() {
        val albumData = albumList.firstOrNull { it.isSelected }

        val addAlbumDialog =
            SelectAlbumImageFullDialog(
                activity!!,
                albumData!!.pictureData,
                selectPathListener = { selectPath ->
                    preferences?.setCoverImage(albumData.folderPath, selectPath)
                    //setCopyMove(isCopy, selectPath, selectImage)
                    setCloseToolbar()
                },
                createAlbumListener = {

                })
        addAlbumDialog.show(supportFragmentManager, addAlbumDialog.tag)

    }

//    fun tryUnLockFolder() {
//        unlockFolder()
//    }
//
//    fun tryLockFolder() {
//        lockFolder()
//    }
//
//    private fun lockFolder() {
//
//        val albumData = albumList.filter { it.isSelected }
//
//        val paths: ArrayList<String> = ArrayList()
//        paths.addAll(albumData.map { it.folderPath })
//        paths.filter { !preferences.isFolderProtected(it) }.forEach {
//            preferences.addFolderProtection(it)
//        }
//        setCloseToolbar()
//
//    }

//    private fun unlockFolder() {
//        lockOperation = 2
//
//        lockedAlbumAlbumList = albumList.filter { it.isSelected } as ArrayList<AlbumData>
//        val intent = Intent(activity, LockActivity::class.java)
//        intent.putExtra(Constant.EXTRA_IS_OPEN_ALBUM, true)
//        lockActivityResultLauncher.launch(intent)
//
//    }

    fun setSelectClick(isSelectAll: Boolean) {
//        if (isSelectAll) {
        var selected = 0
        for (i in albumList.indices) {
            if (albumList[i] != null)
                if (albumList[i] is AlbumData) {
                    val model = albumList[i] as AlbumData
                    if(!model.isCustomAlbum) {
                        model.isSelected = isSelectAll
                        if (isSelectAll)
                            selected++
                    }
                }
        }
        notifyAdapter()
        longClickListener(true, selected, isSelectAll)
        selectedItem = selected
//        } else {
//            longClickListener(false, 0, false)
//            setClose()
//        }
    }

    fun getData() {
        disableScroll()
        binding.swipeRefreshLayout.isRefreshing = true
        Observable.fromCallable {
            getImages()
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    setFilterData()
                    getAlbumCount()
                }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    setFilterData()
                    getAlbumCount()
                }
            }
    }

    private fun getAlbumCount() {
//        albumCountListener(albumList.size)
    }

    private fun getImages() {
        albumList.clear()
        videoList.clear()

//        albumBackupList.clear()
        albumWisePictures.clear()
        activity.runOnUiThread { if (albumAdapter != null) albumAdapter!!.notifyDataSetChanged() }

        val folderList: MutableList<String> = ArrayList()
        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())

        val excludeList: ArrayList<String> = ArrayList()
        excludeList.addAll(preferences.getExcludeList())


        albumCount = 0

        getVideos()
    }

    private fun getVideos() {
        var title: String
        var path: String
        val duration: Int
        val folderList: MutableList<String> = ArrayList<String>()
        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())
//        folderList.addAll(preferencesManager.getExcludeFolderList())
        val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Video.VideoColumns.DATA,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.VideoColumns.SIZE,
            MediaStore.Video.VideoColumns.DURATION,
            MediaStore.Video.VideoColumns.DATE_MODIFIED,
            MediaStore.Video.VideoColumns.DATE_TAKEN,
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
        )
        val filterMedia = preferences.getFilterMedia()
        val selection = getSelectionQuery(filterMedia)
        val selectionArgs = getSelectionArgsQuery(filterMedia).toTypedArray()

        val excludeList: ArrayList<String> = ArrayList()
        excludeList.addAll(preferences.getExcludeList())

        try {
            val cursor = contentResolver.query(
                uri,
                projection,
                selection,
                selectionArgs,
                MediaStore.Video.VideoColumns.DATE_MODIFIED + " DESC"
            )
            if (cursor != null) {
                duration = cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DURATION)
                cursor.moveToFirst()
                while (!cursor.isAfterLast) {

                    path =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA))
                    title =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME))
                    var bucketName =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME))
                    if (bucketName == null) bucketName = path.getParentFolder()

                    val bucketPath = path.substring(0, path.lastIndexOf(title) - 1)

                    var excluded = false
                    excluded = excludeList.any { bucketPath.startsWith(it) }

                    if (!folderList.contains(bucketPath) && !excluded) {
                        var d =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DATE_MODIFIED))
                        d *= 1000
                        var dt =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))
                        dt *= 1000
                        if (dt == 0L)
                            dt = d
                        val fileSizeLength =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
//                        val pictureData = PictureData()
                        val pictureData = PictureData(
                            path,
                            title,
                            bucketName,
                            d,
                            dt,
                            fileSizeLength,
                            true,
                            cursor.getLong(duration)
                        )
                        pictureData.isVideo = true
                        pictureData.isFavorite = favList.contains(path)
                        pictureData.bucketPath = bucketPath

                        val imagesData2: ArrayList<PictureData> = ArrayList()

                        if (albumWisePictures.containsKey(bucketPath)) {
                            val list2: ArrayList<PictureData>? = albumWisePictures[bucketPath]
                            if (list2 != null)
                                imagesData2.addAll(list2)
                        }
                        imagesData2.add(pictureData)
                        videoList.add(pictureData)
                        albumWisePictures[bucketPath] = imagesData2
                    }
                    cursor.moveToNext()
                }
                cursor.close()
            }
        } catch (exp: Exception) {
            exp.printStackTrace()
        }
        val folderKeys: Set<String> = albumWisePictures.keys
        val listFolderkeys = java.util.ArrayList(folderKeys)

//        albumList.add("More Album")
        for (i in listFolderkeys.indices) {
            val imagesData: java.util.ArrayList<PictureData> = ArrayList()
            val list = albumWisePictures[listFolderkeys[i]]
            if (list != null)
                imagesData.addAll(list)

            if (imagesData.size != 0 && imagesData[0].folderName.isNotEmpty()) {
                val albumData = AlbumData()
                albumCount++
                albumData.title = imagesData[0].folderName
                albumData.pictureData = imagesData

                val folderPath = listFolderkeys[i]
                albumData.folderPath = folderPath
                val file = File(folderPath)
                albumData.date = file.lastModified()
                albumData.fileSize = file.length()
                albumList.add(albumData)
//                albumBackupList.add(albumData)
            }
        }
    }

    private fun getSelectionQuery(filterMedia: Int): String {
        val query = StringBuilder()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")

            rawExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }

//        if (filterMedia and TYPE_RAWS != 0) {
//            rawExtensions.forEach {
//                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//            }
//        }

//        if (filterMedia and TYPE_SVGS != 0) {
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//        }
//        if (filterMedia and TYPE_PORTRAITS != 0) {
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
        }


        if (filterMedia and TYPE_GIFS != 0) {
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }


        return query.toString().trim().removeSuffix("OR")
    }

    private fun getSelectionArgsQuery(filterMedia: Int): ArrayList<String> {
        val args = ArrayList<String>()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.jpg")
            args.add("%.jpeg")
            rawExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.svg")
        }

//        if (filterMedia and TYPE_RAWS != 0) {
//            rawExtensions.forEach {
//                args.add("%$it")
//            }
//        }
//
//        if (filterMedia and TYPE_SVGS != 0) {
//            args.add("%.svg")
//        }
//        if (filterMedia and TYPE_PORTRAITS != 0) {
//            args.add("%.jpg")
//            args.add("%.jpeg")
//        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                args.add("%$it")
            }
        }

        if (filterMedia and TYPE_GIFS != 0) {
            args.add("%.gif")
        }


        return args
    }

    private fun disableScroll() {
        binding.albumRecycler.suppressLayout(true)
    }

    private fun enableScroll() {
        binding.albumRecycler.suppressLayout(false)
    }

    fun setFilterData() {
        disableScroll()
        binding.swipeRefreshLayout.isRefreshing = true
        GlobalScope.launch(Dispatchers.IO) {
            sortAlbumMain()
//            sortPhotos()

            if (videoList.size > 0) {
                albumList.add(
                    0,
                    AlbumData(
                        getString(R.string.all_videos),
                        pictureData = videoList,
                        isCustomAlbum = true
                    )
                )
            }

            activity.runOnUiThread {
                setData()
            }
        }

    }

    private fun sortAlbumMain() {
        val sortType = preferences.getAlbumSortType()
        val sortOrder = preferences.getAlbumSortOrder()

        albumList.sortWith(Comparator { p1, p2 ->
            if (sortType == Constant.SORT_NAME) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.title.compareTo(p2.title, true)
                else
                    p2.title.compareTo(p1.title, true)
            } else if (sortType == Constant.SORT_PATH) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.folderPath.compareTo(p2.folderPath, true)
                else
                    p2.folderPath.compareTo(p1.folderPath, true)
            } else if (sortType == Constant.SORT_SIZE) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.fileSize.compareTo(p2.fileSize)
                else
                    p2.fileSize.compareTo(p1.fileSize)
            } else if (sortType == Constant.SORT_LAST_MODIFIED) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.date.compareTo(p2.date)
                else
                    p2.date.compareTo(p1.date)
            } else if (sortType == Constant.SORT_DATE_TAKEN) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.date.compareTo(p2.date)
                else
                    p2.date.compareTo(p1.date)
            } else
                p2.date.compareTo(p1.date)
        })


    }

    private fun setData() {
        binding.swipeRefreshLayout.isRefreshing = false
        enableScroll()
        if (albumAdapter != null) albumAdapter!!.notifyDataSetChanged() else initAdapter()
        setEmptyData()
    }

    private fun setEmptyData() {
        if (albumList != null && albumList.size != 0) {
            binding.albumRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
            binding.layoutBottomAd.beVisible()
        } else {
            binding.albumRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
            binding.layoutBottomAd.beGone()
        }
    }

    private fun initAdapter() {
        setRvLayoutManager()

        albumAdapter = AlbumAdapter(activity, albumList,
            clickListener = {
                val albumData = albumList[it]
                if (albumData.isCheckboxVisible) {
                    if (!albumData.isCustomAlbum) {
                        albumData.isSelected = !albumData.isSelected
                        albumAdapter?.notifyItemChanged(it)
                        setSelectedFile()
                    }
                } else {
                    if (albumData.isCustomAlbum) {
//                        if (albumData.pictureData.size != 0) {
                            openImageList(albumData)
//                        } else {
//                            startActivity(Intent(activity, MediaActivity::class.java))
//                        }

                    } else {
                        openImageList(albumData)
                    }
                }
            },
            longClickListener = {
                if (!albumList[it].isCustomAlbum) {
                    lastLongPressedItem = it
                    binding.albumRecycler.setDragSelectActive(it)
                    lastLongPressedItem = if (lastLongPressedItem == -1) {
                        it
                    } else {
                        val min = min(lastLongPressedItem, it)
                        val max = max(lastLongPressedItem, it)
                        for (i in min..max) {
                            toggleItemSelection(true, i, false)
                        }
//                    updateTitle()
                        it
                    }

                    if (albumList[it] is AlbumData) {
                        val pictureData = albumList[it] as AlbumData
                        for (i in albumList.indices) {
                            if (albumList[i] != null) {
                                val model = albumList[i] as AlbumData
                                model.isCheckboxVisible = true
                            }
                        }
                        pictureData.isCheckboxVisible = true
                        pictureData.isSelected = true
                        notifyAdapter()
                        setSelectedFile()
                    }
                }
            })

        albumAdapter?.pinList?.clear()
        binding.albumRecycler.adapter = albumAdapter

        initZoomListener()
        setupZoomListener(mZoomListener)
        initDragListener()
        setupDragListener(mDragListener)
    }


//    var lockOperation: Int = 0 //0=Open, 1=Lock, 2=Unlock
//    var lockedAlbumData: AlbumData? = null
//    var lockedAlbumAlbumList: ArrayList<AlbumData> = ArrayList()
//    var lockActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
//        ActivityResultContracts.StartActivityForResult()
//    ) { result: ActivityResult ->
//        if (result.resultCode == Activity.RESULT_OK) {
//
//            if (lockedAlbumData != null && lockOperation == 0) {
//                Constant.albumData = AlbumData(
//                    lockedAlbumData!!.title,
//                    lockedAlbumData!!.pictureData,
//                    lockedAlbumData!!.folderPath,
//                    lockedAlbumData!!.date,
//                    lockedAlbumData!!.fileSize
//                )
//                startActivity(Intent(activity, ImageListActivity::class.java))
//                setBackAlbumData()
//            } else if (lockOperation == 1) {
//                setCloseToolbar()
//            } else if (lockOperation == 2) {
//                val paths: ArrayList<String> = ArrayList()
//                paths.addAll(lockedAlbumAlbumList.map { it.folderPath })
//                paths.filter { preferences.isFolderProtected(it) }.forEach {
//                    preferences.removeFolderProtection(it)
//                }
//                setCloseToolbar()
//            }
//
//        }
//    }

    public fun openImageList(albumData: AlbumData) {
//        if (preferences.isFolderProtected(albumData.folderPath)) {
//            lockedAlbumData = albumData
//            val intent = Intent(activity, LockActivity::class.java)
//            intent.putExtra(Constant.EXTRA_IS_OPEN_ALBUM, true)
////            intent.putExtra(Constant.EXTRA_CHANGE_PASS, true)
//            lockActivityResultLauncher.launch(intent)
//        } else {

            Constant.albumData = AlbumData(
                albumData.title,
                albumData.pictureData,
                albumData.folderPath,
                albumData.date,
                albumData.fileSize
            )
            startActivity(Intent(activity, ImageListActivity::class.java))
            setBackAlbumData()
//        }

//        Constant.albumData = AlbumData(
//            albumData.title,
//            albumData.pictureData,
//            albumData.folderPath,
//            albumData.date,
//            albumData.fileSize
//        )
//        startActivity(Intent(activity, ImageListActivity::class.java))
//        setBackAlbumData()
    }


    public fun setBackAlbumData() {
        Constant.albumList.clear()
        for (albumData in albumList) {
            Constant.albumList.add(
                AlbumData(
                    albumData.title,
                    albumData.pictureData,
                    albumData.folderPath,
                    albumData.date,
                    albumData.fileSize
                )
            )
        }
    }

    private fun setSelectedFile() {
        var selected = 0
        var allItemCount = 0
        var currentHeaderPos = -1
        var photosCount = 0
        var photosSelectCount = 0

        for (i in albumList.indices) {
            if (albumList[i] is AlbumData) {
                val model = albumList[i] as AlbumData
                allItemCount++
                photosCount++
                if (model.isSelected) {
                    selected++
                    photosSelectCount++
                }
            }
        }

        longClickListener(true, selected, allItemCount == selected)
        binding.swipeRefreshLayout.isEnabled = false
//        binding.swipeRefreshLayout.isEnabled = selected == 0
        selectedItem = selected
    }

    private fun notifyAdapter() {
        if (albumAdapter != null)
            albumAdapter?.notifyDataSetChanged()
//binding.pictureRecycler.post { pictureAdapter?.notifyDataSetChanged() }
    }

    private fun initZoomListener() {
        val isGridShow = preferences.getShowGrid()
        if (isGridShow) {
            val layoutManager = binding.albumRecycler.layoutManager as MyGridLayoutManager
            mZoomListener = object : MyRecyclerView.MyZoomListener {
                override fun zoomIn() {
                    if (layoutManager.spanCount > 2) {
                        reduceColumnCount()
//                        getRecyclerAdapter()?.finishActMode()
                    }
                }

                override fun zoomOut() {
                    if (layoutManager.spanCount < MAX_COLUMN_COUNT_ALBUM) {
                        increaseColumnCount()
//                        getRecyclerAdapter()?.finishActMode()
                    }
                }
            }
        } else {
            mZoomListener = null
        }
    }

    fun setupZoomListener(zoomListener: MyRecyclerView.MyZoomListener?) {
        binding.albumRecycler.setupZoomListener(zoomListener)
    }

    private fun initDragListener() {
//        val isGridShow = preferences.getShowGrid()
//        if (isGridShow) {
//            val layoutManager = binding.pictureRecycler.layoutManager as MyGridLayoutManager

        mDragListener = object : MyRecyclerView.MyDragListener {

            override fun selectItem(position: Int) {
                toggleItemSelection(true, position, true)
            }

            override fun selectRange(
                initialSelection: Int,
                lastDraggedIndex: Int,
                minReached: Int,
                maxReached: Int
            ) {
                selectItemRange(
                    initialSelection,
                    Math.max(0, lastDraggedIndex),
                    Math.max(0, minReached),
                    maxReached
                )
                if (minReached != maxReached) {
                    lastLongPressedItem = -1
                }
            }

        }
//        } else {
//            mDragListener = null
//        }
    }

    fun setupDragListener(dragListener: MyRecyclerView.MyDragListener?) {
        binding.albumRecycler.setupDragListener(dragListener)
    }

    protected fun selectItemRange(from: Int, to: Int, min: Int, max: Int) {
        if (from == to) {
            (min..max).filter { it != from }.forEach { toggleItemSelection(false, it, true) }
            return
        }

        if (to < from) {
            for (i in to..from) {
                toggleItemSelection(true, i, true)
            }

            if (min > -1 && min < to) {
                (min until to).filter { it != from }
                    .forEach { toggleItemSelection(false, it, true) }
            }

            if (max > -1) {
                for (i in from + 1..max) {
                    toggleItemSelection(false, i, true)
                }
            }
        } else {
            for (i in from..to) {
                toggleItemSelection(true, i, true)
            }

            if (max > -1 && max > to) {
                (to + 1..max).filter { it != from }
                    .forEach { toggleItemSelection(false, it, true) }
            }

            if (min > -1) {
                for (i in min until from) {
                    toggleItemSelection(false, i, true)
                }
            }
        }
    }

    protected fun toggleItemSelection(select: Boolean, pos: Int, updateTitle: Boolean = true) {

        if (albumList[pos] is AlbumData) {
            if (select && !albumList[pos].isCustomAlbum) {
                albumList[pos].isSelected = true
//                albumList[pos].isCheckboxVisible = true
//                selectedKeys.add(itemKey)
            } else {
                albumList[pos].isSelected = false
//                albumList[pos].isCheckboxVisible = true
//                selectedKeys.remove(itemKey)
            }
        }

        albumAdapter?.notifyItemChanged(pos)
        setSelectedFile()
    }

    private fun reduceColumnCount() {
        val selectedGrid = preferences.getAlbumGridCount()
        if (selectedGrid > 2) {
            preferences.setAlbumGridCount(selectedGrid - 1)
        }
        setColumnView()
    }


    private fun setColumnView() {
        (binding.albumRecycler.layoutManager as MyGridLayoutManager).spanCount =
            preferences.getAlbumGridCount()
        albumAdapter?.apply {
            notifyItemRangeChanged(0, albumList.size)
        }
        setRvLayoutManager()
    }

    private fun increaseColumnCount() {
        val selectedGrid = preferences.getAlbumGridCount()
        if (selectedGrid < MAX_COLUMN_COUNT_ALBUM) {
            preferences.setAlbumGridCount(selectedGrid + 1)
        }
        setColumnView()
    }

    fun setCloseToolbar() {
        setClose()
        longClickListener(false, 0, false)
    }

    override fun onBackPressed() {
        if (binding.groupToolbarSelectHeader.visibility == View.VISIBLE) {
            setCloseToolbar()
        } else {
            if (preferences.isNeedInterAd) {

                AdsConfig.showInterstitialAd(this@VideoAlbumActivity) {
                    if(it) preferences.isNeedInterAd = false
                    finish()
                }
            } else {
                super.onBackPressed()
            }
        }
    }

    var isSelectAll = false
    var mSelectedItem = 0
    private fun longClickListener(
        isShowSelection: Boolean,
        selectedItem: Int,
        isAllSelect: Boolean
    ) {
        preferences.refreshMedia = true
        mSelectedItem = selectedItem
        binding.loutToolbar.visibility = View.VISIBLE
        if (isShowSelection) {
//            binding.btnUnhide.visibility = if (binding.viewPager.currentItem == 2) View.VISIBLE else View.GONE
//            binding.btnHide.visibility = if (binding.viewPager.currentItem == 2) View.GONE else View.VISIBLE
//            binding.btnMore.visibility = if (binding.viewPager.currentItem == 2) View.GONE else View.VISIBLE
//            binding.btnPin.visibility = if (binding.viewPager.currentItem == 0) View.VISIBLE else View.GONE
//            binding.btnShare.visibility = if (binding.viewPager.currentItem == 0) View.GONE else View.VISIBLE

        }

        binding.groupToolbarSelectHeader.visibility =
            if (isShowSelection) View.VISIBLE else View.GONE

//        binding.viewPager.setPagingEnabled(!isShowSelection)
        isSelectAll = isAllSelect

        binding.loutSelectOption.visibility =
            if (isShowSelection && selectedItem != 0) View.VISIBLE else View.GONE

//        if (binding.viewPager.currentItem == 2) {
//            binding.groupToolbarSettingHeader.visibility = View.GONE
//            binding.groupToolbarHeaderPrivate.visibility = if (isShowSelection) View.GONE else View.VISIBLE
//        } else
        binding.groupToolbarHeader.visibility =
            if (isShowSelection) View.GONE else View.VISIBLE

//        binding.cardLoutTab.visibility = if (isShowSelection) View.GONE else View.VISIBLE
        binding.txtSelectCount.text = "$selectedItem ${getString(R.string.items_selected)}"
        setSelectAllColor()
    }

    private fun setSelectAllColor() {
        val color =
            ContextCompat.getColor(this, if (isSelectAll) R.color.black else R.color.un_check_color)
        binding.icSelect.setColorFilter(color, PorterDuff.Mode.SRC_IN)
    }

    private fun setClose() {
        Log.e("", "setClose==>> pictures size ${albumList.size} ")
        for (i in albumList.indices) {
            if (albumList[i] != null)
                if (albumList[i] is AlbumData) {
                    val model = albumList[i] as AlbumData
                    model.isSelected = false
                    model.isCheckboxVisible = false
                    Log.e("", "setClose==>> AlbumData selection false")
                }
        }
        binding.swipeRefreshLayout.isEnabled = true
//        setRvLayoutManager()
//        notifyAdapter()
        setRvLayoutManager()
        getData()
        selectedItem = 0
    }

    @SuppressLint("CheckResult")
    private fun deletePhoto(isPermanent: Boolean) {
        val deleteList = ArrayList<String>()

        val progressDialog = ProgressDialog(
            activity,
            R.drawable.ic_drawer_delete,
            selectedItem,
            getString(R.string.Deleting),
            ""
        )
        progressDialog.isCancelable = false
        progressDialog.show(supportFragmentManager,progressDialog.tag)

        preferences.refreshMedia = true
        preferences.scanMedia = true

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(activity)

            for (a in albumList.indices) {
                if (albumList[a].isSelected) {

//                    activity.runOnUiThread {
//                        bindingDialog.txtTitle.text = albumList[a].folderPath
//                    }
                    val pictures = albumList[a].pictureData
                    for (i in pictures.indices) {
                        if (pictures[i] != null) if (pictures[i] is PictureData) {
                            val model = pictures[i] as PictureData
//                            if (model.isSelected) {

                            val isDelete =
                                Utils.deleteFile(activity, model.filePath, dataBase, isPermanent)
                            if (isDelete) {
                                deleteList.add(model.filePath)
                                activity.runOnUiThread {
                                    progressDialog.setProgress(deleteList.size,selectedItem)
//                                    bindingDialog.txtProgressCount.text =
//                                        deleteList.size.toString() + "/" + selectedItem
//                                    bindingDialog.progressBar.progress = deleteList.size
                                }
                            }
//                            } else {
//                                model.isCheckboxVisible = false
//                            }
                        }
//                    else if (pictures[i] is AlbumData) {
//                        val model = pictures[i] as AlbumData
//                        model.isSelected = false
//                        model.isCheckboxVisible = false
//                    }
                    }
                    if (albumList[a] is AlbumData) {
                        val model = albumList[a] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false
                    }
                }

            }

            var i = 0

            for (a in albumList.indices) {
                val pictures = albumList[a].pictureData
                while (i < pictures.size) {
                    if (pictures[i] != null)
                        if (pictures[i] is PictureData) {
                            val model = pictures[i] as PictureData
                            model.isSelected = false
                            model.isCheckboxVisible = false

                        } else
                            if (pictures[i] is PictureData) {
                                val model = pictures[i] as PictureData
                                if (model.isSelected) {
                                    var isPre = false
                                    var isNext = false
                                    if (i != 0) {
                                        isPre = pictures[i - 1] is PictureData
                                    }
                                    if (i < pictures.size - 2) {
                                        isNext = pictures[i + 1] is PictureData
                                    }
                                    if (isPre && isNext) {
                                        pictures.removeAt(i)
                                        pictures.removeAt(i - 1)
                                    } else if (i == pictures.size - 1) {
                                        pictures.removeAt(i)
                                        if (isPre) {
                                            pictures.removeAt(i - 1)
                                        }
                                    } else {
                                        pictures.removeAt(i)
                                    }
                                    if (i != 0) {
                                        i--
                                    }
                                } else {
                                    model.isSelected = false
                                    model.isCheckboxVisible = false
                                }
                            }
                    i++
                }

            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                activity.runOnUiThread {
//                    if (dialog.isShowing)
                        progressDialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
            .subscribe { _: Boolean? ->
                activity.runOnUiThread {
//                    if (dialog.isShowing)
                        progressDialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
    }

    private fun setBeforeDeleteUpdate(deleteList: ArrayList<String>) {
//        EventBus.getDefault().post(DeleteEvent(0, deleteList))
        selectedItem = 0
        notifyAdapter()
//        enableScroll()
        binding.swipeRefreshLayout.isEnabled = true
        longClickListener(false, 0, false)
        setEmptyData()
        toast(getString(R.string.Delete_successfully))
        deleteMainList(deleteList)
    }

    private fun deleteMainList(deleteList: ArrayList<String>) {
        if (deleteList.size != 0) {
//            for (path in deleteList) {
//                for (pictureData in filterList) {
//                    if (pictureData.getFilePath().equalsIgnoreCase(path)) {
//                        filterList.remove(pictureData)
//                        break
//                    }
//                }
//            }
            for (path in deleteList) {
                for (pictureData in albumList) {
                    if (pictureData.folderPath == path) {
                        albumList.remove(pictureData)
                        break
                    }
                }
            }
//            getFindCount()
        }
    }

    fun setRvLayoutManager() {
        val gridCount = preferences.getAlbumGridCount()
        val isGridShow = preferences.getShowGrid()
        if (isGridShow) {
            val layoutManager = binding.albumRecycler.layoutManager as MyGridLayoutManager
            layoutManager.orientation = RecyclerView.VERTICAL
            layoutManager.spanCount = gridCount
            layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int): Int {
                    if (position >= 0 && position < albumList.size) {
                        return if (albumAdapter!!.getItemViewType(position) === albumAdapter!!.ITEM_ALBUM_HEADER_TYPE) {
                            gridCount
                        } else 1
                    } else {
                        return 1
                    }
                }
            }
        } else {
            val layoutManager = binding.albumRecycler.layoutManager as MyGridLayoutManager
            layoutManager.spanCount = 1
            layoutManager.orientation = RecyclerView.VERTICAL
            mZoomListener = null

        }
    }

    fun setListGridData() {
        setRvLayoutManager()
        if (albumAdapter != null) {
            albumAdapter!!.notifyDataSetChanged()
        }
    }


    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onUpdateFavoriteEvent(event: UpdateFavoriteEvent) {
        updateFavoriteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDisplayDeleteEvent(event: DisplayDeleteEvent) {
        displayDeleteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDeleteEvent(event: DeleteEvent) {
        deleteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onCopyMoveEvent(event: CopyMoveEvent) {
        copyMoveEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onRestoreDataEvent(event: RestoreDataEvent) {
        restoreEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onRenameEvent(event: RenameEvent) {
        renameEvent(event)
    }


    private fun updateFavoriteEvent(event: UpdateFavoriteEvent) {
        if (event.path.isNotEmpty()) {
            if (albumList.isNotEmpty()) {
                var isUpdateData = false
                for (albumData in albumList) {
                    if (!isUpdateData)
                        for (pictureData in albumData.pictureData) {
                            if (pictureData.filePath == event.path) {
                                pictureData.isFavorite = event.isFavorite
                                isUpdateData = true
                                break
                            }
                        }
                    else {
                        break
                    }
                }
                if (albumAdapter != null)
                    albumAdapter!!.notifyDataSetChanged()
            }

//            if (albumBackupList.isNotEmpty()) {
//                var isUpdateData = false
//                for (albumData in albumBackupList) {
//                    if (!isUpdateData)
//                        for (pictureData in albumData.pictureData) {
//                            if (pictureData.filePath == event.path) {
//                                pictureData.isFavorite = event.isFavorite
//                                isUpdateData = true
//                                break
//                            }
//                        }
//                    else {
//                        break
//                    }
//                }
//            }
        } else if (event.unFavoriteList.isNotEmpty()) {
            if (albumList.isNotEmpty()) {
                var isUpdateData = false
                for (favPath in event.unFavoriteList) {
                    for (albumData in albumList) {
                        if (!isUpdateData)
                            for (pictureData in albumData.pictureData) {
                                if (pictureData.filePath == favPath) {
                                    pictureData.isFavorite = event.isFavorite
                                    isUpdateData = true
                                    break
                                }
                            }
                        else {
                            break
                        }
                    }
                }
                if (albumAdapter != null)
                    albumAdapter?.notifyDataSetChanged()

//                for (favPath in event.unFavoriteList) {
//                    for (albumData in albumBackupList) {
//                        if (!isUpdateData)
//                            for (pictureData in albumData.pictureData) {
//                                if (pictureData.filePath == favPath) {
//                                    pictureData.isFavorite = event.isFavorite
//                                    isUpdateData = true
//                                    break
//                                }
//                            }
//                        else {
//                            break
//                        }
//                    }
//                }
            }
        }
    }


    private fun displayDeleteEvent(event: DisplayDeleteEvent) {
        if (event.deleteList.isNotEmpty())
            updateDeleteImageData(event.deleteList)
    }

    private fun renameEvent(event: RenameEvent) {
        if (event.oldPath.isNotEmpty() && event.renamePath.isNotEmpty()) {
//            if (albumBackupList.isNotEmpty()) {
//                val file = File(event.renamePath)
//                val parentPath = file.parentFile.path
//                for (albumData in albumBackupList) {
//                    if (albumData.folderPath == parentPath) {
//                        for (model in albumData.pictureData) {
//                            if (model.filePath == event.oldPath) {
//                                model.filePath = event.renamePath
//                                model.fileName = File(event.renamePath).name
//                                model.fileSize = File(event.renamePath).length()
//                                break
//                            }
//                        }
//                    }
//                }
//            }
            if (albumList.isNotEmpty()) {
                val file = File(event.renamePath)
                val parentPath = file.parentFile.path
                for (albumData in albumList) {
                    if (albumData.folderPath == parentPath) {
                        for (model in albumData.pictureData) {
                            if (model.filePath == event.oldPath) {
                                model.filePath = event.renamePath
                                model.fileName = File(event.renamePath).name
                                model.fileSize = File(event.renamePath).length()
                                break
                            }
                        }
                    }
                }

                albumAdapter?.notifyDataSetChanged()
            }
        }
    }

    private fun restoreEvent(event: RestoreDataEvent) {
        if (event.restoreList.isNotEmpty()) {
            val list: ArrayList<String> = ArrayList()
            val imageList: ArrayList<String> = ArrayList()
            val favList = preferences.getFavoriteList()

            for (restoreData in event.restoreList) {
                list.add(restoreData.deletedPath)
                imageList.add(restoreData.path)
            }

            updateDeleteImageData(list)

            for (i in imageList.indices) {
                val file1 = File(imageList[i])
                if (file1.exists()) {
                    val pictureData = PictureData(
                        file1.path,
                        file1.name,
                        file1.parentFile.name,
                        file1.lastModified(),
                        file1.lastModified(),
                        file1.length()
                    )
                    pictureData.isFavorite = favList.contains(file1.path)
                    if (Utils.isVideoFile(file1.path)) {
                        pictureData.isVideo = true
                    }

                    val file = file1.parentFile
                    var isAdd = false
                    for (albumData in albumList) {
                        if (albumData.title == file.name) {
                            val image: ArrayList<PictureData> = ArrayList()
                            image.addAll(albumData.pictureData)
                            image.add(pictureData)
                            albumData.pictureData = image
                            isAdd = true
                        }
                    }

                    if (!isAdd) {
                        val image: ArrayList<PictureData> = ArrayList()
                        image.add(pictureData)
                        val albumData = AlbumData()
                        albumData.title = file.name
                        albumData.folderPath = file.path
                        albumData.pictureData = image
                        albumData.date = file.lastModified()
                        albumData.fileSize = file.length()
                        albumList.add(albumData)
//                        albumBackupList.add(albumData)
                    }

                }
            }
            getAlbumCount()
            setFilterData()
        }
    }

    private fun copyMoveEvent(event: CopyMoveEvent) {
        if (event.copyMoveList.isNotEmpty()) {
            val imageList: ArrayList<String> = ArrayList()
            imageList.addAll(event.copyMoveList)

            val file = File(event.albumPath)

            val favList = preferences.getFavoriteList()

            if (event.deleteList.isNotEmpty())
                updateDeleteImageData(event.deleteList)

            if (file.exists()) {
                val imagesData1 = ArrayList<PictureData>()
                for (i in imageList.indices) {
                    val file1 = File(imageList[i])
                    if (file1.exists()) {
                        val pictureData = PictureData(
                            file1.path,
                            file1.name,
                            file1.parentFile.name,
                            file1.lastModified(),
                            file1.lastModified(),
                            file1.length()
                        )
                        pictureData.isFavorite = favList.contains(file1.path)
                        if (Utils.isVideoFile(file1.path)) {
                            pictureData.isVideo = true
                        }
                        imagesData1.add(pictureData)
                    }
                }

                var isAdd = false
                for (albumData in albumList) {
                    if (albumData.title == file.name) {
                        val image: ArrayList<PictureData> = ArrayList()
                        image.addAll(albumData.pictureData)
                        image.addAll(imagesData1)
                        albumData.pictureData = image
                        isAdd = true
                    }
                }
//                            if (isAdd) {
//                for (albumData in albumList) {
//                    if (albumData.title == file.name) {
//                        val image: ArrayList<PictureData> = ArrayList()
//                        image.addAll(albumData.pictureData)
//                        image.addAll(imagesData1)
//                        albumData.pictureData = image
//                        isAdd = true
//                    }
//                }
//                            }

                if (!isAdd) {
                    val albumData = AlbumData()
                    albumData.title = file.name
                    albumData.folderPath = file.path
                    albumData.pictureData = imagesData1
                    albumData.date = file.lastModified()
                    albumData.fileSize = file.length()
                    albumList.add(albumData)
//                    albumBackupList.add(albumData)
                }
                if (activity != null)
                    activity.runOnUiThread {
                        getAlbumCount()
                        setFilterData()
                    }


            }
        }

    }

    private fun deleteEvent(event: DeleteEvent) {
        if (event.deleteList.isNotEmpty())
            updateDeleteImageData(event.deleteList)
    }

    private fun updateDeleteImageData(deleteList: java.util.ArrayList<String>) {
        if (albumList != null && albumList.size != 0) {
            for (d in deleteList.indices) {
                var i = 0
                while (i < albumList.size) {
                    if (albumList[i] != null) {
                        val photoHeader = albumList[i]
                        val photoList: ArrayList<PictureData> = ArrayList()
                        photoList.addAll(photoHeader.pictureData)
                        if (photoList.size != 0) {
                            for (p in photoList.indices) {
                                if (deleteList[d].equals(
                                        photoList[p].filePath,
                                        ignoreCase = true
                                    )
                                ) {
                                    photoList.removeAt(p)
                                    if (photoList.size == 0) {
                                        if (albumList[i].folderPath.isNotEmpty()) {
//                                            val file = File(albumList[i].folderPath)
//                                            file.delete()
//                                            MediaScannerConnection.scanFile(
//                                                requireActivity(), arrayOf(file.path), null
//                                            ) { _: String?, _: Uri? -> }
                                        }
                                        albumList.removeAt(i)
                                        if (i != 0) {
                                            i--
                                        }
                                    } else {
                                        photoHeader.pictureData = photoList
                                        albumList[i] = photoHeader
                                    }
                                    break
                                }
                            }
                        }
                    }
                    i++
                }
            }
            if (albumAdapter != null) {
                albumAdapter!!.notifyDataSetChanged()
            }
            setEmptyData()
        }

        if (albumList != null && albumList.size != 0) {
            for (d in deleteList.indices) {
                var i = 0
                while (i < albumList.size) {
                    if (albumList[i] != null) {
                        val photoHeader = albumList[i]
                        val photoList: ArrayList<PictureData> = ArrayList()
                        photoList.addAll(photoHeader.pictureData)
                        if (photoList.size != 0) {
                            for (p in photoList.indices) {
                                if (deleteList[d].equals(
                                        photoList[p].filePath,
                                        ignoreCase = true
                                    )
                                ) {
                                    photoList.removeAt(p)
                                    if (photoList.size == 0) {
                                        if (albumList[i].folderPath.isNotEmpty()) {
//                                            val file = File(albumList[i].folderPath)
//                                            file.delete()
//                                            MediaScannerConnection.scanFile(
//                                                requireActivity(), arrayOf(file.path), null
//                                            ) { _: String?, _: Uri? -> }
                                        }
                                        albumList.removeAt(i)
                                        if (i != 0) {
                                            i--
                                        }
                                    } else {
                                        photoHeader.pictureData = photoList
                                        albumList[i] = photoHeader
                                    }
                                    break
                                }
                            }
                        }
                    }
                    i++
                }
            }
            getAlbumCount()
        }
    }


    fun showDeleteDialog() {
        if (selectedItem == 0) {

            toast(getString(R.string.PleaseSelectAlbum))
        } else {
            val deleteDialog = DeleteDialog(
                activity,
                btnClickListener = {
                    deletePhoto(it)
                })
            deleteDialog.show(supportFragmentManager, deleteDialog.tag)
        }
    }

    fun addToExclude() {
        val albumData = albumList.filter { it.isSelected }
        val excludeList: ArrayList<String> = ArrayList()
        excludeList.addAll(preferences.getExcludeList())

        for (i in albumData.indices) {
            if (albumData[i] is AlbumData) {
                val model = albumData[i] as AlbumData
                if (model.isSelected && model.folderPath.isNotEmpty()) {
                    if (!excludeList.contains(model.folderPath)) excludeList.add(model.folderPath)
//                    else excludeList.add(model.folderPath)
                }
            }
        }
        preferences.setExcludeList(excludeList)
        setCloseToolbar()


    }

    fun showRenameDialog() {

        val albumData = albumList.filter { it.isSelected }

        val renameDialog =
            RenameFolderDialog(
                activity,
                albumData.get(0),
                positiveBtnClickListener = { renamePath, oldPath ->
                    val file = File(renamePath)
//                    notifyAdapter()
                    setCloseToolbar()
//                    displayImageList[binding.viewPager.currentItem].filePath = renamePath
//                    displayImageList[binding.viewPager.currentItem].fileName = file.name
//                    pagerAdapter.notifyDataSetChanged()

                }, updateImageListener = {
//                    notifyAdapter()
                    setCloseToolbar()
//                    pagerAdapter.notifyDataSetChanged()

                })
        renameDialog.show(supportFragmentManager, renameDialog.tag)
    }

    fun showAddAlbumDialog(albums: ArrayList<AlbumData>, isCopy: Boolean) {
        if (selectedItem == 0) {

            toast(getString(R.string.PleaseSelectAlbum))
        } else {
            val selectImage: ArrayList<PictureData> = ArrayList()
            val selectedAlbum: ArrayList<AlbumData> = ArrayList()
            for (a in albumList.indices) {
                if (albumList[a].isSelected) {
                    selectedAlbum.add(albumList[a])
                    val pictures = albumList[a].pictureData
                    for (i in pictures.indices) {
                        if (pictures[i] != null)
                            if (pictures[i] is PictureData) {
                                val model: PictureData = pictures[i] as PictureData
//                                if (model.isSelected) {
                                selectImage.add(model)
//                                }
                            }
                    }
                }
            }
            val addAlbumDialog =
                SelectAlbumDialog(
                    activity,
                    albums,
                    selectedAlbum,
                    isCopy,
                    selectPathListener = { selectPath ->
                        setCopyMove(isCopy, selectPath, selectImage)
                    },
                    createAlbumListener = {
                        val createDialog = CreateAlbumDialog(activity, createPathListener = {
                            setCopyMove(isCopy, it, selectImage)
                        })
                        createDialog.show(supportFragmentManager, createDialog.tag)
                    })
            addAlbumDialog.show(supportFragmentManager, addAlbumDialog.tag)
        }
    }

    private fun setCopyMove(
        isCopy: Boolean,
        selectPath: String,
        selectImage: java.util.ArrayList<PictureData>
    ) {
        if (isCopy)
            Utils.copyFiles(
                activity,
                selectPath,
                selectImage,
                selectedItem,
                copyListener = {
                    toast(getString(R.string.copy_successfully))
                    selectedItem = 0
                    longClickListener(false, 0, false)
                    setClose()
                })
        else
            Utils.moveFiles(
                activity,
                selectPath,
                selectImage,
                selectedItem,
                copyListener = {
                    toast(getString(R.string.move_successfully))
                    selectedItem = 0
                    longClickListener(false, 0, false)
                    setClose()
                })

    }

}