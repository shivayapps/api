package com.gallery.photo.image.video.secret

import android.content.Context
import android.util.Log
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.utils.Preferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.Properties
import java.util.Random
import javax.mail.*
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeMessage

object MailUtil {

    const val email = "devtoonboon@gmail.com"
    const val password = "dyrd lkvq dknj ineb"

    fun requestOtp(context: Context, mailListener: (icSuccess: Boolean) -> Unit) {
        val preferences = Preferences(context)
//        val clientMail = preferences.securityEmail
        val clientMail = ""
        var pass = preferences.getPattern()

        if (preferences.getShowPINLock()) {
            pass = preferences.getPass()
        }

        val veriCode = Random().nextInt(9000) + 1000
        val cal = Calendar.getInstance()
        preferences.putVeriCode("$veriCode", cal.timeInMillis)

        val subject = context.getString(R.string.retrieve_password_gallery)
        val message = context.getString(R.string.msg_forget_password, pass)
        val content = """
            <p> Your Verification code for Gallery Vault is: </p>
            <h1 style ="color: black">$veriCode</h1>
            <p> This code is valid for 30 minute.</p>
            <p> Please disregard this message if you did not wish to change your password.</p>
        """.trimIndent()
        sendEmail(clientMail, subject, content, mailListener)
    }
    fun submitFeedback(context: Context,emailText: String, mailListener: (icSuccess: Boolean) -> Unit) {
        val preferences = Preferences(context)
//        val clientMail = preferences.securityEmail
        val clientMail = ""
        var pass = preferences.getPattern()

        if (preferences.getShowPINLock()) {
            pass = preferences.getPass()
        }

//        val veriCode = Random().nextInt(9000) + 1000
//        val cal = Calendar.getInstance()
//        preferences.putVeriCode("$veriCode", cal.timeInMillis)

        val subject = "Feedback Gallery"
//        val message = context.getString(R.string.msg_forget_password, pass)
        val content = """
            $emailText\n
            From : $clientMail
        """.trimIndent()
//        sendEmail(clientMail, subject, emailText, mailListener)
        sendEmail(email, subject, content, mailListener)
    }

    private fun sendEmail(
        to: String,
        subject: String,
        body: String,
        mailListener: (icSuccess: Boolean) -> Unit
    ) {
        Log.i("MailUtil", "sendEmail to:$to")
        Log.i("MailUtil", "sendEmail subject:$subject")
        Log.i("MailUtil", "sendEmail body:$body")
        if(to.isEmpty()) {
            mailListener.invoke(false)
            return
        }
        val properties = Properties().apply {
            put("mail.smtp.host", "smtp.gmail.com")
            put("mail.smtp.port", "587")
            put("mail.smtp.user", "From Gallery.in")
            put("mail.smtp.auth", "true")
            put("mail.smtp.starttls.enable", "true")
            put("mail.transport.protocol", "smtp")
        }

        val session = Session.getDefaultInstance(properties, object : Authenticator() {
            override fun getPasswordAuthentication(): PasswordAuthentication {
                return PasswordAuthentication(email, password)
            }
        })

        val message = MimeMessage(session)
        message.setFrom(InternetAddress(email))
        message.setRecipient(Message.RecipientType.TO, InternetAddress(to))
//        message.setRecipient(Message.RecipientType.CC, InternetAddress(cc))
//        message.setRecipient(Message.RecipientType.BCC, InternetAddress(bcc))

        message.subject = subject
        message.setContent(body, "text/html; charset=utf-8")
//        message.setText(body)

        CoroutineScope(Dispatchers.IO).launch {
            try {
                Transport.send(message)
                mailListener.invoke(true)
                Log.i("MailUtil", "Email Sent")
            } catch (e: Exception) {
                mailListener.invoke(false)
                Log.e("MailUtil", "Error sending email: ${e.message}", e)
            }
        }
    }
}