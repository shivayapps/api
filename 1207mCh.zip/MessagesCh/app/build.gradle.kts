plugins {
    alias(libs.plugins.android.application)
    id("realm-android")   // must come before Kotlin plugins
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.ksp)
    id("kotlin-kapt")
    alias(libs.plugins.google.services)
}

android {
    namespace = "messages.sms.text.chat.messanger.app"
    compileSdk {
        version = release(36)
    }

    defaultConfig {
        applicationId = "messages.sms.text.chat.messanger.app"
        minSdk = 26
        targetSdk = 36

        versionCode = 8
        versionName = "1.0.7"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    extensions.getByType(BasePluginExtension::class.java)
        .archivesName
        .set("Messages-v${defaultConfig.versionName}")

    buildFeatures {
        buildConfig = true
        viewBinding = true
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("debug")
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
//            proguardFiles(getDefaultProguardFile("proguard-android.txt"), "proguard-rules.pro")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    flavorDimensions += "default"
    productFlavors {
        create("TestAd") {
            isDefault = true
            resValue("string", "permission_inter_1", "ca-app-pub-3940256099942544/1033173712")
            resValue("string", "permission_inter_2", "ca-app-pub-3940256099942544/1033173712")
            resValue("string", "home_banner_native1_1", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "home_banner_native1_2", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "home_banner_native3_1", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "home_banner_native3_2", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "home_archived_native1_1", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "home_archived_native1_2", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "home_archived_native3_1", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "home_archived_native3_2", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "home_private_native1_1", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "home_private_native1_2", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "home_private_native3_1", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "home_private_native3_2", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "chat_screen_native_1", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "chat_screen_native_2", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "manage_apps_inter_1", "ca-app-pub-3940256099942544/1033173712")
            resValue("string", "manage_apps_inter_2", "ca-app-pub-3940256099942544/1033173712")
            resValue("string", "manage_apps_native_1", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "manage_apps_native_2", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "caller_card_native_1", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "caller_card_native_2", "ca-app-pub-3940256099942544/2247696110")

        }

        create("LiveAd") {
            resValue("string", "permission_inter_1", "ca-app-pub-3940256099942544/1033173712")
            resValue("string", "permission_inter_2", "ca-app-pub-3940256099942544/1033173712")
            resValue("string", "home_banner_native1_1", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "home_banner_native1_2", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "home_banner_native3_1", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "home_banner_native3_2", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "home_archived_native1_1", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "home_archived_native1_2", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "home_archived_native3_1", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "home_archived_native3_2", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "home_private_native1_1", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "home_private_native1_2", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "home_private_native3_1", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "home_private_native3_2", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "chat_screen_native_1", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "chat_screen_native_2", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "manage_apps_inter_1", "ca-app-pub-3940256099942544/1033173712")
            resValue("string", "manage_apps_inter_2", "ca-app-pub-3940256099942544/1033173712")
            resValue("string", "manage_apps_native_1", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "manage_apps_native_2", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "caller_card_native_1", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "caller_card_native_2", "ca-app-pub-3940256099942544/2247696110")
        }
    }

    dependenciesInfo {
        // Disables dependency metadata when building APKs and AABs.
        includeInApk = false
        includeInBundle = false
    }

    lint {
        abortOnError = false
    }
}

dependencies {

    // -------------------- Lifecycle --------------------
    implementation(libs.lifecycle.viewmodel.ktx)
    implementation(libs.lifecycle.runtime.ktx)
    implementation(libs.lifecycle.livedata.ktx)
    implementation(libs.lifecycle.common.java8)
    implementation("org.greenrobot:eventbus:3.3.1")

    // -------------------- AndroidX --------------------
    implementation(libs.androidx.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.documentfile)
    implementation(libs.androidx.exifinterface)
    implementation(libs.androidx.viewpager2)
//    implementation(libs.androidx.emoji2.bundled)
    implementation("androidx.emoji:emoji-appcompat:1.2.0")

    // -------------------- Material --------------------
    implementation(libs.material)
    implementation("com.intuit.sdp:sdp-android:1.1.1")
    implementation("com.github.QuadFlask:colorpicker:0.0.15")
    implementation("com.airbnb.android:lottie:3.4.4")
    implementation("com.facebook.shimmer:shimmer:0.5.0")
    implementation("com.github.mmmelik:RoundedImageView:v1.0.1")

    implementation("com.google.code.gson:gson:2.11.0")
    implementation("androidx.browser:browser:1.8.0")
    implementation("androidx.activity:activity:1.9.2")
    implementation("androidx.preference:preference-ktx:1.2.1")
    implementation("androidx.multidex:multidex:2.0.1")

    implementation("com.google.android.gms:play-services-measurement-api:22.1.0")

    implementation("com.squareup.retrofit2:converter-gson:2.9.0")

    implementation("com.google.android.play:review-ktx:2.0.1")

    implementation("com.intuit.ssp:ssp-android:1.1.1")

    implementation("com.github.yalantis:ucrop:2.2.8")

    implementation("com.google.firebase:firebase-config-ktx:22.0.0")
    implementation("com.google.firebase:firebase-auth-ktx:23.0.0")

    // -------------------- WorkManager --------------------
    implementation(libs.androidx.work.runtime.ktx)
    implementation(libs.androidx.work.rxjava2)

    // -------------------- Conductor --------------------
    implementation(libs.conductor)
    implementation(libs.conductor.archlifecycle)

    // -------------------- Glide --------------------
    implementation(libs.glide)
    kapt(libs.compiler)

    // -------------------- Media3 --------------------
    implementation(libs.media3.common)
    implementation(libs.media3.exoplayer)
    implementation(libs.media3.ui)

    // -------------------- RxBinding --------------------
    implementation(libs.rxbinding.kotlin)
    implementation(libs.rxbinding.support.v4.kotlin)

    // -------------------- AutoDispose --------------------
    implementation(libs.autodispose)
    implementation(libs.autodispose.android)
    implementation(libs.autodispose.lifecycle)
    implementation(libs.autodispose.android.archcomponents)
    implementation(libs.autodispose.android.archcomponents.test)

    // -------------------- Dagger --------------------
    implementation(libs.dagger)
    implementation(libs.dagger.android.support)
    kapt(libs.dagger.compiler)
    kapt(libs.dagger.android.processor)

    implementation(libs.javax.annotation.api)

    // -------------------- Realm --------------------
    implementation(libs.realm.android.library)
    implementation(libs.realm.android.adapters)
    kapt(libs.realm.annotations.processor)

    // -------------------- RxJava --------------------
    implementation(libs.rxjava)
    implementation(libs.rxandroid)
    implementation(libs.rxkotlin)
    implementation(libs.rxdogtag)
    implementation(libs.rxdogtag.autodispose)

    // -------------------- Moshi --------------------
    implementation(libs.moshi)
    implementation(libs.moshi.kotlin)
    kapt(libs.moshi.kotlin.codegen)

    // -------------------- Coroutines --------------------
    implementation(libs.kotlinx.coroutines.core)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.kotlinx.coroutines.rx2)
    implementation(libs.kotlinx.coroutines.reactive)

    // -------------------- Media / Utils --------------------
    implementation(libs.photoview)
    implementation(libs.flexbox)
    implementation(libs.shortcutbadger)
    implementation(libs.okhttp3.okhttp)
    implementation(libs.libphonenumber.android)
    implementation(libs.datashare)
    implementation(libs.rx.preferences)
    implementation(libs.timber)

    // -------------------- Kotlin --------------------
    implementation(libs.kotlin.stdlib)

    // -------------------- ez-vcard --------------------
    implementation("com.googlecode.ez-vcard:ez-vcard:0.10.4") {
        exclude(group = "org.jsoup", module = "jsoup")
        exclude(group = "org.freemarker", module = "freemarker")
        exclude(group = "com.fasterxml.jackson.core", module = "jackson-core")
    }

    implementation("com.google.android.gms:play-services-ads:23.3.0")
//    implementation("com.google.ads.mediation:pangle:6.2.0.6.0")
//    implementation("com.pangle.global:ads-sdk:6.2.0.6")
//    implementation("com.google.ads.mediation:facebook:6.18.0.0")
//    implementation("com.google.ads.mediation:vungle:7.4.1.0")
//    implementation("com.vungle:vungle-ads:7.4.1")

    // -------------------- Local Modules --------------------
    implementation(project(":library-smsmms"))

    // -------------------- Unit Tests --------------------
    testImplementation(libs.junit)
    testImplementation(libs.mockito.core)
    testImplementation(libs.mockito.kotlin)
    testImplementation(libs.robolectric)
    testImplementation(libs.truth)
    testImplementation(libs.androidx.runner)
    testImplementation(libs.androidx.test.core)

    // -------------------- Instrumentation Tests --------------------
    androidTestImplementation(libs.espresso.core)
    androidTestImplementation(libs.mockito.android)
    androidTestImplementation(libs.truth)
    androidTestImplementation(libs.androidx.test.core)
    androidTestImplementation(libs.androidx.test.core.ktx)
    androidTestImplementation(libs.androidx.runner)
    androidTestImplementation(libs.androidx.test.ext.junit)
}
