package messages.sms.text.chat.messanger.app.mapper

import android.database.Cursor
import messages.sms.text.chat.messanger.app.model.Conversation

interface CursorToConversation : Mapper<Cursor, Conversation> {

    fun getConversationsCursor(): Cursor?

}