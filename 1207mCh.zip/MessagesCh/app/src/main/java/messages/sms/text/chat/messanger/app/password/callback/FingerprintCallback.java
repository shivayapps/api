package messages.sms.text.chat.messanger.app.password.callback;


public interface FingerprintCallback {
    void onAuthenticationSucceeded();

    void onAuthenticationFailed();

    void onAuthenticationError(int errorCode, String error);
}
