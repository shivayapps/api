package messages.sms.text.chat.messanger.app.feature.themepicker

import io.reactivex.Observable
import messages.sms.text.chat.messanger.app.common.base.QkViewContract

interface ThemePickerView : QkViewContract<ThemePickerState> {

    fun themeSelected(): Observable<Int>
    fun hsvThemeSelected(): Observable<Int>
    fun clearHsvThemeClicks(): Observable<*>
    fun applyHsvThemeClicks(): Observable<*>

    fun setCurrentTheme(color: Int)

}