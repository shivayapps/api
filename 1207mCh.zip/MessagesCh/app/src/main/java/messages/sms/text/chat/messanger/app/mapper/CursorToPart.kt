package messages.sms.text.chat.messanger.app.mapper

import android.database.Cursor
import messages.sms.text.chat.messanger.app.model.MmsPart

interface CursorToPart : Mapper<Cursor, MmsPart> {

    fun getPartsCursor(messageId: Long): Cursor?

}