package messages.sms.text.chat.messanger.app.util

import android.net.Uri
import com.f2prateek.rx.preferences2.Preference.Converter

class UriPreferenceConverter : Converter<Uri> {

    override fun deserialize(serialized: String): Uri {
        return Uri.parse(serialized)
    }

    override fun serialize(value: Uri): String {
        return value.toString()
    }

}
