package messages.sms.text.chat.messanger.app.injection

import dagger.Component
import dagger.android.support.AndroidSupportInjectionModule
import messages.sms.text.chat.messanger.app.common.QKApplication
import messages.sms.text.chat.messanger.app.common.QkDialog
import messages.sms.text.chat.messanger.app.common.util.QkChooserTargetService
import messages.sms.text.chat.messanger.app.common.widget.AvatarView
import messages.sms.text.chat.messanger.app.common.widget.BabyTextView
import messages.sms.text.chat.messanger.app.common.widget.MessageTextView
import messages.sms.text.chat.messanger.app.common.widget.PagerTitleView
import messages.sms.text.chat.messanger.app.common.widget.PreferenceView
import messages.sms.text.chat.messanger.app.common.widget.QkEditText
import messages.sms.text.chat.messanger.app.common.widget.QkSwitch
import messages.sms.text.chat.messanger.app.common.widget.RadioPreferenceView
import messages.sms.text.chat.messanger.app.common.widget.StyledTextView
import messages.sms.text.chat.messanger.app.feature.backup.BackupController
import messages.sms.text.chat.messanger.app.feature.blocking.BlockingController
import messages.sms.text.chat.messanger.app.feature.blocking.manager.BlockingManagerController
import messages.sms.text.chat.messanger.app.feature.blocking.messages.BlockedMessagesController
import messages.sms.text.chat.messanger.app.feature.blocking.numbers.BlockedNumbersController
import messages.sms.text.chat.messanger.app.feature.compose.editing.DetailedChipView
import messages.sms.text.chat.messanger.app.feature.conversationinfo.injection.ConversationInfoComponent
import messages.sms.text.chat.messanger.app.feature.settings.AdvanceSettingsController
import messages.sms.text.chat.messanger.app.feature.settings.SettingsController
import messages.sms.text.chat.messanger.app.feature.settings.swipe.SwipeActionsController
import messages.sms.text.chat.messanger.app.feature.themepicker.injection.ThemePickerComponent
import messages.sms.text.chat.messanger.app.feature.widget.WidgetAdapter
import messages.sms.text.chat.messanger.app.injection.android.ActivityBuilderModule
import messages.sms.text.chat.messanger.app.injection.android.BroadcastReceiverBuilderModule
import messages.sms.text.chat.messanger.app.injection.android.ServiceBuilderModule
import javax.inject.Singleton

@Singleton
@Component(
    modules = [
        AndroidSupportInjectionModule::class,
        AppModule::class,
        ActivityBuilderModule::class,
        BroadcastReceiverBuilderModule::class,
        ServiceBuilderModule::class]
)
interface AppComponent {

    fun conversationInfoBuilder(): ConversationInfoComponent.Builder
    fun themePickerBuilder(): ThemePickerComponent.Builder

    fun inject(application: QKApplication)

    fun inject(controller: BackupController)
    fun inject(controller: BlockedMessagesController)
    fun inject(controller: BlockedNumbersController)
    fun inject(controller: BlockingController)
    fun inject(controller: BlockingManagerController)
    fun inject(controller: SettingsController)
    fun inject(controller: AdvanceSettingsController)
    fun inject(controller: SwipeActionsController)

    fun inject(dialog: QkDialog)

    fun inject(service: WidgetAdapter)

    /**
     * This can't use AndroidInjection, or else it will crash on pre-marshmallow devices
     */
    fun inject(service: QkChooserTargetService)

    fun inject(view: AvatarView)
    fun inject(view: DetailedChipView)
    fun inject(view: PagerTitleView)
    fun inject(view: PreferenceView)
    fun inject(view: RadioPreferenceView)
    fun inject(view: QkEditText)
    fun inject(view: QkSwitch)
    fun inject(view: BabyTextView)
    fun inject(view: StyledTextView)
    fun inject(view: MessageTextView)

}
