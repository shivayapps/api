package messages.sms.text.chat.messanger.app.receiver

//class NightModeReceiver : BroadcastReceiver() {
//
//    @Inject
//    lateinit var nightModeManager: NightModeManager
//
//    override fun onReceive(context: Context, intent: Intent) {
//        AndroidInjection.inject(this, context)
//
//        nightModeManager.updateCurrentTheme()
//    }
//}