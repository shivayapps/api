package messages.sms.text.chat.messanger.app.common.widget

import android.content.Context
import android.util.AttributeSet
import androidx.emoji.widget.EmojiAppCompatTextView
import messages.sms.text.chat.messanger.app.common.util.TextViewStyler
import messages.sms.text.chat.messanger.app.injection.appComponent
import messages.sms.text.chat.messanger.app.util.Preferences
import javax.inject.Inject


open class MessageTextView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null,
) : EmojiAppCompatTextView(context, attrs) {

    @Inject
    lateinit var textViewStyler: TextViewStyler

    @Inject
    lateinit var prefs: Preferences


    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)

        // Get a non-null copy of the layout, if available. Then ensure we've got multiple lines
        try {
            val layout = layout ?: return
            if (layout.lineCount <= 1) {
                return
            }

            val maxLineWidth = (0 until layout.lineCount)
                .map(layout::getLineWidth)
                .max() ?: 0f

            val width =
                Math.ceil(maxLineWidth.toDouble())
                    .toInt() + compoundPaddingLeft + compoundPaddingRight
            if (width < measuredWidth) {
                val widthSpec =
                    MeasureSpec.makeMeasureSpec(width, MeasureSpec.getMode(widthMeasureSpec))
                super.onMeasure(widthSpec, heightMeasureSpec)
            }
        } catch (_: Exception) {

        }
    }


    /**
     * Collapse a multiline list of strings into a single line
     *
     * Ex.
     *
     * Toronto, New York, Los Angeles,
     * Seattle, Portland
     *
     * Will be converted to
     *
     * Toronto, New York, Los Angeles, +2
     */
    var collapseEnabled: Boolean = false

    init {
        if (!isInEditMode) {
            appComponent.inject(this)
            textViewStyler.applyAttributes(this, attrs)
        } else {
            TextViewStyler.applyEditModeAttributes(this, attrs)
        }
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)

        if (collapseEnabled) {
            layout
                ?.takeIf { layout -> layout.lineCount > 0 }
                ?.let { layout -> layout.getEllipsisCount(layout.lineCount - 1) }
                ?.takeIf { ellipsisCount -> ellipsisCount > 0 }
                ?.let { ellipsisCount -> text.dropLast(ellipsisCount).lastIndexOf(',') }
                ?.takeIf { lastComma -> lastComma >= 0 }
                ?.let { lastComma ->
                    val remainingNames = text.drop(lastComma).count { c -> c == ',' }
                    text = "${text.take(lastComma)}, +$remainingNames"
                }
        }
    }

    fun setColors(textColor: Int, accentColor: Int, backgroundColor: Int) {
        setTextColor(textColor)
        setLinkTextColor(accentColor)
        setBackgroundColor(backgroundColor)
    }

    fun setColors(textColor: Int, backgroundColor: Int) {
        setTextColor(textColor)
        setBackgroundColor(backgroundColor)
    }


    override fun setTextColor(color: Int) {
        super.setTextColor(color)
        setLinkTextColor(color)
    }

}