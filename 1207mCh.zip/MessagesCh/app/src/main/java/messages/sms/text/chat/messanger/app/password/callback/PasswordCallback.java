package messages.sms.text.chat.messanger.app.password.callback;


public interface PasswordCallback {
    void onPasswordSucceeded();

    boolean onPasswordCheck(String password);

    void onPasswordCancel();
}