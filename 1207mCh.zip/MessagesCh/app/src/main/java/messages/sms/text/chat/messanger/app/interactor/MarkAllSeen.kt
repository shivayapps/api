package messages.sms.text.chat.messanger.app.interactor

import io.reactivex.Flowable
import messages.sms.text.chat.messanger.app.repository.MessageRepository
import javax.inject.Inject

class MarkAllSeen @Inject constructor(private val messageRepo: MessageRepository) :
    Interactor<Unit>() {

    override fun buildObservable(params: Unit): Flowable<Unit> {
        return Flowable.just(Unit)
            .doOnNext { messageRepo.markAllSeen() }
    }

}