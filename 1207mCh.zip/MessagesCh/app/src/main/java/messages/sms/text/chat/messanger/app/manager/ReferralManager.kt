package messages.sms.text.chat.messanger.app.manager

interface ReferralManager {

    suspend fun trackReferrer()

}
