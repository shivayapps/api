package messages.sms.text.chat.messanger.app.feature.qkreply

import io.reactivex.Observable
import messages.sms.text.chat.messanger.app.common.base.QkView

interface QkReplyView : QkView<QkReplyState> {

    val menuItemIntent: Observable<Int>
    val textChangedIntent: Observable<CharSequence>
    val changeSimIntent: Observable<*>
    val sendIntent: Observable<Unit>

    fun setDraft(draft: String)
    fun finish()

}