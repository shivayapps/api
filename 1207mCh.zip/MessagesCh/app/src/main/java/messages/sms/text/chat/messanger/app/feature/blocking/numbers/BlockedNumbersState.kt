package messages.sms.text.chat.messanger.app.feature.blocking.numbers

import io.realm.RealmResults
import messages.sms.text.chat.messanger.app.model.BlockedNumber

data class BlockedNumbersState(
    val numbers: RealmResults<BlockedNumber>? = null,
)
