package messages.sms.text.chat.messanger.app.feature.contacts

import android.os.Bundle
import android.util.Log
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import dagger.android.AndroidInjection
import io.reactivex.Observable
import io.realm.Realm
import io.realm.RealmList
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.common.base.QkThemedActivity
import messages.sms.text.chat.messanger.app.common.util.extensions.viewBinding
import messages.sms.text.chat.messanger.app.commons.adapters.ContactItemAdapter
import messages.sms.text.chat.messanger.app.commons.helpers.ensureBackgroundThread
import messages.sms.text.chat.messanger.app.databinding.ActivityGroupsBinding
import messages.sms.text.chat.messanger.app.feature.fragments.contact.component.ContactDialog
import messages.sms.text.chat.messanger.app.model.Contact
import messages.sms.text.chat.messanger.app.model.ContactData
import messages.sms.text.chat.messanger.app.model.ContactGroup
import messages.sms.text.chat.messanger.app.model.MessageEvent
import messages.sms.text.chat.messanger.app.model.REFRESH_CONTACT_GROUP
import org.greenrobot.eventbus.EventBus
import javax.inject.Inject

class GroupsActivity : QkThemedActivity() {

    var id: Long = 0
    var title: String = ""

    @Inject
    lateinit var contactsRepo: messages.sms.text.chat.messanger.app.repository.ContactRepository

    private val allContacts: Observable<List<Contact>> by lazy { contactsRepo.getUnmanagedContacts() }
    private val contactGroups: Observable<List<ContactGroup>> by lazy { contactsRepo.getUnmanagedContactGroups() }

    var contacts: RealmList<Contact> = RealmList()
    var contactGroup: ContactGroup? = null
    var contactsAdapter = ContactItemAdapter()

    private val binding by viewBinding(ActivityGroupsBinding::inflate)

    //    lateinit var binding:ActivityGroupsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
//        enableEdgeToEdge()
//        binding=ActivityGroupsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        setTitle(R.string.groups_label)
        showBackButton(true)
        if (intent.hasExtra("groupId")) {
            id = intent.getLongExtra("groupId", 0)
            title = intent.getStringExtra("groupName") ?: ""
            Log.e("GroupsActivity", "id:${id},title:${title}")
        }

        allContacts.autoDispose(scope()).subscribe {
            Log.e("GroupsActivity", "allContacts:${it.size}")
            contacts.addAll(it)
//            updateContactGroup(contacts)
        }
        contactGroups.autoDispose(scope()).subscribe { groups ->
            Log.e("GroupsActivity", "allContactGroups:${groups.size}")
            for (group in groups) {
                Log.e("GroupsActivity", "group.id:${group.id},contacts.size:${group.contacts.size}")
            }
            contactGroup = groups.firstOrNull { it.id == id }
//            contactGroup=groups.filter { it.id==id }.first()
            Log.e("GroupsActivity", "001:${groups.firstOrNull { it.id == id }?.contacts?.size}")

            if (contactGroup != null) {
                Log.e("GroupsActivity", "currentGroupContact:${contactGroup?.contacts?.size}")
                contacts.addAll(contactGroup?.contacts!!)
                updateContactGroup(contacts)
            }
        }

        binding.addGroupButton.floatingButton.setOnClickListener { _ ->
            val contactDialog = ContactDialog(contacts) {
                Log.e("GroupsActivity", "checkedContacts:${it.size}")
                contacts.addAll(it)
                addContactToGroup(it)
            }
            contactDialog.show(supportFragmentManager, contactDialog.tag)
        }

        binding.contacts.adapter = contactsAdapter
//        val list = (this)?.contacts ?: ArrayList()
//        contactsAdapter.data = list
    }

    fun updateContactGroup(contactList: RealmList<Contact>) {
        val contactDataList = contactList.map { contact ->
            ContactData(
                lookupKey = contact.lookupKey,
                numbers = ArrayList(contact.numbers),
                name = contact.name,
                photoUri = contact.photoUri,
                starred = contact.starred,
                lastUpdate = contact.lastUpdate
            )
        }
        runOnUiThread {
            contactsAdapter.data = contactDataList as List<ContactData>
        }
    }

    fun addContactToGroup(selectedContact: RealmList<Contact>) {
        ensureBackgroundThread {
            Realm.getDefaultInstance().use { realm ->
                val group = ContactGroup(id = id, title = title, contacts = selectedContact)
                realm.executeTransaction { realm.insertOrUpdate(group) }
            }
            runOnUiThread {
                EventBus.getDefault().post(MessageEvent(REFRESH_CONTACT_GROUP))
//                dialog?.dismiss()
//                callback.invoke()
            }
        }
    }
}