package messages.sms.text.chat.messanger.app.interactor

import io.reactivex.Flowable
import messages.sms.text.chat.messanger.app.manager.NotificationManager
import messages.sms.text.chat.messanger.app.repository.MessageRepository
import javax.inject.Inject

class MarkFailed @Inject constructor(
    private val messageRepo: MessageRepository,
    private val notificationManager: NotificationManager,
) : Interactor<MarkFailed.Params>() {

    data class Params(val id: Long, val resultCode: Int)

    override fun buildObservable(params: Params): Flowable<Unit> {
        return Flowable.just(Unit)
            .doOnNext { messageRepo.markFailed(params.id, params.resultCode) }
            .doOnNext { notificationManager.notifyFailed(params.id, params.resultCode) }
    }

}