package messages.sms.text.chat.messanger.app.repository

import android.net.Uri
import io.reactivex.Observable
import messages.sms.text.chat.messanger.app.model.Message

interface SyncRepository {

    sealed class SyncProgress {
        object Idle : SyncProgress()
        data class Running(val max: Int, val progress: Int, val indeterminate: Boolean) :
            SyncProgress()
    }

    val syncProgress: Observable<SyncProgress>

    fun syncMessages()

    fun syncMessage(uri: Uri): Message?

    fun syncContacts()

}
