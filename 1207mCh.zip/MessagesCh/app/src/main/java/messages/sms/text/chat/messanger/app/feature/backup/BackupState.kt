package messages.sms.text.chat.messanger.app.feature.backup

import messages.sms.text.chat.messanger.app.model.BackupFile
import messages.sms.text.chat.messanger.app.repository.BackupRepository

data class BackupState(
    val backupProgress: BackupRepository.Progress = BackupRepository.Progress.Idle(),
    val restoreProgress: BackupRepository.Progress = BackupRepository.Progress.Idle(),
    val lastBackup: String = "",
    val backups: List<BackupFile> = listOf(),
//    val upgraded: Boolean = true
)
