package messages.sms.text.chat.messanger.app.feature.settings

import android.content.Context
import android.util.Log
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import io.reactivex.rxkotlin.plusAssign
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.common.Navigator
import messages.sms.text.chat.messanger.app.common.base.QkPresenter
import messages.sms.text.chat.messanger.app.common.util.Colors
import messages.sms.text.chat.messanger.app.common.util.DateFormatter
import messages.sms.text.chat.messanger.app.interactor.SyncMessages
import messages.sms.text.chat.messanger.app.manager.AnalyticsManager
import messages.sms.text.chat.messanger.app.repository.SyncRepository
import messages.sms.text.chat.messanger.app.util.NightModeManager
import messages.sms.text.chat.messanger.app.util.Preferences
import timber.log.Timber
import java.util.Calendar
import java.util.concurrent.TimeUnit
import javax.inject.Inject

class SettingsPresenter @Inject constructor(
    colors: Colors,
    syncRepo: SyncRepository,
    private val analytics: AnalyticsManager,
    private val context: Context,
    private val dateFormatter: DateFormatter,
    private val navigator: Navigator,
    private val nightModeManager: NightModeManager,
    private val prefs: Preferences,
    private val syncMessages: SyncMessages,
) : QkPresenter<SettingsView, SettingsState>(
    SettingsState(
        nightModeId = prefs.nightMode.get()
    )
) {

    init {
        disposables += colors.themeObservable()
            .subscribe { theme -> newState { copy(theme = theme.theme) } }

        val nightModeLabels = context.resources.getStringArray(R.array.night_modes)
        disposables += prefs.nightMode.asObservable()
            .subscribe { nightMode ->
                newState {
                    copy(
                        nightModeSummary = nightModeLabels[nightMode],
                        nightModeId = nightMode
                    )
                }
            }

        disposables += prefs.nightStart.asObservable()
            .map { time -> nightModeManager.parseTime(time) }
            .map { calendar -> calendar.timeInMillis }
            .map { millis -> dateFormatter.getTimestamp(millis) }
            .subscribe { nightStart -> newState { copy(nightStart = nightStart) } }

        disposables += prefs.nightEnd.asObservable()
            .map { time -> nightModeManager.parseTime(time) }
            .map { calendar -> calendar.timeInMillis }
            .map { millis -> dateFormatter.getTimestamp(millis) }
            .subscribe { nightEnd -> newState { copy(nightEnd = nightEnd) } }

        disposables += prefs.black.asObservable()
            .subscribe { black -> newState { copy(black = black) } }

        disposables += prefs.notifications().asObservable()
            .subscribe { enabled -> newState { copy(notificationsEnabled = enabled) } }

        disposables += prefs.autoEmoji.asObservable()
            .subscribe { enabled -> newState { copy(autoEmojiEnabled = enabled) } }

        val delayedSendingLabels = context.resources.getStringArray(R.array.delayed_sending_labels)
        disposables += prefs.sendDelay.asObservable()
            .subscribe { id ->
                newState {
                    copy(
                        sendDelaySummary = delayedSendingLabels[id],
                        sendDelayId = id
                    )
                }
            }

        disposables += prefs.delivery.asObservable()
            .subscribe { enabled -> newState { copy(deliveryEnabled = enabled) } }

        disposables += prefs.signature.asObservable()
            .subscribe { signature -> newState { copy(signature = signature) } }

//        val textSizeLabels = context.resources.getStringArray(R.array.text_sizes)
//        disposables += prefs.textSize.asObservable()
//            .subscribe { textSize ->
//                newState { copy(textSizeSummary = textSizeLabels[textSize], textSizeId = textSize) }
//            }

        disposables += prefs.autoColor.asObservable()
            .subscribe { autoColor -> newState { copy(autoColor = autoColor) } }

        disposables += prefs.systemFont.asObservable()
            .subscribe { enabled -> newState { copy(systemFontEnabled = enabled) } }

        disposables += prefs.unicode.asObservable()
            .subscribe { enabled -> newState { copy(stripUnicodeEnabled = enabled) } }

        disposables += prefs.mobileOnly.asObservable()
            .subscribe { enabled -> newState { copy(mobileOnly = enabled) } }

        disposables += prefs.longAsMms.asObservable()
            .subscribe { enabled -> newState { copy(longAsMms = enabled) } }

        val mmsSizeLabels = context.resources.getStringArray(R.array.mms_sizes)
        val mmsSizeIds = context.resources.getIntArray(R.array.mms_sizes_ids)
        disposables += prefs.mmsSize.asObservable()
            .subscribe { maxMmsSize ->
                val index = mmsSizeIds.indexOf(maxMmsSize)
                newState {
                    copy(
                        maxMmsSizeSummary = mmsSizeLabels[index],
                        maxMmsSizeId = maxMmsSize
                    )
                }
            }

        disposables += syncRepo.syncProgress
            .sample(16, TimeUnit.MILLISECONDS)
            .distinctUntilChanged()
            .subscribe { syncProgress -> newState { copy(syncProgress = syncProgress) } }

        disposables += syncMessages
    }

    override fun bindIntents(view: SettingsView) {
        super.bindIntents(view)

        view.preferenceClicks()
            .autoDispose(view.scope())
            .subscribe {
                Timber.v("Preference click: ${context.resources.getResourceName(it.id)}")

                when (it.id) {
                    R.id.theme -> {
                        Log.v("PreferenceClicks", "theme.showThemePicker")
                        view.showThemePicker()
                    }

                    R.id.night -> {
                        Log.v("PreferenceClicks", "night.showNightModeDialog")
                        view.showNightModeDialog()
                    }

                    R.id.nightStart -> {
                        Log.v("PreferenceClicks", "nightStart.showStartTimePicker")
                        val date = nightModeManager.parseTime(prefs.nightStart.get())
                        view.showStartTimePicker(
                            date.get(Calendar.HOUR_OF_DAY),
                            date.get(Calendar.MINUTE)
                        )
                    }

                    R.id.nightEnd -> {
                        Log.v("PreferenceClicks", "nightEnd.showEndTimePicker")
                        val date = nightModeManager.parseTime(prefs.nightEnd.get())
                        view.showEndTimePicker(
                            date.get(Calendar.HOUR_OF_DAY),
                            date.get(Calendar.MINUTE)
                        )
                    }

                    R.id.black -> {
                        Log.v("PreferenceClicks", "black:${prefs.black.get()}")
                        prefs.black.set(!prefs.black.get())
                    }

                    R.id.autoEmoji -> {
                        Log.v("PreferenceClicks", "autoEmoji:${prefs.autoEmoji.get()}")
                        prefs.autoEmoji.set(!prefs.autoEmoji.get())
                    }

                    R.id.notifications -> {
                        Log.v("PreferenceClicks", "notifications.showNotificationSettings")
                        navigator.showNotificationSettings()
                    }

                    R.id.swipeActions -> {
                        Log.v("PreferenceClicks", "swipeActions.showSwipeActions")
                        view.showSwipeActions()
                    }

                    R.id.delayed -> {
                        Log.v("PreferenceClicks", "delayed.showDelayDurationDialog")
                        view.showDelayDurationDialog()
                    }

                    R.id.delivery -> {
                        Log.v("PreferenceClicks", "delivery:${prefs.delivery.get()}")
                        prefs.delivery.set(!prefs.delivery.get())
                    }

                    R.id.signature -> {
                        Log.v("PreferenceClicks", "signature:${prefs.signature.get()}")
                        view.showSignatureDialog(prefs.signature.get())
                    }

                    R.id.textSize -> {
                        Log.v("PreferenceClicks", "textSize.showTextSizePicker")
                        view.showTextSizePicker()
                    }

                    R.id.autoColor -> {
                        Log.v("PreferenceClicks", "autoColor:${prefs.autoColor.get()}")
                        analytics.setUserProperty("Preference: Auto Color", !prefs.autoColor.get())
                        prefs.autoColor.set(!prefs.autoColor.get())
                    }

                    R.id.systemFont -> {
                        Log.v("PreferenceClicks", "systemFont:${prefs.systemFont.get()}")
                        prefs.systemFont.set(!prefs.systemFont.get())
                    }

                    R.id.unicode -> {
                        Log.v("PreferenceClicks", "unicode:${prefs.unicode.get()}")
                        prefs.unicode.set(!prefs.unicode.get())
                    }

                    R.id.mobileOnly -> {
                        Log.v("PreferenceClicks", "mobileOnly:${prefs.mobileOnly.get()}")
                        prefs.mobileOnly.set(!prefs.mobileOnly.get())
                    }

                    R.id.longAsMms -> {
                        Log.v("PreferenceClicks", "longAsMms:${prefs.longAsMms.get()}")
                        prefs.longAsMms.set(!prefs.longAsMms.get())
                    }

                    R.id.mmsSize -> {
                        Log.v("PreferenceClicks", "mmsSize.showMmsSizePicker")
                        view.showMmsSizePicker()
                    }

                    R.id.sync -> {
                        Log.v("PreferenceClicks", "sync.syncMessages.execute")
                        syncMessages.execute(Unit)
                    }
                }
            }

//        view.aboutLongClicks()
//            .map { !prefs.logging.get() }
//            .doOnNext { enabled -> prefs.logging.set(enabled) }
//            .autoDispose(view.scope())
//            .subscribe { enabled ->
//                context.makeToast(
//                    when (enabled) {
//                        true -> R.string.settings_logging_enabled
//                        false -> R.string.settings_logging_disabled
//                    }
//                )
//            }

        view.nightModeSelected()
            .autoDispose(view.scope())
            .subscribe { mode ->
                nightModeManager.updateNightMode(mode)
            }


        view.nightStartSelected()
            .autoDispose(view.scope())
            .subscribe { nightModeManager.setNightStart(it.first, it.second) }

        view.nightEndSelected()
            .autoDispose(view.scope())
            .subscribe { nightModeManager.setNightEnd(it.first, it.second) }

        view.textSizeSelected()
            .autoDispose(view.scope())
            .subscribe(prefs.textSize::set)

        view.sendDelaySelected()
            .autoDispose(view.scope())
            .subscribe { duration ->
                prefs.sendDelay.set(duration)
            }

        view.signatureSet()
            .doOnNext(prefs.signature::set)
            .autoDispose(view.scope())
            .subscribe()

        view.mmsSizeSelected()
            .autoDispose(view.scope())
            .subscribe(prefs.mmsSize::set)
    }

}