package messages.sms.text.chat.messanger.app.password

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.core.graphics.ColorUtils
import com.google.android.material.bottomsheet.BottomSheetDialog
import dagger.android.AndroidInjection
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.common.base.QkThemedActivity
import messages.sms.text.chat.messanger.app.common.util.extensions.setTint
import messages.sms.text.chat.messanger.app.common.util.extensions.viewBinding
import messages.sms.text.chat.messanger.app.commons.extensions.addAlpha
import messages.sms.text.chat.messanger.app.commons.extensions.applyColorFilter
import messages.sms.text.chat.messanger.app.commons.extensions.baseConfig
import messages.sms.text.chat.messanger.app.commons.extensions.updateTextColors
import messages.sms.text.chat.messanger.app.commons.tablayout.tintDrawableColor
import messages.sms.text.chat.messanger.app.databinding.ActivityForgetPasswordBinding
import messages.sms.text.chat.messanger.app.feature.main.PrivateConversationsActivity

class ForgetPasswordActivity : QkThemedActivity() {

    private val binding by viewBinding(ActivityForgetPasswordBinding::inflate)


    private var password = ""
    private var mTempPassword = ""
    private lateinit var dots: List<ImageView>
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationIcon(R.drawable.ic_chevron_left_vector)

        title = resources.getString(R.string.forgotpassword)

        init()
        setUpTheme()


        setNumberButtonListeners()
        setBackspaceListener()
    }


    private fun setNumberButtonListeners() {
        val buttons = listOf<Button>(
            binding.btn1,
            binding.btn2,
            binding.btn3,
            binding.btn4,
            binding.btn5,
            binding.btn6,
            binding.btn7,
            binding.btn8,
            binding.btn9,
            binding.btn0
        )

        buttons.forEach { button ->
            button.setOnClickListener {
                if (password.length < 4) {
                    password += (button.text as String)
                    updateDots()
                }
                if (password.length == 4) {
                    // Handle 4-digit password entered
                    handlePasswordEntered()
                }
            }
        }
    }

    private fun setBackspaceListener() {
        binding.btnBackspace.setOnClickListener {
            if (password.isNotEmpty()) {
                password = password.dropLast(1)
                updateDots()
            }
        }

        binding.forgetpassword.setOnClickListener {
            startActivity(
                Intent(
                    this@ForgetPasswordActivity,
                    ForgetPasswordActivity::class.java
                )
            )
        }
    }

    private fun updateDots() {
        for (i in 0 until 4) {
            if (i < password.length) {
                dots[i].setImageResource(R.drawable.ic_dot_filled)
            } else {
                dots[i].setImageResource(R.drawable.ic_dot_empty)
            }
        }
    }

    private fun handlePasswordEntered() {
        if (mTempPassword.isNotEmpty()) {
            if (mTempPassword == password) {
                baseConfig.privatePin = password
                binding.tvEnterPassword.text = "Please enter your pin"
                password = ""
                updateDots()

                // Set Security Question Here
                showSecurityQuestionBottomSheet(1)

                } else {
                binding.tvEnterPassword.text = "PIN does not match. Try again"
                password = ""
                mTempPassword = ""
                updateDots()
                }

            } else {
            if (password.length == 4) {
                binding.tvEnterPassword.text = "Please confirm your pin"
                mTempPassword = password
                password = ""
                updateDots()
            }
        }
    }

    private fun init() {

        binding.tvEnterPassword.text = "Create your pin"

        showSecurityQuestionBottomSheet(0)

        dots = listOf(
            binding.dot1,
            binding.dot2,
            binding.dot3,
            binding.dot4
        )
    }

    private fun showSecurityQuestionBottomSheet(value: Int) {
        val bottomSheetDialog = BottomSheetDialog(this, R.style.BottomSheetDialogTheme)
        val view = layoutInflater.inflate(R.layout.bottomsheet_layout_security, null)

        val spinner: Spinner = view.findViewById(R.id.security_question_spinner)
        val answerEditText: EditText = view.findViewById(R.id.security_answer_edittext)
        val saveButton: Button = view.findViewById(R.id.btn_save)
        val skipButton: Button = view.findViewById(R.id.btn_skip)
        val spinner_icon: ImageView = view.findViewById(R.id.spinner_icon)

        spinner.tintDrawableColor(baseConfig.primaryColor)
        saveButton.backgroundTintList = ColorStateList.valueOf(baseConfig.primaryColor)
        spinner_icon.setTint(baseConfig.primaryColor)

        saveButton.setOnClickListener {
            val selectedQuestion = spinner.selectedItem.toString()
            val answer = answerEditText.text.toString()

            if (value == 0) {
                if (answer.isNotEmpty() && answer == baseConfig.securityAnswer) {
                    bottomSheetDialog.dismiss()
                    baseConfig.privatePin = ""
                } else {
                    Toast.makeText(this, "Your answer is not correct", Toast.LENGTH_SHORT).show()
                }
            } else {
                if (selectedQuestion.contains("question")) {
                    Toast.makeText(this, "Select security questions first", Toast.LENGTH_SHORT)
                        .show()
                    return@setOnClickListener
                }

                if (answer.isNotEmpty() && answer.length >= 3) {
                    baseConfig.securityAnswer = answer
                    bottomSheetDialog.dismiss()
                    val intent = Intent(this, PrivateConversationsActivity::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    Toast.makeText(this, "Enter at least 3 character", Toast.LENGTH_SHORT).show()
                }
            }
        }

        skipButton.setOnClickListener {
            // Handle the skip action
            bottomSheetDialog.dismiss()
            finish()
        }
        bottomSheetDialog.setContentView(view)
        bottomSheetDialog.setCancelable(false)
        bottomSheetDialog.setCanceledOnTouchOutside(false)
        bottomSheetDialog.show()
    }

    private fun setUpTheme() {

        val primaryColorWithAlpha =
            ColorUtils.setAlphaComponent(baseConfig.primaryColor, (255 * 0.1).toInt())

        val textColorPrimaryss = baseConfig.textColor
        val colorWithAlpha = textColorPrimaryss.addAlpha(0.6F)


        updateTextColors(binding.mainLayout)

//        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
        if (baseConfig.backgroundColor.equals(Color.BLACK)) {
            binding.toolbar.background =
                ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))

        } else {
            binding.toolbar.background = ColorDrawable(baseConfig.statusBarColor)

        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource != -1) {
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.mainLayout.background = drawable
                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
            }
        } else {
            binding.mainLayout.background = null
            toolbar.setBackgroundColor(baseConfig.backgroundColor)

        }

        if (baseConfig.backgroundColor.equals(baseConfig.primaryColor)) {
            val applyBackground = ResourcesCompat.getDrawable(
                resources,
                R.drawable.button_background_rounded,
                getTheme()
            ) as RippleDrawable

            (applyBackground as LayerDrawable).findDrawableByLayerId(R.id.button_background_holder)
                .applyColorFilter(Color.parseColor("#FFFFFF"))
        } else {
            val applyBackground = ResourcesCompat.getDrawable(
                resources,
                R.drawable.button_background_rounded,
                getTheme()
            ) as RippleDrawable
            (applyBackground as LayerDrawable).findDrawableByLayerId(R.id.button_background_holder)
                .applyColorFilter(baseConfig.primaryColor)
        }

    }
}