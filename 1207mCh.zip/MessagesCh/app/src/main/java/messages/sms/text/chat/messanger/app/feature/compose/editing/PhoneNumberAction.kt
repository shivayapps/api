package messages.sms.text.chat.messanger.app.feature.compose.editing

enum class PhoneNumberAction {
    CANCEL,
    JUST_ONCE,
    ALWAYS
}
