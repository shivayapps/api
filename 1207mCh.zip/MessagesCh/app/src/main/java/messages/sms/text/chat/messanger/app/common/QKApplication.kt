package messages.sms.text.chat.messanger.app.common

//import com.uber.rxdogtag.RxDogTag
//import com.uber.rxdogtag.autodispose.AutoDisposeConfigurer
import android.app.Activity
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.core.provider.FontRequest
import androidx.emoji.text.EmojiCompat
import androidx.emoji.text.FontRequestEmojiCompatConfig
//import com.caller.card.keep.CallerAdType
//import com.caller.card.keep.CallerCardGlobal
//import com.caller.card.keep.CallerFirebaseEventListener
import com.google.firebase.FirebaseApp
import dagger.android.AndroidInjector
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import io.realm.Realm
import io.realm.RealmConfiguration
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.ads.AdsApplication
import messages.sms.text.chat.messanger.app.ads.firebaseAnalyticsHandler
import messages.sms.text.chat.messanger.app.ads.getAppCallerCardNative
import messages.sms.text.chat.messanger.app.common.util.CrashlyticsTree
import messages.sms.text.chat.messanger.app.common.util.FileLoggingTree
import messages.sms.text.chat.messanger.app.common.util.extensions.applyEdgeToEdgeInsets
import messages.sms.text.chat.messanger.app.commons.extensions.clientConfigPref
import messages.sms.text.chat.messanger.app.injection.AppComponentManager
import messages.sms.text.chat.messanger.app.injection.appComponent
import messages.sms.text.chat.messanger.app.manager.AnalyticsManager
import messages.sms.text.chat.messanger.app.manager.ReferralManager
import messages.sms.text.chat.messanger.app.migration.QkMigration
import messages.sms.text.chat.messanger.app.migration.QkRealmMigration
import messages.sms.text.chat.messanger.app.util.NightModeManager
import timber.log.Timber
import javax.inject.Inject

class QKApplication : AdsApplication(), HasAndroidInjector {


    companion object {
        var isUpdateDialog: Boolean? = null

        var adCount: Int = 0

        var currentActivity: Activity? = null

        var appUpdateUrl: String = ""

        var callercad_ad_type: String = ""

        var callerdialog_closable: Boolean = false
        // public static Boolean splashOpenAds = false;

        var callerdialog_showornot: Boolean = true

        var stopLangInter: Boolean = true
    }

    /**
     * Inject these so that they are forced to initialize
     */
    @Suppress("unused")
    @Inject
    lateinit var analyticsManager: AnalyticsManager

    @Suppress("unused")
    @Inject
    lateinit var qkMigration: QkMigration

    @Inject
    lateinit var fileLoggingTree: FileLoggingTree

    @Inject
    lateinit var nightModeManager: NightModeManager

    @Inject
    lateinit var realmMigration: QkRealmMigration

    @Inject
    lateinit var referralManager: ReferralManager

    @Inject
    lateinit var androidInjector: DispatchingAndroidInjector<Any>
    override fun androidInjector(): AndroidInjector<Any> = androidInjector
    override fun onCreate() {
        super.onCreate()
        FirebaseApp.initializeApp(this)
        AppComponentManager.init(this)
        appComponent.inject(this)

        Realm.init(this)
        Realm.setDefaultConfiguration(
            RealmConfiguration.Builder()
                .compactOnLaunch()
                .migration(realmMigration)
                .allowWritesOnUiThread(true)
                .schemaVersion(QkRealmMigration.SchemaVersion)
                .build()

        )

        registerActivityLifecycle()

        /* val config = RealmConfiguration.Builder()
             .migration(realmMigration)
             .schemaVersion(QkRealmMigration.SchemaVersion)
             .allowWritesOnUiThread(true)
             .build()
         Realm.setDefaultConfiguration(config)*/


        qkMigration.performMigration()

        initializeCallerCard()
        GlobalScope.launch(Dispatchers.IO) {
            referralManager.trackReferrer()
        }

        nightModeManager.updateCurrentTheme()

        val fontRequest = FontRequest(
            "com.google.android.gms.fonts",
            "com.google.android.gms",
            "Noto Color Emoji Compat",
            R.array.com_google_android_gms_fonts_certs
        )

        EmojiCompat.init(FontRequestEmojiCompatConfig(this, fontRequest))

        Timber.plant(Timber.DebugTree(), CrashlyticsTree(), fileLoggingTree)

//        CoroutineScope(Dispatchers.IO).launch {
//            RxJavaPlugins.setErrorHandler { throwable: Throwable? ->
////                LogE("onCreate: ", throwable?.message.toString())
//            }
//        }
//        RxDogTag.builder()
//            .configureWith(AutoDisposeConfigurer::configure)
//            .install()
    }


    private fun registerActivityLifecycle() {
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityCreated(
                activity: Activity,
                savedInstanceState: Bundle?
            ) {
                activity.applyEdgeToEdgeInsets()
            }

            override fun onActivityStarted(activity: Activity) {}
            override fun onActivityResumed(activity: Activity) {}
            override fun onActivityPaused(activity: Activity) {}
            override fun onActivityStopped(activity: Activity) {}
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
            override fun onActivityDestroyed(activity: Activity) {}
        })
    }

    fun initializeCallerCard() {
//        val adType =
//            if (clientConfigPref.callerCardAdType.equals("banner")) CallerAdType.BANNER else CallerAdType.NATIVE
//        CallerCardGlobal.initilizeCallerCard(
//            this,
//            "",
//            getAppCallerCardNative(),
//            adType, ContextCompat.getDrawable(this, R.mipmap.ic_launcher),
//            object : CallerFirebaseEventListener {
//                override fun onEventListen(eventName: String) {
//                    firebaseAnalyticsHandler.logMessages(eventName, "CallerCard")
//                }
//            }
//        )
    }

}