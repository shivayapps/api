package messages.sms.text.chat.messanger.app.common.base

import androidx.lifecycle.LifecycleOwner

interface QkViewContract<in State> : LifecycleOwner {

    fun render(state: State)

}