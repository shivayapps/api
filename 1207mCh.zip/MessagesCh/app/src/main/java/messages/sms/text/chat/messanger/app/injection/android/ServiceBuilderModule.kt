package messages.sms.text.chat.messanger.app.injection.android

import dagger.Module
import dagger.android.ContributesAndroidInjector
import messages.sms.text.chat.messanger.app.feature.backup.RestoreBackupService
import messages.sms.text.chat.messanger.app.injection.scope.ActivityScope
import messages.sms.text.chat.messanger.app.receiver.SendSmsReceiver
import messages.sms.text.chat.messanger.app.service.HeadlessSmsSendService

@Module
abstract class ServiceBuilderModule {

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindHeadlessSmsSendService(): HeadlessSmsSendService

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindRestoreBackupService(): RestoreBackupService

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindSendSmsReceiver(): SendSmsReceiver

}
