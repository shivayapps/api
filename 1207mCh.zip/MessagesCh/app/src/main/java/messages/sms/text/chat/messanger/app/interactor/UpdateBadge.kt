package messages.sms.text.chat.messanger.app.interactor

import io.reactivex.Flowable
import messages.sms.text.chat.messanger.app.manager.ShortcutManager
import messages.sms.text.chat.messanger.app.manager.WidgetManager
import javax.inject.Inject

class UpdateBadge @Inject constructor(
    private val shortcutManager: ShortcutManager,
    private val widgetManager: WidgetManager,
) : Interactor<Unit>() {

    override fun buildObservable(params: Unit): Flowable<*> {
        return Flowable.just(params)
            .doOnNext { shortcutManager.updateBadge() }
            .doOnNext { widgetManager.updateUnreadCount() }
    }

}