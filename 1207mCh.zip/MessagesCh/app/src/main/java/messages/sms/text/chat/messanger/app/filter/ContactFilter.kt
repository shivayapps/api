package messages.sms.text.chat.messanger.app.filter

import messages.sms.text.chat.messanger.app.extensions.removeAccents
import messages.sms.text.chat.messanger.app.model.Contact
import messages.sms.text.chat.messanger.app.model.ContactData
import javax.inject.Inject

class ContactFilter @Inject constructor(private val phoneNumberFilter: PhoneNumberFilter) :
    Filter<Contact>() {

    override fun filter(item: Contact, query: CharSequence): Boolean {
        return item.name.removeAccents().contains(query, true) || // Name
                item.numbers.map { it.address }
                    .any { address -> phoneNumberFilter.filter(address, query) } // Number
    }

}

class ContactFilter2 @Inject constructor(private val phoneNumberFilter: PhoneNumberFilter) :
    Filter<ContactData>() {

    override fun filter(item: ContactData, query: CharSequence): Boolean {
        return item.name.removeAccents().contains(query, true) || // Name
                item.numbers.map { it.address }
                    .any { address -> phoneNumberFilter.filter(address, query) } // Number
    }

}