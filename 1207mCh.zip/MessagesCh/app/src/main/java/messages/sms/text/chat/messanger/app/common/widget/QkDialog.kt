package messages.sms.text.chat.messanger.app.common.widget

import android.app.Activity
import androidx.annotation.StringRes
import androidx.appcompat.app.AlertDialog
import androidx.core.view.isVisible
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.common.base.QkAdapter
import messages.sms.text.chat.messanger.app.commons.extensions.baseConfig
import messages.sms.text.chat.messanger.app.databinding.QkDialogBinding

class QkDialog(private val context: Activity) :
    AlertDialog(context, R.style.CustomFieldDialogTheme) {

    private val binding = QkDialogBinding.inflate(context.layoutInflater)

    @StringRes
    var titleRes: Int? = null
        set(value) {
            field = value
            title = value?.let(context::getString)
        }

    var title: String? = null
        set(value) {
            field = value
            binding.title.text = value
            binding.title.isVisible = !value.isNullOrBlank()
        }

    @StringRes
    var subtitleRes: Int? = null
        set(value) {
            field = value
            subtitle = value?.let(context::getString)
        }

    var subtitle: String? = null
        set(value) {
            field = value
            binding.subtitle.text = value
            binding.subtitle.isVisible = !value.isNullOrBlank()
        }

    var adapter: QkAdapter<*, *>? = null
        set(value) {
            field = value
            binding.list.isVisible = value != null
            binding.list.adapter = value
        }

    var positiveButtonListener: (() -> Unit)? = null

    @StringRes
    var positiveButton: Int? = null
        set(value) {
            field = value
            value?.run(binding.positiveButton::setText)
            binding.positiveButton.isVisible = value != null
            binding.positiveButton.setOnClickListener {
                positiveButtonListener?.invoke() ?: dismiss()
            }
            binding.positiveButton.setTextColor(context.baseConfig.primaryColor)
        }

    var negativeButtonListener: (() -> Unit)? = null

    @StringRes
    var negativeButton: Int? = null
        set(value) {
            field = value
            value?.run(binding.negativeButton::setText)
            binding.negativeButton.isVisible = value != null
            binding.negativeButton.setOnClickListener {
                negativeButtonListener?.invoke() ?: dismiss()
            }

            binding.positiveButton.setTextColor(context.getColor(R.color.black))
        }

    var cancelListener: (() -> Unit)? = null
        set(value) {
            field = value
            setOnCancelListener { value?.invoke() }
        }

    init {
        setView(binding.root)
    }

}
