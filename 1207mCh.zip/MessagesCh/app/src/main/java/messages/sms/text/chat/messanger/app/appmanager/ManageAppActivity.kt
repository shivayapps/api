package messages.sms.text.chat.messanger.app.appmanager

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.gms.ads.nativead.NativeAd
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.ads.AdmobNative
import messages.sms.text.chat.messanger.app.ads.AdmobNative.nativeAdManageApps
import messages.sms.text.chat.messanger.app.ads.delayExecution
import messages.sms.text.chat.messanger.app.ads.getAppManageAppsNative
import messages.sms.text.chat.messanger.app.commons.extensions.updateTextColors
import messages.sms.text.chat.messanger.app.databinding.ActivityManageAppBinding

class ManageAppActivity : AppCompatActivity() {

    private lateinit var appListAdapter: AppListAdapter

    companion object {
        var totalStoppedCount = 0
        var stoppedAppList = ArrayList<String>()
    }

    lateinit var binding: ActivityManageAppBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityManageAppBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateTextColors(binding.clManageApp)


//        setupToolbar(binding.customizationToolbar, NavigationIcon.Arrow, getColor(R.color.white))
//        binding.customizationToolbar.background=null
        binding.customizationToolbar.setBackgroundColor(Color.TRANSPARENT)
        binding.customizationToolbar.title = "Manage Apps"
        setSupportActionBar(binding.customizationToolbar)
        stoppedAppList.clear()
        totalStoppedCount = 0
        // Enable the back button
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        // Handle back button click
        binding.customizationToolbar.setNavigationOnClickListener { view ->
            // Finish the activity or handle the back navigation
            onBackPressed()
        }

        if (nativeAdManageApps != null) {

            showAds(nativeAdManageApps)
        } else {
            loadNative()
        }
        binding.btnOk.setOnClickListener { view ->

            if (stoppedAppList.size > 0) {
                stoppedAppList = ArrayList(stoppedAppList.toSet())


                for (item in stoppedAppList) {
                    //  if(!isAppRunning(this@ManageAppActivity,item)){
                    totalStoppedCount++
                    //    }
                }
            }
            startActivity(Intent(this@ManageAppActivity, FinalManageAppScreenActivity::class.java))
            finish()
            //  onBackPressed()
        }

//        usestatusbar=false
//        3774FF
        window.statusBarColor = ContextCompat.getColor(this, R.color.primary)

        binding.loader.visibility = View.VISIBLE

        CoroutineScope(Dispatchers.Main).launch {

            val launcherViewModel = LauncherViewModel()
            val appList = launcherViewModel.retrieveInstalledApps(this@ManageAppActivity)
            appListAdapter = AppListAdapter(
                this@ManageAppActivity,
                appList,
                object : AppListAdapter.IAppLaunchListener {
                    override fun onAppSelected(appModel: AppModel) {
//                val optionsDialog=OptionsBottomSheetFragment(appModel)
//                optionsDialog.show(supportFragmentManager,optionsDialog.tag)
                        stoppedAppList.add(appModel.packageName)
                        Log.e("TAG", "onAppSelected: " + appModel.packageName)
                    }
                })

            binding.rvAppList.adapter = appListAdapter

            binding.appsCount.text = "Total " + appList.size.toString() + " apps"

            binding.loader.visibility = View.GONE
        }


        showRAMUsage()

    }


    fun isAppRunning(context: Context, packageName: String): Boolean {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val appProcesses = activityManager.runningAppProcesses

        return appProcesses.any { it.processName == packageName && it.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND }
    }



    private fun showRAMUsage() {

        val totalRamValue = totalRamMemorySize()
        val freeRamValue = freeRamMemorySize()
        val usedRamValue = totalRamValue - freeRamValue

//        tvUsedMemory?.text = mResources.getString(R.string.used_memory) + "\t" + formatSize(usedRamValue)
//        tvFreeMemory?.text = mResources.getString(R.string.free) + "\t" + formatSize(freeRamValue)
//        tvTotalMemory?.text = mResources.getString(R.string.total) + "\t" + formatSize(totalRamValue)

        val usedPercent =
            calculatePercentage(usedRamValue.toDouble(), totalRamValue.toDouble()).toFloat()
        binding.tvPercent.setText("$usedPercent")
//        donutRAMUsage?.progress = Methods.calculatePercentage(usedRamValue.toDouble(), totalRamValue.toDouble()).toFloat()
    }

    fun calculatePercentage(value: Double, total: Double): Int {
        val usage = (value * 100.0f / total).toInt().toDouble()
        return usage.toInt()
    }

    private fun totalRamMemorySize(): Long {
        val mi = ActivityManager.MemoryInfo()
        val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        activityManager.getMemoryInfo(mi)
        return mi.totalMem
    }

    private fun freeRamMemorySize(): Long {
        val mi = ActivityManager.MemoryInfo()
        val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        activityManager.getMemoryInfo(mi)

        return mi.availMem
    }


    private fun loadNative() {
        binding.inNative.shimmerView.startShimmer()
        delayExecution(500) {
            AdmobNative.preLoad(this, { isLoaded, nativeAd ->
                showAds(nativeAd)
            }, getAppManageAppsNative())
        }
    }

    private fun showAds(nativeAd: NativeAd?) {
        if (nativeAd != null) {
            AdmobNative.populateManageAppNativeAd(this, binding.inNative.cvRoot, nativeAd)
        } else {
            binding.adView.visibility = View.GONE
            binding.inNative.shimmerView.stopShimmer()
        }
    }

    override fun onDestroy() {
        super.onDestroy()

        nativeAdManageApps?.destroy()
        nativeAdManageApps = null
    }
}
