package messages.sms.text.chat.messanger.app.ads

import android.content.Context
import messages.sms.text.chat.messanger.app.util.PRIVACY_POLICY

fun Context.getSharedPrefs() = getSharedPreferences(PREFS_KEY, Context.MODE_PRIVATE)
const val PREF_ENABLE_SALES2 = "pref_enable_sales2"
const val PREF_ENABLE_SALES1 = "pref_enable_sales1"
const val PREFS_KEY = "ClientConfigPref"

class ClientConfigPref(context: Context) {
    protected val prefs = context.getSharedPrefs()

    companion object {
        fun newInstance(context: Context) = ClientConfigPref(context)
    }

    var enableSales2: Boolean
        get() = prefs.getBoolean(PREF_ENABLE_SALES2, true)
        set(enableSales2) = prefs.edit().putBoolean(PREF_ENABLE_SALES2, enableSales2).apply()
    var enableSales1: Boolean
        get() = prefs.getBoolean(PREF_ENABLE_SALES1, true)
        set(enableSales1) = prefs.edit().putBoolean(PREF_ENABLE_SALES1, enableSales1).apply()

    var sale2Created: Int
        get() = prefs.getInt("sales2_created", 0)
        set(sale2Created) = prefs.edit().putInt("sales2_created", sale2Created).apply()

    var maxTapTime: Int
        get() = prefs.getInt("maxTapTime", 30)
        set(maxTapTime) = prefs.edit().putInt("maxTapTime", maxTapTime).apply()

    var maxTapCount: Int
        get() = prefs.getInt("maxTapCount", 3)
        set(maxTapCount) = prefs.edit().putInt("maxTapCount", maxTapCount).apply()

    var sale1Created: Int
        get() = prefs.getInt("sales1_created", 0)
        set(sale1Created) = prefs.edit().putInt("sales1_created", sale1Created).apply()


    var adsEnable: Boolean
        get() = /*!isPurchased &&*//* !BuildConfig.DEBUG &&*/ prefs.getBoolean(
            "PREF_ADS_ENABLED",
            true
        )
        set(adsEnable) = prefs.edit().putBoolean("PREF_ADS_ENABLED", adsEnable).apply()

    var isPurchased: Boolean
        get() = prefs.getBoolean("PREF_PURCHASED", false)
        set(isPurchased) = prefs.edit().putBoolean("PREF_PURCHASED", isPurchased).apply()

    var privacyPolicy: String
        get() = prefs.getString("PREF_PRIVACY_POLICY", PRIVACY_POLICY) ?: PRIVACY_POLICY
        set(privacyPolicy) = prefs.edit().putString("PREF_PRIVACY_POLICY", privacyPolicy).apply()

    var feedbackEmail: String
        get() = prefs.getString("PREF_FEEDBACK_EMAIL", "") ?: ""
        set(feedbackEmail) = prefs.edit().putString("PREF_FEEDBACK_EMAIL", feedbackEmail).apply()

    var adsInChat: String
        get() = prefs.getString("adsInChat", "admob") ?: "admob"
        set(adsInChat) = prefs.edit().putString("adsInChat", adsInChat).apply()

    var callerCardAdType: String
        get() = prefs.getString("PREF_CALLER_CARD_AD_TYPE", "native") ?: "native"
        set(callerCardAdType) = prefs.edit().putString("PREF_CALLER_CARD_AD_TYPE", callerCardAdType)
            .apply()

    var reviewEmail: String
        get() = prefs.getString("PREF_reviewEmail", "") ?: ""
        set(callerCardAdType) = prefs.edit().putString("PREF_reviewEmail", callerCardAdType).apply()

    var splashAppOpenIntervalCount: Int
        get() = prefs.getInt("PREF_splashAppOpenIntervalCount", 3) ?: 3
        set(splashAppOpenIntervalCount) = prefs.edit()
            .putInt("PREF_splashAppOpenIntervalCount", splashAppOpenIntervalCount).apply()
    var splashAppOpenWaitTime: Long
        get() = prefs.getLong("PREF_splashAppOpenWaitTime", 6000) ?: 6000
        set(splashAppOpenIntervalCount) = prefs.edit()
            .putLong("PREF_splashAppOpenWaitTime", splashAppOpenIntervalCount).apply()
    var currentSplashAppOpenCount: Int
        get() = prefs.getInt("PREF_currentSplashAppOpenCount", 0)
        set(splashAppOpenIntervalCount) = prefs.edit()
            .putInt("PREF_currentSplashAppOpenCount", splashAppOpenIntervalCount).apply()

    var moreApps: String
        get() = prefs.getString("PREF_moreApps", "") ?: ""
        set(moreApps) = prefs.edit().putString("PREF_moreApps", moreApps).apply()
    var appUpdate: String
        get() = prefs.getString("PREF_appUpdate", "") ?: ""
        set(moreApps) = prefs.edit().putString("PREF_appUpdate", moreApps).apply()


    var rateAppInterval: Int
        get() = prefs.getInt("PREF_rateAppInterval", 3)
        set(value) = prefs.edit().putInt("PREF_rateAppInterval", value).apply()
    var rateAppFeedbackInterval: Int
        get() = prefs.getInt("PREF_rateAppFeedbackInterval", 5)
        set(value) = prefs.edit().putInt("PREF_rateAppFeedbackInterval", value).apply()
    var rateAppIntervalCounter: Int
        get() = prefs.getInt("PREF_rateAppIntervalCounter", 0)
        set(value) = prefs.edit().putInt("PREF_rateAppIntervalCounter", value).apply()
    var isCallerCardPermissionRequired: Boolean
        get() = prefs.getBoolean("PREF_isCallerCardPermissionRequired", false)
        set(isCallerCardPermissionRequired) = prefs.edit()
            .putBoolean("PREF_isCallerCardPermissionRequired", isCallerCardPermissionRequired)
            .apply()

}