package messages.sms.text.chat.messanger.app.feature.backup

import android.content.Context
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import io.reactivex.rxkotlin.plusAssign
import io.reactivex.rxkotlin.withLatestFrom
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.Subject
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.common.Navigator
import messages.sms.text.chat.messanger.app.common.base.QkPresenter
import messages.sms.text.chat.messanger.app.common.util.DateFormatter
import messages.sms.text.chat.messanger.app.common.util.extensions.makeToast
import messages.sms.text.chat.messanger.app.interactor.PerformBackup
import messages.sms.text.chat.messanger.app.manager.PermissionManager
import messages.sms.text.chat.messanger.app.repository.BackupRepository
import java.util.concurrent.TimeUnit
import javax.inject.Inject

class BackupPresenter @Inject constructor(
    private val backupRepo: BackupRepository,
    private val context: Context,
    private val dateFormatter: DateFormatter,
    private val navigator: Navigator,
    private val performBackup: PerformBackup,
    private val permissionManager: PermissionManager,
) : QkPresenter<BackupView, BackupState>(BackupState()) {

    //    private val storagePermissionSubject: Subject<Boolean> = BehaviorSubject.createDefault(permissionManager.hasStorage())
    private val storagePermissionSubject: Subject<Boolean> = BehaviorSubject.createDefault(true)

    init {
        disposables += backupRepo.getBackupProgress()
            .sample(16, TimeUnit.MILLISECONDS)
            .distinctUntilChanged()
            .subscribe { progress -> newState { copy(backupProgress = progress) } }

        disposables += backupRepo.getRestoreProgress()
            .sample(16, TimeUnit.MILLISECONDS)
            .distinctUntilChanged()
            .subscribe { progress -> newState { copy(restoreProgress = progress) } }

        disposables += storagePermissionSubject
            .distinctUntilChanged()
            .switchMap { backupRepo.getBackups() }
            .doOnNext { backups -> newState { copy(backups = backups) } }
            .map { backups -> backups.maxOfOrNull { it.date } ?: 0L }
            .map { lastBackup ->
                when (lastBackup) {
                    0L -> context.getString(R.string.backup_never)
                    else -> dateFormatter.getDetailedTimestamp(lastBackup)
                }
            }
            .startWith(context.getString(R.string.backup_loading))
            .subscribe { lastBackup -> newState { copy(lastBackup = lastBackup) } }

    }

    override fun bindIntents(view: BackupView) {
        super.bindIntents(view)

        view.permissionGiven()
            .distinctUntilChanged()
            .switchMap { backupRepo.getBackups() }
            .subscribe { backups -> newState { copy(backups = backups) } }

        view.activityVisible()
            .map { permissionManager.hasStorage() }
            .autoDispose(view.scope())
            .subscribe(storagePermissionSubject)

        view.restoreClicks()
            .withLatestFrom(
                backupRepo.getBackupProgress(),
                backupRepo.getRestoreProgress()
            )
            { _, backupProgress, restoreProgress ->
                when {
                    backupProgress.running -> context.makeToast(R.string.backup_restore_error_backup)
                    restoreProgress.running -> context.makeToast(R.string.backup_restore_error_restore)
//                    !permissionManager.hasStorage() -> view.requestStoragePermission()
                    else -> view.selectFile()
                }
            }
            .autoDispose(view.scope())
            .subscribe()

        view.restoreFileSelected()
            .autoDispose(view.scope())
            .subscribe { view.confirmRestore() }

        view.restoreConfirmed()
            .withLatestFrom(view.restoreFileSelected()) { _, backup -> backup }
            .autoDispose(view.scope())
            .subscribe { backup -> RestoreBackupService.start(context, backup.path) }

        view.deleteRestoreFileSelected()
            .autoDispose(view.scope())
            .subscribe { backup ->
                backupRepo.deleteBackup(backup.path)
            }

        view.stopRestoreClicks()
            .autoDispose(view.scope())
            .subscribe { view.stopRestore() }

        view.stopRestoreConfirmed()
            .autoDispose(view.scope())
            .subscribe { backupRepo.stopRestore() }

        view.stopBackup()
            .autoDispose(view.scope())
            .subscribe { backupRepo.stopBackup() }

        view.fabClicks()
            .autoDispose(view.scope())
            .subscribe { _ ->

//                if (!permissionManager.hasStorage()) {
//                    view.requestStoragePermission()
//                } else {
//                    Log.e("BackUp","execute Backup")
////                    if (conversationRepo.getAllConversationsSize() != 0) {
//                        performBackup.execute(Unit)
////                    } else
////                        view.showDialog()
//                }

//                when {
//                    !permissionManager.hasStorage() -> view.requestStoragePermission()
//                    else ->
                performBackup.execute(Unit)
//                }
            }
    }

}