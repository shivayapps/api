package messages.sms.text.chat.messanger.app.feature.personalize

import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.renderscript.Allocation
import android.renderscript.Element
import android.renderscript.RenderScript
import android.renderscript.ScriptIntrinsicBlur
import android.util.Log
import android.widget.ImageView
import android.widget.SeekBar
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.RoundedBitmapDrawableFactory
import dagger.android.AndroidInjection
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.common.base.QkThemedActivity
import messages.sms.text.chat.messanger.app.common.util.extensions.viewBinding
import messages.sms.text.chat.messanger.app.commons.extensions.baseConfig
import messages.sms.text.chat.messanger.app.databinding.ActivityCropImageThemeBinding

class CropImageThemeActivity : QkThemedActivity() {

    private var imageUri: String = "";
    lateinit var bitmap: Bitmap
    private val binding by viewBinding(ActivityCropImageThemeBinding::inflate)
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationIcon(R.drawable.ic_chevron_left_vector)

        showBackButton(true)
        setTitle(R.string.themes)


        //  imageUri = intent.getStringExtra("uri").toString()
        imageUri = intent.getParcelableExtra<Uri>("uri").toString()


        val inputStream = contentResolver.openInputStream(Uri.parse(imageUri))
        bitmap = BitmapFactory.decodeStream(inputStream)


        val roundedDrawable = RoundedBitmapDrawableFactory.create(resources, bitmap)
        roundedDrawable.cornerRadius = 30f

        binding.ivBackground.setImageDrawable(roundedDrawable)
        //  binding.ivBackgroundImage.setImageDrawable(roundedDrawable)

        binding.ivBackgroundImage.scaleType = ImageView.ScaleType.FIT_XY
        //  binding.ivBackground.scaleType = ImageView.ScaleType.FIT_XY

        setUpTheme()
        setUpListener()

    }

    private fun setUpTheme() {

        //  updateTextColors(binding.contentView)
        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
            binding.contentView.background =
                ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))
        } else {
            binding.contentView.background = ColorDrawable(baseConfig.backgroundColor)
        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource != -1) {
                Log.i("onCreate", "onCreateitemselse11111: ")
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.contentView.background = drawable
                //      toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
            }
        } else {
            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
            //   toolbar.setBackgroundColor(baseConfig.backgroundColor)
        }


        binding.btnApply.backgroundTintList = ColorStateList.valueOf(baseConfig.primaryColor)

    }


    private fun setUpListener() {

//        val backgroundColor = Color.argb(10, 0, 0, 0)
//        binding.ivTransparent.setBackgroundColor(backgroundColor)

        binding.apply.setOnClickListener {

        }
        binding.transparencySeek.setOnSeekBarChangeListener(object :
            SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                binding.transPer.text = "$progress%"
                val alphaValue = (progress * 255) / 100  // Transparency between 0 and 255

                // Set the color with transparency to the ImageView's background
                val backgroundColor =
                    Color.argb(alphaValue, 0, 0, 0) // Black color with transparency
                binding.ivTransparent.setBackgroundColor(backgroundColor)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                // Optional: You can handle actions when user starts dragging the SeekBar
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                // Optional: You can handle actions when user stops dragging the SeekBar
            }
        })
        binding.blurSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                binding.blurPer.text = "$progress%"

                /*  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                      val blurRadius = (progress.toFloat() / 10) // Max blur radius of 10
                      if (blurRadius > 0) {
                          val blurEffect = RenderEffect.createBlurEffect(blurRadius, blurRadius, Shader.TileMode.CLAMP)
                          binding.ivBackground.setRenderEffect(blurEffect)
                      } else {
                          binding.ivBackground.setRenderEffect(null)
                      }
                  }else {
                      // Fallback for API < 31: Use RenderScript for blur
                      val blurRadius = progress / 10f  // Max blur radius of 10
                      if (blurRadius > 0) {
                          // Apply RenderScript blur
                          binding.ivBackground.setImageBitmap(applyRenderScriptBlur(bitmap, blurRadius))
                      }
                  }*/
                //  binding.ivBackground.scaleType = ImageView.ScaleType.FIT_XY
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                // Optional: You can handle actions when user starts dragging the SeekBar
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                // Optional: You can handle actions when user stops dragging the SeekBar
            }
        })

        binding.transparencySeek.progress = 50
        //    binding.blurSeek.progress = 25


        val blurRadius = 6F
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val blurEffect =
                RenderEffect.createBlurEffect(blurRadius, blurRadius, Shader.TileMode.CLAMP)
            binding.ivBackgroundImage.setRenderEffect(blurEffect)
        } else {
            binding.ivBackgroundImage.setImageBitmap(applyRenderScriptBlur(bitmap, blurRadius))
        }

        val alphaValue = (75 * 255) / 100  // Transparency between 0 and 255

        // Set the color with transparency to the ImageView's background
        val backgroundColor = Color.argb(alphaValue, 0, 0, 0) // Black color with transparency
        binding.ivBackgroundImageblack.setBackgroundColor(backgroundColor)

        binding.ivBackgroundImage.scaleType = ImageView.ScaleType.FIT_XY
    }

    // Function to apply RenderScript blur for API < 31
    private fun applyRenderScriptBlur(bitmap: Bitmap, radius: Float): Bitmap {
        val outputBitmap = Bitmap.createBitmap(bitmap)

        val renderScript = RenderScript.create(this@CropImageThemeActivity)
        val input = Allocation.createFromBitmap(renderScript, bitmap)
        val output = Allocation.createFromBitmap(renderScript, outputBitmap)

        val scriptIntrinsicBlur =
            ScriptIntrinsicBlur.create(renderScript, Element.U8_4(renderScript))
        scriptIntrinsicBlur.setRadius(radius) // The blur radius (0 < radius <= 25)
        scriptIntrinsicBlur.setInput(input)
        scriptIntrinsicBlur.forEach(output)

        output.copyTo(outputBitmap)

        renderScript.destroy()
        return outputBitmap
    }


}