package messages.sms.text.chat.messanger.app.feature.blocking.manager

import io.reactivex.Observable
import io.reactivex.Single
import messages.sms.text.chat.messanger.app.common.base.QkViewContract

interface BlockingManagerView : QkViewContract<BlockingManagerState> {

    fun activityResumed(): Observable<*>
    fun qksmsClicked(): Observable<*>
//    fun callControlClicked(): Observable<*>
//    fun siaClicked(): Observable<*>

    fun showCopyDialog(manager: String): Single<Boolean>

}
