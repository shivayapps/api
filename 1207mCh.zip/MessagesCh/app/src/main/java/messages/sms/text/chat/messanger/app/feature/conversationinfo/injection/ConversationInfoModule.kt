package messages.sms.text.chat.messanger.app.feature.conversationinfo.injection

import dagger.Module
import dagger.Provides
import messages.sms.text.chat.messanger.app.feature.conversationinfo.ConversationInfoController
import messages.sms.text.chat.messanger.app.injection.scope.ControllerScope
import javax.inject.Named

@Module
class ConversationInfoModule(private val controller: ConversationInfoController) {

    @Provides
    @ControllerScope
    @Named("threadId")
    fun provideThreadId(): Long = controller.threadId

}