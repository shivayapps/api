package messages.sms.text.chat.messanger.app.password.callback;


import messages.sms.text.chat.messanger.app.password.view.Fingerprint;

/**
 * Created by Omar on 10/07/2017.
 */

public interface FailAuthCounterCallback {
    void onTryLimitReached(Fingerprint fingerprint);
}
