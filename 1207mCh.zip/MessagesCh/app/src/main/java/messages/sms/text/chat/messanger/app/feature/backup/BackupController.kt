package messages.sms.text.chat.messanger.app.feature.backup

import android.Manifest
import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.view.children
import androidx.core.view.isVisible
import com.jakewharton.rxbinding2.view.clicks
import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.common.base.QkController
import messages.sms.text.chat.messanger.app.common.util.DateFormatter
import messages.sms.text.chat.messanger.app.common.util.extensions.getLabel
import messages.sms.text.chat.messanger.app.common.util.extensions.setBackgroundTint
import messages.sms.text.chat.messanger.app.common.util.extensions.setPositiveButton
import messages.sms.text.chat.messanger.app.common.util.extensions.setTint
import messages.sms.text.chat.messanger.app.common.widget.PreferenceView
import messages.sms.text.chat.messanger.app.databinding.BackupControllerBinding
import messages.sms.text.chat.messanger.app.databinding.BackupListDialogBinding
import messages.sms.text.chat.messanger.app.injection.appComponent
import messages.sms.text.chat.messanger.app.manager.PermissionManagerImpl
import messages.sms.text.chat.messanger.app.model.BackupFile
import messages.sms.text.chat.messanger.app.repository.BackupRepository
import javax.inject.Inject

class BackupController :
    QkController<BackupView, BackupState, BackupPresenter, BackupControllerBinding>(
        BackupControllerBinding::inflate
    ), BackupView {

    @Inject
    lateinit var adapter: BackupAdapter

    @Inject
    lateinit var dateFormatter: DateFormatter

    @Inject
    override lateinit var presenter: BackupPresenter

    val activityVisibleSubject: Subject<Unit> = PublishSubject.create()
    val permissionGivenSubject: Subject<Unit> = PublishSubject.create()
    private val confirmRestoreSubject: Subject<Unit> = PublishSubject.create()
    private val stopRestoreSubject: Subject<Unit> = PublishSubject.create()
    val deleteBackupSubject: Subject<BackupFile> = PublishSubject.create()

    private val backupFilesDialog by lazy {
        val binding = BackupListDialogBinding.inflate(LayoutInflater.from(activity))
            .apply { files.adapter = adapter.apply { emptyView = empty } }

        AlertDialog.Builder(activity!!, R.style.CustomFieldDialogTheme)
            .setView(binding.root)
            .setCancelable(true)
            .create()
    }

    private val confirmRestoreDialog by lazy {
        AlertDialog.Builder(activity!!, R.style.CustomFieldDialogTheme)
            .setTitle(R.string.backup_restore_confirm_title)
            .setMessage(R.string.backup_restore_confirm_message)
            .setPositiveButton(R.string.backup_restore_title, confirmRestoreSubject)
            .setNegativeButton(R.string.button_cancel, null)
            .create()
    }

    private val stopRestoreDialog by lazy {
        AlertDialog.Builder(activity!!, R.style.CustomFieldDialogTheme)
            .setTitle(R.string.backup_restore_stop_title)
            .setMessage(R.string.backup_restore_stop_message)
            .setPositiveButton(R.string.button_stop, stopRestoreSubject)
            .setNegativeButton(R.string.button_cancel, null)
            .create()
    }

    init {
        appComponent.inject(this)
    }

    override fun onAttach(view: View) {
        super.onAttach(view)
        presenter.bindIntents(this)
        setTitle(R.string.backup_title)
//        showBackButton(true)
    }

    override fun onViewCreated() {
        super.onViewCreated()

        themedActivity?.colors?.theme()?.let { theme ->
            binding.progressBar.indeterminateTintList = ColorStateList.valueOf(theme.theme)
            binding.progressBar.progressTintList = ColorStateList.valueOf(theme.theme)
            binding.fab.setBackgroundTint(theme.theme)
            binding.fabIcon.setTint(theme.textPrimary)
            binding.fabLabel.setTextColor(theme.textPrimary)
        }

        // Make the list titles bold
        binding.linearLayout.children
            .mapNotNull { view -> view as? PreferenceView }
            .map { preferenceView -> preferenceView.binding.titleView }
            .forEach { it.setTypeface(it.typeface, Typeface.BOLD) }
    }

    override fun onActivityResumed(activity: Activity) {
        super.onActivityResumed(activity)
        activityVisibleSubject.onNext(Unit)
    }

    override fun render(state: BackupState) {
        when {
            state.backupProgress.running -> {
                binding.progressIcon.setImageResource(R.drawable.ic_file_upload_black_24dp)
                binding.progressTitle.setText(R.string.backup_backing_up)
                binding.progressSummary.text = state.backupProgress.getLabel(activity!!)
                binding.progressSummary.isVisible = binding.progressSummary.text.isNotEmpty()
                binding.progressCancel.isVisible = false
                val running = (state.backupProgress as? BackupRepository.Progress.Running)
                binding.progressBar.isVisible =
                    state.backupProgress.indeterminate || running?.max ?: 0 > 0
                binding.progressBar.isIndeterminate = state.backupProgress.indeterminate
                binding.progressBar.max = running?.max ?: 0
                binding.progressBar.progress = running?.count ?: 0
                binding.progress.isVisible = true
                binding.fab.isVisible = false
            }

            state.restoreProgress.running -> {
                binding.progressIcon.setImageResource(R.drawable.ic_file_download_black_24dp)
                binding.progressTitle.setText(R.string.backup_restoring)
                binding.progressSummary.text = state.restoreProgress.getLabel(activity!!)
                binding.progressSummary.isVisible = binding.progressSummary.text.isNotEmpty()
                binding.progressCancel.isVisible = true
                val running = (state.restoreProgress as? BackupRepository.Progress.Running)
                binding.progressBar.isVisible =
                    state.restoreProgress.indeterminate || running?.max ?: 0 > 0
                binding.progressBar.isIndeterminate = state.restoreProgress.indeterminate
                binding.progressBar.max = running?.max ?: 0
                binding.progressBar.progress = running?.count ?: 0
                binding.progress.isVisible = true
                binding.fab.isVisible = false
            }

            else -> {
                binding.progress.isVisible = false
                binding.fab.isVisible = true
            }
        }

        binding.backup.summary = state.lastBackup


        Log.e("BackUp", "getBackups.003:${state.backups.size}")
        adapter.data = state.backups

        binding.fabIcon.setImageResource(
            R.drawable.ic_file_upload_black_24dp
//            when (state.upgraded) {
//                true -> R.drawable.ic_file_upload_black_24dp
//                false -> R.drawable.ic_star_black_24dp
//            }
        )

        binding.fabLabel.setText(
            R.string.backup_now
//            when (state.upgraded) {
//                true -> R.string.backup_now
//                false -> R.string.title_qksms_plus
//            }
        )
    }

    override fun activityVisible(): Observable<*> = activityVisibleSubject
    override fun permissionGiven(): Observable<*> = permissionGivenSubject

    override fun restoreClicks(): Observable<*> = binding.restore.clicks()

    override fun restoreFileSelected(): Observable<BackupFile> = adapter.backupSelected
        .doOnNext { backupFilesDialog.dismiss() }

    override fun restoreConfirmed(): Observable<*> = confirmRestoreSubject

    //    override fun deleteRestoreFileSelected2(): Observable<*> = deleteBackupSubject
    override fun deleteRestoreFileSelected(): Observable<BackupFile> =
        adapter.deleteSelected.doOnNext {
            deleteBackupSubject.onNext(it)
        }

    override fun stopRestoreClicks(): Observable<*> = binding.progressCancel.clicks()

    override fun stopRestoreConfirmed(): Observable<*> = stopRestoreSubject
    override fun stopBackup(): Observable<*> = binding.progressCancel.clicks()

    override fun fabClicks(): Observable<*> = binding.fab.clicks()

    val list = listOf(
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.WRITE_EXTERNAL_STORAGE
    )

    override fun requestStoragePermission() {
        Log.e("BackUp", "requestStoragePermission")
        if (!PermissionManagerImpl(activity!!).hasStorage()) {
            ActivityCompat.requestPermissions(
                activity!!,
                arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                0
            )
        }
//        ActivityCompat.requestPermissions(
//            activity!!,
//            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE),
//            0
//        )
    }

    override fun selectFile() = backupFilesDialog.show()

    override fun confirmRestore() = confirmRestoreDialog.show()

    override fun stopRestore() = stopRestoreDialog.show()

    override fun requestDefaultSms() {
//        navigator.showDefaultSmsDialog(activity!!)
    }

    override fun showDialog() {
//        CommonDialog(activity!!).show(
//            activity!!, activity!!.getString(R.string.backup_title), activity!!.resources.getString(
//                R.string.no_messages
//            ), activity!!.getString(R.string.ok), "", "", cancelable = false
//        )
    }
}
