package messages.sms.text.chat.messanger.app.feature.compose.part

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.viewbinding.ViewBinding
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.sms.text.chat.messanger.app.common.base.QkViewHolder
import messages.sms.text.chat.messanger.app.common.util.Colors
import messages.sms.text.chat.messanger.app.model.Message
import messages.sms.text.chat.messanger.app.model.MmsPart

abstract class PartBinder<Binding : ViewBinding>(
    val bindingInflater: (LayoutInflater, ViewGroup, Boolean) -> Binding,
) {

    val clicks: Subject<Long> = PublishSubject.create()

    abstract var theme: Colors.Theme

    fun <T : ViewBinding> bindPart(
        holder: QkViewHolder<T>,
        part: MmsPart,
        message: Message,
        canGroupWithPrevious: Boolean,
        canGroupWithNext: Boolean,
    ): Boolean {
        val castHolder = holder as? QkViewHolder<Binding>

        if (!canBindPart(part) || castHolder == null) {
            return false
        }

        bindPartInternal(castHolder, part, message, canGroupWithPrevious, canGroupWithNext)

        return true
    }

    abstract fun canBindPart(part: MmsPart): Boolean

    protected abstract fun bindPartInternal(
        holder: QkViewHolder<Binding>,
        part: MmsPart,
        message: Message,
        canGroupWithPrevious: Boolean,
        canGroupWithNext: Boolean,
    )

}

