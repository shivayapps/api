package messages.sms.text.chat.messanger.app.feature.contacts

import io.reactivex.Observable
import io.reactivex.subjects.Subject
import messages.sms.text.chat.messanger.app.common.base.QkView
import messages.sms.text.chat.messanger.app.extensions.Optional
import messages.sms.text.chat.messanger.app.feature.compose.editing.ComposeItem
import messages.sms.text.chat.messanger.app.feature.compose.editing.PhoneNumberAction

interface ContactsContract : QkView<ContactsState> {

    val queryChangedIntent: Observable<CharSequence>
    val queryClearedIntent: Observable<*>
    val queryBack: Observable<*>
    val queryEditorActionIntent: Observable<Int>
    val composeItemPressedIntent: Subject<ComposeItem>
    val composeItemLongPressedIntent: Subject<ComposeItem>
    val phoneNumberSelectedIntent: Subject<Optional<Long>>
    val phoneNumberActionIntent: Subject<PhoneNumberAction>

    fun clearQuery()
    fun openKeyboard()
    fun back()
    fun finish(result: HashMap<String, String?>)

}
