package messages.sms.text.chat.messanger.app.feature.blocking.numbers

import io.reactivex.Observable
import messages.sms.text.chat.messanger.app.common.base.QkViewContract

interface BlockedNumbersView : QkViewContract<BlockedNumbersState> {

    fun unblockAddress(): Observable<Long>
    fun addAddress(): Observable<*>
    fun saveAddress(): Observable<String>

    fun showAddDialog()

}
