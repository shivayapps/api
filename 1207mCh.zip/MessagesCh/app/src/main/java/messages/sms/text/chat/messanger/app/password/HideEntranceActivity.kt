package messages.sms.text.chat.messanger.app.password

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import dagger.android.AndroidInjection
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.common.base.QkThemedActivity
import messages.sms.text.chat.messanger.app.common.util.extensions.viewBinding
import messages.sms.text.chat.messanger.app.commons.extensions.applyColorFilter
import messages.sms.text.chat.messanger.app.commons.extensions.baseConfig
import messages.sms.text.chat.messanger.app.commons.extensions.config
import messages.sms.text.chat.messanger.app.commons.extensions.getBottomNavigationBackgroundColor
import messages.sms.text.chat.messanger.app.commons.extensions.updateTextColors
import messages.sms.text.chat.messanger.app.databinding.ActivityHideEntranceBinding


class HideEntranceActivity : QkThemedActivity() {

    private val binding by viewBinding(ActivityHideEntranceBinding::inflate)

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationIcon(R.drawable.ic_chevron_left_vector)

        binding.toolbarTitle.text = resources.getString(R.string.hide_entrance)

        setUpTheme()


        binding.apply {
            arrayOf(
                privateSettingsSecurityHolder
            ).forEach {
                if (baseConfig.useImageResource == true) {
                    if (baseConfig.storedImageResource == -1) {

                    } else {
                        try {
                            it.background.applyColorFilter(resources.getColor(R.color.transperent30))
                        } catch (_: Exception) {
                        }
                    }
                } else {
                    it.background.applyColorFilter(getBottomNavigationBackgroundColor())
                }
            }


        }

        binding.apply {
            hideEntranceSwitch.isChecked = config.hideEntranceSwitchStatus
            settingsColoredContactsHolder.setOnClickListener {
                hideEntranceSwitch.toggle()
                config.hideEntranceSwitchStatus = hideEntranceSwitch.isChecked
            }
        }

    }

    private fun setUpTheme() {
        updateTextColors(binding.mainLayout)

//        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
        if (baseConfig.backgroundColor.equals(Color.BLACK)) {
            binding.toolbar.background =
                ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))

        } else {
            binding.toolbar.background = ColorDrawable(baseConfig.statusBarColor)

        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource != -1) {
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.mainLayout.background = drawable
                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
            }
        } else {
            binding.mainLayout.background = null
            toolbar.setBackgroundColor(baseConfig.backgroundColor)

        }

        if (baseConfig.backgroundColor.equals(baseConfig.primaryColor)) {
            val applyBackground = ResourcesCompat.getDrawable(
                resources,
                R.drawable.button_background_rounded,
                getTheme()
            ) as RippleDrawable

            (applyBackground as LayerDrawable).findDrawableByLayerId(R.id.button_background_holder)
                .applyColorFilter(Color.parseColor("#FFFFFF"))
        } else {
            val applyBackground = ResourcesCompat.getDrawable(
                resources,
                R.drawable.button_background_rounded,
                getTheme()
            ) as RippleDrawable
            (applyBackground as LayerDrawable).findDrawableByLayerId(R.id.button_background_holder)
                .applyColorFilter(baseConfig.primaryColor)
        }

    }

}