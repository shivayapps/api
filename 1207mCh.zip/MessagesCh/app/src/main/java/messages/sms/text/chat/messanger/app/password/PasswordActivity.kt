package messages.sms.text.chat.messanger.app.password

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import com.google.android.material.bottomsheet.BottomSheetDialog
import dagger.android.AndroidInjection
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.common.base.QkThemedActivity
import messages.sms.text.chat.messanger.app.common.util.extensions.setTint
import messages.sms.text.chat.messanger.app.common.util.extensions.viewBinding
import messages.sms.text.chat.messanger.app.commons.extensions.applyColorFilter
import messages.sms.text.chat.messanger.app.commons.extensions.baseConfig
import messages.sms.text.chat.messanger.app.commons.extensions.config
import messages.sms.text.chat.messanger.app.commons.extensions.updateTextColors
import messages.sms.text.chat.messanger.app.commons.tablayout.tintDrawableColor
import messages.sms.text.chat.messanger.app.databinding.ActivityPasswordBinding
import messages.sms.text.chat.messanger.app.feature.main.PrivateConversationsActivity
import messages.sms.text.chat.messanger.app.util.hideKeyboard


class PasswordActivity : QkThemedActivity(),
    messages.sms.text.chat.messanger.app.password.callback.FingerprintDialogCallback {

    private val binding by viewBinding(ActivityPasswordBinding::inflate)
    private var firstTimePasswordSet = true


    private var password = ""
    private var mTempPassword = ""
    private lateinit var dots: List<ImageView>
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationIcon(R.drawable.ic_chevron_left_vector)


        title = "Enter pin"

        init()

        setUpTheme()
        setNumberButtonListeners()
        setBackspaceListener()


    }

    private fun init() {

        if (baseConfig.privatePin.isNotEmpty() && baseConfig.securityAnswer.isNotEmpty()) {
            firstTimePasswordSet = false
            binding.tvEnterPassword.text = "Please enter your pin"
            binding.forgetpassword.visibility = View.VISIBLE

            if (config.settingsFingerprtOn) {

                if (messages.sms.text.chat.messanger.app.password.dialog.FingerprintDialog.isAvailable(
                        this
                    )
                ) {
                    messages.sms.text.chat.messanger.app.password.dialog.FingerprintDialog.initialize(
                        this
                    )
                        .title(R.string.fingerprint_title)
                        .message(R.string.fingerprint_message)
                        .callback(this)
                        .show(baseConfig)
                }
            }

        } else {
            firstTimePasswordSet = true
            binding.tvEnterPassword.text = "Create your pin"
            binding.forgetpassword.visibility = View.GONE

        }



        dots = listOf(
            binding.dot1,
            binding.dot2,
            binding.dot3,
            binding.dot4
        )

    }

    private fun setNumberButtonListeners() {
        val buttons = listOf<Button>(
            binding.btn1,
            binding.btn2,
            binding.btn3,
            binding.btn4,
            binding.btn5,
            binding.btn6,
            binding.btn7,
            binding.btn8,
            binding.btn9,
            binding.btn0
        )

        buttons.forEach { button ->
            button.setOnClickListener {
                if (password.length < 4) {
                    password += (button.text as String)
                    updateDots()
                }
                if (password.length == 4) {
                    // Handle 4-digit password entered
                    handlePasswordEntered()
                }
            }
        }
    }

    private fun setBackspaceListener() {
        binding.btnBackspace.setOnClickListener {
            if (password.isNotEmpty()) {
                password = password.dropLast(1)
                updateDots()
            }
        }

        binding.forgetpassword.setOnClickListener {
            startActivity(
                Intent(
                    this@PasswordActivity,
                    ForgetPasswordActivity::class.java
                )
            )
            finish()
        }
    }

    private fun updateDots() {
        for (i in 0 until 4) {
            if (i < password.length) {
                dots[i].setImageResource(R.drawable.ic_dot_filled)
            } else {
                dots[i].setImageResource(R.drawable.ic_dot_empty)
            }
        }
    }

    private fun handlePasswordEntered() {


        if (firstTimePasswordSet) {


            if (mTempPassword.isNotEmpty()) {
                if (mTempPassword == password) {
                    baseConfig.privatePin = password
                    firstTimePasswordSet = false
                    binding.tvEnterPassword.text = "Please enter your pin"
                    password = ""
                    updateDots()

                    // Set Security Question Here
                    showSecurityQuestionBottomSheet()

                } else {
                    binding.tvEnterPassword.text = "PIN does not match. Try again"
                    password = ""
                    mTempPassword = ""
                    updateDots()
                }

            } else {
                if (password.length == 4) {
                    binding.tvEnterPassword.text = "Please confirm your pin"
                    mTempPassword = password
                    password = ""
                    updateDots()
                }
            }
        } else {

            if (password == baseConfig.privatePin) {
                // If the entered PIN is correct
                val intent = Intent(this, PrivateConversationsActivity::class.java)
                startActivity(intent)
                finish()
            } else {
                // If the entered PIN is incorrect
                Toast.makeText(this, "Incorrect PIN, try again.", Toast.LENGTH_SHORT).show()

                binding.tvEnterPassword.text = "Incorrect pin. Try again"
                password = ""
                updateDots()
            }
        }


    }

    private fun showSecurityQuestionBottomSheet() {
        val bottomSheetDialog = BottomSheetDialog(this, R.style.BottomSheetDialogTheme)
        val view = layoutInflater.inflate(R.layout.bottomsheet_layout_security, null)

        val spinner: Spinner = view.findViewById(R.id.security_question_spinner)
        val answerEditText: EditText = view.findViewById(R.id.security_answer_edittext)
        val saveButton: Button = view.findViewById(R.id.btn_save)
        val skipButton: Button = view.findViewById(R.id.btn_skip)
        val spinner_icon: ImageView = view.findViewById(R.id.spinner_icon)

        spinner.tintDrawableColor(baseConfig.primaryColor)
        saveButton.backgroundTintList = ColorStateList.valueOf(baseConfig.primaryColor)
        spinner_icon.setTint(baseConfig.primaryColor)

        saveButton.setOnClickListener {
            val selectedQuestion = spinner.selectedItem.toString()
            val answer = answerEditText.text.toString()
            // Handle the save logic

            if (selectedQuestion.contains("question")) {
                Toast.makeText(this, "Select security questions first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (answer.isNotEmpty() && answer.length >= 3) {
                baseConfig.securityAnswer = answer
                bottomSheetDialog.dismiss()
                val intent = Intent(this, PrivateConversationsActivity::class.java)
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this, "Enter at least 3 character", Toast.LENGTH_SHORT).show()
            }
        }

        skipButton.setOnClickListener {
            // Handle the skip action
            bottomSheetDialog.dismiss()
            finish()
        }

        /* bottomSheetDialog.window?.setBackgroundDrawableResource(R.drawable.rounded_dialog)
         bottomSheetDialog.setOnShowListener {
             val window = bottomSheetDialog.window
             val layoutParams = window?.attributes

             val displayMetrics = DisplayMetrics()
             window?.windowManager?.defaultDisplay?.getMetrics(displayMetrics)
             val screenHeight = displayMetrics.heightPixels

             // Set height to 50% of screen height
             layoutParams?.height = (screenHeight * 0.5).toInt()
             layoutParams?.width = ViewGroup.LayoutParams.MATCH_PARENT // Full width
             window?.attributes = layoutParams
         }*/
        bottomSheetDialog.setContentView(view)
        bottomSheetDialog.setCancelable(false)
        bottomSheetDialog.setCanceledOnTouchOutside(false)
        bottomSheetDialog.show()
    }

    private fun setUpTheme() {

        updateTextColors(binding.mainLayout)

        if (baseConfig.backgroundColor.equals(Color.BLACK)) {
            binding.toolbar.background =
                ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))

        } else {
            binding.toolbar.background = ColorDrawable(baseConfig.statusBarColor)

        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource != -1) {
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.mainLayout.background = drawable
                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
            }
        } else {
            binding.mainLayout.background = null
            toolbar.setBackgroundColor(baseConfig.backgroundColor)

        }

        if (baseConfig.backgroundColor.equals(baseConfig.primaryColor)) {
            val applyBackground = ResourcesCompat.getDrawable(
                resources,
                R.drawable.button_background_rounded,
                getTheme()
            ) as RippleDrawable

            (applyBackground as LayerDrawable).findDrawableByLayerId(R.id.button_background_holder)
                .applyColorFilter(Color.parseColor("#FFFFFF"))

        } else {
            val applyBackground = ResourcesCompat.getDrawable(
                resources,
                R.drawable.button_background_rounded,
                getTheme()
            ) as RippleDrawable
            (applyBackground as LayerDrawable).findDrawableByLayerId(R.id.button_background_holder)
                .applyColorFilter(baseConfig.primaryColor)
        }

    }

    override fun onAuthenticationSucceeded() {
        hideKeyboard()
        startActivity(
            Intent(
                this@PasswordActivity,
                PrivateConversationsActivity::class.java
            )
        )
        finish()
    }

    override fun onAuthenticationCancel() {

    }
}