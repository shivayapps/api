package messages.sms.text.chat.messanger.app.receiver

import com.android.mms.transaction.PushReceiver

class MmsReceiver : PushReceiver()