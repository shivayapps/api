package messages.sms.text.chat.messanger.app.feature.main

import android.content.Intent
import android.os.Bundle
import android.util.Log
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import dagger.android.AndroidInjection
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.ads.AdsPreferences
import messages.sms.text.chat.messanger.app.common.QKApplication
import messages.sms.text.chat.messanger.app.common.QKApplication.Companion.callercad_ad_type
import messages.sms.text.chat.messanger.app.common.QKApplication.Companion.callerdialog_showornot
import messages.sms.text.chat.messanger.app.common.QKApplication.Companion.stopLangInter
import messages.sms.text.chat.messanger.app.common.base.QkThemedActivity
import messages.sms.text.chat.messanger.app.commons.extensions.baseConfig
import messages.sms.text.chat.messanger.app.commons.extensions.config
import messages.sms.text.chat.messanger.app.manager.PermissionManagerImpl
import org.json.JSONObject
import java.util.Locale

class SplashActivity : QkThemedActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)

        AdsPreferences(this).splashCounter++

        fetchJSONArrayFromRemoteConfig()
        launchHomeScreen()


    }


    private fun launchHomeScreen() {
        val cCodeDefault = Locale.getDefault().language
        baseConfig.checkpage = 0
        if (config.getBooleanData("checkfirst") == false) {
            if (!PermissionManagerImpl(this@SplashActivity).isDefaultSms() || !PermissionManagerImpl(
                    this@SplashActivity
                ).hasReadSms() || !PermissionManagerImpl(
                    this@SplashActivity
                ).hasContacts()
            ) {
                startActivity(Intent(this, PermissionActivity::class.java))
                finish()
            } else {
                Log.e("getConversations", "getConversations.launchHomeScreen.001")
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            }
        } else {
            Log.e("getConversations", "getConversations.launchHomeScreen.002")
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

    }

    fun fetchJSONArrayFromRemoteConfig() = CoroutineScope(Dispatchers.IO).launch {

        CoroutineScope(Dispatchers.IO).launch {
//            FirebaseApp.initializeApp(this@SplashActivity)
            // Now you can safely use Firebase Remote Config
            val remoteConfig = FirebaseRemoteConfig.getInstance()

            remoteConfig.setDefaultsAsync(R.xml.remote_config_defaults)
            val configSettings = FirebaseRemoteConfigSettings.Builder()
                .setMinimumFetchIntervalInSeconds(1)
                .build()
            remoteConfig.setConfigSettingsAsync(configSettings)

            fetchFamilyApps(remoteConfig)
        }


    }

    private fun fetchFamilyApps(remoteConfig: FirebaseRemoteConfig) {
        remoteConfig.fetchAndActivate().addOnCompleteListener { task ->
            if (task.isSuccessful) {
                try {
                    val jsonAdsIds = remoteConfig.getString("messages_v1")

                    val jsonObj = JSONObject(jsonAdsIds)


                    try {
                        QKApplication.isUpdateDialog = jsonObj.getBoolean("isUpdateDialog")
                    } catch (e: Exception) {
                    }

                    try {
                        QKApplication.appUpdateUrl = jsonObj.getString("app_update_url")
                    } catch (e: Exception) {
                    }
                    try {

                        QKApplication.callerdialog_closable =
                            jsonObj.getBoolean("callerdailog_closable")
                    } catch (_: Exception) {

                    }
                    try {
                        callercad_ad_type = jsonObj.getString("callercad_ad_type")
                    } catch (_: Exception) {

                    }
                    try {
                        callerdialog_showornot = jsonObj.getBoolean("show_callercad")
                    } catch (_: Exception) {

                    }
                    try {
                        stopLangInter = jsonObj.getBoolean("lang_inter")
                    } catch (_: Exception) {

                    }


                } catch (_: Exception) {
                }
            }
        }
    }

}