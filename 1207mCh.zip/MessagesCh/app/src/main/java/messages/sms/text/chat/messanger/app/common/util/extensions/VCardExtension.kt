package messages.sms.text.chat.messanger.app.common.util.extensions

import ezvcard.VCard

fun VCard.getDisplayName(): String? {
    return formattedName?.value
        ?: telephoneNumbers?.firstOrNull()?.text
        ?: emails?.firstOrNull()?.value
}
