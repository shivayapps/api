package messages.sms.text.chat.messanger.app.mapper

interface Mapper<in From, out To> {

    fun map(from: From): To

}
