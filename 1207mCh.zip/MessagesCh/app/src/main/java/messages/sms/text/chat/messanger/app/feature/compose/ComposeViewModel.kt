package messages.sms.text.chat.messanger.app.feature.compose

import android.content.Context
import android.net.Uri
import android.os.Vibrator
import android.provider.ContactsContract
import android.telephony.SmsMessage
import androidx.core.content.getSystemService
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.Observables
import io.reactivex.rxkotlin.plusAssign
import io.reactivex.rxkotlin.withLatestFrom
import io.reactivex.schedulers.Schedulers
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.common.Navigator
import messages.sms.text.chat.messanger.app.common.base.QkViewModel
import messages.sms.text.chat.messanger.app.common.util.ClipboardUtils
import messages.sms.text.chat.messanger.app.common.util.MessageDetailsFormatter
import messages.sms.text.chat.messanger.app.common.util.extensions.makeToast
import messages.sms.text.chat.messanger.app.compat.SubscriptionManagerCompat
import messages.sms.text.chat.messanger.app.compat.TelephonyCompat
import messages.sms.text.chat.messanger.app.extensions.asObservable
import messages.sms.text.chat.messanger.app.extensions.isImage
import messages.sms.text.chat.messanger.app.extensions.isVideo
import messages.sms.text.chat.messanger.app.extensions.mapNotNull
import messages.sms.text.chat.messanger.app.interactor.AddScheduledMessage
import messages.sms.text.chat.messanger.app.interactor.CancelDelayedMessage
import messages.sms.text.chat.messanger.app.interactor.DeleteMessages
import messages.sms.text.chat.messanger.app.interactor.MarkRead
import messages.sms.text.chat.messanger.app.interactor.RetrySending
import messages.sms.text.chat.messanger.app.interactor.SendMessage
import messages.sms.text.chat.messanger.app.interactor.StarMessages
import messages.sms.text.chat.messanger.app.manager.ActiveConversationManager
import messages.sms.text.chat.messanger.app.manager.PermissionManager
import messages.sms.text.chat.messanger.app.model.Attachment
import messages.sms.text.chat.messanger.app.model.Attachments
import messages.sms.text.chat.messanger.app.model.Conversation
import messages.sms.text.chat.messanger.app.model.Message
import messages.sms.text.chat.messanger.app.model.Recipient
import messages.sms.text.chat.messanger.app.repository.ConversationRepository
import messages.sms.text.chat.messanger.app.repository.MessageRepository
import messages.sms.text.chat.messanger.app.util.ActiveSubscriptionObservable
import messages.sms.text.chat.messanger.app.util.PhoneNumberUtils
import messages.sms.text.chat.messanger.app.util.Preferences
import messages.sms.text.chat.messanger.app.util.tryOrNull
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Named

class ComposeViewModel @Inject constructor(
    @Named("query") private val query: String,
    @Named("threadId") private val threadId: Long,
    @Named("messageIdForScroll") private val scrollToPosition: Long,
    @Named("addresses") private val addresses: List<String>,
    @Named("text") private val sharedText: String,
    @Named("attachments") private val sharedAttachments: Attachments,
    private val contactRepo: messages.sms.text.chat.messanger.app.repository.ContactRepository,
    private val context: Context,
    private val activeConversationManager: ActiveConversationManager,
    private val addScheduledMessage: AddScheduledMessage,
    private val cancelMessage: CancelDelayedMessage,
    private val conversationRepo: ConversationRepository,
    private val deleteMessages: DeleteMessages,
    private val markRead: MarkRead,
    private val messageDetailsFormatter: MessageDetailsFormatter,
    private val messageRepo: MessageRepository,
    private val navigator: Navigator,
    private val starMessages: StarMessages,
    private val permissionManager: PermissionManager,
    private val phoneNumberUtils: PhoneNumberUtils,
    private val prefs: Preferences,
    private val retrySending: RetrySending,
    private val sendMessage: SendMessage,
    private val subscriptionManager: SubscriptionManagerCompat,
) : QkViewModel<ComposeView, ComposeState>(
    ComposeState(
        editingMode = threadId == 0L && addresses.isEmpty(),
        threadId = threadId,
        query = query,
        scrollToPosition = scrollToPosition
    )
) {

    private val attachments: Subject<List<Attachment>> =
        BehaviorSubject.createDefault(sharedAttachments)
    private val chipsReducer: Subject<(List<Recipient>) -> List<Recipient>> =
        PublishSubject.create()
    private val conversation: Subject<Conversation> = BehaviorSubject.create()
    private val messages: Subject<List<Message>> = BehaviorSubject.create()
    private val selectedChips: Subject<List<Recipient>> = BehaviorSubject.createDefault(listOf())
    private val searchResults: Subject<List<Message>> = BehaviorSubject.create()
    private val searchSelection: Subject<Long> = BehaviorSubject.createDefault(-1)

    var shouldShowContacts = threadId == 0L && addresses.isEmpty()

    init {
        val initialConversation = threadId.takeIf { it != 0L }
            ?.let(conversationRepo::getConversationAsync)
            ?.asObservable()
            ?: Observable.empty()

        val selectedConversation = selectedChips
            .skipWhile { it.isEmpty() }
            .map { chips -> chips.map { it.address } }
            .distinctUntilChanged()
            .doOnNext { newState { copy(loading = true) } }
            .observeOn(Schedulers.io())
            .map { addresses ->
                Pair(
                    conversationRepo.getOrCreateConversation(addresses)?.id ?: 0,
                    addresses
                )
            }
            .observeOn(AndroidSchedulers.mainThread())
            .doOnNext { newState { copy(loading = false) } }
            .switchMap { (threadId, addresses) ->
                // If we already have this thread in realm, or we're able to obtain it from the
                // system, just return that.
                threadId.takeIf { it > 0 }?.let {
                    return@switchMap conversationRepo.getConversationAsync(threadId).asObservable()
                }

                // Otherwise, we'll monitor the conversations until our expected conversation is created
                conversationRepo.getConversations().asObservable()
                    .filter { it.isLoaded }
                    .observeOn(Schedulers.io())
                    .map { conversationRepo.getOrCreateConversation(addresses)?.id ?: 0 }
                    .observeOn(AndroidSchedulers.mainThread())
                    .switchMap { actualThreadId ->
                        when (actualThreadId) {
                            0L -> Observable.just(Conversation(0))
                            else -> conversationRepo.getConversationAsync(actualThreadId)
                                .asObservable()
                        }
                    }
            }

        // Merges two potential conversation sources (threadId from constructor and contact selection) into a single
        // stream of conversations. If the conversation was deleted, notify the activity to shut down
        disposables += selectedConversation
            .mergeWith(initialConversation)
            .filter { conversation -> conversation.isLoaded }
            .doOnNext { conversation ->
                if (!conversation.isValid) {
                    newState { copy(hasError = true) }
                }
            }
            .filter { conversation -> conversation.isValid }
            .subscribe(conversation::onNext)

        if (addresses.isNotEmpty()) {
            selectedChips.onNext(addresses.map { address -> Recipient(address = address) })
        }

        disposables += chipsReducer
            .scan(listOf<Recipient>()) { previousState, reducer -> reducer(previousState) }
            .doOnNext { chips -> newState { copy(selectedChips = chips) } }
            .skipUntil(state.filter { state -> state.editingMode })
            .takeUntil(state.filter { state -> !state.editingMode })
            .subscribe(selectedChips::onNext)

        // When the conversation changes, mark read, and update the recipientId and the messages for the adapter
        disposables += conversation
            .distinctUntilChanged { conversation -> conversation.id }
            .observeOn(AndroidSchedulers.mainThread())
            .map { conversation ->
                val messages = messageRepo.getMessages(conversation.id)
                newState {
                    copy(
                        threadId = conversation.id,
                        messages = Pair(conversation, messages)
                    )
                }
                messages
            }
            .switchMap { messages -> messages.asObservable() }
            .subscribe(messages::onNext)

        disposables += conversation
            .map { conversation -> conversation.getTitle() }
            .distinctUntilChanged()
            .subscribe { title -> newState { copy(conversationtitle = title) } }

        disposables += prefs.sendAsGroup.asObservable()
            .distinctUntilChanged()
            .subscribe { enabled -> newState { copy(sendAsGroup = enabled) } }

        disposables += attachments
            .subscribe { attachments -> newState { copy(attachments = attachments) } }

        disposables += conversation
            .map { conversation -> conversation.id }
            .distinctUntilChanged()
            .withLatestFrom(state) { id, state -> messageRepo.getMessages(id, state.query) }
            .switchMap { messages -> messages.asObservable() }
            .takeUntil(state.map { it.query }.filter { it.isEmpty() })
            .filter { messages -> messages.isLoaded }
            .filter { messages -> messages.isValid }
            .subscribe(searchResults::onNext)

        disposables += Observables.combineLatest<Long, List<Message>, Unit>(
            searchSelection,
            searchResults,
        ) { selected, messages ->
            if (selected == -1L) {
                messages.lastOrNull()?.let { message -> searchSelection.onNext(message.id) }
            } else {
                val position = messages.indexOfFirst { it.id == selected } + 1
                newState { copy(searchSelectionPosition = position, searchResults = messages.size) }
            }
            Unit
        }.subscribe()

//        disposables += Observables.combineLatest(
//            searchSelection,
//            searchResults
//        ) { selected, messages ->
//            if (selected == -1L) {
//                messages.lastOrNull()?.let { message -> searchSelection.onNext(message.id) }
//            } else {
//                val position = messages.indexOfFirst { it.id == selected } + 1
//                newState { copy(searchSelectionPosition = position, searchResults = messages.size) }
//            }
//        }.subscribe()

        val latestSubId = messages
            .map { messages -> messages.lastOrNull()?.subId ?: -1 }
            .distinctUntilChanged()

        val subscriptions = ActiveSubscriptionObservable(subscriptionManager)
        disposables += Observables.combineLatest(latestSubId, subscriptions) { subId, subs ->
            val sub = if (subs.size > 1) subs.firstOrNull { it.subscriptionId == subId }
                ?: subs[0] else null
            newState { copy(subscription = sub) }
        }.subscribe()
    }

    override fun bindView(view: ComposeView) {
        super.bindView(view)

        val sharing = sharedText.isNotEmpty() || sharedAttachments.isNotEmpty()
        if (shouldShowContacts) {
            shouldShowContacts = false
            view.showContacts(sharing, selectedChips.blockingFirst())
        }

        view.chipsSelectedIntent
            .withLatestFrom(selectedChips) { hashmap, chips ->
                // If there's no contacts already selected, and the user cancelled the contact
                // selection, close the activity
                if (hashmap.isEmpty() && chips.isEmpty()) {
                    newState { copy(hasError = true) }
                }
                // Filter out any numbers that are already selected
                hashmap.filter { (address) ->
                    chips.none { recipient -> phoneNumberUtils.compare(address, recipient.address) }
                }
            }
            .filter { hashmap -> hashmap.isNotEmpty() }
            .map { hashmap ->
                hashmap.map { (address, lookupKey) ->
                    conversationRepo.getRecipients()
                        .asSequence()
                        .filter { recipient -> recipient.contact?.lookupKey == lookupKey }
                        .firstOrNull { recipient ->
                            phoneNumberUtils.compare(
                                recipient.address,
                                address
                            )
                        }
                        ?: Recipient(
                            address = address,
                            contact = lookupKey?.let(contactRepo::getUnmanagedContact)
                        )
                }
            }
            .autoDispose(view.scope())
            .subscribe { chips ->
                chipsReducer.onNext { list -> list + chips }
                view.showKeyboard()
            }

        // Set the contact suggestions list to visible when the add button is pressed
        view.optionsItemIntent
            .filter { it == R.id.add }
            .withLatestFrom(selectedChips) { _, chips ->
                view.showContacts(sharing, chips)
            }
            .autoDispose(view.scope())
            .subscribe()

        // Update the list of selected contacts when a new contact is selected or an existing one is deselected
        view.chipDeletedIntent
            .autoDispose(view.scope())
            .subscribe { contact ->
                chipsReducer.onNext { contacts ->
                    val result = contacts.filterNot { it == contact }
                    if (result.isEmpty()) {
                        view.showContacts(sharing, result)
                    }
                    result
                }
            }

        // When the menu is loaded, trigger a new state so that the menu options can be rendered correctly
        view.menuReadyIntent
            .autoDispose(view.scope())
            .subscribe { newState { copy() } }

        // Open the phone dialer if the call button is clicked
        view.optionsItemIntent
            .filter { it == R.id.call }
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .mapNotNull { conversation -> conversation.recipients.firstOrNull() }
            .map { recipient -> recipient.address }
            .autoDispose(view.scope())
            .subscribe { address -> navigator.makePhoneCall(address) }

        view.optionsItemIntent
            .filter { it == R.id.star }
            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
            .withLatestFrom(
                view.messagesSelectedIntent
            ) { _, messages ->
                starMessages.execute(messages)
            }
            .autoDispose(view.scope())
            .subscribe { view.clearSelection() }


        // Remove Star message if un star button is clicked
        view.optionsItemIntent
            .filter { it == R.id.un_star }
            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
            .withLatestFrom(
                view.messagesSelectedIntent
            ) { _, messages ->
                starMessages.execute(messages)
            }
            .autoDispose(view.scope())
            .subscribe { view.clearSelection() }

        view.addStarred()
            .autoDispose(view.scope())
            .subscribe { message ->
                starMessages.execute(listOf(message))
            }

        view.addOrRemoveStarred()
            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
            .autoDispose(view.scope())
            .subscribe { message ->
                starMessages.execute(listOf(message))
                try {
                    view.showUnStarredSnackBar()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

        // Open the conversation settings if info button is clicked
        view.optionsItemIntent
            .filter { it == R.id.info }
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .autoDispose(view.scope())
            .subscribe { conversation -> navigator.showConversationInfo(conversation.id) }

        // Copy the message contents
        view.optionsItemIntent
            .filter { it == R.id.copy }
            .withLatestFrom(view.messagesSelectedIntent) { _, messageIds ->
                val messages = messageIds.mapNotNull(messageRepo::getMessage).sortedBy { it.date }
                val text = when (messages.size) {
                    1 -> messages.first().getText()
                    else -> messages.foldIndexed("") { index, acc, message ->
                        when {
                            index == 0 -> message.getText()
                            messages[index - 1].compareSender(message) -> "$acc\n${message.getText()}"
                            else -> "$acc\n\n${message.getText()}"
                        }
                    }
                }

                ClipboardUtils.copy(context, text)
            }
            .autoDispose(view.scope())
            .subscribe { view.clearSelection() }

        // Show the message details
        view.optionsItemIntent
            .filter { it == R.id.details }
            .withLatestFrom(view.messagesSelectedIntent) { _, messages -> messages }
            .mapNotNull { messages -> messages.firstOrNull().also { view.clearSelection() } }
            .mapNotNull(messageRepo::getMessage)
            .map(messageDetailsFormatter::format)
            .autoDispose(view.scope())
            .subscribe { view.showDetails(it) }

        // Delete the messages
        view.optionsItemIntent
            .filter { it == R.id.delete }
            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
            .withLatestFrom(
                view.messagesSelectedIntent,
                conversation
            ) { _, messages, conversation ->
                deleteMessages.execute(DeleteMessages.Params(messages, conversation.id))
            }
            .autoDispose(view.scope())
            .subscribe { view.clearSelection() }

        // Forward the message
        view.optionsItemIntent
            .filter { it == R.id.forward }
            .withLatestFrom(view.messagesSelectedIntent) { _, messages ->
                messages?.firstOrNull()?.let { messageRepo.getMessage(it) }?.let { message ->
                    val images = message.parts.filter { it.isImage() }.mapNotNull { it.getUri() }
                    navigator.showCompose(message.getText(), images)
                }
            }
            .autoDispose(view.scope())
            .subscribe { view.clearSelection() }

        // Show the previous search result
        view.optionsItemIntent
            .filter { it == R.id.previous }
            .withLatestFrom(searchSelection, searchResults) { _, selection, messages ->
                val currentPosition = messages.indexOfFirst { it.id == selection }
                if (currentPosition <= 0L) messages.lastOrNull()?.id ?: -1
                else messages.getOrNull(currentPosition - 1)?.id ?: -1
            }
            .filter { id -> id != -1L }
            .autoDispose(view.scope())
            .subscribe(searchSelection)

        // Show the next search result
        view.optionsItemIntent
            .filter { it == R.id.next }
            .withLatestFrom(searchSelection, searchResults) { _, selection, messages ->
                val currentPosition = messages.indexOfFirst { it.id == selection }
                if (currentPosition >= messages.size - 1) messages.firstOrNull()?.id ?: -1
                else messages.getOrNull(currentPosition + 1)?.id ?: -1
            }
            .filter { id -> id != -1L }
            .autoDispose(view.scope())
            .subscribe(searchSelection)

        // Clear the search
        view.optionsItemIntent
            .filter { it == R.id.clear }
            .autoDispose(view.scope())
            .subscribe { newState { copy(query = "", searchSelectionId = -1) } }

        // Toggle the group sending mode
        view.sendAsGroupIntent
            .autoDispose(view.scope())
            .subscribe { prefs.sendAsGroup.set(!prefs.sendAsGroup.get()) }

        // Scroll to search position
        searchSelection
            .filter { id -> id != -1L }
            .doOnNext { id -> newState { copy(searchSelectionId = id) } }
            .autoDispose(view.scope())
            .subscribe(view::scrollToMessage)

        // Theme changes
        prefs.keyChanges
            .filter { key -> key.contains("theme") }
            .doOnNext { view.themeChanged() }
            .autoDispose(view.scope())
            .subscribe()

        // Retry sending
        view.messageClickIntent
            .mapNotNull(messageRepo::getMessage)
            .filter { message -> message.isFailedMessage() }
            .doOnNext { message -> retrySending.execute(message.id) }
            .autoDispose(view.scope())
            .subscribe()

        // Media attachment clicks
        view.messagePartClickIntent
            .mapNotNull(messageRepo::getPart)
            .filter { part -> part.isImage() || part.isVideo() }
            .autoDispose(view.scope())
            .subscribe { part -> navigator.showMedia(part.id) }

        // Non-media attachment clicks
        view.messagePartClickIntent
            .mapNotNull(messageRepo::getPart)
            .filter { part -> !part.isImage() && !part.isVideo() }
            .autoDispose(view.scope())
            .subscribe { part ->
                if (permissionManager.hasStorage()) {
                    messageRepo.savePart(part.id)?.let(navigator::viewFile)
                } else {
                    view.requestStoragePermission()
                }
            }

        // Update the State when the message selected count changes
        view.messagesSelectedIntent
            .map { selection -> selection.size }
            .autoDispose(view.scope())
            .subscribe { messages ->
                newState {
                    copy(
                        selectedMessages = messages,
                        editingMode = false
                    )
                }
            }

        // Cancel sending a message
        view.cancelSendingIntent
            .mapNotNull(messageRepo::getMessage)
            .doOnNext { message -> view.setDraft(message.getText()) }
            .autoDispose(view.scope())
            .subscribe { message -> cancelMessage.execute(message.id) }

        // Set the current conversation
        Observables
            .combineLatest(
                view.activityVisibleIntent.distinctUntilChanged(),
                conversation.mapNotNull { conversation ->
                    conversation.takeIf { it.isValid }?.id
                }.distinctUntilChanged()
            )
            { visible, threadId ->
                when (visible) {
                    true -> {
                        activeConversationManager.setActiveConversation(threadId)
                        markRead.execute(listOf(threadId))
                    }

                    false -> activeConversationManager.setActiveConversation(null)
                }
            }
            .autoDispose(view.scope())
            .subscribe()

        // Save draft when the activity goes into the background
        view.activityVisibleIntent
            .filter { visible -> !visible }
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .mapNotNull { conversation -> conversation.takeIf { it.isValid }?.id }
            .observeOn(Schedulers.io())
            .withLatestFrom(view.textChangedIntent) { threadId, draft ->
                conversationRepo.saveDraft(threadId, draft.toString())
            }
            .autoDispose(view.scope())
            .subscribe()

        // Open the attachment options
        view.attachIntent
            .autoDispose(view.scope())
            .subscribe { newState { copy(attaching = !attaching) } }

        // Attach a photo from camera
        view.cameraIntent
            .autoDispose(view.scope())
            .subscribe {
                if (permissionManager.hasStorage()) {
                    newState { copy(attaching = false) }
                    view.requestCamera()
                } else {
                    view.requestStoragePermission()
                }
            }

        // Attach a photo from gallery
        view.galleryIntent
            .doOnNext { newState { copy(attaching = false) } }
            .autoDispose(view.scope())
            .subscribe { view.requestGallery() }

        // Choose a time to schedule the message
        view.scheduleIntent
            .doOnNext { newState { copy(attaching = false) } }
            .autoDispose(view.scope())
            .subscribe { view.requestDatePicker() }

        // A photo was selected
        Observable.merge(
            view.attachmentSelectedIntent.map { uri -> Attachment.Image(uri) },
            view.inputContentIntent.map { inputContent -> Attachment.Image(inputContent = inputContent) })
            .withLatestFrom(attachments) { attachment, attachments -> attachments + attachment }
            .doOnNext(attachments::onNext)
            .autoDispose(view.scope())
            .subscribe { newState { copy(attaching = false) } }

        // Set the scheduled time
        view.scheduleSelectedIntent
            .filter { scheduled ->
                (scheduled > System.currentTimeMillis()).also { future ->
                    if (!future) context.makeToast(R.string.compose_scheduled_future)
                }
            }
            .autoDispose(view.scope())
            .subscribe { scheduled -> newState { copy(scheduled = scheduled) } }

        // Attach a contact
        view.attachContactIntent
            .doOnNext { newState { copy(attaching = false) } }
            .autoDispose(view.scope())
            .subscribe { view.requestContact() }

        // Contact was selected for attachment
        view.contactSelectedIntent
            .map { uri -> Attachment.Contact(getVCard(uri)!!) }
            .withLatestFrom(attachments) { attachment, attachments -> attachments + attachment }
            .subscribeOn(Schedulers.io())
            .autoDispose(view.scope())
            .subscribe(attachments::onNext) { error ->
                context.makeToast(R.string.compose_contact_error)
                Timber.w(error)
            }

        // Detach a photo
        view.attachmentDeletedIntent
            .withLatestFrom(attachments) { bitmap, attachments -> attachments.filter { it !== bitmap } }
            .autoDispose(view.scope())
            .subscribe { attachments.onNext(it) }

        conversation
            .map { conversation -> conversation.draft }
            .distinctUntilChanged()
            .autoDispose(view.scope())
            .subscribe { draft ->

                // If text was shared into the conversation, it should take priority over the
                // existing draft
                //
                // TODO: Show dialog warning user about overwriting draft
                if (sharedText.isNotBlank()) {
                    view.setDraft(sharedText)
                } else {
                    view.setDraft(draft)
                }
            }

        // Enable the send button when there is text input into the new message body or there's
        // an attachment, disable otherwise
        Observables
            .combineLatest(view.textChangedIntent, attachments) { text, attachments ->
                text.isNotBlank() || attachments.isNotEmpty()
            }
            .autoDispose(view.scope())
            .subscribe { canSend -> newState { copy(canSend = canSend) } }

        // Show the remaining character counter when necessary
        view.textChangedIntent
            .observeOn(Schedulers.computation())
            .mapNotNull { draft ->
                tryOrNull {
                    SmsMessage.calculateLength(
                        draft,
                        prefs.unicode.get()
                    )
                }
            }
            .map { array ->
                val messages = array[0]
                val remaining = array[2]

                when {
                    messages <= 1 && remaining > 10 -> ""
                    messages <= 1 && remaining <= 10 -> "$remaining"
                    else -> "$remaining / $messages"
                }
            }
            .distinctUntilChanged()
            .autoDispose(view.scope())
            .subscribe { remaining -> newState { copy(remaining = remaining) } }

        // Cancel the scheduled time
        view.scheduleCancelIntent
            .autoDispose(view.scope())
            .subscribe { newState { copy(scheduled = 0) } }

        // Toggle to the next sim slot
        view.changeSimIntent
            .withLatestFrom(state) { _, state ->
                val subs = subscriptionManager.activeSubscriptionInfoList
                val subIndex =
                    subs.indexOfFirst { it.subscriptionId == state.subscription?.subscriptionId }
                val subscription = when {
                    subIndex == -1 -> null
                    subIndex < subs.size - 1 -> subs[subIndex + 1]
                    else -> subs[0]
                }

                if (subscription != null) {
                    context.getSystemService<Vibrator>()?.vibrate(40)
                    context.makeToast(
                        context.getString(
                            R.string.compose_sim_changed_toast,
                            subscription.simSlotIndex + 1, subscription.displayName
                        )
                    )
                }

                newState { copy(subscription = subscription) }
            }
            .autoDispose(view.scope())
            .subscribe()

        // Send a message when the send button is clicked, and disable editing mode if it's enabled
        view.sendIntent
            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
            .filter { permissionManager.hasSendSms().also { if (!it) view.requestSmsPermission() } }
            .withLatestFrom(view.textChangedIntent) { _, body -> body }
            .map { body -> body.toString() }
            .withLatestFrom(
                state,
                attachments,
                conversation,
                selectedChips
            ) {
                    body, state, attachments,
                    conversation, chips,
                ->
                val subId = state.subscription?.subscriptionId ?: -1
                val addresses = when (conversation.recipients.isNotEmpty()) {
                    true -> conversation.recipients.map { it.address }
                    false -> chips.map { chip -> chip.address }
                }
                val delay = when (prefs.sendDelay.get()) {
                    Preferences.SEND_DELAY_SHORT -> 3000
                    Preferences.SEND_DELAY_MEDIUM -> 5000
                    Preferences.SEND_DELAY_LONG -> 10000
                    else -> 0
                }
                val sendAsGroup = !state.editingMode || state.sendAsGroup

                when {
                    // Scheduling a message
                    state.scheduled != 0L -> {
                        newState { copy(scheduled = 0) }
                        val uris = attachments
                            .mapNotNull { it as? Attachment.Image }
                            .map { it.getUri() }
                            .map { it.toString() }
                        val params = AddScheduledMessage
                            .Params(state.scheduled, subId, addresses, sendAsGroup, body, uris)
                        addScheduledMessage.execute(params)
                        context.makeToast(R.string.compose_scheduled_toast)
                    }

                    // Sending a group message
                    sendAsGroup -> {
                        sendMessage.execute(
                            SendMessage
                                .Params(
                                    subId,
                                    conversation.id,
                                    addresses,
                                    body,
                                    attachments,
                                    delay
                                )
                        )
//                        sendMessage.execute(
//                            SendMessage
//                                .Params(subId, conversation.id, addresses, body, attachments, delay)
//                        )
                    }

                    // Sending a message to an existing conversation with one recipient
                    conversation.recipients.size == 1 -> {
                        val address = conversation.recipients.map { it.address }
                        sendMessage.execute(
                            SendMessage.Params(
                                subId,
                                threadId,
                                address,
                                body,
                                attachments,
                                delay
                            )
                        )
                    }

                    // Create a new conversation with one address
                    addresses.size == 1 -> {
                        sendMessage.execute(
                            SendMessage
                                .Params(subId, threadId, addresses, body, attachments, delay)
                        )
                    }

                    // Send a message to multiple addresses
                    else -> {
                        addresses.forEach { addr ->
                            val threadId = tryOrNull(false) {
                                TelephonyCompat.getOrCreateThreadId(context, addr)
                            } ?: 0
                            val address = listOf(
                                conversationRepo
                                    .getConversation(threadId)?.recipients?.firstOrNull()?.address
                                    ?: addr
                            )
                            sendMessage.execute(
                                SendMessage
                                    .Params(subId, threadId, address, body, attachments, delay)
                            )
                        }
                    }
                }

                view.setDraft("")
                this.attachments.onNext(ArrayList())

                if (state.editingMode) {
                    newState { copy(editingMode = false, hasError = !sendAsGroup) }
                }
            }
            .autoDispose(view.scope())
            .subscribe()


        // Navigate back
        view.optionsItemIntent
            .filter { it == android.R.id.home }
            .map { Unit }
            .mergeWith(view.backPressedIntent)
            .withLatestFrom(state) { _, state ->
                when {
                    state.selectedMessages > 0 -> view.clearSelection()
                    else -> newState { copy(hasError = true) }
                }
            }
            .autoDispose(view.scope())
            .subscribe()

    }

    private fun getVCard(contactData: Uri): String? {
        val lookupKey =
            context.contentResolver.query(contactData, null, null, null, null)?.use { cursor ->
                cursor.moveToFirst()
                cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.LOOKUP_KEY))
            }

        val vCardUri = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_VCARD_URI, lookupKey)
        return context.contentResolver.openAssetFileDescriptor(vCardUri, "r")
            ?.createInputStream()
            ?.readBytes()
            ?.let { bytes -> String(bytes) }
    }

}