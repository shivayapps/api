package messages.sms.text.chat.messanger.app.feature.starred

import android.graphics.Typeface
import android.text.Spannable
import android.text.SpannableString
import android.text.style.StyleSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.common.base.QkRealmAdapter
import messages.sms.text.chat.messanger.app.common.base.QkViewHolder
import messages.sms.text.chat.messanger.app.common.util.DateFormatter
import messages.sms.text.chat.messanger.app.commons.extensions.addAlpha
import messages.sms.text.chat.messanger.app.commons.extensions.baseConfig
import messages.sms.text.chat.messanger.app.databinding.StarredListItemBinding
import messages.sms.text.chat.messanger.app.extensions.isText
import messages.sms.text.chat.messanger.app.model.Message
import messages.sms.text.chat.messanger.app.repository.StarredMessageRepository
import javax.inject.Inject

class StarredMessageAdapter @Inject constructor(
    private val dateFormatter: DateFormatter,
    private val starredMessageRepository: StarredMessageRepository,
) : QkRealmAdapter<Message, StarredListItemBinding>() {

    val clicks: Subject<Message> = PublishSubject.create()

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): QkViewHolder<StarredListItemBinding> {

        // Use the parent's context to inflate the layout, otherwise link clicks will crash the app
        val layoutInflater = LayoutInflater.from(parent.context)
        val view: View = layoutInflater.inflate(R.layout.starred_list_item, parent, false)

        val binding = StarredListItemBinding.bind(view)
        return QkViewHolder(binding).apply {
            val textColorPrimary = parent.context.baseConfig.textColor
            val colorWithAlpha = textColorPrimary.addAlpha(0.3F)
            binding.title.setTextColor(textColorPrimary)
            binding.date.setTextColor(textColorPrimary)
            binding.snippet.setTextColor(colorWithAlpha)

            view.setOnClickListener {
                try {
                    val message = getItem(getAdapterPosition()) ?: return@setOnClickListener
                    clicks.onNext(message)
                } catch (e: Exception) {
//                    LogE("onCreateViewHolder: ", "messageAdapter" + e.message.toString())
                }
            }
        }
    }

//    override fun onBindViewHolder(holder: MessagesViewHolder, position: Int) {

    override fun onBindViewHolder(holder: QkViewHolder<StarredListItemBinding>, position: Int) {
        try {
            val message = getItem(position) ?: return

            val conversation = starredMessageRepository.getConversation(message.threadId)
            if (conversation != null) {
                holder.binding.root.isActivated = isSelected(conversation.id)
                holder.binding.avatars.recipients = conversation.recipients
                holder.binding.title.collapseEnabled = conversation.recipients.size > 1
                holder.binding.title.text = conversation.getTitle()
                holder.binding.date.text = dateFormatter.getMessageTimestamp(message.date)
            }
            val messageText = when (message.isSms()) {
                true -> message.body
                false -> {
                    val subject = message.getCleansedSubject()
                    val body = message.parts
                        .filter { part -> part.isText() }
                        .mapNotNull { part -> part.text }
                        .filter { text -> text.isNotBlank() }
                        .joinToString("\n")

                    when {
                        subject.isNotBlank() -> {
                            val spannable =
                                SpannableString(if (body.isNotBlank()) "$subject\n$body" else subject)
                            spannable.setSpan(
                                StyleSpan(Typeface.BOLD), 0, subject.length,
                                Spannable.SPAN_INCLUSIVE_EXCLUSIVE
                            )
                            spannable
                        }

                        else -> body
                    }
                }
            }
            holder.binding.snippet.text = messageText
        } catch (e: Exception) {
//            LogE("onBindViewHolder: ", e.message.toString())
        }
    }
}
