package messages.sms.text.chat.messanger.app.injection

import android.app.Application
import android.content.ContentResolver
import android.content.Context
import android.content.SharedPreferences
import android.preference.PreferenceManager
import androidx.lifecycle.ViewModelProvider
import com.f2prateek.rx.preferences2.RxSharedPreferences
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import dagger.Module
import dagger.Provides
import messages.sms.text.chat.messanger.app.blocking.BlockingClient
import messages.sms.text.chat.messanger.app.blocking.BlockingManager
import messages.sms.text.chat.messanger.app.common.ViewModelFactory
import messages.sms.text.chat.messanger.app.common.util.NotificationManagerImpl
import messages.sms.text.chat.messanger.app.common.util.ShortcutManagerImpl
import messages.sms.text.chat.messanger.app.feature.conversationinfo.injection.ConversationInfoComponent
import messages.sms.text.chat.messanger.app.feature.themepicker.injection.ThemePickerComponent
import messages.sms.text.chat.messanger.app.listener.ContactAddedListener
import messages.sms.text.chat.messanger.app.listener.ContactAddedListenerImpl
import messages.sms.text.chat.messanger.app.manager.ActiveConversationManager
import messages.sms.text.chat.messanger.app.manager.ActiveConversationManagerImpl
import messages.sms.text.chat.messanger.app.manager.AlarmManager
import messages.sms.text.chat.messanger.app.manager.AlarmManagerImpl
import messages.sms.text.chat.messanger.app.manager.AnalyticsManager
import messages.sms.text.chat.messanger.app.manager.AnalyticsManagerImpl
import messages.sms.text.chat.messanger.app.manager.KeyManager
import messages.sms.text.chat.messanger.app.manager.KeyManagerImpl
import messages.sms.text.chat.messanger.app.manager.NotificationManager
import messages.sms.text.chat.messanger.app.manager.PermissionManager
import messages.sms.text.chat.messanger.app.manager.PermissionManagerImpl
import messages.sms.text.chat.messanger.app.manager.RatingManager
import messages.sms.text.chat.messanger.app.manager.ReferralManager
import messages.sms.text.chat.messanger.app.manager.ReferralManagerImpl
import messages.sms.text.chat.messanger.app.manager.ShortcutManager
import messages.sms.text.chat.messanger.app.manager.WidgetManager
import messages.sms.text.chat.messanger.app.manager.WidgetManagerImpl
import messages.sms.text.chat.messanger.app.mapper.CursorToContact
import messages.sms.text.chat.messanger.app.mapper.CursorToContactImpl
import messages.sms.text.chat.messanger.app.mapper.CursorToConversation
import messages.sms.text.chat.messanger.app.mapper.CursorToConversationImpl
import messages.sms.text.chat.messanger.app.mapper.CursorToMessage
import messages.sms.text.chat.messanger.app.mapper.CursorToMessageImpl
import messages.sms.text.chat.messanger.app.mapper.CursorToPart
import messages.sms.text.chat.messanger.app.mapper.CursorToPartImpl
import messages.sms.text.chat.messanger.app.mapper.CursorToRecipient
import messages.sms.text.chat.messanger.app.mapper.CursorToRecipientImpl
import messages.sms.text.chat.messanger.app.mapper.RatingManagerImpl
import messages.sms.text.chat.messanger.app.repository.BackupRepository
import messages.sms.text.chat.messanger.app.repository.BackupRepositoryImpl
import messages.sms.text.chat.messanger.app.repository.BlockingRepository
import messages.sms.text.chat.messanger.app.repository.BlockingRepositoryImpl
import messages.sms.text.chat.messanger.app.repository.ContactRepositoryImpl
import messages.sms.text.chat.messanger.app.repository.ConversationRepository
import messages.sms.text.chat.messanger.app.repository.ConversationRepositoryImpl
import messages.sms.text.chat.messanger.app.repository.MessageRepository
import messages.sms.text.chat.messanger.app.repository.MessageRepositoryImpl
import messages.sms.text.chat.messanger.app.repository.ScheduledMessageRepository
import messages.sms.text.chat.messanger.app.repository.ScheduledMessageRepositoryImpl
import messages.sms.text.chat.messanger.app.repository.StarredMessageRepository
import messages.sms.text.chat.messanger.app.repository.StarredMessageRepositoryImpl
import messages.sms.text.chat.messanger.app.repository.SyncRepository
import messages.sms.text.chat.messanger.app.repository.SyncRepositoryImpl
import javax.inject.Singleton

@Module(
    subcomponents = [
        ConversationInfoComponent::class,
        ThemePickerComponent::class]
)
class AppModule(private var application: Application) {

    @Provides
    @Singleton
    fun provideContext(): Context = application

    @Provides
    fun provideContentResolver(context: Context): ContentResolver = context.contentResolver

    @Provides
    @Singleton
    fun provideSharedPreferences(context: Context): SharedPreferences {
        return PreferenceManager.getDefaultSharedPreferences(context)
    }

    @Provides
    @Singleton
    fun provideRxPreferences(preferences: SharedPreferences): RxSharedPreferences {
        return RxSharedPreferences.create(preferences)
    }

    @Provides
    @Singleton
    fun provideMoshi(): Moshi {
        return Moshi.Builder()
            .add(KotlinJsonAdapterFactory())
            .build()
    }

    @Provides
    fun provideViewModelFactory(factory: ViewModelFactory): ViewModelProvider.Factory = factory

    // Listener

    @Provides
    fun provideContactAddedListener(listener: ContactAddedListenerImpl): ContactAddedListener =
        listener

    // Manager

    @Provides
    fun provideActiveConversationManager(manager: ActiveConversationManagerImpl): ActiveConversationManager =
        manager

    @Provides
    fun provideAlarmManager(manager: AlarmManagerImpl): AlarmManager = manager

    @Provides
    fun provideAnalyticsManager(manager: AnalyticsManagerImpl): AnalyticsManager = manager

    @Provides
    fun blockingClient(manager: BlockingManager): BlockingClient = manager


    @Provides
    fun provideKeyManager(manager: KeyManagerImpl): KeyManager = manager

    @Provides
    fun provideNotificationsManager(manager: NotificationManagerImpl): NotificationManager = manager

    @Provides
    fun providePermissionsManager(manager: PermissionManagerImpl): PermissionManager = manager

    @Provides
    fun provideRatingManager(manager: RatingManagerImpl): RatingManager = manager

    @Provides
    fun provideShortcutManager(manager: ShortcutManagerImpl): ShortcutManager = manager

    @Provides
    fun provideReferralManager(manager: ReferralManagerImpl): ReferralManager = manager

    @Provides
    fun provideWidgetManager(manager: WidgetManagerImpl): WidgetManager = manager

    // Mapper

    @Provides
    fun provideCursorToContact(mapper: CursorToContactImpl): CursorToContact = mapper

    @Provides
    fun provideCursorToConversation(mapper: CursorToConversationImpl): CursorToConversation = mapper

    @Provides
    fun provideCursorToMessage(mapper: CursorToMessageImpl): CursorToMessage = mapper

    @Provides
    fun provideCursorToPart(mapper: CursorToPartImpl): CursorToPart = mapper

    @Provides
    fun provideCursorToRecipient(mapper: CursorToRecipientImpl): CursorToRecipient = mapper

    // Repository

    @Provides
    fun provideBackupRepository(repository: BackupRepositoryImpl): BackupRepository = repository

    @Provides
    fun provideBlockingRepository(repository: BlockingRepositoryImpl): BlockingRepository =
        repository

    @Provides
    fun provideContactRepository(repository: ContactRepositoryImpl): messages.sms.text.chat.messanger.app.repository.ContactRepository =
        repository

    @Provides
    fun provideStarredMessageRepository(repository: StarredMessageRepositoryImpl): StarredMessageRepository =
        repository

    @Provides
    fun provideConversationRepository(repository: ConversationRepositoryImpl): ConversationRepository =
        repository

    @Provides
    fun provideMessageRepository(repository: MessageRepositoryImpl): MessageRepository = repository

    @Provides
    fun provideScheduledMessagesRepository(repository: ScheduledMessageRepositoryImpl): ScheduledMessageRepository =
        repository

    @Provides
    fun provideSyncRepository(repository: SyncRepositoryImpl): SyncRepository = repository

}