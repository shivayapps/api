package messages.sms.text.chat.messanger.app.feature.blocking.messages

import android.app.AlertDialog
import android.content.Context
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.common.base.QkController
import messages.sms.text.chat.messanger.app.common.util.Colors
import messages.sms.text.chat.messanger.app.commons.extensions.baseConfig
import messages.sms.text.chat.messanger.app.databinding.BlockedMessagesControllerBinding
import messages.sms.text.chat.messanger.app.feature.blocking.BlockingDialog
import messages.sms.text.chat.messanger.app.injection.appComponent
import javax.inject.Inject

class BlockedMessagesController :
    QkController<BlockedMessagesView, BlockedMessagesState, BlockedMessagesPresenter,
            BlockedMessagesControllerBinding>(BlockedMessagesControllerBinding::inflate),
    BlockedMessagesView {

    override val menuReadyIntent: Subject<Unit> = PublishSubject.create()
    override val optionsItemIntent: Subject<Int> = PublishSubject.create()
    override val conversationClicks by lazy { blockedMessagesAdapter.clicks }
    override val selectionChanges by lazy { blockedMessagesAdapter.selectionChanges }
    override val confirmDeleteIntent: Subject<List<Long>> = PublishSubject.create()
    override val backClicked: Subject<Unit> = PublishSubject.create()

    @Inject
    lateinit var blockedMessagesAdapter: BlockedMessagesAdapter

    @Inject
    lateinit var blockingDialog: BlockingDialog

    @Inject
    lateinit var colors: Colors

    @Inject
    lateinit var context: Context

    @Inject
    override lateinit var presenter: BlockedMessagesPresenter

    init {
        appComponent.inject(this)
        retainViewMode = RetainViewMode.RETAIN_DETACH
    }

    override fun onViewCreated() {
        super.onViewCreated()
        blockedMessagesAdapter.emptyView = binding.empty
        binding.conversations.adapter = blockedMessagesAdapter
    }

    override fun onAttach(view: View) {
        super.onAttach(view)
        presenter.bindIntents(this)
        setTitle(R.string.blocked_messages_title)
//        showBackButton(true)
        setHasOptionsMenu(true)
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        inflater.inflate(R.menu.blocked_messages, menu)
        menuReadyIntent.onNext(Unit)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        optionsItemIntent.onNext(item.itemId)
        return true
    }

    override fun handleBack(): Boolean {
        backClicked.onNext(Unit)
        return true
    }

    override fun render(state: BlockedMessagesState) {
        blockedMessagesAdapter.updateData(state.data)

        themedActivity?.toolbar?.menu?.findItem(R.id.block)?.isVisible = state.selected > 0
        themedActivity?.toolbar?.menu?.findItem(R.id.delete)?.isVisible = state.selected > 0

        setTitle(
            when (state.selected) {
                0 -> context.getString(R.string.blocked_messages_title)
                else -> context.getString(R.string.main_title_selected, state.selected)
            }
        )
    }

    override fun clearSelection() = blockedMessagesAdapter.clearSelection()

    override fun showBlockingDialog(conversations: List<Long>, block: Boolean) {
        blockingDialog.show(activity!!, conversations, block)
    }

    /* override fun showDeleteDialog(conversations: List<Long>) {
         val count = conversations.size
         AlertDialog.Builder(activity)
             .setTitle(R.string.dialog_delete_title)
             .setMessage(resources?.getQuantityString(R.plurals.dialog_delete_message, count, count))
             .setPositiveButton(R.string.button_delete) { _, _ ->
                 confirmDeleteIntent.onNext(
                     conversations
                 )
             }
             .setNegativeButton(R.string.button_cancel, null)
             .show()
     }*/

    override fun showDeleteDialog(conversations: List<Long>) {
        val count = conversations.size
        val dialog = AlertDialog.Builder(activity, R.style.CustomFieldDialogTheme)
            .setTitle(R.string.dialog_delete_title)
            .setMessage(
                activity?.resources?.getQuantityString(
                    R.plurals.dialog_delete_message,
                    count,
                    count
                )
            )
            .setPositiveButton(R.string.button_delete) { _, _ ->
                confirmDeleteIntent.onNext(conversations)
            }
            .setNegativeButton(R.string.button_cancel, null)
            .create()  // Use create() instead of show()

        dialog.window?.setBackgroundDrawableResource(R.drawable.rounded_dialog)
        dialog.setOnShowListener {
            // Change the button text colors after the dialog is shown
            activity?.baseConfig?.primaryColor?.let { it1 ->
                dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(
                    it1
                )
            }
            activity?.resources?.getColor(R.color.black)
                ?.let { it1 -> dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(it1) }
        }

        dialog.show()
    }

    override fun goBack() {
        router.popCurrentController()
    }

}
