package  messages.sms.text.chat.messanger.app.ads

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.view.ViewGroup
import android.widget.Button
import androidx.core.content.res.ResourcesCompat
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.nativead.NativeAd
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.common.widget.MessageTextView
import messages.sms.text.chat.messanger.app.commons.extensions.baseConfig

object GoogleSmallNativeAdManagerPrivate {
    private var mSmallNativeAd: NativeAd? = null
    private var mSmallNativeAdShow = false
    private var mSmallNativeAd8: NativeAd? = null
    private var mSmallNativeAd8Show = false
    fun loadSmallNativePrivate(context: Context, mAdId: String, listener: (NativeAd?) -> Unit) {
        loadNativePrivate(context, mAdId) {
            mSmallNativeAd = it
            listener(it)
        }
    }

    fun showNativePrivate(context: Context, parentView: ViewGroup) {
        mSmallNativeAd?.let {
            AdmobNative.populateSmallNativeAd(context, parentView, it)
        } ?: manageShowNativeSmallPrivate(context, parentView)
    }

    private fun loadNativePrivate(context: Context, adId: String, listener: (NativeAd?) -> Unit) {
        if (!context.isInternetConnected() || !AdsPreferences(context).adsEnable || AdsPreferences(
                context
            ).isPro
        ) {
            listener(null)
            return
        }
        val adLoader = AdLoader.Builder(context, adId)
            .forNativeAd { listener(it) }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    listener(null)
                    mSmallNativeAdShow = false
                }

                override fun onAdImpression() {
                    mSmallNativeAdShow = true
                }
            })
            .build()

        adLoader.loadAd(AdRequest.Builder().build())
    }

    fun loadSmallNative8Private(context: Context, mAdId: String, listener: (NativeAd?) -> Unit) {
        loadNative8Private(context, mAdId) {
            mSmallNativeAd8 = it
            listener(it)
        }
    }

    fun showNative8Private(context: Context, parentView: ViewGroup) {
        mSmallNativeAd8?.let {
            AdmobNative.populateSmallNativeAd(context, parentView, it)
        } ?: manageShowNativeSmallPrivate(context, parentView)
    }

    private fun manageShowNativeSmallPrivate(context: Context, parentView: ViewGroup) {
        val adsToShow = listOfNotNull(
            mSmallNativeAd.takeIf { mSmallNativeAdShow },
            mSmallNativeAd8.takeIf { mSmallNativeAd8Show }
        )

        if (adsToShow.isNotEmpty()) {
            AdmobNative.populateSmallNativeAd(
                context,
                parentView,
                adsToShow.first() as NativeAd
            )
        }
    }

    private fun loadNative8Private(context: Context, adId: String, listener: (NativeAd?) -> Unit) {
        if (!context.isInternetConnected() || !AdsPreferences(context).adsEnable || AdsPreferences(
                context
            ).isPro
        ) {
            listener(null)
            return
        }

        val adLoader = AdLoader.Builder(context, adId)
            .forNativeAd { listener(it) }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    listener(null)
                    mSmallNativeAd8Show = false
                }

                override fun onAdImpression() {
                    mSmallNativeAd8Show = true
                }
            })
            .build()

        adLoader.loadAd(AdRequest.Builder().build())
    }

    fun onDestroy() {
        mSmallNativeAd?.destroy()
        mSmallNativeAd = null
        mSmallNativeAd8?.destroy()
        mSmallNativeAd8 = null
    }

}