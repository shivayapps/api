package messages.sms.text.chat.messanger.app.repository

import io.reactivex.Observable
import messages.sms.text.chat.messanger.app.model.BackupFile

interface BackupRepository {

    sealed class Progress(val running: Boolean = false, val indeterminate: Boolean = true) {
        class Idle : Progress()
        class Parsing : Progress(true)
        class Running(val max: Int, val count: Int) : Progress(true, false)
        class Saving : Progress(true)
        class Syncing : Progress(true)
        class Finished : Progress(true, false)
    }

    fun performBackup()

    fun getBackupProgress(): Observable<Progress>

    /**
     * Returns a list of all local backups
     */
    fun getBackups(): Observable<List<BackupFile>>

    fun performRestore(filePath: String)

    fun stopRestore()
    fun deleteBackup(filePath: String)
    fun stopBackup()

    fun getRestoreProgress(): Observable<Progress>

}
