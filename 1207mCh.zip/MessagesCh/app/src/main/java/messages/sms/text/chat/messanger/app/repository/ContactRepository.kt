package messages.sms.text.chat.messanger.app.repository

import android.net.Uri
import io.reactivex.Observable
import io.reactivex.Single
import io.realm.RealmResults
import messages.sms.text.chat.messanger.app.model.Contact
import messages.sms.text.chat.messanger.app.model.ContactData
import messages.sms.text.chat.messanger.app.model.ContactGroup

interface ContactRepository {

    fun findContactUri(address: String): Single<Uri>

    fun getContacts(): RealmResults<Contact>
    fun getRecentContacts(): RealmResults<Contact>

    fun getUnmanagedContact(lookupKey: String): Contact?

    fun getUnmanagedContacts(starred: Boolean = false): Observable<List<Contact>>
    fun getContactsList(starred: Boolean = false): List<ContactData>
    fun getContactsListOb(starred: Boolean = false): Observable<List<ContactData>>
    fun getContactsListRecentOb(starred: Boolean = false): Observable<List<ContactData>>

    fun getUnmanagedContactGroups(): Observable<List<ContactGroup>>

    fun setDefaultPhoneNumber(lookupKey: String, phoneNumberId: Long)

}
