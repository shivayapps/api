package  messages.sms.text.chat.messanger.app.ads

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.annotation.Size
import androidx.multidex.BuildConfig
import com.google.firebase.analytics.FirebaseAnalytics

fun Activity.getActivityName(): String {
    return localClassName.substring(localClassName.lastIndexOf(".") + 1)
}

fun Context.getActivityName(): String {
    if (this is Activity) {
        return getActivityName()
    }
    return ""
}

class FirebaseAnalyticsHandler(val context: Context) {
    fun logMessages(
        @Size paramName: String,
        @Size actName: String,
    ) {
        if (context.isInternetConnected()) {
            try {
                val mBundle = Bundle()
                mBundle.putString(paramName, actName)
                if (BuildConfig.DEBUG) {
                    Log.e("firebaseAnalytics", "$paramName $mBundle")
                } else {
                    Log.e("firebaseAnalytics LIVE", "$paramName $mBundle")
                    FirebaseAnalytics.getInstance(context).logEvent(paramName, mBundle)
                }
            } catch (e: Exception) {
            }
        }
    }

    fun logMessages2(
        @Size paramMain: String,
        @Size paramName: String,
        @Size actName: String,
    ) {
        if (context.isInternetConnected()) {
            try {
                val mBundle = Bundle()
                mBundle.putString(paramName, actName)
                if (BuildConfig.DEBUG) {
                    Log.e("firebaseAnalytics", "$paramMain  $mBundle")
                } else {
                    Log.e("firebaseAnalytics LIVE", "$paramMain $mBundle")
                    // FirebaseAnalytics.getInstance(context).logEvent(paramMain, mBundle)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}

const val app_appopen_created = "app_appopen_created"
const val app_ad_appopen_shown = "app_ad_appopen_shown"
const val app_ad_appopen_failed = "app_ad_appopen_shown"
const val app_first_session_bev_first_tracking = "app_first_session_bev_first_tracking"
const val app_splash_first_tracking = "app_splash_first_tracking"
const val app_language_first_tracking = "app_language_first_tracking"
const val app_home_first_tracking = "app_home_first_tracking"
const val app_splash_created = "app_splash_created"
const val app_language_created = "app_language_created"
const val app_home_created = "app_home_created"
const val app_notification_overlay_created = "app_notification_overlay_created"
const val app_notification_overlay_details_clicked = "app_notification_overlay_details_clicked"
const val app_notification_overlay_snooze_clicked = "app_notification_overlay_snooze_clicked"
const val app_notification_overlay_gotit_clicked = "app_notification_overlay_gotit_clicked"
const val app_notification_overlay_mark_complete_clicked =
    "app_notification_overlay_mark_complete_clicked"
const val app_notification_fullscreen_details_clicked =
    "app_notification_fullscreen_details_clicked"
const val app_notification_fullscreen_snooze_clicked = "app_notification_fullscreen_snooze_clicked"
const val app_notification_fullscreen_gotit_clicked = "app_notification_fullscreen_gotit_clicked"
const val app_holiday_clicked = "app_holiday_clicked"
const val app_theme_created = "app_theme_created"
const val app_theme_clicked = "app_theme_clicked"
const val app_widget_created = "app_widget_created"
const val app_widget_clicked = "app_widget_clicked"
const val app_notification_bar_created = "app_notification_bar_created"
const val app_notification_bar_clicked = "app_notification_bar_clicked"
const val app_event_clicked = "app_event_clicked"
const val app_task_clicked = "app_task_clicked"
const val app_ai_description_clicked = "app_ai_description_clicked"

const val app_banner_created = "app_banner_created"
const val app_ad_banner_shown = "app_ad_banner_shown"
const val app_ad_banner_failed = "app_ad_banner_failed"

const val app_native_created = "app_native_created"
const val app_ad_native_shown = "app_ad_native_shown"
const val app_ad_native_failed = "app_ad_native_failed"

const val app_inter_created = "app_inter_created"
const val app_ad_inter_shown = "app_ad_inter_shown"
const val app_ad_inter_failed = "app_ad_inter_failed"

const val app_singlead_click = "app_singlead_click"

const val cad_click_setup = "cad_click_setup"
const val cad_call_allow_permission = "cad_call_allow_permission"
const val cad_call_deny_permission = "cad_call_deny_permission"
const val cad_overlay_allow_permission = "cad_overlay_allow_permission"
const val cad_overlay_deny_permission = "cad_overlay_deny_permission"