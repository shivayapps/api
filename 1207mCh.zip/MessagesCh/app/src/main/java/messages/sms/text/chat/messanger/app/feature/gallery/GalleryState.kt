package messages.sms.text.chat.messanger.app.feature.gallery

import io.realm.RealmResults
import messages.sms.text.chat.messanger.app.model.MmsPart

data class GalleryState(
    val navigationVisible: Boolean = true,
    val title: String? = "",
    val parts: RealmResults<MmsPart>? = null,
)
