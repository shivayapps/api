package messages.sms.text.chat.messanger.app.appmanager

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.AnimationDrawable
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.util.Log
import android.view.View
import android.view.animation.AccelerateInterpolator
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.doOnTextChanged
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.ads.AdmobNative
import messages.sms.text.chat.messanger.app.ads.GoogleInterAdManager.mInterstitialAd
import messages.sms.text.chat.messanger.app.ads.MainInterAdManager.loadManageAppsInter
import messages.sms.text.chat.messanger.app.ads.MainInterAdManager.showManageAppsInter
import messages.sms.text.chat.messanger.app.ads.delayExecution
import messages.sms.text.chat.messanger.app.ads.getAppManageAppsNative
import messages.sms.text.chat.messanger.app.commons.extensions.beGone
import messages.sms.text.chat.messanger.app.commons.extensions.beVisible
import messages.sms.text.chat.messanger.app.commons.extensions.updateTextColors
import messages.sms.text.chat.messanger.app.databinding.ActivityFindAppBinding
import kotlin.math.roundToInt


class FindAppActivity : AppCompatActivity() {

    private lateinit var appListAdapter: AppListAdapter

    lateinit var binding: ActivityFindAppBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFindAppBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateTextColors(binding.clManageApp)


        mInterstitialAd = null
        loadManageAppsInter(this)
        window.statusBarColor = ContextCompat.getColor(this, R.color.primary)

//        setupToolbar(binding.customizationToolbar, NavigationIcon.Arrow)
        binding.customizationToolbar.setBackgroundColor(Color.TRANSPARENT)
        binding.customizationToolbar.title = "Manage Apps"
//        binding.customizationToolbar.toInt()

        binding.llScanner.beVisible()
        binding.llComplete.beGone()
        val animDrawable = binding.root.background as AnimationDrawable
        animDrawable.setEnterFadeDuration(10)
        animDrawable.setExitFadeDuration(5000)
        animDrawable.start()

        setSupportActionBar(binding.customizationToolbar)

        // Enable the back button

        // Enable the back button
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.setDisplayShowHomeEnabled(true)

        // Handle back button click

        // Handle back button click
        binding.customizationToolbar.setNavigationOnClickListener {
            // Finish the activity or handle the back navigation
            onBackPressed()
        }
        binding.countTextView.run {
            interpolator(AccelerateInterpolator())
            start()
        }
        binding.countTextView.doOnTextChanged { text, start, before, count ->
            if (text?.contains("100") == true) {
                setupScanComplete()
                Handler(Looper.getMainLooper()).postDelayed({

                    if (mInterstitialAd != null) {
                        loadNative()
                        showManageAppsInter(this, {

                            startActivity(
                                Intent(
                                    this@FindAppActivity,
                                    ManageAppActivity::class.java
                                )
                            )
                            finish()
                        })
                    }
                }, 300)
            }
        }

        binding.btnManage.setOnClickListener {
            loadNative()
            showManageAppsInter(this, {
                startActivity(Intent(this@FindAppActivity, ManageAppActivity::class.java))
                finish()
            })
        }

//        AdmobIntersAdImpl().load(this,getString(R.string.AppManager_Inter))


        getStorageInfo()
    }

    private fun loadNative() {
        delayExecution(300) {
            AdmobNative.preLoad(this, { isLoaded, nativeAd ->
            }, getAppManageAppsNative())
        }
    }

    fun setupScanComplete() {
        binding.llScanner.beGone()
        binding.llComplete.beVisible()
    }


    fun getStorageInfo() {

        binding.donutProgress.visibility = View.VISIBLE
        binding.donutProgressText.visibility = View.VISIBLE

        // Ensure we have a valid external storage directory
        val externalStorageDir = Environment.getExternalStorageDirectory()

        if (externalStorageDir != null) {
            val statFs = StatFs(externalStorageDir.path)

            // Get total space, available space, and used space
            val totalBytes: Long
            val availableBytes: Long
            val usedBytes: Long
            val availablePercentage: Double
            val usedBytesPercentage: Double

            // Check Android version to handle different StatFs methods
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                totalBytes = statFs.totalBytes
                availableBytes = statFs.availableBytes
            } else {
                @Suppress("DEPRECATION")
                totalBytes = statFs.blockSizeLong * statFs.blockCountLong
                @Suppress("DEPRECATION")
                availableBytes = statFs.blockSizeLong * statFs.availableBlocksLong
            }

            usedBytes = totalBytes - availableBytes

            // Calculate available space percentage
            availablePercentage = (availableBytes.toDouble() / totalBytes.toDouble()) * 100
            usedBytesPercentage = (usedBytes.toDouble() / totalBytes.toDouble()) * 100

            // Log or display the storage information
            Log.d("StorageInfo", "Total Space: ${formatSize(totalBytes)}")
            Log.d(
                "StorageInfo",
                "Available Space: ${formatSize(availableBytes)} (${
                    String.format(
                        "%.2f",
                        availablePercentage / 10
                    )
                }%)"
            )
            Log.d(
                "StorageInfo",
                "Available Space: ${formatSize(usedBytes)} (${
                    String.format(
                        "%.2f",
                        availablePercentage / 10
                    )
                }%)"
            )
            Log.d("StorageInfo", "Used Space: ${formatSize(usedBytes)}")




            binding.donutProgress.progress = usedBytesPercentage.roundToInt().toFloat()
            binding.donutProgress.text = String.format("%.2f", availablePercentage) + "%"


        } else {
            Log.e("StorageInfo", "External storage directory is not available.")
            binding.donutProgress.visibility = View.GONE
            binding.donutProgressText.visibility = View.GONE
        }
    }


    fun formatSize(bytes: Long): String {
        val kb = bytes / 1024
        val mb = kb / 1024
        val gb = mb / 1024
        return when {
            gb > 0 -> "${gb} GB"
            mb > 0 -> "${mb} MB"
            kb > 0 -> "${kb} KB"
            else -> "$bytes Bytes"
        }
    }
}
