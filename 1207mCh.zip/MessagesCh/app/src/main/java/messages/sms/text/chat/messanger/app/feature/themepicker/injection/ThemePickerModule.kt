package messages.sms.text.chat.messanger.app.feature.themepicker.injection

import dagger.Module
import dagger.Provides
import messages.sms.text.chat.messanger.app.feature.themepicker.ThemePickerController
import messages.sms.text.chat.messanger.app.injection.scope.ControllerScope
import javax.inject.Named

@Module
class ThemePickerModule(private val controller: ThemePickerController) {

    @Provides
    @ControllerScope
    @Named("recipientId")
    fun provideThreadId(): Long = controller.recipientId

}