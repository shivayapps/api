package messages.sms.text.chat.messanger.app.feature.contacts

import messages.sms.text.chat.messanger.app.feature.compose.editing.ComposeItem
import messages.sms.text.chat.messanger.app.model.Contact

data class ContactsState(
    val query: String = "",
    val composeItems: List<ComposeItem> = ArrayList(),
    val selectedContact: Contact? = null, // For phone number picker
)
