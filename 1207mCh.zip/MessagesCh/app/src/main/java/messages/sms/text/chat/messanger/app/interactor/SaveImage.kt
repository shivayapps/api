package messages.sms.text.chat.messanger.app.interactor

import io.reactivex.Flowable
import messages.sms.text.chat.messanger.app.repository.MessageRepository
import javax.inject.Inject

class SaveImage @Inject constructor(
    private val messageRepo: MessageRepository,
) : Interactor<Long>() {

    override fun buildObservable(params: Long): Flowable<*> {
        return Flowable.just(params)
            .doOnNext { partId -> messageRepo.savePart(partId) }
    }

}