package messages.sms.text.chat.messanger.app.feature.main

import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.core.graphics.ColorUtils
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import dagger.android.AndroidInjection
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.ads.GoogleSmallNativeAdManagerHome
import messages.sms.text.chat.messanger.app.ads.MainInterAdManager
import messages.sms.text.chat.messanger.app.common.base.QkThemedActivity
import messages.sms.text.chat.messanger.app.common.util.extensions.resolveThemeColor
import messages.sms.text.chat.messanger.app.common.util.extensions.viewBinding
import messages.sms.text.chat.messanger.app.commons.extensions.addAlpha
import messages.sms.text.chat.messanger.app.commons.extensions.baseConfig
import messages.sms.text.chat.messanger.app.commons.extensions.beGone
import messages.sms.text.chat.messanger.app.commons.extensions.beVisible
import messages.sms.text.chat.messanger.app.commons.extensions.clientConfigPref
import messages.sms.text.chat.messanger.app.commons.extensions.config
import messages.sms.text.chat.messanger.app.commons.extensions.updateTextColors
import messages.sms.text.chat.messanger.app.databinding.SettingActivityBinding
import messages.sms.text.chat.messanger.app.manager.PermissionManagerImpl
import messages.sms.text.chat.messanger.app.model.MessageEvent
import messages.sms.text.chat.messanger.app.model.REFRESH_MESSAGE
import messages.sms.text.chat.messanger.app.model.SYNC_MESSAGE
import messages.sms.text.chat.messanger.app.model.TEMP_REFRESH_MESSAGE
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import org.json.JSONObject
import javax.inject.Inject


class SettingActivity : QkThemedActivity() {
    private val binding by viewBinding(SettingActivityBinding::inflate)

    var alertDialog: AlertDialog? = null
    val REQUEST_DRAW_OVERLAYS_PERMISSION = 1002

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
//        binding=MainActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)


//        setSupportActionBar(binding.messageTab.toolbar)
        setSupportActionBar(binding.toolbar)
        isHomeBackClick = false
        showBackButton(true)

        if (!PermissionManagerImpl(this).isDefaultSms()) {
            MainInterAdManager.loadGeneralInter(this)
        }

        fetchJSONArrayFromRemoteConfig()


        binding.ivCaller.setOnClickListener {
            if (!Settings.canDrawOverlays(this@SettingActivity)) {
                permissiondialog()
            }

        }

        binding.ivBack.setOnClickListener {
            finish()
        }

        theme
            .autoDispose(scope())
            .subscribe { theme ->
                // Set the color for the drawer icons
                val states = arrayOf(
                    intArrayOf(android.R.attr.state_activated),
                    intArrayOf(-android.R.attr.state_activated)
                )

                resolveThemeColor(android.R.attr.textColorSecondary)
                    .let { textSecondary ->
                        ColorStateList(
                            states,
                            intArrayOf(theme.theme, textSecondary)
                        )
                    }
                    .let { tintList ->
                    }
            }
        setUpTheme()

        initListener()

        if (baseConfig.ringtoneUri.isEmpty()) {
            baseConfig.ringtoneUri =
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION).toString()
        }

    }

    private fun permissiondialog() {
        if (isFinishing || isDestroyed) {
            return
        }

        val dialogBuilder = AlertDialog.Builder(this)
        val view = layoutInflater.inflate(R.layout.dialog_call_permission, null)

        dialogBuilder.setView(view)

        val btnPermission = view.findViewById<TextView>(R.id.btnPermission)
        val applyBackground = ResourcesCompat.getDrawable(
            resources,
            R.drawable.button_background_rounded,
            null
        ) as RippleDrawable
        (applyBackground as LayerDrawable).findDrawableByLayerId(R.id.button_background_holder)
            .setColorFilter(Color.parseColor("#3774FF"), PorterDuff.Mode.SRC_IN)
        btnPermission.background = applyBackground

        btnPermission.setTextColor(Color.parseColor("#FFFFFF"))

        btnPermission.setOnClickListener {
//            askPermissions()

            requestSystemOverlayPermission()
        }

        alertDialog = dialogBuilder.create()

        alertDialog?.setOnDismissListener {


            if (config.getBooleanData("checkfirsttimedialog") == true) {

            } else {

            }
        }

        alertDialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        if (alertDialog?.isShowing == false) {

            alertDialog?.show()
//            CHECK_FIRSTTIME_DIALOG = true
        }
    }

    private fun requestSystemOverlayPermission() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:" + packageName)
        )
        try {
            startActivityForResult(intent, REQUEST_DRAW_OVERLAYS_PERMISSION)
        } catch (e: Exception) {
//            Log.e("printStackTrace", "printStackTrace:$e")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
        super.onActivityResult(requestCode, resultCode, resultData)

        if (requestCode == REQUEST_DRAW_OVERLAYS_PERMISSION) {

//            Log.i("onActivityResult", "onActivityResult: ")
//            Log.i("stopLoaderdfef", "request: ")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (Settings.canDrawOverlays(this)) {
                    //  navController.navigate(R.id.albumFragment)
                    //  showBanner(false)

                    alertDialog?.dismiss()
                    binding.ivCaller.visibility = View.GONE
//                    val intent = intent
//                    finish()
//                    startActivity(intent)

                }
            } else {
                //   navController.navigate(R.id.albumFragment)

            }

        }
    }


    private fun setUpTheme() {

        val primaryColorWithAlpha =
            ColorUtils.setAlphaComponent(baseConfig.primaryColor, (255 * 0.1).toInt())

        val textColorPrimaryss = baseConfig.textColor
        val colorWithAlpha = textColorPrimaryss.addAlpha(0.6F)

        updateTextColors(binding.mainLayout)
        binding.toolbarTitle.setTextColor(baseConfig.primaryColor)

//        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource != -1) {

//                binding.navView.setBackgroundColor(baseConfig.backgroundColor)
//                val bitmapDrawable = BitmapDrawable(resources, baseConfig.storedBitmap)
//                constraintLayout.background = bitmapDrawable
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.mainLayout.background = drawable

                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
                val unselectedColor =
                    ContextCompat.getColor(this, android.R.color.darker_gray) // Unselected color
                val states = arrayOf(
                    intArrayOf(android.R.attr.state_checked), // Selected state
                    intArrayOf(-android.R.attr.state_checked) // Unselected state
                )

            }
        } else {
            binding.mainLayout.background = null
            val primaryColor = baseConfig.primaryColor
//            lloptionmenu.setBackgroundColor(baseConfig.backgroundColor)
            toolbar.setBackgroundColor(baseConfig.backgroundColor)

            val unselectedColor =
                ContextCompat.getColor(this, android.R.color.darker_gray) // Unselected color
            val states = arrayOf(
                intArrayOf(android.R.attr.state_checked), // Selected state
                intArrayOf(-android.R.attr.state_checked) // Unselected state
            )
            val colors = intArrayOf(
                primaryColor, // Color for selected state
                unselectedColor // Color for unselected state
            )

            val colorStateList = ColorStateList(states, colors)

        }

    }

    private fun initListener() {

    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
    }

    var addContact = false
    var markPinned = false
    var markRead = false
    var selectedConversations = 0
    var currentPage: MainPage = Inbox()


    override fun onResume() {
        super.onResume()
        if (prefs.themechanged.get()) {
            runOnUiThread {
                prefs.themechanged.set(false)
                // Set the theme color tint to the recyclerView, progressbar, and FAB
                theme
                    .autoDispose(scope())
                    .subscribe { theme ->
                        // Set the color for the drawer icons
                        val states = arrayOf(
                            intArrayOf(android.R.attr.state_activated),
                            intArrayOf(-android.R.attr.state_activated)
                        )

                        resolveThemeColor(android.R.attr.textColorSecondary)
                            .let { textSecondary ->
                                ColorStateList(
                                    states,
                                    intArrayOf(theme.theme, textSecondary)
                                )
                            }
                            .let { tintList ->
                            }
                    }

                setUpTheme()
            }
        }

        if (Settings.canDrawOverlays(this)) {
            binding.ivCaller.visibility = View.GONE
        } else {
            binding.ivCaller.visibility = View.GONE
        }
    }


    override fun onPause() {
        super.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
//        disposables.dispose()
        if (EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().unregister(this)

        GoogleSmallNativeAdManagerHome.onDestroy()
    }

    override fun setTitle(titleId: Int) {
        //super.setTitle(titleId)
        binding.toolbarTitle.text = getString(titleId)
    }

    override fun setTitle(title: CharSequence?) {
        ///super.setTitle(title)
        binding.toolbarTitle.text = title
    }

    override fun showBackButton(show: Boolean) {

        if (show) {
            binding.mainToolbar.beGone()
        } else {
            binding.mainToolbar.beVisible()
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        when (event.type) {
            REFRESH_MESSAGE -> {
                Log.e("onMessageEvent", "REFRESH_MESSAGE")

//                viewModel.refreshMessages()
            }


            SYNC_MESSAGE -> {
                Log.e("onMessageEvent", "SYNC_MESSAGE")
//                viewModel.forceRefreshMessages()
            }

            TEMP_REFRESH_MESSAGE -> {
//                viewModel.refreshMessages()
            }
        }
    }


//    private fun initContactView() {
//        val adapter = ViewPagerAdapter(this, supportFragmentManager)
////        adapter.addFragment(AllContactFragment())
//
//        val drawable = GradientDrawable()
//        drawable.shape = GradientDrawable.RECTANGLE
//        val colorWithOpacity = baseConfig.primaryColor
//
//        val colorWith20Opacity =
//            colorWithOpacity?.let { ColorUtils.setAlphaComponent(it, 20) } // 51 is 20% of 255
//        if (colorWith20Opacity != null) {
//            drawable.setColor(colorWith20Opacity)
//        }
//        val strokeWidthInDp = 1.5f
//        val strokeWidthInPixels =
//            (strokeWidthInDp * resources?.displayMetrics!!.density + 0.5f).toInt()
//        baseConfig.let { drawable.setStroke(strokeWidthInPixels, it.primaryColor) }
//        val cornerRadius = resources?.getDimension(R.dimen.normal_text_size)
//        if (cornerRadius != null) {
//            drawable.cornerRadius = cornerRadius
//        }
//
//        binding.contactTab.loutTab.tabIndicator.indicatorDrawable = drawable
//        binding.contactTab.loutTab.apply {
//            observeIndexChange { fromIndex, toIndex, reselect, fromUser ->
//                binding.contactTab.viewPager.currentItem = toIndex
//            }
//            tabLayoutConfig?.tabDeselectColor = baseConfig.textColor
//            tabLayoutConfig?.tabSelectColor = baseConfig.textColor
//        }
//
//        binding.contactTab.viewPager.addOnPageChangeListener(object :
//            ViewPager.OnPageChangeListener {
//            override fun onPageScrolled(
//                position: Int,
//                positionOffset: Float,
//                positionOffsetPixels: Int,
//            ) {
//
//            }
//
//            override fun onPageSelected(position: Int) {
//                binding.contactTab.loutTab.onPageSelected(position)
//
//            }
//
//            override fun onPageScrollStateChanged(state: Int) {
//
//            }
//        })
//
//        /*    binding.messageTab.recyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
//             override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
//                 super.onScrollStateChanged(recyclerView, newState)
//                 val layoutManager = recyclerView.layoutManager as? LinearLayoutManager
//                 val isVisible = (layoutManager?.findFirstCompletelyVisibleItemPosition()!! > 10)
//                 binding.messageTab.goToTopButton.visibility = if (isVisible) View.VISIBLE else View.GONE
//             }
//         })*/
//
//        binding.messageTab.recyclerView.addOnScrollListener(object :
//            RecyclerView.OnScrollListener() {
//
//            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
//                super.onScrolled(recyclerView, dx, dy)
//
//                val layoutManager = recyclerView.layoutManager as? LinearLayoutManager
//                val isVisible = (layoutManager?.findFirstCompletelyVisibleItemPosition()!! > 5)
//                binding.messageTab.goToTopButton.visibility =
//                    if (isVisible) {
//                        View.VISIBLE
//                    } else {
//                        View.GONE
//                    }
//
//                if (dy > 5) {
//                    binding.messageTab.compose.collapse()
//                } else {
//                    binding.messageTab.compose.expand()
//                }
//            }
//        })
//    }

    fun fetchJSONArrayFromRemoteConfig() = CoroutineScope(Dispatchers.IO).launch {

        CoroutineScope(Dispatchers.IO).launch {
//            FirebaseApp.initializeApp(this@SplashActivity)
            // Now you can safely use Firebase Remote Config
            val remoteConfig = FirebaseRemoteConfig.getInstance()

            remoteConfig.setDefaultsAsync(R.xml.remote_config_defaults)
            val configSettings = FirebaseRemoteConfigSettings.Builder()
                .setMinimumFetchIntervalInSeconds(1)
                .build()
            remoteConfig.setConfigSettingsAsync(configSettings)

        }
    }

}
