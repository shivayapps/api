package messages.sms.text.chat.messanger.app.password

import android.content.Context
import android.view.LayoutInflater
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import messages.sms.text.chat.messanger.app.R

class AddContactDialog(context: Context, private val callback: DialogCallback) {

    init {
        showDialog(context)
    }

    private fun showDialog(context: Context) {
        // Inflate the custom layout
        val inflater = LayoutInflater.from(context)
        val dialogView = inflater.inflate(R.layout.add_contact_dialog_layout, null)

        // Find and set click listeners for each item
        val item1 = dialogView.findViewById<TextView>(R.id.item1)
        val item2 = dialogView.findViewById<TextView>(R.id.item2)
        val item3 = dialogView.findViewById<TextView>(R.id.item3)

        // Create and configure the AlertDialog
        val dialog = AlertDialog.Builder(context, R.style.AppThemeDialog)
            .setView(dialogView)
            .setNegativeButton("Cancel") { dialogInterface, _ ->
                dialogInterface.dismiss()
            }
            .create()
        dialog.window?.setBackgroundDrawableResource(R.drawable.rounded_dialog)

        item1.setOnClickListener {
            callback.onItemClick(1)
            dialog.dismiss()
        }

        item2.setOnClickListener {
            callback.onItemClick(2)
            dialog.dismiss()
        }

        item3.setOnClickListener {
            callback.onItemClick(3)
            dialog.dismiss()
        }

        // Show the dialog
        dialog.show()
    }
}

interface DialogCallback {
    fun onItemClick(position: Int)
}