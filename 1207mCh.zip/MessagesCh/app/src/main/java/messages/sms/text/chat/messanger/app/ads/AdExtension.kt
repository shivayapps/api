package  messages.sms.text.chat.messanger.app.ads

import android.app.Activity
import android.content.Context
import android.net.ConnectivityManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import messages.sms.text.chat.messanger.app.R


val Context.firebaseAnalyticsHandler: FirebaseAnalyticsHandler get() = FirebaseAnalyticsHandler(this)

fun Context.isFirstTimeAppOpen(): Boolean {

    return AdsPreferences(this).splashCounter <= 1


}


fun View.beVisibleIf(beVisible: Boolean) = if (beVisible) beVisible() else beGone()

fun View.beGoneIf(beGone: Boolean) = beVisibleIf(!beGone)

fun View.beInvisible() {
    visibility = View.INVISIBLE
}

fun View.beVisible() {
    visibility = View.VISIBLE
}


fun View.beGone() {
    visibility = View.GONE
}

fun Activity.delayExecution(millis: Long, callback: () -> Unit) {
    Handler(Looper.myLooper()!!).postDelayed({
        callback()
    }, millis)
}
fun Context.getAppListNative1(): String {
    if (isFirstTimeAppOpen()) {
        Log.d("AdsId", "getAppListNative: home_banner_native1_1")
        return getString(R.string.home_banner_native1_1)
    }
    Log.d("AdsId", "getAppListNative: home_banner_native1_2")
    return getString(R.string.home_banner_native1_2)
}

fun Context.getAppListNative3(): String {
    if (isFirstTimeAppOpen()) {
        Log.d("AdsId", "getAppListNative: home_banner_native3_1")
        return getString(R.string.home_banner_native3_1)
    }
    Log.d("AdsId", "getAppListNative: home_banner_native3_2")
    return getString(R.string.home_banner_native3_2)
}

fun Context.getAppArchivedNative1(): String {
    if (isFirstTimeAppOpen()) {
        Log.d("AdsId", "getAppListNative: home_banner_native1_1")
        return getString(R.string.home_archived_native1_1)
    }
    Log.d("AdsId", "getAppListNative: home_banner_native1_2")
    return getString(R.string.home_archived_native1_2)
}

fun Context.getAppArchivedNative3(): String {
    if (isFirstTimeAppOpen()) {
        Log.d("AdsId", "getAppListNative: home_banner_native3_1")
        return getString(R.string.home_archived_native3_1)
    }
    Log.d("AdsId", "getAppListNative: home_banner_native3_2")
    return getString(R.string.home_archived_native3_2)
}

fun Context.getAppPrivateNative1(): String {
    if (isFirstTimeAppOpen()) {
        Log.d("AdsId", "getAppListNative: home_banner_native1_1")
        return getString(R.string.home_private_native1_1)
    }
    Log.d("AdsId", "getAppListNative: home_banner_native1_2")
    return getString(R.string.home_private_native1_2)
}

fun Context.getAppPrivateNative3(): String {
    if (isFirstTimeAppOpen()) {
        Log.d("AdsId", "getAppListNative: home_banner_native3_1")
        return getString(R.string.home_private_native3_1)
    }
    Log.d("AdsId", "getAppListNative: home_banner_native3_2")
    return getString(R.string.home_private_native3_2)
}

fun Context.getAppManageAppsNative(): String {
    if (AdsPreferences(this).selectedLanguage.isEmpty()) {
        Log.d("AdsId", "getAppListNative: manage_apps_native_1")
        return getString(R.string.manage_apps_native_1)
    }
    Log.d("AdsId", "getAppListNative: manage_apps_native_2")
    return getString(R.string.manage_apps_native_2)
}


fun Context.getAppChatScreenNative(): String {
    if (AdsPreferences(this).selectedLanguage.isEmpty()) {
        Log.d("AdsId", "getAppListNative: language_native_1")
        return getString(R.string.chat_screen_native_1)
    }
    Log.d("AdsId", "getAppListNative: language_native_2")
    return getString(R.string.chat_screen_native_2)
}

fun Context.getAppCallerCardNative(): String {
    if (AdsPreferences(this).selectedLanguage.isEmpty()) {
        Log.d("AdsId", "getAppListNative: caller_card_native_1")
        return getString(R.string.caller_card_native_1)
    }
    Log.d("AdsId", "getAppListNative: caller_card_native_2")
    return getString(R.string.caller_card_native_2)
}

fun Context.getAppManageAppsInter(): String {
    if (AdsPreferences(this).selectedLanguage.isEmpty()) {
        Log.d("AdsId", "getAppCallerCardNative: manage_apps_inter_1")
        return getString(R.string.manage_apps_inter_1)
    }
    Log.d("AdsId", "getAppCallerCardNative: manage_apps_inter_2")
    return getString(R.string.manage_apps_inter_2)
}

fun Context.getAppPermissionInter(): String {
    if (isFirstTimeAppOpen()) {
        Log.d("AdsId", "getAppPermissionInter: permission_inter_1")
        return getString(R.string.permission_inter_1)
    }
    Log.d("AdsId", "getAppPermissionInter: permission_inter_2")
    return getString(R.string.permission_inter_2)
}

fun Context.isInternetConnected(): Boolean {
    val connectivityManager =
        getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val activeNetworkInfo = connectivityManager.activeNetworkInfo
    return activeNetworkInfo != null && activeNetworkInfo.isConnected
}