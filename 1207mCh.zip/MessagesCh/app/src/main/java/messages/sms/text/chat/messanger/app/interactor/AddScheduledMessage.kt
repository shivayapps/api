package messages.sms.text.chat.messanger.app.interactor

import io.reactivex.Flowable
import messages.sms.text.chat.messanger.app.repository.ScheduledMessageRepository
import javax.inject.Inject

class AddScheduledMessage @Inject constructor(
    private val scheduledMessageRepo: ScheduledMessageRepository,
    private val updateScheduledMessageAlarms: UpdateScheduledMessageAlarms,
) : Interactor<AddScheduledMessage.Params>() {

    data class Params(
        val date: Long,
        val subId: Int,
        val recipients: List<String>,
        val sendAsGroup: Boolean,
        val body: String,
        val attachments: List<String>,
    )

    override fun buildObservable(params: Params): Flowable<*> {
        return Flowable.just(params)
            .map {
                scheduledMessageRepo.saveScheduledMessage(
                    it.date, it.subId, it.recipients, it.sendAsGroup, it.body,
                    it.attachments
                )
            }
            .flatMap { updateScheduledMessageAlarms.buildObservable(Unit) }
    }

}