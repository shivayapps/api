package messages.sms.text.chat.messanger.app.password.callback;


public interface FingerprintDialogCallback {
    void onAuthenticationSucceeded();

    void onAuthenticationCancel();
}
