package messages.sms.text.chat.messanger.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import dagger.android.AndroidInjection
import messages.sms.text.chat.messanger.app.interactor.SendScheduledMessage
import messages.sms.text.chat.messanger.app.repository.MessageRepository
import javax.inject.Inject

class SendScheduledMessageReceiver : BroadcastReceiver() {

    @Inject
    lateinit var messageRepo: MessageRepository

    @Inject
    lateinit var sendScheduledMessage: SendScheduledMessage

    override fun onReceive(context: Context, intent: Intent) {
        AndroidInjection.inject(this, context)

        intent.getLongExtra("id", -1L).takeIf { it >= 0 }?.let { id ->
            val result = goAsync()
            sendScheduledMessage.execute(id) { result.finish() }
        }
    }

}