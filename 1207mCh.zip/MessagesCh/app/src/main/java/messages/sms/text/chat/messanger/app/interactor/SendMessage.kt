package messages.sms.text.chat.messanger.app.interactor

import android.content.Context
import android.util.Log
import io.reactivex.Flowable
import messages.sms.text.chat.messanger.app.compat.TelephonyCompat
import messages.sms.text.chat.messanger.app.extensions.mapNotNull
import messages.sms.text.chat.messanger.app.model.Attachment
import messages.sms.text.chat.messanger.app.repository.ConversationRepository
import messages.sms.text.chat.messanger.app.repository.MessageRepository
import javax.inject.Inject


class SendMessage @Inject constructor(
    private val context: Context,
    private val conversationRepo: ConversationRepository,
    private val messageRepo: MessageRepository,
    private val updateBadge: UpdateBadge,
) : Interactor<SendMessage.Params>() {

    data class Params(
        val subId: Int,
        val threadId: Long,
        val addresses: List<String>,
        val body: String,
        val attachments: List<Attachment> = listOf(),
        val delay: Int = 0,
    )

    override fun buildObservable(params: Params): Flowable<*> = Flowable.just(Unit)
        .filter { params.addresses.isNotEmpty() }
        .doOnNext {
            // If a threadId isn't provided, try to obtain one
            val threadId = when (params.threadId) {
                0L -> TelephonyCompat.getOrCreateThreadId(context, params.addresses.toSet())
                else -> params.threadId
            }
            Log.w("messageApp : ", "Message buildObservable --  $threadId")

            messageRepo.sendMessage(
                params.subId, threadId, params.addresses, params.body, params.attachments,
                params.delay
            )
        }
        .mapNotNull {
            Log.w("messageApp : ", "Message buildObservable 111--  ")

            // If the threadId wasn't provided, then it's probably because it doesn't exist in Realm.
            // Sync it now and get the id
            when (params.threadId) {
                0L -> conversationRepo.getOrCreateConversation(params.addresses)?.id
                else -> params.threadId
            }
        }
        .doOnNext { threadId ->
            Log.w("messageApp : ", "Message Send Messsage updateConversations--  ")
            conversationRepo.updateConversations(threadId)
        }
        .doOnNext { threadId ->
            Log.w("messageApp : ", "Message Send Messsage markUnarchived --  ")
            conversationRepo.markUnarchived(threadId)
        }
        .flatMap { updateBadge.buildObservable(Unit) } // Update the widget

}