package messages.sms.text.chat.messanger.app.feature.themepicker

import android.animation.ObjectAnimator
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.jakewharton.rxbinding2.view.clicks
import io.reactivex.Observable
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.common.base.QkController
import messages.sms.text.chat.messanger.app.common.util.Colors
import messages.sms.text.chat.messanger.app.common.util.extensions.dpToPx
import messages.sms.text.chat.messanger.app.common.util.extensions.setBackgroundTint
import messages.sms.text.chat.messanger.app.common.util.extensions.setVisible
import messages.sms.text.chat.messanger.app.databinding.ThemePickerControllerBinding
import messages.sms.text.chat.messanger.app.feature.themepicker.injection.ThemePickerModule
import messages.sms.text.chat.messanger.app.injection.appComponent
import javax.inject.Inject

class ThemePickerController(
    val recipientId: Long = 0L,
) : QkController<ThemePickerView, ThemePickerState, ThemePickerPresenter, ThemePickerControllerBinding>(
    ThemePickerControllerBinding::inflate
), ThemePickerView {

    @Inject
    override lateinit var presenter: ThemePickerPresenter

    @Inject
    lateinit var colors: Colors

    @Inject
    lateinit var themeAdapter: ThemeAdapter

    @Inject
    lateinit var themePagerAdapter: ThemePagerAdapter


    init {
        appComponent
            .themePickerBuilder()
            .themePickerModule(ThemePickerModule(this))
            .build()
            .inject(this)
    }

    override fun onViewCreated() {
        binding.pager.offscreenPageLimit = 1
        binding.pager.adapter = themePagerAdapter
        binding.tabs.pager = binding.pager

        themeAdapter.data = colors.materialColors

        binding.materialColors.layoutManager = LinearLayoutManager(activity)
        binding.materialColors.adapter = themeAdapter
    }

    override fun onAttach(view: View) {
        super.onAttach(view)
        presenter.bindIntents(this)
        setTitle(R.string.title_theme)
        showBackButton(true)

        themedActivity?.supportActionBar?.let { toolbar ->
            ObjectAnimator.ofFloat(toolbar, "elevation", toolbar.elevation, 0f).start()
        }
    }

    override fun onDetach(view: View) {
        super.onDetach(view)

        themedActivity?.supportActionBar?.let { toolbar ->
            ObjectAnimator.ofFloat(
                toolbar,
                "elevation",
                toolbar.elevation,
                8.dpToPx(toolbar.themedContext).toFloat()
            )
                .start()
        }
    }


    override fun themeSelected(): Observable<Int> = themeAdapter.colorSelected

    override fun hsvThemeSelected(): Observable<Int> = binding.hsvPicker.picker.selectedColor

    override fun clearHsvThemeClicks(): Observable<*> = binding.hsvPicker.clear.clicks()

    override fun applyHsvThemeClicks(): Observable<*> = binding.hsvPicker.apply.clicks()


    override fun render(state: ThemePickerState) {
        binding.tabs.setRecipientId(state.recipientId)

        binding.hsvPicker.hex.setText(Integer.toHexString(state.newColor).takeLast(6))

        binding.hsvPicker.applyGroup.setVisible(state.applyThemeVisible)
        binding.hsvPicker.apply.setBackgroundTint(state.newColor)
        binding.hsvPicker.apply.setTextColor(state.newTextColor)
    }

    override fun setCurrentTheme(color: Int) {
        binding.hsvPicker.picker.setColor(color)
        themeAdapter.selectedColor = color
    }

}