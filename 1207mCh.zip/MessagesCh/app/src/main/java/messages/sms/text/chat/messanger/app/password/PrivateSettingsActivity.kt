package messages.sms.text.chat.messanger.app.password

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import dagger.android.AndroidInjection
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.common.base.QkThemedActivity
import messages.sms.text.chat.messanger.app.common.util.extensions.viewBinding
import messages.sms.text.chat.messanger.app.commons.extensions.applyColorFilter
import messages.sms.text.chat.messanger.app.commons.extensions.baseConfig
import messages.sms.text.chat.messanger.app.commons.extensions.config
import messages.sms.text.chat.messanger.app.commons.extensions.getBottomNavigationBackgroundColor
import messages.sms.text.chat.messanger.app.commons.extensions.getBottomNavigationBackgroundColorsetting
import messages.sms.text.chat.messanger.app.commons.extensions.updateTextColors
import messages.sms.text.chat.messanger.app.databinding.ActivityPrivateSettingsBinding
import messages.sms.text.chat.messanger.app.feature.main.PrivateContactActivity


class PrivateSettingsActivity : QkThemedActivity() {

    private val binding by viewBinding(ActivityPrivateSettingsBinding::inflate)

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationIcon(R.drawable.ic_chevron_left_vector)
        setUpTheme()

        binding.apply {
            arrayOf(
                privateSettingsSecurityHolder,
                privateSettingsContactHolder,
                privateSettingsEntranceHolder,
                privateSettingsNotificationHolder,
            ).forEach {
                if (baseConfig.useImageResource) {
                    if (baseConfig.storedImageResource == -1) {

                    } else {
                        try {
                            it.background.applyColorFilter(resources.getColor(R.color.transperent30))
                        } catch (_: Exception) {
                        }
                    }
                } else {
                    it.background.applyColorFilter(getBottomNavigationBackgroundColor())
                }
            }

            arrayOf(
                v1,
                v2,
                v3
            ).forEach {
                it.background.applyColorFilter(getBottomNavigationBackgroundColorsetting())
            }
        }

        binding.apply {
            changePassword.setOnClickListener {
                startActivity(
                    Intent(
                        this@PrivateSettingsActivity,
                        ChangePasswordActivity::class.java
                    )
                )
            }
            if (config.settingsFingerprtOn) {
                settingsFingerprtdes.text = resources.getString(R.string.fingerprint_unlock_des)
            } else {
                settingsFingerprtdes.text = resources.getString(R.string.fingerprint_lock_des)
            }

            settingsFingerprint.isChecked = config.settingsFingerprtOn

            settingsColoredContactsHolder.setOnClickListener {
                settingsFingerprint.toggle()
                config.settingsFingerprtOn = settingsFingerprint.isChecked

                if (config.settingsFingerprtOn) {
                    settingsFingerprtdes.text = resources.getString(R.string.fingerprint_unlock_des)
                } else {
                    settingsFingerprtdes.text = resources.getString(R.string.fingerprint_lock_des)
                }
            }


            notificationSwitch.isChecked = config.privateNotification
            llNotificationSwitch.setOnClickListener {
                notificationSwitch.toggle()
                config.privateNotification = notificationSwitch.isChecked

            }

            rprivatebox.setOnClickListener {
                val privateRenameDialog =
                    PrivateRenameDialog(config, this@PrivateSettingsActivity, object :
                        PrivateRenameDialog.renameListener {
                        override fun renameStatus(newString: String) {

                            binding.privateboxDes.text = newString
                        }

                    })
                privateRenameDialog.show()
            }

            hideEntrance.setOnClickListener {
                startActivity(
                    Intent(
                        this@PrivateSettingsActivity,
                        HideEntranceActivity::class.java
                    )
                )

            }

            binding.addContacts.setOnClickListener {
                startActivity(
                    Intent(
                        this@PrivateSettingsActivity,
                        PrivateContactActivity::class.java
                    )
                )
            }


            customNotification.setOnClickListener {
                val customNotificationDialog =
                    CustomNotificationMessageDialog(config, this@PrivateSettingsActivity, object :
                        CustomNotificationMessageDialog.CustomNotificationListener {
                        override fun customNotificationStatus(newString: String) {
                            binding.privateMsg.text = newString
                        }
                    })
                customNotificationDialog.show()
            }
        }

        binding.privateboxDes.text = baseConfig.privateBoxName
        binding.privateMsg.text = baseConfig.customMessageForPrivate
    }


    override fun onResume() {
        super.onResume()
    }

    private fun setUpTheme() {
        updateTextColors(binding.mainLayout)

//        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
        if (baseConfig.backgroundColor.equals(Color.BLACK)) {
            binding.toolbar.background =
                ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))

        } else {
            binding.toolbar.background = ColorDrawable(baseConfig.statusBarColor)

        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource != -1) {
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.mainLayout.background = drawable
                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
            }
        } else {
            binding.mainLayout.background = null
            toolbar.setBackgroundColor(baseConfig.backgroundColor)

        }

        if (baseConfig.backgroundColor.equals(baseConfig.primaryColor)) {
            val applyBackground = ResourcesCompat.getDrawable(
                resources,
                R.drawable.button_background_rounded,
                getTheme()
            ) as RippleDrawable

            (applyBackground as LayerDrawable).findDrawableByLayerId(R.id.button_background_holder)
                .applyColorFilter(Color.parseColor("#FFFFFF"))
        } else {
            val applyBackground = ResourcesCompat.getDrawable(
                resources,
                R.drawable.button_background_rounded,
                getTheme()
            ) as RippleDrawable
            (applyBackground as LayerDrawable).findDrawableByLayerId(R.id.button_background_holder)
                .applyColorFilter(baseConfig.primaryColor)
        }

    }


}