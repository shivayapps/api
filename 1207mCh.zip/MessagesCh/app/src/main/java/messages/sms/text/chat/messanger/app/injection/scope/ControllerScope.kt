package messages.sms.text.chat.messanger.app.injection.scope

import javax.inject.Scope

@Scope
annotation class ControllerScope