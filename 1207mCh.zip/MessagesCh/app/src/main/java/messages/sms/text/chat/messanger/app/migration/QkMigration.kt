package messages.sms.text.chat.messanger.app.migration

import android.content.Context
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import messages.sms.text.chat.messanger.app.blocking.QksmsBlockingClient
import messages.sms.text.chat.messanger.app.common.util.extensions.versionCode
import messages.sms.text.chat.messanger.app.repository.ConversationRepository
import messages.sms.text.chat.messanger.app.util.Preferences
import javax.inject.Inject

class QkMigration @Inject constructor(
    private val context: Context,
    private val conversationRepo: ConversationRepository,
    private val prefs: Preferences,
    private val qksmsBlockingClient: QksmsBlockingClient,
) {

    fun performMigration() {
        GlobalScope.launch {
            prefs.version.set(context.versionCode)
        }
    }


}
