package messages.sms.text.chat.messanger.app.feature.gallery

import io.reactivex.Observable
import messages.sms.text.chat.messanger.app.common.base.QkView
import messages.sms.text.chat.messanger.app.model.MmsPart

interface GalleryView : QkView<GalleryState> {

    fun optionsItemSelected(): Observable<Int>
    fun screenTouched(): Observable<*>
    fun pageChanged(): Observable<MmsPart>

    fun requestStoragePermission()

}