package messages.sms.text.chat.messanger.app.appmanager

import android.graphics.drawable.Drawable

data class AppModel(
    var appName: String,
    var packageName: String,
    var versionCode: Int,
    var versionName: String,
    var launcherIcon: Drawable?,
)
