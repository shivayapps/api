package messages.sms.text.chat.messanger.app.appmanager

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.appmanager.ManageAppActivity.Companion.stoppedAppList
import messages.sms.text.chat.messanger.app.appmanager.ManageAppActivity.Companion.totalStoppedCount
import messages.sms.text.chat.messanger.app.commons.extensions.updateTextColors
import messages.sms.text.chat.messanger.app.databinding.ActivityFinalManageAppScreenBinding

class FinalManageAppScreenActivity : AppCompatActivity() {

    private lateinit var appListAdapter: AppListAdapter

    lateinit var binding: ActivityFinalManageAppScreenBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFinalManageAppScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateTextColors(binding.clManageApp)


//        setupToolbar(binding.customizationToolbar, NavigationIcon.Arrow, getColor(R.color.white))
//        binding.customizationToolbar.background=null
        binding.customizationToolbar.setBackgroundColor(Color.TRANSPARENT)
        binding.customizationToolbar.title = "Manage Apps"
        setSupportActionBar(binding.customizationToolbar)

        // Enable the back button
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        // Handle back button click
        binding.customizationToolbar.setNavigationOnClickListener { view ->
            // Finish the activity or handle the back navigation
            onBackPressed()
        }
        window.statusBarColor = ContextCompat.getColor(this, R.color.primary)
        val countText = resources.getString(R.string.apps_running_in_the_background)
        val stop = resources.getString(R.string.stopped)
        val formattedText = String.format("%s %d %s", stop, totalStoppedCount, countText)
        binding.finalTextBottom.text = formattedText
        stoppedAppList.clear()
        totalStoppedCount = 0

        // binding.finalText

        Handler(Looper.getMainLooper()).postDelayed({

            moveView(binding.finalTextBottom, binding.finalTextTop)
        }, 500)

    }



    private fun moveView(viewToBeMoved: View, targetView: View) {
        val targetX: Float =
            targetView.x + targetView.width / 2 - viewToBeMoved.width / 2
        val targetY: Float =
            targetView.y + targetView.height / 2 - viewToBeMoved.height / 2

        viewToBeMoved.animate()
            .x(targetX)
            .y(targetY)
            .setDuration(800)
            .withEndAction {
                targetView.visibility = View.GONE
            }
            .start()
    }

}
