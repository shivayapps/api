package messages.sms.text.chat.messanger.app.feature.gallery

import android.content.Context
import android.view.View
import android.view.ViewGroup
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.viewbinding.ViewBinding
import com.bumptech.glide.Glide
//import com.google.android.exoplayer2.ExoPlayer
//import com.google.android.exoplayer2.MediaItem
//import com.google.android.exoplayer2.source.ProgressiveMediaSource
//import com.google.android.exoplayer2.trackselection.DefaultTrackSelector
//import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory
//import com.google.android.exoplayer2.util.Util
import com.google.android.mms.ContentType
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.sms.text.chat.messanger.app.common.base.QkRealmAdapter
import messages.sms.text.chat.messanger.app.common.base.QkViewHolder
import messages.sms.text.chat.messanger.app.databinding.GalleryImagePageBinding
import messages.sms.text.chat.messanger.app.databinding.GalleryInvalidPageBinding
import messages.sms.text.chat.messanger.app.databinding.GalleryVideoPageBinding
import messages.sms.text.chat.messanger.app.extensions.isImage
import messages.sms.text.chat.messanger.app.extensions.isVideo
import messages.sms.text.chat.messanger.app.model.MmsPart
import java.util.Collections
import java.util.WeakHashMap
import javax.inject.Inject

class GalleryPagerAdapter @Inject constructor(
    private val context: Context,
) : QkRealmAdapter<MmsPart, ViewBinding>() {

    companion object {
        private const val VIEW_TYPE_INVALID = 0
        private const val VIEW_TYPE_IMAGE = 1
        private const val VIEW_TYPE_VIDEO = 2
    }

    val clicks: Subject<View> = PublishSubject.create()

    private val contentResolver = context.contentResolver
    private val exoPlayers = Collections.newSetFromMap(WeakHashMap<ExoPlayer?, Boolean>())

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QkViewHolder<ViewBinding> {
        val holder: QkViewHolder<ViewBinding> = when (viewType) {
            VIEW_TYPE_IMAGE -> QkViewHolder(parent, GalleryImagePageBinding::inflate)
            VIEW_TYPE_VIDEO -> QkViewHolder(parent, GalleryVideoPageBinding::inflate)
            else -> QkViewHolder(parent, GalleryInvalidPageBinding::inflate)
        }

        return holder.apply {
            if (binding is GalleryImagePageBinding) {
                // When calling the public setter, it doesn't allow the midscale to be the same as the
                // maxscale or the minscale. We don't want 3 levels and we don't want to modify the library
                // so let's celebrate the invention of reflection!
                binding.image.attacher.run {
                    javaClass.getDeclaredField("mMinScale").run {
                        isAccessible = true
                        setFloat(binding.image.attacher, 1f)
                    }
                    javaClass.getDeclaredField("mMidScale").run {
                        isAccessible = true
                        setFloat(binding.image.attacher, 1f)
                    }
                    javaClass.getDeclaredField("mMaxScale").run {
                        isAccessible = true
                        setFloat(binding.image.attacher, 3f)
                    }
                }
            }

            binding.root.setOnClickListener(clicks::onNext)
        }
    }

    override fun onBindViewHolder(holder: QkViewHolder<ViewBinding>, position: Int) {
        val part = getItem(position) ?: return
        when {
            getItemViewType(position) == VIEW_TYPE_IMAGE && holder.binding is GalleryImagePageBinding -> {
                // We need to explicitly request a gif from glide for animations to work
                when (part.getUri().let(contentResolver::getType)) {
                    ContentType.IMAGE_GIF -> Glide.with(context)
                        .asGif()
                        .load(part.getUri())
                        .into(holder.binding.image)

                    else -> Glide.with(context)
                        .asBitmap()
                        .load(part.getUri())
                        .into(holder.binding.image)
                }
            }

            getItemViewType(position) == VIEW_TYPE_VIDEO && holder.binding is GalleryVideoPageBinding -> {
//                val binding = GalleryVideoPageBinding.bind(holder.containerView)
                val exoPlayer = ExoPlayer.Builder(context).build()
                holder.binding.video.player = exoPlayer
                exoPlayers.add(exoPlayer)

                val mediaItem = MediaItem.fromUri(part.getUri())
                exoPlayer.setMediaItem(mediaItem)
                exoPlayer.prepare()

//                val trackSelector = DefaultTrackSelector(context)
//                val exoPlayer = ExoPlayer.Builder(context).setTrackSelector(trackSelector).build()
//                holder.binding.video.player = exoPlayer
//                exoPlayers.add(exoPlayer)
//
//                val dataSourceFactory = DefaultDataSourceFactory(
//                    context,
//                    Util.getUserAgent(context, "Message")
//                )
//                val videoSource = ProgressiveMediaSource.Factory(dataSourceFactory)
//                    .createMediaSource(MediaItem.fromUri(part.getUri()))
//                exoPlayer.setMediaSource(videoSource)
//                exoPlayer.prepare()
            }
        }
    }

    override fun getItemViewType(position: Int): Int {
        val part = getItem(position)
        return when {
            part?.isImage() == true -> VIEW_TYPE_IMAGE
            part?.isVideo() == true -> VIEW_TYPE_VIDEO
            else -> VIEW_TYPE_INVALID
        }
    }

    fun destroy() {
        exoPlayers.forEach { exoPlayer -> exoPlayer?.release() }
    }

}