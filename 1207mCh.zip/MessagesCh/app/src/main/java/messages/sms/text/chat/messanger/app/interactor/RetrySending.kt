package messages.sms.text.chat.messanger.app.interactor

import io.reactivex.Flowable
import messages.sms.text.chat.messanger.app.extensions.mapNotNull
import messages.sms.text.chat.messanger.app.model.Message
import messages.sms.text.chat.messanger.app.repository.MessageRepository
import javax.inject.Inject

class RetrySending @Inject constructor(private val messageRepo: MessageRepository) :
    Interactor<Long>() {

    override fun buildObservable(params: Long): Flowable<Message> {
        return Flowable.just(params)
            .doOnNext(messageRepo::markSending)
            .mapNotNull(messageRepo::getMessage)
            .doOnNext { message ->
                when (message.isSms()) {
                    true -> messageRepo.sendSms(message)
                    false -> messageRepo.resendMms(message)
                }
            }
    }

}
