package messages.sms.text.chat.messanger.app.repository

import android.content.ContentResolver
import android.content.ContentUris
import android.net.Uri
import android.provider.Telephony
import com.f2prateek.rx.preferences2.RxSharedPreferences
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.Subject
import io.realm.Realm
import io.realm.Sort
import messages.sms.text.chat.messanger.app.extensions.insertOrUpdate
import messages.sms.text.chat.messanger.app.extensions.map
import messages.sms.text.chat.messanger.app.manager.KeyManager
import messages.sms.text.chat.messanger.app.mapper.CursorToContact
import messages.sms.text.chat.messanger.app.mapper.CursorToConversation
import messages.sms.text.chat.messanger.app.mapper.CursorToMessage
import messages.sms.text.chat.messanger.app.mapper.CursorToRecipient
import messages.sms.text.chat.messanger.app.model.Contact
import messages.sms.text.chat.messanger.app.model.Conversation
import messages.sms.text.chat.messanger.app.model.Message
import messages.sms.text.chat.messanger.app.model.MessageEvent
import messages.sms.text.chat.messanger.app.model.MmsPart
import messages.sms.text.chat.messanger.app.model.PhoneNumber
import messages.sms.text.chat.messanger.app.model.Recipient
import messages.sms.text.chat.messanger.app.model.SyncLog
import messages.sms.text.chat.messanger.app.model.TEMP_REFRESH_MESSAGE
import messages.sms.text.chat.messanger.app.util.PhoneNumberUtils
import messages.sms.text.chat.messanger.app.util.tryOrNull
import org.greenrobot.eventbus.EventBus
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SyncRepositoryImpl @Inject constructor(
    private val contentResolver: ContentResolver,
    private val conversationRepo: ConversationRepository,
    private val cursorToConversation: CursorToConversation,
    private val cursorToMessage: CursorToMessage,
    private val cursorToRecipient: CursorToRecipient,
    private val cursorToContact: CursorToContact,
    private val keys: KeyManager,
    private val phoneNumberUtils: PhoneNumberUtils,
    private val rxPrefs: RxSharedPreferences,
) : SyncRepository {

    override val syncProgress: Subject<SyncRepository.SyncProgress> =
        BehaviorSubject.createDefault(SyncRepository.SyncProgress.Idle)

    override fun syncMessages() {

        if (syncProgress.blockingFirst() is SyncRepository.SyncProgress.Running) return
        syncProgress.onNext(SyncRepository.SyncProgress.Running(0, 0, true))




        keys.reset()

        val messageCursor = cursorToMessage.getMessagesCursor()
        val conversationCursor = cursorToConversation.getConversationsCursor()
        val recipientCursor = cursorToRecipient.getRecipientCursor()

        val max = (messageCursor?.count ?: 0) +
                (conversationCursor?.count ?: 0) +
                (recipientCursor?.count ?: 0)


        var progress = 0

        //Temp--------------------------------------------------------------------------

        val realmTemp = Realm.getDefaultInstance()
        realmTemp.beginTransaction()

        val persistedDataTemp = realmTemp.copyFromRealm(
            realmTemp.where(Conversation::class.java)
                .beginGroup()
                .equalTo("archived", true)
                .or()
//                .equalTo("isRecycle", true)
//                .or()
                .equalTo("blocked", true)
                .or()
                .equalTo("pinned", true)
                .or()
                .isNotEmpty("name")
                .or()
                .isNotNull("blockingClient")
                .or()
                .isNotEmpty("blockReason")
                .endGroup()
                .findAll()
        )
            .associateBy { conversation -> conversation.id }
            .toMutableMap()

        realmTemp.delete(Contact::class.java)
        realmTemp.delete(Conversation::class.java)
        realmTemp.delete(Message::class.java)
        realmTemp.delete(MmsPart::class.java)
        realmTemp.delete(Recipient::class.java)

        val recipientCursorTemp = cursorToRecipient.getRecipientCursor()
        val messageCursorTemp = cursorToMessage.getMessagesCursor()
        val conversationCursorTemp = cursorToConversation.getConversationsCursor()
        messageCursorTemp?.use {
            val messageColumns = CursorToMessage.MessageColumns(messageCursorTemp)
            val messages = mutableListOf<Message>()

            val maxx = 200

            while (messageCursorTemp.moveToNext() && messages.size < maxx) {


                val message = cursorToMessage.map(Pair(messageCursorTemp, messageColumns))
                messages.add(message)
            }
            realmTemp.insertOrUpdate(messages)
        }

        conversationCursorTemp?.use {
            val conversations = conversationCursorTemp.map { cursor ->


                cursorToConversation.map(cursor).apply {
                    persistedDataTemp[id]?.let { persistedConversation ->
                        archived = persistedConversation.archived
                        blocked = persistedConversation.blocked
                        pinned = persistedConversation.pinned
                        name = persistedConversation.name
                        blockingClient = persistedConversation.blockingClient
                        blockReason = persistedConversation.blockReason
                    }

                }
            }

            realmTemp.where(Message::class.java)
                .sort("date", Sort.DESCENDING)
                .distinct("threadId")
                .findAll()
                .forEach { message ->
                    val conversation =
                        conversations.find { conversation -> conversation.id == message.threadId }
                    conversation?.lastMessage = message
                }

            realmTemp.insertOrUpdate(conversations)

        }

        // Sync recipients
        recipientCursorTemp?.use {
            val contacts = realmTemp.copyToRealmOrUpdate(getContacts())
            val recipients = recipientCursorTemp.map { cursor ->
                cursorToRecipient.map(cursor).apply {
                    contact = contacts.firstOrNull { contact ->
                        contact.numbers.any { phoneNumberUtils.compare(address, it.address) }
                    }
                }
            }
            realmTemp.insertOrUpdate(recipients)
        }

        realmTemp.insert(SyncLog())
        realmTemp.commitTransaction()
        realmTemp.close()

        EventBus.getDefault().post(MessageEvent(TEMP_REFRESH_MESSAGE))


        //    syncProgress.onNext(SyncRepository.SyncProgress.Idle)

//Temp--------------------------------------------------------------------------

        syncProgress.onNext(SyncRepository.SyncProgress.Running(0, 0, true))

        val realm = Realm.getDefaultInstance()
        realm.beginTransaction()
        val persistedData = realm.copyFromRealm(
            realm.where(Conversation::class.java)
                .beginGroup()
                .equalTo("archived", true)
                .or()
//                .equalTo("isRecycle", true)
//                .or()
                .equalTo("blocked", true)
                .or()
                .equalTo("pinned", true)
                .or()
                .isNotEmpty("name")
                .or()
                .isNotNull("blockingClient")
                .or()
                .isNotEmpty("blockReason")
                .endGroup()
                .findAll()
        )
            .associateBy { conversation -> conversation.id }
            .toMutableMap()

        realm.delete(Contact::class.java)
        realm.delete(Conversation::class.java)
        realm.delete(Message::class.java)
        realm.delete(MmsPart::class.java)
        realm.delete(Recipient::class.java)

        progress = 0

        // Sync messages
        messageCursor?.use {
            // val messages : List<Message> = mutableListOf()
            val messageColumns = CursorToMessage.MessageColumns(messageCursor)

            val messages = messageCursor.map { cursor ->
                progress++
                syncProgress.onNext(SyncRepository.SyncProgress.Running(max, progress, false))
                cursorToMessage.map(Pair(cursor, messageColumns))
            }
            realm.insertOrUpdate(messages)
        }

        // Migrate blocked conversations from 2.7.3
        val oldBlockedSenders = rxPrefs.getStringSet("pref_key_blocked_senders")
        oldBlockedSenders.get()
            .map { threadIdString -> threadIdString.toLong() }
            .filter { threadId -> !persistedData.contains(threadId) }
            .forEach { threadId ->
                persistedData[threadId] = Conversation(id = threadId, blocked = true)
            }

        // Sync conversations
        conversationCursor?.use {
            val conversations = conversationCursor.map { cursor ->
                progress++

                syncProgress.onNext(SyncRepository.SyncProgress.Running(max, progress, false))
                cursorToConversation.map(cursor).apply {
                    persistedData[id]?.let { persistedConversation ->
                        archived = persistedConversation.archived
                        blocked = persistedConversation.blocked
                        pinned = persistedConversation.pinned
                        name = persistedConversation.name
                        blockingClient = persistedConversation.blockingClient
                        blockReason = persistedConversation.blockReason
                    }

                }
            }

            realm.where(Message::class.java)
                .sort("date", Sort.DESCENDING)
                .distinct("threadId")
                .findAll()
                .forEach { message ->
                    val conversation =
                        conversations.find { conversation -> conversation.id == message.threadId }
                    conversation?.lastMessage = message
                }

            realm.insertOrUpdate(conversations)

        }

        // Sync recipients
        recipientCursor?.use {
            val contacts = realm.copyToRealmOrUpdate(getContacts())
            val recipients = recipientCursor.map { cursor ->
                progress++
                syncProgress.onNext(SyncRepository.SyncProgress.Running(max, progress, false))
                cursorToRecipient.map(cursor).apply {
                    contact = contacts.firstOrNull { contact ->
                        contact.numbers.any { phoneNumberUtils.compare(address, it.address) }
                    }
                }
            }
            realm.insertOrUpdate(recipients)
        }

        syncProgress.onNext(SyncRepository.SyncProgress.Running(0, 0, true))


        realm.insert(SyncLog())
        realm.commitTransaction()
        realm.close()

        // Only delete this after the sync has successfully completed
        oldBlockedSenders.delete()

        syncProgress.onNext(SyncRepository.SyncProgress.Idle)
    }


    override fun syncMessage(uri: Uri): Message? {

        // If we don't have a valid type, return null
        val type = when {
            uri.toString().contains("mms") -> "mms"
            uri.toString().contains("sms") -> "sms"
            else -> return null
        }

        // If we don't have a valid id, return null
        val id = tryOrNull(false) { ContentUris.parseId(uri) } ?: return null

        // Check if the message already exists, so we can reuse the id
        val existingId = Realm.getDefaultInstance().use { realm ->
            realm.refresh()
            realm.where(Message::class.java)
                .equalTo("type", type)
                .equalTo("contentId", id)
                .findFirst()
                ?.id
        }

        // The uri might be something like content://mms/inbox/id
        // The box might change though, so we should just use the mms/id uri
        val stableUri = when (type) {
            "mms" -> ContentUris.withAppendedId(Telephony.Mms.CONTENT_URI, id)
            else -> ContentUris.withAppendedId(Telephony.Sms.CONTENT_URI, id)
        }

        return contentResolver.query(stableUri, null, null, null, null)?.use { cursor ->

            // If there are no rows, return null. Otherwise, we've moved to the first row
            if (!cursor.moveToFirst()) return null

            val columnsMap = CursorToMessage.MessageColumns(cursor)
            cursorToMessage.map(Pair(cursor, columnsMap)).apply {
                existingId?.let { this.id = it }

                conversationRepo.getOrCreateConversation(threadId)
                insertOrUpdate()
            }
        }
    }

    override fun syncContacts() {
        // Load all the contacts
        var contacts = getContacts()

        Realm.getDefaultInstance()?.use { realm ->
            val recipients = realm.where(Recipient::class.java).findAll()

            realm.executeTransaction {
                realm.delete(Contact::class.java)

                contacts = realm.copyToRealmOrUpdate(contacts)

                // Update all the recipients with the new contacts
                recipients.forEach { recipient ->
                    recipient.contact = contacts.find { contact ->
                        contact.numbers.any {
                            phoneNumberUtils.compare(
                                recipient.address,
                                it.address
                            )
                        }
                    }
                }

                realm.insertOrUpdate(recipients)
            }

        }
    }

    private fun getContacts(): List<Contact> {
        val defaultNumberIds = Realm.getDefaultInstance().use { realm ->
            realm.where(PhoneNumber::class.java)
                .equalTo("isDefault", true)
                .findAll()
                .map { number -> number.id }
        }

        return cursorToContact.getContactsCursor()
            ?.map { cursor -> cursorToContact.map(cursor) }
            ?.groupBy { contact -> contact.lookupKey }
            ?.map { contacts ->
                // Sometimes, contacts providers on the phone will create duplicate phone number entries. This
                // commonly happens with Whatsapp. Let's try to detect these duplicate entries and filter them out
                val uniqueNumbers = mutableListOf<PhoneNumber>()
                contacts.value
                    .flatMap { it.numbers }
                    .forEach { number ->
                        number.isDefault = defaultNumberIds.any { id -> id == number.id }
                        val duplicate = uniqueNumbers.find { other ->
                            phoneNumberUtils.compare(number.address, other.address)
                        }

                        if (duplicate == null) {
                            uniqueNumbers += number
                        } else if (!duplicate.isDefault && number.isDefault) {
                            duplicate.isDefault = true
                        }
                    }

                contacts.value.first().apply {
                    numbers.clear()
                    numbers.addAll(uniqueNumbers)
                }
            } ?: listOf()
    }


}
