package messages.sms.text.chat.messanger.app.interactor

import android.net.Uri
import io.reactivex.Flowable
import messages.sms.text.chat.messanger.app.extensions.mapNotNull
import messages.sms.text.chat.messanger.app.repository.ConversationRepository
import messages.sms.text.chat.messanger.app.repository.SyncRepository
import javax.inject.Inject

class SyncMessage @Inject constructor(
    private val conversationRepo: ConversationRepository,
    private val syncManager: SyncRepository,
    private val updateBadge: UpdateBadge,
) : Interactor<Uri>() {

    override fun buildObservable(params: Uri): Flowable<*> {
        return Flowable.just(params)
            .mapNotNull { uri -> syncManager.syncMessage(uri) }
            .doOnNext { message -> conversationRepo.updateConversations(message.threadId) }
            .flatMap { updateBadge.buildObservable(Unit) } // Update the badge
    }

}