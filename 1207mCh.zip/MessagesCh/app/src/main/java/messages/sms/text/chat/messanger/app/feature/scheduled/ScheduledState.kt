package messages.sms.text.chat.messanger.app.feature.scheduled

import io.realm.RealmResults
import messages.sms.text.chat.messanger.app.model.ScheduledMessage

data class ScheduledState(
    val scheduledMessages: RealmResults<ScheduledMessage>? = null,
    val upgraded: Boolean = true,
)
