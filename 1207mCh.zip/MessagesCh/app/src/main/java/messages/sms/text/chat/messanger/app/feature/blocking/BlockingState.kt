package messages.sms.text.chat.messanger.app.feature.blocking

data class BlockingState(
    val blockingManager: String = "",
    val dropEnabled: Boolean = false,
)
