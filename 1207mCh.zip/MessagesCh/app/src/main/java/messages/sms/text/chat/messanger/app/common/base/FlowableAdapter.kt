package messages.sms.text.chat.messanger.app.common.base

import androidx.annotation.CallSuper
import androidx.recyclerview.widget.RecyclerView
import androidx.viewbinding.ViewBinding
import io.reactivex.Flowable
import io.reactivex.disposables.Disposable

/**
 * Base RecyclerView.Adapter that provides some convenience when creating a new Adapter, such as
 * data list handing and item animations
 */
abstract class FlowableAdapter<T, Binding : ViewBinding> : QkAdapter<T, Binding>() {

    var flowable: Flowable<List<T>>? = null
        set(value) {
            if (field === value) return

            field = value

            // Stop listening for updates on the old flowable
            dispose()

            // If we're attached to any RecyclerViews, then subscribe to updates
            if (recyclerViews.isNotEmpty()) {
                subscribe()
            }
        }

    private val recyclerViews = ArrayList<RecyclerView>()
    private var disposable: Disposable? = null

    @CallSuper
    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {

        // If this is the first RecyclerView to be attached, then start listening to updates
        if (recyclerViews.isEmpty() || disposable == null) {
            subscribe()
        }

        recyclerViews.add(recyclerView)
    }

    @CallSuper
    override fun onDetachedFromRecyclerView(recyclerView: RecyclerView) {
        recyclerViews.remove(recyclerView)

        // If no more RecyclerViews are attached, stop listening to updates
        if (recyclerViews.isEmpty()) {
            dispose()
        }
    }

    private fun subscribe() {
        disposable = flowable?.subscribe {
            data = it
        }
    }

    private fun dispose() {
        disposable?.dispose()
    }

}