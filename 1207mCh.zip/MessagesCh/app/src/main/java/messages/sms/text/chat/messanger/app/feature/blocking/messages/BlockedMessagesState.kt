package messages.sms.text.chat.messanger.app.feature.blocking.messages

import io.realm.RealmResults
import messages.sms.text.chat.messanger.app.model.Conversation

data class BlockedMessagesState(
    val data: RealmResults<Conversation>? = null,
    val selected: Int = 0,
)
