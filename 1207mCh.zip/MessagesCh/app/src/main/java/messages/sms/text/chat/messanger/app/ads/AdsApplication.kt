package  messages.sms.text.chat.messanger.app.ads

import androidx.multidex.MultiDexApplication
import com.google.android.gms.ads.MobileAds
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

var isAdsNotShowOnResume = false


open class AdsApplication : MultiDexApplication() {

    override fun onCreate() {
        super.onCreate()
        val backgroundScope = CoroutineScope(Dispatchers.IO)
        backgroundScope.launch {
            MobileAds.initialize(this@AdsApplication) {}
        }

//        AppLovinSdk.getInstance( this ).setMediationProvider( "max" )
//        AppLovinSdk.getInstance( this ).initializeSdk({ configuration: AppLovinSdkConfiguration ->
//            // AppLovin SDK is initialized, start loading ads
//            registerActivityLifecycleCallbacks(AdjustLifecycleCallbacks())
//        })


    }


}