package  messages.sms.text.chat.messanger.app.ads

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import androidx.core.content.res.ResourcesCompat
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.VideoOptions
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.commons.extensions.baseConfig
import messages.sms.text.chat.messanger.app.databinding.LayoutChatNativeBinding
import messages.sms.text.chat.messanger.app.databinding.LayoutLanguageBigNativeBinding
import messages.sms.text.chat.messanger.app.databinding.LayoutListItemNativeBinding
import messages.sms.text.chat.messanger.app.databinding.LayoutManageAppNativeBinding

object AdmobNative {

    var nativeAdManageApps: NativeAd? = null
    fun preLoad(
        mContext: Context,
        listener: (isLoaded: Boolean, NativeAd?) -> Unit?,
        adId: String,
    ) {
        if (!mContext.isInternetConnected() || !AdsPreferences(mContext).adsEnable || AdsPreferences(
                mContext
            ).isPro
        ) {
            listener.invoke(false, null)
            return
        }
        val videoOptionBuilder = VideoOptions.Builder()
            .setClickToExpandRequested(true)
            .setStartMuted(true)

        val nativeAdOptionsBuilder = NativeAdOptions.Builder()
            .setVideoOptions(videoOptionBuilder.build())

        val adLoader = AdLoader.Builder(mContext, adId)
            .forNativeAd { nativeAd: NativeAd ->
                nativeAdManageApps = nativeAd
                listener.invoke(true, nativeAd)
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    nativeAdManageApps = null
                    listener.invoke(false, null)
                }

                override fun onAdClicked() {
                    super.onAdClicked()
                }
            })
            .withNativeAdOptions(nativeAdOptionsBuilder.build())
            .build()

        adLoader.loadAd(AdRequest.Builder().build())
    }

    fun preLoadChat(
        mContext: Context,
        listener: (isLoaded: Boolean, NativeAd?) -> Unit?,
        adId: String,
    ) {
        if (!mContext.isInternetConnected() || !AdsPreferences(mContext).adsEnable || AdsPreferences(
                mContext
            ).isPro
        ) {
            listener.invoke(false, null)
            return
        }
        val videoOptionBuilder = VideoOptions.Builder()
            .setClickToExpandRequested(true)
            .setStartMuted(true)

        val nativeAdOptionsBuilder = NativeAdOptions.Builder()
            .setVideoOptions(videoOptionBuilder.build())

        val adLoader = AdLoader.Builder(mContext, adId)
            .forNativeAd { nativeAd: NativeAd ->
                nativeAdChat = nativeAd
                listener.invoke(true, nativeAd)

            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    nativeAdChat = null
                    listener.invoke(false, null)
                }

                override fun onAdClicked() {
                    super.onAdClicked()
                }
            })
            .withNativeAdOptions(nativeAdOptionsBuilder.build())
            .build()

        adLoader.loadAd(AdRequest.Builder().build())
    }

    fun populateManageAppNativeAd(
        context: Context,
        view: View,
        nativeAd: NativeAd,
    ) {

        val applyBackground = ResourcesCompat.getDrawable(
            context.resources,
            R.drawable.ads_big_gradiant_rounded,
            null
        ) as LayerDrawable
//        val strokeDrawable =
//            applyBackground.findDrawableByLayerId(R.id.button_background_ads) as GradientDrawable
//        strokeDrawable.setStroke(2, context.baseConfig.backgroundColor)



        LayoutManageAppNativeBinding.bind(view).apply {
            adHeadline.text = nativeAd.headline
            adBody.text = nativeAd.body
            adCallToAction.text = nativeAd.callToAction

            if (nativeAd.icon != null) {
                ivAdAppIcon.setImageDrawable(nativeAd.icon!!.drawable)
                nativeAdView.iconView = ivAdAppIcon
            } else {
                cvAppIcon.layoutParams.width = 0
            }
            adMedia.mediaContent = nativeAd.mediaContent
            adMedia.setImageScaleType(ImageView.ScaleType.FIT_CENTER)
            nativeAdView.headlineView = adHeadline
            nativeAdView.callToActionView = adCallToAction
            nativeAdView.mediaView = adMedia
            nativeAdView.setNativeAd(nativeAd)

            cvRoot.background = applyBackground

            shimmerView.beGone()
            nativeAdView.beVisible()
        }
    }


    fun populateLanguageNativeAd(
        view: View,
        nativeAd: NativeAd,
    ) {
        LayoutLanguageBigNativeBinding.bind(view).apply {
            adHeadline.text = nativeAd.headline
            adBody.text = nativeAd.body
            adCallToAction.text = nativeAd.callToAction

            if (nativeAd.icon != null) {
                ivAdAppIcon.setImageDrawable(nativeAd.icon!!.drawable)
                nativeAdView.iconView = ivAdAppIcon
            } else {
                cvAppIcon.layoutParams.width = 0
            }
            adMedia.mediaContent = nativeAd.mediaContent
            adMedia.setImageScaleType(ImageView.ScaleType.FIT_CENTER)
            nativeAdView.headlineView = adHeadline
            nativeAdView.bodyView = adBody
            nativeAdView.callToActionView = adCallToAction
            nativeAdView.mediaView = adMedia
            nativeAdView.setNativeAd(nativeAd)
            shimmerView.beGone()
            nativeAdView.beVisible()
        }
    }

    var nativeAdChat: NativeAd? = null

    fun populateChatNativeAd(
        mContext: Context,
        view: View,
    ) {
        if (nativeAdChat == null) return

        val nativeAd = nativeAdChat
        val applyBackground = ResourcesCompat.getDrawable(
            mContext.resources,
            R.drawable.ads_item_gradiant_rounded,
            null
        ) as LayerDrawable
        val strokeDrawable =
            applyBackground.findDrawableByLayerId(R.id.button_background_ads) as GradientDrawable
        strokeDrawable.setStroke(2, mContext.baseConfig.primaryColor)

        LayoutChatNativeBinding.bind(view).apply {
            adHeadline.text = nativeAd?.headline
            adCallToAction.text = nativeAd?.callToAction
            adCallToAction.setTextColor(mContext.baseConfig.primaryColor)

            if (nativeAd?.icon != null) {
                ivAdAppIcon.setImageDrawable(nativeAd?.icon!!.drawable)
                nativeAdView.iconView = ivAdAppIcon
            } else {
                ivAdAppIcon.layoutParams.height = 0
            }
            nativeAdView.headlineView = adHeadline
            nativeAdView.callToActionView = adCallToAction
            nativeAdView.setNativeAd(nativeAd!!)
            nativeAdView.beVisible()
        }
    }

    fun populateExitNativeAd(
        mContext: Context,
        view: View,
        nativeAd: NativeAd,
    ) {

        LayoutLanguageBigNativeBinding.bind(view).apply {
//            adCallToAction.setTextColor(Color.WHITE)
            adHeadline.text = nativeAd.headline
            adBody.text = nativeAd.body
            adCallToAction.text = nativeAd.callToAction

            if (nativeAd.icon != null) {
                ivAdAppIcon.setImageDrawable(nativeAd.icon!!.drawable)
                nativeAdView.iconView = ivAdAppIcon
            } else {
                cvAppIcon.layoutParams.width = 0
            }
            adMedia.mediaContent = nativeAd.mediaContent
            adMedia.setImageScaleType(ImageView.ScaleType.FIT_CENTER)
            nativeAdView.headlineView = adHeadline
            nativeAdView.bodyView = adBody
            nativeAdView.callToActionView = adCallToAction
            nativeAdView.mediaView = adMedia
            nativeAdView.setNativeAd(nativeAd)
            shimmerView.beGone()
            nativeAdView.beVisible()
        }
    }

    fun populateSmallNativeAd(
        mContext: Context,
        view: View,
        nativeAd: NativeAd,
    ) {

        try {
            val applyBackground = ResourcesCompat.getDrawable(
                mContext.resources,
                R.drawable.ads_item_gradiant_rounded,
                null
            ) as LayerDrawable
            val strokeDrawable =
                applyBackground.findDrawableByLayerId(R.id.button_background_ads) as GradientDrawable
            strokeDrawable.setStroke(2, mContext.baseConfig.primaryColor)


            LayoutListItemNativeBinding.bind(view).apply {
                //            if(adCallToAction!=null) adCallToAction.setTextColor(Color.WHITE)
                if (adHeadline != null) adHeadline.text = nativeAd.headline
                if (adBody != null) adBody.text = nativeAd.body
                if (adCallToAction != null) {
                    adCallToAction.text = nativeAd.callToAction
                    adCallToAction.setTextColor(mContext.baseConfig.primaryColor)
                }
                adCallToAction.background = applyBackground

                if (ivAdAppIcon != null) {
                    if (nativeAd.icon != null) {
                        ivAdAppIcon.setImageDrawable(nativeAd.icon!!.drawable)
                        nativeAdView.iconView = ivAdAppIcon
                    } else {
                        ivAdAppIcon.layoutParams.width = 0
                    }
                }
                if (nativeAdView != null) {
                    nativeAdView.headlineView = adHeadline
                    nativeAdView.bodyView = adBody
                    nativeAdView.callToActionView = adCallToAction
                    nativeAdView.setNativeAd(nativeAd)
                    nativeAdView.setBackgroundColor(view.context.resources.getColor(R.color.smallnativebg))
                    shimmerView.beGone()
                    nativeAdView.beVisible()
                }
            }
        } catch (e: Exception) {
        }
    }
}