package messages.sms.text.chat.messanger.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import dagger.android.AndroidInjection
import messages.sms.text.chat.messanger.app.interactor.UpdateScheduledMessageAlarms
import javax.inject.Inject

class BootReceiver : BroadcastReceiver() {

    @Inject
    lateinit var updateScheduledMessageAlarms: UpdateScheduledMessageAlarms

    override fun onReceive(context: Context, intent: Intent?) {
        AndroidInjection.inject(this, context)

        val result = goAsync()
        updateScheduledMessageAlarms.execute(Unit) { result.finish() }
    }

}