package messages.sms.text.chat.messanger.app.common.base

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.view.View
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.Subject
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.ads.AdsApplication
import messages.sms.text.chat.messanger.app.common.util.Colors
import messages.sms.text.chat.messanger.app.common.util.extensions.resolveThemeBoolean
import messages.sms.text.chat.messanger.app.common.util.extensions.resolveThemeColor
import messages.sms.text.chat.messanger.app.commons.extensions.addBit
import messages.sms.text.chat.messanger.app.commons.extensions.baseConfig
import messages.sms.text.chat.messanger.app.commons.extensions.getContrastColor
import messages.sms.text.chat.messanger.app.commons.extensions.getProperBackgroundColor
import messages.sms.text.chat.messanger.app.commons.extensions.removeBit
import messages.sms.text.chat.messanger.app.commons.helpers.DARK_GREY
import messages.sms.text.chat.messanger.app.extensions.Optional
import messages.sms.text.chat.messanger.app.extensions.asObservable
import messages.sms.text.chat.messanger.app.extensions.mapNotNull
import messages.sms.text.chat.messanger.app.repository.ConversationRepository
import messages.sms.text.chat.messanger.app.repository.MessageRepository
import messages.sms.text.chat.messanger.app.util.PhoneNumberUtils
import messages.sms.text.chat.messanger.app.util.Preferences
import java.util.concurrent.TimeUnit
import javax.inject.Inject

/**
 * Base activity that automatically applies any necessary theme theme settings and colors
 *
 * In most cases, this should be used instead of the base QkActivity, except for when
 * an activity does not depend on the theme
 */
abstract class QkThemedActivity : QkActivity() {

    @Inject
    lateinit var colors: Colors

    @Inject
    lateinit var conversationRepo: ConversationRepository

    @Inject
    lateinit var messageRepo: MessageRepository

    @Inject
    lateinit var phoneNumberUtils: PhoneNumberUtils

    @Inject
    lateinit var prefs: Preferences

    lateinit var adsApplication: AdsApplication
    /**
     * In case the activity should be themed for a specific conversation, the selected conversation
     * can be changed by pushing the threadId to this subject
     */
    val threadId: Subject<Long> = BehaviorSubject.createDefault(0)

    /**
     * Switch the theme if the threadId changes
     * Set it based on the latest message in the conversation
     */
    val theme: Observable<Colors.Theme> = threadId
        .distinctUntilChanged()
        .switchMap { threadId ->
            val conversation = conversationRepo.getConversation(threadId)
            when {
                conversation == null -> Observable.just(Optional(null))

                conversation.recipients.size == 1 -> Observable.just(Optional(conversation.recipients.first()))

                else -> messageRepo.getLastIncomingMessage(conversation.id)
                    .asObservable()
                    .mapNotNull { messages -> messages.firstOrNull() }
                    .distinctUntilChanged { message -> message.address }
                    .mapNotNull { message ->
                        conversation.recipients.find { recipient ->
                            phoneNumberUtils.compare(recipient.address, message.address)
                        }
                    }
                    .map { recipient -> Optional(recipient) }
                    .startWith(Optional(conversation.recipients.firstOrNull()))
                    .distinctUntilChanged()
            }
        }
        .switchMap { colors.themeObservable(it.value) }

    @SuppressLint("InlinedApi")
    override fun onCreate(savedInstanceState: Bundle?) {
//        setTheme(getActivityThemeRes(prefs.black.get()))
        setTheme(R.style.AppTheme)
        super.onCreate(savedInstanceState)

        adsApplication = applicationContext as AdsApplication
        // When certain preferences change, we need to recreate the activity
        val triggers =
            listOf(prefs.nightMode, prefs.night, prefs.black, prefs.textSize, prefs.systemFont)
        Observable.merge(triggers.map { it.asObservable().skip(1) })
            .debounce(400, TimeUnit.MILLISECONDS)
            .observeOn(AndroidSchedulers.mainThread())
            .autoDispose(scope())
            .subscribe { recreate() }

        // We can only set light nav bar on API 27 in attrs, but we can do it in API 26 here
        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.O) {
            val night = !resolveThemeBoolean(R.attr.isLightTheme)
            window.decorView.systemUiVisibility = if (night) 0 else
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }

        // Some devices don't let you modify android.R.attr.navigationBarColor
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            window.navigationBarColor = resolveThemeColor(android.R.attr.windowBackground)
        }

        window.statusBarColor = baseConfig.statusBarColor

        // Set the color for the recent apps title
//        val toolbarColor = resolveThemeColor(R.attr.colorPrimary)
//        val icon = BitmapFactory.decodeResource(resources, R.mipmap.ic_launcher)
//        val taskDesc = ActivityManager.TaskDescription(getString(R.string.app_name), icon, toolbarColor)
//        setTaskDescription(taskDesc)

    }

    fun updateActionbarColor(color: Int = getProperBackgroundColor()) { //getProperStatusBarColor()
        //supportActionBar?.setBackgroundDrawable(ColorDrawable(color))
//        supportActionBar?.elevation = 0F
        //updateActionBarTitle(supportActionBar?.title.toString(), color)
        updateStatusBarColor(color)
//        setTaskDescription(ActivityManager.TaskDescription(null, null, color))
    }

    fun updateStatusBarColor(color: Int) {
        window.statusBarColor = baseConfig.statusBarColor
//        window.statusBarColor = color
        updateStatusbarContents(color)
    }

    fun updateStatusbarContents(color: Int) {
        if (color.getContrastColor() == DARK_GREY) {
            window.decorView.systemUiVisibility =
                window.decorView.systemUiVisibility.addBit(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)
        } else {
            window.decorView.systemUiVisibility =
                window.decorView.systemUiVisibility.removeBit(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)
        }
    }

    var resumeTheme = false
    override fun onPause() {
        super.onPause()
        resumeTheme = true
    }

    override fun onResume() {
        super.onResume()
        if (resumeTheme) {
            resumeTheme = false
            setTheme(R.style.AppTheme)
            try {
                window.statusBarColor = baseConfig.statusBarColor
            } catch (_: Exception) {
            }
        }
        window.statusBarColor = baseConfig.statusBarColor
    }

    override fun onPostCreate(savedInstanceState: Bundle?) {
        super.onPostCreate(savedInstanceState)

        // Set the color for the overflow and navigation icon
        val textSecondary = resolveThemeColor(android.R.attr.textColorSecondary)
        toolbar?.overflowIcon = toolbar?.overflowIcon?.apply { setTint(textSecondary) }

        // Update the colours of the menu items
        /* Observables.combineLatest(menu, theme) { menu, theme ->
             menu.iterator().forEach { menuItem ->
                 val tint = when (menuItem.itemId) {
                     in getColoredMenuItems() -> theme.theme
                     else -> textSecondary

                 }

                 menuItem.icon = menuItem.icon?.apply { setTint(tint) }
             }
         }.autoDispose(scope(Lifecycle.Event.ON_DESTROY)).subscribe()*/
    }

    open fun getColoredMenuItems(): List<Int> {
        return listOf()
    }

    /**
     * This can be overridden in case an activity does not want to use the default themes
     */
//    open fun getActivityThemeRes(black: Boolean) = when {
//        black -> R.style.AppTheme_Black
//        else -> R.style.AppTheme
//    }

}