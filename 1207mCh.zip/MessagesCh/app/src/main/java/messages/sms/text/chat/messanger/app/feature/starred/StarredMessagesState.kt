package messages.sms.text.chat.messanger.app.feature.starred

import io.realm.RealmResults
import messages.sms.text.chat.messanger.app.model.Message

data class StarredMessagesState(
    val data: RealmResults<Message>? = null,
    val selected: Int = 0,
)
