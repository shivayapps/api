package messages.sms.text.chat.messanger.app.feature.blocking.numbers

import android.view.ViewGroup
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.common.base.QkRealmAdapter
import messages.sms.text.chat.messanger.app.common.base.QkViewHolder
import messages.sms.text.chat.messanger.app.databinding.BlockedNumberListItemBinding
import messages.sms.text.chat.messanger.app.model.BlockedNumber

class BlockedNumbersAdapter : QkRealmAdapter<BlockedNumber, BlockedNumberListItemBinding>() {

    val unblockAddress: Subject<Long> = PublishSubject.create()

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): QkViewHolder<BlockedNumberListItemBinding> {
        return QkViewHolder(parent, BlockedNumberListItemBinding::inflate).apply {
            binding.unblock.setOnClickListener {
                val number = getItem(adapterPosition) ?: return@setOnClickListener
                unblockAddress.onNext(number.id)
            }
        }
    }

    override fun onBindViewHolder(
        holder: QkViewHolder<BlockedNumberListItemBinding>,
        position: Int,
    ) {
        val item = getItem(position)!!

        holder.binding.number.text = item.address
        holder.binding.number.setTextColor(holder.binding.number.context.getColor(R.color.black))
    }

}

