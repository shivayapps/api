package messages.sms.text.chat.messanger.app.filter

abstract class Filter<in T> {

    abstract fun filter(item: T, query: CharSequence): Boolean

}