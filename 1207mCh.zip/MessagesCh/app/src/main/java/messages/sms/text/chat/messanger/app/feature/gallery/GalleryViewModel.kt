package messages.sms.text.chat.messanger.app.feature.gallery

import android.content.Context
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import io.reactivex.Flowable
import io.reactivex.rxkotlin.plusAssign
import io.reactivex.rxkotlin.withLatestFrom
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.common.Navigator
import messages.sms.text.chat.messanger.app.common.base.QkViewModel
import messages.sms.text.chat.messanger.app.common.util.extensions.makeToast
import messages.sms.text.chat.messanger.app.extensions.mapNotNull
import messages.sms.text.chat.messanger.app.interactor.SaveImage
import messages.sms.text.chat.messanger.app.manager.PermissionManager
import messages.sms.text.chat.messanger.app.repository.ConversationRepository
import messages.sms.text.chat.messanger.app.repository.MessageRepository
import javax.inject.Inject
import javax.inject.Named

class GalleryViewModel @Inject constructor(
    conversationRepo: ConversationRepository,
    @Named("partId") private val partId: Long,
    private val context: Context,
    private val messageRepo: MessageRepository,
    private val navigator: Navigator,
    private val saveImage: SaveImage,
    private val permissions: PermissionManager,
) : QkViewModel<GalleryView, GalleryState>(GalleryState()) {

    init {
        disposables += Flowable.just(partId)
            .mapNotNull(messageRepo::getMessageForPart)
            .mapNotNull { message -> message.threadId }
            .doOnNext { threadId ->
                newState {
                    copy(
                        parts = messageRepo.getPartsForConversation(
                            threadId
                        )
                    )
                }
            }
            .doOnNext { threadId ->
                newState {
                    copy(title = conversationRepo.getConversation(threadId)?.getTitle())
                }
            }
            .subscribe()
    }

    override fun bindView(view: GalleryView) {
        super.bindView(view)

        // When the screen is touched, toggle the visibility of the navigation UI
        view.screenTouched()
            .withLatestFrom(state) { _, state -> state.navigationVisible }
            .map { navigationVisible -> !navigationVisible }
            .autoDispose(view.scope())
            .subscribe { navigationVisible -> newState { copy(navigationVisible = navigationVisible) } }

        // Save image to device
        view.optionsItemSelected()
            .filter { itemId -> itemId == R.id.save }
            .filter { permissions.hasStorage().also { if (!it) view.requestStoragePermission() } }
            .withLatestFrom(view.pageChanged()) { _, part -> part.id }
            .autoDispose(view.scope())
            .subscribe { partId -> saveImage.execute(partId) { context.makeToast(R.string.gallery_toast_saved) } }

        // Share image externally
        view.optionsItemSelected()
            .filter { itemId -> itemId == R.id.share }
            .filter { permissions.hasStorage().also { if (!it) view.requestStoragePermission() } }
            .withLatestFrom(view.pageChanged()) { _, part -> part.id }
            .autoDispose(view.scope())
            .subscribe { partId -> messageRepo.savePart(partId)?.let(navigator::shareFile) }
    }

}
