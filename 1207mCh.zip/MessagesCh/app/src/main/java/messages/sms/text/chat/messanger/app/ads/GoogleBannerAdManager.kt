package  messages.sms.text.chat.messanger.app.ads

import android.app.Activity
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.view.ViewGroup
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError


object GoogleBannerAdManager {
    private val TAG = "BannerAdManager"


    private var homeBannerAd: AdView? = null
    private var ishomeBannerLoading = false
    private var ishomeBannerLoaded = false
    fun showHomeGoogleBanner(activity: Activity, parentView: ViewGroup) {
//        homeBannerAd = null
//        ishomeBannerLoading = false
//        ishomeBannerLoaded = false
//        if (!activity.isInternetConnected() || !AdsPreferences(activity).adsEnable || AdsPreferences(
//                activity
//            ).isPro
//        ) {
//            handleBannerVisibility(activity, parentView, null)
//            return
//        }
//
//        if (homeBannerAd != null) {
//            handleBannerVisibility(activity, parentView, homeBannerAd!!)
//        } else {
//            if (ishomeBannerLoading) return
//            ishomeBannerLoading = true
//            homeBannerAd = AdView(activity)
//            homeBannerAd!!.apply {
//                setAdSize(getAdSize(activity))
//                adUnitId = activity.getAppHomeBanner()
//                adListener = object : AdListener() {
//                    override fun onAdFailedToLoad(adError: LoadAdError) {
//                        ishomeBannerLoading = false
//                        failedToLoad(activity, adError)
//                        homeBannerAd = null
//                        handleBannerVisibility(activity, parentView, null)
//                    }
//
//                    override fun onAdLoaded() {
//                        ishomeBannerLoading = false
//                        ishomeBannerLoaded = true
//                        handleBannerVisibility(activity, parentView, this@apply)
//                        loadedLog(activity)
//
//                    }
//
//                    override fun onAdClicked() {
//                        super.onAdClicked()
//                        isAdsNotShowOnResume = true
//                    }
//                }
//                loadAd(AdRequest.Builder().build())
//            }
//        }
    }


    fun showListGoogleBanner(activity: Activity, parentView: ViewGroup) {
        if (!activity.isInternetConnected() || !AdsPreferences(activity).adsEnable || AdsPreferences(
                activity
            ).isPro
        ) {
            handleBannerVisibility(activity, parentView, null)
            return
        }
        if (homeBannerAd != null) {
            parentView.removeAllViews()
            val bannerParent = homeBannerAd!!.parent as? ViewGroup
            bannerParent?.removeView(homeBannerAd)
            parentView.addView(homeBannerAd)
            homeBannerAd!!.resume()

        } else {
            showHomeGoogleBanner(activity, parentView)
        }
    }


    /*  private var docViewBannerAd: AdView? = null
      private var isDocViewBannerLoading = false
      private var isDocViewBannerLoaded = false
      fun showDocViewBanner(activity: Activity, parentView: ViewGroup) {
          if (!activity.isInternetConnected() || !AdsPreferences(activity).adsEnable || AdsPreferences(
                  activity
              ).isPro
          ) {
              handleBannerVisibility(activity, parentView, null)
              return
          }

          if (docViewBannerAd != null) {
              handleBannerVisibility(activity, parentView, docViewBannerAd!!)
          } else {
              if (isDocViewBannerLoading) return
              isDocViewBannerLoading = true
              docViewBannerAd = AdView(activity)
              docViewBannerAd!!.apply {
                  setAdSize(getAdSize(activity))
                  adUnitId = activity.getFilesViewBanner()
                  adListener = object : AdListener() {
                      override fun onAdFailedToLoad(adError: LoadAdError) {
                          isDocViewBannerLoading = false
                          failedToLoad(activity, adError)
                          docViewBannerAd = null
                          handleBannerVisibility(activity, parentView, null)
                      }

                      override fun onAdLoaded() {
                          isDocViewBannerLoading = false
                          isDocViewBannerLoaded = true
                          handleBannerVisibility(activity, parentView, this@apply)
                          loadedLog(activity)

                      }

                      override fun onAdClicked() {
                          super.onAdClicked()
                          isAdsNotShowOnResume = true
                      }
                  }
                  loadAd(AdRequest.Builder().build())
              }
          }
      }

      private var pdfPreviewBannerAd: AdView? = null
      private var ispdfPreviewBannerLoading = false
      private var ispdfPreviewBannerLoaded = false
      fun showPdfPreviewBanner(activity: Activity, parentView: ViewGroup) {
          if (!activity.isInternetConnected() || !AdsPreferences(activity).adsEnable || AdsPreferences(
                  activity
              ).isPro
          ) {
              handleBannerVisibility(activity, parentView, null)
              return
          }

          if (pdfPreviewBannerAd != null) {
              handleBannerVisibility(activity, parentView, pdfPreviewBannerAd!!)
          } else {
              if (ispdfPreviewBannerLoading) return
              ispdfPreviewBannerLoading = true
              pdfPreviewBannerAd = AdView(activity)
              pdfPreviewBannerAd!!.apply {
                  setAdSize(getAdSize(activity))
                  adUnitId = activity.getFilesViewBanner()
                  adListener = object : AdListener() {
                      override fun onAdFailedToLoad(adError: LoadAdError) {
                          ispdfPreviewBannerLoading = false
                          failedToLoad(activity, adError)
                          pdfPreviewBannerAd = null
                          handleBannerVisibility(activity, parentView, null)
                      }

                      override fun onAdLoaded() {
                          ispdfPreviewBannerLoading = false
                          ispdfPreviewBannerLoaded = true
                          handleBannerVisibility(activity, parentView, this@apply)
                          loadedLog(activity)
                      }

                      override fun onAdClicked() {
                          super.onAdClicked()
                          isAdsNotShowOnResume = true
                      }
                  }
                  loadAd(AdRequest.Builder().build())
              }
          }
      }


      private var mainHomeViewBannerAd: AdView? = null
      private var ismainHomeViewBannerLoading = false
      private var isMainHomeViewBannerLoaded = false
      fun showMainHomeViewBanner(activity: Activity, parentView: ViewGroup) {
          if (!activity.isInternetConnected() || !AdsPreferences(activity).adsEnable || AdsPreferences(
                  activity
              ).isPro
          ) {
              handleBannerVisibility(activity, parentView, null)
              return
          }

          if (mainHomeViewBannerAd != null) {
              handleBannerVisibility(activity, parentView, mainHomeViewBannerAd!!)
          } else {
              if (ismainHomeViewBannerLoading) return
              ismainHomeViewBannerLoading = true
              mainHomeViewBannerAd = AdView(activity)
              mainHomeViewBannerAd!!.apply {
                  setAdSize(getAdSize(activity))
                  adUnitId = activity.geMainHomeBanner()
                  adListener = object : AdListener() {
                      override fun onAdFailedToLoad(adError: LoadAdError) {
                          ismainHomeViewBannerLoading = false
                          failedToLoad(activity, adError)
                          mainHomeViewBannerAd = null
                          handleBannerVisibility(activity, parentView, null)
                      }

                      override fun onAdLoaded() {
                          ismainHomeViewBannerLoading = false
                          isMainHomeViewBannerLoaded = true
                          handleBannerVisibility(activity, parentView, this@apply)
                          loadedLog(activity)
                      }

                      override fun onAdClicked() {
                          super.onAdClicked()
                          isAdsNotShowOnResume = true
                      }
                  }
                  loadAd(AdRequest.Builder().build())
              }
          }
      }

      private var singleImageViewBannerAd: AdView? = null
      private var isSingleImageViewBannerLoading = false
      private var isSingleImageViewBannerLoaded = false
      fun showSingleImageViewBanner(activity: Activity, parentView: ViewGroup) {
          if (!activity.isInternetConnected() || !AdsPreferences(activity).adsEnable || AdsPreferences(
                  activity
              ).isPro
          ) {
              handleBannerVisibility(activity, parentView, null)
              return
          }

          if (singleImageViewBannerAd != null) {
              handleBannerVisibility(activity, parentView, singleImageViewBannerAd!!)
          } else {
              if (isSingleImageViewBannerLoading) return
              isSingleImageViewBannerLoading = true
              singleImageViewBannerAd = AdView(activity)
              singleImageViewBannerAd!!.apply {
                  setAdSize(getAdSize(activity))
                  adUnitId = activity.getFilesViewBanner()
                  adListener = object : AdListener() {
                      override fun onAdFailedToLoad(adError: LoadAdError) {
                          isSingleImageViewBannerLoading = false
                          failedToLoad(activity, adError)
                          singleImageViewBannerAd = null
                          handleBannerVisibility(activity, parentView, null)
                      }

                      override fun onAdLoaded() {
                          isSingleImageViewBannerLoading = false
                          isSingleImageViewBannerLoaded = true
                          handleBannerVisibility(activity, parentView, this@apply)
                          loadedLog(activity)
                      }

                      override fun onAdClicked() {
                          super.onAdClicked()
                          isAdsNotShowOnResume = true
                      }
                  }
                  loadAd(AdRequest.Builder().build())
              }
          }
      }*/


    fun handleBannerVisibility(activity: Activity, parentView: ViewGroup, bannerAdView: AdView?) {
        if (activity.isDestroyed || activity.isFinishing) return

        if (bannerAdView != null) {
            activity.firebaseAnalyticsHandler.logMessages(
                app_banner_created, activity.getActivityName()
            )
            activity.firebaseAnalyticsHandler.logMessages(
                app_ad_banner_shown, activity.getActivityName()
            )
            val view = parentView.getChildAt(0)

            if (view.tag != null && view.tag.toString().equals("shrimmer")) {
                if (bannerAdView.parent != null) (bannerAdView.parent as ViewGroup).removeView(
                    bannerAdView
                )
                parentView.removeAllViews()
                parentView.addView(bannerAdView)
                bannerAdView.resume()
            } else {
                parentView.addView(bannerAdView)
            }
        } else {
            activity.firebaseAnalyticsHandler.logMessages(
                app_banner_created, activity.getActivityName()
            )
            activity.firebaseAnalyticsHandler.logMessages(
                app_ad_banner_failed, activity.getActivityName()
            )
            parentView.removeAllViews()
            (parentView.parent as View).visibility = View.GONE
        }

    }


    /*   fun onPause(activity: Activity) {
           if (activity is HomeActivity) mainHomeViewBannerAd?.pause()
           if (activity is FileListActivity) homeBannerAd?.pause()
           if (activity is DirectoriesActivity) homeBannerAd?.pause()
           if (activity is SingleImageViewActivity) singleImageViewBannerAd?.pause()
           if (activity is EditActivity) pdfPreviewBannerAd?.pause()
           if (activity is ViewFilesNew_Activity) docViewBannerAd?.pause()
           if (activity is RecyclerActivity) homeBannerAd?.pause()
       }

       fun onResume(activity: Activity) {
           if (activity is HomeActivity) mainHomeViewBannerAd?.resume()
           if (activity is DirectoriesActivity) homeBannerAd?.resume()
           if (activity is RecyclerActivity) homeBannerAd?.resume()
           if (activity is FileListActivity) homeBannerAd?.resume()
           if (activity is SingleImageViewActivity) singleImageViewBannerAd?.resume()
           if (activity is EditActivity) pdfPreviewBannerAd?.resume()
           if (activity is ViewFilesNew_Activity) docViewBannerAd?.resume()
       }*/


    fun onDestroyFileView() {

        /* docViewBannerAd?.destroy()
         docViewBannerAd = null

         pdfPreviewBannerAd?.destroy()
         pdfPreviewBannerAd = null

         singleImageViewBannerAd?.destroy()
         singleImageViewBannerAd = null*/
    }

    fun onDestroy() {
//        mainHomeViewBannerAd?.destroy()
//        mainHomeViewBannerAd = null

        homeBannerAd?.destroy()
        homeBannerAd = null

//        docViewBannerAd?.destroy()
//        docViewBannerAd = null

//        pdfPreviewBannerAd?.destroy()
//        pdfPreviewBannerAd = null

//        singleImageViewBannerAd?.destroy()
//        singleImageViewBannerAd = null
    }

    private fun getAdSize(activity: Activity): AdSize {
        val display = activity.windowManager.defaultDisplay
        val outMetrics = DisplayMetrics()
        display.getMetrics(outMetrics)
        val widthPixels = outMetrics.widthPixels.toFloat()
        val density = outMetrics.density
        val adWidth = (widthPixels / density).toInt()

        // Step 3 - Get adaptive ad size and return for setting on the ad view.
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(
            activity, adWidth
        )
    }

    private fun failedToLoad(activity: Activity, adError: LoadAdError) {
        Log.i(
            activity.localClassName.replace(activity.packageName, ""),
            "onAdFailedToLoad: Ad failed to load -> \nresponseInfo::${adError.responseInfo}\nErrorCode::${adError.code}\nErrorMessage::${adError.message}"
        )
    }

    private fun loadedLog(activity: Activity) {
        Log.i(
            activity.localClassName.replace(activity.packageName, ""),
            "onAdFailedToLoad: loadedLog "
        )
    }
}