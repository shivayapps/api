package messages.sms.text.chat.messanger.app.ads

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson

class AdsPreferences(context: Context) {
    private val HOROSCOPE_PARAMETERS = "horoscope_parameters"

    private val gson = Gson()

    private val preferences: SharedPreferences =
        context.getSharedPreferences(HOROSCOPE_PARAMETERS, Context.MODE_PRIVATE)

    private val horoscope_language = "horoscope_language"
    private val horoscope_premium = "horoscope_premium"
    private val notification_dialog = "notification_dialog"
    private val horoscope_first = "horoscope_first"
    private val LIST_RECENT_ITEM = "listRecentItem"
    private val ALL_FILE_PERMISSION = "all_file_permission"


    private val callerdialog_closable_v = "callerdialog_closable"
    private val show_callercad_v = "show_callercad"
    private val check_First_Time_Data = "checkfirsttimedata"

    var selectedLanguage: String
        get() = preferences.getString("selectedLanguage", "") ?: ""
        set(selectedLanguage) = preferences.edit().putString("selectedLanguage", selectedLanguage)
            .apply()


    var splashCounter: Int
        get() = preferences.getInt("splashCounter", 0)
        set(splashCounter) = preferences.edit().putInt("splashCounter", splashCounter).apply()

    var horoscopeLanguage: String?
        get() = preferences.getString(horoscope_language, "en")
        set(value) = preferences.edit().putString(horoscope_language, value).apply()

    var isPro: Boolean
        get() = preferences.getBoolean(horoscope_premium, false)
        set(value) = preferences.edit().putBoolean(horoscope_premium, value).apply()
    var shownotificationdialog: Boolean
        get() = preferences.getBoolean(notification_dialog, false)
        set(value) = preferences.edit().putBoolean(notification_dialog, value).apply()

    var isFirstHoroscope: Boolean
        get() = preferences.getBoolean(horoscope_first, true)
        set(value) = preferences.edit().putBoolean(horoscope_first, value).apply()

    var allFilePermissionDialog: Boolean
        get() = preferences.getBoolean(ALL_FILE_PERMISSION, false)
        set(value) = preferences.edit().putBoolean(ALL_FILE_PERMISSION, value).apply()

    var adsEnable: Boolean
        get() = /*!isPurchased &&*//* !BuildConfig.DEBUG &&*/ preferences.getBoolean(
            "PREF_ADS_ENABLED",
            true
        )
        set(adsEnable) = preferences.edit().putBoolean("PREF_ADS_ENABLED", adsEnable).apply()


    var callerdialog_closable: Boolean
        get() = preferences.getBoolean(callerdialog_closable_v, false)
        set(value) = preferences.edit().putBoolean(callerdialog_closable_v, value).apply()

    var checkFirstTimeData: Boolean
        get() = preferences.getBoolean(check_First_Time_Data, false)
        set(value) = preferences.edit().putBoolean(check_First_Time_Data, value).apply()

    var native1: String?
        get() = preferences.getString("nativ1", "")
        set(value) = preferences.edit().putString("nativ1", value).apply()


    var maxTapTime: Int
        get() = preferences.getInt("maxTapTime", 30)
        set(maxTapTime) = preferences.edit().putInt("maxTapTime", maxTapTime).apply()

    var maxTapCount: Int
        get() = preferences.getInt("maxTapCount", 3)
        set(maxTapCount) = preferences.edit().putInt("maxTapCount", maxTapCount).apply()

    companion object {
        private const val PREF_NAME = "MySharedPreferences"
    }


}