package messages.sms.text.chat.messanger.app.common.util

import android.content.ComponentName
import android.content.IntentFilter
import android.graphics.drawable.Icon
import android.service.chooser.ChooserTarget
import android.service.chooser.ChooserTargetService
import androidx.core.os.bundleOf
import com.bumptech.glide.Glide
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.feature.compose.ComposeActivity
import messages.sms.text.chat.messanger.app.injection.appComponent
import messages.sms.text.chat.messanger.app.model.Conversation
import messages.sms.text.chat.messanger.app.repository.ConversationRepository

import messages.sms.text.chat.messanger.app.util.tryOrNull
import javax.inject.Inject

class QkChooserTargetService : ChooserTargetService() {

    @Inject
    lateinit var conversationRepo: ConversationRepository

    override fun onCreate() {
        appComponent.inject(this)
        super.onCreate()
    }

    override fun onGetChooserTargets(
        targetActivityName: ComponentName?,
        matchedFilter: IntentFilter?,
    ): List<ChooserTarget> {
        return conversationRepo.getTopConversations()
            .take(3)
            .map(this::createShortcutForConversation)
    }

    private fun createShortcutForConversation(conversation: Conversation): ChooserTarget {
        val icon = when (conversation.recipients.size) {
            1 -> {
                val photoUri = conversation.recipients.first()?.contact?.photoUri
                val request = Glide.with(this)
                    .asBitmap()
                    .circleCrop()
                    .load(photoUri)
                    .submit()
                val bitmap = tryOrNull(false) { request.get() }

                if (bitmap != null) Icon.createWithBitmap(bitmap)
                else Icon.createWithResource(this, R.mipmap.ic_shortcut_person)
            }

            else -> Icon.createWithResource(this, R.mipmap.ic_shortcut_people)
        }

        val componentName = ComponentName(this, ComposeActivity::class.java)

        return ChooserTarget(
            conversation.getTitle(),
            icon,
            1f,
            componentName,
            bundleOf("threadId" to conversation.id)
        )
    }

}