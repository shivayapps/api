package messages.sms.text.chat.messanger.app.interactor

import io.reactivex.Flowable
import messages.sms.text.chat.messanger.app.repository.BackupRepository
import javax.inject.Inject

class PerformBackup @Inject constructor(
    private val backupRepo: BackupRepository,
) : Interactor<Unit>() {

    override fun buildObservable(params: Unit): Flowable<*> {
        return Flowable.just(params)
            .doOnNext { backupRepo.performBackup() }
    }

}