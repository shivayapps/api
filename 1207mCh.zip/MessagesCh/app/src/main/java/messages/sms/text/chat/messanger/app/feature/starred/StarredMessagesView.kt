package messages.sms.text.chat.messanger.app.feature.starred

import io.reactivex.Observable
import messages.sms.text.chat.messanger.app.common.base.QkView
import messages.sms.text.chat.messanger.app.model.Message

interface StarredMessagesView : QkView<StarredMessagesState> {
    val conversationClicks: Observable<Message>
    fun requestDefaultSms()
}
