package messages.sms.text.chat.messanger.app.feature.personalize

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.core.view.ViewCompat
import dagger.android.AndroidInjection
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.common.base.QkThemedActivity
import messages.sms.text.chat.messanger.app.common.util.extensions.setTint
import messages.sms.text.chat.messanger.app.common.util.extensions.viewBinding
import messages.sms.text.chat.messanger.app.commons.extensions.applyColorFilter
import messages.sms.text.chat.messanger.app.commons.extensions.baseConfig
import messages.sms.text.chat.messanger.app.commons.extensions.config
import messages.sms.text.chat.messanger.app.commons.extensions.getBottomNavigationBackgroundColor
import messages.sms.text.chat.messanger.app.commons.extensions.getContrastColor
import messages.sms.text.chat.messanger.app.commons.extensions.updateTextColors
import messages.sms.text.chat.messanger.app.commons.helpers.BUBBLE_STYLE_IOS
import messages.sms.text.chat.messanger.app.commons.helpers.BUBBLE_STYLE_IOS_NEW
import messages.sms.text.chat.messanger.app.commons.helpers.BUBBLE_STYLE_ORIGINAL
import messages.sms.text.chat.messanger.app.commons.helpers.BUBBLE_STYLE_ROUNDED
import messages.sms.text.chat.messanger.app.commons.helpers.BubbleStyleType
import messages.sms.text.chat.messanger.app.databinding.ActivityBubbleBinding

class BubbleActivity : QkThemedActivity() {

    var title: String = ""
    var color = 0
    private val PRIMARY_COLORS_COUNT = 19
    private val DEFAULT_PRIMARY_COLOR_INDEX = 14
    private val DEFAULT_SECONDARY_COLOR_INDEX = 6

    //    private var backgroundColorOne: Int = Color.parseColor("#E7F0FB")
//    private var backgroundColorTwo: Int = Color.parseColor("#569BF5")
//    private var backgroundTextColorOne: Int = Color.parseColor("#000000")
//    private var backgroundTextColorTwo: Int = Color.parseColor("#FFFFFF")
    private var backgroundColorOne: Int = Color.parseColor("#E7F0FB")
    private var backgroundColorTwo: Int = Color.parseColor("#569BF5")
    private var backgroundTextColorOne: Int = Color.parseColor("#000000")
    private var backgroundTextColorTwo: Int = Color.parseColor("#FFFFFF")

    private var TempBackgroundColorOne: Int = Color.parseColor("#E7F0FB")
    private var TempBackgroundColorTwo: Int = Color.parseColor("#569BF5")
    private var TempBackgroundTextColorOne: Int = Color.parseColor("#000000")
    private var TempBackgroundTextColorTwo: Int = Color.parseColor("#FFFFFF")

    private var backgroundstyle: Int = 0
    private var backgroundStyleType: BubbleStyleType = BubbleStyleType.AUTO


    private val binding by viewBinding(ActivityBubbleBinding::inflate)
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        showBackButton(true)
        setTitle(R.string.bubble)


        TempBackgroundColorOne = Color.parseColor("#E7F0FB")
        TempBackgroundColorTwo = Color.parseColor("#569BF5")
        TempBackgroundTextColorOne = Color.parseColor("#000000")
        TempBackgroundTextColorTwo = Color.parseColor("#FFFFFF")


        val background = ResourcesCompat.getDrawable(
            resources,
            R.drawable.item_received_background,
            null
        )

        binding.tvone.background = background
        binding.tvone.background.applyColorFilter(TempBackgroundColorOne)

        binding.tvtwo.setTextColor(TempBackgroundTextColorTwo)
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationIcon(R.drawable.ic_chevron_left_vector)

        setUI()
        setUpTheme()
        setUpListener()

        binding.btnApply.setTextColor(Color.parseColor("#FFFFFF"))

        val checks = listOf(
            binding.styleOriginalCheckautoFill,
            binding.styleRoundedCheckautoFill,
            binding.styleIosNewCheckautoFill,
            binding.styleIosCheckautoFill,
            binding.styleOriginalCheckfill,
            binding.styleRoundedCheckfill,
            binding.styleIosNewCheckfill,
            binding.styleIosCheckfill
        )
        checks.forEach { it.setTint(baseConfig.primaryColor) }

        val checksHide = listOf(
            binding.styleOriginalCheckauto,
            binding.styleRoundedCheckauto,
            binding.styleIosNewCheckauto,
            binding.styleIosCheckauto,
            binding.styleOriginalCheck,
            binding.styleRoundedCheck,
            binding.styleIosNewCheck,
            binding.styleIosCheck
        )
        checksHide.forEach { it.setVisibility(View.GONE) }


        val views = listOf(
            binding.autoIndicator,
            binding.colorIndicator,
            binding.messageIndicator,
            binding.textIndicator,
            binding.viewleft,
            binding.viewright,
            binding.viewlefttvtext,
            binding.viewrighttext
        )
        val colorStateList = ColorStateList.valueOf(baseConfig.primaryColor)
        views.forEach {
            ViewCompat.setBackgroundTintList(it, colorStateList)
        }


        /* ViewCompat.setBackgroundTintList(
             binding.autoIndicator,
             ColorStateList.valueOf(baseConfig.primaryColor)
         )
         ViewCompat.setBackgroundTintList(
             binding.colorIndicator,
             ColorStateList.valueOf(baseConfig.primaryColor)
         )
         ViewCompat.setBackgroundTintList(
             binding.messageIndicator,
             ColorStateList.valueOf(baseConfig.primaryColor)
         )
         ViewCompat.setBackgroundTintList(
             binding.textIndicator,
             ColorStateList.valueOf(baseConfig.primaryColor)
         )

         ViewCompat.setBackgroundTintList(
             binding.viewleft,
             ColorStateList.valueOf(baseConfig.primaryColor)
         )
         ViewCompat.setBackgroundTintList(
             binding.viewright,
             ColorStateList.valueOf(baseConfig.primaryColor)
         )
         ViewCompat.setBackgroundTintList(
             binding.viewlefttvtext,
             ColorStateList.valueOf(baseConfig.primaryColor)
         )
         ViewCompat.setBackgroundTintList(
             binding.viewrighttext,
             ColorStateList.valueOf(baseConfig.primaryColor)
         )*/


    }

    private fun setUpTheme() {

        Log.e("MainActivity", "setUpTheme.useImageResource:${baseConfig.useImageResource}")
        Log.e("MainActivity", "setUpTheme.storedImageResource:${baseConfig.storedImageResource}")

        updateTextColors(binding.contentView)
        //   binding.toolbarTitle.setTextColor(baseConfig.primaryColor)

        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
            binding.contentView.background =
                ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))
//            arrayListOf(binding.ivBack).forEach {
//                val colorStateList = ColorStateList.valueOf(Color.WHITE)
//                it.imageTintList = colorStateList
//            }
        } else {
            binding.contentView.background = ColorDrawable(baseConfig.backgroundColor)
//            arrayListOf(binding.ivBack).forEach {
//                val colorStateList = ColorStateList.valueOf(Color.BLACK)
//                it.imageTintList = colorStateList
//            }
        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource != -1) {
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.contentView.background = drawable
                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
            }
        } else {
            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
            toolbar.setBackgroundColor(baseConfig.backgroundColor)
        }


        arrayOf(
            binding.llbottom,
        ).forEach {
            if (baseConfig.useImageResource == true) {
                if (baseConfig.storedImageResource == -1) {

                } else {
                    try {
                        it.background.applyColorFilter(resources.getColor(R.color.transperent30))
                    } catch (_: Exception) {
                    }
                }
            } else {
                it.background.applyColorFilter(getBottomNavigationBackgroundColor())
            }
        }
    }

    private fun setUI() {


        binding.btnApply.backgroundTintList = ColorStateList.valueOf(baseConfig.primaryColor)


        val drawable = GradientDrawable()
        drawable.shape = GradientDrawable.RECTANGLE
        val colorWithOpacity = baseConfig.primaryColor
//        val colorWith90Opacity = colorWithOpacity?.let { ColorUtils.setAlphaComponent(it, (0.9 * 255).toInt()) }
        val colorWith90Opacity = baseConfig.primaryColor
        drawable.setColor(colorWith90Opacity)

        val cornerRadius = resources?.getDimension(R.dimen.small_icon_size)
        if (cornerRadius != null) {
            drawable.cornerRadius = cornerRadius
        }

        binding.autoIndicator.visibility = View.VISIBLE
        binding.messageIndicator.visibility = View.INVISIBLE
        binding.colorIndicator.visibility = View.INVISIBLE
        binding.textIndicator.visibility = View.INVISIBLE
        binding.rauto.visibility = View.VISIBLE
        binding.rmessage.visibility = View.GONE
        binding.rbgpicker.visibility = View.GONE
        binding.lltvtextcolor.visibility = View.GONE

        binding.autoIndicator.background = drawable
        binding.colorIndicator.background = drawable
        binding.messageIndicator.background = drawable
        binding.textIndicator.background = drawable


        binding.viewleft.visibility = View.VISIBLE
        binding.viewright.visibility = View.GONE
        binding.rleftpicker.visibility = View.VISIBLE
        binding.rrightpicker.visibility = View.GONE
        binding.viewlefttvtext.visibility = View.VISIBLE
        binding.viewrighttext.visibility = View.GONE
        binding.rleftpickertext.visibility = View.VISIBLE
        binding.rrightpickertext.visibility = View.GONE


        binding.tvLllefttvtext.setTextColor(baseConfig.primaryColor)
        binding.tvLllefttv.setTextColor(baseConfig.primaryColor)
        binding.tvLlrighttv.setTextColor(resources.getColor(R.color.radiobutton_disabled))
        binding.tvLlrighttvtext.setTextColor(resources.getColor(R.color.radiobutton_disabled))
    }

    private fun setupColorsRight(primaryColor: Int) {
        binding.apply {
            val backgroundReceived = primaryColor
            val contrastColorReceived = backgroundReceived.getContrastColor()
            tvtwo.background.applyColorFilter(backgroundReceived)
            tvtwo.setTextColor(contrastColorReceived)
            backgroundTextColorTwo = contrastColorReceived
            backgroundColorTwo = primaryColor
        }
    }

    private fun setUpListener() {
//        binding.ivBack.setOnClickListener {
//            onBackPressed()
//        }
        binding.llauto.setOnClickListener {
            backgroundStyleType = BubbleStyleType.AUTO
            binding.autoIndicator.visibility = View.VISIBLE
            binding.messageIndicator.visibility = View.INVISIBLE
            binding.colorIndicator.visibility = View.INVISIBLE
            binding.textIndicator.visibility = View.INVISIBLE

            binding.rauto.visibility = View.VISIBLE
            binding.rmessage.visibility = View.GONE
            binding.rbgpicker.visibility = View.GONE
            binding.lltvtextcolor.visibility = View.GONE
        }
        binding.llcustomBubble.setOnClickListener {

            backgroundStyleType = BubbleStyleType.CUSTOM
            binding.autoIndicator.visibility = View.INVISIBLE
            binding.messageIndicator.visibility = View.VISIBLE
            binding.colorIndicator.visibility = View.INVISIBLE
            binding.textIndicator.visibility = View.INVISIBLE

            binding.rauto.visibility = View.GONE
            binding.rmessage.visibility = View.VISIBLE
            binding.rbgpicker.visibility = View.GONE
            binding.lltvtextcolor.visibility = View.GONE
        }
        binding.llbgcolor.setOnClickListener {

            binding.autoIndicator.visibility = View.INVISIBLE
            binding.messageIndicator.visibility = View.INVISIBLE
            binding.colorIndicator.visibility = View.VISIBLE
            binding.textIndicator.visibility = View.INVISIBLE

            binding.rauto.visibility = View.GONE
            binding.rmessage.visibility = View.GONE
            binding.rbgpicker.visibility = View.VISIBLE
            binding.lltvtextcolor.visibility = View.GONE
        }
        binding.lltextcolor.setOnClickListener {
            binding.autoIndicator.visibility = View.INVISIBLE
            binding.messageIndicator.visibility = View.INVISIBLE
            binding.colorIndicator.visibility = View.INVISIBLE
            binding.textIndicator.visibility = View.VISIBLE

            binding.rauto.visibility = View.GONE
            binding.rmessage.visibility = View.GONE
            binding.rbgpicker.visibility = View.GONE
            binding.lltvtextcolor.visibility = View.VISIBLE

        }

//        -----------------------------------Start Bubble Text Color with  Items Click and Select Color(4rd Tab)------------------------------------

        binding.lllefttvtext.setOnClickListener {
            binding.viewlefttvtext.visibility = View.VISIBLE
            binding.viewrighttext.visibility = View.INVISIBLE
            binding.rleftpickertext.visibility = View.VISIBLE
            binding.rrightpickertext.visibility = View.GONE

            binding.tvLllefttvtext.setTextColor(baseConfig.primaryColor)
            binding.tvLlrighttvtext.setTextColor(resources.getColor(R.color.radiobutton_disabled))
        }
        binding.llrighttvtext.setOnClickListener {
            binding.viewlefttvtext.visibility = View.INVISIBLE
            binding.viewrighttext.visibility = View.VISIBLE
            binding.rleftpickertext.visibility = View.GONE
            binding.rrightpickertext.visibility = View.VISIBLE

            binding.tvLllefttvtext.setTextColor(resources.getColor(R.color.radiobutton_disabled))
            binding.tvLlrighttvtext.setTextColor(baseConfig.primaryColor)
        }

        binding.colorPickerViewtext.addOnColorSelectedListener { selectedColor ->
            binding.tvone.setTextColor(selectedColor)
            backgroundTextColorOne = selectedColor
        }
        binding.colorPickerViewrighttext.addOnColorSelectedListener { selectedColor ->
            binding.tvtwo.setTextColor(selectedColor)
            backgroundTextColorTwo = selectedColor
        }
//        -----------------------------------End Bubble Text Color with  Items Click and Select Color(4rd Tab)------------------------------------


//        -----------------------------------Start Bubble Color with  Items Click and Select Color(3rd Tab)------------------------------------

        binding.lllefttv.setOnClickListener {
            binding.viewleft.visibility = View.VISIBLE
            binding.viewright.visibility = View.INVISIBLE
            binding.rleftpicker.visibility = View.VISIBLE
            binding.rrightpicker.visibility = View.GONE

            binding.tvLllefttv.setTextColor(baseConfig.primaryColor)
            binding.tvLlrighttv.setTextColor(resources.getColor(R.color.radiobutton_disabled))

        }
        binding.llrighttv.setOnClickListener {
            binding.viewleft.visibility = View.INVISIBLE
            binding.viewright.visibility = View.VISIBLE
            binding.rleftpicker.visibility = View.GONE
            binding.rrightpicker.visibility = View.VISIBLE

            binding.tvLllefttv.setTextColor(resources.getColor(R.color.radiobutton_disabled))
            binding.tvLlrighttv.setTextColor(baseConfig.primaryColor)
        }

        binding.colorPickerView.addOnColorSelectedListener { selectedColor ->
            setupColors(selectedColor)
            TempBackgroundColorOne = selectedColor
        }
        binding.colorPickerViewright.addOnColorSelectedListener { selectedColor ->
            setupColorsRight(selectedColor)
            TempBackgroundColorTwo = selectedColor
        }

//        -----------------------------------End Bubble Color with  Items Click and Select Color(3rd Tab)------------------------------------


//        -----------------------------------Start Message Items Click(2nd Tab)------------------------------------

        binding.styleOriginal.setOnClickListener {
            backgroundstyle = BUBBLE_STYLE_ORIGINAL
            backgroundStyleType = BubbleStyleType.CUSTOM

            hideAllSecondTabBubbles()
            binding.styleOriginalCheck.visibility = View.VISIBLE

            backgroundColorOne = config.getIntData("backgroundColorone", TempBackgroundColorOne)
            backgroundColorTwo = config.getIntData("backgroundColortwo", TempBackgroundColorTwo)
            backgroundTextColorOne =
                config.getIntData("backgroundtextColorone", TempBackgroundTextColorOne)
            backgroundTextColorTwo =
                config.getIntData("backgroundtextColortwo", TempBackgroundTextColorTwo)

            binding.tvone.apply {
                background = ResourcesCompat.getDrawable(
                    resources,
                    R.drawable.item_received_background,
                    null
                )
                val backgroundReceived =
                    config.getIntData("backgroundColorone", TempBackgroundColorOne)
                background.applyColorFilter(backgroundReceived)

                setTextColor(
                    config.getIntData(
                        "backgroundtextColorone",
                        TempBackgroundTextColorOne
                    )
                )

            }

            binding.tvtwo.apply {
                background =
                    ResourcesCompat.getDrawable(resources, R.drawable.item_sent_background, null)
                val backgroundReceived =
                    config.getIntData("backgroundColortwo", TempBackgroundColorTwo)
                background.applyColorFilter(backgroundReceived)
                setTextColor(
                    config.getIntData(
                        "backgroundtextColortwo",
                        TempBackgroundTextColorTwo
                    )
                )


            }

            binding.styleOriginalCheckauto.isActivated = false
            binding.styleRoundedCheckauto.isActivated = false
            binding.styleIosNewCheckauto.isActivated = false
            binding.styleIosCheckauto.isActivated = false

        }
        binding.styleRounded.setOnClickListener {
            backgroundstyle = BUBBLE_STYLE_ROUNDED
            backgroundStyleType = BubbleStyleType.CUSTOM


            hideAllSecondTabBubbles()
            binding.styleRoundedCheck.visibility = View.VISIBLE

            backgroundColorOne = config.getIntData("backgroundColorone", TempBackgroundColorOne)
            backgroundColorTwo = config.getIntData("backgroundColortwo", TempBackgroundColorTwo)
            backgroundTextColorOne =
                config.getIntData("backgroundtextColorone", TempBackgroundTextColorOne)
            backgroundTextColorTwo =
                config.getIntData("backgroundtextColortwo", TempBackgroundTextColorTwo)

            binding.tvone.apply {
                background = ResourcesCompat.getDrawable(
                    resources,
                    R.drawable.item_received_rounded_background,
                    null
                )
                val backgroundReceived =
                    config.getIntData("backgroundColorone", TempBackgroundColorOne)
                background.applyColorFilter(backgroundReceived)

                setTextColor(
                    config.getIntData(
                        "backgroundtextColorone",
                        TempBackgroundTextColorOne
                    )
                )
            }

            binding.tvtwo.apply {
                background = ResourcesCompat.getDrawable(
                    resources,
                    R.drawable.item_sent_rounded_background,
                    null
                )
                val backgroundReceived =
                    config.getIntData("backgroundColortwo", TempBackgroundColorTwo)
                background.applyColorFilter(backgroundReceived)
                setTextColor(
                    config.getIntData(
                        "backgroundtextColortwo",
                        TempBackgroundTextColorTwo
                    )
                )
            }

            binding.styleOriginalCheckauto.isActivated = false
            binding.styleRoundedCheckauto.isActivated = false
            binding.styleIosNewCheckauto.isActivated = false
            binding.styleIosCheckauto.isActivated = false

        }
        binding.styleIosNew.setOnClickListener {
            backgroundstyle = BUBBLE_STYLE_IOS_NEW
            backgroundStyleType = BubbleStyleType.CUSTOM


            hideAllSecondTabBubbles()
            binding.styleIosNewCheck.visibility = View.VISIBLE

            backgroundColorOne = config.getIntData("backgroundColorone", TempBackgroundColorOne)
            backgroundColorTwo = config.getIntData("backgroundColortwo", TempBackgroundColorTwo)
            backgroundTextColorOne =
                config.getIntData("backgroundtextColorone", TempBackgroundTextColorOne)
            backgroundTextColorTwo =
                config.getIntData("backgroundtextColortwo", TempBackgroundTextColorTwo)

            binding.tvone.apply {
                background = ResourcesCompat.getDrawable(
                    resources,
                    R.drawable.item_received_ios_new_background,
                    null
                )
                val backgroundReceived =
                    config.getIntData("backgroundColorone", TempBackgroundColorOne)
                background.applyColorFilter(backgroundReceived)

                setTextColor(
                    config.getIntData(
                        "backgroundtextColorone",
                        TempBackgroundTextColorOne
                    )
                )

            }

            binding.tvtwo.apply {
                background = ResourcesCompat.getDrawable(
                    resources,
                    R.drawable.item_sent_ios_new_background,
                    null
                )
                val backgroundReceived =
                    config.getIntData("backgroundColortwo", TempBackgroundColorTwo)
                background.applyColorFilter(backgroundReceived)
                setTextColor(
                    config.getIntData(
                        "backgroundtextColortwo",
                        TempBackgroundTextColorTwo
                    )
                )


            }

            binding.styleOriginalCheckauto.isActivated = false
            binding.styleRoundedCheckauto.isActivated = false
            binding.styleIosNewCheckauto.isActivated = false
            binding.styleIosCheckauto.isActivated = false

        }
        binding.styleIos.setOnClickListener {
            backgroundstyle = BUBBLE_STYLE_IOS
            backgroundStyleType = BubbleStyleType.CUSTOM

            backgroundColorOne = config.getIntData("backgroundColorone", TempBackgroundColorOne)
            backgroundColorTwo = config.getIntData("backgroundColortwo", TempBackgroundColorTwo)
            backgroundTextColorOne =
                config.getIntData("backgroundtextColorone", TempBackgroundTextColorOne)
            backgroundTextColorTwo =
                config.getIntData("backgroundtextColortwo", TempBackgroundTextColorTwo)



            hideAllSecondTabBubbles()
            binding.styleIosCheck.visibility = View.VISIBLE

            binding.tvone.apply {
                background = ResourcesCompat.getDrawable(
                    resources,
                    R.drawable.item_received_ios_background,
                    null
                )
                val backgroundReceived =
                    config.getIntData("backgroundColorone", TempBackgroundColorOne)
                background.applyColorFilter(backgroundReceived)
                setTextColor(
                    config.getIntData(
                        "backgroundtextColorone",
                        TempBackgroundTextColorOne
                    )
                )
            }

            binding.tvtwo.apply {
                background = ResourcesCompat.getDrawable(
                    resources,
                    R.drawable.item_sent_ios_background,
                    null
                )
                val backgroundReceived =
                    config.getIntData("backgroundColortwo", TempBackgroundColorTwo)
                background.applyColorFilter(backgroundReceived)
                setTextColor(
                    config.getIntData(
                        "backgroundtextColortwo",
                        TempBackgroundTextColorTwo
                    )
                )
            }

            binding.styleOriginalCheckauto.isActivated = false
            binding.styleRoundedCheckauto.isActivated = false
            binding.styleIosNewCheckauto.isActivated = false
            binding.styleIosCheckauto.isActivated = false
        }

//        -----------------------------------End Message Items Click(2nd Tab)------------------------------------


//        -----------------------------------Start Auto Items Click(1st Tab)------------------------------------

        binding.styleOriginalauto.setOnClickListener {
            backgroundstyle = BUBBLE_STYLE_ORIGINAL

//            setupToggleBubbleStyle(BUBBLE_STYLE_ORIGINAL)

            backgroundStyleType = BubbleStyleType.AUTO
            backgroundColorOne = Color.parseColor("#E7F0FB")
            backgroundColorTwo = Color.parseColor("#569BF5")
            backgroundTextColorOne = Color.parseColor("#000000")
            backgroundTextColorTwo = Color.parseColor("#FFFFFF")


            hideAllFirstTabBubbles()
            binding.styleOriginalCheckauto.visibility = View.VISIBLE


            TempBackgroundColorOne = backgroundColorOne
            TempBackgroundColorTwo = backgroundColorTwo
            TempBackgroundTextColorOne = backgroundTextColorOne
            TempBackgroundTextColorTwo = backgroundTextColorTwo

            binding.tvone.apply {
                background = ResourcesCompat.getDrawable(
                    resources,
                    R.drawable.item_received_background,
                    null
                )
                val backgroundReceived = backgroundColorOne
                background.applyColorFilter(backgroundReceived)
                setTextColor(backgroundTextColorOne)
            }

            binding.tvtwo.apply {
                background =
                    ResourcesCompat.getDrawable(resources, R.drawable.item_sent_background, null)
                val backgroundReceived = backgroundColorTwo
                background.applyColorFilter(backgroundReceived)
                setTextColor(backgroundTextColorTwo)
            }

            hideAllSecondTabBubbles()

        }
        binding.styleRoundedauto.setOnClickListener {
            backgroundstyle = BUBBLE_STYLE_ROUNDED

            hideAllFirstTabBubbles()
            binding.styleRoundedCheckauto.visibility = View.VISIBLE

            backgroundStyleType = BubbleStyleType.AUTO

            backgroundColorOne = Color.parseColor("#E8E2FF")
            backgroundColorTwo = Color.parseColor("#8A6EFF")
            backgroundTextColorOne = Color.parseColor("#000000")
            backgroundTextColorTwo = Color.parseColor("#FFFFFF")


            TempBackgroundColorOne = backgroundColorOne
            TempBackgroundColorTwo = backgroundColorTwo
            TempBackgroundTextColorOne = backgroundTextColorOne
            TempBackgroundTextColorTwo = backgroundTextColorTwo

            binding.tvone.apply {
                background = ResourcesCompat.getDrawable(
                    resources,
                    R.drawable.item_received_rounded_background,
                    null
                )
                val backgroundReceived = backgroundColorOne
                background.applyColorFilter(backgroundReceived)
                setTextColor(backgroundTextColorOne)
            }

            binding.tvtwo.apply {
                background = ResourcesCompat.getDrawable(
                    resources,
                    R.drawable.item_sent_rounded_background,
                    null
                )
                val backgroundReceived = backgroundColorTwo
                background.applyColorFilter(backgroundReceived)
                setTextColor(backgroundTextColorTwo)
            }

            hideAllSecondTabBubbles()

        }
        binding.styleIosNewauto.setOnClickListener {
            backgroundstyle = BUBBLE_STYLE_IOS_NEW
//            setupToggleBubbleStyle(BUBBLE_STYLE_IOS_NEW)

            backgroundStyleType = BubbleStyleType.AUTO

            backgroundColorOne = Color.parseColor("#E0FFF1")
            backgroundColorTwo = Color.parseColor("#4BD695")
            backgroundTextColorOne = Color.parseColor("#000000")
            backgroundTextColorTwo = Color.parseColor("#FFFFFF")

            TempBackgroundColorOne = backgroundColorOne
            TempBackgroundColorTwo = backgroundColorTwo
            TempBackgroundTextColorOne = backgroundTextColorOne
            TempBackgroundTextColorTwo = backgroundTextColorTwo


            hideAllFirstTabBubbles()
            binding.styleIosNewCheckauto.visibility = View.VISIBLE

            binding.tvone.apply {
                background = ResourcesCompat.getDrawable(
                    resources,
                    R.drawable.item_received_ios_new_background,
                    null
                )
                val backgroundReceived = backgroundColorOne
                background.applyColorFilter(backgroundReceived)
                setTextColor(backgroundTextColorOne)
            }

            binding.tvtwo.apply {
                background = ResourcesCompat.getDrawable(
                    resources,
                    R.drawable.item_sent_ios_new_background,
                    null
                )
                val backgroundReceived = backgroundColorTwo
                background.applyColorFilter(backgroundReceived)
                setTextColor(backgroundTextColorTwo)
            }

            hideAllSecondTabBubbles()

        }
        binding.styleIosauto.setOnClickListener {

            backgroundColorOne = Color.parseColor("#FFF6DF")
            backgroundColorTwo = Color.parseColor("#FFB801")
            backgroundTextColorOne = Color.parseColor("#000000")
            backgroundTextColorTwo = Color.parseColor("#FFFFFF")


            TempBackgroundColorOne = backgroundColorOne
            TempBackgroundColorTwo = backgroundColorTwo
            TempBackgroundTextColorOne = backgroundTextColorOne
            TempBackgroundTextColorTwo = backgroundTextColorTwo

            backgroundstyle = BUBBLE_STYLE_IOS
            backgroundStyleType = BubbleStyleType.AUTO

            hideAllFirstTabBubbles()
            binding.styleIosCheckauto.visibility = View.VISIBLE
//            setupToggleBubbleStyle(BUBBLE_STYLE_IOS)


            binding.tvone.apply {
                background = ResourcesCompat.getDrawable(
                    resources,
                    R.drawable.item_received_ios_background,
                    null
                )
                val backgroundReceived = backgroundColorOne
                background.applyColorFilter(backgroundReceived)

                setTextColor(backgroundTextColorOne)

            }

            binding.tvtwo.apply {
                background = ResourcesCompat.getDrawable(
                    resources,
                    R.drawable.item_sent_ios_background,
                    null
                )
                val backgroundReceived = backgroundColorTwo
                background.applyColorFilter(backgroundReceived)
                setTextColor(backgroundTextColorTwo)


            }
            hideAllSecondTabBubbles()

        }

//        -----------------------------------End Auto Items Click(1st Tab)------------------------------------
        binding.btnApply.setOnClickListener {
            setupToggleBubbleStyle()
            finish()
        }
    }

    private fun hideAllFirstTabBubbles() {


        binding.styleOriginalCheckauto.visibility = View.GONE
        binding.styleRoundedCheckauto.visibility = View.GONE
        binding.styleIosNewCheckauto.visibility = View.GONE
        binding.styleIosCheckauto.visibility = View.GONE


    }

    private fun hideAllSecondTabBubbles() {


        binding.styleOriginalCheck.visibility = View.GONE
        binding.styleRoundedCheck.visibility = View.GONE
        binding.styleIosNewCheck.visibility = View.GONE
        binding.styleIosCheck.visibility = View.GONE


    }



    private fun setupToggleBubbleStyle() {

        Log.e("ZZZZZZZ", "backgroundStyleType--->>> " + backgroundStyleType.toString())
        Log.e("ZZZZZZZ", "backgroundstyle--->>> " + backgroundstyle.toString())

        prefs.bubbleStyleType.set(backgroundStyleType.toString())
        prefs.bubbleStyle.set(backgroundstyle)
        config.saveData("backgroundColorone", backgroundColorOne)
        config.saveData("backgroundColortwo", backgroundColorTwo)
        config.saveData("backgroundtextColorone", backgroundTextColorOne)
        config.saveData("backgroundtextColortwo", backgroundTextColorTwo)


        config.bubbleStyle = backgroundstyle

        binding.styleOriginalCheck.isActivated = backgroundstyle == BUBBLE_STYLE_ORIGINAL
        binding.styleRoundedCheck.isActivated = backgroundstyle == BUBBLE_STYLE_ROUNDED
        binding.styleIosNewCheck.isActivated = backgroundstyle == BUBBLE_STYLE_IOS_NEW
        binding.styleIosCheck.isActivated = backgroundstyle == BUBBLE_STYLE_IOS

        binding.styleOriginalCheckauto.isActivated = backgroundstyle == BUBBLE_STYLE_ORIGINAL
        binding.styleRoundedCheckauto.isActivated = backgroundstyle == BUBBLE_STYLE_ROUNDED
        binding.styleIosNewCheckauto.isActivated = backgroundstyle == BUBBLE_STYLE_IOS_NEW
        binding.styleIosCheckauto.isActivated = backgroundstyle == BUBBLE_STYLE_IOS
    }

    private fun setupColors(primaryColor: Int) {
        binding.apply {
            val backgroundReceived = primaryColor
            val contrastColorReceived = backgroundReceived.getContrastColor()
            tvone.background.applyColorFilter(backgroundReceived)
            tvone.setTextColor(contrastColorReceived)

            backgroundTextColorOne = contrastColorReceived
            backgroundColorOne = primaryColor
        }
    }

    private fun Context.getColorIndexes(color: Int, defaultColor: Int): Pair<Int, Int> {
        if (color == defaultColor) {
            return getDefaultColorPair()
        }

        for (i in 0 until PRIMARY_COLORS_COUNT) {
            getColorsForIndex(i).indexOfFirst { color == it }.apply {
                if (this != -1) {
                    return Pair(i, this)
                }
            }
        }

        return getDefaultColorPair()
    }

    fun getDefaultColorPair() = Pair(DEFAULT_PRIMARY_COLOR_INDEX, DEFAULT_SECONDARY_COLOR_INDEX)


    private fun Context.getColorsForIndex(index: Int) = when (index) {
        0 -> getColors(R.array.md_reds)
        1 -> getColors(R.array.md_pinks)
        2 -> getColors(R.array.md_purples)
        3 -> getColors(R.array.md_deep_purples)
        4 -> getColors(R.array.md_indigos)
        5 -> getColors(R.array.md_blues)
        6 -> getColors(R.array.md_light_blues)
        7 -> getColors(R.array.md_cyans)
        8 -> getColors(R.array.md_teals)
        9 -> getColors(R.array.md_greens)
        10 -> getColors(R.array.md_light_greens)
        11 -> getColors(R.array.md_limes)
        12 -> getColors(R.array.md_yellows)
        13 -> getColors(R.array.md_ambers)
        14 -> getColors(R.array.md_oranges)
        15 -> getColors(R.array.md_deep_oranges)
        16 -> getColors(R.array.md_browns)
        17 -> getColors(R.array.md_blue_greys)
        18 -> getColors(R.array.md_greys)
        else -> throw RuntimeException("Invalid color id $index")
    }

    private fun Context.getColors(id: Int) = resources.getIntArray(id).toCollection(ArrayList())


}