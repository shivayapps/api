package messages.sms.text.chat.messanger.app.commons.adapters

import android.content.Context
import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.common.widget.BabyTextView
import messages.sms.text.chat.messanger.app.commons.extensions.baseConfig
import messages.sms.text.chat.messanger.app.commons.extensions.toast
import messages.sms.text.chat.messanger.app.commons.extensions.updateTextColors
import messages.sms.text.chat.messanger.app.util.Preferences

class ColorAdapter(
    private val prefs: Preferences,
    private val itemList: List<String>,
    private val colorList: List<Int>,
    private val context: Context,
    private val onItemClickListener: OnItemClickListener,
) : RecyclerView.Adapter<ColorAdapter.MyViewHolder>() {

//    private var selectedItemPosition: Int = RecyclerView.NO_POSITION

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.item_theme_layout, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.textViewItem.text = itemList[position]
        context.updateTextColors(holder.main)

        holder.llcolor.backgroundTintList =
            ColorStateList.valueOf(colorList[position % colorList.size])

        if (context.baseConfig.primaryColortheme.equals(colorList.get(position))) {
            //  selectedItemPosition = position
        } else {

        }


        if (position == prefs.selectedThemeNo.get() - 1) {

            holder.ivMain.visibility = View.VISIBLE
            holder.ivMainO.visibility = View.VISIBLE
            holder.ivMain.setColorFilter(context.baseConfig.primaryColor)

        } else {

            holder.ivMain.visibility = View.GONE
            holder.ivMainO.visibility = View.GONE
        }

        holder.itemView.setOnClickListener {


            if (position == 7) {
                holder.ivMain.context.toast(holder.ivMain.context.resources.getString(R.string.under_development))
                return@setOnClickListener
            }
            notifyDataSetChanged()

            onItemClickListener.onItemClick(position, colorList.get(position), itemList[position])
        }
    }

    override fun getItemCount(): Int = itemList.size

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textViewItem: BabyTextView = itemView.findViewById(R.id.textViewItem)
        val ivMain: ImageView = itemView.findViewById(R.id.ivMain)
        val ivMainO: ImageView = itemView.findViewById(R.id.ivMainO)
        val main: ConstraintLayout = itemView.findViewById(R.id.main)
        val llcolor: View = itemView.findViewById(R.id.llColor)
    }

    interface OnItemClickListener {
        fun onItemClick(position: Int, color: Int, name: String)
    }
}
