package messages.sms.text.chat.messanger.app.feature.settings.swipe

import io.reactivex.Observable
import messages.sms.text.chat.messanger.app.common.base.QkViewContract

interface SwipeActionsView : QkViewContract<SwipeActionsState> {

    enum class Action { LEFT, RIGHT }

    fun actionClicks(): Observable<Action>
    fun actionSelected(): Observable<Int>

    fun showSwipeActions(selected: Int)

}