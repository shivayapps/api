package messages.sms.text.chat.messanger.app.mapper

import android.database.Cursor
import messages.sms.text.chat.messanger.app.model.Contact

interface CursorToContact : Mapper<Cursor, Contact> {

    fun getContactsCursor(): Cursor?

}