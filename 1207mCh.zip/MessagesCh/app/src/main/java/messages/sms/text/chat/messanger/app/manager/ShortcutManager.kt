package messages.sms.text.chat.messanger.app.manager

interface ShortcutManager {

    fun updateBadge()

    fun updateShortcuts()

}