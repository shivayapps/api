package messages.sms.text.chat.messanger.app.common.widget

import android.content.Context
import android.util.AttributeSet
import androidx.emoji.widget.EmojiAppCompatTextView
import messages.sms.text.chat.messanger.app.common.util.TextViewStyler
import messages.sms.text.chat.messanger.app.injection.appComponent
//import messages.sms.text.chat.messanger.app.common.util.TextViewStyler
//import messages.sms.text.chat.messanger.app.injection.appComponent
import javax.inject.Inject

open class StyledTextView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null,
) : EmojiAppCompatTextView(context, attrs) {

    @Inject
    lateinit var textViewStyler: TextViewStyler

    var collapseEnabled: Boolean = false

    init {
        if (!isInEditMode) {
            appComponent.inject(this)
            textViewStyler.applyAttributes(this, attrs)
        } else {
            TextViewStyler.applyEditModeAttributes(this, attrs)
        }
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)

        if (collapseEnabled) {
            layout
                ?.takeIf { layout -> layout.lineCount > 0 }
                ?.let { layout -> layout.getEllipsisCount(layout.lineCount - 1) }
                ?.takeIf { ellipsisCount -> ellipsisCount > 0 }
                ?.let { ellipsisCount -> text.dropLast(ellipsisCount).lastIndexOf(',') }
                ?.takeIf { lastComma -> lastComma >= 0 }
                ?.let { lastComma ->
                    val remainingNames = text.drop(lastComma).count { c -> c == ',' }
                    text = "${text.take(lastComma)}, +$remainingNames"
                    textSize = textSize * 0.8f
                }
        }
    }

    fun setColors(textColor: Int, accentColor: Int, backgroundColor: Int) {
        setTextColor(textColor)
        setLinkTextColor(accentColor)
    }

    override fun setTextColor(color: Int) {
        super.setTextColor(color)
        setLinkTextColor(color)
    }

}