package messages.sms.text.chat.messanger.app.feature.compose

import io.realm.RealmResults
import messages.sms.text.chat.messanger.app.compat.SubscriptionInfoCompat
import messages.sms.text.chat.messanger.app.model.Attachment
import messages.sms.text.chat.messanger.app.model.Conversation
import messages.sms.text.chat.messanger.app.model.Message
import messages.sms.text.chat.messanger.app.model.Recipient

data class ComposeState(
    val hasError: Boolean = false,
    val editingMode: Boolean = false,
    val threadId: Long = 0,
    val selectedChips: List<Recipient> = ArrayList(),
    val sendAsGroup: Boolean = true,
    val conversationtitle: String = "",
    val loading: Boolean = false,
    val query: String = "",
    val searchSelectionId: Long = -1,
    val searchSelectionPosition: Int = 0,
    val searchResults: Int = 0,
    val messages: Pair<Conversation, RealmResults<Message>>? = null,
    val selectedMessages: Int = 0,
    val scheduled: Long = 0,
    val attachments: List<Attachment> = ArrayList(),
    val attaching: Boolean = false,
    val remaining: String = "",
    val subscription: SubscriptionInfoCompat? = null,
    val canSend: Boolean = false,
    val scrollToPosition: Long? = -1,
)