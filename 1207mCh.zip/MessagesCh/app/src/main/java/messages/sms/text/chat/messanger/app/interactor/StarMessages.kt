package messages.sms.text.chat.messanger.app.interactor

import io.reactivex.Flowable
import messages.sms.text.chat.messanger.app.repository.MessageRepository
import javax.inject.Inject

class StarMessages @Inject constructor(
    private val messageRepo: MessageRepository,
) : Interactor<List<Long>>() {

    override fun buildObservable(list: List<Long>): Flowable<*> {
        return Flowable.just(list.toLongArray())
            .doOnNext { messageIds -> messageRepo.starMessages(*messageIds) } // Star the messages
    }

}