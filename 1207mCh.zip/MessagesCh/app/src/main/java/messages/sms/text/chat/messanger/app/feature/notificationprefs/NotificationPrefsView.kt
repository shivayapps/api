package messages.sms.text.chat.messanger.app.feature.notificationprefs

import android.net.Uri
import io.reactivex.Observable
import io.reactivex.subjects.Subject
import messages.sms.text.chat.messanger.app.common.base.QkView
import messages.sms.text.chat.messanger.app.common.widget.PreferenceView

interface NotificationPrefsView : QkView<NotificationPrefsState> {

    val preferenceClickIntent: Subject<PreferenceView>
    val previewModeSelectedIntent: Subject<Int>
    val ringtoneSelectedIntent: Observable<String>
    val actionsSelectedIntent: Subject<Int>

    fun showPreviewModeDialog()
    fun showRingtonePicker(default: Uri?)
    fun showActionDialog(selected: Int)
}
