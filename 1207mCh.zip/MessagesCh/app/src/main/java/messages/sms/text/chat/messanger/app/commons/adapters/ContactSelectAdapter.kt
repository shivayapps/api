package messages.sms.text.chat.messanger.app.commons.adapters

import android.util.Log
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import messages.sms.text.chat.messanger.app.common.base.QkAdapter
import messages.sms.text.chat.messanger.app.common.base.QkViewHolder
import messages.sms.text.chat.messanger.app.common.util.extensions.forwardTouches
import messages.sms.text.chat.messanger.app.databinding.ContactListSelectBinding
import messages.sms.text.chat.messanger.app.feature.compose.editing.PhoneNumberAdapter
import messages.sms.text.chat.messanger.app.model.Contact
import messages.sms.text.chat.messanger.app.model.PhoneNumber

class ContactSelectAdapter : QkAdapter<Contact, ContactListSelectBinding>() {
    private val numbersViewPool = RecyclerView.RecycledViewPool()

    init {
        // This is how we access the threadId for the swipe actions
        setHasStableIds(true)
    }

    public fun checkedContact(): List<Contact> {
        val selectedContacts = data.filter { isSelected(it.lookupKey) }
//        val selectedContacts = data.filter { it.starred }
        return selectedContacts
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): QkViewHolder<ContactListSelectBinding> {
        return QkViewHolder(parent, ContactListSelectBinding::inflate).apply {
            binding.numbers.setRecycledViewPool(numbersViewPool)
            binding.numbers.adapter = PhoneNumberAdapter()
            binding.numbers.forwardTouches(binding.root)

            binding.root.setOnClickListener {
                val contact = getItem(adapterPosition)
                if (toggleSelection(contact.lookupKey)) {
                    binding.root.isActivated = isSelected(contact.lookupKey)
                    if (isSelected(contact.lookupKey)) {
                        binding.cbSelect.isChecked = true
                    } else {
                        binding.cbSelect.isChecked = false
                    }
                }

//                toggleSelection(contact.hashCode().toLong(), false)
//                binding.root.isActivated = isSelected(contact.hashCode().toLong())
////                val item = getItem(adapterPosition)
//                if (isSelected(contact.hashCode().toLong())) {
//                    binding.cbSelect.isChecked = true
//                } else {
//                    binding.cbSelect.isChecked = false
//                }
//                (it.context as? MainActivity)?.onContactClick(item)
            }

//            binding.root.setOnLongClickListener {
//                val item = data.filter { isSelected(it.hashCode().toLong()) }
////                (it.context as? MainActivity)?.onContactLongClick(item)
//                true
//            }


        }
    }

    override fun onBindViewHolder(holder: QkViewHolder<ContactListSelectBinding>, position: Int) {
        val contact = getItem(position) ?: return
        var numbersList = ArrayList<PhoneNumber>()
        try {
            numbersList = ArrayList(contact.numbers)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        holder.binding.root.isActivated = isSelected(contact.lookupKey)
        if (isSelected(contact.lookupKey)) {
            holder.binding.cbSelect.isChecked = true
        } else {
            holder.binding.cbSelect.isChecked = false
        }
//        if (isSelection()) {
//            holder.binding.cbSelect.beVisible()
//        } else {
//            holder.binding.cbSelect.beGone()
//        }
//        holder.binding.avatars.recipientData = listOf(
//            RecipientData(
//                address = numbersList.firstOrNull()?.address ?: "",
//                contact = ContactData(
//                    lookupKey = contact.lookupKey,
//                    numbers = contact.numbers,
//                    name = contact.name,
//                    photoUri = contact.photoUri,
//                    starred = contact.starred,
//                    lastUpdate = contact.lastUpdate
//                )
//            )
//        )
        Log.e("GroupsActivity", "lookupKey:${contact.lookupKey}")
        try {
            holder.binding.title.text = contact.name
        } catch (e: Exception) {
            e.printStackTrace()
        }
        holder.binding.subtitle.isVisible = false
        holder.binding.numbers.isVisible = true
        (holder.binding.numbers.adapter as PhoneNumberAdapter).data = numbersList
    }

//    override fun areContentsTheSame(old: ContactData, new: Contact): Boolean {
//        return old.name == new.name && old.numbers == new.numbers
//    }
//
//    override fun areItemsTheSame(old: ContactData, new: Contact): Boolean {
//        return old.name == new.name && old.numbers == new.numbers
//    }

}
