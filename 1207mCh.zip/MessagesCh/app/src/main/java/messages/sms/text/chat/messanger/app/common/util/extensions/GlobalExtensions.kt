package messages.sms.text.chat.messanger.app.common.util.extensions

fun now(): Long {
    return System.currentTimeMillis()
}
