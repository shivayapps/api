package messages.sms.text.chat.messanger.app.password

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.commons.extensions.baseConfig
import messages.sms.text.chat.messanger.app.commons.helpers.Config

class AddPhoneNumberDialog(
    private val config: Config,
    private val context: Context,
    private val addphonenumberlistener: AddPhoneNumberListener,
) {

    fun show() {
        // Inflate the custom layout
        val inflater = LayoutInflater.from(context)
        val dialogView = inflater.inflate(R.layout.dialog_add_number, null)

        // Initialize views
        val dialogInput = dialogView.findViewById<EditText>(R.id.dialog_input)
        val dialogCancelButton = dialogView.findViewById<Button>(R.id.dialog_cancel_button)
        val dialogOkButton = dialogView.findViewById<Button>(R.id.dialog_ok_button)
        //   dialogInput.setText(config.privateBoxName)

        dialogCancelButton.setTextColor(Color.BLACK)
        dialogOkButton.setTextColor(context.baseConfig.primaryColor)

        val alertDialog = AlertDialog.Builder(context)
            .setTitle("Add phone number")
            .setView(dialogView)
            .create()

        alertDialog.window?.setBackgroundDrawableResource(R.drawable.rounded_dialog)

        alertDialog.setOnShowListener {
            val window = alertDialog.window
            val layoutParams = window?.attributes

            val displayMetrics = context.resources.displayMetrics
            val dialogWidth = (displayMetrics.widthPixels * 0.85).toInt() // 85% of screen width

            layoutParams?.width = dialogWidth
            window?.attributes = layoutParams
        }

        // Set click listeners for custom buttons
        dialogCancelButton.setOnClickListener {
            alertDialog.dismiss()
        }

        dialogOkButton.setOnClickListener {
            val inputText = dialogInput.text.toString()
            if (inputText.isNotEmpty()) {
                addphonenumberlistener.addNumber(inputText)
                alertDialog.dismiss()
            } else {
                Toast.makeText(context, "You cannot save an empty field", Toast.LENGTH_LONG).show()
            }
        }

        alertDialog.show()
    }

    interface AddPhoneNumberListener {
        fun addNumber(newString: String)
    }
}

















