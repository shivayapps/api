package messages.sms.text.chat.messanger.app.common.widget

import android.app.Activity
import android.content.DialogInterface
import androidx.appcompat.app.AlertDialog
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.databinding.FieldDialogBinding

class FieldDialog(
    context: Activity,
    hint: String,
    listener: (String) -> Unit,
) : AlertDialog(context, R.style.CustomFieldDialogTheme) {

    private val binding = FieldDialogBinding.inflate(context.layoutInflater)

    init {
        binding.field.hint = hint

        setView(binding.root)
        setButton(
            DialogInterface.BUTTON_NEUTRAL,
            context.getString(R.string.button_cancel)
        ) { _, _ -> }
        setButton(
            DialogInterface.BUTTON_NEGATIVE,
            context.getString(R.string.button_delete)
        ) { _, _ -> listener("") }
        setButton(
            DialogInterface.BUTTON_POSITIVE,
            context.getString(R.string.button_save)
        ) { _, _ ->
            listener(binding.field.text.toString())
        }

    }

    fun setText(text: String): FieldDialog {
        binding.field.setText(text)
        return this
    }

}
