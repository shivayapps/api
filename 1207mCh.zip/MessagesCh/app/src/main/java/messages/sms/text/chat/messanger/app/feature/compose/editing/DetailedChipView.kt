package messages.sms.text.chat.messanger.app.feature.compose.editing

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.view.animation.AlphaAnimation
import androidx.constraintlayout.widget.ConstraintLayout
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.common.util.Colors
import messages.sms.text.chat.messanger.app.common.util.extensions.dpToPx
import messages.sms.text.chat.messanger.app.common.util.extensions.setBackgroundTint
import messages.sms.text.chat.messanger.app.common.util.extensions.setTint
import messages.sms.text.chat.messanger.app.common.util.extensions.viewBinding
import messages.sms.text.chat.messanger.app.databinding.ContactChipDetailedBinding
import messages.sms.text.chat.messanger.app.injection.appComponent
import messages.sms.text.chat.messanger.app.model.Recipient
import javax.inject.Inject

class DetailedChipView(context: Context, attrs: AttributeSet? = null) :
    ConstraintLayout(context, attrs) {

    @Inject
    lateinit var colors: Colors

    private val binding = viewBinding(ContactChipDetailedBinding::inflate)

    init {
        if (!isInEditMode) {
            appComponent.inject(this)
            visibility = View.GONE
        }

        setOnClickListener { hide() }
        setBackgroundResource(R.drawable.rounded_rectangle_2dp)

        elevation = 8.dpToPx(context).toFloat()
//        updateLayoutParams<LinearLayout.LayoutParams> { setMargins(8.dpToPx(context) ) }

        isFocusable = true
        isFocusableInTouchMode = true
    }

    fun setRecipient(recipient: Recipient) {
        binding.avatar.setRecipient(recipient)
        binding.name.text = recipient.contact?.name?.takeIf { it.isNotBlank() } ?: recipient.address
        binding.info.text = recipient.address

        colors.theme(recipient).let { theme ->
            setBackgroundTint(theme.theme)
            binding.name.setTextColor(theme.textPrimary)
            binding.info.setTextColor(theme.textTertiary)
            binding.delete.setTint(theme.textPrimary)
        }
    }

    fun show() {
        startAnimation(AlphaAnimation(0f, 1f).apply { duration = 200 })

        visibility = View.VISIBLE
        requestFocus()
        isClickable = true
    }

    fun hide() {
        startAnimation(AlphaAnimation(1f, 0f).apply { duration = 200 })

        visibility = View.GONE
        clearFocus()
        isClickable = false
    }

    fun setOnDeleteListener(listener: (View) -> Unit) {
        binding.delete.setOnClickListener(listener)
    }

}

