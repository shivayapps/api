package messages.sms.text.chat.messanger.app.feature.scheduled

import android.content.Context
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.plusAssign
import io.reactivex.rxkotlin.withLatestFrom
import io.reactivex.schedulers.Schedulers
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.common.Navigator
import messages.sms.text.chat.messanger.app.common.base.QkViewModel
import messages.sms.text.chat.messanger.app.common.util.ClipboardUtils
import messages.sms.text.chat.messanger.app.common.util.extensions.makeToast
import messages.sms.text.chat.messanger.app.interactor.SendScheduledMessage
import messages.sms.text.chat.messanger.app.repository.ScheduledMessageRepository
import javax.inject.Inject

class ScheduledViewModel @Inject constructor(
    private val context: Context,
    private val navigator: Navigator,
    private val scheduledMessageRepo: ScheduledMessageRepository,
    private val sendScheduledMessage: SendScheduledMessage,
) : QkViewModel<ScheduledView, ScheduledState>(
    ScheduledState(
        scheduledMessages = scheduledMessageRepo.getScheduledMessages()
    )
) {

    override fun bindView(view: ScheduledView) {
        super.bindView(view)

        view.messageClickIntent
            .autoDispose(view.scope())
            .subscribe { view.showMessageOptions() }

        view.messageMenuIntent
            .withLatestFrom(view.messageClickIntent) { itemId, messageId ->
                when (itemId) {
                    0 -> sendScheduledMessage.execute(messageId)
                    1 -> scheduledMessageRepo.getScheduledMessage(messageId)?.let { message ->
                        ClipboardUtils.copy(context, message.body)
                        context.makeToast(R.string.toast_copied)
                    }

                    2 -> {
                        val deleteSubscription = Observable.fromCallable {
                            scheduledMessageRepo.deleteScheduledMessage(messageId)
                        }
                            .subscribeOn(Schedulers.io())
                            .observeOn(AndroidSchedulers.mainThread())
                            .subscribe({
                                // Handle completion, e.g., log success or update UI
                            }, {
                                // Handle error, e.g., log or show error message
                            })

                        disposables += deleteSubscription
                    }
                }
                Unit
            }
            .autoDispose(view.scope())
            .subscribe()

        view.composeIntent
            .autoDispose(view.scope())
            .subscribe { navigator.showCompose() }


    }
}
