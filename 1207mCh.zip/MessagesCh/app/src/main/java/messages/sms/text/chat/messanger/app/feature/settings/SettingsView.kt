package messages.sms.text.chat.messanger.app.feature.settings

import io.reactivex.Observable
import messages.sms.text.chat.messanger.app.common.base.QkViewContract
import messages.sms.text.chat.messanger.app.common.widget.PreferenceView

interface SettingsView : QkViewContract<SettingsState> {
    fun preferenceClicks(): Observable<PreferenceView>
    fun nightModeSelected(): Observable<Int>
    fun nightStartSelected(): Observable<Pair<Int, Int>>
    fun nightEndSelected(): Observable<Pair<Int, Int>>
    fun textSizeSelected(): Observable<Int>
    fun sendDelaySelected(): Observable<Int>
    fun signatureSet(): Observable<String>
    fun mmsSizeSelected(): Observable<Int>

    fun showNightModeDialog()
    fun showStartTimePicker(hour: Int, minute: Int)
    fun showEndTimePicker(hour: Int, minute: Int)
    fun showTextSizePicker()
    fun showDelayDurationDialog()
    fun showSignatureDialog(signature: String)
    fun showMmsSizePicker()
    fun showSwipeActions()
    fun showThemePicker()
}
