package  messages.sms.text.chat.messanger.app.ads

import android.app.Activity
import android.util.Log
import messages.sms.text.chat.messanger.app.ads.GoogleInterAdManager.loadAdGeneral


object MainInterAdManager {
    var isLoading = false
    var isGeneralLoading = false
    var showInterTime: Long = 0
    var adinterval: Long = 0
    var enablead: Boolean = false
    var interex1: String = ""
    var interex2: String = ""

    fun loadManageAppsInter(activity: Activity) {
        if (isLoading) return
        isLoading = true
        GoogleInterAdManager.loadManageAppsInter(activity)
    }

    fun loadGeneralInter(activity: Activity) {
        val adId = activity.getAppPermissionInter()

        Log.e("LLL_Splash", "getAppPermissionInter: $adId")

        if (!AdsPreferences(activity).adsEnable || AdsPreferences(activity).isPro) return

        loadAdGeneral(activity, adId)

    }

    fun showGeneralInterAds(activity: Activity, forward: Boolean, dismissCallback: () -> Unit) {
        GoogleInterAdManager.showGeneralInterAds(activity, dismissCallback, forward)
    }

    /*  fun loadGeneralInter(activity: Activity) {
          if (isGeneralLoading && showInterTime != 0L) {
              if (!activity.AdsPreferences(context).adsEnable || adinterval == 0L || !enablead) return
              val diff = Date().time - showInterTime
              Log.e("LLL_Splash", "loadBackPressInter: $diff")
              if (diff < (adinterval * 1000)) {
                  return
              }
              if (isGeneralLoading2) return
              isGeneralLoading2 = true
              val adId = if (activity.isFirstTimeAppOpen()) interex1 else interex2
              Log.e("LLL_Splash", "loadBackPressInter: $adId")
              GoogleInterAdManager.loadAdGeneral(activity, adId)
          }

          if (isGeneralLoading) return
          isGeneralLoading = true
          GoogleInterAdManager.loadAdGeneral(activity, activity.getAppBackPressedInter())
      }*/


    fun showManageAppsInter(activity: Activity, dismissCallback: () -> Unit) {
        GoogleInterAdManager.showManageAppsInter(activity, dismissCallback)
    }



    fun showGeneralInter(activity: Activity, dismissCallback: () -> Unit) {
        GoogleInterAdManager.showGeneralInter(activity, dismissCallback)
    }


    fun isLoadingAds() = isLoading

    fun onDestroy() {
        isGeneralLoading = false
        isLoading = false
        GoogleInterAdManager.onDestroy()
        showInterTime = 0
        adinterval = 0
        enablead = false
        interex1 = ""
        interex2 = ""
    }
}