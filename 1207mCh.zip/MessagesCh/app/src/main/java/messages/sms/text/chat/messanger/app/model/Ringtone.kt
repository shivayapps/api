package messages.sms.text.chat.messanger.app.model

data class Ringtone(
    val name: String,
    val image: Int,
    val sound: Int,
)