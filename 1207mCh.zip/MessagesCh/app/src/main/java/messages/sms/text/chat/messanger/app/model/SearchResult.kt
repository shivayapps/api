package messages.sms.text.chat.messanger.app.model

data class SearchResult(val query: String, val conversation: Conversation, val messages: Int)