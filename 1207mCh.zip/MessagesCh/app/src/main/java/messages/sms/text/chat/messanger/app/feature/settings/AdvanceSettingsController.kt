package messages.sms.text.chat.messanger.app.feature.settings

import android.animation.ObjectAnimator
import android.app.TimePickerDialog
import android.content.Context
import android.os.Build
import android.text.format.DateFormat
import android.view.View
import android.widget.ScrollView
import com.bluelinelabs.conductor.RouterTransaction
import com.jakewharton.rxbinding2.view.clicks
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.common.MenuItem
import messages.sms.text.chat.messanger.app.common.QkChangeHandler
import messages.sms.text.chat.messanger.app.common.QkDialog
import messages.sms.text.chat.messanger.app.common.base.QkController
import messages.sms.text.chat.messanger.app.common.util.Colors
import messages.sms.text.chat.messanger.app.common.util.extensions.animateLayoutChanges
import messages.sms.text.chat.messanger.app.common.widget.FieldDialog
import messages.sms.text.chat.messanger.app.common.widget.PreferenceView
import messages.sms.text.chat.messanger.app.common.widget.QkSwitch
import messages.sms.text.chat.messanger.app.commons.extensions.beInvisible
import messages.sms.text.chat.messanger.app.commons.extensions.beVisible
import messages.sms.text.chat.messanger.app.databinding.AdvanceSettingsControllerBinding
import messages.sms.text.chat.messanger.app.feature.settings.swipe.SwipeActionsController
import messages.sms.text.chat.messanger.app.feature.themepicker.ThemePickerController
import messages.sms.text.chat.messanger.app.injection.appComponent
import messages.sms.text.chat.messanger.app.repository.SyncRepository
import javax.inject.Inject

class AdvanceSettingsController :
    QkController<SettingsView, SettingsState, SettingsPresenter, AdvanceSettingsControllerBinding>(
        AdvanceSettingsControllerBinding::inflate
    ), SettingsView {

    @Inject
    lateinit var context: Context

    @Inject
    lateinit var colors: Colors

    @Inject
    lateinit var nightModeDialog: QkDialog

    @Inject
    lateinit var textSizeDialog: QkDialog

    @Inject
    lateinit var sendDelayDialog: QkDialog

    @Inject
    lateinit var mmsSizeDialog: QkDialog

    @Inject
    override lateinit var presenter: SettingsPresenter

    private val signatureDialog: FieldDialog by lazy {
        FieldDialog(
            activity!!,
            context.getString(R.string.settings_signature_title),
            signatureSubject::onNext
        )
    }

    private val startTimeSelectedSubject: Subject<Pair<Int, Int>> = PublishSubject.create()
    private val endTimeSelectedSubject: Subject<Pair<Int, Int>> = PublishSubject.create()
    private val signatureSubject: Subject<String> = PublishSubject.create()

    private val progressAnimator by lazy {
        ObjectAnimator.ofInt(
            binding.syncingProgress,
            "progress",
            0,
            0
        )
    }

    init {
        appComponent.inject(this)
        retainViewMode = RetainViewMode.RETAIN_DETACH

        colors.themeObservable()
            .autoDispose(scope())
            .subscribe { activity?.recreate() }
    }

    override fun onViewCreated() {
        binding.preferences.postDelayed({ binding.preferences.animateLayoutChanges = true }, 100)

        when (Build.VERSION.SDK_INT >= 29) {
            true -> nightModeDialog.adapter.setData(R.array.night_modes)
            false -> nightModeDialog.adapter.data =
                context.resources.getStringArray(R.array.night_modes)
                    .mapIndexed { index, title -> MenuItem(title, index) }
                    .drop(1)
        }
        textSizeDialog.adapter.setData(R.array.text_sizes)
        sendDelayDialog.adapter.setData(R.array.delayed_sending_labels)
        mmsSizeDialog.adapter.setData(R.array.mms_sizes, R.array.mms_sizes_ids)

    }

    override fun onAttach(view: View) {
        super.onAttach(view)
        presenter.bindIntents(this)
        setTitle(R.string.advance)
//        showBackButton(true)
    }

    override fun preferenceClicks(): Observable<PreferenceView> =
        (0 until binding.preferences.childCount)
            .map { index -> binding.preferences.getChildAt(index) }
            .mapNotNull { view -> view as? PreferenceView }
            .map { preference -> preference.clicks().map { preference } }
            .let { preferences -> Observable.merge(preferences) }


    override fun nightModeSelected(): Observable<Int> = nightModeDialog.adapter.menuItemClicks

    override fun nightStartSelected(): Observable<Pair<Int, Int>> = startTimeSelectedSubject

    override fun nightEndSelected(): Observable<Pair<Int, Int>> = endTimeSelectedSubject

    override fun textSizeSelected(): Observable<Int> = textSizeDialog.adapter.menuItemClicks

    override fun sendDelaySelected(): Observable<Int> = sendDelayDialog.adapter.menuItemClicks

    override fun signatureSet(): Observable<String> = signatureSubject

    override fun mmsSizeSelected(): Observable<Int> = mmsSizeDialog.adapter.menuItemClicks

    override fun render(state: SettingsState) {
//        binding.theme.widget<View>().setBackgroundTint(state.theme)
//        binding.night.summary = state.nightModeSummary
        nightModeDialog.adapter.selectedItem = state.nightModeId
//        binding.nightStart.setVisible(state.nightModeId == AdsPreferences.NIGHT_MODE_AUTO)
//        binding.nightStart.summary = state.nightStart
//        binding.nightEnd.setVisible(state.nightModeId == AdsPreferences.NIGHT_MODE_AUTO)
//        binding.nightEnd.summary = state.nightEnd

//        binding.black.setVisible(state.nightModeId != AdsPreferences.NIGHT_MODE_OFF)
//        binding.black.widget<QkSwitch>().isChecked = state.black

        binding.autoEmoji.widget<QkSwitch>().isChecked = state.autoEmojiEnabled

        binding.delayed.summary = state.sendDelaySummary
        sendDelayDialog.adapter.selectedItem = state.sendDelayId

        binding.delivery.widget<QkSwitch>().isChecked = state.deliveryEnabled

//        binding.signature.summary = state.signature.takeIf { it.isNotBlank() }
//            ?: context.getString(R.string.settings_signature_summary)

//        binding.textSize.summary = state.textSizeSummary
//        textSizeDialog.adapter.selectedItem = state.textSizeId

//        binding.autoColor.widget<QkSwitch>().isChecked = state.autoColor

//        binding.systemFont.widget<QkSwitch>().isChecked = state.systemFontEnabled

        binding.unicode.widget<QkSwitch>().isChecked = state.stripUnicodeEnabled
        binding.mobileOnly.widget<QkSwitch>().isChecked = state.mobileOnly
        binding.longAsMms.widget<QkSwitch>().isChecked = state.longAsMms

        binding.mmsSize.summary = state.maxMmsSizeSummary
        mmsSizeDialog.adapter.selectedItem = state.maxMmsSizeId

        when (state.syncProgress) {
            is SyncRepository.SyncProgress.Idle -> binding.syncingProgress.beInvisible()

            is SyncRepository.SyncProgress.Running -> {
                binding.contentView.fullScroll(ScrollView.FOCUS_DOWN);
                binding.syncingProgress.beVisible()
                binding.syncingProgress.max = state.syncProgress.max
                progressAnimator.apply {
                    setIntValues(
                        binding.syncingProgress.progress,
                        state.syncProgress.progress
                    )
                }.start()
                binding.syncingProgress.isIndeterminate = state.syncProgress.indeterminate
            }
        }
    }

    override fun showNightModeDialog() = nightModeDialog.show(activity!!)

    override fun showStartTimePicker(hour: Int, minute: Int) {
        TimePickerDialog(activity, TimePickerDialog.OnTimeSetListener { _, newHour, newMinute ->
            startTimeSelectedSubject.onNext(Pair(newHour, newMinute))
        }, hour, minute, DateFormat.is24HourFormat(activity)).show()
    }

    override fun showEndTimePicker(hour: Int, minute: Int) {
        TimePickerDialog(activity, TimePickerDialog.OnTimeSetListener { _, newHour, newMinute ->
            endTimeSelectedSubject.onNext(Pair(newHour, newMinute))
        }, hour, minute, DateFormat.is24HourFormat(activity)).show()
    }

    override fun showTextSizePicker() = textSizeDialog.show(activity!!)

    override fun showDelayDurationDialog() = sendDelayDialog.show(activity!!)

    override fun showSignatureDialog(signature: String) = signatureDialog.setText(signature).show()

    override fun showMmsSizePicker() = mmsSizeDialog.show(activity!!)

    override fun showSwipeActions() {
        router.pushController(
            RouterTransaction.with(SwipeActionsController())
                .pushChangeHandler(QkChangeHandler())
                .popChangeHandler(QkChangeHandler())
        )
    }

    override fun showThemePicker() {
        router.pushController(
            RouterTransaction.with(ThemePickerController())
                .pushChangeHandler(QkChangeHandler())
                .popChangeHandler(QkChangeHandler())
        )
    }

}