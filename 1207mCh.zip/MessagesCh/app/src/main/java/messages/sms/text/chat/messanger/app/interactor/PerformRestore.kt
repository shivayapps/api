package messages.sms.text.chat.messanger.app.interactor

import io.reactivex.Flowable
import messages.sms.text.chat.messanger.app.repository.BackupRepository
import javax.inject.Inject

class PerformRestore @Inject constructor(
    private val backupRepo: BackupRepository,
) : Interactor<String>() {

    override fun buildObservable(params: String): Flowable<*> {
        return Flowable.just(params)
            .doOnNext(backupRepo::performRestore)
    }

}
