package messages.sms.text.chat.messanger.app.model

import android.telephony.PhoneNumberUtils
import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import java.util.Locale

open class Recipient(
    @PrimaryKey var id: Long = 0,
    var address: String = "",
    var contact: Contact? = null,
    var lastUpdate: Long = 0,
) : RealmObject() {

    /**
     * Return a string that can be displayed to represent the name of this contact
     */
    fun getDisplayName(): String = contact?.name?.takeIf { it.isNotBlank() }
        ?: PhoneNumberUtils.formatNumber(
            address,
            Locale.getDefault().country
        ) // TODO: Use our own PhoneNumberUtils
        ?: address

}

data class RecipientData(
    @PrimaryKey var id: Long = 0,
    var address: String = "",
    var contact: ContactData? = null,
    var lastUpdate: Long = 0,
) {

    fun getDisplayName(): String = contact?.name?.takeIf { it.isNotBlank() }
        ?: PhoneNumberUtils.formatNumber(
            address,
            Locale.getDefault().country
        ) // TODO: Use our own PhoneNumberUtils
        ?: address

}