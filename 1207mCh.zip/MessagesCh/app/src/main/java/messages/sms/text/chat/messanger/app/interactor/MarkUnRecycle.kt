package messages.sms.text.chat.messanger.app.interactor

import io.reactivex.Flowable
import messages.sms.text.chat.messanger.app.repository.ConversationRepository
import javax.inject.Inject

class MarkUnRecycle @Inject constructor(private val conversationRepo: ConversationRepository) :
    Interactor<List<Long>>() {

    override fun buildObservable(params: List<Long>): Flowable<*> {
        return Flowable.just(params.toLongArray())
            .doOnNext { threadIds -> conversationRepo.markUnRecycle(*threadIds) }
    }

}