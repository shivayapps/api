package  messages.sms.text.chat.messanger.app.ads

import android.content.Context
import android.view.ViewGroup

object MainNativeAdManager {
    var isLoading = false
    var isExitShown = false

    /* fun loadExitNative(context: Context) {
         if (isLoading) return
         isLoading = true
         isExitShown = false
         GoogleNativeAdManager.loadExitNative(context)
     }*/

    fun showNative(mContext: Context, parentView: ViewGroup) {
        if (!isExitShown) {
            mContext.firebaseAnalyticsHandler.logMessages(
                app_native_created,
                mContext.getActivityName()
            )
            mContext.firebaseAnalyticsHandler.logMessages(
                app_ad_native_shown,
                mContext.getActivityName()
            )
        }
        isExitShown = true
        GoogleNativeAdManager.showNative(mContext, parentView)
    }


    fun onDestroy() {
        isLoading = false
        GoogleNativeAdManager.onDestroy()
        isExitShown = false
    }

    fun isExitNativeLoaded(): Boolean {
        if (GoogleNativeAdManager.isExitAdLoaded())
            return true

        return false
    }
}