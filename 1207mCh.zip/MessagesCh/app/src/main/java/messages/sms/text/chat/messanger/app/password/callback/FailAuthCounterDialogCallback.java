package messages.sms.text.chat.messanger.app.password.callback;


import messages.sms.text.chat.messanger.app.password.dialog.FingerprintDialog;

public interface FailAuthCounterDialogCallback {
    void onTryLimitReached(FingerprintDialog fingerprintDialog);
}
