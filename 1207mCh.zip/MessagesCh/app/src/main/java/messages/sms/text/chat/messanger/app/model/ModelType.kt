package messages.sms.text.chat.messanger.app.model

interface ModelType {
    val CONVERSATION_TYPE: Int
        get() = 1

    val AD_TYPE: Int
        get() = 2

    fun getType(): Int
}