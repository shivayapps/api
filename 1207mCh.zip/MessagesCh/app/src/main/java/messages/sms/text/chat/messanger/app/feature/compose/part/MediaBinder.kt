package messages.sms.text.chat.messanger.app.feature.compose.part

import android.content.Context
import com.bumptech.glide.Glide
import messages.sms.text.chat.messanger.app.common.base.QkViewHolder
import messages.sms.text.chat.messanger.app.common.util.Colors
import messages.sms.text.chat.messanger.app.common.util.extensions.setVisible
import messages.sms.text.chat.messanger.app.common.widget.BubbleImageView
import messages.sms.text.chat.messanger.app.databinding.MmsPreviewListItemBinding
import messages.sms.text.chat.messanger.app.extensions.isImage
import messages.sms.text.chat.messanger.app.extensions.isVideo
import messages.sms.text.chat.messanger.app.model.Message
import messages.sms.text.chat.messanger.app.model.MmsPart

import javax.inject.Inject

class MediaBinder @Inject constructor(
    colors: Colors,
    private val context: Context,
) : PartBinder<MmsPreviewListItemBinding>(MmsPreviewListItemBinding::inflate) {

    override var theme = colors.theme()

    override fun canBindPart(part: MmsPart) = part.isImage() || part.isVideo()

    override fun bindPartInternal(
        holder: QkViewHolder<MmsPreviewListItemBinding>,
        part: MmsPart,
        message: Message,
        canGroupWithPrevious: Boolean,
        canGroupWithNext: Boolean,
    ) {
        holder.binding.video.setVisible(part.isVideo())
        holder.binding.root.setOnClickListener { clicks.onNext(part.id) }

        holder.binding.thumbnail.bubbleStyle = when {
            !canGroupWithPrevious && canGroupWithNext -> if (message.isMe()) BubbleImageView.Style.OUT_FIRST else BubbleImageView.Style.IN_FIRST
            canGroupWithPrevious && canGroupWithNext -> if (message.isMe()) BubbleImageView.Style.OUT_MIDDLE else BubbleImageView.Style.IN_MIDDLE
            canGroupWithPrevious && !canGroupWithNext -> if (message.isMe()) BubbleImageView.Style.OUT_LAST else BubbleImageView.Style.IN_LAST
            else -> BubbleImageView.Style.ONLY
        }

        Glide.with(context).load(part.getUri()).fitCenter().into(holder.binding.thumbnail)
    }

}