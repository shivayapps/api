package messages.sms.text.chat.messanger.app.feature.themepicker.injection

import dagger.Subcomponent
import messages.sms.text.chat.messanger.app.feature.themepicker.ThemePickerController
import messages.sms.text.chat.messanger.app.injection.scope.ControllerScope

@ControllerScope
@Subcomponent(modules = [ThemePickerModule::class])
interface ThemePickerComponent {

    fun inject(controller: ThemePickerController)

    @Subcomponent.Builder
    interface Builder {
        fun themePickerModule(module: ThemePickerModule): Builder
        fun build(): ThemePickerComponent
    }

}