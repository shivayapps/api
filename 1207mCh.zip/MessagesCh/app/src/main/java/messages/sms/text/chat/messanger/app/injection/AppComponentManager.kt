package messages.sms.text.chat.messanger.app.injection


import messages.sms.text.chat.messanger.app.common.QKApplication


internal lateinit var appComponent: AppComponent
    private set

internal object AppComponentManager {

    fun init(application: QKApplication) {
        appComponent = DaggerAppComponent.builder()
            .appModule(AppModule(application))
            .build()
    }

}