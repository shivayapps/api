package messages.sms.text.chat.messanger.app.experiment

data class Variant<T>(val key: String, val value: T)