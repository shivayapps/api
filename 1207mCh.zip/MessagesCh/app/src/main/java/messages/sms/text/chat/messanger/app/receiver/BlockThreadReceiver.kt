package messages.sms.text.chat.messanger.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import dagger.android.AndroidInjection
import messages.sms.text.chat.messanger.app.blocking.BlockingClient
import messages.sms.text.chat.messanger.app.interactor.MarkBlocked
import messages.sms.text.chat.messanger.app.repository.ConversationRepository
import messages.sms.text.chat.messanger.app.util.Preferences
import javax.inject.Inject

class BlockThreadReceiver : BroadcastReceiver() {

    @Inject
    lateinit var blockingClient: BlockingClient

    @Inject
    lateinit var conversationRepo: ConversationRepository

    @Inject
    lateinit var markBlocked: MarkBlocked

    @Inject
    lateinit var prefs: Preferences

    override fun onReceive(context: Context, intent: Intent) {
        AndroidInjection.inject(this, context)

        val pendingResult = goAsync()
        val threadId = intent.getLongExtra("threadId", 0)
        val conversation = conversationRepo.getConversation(threadId)!!
        val blockingManager = prefs.blockingManager.get()

        blockingClient
            .block(conversation.recipients.map { it.address })
            .andThen(
                markBlocked.buildObservable(
                    MarkBlocked.Params(
                        listOf(threadId),
                        blockingManager,
                        null
                    )
                )
            )
            .subscribe { pendingResult.finish() }
    }

}
