package messages.sms.text.chat.messanger.app.model

data class BackupFile(
    val path: String,
    val date: Long,
    val messages: Int,
    val size: Long,
)
