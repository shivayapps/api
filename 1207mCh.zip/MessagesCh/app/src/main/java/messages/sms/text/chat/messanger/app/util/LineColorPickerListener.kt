package messages.sms.text.chat.messanger.app.util

fun interface LineColorPickerListener {
    fun colorChanged(index: Int, color: Int)
}
