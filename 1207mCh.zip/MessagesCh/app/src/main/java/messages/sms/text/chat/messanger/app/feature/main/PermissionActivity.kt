package messages.sms.text.chat.messanger.app.feature.main

import android.app.Activity
import android.app.role.RoleManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.provider.Telephony
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import androidx.browser.customtabs.CustomTabColorSchemeParams
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import dagger.android.AndroidInjection
import messages.sms.text.chat.messanger.app.ads.MainInterAdManager
import messages.sms.text.chat.messanger.app.common.base.QkThemedActivity
import messages.sms.text.chat.messanger.app.common.util.extensions.viewBinding
import messages.sms.text.chat.messanger.app.commons.dialog.PermissionRequiredDialog
import messages.sms.text.chat.messanger.app.commons.extensions.config
import messages.sms.text.chat.messanger.app.commons.extensions.getPermissionString
import messages.sms.text.chat.messanger.app.commons.extensions.hasPermission
import messages.sms.text.chat.messanger.app.commons.extensions.isPackageInstalled
import messages.sms.text.chat.messanger.app.commons.helpers.PERMISSION_POST_NOTIFICATIONS
import messages.sms.text.chat.messanger.app.commons.helpers.PERMISSION_READ_CONTACTS
import messages.sms.text.chat.messanger.app.commons.helpers.PERMISSION_READ_SMS
import messages.sms.text.chat.messanger.app.commons.helpers.PERMISSION_SEND_SMS
import messages.sms.text.chat.messanger.app.commons.helpers.isOreoPlus
import messages.sms.text.chat.messanger.app.commons.helpers.isQPlus
import messages.sms.text.chat.messanger.app.commons.helpers.isTiramisuPlus
import messages.sms.text.chat.messanger.app.databinding.ActivityPermissionBinding


class PermissionActivity : QkThemedActivity() {

    private val binding by viewBinding(ActivityPermissionBinding::inflate)

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)



        binding.btnStart.setOnClickListener {


            loadMessages()
        }

        binding.tvTermsPrivacy.paintFlags =
            binding.tvTermsPrivacy.paintFlags or Paint.UNDERLINE_TEXT_FLAG
        binding.tvUserAgreement.paintFlags =
            binding.tvUserAgreement.paintFlags or Paint.UNDERLINE_TEXT_FLAG

        binding.tvUserAgreement.setOnClickListener {

            val url: String =
                resources?.getString(messages.sms.text.chat.messanger.app.R.string.user_agreement_url)
                    .toString()
            privacyUrlRedirect(url)
        }
        binding.tvTermsPrivacy.setOnClickListener {

            val url: String =
                resources?.getString(messages.sms.text.chat.messanger.app.R.string.privacy_policy_url)
                    .toString()
            privacyUrlRedirect(url)
        }




    }

    private fun launchHomeScreen() {
        config.saveData("for_first_time", true)
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private val MAKE_DEFAULT_APP_REQUEST = 111
    private fun loadMessages() {
        if (isQPlus()) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager!!.isRoleAvailable(RoleManager.ROLE_SMS)) {
                if (roleManager.isRoleHeld(RoleManager.ROLE_SMS)) {
                    askPermissions()
                } else {
                    val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_SMS)
                    intent.putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName)
                    startActivityForResult(intent, MAKE_DEFAULT_APP_REQUEST)
                }
            } else {
//                Log.i(TAG, "loadMessages: ")
//                toast(R.string.unknown_error_occurred)
                finish()
            }
        } else {
            if (Telephony.Sms.getDefaultSmsPackage(this) == packageName) {
                askPermissions()
            } else {
                val intent = Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                intent.putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName)
                startActivityForResult(intent, MAKE_DEFAULT_APP_REQUEST)
            }
        }
    }

    private fun askPermissions() {
        handlePermission(PERMISSION_READ_SMS) {
            if (it) {
                handlePermission(PERMISSION_SEND_SMS) {
                    if (it) {
                        handlePermission(PERMISSION_READ_CONTACTS) {
                            handleNotificationPermission { granted ->
                                if (!granted) {
                                    // Show permission required dialog
                                    PermissionRequiredDialog(
                                        activity = this,
                                        textId = messages.sms.text.chat.messanger.app.R.string.allow_notifications_incoming_messages,
                                        positiveActionCallback = {

                                            openNotificationSettings() // Open notification settings
                                        },
                                        negativeActionCallback = {
                                            // Handle negative action (e.g., finish activity)
                                            openNotificationSettings()
                                        }
                                    )
                                } else {
                                    // Proceed with the action if all permissions are granted
                                    //  tapCount = 3
                                    MainInterAdManager.showGeneralInterAds(this, true) {
                                        launchHomeScreen()
                                    }
                                }
                            }
                        }
                    } else {
                        // Handle permission denied case for PERMISSION_SEND_SMS
                        finish()
                    }
                }
            } else {
                // Handle permission denied case for PERMISSION_READ_SMS
                finish()
            }
        }
    }

    fun openNotificationSettings() {
        if (isOreoPlus()) {
            val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            intent.putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            startActivity(intent)
        } else {
            // For Android versions below Oreo, you can't directly open the app's notification settings.
            // You can open the general notification settings instead.
            val intent = Intent(Settings.ACTION_SETTINGS)
            startActivity(intent)
        }
    }

    fun handleNotificationPermission(callback: (granted: Boolean) -> Unit) {
        if (!isTiramisuPlus()) {
            callback(true)
        } else {
            handlePermission(PERMISSION_POST_NOTIFICATIONS) { granted ->
                callback(granted)
            }
        }
    }

    var actionOnPermission: ((granted: Boolean) -> Unit)? = null
    var isAskingPermissions = false
    private val GENERIC_PERM_HANDLER = 100

    fun handlePermission(permissionId: Int, callback: (granted: Boolean) -> Unit) {
        actionOnPermission = null
        if (hasPermission(permissionId)) {
            callback(true)
        } else {
            isAskingPermissions = true
            actionOnPermission = callback
            ActivityCompat.requestPermissions(
                this,
                arrayOf(getPermissionString(permissionId)),
                GENERIC_PERM_HANDLER
            )
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
        super.onActivityResult(requestCode, resultCode, resultData)
        Log.e("MAKEDEFAULTAPPREQUEST", " -00 " + "onActivityResult - " + requestCode)
        if (requestCode == MAKE_DEFAULT_APP_REQUEST) {
            if (resultCode == Activity.RESULT_OK) {
                askPermissions()
            } else if (resultCode == Activity.RESULT_CANCELED) {
                /* val alertDialog = AlertDialog.Builder(this)
                     .setMessage("Please set this app as the default SMS app in settings")
                     .setNegativeButton("Cancel") { dialog, _ ->
                         dialog.dismiss()
                         Toast.makeText(this, "This permission must required for use this application", Toast.LENGTH_SHORT).show()
                     }
                     .setPositiveButton("Allow") { _, _ ->
                         val intent = Intent(android.provider.Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)
                         startActivity(intent)
                     }
                     .create()
                 alertDialog.show()*/

                permissiondialog()
            }
        }
    }

    var alertDialog: android.app.AlertDialog? = null
    private fun permissiondialog() {
        if (isFinishing || isDestroyed) {
            return
        }

        val dialogBuilder = android.app.AlertDialog.Builder(
            this,
            messages.sms.text.chat.messanger.app.R.style.CustomFieldDialogTheme
        )
        val view = layoutInflater.inflate(
            messages.sms.text.chat.messanger.app.R.layout.dialog_sms_permission,
            null
        )

        dialogBuilder.setView(view)

        val btnDismiss =
            view.findViewById<TextView>(messages.sms.text.chat.messanger.app.R.id.btnDismiss)
        val btnsetup =
            view.findViewById<TextView>(messages.sms.text.chat.messanger.app.R.id.btnsetup)
//        val applyBackground = ResourcesCompat.getDrawable(resources, R.drawable.button_background_rounded, theme) as RippleDrawable
//        (applyBackground as LayerDrawable).findDrawableByLayerId(R.id.button_background_holder)
//            .setColorFilter(Color.parseColor("#3774FF"), PorterDuff.Mode.SRC_IN)
//        btnsetup.background = applyBackground

//        val applybtnDismissBackground = ResourcesCompat.getDrawable(resources, R.drawable.button_dismissbackground_rounded, theme) as RippleDrawable
//        btnDismiss.background = applybtnDismissBackground

        btnsetup.setTextColor(Color.parseColor("#FFFFFF"))

        btnDismiss.setTextColor(Color.parseColor("#000000"))

        btnsetup.setOnClickListener {
            alertDialog?.dismiss()
            val intent = Intent(android.provider.Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)
            startActivity(intent)
        }

        btnDismiss.setOnClickListener {
            alertDialog?.dismiss()
            //  Toast.makeText(this, "This permission must required for use this application", Toast.LENGTH_SHORT).show()
        }

        alertDialog = dialogBuilder.create()

        alertDialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        if (alertDialog?.isShowing == false) {

//            Log.i("onCreate", "permissiondialog: ")
            alertDialog?.show()
//            CHECK_FIRSTTIME_DIALOG = true
        }
    }

    private fun privacyUrlRedirect(url: String) {
        val builder = CustomTabsIntent.Builder()
        val params = CustomTabColorSchemeParams.Builder()
        params.setToolbarColor(
            ContextCompat.getColor(
                this@PermissionActivity,
                messages.sms.text.chat.messanger.app.R.color.color_app_theme
            )
        )
        builder.setDefaultColorSchemeParams(params.build())
        builder.setShowTitle(true)
        builder.setShareState(CustomTabsIntent.SHARE_STATE_ON)
        builder.setInstantAppsEnabled(true)
        val customBuilder = builder.build()

        if (isPackageInstalled("com.android.chrome")) {
            customBuilder.intent.setPackage("com.android.chrome")
            customBuilder.launchUrl(this@PermissionActivity, Uri.parse(url))
        } else {
            val i = Intent(Intent.ACTION_VIEW)
            i.data = Uri.parse(url)
            startActivity(i)
        }
    }

    private var backPressedTime: Long = 0

    override fun onBackPressed() {
        if (backPressedTime + 2000 > System.currentTimeMillis()) {

            startActivity(Intent(this, MainActivity::class.java))
            finish()
        } else {
            Toast.makeText(this, "Kindly grant the necessary permissions", Toast.LENGTH_SHORT)
                .show()
            backPressedTime = System.currentTimeMillis()
        }
    }
}