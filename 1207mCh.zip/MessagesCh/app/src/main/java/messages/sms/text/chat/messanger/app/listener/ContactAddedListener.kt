package messages.sms.text.chat.messanger.app.listener

import io.reactivex.Observable

interface ContactAddedListener {

    fun listen(): Observable<*>

}
