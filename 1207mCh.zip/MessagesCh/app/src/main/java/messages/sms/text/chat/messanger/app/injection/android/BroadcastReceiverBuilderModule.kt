package messages.sms.text.chat.messanger.app.injection.android

//import messages.sms.text.chat.messanger.app.receiver.NightModeReceiver
import dagger.Module
import dagger.android.ContributesAndroidInjector
import messages.sms.text.chat.messanger.app.feature.widget.WidgetProvider
import messages.sms.text.chat.messanger.app.injection.scope.ActivityScope
import messages.sms.text.chat.messanger.app.receiver.BlockThreadReceiver
import messages.sms.text.chat.messanger.app.receiver.BootReceiver
import messages.sms.text.chat.messanger.app.receiver.DefaultSmsChangedReceiver
import messages.sms.text.chat.messanger.app.receiver.DeleteMessagesReceiver
import messages.sms.text.chat.messanger.app.receiver.MarkArchivedReceiver
import messages.sms.text.chat.messanger.app.receiver.MarkReadReceiver
import messages.sms.text.chat.messanger.app.receiver.MarkSeenReceiver
import messages.sms.text.chat.messanger.app.receiver.MmsReceivedReceiver
import messages.sms.text.chat.messanger.app.receiver.MmsReceiver
import messages.sms.text.chat.messanger.app.receiver.MmsSentReceiver
import messages.sms.text.chat.messanger.app.receiver.MmsUpdatedReceiver
import messages.sms.text.chat.messanger.app.receiver.RemoteMessagingReceiver
import messages.sms.text.chat.messanger.app.receiver.SendScheduledMessageReceiver
import messages.sms.text.chat.messanger.app.receiver.SmsDeliveredReceiver
import messages.sms.text.chat.messanger.app.receiver.SmsProviderChangedReceiver
import messages.sms.text.chat.messanger.app.receiver.SmsReceiver
import messages.sms.text.chat.messanger.app.receiver.SmsSentReceiver

@Module
abstract class BroadcastReceiverBuilderModule {

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindBlockThreadReceiver(): BlockThreadReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindBootReceiver(): BootReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindDefaultSmsChangedReceiver(): DefaultSmsChangedReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindDeleteMessagesReceiver(): DeleteMessagesReceiver

    @ActivityScope
    @ContributesAndroidInjector
    abstract fun bindMarkArchivedReceiver(): MarkArchivedReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindMarkReadReceiver(): MarkReadReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindMarkSeenReceiver(): MarkSeenReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindMmsReceivedReceiver(): MmsReceivedReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindMmsReceiver(): MmsReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindMmsSentReceiver(): MmsSentReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindMmsUpdatedReceiver(): MmsUpdatedReceiver

//    @ActivityScope
//    @ContributesAndroidInjector()
//    abstract fun bindNightModeReceiver(): NightModeReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindRemoteMessagingReceiver(): RemoteMessagingReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindSendScheduledMessageReceiver(): SendScheduledMessageReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindSmsDeliveredReceiver(): SmsDeliveredReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindSmsProviderChangedReceiver(): SmsProviderChangedReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindSmsReceiver(): SmsReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindSmsSentReceiver(): SmsSentReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindWidgetProvider(): WidgetProvider

}