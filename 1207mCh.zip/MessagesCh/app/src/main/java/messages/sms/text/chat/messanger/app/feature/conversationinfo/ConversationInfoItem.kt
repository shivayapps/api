package messages.sms.text.chat.messanger.app.feature.conversationinfo

import io.realm.RealmList
import messages.sms.text.chat.messanger.app.model.MmsPart
import messages.sms.text.chat.messanger.app.model.Recipient

sealed class ConversationInfoItem {

    data class ConversationInfoRecipient(val value: Recipient) : ConversationInfoItem()

    data class ConversationInfoSettings(
        val name: String,
        val recipients: RealmList<Recipient>,
        val archived: Boolean,
        val blocked: Boolean,
    ) : ConversationInfoItem()

    data class ConversationInfoMedia(val value: MmsPart) : ConversationInfoItem()

}
