package messages.sms.text.chat.messanger.app.feature.conversationinfo

import android.util.Log
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.GridLayoutManager
import com.bluelinelabs.conductor.RouterTransaction
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.common.Navigator
import messages.sms.text.chat.messanger.app.common.QkChangeHandler
import messages.sms.text.chat.messanger.app.common.base.QkController
import messages.sms.text.chat.messanger.app.common.util.extensions.scrapViews
import messages.sms.text.chat.messanger.app.common.widget.FieldDialog
import messages.sms.text.chat.messanger.app.commons.extensions.baseConfig
import messages.sms.text.chat.messanger.app.databinding.ConversationInfoControllerBinding
import messages.sms.text.chat.messanger.app.feature.blocking.BlockingDialog
import messages.sms.text.chat.messanger.app.feature.conversationinfo.injection.ConversationInfoModule
import messages.sms.text.chat.messanger.app.feature.themepicker.ThemePickerController
import messages.sms.text.chat.messanger.app.injection.appComponent
import javax.inject.Inject

class ConversationInfoController(
    val threadId: Long = 0,
) : QkController<ConversationInfoView, ConversationInfoState, ConversationInfoPresenter,
        ConversationInfoControllerBinding>(ConversationInfoControllerBinding::inflate),
    ConversationInfoView {

    @Inject
    override lateinit var presenter: ConversationInfoPresenter

    @Inject
    lateinit var blockingDialog: BlockingDialog

    @Inject
    lateinit var navigator: Navigator

    @Inject
    lateinit var adapter: ConversationInfoAdapter

    /* private val nameDialog: FieldDialog by lazy {
         FieldDialog(activity!!, activity!!.getString(R.string.info_name), nameChangeSubject::onNext)

     }*/

    private val nameDialog: FieldDialog by lazy {
        FieldDialog(
            activity!!,
            activity!!.getString(R.string.info_name),
            nameChangeSubject::onNext
        ).apply {
            // Show listener to set button colors after the dialog is shown
            setOnShowListener {
                getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(context.baseConfig.primaryColor)
                getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(context.baseConfig.primaryColor)
                getButton(AlertDialog.BUTTON_NEUTRAL)?.setTextColor(context.getColor(R.color.black))
            }
        }
    }

    private val nameChangeSubject: Subject<String> = PublishSubject.create()
    private val confirmDeleteSubject: Subject<Unit> = PublishSubject.create()

    init {
        appComponent
            .conversationInfoBuilder()
            .conversationInfoModule(ConversationInfoModule(this))
            .build()
            .inject(this)
    }

    override fun onViewCreated() {
        binding.recyclerView.adapter = adapter
        binding.recyclerView.addItemDecoration(GridSpacingItemDecoration(adapter, activity!!))
        binding.recyclerView.layoutManager = GridLayoutManager(activity, 3).apply {
            spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int): Int =
                    if (adapter.getItemViewType(position) == 2) 1 else 3
            }
        }

        themedActivity?.theme
            ?.autoDispose(scope())
            ?.subscribe { binding.recyclerView.scrapViews() }
    }

    override fun onAttach(view: View) {
        super.onAttach(view)
        presenter.bindIntents(this)
        setTitle(R.string.info_title)
        showBackButton(true)
    }

    override fun render(state: ConversationInfoState) {
        if (state.hasError) {
            Log.e("render", "ConversationInfo:render.hasError:${state.data}")
            activity?.finish()
            return
        }

        adapter.data = state.data
    }

    override fun recipientClicks(): Observable<Long> = adapter.recipientClicks
    override fun recipientLongClicks(): Observable<Long> = adapter.recipientLongClicks
    override fun themeClicks(): Observable<Long> = adapter.themeClicks
    override fun nameClicks(): Observable<*> = adapter.nameClicks
    override fun nameChanges(): Observable<String> = nameChangeSubject
    override fun notificationClicks(): Observable<*> = adapter.notificationClicks
    override fun archiveClicks(): Observable<*> = adapter.archiveClicks
    override fun blockClicks(): Observable<*> = adapter.blockClicks
    override fun deleteClicks(): Observable<*> = adapter.deleteClicks
    override fun confirmDelete(): Observable<*> = confirmDeleteSubject
    override fun mediaClicks(): Observable<Long> = adapter.mediaClicks

    override fun showNameDialog(name: String) = nameDialog.setText(name).show()


    override fun showThemePicker(recipientId: Long) {
        router.pushController(
            RouterTransaction.with(ThemePickerController(recipientId))
                .pushChangeHandler(QkChangeHandler())
                .popChangeHandler(QkChangeHandler())
        )
    }

    override fun showBlockingDialog(conversations: List<Long>, block: Boolean) {
        blockingDialog.show(activity!!, conversations, block)
    }

    override fun requestDefaultSms() {
        navigator.showDefaultSmsDialog(activity!!)
    }

    override fun showDeleteDialog() {
        AlertDialog.Builder(activity!!, R.style.CustomFieldDialogTheme)
            .setTitle(R.string.dialog_delete_title)
            .setMessage(resources?.getQuantityString(R.plurals.dialog_delete_message, 1))
            .setPositiveButton(R.string.button_delete) { _, _ -> confirmDeleteSubject.onNext(Unit) }
            .setNegativeButton(R.string.button_cancel, null)
            .show()
    }

}