package  messages.sms.text.chat.messanger.app.ads

import android.content.Context
import android.view.ViewGroup
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.VideoOptions
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions

object GoogleNativeAdManager {
    private var mExitNativeAd: NativeAd? = null
    fun loadExitNative(mContext: Context, parentView: ViewGroup) {
        if (mExitNativeAd == null)
            loadNative(mContext, mContext.getAppCallerCardNative()) {
                mExitNativeAd = it
                showNative(mContext, parentView)
            }
    }

    fun showNative(mContext: Context, parentView: ViewGroup) {
        if (mExitNativeAd != null) {
            AdmobNative.populateExitNativeAd(mContext, parentView, mExitNativeAd!!)
        }
    }


    fun isExitAdLoaded() = mExitNativeAd != null
    private fun loadNative(mContext: Context, adId: String, listener: (NativeAd?) -> Unit) {
        if (!mContext.isInternetConnected() || !AdsPreferences(mContext).adsEnable || AdsPreferences(
                mContext
            ).isPro
        ) {
            listener.invoke(null)
            return
        }
        val videoOptionBuilder = VideoOptions.Builder()
            .setClickToExpandRequested(true)
            .setStartMuted(true)

        val nativeAdOptionsBuilder = NativeAdOptions.Builder()
            .setVideoOptions(videoOptionBuilder.build())

        val adLoader = AdLoader.Builder(mContext, adId)
            .forNativeAd { nativeAd: NativeAd ->
                listener.invoke(nativeAd)
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    listener.invoke(null)
                }

                override fun onAdClicked() {
                    super.onAdClicked()
                    isAdsNotShowOnResume = true
                }
            })
            .withNativeAdOptions(nativeAdOptionsBuilder.build())
            .build()

        adLoader.loadAd(AdRequest.Builder().build())
    }

    fun onDestroy() {
        mExitNativeAd?.destroy()
        mExitNativeAd = null
    }


}