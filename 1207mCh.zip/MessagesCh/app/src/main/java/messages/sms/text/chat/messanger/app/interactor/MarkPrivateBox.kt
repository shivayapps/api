package messages.sms.text.chat.messanger.app.interactor

import io.reactivex.Flowable
import messages.sms.text.chat.messanger.app.repository.ConversationRepository
import javax.inject.Inject


class MarkPrivateBox @Inject constructor(
    private val conversationRepo: ConversationRepository,
    private val markRead: MarkRead,
) : Interactor<List<Long>>() {

    override fun buildObservable(params: List<Long>): Flowable<*> {
        return Flowable.just(params.toLongArray())
            .doOnNext { threadIds -> conversationRepo.markPrivateBox(*threadIds) }
            .flatMap { markRead.buildObservable(params) }
    }

}