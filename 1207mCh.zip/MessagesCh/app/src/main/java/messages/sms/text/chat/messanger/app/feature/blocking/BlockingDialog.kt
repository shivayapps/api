package messages.sms.text.chat.messanger.app.feature.blocking

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.blocking.BlockingClient
import messages.sms.text.chat.messanger.app.interactor.MarkBlocked
import messages.sms.text.chat.messanger.app.interactor.MarkUnblocked
import messages.sms.text.chat.messanger.app.repository.ConversationRepository
import messages.sms.text.chat.messanger.app.util.Preferences
import javax.inject.Inject

class BlockingDialog @Inject constructor(
    private val blockingManager: BlockingClient,
    private val context: Context,
    private val conversationRepo: ConversationRepository,
    private val prefs: Preferences,
    private val markBlocked: MarkBlocked,
    private val markUnblocked: MarkUnblocked,
) {

    fun show(activity: Activity, conversationIds: List<Long>, block: Boolean) = GlobalScope.launch {
        val addresses = conversationIds.toLongArray()
            .let { conversationRepo.getConversations(*it) }
            .flatMap { conversation -> conversation.recipients }
            .map { it.address }
            .distinct()

        if (addresses.isEmpty()) {
            return@launch
        }

        if (blockingManager.getClientCapability() == BlockingClient.Capability.BLOCK_WITHOUT_PERMISSION) {
            // If we can block/unblock in the external manager, then just fire that off and exit
            if (block) {
                markBlocked.execute(
                    MarkBlocked.Params(
                        conversationIds,
                        prefs.blockingManager.get(),
                        null
                    )
                )
                blockingManager.block(addresses).subscribe()
            } else {
                markUnblocked.execute(conversationIds)
                blockingManager.unblock(addresses).subscribe()
            }
        } else if (block == allBlocked(addresses)) {
            // If all of the addresses are already in their correct state in the blocking manager, just marked the
            // conversations blocked and exit
            when (block) {
                true -> markBlocked.execute(
                    MarkBlocked.Params(
                        conversationIds,
                        prefs.blockingManager.get(),
                        null
                    )
                )

                false -> markUnblocked.execute(conversationIds)
            }
        } else {
            // Otherwise, show the UI that lets the users know they need to mark the number as blocked in the client
            showDialog(activity, conversationIds, addresses, block)
        }
    }

    private fun allBlocked(addresses: List<String>): Boolean = addresses.all { address ->
        blockingManager.getAction(address).blockingGet() is BlockingClient.Action.Block
    }

    private suspend fun showDialog(
        activity: Activity,
        conversationIds: List<Long>,
        addresses: List<String>,
        block: Boolean,
    ) = withContext(MainScope().coroutineContext) {
        val res = when (block) {
            true -> R.plurals.blocking_block_external
            false -> R.plurals.blocking_unblock_external
        }

        val manager = context.getString(
            when (prefs.blockingManager.get()) {
                Preferences.BLOCKING_MANAGER_SIA -> R.string.blocking_manager_sia_title
                Preferences.BLOCKING_MANAGER_CC -> R.string.blocking_manager_call_control_title
                else -> R.string.blocking_manager_qksms_title
            }
        )

        val message = context.resources.getQuantityString(res, addresses.size, manager)

        // Otherwise, show a dialog asking the user if they want to be directed to the external
        // blocking manager
        AlertDialog.Builder(activity, R.style.CustomFieldDialogTheme)
            .setTitle(
                when (block) {
                    true -> R.string.blocking_block_title
                    false -> R.string.blocking_unblock_title
                }
            )
            .setMessage(message)
            .setPositiveButton(R.string.button_continue) { _, _ ->
                if (block) {
                    markBlocked.execute(
                        MarkBlocked.Params(
                            conversationIds,
                            prefs.blockingManager.get(),
                            null
                        )
                    )
                    blockingManager.block(addresses).subscribe()
                } else {
                    markUnblocked.execute(conversationIds)
                    blockingManager.unblock(addresses).subscribe()
                }
            }
            .setNegativeButton(R.string.button_cancel) { _, _ -> }
            .create()
            .show()
    }

}
