package messages.sms.text.chat.messanger.app.mapper

import android.database.Cursor
import messages.sms.text.chat.messanger.app.model.Recipient

interface CursorToRecipient : Mapper<Cursor, Recipient> {

    fun getRecipientCursor(): Cursor?

    fun getRecipientCursor(id: Long): Cursor?

}