package messages.sms.text.chat.messanger.app.feature.fragments


import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.app.role.RoleManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Build.VERSION.SDK_INT
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.preference.PreferenceManager
import android.provider.Telephony
import android.text.format.DateUtils.formatElapsedTime
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog.BUTTON_NEGATIVE
import androidx.appcompat.app.AlertDialog.BUTTON_NEUTRAL
import androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.fragment.app.Fragment
import com.f2prateek.rx.preferences2.RxSharedPreferences
import com.google.android.play.core.review.ReviewInfo
import com.google.android.play.core.review.ReviewManager
import com.google.android.play.core.review.ReviewManagerFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import messages.sms.text.chat.messanger.app.BuildConfig
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.appmanager.FindAppActivity
import messages.sms.text.chat.messanger.app.common.util.MessageTotal
import messages.sms.text.chat.messanger.app.common.util.exportMessages
import messages.sms.text.chat.messanger.app.common.util.importMessages
import messages.sms.text.chat.messanger.app.common.widget.FieldDialog
import messages.sms.text.chat.messanger.app.commons.dialogs.ColorPickerDialog
import messages.sms.text.chat.messanger.app.commons.extensions.applyColorFilter
import messages.sms.text.chat.messanger.app.commons.extensions.areMultipleSIMsAvailable
import messages.sms.text.chat.messanger.app.commons.extensions.baseConfig
import messages.sms.text.chat.messanger.app.commons.extensions.beGone
import messages.sms.text.chat.messanger.app.commons.extensions.beGoneIf
import messages.sms.text.chat.messanger.app.commons.extensions.beVisible
import messages.sms.text.chat.messanger.app.commons.extensions.config
import messages.sms.text.chat.messanger.app.commons.extensions.getBottomNavigationBackgroundColor
import messages.sms.text.chat.messanger.app.commons.extensions.getBottomNavigationBackgroundColorsetting
import messages.sms.text.chat.messanger.app.commons.extensions.getProperTextColor
import messages.sms.text.chat.messanger.app.commons.extensions.toast
import messages.sms.text.chat.messanger.app.commons.extensions.updateTextColors
import messages.sms.text.chat.messanger.app.commons.helpers.isQPlus
import messages.sms.text.chat.messanger.app.databinding.FragmentSettingBinding
import messages.sms.text.chat.messanger.app.feature.blocking.BlockingActivity
import messages.sms.text.chat.messanger.app.feature.main.ArchiveActivity
import messages.sms.text.chat.messanger.app.feature.notificationprefs.NotificationPrefsActivity
import messages.sms.text.chat.messanger.app.feature.scheduled.ScheduledActivity
import messages.sms.text.chat.messanger.app.feature.settings.AdvanceSettingsActivity
import messages.sms.text.chat.messanger.app.feature.settings.SwipeActionsActivity
import messages.sms.text.chat.messanger.app.feature.starred.StarredActivity
import messages.sms.text.chat.messanger.app.manager.PermissionManagerImpl
import messages.sms.text.chat.messanger.app.model.MessageEvent
import messages.sms.text.chat.messanger.app.model.REFRESH_MESSAGE
import messages.sms.text.chat.messanger.app.model.SYNC_MESSAGE
import messages.sms.text.chat.messanger.app.model.THEME_CHANGED
import messages.sms.text.chat.messanger.app.password.PasswordActivity
import messages.sms.text.chat.messanger.app.util.Preferences
import org.greenrobot.eventbus.EventBus
import java.lang.ref.WeakReference
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs


const val EXPORT_MESSAGES = 1
const val IMPORT_MESSAGES = 2

class SettingFragment constructor() : Fragment() {

    //    @Inject
    lateinit var prefs: Preferences

    lateinit var binding: FragmentSettingBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
//        AndroidInjection.inject(activity)
        binding = FragmentSettingBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val shPrefs = PreferenceManager.getDefaultSharedPreferences(context)
        val rxPrefs = RxSharedPreferences.create(shPrefs)
        prefs = Preferences(requireContext(), rxPrefs, shPrefs)

        setUI()
        setUpListener()
        setupUseColoredContacts()
//        setupContactsColorList()
        setupColorSimIcons()
        setupSimCardColorList()
    }

    private fun setUI() {
        requireActivity().updateTextColors(binding.settingsCoordinator)

        binding.apply {
            arrayOf(
                vdefault,
                vcolorlist,
                vmange,
                vbock,
                varchive,
                vrecycler,
                vaagesture,
                vswipe,
                vnoti,
                xxa,
                xxb,
                vlanguage,
                vadvance,
                vshare,
                vexpose,
                vprivate,
            ).forEach {
                it.background.applyColorFilter(requireContext().getBottomNavigationBackgroundColorsetting())
            }

            /*  arrayOf(
                  settingsAppearanceLabel,
                  settingsGeneralLabel,
                  settingsBackupsLabel,
              ).forEach {
                  it.setTextColor(requireContext().getProperPrimaryColor())
              }*/

            arrayOf(
                settingsColorCustomizationHolder,
                settingsGeneralHolder,
                settingsBackupsHolder,
            ).forEach {
//                it.background.applyColorFilter(requireContext().getBottomNavigationBackgroundColor())

                if (requireActivity().baseConfig.useImageResource == true) {
                    if (requireActivity().baseConfig.storedImageResource == -1) {

                    } else {
                        try {
                            it.background.applyColorFilter(requireContext().resources.getColor(R.color.transperent30))
                        } catch (_: Exception) {
                        }
                    }
                } else {
//                    if(activity?.baseConfig?.backgroundColor==-1){
//                        it.background.applyColorFilter(requireContext().resources.getColor(R.color.white))
//                    }else{
                    it.background.applyColorFilter(requireContext().getBottomNavigationBackgroundColor())
                    // }
                }
            }

            arrayOf(
                settingsCustomizeColorsChevron,
                settingsManageBlockedKeywordsChevron,
                settingsChangeDateTimeFormatChevron,
                settingsImportMessagesChevron,
                settingsExportMessagesChevron,
            ).forEach {
                it.applyColorFilter(requireContext().getProperTextColor())
            }
        }
    }

    private val signatureDialog: FieldDialog by lazy {
        FieldDialog(
            requireActivity(), requireContext().getString(R.string.settings_signature_title)
        ) { signature ->
            prefs.signature.set(signature)
        }
    }

    private fun setUpListener() {
        binding.redefaultsms.setOnClickListener {
            loadMessages()
        }
        binding.reshareapp.setOnClickListener {
            shareApp()
        }
        binding.rerateus.setOnClickListener {
            showRatingDialog()
        }
        binding.icReArchive.imageTintList =
            ContextCompat.getColorStateList(requireActivity(), R.color.icon_tint_setiing)
        binding.reArchive.setOnClickListener {
            startActivity(Intent(context, ArchiveActivity::class.java))
        }
        binding.resignature.setOnClickListener {
            signatureDialog.setText(prefs.signature.get()).show()

            signatureDialog.window?.setBackgroundDrawableResource(R.drawable.rounded_dialog)
            signatureDialog.getButton(BUTTON_POSITIVE)
                ?.setTextColor(requireActivity().baseConfig.primaryColor)
            signatureDialog.getButton(BUTTON_NEGATIVE)
                ?.setTextColor(requireActivity().baseConfig.primaryColor)
            signatureDialog.getButton(BUTTON_NEUTRAL)
                ?.setTextColor(ContextCompat.getColor(requireActivity(), R.color.black))
        }
        binding.restarred.setOnClickListener {
            startActivity(Intent(context, StarredActivity::class.java))
        }
        binding.rlManageApp.setOnClickListener {
            startActivity(Intent(context, FindAppActivity::class.java))
        }
        binding.rprivatebox.setOnClickListener {

            startActivity(Intent(context, PasswordActivity::class.java))
//            startActivity(Intent(context, PrivateConversationsActivity::class.java))
            //   context?.toast(R.string.under_development)
        }
        binding.reSwipeActions.setOnClickListener {
            val intent = Intent(context, SwipeActionsActivity::class.java)
            startActivity(intent)
        }

        binding.rerecycler.setOnClickListener {
            //startActivity(Intent(context, RecycleBinConversationsActivity::class.java))

            context?.toast(R.string.under_development)
        }
        binding.reAdvance.setOnClickListener {
            startActivity(Intent(context, AdvanceSettingsActivity::class.java))
        }

        binding.reschedule.setOnClickListener {
            startActivity(Intent(context, ScheduledActivity::class.java))
        }
        binding.reBlock.setOnClickListener {
            startActivity(Intent(context, BlockingActivity::class.java))
        }
        binding.renotifications.setOnClickListener {
//            requireActivity().launchCustomizeNotificationsIntent()
            val intent = Intent(context, NotificationPrefsActivity::class.java)
            intent.putExtra("threadId", 0)
            startActivity(intent)
        }
        binding.settingsExportMessagesHolder.setOnClickListener {
            exportMessagesManual()
        }
        binding.settingsImportMessagesHolder.setOnClickListener {
//            operation = ::importMessagesManual
            importMessagesManual()
//            checkDefaultSMSApp()
        }
    }

    private fun importMessagesManual() {
        if (SDK_INT < 23) {
            setStatusReport(getString(R.string.message_import_api_23_requirement))
            return
        }
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type =
                if (SDK_INT < 29) "*/*" else "application/zip" //see https://github.com/tmo1/sms-ie/issues/3#issuecomment-900518890
        }
        startActivityForResult(intent, IMPORT_MESSAGES)
    }


    private fun exportMessagesManual() {/*if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_SMS
            ) == PackageManager.PERMISSION_GRANTED
            && ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_CONTACTS
            ) == PackageManager.PERMISSION_GRANTED
        )*/
        if (PermissionManagerImpl(requireActivity()).isDefaultSms()) {
//        if (checkReadSMSContactsPermissions(this)) {
//            val date = getCurrentDateTime()
//            val dateInString = date.toString("yyyy-MM-dd")
            val dateInString = SimpleDateFormat(
                "yyyyMMddHHmmss",
                Locale.getDefault()
            ).format(System.currentTimeMillis())
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/zip"
                putExtra(Intent.EXTRA_TITLE, "messages-$dateInString.zip")
            }
            startActivityForResult(intent, EXPORT_MESSAGES)
        } else {
            setStatusReport(getString(R.string.sms_permissions_required))
        }
    }

    private fun setStatusReport(statusReport: String) {
//        val statusReportText: TextView = findViewById(R.id.status_report)
//        statusReportText.text = statusReport
    }

    private val MAKE_DEFAULT_APP_REQUEST = 1
    private fun loadMessages() {
        if (isQPlus()) {
            val roleManager = requireContext().getSystemService(RoleManager::class.java)
            if (roleManager != null && !roleManager.isRoleHeld(RoleManager.ROLE_SMS)) {
                val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_SMS)
                startActivityForResult(intent, MAKE_DEFAULT_APP_REQUEST)
            } else {
                Toast.makeText(
                    requireContext(),
                    "App is already the default SMS handler",
                    Toast.LENGTH_SHORT
                ).show()
            }
        } else {
            if (Telephony.Sms.getDefaultSmsPackage(requireContext()) != requireActivity().packageName) {

                val intent = Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                intent.putExtra(
                    Telephony.Sms.Intents.EXTRA_PACKAGE_NAME,
                    requireActivity().packageName
                )
                startActivityForResult(intent, MAKE_DEFAULT_APP_REQUEST)
            }
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
        super.onActivityResult(requestCode, resultCode, resultData)
        if (requestCode == MAKE_DEFAULT_APP_REQUEST) {
            EventBus.getDefault().post(MessageEvent(REFRESH_MESSAGE))
        }

        var total: MessageTotal
        val startTime = System.nanoTime()

        if (requestCode == EXPORT_MESSAGES && resultCode == Activity.RESULT_OK) {
            resultData?.data?.let {
                //statusReportText.text = getString(R.string.begin_exporting_messages)
                CoroutineScope(Dispatchers.Main).launch {
                    binding.llExportSync.beVisible()
                    total = exportMessages(
                        requireActivity(),
                        it,
                        binding.progressBarExport,
                        binding.reportExport
                    )
                    binding.reportExport.text = getString(
                        R.string.export_messages_results, total.sms, total.mms, formatElapsedTime(
                            TimeUnit.SECONDS.convert(
                                System.nanoTime() - startTime, TimeUnit.NANOSECONDS
                            )
                        )
                    )
//                    logElapsedTime(startTime)
                    Handler(Looper.getMainLooper()).postDelayed({
                        binding.llExportSync.beGone()
                    }, 1500)
                }
            }
        }

        if (requestCode == IMPORT_MESSAGES && resultCode == Activity.RESULT_OK) {
            resultData?.data?.let {
                CoroutineScope(Dispatchers.Main).launch {
                    binding.llImportSync.beVisible()
                    // importMessages() requires API level 23, but we check for that back in importMessagesManual()
                    total = importMessages(
                        requireActivity(),
                        it,
                        binding.progressBarImport,
                        binding.reportImport
                    )
                    binding.reportImport.text = getString(
                        R.string.import_messages_results, total.sms, total.mms, formatElapsedTime(
                            TimeUnit.SECONDS.convert(
                                System.nanoTime() - startTime, TimeUnit.NANOSECONDS
                            )
                        )
                    )
                    requireActivity().runOnUiThread {
                        EventBus.getDefault().post(MessageEvent(SYNC_MESSAGE))
                        Handler(Looper.getMainLooper()).postDelayed({
                            binding.llImportSync.beGone()
                        }, 1500)
                    }
//                    logElapsedTime(startTime)
                }
            }
        }
    }

    private fun shareApp() {
        val shareIntent = Intent(Intent.ACTION_SEND)
        shareIntent.setType("text/plain")
        val shareMessage =
            "Check out this amazing app: https://play.google.com/store/apps/details?id=${BuildConfig.APPLICATION_ID}"
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
        startActivity(Intent.createChooser(shareIntent, "Share App via"))
    }

    var rate: Float = 0f
    private fun showRatingDialog() {
        rate = 0f
        val dialog = Dialog(requireContext())
        val inflater = layoutInflater
        val dialogView: View = inflater.inflate(R.layout.rating_dialog, null)
        dialog.setContentView(dialogView)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        val rootView = dialogView.parent as ViewGroup
        // Set the layout parameters to respect the margins
        val params = rootView.layoutParams as ViewGroup.MarginLayoutParams
        params.setMargins(40, 20, 40, 20) // Set margins here as needed
        rootView.layoutParams = params
        val buttondialogok: TextView = dialogView.findViewById(R.id.buttondialogok)
        val btRatingBar: messages.sms.text.chat.messanger.app.commons.ratingbar.ScaleRatingBar =
            dialogView.findViewById(R.id.bt_ratingBar)
        btRatingBar.setOnRatingChangeListener { ratingBar, rating, fromUser ->
            rate = rating
        }
        buttondialogok.setOnClickListener {
            if (rate < 1) {
                requireActivity().toast("Please rate us. Your review is important to us for improvement")
                return@setOnClickListener
            }
            if (rate >= 4) {
//                AdsPreferences(activity).isRatingDone=true
                showInAppRateDialog(requireActivity())
            } else {
                launchEmail()
            }
            dialog.dismiss()
        }
        dialog.show()
    }

    private fun launchEmail() {
        val i = Intent(Intent.ACTION_SEND)
        i.type = "message/rfc822"
        i.putExtra(Intent.EXTRA_EMAIL, arrayOf("babymariagame@gmail.com"))
        i.putExtra(
            Intent.EXTRA_SUBJECT,
            "${getString(R.string.app_name)} ${getString(R.string.feedback)}"
        )
        i.putExtra(Intent.EXTRA_TEXT, "")
        i.setPackage("com.google.android.gm")

        try {
            startActivity(Intent.createChooser(i, "Send_mail"))
        } catch (_: ActivityNotFoundException) {
        }
    }

    override fun onResume() {
        super.onResume()

        val states = arrayOf(
            intArrayOf(-android.R.attr.state_checked),
            intArrayOf(android.R.attr.state_checked)
        )
        val thumbColors = intArrayOf(
            requireActivity().getColor(R.color.icon_tint),  // Gray color for unselected state
            requireActivity().baseConfig.primaryColor  // Active color
        )

        val primaryColorWithAlpha =
            ColorUtils.setAlphaComponent(
                requireActivity().baseConfig.primaryColor,
                (255 * 0.4).toInt()
            )
        val trackColors = intArrayOf(
            requireActivity().getColor(R.color.trackColorOff),  // Gray color for unselected state
            primaryColorWithAlpha  // Active color
        )


        binding.settingsColoredContacts.thumbTintList = ColorStateList(states, thumbColors)
        binding.settingsColorSimCardIcons.thumbTintList = ColorStateList(states, thumbColors)

        binding.settingsColoredContacts.trackTintList = ColorStateList(states, trackColors)
        binding.settingsColorSimCardIcons.trackTintList = ColorStateList(states, trackColors)

        binding.privateBoxTitle.text = requireActivity().baseConfig.privateBoxName

        if (requireActivity().baseConfig.hideEntranceSwitchStatus) {
            binding.rprivatebox.visibility = View.GONE
            binding.vprivate.visibility = View.GONE
        } else {
            binding.rprivatebox.visibility = View.VISIBLE
            binding.vprivate.visibility = View.VISIBLE
        }
    }


    private fun showInAppRateDialog(activity: Activity) {
        Log.e("RatingDialog", "showInAppRateDialog")
        val reviewManager = ReviewManagerFactory.create(activity)
        val activityRef = WeakReference(activity)
        val requestReview = reviewManager.requestReviewFlow()
        requestReview.addOnCompleteListener { task ->
            Log.e("RatingDialog", "showInAppRateDialog.task:${task.isSuccessful}")
            if (task.isSuccessful) {
                val fragmentActivity = activityRef.get()
                if (fragmentActivity != null) {
                    showInAppRateDialogInternal(
                        reviewManager,
                        fragmentActivity,
                        task.result
                    )
                }
            } else {
                Log.e("RatingDialog", "showInAppRateDialog.exception:${task.exception}")
//                log.error(task.exception)
            }
        }
    }

    private fun showInAppRateDialogInternal(
        reviewManager: ReviewManager,
        activity: Activity,
        reviewInfo: ReviewInfo,
    ) {
        Log.e("RatingDialog", "showInAppRateDialogInternal")
        val reviewFlow = reviewManager.launchReviewFlow(activity, reviewInfo)
        val activityRef = WeakReference(activity)
        reviewFlow.addOnCompleteListener { task ->
            Log.e("RatingDialog", "showInAppRateDialogInternal.task:${task.isSuccessful}")
            if (task.isSuccessful) {
                val fragmentActivity = activityRef.get()
                if (fragmentActivity != null) {
                    launchAppStore()
                    Log.e("RatingDialog", "showInAppRateDialogInternal.RateUsState.IGNORED")
                }
            } else {
                Log.e("RatingDialog", "showInAppRateDialogInternal.exception:${task.exception}")
            }
        }
    }

    private fun launchAppStore() {
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("http://play.google.com/store/apps/details?id=${activity?.packageName}")
        )
        startActivity(intent)
    }

    //    lateinit var settingsController: SettingsController
    private fun setupUseColoredContacts() = binding.apply {
//        settingsController= SettingsController()
//        settingsContactColorListHolder.beVisibleIf(requireContext().config.useColoredContacts)
//        settingsColoredContacts.isChecked = requireContext().config.useColoredContacts
//        settingsColoredContacts.isChecked = rxPrefs.getBoolean("autoColor", true).get()
        settingsColoredContacts.isChecked = prefs.autoColor.get()

        settingsColoredContactsHolder.setOnClickListener {
            settingsColoredContacts.toggle()
            prefs.autoColor.set(settingsColoredContacts.isChecked)
            requireContext().config.tabsChanged = true
            EventBus.getDefault().post(MessageEvent(THEME_CHANGED))
        }
    }


//    private fun setupContactsColorList() = binding.apply {
//        settingsContactColorListHolder.beVisibleIf(requireContext().config.useColoredContacts)
//        settingsContactColorListIcon.setImageResource(getContactsColorListIcon(requireContext().config.contactColorList))
//        settingsContactColorListHolder.setOnClickListener {
//            ColorListDialog(requireActivity()) {
//                requireContext().config.contactColorList = it as Int
//                settingsContactColorListIcon.setImageResource(getContactsColorListIcon(it))
//                requireContext().config.tabsChanged = true
//            }
//        }
//    }

    private fun setupColorSimIcons() = binding.apply {
        settingsColorSimCardIconsHolder.beGoneIf(requireContext().areMultipleSIMsAvailable())
        settingsColorSimCardIcons.isChecked = requireContext().config.colorSimIcons
        settingsColorSimCardIconsHolder.setOnClickListener {
            settingsColorSimCardIcons.toggle()
            requireContext().config.colorSimIcons = settingsColorSimCardIcons.isChecked

            if (requireContext().config.colorSimIcons) {
                settingsSimCardColorListHolder.visibility = View.VISIBLE
            } else {
                settingsSimCardColorListHolder.visibility = View.GONE
            }
        }

        if (requireContext().config.colorSimIcons) {
            settingsSimCardColorListHolder.visibility = View.VISIBLE
        } else {
            settingsSimCardColorListHolder.visibility = View.GONE
        }
    }

    @SuppressLint("SetTextI18n")
    private fun setupSimCardColorList() = binding.apply {
        settingsSimCardColorListIcon1.setColorFilter(requireContext().config.simIconsColors[1])
        settingsSimCardColorListIcon2.setColorFilter(requireContext().config.simIconsColors[2])
        settingsSimCardColorListIcon1.setOnClickListener {
            ColorPickerDialog(
                requireActivity(),
                requireContext().config.simIconsColors[1],
                addDefaultColorButton = true,
                colorDefault = resources.getColor(R.color.ic_dialer),
                title = resources.getString(R.string.color_sim_card_icons)
            ) { wasPositivePressed, color ->
                if (wasPositivePressed) {
                    if (hasColorChanged(requireContext().config.simIconsColors[1], color)) {
                        addSimCardColor(1, color)
                        settingsSimCardColorListIcon1.setColorFilter(color)
                    }
                }
            }
        }
        settingsSimCardColorListIcon2.setOnClickListener {
            ColorPickerDialog(
                requireActivity(),
                requireContext().config.simIconsColors[2],
                addDefaultColorButton = true,
                colorDefault = resources.getColor(R.color.color_primary),
                title = resources.getString(R.string.color_sim_card_icons)
            ) { wasPositivePressed, color ->
                if (wasPositivePressed) {
                    if (hasColorChanged(requireContext().config.simIconsColors[2], color)) {
                        addSimCardColor(2, color)
                        settingsSimCardColorListIcon2.setColorFilter(color)
                    }
                }
            }
        }
    }

    private fun addSimCardColor(index: Int, color: Int) {
        val recentColors = requireContext().config.simIconsColors

        recentColors.removeAt(index)
        recentColors.add(index, color)

        requireActivity().baseConfig.simIconsColors = recentColors
    }

    private fun hasColorChanged(old: Int, new: Int) = abs(old - new) > 1


}
