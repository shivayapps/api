package messages.sms.text.chat.messanger.app.feature.scheduled

import android.content.Context
import android.net.Uri
import android.view.ViewGroup
import com.bumptech.glide.Glide
import messages.sms.text.chat.messanger.app.common.base.QkAdapter
import messages.sms.text.chat.messanger.app.common.base.QkViewHolder
import messages.sms.text.chat.messanger.app.databinding.ScheduledMessageImageListItemBinding

import javax.inject.Inject

class ScheduledMessageAttachmentAdapter @Inject constructor(
    private val context: Context,
) : QkAdapter<Uri, ScheduledMessageImageListItemBinding>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): QkViewHolder<ScheduledMessageImageListItemBinding> {
        return QkViewHolder(parent, ScheduledMessageImageListItemBinding::inflate).apply {
            binding.thumbnail.clipToOutline = true
        }
    }

    override fun onBindViewHolder(
        holder: QkViewHolder<ScheduledMessageImageListItemBinding>,
        position: Int,
    ) {
        val attachment = getItem(position)

        Glide.with(context).load(attachment).into(holder.binding.thumbnail)
    }

}