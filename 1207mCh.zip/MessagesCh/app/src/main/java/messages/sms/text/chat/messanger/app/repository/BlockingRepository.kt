package messages.sms.text.chat.messanger.app.repository

import io.realm.RealmResults
import messages.sms.text.chat.messanger.app.model.BlockedNumber

interface BlockingRepository {

    fun blockNumber(vararg addresses: String)

    fun getBlockedNumbers(): RealmResults<BlockedNumber>

    fun getBlockedNumber(id: Long): BlockedNumber?

    fun isBlocked(address: String): Boolean

    fun unblockNumber(id: Long)

    fun unblockNumbers(vararg addresses: String)

}
