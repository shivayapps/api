package messages.sms.text.chat.messanger.app.feature.starred

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import dagger.android.AndroidInjection
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.common.Navigator
import messages.sms.text.chat.messanger.app.common.base.QkThemedActivity
import messages.sms.text.chat.messanger.app.common.util.extensions.viewBinding
import messages.sms.text.chat.messanger.app.commons.extensions.baseConfig
import messages.sms.text.chat.messanger.app.commons.extensions.beGone
import messages.sms.text.chat.messanger.app.commons.extensions.beVisible
import messages.sms.text.chat.messanger.app.commons.extensions.updateTextColors
import messages.sms.text.chat.messanger.app.databinding.StarredActivityBinding
import javax.inject.Inject


class StarredActivity : QkThemedActivity(), StarredMessagesView {

    @Inject
    lateinit var messageAdapter: StarredMessageAdapter

    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory
    override val conversationClicks by lazy { messageAdapter.clicks }

    @Inject
    lateinit var navigator: Navigator


    private val viewModel by lazy {
        ViewModelProvider(
            this,
            viewModelFactory
        )[StarredViewModel::class.java]
    }

    private val binding by viewBinding(StarredActivityBinding::inflate)

    //    lateinit var binding:StarredActivityBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
//        binding=StarredActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationIcon(R.drawable.ic_chevron_left_vector)

        setTitle(R.string.starred)
        showBackButton(true)
        viewModel.bindView(this)
        messageAdapter.emptyView = binding.empty
        binding.messages.adapter = messageAdapter

        setUpTheme()


    }

    private fun setUpTheme() {

        Log.e("MainActivity", "setUpTheme.useImageResource:${baseConfig.useImageResource}")
        Log.e("MainActivity", "setUpTheme.storedImageResource:${baseConfig.storedImageResource}")

        updateTextColors(binding.contentView)
        //    binding.toolbarTitle.setTextColor(baseConfig.primaryColor)

        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
            binding.contentView.background =
                ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))

        } else {
            binding.contentView.background = ColorDrawable(baseConfig.backgroundColor)

        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                Log.i("onCreate", "onCreateitemselse11111: ")
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.contentView.background = drawable
                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
            }
        } else {
            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
            toolbar.setBackgroundColor(baseConfig.backgroundColor)
        }

    }

    override fun requestDefaultSms() {
        navigator.showDefaultSmsDialog(this@StarredActivity)
    }

    override fun render(state: StarredMessagesState) {
        if (state.data?.isNotEmpty()!!) {
            binding.empty.beGone()
            messageAdapter.updateData(state.data)
        } else {
            binding.empty.beVisible()
        }
    }


    override fun onDestroy() {
        super.onDestroy()
    }

    override fun onPause() {
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
    }


}