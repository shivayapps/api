package messages.sms.text.chat.messanger.app.feature.backup

import io.reactivex.Observable
import messages.sms.text.chat.messanger.app.common.base.QkViewContract
import messages.sms.text.chat.messanger.app.model.BackupFile

interface BackupView : QkViewContract<BackupState> {

//    fun activityVisible(): Observable<*>
//    fun permissionGiven(): Observable<*>
//    fun restoreClicks(): Observable<*>
//    fun restoreFileSelected(): Observable<BackupFile>
//    fun restoreConfirmed(): Observable<*>
//    fun stopRestoreClicks(): Observable<*>
//    fun stopRestoreConfirmed(): Observable<*>
//    fun stopBackup(): Observable<*>
//    fun fabClicks(): Observable<*>
//
//    fun requestStoragePermission()
//    fun selectFile()
//    fun confirmRestore()
//    fun stopRestore()

    fun activityVisible(): Observable<*>
    fun permissionGiven(): Observable<*>
    fun restoreClicks(): Observable<*>
    fun restoreFileSelected(): Observable<BackupFile>
    fun restoreConfirmed(): Observable<*>
    fun deleteRestoreFileSelected(): Observable<BackupFile>

    //    fun deleteRestoreFileSelected2(): Observable<*>
    fun stopRestoreClicks(): Observable<*>
    fun stopRestoreConfirmed(): Observable<*>
    fun stopBackup(): Observable<*>
    fun fabClicks(): Observable<*>


    fun requestDefaultSms()
    fun requestStoragePermission()
    fun selectFile()
    fun confirmRestore()
    fun stopRestore()
    fun showDialog()

}
