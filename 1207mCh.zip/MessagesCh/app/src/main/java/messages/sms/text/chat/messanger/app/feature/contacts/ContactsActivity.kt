package messages.sms.text.chat.messanger.app.feature.contacts

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider

import com.jakewharton.rxbinding2.view.clicks
import com.jakewharton.rxbinding2.widget.editorActions
import com.jakewharton.rxbinding2.widget.textChanges
import dagger.android.AndroidInjection
import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.common.ViewModelFactory
import messages.sms.text.chat.messanger.app.common.base.QkThemedActivity
import messages.sms.text.chat.messanger.app.common.util.extensions.hideKeyboard
import messages.sms.text.chat.messanger.app.common.util.extensions.setBackgroundTint
import messages.sms.text.chat.messanger.app.common.util.extensions.showKeyboard
import messages.sms.text.chat.messanger.app.common.util.extensions.viewBinding
import messages.sms.text.chat.messanger.app.common.widget.QkDialog
import messages.sms.text.chat.messanger.app.commons.extensions.addAlpha
import messages.sms.text.chat.messanger.app.commons.extensions.baseConfig
import messages.sms.text.chat.messanger.app.commons.extensions.updateTextColors
import messages.sms.text.chat.messanger.app.databinding.ContactsActivityBinding
import messages.sms.text.chat.messanger.app.extensions.Optional
import messages.sms.text.chat.messanger.app.feature.compose.editing.ComposeItem
import messages.sms.text.chat.messanger.app.feature.compose.editing.ComposeItemAdapter
import messages.sms.text.chat.messanger.app.feature.compose.editing.PhoneNumberAction
import messages.sms.text.chat.messanger.app.feature.compose.editing.PhoneNumberPickerAdapter
import javax.inject.Inject

class ContactsActivity : QkThemedActivity(), ContactsContract {

    companion object {
        const val SharingKey = "sharing"
        const val ChipsKey = "chips"
    }

    @Inject
    lateinit var contactsAdapter: ComposeItemAdapter

    @Inject
    lateinit var phoneNumberAdapter: PhoneNumberPickerAdapter

    @Inject
    lateinit var viewModelFactory: ViewModelFactory

    override val queryChangedIntent: Observable<CharSequence> by lazy { binding.search.textChanges() }
    override val queryClearedIntent: Observable<*> by lazy { binding.cancel.clicks() }
    override val queryBack: Observable<*> by lazy { binding.ivBack.clicks() }
    override val queryEditorActionIntent: Observable<Int> by lazy { binding.search.editorActions() }
    override val composeItemPressedIntent: Subject<ComposeItem> by lazy { contactsAdapter.clicks }
    override val composeItemLongPressedIntent: Subject<ComposeItem> by lazy { contactsAdapter.longClicks }
    override val phoneNumberSelectedIntent: Subject<Optional<Long>> by lazy { phoneNumberAdapter.selectedItemChanges }
    override val phoneNumberActionIntent: Subject<PhoneNumberAction> = PublishSubject.create()

    private val binding by viewBinding(ContactsActivityBinding::inflate)
    private val viewModel by lazy {
        ViewModelProvider(
            this,
            viewModelFactory
        )[ContactsViewModel::class.java]
    }

    private val phoneNumberDialog by lazy {
        QkDialog(this).apply {
            titleRes = R.string.compose_number_picker_title
            adapter = phoneNumberAdapter
            positiveButton = R.string.compose_number_picker_always
            positiveButtonListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.ALWAYS) }
            negativeButton = R.string.compose_number_picker_once
            negativeButtonListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.JUST_ONCE) }
            cancelListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.CANCEL) }

        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        showBackButton(true)
        viewModel.bindView(this)

        binding.contacts.adapter = contactsAdapter

        setUpTheme()
    }


    private fun setUpTheme() {

        Log.e("MainActivity", "setUpTheme.useImageResource:${baseConfig.useImageResource}")
        Log.e("MainActivity", "setUpTheme.storedImageResource:${baseConfig.storedImageResource}")
//        if (baseConfig.useImageResource){
//            if (baseConfig.storedImageResource==-1){
//
//            }else{
////                val bitmapDrawable = BitmapDrawable(resources, baseConfig.storedBitmap)
//                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
//                binding.mainLayout.background = drawable
//            }
//        }

        updateTextColors(binding.contentView)
//        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
//            binding.llBottomAction.background = ColorDrawable(resources.getColor(R.color.bottom_tabs_black_backgroundnew))
//            arrayListOf(binding.ivDelete, binding.ivMore, binding.ivArchive, binding.ivRead, binding.ivBlock).forEach {
////                val whiteColor = ContextCompat.getColor(this, R.color.white)
//                val colorStateList = ColorStateList.valueOf(Color.WHITE)
//                it.imageTintList = colorStateList
//            }
//        } else {
//            binding.llBottomAction.background = ColorDrawable(baseConfig.statusBarColor)
//            arrayListOf(binding.ivDelete, binding.ivMore, binding.ivArchive, binding.ivRead, binding.ivBlock).forEach {
////                val whiteColor = ContextCompat.getColor(this, R.color.black)
//                val colorStateList = ColorStateList.valueOf(Color.BLACK)
//                it.imageTintList = colorStateList
//            }
//        }

        if (baseConfig.useImageResource == true) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                Log.i("onCreate", "onCreateitemselse11111: ")

//                val bitmapDrawable = BitmapDrawable(resources, baseConfig.storedBitmap)
//                constraintLayout.background = bitmapDrawable
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.contentView.background = drawable

                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))

            }
        } else {

            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
//            binding.navView.setBackgroundColor(baseConfig.backgroundColor)
//            lloptionmenu.setBackgroundColor(baseConfig.backgroundColor)
            toolbar.setBackgroundColor(baseConfig.backgroundColor)

        }

//        supportActionBar?.setHomeButtonEnabled(true)
//        supportActionBar?.setDisplayHomeAsUpEnabled(true)
//        binding.toolbar.setNavigationIcon(R.drawable.ic_chevron_left_vector)

        val primaryColorWithAlpha =
            ColorUtils.setAlphaComponent(baseConfig.primaryColor, (255 * 0.1).toInt())
        val textColorPrimaryss = baseConfig.textColor
        val colorWithAlpha = textColorPrimaryss.addAlpha(0.6F)
        binding.search.setBackgroundTint(primaryColorWithAlpha)
//        binding.search.textSize = resources.getDimension(R.dimen.search_hint_text_size)
        binding.search.setHintTextColor(colorWithAlpha)

        binding.ivBack.setOnClickListener {
            onBackPressed()
        }

    }

    override fun render(state: ContactsState) {
        binding.cancel.isVisible = state.query.length > 1

        contactsAdapter.data = state.composeItems

        if (state.selectedContact != null && !phoneNumberDialog.isShowing) {
            phoneNumberAdapter.data = state.selectedContact.numbers
            phoneNumberDialog.subtitle = state.selectedContact.name

            phoneNumberDialog.window?.setBackgroundDrawableResource(R.drawable.rounded_dialog)
            phoneNumberDialog.show()
        } else if (state.selectedContact == null && phoneNumberDialog.isShowing) {
            phoneNumberDialog.dismiss()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun clearQuery() {
        binding.search.text = null
    }

    override fun openKeyboard() {
        binding.search.postDelayed({
            binding.search.showKeyboard()
        }, 200)
    }

    override fun back() {
        onBackPressed()
    }

    override fun finish(result: HashMap<String, String?>) {
        binding.search.hideKeyboard()
        val intent = Intent().putExtra(ChipsKey, result)
        setResult(Activity.RESULT_OK, intent)
        finish()
    }

}
