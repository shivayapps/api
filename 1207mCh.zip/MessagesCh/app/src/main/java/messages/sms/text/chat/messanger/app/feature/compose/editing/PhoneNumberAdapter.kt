package messages.sms.text.chat.messanger.app.feature.compose.editing

import android.view.ViewGroup
import messages.sms.text.chat.messanger.app.common.base.QkAdapter
import messages.sms.text.chat.messanger.app.common.base.QkViewHolder
import messages.sms.text.chat.messanger.app.commons.extensions.addAlpha
import messages.sms.text.chat.messanger.app.commons.extensions.baseConfig
import messages.sms.text.chat.messanger.app.databinding.ContactNumberListItemBinding
import messages.sms.text.chat.messanger.app.model.PhoneNumber

class PhoneNumberAdapter : QkAdapter<PhoneNumber, ContactNumberListItemBinding>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): QkViewHolder<ContactNumberListItemBinding> {
        return QkViewHolder(parent, ContactNumberListItemBinding::inflate).apply {
//            val textColorPrimary = parent.context.baseConfig.textColor
            val colorWithAlpha = parent.context.baseConfig.textColor.addAlpha(0.3F)
            binding.address.setTextColor(colorWithAlpha)
            binding.type.setTextColor(colorWithAlpha)

        }
    }

    override fun onBindViewHolder(
        holder: QkViewHolder<ContactNumberListItemBinding>,
        position: Int,
    ) {
        val number = getItem(position)

        holder.binding.address.text = number.address
        holder.binding.type.text = number.type

        val textColorPrimary = holder.binding.address.context.baseConfig.textColor
        val colorWithAlpha = textColorPrimary.addAlpha(0.45F)
        holder.binding.address.setTextColor(colorWithAlpha)
        holder.binding.type.setTextColor(colorWithAlpha)
    }

    override fun areItemsTheSame(old: PhoneNumber, new: PhoneNumber): Boolean {
        return old.type == new.type && old.address == new.address
    }

    override fun areContentsTheSame(old: PhoneNumber, new: PhoneNumber): Boolean {
        return old.type == new.type && old.address == new.address
    }

}