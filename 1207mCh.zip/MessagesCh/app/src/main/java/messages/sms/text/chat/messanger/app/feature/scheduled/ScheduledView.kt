package messages.sms.text.chat.messanger.app.feature.scheduled

import io.reactivex.Observable
import messages.sms.text.chat.messanger.app.common.base.QkView

interface ScheduledView : QkView<ScheduledState> {

    val messageClickIntent: Observable<Long>
    val messageMenuIntent: Observable<Int>
    val composeIntent: Observable<*>

    fun showMessageOptions()

}
