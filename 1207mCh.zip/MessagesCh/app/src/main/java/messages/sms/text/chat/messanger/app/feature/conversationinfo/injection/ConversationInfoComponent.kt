package messages.sms.text.chat.messanger.app.feature.conversationinfo.injection

import dagger.Subcomponent
import messages.sms.text.chat.messanger.app.feature.conversationinfo.ConversationInfoController
import messages.sms.text.chat.messanger.app.injection.scope.ControllerScope

@ControllerScope
@Subcomponent(modules = [ConversationInfoModule::class])
interface ConversationInfoComponent {

    fun inject(controller: ConversationInfoController)

    @Subcomponent.Builder
    interface Builder {
        fun conversationInfoModule(module: ConversationInfoModule): Builder
        fun build(): ConversationInfoComponent
    }

}