package messages.sms.text.chat.messanger.app.feature.settings.swipe

import androidx.annotation.DrawableRes
import messages.sms.text.chat.messanger.app.R

data class SwipeActionsState(
    @DrawableRes val rightIcon: Int = R.drawable.ic_archive_swipe,
    val rightLabel: String = "",

    @DrawableRes val leftIcon: Int = R.drawable.ic_archive_swipe,
    val leftLabel: String = "",
)