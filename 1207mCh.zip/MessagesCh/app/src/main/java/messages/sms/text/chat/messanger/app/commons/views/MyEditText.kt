package messages.sms.text.chat.messanger.app.commons.views

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.drawable.Drawable
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.util.AttributeSet
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputConnectionWrapper
import android.widget.TextView
import androidx.appcompat.widget.AppCompatEditText
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat
import androidx.core.view.inputmethod.EditorInfoCompat
import androidx.core.view.inputmethod.InputConnectionCompat
import androidx.core.view.inputmethod.InputContentInfoCompat
import com.google.android.mms.ContentType
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.commons.extensions.adjustAlpha
import messages.sms.text.chat.messanger.app.commons.extensions.getColoredDrawableWithColor
import messages.sms.text.chat.messanger.app.commons.extensions.isMiUi
import messages.sms.text.chat.messanger.app.commons.helpers.MEDIUM_ALPHA
import messages.sms.text.chat.messanger.app.commons.helpers.isQPlus
import messages.sms.text.chat.messanger.app.util.tryOrNull
import java.lang.reflect.Field


class MyEditText : AppCompatEditText {

//    @Inject lateinit var textViewStyler: TextViewStyler

    val backspaces: Subject<Unit> = PublishSubject.create()
    val inputContentSelected: Subject<InputContentInfoCompat> = PublishSubject.create()
    var supportsInputContent: Boolean = false

    constructor(context: Context) : super(context)

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs)

    constructor(context: Context, attrs: AttributeSet, defStyle: Int) : super(
        context,
        attrs,
        defStyle
    )

    @SuppressLint("DiscouragedPrivateApi")
    fun setColors(textColor: Int, accentColor: Int, backgroundColor: Int) {
        // TODO HIDE
        // background?.mutate()?.applyColorFilter(accentColor)

        // requires android:textCursorDrawable="@null" in xml to color the cursor too
        setTextColor(textColor)
        setHintTextColor(textColor.adjustAlpha(MEDIUM_ALPHA))
        setLinkTextColor(accentColor)
        if (backgroundColor != -2) {
            if (isQPlus()) {
                textCursorDrawable = resources.getColoredDrawableWithColor(
                    context,
                    R.drawable.cursor_text_vertical,
                    backgroundColor
                )
                if (!isMiUi()) {
                    setTextSelectHandle(
                        resources.getColoredDrawableWithColor(
                            R.drawable.ic_drop_vector,
                            backgroundColor
                        )
                    )
                    setTextSelectHandleLeft(
                        resources.getColoredDrawableWithColor(
                            R.drawable.ic_drop_left_vector,
                            backgroundColor
                        )
                    )
                    setTextSelectHandleRight(
                        resources.getColoredDrawableWithColor(
                            R.drawable.ic_drop_right_vector,
                            backgroundColor
                        )
                    )
                }
            } else {
                try {
                    val fEditor: Field = TextView::class.java.getDeclaredField("mEditor")
                    fEditor.isAccessible = true
                    val editor: Any = fEditor.get(this) as Any
                    if (!isMiUi()) {
                        val fSelectHandleLeft: Field =
                            editor.javaClass.getDeclaredField("mSelectHandleLeft")
                        val fSelectHandleRight: Field =
                            editor.javaClass.getDeclaredField("mSelectHandleRight")
                        val fSelectHandleCenter: Field =
                            editor.javaClass.getDeclaredField("mSelectHandleCenter")
                        fSelectHandleLeft.isAccessible = true
                        fSelectHandleRight.isAccessible = true
                        fSelectHandleCenter.isAccessible = true
                        fSelectHandleLeft.set(
                            editor,
                            resources.getColoredDrawableWithColor(
                                context,
                                R.drawable.ic_drop_left_vector,
                                backgroundColor
                            )
                        )
                        fSelectHandleRight.set(
                            editor,
                            resources.getColoredDrawableWithColor(
                                context,
                                R.drawable.ic_drop_right_vector,
                                backgroundColor
                            )
                        )
                        fSelectHandleCenter.set(
                            editor,
                            resources.getColoredDrawableWithColor(
                                context,
                                R.drawable.ic_drop_vector,
                                backgroundColor
                            )
                        )
                    }

                    // Get the cursor resource id
                    var field = TextView::class.java.getDeclaredField("mCursorDrawableRes")
                    field.isAccessible = true
                    val drawableResId = field.getInt(this)

                    // Get the editor
                    field = TextView::class.java.getDeclaredField("mEditor")
                    field.isAccessible = true
                    //val editor = field[this]

                    // Get the drawable and set a color filter
                    val drawable = ContextCompat.getDrawable(context, drawableResId)
                    DrawableCompat.setTint(drawable!!, backgroundColor)

                    // Set the drawables
                    val drawables = arrayOf<Drawable?>(drawable, drawable)
                    field = editor.javaClass.getDeclaredField("mCursorDrawable")
                    field.isAccessible = true
                    field[editor] = drawables
                } catch (ignored: Exception) {
                }
            }
        }
    }

    override fun onCreateInputConnection(editorInfo: EditorInfo): InputConnection {
        try {

            val inputConnection =
                object : InputConnectionWrapper(super.onCreateInputConnection(editorInfo), true) {
                    override fun sendKeyEvent(event: KeyEvent): Boolean {
                        if (event.action == KeyEvent.ACTION_DOWN && event.keyCode == KeyEvent.KEYCODE_DEL) {
                            backspaces.onNext(Unit)
                        }
                        return super.sendKeyEvent(event)
                    }


                    override fun deleteSurroundingText(
                        beforeLength: Int,
                        afterLength: Int,
                    ): Boolean {
                        if (beforeLength == 1 && afterLength == 0) {
                            backspaces.onNext(Unit)
                        }
                        return super.deleteSurroundingText(beforeLength, afterLength)
                    }
                }

            if (supportsInputContent) {
                EditorInfoCompat.setContentMimeTypes(
                    editorInfo, arrayOf(
                        ContentType.IMAGE_JPEG,
                        ContentType.IMAGE_JPG,
                        ContentType.IMAGE_PNG,
                        ContentType.IMAGE_GIF
                    )
                )
            }

            val callback =
                InputConnectionCompat.OnCommitContentListener { inputContentInfo, flags, opts ->
                    val grantReadPermission =
                        flags and InputConnectionCompat.INPUT_CONTENT_GRANT_READ_URI_PERMISSION != 0

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1 && grantReadPermission) {
                        return@OnCommitContentListener tryOrNull {
                            inputContentInfo.requestPermission()
                            inputContentSelected.onNext(inputContentInfo)
                            true
                        } ?: false

                    }

                    true
                }

            return InputConnectionCompat.createWrapper(inputConnection, editorInfo, callback)
        } catch (e: Exception) {
            return InputMethodService().currentInputConnection
        }

    }
}
