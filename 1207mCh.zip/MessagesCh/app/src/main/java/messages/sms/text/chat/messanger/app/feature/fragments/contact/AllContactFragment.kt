package messages.sms.text.chat.messanger.app.feature.fragments.contact

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import messages.sms.text.chat.messanger.app.common.util.extensions.scrapViews
import messages.sms.text.chat.messanger.app.commons.adapters.ContactItemAdapter
import messages.sms.text.chat.messanger.app.databinding.FragmentAllContactBinding
import messages.sms.text.chat.messanger.app.feature.main.MainActivity
import messages.sms.text.chat.messanger.app.model.MessageEvent
import messages.sms.text.chat.messanger.app.model.THEME_CHANGED
import messages.sms.text.chat.messanger.app.model.UPDATE_ALL_CONTACT
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode


class AllContactFragment : Fragment() {

    var contactsAdapter = ContactItemAdapter()
    lateinit var binding: FragmentAllContactBinding
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentAllContactBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (!EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().register(this)

        binding.contacts.adapter = contactsAdapter
        val list = (requireActivity() as? MainActivity)?.contacts ?: ArrayList()
        contactsAdapter.data = list
    }

    override fun onDestroyView() {
        super.onDestroyView()
        if (EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().unregister(this)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        when (event.type) {
            UPDATE_ALL_CONTACT -> {
                if (::binding.isInitialized) {
                    val list = (requireActivity() as? MainActivity)?.contacts ?: ArrayList()
                    contactsAdapter.data = list
                }
            }

            THEME_CHANGED -> {
                if (::binding.isInitialized) {
                    binding.contacts.scrapViews()
                }
            }
        }
    }
}
