package messages.sms.text.chat.messanger.app.manager

interface AnalyticsManager {

    fun track(event: String, vararg properties: Pair<String, Any>)

    fun setUserProperty(key: String, value: Any)

}
