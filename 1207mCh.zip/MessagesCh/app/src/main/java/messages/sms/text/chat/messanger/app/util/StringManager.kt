package messages.sms.text.chat.messanger.app.util

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class StringManager(context: Context) {
    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences("my_prefs_custom_theme", Context.MODE_PRIVATE)
    private val gson = Gson()

    companion object {
        const val LIST_KEY = "string_list"
    }

    // Get current list from SharedPreferences
    private fun getStringList(): MutableList<String> {
        val json = sharedPreferences.getString(LIST_KEY, null)
        val type = object : TypeToken<MutableList<String>>() {}.type
        return if (json != null) {
            gson.fromJson(json, type)
        } else {
            mutableListOf()
        }
    }

    // Save the list back to SharedPreferences
    private fun saveStringList(list: MutableList<String>) {
        val json = gson.toJson(list)
        sharedPreferences.edit().putString(LIST_KEY, json).apply()
    }

    // Add a new string and manage the list
    fun addString(newString: String) {
        val stringList = getStringList()

        // Add the new string
        stringList.add(newString)

        // Save the updated list back to SharedPreferences
        saveStringList(stringList)
    }

    // Retrieve the current list of strings
    fun getStrings(): List<String> {
        return getStringList()
    }
}
