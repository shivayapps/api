package messages.sms.text.chat.messanger.app.feature.blocking

import io.reactivex.Observable
import messages.sms.text.chat.messanger.app.common.base.QkViewContract

interface BlockingView : QkViewContract<BlockingState> {

    //    val blockingManagerIntent: Observable<*>
    val blockedNumbersIntent: Observable<*>
    val blockedMessagesIntent: Observable<*>
    val dropClickedIntent: Observable<*>

    //    fun openBlockingManager()
    fun openBlockedNumbers()
    fun openBlockedMessages()
}
