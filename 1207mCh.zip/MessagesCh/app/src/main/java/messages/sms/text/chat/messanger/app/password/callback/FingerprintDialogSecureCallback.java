package messages.sms.text.chat.messanger.app.password.callback;


import messages.sms.text.chat.messanger.app.password.utils.FingerprintToken;

/**
 * Created by Omar on 08/01/2018.
 */

public interface FingerprintDialogSecureCallback {
    void onAuthenticationSucceeded();

    void onAuthenticationCancel();

    void onNewFingerprintEnrolled(FingerprintToken token);
}
