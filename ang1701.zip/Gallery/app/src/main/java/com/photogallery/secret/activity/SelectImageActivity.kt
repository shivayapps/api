package com.photogallery.secret.activity

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.photogallery.R
import com.photogallery.base.BaseActivity
import com.photogallery.databinding.ActivitySelectImageBinding
import com.photogallery.dialog.ActionConfirmationDialog
import com.photogallery.dialog.CopyMoveDialog
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.extension.isVisible
import com.photogallery.jobs.MediaLoaderX
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.secret.adapter.SelectAlbumAdapter
import com.photogallery.secret.adapter.SelectImageAdapter
import com.photogallery.secret.adapter.SelectImageListAdapter
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences
import com.photogallery.utils.Utils
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale

class SelectImageActivity : BaseActivity() {

    lateinit var binding: ActivitySelectImageBinding
    lateinit var preferences: Preferences
    var albumList: ArrayList<AlbumData> = ArrayList()
    val allImages: ArrayList<MediaData> = ArrayList()
    val selectedImageList: ArrayList<MediaData> = ArrayList()
    var spinnerAdapter: SelectAlbumAdapter? = null
    var allPictures = ArrayList<Any>()
    var pictures = ArrayList<Any>()
    var pictureAdapter: SelectImageAdapter? = null
    var selectImageAdapter: SelectImageListAdapter? = null
    var selectAlbumPath: String = ""
    var spinnerPos = -1
    var openType = 0
    var includeVideo = true
    lateinit var dropdownAnimation: Animation

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySelectImageBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
//        WindowCompat.getInsetsController(window, window.decorView).apply {
//            isAppearanceLightStatusBars = false
//            isAppearanceLightNavigationBars = true
//        }
        //updateStatusBarColor(Color.parseColor("#161616"))

        intView()
        intListener()
        setRvLayoutManager()
        loadBanner()
    }

    private fun intView() {

        binding.loutBottomSelect.visibility = View.GONE
        openType = intent.getIntExtra(Constant.EXTRA_SELECT_TYPE, 0)
        includeVideo = intent.getBooleanExtra(Constant.EXTRA_INCLUDE_VIDEO, true)

        if (openType == Constant.SELECT_TYPE_CRATE_ALBUM) {
            selectAlbumPath = intent.getStringExtra(Constant.EXTRA_ALBUM_PATH) ?: ""
        }

//        if (openType == Constant.SELECT_TYPE_HIDE) {
//            binding.btDone.text = getString(R.string.hide)
//        }

        preferences = Preferences(this)
        dropdownAnimation = AnimationUtils.loadAnimation(this, R.anim.dropdown_animation)
        getData()
        setSelectAdapter()
    }

    private fun loadBanner() {

    }

    private fun setSelectAdapter() {
        selectImageAdapter = SelectImageListAdapter(this, selectedImageList, deleteListener = {
            selectedImageList.removeAt(it)
            selectImageAdapter?.notifyDataSetChanged()
            pictureAdapter?.notifyDataSetChanged()
            checkSelectionEmpty()
        })
        binding.rvSelect.adapter = selectImageAdapter
    }

    private fun checkSelectionEmpty() {
        binding.loutBottomSelect.visibility =
            if (selectedImageList.isEmpty()) View.GONE else View.VISIBLE
        binding.tvImageSelect.text = "${selectedImageList.size} ${getString(R.string.selected)}"
    }


    fun toggleExpand(mainView: View, actionView: View) {
        if (mainView.isVisible()) {
            mainView.beGone()
            actionView.animate()
                .rotation(0f)
                .setDuration(500).start()
        } else {
            mainView.beVisible()
            actionView.animate()
                .rotation(180f)
                .setDuration(500).start()
        }
    }

    override fun onBackPressed() {
        if (spinnerPos != -1) {
            binding.tvPhotos.performClick()
        } else {
            finish()
        }
    }

    private fun intListener() {
        binding.icBack.setOnClickListener { onBackPressed() }

        binding.togglePreview.setOnClickListener {
            toggleExpand(binding.loutBottomSelect, binding.togglePreview)
        }
        binding.icDelete.setOnClickListener {
            val confirmationDialog = ActionConfirmationDialog(
                this,
                getString(R.string.clear_all),
                getString(R.string.clear_all_msg),
                getString(R.string.yes),
                positiveBtnClickListener = {
                    selectedImageList.clear()
                    selectImageAdapter?.notifyDataSetChanged()
                    pictureAdapter?.notifyDataSetChanged()
                    checkSelectionEmpty()
                },
                false,
                getString(R.string.no)
            )
            confirmationDialog.show()
        }

        binding.tvPhotos.setOnClickListener {
            binding.tvAlbums.backgroundTintList = null
            binding.tvPhotos.backgroundTintList = null

            setImageAdapter(-1)
            binding.llPhoto.beVisible()
            binding.llAlbum.beGone()

            binding.tvPhotos.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#1878F3"))
            binding.tvAlbums.background = resources.getDrawable(R.drawable.roundcorner)
            binding.tvPhotos.setTextColor(Color.parseColor("#FFFFFF"))
            binding.tvAlbums.setTextColor(ContextCompat.getColor(this, R.color.black_text))
        }
        binding.tvAlbums.setOnClickListener {
            binding.tvAlbums.backgroundTintList = null
            binding.tvPhotos.backgroundTintList = null

            binding.llPhoto.beGone()
            binding.llAlbum.beVisible()

            binding.tvPhotos.background = resources.getDrawable(R.drawable.roundcorner)
            binding.tvAlbums.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#1878F3"))
            binding.tvPhotos.setTextColor(ContextCompat.getColor(this, R.color.black_text))
            binding.tvAlbums.setTextColor(Color.parseColor("#FFFFFF"))
        }


        binding.btnDone.setOnClickListener {
            if (selectedImageList.isNotEmpty()) {

                if (openType == Constant.SELECT_TYPE_CRATE_ALBUM) {

                    CopyMoveDialog(this, { option ->
                        val file = File(selectAlbumPath)
                        if (!file.exists())
                            file.mkdirs()
                        if (option == 0) {
                            Utils.moveFiles(
                                this,
                                selectAlbumPath,
                                selectedImageList,
                                selectedImageList.size,
                                moveListener = {
                                    preferences.refreshMedia = true
                                    Toast.makeText(
                                        this,
                                        getString(R.string.import_successfully),
                                        Toast.LENGTH_SHORT
                                    ).show()
                                    finish()
                                }
                            )
                        } else if (option == 1) {

                            Utils.copyFiles(
                                this,
                                selectAlbumPath,
                                selectedImageList,
                                selectedImageList.size,
                                copyListener = {
                                    preferences.refreshMedia = true
                                    Toast.makeText(
                                        this,
                                        getString(R.string.import_successfully),
                                        Toast.LENGTH_SHORT
                                    ).show()
                                    finish()
                                }
                            )
                        }
                    }).show()

                } else if (openType == Constant.SELECT_TYPE_CRATE_PDF) {
                    submitPhoto()
                } else if (openType == Constant.SELECT_TYPE_HIDE) {
                    submitPhoto()
                }
            }
        }
//        binding.spinner.viewTreeObserver?.addOnWindowFocusChangeListener { hasFocus -> //This updates the arrow icon up/down depending on Spinner opening/closing
//            Log.e("spinnerTag", "addOnWindowFocusChangeListener $hasFocus ")
//            if (hasFocus) {
//                rotationAngle = if (rotationAngle == 0f) 180f else 0f
//                binding.ivDropDown.animate().rotation(rotationAngle).setDuration(500).start()
//            } else {
//                rotationAngle = if (rotationAngle == 0f) 180f else 0f
//                binding.ivDropDown.animate().rotation(rotationAngle).setDuration(500).start()
//            }
//        }
//        binding.spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
//            override fun onItemSelected(
//                parent: AdapterView<*>?,
//                view: View?,
//                position: Int,
//                id: Long
//            ) {
//
//            }
//
//            override fun onNothingSelected(p0: AdapterView<*>?) {
//                Log.e("spinnerTag", "onNothingSelected")
//            }
//
//        }
    }

    private fun submitPhoto() {
        Constant.selectedImageList = ArrayList()
        Constant.selectedImageList.addAll(selectedImageList)
        setResult(Activity.RESULT_OK)
        finish()
    }

    private fun setImageAdapter(position: Int) {
        binding.llAlbum.beGone()
        binding.llPhoto.beVisible()
        pictures.clear()
        if (position == -1) {
            binding.txtItemSpinner.text = getString(R.string.app_name)
            pictures.addAll(allPictures)
            Log.e("setImageAdapter", "position:${position}")
            Log.e("setImageAdapter", "pictures:${allPictures.size}")
        } else {
            binding.txtItemSpinner.text = albumList[position].title
            pictures.clear()
            pictures.addAll(albumList[position].mediaData)
            Log.e("setImageAdapter", "position:${position}")
            Log.e("setImageAdapter", "pictures:${pictures.size}")
        }

        pictureAdapter = SelectImageAdapter(
            this, pictures,
            selectedImageList,
            clickListener = {
                if (pictures[it] is MediaData) {
                    val pictureData = pictures[it] as MediaData
                    pictureData.isSelected = !pictureData.isSelected
                    if (selectedImageList.contains(pictureData)) {
                        selectedImageList.remove(pictureData)
                    } else {
                        selectedImageList.add(pictureData)
                    }
                    pictureAdapter?.notifyItemChanged(it)
                    selectImageAdapter?.notifyDataSetChanged()
                    checkSelectionEmpty()
                }
            },
            headerSelectListener = {
                if (pictures[it] is AlbumData) {
                    val albumData = pictures[it] as AlbumData
                    val isSelectAll = !albumData.isSelected
                    albumData.isSelected = isSelectAll
                    var pos = it + 1
                    while (pos < pictures.size) {
                        if (pictures[pos] is MediaData) {
                            val model = pictures[pos] as MediaData
                            model.isSelected = isSelectAll
                            pos++
                            if (isSelectAll) {
                                if (!selectedImageList.contains(model)) {
                                    selectedImageList.add(model)
                                }
                            } else {
                                if (selectedImageList.contains(model)) {
                                    selectedImageList.remove(model)
                                }
                            }
                        } else if (pictures[pos] is AlbumData) {
                            break
                        }
                    }
                    selectImageAdapter?.notifyDataSetChanged()
                    pictureAdapter?.notifyDataSetChanged()
                    checkSelectionEmpty()
                }
            })

        binding.pictureRecycler.adapter = pictureAdapter
    }

    fun setSelectedFile() {

    }

    fun setRvLayoutManager() {
        binding.albumRecycler.layoutManager = GridLayoutManager(this, 3, RecyclerView.VERTICAL, false)

//        val gridCount = preferences.getGridCount()
        val gridLayoutManager = GridLayoutManager(this, 4, RecyclerView.VERTICAL, false)
        binding.pictureRecycler.layoutManager = gridLayoutManager
        gridLayoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                if (position >= 0 && position < pictures.size) {
                    return if (pictureAdapter!!.getItemViewType(position) === pictureAdapter!!.ITEM_HEADER_TYPE) {
                        4
                    } else 1
                } else {
                    return 1
                }
            }
        }
    }

    private fun setData() {
        binding.progressBar.visibility = View.GONE
        setEmptyData()
        checkSelectionEmpty()

        if (albumList.isNotEmpty()) {
            spinnerAdapter = SelectAlbumAdapter(this, albumList, { position ->
                Log.e("spinnerTag", "onItemSelected")
                if (spinnerPos != position) {
                    setImageAdapter(position)
                }
            })
            binding.albumRecycler.adapter = spinnerAdapter

            //spinnerAdapter?.setSelection()
//            setImageAdapter(0)

            setImageAdapter(-1)
        }
    }

    private fun setEmptyData() {
        if (albumList != null && albumList.size != 0) {
            binding.pictureRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
        } else {
            binding.pictureRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
        }
    }

    private fun getData() {
        binding.progressBar.visibility = View.VISIBLE

        Log.e("SelectImageActivity", "startMediaLoader")
        MediaLoaderX(
            this,
            addCustomAlbum = false
        ).getAllData(onSuccess = { groupedMediaList, mediaList, mediaFolderList ->
            Log.e("SelectImageActivity", "onSuccess.mediaList:${mediaList.size},albumList:${mediaFolderList.size}")

            allImages.clear()
            allImages.addAll(mediaList)

            allPictures.clear()
            allPictures.addAll(groupedMediaList)

            albumList.clear()
            albumList.addAll(mediaFolderList)

            Log.e("SelectImageActivity", "onSuccess.setData")
            runOnUiThread {
                setData()
            }
        }, onFailed = { error ->
            Log.e("SelectImageActivity", "onFailed.error:$error")
        })
    }

    private fun setDataList() {
        Observable.fromCallable {
            setList()
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread { setData() }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread { setData() }
            }
    }

    private fun setList() {

//        if (allImages.isNotEmpty()) {
//            val albumData = AlbumData()
//            albumData.title = "All"
//            albumData.mediaData = allImages
//            albumList.add(0, albumData)
//        }
        val format = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
        if (albumList.isNotEmpty()) {
            for (a in albumList.indices) {

                val dateWisePictures = LinkedHashMap<String, ArrayList<MediaData>>()
                val picturesList: ArrayList<Any> = ArrayList()
                for (pictureData in albumList[a].mediaData) {
                    val strDate = format.format(pictureData.date)
                    var imagesData1: ArrayList<MediaData> = ArrayList()
                    if (dateWisePictures.containsKey(strDate)) {
                        val list: ArrayList<MediaData>? = dateWisePictures[strDate]
                        if (!list.isNullOrEmpty())
                            imagesData1.addAll(list)
                    } else {
                        imagesData1 = ArrayList()
                    }
                    imagesData1.add(pictureData)
                    dateWisePictures[strDate] = imagesData1

                }
                val keys: Set<String> = dateWisePictures.keys
                val listKeys = ArrayList(keys)

                for (i in listKeys.indices) {
                    val imagesData = dateWisePictures[listKeys[i]]
                    if (imagesData != null && imagesData.size != 0) {
                        val bucketData = AlbumData(listKeys[i], imagesData)
                        picturesList.add(bucketData)
                        picturesList.addAll(imagesData)
                    }
                }

                albumList[a].folderImageList = picturesList
            }
        }

    }

}