package com.photogallery.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.photogallery.databinding.ItemImageViewerBinding
import com.photogallery.model.MediaData

class ImageViewerAdapter(
    var context: Context,
    var list: ArrayList<MediaData>,
    val clickListener: (pos: Int) -> Unit,
    val clickImageListener: (pos: Int) -> Unit
) :
    RecyclerView.Adapter<ImageViewerAdapter.ViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemImageViewerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.displayImage.controller.settings
            .setMaxZoom(7f).doubleTapZoom = 3f

        Glide.with(context).load(list[position].filePath)
            .diskCacheStrategy(DiskCacheStrategy.NONE)
            .skipMemoryCache(true)
            .into(holder.binding.displayImage)

        holder.binding.icVideo.visibility = if (list[position].isVideo) View.VISIBLE else View.GONE
        holder.binding.icVideo.setOnClickListener {
            clickListener(position)
        }
        holder.binding.displayImage.setOnClickListener {
            clickImageListener(position)
        }
    }

    class ViewHolder(var binding: ItemImageViewerBinding) : RecyclerView.ViewHolder(binding.root) {

    }
}