@file:Suppress("DEPRECATION")

package com.mediaplayer.video.player.videoplayer.music.common.feedback

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.inputmethodservice.KeyboardView
import android.net.Uri
import android.os.Bundle
import android.preference.PreferenceManager
import android.provider.Settings
import android.text.TextUtils
import android.util.Base64
import android.util.Log
import android.util.Patterns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.annotation.NonNull
import androidx.core.app.ActivityCompat
import com.mediaplayer.video.player.videoplayer.music.R

import com.google.android.material.snackbar.Snackbar

import java.io.UnsupportedEncodingException
import java.nio.charset.Charset
import java.util.regex.Matcher
import java.util.regex.Pattern


fun KeyboardView.bg(){

}

var a = 5


var position = 0



fun getBaseUrl(encoded: String): String {
    val dataDec: ByteArray = Base64.decode(encoded, Base64.DEFAULT)
    var decodedString = ""
    try {
        decodedString = String(dataDec, Charset.forName("UTF-8"))
    } catch (e: UnsupportedEncodingException) {

    } finally {
        return decodedString
    }
}
fun Context.showPermissionsAlert() {
    val title = "Need Permission"
    val message = "Please Allow Permission"
    val positiveText = "Go to Setting"
    val negativeText = getString(android.R.string.cancel)
//    showAlert(title, message, positiveText, negativeText, object : OnPositive {
//        override fun onYes() {
//            openSettings()
//        }
//    })
}
private fun Context.openSettings() {
    val intent = Intent()
    intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
    intent.data = Uri.fromParts("package", packageName, null)
    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
    startActivity(intent)
}
public fun String.isValidContactInformation(): Boolean {
    return when {
        this.contains("@") -> {
            this.isValidEmail()
        }
        this.isValidPhone() -> {
            return true
        }
        else -> {
            return false
        }
    }
}

@Suppress("unused")
fun String.isValidEmail(): Boolean {
    return !TextUtils.isEmpty(this) && Patterns.EMAIL_ADDRESS.matcher(this).matches()
}

fun String.isValidPhone(): Boolean {
    val phonePattern = "^\\s*(?:\\+?(\\d{1,3}))?[-. (]*(\\d{3})[-. )]*(\\d{3})[-. ]*(\\d{4})(?: *x(\\d+))?\\s*$"
    val pattern = Pattern.compile(phonePattern)
    val matcher: Matcher = pattern.matcher(this)
    return matcher.matches()
}
fun Context.getReviewBaseUrl(): String {
    return getBaseUrl(getString(R.string.base_url_review_live))
}
fun Context.rateApp() {
    try {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")))
    } catch (anfe: ActivityNotFoundException) {
        Log.e("TAG", anfe.toString())
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName")))
    }
}
//fun Context.getUpdateBaseUrl(): String {
//    return getBaseUrl(getString(R.string.base_url_update))
//}
//fun Context.getUpdateBaseUrl1(): String {
//    return getBaseUrl(getString(R.string.base_url_update1))
//}



inline val String.capitalize: String
    get() {
        val strLen = this.length
        if (strLen == 0) {
            return this
        }
        val firstCodePoint = this.codePointAt(0)
        val newCodePoint = Character.toTitleCase(firstCodePoint)
        if (firstCodePoint == newCodePoint) {
            return this
        }
        val newCodePoints = IntArray(strLen) // cannot be longer than the char array
        var outOffset = 0
        newCodePoints[outOffset++] = newCodePoint // copy the first code point
        var inOffset = Character.charCount(firstCodePoint)
        while (inOffset < strLen) {
            val codePoint = this.codePointAt(inOffset)
            newCodePoints[outOffset++] = codePoint // copy the remaining ones
            inOffset += Character.charCount(codePoint)
        }
        return String(newCodePoints, 0, outOffset)
    }


fun Context.doNotAskAgain() {

    val intent = Intent()
    intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
    intent.addCategory(Intent.CATEGORY_DEFAULT)
    intent.data = Uri.parse("package:" + this.packageName)
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
    intent.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
    this.startActivity(intent)


}



//TODO IN APP PURCHASE



//fun showAlert(activity: Activity, title: String, message: String) {
//    val builder = AlertDialog.Builder(
//        activity,
//        R.style.AppCompatAlertDialogStyle
//    )
//    builder.setTitle(title)
//    builder.setMessage(message)
//    builder.setPositiveButton("OK", null)
//    builder.show()
//}

fun View.showSnackbar(snackbarText: String, timeLength: Int) {
    Snackbar.make(this, snackbarText, timeLength).show()
}

@SuppressLint("NewApi")
fun View.updatePadding(
    paddingStart: Int = getPaddingStart(),
    paddingTop: Int = getPaddingTop(),
    paddingEnd: Int = getPaddingEnd(),
    paddingBottom: Int = getPaddingBottom()
) {
    setPaddingRelative(paddingStart, paddingTop, paddingEnd, paddingBottom)
}

fun View.setHeight(value: Int) {
    val lp = layoutParams
    lp?.let {
        lp.height = value
        layoutParams = lp
    }
}

fun Context.toast(text: CharSequence, duration: Int = Toast.LENGTH_SHORT) {
    Toast.makeText(this, text, duration).show()
}


fun ViewGroup.inflate(layoutRes: Int): View {
    return LayoutInflater.from(context).inflate(layoutRes, this, false)
}

fun <T> Context.newactivity(it: Class<T>, extras: Bundle.() -> Unit = {}) {
    var intent = Intent(this, it)
    intent.putExtras(Bundle().apply(extras))
    startActivity(intent)
}

fun getStringPreference(context: Context, key: String): String? {
    var value: String? = null
    val preferences = PreferenceManager.getDefaultSharedPreferences(context)
    if (preferences != null) {
        value = preferences.getString(key, null)
    }
    return value
}

fun setStringPreference(context: Context, key: String, value: String): Boolean {
    val preferences = PreferenceManager.getDefaultSharedPreferences(context)
    if (preferences != null && !TextUtils.isEmpty(key)) {
        val editor = preferences.edit()
        editor.putString(key, value)
        return editor.commit()
    }
    return false
}

fun Context.Share1() {
    try {
        val shareIntent = Intent(Intent.ACTION_SEND)
        shareIntent.type = "text/plain"
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Fonts Keyboard")
        var shareMessage =
            "\n Stylish Fonts For your phone  \n\n"
        shareMessage =
            shareMessage + "https://play.google.com/store/apps/details?id=" + this.packageName + "\n\n"
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
        this.startActivity(Intent.createChooser(shareIntent, "choose one"))
    } catch (e: Exception) {
        //e.toString()
    }

}

fun Context.isPermissionGranted(@NonNull fPermissionList: List<String>): Boolean {

    var lIsGranted = true
    for (lPermission in fPermissionList) {
        if (ActivityCompat.checkSelfPermission(
                this,
                lPermission
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            lIsGranted = false
        }
    }

    return lIsGranted
}