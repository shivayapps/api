package com.mediaplayer.video.player.videoplayer.music.common.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "video_playlist")
data class VideoPlaylist(
    @PrimaryKey
    var PlaylistName : String ="",
) : Serializable
