package com.mediaplayer.video.player.videoplayer.music.common.newInApp

import com.android.billingclient.api.Purchase


const val PLAY_STORE_SUBSCRIPTION_URL = "https://play.google.com/store/account/subscriptions"
const val PLAY_STORE_SUBSCRIPTION_DEEPLINK_URL = "https://play.google.com/store/account/subscriptions?sku=%s&package=%s"


//const val PRODUCT_PURCHASED = "android.test.purchased"

//const val PRODUCT_PURCHASED = "com.camera.scanner.subscription.onetime"

const val SUBSCRIPTION_ONE_MONTH = "subscription.one.month"
const val SUBSCRIPTION_SIX_MONTH = "subscription.six.month"
const val SUBSCRIPTION_ONE_YEAR = "subscription.one.year"
const val SUBSCRIPTION_LIFE_TIME = "subscription.lifetime"

//const val NORMAL_SKU = "com.camera.scanner.subscription.monthly.discount"

//const val MONTH_SKU = "com.mediaplayer.video.player.subscription.weeklyy"

//const val YEAR_SKU = "com.mediaplayer.video.player.subscription.yearly"

//const val DISCOUNT_SKU = "com.camera.scanner.subscription.monthly.discount"


// List of purchased products
val purchaseHistory: ArrayList<Purchase> = ArrayList()

// List of available products to buy
val PRODUCT_LIST: ArrayList<DaoProducts> = ArrayList()

// SKU list
val skuPurchaseList = listOf(SUBSCRIPTION_LIFE_TIME)
val skuSubList = listOf(SUBSCRIPTION_ONE_MONTH, SUBSCRIPTION_SIX_MONTH, SUBSCRIPTION_ONE_YEAR)


