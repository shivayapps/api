package com.mediaplayer.video.player.videoplayer.music.common.activity

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.Purchase
import com.google.firebase.analytics.FirebaseAnalytics
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.adapter.ImgAdapter
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingActivity
import com.mediaplayer.video.player.videoplayer.music.common.newInApp.*
import com.mediaplayer.video.player.videoplayer.music.common.utils.ItemOffsetDecoration
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivitySubscriptionBinding
import com.mediaplayer.video.player.videoplayer.music.musicplayer.App
import com.mediaplayer.video.player.videoplayer.music.musicplayer.GENERAL_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.IMAGE_THEME

import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.setDrawBehindSystemBars
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.setImmersiveFullscreen
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.PreferenceUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.json.JSONObject

class SubscriptionActivity : BaseBindingActivity<ActivitySubscriptionBinding>(),
    ProductPurchaseHelper.ProductPurchaseListener {

    private lateinit var mImgAdapter: ImgAdapter
    private var mSelectedSubscriptionPeriod = ""

    //    var productKeyYear = ""
//    var productKeyMonth = ""
//    var trialYear = ""
//    var trial = ""
    private var mode = "year"

    private var mFirebaseAnalytics: FirebaseAnalytics? = null

    private enum class SubUI {
        _Month, _6_Month, _Year, Life
    }

    override fun getActivityContext(): FragmentActivity {
        return this@SubscriptionActivity
    }

    override fun setBinding(): ActivitySubscriptionBinding {
        return ActivitySubscriptionBinding.inflate(layoutInflater)
    }

    override fun initView() {
        super.initView()

        initBilling()

        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        } else {
            setImmersiveFullscreen()
        }
        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            IMAGE_THEME, ""
        )
        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            GENERAL_THEME, ""
        )

        if (editors == "theme_one") {

            mBinding.root.background =
                ContextCompat.getDrawable(mActivity, R.drawable.img_theme_one)
        } else if (editors == "theme_two") {

            mBinding.root.background =
                ContextCompat.getDrawable(mActivity, R.drawable.img_theme_two)
        } else if (edit == "ligt" || edit == "dark") {
            mBinding.root.background = null
        }
        val img = intArrayOf(
            R.drawable.img_one,
            R.drawable.img_two,
            R.drawable.img_three,
            R.drawable.img_four,
            R.drawable.img_five,
            R.drawable.img_six,
            R.drawable.img_seven,
            R.drawable.img_eight
        )

        mImgAdapter = ImgAdapter(mActivity, img)

        mBinding.rvSubImg.run {
            adapter = mImgAdapter
            addItemDecoration(ItemOffsetDecoration(mActivity, R.dimen._4sdp))
        }

        val duration = 10
        val pixelsToMove = 25
        val mHandler: Handler = Handler(Looper.getMainLooper())
        val SCROLLING_RUNNABLE: Runnable = object : Runnable {
            override fun run() {
                mBinding.rvSubImg.smoothScrollBy(pixelsToMove, 0)
                mHandler.postDelayed(this, duration.toLong())
            }
        }

        mBinding.rvSubImg.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                val lastItem: Int =
                    (mBinding.rvSubImg.layoutManager as LinearLayoutManager).findLastCompletelyVisibleItemPosition()
                if (lastItem == mBinding.rvSubImg.layoutManager!!.itemCount - 1) {
                    (mBinding.rvSubImg.layoutManager as LinearLayoutManager).smoothScrollToPosition(
                        mBinding.rvSubImg,
                        RecyclerView.State(),
                        0
                    )
                }
            }
        })
        mHandler.postDelayed(SCROLLING_RUNNABLE, 500)

        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this)

    }

    override fun initViewAction() {
        super.initViewAction()

//        productKeyYear = InAppPurchaseHelper.instance!!.getProductPrice(YEAR_SKU)
//        productKeyMonth = InAppPurchaseHelper.instance!!.getProductPrice(MONTH_SKU)

//        mBinding.tvYearlyPrice.text = productKeyYear
//        mBinding.tvMonthlyPrice.text = productKeyMonth
//        Log.e(TAG, "initViewAction: $productKeyYear : $productKeyMonth", )
//
//        try {
//
//            val lYearNumber: String = productKeyYear.replace("""[^0-9.]""".toRegex(), "")
//            val lWeekNumber: String = productKeyMonth.replace("""[^0-9.]""".toRegex(), "")
//
//            Log.e(TAG, "getSubscriptionPrice: lYearNumber $lYearNumber")
//            Log.e(TAG, "getSubscriptionPrice: lWeekNumber $lWeekNumber")
//
//            if (lYearNumber.isNotEmpty()) {
//
//                val lWeekPrize: Double = (lWeekNumber.toDouble() * 52) - lYearNumber.toDouble() //5300
//                Log.e(TAG, "getSubscriptionPrice: lWeekPrize $lWeekPrize")
//
//                val lYearPrizeBaseOfWeek = (lWeekNumber.toDouble() * 52)//7800
//                Log.e(TAG, "getSubscriptionPrice: lYearPrizeBaseOfWeek $lYearPrizeBaseOfWeek")
//
//                val lDiscount = (lWeekPrize / lYearPrizeBaseOfWeek) * 100//67
//                Log.e(TAG, "getSubscriptionPrice: lDiscount $lDiscount")
//
//                val countedWeekPrice: String = productKeyMonth.replace(
//                    lWeekNumber,
//                    String.format("%.2f", (lYearNumber.toDouble() / 52))
//                )
//                Log.e(TAG, "getSubscriptionPrice: countedWeekPrice $countedWeekPrice")
//
//               mBinding.tvYearMonthPrize.text = "$countedWeekPrice /${resources.getString(R.string.week)}"
//
////                mBinding.tvSaveSpecial.text = "${resources.getString(R.string.save)} ${lDiscount.toInt()}%"
//
//
//            }
//
//        } catch (e: Exception) {
//
//        }

//        try {
//            trialYear = ProductPurchaseHelper.instance!!.getSkuDetails(YEAR_SKU)!!.freeTrialPeriod[1].toString().plus(" " + "Days free trial" )
//            Log.e(TAG, "initViewAction: $trialYear", )
//            trial = InAppPurchaseHelper.instance!!.getSkuDetails(YEAR_SKU)!!.freeTrialPeriod[1].toString()
//            Log.e(TAG, "initViewAction: $trial", )
//        }catch (e:Exception) {
//        }

        setupUI(SubUI._6_Month)

    }

    override fun initViewListener() {
        super.initViewListener()

        mBinding.btnSubscription.setOnClickListener(this)
//        mBinding.cardStudent.setOnClickListener(this)
//        mBinding.cardYear.setOnClickListener(this)
//        mBinding.cardLife.setOnClickListener(this)
        mBinding.btnSubscription.setOnClickListener(this)
        mBinding.ivClose.setOnClickListener(this)
        mBinding.tvPrivacy.setOnClickListener(this)

    }

    override fun onClick(v: View) {
        super.onClick(v)
        when (v.id) {
            R.id.iv_close -> {
                onBackPressed()
            }
            R.id.tv_privacy -> {
                openURL("https://vasundharaapps.com/video-player/privacy-policy")
            }
//            R.id.card_student ->
//            {
//                setupUI(SubUI._Month)
//                mode = "month"
//            }
//            R.id.card_year ->
//            {
//                setupUI(SubUI._6_Month)
//                mode = "year"
//            }
//            R.id.card_life ->
//            {
//                setupUI(SubUI.Life)
//            }
            R.id.btn_subscription -> {
                if (mode.equals("year")) {
                    GlobalScope.launch {
                        ProductPurchaseHelper.subscribeProduct(
                            this@SubscriptionActivity,
                            mSelectedSubscriptionPeriod,
                            false
                        )
                    }
                }
            }
        }
    }

    private fun openURL(fURL: String) {
        try {
            val customTabsIntent: CustomTabsIntent = CustomTabsIntent.Builder()
                .addDefaultShareMenuItem()
                .setToolbarColor(ContextCompat.getColor(mActivity, R.color.bg_light_color))
                .setShowTitle(true)
                .addDefaultShareMenuItem()
                .build()
            customTabsIntent.launchUrl(mActivity, Uri.parse(fURL.replace(" ", "+")))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(
                mActivity, "No application can handle this request."
                        + " Please install a web browser", Toast.LENGTH_LONG
            ).show()

        }
    }

    override fun fromActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.fromActivityResult(requestCode, resultCode, data)
        if (requestCode == 111 && resultCode == RESULT_OK) {
            setResult(RESULT_OK)
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
    }

    private fun setupUI(fType: SubUI) {

        when (fType) {

            SubUI._Month -> {

                //    mBinding.conStudentSave.visibility = View.VISIBLE
//                mBinding.conSpecialSave.visibility = View.GONE
//                mBinding.conLifeSave.visibility = View.GONE
//                mBinding.conStudent.background = ContextCompat.getDrawable(mActivity,R.drawable.rounded_selected_student)
//                mBinding.conSpecial.background = null
//                mBinding.conLife.background = null
                mBinding.btnSubscription.text = "Subscribe Now"
                mBinding.tvCancelAnytime.text = "Billed weekly, cancel anytime"

                val product = ProductPurchaseHelper.getProductInfo("_Month")

            }

            SubUI._6_Month -> {

//                mBinding.conStudentSave.visibility = View.GONE
//                mBinding.conSpecialSave.visibility = View.VISIBLE
//                mBinding.conLifeSave.visibility = View.GONE
//                mBinding.conStudent.background = null
//                mBinding.conSpecial.background = ContextCompat.getDrawable(mActivity,R.drawable.rounded_selected_special)
//                mBinding.conLife.background = null
                mBinding.tvCancelAnytime.text = "Billed yearly, cancel anytime"

                val product = ProductPurchaseHelper.getProductInfo("_Month")
                if (trial.isNotEmpty()) {
                    mBinding.btnSubscription.text = "Start your " + trialYear
                } else {
                    mBinding.btnSubscription.text = "Subscribe Now"
                }


            }
            SubUI._Year -> {

//                mBinding.conStudentSave.visibility = View.GONE
//                mBinding.conSpecialSave.visibility = View.VISIBLE
//                mBinding.conLifeSave.visibility = View.GONE
//                mBinding.conStudent.background = null
//                mBinding.conSpecial.background = ContextCompat.getDrawable(mActivity,R.drawable.rounded_selected_special)
//                mBinding.conLife.background = null
                mBinding.tvCancelAnytime.text = "Billed yearly, cancel anytime"

                val product = ProductPurchaseHelper.getProductInfo("_Year")
                if (trial.isNotEmpty()) {
                    mBinding.btnSubscription.text = "Start your " + trialYear
                } else {
                    mBinding.btnSubscription.text = "Subscribe Now"
                }


            }

            SubUI.Life -> {

//                mBinding.conStudentSave.visibility = View.GONE
//                mBinding.conSpecialSave.visibility = View.GONE
//                mBinding.conLifeSave.visibility = View.VISIBLE
//                mBinding.conStudent.background = null
//                mBinding.conSpecial.background =null
//                mBinding.conLife.background = ContextCompat.getDrawable(mActivity,R.drawable.rounded_selected_life)


            }
        }

    }

    private fun initBilling() {
        try {
            ProductPurchaseHelper.setLifeTimeProductKey(SUBSCRIPTION_LIFE_TIME)
            ProductPurchaseHelper.setSubscriptionKey(
                SUBSCRIPTION_ONE_MONTH,
                SUBSCRIPTION_SIX_MONTH,
                SUBSCRIPTION_ONE_YEAR
            )
            ProductPurchaseHelper.initBillingClient(this@SubscriptionActivity, this)
        } catch (e: Exception) {

        }
    }

    override fun onPurchasedExpired(productType: String) {

    }

    override fun onPurchasedSuccess(purchase: Purchase) {
        val json = JSONObject(purchase.originalJson)
        when (json.getString("productId")) {
//            SUBSCRIPTION_ONE_MONTH -> {
//                val bundle = Bundle()
//                bundle.putString("WEEKLY_SUBSCRIPTION_SUCCESSFUL", "WEEKLY_SUBSCRIPTION_SUCCESSFUL")
//                mFirebaseAnalytics!!.logEvent("WEEKLY_SUBSCRIPTION_SUCCESSFUL", bundle)
//            }

        }

        val intent = Intent(mActivity, YearSubscriptionSuccessActivity::class.java)
        launchActivityForResult(intent, 111)
    }

    override fun onPurchasedFound(productType: String, purchaseList: MutableList<Purchase>?) {
    }


    override fun onBillingSetupFinished(billingResult: BillingResult) {
        GlobalScope.launch(Dispatchers.Main) {
            ProductPurchaseHelper.initProductsKeys(this@SubscriptionActivity) {

            }
            ProductPurchaseHelper.initSubscriptionKeys(this@SubscriptionActivity) {

            }
        }
    }

    override fun onBillingKeyNotFound(productId: String) {

    }

}