package com.mediaplayer.video.player.videoplayer.music.common.adsHelper

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.util.Log
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.preference.PreferenceManager
import com.example.app.ads.helper.InterstitialAdHelper
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.hsalf.smilerating.BaseRating
import com.hsalf.smilerating.BaseRating.GOOD
import com.hsalf.smilerating.BaseRating.GREAT
import com.hsalf.smilerating.SmileRating
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.activity.ExitActivity
import com.mediaplayer.video.player.videoplayer.music.common.newInApp.AdsManager
import com.mediaplayer.video.player.videoplayer.music.common.utils.displayWidth
import com.mediaplayer.video.player.videoplayer.music.common.utils.isOnline
import com.mediaplayer.video.player.videoplayer.music.musicplayer.App
import com.mediaplayer.video.player.videoplayer.music.musicplayer.RATE_
import kotlinx.android.synthetic.main.layout_ad_view.*


private const val TAG = "ExitDialogs"

var RATING = -1


fun AppCompatActivity.exitDialog() {
    try {

        val inflater = this.layoutInflater
        val alertLayout = inflater.inflate(R.layout.dialog_exit_with_native_ad, null)
        val btnNo = alertLayout.findViewById<TextView>(R.id.btn_no)
        val btnYes = alertLayout.findViewById<TextView>(R.id.btn_yes)


        val adContainer = alertLayout.findViewById<FrameLayout>(R.id.ad_view_container_mob)

        if (AdsManager(this).isNeedToShowAds() && isOnline) {
            InterstitialAdHelper.loadInterstitialAd(this)
            NativeAdvancedModelHelper.destroy()
            NativeAdvancedModelHelper(this).loadNativeAdvancedAd(NativeAdsSize.Big, adContainer, isAddVideoOptions = false)
        }

        val alert = Dialog(this)
        window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        alert.setContentView(alertLayout)
        alert.setCancelable(false)
        alert.setCanceledOnTouchOutside(false)

        window!!.setGravity(Gravity.CENTER)
        window!!.setLayout((0.9 * this.displayWidth).toInt(), Toolbar.LayoutParams.WRAP_CONTENT)
        btnNo.setOnClickListener { alert.dismiss() }
        btnYes.setOnClickListener {
            ExitSPHelper(this).updateExitCount()
            alert.dismiss()

            if (isOnline && AdsManager(this).isNeedToShowAds()) {
                isShowInterstitialAd(true){
                    startActivity(Intent(this@exitDialog, ExitActivity::class.java))
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                }
            } else {
                startActivity(Intent(this@exitDialog, ExitActivity::class.java))
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            }
        }

        alert.show()
    } catch (ignored: Exception) {
        Log.e(TAG, ignored.toString())
    }
}


fun Context.ratingDialog(listener: OnRateListener) {
    try {
        Log.i(TAG, "Rate Dialog called")
        val inflater = (this as Activity).layoutInflater
        val alertLayout = inflater.inflate(R.layout.layout_dialog_rate_us, null)
        val smileRating: SmileRating = alertLayout.findViewById(R.id.rate_smile_rating)
        val btnDismiss = alertLayout.findViewById<TextView>(R.id.rate_btn_dismiss)
        val tvTitle = alertLayout.findViewById<TextView>(R.id.rate_tv_title)

        val alert = AlertDialog.Builder(this)
        alert.setView(alertLayout)
        alert.setCancelable(false)
        val dialog = alert.create()
        btnDismiss.setOnClickListener {
            ExitSPHelper(this).saveDismissed(true)
            RATING = -1
            dialog.dismiss()
        }
        dialog.setOnDismissListener { listener.onRate(RATING) }

        smileRating.setNameForSmile(BaseRating.TERRIBLE, getString(R.string.rating_terrible))
        smileRating.setNameForSmile(BaseRating.BAD, getString(R.string.rating_bad))
        smileRating.setNameForSmile(BaseRating.OKAY, getString(R.string.rating_okay))
        smileRating.setNameForSmile(BaseRating.GOOD, getString(R.string.rating_good))
        smileRating.setNameForSmile(BaseRating.GREAT, getString(R.string.rating_great))

        smileRating.setOnSmileySelectionListener { smiley, _ ->
            val editor = PreferenceManager.getDefaultSharedPreferences(App.getContext())
            editor.edit().putString(RATE_,"yes").apply()
            dialog.dismiss()
            ExitSPHelper(this).saveRate(true)

            RATING = if (smiley == GOOD || smiley == GREAT) {
                4
            } else if (smiley == BaseRating.TERRIBLE) {
                1
            } else if (smiley == BaseRating.TERRIBLE) {
                2
            } else if (smiley == BaseRating.TERRIBLE) {
                3
            } else {
                1
            }
        }
        dialog.show()
    } catch (ignored: Exception) {
        Log.e(TAG, ignored.toString())
    }
}


fun Activity.rateApp() {

    try {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")))
    } catch (anfe: ActivityNotFoundException) {
        Log.e(TAG, anfe.toString())
        startActivity(
            Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://play.google.com/store/apps/details?id=$packageName")
            )
        )
    }
}

interface OnRateListener {
    fun onRate(rate: Int)
}