/*
 * Copyright (c) 2020 Hemanth Savarla.
 *
 * Licensed under the GNU General Public License v3
 *
 * This is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 */
package com.mediaplayer.video.player.videoplayer.music.musicplayer

import android.app.Activity
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import code.name.monkey.appthemehelper.ThemeStore
import code.name.monkey.appthemehelper.util.VersionUtils
import com.example.app.ads.helper.VasuAdsConfig
import com.example.app.ads.helper.openad.AppOpenApplication
import com.example.app.ads.helper.openad.OpenAdHelper
import com.example.app.appcenter.MoreAppsActivity
import com.facebook.FacebookSdk
import com.mediaplayer.video.player.videoplayer.music.musicplayer.appshortcuts.DynamicShortcutManager
import com.mediaplayer.video.player.videoplayer.music.musicplayer.helper.WallpaperAccentManager
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.activity.SplashActivity
import com.mediaplayer.video.player.videoplayer.music.common.activity.SubscriptionActivity
import com.mediaplayer.video.player.videoplayer.music.common.newInApp.AdsManager
import com.onesignal.OneSignal
import com.mediaplayer.video.player.videoplayer.music.common.activity.OutMusicActivity
import com.mediaplayer.video.player.videoplayer.music.common.utils.NetworkChangeReceiver
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin
import java.security.MessageDigest

class App :  AppOpenApplication(), AppOpenApplication.AppLifecycleListener {


    private val wallpaperAccentManager = WallpaperAccentManager(this)

    override fun onCreate() {
        super.onCreate()

        instance = this

        startKoin {
            androidContext(this@App)
            modules(appModules)
        }

        if (!ThemeStore.isConfigured(this, 3)) {
            ThemeStore.editTheme(this)
                .accentColorRes(R.color.select_text_color)
                .coloredNavigationBar(true)
                .commit()
        }
        wallpaperAccentManager.init()

        if (VersionUtils.hasNougatMR())
            DynamicShortcutManager(this).initDynamicShortcuts()


        try {

            setAppLifecycleListener(this)
            FacebookSdk.sdkInitialize(this)

            VasuAdsConfig.with(applicationContext)
                .isEnableOpenAd(true)
                .setAdmobAppId(getString(R.string.admob_app_id))
                .setAdmobInterstitialAdId(getString(R.string.admob_interstitial_ad_id))
                .setAdmobNativeAdvancedAdId(getString(R.string.admob_native_advanced_ad_id))
                .setAdmobOpenAdId(getString(R.string.admob_open_ad_id))
                .initialize()

            initMobileAds("29237066D400BEE88311EF9E95282881","5F7389A91982D6377F521F84F79C1186","487309CB03DA41AAEC610EB04FE2BCC5",
                "EA31E345EBEC43D7863865B2E54FDD76","9CE8EE0D888F04B11EF54CFEE7958B3C","E05F62E81809F1B93F5F1E528D2F1E64",
                "1AC5B496784B91FF599A94E3DA48B393","F79B7245F65D16A26A43BE8EEC21FF40","2C442444C379814ECB90C6034B1C552E","641288EB9DDC7F60B2B10271422AF26F",
                "8A2D831696195FD09F006F237E797FC1","A7503292B2D6A0825C576DF4D1512159","135E675E9D65ED36BFA8CE734266CAA0","EB405C82A1E756B8033A9668D52A8578",
                "21FAC2CB1D8CB17678B0F11D536632AC","D9DFEFF41E2FDFE56FC3CC89E878CB73","113509A6A88562BAD5272F88B4C3949D","126C1A166BC85A4FC5797CE8AC1C5966",
                "CAA8892AF5E3DB16CEAB55DDC700F772","8AAF60B70F9D732D24AD799F7FACBA6A","032A2864719136B90B2304FC866348A4","943E8614610F57152224B5F44FD1F6B4",
                "F8245A377CA41FBAA36AA02B1A843BA4","ACAF0274E871E994A9F44D00A72AE99F")

            OpenAdHelper.destroy()
            OpenAdHelper.loadOpenAd(applicationContext)

            FacebookSdk.setAutoInitEnabled(true)
            FacebookSdk.fullyInitialize()

            OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE)
            OneSignal.initWithContext(applicationContext)
            OneSignal.setAppId("920a10c9-3a80-4020-8278-196a15a99b89")

            val filter = IntentFilter()
            filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
            registerReceiver(NetworkChangeReceiver(), filter)

            val info = packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES)
            for (signature in info.signatures) {
                val md = MessageDigest.getInstance("SHA")
                md.update(signature.toByteArray())

                //Log.e("KeyHash:", Base64.encodeToString(md.digest(), Base64.DEFAULT))
            }



        }catch (e : Exception)
        {}

    }

    override fun onTerminate() {
        super.onTerminate()

        wallpaperAccentManager.release()
    }

    companion object {
        private var instance: App? = null

        fun getContext(): App {
            return instance!!
        }

        fun isProVersion(): Boolean {
            return AdsManager(instance!!.applicationContext).isNeedToShowAds()
        }
    }

    override fun onResumeApp(fCurrentActivity: Activity): Boolean {
        return when {
            fCurrentActivity is SplashActivity -> {

                false

            }
            fCurrentActivity is SubscriptionActivity ->
            {

                false

            }
            fCurrentActivity is OutMusicActivity ->
            {

                false

            }
            fCurrentActivity.localClassName == MoreAppsActivity::class.java.canonicalName -> {


                false

            }
            AdsManager(fCurrentActivity).isNeedToShowAds() -> {
                true
            }

            else -> {
                false
            }
        }
    }
}
