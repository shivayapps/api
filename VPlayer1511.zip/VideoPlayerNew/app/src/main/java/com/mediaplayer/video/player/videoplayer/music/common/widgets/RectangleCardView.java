package com.mediaplayer.video.player.videoplayer.music.common.widgets;

import android.content.Context;
import android.util.AttributeSet;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;

public class RectangleCardView extends CardView {
    public RectangleCardView(@NonNull Context context) {
        super(context);
    }

    public RectangleCardView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public RectangleCardView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, widthMeasureSpec );

        int width = getMeasuredWidth();
        int heigth = getMeasuredHeight();

        setMeasuredDimension(width, (int) (width*0.70));

    }
}
