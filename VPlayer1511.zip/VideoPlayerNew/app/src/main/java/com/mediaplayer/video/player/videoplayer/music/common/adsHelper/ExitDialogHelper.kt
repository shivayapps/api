package com.mediaplayer.video.player.videoplayer.music.common.adsHelper

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import com.mediaplayer.video.player.videoplayer.music.common.adsHelper.*
import com.mediaplayer.video.player.videoplayer.music.common.feedback.FeedbackActivity



const val rateDialogCount = 5

fun AppCompatActivity.displayExitDialog(isRating: Boolean) {
    val sp = ExitSPHelper(this)

    if (isRating) {
        if (!sp.isRated()) {
            ratingDialog(object : OnRateListener {
                override fun onRate(rate: Int) {
                    sp.saveRatingCount(rate)
                    if(rate > 0){
                        if (rate > 3) {
                            rateApp()
                        } else {
                            val subscriptionIntent = Intent(this@displayExitDialog, FeedbackActivity::class.java)
                            subscriptionIntent.putExtra("Rating",rate)
                            startActivity(subscriptionIntent)
                        }
                    }
                }
            })
        }
    } else {
        if (!sp.isRated() && sp.getExitCount() >= rateDialogCount && !sp.isDismissed()) {
            ratingDialog(object : OnRateListener {
                override fun onRate(rate: Int) {
                    if(rate > 0){
                        if (rate > 3) {
                            rateApp()
                        } else {
                            val subscriptionIntent = Intent(this@displayExitDialog, FeedbackActivity::class.java)
                            subscriptionIntent.putExtra("Rating",rate)
                            startActivity(subscriptionIntent)
                        }
                    }
                }
            })
        } else {
            sp.saveDismissed(false)
            exitDialog()
        }
    }


}