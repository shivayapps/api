package com.mediaplayer.video.player.videoplayer.music.musicplayer.fragment

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Intent
import android.graphics.Color
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import androidx.core.animation.doOnEnd
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isGone
import androidx.fragment.app.Fragment
import androidx.fragment.app.commit
import androidx.navigation.NavOptions
import code.name.monkey.appthemehelper.util.VersionUtils
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.activity.MainActivity
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingFragment
import com.mediaplayer.video.player.videoplayer.music.databinding.FragmentMusicMainBinding

import com.mediaplayer.video.player.videoplayer.music.musicplayer.RetroBottomSheetBehavior
import com.mediaplayer.video.player.videoplayer.music.musicplayer.activities.MusicPlayerActivity
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.*
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.LibraryViewModel
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.NowPlayingScreen
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.base.AbsPlayerFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.other.MiniPlayerFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.adaptive.AdaptiveFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.blur.BlurPlayerFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.card.CardFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.cardblur.CardBlurFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.circle.CirclePlayerFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.classic.ClassicPlayerFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.color.ColorFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.fit.FitFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.flat.FlatPlayerFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.full.FullPlayerFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.gradient.GradientPlayerFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.material.MaterialFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.normal.PlayerFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.peek.PeekPlayerFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.plain.PlainPlayerFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.simple.SimplePlayerFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.tiny.TinyPlayerFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.helper.MusicPlayerRemote
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.PreferenceUtil
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.RetroUtil
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.ViewUtil
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetBehavior.*
import com.google.android.material.tabs.TabLayout
import org.koin.androidx.viewmodel.ext.android.viewModel


class MusicMainFragment : BaseBindingFragment<FragmentMusicMainBinding>() {


    private lateinit var bottomSheetBehavior: RetroBottomSheetBehavior<FrameLayout>
    private val argbEvaluator: ArgbEvaluator = ArgbEvaluator()
    private var playerFragment: AbsPlayerFragment? = null
    private var miniPlayerFragment: MiniPlayerFragment? = null
    private var nowPlayingScreen: NowPlayingScreen? = null
    private var navigationBarColor = 0
    private var taskColor: Int = 0
    private var paletteColor: Int = Color.WHITE
    private val panelState: Int get() = bottomSheetBehavior.state
    private var navigationBarColorAnimator: ValueAnimator? = null
    protected val libraryViewModel by viewModel<LibraryViewModel>()

    private var windowInsets: WindowInsetsCompat? = null

    private val bottomSheetCallbackList = object : BottomSheetBehavior.BottomSheetCallback() {

        override fun onSlide(bottomSheet: View, slideOffset: Float) {
            setMiniPlayerAlphaProgress(slideOffset)

            navigationBarColorAnimator?.cancel()
            (requireActivity() as MainActivity).setNavigationBarColorPreOreo(
                argbEvaluator.evaluate(
                    slideOffset,
                    surfaceColor(),
                    navigationBarColor
                ) as Int
            )
        }
        override fun onStateChanged(bottomSheet: View, newState: Int) {
            when (newState) {
                STATE_EXPANDED -> {
                    onPanelExpanded()
                    if (PreferenceUtil.lyricsScreenOn && PreferenceUtil.showLyrics) {
                        (requireActivity() as MainActivity).keepScreenOn(true)
                    }
                }
                STATE_COLLAPSED -> {
                    onPanelCollapsed()
                    if ((PreferenceUtil.lyricsScreenOn && PreferenceUtil.showLyrics) || !PreferenceUtil.isScreenOnEnabled) {
                        (requireActivity() as MainActivity).keepScreenOn(false)
                    }
                }
                STATE_SETTLING, STATE_DRAGGING -> {

//                    if (fromNotification) {
//                        binding.bottomNavigationView.bringToFront()
//                        fromNotification = false
//                    }
                }
                else -> {
                    println("Do a flip")
                }
            }
        }
    }



    fun getBottomSheetBehavior() = bottomSheetBehavior
    override fun setBinding(
        layoutInflater: LayoutInflater,
        container: ViewGroup?
    ): FragmentMusicMainBinding {
       return  FragmentMusicMainBinding.inflate(layoutInflater)
    }

    override fun initView() {
        super.initView()


        chooseFragmentForTheme()
        setupSlidingUpPanel()
        setupBottomSheet()
        updateColor()
        val navController = findNavController(R.id.fragment_container)

        val navInflater = navController.navInflater
        val navGraph = navInflater.inflate(R.navigation.main_graph)

        navController.graph = navGraph

        val navOptions: NavOptions = NavOptions.Builder()
            .setLaunchSingleTop(true)
            .build()


        mBinding.tbMusicMain.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                when (tab.position) {
                    0 -> navController.navigate(R.id.action_home, null, navOptions)
                    1 -> navController.navigate(R.id.action_song, null, navOptions)
                    2 -> navController.navigate(R.id.action_album, null, navOptions)
                    3 -> navController.navigate(R.id.action_artist, null, navOptions)
                    4 -> navController.navigate(R.id.action_playlist, null, navOptions)
                    5 -> navController.navigate(R.id.action_folder, null, navOptions)
                }

            }
            override fun onTabUnselected(tab: TabLayout.Tab) {
            }

            override fun onTabReselected(tab: TabLayout.Tab) {

            }



        })



        navController.addOnDestinationChangedListener { _, destination, _ ->
//            if (destination.id == navGraph.startDestinationId) {
//                ( requireActivity() as MainActivity).currentFragment(R.id.fragment_container)?.enterTransition = null
//            }
            when (destination.id) {
                R.id.action_home, R.id.action_song, R.id.action_album, R.id.action_artist, R.id.action_folder, R.id.action_playlist, R.id.action_genre, R.id.action_search -> {
                    // Save the last tab
                    if (PreferenceUtil.rememberLastTab) {

                    }

                    setBottomNavVisibility(visible = true, animate = true)

                }
                R.id.playing_queue_fragment -> {
                    setBottomNavVisibility(visible = false, hideBottomSheet = true)
                }
                else -> setBottomNavVisibility(
                    visible = false,
                    animate = true
                )
            }
        }
        ViewCompat.setOnApplyWindowInsetsListener(
            mBinding.root
        ) { _, insets ->
            windowInsets = insets
            insets
        }

        if (RetroUtil.isLandscape()) {
            mBinding.slidingPanel.drawAboveSystemBarsWithPadding()
        }


        if (!PreferenceUtil.materialYou) {
            //mBinding.slidingPanel.backgroundTintList = ColorStateList.valueOf(requireActivity().darkAccentColor())
        }

        navigationBarColor = surfaceColor()





    }
    private var isInOneTabMode = false
    fun setBottomNavVisibility(visible: Boolean = true, animate: Boolean = false, hideBottomSheet : Boolean = MusicPlayerRemote.playingQueue.isEmpty()) {
        if (isInOneTabMode) {
//            hideBottomSheet(
//                hide = hideBottomSheet,
//                animate = animate,
//                isBottomNavVisible = false
//            )
            return
        }

        hideBottomSheet(
            hide = hideBottomSheet,
            animate = animate,
            isBottomNavVisible = visible
        )
    }



    fun hideBottomSheet(
        hide: Boolean,
        animate: Boolean = false,
        isBottomNavVisible: Boolean = false
    ) {
        val heightOfBar = dip(R.dimen.mini_player_height)
        val heightOfBarWithTabs = heightOfBar + 0
        if (hide) {
            bottomSheetBehavior.peekHeight = -windowInsets.safeGetBottomInsets()
            bottomSheetBehavior.state = STATE_COLLAPSED
            libraryViewModel.setFabMargin(if (isBottomNavVisible) dip(R.dimen.mini_cast_player_height_expanded) else R.dimen.mini_cast_player_height_expanded)
        } else {
            if (MusicPlayerRemote.playingQueue.isNotEmpty()) {
                mBinding.slidingPanel.elevation = 0F

                if (isBottomNavVisible) {
                    println("List")
                    if (animate) {
                        bottomSheetBehavior.peekHeightAnimate(heightOfBarWithTabs)
                    } else {
                        bottomSheetBehavior.peekHeight = heightOfBarWithTabs
                    }
                    libraryViewModel.setFabMargin(dip(R.dimen.mini_cast_player_height_expanded))
                } else {
                    println("Details")
                    if (animate) {
                        bottomSheetBehavior.peekHeightAnimate(heightOfBar).doOnEnd {
                            mBinding.slidingPanel.bringToFront()
                        }
                    } else {
                        bottomSheetBehavior.peekHeight = heightOfBar
                        mBinding.slidingPanel.bringToFront()
                    }
                    libraryViewModel.setFabMargin(dip(R.dimen.mini_cast_player_height_expanded))
                }
            }
        }
    }




    private fun setupSlidingUpPanel() {

        mBinding.slidingPanel.viewTreeObserver.addOnGlobalLayoutListener(object :
            ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                mBinding.slidingPanel.viewTreeObserver.removeOnGlobalLayoutListener(this)
                if (nowPlayingScreen != NowPlayingScreen.Peek) {
                    val params = mBinding.slidingPanel.layoutParams as ViewGroup.LayoutParams
                    params.height = ViewGroup.LayoutParams.MATCH_PARENT
                    mBinding.slidingPanel.layoutParams = params
                }
                when (panelState) {
                  STATE_EXPANDED -> onPanelExpanded()
                    STATE_COLLAPSED -> onPanelCollapsed()
                    STATE_DRAGGING -> Log.e(TAG, "onGlobalLayout: ", )
                    else -> {
                        // playerFragment!!.onHide()
                    }
                }
            }
        })
    }

    open fun onPanelCollapsed() {
        setMiniPlayerAlphaProgress(0F)
        // restore values
        animateNavigationBarColor(surfaceColor())
        (requireActivity() as MainActivity).setLightStatusBarAuto()
        (requireActivity() as MainActivity).setLightNavigationBarAuto()
        (requireActivity() as MainActivity).setTaskDescriptionColor(taskColor)
        playerFragment?.onHide()

    }
    private fun updateColor() {
        libraryViewModel.paletteColor.observe(this) { color ->
            this.paletteColor = color
            onPaletteColorChanged()
        }
    }

    open fun onPanelExpanded() {
        setMiniPlayerAlphaProgress(1F)
        onPaletteColorChanged()
        playerFragment?.onShow()
    }


    private fun setupBottomSheet() {
        bottomSheetBehavior = from(mBinding.slidingPanel) as RetroBottomSheetBehavior<FrameLayout>
        bottomSheetBehavior.addBottomSheetCallback(bottomSheetCallbackList)
        bottomSheetBehavior.isHideable = false
        bottomSheetBehavior.setAllowDragging(false)
        setMiniPlayerAlphaProgress(0F)
    }
    override fun onResume() {
        super.onResume()
//        if (nowPlayingScreen != PreferenceUtil.nowPlayingScreen) {
//            requireActivity().recreate()
//        }
        if (bottomSheetBehavior.state == STATE_EXPANDED) {
            setMiniPlayerAlphaProgress(1f)
        }

    }

    private fun setMiniPlayerAlphaProgress(progress: Float) {
        if (progress < 0) return
        val alpha = 1 - progress
        miniPlayerFragment?.view?.alpha = 1 - (progress / 0.2F)
        miniPlayerFragment?.view?.isGone = alpha == 0f
        mBinding.playerFragmentContainer.alpha = (progress - 0.2F) / 0.2F


    }

    private fun chooseFragmentForTheme() {
        nowPlayingScreen = PreferenceUtil.nowPlayingScreen

        val fragment: Fragment = when (nowPlayingScreen) {
            NowPlayingScreen.Blur -> BlurPlayerFragment()
            NowPlayingScreen.Adaptive -> AdaptiveFragment()
            NowPlayingScreen.Normal -> PlayerFragment()
            NowPlayingScreen.Card -> CardFragment()
            NowPlayingScreen.BlurCard -> CardBlurFragment()
            NowPlayingScreen.Fit -> FitFragment()
            NowPlayingScreen.Flat -> FlatPlayerFragment()
            NowPlayingScreen.Full -> FullPlayerFragment()
            NowPlayingScreen.Plain -> PlainPlayerFragment()
            NowPlayingScreen.Simple -> SimplePlayerFragment()
            NowPlayingScreen.Material -> MaterialFragment()
            NowPlayingScreen.Color -> ColorFragment()
            NowPlayingScreen.Gradient -> GradientPlayerFragment()
            NowPlayingScreen.Tiny -> TinyPlayerFragment()
            NowPlayingScreen.Peek -> PeekPlayerFragment()
            NowPlayingScreen.Circle -> CirclePlayerFragment()
            NowPlayingScreen.Classic -> ClassicPlayerFragment()
            else -> PlayerFragment()
        }
        requireActivity().supportFragmentManager.commit {
            replace(R.id.playerFragmentContainer, fragment)
        }

        playerFragment = whichFragment<AbsPlayerFragment>(R.id.playerFragmentContainer)
        miniPlayerFragment = whichFragment<MiniPlayerFragment>(R.id.miniPlayerFragment)
        miniPlayerFragment?.view?.setOnClickListener {

            openPlayer()

        }
    }

    fun openPlayer()
    {
        val intent = Intent(mContext,MusicPlayerActivity::class.java)
        launchActivity(intent)
        mContext.overridePendingTransition( R.anim.slide_in_up, R.anim.slide_out_up )
    }

    fun collapsePanel() {
        bottomSheetBehavior.state = BottomSheetBehavior.STATE_COLLAPSED
    }

    fun expandPanel() {
        bottomSheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED
    }
    private fun setTaskDescColor(color: Int) {
        taskColor = color
        if (panelState == STATE_COLLAPSED) {
           requireActivity().setTaskDescriptionColor(color)
        }
    }

    private fun onPaletteColorChanged() {
        if (panelState == STATE_EXPANDED) {
            navigationBarColor = surfaceColor()
            setTaskDescColor(paletteColor)
            val isColorLight = paletteColor.isColorLight
            if (PreferenceUtil.isAdaptiveColor && (nowPlayingScreen == NowPlayingScreen.Normal || nowPlayingScreen == NowPlayingScreen.Flat)) {
                ( requireActivity() as MainActivity).setLightNavigationBar(true)
                ( requireActivity() as MainActivity).setLightStatusBar(isColorLight)
            } else if (nowPlayingScreen == NowPlayingScreen.Card || nowPlayingScreen == NowPlayingScreen.Blur || nowPlayingScreen == NowPlayingScreen.BlurCard) {
                animateNavigationBarColor(Color.BLACK)
                navigationBarColor = Color.BLACK
                ( requireActivity() as MainActivity).setLightStatusBar(false)
                ( requireActivity() as MainActivity).setLightNavigationBar(true)
            } else if (nowPlayingScreen == NowPlayingScreen.Color || nowPlayingScreen == NowPlayingScreen.Tiny || nowPlayingScreen == NowPlayingScreen.Gradient) {
                animateNavigationBarColor(paletteColor)
                navigationBarColor = paletteColor
                ( requireActivity() as MainActivity).setLightNavigationBar(isColorLight)
                ( requireActivity() as MainActivity).setLightStatusBar(isColorLight)
            } else if (nowPlayingScreen == NowPlayingScreen.Full) {
                animateNavigationBarColor(paletteColor)
                navigationBarColor = paletteColor
                ( requireActivity() as MainActivity).setLightNavigationBar(isColorLight)
                ( requireActivity() as MainActivity).setLightStatusBar(false)
            } else if (nowPlayingScreen == NowPlayingScreen.Classic) {
                ( requireActivity() as MainActivity).setLightStatusBar(false)
            } else if (nowPlayingScreen == NowPlayingScreen.Fit) {
                ( requireActivity() as MainActivity).setLightStatusBar(false)
            }
        }
    }

    private fun animateNavigationBarColor(color: Int) {
        if (VersionUtils.hasOreo()) return
        navigationBarColorAnimator?.cancel()
        navigationBarColorAnimator = ValueAnimator
            .ofArgb(requireActivity().window.navigationBarColor, color).apply {
                duration = ViewUtil.RETRO_MUSIC_ANIM_TIME.toLong()
                interpolator = PathInterpolator(0.4f, 0f, 1f, 1f)
                addUpdateListener { animation: ValueAnimator ->
                    ( requireActivity() as MainActivity).setNavigationBarColorPreOreo(
                        animation.animatedValue as Int
                    )
                }
                start()
            }
    }

    companion object{
        fun newInstance(): MusicMainFragment {
            return MusicMainFragment()
        }
    }

}