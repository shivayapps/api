package com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions

import com.mediaplayer.video.player.videoplayer.music.musicplayer.model.Song
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.MusicUtil

val Song.uri get() = MusicUtil.getSongFileUri(songId = id)