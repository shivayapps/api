package com.mediaplayer.video.player.videoplayer.music.musicplayer.activities

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.*
import android.graphics.Color
import android.os.IBinder
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import androidx.core.animation.doOnEnd
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isGone
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.commit
import androidx.lifecycle.lifecycleScope
import androidx.preference.PreferenceManager
import code.name.monkey.appthemehelper.util.VersionUtils
import com.example.app.ads.helper.openad.OpenAdHelper
import com.example.app.ads.helper.openad.OpenAdHelper.isShowOpenAd
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingActivity
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityMusicPlayerBinding

import com.mediaplayer.video.player.videoplayer.music.musicplayer.db.toPlayCount
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.*
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.LibraryViewModel
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.NowPlayingScreen
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.base.AbsPlayerFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.other.MiniPlayerFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.adaptive.AdaptiveFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.blur.BlurPlayerFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.card.CardFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.cardblur.CardBlurFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.circle.CirclePlayerFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.classic.ClassicPlayerFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.color.ColorFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.fit.FitFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.flat.FlatPlayerFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.full.FullPlayerFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.gradient.GradientPlayerFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.material.MaterialFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.normal.PlayerFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.peek.PeekPlayerFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.plain.PlainPlayerFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.simple.SimplePlayerFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.player.tiny.TinyPlayerFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.helper.MusicPlayerRemote
import com.mediaplayer.video.player.videoplayer.music.musicplayer.service.MusicService
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.PreferenceUtil
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.RetroUtil
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.ViewUtil
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.mediaplayer.video.player.videoplayer.music.common.newInApp.AdsManager
import com.mediaplayer.video.player.videoplayer.music.common.utils.isOnline
import com.mediaplayer.video.player.videoplayer.music.musicplayer.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.koin.androidx.viewmodel.ext.android.viewModel
import java.lang.ref.WeakReference

class MusicPlayerActivity : BaseBindingActivity<ActivityMusicPlayerBinding>() {

    private lateinit var bottomSheetBehavior: RetroBottomSheetBehavior<FrameLayout>
    private val argbEvaluator: ArgbEvaluator = ArgbEvaluator()
    private var playerFragment: AbsPlayerFragment? = null
    private var miniPlayerFragment: MiniPlayerFragment? = null
    private var nowPlayingScreen: NowPlayingScreen? = null
    private var navigationBarColor = 0
    private var taskColor: Int = 0
    private var paletteColor: Int = Color.WHITE
    private val panelState: Int get() = bottomSheetBehavior.state
    private var navigationBarColorAnimator: ValueAnimator? = null
    protected val libraryViewModel by viewModel<LibraryViewModel>()

    private var windowInsets: WindowInsetsCompat? = null
    private var isPause = false


    private val bottomSheetCallbackList = object : BottomSheetBehavior.BottomSheetCallback() {

        override fun onSlide(bottomSheet: View, slideOffset: Float) {
            setMiniPlayerAlphaProgress(slideOffset)
            navigationBarColorAnimator?.cancel()
            setNavigationBarColorPreOreo(
                argbEvaluator.evaluate(
                    slideOffset,
                    surfaceColor(),
                    navigationBarColor
                ) as Int
            )
        }
        override fun onStateChanged(bottomSheet: View, newState: Int) {
            when (newState) {
                BottomSheetBehavior.STATE_EXPANDED -> {
                    onPanelExpanded()
                    if (PreferenceUtil.lyricsScreenOn && PreferenceUtil.showLyrics) {
                       keepScreenOn(true)
                    }
                }
                BottomSheetBehavior.STATE_COLLAPSED -> {
                    onPanelCollapsed()
                    if ((PreferenceUtil.lyricsScreenOn && PreferenceUtil.showLyrics) || !PreferenceUtil.isScreenOnEnabled) {
                        keepScreenOn(false)
                    }
                }
                BottomSheetBehavior.STATE_SETTLING, BottomSheetBehavior.STATE_DRAGGING -> {

                    collapsePanel()
                }
                else -> {
                    println("Do a flip")
                }
            }
        }
    }





    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(R.anim.slide_from_top,R.anim.slide_in_top)
    }

    override fun getActivityContext(): FragmentActivity {
        return this@MusicPlayerActivity
    }

    override fun setBinding(): ActivityMusicPlayerBinding {
       return ActivityMusicPlayerBinding.inflate(layoutInflater)
    }

    fun getBottomSheetBehavior() = bottomSheetBehavior


    override fun initView() {
        super.initView()
        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        }
        else{
            setImmersiveFullscreen()
        }


        try {
            if (intent.hasExtra("Click"))
            {
                if (isOnline && AdsManager(mActivity).isNeedToShowAds()) {
                    OpenAdHelper.destroy()
                    OpenAdHelper.loadOpenAd(mActivity) {
                        isShowOpenAd { }
                    }
                }

            }
        }catch (e: Exception)
        {}



        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            IMAGE_THEME,"")
        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            GENERAL_THEME,"")

        if (editors == "theme_one")
        {

            mBinding.root.background = ContextCompat.getDrawable(mActivity,R.drawable.img_theme_one)
        }
        else if (editors == "theme_two")
        {

            mBinding.root.background = ContextCompat.getDrawable(mActivity,R.drawable.img_theme_two)
        }
        else if (edit == "ligt" || edit == "dark")
        {
            mBinding.root.background = null
        }

        serviceToken = MusicPlayerRemote.bindToService(this, object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName, service: IBinder) {
                onServiceConnected()
            }

            override fun onServiceDisconnected(name: ComponentName) {
                onServiceDisconnected()
            }
        })

        chooseFragmentForTheme()
        setupSlidingUpPanel()
        setupBottomSheet()
        updateColor()

        ViewCompat.setOnApplyWindowInsetsListener(
            mBinding.root
        ) { _, insets ->
            windowInsets = insets
            insets
        }

        if (RetroUtil.isLandscape()) {
            mBinding.slidingPanel.drawAboveSystemBarsWithPadding()
        }

        if (!PreferenceUtil.materialYou) {
           // mBinding.slidingPanel.backgroundTintList = ColorStateList.valueOf(darkAccentColor())
        }


        navigationBarColor = surfaceColor()

        setBottomNavVisibility(visible = true, animate = true)

        expandPanel()

        if (PreferenceUtil.lyricsScreenOn && PreferenceUtil.showLyrics) {
            keepScreenOn(true)
        } else if (!PreferenceUtil.isScreenOnEnabled && !PreferenceUtil.showLyrics) {
            keepScreenOn(false)
        }

    }
    private var isInOneTabMode = false
    fun setBottomNavVisibility(visible: Boolean = true, animate: Boolean = false, hideBottomSheet : Boolean = MusicPlayerRemote.playingQueue.isEmpty()) {
        if (isInOneTabMode) {
            return
        }
        hideBottomSheet(hide = hideBottomSheet, animate = animate, isBottomNavVisible = visible)
    }

    fun hideBottomSheet(hide: Boolean, animate: Boolean = false, isBottomNavVisible: Boolean = false) {
        val heightOfBar =  if (MusicPlayerRemote.isCasting) dip(R.dimen.cast_mini_player_height) else dip(R.dimen.mini_player_height)
        val heightOfBarWithTabs = heightOfBar + 0
        if (hide) {
            bottomSheetBehavior.peekHeight = -windowInsets.safeGetBottomInsets()
            bottomSheetBehavior.state = BottomSheetBehavior.STATE_COLLAPSED
        } else {
            if (MusicPlayerRemote.playingQueue.isNotEmpty()) {
               mBinding.slidingPanel.elevation = 0F

                if (isBottomNavVisible) {
                    println("List")
                    if (animate) {
                        bottomSheetBehavior.peekHeightAnimate(heightOfBarWithTabs)
                    } else {
                        bottomSheetBehavior.peekHeight = heightOfBarWithTabs
                    }

                } else {
                    println("Details")
                    if (animate) {
                        bottomSheetBehavior.peekHeightAnimate(heightOfBar).doOnEnd {
                            mBinding.slidingPanel.bringToFront()
                        }
                    } else {
                        bottomSheetBehavior.peekHeight = heightOfBar
                        mBinding.slidingPanel.bringToFront()
                    }
                }
            }
        }
    }



    private fun setupSlidingUpPanel() {

        mBinding.slidingPanel.viewTreeObserver.addOnGlobalLayoutListener(object :
            ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                mBinding.slidingPanel.viewTreeObserver.removeOnGlobalLayoutListener(this)
                if (nowPlayingScreen != NowPlayingScreen.Peek) {
                    val params = mBinding.slidingPanel.layoutParams as ViewGroup.LayoutParams
                    params.height = ViewGroup.LayoutParams.MATCH_PARENT
                    mBinding.slidingPanel.layoutParams = params
                }
                when (panelState) {
                    BottomSheetBehavior.STATE_EXPANDED -> onPanelExpanded()
                    BottomSheetBehavior.STATE_COLLAPSED -> onPanelCollapsed()
                    else -> {
                        // playerFragment!!.onHide()
                    }
                }
            }
        })
    }

    open fun onPanelCollapsed() {
        setMiniPlayerAlphaProgress(0F)
        // restore values
        animateNavigationBarColor(surfaceColor())
    // setLightStatusBarAuto()
     setLightNavigationBarAuto()
     setTaskDescriptionColor(taskColor)
        playerFragment?.onHide()

    }
    private fun updateColor() {
        libraryViewModel.paletteColor.observe(this) { color ->
            this.paletteColor = color
            onPaletteColorChanged()
        }
    }

    open fun onPanelExpanded() {
        setMiniPlayerAlphaProgress(1F)
        onPaletteColorChanged()
        playerFragment?.onShow()
    }


    private fun setupBottomSheet() {
        bottomSheetBehavior = BottomSheetBehavior.from(mBinding.slidingPanel) as RetroBottomSheetBehavior<FrameLayout>
        bottomSheetBehavior.addBottomSheetCallback(bottomSheetCallbackList)
        bottomSheetBehavior.isHideable = false
        bottomSheetBehavior.setAllowDragging(true)
        setMiniPlayerAlphaProgress(0F)
    }

    override fun onPause() {
        super.onPause()
        isPause = true
        Log.e(TAG, "onPause: ", )
    }
    override fun onResume() {
        super.onResume()
        if (nowPlayingScreen != PreferenceUtil.nowPlayingScreen) {
            recreate()
        }
        if (bottomSheetBehavior.state == BottomSheetBehavior.STATE_EXPANDED) {
            setMiniPlayerAlphaProgress(1f)
        }

        if (isPause)
        {
            isPause = false
            if (MusicPlayerRemote.playingQueue.isEmpty()) {

                try {
                    if (intent.hasExtra("Click"))
                    {
                        mActivity.finishAndRemoveTask()
                    }
                    else
                    {
                        onBackPressed()
                    }
                }catch (e: Exception)
                {

                }

            }
        }


    }

    private fun setMiniPlayerAlphaProgress(progress: Float) {
        if (progress < 0) return
        val alpha = 1 - progress
        miniPlayerFragment?.view?.alpha = 1 - (progress / 0.2F)
        miniPlayerFragment?.view?.isGone = alpha == 0f
        mBinding.playerFragmentContainer.alpha = (progress - 0.2F) / 0.2F


    }

    private fun chooseFragmentForTheme() {
        nowPlayingScreen = PreferenceUtil.nowPlayingScreen

        if (AdsManager(mActivity).isNeedToShowAds())
        {

            val fragment : Fragment = when (nowPlayingScreen)
            {
                NowPlayingScreen.Normal ->
                {
                    PlayerFragment()
                }
                NowPlayingScreen.Material -> {
                    MaterialFragment()
                }
                NowPlayingScreen.Gradient -> {GradientPlayerFragment()}
                NowPlayingScreen.Flat -> {FlatPlayerFragment()}
                NowPlayingScreen.Fit -> {FitFragment()}
                NowPlayingScreen.Classic -> {ClassicPlayerFragment()}
                NowPlayingScreen.Peek -> {PeekPlayerFragment()}
                NowPlayingScreen.Tiny ->{ TinyPlayerFragment()}

                else -> {
                    PlayerFragment()
                }
            }
            supportFragmentManager.commit { replace(R.id.playerFragmentContainer, fragment)
            }

            playerFragment = whichFragment<AbsPlayerFragment>(R.id.playerFragmentContainer)
            miniPlayerFragment = whichFragment<MiniPlayerFragment>(R.id.miniPlayerFragment)
            miniPlayerFragment?.view?.setOnClickListener {
                expandPanel()
            }

        }
        else
        {
            val fragment: Fragment = when (nowPlayingScreen) {
                NowPlayingScreen.Blur -> BlurPlayerFragment()
                NowPlayingScreen.Adaptive -> AdaptiveFragment()
                NowPlayingScreen.Normal -> PlayerFragment()
                NowPlayingScreen.Card -> CardFragment()
                NowPlayingScreen.BlurCard -> CardBlurFragment()
                NowPlayingScreen.Fit -> FitFragment()
                NowPlayingScreen.Flat -> FlatPlayerFragment()
                NowPlayingScreen.Full -> FullPlayerFragment()
                NowPlayingScreen.Plain -> PlainPlayerFragment()
                NowPlayingScreen.Simple -> SimplePlayerFragment()
                NowPlayingScreen.Material -> MaterialFragment()
                NowPlayingScreen.Color -> ColorFragment()
                NowPlayingScreen.Gradient -> GradientPlayerFragment()
                NowPlayingScreen.Tiny -> TinyPlayerFragment()
                NowPlayingScreen.Peek -> PeekPlayerFragment()
                NowPlayingScreen.Circle -> CirclePlayerFragment()
                NowPlayingScreen.Classic -> ClassicPlayerFragment()
                else -> PlayerFragment()
            }
            supportFragmentManager.commit { replace(R.id.playerFragmentContainer, fragment)
            }

            playerFragment = whichFragment<AbsPlayerFragment>(R.id.playerFragmentContainer)
            miniPlayerFragment = whichFragment<MiniPlayerFragment>(R.id.miniPlayerFragment)
            miniPlayerFragment?.view?.setOnClickListener {
                expandPanel()
            }
        }


    }


    fun collapsePanel() {
        onBackPressed()
    }

    fun expandPanel() {
        bottomSheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED
    }
    private fun setTaskDescColor(color: Int) {
        taskColor = color
        if (panelState == BottomSheetBehavior.STATE_COLLAPSED) {
            setTaskDescriptionColor(color)
        }
    }

    private fun onPaletteColorChanged() {
        if (panelState == BottomSheetBehavior.STATE_EXPANDED) {
            navigationBarColor = surfaceColor()
            setTaskDescColor(paletteColor)
            val isColorLight = paletteColor.isColorLight
            if (PreferenceUtil.isAdaptiveColor && (nowPlayingScreen == NowPlayingScreen.Normal || nowPlayingScreen == NowPlayingScreen.Flat)) {
             setLightNavigationBar(true)
            // setLightStatusBar(isColorLight)
            } else if (nowPlayingScreen == NowPlayingScreen.Card || nowPlayingScreen == NowPlayingScreen.Blur || nowPlayingScreen == NowPlayingScreen.BlurCard) {
                animateNavigationBarColor(Color.BLACK)
                navigationBarColor = Color.BLACK
            //  setLightStatusBar(false)
              setLightNavigationBar(true)
            } else if (nowPlayingScreen == NowPlayingScreen.Color || nowPlayingScreen == NowPlayingScreen.Tiny || nowPlayingScreen == NowPlayingScreen.Gradient) {
                animateNavigationBarColor(paletteColor)
                navigationBarColor = paletteColor
      setLightNavigationBar(isColorLight)
    //  setLightStatusBar(isColorLight)
            } else if (nowPlayingScreen == NowPlayingScreen.Full) {
                animateNavigationBarColor(paletteColor)
                navigationBarColor = paletteColor
                setDrawBehindSystemBars()
       setLightNavigationBar(isColorLight)
       //setLightStatusBar(false)
            } else if (nowPlayingScreen == NowPlayingScreen.Classic) {
             //  setLightStatusBar(false)
            } else if (nowPlayingScreen == NowPlayingScreen.Fit) {
          // setLightStatusBar(false)
            }
        }
    }

    private fun animateNavigationBarColor(color: Int) {
        if (VersionUtils.hasOreo()) return
        navigationBarColorAnimator?.cancel()
        navigationBarColorAnimator = ValueAnimator
            .ofArgb(window.navigationBarColor, color).apply {
                duration = ViewUtil.RETRO_MUSIC_ANIM_TIME.toLong()
                interpolator = PathInterpolator(0.4f, 0f, 1f, 1f)
                addUpdateListener { animation: ValueAnimator ->
                    setNavigationBarColorPreOreo(
                        animation.animatedValue as Int
                    )
                }
                start()
            }
    }

    override fun onServiceConnected() {
        if (!receiverRegistered) {
            musicStateReceiver = MusicStateReceiver(this)

            val filter = IntentFilter()
            filter.addAction(MusicService.PLAY_STATE_CHANGED)
            filter.addAction(MusicService.SHUFFLE_MODE_CHANGED)
            filter.addAction(MusicService.REPEAT_MODE_CHANGED)
            filter.addAction(MusicService.META_CHANGED)
            filter.addAction(MusicService.QUEUE_CHANGED)
            filter.addAction(MusicService.MEDIA_STORE_CHANGED)
            filter.addAction(MusicService.FAVORITE_STATE_CHANGED)

            registerReceiver(musicStateReceiver, filter)

            receiverRegistered = true
        }

        for (listener in mMusicServiceEventListeners) {
            listener.onServiceConnected()
        }
    }

    var musicStateReceiver: MusicStateReceiver? = null

    class MusicStateReceiver(activity: MusicPlayerActivity) : BroadcastReceiver() {

        val reference: WeakReference<MusicPlayerActivity> = WeakReference(activity)

        override fun onReceive(context: Context, intent: Intent) {
            val action = intent.action
            val activity = reference.get()
            if (activity != null && action != null) {
                when (action) {
                    MusicService.FAVORITE_STATE_CHANGED -> activity.onFavoriteStateChanged()
                    MusicService.META_CHANGED -> activity.onPlayingMetaChanged()
                    MusicService.QUEUE_CHANGED -> activity.onQueueChanged()
                    MusicService.PLAY_STATE_CHANGED -> activity.onPlayStateChanged()
                    MusicService.REPEAT_MODE_CHANGED -> activity.onRepeatModeChanged()
                    MusicService.SHUFFLE_MODE_CHANGED -> activity.onShuffleModeChanged()
                    MusicService.MEDIA_STORE_CHANGED -> activity.onMediaStoreChanged()
                }
            }
        }
    }

    override fun onServiceDisconnected() {
        if (receiverRegistered) {
            unregisterReceiver(musicStateReceiver)
            receiverRegistered = false
        }

        for (listener in mMusicServiceEventListeners) {
            listener.onServiceDisconnected()
        }
    }

    override fun onQueueChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onQueueChanged()
        }
    }


    override fun onPlayingMetaChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onPlayingMetaChanged()
        }
        lifecycleScope.launch(Dispatchers.IO) {
            val entity = repository.songPresentInHistory(MusicPlayerRemote.currentSong)
            if (entity != null) {
                repository.updateHistorySong(MusicPlayerRemote.currentSong)
            } else {
                repository.addSongToHistory(MusicPlayerRemote.currentSong)
            }
            val songs = repository.checkSongExistInPlayCount(MusicPlayerRemote.currentSong.id)
            if (songs.isNotEmpty()) {
                repository.updateSongInPlayCount(songs.first().apply {
                    playCount += 1
                })
            } else {
                repository.insertSongInPlayCount(MusicPlayerRemote.currentSong.toPlayCount())
            }
        }
    }

    override fun onPlayStateChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onPlayStateChanged()
        }
    }

    override fun onRepeatModeChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onRepeatModeChanged()
        }
    }

    override fun onShuffleModeChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onShuffleModeChanged()
        }
    }

    override fun onFavoriteStateChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onFavoriteStateChanged()
        }
    }

    override fun onMediaStoreChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onMediaStoreChanged()
        }
    }
}