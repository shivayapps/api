package com.mediaplayer.video.player.videoplayer.music.musicplayer.model

import android.graphics.Bitmap

class ArtworkInfo constructor(val albumId: Long, val artwork: Bitmap?)
