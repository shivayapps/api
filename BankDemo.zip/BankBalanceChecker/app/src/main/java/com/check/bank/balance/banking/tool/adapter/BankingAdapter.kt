package com.check.bank.balance.banking.tool.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.check.bank.balance.banking.tool.R
import com.check.bank.balance.banking.tool.model.BankingModel

class BankingAdapter(
    var mContext: Context,
    var mBakingList: ArrayList<BankingModel>,
    var clickListener: ClickListener
) :
    RecyclerView.Adapter<BankingAdapter.BankingViewHolder>() {
    class BankingViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var mImage: ImageView = view.findViewById(R.id.mIVBanking)
        var mText: TextView = view.findViewById(R.id.mTVBanking)
//        var mCLItem: ConstraintLayout = view.findViewById(R.id.mCLItem)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BankingViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.single_banking_view, parent, false)
        return BankingViewHolder(view)
    }

    override fun getItemCount(): Int = mBakingList.size

    override fun onBindViewHolder(holder: BankingViewHolder, position: Int) {
        val mList = mBakingList[position]

        holder.mText.text = mList.mText
        Glide.with(mContext).load(mList.mImage).into(holder.mImage)

        holder.itemView.setOnClickListener {
//            Toast.makeText(mContext, "${mList.mText}", Toast.LENGTH_SHORT).show()
            clickListener.onItemClick(position)
        }
    }
    interface ClickListener {
        fun onItemClick(position: Int)
    }
}