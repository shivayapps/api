package com.check.bank.balance.banking.tool.activity

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.check.bank.balance.banking.tool.R
import kotlinx.android.synthetic.main.custom_toolbar.*
import java.text.DecimalFormat
import java.util.regex.Matcher
import java.util.regex.Pattern
import kotlin.math.pow
import android.R.attr.password




class CalculatorActivity : AppCompatActivity() {

    lateinit var mTVTitle1: TextView
    lateinit var mTVTitle2: TextView
    lateinit var mTVTitle3: TextView
    lateinit var mTVTitle4: TextView
    lateinit var mTVTitle5: TextView
    lateinit var mTVTitle6: TextView
    lateinit var mTVTitle7: TextView
    lateinit var mTVTitle8: TextView
    lateinit var mTVTitle9: TextView
    lateinit var mET1: EditText
    lateinit var mET2: EditText
    lateinit var mET3: EditText
    lateinit var mBCal: Button
    lateinit var mBReset: Button
    lateinit var mTVTitle7Scroll: HorizontalScrollView
    lateinit var mTVTitle8Scroll: HorizontalScrollView
    lateinit var mTVTitle9Scroll: HorizontalScrollView
    var input: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val cal = intent.getIntExtra("cal", 0)
        setContentView(R.layout.activity_calculator_new)
        imgBtnBack.setOnClickListener { onBackPressed() }
        hideSystemUI()
        var emi: Double
        var p: Double
        var r: Double
        var n: Double

        mTVTitle1 = findViewById(R.id.mTVTitle1)
        mTVTitle2 = findViewById(R.id.mTVTitle2)
        mTVTitle3 = findViewById(R.id.mTVTitle3)
        mTVTitle4 = findViewById(R.id.mTVTitle4)
        mTVTitle5 = findViewById(R.id.mTVTitle5)
        mTVTitle6 = findViewById(R.id.mTVTitle6)
        mTVTitle7 = findViewById(R.id.mTVTitle7)
        mTVTitle8 = findViewById(R.id.mTVTitle8)
        mTVTitle9 = findViewById(R.id.mTVTitle9)
        mTVTitle7Scroll = findViewById(R.id.mTVTitle7Scroll)
        mTVTitle8Scroll = findViewById(R.id.mTVTitle8Scroll)
        mTVTitle9Scroll = findViewById(R.id.mTVTitle9Scroll)
        mET1 = findViewById(R.id.mET1)
        mET2 = findViewById(R.id.mET2)
        mET3 = findViewById(R.id.mET3)
        mET1.hint = "5000"
        mET3.hint = "10"
        mET2.hint = "Months"
        mBCal = findViewById(R.id.mBCal)
        mBReset = findViewById(R.id.mBReset)

        if (cal == 1) {
            mTVToolbar.text = "EMI Calculator"
            mTVTitle1.text = "Loan Amount"
            mTVTitle2.text = "Period"
            mTVTitle3.text = "Rate(%)"
            mTVTitle4.text = "Monthly EMI"
            mTVTitle5.text = "Total Interest"
            mTVTitle6.text = "Total Payment"
        }
        if (cal == 2) {
            mTVToolbar.text = "LOAN Calculator"
            mTVTitle1.text = "Loan Amount"
            mTVTitle2.text = "Period"
            mTVTitle3.text = "Rate(%)"
            mTVTitle4.text = "Monthly EMI"
            mTVTitle5.text = "Total Interest"
            mTVTitle6.text = "Total Payment"
        }
        if (cal == 4) {
            mTVToolbar.text = "SIP Calculator"
            mTVTitle1.text = "Monthly SIP Investment"
            mTVTitle2.text = "Period"
            mTVTitle3.text = "Rate(%)"
            mTVTitle4.text = "Expected Amount"
            mTVTitle5.text = "Amount Interested"
            mTVTitle6.text = "Wealth Gain"
        }
        if (cal == 3) {
            mET2.hint = "Years"
            mTVToolbar.text = "FD Calculator"
            mTVTitle1.text = "Deposit Investment"
            mTVTitle2.text = "Period"
            mTVTitle3.text = "Rate(%)"
            mTVTitle4.text = "Total Deposit"
            mTVTitle5.text = "Total Interest"
            mTVTitle6.text = "Maturity Amount"
        }

        fun specialValue(str: String) : Boolean{
            var isVailed = true
            val special = Pattern.compile("[.!@#$%&*()_+=|<>?{}\\[\\]~-]")
            if (str.isEmpty()){
                isVailed = false
            }else{
                val hasSpecial = special.matcher(str)
                if (hasSpecial.find()){
                    if (str.length == 1){
                        isVailed = false
                    }else{
                         input = "0$str"
                    }
                }else{
                    isVailed = true
                }
            }
            return isVailed
        }

        mBCal.setOnClickListener {
            val loan1 = mET1.text.toString()
            val loan2 = mET2.text.toString()
            val loan3 = mET3.text.toString()

            if (specialValue(loan1) && specialValue(loan2) && specialValue(loan3)){
                //LOGIC
                mTVTitle7Scroll.fullScroll(HorizontalScrollView.FOCUS_RIGHT)
                mTVTitle8Scroll.fullScroll(HorizontalScrollView.FOCUS_RIGHT)
                mTVTitle9Scroll.fullScroll(HorizontalScrollView.FOCUS_RIGHT)

                if (mET1.text.toString().trim().isNotEmpty()) {
                    try {
                        p = mET1.text.toString().toDouble()
                        if (mET2.text.toString().trim().isNotEmpty()) {
                            n = mET2.text.toString().toDouble()
                            if (mET3.text.toString().trim().isNotEmpty()) {
                                r = mET3.text.toString().toDouble()
                                val rate = r / 12 / 100
                                //  cal 1 == EMI // Cal 2 == LOAN // Cal 3 == FD // Cal 4 == SIP
                                if (cal == 1 || cal == 2) {
                                    val dev = (1 + rate).pow(n)
                                    val fd = p * rate * dev
                                    val d = dev - 1
                                    emi = fd / d
                                    val total = (emi * n)

                                    mTVTitle7.text = "Rs. ${DecimalFormat("##.##").format(emi)}"
                                    mTVTitle8.text = "Rs. ${DecimalFormat("##.##").format(total - p)}"
                                    mTVTitle9.text = "Rs. ${DecimalFormat("##.##").format(total)}"
                                }

                                if (cal == 3) {
                                    var mIncrement = p * (r / 100)
                                    var maturity = p + mIncrement
//                                 var maturityNew = p + (p * r * n/100)
                                    for (i in 2..n.toInt()) {
                                        mIncrement = maturity * (r / 100 )
                                        maturity += mIncrement
                                    }

                                    mTVTitle7.text = "Rs. ${DecimalFormat("##.##").format(p)}"
                                    mTVTitle8.text = "Rs. ${DecimalFormat("##.##").format(maturity - p)}"
                                    mTVTitle9.text = "Rs. ${DecimalFormat("##.##").format(maturity)}"
                                }
                                if (cal == 4) {
                                    val fv = p * (((1 + rate).pow(n) - 1) / rate) * (1 + rate)
                                    mTVTitle7.text = "Rs. ${DecimalFormat("##.##").format(fv)}"
                                    mTVTitle8.text = "Rs. ${DecimalFormat("##.##").format(p * n)}"
                                    mTVTitle9.text = "Rs. ${DecimalFormat("##.##").format(fv - p)}"
                                }
                            }
                            else {
                                if (cal == 1 || cal == 2 || cal == 3 || cal == 4) {
                                    Toast.makeText(this, "Please Enter Rate", Toast.LENGTH_SHORT).show()
                                }
                                mTVTitle9.text = "Rs. 0"
                            }
                        }
                        else {
                            if (cal == 1 || cal == 2 || cal == 4) {
                                Toast.makeText(this, "Please Enter Months", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(this, "Please Enter Years", Toast.LENGTH_SHORT).show()
                            }
                            mTVTitle8.text = "Rs. 0"
                        }
                    } catch (e: Exception) {
                    }
                }
                else {
                    if (cal == 1 || cal == 2) {
                        Toast.makeText(this, "Please Enter Loan Amount", Toast.LENGTH_SHORT).show()
                    }
                    if (cal == 4) {
                        Toast.makeText(this, "Please Enter SIP Amount", Toast.LENGTH_SHORT).show()
                    }
                    if (cal == 3) {
                        Toast.makeText(this, "Please Enter Deposit Amount", Toast.LENGTH_SHORT).show()
                    }
                    mTVTitle7.text = "Rs. 0"
                    mTVTitle8.text = "Rs. 0"
                    mTVTitle9.text = "Rs. 0"
                }
            }else{
                //Enter Valied Value Toast
                Toast.makeText(this, "Please Enter Value", Toast.LENGTH_SHORT).show()
            }
        }

        mBReset.setOnClickListener {
            mTVTitle7Scroll.fullScroll(HorizontalScrollView.FOCUS_RIGHT)
            mTVTitle8Scroll.fullScroll(HorizontalScrollView.FOCUS_RIGHT)
            mTVTitle9Scroll.fullScroll(HorizontalScrollView.FOCUS_RIGHT)
            mET1.text.clear()
            mET2.text.clear()
            mET3.text.clear()
            mTVTitle7.text = "Rs. 0"
            mTVTitle8.text = "Rs. 0"
            mTVTitle9.text = "Rs. 0"
        }
    }

    private fun hideSystemUI() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = Color.TRANSPARENT
        }
    }
}