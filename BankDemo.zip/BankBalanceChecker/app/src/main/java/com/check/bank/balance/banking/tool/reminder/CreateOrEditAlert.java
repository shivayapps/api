package com.check.bank.balance.banking.tool.reminder;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NavUtils;

import com.check.bank.balance.banking.tool.activity.MainActivity;
import com.check.bank.balance.banking.tool.utils.ListHelper;
import com.check.bank.balance.banking.tool.R;

import java.sql.Time;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CreateOrEditAlert extends AppCompatActivity {

    private SimpleAdapter mAdapter;
    private EditText mContent, mTitle;
    private TextView mTVToolbar;
    private ImageButton imgBtnBack;
    private Button btnReminder;
    private String mTime, mDate;
    private int mID, mRepeatMode;
    private Map<String, String> mAlarmTime, mAlarmDate, mAlarmRepeat;
    private Calendar mAlertTime;
    private ContentResolver mContentResolver;
    private Dialog alert;
    private TimePickerDialog timePicker;
    private DatePickerDialog datePicker;
    private AlertDialog alertDialog;
    private Handler handler;
    private Runnable runnable;

    private static final String NONE = "None";
    private static final String HOURLY = "Hourly";
    private static final String DAILY = "Daily";
    private static final String WEEKLY = "Weekly";
    private static final String MONTHLY = "Monthly";
    private static final String YEARLY = "Yearly";

    private static final String[] REPEAT_MODES = new String[]{NONE, HOURLY, DAILY, WEEKLY, MONTHLY, YEARLY};

    private static final DateFormat TIME_FORMAT = new SimpleDateFormat("hh:mm aa");
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yy");

    public static final String ID_KEY = "id";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_or_edit_alert);

        transparentStatusAndNavigation();
        mContentResolver = getContentResolver();

        List<Map<String, String>> mapList = new ArrayList<Map<String, String>>();
        mAlarmTime = new HashMap<String, String>();
        mAlarmDate = new HashMap<String, String>();
        mAlarmRepeat = new HashMap<String, String>();

        mContent = (EditText) findViewById(R.id.alertContent);
        mTitle = (EditText) findViewById(R.id.alertTitle);
        mTVToolbar = findViewById(R.id.mTVToolbar);
        imgBtnBack = findViewById(R.id.imgBtnBack);
        btnReminder = findViewById(R.id.btnReminder);

        btnReminder.setOnClickListener(v -> {
            if (mContent.length() > 0 && mTitle.length() > 0) {
                saveAlert();
            } else {
                if (mTitle.getText().toString().trim().isEmpty()) {
                    Toast.makeText(CreateOrEditAlert.this, "Please Enter Title and Content", Toast.LENGTH_SHORT).show();
                } else if (mContent.getText().toString().trim().isEmpty()) {
                    Toast.makeText(CreateOrEditAlert.this, "Please Enter Title and Content", Toast.LENGTH_SHORT).show();
                }
            }
        });

        imgBtnBack.setOnClickListener(v -> {
            onBackPressed();
        });

        mRepeatMode = 0;
        Intent intent = getIntent();
        mID = intent.getIntExtra(ID_KEY, 0);
        mAlertTime = Calendar.getInstance();

//    Toolbar toolbar = (Toolbar) findViewById(R.id.tool_bar);
//    this.setSupportActionBar(toolbar);

        // If item exists, then set mTime and mDate list items to the mTime and mDate stored in alert
        if (mID > 0) {
            Uri uri = ContentUris.withAppendedId(ReminderContract.Alerts.CONTENT_URI, mID);
            Cursor cursor = mContentResolver.query(uri, null, null, null, null);
            cursor.moveToFirst();
            String contentString = cursor.getString(cursor.getColumnIndex(ReminderDataHelper.DB_COLUMN_CONTENT));
            String titleString = cursor.getString(cursor.getColumnIndex(ReminderDataHelper.DB_COLUMN_TITLE));
            mContent.setText(contentString);
            mTitle.setText(titleString);

            long timeInMilliseconds = cursor.getLong(cursor.getColumnIndex(ReminderDataHelper.DB_COLUMN_TIME));
            mRepeatMode = cursor.getInt(cursor.getColumnIndex(ReminderDataHelper.DB_COLUMN_FREQUENCY));
            mAlertTime.setTimeInMillis(timeInMilliseconds);
            DateFormat timeFormat = new SimpleDateFormat("hh:mm aa");
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yy");

            mTime = timeFormat.format(mAlertTime.getTime());
            mDate = dateFormat.format(mAlertTime.getTime());
            mTVToolbar.setText("Edit Alert");
            cursor.close();

            // Otherwise, set mTime and mDate list items to system mTime
        } else {
            Calendar current = Calendar.getInstance();
            mTime = TIME_FORMAT.format(current.getTime());
            mDate = DATE_FORMAT.format(current.getTime());
            mAlertTime.setTimeInMillis(current.getTimeInMillis());
            mTVToolbar.setText("Create Alert");
        }

        mAlarmTime.put("mTitle", "Time");
        mAlarmTime.put("subtext", mTime);
        mAlarmDate.put("mTitle", "Date");
        mAlarmDate.put("subtext", mDate);
        mAlarmRepeat.put("mTitle", "Repeat");
        mAlarmRepeat.put("subtext", REPEAT_MODES[mRepeatMode]);

        mapList.add(mAlarmTime);
        mapList.add(mAlarmDate);
        mapList.add(mAlarmRepeat);
        int totalHeight = 0;
        mAdapter = new SimpleAdapter(this, mapList, R.layout.custom_card_view, new String[]{"mTitle", "subtext"}, new int[]{R.id.text1, R.id.text2});
        ListView listView = (ListView) findViewById(R.id.alertSettings);

        listView.setAdapter(mAdapter);
        ListHelper.getListViewSize(listView);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //if first item in list (the mTime), then show timePickerDialog
                listView.setEnabled(false);
                handler = new Handler();
                runnable = new Runnable() {
                    @Override
                    public void run() {
                        listView.setEnabled(true);
                        try {
                            if (i == 0) {
                                timePicker = timePicker();
                                timePicker.show();
                                //if second item in list (the mDate), then show datePicker dialog
                            } else if (i == 1) {
                                datePicker = datePicker();
                                datePicker.show();
                            } else {
                                alertDialog = repeatDialog();
                                alertDialog.show();
                            }
                        } catch (Exception e) {
                            //e.toString();
                        }
                    }
                };
                handler.postDelayed(runnable, 1000);
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (mTitle.getText().toString().trim().isEmpty() && mContent.getText().toString().trim().isEmpty()) {
            super.onBackPressed();
//      Toast.makeText(CreateOrEditAlert.this, "Please Enter title", Toast.LENGTH_SHORT).show();
        } else {
            String contentString = mContent.getText().toString();
            String titleString = mTitle.getText().toString();
            discardDialog(mID, titleString, contentString, Calendar.getInstance().getTimeInMillis());
//      Toast.makeText(CreateOrEditAlert.this, "Please Enter Content", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_create_or_edit_alert, menu);
        return true;
    }

    private void transparentStatusAndNavigation() {
        //make full transparent statusBar
        if (Build.VERSION.SDK_INT >= 19 && Build.VERSION.SDK_INT < 21) {
            setWindowFlag(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, true);
        }
        if (Build.VERSION.SDK_INT >= 19) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
        if (Build.VERSION.SDK_INT >= 21) {
            setWindowFlag(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, false);

            getWindow().setStatusBarColor(Color.TRANSPARENT);
            //getWindow().setNavigationBarColor(Color.TRANSPARENT);
        }
    }

    private void setWindowFlag(final int bits, boolean on) {
        Window win = getWindow();
        WindowManager.LayoutParams winParams = win.getAttributes();
        if (on) {
            winParams.flags |= bits;
        } else {
            winParams.flags &= ~bits;
        }
        win.setAttributes(winParams);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case android.R.id.home:
                saveAlert();
                break;

            default:
                break;
        }
        return true;
    }

    // mTime picker
    private TimePickerDialog timePicker() {
         timePicker = new TimePickerDialog(CreateOrEditAlert.this, R.style.datepicker,
                new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int hour, int minute) {
                        mAlertTime.set(Calendar.HOUR_OF_DAY, hour);
                        mAlertTime.set(Calendar.MINUTE, minute);
                        mAlertTime.set(Calendar.SECOND, 0);
                        mTime = TIME_FORMAT.format(mAlertTime.getTime());
                        mAlarmTime.put("subtext", mTime);
                        Log.d("mTime", "onTimeSet: "+mTime);
                        mAdapter.notifyDataSetChanged();
                    }
                }, mAlertTime.get(Calendar.HOUR_OF_DAY), mAlertTime.get(Calendar.MINUTE), false);
        return timePicker;
    }

    // mDate picker
    private DatePickerDialog datePicker() {
         datePicker = new DatePickerDialog(CreateOrEditAlert.this, R.style.datepicker,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                        mAlertTime.set(Calendar.YEAR, year);
                        mAlertTime.set(Calendar.MONTH, month);
                        mAlertTime.set(Calendar.DAY_OF_MONTH, day);
                        mDate = DATE_FORMAT.format(mAlertTime.getTime());
                        mAlarmDate.put("subtext", mDate);
                        Log.d("mTime", "onTimeSet:113 "+mDate);
                        mAdapter.notifyDataSetChanged();
                    }
                }, mAlertTime.get(Calendar.YEAR), mAlertTime.get(Calendar.MONTH), mAlertTime.get(Calendar.DAY_OF_MONTH));
        datePicker.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
        return datePicker;
    }

    private void discardDialog(int id, String title, String content, long time) {
        final int saveId = id;
        final long saveTime = time;
        final String saveMessage = content;
        final String saveTitle = title;

        alert = new Dialog(CreateOrEditAlert.this);
        View mView = getLayoutInflater().inflate(R.layout.dialog_discard, null);

        Button btn_cancel = (Button) mView.findViewById(R.id.btnNagative);
        Button btn_okay = (Button) mView.findViewById(R.id.btnPositive);
        alert.setContentView(mView);

//        final AlertDialog alertDialog = alert.create();

//        alertDialog.setCanceledOnTouchOutside(false);
        alert.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        DisplayMetrics mDisplay = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(mDisplay);
        int width = mDisplay.widthPixels;
        alert.getWindow().setLayout((int) (width*0.90), ViewGroup.LayoutParams.WRAP_CONTENT);

        btn_okay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//        btn_okay.setBackground(getResources().getDrawable(R.drawable.ic_round_btn));
//        btn_okay.setTextColor(getResources().getColor(R.color.black));

               /* if (mTitle.getText().toString().trim().isEmpty()) {
                    Toast.makeText(CreateOrEditAlert.this, "Please Enter Title and Content", Toast.LENGTH_SHORT).show();
                } else if (mContent.getText().toString().trim().isEmpty()) {
                    Toast.makeText(CreateOrEditAlert.this, "Please Enter Title and Content", Toast.LENGTH_SHORT).show();
                } else {


                    // if item exists, cancel previous alarm, update alert, then set new alarm
                    if (saveId > 0) {
                        Intent cancelPrevious = new Intent(CreateOrEditAlert.this,
                                AlarmService.class);
                        cancelPrevious.putExtra("id", saveId);
                        cancelPrevious.setAction(AlarmService.CANCEL);
                        startService(cancelPrevious);
                        ContentValues values = new ContentValues();
                        values.put(ReminderContract.Alerts.TITLE, saveTitle);
                        values.put(ReminderContract.Alerts.CONTENT, saveMessage);
                        values.put(ReminderContract.Alerts.TIME, saveTime);
                        values.put(ReminderContract.Alerts.FREQUENCY, mRepeatMode);
                        Uri uri = ContentUris.withAppendedId(ReminderContract.Alerts.CONTENT_URI,
                                saveId);
                        mContentResolver.update(uri, values, null, null);
                        createAlarm(saveId);

                        // creates alarm for new alert
                    } else {
                        ContentValues values = new ContentValues();
                        values.put(ReminderContract.Alerts.TYPE, ReminderContract.PATH_ALERT);
                        values.put(ReminderContract.Alerts.TITLE, saveTitle);
                        values.put(ReminderContract.Alerts.CONTENT, saveMessage);
                        values.put(ReminderContract.Alerts.TIME, saveTime);
                        values.put(ReminderContract.Alerts.FREQUENCY, mRepeatMode);
                        Uri uri = mContentResolver.insert(ReminderContract.Notes.CONTENT_URI,
                                values);
                        createAlarm(Integer.parseInt(uri.getLastPathSegment()));
                    }
                    terminateActivity();
                    alertDialog.dismiss();

                }*/
//                terminateActivity();
                alert.dismiss();

            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                terminateActivity();
                alert.dismiss();
            }
        });
        alert.show();

//            new AlertDialog.Builder(this)
//            .setTitle("Confirm")
//            .setMessage("Do you want to save?")
//            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
//
//              public void onClick(DialogInterface dialog, int i) {
//
//                if (mTitle.getText().toString().trim().isEmpty()){
//                  Toast.makeText(CreateOrEditAlert.this, "Please Enter title", Toast.LENGTH_SHORT).show();
//                }else if (mContent.getText().toString().trim().isEmpty()){
//                  Toast.makeText(CreateOrEditAlert.this, "Please Enter Content", Toast.LENGTH_SHORT).show();
//                }else {
//
//                  // if item exists, cancel previous alarm, update alert, then set new alarm
//                  if (saveId > 0) {
//                    Intent cancelPrevious = new Intent(CreateOrEditAlert.this,
//                            AlarmService.class);
//                    cancelPrevious.putExtra("id", saveId);
//                    cancelPrevious.setAction(AlarmService.CANCEL);
//                    startService(cancelPrevious);
//                    ContentValues values = new ContentValues();
//                    values.put(ReminderContract.Alerts.TITLE, saveTitle);
//                    values.put(ReminderContract.Alerts.CONTENT, saveMessage);
//                    values.put(ReminderContract.Alerts.TIME, saveTime);
//                    values.put(ReminderContract.Alerts.FREQUENCY, mRepeatMode);
//                    Uri uri = ContentUris.withAppendedId(ReminderContract.Alerts.CONTENT_URI,
//                            saveId);
//                    mContentResolver.update(uri, values, null, null);
//                    createAlarm(saveId);
//
//                    // creates alarm for new alert
//                  } else {
//                    ContentValues values = new ContentValues();
//                    values.put(ReminderContract.Alerts.TYPE, ReminderContract.PATH_ALERT);
//                    values.put(ReminderContract.Alerts.TITLE, saveTitle);
//                    values.put(ReminderContract.Alerts.CONTENT, saveMessage);
//                    values.put(ReminderContract.Alerts.TIME, saveTime);
//                    values.put(ReminderContract.Alerts.FREQUENCY, mRepeatMode);
//                    Uri uri = mContentResolver.insert(ReminderContract.Notes.CONTENT_URI,
//                            values);
//                    createAlarm(Integer.parseInt(uri.getLastPathSegment()));
//                  }
//                  terminateActivity();
//                  dialog.dismiss();
//
//                }
//
//              }
//
//            })
//            .setNegativeButton("No", new DialogInterface.OnClickListener() {
//              public void onClick(DialogInterface dialog, int i) {
//                terminateActivity();
//                dialog.dismiss();
//
//              }
//            })
//            .create();
    }

    private void saveDialog(int id, String title, String content, long time) {
        final int saveId = id;
        final long saveTime = time;
        final String saveMessage = content;
        final String saveTitle = title;

        alert = new Dialog(CreateOrEditAlert.this);

        View mView = getLayoutInflater().inflate(R.layout.dialog_save, null);

        Button btn_cancel = (Button) mView.findViewById(R.id.btnNagative);
        Button btn_okay = (Button) mView.findViewById(R.id.btnPositive);
        alert.setContentView(mView);

//        final AlertDialog alertDialog = alert.create();

        alert.setCanceledOnTouchOutside(false);
        alert.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        DisplayMetrics mDisplay = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(mDisplay);
        int width = mDisplay.widthPixels;
        alert.getWindow().setLayout((int) (width*0.90), ViewGroup.LayoutParams.WRAP_CONTENT);

        btn_okay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//        btn_okay.setBackground(getResources().getDrawable(R.drawable.ic_round_btn));
//        btn_okay.setTextColor(getResources().getColor(R.color.black));

                if (mTitle.getText().toString().trim().isEmpty()) {
                    Toast.makeText(CreateOrEditAlert.this, "Please Enter Title and Content", Toast.LENGTH_SHORT).show();
                } else if (mContent.getText().toString().trim().isEmpty()) {
                    Toast.makeText(CreateOrEditAlert.this, "Please Enter Title and Content", Toast.LENGTH_SHORT).show();
                } else {


                    // if item exists, cancel previous alarm, update alert, then set new alarm
                    if (saveId > 0) {
                        Intent cancelPrevious = new Intent(CreateOrEditAlert.this, AlarmService.class);
                        cancelPrevious.putExtra("id", saveId);
                        cancelPrevious.setAction(AlarmService.CANCEL);
                        startService(cancelPrevious);
                        ContentValues values = new ContentValues();
                        values.put(ReminderContract.Alerts.TITLE, saveTitle);
                        values.put(ReminderContract.Alerts.CONTENT, saveMessage);
                        values.put(ReminderContract.Alerts.TIME, saveTime);
                        values.put(ReminderContract.Alerts.FREQUENCY, mRepeatMode);
                        Uri uri = ContentUris.withAppendedId(ReminderContract.Alerts.CONTENT_URI, saveId);
                        mContentResolver.update(uri, values, null, null);
                        createAlarm(saveId);

                        // creates alarm for new alert
                    } else {
                        ContentValues values = new ContentValues();
                        values.put(ReminderContract.Alerts.TYPE, ReminderContract.PATH_ALERT);
                        values.put(ReminderContract.Alerts.TITLE, saveTitle);
                        values.put(ReminderContract.Alerts.CONTENT, saveMessage);
                        values.put(ReminderContract.Alerts.TIME, saveTime);
                        values.put(ReminderContract.Alerts.FREQUENCY, mRepeatMode);
                        Uri uri = mContentResolver.insert(ReminderContract.Notes.CONTENT_URI, values);
                        createAlarm(Integer.parseInt(uri.getLastPathSegment()));
                    }
                    terminateActivity();
                    alert.dismiss();
                }
            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                terminateActivity();
                alert.dismiss();
            }
        });
        alert.show();

//            new AlertDialog.Builder(this)
//            .setTitle("Confirm")
//            .setMessage("Do you want to save?")
//            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
//
//              public void onClick(DialogInterface dialog, int i) {
//
//                if (mTitle.getText().toString().trim().isEmpty()){
//                  Toast.makeText(CreateOrEditAlert.this, "Please Enter title", Toast.LENGTH_SHORT).show();
//                }else if (mContent.getText().toString().trim().isEmpty()){
//                  Toast.makeText(CreateOrEditAlert.this, "Please Enter Content", Toast.LENGTH_SHORT).show();
//                }else {
//
//                  // if item exists, cancel previous alarm, update alert, then set new alarm
//                  if (saveId > 0) {
//                    Intent cancelPrevious = new Intent(CreateOrEditAlert.this,
//                            AlarmService.class);
//                    cancelPrevious.putExtra("id", saveId);
//                    cancelPrevious.setAction(AlarmService.CANCEL);
//                    startService(cancelPrevious);
//                    ContentValues values = new ContentValues();
//                    values.put(ReminderContract.Alerts.TITLE, saveTitle);
//                    values.put(ReminderContract.Alerts.CONTENT, saveMessage);
//                    values.put(ReminderContract.Alerts.TIME, saveTime);
//                    values.put(ReminderContract.Alerts.FREQUENCY, mRepeatMode);
//                    Uri uri = ContentUris.withAppendedId(ReminderContract.Alerts.CONTENT_URI,
//                            saveId);
//                    mContentResolver.update(uri, values, null, null);
//                    createAlarm(saveId);
//
//                    // creates alarm for new alert
//                  } else {
//                    ContentValues values = new ContentValues();
//                    values.put(ReminderContract.Alerts.TYPE, ReminderContract.PATH_ALERT);
//                    values.put(ReminderContract.Alerts.TITLE, saveTitle);
//                    values.put(ReminderContract.Alerts.CONTENT, saveMessage);
//                    values.put(ReminderContract.Alerts.TIME, saveTime);
//                    values.put(ReminderContract.Alerts.FREQUENCY, mRepeatMode);
//                    Uri uri = mContentResolver.insert(ReminderContract.Notes.CONTENT_URI,
//                            values);
//                    createAlarm(Integer.parseInt(uri.getLastPathSegment()));
//                  }
//                  terminateActivity();
//                  dialog.dismiss();
//
//                }
//
//              }
//
//            })
//            .setNegativeButton("No", new DialogInterface.OnClickListener() {
//              public void onClick(DialogInterface dialog, int i) {
//                terminateActivity();
//                dialog.dismiss();
//
//              }
//            })
//            .create();
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            alert.dismiss();
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            timePicker.dismiss();
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            datePicker.dismiss();
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            alertDialog.dismiss();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private AlertDialog deleteDialog(int id) {
        final int deleteId = id;
        return new AlertDialog.Builder(this)
                .setTitle("Confirm")
                .setMessage("Do you want to delete?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int i) {
                        if (deleteId > 0) {
                            // delete the alarm
                            Intent delete = new Intent(CreateOrEditAlert.this, AlarmService.class);
                            delete.putExtra(ID_KEY, deleteId);
                            delete.setAction(AlarmService.DELETE);
                            Uri uri = ContentUris.withAppendedId(ReminderContract.Notes.CONTENT_URI, deleteId);
                            mContentResolver.delete(uri, null, null);
                            startService(delete);
                            terminateActivity();
                        } else {
                            terminateActivity();
                        }
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.dismiss();
                    }
                })
                .create();
    }

    // set repeat mode from None, Hour, Daily, Monthly, Yearly
    private AlertDialog repeatDialog() {
        final int prevRepeat = mRepeatMode;
        Log.d("aaaadad", "repeatDialog: " + mRepeatMode);
        return new AlertDialog.Builder(this, R.style.datepicker)
                .setTitle("Repeat")
                .setSingleChoiceItems(REPEAT_MODES, mRepeatMode, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        mRepeatMode = i;
                    }
                })
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        // set label to selected repeat mode
                        mAlarmRepeat.put("subtext", REPEAT_MODES[mRepeatMode]);
                        mAdapter.notifyDataSetChanged();
                        dialog.dismiss();
                    }
                })
                .setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        mRepeatMode = prevRepeat;
                    }
                })
                .create();
    }

    // creates an alarm
    private void createAlarm(int id) {
        Intent alarm = new Intent(this, AlarmService.class);
        alarm.putExtra(ID_KEY, id);
        alarm.setAction(AlarmService.CREATE);
        startService(alarm);
    }

    // go back to main activity
    private void terminateActivity() {
        NavUtils.navigateUpFromSameTask(this);
    }

    // saves the alert (Handles case where if mTime set to before current, just set immediate alert)
    private void saveAlert() {
        String contentString = mContent.getText().toString();
        String titleString = mTitle.getText().toString();

        if (!(mAlertTime.getTimeInMillis() < Calendar.getInstance().getTimeInMillis())) {
            saveDialog(mID, titleString, contentString, mAlertTime.getTimeInMillis());

        } else {
            saveDialog(mID, titleString, contentString, Calendar.getInstance().getTimeInMillis());
        }
    }
}
