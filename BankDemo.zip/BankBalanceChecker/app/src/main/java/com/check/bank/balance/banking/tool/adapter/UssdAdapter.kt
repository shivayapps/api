package com.check.bank.balance.banking.tool.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.check.bank.balance.banking.tool.R
import com.check.bank.balance.banking.tool.model.UssdModel

class UssdAdapter(var mContext: Context, var mUssdList: ArrayList<String>, var clickListener: ClickListener) : RecyclerView.Adapter<UssdAdapter.UssdViewHolder>() {
    class UssdViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var mIVLeft: ImageView = view.findViewById(R.id.mIVLeft)
        var mTVText: TextView = view.findViewById(R.id.mTVText)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UssdViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.single_ussd, parent, false)
        return UssdViewHolder(view)
    }

    override fun getItemCount(): Int = mUssdList.size

    override fun onBindViewHolder(holder: UssdViewHolder, position: Int) {
        val mList = mUssdList[position]

        holder.mTVText.text = mList
        Glide.with(mContext).load(R.drawable.ic_miss_call).into(holder.mIVLeft)

        holder.itemView.setOnClickListener {
            clickListener.onItemClick(position)
        }
    }

    interface ClickListener {
        fun onItemClick(position: Int)
    }
}