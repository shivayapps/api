package com.check.bank.balance.banking.tool.activity

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.telephony.TelephonyManager
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.check.bank.balance.banking.tool.R
import com.check.bank.balance.banking.tool.adapter.UssdAdapter
import kotlinx.android.synthetic.main.custom_toolbar.*

class USSDActivity : AppCompatActivity() {

    lateinit var mRVUssd: RecyclerView
    lateinit var mBUssdLayout: LinearLayoutManager
    lateinit var mUssdAdapter: UssdAdapter
    lateinit var mToolbar: Toolbar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_u_s_s_d)
        mRVUssd = findViewById(R.id.mRVUSSD)

        hideSystemUI()
        mTVToolbar.text = "USSD Code"
        imgBtnBack.setOnClickListener { onBackPressed() }

        val mUssdList: ArrayList<String> = arrayListOf()

        val mUssdArray: Array<String> = arrayOf(
            "My Profile",
            "Check Bank Balance",
            "Send Money",
            "Receive Money",
            "Pending Request",
            "Transactions",
            "UPI Pin",
            "All Bank USSD Code",
            "First Set Up Dial"
        )

        mUssdList.addAll(mUssdArray)

        mBUssdLayout = LinearLayoutManager(this)
        mUssdAdapter = UssdAdapter(this, mUssdList, object : UssdAdapter.ClickListener {
            override fun onItemClick(position: Int) {
                when (position) {
                    0 -> {
                        openDialer("*99*4")
                    }
                    1 -> {
                        openDialer("*99*3")
                    }
                    2 -> {
                        openDialer("*99*1")
                    }
                    3 -> {
                        openDialer("*99*2")
                    }
                    4 -> {
                        openDialer("*99*5")
                    }
                    5 -> {
                        openDialer("*99*6")
                    }
                    6 -> {
                        openDialer("*99*7")
                    }
                    7 -> {
                        startActivity(Intent(this@USSDActivity, UssdBankActivity::class.java))
                    }
                    8 -> {
                        startActivity(Intent(this@USSDActivity, FirstUssdActivity::class.java))
                    }

                }
            }
        })
        mRVUssd.layoutManager = mBUssdLayout
        mRVUssd.adapter = mUssdAdapter
    }

    private fun openDialer(num: String?) {
        if (isTelephonyEnabled()) {
            val i = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num%23"))
            startActivity(i)
        } else {
            Toast.makeText(this, "Service Not Supported", Toast.LENGTH_SHORT).show()
        }
    }

    private fun isTelephonyEnabled():Boolean{
        val tm:TelephonyManager = this.getSystemService(TELEPHONY_SERVICE) as TelephonyManager
        return tm.simState ==TelephonyManager.SIM_STATE_READY
    }

    private fun hideSystemUI() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = Color.TRANSPARENT
        }
    }
}