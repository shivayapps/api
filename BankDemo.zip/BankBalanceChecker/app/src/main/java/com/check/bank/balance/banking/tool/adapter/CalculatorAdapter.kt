package com.check.bank.balance.banking.tool.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.check.bank.balance.banking.tool.R

class CalculatorAdapter (var mContext: Context, var mBakingList: ArrayList<String>, var clickListener: ClickListener) : RecyclerView.Adapter<CalculatorAdapter.CalculatorViewHolder>() {
    class CalculatorViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var mText: TextView = view.findViewById(R.id.mTVCal)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CalculatorViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.single_calculator, parent, false)
        return CalculatorViewHolder(view)
    }

    override fun getItemCount(): Int = mBakingList.size

    override fun onBindViewHolder(holder: CalculatorViewHolder, position: Int) {
        val mList = mBakingList[position]

        when (position) {
            0 -> {
                holder.mText.setTextColor(mContext.resources.getColor(R.color.cal0))
            }
            1 -> {
                holder.mText.setTextColor(mContext.resources.getColor(R.color.cal1))
            }
            2 -> {
                holder.mText.setTextColor(mContext.resources.getColor(R.color.cal2))
            }
            else -> {
                holder.mText.setTextColor(mContext.resources.getColor(R.color.cal3))
            }
        }
        holder.mText.text = mList
        holder.itemView.setOnClickListener {
            clickListener.onItemClick(position)
        }
    }

    interface ClickListener {
        fun onItemClick(position: Int)
    }
}