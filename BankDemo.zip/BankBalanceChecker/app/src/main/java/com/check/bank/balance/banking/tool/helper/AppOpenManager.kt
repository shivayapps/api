package com.check.bank.balance.banking.tool.helper


import android.app.Activity
import android.app.Application
import android.os.Bundle
import android.util.Log
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.ProcessLifecycleOwner
import com.check.bank.balance.banking.tool.BalanceCheckerApplication
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.appopen.AppOpenAd
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.appid.AppIDs
import java.util.*

class AppOpenManager : LifecycleObserver,Application.ActivityLifecycleCallbacks {

    private val LOG_TAG = "AppOpenManager"
    private var AD_UNIT_ID = AppIDs().getGoogleOpenAds()
    private var appOpenAd: AppOpenAd? = null

    private var loadTime: Long = 0

    private var loadCallback: AppOpenAd.AppOpenAdLoadCallback? = null

    private var myApplication: BalanceCheckerApplication? = null

    private var currentActivity: Activity? = null

    private var isShowingAd = false

    enum class CallBackType {
        DISMISS,
        FAILED,
        ERROR
    }

    /** Constructor  */
    constructor(myApplication: BalanceCheckerApplication?) {
        this.myApplication = myApplication
        this.myApplication?.registerActivityLifecycleCallbacks(this)
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)
        //AD_UNIT_ID = AppIDs.instnace!!.getGoogleInterstitial(0)
    }

    /** LifecycleObserver methods  */
    /*@OnLifecycleEvent(ON_START)
    fun onStart() {
        showAdIfAvailable()
        Log.d(LOG_TAG, "onStart")
    }*/

    /** Request an ad  */
    fun fetchAd() {
        // Have unused ad, no need to fetch another.
        Log.d(LOG_TAG, "fetchAd: ${isAdAvailable()}")
        if (isAdAvailable()) {
            return
        }

        loadCallback = object : AppOpenAd.AppOpenAdLoadCallback() {
            /**
             * Called when an app open ad has loaded.
             *
             * @param ad the loaded app open ad.
             */

            override fun onAdLoaded(ad: AppOpenAd) {
                super.onAdLoaded(ad)
                appOpenAd = ad
                loadTime = Date().time
                Log.d(LOG_TAG, "onAppOpenAdLoaded: $loadTime")
            }

            override fun onAdFailedToLoad(p0: LoadAdError) {
                super.onAdFailedToLoad(p0)
            }
        }

        val request = getAdRequest()
        AppOpenAd.load(myApplication, AD_UNIT_ID, request, AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, loadCallback)

        Log.d("ADS", "fetchAd: $AD_UNIT_ID")
    }

    /** Creates and returns ad request.  */
    private fun getAdRequest(): AdRequest? {
        return AdRequest.Builder().build()
    }

    /** Utility method that checks if ad exists and can be shown.  */
    fun isAdAvailable(): Boolean {
        return appOpenAd != null && wasLoadTimeLessThanNHoursAgo(4)
    }

    /** Shows the ad if one isn't already showing.  */
    fun showAdIfAvailable(callback : ((CallBackType)->Unit)? = null) {
        // Only show ad if there is not already an app open ad currently showing
        // and an ad is available.
        var callback = callback
        Log.d(LOG_TAG, "showAdIfAvailable: $isShowingAd ${isAdAvailable()}")
        if (!isShowingAd && isAdAvailable()) {
            Log.d(LOG_TAG, "Will show ad.")
            val fullScreenContentCallback: FullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    // Set the reference to null so isAdAvailable() returns false.
                    appOpenAd = null
                    isShowingAd = false
                    callback?.invoke(CallBackType.DISMISS)
                    callback = null
                    //fetchAd()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError?) {
                    callback?.invoke(CallBackType.FAILED)
                    callback = null
                }
                override fun onAdShowedFullScreenContent() {
                    isShowingAd = true
                }
            }
            Log.d(LOG_TAG, "showAdIfAvailable: ${currentActivity}")
            if(currentActivity != null)
                appOpenAd?.fullScreenContentCallback = fullScreenContentCallback
                appOpenAd?.show(currentActivity)
        } else {
            Log.d(LOG_TAG, "Can not show ad.")
            if(!isShowingAd) {
                callback?.invoke(CallBackType.ERROR)
                callback = null
            }
            //fetchAd()
        }
    }

    /** Utility method to check if ad was loaded more than n hours ago.  */
    private fun wasLoadTimeLessThanNHoursAgo(numHours: Long): Boolean {
        val dateDifference = Date().time - loadTime
        val numMilliSecondsPerHour: Long = 3600000
        return dateDifference < numMilliSecondsPerHour * numHours
    }

    override fun onActivityPaused(activity: Activity) {
    }

    override fun onActivityStarted(activity: Activity) {
        currentActivity = activity;
    }

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {

    }

    override fun onActivityStopped(activity: Activity) {

    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {

    }

    override fun onActivityResumed(activity: Activity) {
        currentActivity = activity;
    }

    override fun onActivityDestroyed(activity: Activity) {
        currentActivity = null
    }
}