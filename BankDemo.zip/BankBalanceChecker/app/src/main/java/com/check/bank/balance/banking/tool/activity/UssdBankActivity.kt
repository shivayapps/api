package com.check.bank.balance.banking.tool.activity

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.check.bank.balance.banking.tool.R
import com.check.bank.balance.banking.tool.adapter.ShortBankAdapter
import com.check.bank.balance.banking.tool.model.ShortBankModel
import kotlinx.android.synthetic.main.custom_toolbar.*
import org.json.JSONObject
import java.io.InputStream

class UssdBankActivity : AppCompatActivity() {

    lateinit var mRVShort: RecyclerView
    lateinit var mShortLayout: LinearLayoutManager
    lateinit var mShortAdapter: ShortBankAdapter
    lateinit var mToolbar: Toolbar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ussd_bank)
        mRVShort=findViewById(R.id.mRVShortBank)

        hideSystemUI()
        mTVToolbar.text = "Bank's USSD Code"
        imgBtnBack.setOnClickListener { onBackPressed() }

        val mShortList:ArrayList<ShortBankModel> = arrayListOf()

        val json:String?
        val inputStream: InputStream = this.assets.open("ussd.json");
        val size = inputStream.available();
        val buffer:ByteArray = ByteArray(size)
        inputStream.read(buffer);
        inputStream.close();
        json = String(buffer, charset("UTF-8"))

        val jsonRootObject = JSONObject(json)
        val jsonObject = jsonRootObject.getJSONArray("short")

        for (i in 0 until jsonObject.length()) {
            val jsonObj = jsonObject.getJSONObject(i)
            val mName = jsonObj.optString("Bank Name").toString()
            val mShort = jsonObj.optString("Short Name").toString()
            val mCode = jsonObj.optString("Balance check Ussd Code").toString()
            val mIfsc = jsonObj.optString("IFSC Code").toString()
            mShortList.add(ShortBankModel(mName,mShort,mCode,mIfsc))
        }
        mShortLayout= LinearLayoutManager(this)
        mShortAdapter = ShortBankAdapter(this,mShortList)
        mRVShort.layoutManager=mShortLayout
        mRVShort.adapter=mShortAdapter
    }

    private fun hideSystemUI() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = Color.TRANSPARENT
        }
    }
}