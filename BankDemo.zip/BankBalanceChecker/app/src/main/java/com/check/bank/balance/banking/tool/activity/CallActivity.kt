package com.check.bank.balance.banking.tool.activity

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.check.bank.balance.banking.tool.R
import com.check.bank.balance.banking.tool.adapter.CallAdapter
import com.check.bank.balance.banking.tool.model.CallModel
import com.karumi.dexter.Dexter
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionDeniedResponse
import com.karumi.dexter.listener.PermissionGrantedResponse
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.single.PermissionListener
import kotlinx.android.synthetic.main.custom_toolbar.*


class CallActivity : AppCompatActivity() {

    lateinit var mRVCall: RecyclerView
    lateinit var mCallLayout: LinearLayoutManager
    lateinit var mCallAdapter: CallAdapter
    lateinit var mToolbar: Toolbar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_call)

        mTVToolbar.text = intent.getStringExtra("bank")
        imgBtnBack.setOnClickListener { onBackPressed() }
        hideSystemUI()

        val mBankBalance: String? = intent.getStringExtra("balance")
        val mBankMini: String? = intent.getStringExtra("mini")
        val mBankCustomer: String? = intent.getStringExtra("cus")

        Log.e("TAG", "onCreate: $mBankBalance $mBankMini $mBankCustomer")
        val mCallList: ArrayList<CallModel> = arrayListOf()
        mCallList.add(CallModel("Balance Enquiry", mBankBalance))
        if (mBankMini != null) {
            mCallList.add(CallModel("Mini Statement", mBankMini))
        }
        mCallList.add(CallModel("Customer Care", mBankCustomer))

        mRVCall = findViewById(R.id.mRVCall)
        mCallLayout = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        mCallAdapter = CallAdapter(this, mCallList, object : CallAdapter.ClickListener {
            override fun onItemClick(position: String) {
                Dexter.withContext(this@CallActivity)
                    .withPermission(Manifest.permission.CALL_PHONE)
                    .withListener(object : PermissionListener {
                        override fun onPermissionGranted(response: PermissionGrantedResponse) {
                            val callIntent = Intent(Intent.ACTION_CALL)
                            callIntent.data = Uri.parse("tel:$position")
                            startActivity(callIntent)
                        }

                        override fun onPermissionDenied(response: PermissionDeniedResponse) {
                            Toast.makeText(this@CallActivity, "Permission Required", Toast.LENGTH_LONG).show()
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                            val uri = Uri.fromParts("package", packageName, null)
                            intent.data = uri
                            startActivity(intent)
                        }

                        override fun onPermissionRationaleShouldBeShown(permission: PermissionRequest?, token: PermissionToken?) {
                            Toast.makeText(this@CallActivity, "Permission Required", Toast.LENGTH_SHORT).show()
                            token?.continuePermissionRequest()
                        }
                    }).check()
            }
        })
        mRVCall.layoutManager = mCallLayout
        mRVCall.adapter = mCallAdapter
    }

    private fun hideSystemUI() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = Color.TRANSPARENT
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }
}