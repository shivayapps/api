package com.check.bank.balance.banking.tool.activity

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.telephony.TelephonyManager
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.check.bank.balance.banking.tool.R
import kotlinx.android.synthetic.main.custom_toolbar.*

class SendSmsActivity : AppCompatActivity() {
    lateinit var mETSms: EditText
    lateinit var mBSend: Button
    lateinit var mTVInfo: TextView
    lateinit var mToolbar: Toolbar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_send_sms)

        hideSystemUI()

        imgBtnBack.setOnClickListener { onBackPressed() }
        mTVToolbar.text = "Send Message"

        mETSms = findViewById(R.id.mETSms)
        mBSend = findViewById(R.id.mBSend)
        mTVInfo = findViewById(R.id.mTVInfo)

        val mBankSmsNumber = intent.getStringExtra("mBankSmsNumber")
        val mBankSmsCode = intent.getStringExtra("mBankSmsCode")
        val mBankSmsInfo = intent.getStringExtra("mBankSmsInfo")

        mTVInfo.text = "$mBankSmsInfo"

        mETSms.setText(mBankSmsNumber)
        sendData(mBankSmsCode)
    }

    private fun sendData(num: String?) {
        mBSend.setOnClickListener {
            Log.d("21212", "sendData: ${isTelephonyEnabled()} ")
            if (isTelephonyEnabled()) {
                val intent = Intent(Intent.ACTION_VIEW)
                intent.data = Uri.parse("smsto:$num")
                intent.putExtra("sms_body", mETSms.text.toString())
                startActivity(intent)
            } else {
                Toast.makeText(this, "This Service not available for this Device.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun isTelephonyEnabled(): Boolean {
        val tm: TelephonyManager = getSystemService(TELEPHONY_SERVICE) as TelephonyManager;
        return tm != null && tm.simState == TelephonyManager.SIM_STATE_READY
    }

    private fun hideSystemUI() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = Color.TRANSPARENT
        }
    }
}