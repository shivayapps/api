package com.check.bank.balance.banking.tool.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.check.bank.balance.banking.tool.R
import com.check.bank.balance.banking.tool.model.BankMissCallModel
import com.check.bank.balance.banking.tool.model.SmsModel

class SmsAdapter(var mContext: Context, var mSmsList: ArrayList<SmsModel>, var mClickListener: ClickListener): RecyclerView.Adapter<SmsAdapter.SmsViewHolder>() {
    class SmsViewHolder(view: View): RecyclerView.ViewHolder(view){
        val mTVSms: TextView = view.findViewById(R.id.mTVText)
    }

    interface ClickListener{
        fun onItemClick(position:Int)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SmsViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.single_sms,parent,false)
        return SmsViewHolder(view)
    }

    override fun onBindViewHolder(holder: SmsViewHolder, position: Int) {
        val list = mSmsList[position]
        holder.mTVSms.text = list.mText.split(' ').joinToString(" ") { it.capitalize() }
        holder.itemView.setOnClickListener {
            mClickListener.onItemClick(position)
        }
    }

    override fun getItemCount(): Int = mSmsList.size

    fun filterList(filterdNames: ArrayList<SmsModel>) {
        this.mSmsList = filterdNames
        notifyDataSetChanged()
    }
}