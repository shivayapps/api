package com.check.bank.balance.banking.tool.activity

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.check.bank.balance.banking.tool.R
import com.check.bank.balance.banking.tool.adapter.BankAdapter
import com.check.bank.balance.banking.tool.adapter.BankSmsAdapter
import com.check.bank.balance.banking.tool.database.DBHelper
import com.check.bank.balance.banking.tool.model.BankMissCallModel
import kotlinx.android.synthetic.main.activity_bank.*
import kotlinx.android.synthetic.main.custom_toolbar.*
import java.util.*
import kotlin.collections.ArrayList

class BankActivity : AppCompatActivity() {

    lateinit var mRVBank: RecyclerView
    lateinit var mBankLayout: LinearLayoutManager
    lateinit var mBankSmsLayout: LinearLayoutManager
    var mBankAdapter: BankAdapter? = null
    lateinit var mBankSmsAdapter: BankSmsAdapter

    lateinit var mBankList: ArrayList<BankMissCallModel>
    lateinit var mBankSmsList: ArrayList<String>

    private var database: DBHelper? = null
    private var db: SQLiteDatabase? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bank)

        mBankList = arrayListOf()
        mRVBank = findViewById(R.id.mRVBank)
        mIVSearch.visibility = View.VISIBLE

//        if(intent.getIntExtra("head",11) == 11){
//            mTVToolbar.text = "Balance Enquiry"
//        }

        Log.d("nameset", "onCreate: ${intent.getStringExtra("nameset")}")

        mIVSearch.setOnClickListener {
            mETSearch.visibility = View.VISIBLE
            mIVSearch.visibility = View.GONE
        }

        mETSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                if (mBankAdapter != null) {
                    filter(s.toString())
                } else {
                    filterSmsBank(s.toString())
                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        try {
            mTermsToolbar.setPadding(0, statusBar(), 0, 0)
        } catch (e: Exception) {
        }

        hideSystemUI()
        imgBtnBack.setOnClickListener { onBackPressed() }

        val mBankArray = arrayOf<BankMissCallModel>(
            BankMissCallModel(
                0,
                R.drawable.bank,
                "18604195555",
                "Axis Bank",
                "18004195959",
                "18004196969",
                "https://retail.axisbank.co.in/wps/portal/rBanking/axisebanking/AxisRetailLogin/!ut/p/a1/04_Sj9CPykssy0xPLMnMz0vMAfGjzOKNAzxMjIwNjLwsQp0MDBw9PUOd3HwdDQwMjIEKIoEKDHAARwNC-sP1o_ArMYIqwGNFQW6EQaajoiIAVNL82A!!/dl5/d5/L2dBISEvZ0FBIS9nQSEh/"
            ),
            BankMissCallModel(
                1,
                R.drawable.bank,
                "18004251515",
                "Andhra Bank",
                "09223011300",
                "09223011300",
                "https://www.unonbankofindia.co.in/english/home.aspx"
            ),
            BankMissCallModel(
                2,
                R.drawable.bank,
                "18005722000",
                "Allahabad Bank",
                "09224150150",
                "09224150150",
                "https://www.indianbank.in/"
            ),
            BankMissCallModel(
                4,
                R.drawable.bank,
                "18002334526",
                "Bank of Maharashtra",
                "09222281818",
                "18002334526",
                "https://www.mahaconnect.in/jsp/index.html"
            ),
            BankMissCallModel(
                5,
                R.drawable.bank,
                "1800220229",
                "Bank of India",
                "9015135135",
                "09266135135",
                "https://www.bankofindia.co.in/"
            ),
            BankMissCallModel(
                6,
                R.drawable.bank,
                "18001024455",
                "Bank of Baroda",
                "08468001111",
                "08468001122",
                "https://www.bobibanking.com/"
            ),
            BankMissCallModel(
                7,
                R.drawable.bank,
                "18002588181",
                "Bandhan Bank",
                "9223008666",
                "9223008777",
                "https://bandhanbankonline.com/netbanking/"
            ),
            BankMissCallModel(
                8,
                R.drawable.bank,
                "18004253555",
                "Corporation Bank",
                "09268892688",
                null,
                "https://www.unionbankofindia.co.in/english/home.aspx"
            ),
            BankMissCallModel(
                9,
                R.drawable.bank,
                "18602102484",
                "Citibank",
                "09880752484",
                null,
                "https://www.online.citibank.co.in/products-services/online-services/internet-banking.htm"
            ),
            BankMissCallModel(
                10,
                R.drawable.bank,
                "18002669090",
                "Catholic Syrian Bank",
                "8828800900",
                null,
                "https://www.csbnet.co.in/#b"
            ),
            BankMissCallModel(
                11,
                R.drawable.bank,
                "1800221911",
                "Central Bank of India",
                "9555244442",
                "9555144441",
                "https://www.centralbank.net.in/jsp/startMain.jsp"
            ),
            BankMissCallModel(
                12,
                R.drawable.bank,
                "18002095363",
                "DCB Bank",
                "7506660011",
                "7506660022",
                "https://www.dcbbank.com/cms/showpage/page/personal-internet-banking"
            ),
            BankMissCallModel(
                13,
                R.drawable.bank,
                "18602666601",
                "Deutsche Bank",
                "18602666601",
                null,
                "https://login.deutschebank.co.in/corp/AuthenticationController?__START_TRAN_FLAG__=Y&FORMSGROUP_ID__=AuthenticationFG&__EVENT_ID__=LOAD&FG_BUTTONS__=LOAD&ACTION.LOAD=Y&AuthenticationFG.LOGIN_FLAG=1&BANK_ID=200&LANGUAGE_ID=001"
            ),
            BankMissCallModel(
                14,
                R.drawable.bank,
                "18002336427",
                "Dena Bank",
                "09289356677",
                "09278656677",
                "https://edena.bankofbaroda.in/viewsection.jsp?lang=0&id=0,9,347"
            ),
            BankMissCallModel(
                15,
                R.drawable.bank,
                "04876613000",
                "Dhanlaxmi Bank",
                "08067747700",
                "08067747711",
                "https://netbank.dhanbank.in/DBRetailBank/"
            ),
            BankMissCallModel(
                16,
                R.drawable.bank,
                "18004201199",
                "Federal Bank",
                "8431900900",
                "8431600600",
                "https://www.fednetbank.com/"
            ),
            BankMissCallModel(
                17,
                R.drawable.bank,
                "18602676161",
                "HDFC Bank",
                "18002703333",
                "18002703355",
                "https://netbanking.hdfcbank.com/netbanking/"
            ),
            BankMissCallModel(
                18,
                R.drawable.bank,
                "18002094324",
                "IDBI Bank",
                "18008431122",
                "18008431133",
                "https://www.idbibank.in/idbi-bank-internet-banking.asp"
            ),
            BankMissCallModel(
                19,
                R.drawable.bank,
                "18002003344",
                "ICICI Bank",
                "9594612612",
                "9594613613",
                "https://www.icicibank.com/Personal-Banking/insta-banking/internet-banking/index.page"
            ),
            BankMissCallModel(
                20,
                R.drawable.bank,
                "18004254445",
                "Indian Overseas Bank",
                "9210622122",
                null,
                "https://www.iobnet.co.in/ibanking/html/index.html"
            ),
            BankMissCallModel(
                21,
                R.drawable.bank,
                "180042500000",
                "Indian Bank",
                "9289592895",
                "09444394443",
                "https://www.indianbank.net.in/jsp/startIBPreview.jsp"
            ),
            BankMissCallModel(
                22,
                R.drawable.bank,
                "18004194332",
                "IDFC Bank",
                "18002700720",
                null,
                "https://www.idfcfirstbank.com/banking-products/online-services/internet-banking-services.html"
            ),
            BankMissCallModel(
                23,
                R.drawable.bank,
                "18605005004",
                "Indus Ind Bank",
                "18002741000",
                null,
                "https://www.indusind.com/in/en/personal/online-banking/indus-net.html"
            ),
            BankMissCallModel(
                24,
                R.drawable.bank,
                "18004251444",
                "Karnataka Bank",
                "18004251445",
                "18004251446",
                "https://karnatakabank.com/personal/internet-banking"
            ),
            BankMissCallModel(
                25,
                R.drawable.bank,
                "18602662666",
                "Kotak Mahindra Bank",
                "18002740110",
                "18002740110",
                "https://www.kotak.com/en/digital-banking/ways-to-bank/net-banking.html"
            ),
            BankMissCallModel(
                26,
                R.drawable.bank,
                "18602581916",
                "Karur Vysya Bank",
                "9266292666",
                "9266292665",
                "https://www.kvb.co.in/ilogin/"
            ),
            BankMissCallModel(
                27,
                R.drawable.bank,
                "180042510000",
                "Kerala Gramin Bank",
                "9015800400",
                "9015800400",
                "https://netbanking.keralagbank.com/"
            ),
            BankMissCallModel(
                28,
                R.drawable.bank,
                "18004198300",
                "Punjab and Sind Bank",
                "7039035156",
                "7039035156",
                "https://punjabandsindbank.co.in/"
            ),
            BankMissCallModel(
                29,
                R.drawable.bank,
                "18001802222",
                "Punjab National Bank",
                "18001802223",
                "18001802223",
                "https://netpnb.com/"
            ),
            BankMissCallModel(
                31,
                R.drawable.bank,
                "18004251809",
                "South Indian Bank",
                "9223008488",
                "9223008488",
                "https://southindianbank.com/forms/NetBankingRequest.aspx"
            ),
            BankMissCallModel(
                32,
                R.drawable.bank,
                "18001806005",
                "State Bank of Bikaner and Jaipur",
                "9223766666",
                "9223866666",
                "https://corp.onlinesbi.com/sbijava/registrationform.html"
            ),
            BankMissCallModel(
                33,
                R.drawable.bank,
                "18004253800",
                "State Bank of India",
                "9223766666",
                "9223866666",
                "https://www.onlinesbi.com/"
            ),
            BankMissCallModel(
                34,
                R.drawable.bank,
                "18004251825",
                "State Bank of Hyderabad",
                "9223766666",
                "9223866666",
                "https://www.onlinesbi.com/"
            ),
            BankMissCallModel(
                35,
                R.drawable.bank,
                "18001033817",
                "State Bank of Mysore",
                "9223766666",
                "9223866666",
                "https://www.onlinesbi.com/"
            ),
            BankMissCallModel(
                36,
                R.drawable.bank,
                "1800229999",
                "Saraswat Bank",
                "9223040000",
                "9223501111",
                "https://www.saraswatbank.com/content.aspx?id=Internet-Banking"
            ),
            BankMissCallModel(
                37,
                R.drawable.bank,
                "18004253800",
                "State Bank of Travancore",
                "9223766666",
                "9223866666",
                "https://onlinesbi.com/"
            ),
            BankMissCallModel(
                38,
                R.drawable.bank,
                "18001802010",
                "State Bank of Patiala",
                "9223766666",
                "9223866666",
                "https://onlinesbi.com/"
            ),
            BankMissCallModel(
                39,
                R.drawable.bank,
                "180030113333",
                "Syndicate Bank",
                "09015483483",
                null,
                "https://canarabank.com/"
            ),
            BankMissCallModel(
                40,
                R.drawable.bank,
                "02261156300",
                "The Ratnakar Bank (RBL)",
                "18004190610",
                "912261156300",
                "https://online.rblbank.com/corp/AuthenticationController?FORMSGROUP_ID__=AuthenticationFG&__START_TRAN_FLAG__=Y&__FG_BUTTONS__=LOAD&ACTION.LOAD=Y&AuthenticationFG.LOGIN_FLAG=1&BANK_ID=176"
            ),
            BankMissCallModel(
                41,
                R.drawable.bank,
                "9842461461",
                "Tamilnad Mercantile Bank Ltd",
                "9211937373",
                "9211947474",
                "https://www.tmbnet.in/"
            ),
            BankMissCallModel(
                42,
                R.drawable.bank,
                "18001030123",
                "UCO Bank",
                "9278792787",
                "9213125125",
                "https://www.ucobank.com/english/e-banking.aspx"
            ),
            BankMissCallModel(
                43,
                R.drawable.bank,
                "1800222244",
                "Union Bank of India",
                "9223008586",
                "9223008486",
                "https://www.unionbankofindia.co.in/english/home.aspx"
            ),
            BankMissCallModel(
                44,
                R.drawable.bank,
                "18003450345",
                "United Bank of India",
                "9015431345",
                null,
                "https://www.pnbindia.in/"
            ),
            BankMissCallModel(
                45,
                R.drawable.bank,
                "18004255885",
                "Vijaya Bank",
                "1800 425 9992",
                "18001035535",
                "https://www.bobibanking.com/"
            ),
            BankMissCallModel(
                46,
                R.drawable.bank,
                "18001200",
                "Yes Bank",
                "9223920000",
                "9223921111",
                "https://www.yesbank.in/retail-disclaimer"
            )
        )
        mBankList.addAll(mBankArray)

        mBankSmsList = arrayListOf()

        database = DBHelper(this)
        database!!.onCreate(db)
        database!!.openDatabase()
        val res = database!!.allData
        while (res.moveToNext()) {
            if (!mBankSmsList.contains(res.getString(2))) {
                mBankSmsList.add(res.getString(2))
            }
        }


        val services = intent.getIntExtra("mobile", 0)
        if (intent.getStringExtra("nameset").equals("Enquiry")) {
            mTVToolbar.text = "Bank Enquiry"
        }

        mBankLayout = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)

        if (services == 1) {
            mBankAdapter = BankAdapter(this, mBankList, object : BankAdapter.ClickListener {
                override fun onItemClick(position: BankMissCallModel) {
                    val intent = Intent(this@BankActivity, CallActivity::class.java)
                    Log.e("TAG", "onContactSelected: ${position!!.mBankName} ${position.mBankBalance} ${position.mBankMiniStatement} ${position.mBankCustomer}")
                    intent.putExtra("balance", position.mBankBalance)
                    intent.putExtra("mini", position.mBankMiniStatement)
                    intent.putExtra("cus", position.mBankCustomer)
                    intent.putExtra("bank", position.mBankName)
                    startActivity(intent)
                }
            })
            mRVBank.layoutManager = mBankLayout
            mRVBank.adapter = mBankAdapter
        }


        if (services == 2) {
            mBankSmsList.sort()
            mBankSmsLayout = LinearLayoutManager(this)
            mBankSmsAdapter =
                BankSmsAdapter(this, mBankSmsList, object : BankSmsAdapter.ClickListener {
                    override fun onItemClick(position: String) {
                        val intent = Intent(this@BankActivity, SmsActivity::class.java).putExtra("bankName", position)
                        startActivity(intent)
                    }
                })
            mRVBank.layoutManager = mBankSmsLayout
            mRVBank.adapter = mBankSmsAdapter
        }

        if (services == 3) {
            mBankAdapter = BankAdapter(this, mBankList, object : BankAdapter.ClickListener {
                @RequiresApi(Build.VERSION_CODES.M)
                override fun onItemClick(position: BankMissCallModel) {
                    val intent = Intent(this@BankActivity, NetBankingActivity::class.java)
                    if (isOnline()) {
                        intent.putExtra("uri", position.mNetBanking)
                        startActivity(intent)
                    } else {
                        Toast.makeText(this@BankActivity, "Check Internet Connection", Toast.LENGTH_SHORT).show()
                    }
                }
            })
            mRVBank.layoutManager = mBankLayout
            mRVBank.adapter = mBankAdapter
        }
    }

    @RequiresApi(Build.VERSION_CODES.M)
    protected fun isOnline(): Boolean {
        val cm: ConnectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val netInfo: NetworkInfo? = cm.activeNetworkInfo
        return netInfo != null && netInfo.isConnected
    }


    private fun filterSmsBank(text: String) {
        //new array list that will hold the filtered data
        val filterdNames: ArrayList<String> = arrayListOf()

        //looping through existing elements
        for (s in mBankSmsList) {
            //if the existing elements contains the search input
            if (s.toLowerCase().contains(text.toLowerCase())) {
                //adding the element to filtered list
                filterdNames.add(s)
            }
            if (filterdNames.isEmpty()) {
                TvNoSearchFound.visibility = View.VISIBLE
            }else{
                TvNoSearchFound.visibility = View.INVISIBLE
            }
        }

        //calling a method of the adapter class and passing the filtered list
        mBankSmsAdapter.filterList(filterdNames)
    }


    private fun filter(text: String) {
        //new array list that will hold the filtered data
        val filterdNames: ArrayList<BankMissCallModel> = arrayListOf()

        //looping through existing elements
        for (s in mBankList) {
            //if the existing elements contains the search input
            if (s.mBankName.toLowerCase().contains(text.toLowerCase())) {
                //adding the element to filtered list
                filterdNames.add(s)
            }

        }
        if (filterdNames.isEmpty()) {
            TvNoSearchFound.visibility = View.VISIBLE
        }else{
            TvNoSearchFound.visibility = View.INVISIBLE
        }

        //calling a method of the adapter class and passing the filtered list
        mBankAdapter!!.filterList(filterdNames)
    }


    override fun onStop() {
        super.onStop()
        mETSearch.text.clear()
        mIVSearch.visibility = View.VISIBLE
        mETSearch.visibility = View.GONE
        Log.e("TAG", "onStop: thishihi")
    }

    private fun hideSystemUI() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = Color.TRANSPARENT
        }
    }

    override fun onBackPressed() {
        if (!mIVSearch.isVisible) {
            hideKeyboard(this)

            mETSearch.text.clear()
            mIVSearch.visibility = View.VISIBLE
            mETSearch.visibility = View.GONE
        } else {
            super.onBackPressed()
        }
    }

    fun hideKeyboard(activity: Activity?) {
        val imm = activity!!.getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
        //Find the currently focused view, so we can grab the correct window token from it.
        var view = activity.currentFocus
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = View(activity)
        }
        imm.hideSoftInputFromWindow(view.windowToken, 0)
    }

    fun statusBar(): Int {
        var result: Int = 0
        try {
            result = 0
            val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
            if (resourceId > 0) {
                result = resources.getDimensionPixelSize(resourceId)
            }
        } catch (e: Exception) {
        }
        return result
    }
}