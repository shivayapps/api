package com.check.bank.balance.banking.tool.activity

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.check.bank.balance.banking.tool.R
import com.check.bank.balance.banking.tool.adapter.StateAdapter
import kotlinx.android.synthetic.main.activity_bank.*
import kotlinx.android.synthetic.main.activity_bank.TvNoSearchFound
import kotlinx.android.synthetic.main.activity_state.*
import kotlinx.android.synthetic.main.custom_toolbar.*
import org.json.JSONObject
import java.io.InputStream

class StateActivity : AppCompatActivity() {

    lateinit var mRVState: RecyclerView
    lateinit var mStateLayout: LinearLayoutManager
    lateinit var mStateAdapter: StateAdapter
    lateinit var mToolbar: Toolbar
    lateinit var mStateList: ArrayList<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_state)

        mStateList = arrayListOf()

        hideSystemUI()
        imgBtnBack.setOnClickListener { onBackPressed() }
        mTVToolbar.text = "Select State"

        mRVState = findViewById(R.id.mRVState)

        mIVSearch.visibility = View.VISIBLE

        mIVSearch.setOnClickListener {
            mETSearch.visibility = View.VISIBLE
            mETSearch.hint = "Search State"
            mIVSearch.visibility = View.GONE
        }
        val json: String?
//        val inputStream: InputStream = this.assets.open("state.json");
        val inputStream: InputStream = this.assets.open("holiday_2023.json");
        val size = inputStream.available();
        val buffer: ByteArray = ByteArray(size)
        inputStream.read(buffer);
        inputStream.close();
        json = String(buffer, charset("UTF-8"))

        mETSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                filterState(s.toString())
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            }
        })

        val jsonRootObject = JSONObject(json)
        val jsonObject = jsonRootObject.getJSONObject("states")
        val keys = jsonObject.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            mStateList.add(key)
        }

        mStateLayout = LinearLayoutManager(this)
        mStateAdapter = StateAdapter(this, mStateList, object : StateAdapter.ClickListener {
            override fun onItemClick(position: String) {
                val intent = Intent(this@StateActivity, HolidayActivity::class.java)
                intent.putExtra("state", position)
                startActivity(intent)
            }
        })
        mRVState.layoutManager = mStateLayout
        mRVState.adapter = mStateAdapter
    }

    private fun hideSystemUI() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = Color.TRANSPARENT
        }
    }

    private fun filterState(text: String) {
        //new array list that will hold the filtered data
        val filterdNames: ArrayList<String> = arrayListOf()

        //looping through existing elements
        for (s in mStateList) {
            //if the existing elements contains the search input
            if (s.toLowerCase().contains(text.toLowerCase())) {
                //adding the element to filtered list
                filterdNames.add(s)
            }
        }
        if (filterdNames.isEmpty()) {
            TvNoSearchFoundState.visibility = View.VISIBLE
        }else{
            TvNoSearchFoundState.visibility = View.INVISIBLE
        }

        //calling a method of the adapter class and passing the filtered list
        mStateAdapter.filterList(filterdNames)
    }

    override fun onStop() {
        super.onStop()
        mETSearch.text.clear()
        mIVSearch.visibility = View.VISIBLE
        mETSearch.visibility = View.GONE
    }

    override fun onBackPressed() {
        if (!mIVSearch.isVisible) {
            hideKeyboard(this)
            mETSearch.text.clear()
            mIVSearch.visibility = View.VISIBLE
            mETSearch.visibility = View.GONE
        } else {
            super.onBackPressed()
        }
    }

    fun hideKeyboard(activity: Activity?) {
        val imm = activity!!.getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
        //Find the currently focused view, so we can grab the correct window token from it.
        var view = activity.currentFocus
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = View(activity)
        }
        imm.hideSoftInputFromWindow(view.windowToken, 0)
    }
}