package com.check.bank.balance.banking.tool.activity
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.util.Base64
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import com.check.bank.balance.banking.tool.BalanceCheckerApplication.Companion.instance
import com.check.bank.balance.banking.tool.R
import com.check.bank.balance.banking.tool.helper.AppOpenManager
import com.check.bank.balance.banking.tool.share_prefrence.MySharedPref
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.Helper
import kotlinx.android.synthetic.main.activity_splash_screen.*

class SplashScreenActivity : AppCompatActivity() {
    private var sharedPref: MySharedPref? = null
    private var type: String = ""
    val isSubscribe = false
    var handler : Handler = Handler(Looper.getMainLooper())
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)
        startAnim()
        Helper().startDataSync(this, this)
//        try {
//            instance!!.openManager!!.fetchAd()
//        } catch (e: Exception) {
//        }
        sharedPref = MySharedPref(this)
        Handler(Looper.getMainLooper()).postDelayed({
            if (intent.hasExtra("redirect")) {
                type = intent.getStringExtra("redirect")!!
                stopAnim()
            }
        }, 500)

        try {
            val info: PackageInfo = packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES)
            for (signature in info.signatures) {
                val md: MessageDigest = MessageDigest.getInstance("SHA")
                md.update(signature.toByteArray())
                Log.d("KeyHash:", Base64.encodeToString(md.digest(), Base64.DEFAULT))
            }
        } catch (e: PackageManager.NameNotFoundException) {
        } catch (e: NoSuchAlgorithmException) {
        }

        hideSystemUI()

        handler.postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
        },6000)

        /*Handler(Looper.getMainLooper()).postDelayed({
//            if (isSubscribe) {
//                startActivity(Intent(this, MainActivity::class.java))
//            } else {
//                instance!!.openManager?.showAdIfAvailable {
//                    when (it) {
//                        AppOpenManager.CallBackType.DISMISS -> {
//                            if (isFinishing)
//                                return@showAdIfAvailable
//                            Handler().postDelayed({
//                                sharedPref!!.needToShowAds()
//                                startActivity(Intent(this, MainActivity::class.java))
//                            }, 200)
//                        }
//                        AppOpenManager.CallBackType.FAILED -> {
//                            if (isFinishing)
//                                return@showAdIfAvailable
//
//                            sharedPref!!.needToShowAds()
//                            startActivity(Intent(this, MainActivity::class.java))
//                        }
//                        AppOpenManager.CallBackType.ERROR -> {
//                            if (isFinishing)
//                                return@showAdIfAvailable
//                            sharedPref!!.needToShowAds()
//                            startActivity(Intent(this, MainActivity::class.java))
//                        }
//                    }
//                }
//            }

        }, 6000)*/

//        openNextActivity()
    }

    fun startAnim() {
        mProgressBar1.show()
        // or avi.smoothToShow();
    }

    fun stopAnim() {
        mProgressBar1.hide()
        // or avi.smoothToHide();
    }

    private fun hideSystemUI() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = Color.TRANSPARENT
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        finish()
        finishAffinity()
        handler.removeCallbacksAndMessages(null);

    }
    private fun openNextActivity() {
        if (!isFinishing) {
            Handler(Looper.getMainLooper()).postDelayed({
                val intent = Intent(this@SplashScreenActivity, MainActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK
                intent.putExtra("redirect", type)
                startActivity(intent)
                finish()
            }, 500)
        }
    }
}