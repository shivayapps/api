package com.check.bank.balance.banking.tool.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.check.bank.balance.banking.tool.R
import com.check.bank.balance.banking.tool.model.BankMissCallModel

class BankSmsAdapter(var mContext: Context, var mBankList: ArrayList<String>, var mClickListener: ClickListener):
    RecyclerView.Adapter<BankSmsAdapter.BankSmsViewHolder>() {
    class BankSmsViewHolder(view: View):RecyclerView.ViewHolder(view){
        var mTVBank: TextView = view.findViewById(R.id.mTVNumber)
        var mIVBank: TextView = view.findViewById(R.id.mIVCall)
    }
    interface ClickListener{
        fun onItemClick(position:String)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):BankSmsViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.single_bank,parent,false)
        return BankSmsViewHolder(view)
    }

    override fun onBindViewHolder(holder: BankSmsViewHolder, position: Int) {
        val mList = mBankList[position]
        holder.mTVBank.text = mList
        holder.mIVBank.text = (mList[0]).toString()

        holder.itemView.setOnClickListener {
            mClickListener.onItemClick(mList)
        }
    }

    override fun getItemCount(): Int = mBankList.size

    fun filterList(filterdNames: ArrayList<String>) {
        this.mBankList = filterdNames
        notifyDataSetChanged()
    }
}