import com.check.bank.balance.banking.tool.model.Currency

import retrofit2.Call
import retrofit2.http.GET

interface APIInterface {

    @GET("latest?base=USD")
    fun getData(): Call<Currency>
}