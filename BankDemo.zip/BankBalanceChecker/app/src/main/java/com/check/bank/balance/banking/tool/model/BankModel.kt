package com.check.bank.balance.banking.tool.model

data class BankMissCallModel(
    var mBankID: Int,
    var mBankImage: Int,
    var mBankCustomer: String,
    var mBankName: String,
    var mBankBalance: String,
    var mBankMiniStatement: String?,
    var mNetBanking: String?
    )

//data class BankSmsModel(
//    var mBankName: String,
//    var mBankImage: Int,
//    var mBankSmsNumber: String?,
//    var mGetCustomerId: String?,
//    var mSmsBalanceEnq: String?,
//    var mSmsLastTransaction: String?,
//    var mNearestAtm: String?,
//    var mRegisterEStatement: String?,
//    var mGetChequeBook: String?,
//    var mChequeBookStatus: String?,
//    var mLinkAadhaarWithBank: String?,
//    var mUpdateEmail: String?,
//    var mUpdatePan: String?
//)

data class BankSmsModel(
    var mBankName: String,
    var mBankImage: Int,
    var mTitle: String,
    var mMessage: String,
    var mPhone: String
)

data class BankingModel(var mImage: Int, var mText: String)

data class SmsModel(var mText: String, var mPhone: String,var mCode:String,var mInfo:String?)

data class CallModel(var mType: String, var mBalance: String?)

data class StateModel(var mDate: String, var mDay: String, var mHoliday: String)

data class UssdModel(var mIVLeft: Int, var mTVText: String, var mIVRight: Int)

data class ShortBankModel(
    var mTVName: String,
    var mTVShortName: String,
    var mTVCode: String,
    var mTVIFSC: String
)

//bank data
//        val mBankArray = arrayOf<BankMissCallModel>(
//            BankMissCallModel(0,R.drawable.bank,"18604195555","Axis Bank","18004195959","18004196969",
//                "https://retail.axisbank.co.in/wps/portal/rBanking/axisebanking/AxisRetailLogin/!ut/p/a1/04_Sj9CPykssy0xPLMnMz0vMAfGjzOKNAzxMjIwNjLwsQp0MDBw9PUOd3HwdDQwMjIEKIoEKDHAARwNC-sP1o_ArMYIqwGNFQW6EQaajoiIAVNL82A!!/dl5/d5/L2dBISEvZ0FBIS9nQSEh/"),
//            BankMissCallModel(1,R.drawable.bank,"18004251515","Andhra Bank","9223011300",null,"https://www.andhrabank.in/English/upi.aspx"),
//            BankMissCallModel(2,R.drawable.bank,"18005722000","Allahabad Bank","9224150150","9224150150","https://www.allbankonline.in/"),
//            BankMissCallModel(4,R.drawable.bank,"18002334526","Bank of Maharashtra","9222281818",null,"https://www.mahaconnect.in/jsp/index.html"),
//            BankMissCallModel(5,R.drawable.bank,"1800220229","Bank of India","9015135135",null,"https://www.bankofindia.co.in/"),
//            BankMissCallModel(6,R.drawable.bank,"18001024455","Bank of Baroda","9223011311",null,"https://www.bobibanking.com/"),
//            BankMissCallModel(7,R.drawable.bank,"18002588181","Bandhan Bank","18002588181","9223008777","https://bandhanbankonline.com/netbanking/"),
//            BankMissCallModel(8,R.drawable.bank,"18004253555","Corporation Bank","9289792897",null,"https://corpnetbanking.com/corp/AuthenticationController?__START_TRAN_FLAG__=Y&FORMSGROUP_ID__=AuthenticationFG&__EVENT_ID__=LOAD&FG_BUTTONS__=LOAD&ACTION.LOAD=Y&AuthenticationFG.LOGIN_FLAG=1&BANK_ID=CB&LANGUAGE_ID=001"),
//            BankMissCallModel(9,R.drawable.bank,"18602102484","Citibank","9880752484",null,"https://www.online.citibank.co.in/products-services/online-services/internet-banking.htm"),
//            BankMissCallModel(10,R.drawable.bank,"18002669090","Catholic Syrian Bank","9895923000",null,"https://www.csbnet.co.in/#b"),
//            BankMissCallModel(11,R.drawable.bank,"1800221911","Central Bank of India","9555244442","9555144441","https://www.centralbank.net.in/jsp/startMain.jsp"),
//            BankMissCallModel(12,R.drawable.bank,"18002095363","DCB Bank","7506660011","7506660022","https://www.dcbbank.com/cms/showpage/page/personal-internet-banking"),
//            BankMissCallModel(13,R.drawable.bank,"18602666601","Deutsche Bank","18602666601",null,"https://login.deutschebank.co.in/corp/AuthenticationController?__START_TRAN_FLAG__=Y&FORMSGROUP_ID__=AuthenticationFG&__EVENT_ID__=LOAD&FG_BUTTONS__=LOAD&ACTION.LOAD=Y&AuthenticationFG.LOGIN_FLAG=1&BANK_ID=200&LANGUAGE_ID=001"),
//            BankMissCallModel(14,R.drawable.bank,"18002336427","Dena Bank","9289356677","9278656677","https://edena.bankofbaroda.in/viewsection.jsp?lang=0&id=0,9,347"),
//            BankMissCallModel(15,R.drawable.bank,"04876613000","Dhanlaxmi Bank","8067747700","8067747711","https://netbank.dhanbank.in/DBRetailBank/"),
//            BankMissCallModel(16,R.drawable.bank,"18004201199","Federal Bank","8431900900","8431600600","https://www.fednetbank.com/"),
//            BankMissCallModel(17,R.drawable.bank,"18602676161","HDFC Bank","18002703333","18002703355","https://netbanking.hdfcbank.com/netbanking/"),
//            BankMissCallModel(18,R.drawable.bank,"18002094324","IDBI Bank","18008431122","18008431133","https://www.idbibank.in/idbi-bank-internet-banking.asp"),
//            BankMissCallModel(19,R.drawable.bank,"18002003344","ICICI Bank","02230256767","02230256868","https://www.icicibank.com/Personal-Banking/insta-banking/internet-banking/index.page"),
//            BankMissCallModel(20,R.drawable.bank,"18004254445","Indian Overseas Bank","04442220004",null,"https://www.iobnet.co.in/ibanking/html/index.html"),
//            BankMissCallModel(21,R.drawable.bank,"180042500000","Indian Bank","9289592895",null,"https://www.indianbank.net.in/jsp/startIBPreview.jsp"),
//            BankMissCallModel(22,R.drawable.bank,"18004194332","IDFC Bank","18002700720",null,"https://www.idfcfirstbank.com/banking-products/online-services/internet-banking-services.html"),
//            BankMissCallModel(23,R.drawable.bank,"18605005004","Indus Ind Bank","18002741000",null,"https://www.indusind.com/in/en/personal/online-banking/indus-net.html"),
//            BankMissCallModel(24,R.drawable.bank,"18004251444","Karnataka Bank","18004251445","18004251446","https://karnatakabank.com/personal/internet-banking"),
//            BankMissCallModel(25,R.drawable.bank,"18602662666","Kotak Mahindra Bank","18002740110",null,"https://www.kotak.com/en/digital-banking/ways-to-bank/net-banking.html"),
//            BankMissCallModel(26,R.drawable.bank,"18602581916","Karur Vysya Bank","9266292666","9266292665","https://www.kvb.co.in/ilogin/"),
//            BankMissCallModel(27,R.drawable.bank,"9015800400","Kerala Gramin Bank","9015800400",null,"https://netbanking.keralagbank.com/"),
//            BankMissCallModel(28,R.drawable.bank,"18004198300","Punjab and Sind Bank","9223984344",null,"https://www.psbindia.com/content/home-page1"),
//            BankMissCallModel(29,R.drawable.bank,"18001802222","Punjab National Bank","18001802223","01202490000","https://netpnb.com/"),
//            BankMissCallModel(30,R.drawable.bank,"18001238040","RBL BANK","18004190610",null,"https://www.rblbank.com/"),
//            BankMissCallModel(31,R.drawable.bank,"18004251809","South Indian Bank","9223008488",null,"https://southindianbank.com/forms/NetBankingRequest.aspx"),
//            BankMissCallModel(32,R.drawable.bank,"18001806005","State Bank of Bikaner and Jaipur","9223766666","9223866666","https://corp.onlinesbi.com/sbijava/registrationform.html"),
//            BankMissCallModel(33,R.drawable.bank,"18004253800","State Bank of India","9223766666","9223866666","https://www.onlinesbi.com/"),
//            BankMissCallModel(34,R.drawable.bank,"18004251825","State Bank of Hyderabad","9223766666","9223866666","https://www.onlinesbi.com/"),
//            BankMissCallModel(35,R.drawable.bank,"18004252244","State Bank of Mysore","9223766666","9223866666","https://www.onlinesbi.com/"),
//            BankMissCallModel(36,R.drawable.bank,"1800229999","Saraswat Bank","9223040000","9223501111","https://www.saraswatbank.com/content.aspx?id=Internet-Banking"),
//            BankMissCallModel(37,R.drawable.bank,"18004253800","State Bank of Travancore","9223766666","9223866666","https://onlinesbi.com/"),
//            BankMissCallModel(38,R.drawable.bank,"18001802010","State Bank of Patiala","9223766666","9223866666","https://onlinesbi.com/"),
//            BankMissCallModel(39,R.drawable.bank,"180030113333","Syndicate Bank","9664552255","8067006979","https://netbanking.syndicatebank.in/"),
//            BankMissCallModel(40,R.drawable.bank,"02261156300","The Ratnakar Bank (RBL)","18004190610",null,"https://online.rblbank.com/corp/AuthenticationController?FORMSGROUP_ID__=AuthenticationFG&__START_TRAN_FLAG__=Y&__FG_BUTTONS__=LOAD&ACTION.LOAD=Y&AuthenticationFG.LOGIN_FLAG=1&BANK_ID=176"),
//            BankMissCallModel(41,R.drawable.bank,"9842461461","Tamilnad Mercantile Bank Ltd","9211937373",null,"https://www.tmbnet.in/"),
//            BankMissCallModel(42,R.drawable.bank,"18002740123","UCO Bank","9278792787","9213125125","https://www.ucobank.com/english/e-banking.aspx"),
//            BankMissCallModel(43,R.drawable.bank,"1800222244","Union Bank of India","9223008586",null,"https://www.unionbankonline.co.in/"),
//            BankMissCallModel(44,R.drawable.bank,"18003450345","United Bank of India","9015431345",null,"https://www.unitedbank.co.in/"),
//            BankMissCallModel(45,R.drawable.bank,"18004255885","Vijaya Bank","18002665555","18001035535","https://www.vijayabankonline.in/NASApp/continue-login.html"),
//            BankMissCallModel(46,R.drawable.bank,"18001200","Yes Bank","9223920000","9223921111","https://www.yesbank.in/retail-disclaimer")
//        )

