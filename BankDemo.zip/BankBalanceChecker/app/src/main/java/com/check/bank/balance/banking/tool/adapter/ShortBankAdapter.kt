package com.check.bank.balance.banking.tool.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.check.bank.balance.banking.tool.R
import com.check.bank.balance.banking.tool.model.ShortBankModel

class ShortBankAdapter(var mContext: Context, var mShortList: ArrayList<ShortBankModel>) : RecyclerView.Adapter<ShortBankAdapter.ShortBankViewHolder>() {
    class ShortBankViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var mTVName: TextView = view.findViewById(R.id.mTVName)
        var mTVShortName: TextView = view.findViewById(R.id.mTVShortName)
        var mTVCode: TextView = view.findViewById(R.id.mTVCode)
        var mTVIFSC: TextView = view.findViewById(R.id.mTVIFSC)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ShortBankViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.single_short_bank, parent, false)
        return ShortBankViewHolder(view)
    }

    override fun getItemCount(): Int = mShortList.size

    override fun onBindViewHolder(holder: ShortBankViewHolder, position: Int) {
        val mList = mShortList[position]

        holder.mTVName.text = mList.mTVName
        holder.mTVShortName.text = mList.mTVShortName
        holder.mTVCode.text = mList.mTVCode
        holder.mTVIFSC.text = mList.mTVIFSC
    }
}