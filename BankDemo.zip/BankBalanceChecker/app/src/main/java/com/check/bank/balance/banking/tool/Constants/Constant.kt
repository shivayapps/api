package com.check.bank.balance.banking.tool.Constants

object Constant {
    @JvmField
    var isDel = 0
}