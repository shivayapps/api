package com.check.bank.balance.banking.tool.activity

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.util.Log
import android.view.View
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.airbnb.lottie.LottieAnimationView
import com.auto.wallpaper.live.background.changer.customdilaog.RateDialogFragment
import com.check.bank.balance.banking.tool.R
import com.check.bank.balance.banking.tool.helper.OfflineNativeAdvanced
import com.check.bank.balance.banking.tool.utils.InternetConnection
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.appid.AppIDs
import com.scribble.animation.maker.video.effect.myadslibrary.ui.MoreAppActivity
import kotlinx.android.synthetic.main.activity_setting.*
import kotlinx.android.synthetic.main.custom_toolbar.*
import org.jsoup.Jsoup

class SettingActivity : AppCompatActivity() {

    private var currentVersion: String? = null
    private var animationView: LottieAnimationView? = null
    var mInterstitialAd: InterstitialAd? = null
    private var lastClickTime = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setting)
        animationView = findViewById(R.id.animationView)
        hideSystemUI()
        mTVToolbar.text = "Setting"

        initListener()
        initAction()
//        animationView!!.setOnClickListener {
//            if (mInterstitialAd != null) {
//                showInterstitialAd()
//                mInterstitialAd!!.show(this@SettingActivity)
//            } else {
//                Toast.makeText(this, "Check Your Internet Connection", Toast.LENGTH_SHORT).show()
//            }
//        }
//        NativeAdvanceHelper.loadAdSmall(this, findViewById(R.id.fl_adplaceholder));
    }

    override fun onResume() {
        super.onResume()
//        loadInterstitialAd()
//        OfflineNativeAdvanced.loadOfflineGoogleNativeBanner(this@SettingActivity,findViewById(R.id.fl_adplaceholder)){
//            if(it == 0){
//                findViewById<FrameLayout>(R.id.fl_adplaceholder).visibility = View.INVISIBLE
//            }else if(it == 1){
//                findViewById<FrameLayout>(R.id.fl_adplaceholder).visibility = View.VISIBLE
//            }
//        }
    }
    private fun loadInterstitialAd() {
        val adRequest = AdRequest.Builder().build()
        val adId = AppIDs().getGoogleInterstitial()
        InterstitialAd.load(this, adId, adRequest, object : InterstitialAdLoadCallback() {
            override fun onAdFailedToLoad(adError: LoadAdError?) {
                Log.d("Ads123", adError!!.message)
                mInterstitialAd = null
                animationView!!.visibility = View.INVISIBLE
                loadInterstitialAd()
            }

            override fun onAdLoaded(interstitialAd: InterstitialAd) {
                Log.d("Ads123", "Ad was loaded.")
                mInterstitialAd = interstitialAd
                animationView!!.visibility = View.VISIBLE
            }
        })
    }

    private fun showInterstitialAd() {
        mInterstitialAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                Log.d("Ads123", "Ad was dismissed.")
                mInterstitialAd = null
                animationView!!.visibility = View.INVISIBLE
                loadInterstitialAd()
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError?) {
                Log.d("Ads123", "Ad failed to show.")
                animationView!!.visibility = View.INVISIBLE
                loadInterstitialAd()
            }

            override fun onAdShowedFullScreenContent() {
                Log.d("Ads123", "Ad showed fullscreen content.")
                animationView!!.visibility = View.INVISIBLE
//                loadInterstitialAd()
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (InternetConnection.checkConnection(this)) {
            GetVersionCode().execute()
        } else {
            textView11.text = "No Internet Connection"
        }
    }

    private fun initListener(){
        imgBtnBack.setOnClickListener { onBackPressed() }

        clShare.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()
            shareApp()
        }

        clRateUs.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()
            val rateDialog = RateDialogFragment(packageName)
            rateDialog.show(supportFragmentManager, "dialog")
        }

        clMoreApp.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()
            startActivity(Intent(this, MoreAppActivity::class.java))
        }
    }

    private fun initAction(){
        try {
            currentVersion = packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
        }
    }

    private fun hideSystemUI() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = Color.TRANSPARENT
        }
    }

    private fun shareApp() {
        clShare.isEnabled = false
        Handler(Looper.getMainLooper()).postDelayed({
            clShare.isEnabled = true
            try {
                val shareIntent = Intent(Intent.ACTION_SEND)
                shareIntent.type = "text/plain"
                shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Bank Balance")
                var shareMessage = "\nGo with Bank Balance and make beautiful text image.\n\n"
                shareMessage = "https://play.google.com/store/apps/details?id=$packageName\n\n"
                shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
                startActivity(Intent.createChooser(shareIntent, "choose one"))
            } catch (e: java.lang.Exception) { //e.toString();
            }
        },1000)
    }

    inner class GetVersionCode : AsyncTask<Unit?, String?, String?>() {

        override fun doInBackground(vararg units: Unit?): String? {
            var newVersion: String? = null
            return try {
                newVersion = Jsoup.connect("https://play.google.com/store/apps/details?id=$packageName&hl=it")
                    .timeout(30000)
                    .userAgent("Mozilla/5.0 (Windows; U; WindowsNT 5.1; en-US; rv1.8.1.6) Gecko/20070725 Firefox/2.0.0.6")
                    .referrer("http://www.google.com")
                    .get()
                    .select(".hAyfc .htlgb")[7]
                    .ownText()
                newVersion
            } catch (e: Exception) {
                newVersion
            }
        }

        override fun onPostExecute(onlineVersion: String?) {
            super.onPostExecute(onlineVersion)
            if (onlineVersion != null && !onlineVersion.isEmpty()) {
                if (currentVersion != onlineVersion) {
                    checkForUpdate.visibility = View.VISIBLE
                    textView11.text = "Newer version available"
                    clCheckForUpdate.setOnClickListener {
                        try {
                            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")))
                        } catch (e: Exception) {
                        }
                    }
                } else {
                    uptodate.visibility = View.VISIBLE
                    textView11.text = "Your version is up to date."
                }
            } else {
                uptodate.visibility = View.VISIBLE
                textView11.text = "Your version is up to date."
            }
            Log.d("update", "Current version " + currentVersion + "playstore version " + onlineVersion)
        }
    }
}