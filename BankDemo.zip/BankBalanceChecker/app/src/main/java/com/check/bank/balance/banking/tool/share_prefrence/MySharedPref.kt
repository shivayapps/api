package com.check.bank.balance.banking.tool.share_prefrence

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri

class MySharedPref(mContext: Context?) {
    var mContext: Context?
    var sharedPreferences: SharedPreferences
    var editor: SharedPreferences.Editor

    fun noToShowAds(): Boolean {
        return sharedPreferences.getBoolean("ShowAds", true)
    }
    fun needToShowAds() {
        editor.putBoolean("ShowAds", true)
        editor.commit()
    }
    fun isSub(): Boolean {
        return sharedPreferences.getBoolean("isSub", true)
    }
    fun isSetSub() {
        editor.putBoolean("ShowAds", true)
        editor.commit()
    }

    init {
        if (mContext == null) {
//            return
        }
        this.mContext = mContext
        sharedPreferences = mContext!!.getSharedPreferences("my_pref", Context.MODE_PRIVATE)
        editor = sharedPreferences.edit()
    }
}