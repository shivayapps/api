package com.check.bank.balance.banking.tool.activity

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.check.bank.balance.banking.tool.R
import com.check.bank.balance.banking.tool.adapter.SmsAdapter
import com.check.bank.balance.banking.tool.database.DBHelper
import com.check.bank.balance.banking.tool.model.SmsModel
import kotlinx.android.synthetic.main.activity_bank.*
import kotlinx.android.synthetic.main.activity_bank.TvNoSearchFound
import kotlinx.android.synthetic.main.activity_sms.*
import kotlinx.android.synthetic.main.custom_toolbar.*
import java.util.*
import kotlin.Comparator
import kotlin.collections.ArrayList

class SmsActivity : AppCompatActivity() {

    lateinit var mSmsAdapter: SmsAdapter
    lateinit var mSmsLayout: RecyclerView.LayoutManager
    lateinit var mRVSms: RecyclerView
    lateinit var mToolbar: Toolbar

    private var database: DBHelper? = null
    private var db: SQLiteDatabase? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sms)

        hideSystemUI()
        imgBtnBack.setOnClickListener { onBackPressed() }
        mRVSms = findViewById(R.id.mRVSms)

        val mBankName = intent.getStringExtra("bankName")
        mTVToolbar.text = mBankName

        val mSmsList: ArrayList<SmsModel> = arrayListOf()

        database = DBHelper(this)
        database!!.onCreate(db)
        database!!.openDatabase()

        val res = database!!.allData
        while (res.moveToNext()) {
            if (mBankName == res.getString(2)) {
                mSmsList.add(SmsModel(res.getString(1), res.getString(3), res.getString(5), res.getString(4)))
            }
        }

        mSmsLayout = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        mSmsAdapter = SmsAdapter(this, mSmsList, object : SmsAdapter.ClickListener {
            override fun onItemClick(position: Int) {
                sendData(mSmsList[position].mPhone, mSmsList[position].mCode, mSmsList[position].mInfo)
            }
        })
        mRVSms.layoutManager = mSmsLayout
        mRVSms.adapter = mSmsAdapter
    }

    fun sendData(num: String?, smsValue: String?, smsInfo: String?) {
        val intent = Intent(this@SmsActivity, SendSmsActivity::class.java)
        intent.putExtra("mBankSmsNumber", num)
        intent.putExtra("mBankSmsCode", smsValue)
        intent.putExtra("mBankSmsInfo", smsInfo)
        startActivity(intent)
    }

    private fun hideSystemUI() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = Color.TRANSPARENT
        }
    }
}