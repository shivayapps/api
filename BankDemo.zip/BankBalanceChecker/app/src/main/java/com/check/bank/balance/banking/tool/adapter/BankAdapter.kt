package com.check.bank.balance.banking.tool.adapter

import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.check.bank.balance.banking.tool.R
import com.check.bank.balance.banking.tool.activity.CallActivity
import com.check.bank.balance.banking.tool.model.BankMissCallModel

class BankAdapter(var mContext: Context, var mBankList: ArrayList<BankMissCallModel>,
    var clickListener: ClickListener) : RecyclerView.Adapter<BankAdapter.BankViewHolder>() {

    class BankViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var mIVBank: TextView = view.findViewById(R.id.mIVCall)
        var mTVBank: TextView = view.findViewById(R.id.mTVNumber)
        var mCVBank: CardView = view.findViewById(R.id.mCVCall)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BankViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.single_bank, parent, false)
        return BankViewHolder(view)
    }

    override fun getItemCount(): Int = mBankList.size

    override fun onBindViewHolder(holder: BankViewHolder, position: Int) {
        val mList = mBankList[position]

        holder.mTVBank.text = mList.mBankName
        holder.mIVBank.text = ((mList.mBankName)[0]).toString()

        holder.itemView.setOnClickListener {
            Log.e("TAG", "onBindViewHolder: ${mList.mBankName}" )
            clickListener.onItemClick(mList)
//            val intent = Intent(mContext, CallActivity::class.java)
//            intent.putExtra("balance", mList.mBankBalance)
//            intent.putExtra("mini", mList.mBankMiniStatement)
//            intent.putExtra("cus", mList.mBankCustomer)
//            mContext.startActivity(intent)
        }

//        holder.mCVBank.setOnClickListener {
//
//            val intent = Intent(mContext, CallActivity::class.java)
//            intent.putExtra("balance", mList.mBankBalance)
//            intent.putExtra("mini", mList.mBankMiniStatement)
//            mContext.startActivity(intent)
//        }
    }

    interface ClickListener {
        fun onItemClick(position: BankMissCallModel)
    }

    fun filterList(filterdNames: ArrayList<BankMissCallModel>) {
        this.mBankList = filterdNames
        notifyDataSetChanged()
    }
}