package com.check.bank.balance.banking.tool.reminder;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;

import androidx.core.app.NotificationCompat;
import androidx.legacy.content.WakefulBroadcastReceiver;

import com.check.bank.balance.banking.tool.R;
import com.check.bank.balance.banking.tool.helper.NetworkHelper;

import java.util.Calendar;

/**
 * Created by kyle on 07/09/16.
 */
public class AlarmReceiver extends WakefulBroadcastReceiver {

  private static final int HOURLY = 1, DAILY = 2, WEEKLY = 3, MONTHLY = 4, YEARLY = 5;

  @Override
  public void onReceive(Context context, Intent intent) {
    int id = intent.getIntExtra(AlarmService.ID_KEY, 0);
    String title = intent.getStringExtra(AlarmService.TITLE_KEY);
    String msg = intent.getStringExtra(AlarmService.MESSAGE_KEY);

    Uri uri = ContentUris.withAppendedId(ReminderContract.All.CONTENT_URI, id);
    Cursor cursor = context.getContentResolver().query(uri, null, null, null, null);
    cursor.moveToFirst();

    int frequency = 0;
    try {
      frequency = cursor.getInt(cursor.getColumnIndex(ReminderDataHelper.DB_COLUMN_FREQUENCY));
    } catch (Exception e) {
      e.printStackTrace();
    }

    Calendar time = Calendar.getInstance();
    try {
      time.setTimeInMillis(cursor.getLong(cursor.getColumnIndex(ReminderDataHelper.DB_COLUMN_TIME)));
    } catch (Exception e) {
      e.printStackTrace();
    }

    if (frequency > 0) {
      if (frequency == HOURLY) {
        time.add(Calendar.HOUR, 1);
      } else if (frequency == DAILY) {
        time.add(Calendar.DATE, 1);
      } else if (frequency == WEEKLY) {
        time.add(Calendar.DATE, 7);
      } else if (frequency == MONTHLY) {
        time.add(Calendar.MONTH, 1);
      } else if (frequency == YEARLY) {
        time.add(Calendar.YEAR, 1);
      }

      ContentValues values = new ContentValues();
      values.put(ReminderContract.Alerts.TIME, time.getTimeInMillis());
      uri = ContentUris.withAppendedId(ReminderContract.Alerts.CONTENT_URI, id);
      context.getContentResolver().update(uri, values, null, null);

      try {
        Intent setAlarm = new Intent(context, AlarmService.class);
        setAlarm.putExtra(AlarmService.ID_KEY, id);
        setAlarm.setAction(AlarmService.CREATE);
        context.startService(setAlarm);
      } catch (Exception e) {
        e.printStackTrace();
      }
    }

    Intent result = new Intent(context, CreateOrEditAlert.class);
    result.putExtra(AlarmService.ID_KEY, id);
    TaskStackBuilder stackBuilder = TaskStackBuilder.create(context);
    stackBuilder.addParentStack(CreateOrEditAlert.class);
    stackBuilder.addNextIntent(result);
    PendingIntent clicked = stackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT);

    NotificationChannel notificationChannel = null;
    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
      notificationChannel = new NotificationChannel("1" , "BankDemo", NotificationManager.IMPORTANCE_HIGH);
      notificationChannel.enableLights(true);
      notificationChannel.enableVibration(true);
      notificationChannel.setVibrationPattern(new long[]{100, 200, 300, 400, 500, 400, 300, 200, 400});
      NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
      notificationManager.createNotificationChannel(notificationChannel);
    }

    NotificationCompat.BigTextStyle bigStyle = new NotificationCompat.BigTextStyle();
    bigStyle.setBigContentTitle(title);
    bigStyle.bigText(msg);
    Log.d("fdfdfdfdf", ""+title);

    NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(context,"1");
    mBuilder.setContentTitle(title);
    mBuilder.setContentText(msg);
    mBuilder.setSmallIcon(R.drawable.ic_calendar_check_black_48dp);
    mBuilder.setContentIntent(clicked);
    mBuilder.setAutoCancel(true);

    mBuilder.setSound(RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_ALARM));
    mBuilder.setVibrate(new long[]{100, 200, 300, 400, 500, 400, 300, 200, 400});

    NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

    notificationManager.notify(id, mBuilder.build());
  }
}