package com.auto.wallpaper.live.background.changer.customdilaog;

import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.DialogFragment;

import com.willy.ratingbar.ScaleRatingBar;

import static android.content.Context.MODE_PRIVATE;

public class RateDialogFragment extends DialogFragment {

    private String mTitle;
    private String mMessage, positive, negative;
    private OnButtonClickListener mListener;
    private Dialog bottomSheetDialog;
    private int titleImagel;
    private String packageName;
    private float rating1 = 0;

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    public RateDialogFragment(String packageName) {
        this.packageName = packageName;
    }

    public interface OnButtonClickListener {
        void onPositive(RateDialogFragment rateDialogFragment);

        void onNegative(RateDialogFragment rateDialogFragment);
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setStyle(BottomSheetDialogFragment.STYLE_NORMAL, R.style.materialButton);
        setStyle(DialogFragment.STYLE_NO_TITLE, R.style.materialButton);

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.dialog_rate_app, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        sharedPreferences = getContext().getSharedPreferences("data", MODE_PRIVATE);

        view.findViewById(R.id.btnNextTime).setOnClickListener(v -> {
            dismiss();
            //mListener.onPositive(RateDialogFragment.this);
        });

        view.findViewById(R.id.ivClose).setOnClickListener(v -> {
            dismiss();
            //mListener.onNegative(RateDialogFragment.this);
        });

        ScaleRatingBar scaleRatingBar = view.findViewById(R.id.ratingBar);
        Handler handler = new Handler();
        Runnable runnable = () -> {
            if (rating1 > 3) {
                editor = sharedPreferences.edit();
                editor.putBoolean("isShow", false);
                editor.commit();
                rate_app();
                dismiss();
            } else {
//                Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
//                emailIntent.setData(Uri.parse("mailto:"));
//                emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{"profagnesh009@gmail.com"});
//
//                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Share your valuable feedback to improve app quality of Bank Balance");
//                PackageManager packageManager = getActivity().getPackageManager();
//                boolean isIntentSafe = emailIntent.resolveActivity(packageManager) != null;
//                if (isIntentSafe) {
//                    startActivity(emailIntent);
//                    editor = sharedPreferences.edit();
//                    editor.putBoolean("isShow", false);
//                    editor.commit();
//                } else {
//                    Toast.makeText(getActivity(), "Email have been not installed.", Toast.LENGTH_SHORT).show();
//                }
                Toast.makeText(getActivity(), "Thanks for giving rating", Toast.LENGTH_SHORT).show();
                dismiss();
            }
        };

        scaleRatingBar.setOnRatingChangeListener((ratingBar, rating, fromUser) -> {
            rating1 = rating;
            handler.removeCallbacks(runnable);
            handler.postDelayed(runnable, 200);
        });
    }

    private void rate_app() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + packageName)));
        } catch (ActivityNotFoundException anfe) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + packageName)));
        }
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        bottomSheetDialog = getDialog();
        // ((View) getView().getParent()).setPadding(0,0,0,);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int height = displayMetrics.heightPixels;
        int width = displayMetrics.widthPixels;
        width -= width / 8.5f;
        bottomSheetDialog.getWindow().setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT);
        // setColoredNavBar(true);
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Dialog dialog = super.onCreateDialog(savedInstanceState);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            //setWhiteNavigationBar(dialog);
        }
        return dialog;
    }

    private void setColoredNavBar(boolean coloredNavigationBar) {
        if (coloredNavigationBar && bottomSheetDialog.getWindow() != null && Build.VERSION.SDK_INT >= 21) {
            //if (isColorLight(Color.WHITE)) {
            bottomSheetDialog.getWindow().setNavigationBarColor(Color.WHITE);
            if (Build.VERSION.SDK_INT >= 26) {
                bottomSheetDialog.getWindow().setNavigationBarColor(Color.WHITE);
                int flags = bottomSheetDialog.getWindow().getDecorView().getSystemUiVisibility();
                flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                bottomSheetDialog.getWindow().getDecorView().setSystemUiVisibility(flags);
            }
           /* } else {


                if (Build.VERSION.SDK_INT >= 26) {
                    int flags = bottomSheetDialog.getWindow().getDecorView().getSystemUiVisibility();
                    flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    bottomSheetDialog.getWindow().getDecorView().setSystemUiVisibility(flags);
                }
            }*/
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        /*if (getDialog() != null && getDialog().getWindow() != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Window window = getDialog().getWindow();
            window.findViewById(com.google.android.material.R.id.container).setFitsSystemWindows(false);
            // dark navigation bar icons
            View decorView = window.getDecorView();
            decorView.setSystemUiVisibility(decorView.getSystemUiVisibility() | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        }*/
    }

    @Override
    public void onPause() {
        super.onPause();
        try {
            bottomSheetDialog.dismiss();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void setWhiteNavigationBar(@NonNull Dialog dialog) {
        Window window = dialog.getWindow();

        if (window != null) {
            DisplayMetrics metrics = new DisplayMetrics();
            window.getWindowManager().getDefaultDisplay().getMetrics(metrics);

            GradientDrawable dimDrawable = new GradientDrawable();
            // ...customize your dim effect here

            GradientDrawable navigationBarDrawable = new GradientDrawable();
            navigationBarDrawable.setShape(GradientDrawable.RECTANGLE);
            navigationBarDrawable.setColor(Color.WHITE);

            Drawable[] layers = {dimDrawable, navigationBarDrawable};

            LayerDrawable windowBackground = new LayerDrawable(layers);
            windowBackground.setLayerInsetTop(1, metrics.heightPixels);

            window.setBackgroundDrawable(windowBackground);

            int flags = dialog.getWindow().getDecorView().getSystemUiVisibility();
            flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            window.getDecorView().setSystemUiVisibility(flags);
        }
    }

    private boolean isColorLight(@ColorInt int color) {
        if (color == Color.BLACK) return false;
        else if (color == Color.WHITE || color == Color.TRANSPARENT) return true;
        final double darkness = 1 - (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255;
        return darkness < 0.4;
    }
}