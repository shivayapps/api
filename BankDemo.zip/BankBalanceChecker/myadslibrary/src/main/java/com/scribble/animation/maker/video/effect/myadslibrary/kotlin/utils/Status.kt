package com.scribble.animation.maker.video.effect.myadslibrary.kotlin.utils

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}