plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.ksp)
    alias(libs.plugins.crashlytics)
    alias(libs.plugins.google.service)
//    id("com.google.gms.google-services")
//    id("com.google.devtools.ksp")
//    id("com.onesignal.androidsdk.onesignal-gradle-plugin")
}

android {
    namespace = "com.explorefile.filemanager"
    compileSdk = 36

    signingConfigs {
        create("release") {
            storeFile = rootProject.file("app/com.file.filemanager.jks")
            storePassword = "com.file.filemanager"
            keyAlias = "com.file.filemanager"
            keyPassword = "com.file.filemanager"
        }
    }
    defaultConfig {
        applicationId = "com.file.filemanager"
        minSdk = 26
        targetSdk = 36
        versionCode = 10
        versionName = "1.0"

        setProperty("archivesBaseName", "FileManager-$versionName")
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        debug {
            signingConfig = signingConfigs.getByName("debug")
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }


    flavorDimensions("default")
    productFlavors {
        create("TestAd") {
            isDefault = true

            resValue("string", "ads_application_id", "ca-app-pub-3940256099942544~3347511713")
            resValue("string", "b_fileType", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "b_main", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "native_all", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "open_all", "ca-app-pub-3940256099942544/9257395921")
            resValue("string", "inter_all", "ca-app-pub-3940256099942544/1033173712")
        }
        create("LiveAd") {

            resValue("string", "ads_application_id", "ca-app-pub-3940256099942544~3347511713")
            resValue("string", "b_fileType", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "b_main", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "native_all", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "open_all", "ca-app-pub-3940256099942544/9257395921")
            resValue("string", "inter_all", "ca-app-pub-3940256099942544/1033173712")
        }
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
//        dataBinding = true
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)

    implementation("commons-io:commons-io:2.15.0")
    implementation(libs.androidx.swiperefreshlayout)
    implementation(libs.gestureviews)
    implementation(libs.zip4j)
    implementation(libs.lottie)

    implementation(libs.joda.time)
    implementation(libs.gson)

    implementation(libs.glide)
//    ksp(libs.glide.compiler)

    implementation(platform(libs.firebase.bom))
    implementation(libs.firebase.analytics)
    implementation(libs.firebase.messaging)
    implementation(libs.firebase.config)
//    implementation(libs.firebase.crashlytics)
//    implementation(libs.firebase.perf)


    implementation(libs.google.zxing.core)
    implementation(libs.journeyapps.zxing.android)

    implementation(libs.bundles.room)
    implementation(libs.bundles.paging)
    ksp(libs.androidx.room.compiler)

    implementation(libs.play.mlkit.document.scanner)
    implementation(project(":imagestopdf"))

    implementation("androidx.biometric:biometric-ktx:1.2.0-alpha05")

    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.6.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.6.1")
    annotationProcessor("androidx.lifecycle:lifecycle-compiler:2.6.1")
    implementation("androidx.lifecycle:lifecycle-process:2.6.1")

//    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0")
    implementation("com.intuit.sdp:sdp-android:1.1.1")
    implementation("com.intuit.ssp:ssp-android:1.1.1")
    implementation("androidx.multidex:multidex:2.0.1")
//    implementation("com.onesignal:OneSignal:4.7.2")

    implementation("com.github.junrar:junrar:7.5.4")
    implementation("org.apache.commons:commons-compress:1.24.0")
    implementation("com.google.android.gms:play-services-ads:23.0.0")
    implementation("com.facebook.shimmer:shimmer:0.5.0")
    implementation("com.github.zhpanvip:viewpagerindicator:1.2.2")
//    implementation(project(":filepicker"))
    implementation(project(":codeview"))
    implementation(project(":doc_viewer"))
}