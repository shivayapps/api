package com.explorefile.filemanager.models

data class RadioItem(val id: Int, val title: String, val value: Any = id)
