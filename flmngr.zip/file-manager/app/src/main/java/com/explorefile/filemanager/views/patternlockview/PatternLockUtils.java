package com.explorefile.filemanager.views.patternlockview;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class PatternLockUtils {

    private static final String UTF8 = "UTF-8";
    private static final String SHA1 = "SHA-1";
    private static final String MD5 = "MD5";

    private PatternLockUtils() {
        throw new AssertionError("You can not instantiate this class. Use its static utility methods instead");
    }

    public static String patternToString(PatternLockView patternLockView,
                                         List<PatternLockView.Dot> pattern) {
        if (pattern == null) {
            return "";
        }
        int patternSize = pattern.size();
        StringBuilder stringBuilder = new StringBuilder();

        for (int i = 0; i < patternSize; i++) {
            PatternLockView.Dot dot = pattern.get(i);
            stringBuilder.append((dot.getRow() * patternLockView.getDotCount() + dot.getColumn()));
        }
        return stringBuilder.toString();
    }

    public static List<PatternLockView.Dot> stringToPattern(PatternLockView patternLockView,
                                                            String string) {
        List<PatternLockView.Dot> result = new ArrayList<>();

        for (int i = 0; i < string.length(); i++) {
            int number = Character.getNumericValue(string.charAt(i));
            result.add(PatternLockView.Dot.Companion.of(number / patternLockView.getDotCount(),
                    number % patternLockView.getDotCount()));
        }
        return result;
    }

    public static String patternToSha1(PatternLockView patternLockView,
                                       List<PatternLockView.Dot> pattern) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance(SHA1);
            messageDigest.update(patternToString(patternLockView, pattern).getBytes(UTF8));

            byte[] digest = messageDigest.digest();
            BigInteger bigInteger = new BigInteger(1, digest);
            return String.format((Locale) null,
                    "%0" + (digest.length * 2) + "x", bigInteger).toLowerCase();
        } catch (NoSuchAlgorithmException e) {
            return null;
        } catch (UnsupportedEncodingException e) {
            return null;
        }
    }

    public static String patternToMD5(PatternLockView patternLockView,
                                      List<PatternLockView.Dot> pattern) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance(MD5);
            messageDigest.update(patternToString(patternLockView, pattern).getBytes(UTF8));

            byte[] digest = messageDigest.digest();
            BigInteger bigInteger = new BigInteger(1, digest);
            return String.format((Locale) null,
                    "%0" + (digest.length * 2) + "x", bigInteger).toLowerCase();
        } catch (NoSuchAlgorithmException e) {
            return null;
        } catch (UnsupportedEncodingException e) {
            return null;
        }
    }

}
