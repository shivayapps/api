package com.explorefile.filemanager.filecleaner.extension

import com.explorefile.filemanager.filecleaner.entity.StorageStat
import java.util.concurrent.atomic.AtomicLong


fun AtomicLong?.getBoxed(): Long? {
    return this?.get()
}

fun Collection<*>?.sizeBoxed(): Int? {
    return this?.size
}

fun StorageStat?.usedSize(): Long? {
    return this?.usedSize
}

fun StorageStat?.totalSize(): Long? {
    return this?.totalSize
}