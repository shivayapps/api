package com.explorefile.filemanager.dialogs

import android.app.Activity
import androidx.appcompat.app.AlertDialog
import com.explorefile.filemanager.R
import com.explorefile.filemanager.databinding.DialogMessageBinding
import com.explorefile.filemanager.extensions.getAlertDialogBuilder
import com.explorefile.filemanager.extensions.setupDialogStuff

class PermissionRequiredDialog(
    val activity: Activity,
    textId: Int,
    private val positiveActionCallback: () -> Unit,
    private val negativeActionCallback: (() -> Unit)? = null
) {
    private var dialog: AlertDialog? = null

    init {
        val view = DialogMessageBinding.inflate(activity.layoutInflater, null, false)
        view.message.text = activity.getString(textId)

        activity.getAlertDialogBuilder()
            .apply {
                activity.setupDialogStuff(view.root, this) { alertDialog ->
                    dialog = alertDialog
                }

                view.txtCancel.text = activity.resources.getText(R.string.cancel)

                view.txtOk.text = activity.resources.getText(R.string.grant_permission)

                view.txtOk.setOnClickListener {
                    positiveActionCallback()
                }

                view.txtCancel.setOnClickListener {
                    negativeActionCallback?.invoke()
                }
            }
    }
}
