package com.explorefile.filemanager.dialogs

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.RatingBar
import androidx.annotation.DrawableRes
import androidx.appcompat.app.AlertDialog
import androidx.exifinterface.media.ExifInterface
import com.explorefile.filemanager.App
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.BaseActivity
import com.explorefile.filemanager.databinding.DialogProgressBinding
import com.explorefile.filemanager.extensions.beGone
import com.explorefile.filemanager.extensions.formatAsResolution
import com.explorefile.filemanager.extensions.formatDate
import com.explorefile.filemanager.extensions.formatSize
import com.explorefile.filemanager.extensions.getAlertDialogBuilder
import com.explorefile.filemanager.extensions.getAndroidSAFUri
import com.explorefile.filemanager.extensions.getDoesFilePathExist
import com.explorefile.filemanager.extensions.getExifCameraModel
import com.explorefile.filemanager.extensions.getExifDateTaken
import com.explorefile.filemanager.extensions.getExifProperties
import com.explorefile.filemanager.extensions.getFileInputStreamSync
import com.explorefile.filemanager.extensions.getFilenameFromPath
import com.explorefile.filemanager.extensions.getIsPathDirectory
import com.explorefile.filemanager.extensions.getLongValue
import com.explorefile.filemanager.extensions.isAudioSlow
import com.explorefile.filemanager.extensions.isImageSlow
import com.explorefile.filemanager.extensions.isPathOnOTG
import com.explorefile.filemanager.extensions.isRestrictedSAFOnlyRoot
import com.explorefile.filemanager.extensions.isVideoSlow
import com.explorefile.filemanager.extensions.md5
import com.explorefile.filemanager.extensions.setupDialogStuff
import com.explorefile.filemanager.extensions.showErrorToast
import com.explorefile.filemanager.extensions.toast
import com.explorefile.filemanager.helpers.Helpers
import com.explorefile.filemanager.helpers.ensureBackgroundThread
import com.explorefile.filemanager.helpers.isNougatPlus
import com.explorefile.filemanager.helpers.sumByInt
import com.explorefile.filemanager.helpers.sumByLong
import com.explorefile.filemanager.views.MyTextView
import java.io.File
import java.util.ArrayList


class ProgressDialog(
    private val activity: Activity,
    private val callback: (result: Boolean) -> Unit
) {

    private var dialog: AlertDialog? = null
    private val binding: DialogProgressBinding

    init {
        binding = DialogProgressBinding.inflate(activity.layoutInflater)

        val builder = activity.getAlertDialogBuilder()

        binding.progressBar.progress = 0
        binding.progressText.text = "0%"

        builder.apply {
            activity.setupDialogStuff(
                binding.root,
                this
            ) { alertDialog ->
                dialog = alertDialog
            }
        }
    }

    fun show() {
        dialog?.show()
    }

    fun updateProgress(percent: Int) {
        activity.runOnUiThread {
            binding.progressBar.progress = percent
            binding.progressText.text = "$percent%"
        }
    }

    fun complete(success: Boolean) {
        activity.runOnUiThread {
            dialog?.dismiss()
            callback(success)
        }
    }

    fun error(e: Exception) {
        e.printStackTrace()
        complete(false)
    }
}
