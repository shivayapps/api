package com.explorefile.filemanager.models

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File

// isSectionTitle is used only at search results for showing the current folders path
data class ListItem(
    val mPath: String, val mName: String = "", var mIsDirectory: Boolean = false, var mChildren: Int = 0, var mSize: Long = 0L, var mModified: Long = 0L,
    var isSectionTitle: Boolean, val isGridTypeDivider: Boolean
) : FileDirItem(mPath, mName, mIsDirectory, mChildren, mSize, mModified)

fun ListItem.isVideo(): Boolean
{
    return mName.endsWith(".mp4") || mName.endsWith(".mkv") || mName.endsWith(".webm") || mName.endsWith(".mov") || mName.endsWith(".avi")
}
fun ListItem.delete(): Boolean {
    val file = File(mPath)
    return if (file.exists()) {
        if (file.isDirectory) {
            file.deleteRecursively()
        } else {
            file.delete()
        }
    } else {
        false
    }
}

fun ListItem.deleteSafely(): Result<Unit> {
    return try {
        val file = File(mPath)
        if (!file.exists()) {
            Result.failure(IllegalStateException("File does not exist"))
        } else {
            val deleted = if (file.isDirectory) {
                file.deleteRecursively()
            } else {
                file.delete()
            }

            if (deleted) Result.success(Unit)
            else Result.failure(Exception("Delete failed"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }
}


fun ListItem.share(context: Context) {
    val file = File(mPath)

    if (!file.exists() || file.isDirectory) return

    val uri = FileProvider.getUriForFile(
        context,
        "${context.packageName}.fileprovider",
        file
    )

    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "*/*"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }

    context.startActivity(
        Intent.createChooser(intent, "Share ${file.name}")
    )
}