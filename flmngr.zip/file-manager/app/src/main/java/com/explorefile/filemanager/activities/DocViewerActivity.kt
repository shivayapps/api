package com.explorefile.filemanager.activities

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.cherry.lib.doc.bean.DocEngine
import com.cherry.lib.doc.bean.DocSourceType
import com.explorefile.filemanager.R
import com.explorefile.filemanager.databinding.ActivityDocViewerBinding
import com.explorefile.filemanager.extensions.getProperBackgroundColor
import com.explorefile.filemanager.extensions.viewBinding
import com.explorefile.filemanager.helpers.NavigationIcon
import kotlin.getValue

class DocViewerActivity : BaseActivity() {

    private var filePath = ""
    private var fileName = ""
    private var fileType = ""

    val binding by viewBinding(ActivityDocViewerBinding::inflate)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        filePath = intent?.getStringExtra("filePath").toString()
        fileName = intent?.getStringExtra("fileName").toString()
        fileType = intent?.getStringExtra("fileType").toString()
        initActions()
        getDataUpdateUi()

        setupToolbar()
    }

    fun initActions() {
//        binding.ivBack.setOnClickListener {
//            onBackPressed()
//        }
    }
    override fun onResume() {
        super.onResume()
        setupToolbar(binding.docviewerToolbar, NavigationIcon.Arrow)
        updateTopBarColors(binding.docviewerToolbar, getProperBackgroundColor())
    }
    private fun setupToolbar() {
        binding.docviewerToolbar.title = fileName
    }
    private fun getDataUpdateUi(){
        filePath = intent?.getStringExtra("filePath").toString()
        fileName = intent?.getStringExtra("fileName").toString()
        fileType = intent?.getStringExtra("fileType").toString()

//        val colorResId = when (fileType) {
//            "PDF" -> R.color.light_red
//            "PowerPoint" -> R.color.light_orange
//            "Excel" -> R.color.light_green
//            "Word" -> R.color.light_blue
//            else -> R.color.white
//        }
//
//        binding.activityDocViewerToolbar.setBackgroundColor(ContextCompat.getColor(this, colorResId))
//        setStatusBarColor(colorResId)

        try {
            binding.docview.openDoc(this, filePath, DocSourceType.PATH, -1, true, DocEngine.GOOGLE)
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to open document.", Toast.LENGTH_SHORT).show()
        }
    }
}