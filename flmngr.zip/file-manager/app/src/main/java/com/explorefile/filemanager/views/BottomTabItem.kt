package com.explorefile.filemanager.views

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.explorefile.filemanager.R
import com.explorefile.filemanager.extensions.applyColorFilter
import com.explorefile.filemanager.extensions.baseConfig
import com.explorefile.filemanager.extensions.getProperPrimaryColor

class BottomTabItem @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    private val container: LinearLayout
    private val icon: ImageView
    private val title: TextView

    var isSelectedTab = false
        set(value) {
            field = value
            updateState()
        }

    init {
        LayoutInflater.from(context).inflate(R.layout.item_bottom_tab, this, true)
        container = findViewById(R.id.container)
        icon = findViewById(R.id.icon)
        title = findViewById(R.id.title)
        val textColor = context.baseConfig.textColor
        title.setTextColor(textColor)
        icon.applyColorFilter(textColor)
        updateState()
    }

    fun setData(iconRes: Int, text: String) {
        icon.setImageResource(iconRes)
        title.text = text
    }

    private fun updateState() {
        if (isSelectedTab) {
            container.orientation = LinearLayout.HORIZONTAL
            container.setBackgroundResource(R.drawable.bg_bottom_nav)
            title.setPadding(8, 0, 0, 0)
        } else {
            container.orientation = LinearLayout.VERTICAL
            container.setBackgroundResource(android.R.color.transparent)
            title.setPadding(0, 4, 0, 0)
        }
    }
}
