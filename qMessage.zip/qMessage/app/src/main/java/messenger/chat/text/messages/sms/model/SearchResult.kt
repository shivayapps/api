package messenger.chat.text.messages.sms.model

data class SearchResult(val query: String, val conversation: Conversation, val messages: Int)