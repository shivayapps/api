package messenger.chat.text.messages.sms.feature.backup

import android.content.Intent
import android.os.Bundle
import androidx.documentfile.provider.DocumentFile
import com.bluelinelabs.conductor.Conductor
import com.bluelinelabs.conductor.Router
import com.bluelinelabs.conductor.RouterTransaction
import messenger.chat.text.messages.sms.common.base.QkThemedActivity
import messenger.chat.text.messages.sms.common.util.extensions.viewBinding
import dagger.android.AndroidInjection
import messenger.chat.text.messages.sms.databinding.ContainerActivityBinding


class BackupActivity : QkThemedActivity() {

    private lateinit var backupController: BackupController
    private lateinit var router: Router
    private val binding by viewBinding(ContainerActivityBinding::inflate)

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        router = Conductor.attachRouter(this, binding.container, savedInstanceState)
        backupController = BackupController()
        if (!router.hasRootController()) {
            router.setRoot(RouterTransaction.with(backupController))
        }
        showBackButton(true)
    }

    override fun onBackPressed() {
        if (!router.handleBack()) {
            super.onBackPressed()
        }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            val uri = data.data
            val takeFlags: Int = (data.flags
                    and (Intent.FLAG_GRANT_READ_URI_PERMISSION
                    or Intent.FLAG_GRANT_WRITE_URI_PERMISSION))
            contentResolver.takePersistableUriPermission(uri!!, takeFlags)
            val documentFile: DocumentFile? = DocumentFile.fromTreeUri(this, uri)
            if (documentFile != null) {
                if(documentFile.name == "Backups" && uri.toString().contains("Messages") ){
                    prefs.downloadUri.set(uri.toString())
                    backupController.permissionGivenSubject.onNext(Unit)
                } else {
//                    toastMsg(getString(R.string.select_correct_restore_folder))
                }
            } else {
//                toastMsg(getString(R.string.some_thing_wrong))
            }
        }
    }

}