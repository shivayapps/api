package messenger.chat.text.messages.sms.interactor

import messenger.chat.text.messages.sms.repository.ConversationRepository
import io.reactivex.Flowable
import javax.inject.Inject

class MarkRecycle @Inject constructor(
    private val conversationRepo: ConversationRepository,
    private val markRead: MarkRead
) : Interactor<List<Long>>() {

    override fun buildObservable(params: List<Long>): Flowable<*> {
        return Flowable.just(params.toLongArray())
            .doOnNext { threadIds -> conversationRepo.markRecycle(*threadIds) }
            .flatMap { markRead.buildObservable(params) }
    }

}