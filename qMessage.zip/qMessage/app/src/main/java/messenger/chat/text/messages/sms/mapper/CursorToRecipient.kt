package messenger.chat.text.messages.sms.mapper

import android.database.Cursor
import messenger.chat.text.messages.sms.model.Recipient

interface CursorToRecipient : Mapper<Cursor, Recipient> {

    fun getRecipientCursor(): Cursor?

    fun getRecipientCursor(id: Long): Cursor?

}