package messenger.chat.text.messages.sms.feature.compose.editing

import android.view.ViewGroup
import messenger.chat.text.messages.sms.common.base.QkAdapter
import messenger.chat.text.messages.sms.common.base.QkViewHolder
import messenger.chat.text.messages.sms.commons.extensions.baseConfig
import messenger.chat.text.messages.sms.commons.extensions.addAlpha
import messenger.chat.text.messages.sms.model.PhoneNumber
import messenger.chat.text.messages.sms.databinding.ContactNumberListItemBinding

class PhoneNumberAdapter : QkAdapter<PhoneNumber, ContactNumberListItemBinding>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QkViewHolder<ContactNumberListItemBinding> {
        return QkViewHolder(parent, ContactNumberListItemBinding::inflate).apply {
//            val textColorPrimary = parent.context.baseConfig.textColor
            val colorWithAlpha = parent.context.baseConfig.textColor.addAlpha(0.3F)
            binding.address.setTextColor(colorWithAlpha)
            binding.type.setTextColor(colorWithAlpha)

        }
    }

    override fun onBindViewHolder(holder: QkViewHolder<ContactNumberListItemBinding>, position: Int) {
        val number = getItem(position)

        holder.binding.address.text = number.address
        holder.binding.type.text = number.type
    }

    override fun areItemsTheSame(old: PhoneNumber, new: PhoneNumber): Boolean {
        return old.type == new.type && old.address == new.address
    }

    override fun areContentsTheSame(old: PhoneNumber, new: PhoneNumber): Boolean {
        return old.type == new.type && old.address == new.address
    }

}