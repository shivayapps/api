package messenger.chat.text.messages.sms.common.base

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.Subject
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.common.widget.BabyTextView
import messenger.chat.text.messages.sms.commons.extensions.beGone
import messenger.chat.text.messages.sms.commons.extensions.beVisible

abstract class QkActivity : AppCompatActivity() {
    var isHomeBackClick = true
    protected val menu: Subject<Menu> = BehaviorSubject.create()
    val toolbar by lazy { findViewById<Toolbar?>(R.id.toolbar) }

    @SuppressLint("InlinedApi")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        onNewIntent(intent)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
//                if (isHomeBackClick) {
                onBackPressed()
                true
//                } else
//                    super.onOptionsItemSelected(item)
            }

            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun setContentView(layoutResID: Int) {
        super.setContentView(layoutResID)
        setSupportActionBar(findViewById(R.id.toolbar))
//        title = title // The title may have been set before layout inflation
    }

    override fun setTitle(titleId: Int) {
//        super.setTitle(getString(titleId))
        findViewById<BabyTextView?>(R.id.toolbarTitle)?.text = getString(titleId)
//        title = getString(titleId)
//        title= getString(titleId)
    }

    override fun setTitle(title: CharSequence?) {
//        super.setTitle(title)
        findViewById<BabyTextView?>(R.id.toolbarTitle)?.text = title
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val result = super.onCreateOptionsMenu(menu)
        if (menu != null) {
            this.menu.onNext(menu)
        }
        return result
    }

    protected open fun showBackButton(show: Boolean) {
        if (show) {
            findViewById<ImageView?>(R.id.ivBack)?.beVisible()
        } else {
            findViewById<ImageView?>(R.id.ivBack)?.beGone()
        }
//        if(show) supportActionBar?.setHomeAsUpIndicator(R.drawable.ic_chevron_left_vector)
//        else supportActionBar?.setHomeAsUpIndicator(null)
//        supportActionBar?.setDisplayHomeAsUpEnabled(show)
////        supportActionBar?.setDisplayShowHomeEnabled(show)
//        supportActionBar?.setHomeButtonEnabled(show)
    }

}