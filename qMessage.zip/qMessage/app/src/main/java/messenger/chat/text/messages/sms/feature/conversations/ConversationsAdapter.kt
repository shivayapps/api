package messenger.chat.text.messages.sms.feature.conversations

import android.content.Context
import android.graphics.Typeface
import android.util.Log
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import com.jakewharton.rxbinding2.widget.checked
import io.realm.RealmResults
import messenger.chat.text.messages.sms.common.Navigator
import messenger.chat.text.messages.sms.common.base.QkRealmAdapter
import messenger.chat.text.messages.sms.common.base.QkViewHolder
import messenger.chat.text.messages.sms.common.util.Colors
import messenger.chat.text.messages.sms.common.util.DateFormatter
import messenger.chat.text.messages.sms.common.util.extensions.resolveThemeColor
import messenger.chat.text.messages.sms.common.util.extensions.setTint
import messenger.chat.text.messages.sms.model.Conversation
import messenger.chat.text.messages.sms.util.PhoneNumberUtils
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.commons.extensions.addAlpha
import messenger.chat.text.messages.sms.commons.extensions.baseConfig
import messenger.chat.text.messages.sms.databinding.ConversationListItemBinding
import messenger.chat.text.messages.sms.commons.extensions.beGone
import messenger.chat.text.messages.sms.commons.extensions.beVisible
import javax.inject.Inject

class ConversationsAdapter @Inject constructor(
    private val colors: Colors,
    private val context: Context,
    private val dateFormatter: DateFormatter,
    private val navigator: Navigator,
    private val phoneNumberUtils: PhoneNumberUtils
) : QkRealmAdapter<Conversation, ConversationListItemBinding>() {

    init {
        // This is how we access the threadId for the swipe actions
        setHasStableIds(true)
    }

    //    fun selectAll(conversationlist: RealmResults<Conversation>?) {
    fun toggleSelectAll(isSelect: Boolean) {
        val cnt = itemCount
        Log.e("ConversationsAdapter","isSelect:$isSelect, cnt:$cnt")
        if (selection.size == cnt) {
            Log.e("ConversationsAdapter","toggleSelectAll.001")
            clearSelection()
        } else {
//            Log.e("ConversationsAdapter","toggleSelectAll.002")
            for (i in 0 until cnt) {
//                Log.e("ConversationsAdapter","toggleSelectAll.003")
                val conversation = getItem(i)
                if (selection.contains(conversation?.id!!)) {
//                    selection.add(Conversationlist[i]?.id!!)
                    if (!isSelect) {
                        Log.e("ConversationsAdapter","toggleSelectAll.004")
                        selection = selection - conversation.id
                        selectionChanges.onNext(selection)
                    }
                } else {
                    if (isSelect) {
                        Log.e("ConversationsAdapter","toggleSelectAll.005")
                        selection = selection + conversation.id
                        selectionChanges.onNext(selection)
                    }
                }
//            toggleSelection(i.toLong(), false)
            }
            Log.e("ConversationsAdapter","selection:${selection.size}")
            notifyDataSetChanged()
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): QkViewHolder<ConversationListItemBinding> {
        return QkViewHolder(parent, ConversationListItemBinding::inflate).apply {

//                val textColorPrimary = parent.context.resolveThemeColor(android.R.attr.textColorPrimary)
            val textColorPrimary = context.baseConfig.textColor
            val colorWithAlpha = textColorPrimary.addAlpha(0.3F)
            binding.title.setTextColor(textColorPrimary)
            binding.date.setTextColor(textColorPrimary)
            binding.snippet.setTextColor(colorWithAlpha)

            if (viewType == 1) {

                binding.title.setTypeface(binding.title.typeface, Typeface.BOLD)
                binding.snippet.setTypeface(binding.snippet.typeface, Typeface.BOLD)
//                binding.snippet.setTextColor(textColorPrimary)
                binding.snippet.maxLines = 5

                binding.unread.isVisible = true
                binding.date.setTypeface(binding.date.typeface, Typeface.BOLD)
//                binding.date.setTextColor(textColorPrimary)
            } else {
                binding.title.setTypeface(binding.title.typeface, Typeface.NORMAL)
                binding.snippet.setTypeface(binding.snippet.typeface, Typeface.NORMAL)
            }

            binding.root.setOnClickListener {
                val conversation = getItem(adapterPosition) ?: return@setOnClickListener
                when (toggleSelection(conversation.id, false)) {
                    true -> {
                        binding.root.isActivated = isSelected(conversation.id)
                        if (isSelected(conversation.id)) {
                            binding.cbSelect.isChecked = true
                        } else {
                            binding.cbSelect.isChecked = false
                        }
                    }

                    false -> {
                        navigator.showConversation(conversation.id)
                    }
                }
            }

            binding.root.setOnLongClickListener {
                val conversation = getItem(adapterPosition) ?: return@setOnLongClickListener true
                toggleSelection(conversation.id)
                binding.root.isActivated = isSelected(conversation.id)
                if (isSelected(conversation.id)) {
                    binding.cbSelect.isChecked = true
                } else {
                    binding.cbSelect.isChecked = false
                }
                notifyDataSetChanged()
                true
            }
        }
    }

    override fun onBindViewHolder(
        holder: QkViewHolder<ConversationListItemBinding>,
        position: Int
    ) {
        val conversation = getItem(position) ?: return

        holder.binding.root.isActivated = isSelected(conversation.id)
        if (isSelected(conversation.id)) {
            holder.binding.cbSelect.isChecked = true
        } else {
            holder.binding.cbSelect.isChecked = false
        }

        holder.binding.avatars.title = conversation.getTitle()
        holder.binding.avatars.recipients = conversation.recipients
        holder.binding.title.collapseEnabled = conversation.recipients.size > 1
        holder.binding.title.text = conversation.getTitle()
        holder.binding.date.text =
            conversation.date.takeIf { it > 0 }?.let(dateFormatter::getConversationTimestamp)
        holder.binding.snippet.text = when {
            conversation.draft.isNotEmpty() -> context.getString(
                R.string.main_draft,
                conversation.draft
            )

            conversation.me -> context.getString(R.string.main_sender_you, conversation.snippet)
            else -> conversation.snippet
        }
        holder.binding.pinned.isVisible = conversation.pinned

        Log.e(
            "ConversationsAdapter",
            "selection.size:${selection.size}, isSelection:${isSelection()}, isSelected:${
                isSelected(conversation.id)
            }"
        )
        if (isSelection()) {
            holder.binding.cbSelect.beVisible()
        } else {
            holder.binding.cbSelect.beGone()
        }
//        if (isSelected(conversation.id)) {
//            holder.binding.cbSelect.isChecked=true
////            holder.binding.cbSelect.visible()
//////            holder.binding.conversationBack.setBackgroundColor(ContextCompat.getColor(MainActivity.mainActivity ?:context,R.color.subs_plan_select_bg))
//        } else {
//            holder.binding.cbSelect.isChecked=false
//////            holder.binding.conversationBack.setBackgroundColor(ContextCompat.getColor(MainActivity.mainActivity ?:context,android.R.color.transparent))
////            holder.binding.cbSelect.beGo()
//        }

        // If the last message wasn't incoming, then the colour doesn't really matter anyway
        val lastMessage = conversation.lastMessage
        val recipient = when {
            conversation.recipients.size == 1 || lastMessage == null -> conversation.recipients.firstOrNull()
            else -> conversation.recipients.find { recipient ->
                phoneNumberUtils.compare(recipient.address, lastMessage.address)
            }
        }

        holder.binding.unread.setTint(colors.theme(recipient).theme)
    }

    override fun getItemId(position: Int): Long {
        return getItem(position)?.id ?: -1
    }

    override fun getItemViewType(position: Int): Int {
        return if (getItem(position)?.unread == false) 0 else 1
    }
}
