package messenger.chat.text.messages.sms.commons.tablayout

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.text.TextUtils
import android.util.AttributeSet
import android.view.Gravity
import kotlin.math.max

open class DslBadgeDrawable : DslGradientDrawable() {

    val dslGravity = DslGravity()

    var badgeGravity: Int = Gravity.CENTER //Gravity.TOP or Gravity.RIGHT

    var badgeTextColor = Color.WHITE

    var badgeText: String? = null

    var badgeTextSize: Float = 12 * dp
        set(value) {
            field = value
            textPaint.textSize = field
        }

    var badgeAutoCircle: Boolean = true

    var badgeCircleRadius = 4 * dpi

    var badgeCircleOffsetX: Int = 0
    var badgeCircleOffsetY: Int = 0

    var badgeOffsetX: Int = 0
    var badgeOffsetY: Int = 0

    var badgeTextOffsetX: Int = 0
    var badgeTextOffsetY: Int = 0

    var badgePaddingLeft = 0
    var badgePaddingRight = 0
    var badgePaddingTop = 0
    var badgePaddingBottom = 0

    var badgeMinHeight = -2

    var badgeMinWidth = -2

    val textWidth: Float
        get() = textPaint.textWidth(badgeText)

    val maxWidth: Int
        get() = max(
            textWidth.toInt(),
            originDrawable?.minimumWidth ?: 0
        ) + badgePaddingLeft + badgePaddingRight

    val maxHeight: Int
        get() = max(
            textHeight.toInt(),
            originDrawable?.minimumHeight ?: 0
        ) + badgePaddingTop + badgePaddingBottom

    val textHeight: Float
        get() = textPaint.textHeight()

    val isCircle: Boolean
        get() = TextUtils.isEmpty(badgeText)

    override fun initAttribute(context: Context, attributeSet: AttributeSet?) {
        super.initAttribute(context, attributeSet)
        updateOriginDrawable()
    }

    override fun draw(canvas: Canvas) {
        //super.draw(canvas)

        if (badgeText == null) {
            return
        }

        with(dslGravity) {
            gravity = if (isViewRtl) {
                when (badgeGravity) {
                    Gravity.RIGHT -> {
                        Gravity.LEFT
                    }

                    Gravity.LEFT -> {
                        Gravity.RIGHT
                    }

                    else -> {
                        badgeGravity
                    }
                }
            } else {
                badgeGravity
            }

            setGravityBounds(bounds)

            if (isCircle) {
                gravityOffsetX = badgeCircleOffsetX
                gravityOffsetY = badgeCircleOffsetY
            } else {
                gravityOffsetX = badgeOffsetX
                gravityOffsetY = badgeOffsetY
            }

            val textWidth = textPaint.textWidth(badgeText)
            val textHeight = textPaint.textHeight()

            val drawHeight = if (isCircle) {
                badgeCircleRadius.toFloat()
            } else {
                val height = textHeight + badgePaddingTop + badgePaddingBottom
                if (badgeMinHeight > 0) {
                    max(height, badgeMinHeight.toFloat())
                } else {
                    height
                }
            }

            val drawWidth = if (isCircle) {
                badgeCircleRadius.toFloat()
            } else {
                val width = textWidth + badgePaddingLeft + badgePaddingRight
                if (badgeMinWidth == -1) {
                    max(width, drawHeight)
                } else if (badgeMinWidth > 0) {
                    max(width, badgeMinWidth.toFloat())
                } else {
                    width
                }
            }

            applyGravity(drawWidth, drawHeight) { centerX, centerY ->

                if (isCircle) {
                    textPaint.color = gradientSolidColor

                    val cx: Float
                    val cy: Float
                    if (gravity.isCenter()) {
                        cx = centerX.toFloat()
                        cy = centerY.toFloat()
                    } else {
                        cx = centerX.toFloat() + _gravityOffsetX
                        cy = centerY.toFloat() + _gravityOffsetY
                    }

                    textPaint.color = gradientSolidColor
                    canvas.drawCircle(
                        cx,
                        cy,
                        badgeCircleRadius.toFloat(),
                        textPaint
                    )

                    if (gradientStrokeWidth > 0 && gradientStrokeColor != Color.TRANSPARENT) {
                        val oldWidth = textPaint.strokeWidth
                        val oldStyle = textPaint.style

                        textPaint.color = gradientStrokeColor
                        textPaint.strokeWidth = gradientStrokeWidth.toFloat()
                        textPaint.style = Paint.Style.STROKE

                        canvas.drawCircle(
                            cx,
                            cy,
                            badgeCircleRadius.toFloat(),
                            textPaint
                        )

                        textPaint.strokeWidth = oldWidth
                        textPaint.style = oldStyle
                    }

                } else {
                    textPaint.color = badgeTextColor

                    val textDrawX: Float = centerX - textWidth / 2
                    val textDrawY: Float = centerY + textHeight / 2

                    val bgLeft = _gravityLeft
                    val bgTop = _gravityTop

                    if (badgeAutoCircle && badgeText?.length == 1) {
                        if (gradientSolidColor != Color.TRANSPARENT) {
                            textPaint.color = gradientSolidColor
                            canvas.drawCircle(
                                centerX.toFloat(),
                                centerY.toFloat(),
                                max(maxWidth, maxHeight).toFloat() / 2,
                                textPaint
                            )
                        }
                    } else {
                        originDrawable?.apply {
                            setBounds(
                                bgLeft, bgTop,
                                (bgLeft + drawWidth).toInt(),
                                (bgTop + drawHeight).toInt()
                            )
                            draw(canvas)
                        }
                    }

                    //绘制文本
                    textPaint.color = badgeTextColor
                    canvas.drawText(
                        badgeText!!,
                        textDrawX + badgeTextOffsetX,
                        textDrawY - textPaint.descent() + badgeTextOffsetY,
                        textPaint
                    )
                }
            }
        }
    }

    override fun getIntrinsicWidth(): Int {
        val width = if (isCircle) {
            badgeCircleRadius * 2
        } else if (badgeAutoCircle && badgeText?.length == 1) {
            max(maxWidth, maxHeight)
        } else {
            maxWidth
        }
        return max(badgeMinWidth, width)
    }

    override fun getIntrinsicHeight(): Int {
        val height = if (isCircle) {
            badgeCircleRadius * 2
        } else if (badgeAutoCircle && badgeText?.length == 1) {
            max(maxWidth, maxHeight)
        } else {
            maxHeight
        }
        return max(badgeMinHeight, height)
    }
}
