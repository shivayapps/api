package messenger.chat.text.messages.sms.feature.main

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.provider.Telephony
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import androidx.browser.customtabs.CustomTabColorSchemeParams
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import com.bluelinelabs.conductor.Conductor
import com.bluelinelabs.conductor.Router
import com.bluelinelabs.conductor.RouterTransaction
import messenger.chat.text.messages.sms.common.base.QkThemedActivity
import messenger.chat.text.messages.sms.common.util.extensions.viewBinding
import dagger.android.AndroidInjection
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.commons.dialog.PermissionRequiredDialog
import messenger.chat.text.messages.sms.commons.extensions.config
import messenger.chat.text.messages.sms.commons.extensions.getPermissionString
import messenger.chat.text.messages.sms.commons.extensions.hasPermission
import messenger.chat.text.messages.sms.commons.extensions.isPackageInstalled
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_ACCESS_COARSE_LOCATION
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_ACCESS_FINE_LOCATION
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_CALL_PHONE
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_CAMERA
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_GET_ACCOUNTS
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_MEDIA_LOCATION
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_POST_NOTIFICATIONS
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_READ_CALENDAR
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_READ_CALL_LOG
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_READ_CONTACTS
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_READ_MEDIA_AUDIO
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_READ_MEDIA_IMAGES
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_READ_MEDIA_VIDEO
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_READ_MEDIA_VISUAL_USER_SELECTED
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_READ_PHONE_STATE
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_READ_SMS
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_READ_STORAGE
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_READ_SYNC_SETTINGS
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_RECORD_AUDIO
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_SEND_SMS
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_WRITE_CALENDAR
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_WRITE_CALL_LOG
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_WRITE_CONTACTS
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_WRITE_STORAGE
import messenger.chat.text.messages.sms.commons.helpers.isOreoPlus
import messenger.chat.text.messages.sms.commons.helpers.isQPlus
import messenger.chat.text.messages.sms.commons.helpers.isTiramisuPlus
import messenger.chat.text.messages.sms.databinding.ActivityPermissionBinding

class PermissionActivity : QkThemedActivity() {

    private val binding by viewBinding(ActivityPermissionBinding::inflate)

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.btnStart.setOnClickListener {

            if(binding.checkBox.isChecked){

                loadMessages()
            }else{
                Toast.makeText(this,"Please click the checkbox to proceed",Toast.LENGTH_SHORT).show()
            }
        }
        binding.tvTermsPrivacy.setOnClickListener {
            privacyUrlRedirect()
        }

        if(binding.checkBox.isChecked){
            binding.btnStart.background =
                ContextCompat.getDrawable(this@PermissionActivity, R.drawable.round_button)
            binding.btnStart.setTextColor(
                ContextCompat.getColor(
                    this@PermissionActivity,
                    R.color.whiteOnlyColor
                ))
        }else{

            binding.btnStart.background =
                ContextCompat.getDrawable(this@PermissionActivity, R.drawable.round_button_grey)
            binding.btnStart.setTextColor(
                ContextCompat.getColor(
                    this@PermissionActivity,
                    R.color.btn_txt_disabled
                )
            )
        }


        //  binding.checkBox.isChecked = true
        binding.checkBox.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                //   binding.btnStart.isEnabled = true
                binding.btnStart.background =
                    ContextCompat.getDrawable(this@PermissionActivity, R.drawable.round_button)
                binding.btnStart.setTextColor(
                    ContextCompat.getColor(
                        this@PermissionActivity,
                        R.color.whiteOnlyColor
                    )
                )
            } else {
                //     binding.btnStart.isEnabled = false
                binding.btnStart.background =
                    ContextCompat.getDrawable(this@PermissionActivity, R.drawable.round_button_grey)
                binding.btnStart.setTextColor(
                    ContextCompat.getColor(
                        this@PermissionActivity,
                        R.color.btn_txt_disabled
                    )
                )

                binding.checkBox.isChecked = false
            }
        }
    }

    private fun launchHomeScreen() {
        config.saveData("for_first_time", true)
        Log.e("getConversations", "getConversations.launchHomeScreen.003")
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private val MAKE_DEFAULT_APP_REQUEST = 111
    private fun loadMessages() {
        if (isQPlus()) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager!!.isRoleAvailable(RoleManager.ROLE_SMS)) {
                if (roleManager.isRoleHeld(RoleManager.ROLE_SMS)) {
                    askPermissions()
                } else {
                    val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_SMS)
                    intent.putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName)
                    startActivityForResult(intent, MAKE_DEFAULT_APP_REQUEST)
                }
            } else {
//                Log.i(TAG, "loadMessages: ")
//                toast(R.string.unknown_error_occurred)
                finish()
            }
        } else {
            if (Telephony.Sms.getDefaultSmsPackage(this) == packageName) {
                askPermissions()
            } else {
                val intent = Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                intent.putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName)
                startActivityForResult(intent, MAKE_DEFAULT_APP_REQUEST)
            }
        }
    }

    private fun askPermissions() {
        handlePermission(PERMISSION_READ_SMS) {
            if (it) {
                handlePermission(PERMISSION_SEND_SMS) {
                    if (it) {
                        handlePermission(PERMISSION_READ_CONTACTS) {
                            handleNotificationPermission { granted ->
                                if (!granted) {
                                    PermissionRequiredDialog(
                                        activity = this,
                                        textId = R.string.allow_notifications_incoming_messages,
                                        positiveActionCallback = { openNotificationSettings() })
                                }
                            }

                            launchHomeScreen()

                        }
                    } else {
//                        finish()
                    }
                }
            } else {
//                finish()
            }
        }
    }

    fun openNotificationSettings() {
        if (isOreoPlus()) {
            val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            intent.putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            startActivity(intent)
        } else {
            // For Android versions below Oreo, you can't directly open the app's notification settings.
            // You can open the general notification settings instead.
            val intent = Intent(Settings.ACTION_SETTINGS)
            startActivity(intent)
        }
    }
    fun handleNotificationPermission(callback: (granted: Boolean) -> Unit) {
        if (!isTiramisuPlus()) {
            callback(true)
        } else {
            handlePermission(PERMISSION_POST_NOTIFICATIONS) { granted ->
                callback(granted)
            }
        }
    }

    var actionOnPermission: ((granted: Boolean) -> Unit)? = null
    var isAskingPermissions = false
    private val GENERIC_PERM_HANDLER = 100

    fun handlePermission(permissionId: Int, callback: (granted: Boolean) -> Unit) {
        actionOnPermission = null
        if (hasPermission(permissionId)) {
            callback(true)
        } else {
            isAskingPermissions = true
            actionOnPermission = callback
            ActivityCompat.requestPermissions(this, arrayOf(getPermissionString(permissionId)), GENERIC_PERM_HANDLER)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
        super.onActivityResult(requestCode, resultCode, resultData)
        Log.e("MAKEDEFAULTAPPREQUEST", " -00 " + "onActivityResult - " + requestCode)
        if (requestCode == MAKE_DEFAULT_APP_REQUEST) {
            if (resultCode == Activity.RESULT_OK) {
                askPermissions()
            } else if (resultCode == Activity.RESULT_CANCELED) {
                /* val alertDialog = AlertDialog.Builder(this)
                     .setMessage("Please set this app as the default SMS app in settings")
                     .setNegativeButton("Cancel") { dialog, _ ->
                         dialog.dismiss()
                         Toast.makeText(this, "This permission must required for use this application", Toast.LENGTH_SHORT).show()
                     }
                     .setPositiveButton("Allow") { _, _ ->
                         val intent = Intent(android.provider.Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)
                         startActivity(intent)
                     }
                     .create()
                 alertDialog.show()*/

                permissiondialog()
            }
        }
    }

    var alertDialog: android.app.AlertDialog? = null
    private fun permissiondialog() {
        if (isFinishing || isDestroyed) {
            return
        }

        val dialogBuilder = android.app.AlertDialog.Builder(this)
        val view = layoutInflater.inflate(R.layout.dialog_sms_permission, null)

        dialogBuilder.setView(view)

        val btnDismiss = view.findViewById<TextView>(R.id.btnDismiss)
        val btnsetup = view.findViewById<TextView>(R.id.btnsetup)
//        val applyBackground = ResourcesCompat.getDrawable(resources, R.drawable.button_background_rounded, theme) as RippleDrawable
//        (applyBackground as LayerDrawable).findDrawableByLayerId(R.id.button_background_holder)
//            .setColorFilter(Color.parseColor("#3774FF"), PorterDuff.Mode.SRC_IN)
//        btnsetup.background = applyBackground

//        val applybtnDismissBackground = ResourcesCompat.getDrawable(resources, R.drawable.button_dismissbackground_rounded, theme) as RippleDrawable
//        btnDismiss.background = applybtnDismissBackground

        btnsetup.setTextColor(Color.parseColor("#FFFFFF"))

        btnDismiss.setTextColor(Color.parseColor("#000000"))

        btnsetup.setOnClickListener {
            alertDialog?.dismiss()
            val intent = Intent(android.provider.Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)
            startActivity(intent)
        }

        btnDismiss.setOnClickListener {
            alertDialog?.dismiss()
            //  Toast.makeText(this, "This permission must required for use this application", Toast.LENGTH_SHORT).show()
        }

        alertDialog = dialogBuilder.create()

        alertDialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        if (alertDialog?.isShowing == false) {

//            Log.i("onCreate", "permissiondialog: ")
            alertDialog?.show()
//            CHECK_FIRSTTIME_DIALOG = true
        }
    }

    private fun privacyUrlRedirect() {
        val url: String = resources?.getString(R.string.privacy_policy_url).toString()

        val builder = CustomTabsIntent.Builder()
        val params = CustomTabColorSchemeParams.Builder()
        params.setToolbarColor(
            ContextCompat.getColor(
                this@PermissionActivity,
                R.color.color_app_theme
            )
        )
        builder.setDefaultColorSchemeParams(params.build())
        builder.setShowTitle(true)
        builder.setShareState(CustomTabsIntent.SHARE_STATE_ON)
        builder.setInstantAppsEnabled(true)
        val customBuilder = builder.build()

        if (isPackageInstalled("com.android.chrome")) {
            customBuilder.intent.setPackage("com.android.chrome")
            customBuilder.launchUrl(this@PermissionActivity, Uri.parse(url))
        } else {
            val i = Intent(Intent.ACTION_VIEW)
            i.data = Uri.parse(url)
            startActivity(i)
        }
    }

    override fun onBackPressed() {
        Toast.makeText(this, "Kindly grant the necessary permissions", Toast.LENGTH_SHORT).show()
//        super.onBackPressed()
//        launchHomeScreen()
    }
}