package messenger.chat.text.messages.sms.feature.settings.swipe

import android.view.View
import androidx.core.view.isVisible
import com.jakewharton.rxbinding2.view.clicks
import messenger.chat.text.messages.sms.common.QkDialog
import messenger.chat.text.messages.sms.common.base.QkController
import messenger.chat.text.messages.sms.common.util.Colors
import messenger.chat.text.messages.sms.common.util.extensions.animateLayoutChanges
import messenger.chat.text.messages.sms.common.util.extensions.setBackgroundTint
import messenger.chat.text.messages.sms.common.util.extensions.setTint
import messenger.chat.text.messages.sms.injection.appComponent
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.databinding.SwipeActionsControllerBinding
import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import javax.inject.Inject

class SwipeActionsController :
    QkController<SwipeActionsView, SwipeActionsState, SwipeActionsPresenter, SwipeActionsControllerBinding>(
        SwipeActionsControllerBinding::inflate
    ), SwipeActionsView {

    @Inject
    override lateinit var presenter: SwipeActionsPresenter

    @Inject
    lateinit var actionsDialog: QkDialog

    @Inject
    lateinit var colors: Colors

    /**
     * Allows us to subscribe to [actionClicks] more than once
     */
    private val actionClicks: Subject<SwipeActionsView.Action> = PublishSubject.create()

    init {
        appComponent.inject(this)

        actionsDialog.adapter.setData(R.array.settings_swipe_actions)
    }

    override fun onViewCreated() {
        colors.theme().let { theme ->
            binding.rightIcon.setBackgroundTint(theme.theme)
            binding.rightIcon.setTint(theme.textPrimary)
            binding.leftIcon.setBackgroundTint(theme.theme)
            binding.leftIcon.setTint(theme.textPrimary)
        }

        binding.right.postDelayed({ binding.right.animateLayoutChanges = true }, 100)
        binding.left.postDelayed({ binding.left.animateLayoutChanges = true }, 100)

        Observable.merge(
            binding.right.clicks().map { SwipeActionsView.Action.RIGHT },
            binding.left.clicks().map { SwipeActionsView.Action.LEFT })
            .autoDisposable(scope())
            .subscribe(actionClicks)
    }

    override fun onAttach(view: View) {
        super.onAttach(view)
        presenter.bindIntents(this)
        setTitle(R.string.settings_swipe_actions)
//        showBackButton(true)
    }

    override fun actionClicks(): Observable<SwipeActionsView.Action> = actionClicks

    override fun actionSelected(): Observable<Int> = actionsDialog.adapter.menuItemClicks

    override fun showSwipeActions(selected: Int) {
        actionsDialog.adapter.selectedItem = selected
        activity?.let(actionsDialog::show)
    }

    override fun render(state: SwipeActionsState) {
        binding.rightIcon.isVisible = state.rightIcon != 0
        binding.rightIcon.setImageResource(state.rightIcon)
        binding.rightLabel.text = state.rightLabel

        binding.leftIcon.isVisible = state.leftIcon != 0
        binding.leftIcon.setImageResource(state.leftIcon)
        binding.leftLabel.text = state.leftLabel
    }

}