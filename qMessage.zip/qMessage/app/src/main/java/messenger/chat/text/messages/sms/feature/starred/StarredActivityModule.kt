package messenger.chat.text.messages.sms.feature.starred

import androidx.lifecycle.ViewModel
import dagger.Module
import dagger.Provides
import dagger.multibindings.IntoMap
import messenger.chat.text.messages.sms.injection.ViewModelKey

@Module
class StarredActivityModule {

    @Provides
    @IntoMap
    @ViewModelKey(StarredViewModel::class)
    fun provideScheduledViewModel(viewModel: StarredViewModel): ViewModel = viewModel

}