package messenger.chat.text.messages.sms.feature.blocking.numbers

import messenger.chat.text.messages.sms.common.base.QkViewContract
import io.reactivex.Observable

interface BlockedNumbersView : QkViewContract<BlockedNumbersState> {

    fun unblockAddress(): Observable<Long>
    fun addAddress(): Observable<*>
    fun saveAddress(): Observable<String>

    fun showAddDialog()

}
