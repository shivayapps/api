package messenger.chat.text.messages.sms.common.widget

import android.content.Context
import android.content.res.ColorStateList
import android.util.AttributeSet
import androidx.appcompat.widget.SwitchCompat
import messenger.chat.text.messages.sms.common.util.Colors
import messenger.chat.text.messages.sms.common.util.extensions.resolveThemeColor
import messenger.chat.text.messages.sms.common.util.extensions.withAlpha
import messenger.chat.text.messages.sms.injection.appComponent
import messenger.chat.text.messages.sms.util.Preferences
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.common.util.TextViewStyler
import messenger.chat.text.messages.sms.commons.extensions.getContrastColor
import javax.inject.Inject

class QkSwitch @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : SwitchCompat(context, attrs) {

    @Inject
    lateinit var colors: Colors

    @Inject
    lateinit var prefs: Preferences

//    @Inject
//    lateinit var textViewStyler: TextViewStyler

    init {
        if (!isInEditMode) {
            appComponent.inject(this)
//            textViewStyler.applyAttributes(this, attrs)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()

        if (!isInEditMode) {
            val states = arrayOf(
                intArrayOf(-android.R.attr.state_enabled),
                intArrayOf(android.R.attr.state_checked),
                intArrayOf()
            )

            thumbTintList = ColorStateList(
                states, intArrayOf(
                    context.resolveThemeColor(R.attr.switchThumbDisabled),
                    colors.theme().theme,
                    context.resolveThemeColor(R.attr.switchThumbEnabled)
                )
            )

            trackTintList = ColorStateList(
                states, intArrayOf(
                    context.resolveThemeColor(R.attr.switchTrackDisabled),
                    colors.theme().theme.withAlpha(0x4D),
                    context.resolveThemeColor(R.attr.switchTrackEnabled)
                )
            )
        }
    }

    fun setColors(textColor: Int, accentColor: Int, backgroundColor: Int) {
        setTextColor(textColor)
        val states = arrayOf(intArrayOf(-android.R.attr.state_checked), intArrayOf(android.R.attr.state_checked))
        val thumbCheckedColors =
            accentColor.getContrastColor() //if (accentColor == resources.getColor(R.color.white)) backgroundColor else resources.getColor(R.color.white)
        val thumbColors = intArrayOf(resources.getColor(R.color.thumb_deactivated), accentColor)
        val trackColors = intArrayOf(resources.getColor(R.color.track_deactivated), accentColor) //accentColor.adjustAlpha(0.3f)
        //DrawableCompat.setTintList(DrawableCompat.wrap(thumbDrawable!!), ColorStateList(states, thumbColors))
        //DrawableCompat.setTintList(DrawableCompat.wrap(trackDrawable!!), ColorStateList(states, trackColors))
        thumbTintList = ColorStateList(states, thumbColors)
        trackTintList = ColorStateList(states, trackColors)
    }
}