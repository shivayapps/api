package messenger.chat.text.messages.sms.feature.backup

import messenger.chat.text.messages.sms.common.base.QkViewContract
import messenger.chat.text.messages.sms.model.BackupFile
import io.reactivex.Observable

interface BackupView : QkViewContract<BackupState> {

//    fun activityVisible(): Observable<*>
//    fun permissionGiven(): Observable<*>
//    fun restoreClicks(): Observable<*>
//    fun restoreFileSelected(): Observable<BackupFile>
//    fun restoreConfirmed(): Observable<*>
//    fun stopRestoreClicks(): Observable<*>
//    fun stopRestoreConfirmed(): Observable<*>
//    fun stopBackup(): Observable<*>
//    fun fabClicks(): Observable<*>
//
//    fun requestStoragePermission()
//    fun selectFile()
//    fun confirmRestore()
//    fun stopRestore()

    fun activityVisible(): Observable<*>
    fun permissionGiven(): Observable<*>
    fun restoreClicks(): Observable<*>
    fun restoreFileSelected(): Observable<BackupFile>
    fun restoreConfirmed(): Observable<*>
    fun deleteRestoreFileSelected(): Observable<BackupFile>
//    fun deleteRestoreFileSelected2(): Observable<*>
    fun stopRestoreClicks(): Observable<*>
    fun stopRestoreConfirmed(): Observable<*>
    fun stopBackup(): Observable<*>
    fun fabClicks(): Observable<*>


    fun requestDefaultSms()
    fun requestStoragePermission()
    fun selectFile()
    fun confirmRestore()
    fun stopRestore()
    fun showDialog()

}
