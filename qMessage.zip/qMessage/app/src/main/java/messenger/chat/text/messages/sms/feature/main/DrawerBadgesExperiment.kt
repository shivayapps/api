package messenger.chat.text.messages.sms.feature.main

import android.content.Context
import messenger.chat.text.messages.sms.experiment.Experiment
import messenger.chat.text.messages.sms.experiment.Variant
import messenger.chat.text.messages.sms.manager.AnalyticsManager
import javax.inject.Inject

class DrawerBadgesExperiment @Inject constructor(
    context: Context,
    analyticsManager: AnalyticsManager
) : Experiment<Boolean>(context, analyticsManager) {

    override val key: String = "Drawer Badges"

    override val variants: List<Variant<Boolean>> = listOf(
        Variant("variant_a", false),
        Variant("variant_b", true)
    )

    override val default: Boolean = false

    override val qualifies: Boolean = true

}