package messenger.chat.text.messages.sms.commons.adapters

import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import messenger.chat.text.messages.sms.common.base.QkAdapter
import messenger.chat.text.messages.sms.common.base.QkViewHolder
import messenger.chat.text.messages.sms.common.util.extensions.forwardTouches
import messenger.chat.text.messages.sms.commons.extensions.addAlpha
import messenger.chat.text.messages.sms.commons.extensions.baseConfig
import messenger.chat.text.messages.sms.databinding.ContactListItemNewBinding
import messenger.chat.text.messages.sms.feature.compose.editing.PhoneNumberAdapter
import messenger.chat.text.messages.sms.feature.main.MainActivity
import messenger.chat.text.messages.sms.model.ContactData
import messenger.chat.text.messages.sms.model.PhoneNumber
import messenger.chat.text.messages.sms.model.RecipientData

class ContactItemAdapter : QkAdapter<ContactData, ContactListItemNewBinding>() {
    private val numbersViewPool = RecyclerView.RecycledViewPool()

    init {
        // This is how we access the threadId for the swipe actions
        setHasStableIds(true)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QkViewHolder<ContactListItemNewBinding> {
        return QkViewHolder(parent, ContactListItemNewBinding::inflate).apply {
            val textColorPrimary = parent.context.baseConfig.textColor
            binding.title.setTextColor(textColorPrimary)

            binding.numbers.setRecycledViewPool(numbersViewPool)
            binding.numbers.adapter = PhoneNumberAdapter()
            binding.numbers.forwardTouches(binding.root)

            binding.root.setOnClickListener {
                val item = getItem(adapterPosition)
                (it.context as? MainActivity)?.onContactClick(item)
            }

            binding.root.setOnLongClickListener {
                val item = getItem(adapterPosition)
                (it.context as? MainActivity)?.onContactLongClick(item)
                true
            }


        }
    }

    override fun onBindViewHolder(holder: QkViewHolder<ContactListItemNewBinding>, position: Int) {

        val contact = getItem(position) ?: return
        var numbersList = ArrayList<PhoneNumber>()
        try {
            numbersList = ArrayList(contact.numbers)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        holder.binding.avatars.recipientData = listOf(
            RecipientData(
                address = numbersList.firstOrNull()?.address ?: "",
                contact = contact
            )
        )
        try {
            holder.binding.title.text = contact.name
        } catch (e: Exception) {
            e.printStackTrace()
        }
        holder.binding.subtitle.isVisible = false
        holder.binding.numbers.isVisible = true
        (holder.binding.numbers.adapter as PhoneNumberAdapter).data = numbersList
    }

    override fun areContentsTheSame(old: ContactData, new: ContactData): Boolean {
        return old.name == new.name && old.numbers == new.numbers
    }

    override fun areItemsTheSame(old: ContactData, new: ContactData): Boolean {
        return old.name == new.name && old.numbers == new.numbers
    }

}
