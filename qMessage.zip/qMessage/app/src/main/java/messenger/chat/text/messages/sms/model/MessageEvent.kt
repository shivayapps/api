package messenger.chat.text.messages.sms.model


data class MessageEvent(val type: String, val data: Any? = null)

const val REFRESH_MESSAGE = "REFRESH_MESSAGE"
const val REFRESH_CONTACT_GROUP = "REFRESH_CONTACT_GROUP"
const val SYNC_MESSAGE = "SYNC_MESSAGE"
const val UPDATE_ALL_CONTACT = "UPDATE_ALL_CONTACT"
const val THEME_CHANGED = "THEME_CHANGED"
const val REFRESH_ARCHIVE = "REFRESH_ARCHIVE"
