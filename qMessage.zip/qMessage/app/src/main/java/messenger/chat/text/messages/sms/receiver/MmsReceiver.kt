package messenger.chat.text.messages.sms.receiver

import com.android.mms.transaction.PushReceiver

class MmsReceiver : PushReceiver()