package messenger.chat.text.messages.sms.appmanager

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.BlendMode
import android.graphics.BlendModeColorFilter
import android.graphics.PorterDuff
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.commons.extensions.*


import java.lang.Exception

/**
 * Adapter to list the installed apps
 */
class AppListAdapter(
    val context: Context,
    private val appList: List<AppModel>,
    private val appLaunchListener: IAppLaunchListener
) : RecyclerView.Adapter<AppListAdapter.ViewHolder>(), Filterable {

    var appFilterList = appList
    var textColor = context.getProperTextColor()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val context = parent.context
        val inflater = LayoutInflater.from(context)
        val languageView = inflater.inflate(
            R.layout.app_info_item, parent, false
        )
        return ViewHolder(languageView)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val context = viewHolder.itemView.context
        viewHolder.txtAppName.text = appFilterList[position].appName
//        viewHolder.txtVersion.text = String.format(
//            context.getString(R.string.installed_app_version),
//            appFilterList[position].versionName
//        )
//        viewHolder.txtVersionCode.text = String.format(
//            context.getString(R.string.installed_app_version_code),
//            appFilterList[position].versionCode
//        )

        try {
            appFilterList[position].launcherIcon?.let {
                viewHolder.ivAppIcon.setBackgroundDrawable(it)
            }?:run {
                viewHolder.ivAppIcon.setBackgroundDrawable(viewHolder.itemView.context.getDrawable(R.drawable.manage_apps))
            }
        }catch (e : Exception) {
            viewHolder.ivAppIcon.setBackgroundDrawable(viewHolder.itemView.context.getDrawable(R.drawable.manage_apps))
        }
//        viewHolder.itemView.setOnClickListener {
//            appLaunchListener.onAppSelected(appFilterList[position])
//        }
        viewHolder.appOption.setOnClickListener {
            showPopupMenu(viewHolder.appOption,appFilterList[position])
//            appLaunchListener.onAppSelected(appFilterList[position])
        }
    }

    fun setAppList(appList: List<AppModel>) {
        this.appFilterList = appList
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int {
        return appFilterList.size
    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(constraint: CharSequence?): FilterResults {
                val charSearch = constraint.toString()
                appFilterList = if (charSearch.isEmpty()) {
                    appList
                } else {
                    appList.filter { it.appName.contains(charSearch, true) }
                }
                val filterResults = FilterResults()
                filterResults.values = appFilterList
                return filterResults
            }

            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                appFilterList = results?.values as MutableList<AppModel>
                setAppList(appFilterList)
            }
        }
    }

    private fun showPopupMenu(view: View,appInfo: AppModel) {
//        val wrapper: Context = ContextThemeWrapper(context, context.getPopupMenuTheme())
//        val popupMenu = PopupMenu(wrapper, view, Gravity.END)
        val popupMenu = PopupMenu(context, view, Gravity.END)
        popupMenu.menu.add(1, 1, 1, "Launch App")
        popupMenu.menu.add(1, 2, 2, "App Info")
        popupMenu.menu.add(1, 3, 3, "Open in Store")
        popupMenu.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> {
                    LauncherViewModel().getLauncherIntent(context, appInfo.packageName)?.let {
                        context.startActivity(it)
                    }
                }

                2 -> {
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    intent.data = Uri.parse("package:${appInfo.packageName}")
                    context.startActivity(intent)
                }

                3 -> {
                    val url="market://details?id=${appInfo.packageName}"
                    Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                        try {
                            context.startActivity(this)
                        } catch (e: ActivityNotFoundException) {
                            context.toast(R.string.no_app_found)
                        } catch (e: Exception) {
                            context.showErrorToast(e)
                        }
                    }
                }
                else -> {

                    //if (numbersList.isNotEmpty()) activity.copyToClipboard(numbersList[item.itemId - 4])
                }
            }
            true
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            popupMenu.setForceShowIcon(true)
        }
        popupMenu.show()
        // icon coloring
//        popupMenu.menu.apply {
//            for (index in 0 until this.size()) {
//                val item = this.getItem(index)
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
//                    item.icon!!.colorFilter = BlendModeColorFilter(
//                        textColor, BlendMode.SRC_IN
//                    )
//                } else {
//                    item.icon!!.setColorFilter(textColor, PorterDuff.Mode.SRC_IN)
//                }
//            }
//        }
    }

    interface IAppLaunchListener {
        fun onAppSelected(appModel: AppModel)
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val appOption = itemView.findViewById<ImageView>(R.id.appOption)
        val txtAppName = itemView.findViewById<TextView>(R.id.appName)
//        val txtVersion = itemView.findViewById<TextView>(R.id.appVersion)
//        val txtVersionCode = itemView.findViewById<TextView>(R.id.appVersionCode)
        val ivAppIcon = itemView.findViewById<ImageView>(R.id.appIcon)
    }
}
