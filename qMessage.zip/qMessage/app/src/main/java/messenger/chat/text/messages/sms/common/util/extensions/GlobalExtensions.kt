package messenger.chat.text.messages.sms.common.util.extensions

fun now(): Long {
    return System.currentTimeMillis()
}
