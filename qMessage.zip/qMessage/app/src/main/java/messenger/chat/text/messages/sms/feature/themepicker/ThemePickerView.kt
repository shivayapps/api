package messenger.chat.text.messages.sms.feature.themepicker

import messenger.chat.text.messages.sms.common.base.QkViewContract
import io.reactivex.Observable

interface ThemePickerView : QkViewContract<ThemePickerState> {

    fun themeSelected(): Observable<Int>
    fun hsvThemeSelected(): Observable<Int>
    fun clearHsvThemeClicks(): Observable<*>
    fun applyHsvThemeClicks(): Observable<*>

    fun setCurrentTheme(color: Int)

}