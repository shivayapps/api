package messenger.chat.text.messages.sms.feature.themepicker.injection

import messenger.chat.text.messages.sms.feature.themepicker.ThemePickerController
import messenger.chat.text.messages.sms.injection.scope.ControllerScope
import dagger.Subcomponent

@ControllerScope
@Subcomponent(modules = [ThemePickerModule::class])
interface ThemePickerComponent {

    fun inject(controller: ThemePickerController)

    @Subcomponent.Builder
    interface Builder {
        fun themePickerModule(module: ThemePickerModule): Builder
        fun build(): ThemePickerComponent
    }

}