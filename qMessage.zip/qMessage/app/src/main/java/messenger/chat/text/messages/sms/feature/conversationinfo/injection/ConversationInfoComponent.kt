package messenger.chat.text.messages.sms.feature.conversationinfo.injection

import messenger.chat.text.messages.sms.feature.conversationinfo.ConversationInfoController
import messenger.chat.text.messages.sms.injection.scope.ControllerScope
import dagger.Subcomponent

@ControllerScope
@Subcomponent(modules = [ConversationInfoModule::class])
interface ConversationInfoComponent {

    fun inject(controller: ConversationInfoController)

    @Subcomponent.Builder
    interface Builder {
        fun conversationInfoModule(module: ConversationInfoModule): Builder
        fun build(): ConversationInfoComponent
    }

}