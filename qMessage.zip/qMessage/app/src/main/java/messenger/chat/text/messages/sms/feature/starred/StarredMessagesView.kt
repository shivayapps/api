package messenger.chat.text.messages.sms.feature.starred

import io.reactivex.Observable
import messenger.chat.text.messages.sms.common.base.QkView
import messenger.chat.text.messages.sms.model.Message

interface StarredMessagesView : QkView<StarredMessagesState> {
    val conversationClicks: Observable<Message>
    fun requestDefaultSms()
}
