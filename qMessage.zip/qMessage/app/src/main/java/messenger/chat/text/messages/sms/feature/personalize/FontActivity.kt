package messenger.chat.text.messages.sms.feature.personalize

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.widget.SeekBar
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.GridLayoutManager
import dagger.android.AndroidInjection
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.common.base.QkThemedActivity
import messenger.chat.text.messages.sms.common.util.extensions.viewBinding
import messenger.chat.text.messages.sms.commons.adapters.FontListAdapter
import messenger.chat.text.messages.sms.commons.extensions.applyColorFilter
import messenger.chat.text.messages.sms.commons.extensions.baseConfig
import messenger.chat.text.messages.sms.commons.extensions.getBottomNavigationBackgroundColorFont
import messenger.chat.text.messages.sms.commons.extensions.toast
import messenger.chat.text.messages.sms.commons.extensions.updateTextColors
import messenger.chat.text.messages.sms.databinding.ActivityFontBinding
import messenger.chat.text.messages.sms.model.MessageEvent
import messenger.chat.text.messages.sms.model.THEME_CHANGED
import org.greenrobot.eventbus.EventBus
import java.io.IOException

class FontActivity : QkThemedActivity() {


    private lateinit var adapter: FontListAdapter
    private lateinit var fontList: MutableList<Int>

    var checkfontsize = 16;
    var checkfontname = -1

    private val binding by viewBinding(ActivityFontBinding::inflate)
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        showBackButton(true)
        setTitle(R.string.title_font)

        setUI()
        setUpListener()
        setUpTheme()
    }

    private fun setUpTheme() {

        Log.e("MainActivity", "setUpTheme.useImageResource:${baseConfig.useImageResource}")
        Log.e("MainActivity", "setUpTheme.storedImageResource:${baseConfig.storedImageResource}")

        updateTextColors(binding.contentView)
        binding.toolbarTitle.setTextColor(baseConfig.primaryColor)

        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
            binding.contentView.background = ColorDrawable(resources.getColor(R.color.bottom_tabs_black_backgroundnew))
            arrayListOf(binding.ivBack).forEach {
                val colorStateList = ColorStateList.valueOf(Color.WHITE)
                it.imageTintList = colorStateList
            }
        } else {
            binding.contentView.background = ColorDrawable(baseConfig.backgroundColor)
            arrayListOf(binding.ivBack).forEach {
//                val whiteColor = ContextCompat.getColor(this, R.color.black)
                val colorStateList = ColorStateList.valueOf(Color.BLACK)
                it.imageTintList = colorStateList
            }
        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                Log.i("onCreate", "onCreateitemselse11111: ")
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.contentView.background = drawable
                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
            }
        } else {
            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
            toolbar.setBackgroundColor(baseConfig.backgroundColor)
        }

    }

    private fun setUI() {
        binding.btnApply.backgroundTintList = ColorStateList.valueOf(baseConfig.primaryColor)
        binding.btnApply.setTextColor(Color.parseColor("#FFFFFF"))

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.root.background = drawable
            }
        }

        binding.imDivider.background.applyColorFilter(getBottomNavigationBackgroundColorFont())

        checkfontname = prefs.selectedFont.get()
        checkfontsize =prefs.textSize.get()

        val typeface = ResourcesCompat.getFont(this, checkfontname)
        binding.tvone.typeface = typeface
        binding.tvtwo.typeface = typeface

        binding.tvone.textSize = checkfontsize.toFloat()
        binding.tvtwo.textSize = checkfontsize.toFloat()

        binding.recyclerView.layoutManager = GridLayoutManager(this, 3)
        fontList = getFontList()
        adapter = FontListAdapter(this@FontActivity, fontList, checkfontname) { selectedFont ->
            checkfontname = selectedFont
            val checkTypeface = ResourcesCompat.getFont(this, selectedFont)
            binding.tvone.setTypeface(checkTypeface, checkTypeface?.style ?: Typeface.NORMAL)
            binding.tvtwo.setTypeface(checkTypeface, checkTypeface?.style ?: Typeface.NORMAL)
        }
        binding.recyclerView.adapter = adapter

    }

    private fun getFontList(): MutableList<Int> {
        val fonts: MutableList<Int> = ArrayList()
        fonts.add(R.font.acme_regular)
        fonts.add(R.font.courgette_regular)
        fonts.add(R.font.josefinslab_regular)
        fonts.add(R.font.lato_regular)
        fonts.add(R.font.libre_baskerville)
        fonts.add(R.font.montserrat_regular)
        fonts.add(R.font.notoserif_regular)
        fonts.add(R.font.opensans_regular)
        fonts.add(R.font.poetsen_one)
        fonts.add(R.font.poppins_regular)
        fonts.add(R.font.roboto)
        fonts.add(R.font.rubik_regular)

        return fonts
    }

    var newFontSize = 16;
    private fun setUpListener() {

        newFontSize = prefs.textSize.get()

        binding.fontSizeSeekBar.setProgress(prefs.textSize.get())
        binding.fontSizeSeekBar.setOnSeekBarChangeListener(object :
            SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                // Update font size of the TextView based on the progress range 10-20
                val fontSize = progress // Adjust to start from 10
                newFontSize = fontSize
                binding.tvone.textSize = fontSize.toFloat()
                binding.tvtwo.textSize = fontSize.toFloat()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                // Not needed
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                // Not needed
            }
        })

        binding.ivBack.setOnClickListener {
            onBackPressed()
        }
        binding.btnApply.setOnClickListener {
//            prefs.selectedFont.set(R.font.poetsen_one)
            prefs.selectedFont.set(checkfontname)
            prefs.textSize.set(newFontSize)

            EventBus.getDefault().post(MessageEvent(THEME_CHANGED))
            toast("Setting Applied")
//            baseConfig.fontSizenew = checkfontsize
//            finish()
        }
    }
}