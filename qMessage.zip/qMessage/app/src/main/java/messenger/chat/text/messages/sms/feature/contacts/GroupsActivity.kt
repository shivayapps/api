package messenger.chat.text.messages.sms.feature.contacts

import android.os.Bundle
import android.util.Log
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import dagger.android.AndroidInjection
import io.reactivex.Observable
import io.reactivex.rxkotlin.Observables
import io.realm.Realm
import io.realm.RealmList
import io.realm.annotations.PrimaryKey
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.common.base.QkThemedActivity
import messenger.chat.text.messages.sms.common.util.extensions.viewBinding
import messenger.chat.text.messages.sms.commons.adapters.ContactItemAdapter
import messenger.chat.text.messages.sms.commons.helpers.ensureBackgroundThread
import messenger.chat.text.messages.sms.databinding.ActivityGroupsBinding
import messenger.chat.text.messages.sms.feature.fragments.contact.component.ContactDialog
import messenger.chat.text.messages.sms.feature.fragments.contact.component.GroupUpdateDialog
import messenger.chat.text.messages.sms.feature.main.MainActivity
import messenger.chat.text.messages.sms.model.Contact
import messenger.chat.text.messages.sms.model.ContactData
import messenger.chat.text.messages.sms.model.ContactGroup
import messenger.chat.text.messages.sms.model.MessageEvent
import messenger.chat.text.messages.sms.model.REFRESH_CONTACT_GROUP
import messenger.chat.text.messages.sms.repository.ContactRepository
import org.greenrobot.eventbus.EventBus
import javax.inject.Inject

class GroupsActivity : QkThemedActivity() {

    var id: Long = 0
    var title: String = ""

    @Inject
    lateinit var contactsRepo: ContactRepository

    private val allContacts: Observable<List<Contact>> by lazy { contactsRepo.getUnmanagedContacts() }
    private val contactGroups: Observable<List<ContactGroup>> by lazy { contactsRepo.getUnmanagedContactGroups() }

    var contacts: RealmList<Contact> = RealmList()
    var contactGroup: ContactGroup?=null
    var contactsAdapter = ContactItemAdapter()

    private val binding by viewBinding(ActivityGroupsBinding::inflate)

    //    lateinit var binding:ActivityGroupsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
//        enableEdgeToEdge()
//        binding=ActivityGroupsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        setTitle(R.string.groups_label)
        showBackButton(true)
        if (intent.hasExtra("groupId")) {
            id = intent.getLongExtra("groupId", 0)
            title = intent.getStringExtra("groupName") ?: ""
            Log.e("GroupsActivity","id:${id},title:${title}")
        }

        allContacts.autoDisposable(scope()).subscribe {
            Log.e("GroupsActivity","allContacts:${it.size}")
            contacts.addAll(it)
//            updateContactGroup(contacts)
        }
        contactGroups.autoDisposable(scope()).subscribe {groups->
            Log.e("GroupsActivity","allContactGroups:${groups.size}")
            for (group in groups) {
                Log.e("GroupsActivity","group.id:${group.id},contacts.size:${group.contacts.size}")
            }
            contactGroup=groups.firstOrNull{ it.id==id }
//            contactGroup=groups.filter { it.id==id }.first()
            Log.e("GroupsActivity","001:${groups.firstOrNull{ it.id==id }?.contacts?.size}")

            if(contactGroup!=null) {
                Log.e("GroupsActivity","currentGroupContact:${contactGroup?.contacts?.size}")
                contacts.addAll(contactGroup?.contacts!!)
                updateContactGroup(contacts)
            }
        }

        binding.addGroupButton.floatingButton.setOnClickListener { _ ->
            val contactDialog = ContactDialog(contacts) {
                Log.e("GroupsActivity","checkedContacts:${it.size}")
                contacts.addAll(it)
                addContactToGroup(it)
            }
            contactDialog.show(supportFragmentManager, contactDialog.tag)
        }

        binding.contacts.adapter = contactsAdapter
//        val list = (this)?.contacts ?: ArrayList()
//        contactsAdapter.data = list
    }
    fun updateContactGroup(contactList: RealmList<Contact>) {
        val contactDataList = contactList.map { contact ->
            ContactData(
                lookupKey = contact.lookupKey,
                numbers = ArrayList(contact.numbers),
                name = contact.name,
                photoUri = contact.photoUri,
                starred = contact.starred,
                lastUpdate = contact.lastUpdate
            )
        }
        runOnUiThread{
            contactsAdapter.data = contactDataList as List<ContactData>
        }
    }

    fun addContactToGroup(selectedContact: RealmList<Contact>) {
        ensureBackgroundThread {
            Realm.getDefaultInstance().use { realm ->
                val group = ContactGroup(id = id, title = title, contacts = selectedContact)
                realm.executeTransaction { realm.insertOrUpdate(group) }
            }
            runOnUiThread {
                EventBus.getDefault().post(MessageEvent(REFRESH_CONTACT_GROUP))
//                dialog?.dismiss()
//                callback.invoke()
            }
        }
    }
}