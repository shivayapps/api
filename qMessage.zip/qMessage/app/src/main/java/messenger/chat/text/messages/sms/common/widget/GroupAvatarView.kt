package messenger.chat.text.messages.sms.common.widget

import android.content.Context
import android.util.AttributeSet
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.updateLayoutParams
import messenger.chat.text.messages.sms.common.util.extensions.getColorCompat
import messenger.chat.text.messages.sms.common.util.extensions.resolveThemeColor
import messenger.chat.text.messages.sms.common.util.extensions.setBackgroundTint
import messenger.chat.text.messages.sms.common.util.extensions.viewBinding
import messenger.chat.text.messages.sms.commons.extensions.beGone
import messenger.chat.text.messages.sms.commons.extensions.beVisible
import messenger.chat.text.messages.sms.databinding.GroupAvatarViewBinding
import messenger.chat.text.messages.sms.model.Recipient
import messenger.chat.text.messages.sms.model.RecipientData

class GroupAvatarView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : ConstraintLayout(context, attrs) {
    private val binding = viewBinding(GroupAvatarViewBinding::inflate)
    var title: String = ""
    var recipients: List<Recipient> = ArrayList()
        set(value) {
            field = value.sortedWith(compareByDescending { contact -> contact.contact?.lookupKey })
            updateView()
        }
    var recipientsGroup: List<Recipient> = ArrayList()
        set(value) {
            field = value.sortedWith(compareByDescending { contact -> contact.contact?.lookupKey })
            updateView()
        }
    var recipientData: List<RecipientData> = ArrayList()
        set(value) {
            field = value.sortedWith(compareByDescending { contact -> contact.contact?.lookupKey })
            updateView()
        }


    override fun onFinishInflate() {
        super.onFinishInflate()

        if (!isInEditMode) {
            updateView()
        }
    }

    private fun updateView() {

        if (recipientData.isNotEmpty()) {
            try {
                if (recipientData.size > 1) {
                    binding.avatar2.beVisible()
                    recipientData.getOrNull(1).run(binding.avatar2::setRecipient)
                    binding.avatar1Frame.updateLayoutParams<LayoutParams> {
                        matchConstraintPercentWidth = 0.75f
                    }
                } else {
                    binding.avatar2.beGone()
                    binding.avatar1Frame.updateLayoutParams<LayoutParams> {
                        matchConstraintPercentWidth = 1.0f
                    }
                }
                recipientData.getOrNull(0).run(binding.avatar1::setRecipient)

            } catch (e: Exception) {
                e.printStackTrace()
            }
        } else if (recipientsGroup.isNotEmpty()) {
            binding.avatar1Frame.setBackgroundTint(
                when (recipientsGroup.size > 1) {
                    true -> context.resolveThemeColor(android.R.attr.windowBackground)
                    false -> context.getColorCompat(android.R.color.transparent)
                }
            )
            binding.avatar1Frame.updateLayoutParams<LayoutParams> {
                matchConstraintPercentWidth = if (recipientsGroup.size > 1) 0.75f else 1.0f
            }

            recipientsGroup.getOrNull(0).run {
                binding.avatar1.setRecipient(this, title)
            }
        } else {
            try {
                if (recipients.size > 1) {
                    binding.avatar2.beVisible()
                    recipients.getOrNull(1).run(binding.avatar2::setRecipient)
                    binding.avatar1Frame.updateLayoutParams<LayoutParams> {
                        matchConstraintPercentWidth = 0.75f
                    }
                } else {
                    binding.avatar2.beGone()
                    binding.avatar1Frame.updateLayoutParams<LayoutParams> {
                        matchConstraintPercentWidth = 1.0f
                    }
                }
                recipients.getOrNull(0).run(binding.avatar1::setRecipient)

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

    }

}
