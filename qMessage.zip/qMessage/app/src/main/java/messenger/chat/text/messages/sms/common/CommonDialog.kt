package messenger.chat.text.messages.sms.common

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.util.Log
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.WindowManager
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.text.HtmlCompat
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messenger.chat.text.messages.sms.R
import java.text.SimpleDateFormat
import java.util.*

class CommonDialog(val context: Context) {

    val moreClicks: Subject<Unit> = PublishSubject.create()

    fun show(
        activity: Activity,
        title: String,
        message: String,
        positive: String,
        negative: String,
        neutral: String,
        onPositive: () -> Unit = {},
        onNegative: () -> Unit = {},
        onNeutral: () -> Unit = {},
        onDialogClose: () -> Unit = {},
        cancelable: Boolean = true
    ) {
        val alertDialog = AlertDialog.Builder(activity, R.style.FontMyOptionDialogTheme)
        if (title.isNotEmpty()) {
            alertDialog.setTitle(title)
        }
        alertDialog.setMessage(message)
        if (positive.isNotEmpty()) {
            alertDialog.setPositiveButton(positive) { _, _ ->
                onPositive()
            }
        }
        if (negative.isNotEmpty()) {
            alertDialog.setNegativeButton(negative) { _, _ ->
                onNegative()
            }
        }
        if (neutral.isNotEmpty()) {
            alertDialog.setNeutralButton(neutral) { _, _ ->
                onNeutral()
            }
        }
        alertDialog.setOnCancelListener {
            onDialogClose()
        }
        alertDialog.setCancelable(cancelable)
        alertDialog.show().apply {
            if (neutral.isNotEmpty()) {
                getButton(Dialog.BUTTON_NEUTRAL)?.setTextColor(
                    ContextCompat.getColor(
                        activity, R.color.color_app_theme
                    )
                )
                getButton(Dialog.BUTTON_NEUTRAL)?.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18F)
            }
            if (negative.isNotEmpty()) {
                getButton(Dialog.BUTTON_NEGATIVE)?.setTextColor(
                    ContextCompat.getColor(
                        activity, R.color.color_app_theme
                    )
                )
                getButton(Dialog.BUTTON_NEGATIVE)?.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18F)
            }
            if (positive.isNotEmpty()) {
                getButton(Dialog.BUTTON_POSITIVE)?.setTextColor(
                    ContextCompat.getColor(
                        activity, R.color.color_app_theme
                    )
                )
                getButton(Dialog.BUTTON_POSITIVE)?.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18F)
            }
        }
    }

//    fun showChangeLog(activity: Activity, changelog: ChangelogManager.Changelog) {
//        val layout = LayoutInflater.from(activity).inflate(R.layout.changelog_dialog, null)
//        val adapter = ChangelogAdapter(activity)
//        val dialog = AlertDialog.Builder(activity)
//            .setCancelable(true)
//            .setView(layout)
//            .create()
//
//        layout.version.text =
//            activity.getString(R.string.changelog_version, BuildConfig.VERSION_NAME)
//        layout.changelog.adapter = adapter
//        layout.more.setOnClickListener {
//            dialog.dismiss()
//            moreClicks.onNext(Unit)
//        }
//        layout.dismiss.setOnClickListener { dialog.dismiss() }
//        adapter.setChangelog(changelog)
//        dialog.show()
//    }

    fun showNew(
        activity: Activity,
        icon: Int,
        title: String,
        message: String,
        positive: String,
        negative: String,
        cancelable: Boolean = true
    ) {
        val alertDialog = AlertDialog.Builder(activity, R.style.FontMyOptionDialogTheme)

        val dialog = alertDialog.create()
        alertDialog.setIcon(icon)
        alertDialog.setTitle(title)
        alertDialog.setMessage(message)
        alertDialog.setPositiveButton(positive) { _, _ ->
            dialog.dismiss()
        }
        alertDialog.setNegativeButton(negative) { _, _ ->

        }
        alertDialog.setCancelable(cancelable)
        alertDialog.show().apply {
            if (negative.isNotEmpty()) {
                getButton(Dialog.BUTTON_NEGATIVE)?.setTextColor(
                    ContextCompat.getColor(
                        activity, R.color.color_app_theme
                    )
                )
                getButton(Dialog.BUTTON_NEGATIVE)?.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18F)
            }
            if (positive.isNotEmpty()) {
                getButton(Dialog.BUTTON_POSITIVE)?.setTextColor(
                    ContextCompat.getColor(
                        activity, R.color.color_app_theme
                    )
                )
                getButton(Dialog.BUTTON_POSITIVE)?.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18F)
            }
        }
    }

    /**
     * This method is used to show the video ad to the user, so that after watching ad user can use the pro feature.
     * */
//    fun showPremiumDownloadDialog(
//        activity: Activity,
//        eventName: String,
//        paramValue: String,
//        dialogAdFinishedCallback: () -> Unit,
//        dialogAccessProEnabledOrNot: () -> Unit
//    ) {
////        val jsonArray =
////            JSONArray(MessagesApplication.remoteConfig.getString(UtilsStaticData.premium_feature_dialog_data))
//
//        val showDialogAccessPro =
//            jsonArray.getJSONObject(0).getBoolean("show_dialog_access_pro")
//        val textUnlock = jsonArray.getJSONObject(1).getString("text_unlock")
//        val textWatchVideo = jsonArray.getJSONObject(2).getString("text_watch_video")
//        val buttonPositionChange =
//            jsonArray.getJSONObject(3).getBoolean("button_position_change")
//        val dialogTitle = jsonArray.getJSONObject(4).getString("dialog_title")
//        val dialogDesc = jsonArray.getJSONObject(5).getString("pro_dialog_description")
//        if (showDialogAccessPro) {
//            AppUtils.logAdapterMessages(
//                EventKeys.pro_dialog,
//                EventKeys.show,
//                paramValue + EventKeys._pro
//            )
//            var premiumDialog: AlertDialog? = null
//            val builder = AlertDialog.Builder(activity)
//            val binding: DialogAccessProFeatureAdsBinding =
//                DialogAccessProFeatureAdsBinding.inflate(LayoutInflater.from(activity))
//            builder.setView(binding.root)
//
//            with(binding) {
//                Log.e("MSG", "showPremiumDownloadDialog: ------${buttonPositionChange}")
//                tvProDialogTitle.text = dialogTitle
//                tvProDialogDesc.text = dialogDesc
//
//                if (buttonPositionChange) {
//                    btnUnlockAll.text = textWatchVideo.trim()
//                    btnUnlockAll.setBackgroundResource(R.drawable.round_button)
//                    btnUnlockAll.setBackgroundTint(
//                        ContextCompat.getColor(
//                            activity,
//                            R.color.color_app_theme
//                        )
//                    )
//                    btnUnlockAll.setCompoundDrawablesWithIntrinsicBounds(
//                        ContextCompat.getDrawable(
//                            activity,
//                            R.drawable.ic_watch_video
//                        ), null, null, null
//                    )
//
//
//                    btnWatchAd.text = textUnlock.trim()
//                    btnWatchAd.setBackgroundResource(R.drawable.round_button)
//                    btnWatchAd.setBackgroundTint(
//                        ContextCompat.getColor(
//                            activity,
//                            R.color.btn_dialog_unlock_all
//                        )
//                    )
//                    btnWatchAd.setCompoundDrawablesWithIntrinsicBounds(
//                        ContextCompat.getDrawable(
//                            activity,
//                            R.drawable.ic_dialog_vip_crown
//                        ), null, null, null
//                    )
//
//                } else {
//                    btnUnlockAll.text = textUnlock.trim()
//                    btnUnlockAll.setBackgroundResource(R.drawable.round_button)
//                    btnUnlockAll.setBackgroundTint(
//                        ContextCompat.getColor(
//                            activity,
//                            R.color.btn_dialog_unlock_all
//                        )
//                    )
//                    btnUnlockAll.setCompoundDrawablesWithIntrinsicBounds(
//                        ContextCompat.getDrawable(
//                            activity,
//                            R.drawable.ic_dialog_vip_crown
//                        ), null, null, null
//                    )
//
//                    btnWatchAd.text = textWatchVideo.trim()
//                    btnWatchAd.setBackgroundResource(R.drawable.round_button)
//                    btnWatchAd.setBackgroundTint(
//                        ContextCompat.getColor(
//                            activity,
//                            R.color.color_app_theme
//                        )
//                    )
//                    btnWatchAd.setCompoundDrawablesWithIntrinsicBounds(
//                        ContextCompat.getDrawable(
//                            activity,
//                            R.drawable.ic_watch_video
//                        ), null, null, null
//                    )
//
//
//                }
//
//                btnUnlockAll.setOnClickListener {
//                    when (btnUnlockAll.text) {
//                        textUnlock -> {
//                            AppUtils.logAdapterMessages(
//                                EventKeys.pro_dialog,
//                                EventKeys.click,
//                                paramValue + EventKeys._pro
//                            )
//                            activity.launchSubscription()
//                            if (premiumDialog != null && !activity.isFinishing && premiumDialog!!.isShowing) {
//                                premiumDialog!!.dismiss()
//                            }
//                        }
//                        textWatchVideo -> {
//                            AppUtils.logAdapterMessages(
//                                EventKeys.pro_dialog,
//                                EventKeys.click,
//                                paramValue + EventKeys._watch_video
//                            )
//                            if (activity.isOnline) {
//                                dialogAdFinishedCallback()
//                                PreferenceManager.saveData(
//                                    activity,
//                                    PreferenceKeys.OPEN_FROM_REWARD_AD,
//                                    true
//                                )
//                            } else {
//                                activity.toastMsg(activity.resources.getString(R.string.no_internet))
//                            }
//                            if (premiumDialog != null && !activity.isFinishing) {
//                                premiumDialog!!.dismiss()
//                            }
//                        }
//                    }
//
//                }
//
//                btnWatchAd.setOnClickListener {
//                        when (btnWatchAd.text) {
//                            textUnlock -> {
//                                AppUtils.logAdapterMessages(
//                                    EventKeys.pro_dialog,
//                                    EventKeys.click,
//                                    paramValue + EventKeys._pro
//                                )
//
//                                activity.launchSubscription()
//                                if (premiumDialog != null && !activity.isFinishing) {
//                                    premiumDialog!!.dismiss()
//                                }
//                            }
//                            textWatchVideo -> {
//                                AppUtils.logAdapterMessages(
//                                    EventKeys.pro_dialog,
//                                    EventKeys.click,
//                                    paramValue + EventKeys._watch_video
//                                )
//                                if (activity.isOnline) {
//                                    dialogAdFinishedCallback()
//                                    PreferenceManager.saveData(
//                                        activity,
//                                        PreferenceKeys.OPEN_FROM_REWARD_AD,
//                                        true
//                                    )
//                                } else {
//                                    activity.toastMsg(activity.resources.getString(R.string.no_internet))
//                                }
//                                if (premiumDialog != null && !activity.isFinishing) {
//                                    premiumDialog!!.dismiss()
//                                }
//                            }
//                        }
//                }
//
//            }
//            premiumDialog = builder.create()
//            if (!activity.isFinishing && !premiumDialog.isShowing) {
//                premiumDialog.show()
//                premiumDialog.setCanceledOnTouchOutside(true)
//                premiumDialog.window!!.setBackgroundDrawable(
//                    ColorDrawable(
//                        Color.TRANSPARENT
//                    )
//                )
//            }
//        } else {
//            AppUtils.logAdapterMessages(
//                eventName,
//                EventKeys.click,
//                paramValue
//            )
//            PreferenceManager.saveData(activity, PreferenceKeys.OPEN_FROM_REWARD_AD, false)
//            dialogAccessProEnabledOrNot.invoke()
//        }
//    }

//    fun getProFeaturesDirectAccess(
//        activity: Activity,
//        dialogAdFinishedCallback: (adType: String) -> Unit
//    ) {
//
////        val jsonArrayNew =
////            JSONArray(MessagesApplication.remoteConfig.getString(UtilsStaticData.premium_feature_with_ads))
////        val accessFeatureUsingAds =
////            jsonArrayNew.getJSONObject(0).getBoolean("access_feature_using_ads")
////        val accessFeatureAdType =
////            jsonArrayNew.getJSONObject(1).getString("access_ad_type").lowercase()
//
////        if (accessFeatureUsingAds) {
////            if (accessFeatureAdType.isNotEmpty()) {
////                when (accessFeatureAdType) {
////                    UtilsStaticData.admob_reward.lowercase() -> {
////                        if (activity.isOnline) {
////                            dialogAdFinishedCallback(accessFeatureAdType)
////                            PreferenceManager.saveData(
////                                activity,
////                                PreferenceKeys.OPEN_FROM_REWARD_AD,
////                                true
////                            )
////                        } else {
////                            activity.launchSubscription()
////                        }
////                    }
////                    UtilsStaticData.admob_int.lowercase(Locale.ROOT) -> {
////                        if (activity.isOnline) {
////                            dialogAdFinishedCallback(accessFeatureAdType)
////                        } else {
////                            activity.launchSubscription()
////                        }
////                    }
////                }
////            } else {
////                activity.launchSubscription()
////            }
////        } else {
////            activity.launchSubscription()
////        }
//    }
}