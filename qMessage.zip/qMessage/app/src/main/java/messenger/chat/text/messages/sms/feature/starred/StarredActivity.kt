package messenger.chat.text.messages.sms.feature.starred

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider
import dagger.android.AndroidInjection
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.common.Navigator
import messenger.chat.text.messages.sms.common.base.QkThemedActivity
import messenger.chat.text.messages.sms.common.util.extensions.viewBinding
import messenger.chat.text.messages.sms.commons.extensions.baseConfig
import messenger.chat.text.messages.sms.commons.extensions.beGone
import messenger.chat.text.messages.sms.commons.extensions.beVisible
import messenger.chat.text.messages.sms.commons.extensions.updateTextColors
import messenger.chat.text.messages.sms.databinding.StarredActivityBinding
import javax.inject.Inject


class StarredActivity : QkThemedActivity(), StarredMessagesView {

    @Inject
    lateinit var messageAdapter: StarredMessageAdapter

    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory
    override val conversationClicks by lazy { messageAdapter.clicks }

    @Inject
    lateinit var navigator: Navigator


    private val viewModel by lazy {
        ViewModelProvider(
            this,
            viewModelFactory
        )[StarredViewModel::class.java]
    }

    private val binding by viewBinding(StarredActivityBinding::inflate)

    //    lateinit var binding:StarredActivityBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
//        binding=StarredActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        setTitle(R.string.starred)
        showBackButton(true)
        viewModel.bindView(this)
        messageAdapter.emptyView = binding.empty
        binding.messages.adapter = messageAdapter

        setUpTheme()

        binding.ivBack.setOnClickListener {
            onBackPressed()
        }

    }

    private fun setUpTheme() {

        Log.e("MainActivity", "setUpTheme.useImageResource:${baseConfig.useImageResource}")
        Log.e("MainActivity", "setUpTheme.storedImageResource:${baseConfig.storedImageResource}")

        updateTextColors(binding.contentView)
        binding.toolbarTitle.setTextColor(baseConfig.primaryColor)

        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
            binding.contentView.background = ColorDrawable(resources.getColor(R.color.bottom_tabs_black_backgroundnew))
            arrayListOf(binding.ivBack).forEach {
                val colorStateList = ColorStateList.valueOf(Color.WHITE)
                it.imageTintList = colorStateList
            }
        } else {
            binding.contentView.background = ColorDrawable(baseConfig.backgroundColor)
            arrayListOf(binding.ivBack).forEach {
//                val whiteColor = ContextCompat.getColor(this, R.color.black)
                val colorStateList = ColorStateList.valueOf(Color.BLACK)
                it.imageTintList = colorStateList
            }
        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                Log.i("onCreate", "onCreateitemselse11111: ")
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.contentView.background = drawable
                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
            }
        } else {
            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
            toolbar.setBackgroundColor(baseConfig.backgroundColor)
        }

    }

    override fun requestDefaultSms() {
        navigator.showDefaultSmsDialog(this@StarredActivity)
    }

    override fun render(state: StarredMessagesState) {
        if (state.data?.isNotEmpty()!!) {
            binding.empty.beGone()
            messageAdapter.updateData(state.data)
        } else {
            binding.empty.beVisible()
        }
    }


    override fun onDestroy() {
        super.onDestroy()
    }

    override fun onPause() {
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
    }

    override fun onBackPressed() {
        finish()
    }
}