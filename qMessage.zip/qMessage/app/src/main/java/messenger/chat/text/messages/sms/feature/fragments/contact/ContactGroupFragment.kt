package messenger.chat.text.messages.sms.feature.fragments.contact

import android.content.res.ColorStateList
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import messenger.chat.text.messages.sms.common.util.extensions.scrapViews
import messenger.chat.text.messages.sms.commons.adapters.ContactGroupItemAdapter
import messenger.chat.text.messages.sms.commons.extensions.baseConfig
import messenger.chat.text.messages.sms.commons.extensions.beVisibleIf
import messenger.chat.text.messages.sms.databinding.FragmentGroupContactBinding
import messenger.chat.text.messages.sms.feature.fragments.contact.component.GroupUpdateDialog
import messenger.chat.text.messages.sms.feature.main.MainActivity
import messenger.chat.text.messages.sms.model.MessageEvent
import messenger.chat.text.messages.sms.model.REFRESH_CONTACT_GROUP
import messenger.chat.text.messages.sms.model.THEME_CHANGED
import messenger.chat.text.messages.sms.model.UPDATE_ALL_CONTACT
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode


class ContactGroupFragment : Fragment() {

    lateinit var binding: FragmentGroupContactBinding
    var contactsAdapter = ContactGroupItemAdapter()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentGroupContactBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (!EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().register(this)

        binding.contacts.adapter = contactsAdapter
        val list = (requireActivity() as? MainActivity)?.contactGroups ?: ArrayList()
        contactsAdapter.data = list
        binding.groupsListEmptyLabel.beVisibleIf(list.isEmpty())
        binding.addGroupButton.floatingButton.backgroundTintList = activity?.baseConfig?.let {
            ColorStateList.valueOf(
                it.primaryColor
            )
        }
        binding.addGroupButton.floatingButton.setOnClickListener { _ ->
            GroupUpdateDialog(requireActivity(), null, list) {
                EventBus.getDefault().post(MessageEvent(REFRESH_CONTACT_GROUP))
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        if (EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().unregister(this)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        when (event.type) {
            UPDATE_ALL_CONTACT -> {
                if (::binding.isInitialized) {
                    val list = (requireActivity() as? MainActivity)?.contactGroups ?: ArrayList()
                    contactsAdapter.data = list
                    binding.groupsListEmptyLabel.beVisibleIf(list.isEmpty())
                }
            }

            THEME_CHANGED -> {
                if (::binding.isInitialized) {
                    binding.contacts.scrapViews()
                }
            }
        }

    }
}
