package messenger.chat.text.messages.sms.feature.personalize

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.widget.SeekBar
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.GridLayoutManager
import dagger.android.AndroidInjection
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.common.base.QkThemedActivity
import messenger.chat.text.messages.sms.common.util.extensions.viewBinding
import messenger.chat.text.messages.sms.commons.adapters.ColorAdapter
import messenger.chat.text.messages.sms.commons.adapters.FontListAdapter
import messenger.chat.text.messages.sms.commons.extensions.applyColorFilter
import messenger.chat.text.messages.sms.commons.extensions.baseConfig
import messenger.chat.text.messages.sms.commons.extensions.getBottomNavigationBackgroundColor
import messenger.chat.text.messages.sms.commons.extensions.getBottomNavigationBackgroundColorFont
import messenger.chat.text.messages.sms.commons.extensions.getProperPrimaryColor
import messenger.chat.text.messages.sms.commons.extensions.toast
import messenger.chat.text.messages.sms.commons.extensions.updateTextColors
import messenger.chat.text.messages.sms.databinding.ActivityThemeBinding
import messenger.chat.text.messages.sms.model.MessageEvent
import messenger.chat.text.messages.sms.model.THEME_CHANGED
import org.greenrobot.eventbus.EventBus
import java.io.IOException

class ThemeActivity : QkThemedActivity() {


    private val binding by viewBinding(ActivityThemeBinding::inflate)
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        showBackButton(true)
        setTitle(R.string.themes)

        setUI()
        setUpTheme()
        setUpListener()
    }

    private fun setUpTheme() {

        Log.e("MainActivity", "setUpTheme.useImageResource:${baseConfig.useImageResource}")
        Log.e("MainActivity", "setUpTheme.storedImageResource:${baseConfig.storedImageResource}")

        updateTextColors(binding.contentView)
        binding.toolbarTitle.setTextColor(baseConfig.primaryColor)

        binding.apply {
            arrayOf(
                classicLabel,
                seasonLabel,
            ).forEach {
                it.setTextColor(getProperPrimaryColor())
            }

            arrayOf(
                binding.settingsColorCustomizationHolder,
                binding.settingsImageCustomizationHolder
            ).forEach {
                it.background.applyColorFilter(getBottomNavigationBackgroundColor())
            }
        }

        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
            binding.contentView.background = ColorDrawable(resources.getColor(R.color.bottom_tabs_black_backgroundnew))
            arrayListOf(binding.ivBack).forEach {
                val colorStateList = ColorStateList.valueOf(Color.WHITE)
                it.imageTintList = colorStateList
            }
        } else {
            binding.contentView.background = ColorDrawable(baseConfig.backgroundColor)
            arrayListOf(binding.ivBack).forEach {
//                val whiteColor = ContextCompat.getColor(this, R.color.black)
                val colorStateList = ColorStateList.valueOf(Color.BLACK)
                it.imageTintList = colorStateList
            }
        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                Log.i("onCreate", "onCreateitemselse11111: ")
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.contentView.background = drawable
                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
            }
        } else {
            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
            toolbar.setBackgroundColor(baseConfig.backgroundColor)
        }

    }

    private fun setUI() {

        val colorList = listOf(
            Color.parseColor("#3774FF"),
            Color.parseColor("#00A11F"),
            Color.parseColor("#FF6E96"),
            Color.parseColor("#FF9C00"),
            Color.parseColor("#FE7D68"),
            Color.parseColor("#2F3F83"),
            Color.parseColor("#0183C9"),
            Color.parseColor("#000000"),
        )
        val itemList = listOf(
            "Blue",
            "Green",
            "Pink",
            "Yellow",
            "Oral",
            "Navy Blue",
            "Cerulean\n" +
                    "Blue",
            "Black & Blue",
        )

        binding.rvClassic.layoutManager = GridLayoutManager(this, 4)
        val myAdapter =
            ColorAdapter(itemList, colorList, this, object : ColorAdapter.OnItemClickListener {
                override fun onItemClick(position: Int, color: Int, name: String) {
                    val intent = Intent(this@ThemeActivity, ThemePreviewActivity::class.java)
                    intent.putExtra("color", color)
                    intent.putExtra("position", position)
                    intent.putExtra("c_name", name)
                    startActivity(intent)
//                    finish()
                }
            })

        binding.rvClassic.adapter = myAdapter
    }

    private fun setUpListener() {

        binding.ivBack.setOnClickListener {
            onBackPressed()
        }

        binding.llspring.setOnClickListener {
            var intent = Intent(this, ThemeImagePreviewActivity::class.java);
//            intent.putExtra("imagePath", "spring")
            intent.putExtra("imageResource", R.drawable.spring_bg)
            intent.putExtra("c_name", "Spring")
            startActivity(intent);
//            finish()
        }

        binding.llautumn.setOnClickListener {
            var intent = Intent(this, ThemeImagePreviewActivity::class.java);
//            intent.putExtra("imagePath", "autumn")
            intent.putExtra("imageResource", R.drawable.autumn_bg)
            intent.putExtra("c_name", "Autumn")
            startActivity(intent);
//            finish()
        }

        binding.llsummer.setOnClickListener {
            var intent = Intent(this, ThemeImagePreviewActivity::class.java);
//            intent.putExtra("imagePath", "summer")
            intent.putExtra("imageResource", R.drawable.summer_bg)
            intent.putExtra("c_name", "Summer")
            startActivity(intent);
//            finish()
        }
        binding.llwinter.setOnClickListener {
            var intent = Intent(this, ThemeImagePreviewActivity::class.java);
//            intent.putExtra("imagePath", "winter")
            intent.putExtra("imageResource", R.drawable.winter_bg)
            intent.putExtra("c_name", "Winter")
            startActivity(intent);
//            finish()
        }

    }

}