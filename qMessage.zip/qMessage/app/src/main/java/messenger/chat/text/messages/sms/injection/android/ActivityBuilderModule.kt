package messenger.chat.text.messages.sms.injection.android

import messenger.chat.text.messages.sms.feature.backup.BackupActivity
import messenger.chat.text.messages.sms.feature.blocking.BlockingActivity
import messenger.chat.text.messages.sms.feature.compose.ComposeActivity
import messenger.chat.text.messages.sms.feature.compose.ComposeActivityModule
import messenger.chat.text.messages.sms.feature.contacts.ContactsActivity
import messenger.chat.text.messages.sms.feature.contacts.ContactsActivityModule
import messenger.chat.text.messages.sms.feature.conversationinfo.ConversationInfoActivity
import messenger.chat.text.messages.sms.feature.gallery.GalleryActivity
import messenger.chat.text.messages.sms.feature.gallery.GalleryActivityModule
import messenger.chat.text.messages.sms.feature.main.MainActivity
import messenger.chat.text.messages.sms.feature.main.MainActivityModule
import messenger.chat.text.messages.sms.feature.notificationprefs.NotificationPrefsActivity
import messenger.chat.text.messages.sms.feature.notificationprefs.NotificationPrefsActivityModule
import messenger.chat.text.messages.sms.feature.qkreply.QkReplyActivity
import messenger.chat.text.messages.sms.feature.qkreply.QkReplyActivityModule
import messenger.chat.text.messages.sms.feature.scheduled.ScheduledActivity
import messenger.chat.text.messages.sms.feature.scheduled.ScheduledActivityModule
import messenger.chat.text.messages.sms.feature.settings.SettingsActivity
import messenger.chat.text.messages.sms.injection.scope.ActivityScope
import dagger.Module
import dagger.android.ContributesAndroidInjector
import messenger.chat.text.messages.sms.appmanager.FindAppActivity
import messenger.chat.text.messages.sms.appmanager.ManageAppActivity
import messenger.chat.text.messages.sms.feature.contacts.GroupsActivity
import messenger.chat.text.messages.sms.feature.main.ArchiveActivity
import messenger.chat.text.messages.sms.feature.main.PermissionActivity
import messenger.chat.text.messages.sms.feature.main.SplashActivity
import messenger.chat.text.messages.sms.feature.personalize.BubbleActivity
import messenger.chat.text.messages.sms.feature.personalize.FontActivity
import messenger.chat.text.messages.sms.feature.personalize.RingtonesListActivity
import messenger.chat.text.messages.sms.feature.personalize.ThemeActivity
import messenger.chat.text.messages.sms.feature.personalize.ThemeImagePreviewActivity
import messenger.chat.text.messages.sms.feature.personalize.ThemePreviewActivity
import messenger.chat.text.messages.sms.feature.settings.AdvanceSettingsActivity
import messenger.chat.text.messages.sms.feature.settings.NewSettingsActivity
import messenger.chat.text.messages.sms.feature.settings.SwipeActionsActivity
import messenger.chat.text.messages.sms.feature.starred.StarredActivity
import messenger.chat.text.messages.sms.feature.starred.StarredActivityModule

@Module
abstract class ActivityBuilderModule {

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindMainActivity(): MainActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindArchiveActivity(): ArchiveActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindBackupActivity(): BackupActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [StarredActivityModule::class])
    abstract fun bindStarredActivity(): StarredActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindFontActivity(): FontActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindThemeActivity(): ThemeActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindBubbleActivity(): BubbleActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindRingtonesListActivity(): RingtonesListActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindThemePreviewActivity(): ThemePreviewActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindThemeImagePreviewActivity(): ThemeImagePreviewActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindFindAppActivity(): FindAppActivity
    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindManageAppActivity(): ManageAppActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [ComposeActivityModule::class])
    abstract fun bindComposeActivity(): ComposeActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [ContactsActivityModule::class])
    abstract fun bindContactsActivity(): ContactsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindConversationInfoActivity(): ConversationInfoActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [GalleryActivityModule::class])
    abstract fun bindGalleryActivity(): GalleryActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [NotificationPrefsActivityModule::class])
    abstract fun bindNotificationPrefsActivity(): NotificationPrefsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [QkReplyActivityModule::class])
    abstract fun bindQkReplyActivity(): QkReplyActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [ScheduledActivityModule::class])
    abstract fun bindScheduledActivity(): ScheduledActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindSettingsActivity(): SettingsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindNewSettingsActivity(): NewSettingsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindAdvanceSettingsActivity(): AdvanceSettingsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindSwipeActionsActivity(): SwipeActionsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindSplashActivity(): SplashActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindPermissionActivity(): PermissionActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindBlockingActivity(): BlockingActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindGroupsActivity(): GroupsActivity

}
