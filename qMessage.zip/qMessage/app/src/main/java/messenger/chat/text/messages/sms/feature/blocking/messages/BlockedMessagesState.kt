package messenger.chat.text.messages.sms.feature.blocking.messages

import messenger.chat.text.messages.sms.model.Conversation
import io.realm.RealmResults

data class BlockedMessagesState(
    val data: RealmResults<Conversation>? = null,
    val selected: Int = 0
)
