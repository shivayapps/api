package messenger.chat.text.messages.sms.appmanager

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import com.google.gson.Gson
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.commons.helpers.is_private_check
import messenger.chat.text.messages.sms.feature.compose.ComposeActivity
import messenger.chat.text.messages.sms.feature.main.SplashActivity


class Foreground : Service() {
    val notification_channel = "Insta"
    val service_id = 404
    lateinit var notification: Notification
    lateinit var nortificationManager: NotificationManager
    val handler: Handler = Handler(Looper.getMainLooper())
    var count = 0
    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onCreate() {
        super.onCreate()
        createchannel()
        createnotification()
    }

    @SuppressLint("ForegroundServiceType")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val toastrunnable = object : Runnable {
            override fun run() {
//                Toast.makeText(this@Forground, "$count", Toast.LENGTH_SHORT).show()
                count++
                handler.postDelayed(this, 1000)
            }

        }
        handler.postDelayed(toastrunnable, 1000)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                service_id, notification
            )
        } else
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    service_id, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MANIFEST
                )
            } else {
                startForeground(service_id, notification)
            }
        return START_STICKY
    }

    fun createchannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                notification_channel,
                "Forground",
                NotificationManager.IMPORTANCE_HIGH
            )
            nortificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nortificationManager.createNotificationChannel(channel)

        }
    }

    @SuppressLint("RemoteViewLayout")
    fun createnotification() {
        val collapsedView = RemoteViews(packageName, R.layout.noti_collapse)
        val expandedView = RemoteViews(packageName, R.layout.noti_expand)

//        collapsedView.setTextViewText(R.id.textViewCollapse, "This is Collapse!")

//        expandedView.setImageViewResource(R.id.image_view_expanded, R.drawable.ic_launcher_background)
//        expandedView.setOnClickPendingIntent(R.id.image_view_expanded, clickPendingIntent)

        collapsedView.setOnClickPendingIntent(R.id.btn1, getintent("button1"))
        collapsedView.setOnClickPendingIntent(R.id.btn2, getintent("button2"))
        collapsedView.setOnClickPendingIntent(R.id.btn3, getintent("button3"))
        collapsedView.setOnClickPendingIntent(R.id.btn4, getintent("button4"))

        expandedView.setOnClickPendingIntent(R.id.btn1, getintent("button1"))
        expandedView.setOnClickPendingIntent(R.id.btn2, getintent("button2"))
        expandedView.setOnClickPendingIntent(R.id.btn3, getintent("button3"))
        expandedView.setOnClickPendingIntent(R.id.btn4, getintent("button4"))

        val build = NotificationCompat.Builder(this, notification_channel)
            .setSmallIcon(R.drawable.ic_notification)
            .setColorized(true)
            .setColor(Color.parseColor("#3774FF"))
            .setCustomContentView(collapsedView)
            .setCustomBigContentView(expandedView)
            .setStyle(NotificationCompat.DecoratedCustomViewStyle())

        notification = build.build()


//        val remoteview = RemoteViews(packageName, R.layout.noti)
//        remoteview.setOnClickPendingIntent(R.id.btn1, getintent("button1"))
//        remoteview.setOnClickPendingIntent(R.id.btn2, getintent("button2"))
//        remoteview.setOnClickPendingIntent(R.id.btn3, getintent("button3"))
//        val build = NotificationCompat.Builder(this, notification_channel)
//            .setSmallIcon(R.drawable.ic_launcher)
//            .setContent(remoteview)
//        notification = build.build()


    }

    fun getintent(msg: String): PendingIntent {
//        val intent = Intent(this, NotificationClickReceiver::class.java).apply {
//            action = "BUUTTENACCTION"
//            putExtra("msg", "$msg")
//        }

        var requstcount = 0
        val intent = when (msg) {
            "button1" -> {
                requstcount = 101
                Intent(this, SplashActivity::class.java)
            }

            "button2" -> {
                requstcount = 102
//                getThreadActivity("9601685210","MG",this)
                Intent(this, ComposeActivity::class.java)
            }

            "button3" -> {
                requstcount = 103
                Intent(this, FindAppActivity::class.java)
            }

//            "button4" -> {
//                requstcount = 104
//                Intent(this, ThemeActivity::class.java)
//            }

            else -> {
                requstcount = 105
                Intent(this, SplashActivity::class.java)
            }
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)

//        val intent = Intent(context, AppInstalledActivity::class.java).apply {
//            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
//            putExtra("PACKAGE_NAME", packageName)
//        }
        val pendingIntent: PendingIntent =
            PendingIntent.getActivity(this, requstcount, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return pendingIntent

//        return PendingIntent.getBroadcast(
//            this,
//            requstcount,
//            intent,
//            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
//        )
    }


}
