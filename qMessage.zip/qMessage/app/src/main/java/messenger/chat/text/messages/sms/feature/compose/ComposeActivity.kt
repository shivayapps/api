package messenger.chat.text.messages.sms.feature.compose

import android.Manifest
import android.animation.LayoutTransition
import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ContentValues
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PersistableBundle
import android.provider.ContactsContract
import android.provider.MediaStore
import android.text.format.DateFormat
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import com.google.android.flexbox.FlexboxLayoutManager
import com.google.android.material.snackbar.Snackbar
import com.jakewharton.rxbinding2.view.clicks
import com.jakewharton.rxbinding2.widget.textChanges
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import dagger.android.AndroidInjection
import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.common.Navigator
import messenger.chat.text.messages.sms.common.base.QkThemedActivity
import messenger.chat.text.messages.sms.common.util.DateFormatter
import messenger.chat.text.messages.sms.common.util.extensions.autoScrollToStart
import messenger.chat.text.messages.sms.common.util.extensions.hideKeyboard
import messenger.chat.text.messages.sms.common.util.extensions.resolveThemeColor
import messenger.chat.text.messages.sms.common.util.extensions.scrapViews
import messenger.chat.text.messages.sms.common.util.extensions.setBackgroundTint
import messenger.chat.text.messages.sms.common.util.extensions.setTint
import messenger.chat.text.messages.sms.common.util.extensions.setVisible
import messenger.chat.text.messages.sms.common.util.extensions.showKeyboard
import messenger.chat.text.messages.sms.common.util.extensions.viewBinding
import messenger.chat.text.messages.sms.commons.extensions.addAlpha
import messenger.chat.text.messages.sms.commons.extensions.baseConfig
import messenger.chat.text.messages.sms.commons.extensions.setItemColors
import messenger.chat.text.messages.sms.commons.extensions.updateTextColors
import messenger.chat.text.messages.sms.databinding.ComposeActivityBinding
import messenger.chat.text.messages.sms.feature.compose.editing.ChipsAdapter
import messenger.chat.text.messages.sms.feature.contacts.ContactsActivity
import messenger.chat.text.messages.sms.model.Attachment
import messenger.chat.text.messages.sms.model.Recipient
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import javax.inject.Inject

class ComposeActivity : QkThemedActivity(), ComposeView {

    companion object {
        private const val SelectContactRequestCode = 0
        private const val TakePhotoRequestCode = 1
        private const val AttachPhotoRequestCode = 2
        private const val AttachContactRequestCode = 3

        private const val CameraDestinationKey = "camera_destination"
    }

    @Inject
    lateinit var attachmentAdapter: AttachmentAdapter

    @Inject
    lateinit var chipsAdapter: ChipsAdapter

    @Inject
    lateinit var dateFormatter: DateFormatter

    @Inject
    lateinit var messageAdapter: MessagesAdapter

    @Inject
    lateinit var navigator: Navigator

    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory

    override val activityVisibleIntent: Subject<Boolean> = PublishSubject.create()
    override val chipsSelectedIntent: Subject<HashMap<String, String?>> = PublishSubject.create()
    override val chipDeletedIntent: Subject<Recipient> by lazy { chipsAdapter.chipDeleted }
    override val menuReadyIntent: Observable<Unit> = menu.map { Unit }
    override val optionsItemIntent: Subject<Int> = PublishSubject.create()
    override val sendAsGroupIntent by lazy { binding.sendAsGroupBackground.clicks() }
    override val messageClickIntent: Subject<Long> by lazy { messageAdapter.clicks }
    override val messagePartClickIntent: Subject<Long> by lazy { messageAdapter.partClicks }
    override val messagesSelectedIntent by lazy { messageAdapter.selectionChanges }
    override val cancelSendingIntent: Subject<Long> by lazy { messageAdapter.cancelSending }
    override val attachmentDeletedIntent: Subject<Attachment> by lazy { attachmentAdapter.attachmentDeleted }
    override val textChangedIntent by lazy { binding.message.textChanges() }
    override val removeStarMessageSubject: Subject<Long> by lazy { messageAdapter.removeStarMessageSubject }
    override fun addOrRemoveStarred(): Observable<Long> = removeStarMessageSubject
    override fun addStarred(): Observable<Long> = starMessageSubject
    override val starMessageSubject: Subject<Long> = PublishSubject.create()
    override val attachIntent by lazy { Observable.merge(binding.attach.clicks(), binding.attachingBackground.clicks()) }
    override val cameraIntent by lazy { Observable.merge(binding.camera.clicks(), binding.cameraLabel.clicks()) }
    override val galleryIntent by lazy { Observable.merge(binding.gallery.clicks(), binding.galleryLabel.clicks()) }
    override val scheduleIntent by lazy { Observable.merge(binding.schedule.clicks(), binding.scheduleLabel.clicks()) }
    override val attachContactIntent by lazy { Observable.merge(binding.contact.clicks(), binding.contactLabel.clicks()) }
    override val attachmentSelectedIntent: Subject<Uri> = PublishSubject.create()
    override val contactSelectedIntent: Subject<Uri> = PublishSubject.create()
    override val inputContentIntent by lazy { binding.message.inputContentSelected }
    override val scheduleSelectedIntent: Subject<Long> = PublishSubject.create()
    override val changeSimIntent by lazy { binding.sim.clicks() }
    override val scheduleCancelIntent by lazy { binding.scheduledCancel.clicks() }
    override val sendIntent by lazy { binding.send.clicks() }
    override val backPressedIntent: Subject<Unit> = PublishSubject.create()

    private val binding by viewBinding(ComposeActivityBinding::inflate)
    private val viewModel by lazy { ViewModelProviders.of(this, viewModelFactory)[ComposeViewModel::class.java] }

    private var cameraDestination: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        if (intent.hasExtra(ContactsActivity.ChipsKey)) {
            viewModel.shouldShowContacts = false
        }
        viewModel.bindView(this)
        setSupportActionBar(binding.toolbar)
//        showBackButton(true)
        binding.contentView.layoutTransition = LayoutTransition().apply {
            disableTransitionType(LayoutTransition.CHANGING)
        }

        chipsAdapter.view = binding.chips

//        binding.chips.itemAnimator = null
        binding.chips.layoutManager = FlexboxLayoutManager(this)

        messageAdapter.autoScrollToStart(binding.messageList)
        messageAdapter.emptyView = binding.messagesEmpty

        binding.messageList.setHasFixedSize(true)
        binding.messageList.adapter = messageAdapter

        binding.attachments.adapter = attachmentAdapter

        binding.message.supportsInputContent = true

        theme
            .autoDisposable(scope())
            .subscribe { theme ->
                binding.attach.setBackgroundTint(theme.theme)
                binding.attach.setTint(theme.textPrimary)
                binding.loading.setTint(theme.theme)
                messageAdapter.theme = theme
            }

//        theme
//            .doOnNext { binding.loading.setTint(it.theme) }
//            .doOnNext { binding.attach.setBackgroundTint(it.theme) }
//            .doOnNext { binding.attach.setTint(it.textPrimary) }
//            .doOnNext { messageAdapter.theme = it }
//            .autoDisposable(scope())
//            .subscribe()

        window.callback = ComposeWindowCallback(window.callback, this)

        // These theme attributes don't apply themselves on API 21
        if (Build.VERSION.SDK_INT <= 22) {
            binding.messageBackground.setBackgroundTint(resolveThemeColor(R.attr.bubbleColor))
        }
        chipsSelectedIntent.onNext(intent?.getSerializableExtra(ContactsActivity.ChipsKey)
            ?.let { serializable -> serializable as? HashMap<String, String?> }
            ?: hashMapOf())

        setUpTheme()
    }

    private fun setUpTheme() {

        Log.e("MainActivity", "setUpTheme.useImageResource:${baseConfig.useImageResource}")
        Log.e("MainActivity", "setUpTheme.storedImageResource:${baseConfig.storedImageResource}")

        updateTextColors(binding.contentView)

        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
            binding.contentView.background = ColorDrawable(resources.getColor(R.color.bottom_tabs_black_backgroundnew))
//            arrayListOf(binding.ivBack, binding.ivDelete, binding.ivMore, binding.ivArchive, binding.ivRead, binding.ivBlock).forEach {
////                val whiteColor = ContextCompat.getColor(this, R.color.white)
//                val colorStateList = ColorStateList.valueOf(Color.WHITE)
//                it.imageTintList = colorStateList
//            }
        } else {
            binding.contentView.background = ColorDrawable(baseConfig.backgroundColor)
//            arrayListOf(binding.ivBack,binding.ivDelete, binding.ivMore, binding.ivArchive, binding.ivRead, binding.ivBlock).forEach {
////                val whiteColor = ContextCompat.getColor(this, R.color.black)
//                val colorStateList = ColorStateList.valueOf(Color.BLACK)
//                it.imageTintList = colorStateList
//            }
        }

        if (baseConfig.useImageResource == true) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                Log.i("onCreate", "onCreateitemselse11111: ")

//                val bitmapDrawable = BitmapDrawable(resources, baseConfig.storedBitmap)
//                constraintLayout.background = bitmapDrawable
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.contentView.background = drawable

                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))

//                val colorWithAlpha = baseConfig.primaryColor.addAlpha(0.8F)
//                binding.navView.background = ColorDrawable(colorWithAlpha)

                val unselectedColor =
                    ContextCompat.getColor(this, android.R.color.darker_gray) // Unselected color
                val states = arrayOf(
                    intArrayOf(android.R.attr.state_checked), // Selected state
                    intArrayOf(-android.R.attr.state_checked) // Unselected state
                )

                val primaryColor = Color.parseColor("#FFFFFF")
                val colors = intArrayOf(
                    primaryColor, // Color for selected state
                    primaryColor // Color for unselected state
                )

//                val colorStateList = ColorStateList(states, colors)
//                binding.navView.itemIconTintList = colorStateList
//                binding.navView.setItemColors(primaryColor, primaryColor)
//                binding.navView.itemRippleColor = ColorStateList.valueOf(primaryColor.addAlpha(0.08F))
//                binding.navView.itemActiveIndicatorColor = ColorStateList.valueOf(primaryColor.addAlpha(0.12F))
            }
        } else {

            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
//            binding.navView.setBackgroundColor(baseConfig.backgroundColor)
//            lloptionmenu.setBackgroundColor(baseConfig.backgroundColor)
            toolbar.setBackgroundColor(baseConfig.backgroundColor)

            val unselectedColor =
                ContextCompat.getColor(this, android.R.color.darker_gray) // Unselected color
            val states = arrayOf(
                intArrayOf(android.R.attr.state_checked), // Selected state
                intArrayOf(-android.R.attr.state_checked) // Unselected state
            )
            val colors = intArrayOf(
                primaryColor, // Color for selected state
                unselectedColor // Color for unselected state
            )

            if (baseConfig.backgroundColor.equals(Color.BLACK)) {
                val primaryColortext = Color.parseColor("#FFFFFF")
                val colorstext = intArrayOf(
                    primaryColortext, // Color for selected state
                    unselectedColor // Color for unselected state
                )
                val colorStateListtext = ColorStateList(states, colorstext)
//                binding.navView.itemTextColor = colorStateListtext
            } else {
                val primaryColortext = Color.parseColor("#000000")
                val colorstext = intArrayOf(
                    primaryColortext, // Color for selected state
                    unselectedColor // Color for unselected state
                )
                val colorStateListtext = ColorStateList(states, colorstext)
//                binding.navView.itemTextColor = colorStateListtext
            }

//            val colorStateList = ColorStateList(states, colors)
//            binding.navView.itemIconTintList = colorStateList
//            binding.navView.itemRippleColor = ColorStateList.valueOf(primaryColor.addAlpha(0.08F))
//            binding.navView.itemActiveIndicatorColor =
//                ColorStateList.valueOf(primaryColor.addAlpha(0.12F))

        }

    }

    override fun onStart() {
        super.onStart()
        activityVisibleIntent.onNext(true)
    }

    override fun onPause() {
        super.onPause()
        activityVisibleIntent.onNext(false)
    }

    override fun render(state: ComposeState) {
        if (state.hasError) {
            Log.e("render","ComposeActivity:render.hasError:${state.messages?.second}")
//            finish()
//            return
        }

        threadId.onNext(state.threadId)

        binding.toolbarTitle.text = when {
            state.selectedMessages > 0 -> getString(R.string.compose_title_selected, state.selectedMessages)
            state.query.isNotEmpty() -> state.query
            else -> state.conversationtitle
        }

        binding.toolbarSubtitle.setVisible(state.query.isNotEmpty())
        binding.toolbarSubtitle.text = getString(
            R.string.compose_subtitle_results, state.searchSelectionPosition,
            state.searchResults
        )

        binding.toolbarTitle.setVisible(!state.editingMode)
        binding.chips.setVisible(state.editingMode)
        binding.composeBar.setVisible(!state.loading)

        // Don't set the adapters unless needed
        if (state.editingMode && binding.chips.adapter == null) binding.chips.adapter = chipsAdapter

        toolbar.menu.findItem(R.id.star)?.isVisible = !messageAdapter.isStarred && !state.editingMode && state.selectedMessages == 1

        toolbar.menu.findItem(R.id.un_star)?.isVisible = messageAdapter.isStarred && !state.editingMode && state.selectedMessages == 1

        binding.toolbar.menu.findItem(R.id.add)?.isVisible = state.editingMode
        binding.toolbar.menu.findItem(R.id.call)?.isVisible = !state.editingMode && state.selectedMessages == 0
                && state.query.isEmpty()
        binding.toolbar.menu.findItem(R.id.info)?.isVisible = !state.editingMode && state.selectedMessages == 0
                && state.query.isEmpty()
        binding.toolbar.menu.findItem(R.id.copy)?.isVisible = !state.editingMode && state.selectedMessages > 0
        binding.toolbar.menu.findItem(R.id.details)?.isVisible = !state.editingMode && state.selectedMessages == 1
        binding.toolbar.menu.findItem(R.id.delete)?.isVisible = !state.editingMode && state.selectedMessages > 0
        binding.toolbar.menu.findItem(R.id.forward)?.isVisible = !state.editingMode && state.selectedMessages == 1
        binding.toolbar.menu.findItem(R.id.previous)?.isVisible = state.selectedMessages == 0 && state.query.isNotEmpty()
        binding.toolbar.menu.findItem(R.id.next)?.isVisible = state.selectedMessages == 0 && state.query.isNotEmpty()
        binding.toolbar.menu.findItem(R.id.clear)?.isVisible = state.selectedMessages == 0 && state.query.isNotEmpty()

        chipsAdapter.data = state.selectedChips

        binding.loading.setVisible(state.loading)

        binding.sendAsGroup.setVisible(state.editingMode && state.selectedChips.size >= 2)
        binding.sendAsGroupSwitch.isChecked = state.sendAsGroup

        binding.messageList.setVisible(!state.editingMode || state.sendAsGroup || state.selectedChips.size == 1)
        messageAdapter.data = state.messages
        messageAdapter.highlight = state.searchSelectionId

        binding.scheduledGroup.isVisible = state.scheduled != 0L
        binding.scheduledTime.text = dateFormatter.getScheduledTimestamp(state.scheduled)

        binding.attachments.setVisible(state.attachments.isNotEmpty())
        attachmentAdapter.data = state.attachments

        binding.attach.animate().rotation(if (state.attaching) 135f else 0f).start()
        binding.attaching.isVisible = state.attaching

        binding.counter.text = state.remaining
        binding.counter.setVisible(binding.counter.text.isNotBlank())

        binding.sim.setVisible(state.subscription != null)
        binding.sim.contentDescription = getString(R.string.compose_sim_cd, state.subscription?.displayName)
        binding.simIndex.text = state.subscription?.simSlotIndex?.plus(1)?.toString()

        binding.send.isEnabled = state.canSend
        binding.send.imageAlpha = if (state.canSend) 255 else 128

        if (state.scrollToPosition!! > 0) {
            scrollToMessage(state.scrollToPosition!!)
        }
    }

    override fun clearSelection() = messageAdapter.clearSelection()

    override fun showDetails(details: String) {
        AlertDialog.Builder(this)
            .setTitle(R.string.compose_details_title)
            .setMessage(details)
            .setCancelable(true)
            .show()
    }


    override fun showUnStarredSnackBar() {
        Snackbar.make(binding.contentView, getString(R.string.star_removed), Snackbar.LENGTH_LONG)
            .apply {
                setAction(getString(R.string.undo)) { starMessageSubject.onNext(messageAdapter.messageIdForUndoUnStar) }
                setActionTextColor(
                    ContextCompat.getColor(
                        this@ComposeActivity,
                        R.color.color_app_theme
                    )
                )
                show()
            }
//        if (snackBar?.isShown ?: false) {
//            snackBar?.dismiss()
//        }
    }

    override fun requestDefaultSms() {
        navigator.showDefaultSmsDialog(this)
    }

    override fun requestStoragePermission() {
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 0)
    }

    override fun requestSmsPermission() {
        ActivityCompat.requestPermissions(
            this, arrayOf(
                Manifest.permission.READ_SMS,
                Manifest.permission.SEND_SMS
            ), 0
        )
    }

    override fun requestDatePicker() {
        val calendar = Calendar.getInstance()
        DatePickerDialog(this, DatePickerDialog.OnDateSetListener { _, year, month, day ->
            TimePickerDialog(this, TimePickerDialog.OnTimeSetListener { _, hour, minute ->
                calendar.set(Calendar.YEAR, year)
                calendar.set(Calendar.MONTH, month)
                calendar.set(Calendar.DAY_OF_MONTH, day)
                calendar.set(Calendar.HOUR_OF_DAY, hour)
                calendar.set(Calendar.MINUTE, minute)
                scheduleSelectedIntent.onNext(calendar.timeInMillis)
            }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), DateFormat.is24HourFormat(this))
                .show()
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
    }

    override fun requestContact() {
        val intent = Intent(Intent.ACTION_PICK)
            .setType(ContactsContract.CommonDataKinds.Phone.CONTENT_TYPE)

        startActivityForResult(Intent.createChooser(intent, null), AttachContactRequestCode)
    }

    override fun showContacts(sharing: Boolean, chips: List<Recipient>) {
        binding.message.hideKeyboard()
        val serialized = HashMap(chips.associate { chip -> chip.address to chip.contact?.lookupKey })
        val intent = Intent(this, ContactsActivity::class.java)
            .putExtra(ContactsActivity.SharingKey, sharing)
            .putExtra(ContactsActivity.ChipsKey, serialized)
        startActivityForResult(intent, SelectContactRequestCode)
    }

    override fun themeChanged() {
        binding.messageList.scrapViews()
    }

    override fun showKeyboard() {
        binding.message.postDelayed({
            binding.message.showKeyboard()
        }, 200)
    }

    override fun requestCamera() {
        cameraDestination = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            .let { timestamp -> ContentValues().apply { put(MediaStore.Images.Media.TITLE, timestamp) } }
            .let { cv -> contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) }

        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            .putExtra(MediaStore.EXTRA_OUTPUT, cameraDestination)
        startActivityForResult(Intent.createChooser(intent, null), TakePhotoRequestCode)
    }

    override fun requestGallery() {
        val intent = Intent(Intent.ACTION_PICK)
            .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            .addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            .putExtra(Intent.EXTRA_LOCAL_ONLY, false)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            .setType("image/*")
        startActivityForResult(Intent.createChooser(intent, null), AttachPhotoRequestCode)
    }

    override fun setDraft(draft: String) = binding.message.setText(draft)

    override fun scrollToMessage(id: Long) {
        messageAdapter.data?.second
            ?.indexOfLast { message -> message.id == id }
            ?.takeIf { position -> position != -1 }
            ?.let(binding.messageList::scrollToPosition)
    }


    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.compose, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
            }
            else -> optionsItemIntent.onNext(item.itemId)
        }
//        optionsItemIntent.onNext(item.itemId)
        return true
    }

    override fun getColoredMenuItems(): List<Int> {
        return super.getColoredMenuItems() + R.id.call
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when {
            requestCode == SelectContactRequestCode -> {
                chipsSelectedIntent.onNext(data?.getSerializableExtra(ContactsActivity.ChipsKey)
                    ?.let { serializable -> serializable as? HashMap<String, String?> }
                    ?: hashMapOf())
            }

            requestCode == TakePhotoRequestCode && resultCode == Activity.RESULT_OK -> {
                cameraDestination?.let(attachmentSelectedIntent::onNext)
            }

            requestCode == AttachPhotoRequestCode && resultCode == Activity.RESULT_OK -> {
                data?.clipData?.itemCount
                    ?.let { count -> 0 until count }
                    ?.mapNotNull { i -> data.clipData?.getItemAt(i)?.uri }
                    ?.forEach(attachmentSelectedIntent::onNext)
                    ?: data?.data?.let(attachmentSelectedIntent::onNext)
            }

            requestCode == AttachContactRequestCode && resultCode == Activity.RESULT_OK -> {
                data?.data?.let(contactSelectedIntent::onNext)
            }

            else -> super.onActivityResult(requestCode, resultCode, data)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putParcelable(CameraDestinationKey, cameraDestination)
        super.onSaveInstanceState(outState)
    }

    override fun onRestoreInstanceState(
        savedInstanceState: Bundle?,
        persistentState: PersistableBundle?
    ) {
        cameraDestination = savedInstanceState?.getParcelable(CameraDestinationKey)
        super.onRestoreInstanceState(savedInstanceState, persistentState)
    }

//    override fun onRestoreInstanceState(savedInstanceState: Bundle?) {
//        cameraDestination = savedInstanceState?.getParcelable(CameraDestinationKey)
//        super.onRestoreInstanceState(savedInstanceState)
//    }

//    override fun onBackPressed() = backPressedIntent.onNext(Unit)
    override fun onBackPressed() {
        if (messageAdapter.selection.isNotEmpty()) {
            clearSelection()
        } else {
            finish()
        }
    }
    override fun onDestroy() {
        super.onDestroy()
        binding.message.hideKeyboard()
    }
}
