package messenger.chat.text.messages.sms.commons.adapters

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import messenger.chat.text.messages.sms.commons.extensions.applyColorFilter
import messenger.chat.text.messages.sms.commons.extensions.baseConfig
import messenger.chat.text.messages.sms.commons.extensions.getBottomNavigationBackgroundColor
import messenger.chat.text.messages.sms.commons.extensions.updateTextColors
import messenger.chat.text.messages.sms.R

class RingtoneListAdapter(private val context: Context,
                          private val fontList: MutableList<Array<String>>,
                          private val listener: (String,Int) -> Unit
                          ) :
    RecyclerView.Adapter<RingtoneListAdapter.ViewHolder>() {

    private var selectedPosition = RecyclerView.NO_POSITION

    val colorList = listOf(
        R.drawable.bling,
        R.drawable.customize,
        R.drawable.system_im,
        R.drawable.love,
        R.drawable.instruments,
        R.drawable.tick
    )

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_layout_ringtone, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val fontName = fontList[position]

        context.updateTextColors(holder.llmain)
        holder.fontTextView.text = fontList.get(position).get(1)

        holder.item_textsec.isVisible = false

        val drawableResId = colorList[position % colorList.size]
        // Set the background drawable with rounded corners
        holder.llmain.setBackgroundResource(drawableResId)


        if (context.baseConfig.ringtoneUri.equals(fontList.get(position).get(2))) {
            selectedPosition = position

        } else {


        }


        if (position == selectedPosition) {

            holder.im_check.visibility = View.VISIBLE
        } else {
            holder.im_check.visibility = View.GONE
        }
    }

    override fun getItemCount(): Int {
        return fontList.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val fontTextView: TextView = itemView.findViewById(R.id.item_text)
        val item_textsec: TextView = itemView.findViewById(R.id.item_textsec)
        val im_check: ImageView = itemView.findViewById(R.id.im_check)
        val llmain: LinearLayout = itemView.findViewById(R.id.llmain)

        init {
            itemView.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    val fontName = fontList.get(position).get(1)

                    // Update the selected position and notify the adapter
                    val previousPosition = selectedPosition
                    selectedPosition = position
                    notifyItemChanged(previousPosition)
                    notifyItemChanged(selectedPosition)

                    listener.invoke(fontName, position)
//                    listener.onRingtoneItemClick(fontName, position)
                }
            }
        }

    }

}
