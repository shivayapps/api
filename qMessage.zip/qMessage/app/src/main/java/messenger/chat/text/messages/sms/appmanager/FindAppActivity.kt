package messenger.chat.text.messages.sms.appmanager

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.AnimationDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.AccelerateInterpolator
import androidx.core.content.ContextCompat
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.commons.extensions.baseConfig
import messenger.chat.text.messages.sms.commons.extensions.beGone
import messenger.chat.text.messages.sms.commons.extensions.beVisible
import messenger.chat.text.messages.sms.commons.extensions.updateTextColors
import messenger.chat.text.messages.sms.commons.helpers.NavigationIcon
import messenger.chat.text.messages.sms.databinding.ActivityFindAppBinding

class FindAppActivity : AppCompatActivity() {

    private lateinit var appListAdapter : AppListAdapter

    lateinit var binding: ActivityFindAppBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityFindAppBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateTextColors(binding.clManageApp)


//        usestatusbar=false

        window.statusBarColor = ContextCompat.getColor(this, R.color.primary)

//        setupToolbar(binding.customizationToolbar, NavigationIcon.Arrow)
        binding.customizationToolbar.setBackgroundColor(Color.TRANSPARENT)
        binding.customizationToolbar.title="Manage Apps"
//        binding.customizationToolbar.toInt()

        binding.llScanner.beVisible()
        binding.llComplete.beGone()
        val animDrawable = binding.root.background as AnimationDrawable
        animDrawable.setEnterFadeDuration(10)
        animDrawable.setExitFadeDuration(5000)
        animDrawable.start()


        setSupportActionBar(binding.customizationToolbar)

        // Enable the back button

        // Enable the back button
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.setDisplayShowHomeEnabled(true)

        // Handle back button click

        // Handle back button click
        binding.customizationToolbar.setNavigationOnClickListener { view ->
            // Finish the activity or handle the back navigation
            onBackPressed()
        }
        binding.countTextView.run {
            interpolator(AccelerateInterpolator())
            start()
        }

        binding.btnManage.setOnClickListener {
//            AdsConfig().showInterstitialAd(this@FindAppActivity) {
                startActivity(Intent(this@FindAppActivity, ManageAppActivity::class.java))
//            }
        }

//        AdmobIntersAdImpl().load(this,getString(R.string.AppManager_Inter))
        Handler(Looper.getMainLooper()).postDelayed({
            setupScanComplete()
        },3500)
    }

    fun setupScanComplete() {
        binding.llScanner.beGone()
        binding.llComplete.beVisible()
    }
}
