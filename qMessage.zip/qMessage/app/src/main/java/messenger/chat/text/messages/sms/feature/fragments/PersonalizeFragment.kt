package messenger.chat.text.messages.sms.feature.fragments


import android.content.Intent
import android.os.Bundle
import android.preference.PreferenceManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.f2prateek.rx.preferences2.RxSharedPreferences
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.commons.extensions.applyColorFilter
import messenger.chat.text.messages.sms.commons.extensions.baseConfig
import messenger.chat.text.messages.sms.commons.extensions.getBottomNavigationBackgroundColor
import messenger.chat.text.messages.sms.commons.extensions.getProperPrimaryColor
import messenger.chat.text.messages.sms.commons.extensions.updateTextColors
import messenger.chat.text.messages.sms.databinding.FragmentPersonalizeBinding
import messenger.chat.text.messages.sms.feature.personalize.BubbleActivity
import messenger.chat.text.messages.sms.feature.personalize.FontActivity
import messenger.chat.text.messages.sms.feature.personalize.RingtonesListActivity
import messenger.chat.text.messages.sms.feature.personalize.ThemeActivity
import messenger.chat.text.messages.sms.util.Preferences


class PersonalizeFragment constructor() : Fragment() {

    lateinit var prefs: Preferences

    lateinit var binding: FragmentPersonalizeBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentPersonalizeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val shPrefs = PreferenceManager.getDefaultSharedPreferences(context)
        val rxPrefs = RxSharedPreferences.create(shPrefs)
        prefs = Preferences(requireContext(), rxPrefs, shPrefs)

        setUI()
        setUpListener()
    }

    private fun setUI() {
        requireContext().updateTextColors(binding.personalizeCoordinator)

        binding.apply {

            arrayOf(
                themeLabel,
                fontLabel,
                bubbleLabel,
                ringtoneLabel,
            ).forEach {
                it.setTextColor(requireContext().getProperPrimaryColor())
            }

//            arrayOf(
//                llThemeHolder,
//                llFontHolder,
//                llBubbleHolder,
//                llRingtoneHolder,
//            ).forEach {
//                it.background.applyColorFilter(requireContext().getBottomNavigationBackgroundColor())
//            }
            arrayOf(
                llThemeHolder,
                llFontHolder,
                llBubbleHolder,
                llRingtoneHolder,
            ).forEach {
                if (requireActivity().baseConfig.useImageResource == true) {
                    if (requireActivity().baseConfig.storedImageResource==-1) {

                    } else {
                        it.background.applyColorFilter(requireContext().resources.getColor(R.color.transperent30))
                    }
                } else {
                    it.background.applyColorFilter(requireContext().getBottomNavigationBackgroundColor())

                }
            }
        }


    }

    private fun setUpListener() {

        binding.llFontHolder.setOnClickListener {
            val intent = Intent(requireContext(), FontActivity::class.java);
            startActivity(intent);
        }
        binding.llThemeHolder.setOnClickListener {
            val intent = Intent(requireContext(), ThemeActivity::class.java);
            startActivity(intent);
        }
        binding.llBubbleHolder.setOnClickListener {
            val intent = Intent(requireContext(), BubbleActivity::class.java);
            startActivity(intent);
        }
        binding.llRingtoneHolder.setOnClickListener {
            val intent = Intent(requireContext(), RingtonesListActivity::class.java);
            startActivity(intent);
        }
    }


}
