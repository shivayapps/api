package messenger.chat.text.messages.sms.common.util

import android.graphics.Typeface
import android.os.Build
import android.util.AttributeSet
import android.widget.EditText
import android.widget.TextView
import messenger.chat.text.messages.sms.common.util.TextViewStyler.Companion.SIZE_PRIMARY
import messenger.chat.text.messages.sms.common.util.TextViewStyler.Companion.SIZE_SECONDARY
import messenger.chat.text.messages.sms.common.util.TextViewStyler.Companion.SIZE_TERTIARY
import messenger.chat.text.messages.sms.common.util.TextViewStyler.Companion.SIZE_TOOLBAR
import messenger.chat.text.messages.sms.common.widget.BabyTextView
import messenger.chat.text.messages.sms.util.Preferences
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.common.widget.MessageTextView
import messenger.chat.text.messages.sms.common.widget.StyledTextView
import javax.inject.Inject


class TextViewStyler @Inject constructor(
    private val prefs: Preferences,
    private val colors: Colors,
    private val fontProvider: FontProvider
) {

    companion object {
        const val COLOR_THEME = 0
        const val COLOR_PRIMARY_ON_THEME = 1
        const val COLOR_SECONDARY_ON_THEME = 2
        const val COLOR_TERTIARY_ON_THEME = 3

        const val SIZE_PRIMARY = 0
        const val SIZE_SECONDARY = 1
        const val SIZE_TERTIARY = 2
        const val SIZE_TOOLBAR = 3
        const val SIZE_DIALOG = 4
        const val SIZE_EMOJI = 5
        const val SIZE_NORMAL = 6

        fun applyEditModeAttributes(textView: TextView, attrs: AttributeSet?) {
            textView.run {
                var colorAttr = 0
                var textSizeAttr = 0

                when (this) {
                    is BabyTextView -> context.obtainStyledAttributes(attrs, R.styleable.QkTextView)
                        ?.run {
                            colorAttr = getInt(R.styleable.QkTextView_textColor, -1)
//                        textSizeAttr = getInt(R.styleable.QkTextView_textSize, -1)
                            recycle()
                        }

                    is StyledTextView -> context.obtainStyledAttributes(
                        attrs,
                        R.styleable.QkTextView
                    )?.run {
                        colorAttr = getInt(R.styleable.QkTextView_textColor, -1)
//                        textSizeAttr = getInt(R.styleable.QkTextView_textSize, -1)
                        recycle()
                    }

//                    is QkEditText -> context.obtainStyledAttributes(attrs, R.styleable.QkEditText)?.run {
//                        colorAttr = getInt(R.styleable.QkEditText_textColor, -1)
////                        textSizeAttr = getInt(R.styleable.QkEditText_textSize, -1)
//                        recycle()
//                    }

                    else -> return
                }

//                textSize = when (textSizeAttr) {
//                    SIZE_PRIMARY -> 16f
//                    SIZE_SECONDARY -> 14f
//                    SIZE_TERTIARY -> 12f
//                    SIZE_TOOLBAR -> 20f
//                    SIZE_DIALOG -> 18f
//                    SIZE_EMOJI -> 32f
//                    else -> textSize / paint.density
//                }
            }
        }
    }

    fun applyAttributes(textView: TextView, attrs: AttributeSet?) {
//        var colorAttr = 0
        var textSizeAttr = 0
        var isMessage = false


        when (textView) {
            is BabyTextView -> textView.context.obtainStyledAttributes(
                attrs,
                R.styleable.QkTextView
            ).run {
                isMessage=false
//                colorAttr = getInt(R.styleable.QkTextView_textColor, -1)
                textSizeAttr = getInt(R.styleable.QkTextView_textSize, -1)
                recycle()
            }

            is StyledTextView -> textView.context.obtainStyledAttributes(
                attrs,
                R.styleable.QkTextView
            ).run {
                isMessage=false
//                colorAttr = getInt(R.styleable.QkTextView_textColor, -1)
                textSizeAttr = getInt(R.styleable.QkTextView_textSize, -1)
//                setTextSize(textView, textSizeAttr)
                recycle()
            }

            is MessageTextView -> textView.context.obtainStyledAttributes(
                attrs,
                R.styleable.QkTextView
            ).run {
                isMessage=true
//                colorAttr = getInt(R.styleable.QkTextView_textColor, -1)
                textSizeAttr = getInt(R.styleable.QkTextView_textSize, -1)

                if (!prefs.systemFont.get()) {
                    fontProvider.getLato { lato ->
                        textView.setTypeface(lato, textView.typeface?.style ?: Typeface.NORMAL)
                    }
                }
                recycle()
            }

//            is TextView -> textView.context.obtainStyledAttributes(attrs, R.styleable.QkTextView).run {
//                colorAttr = getInt(R.styleable.QkTextView_textColor, -1)
//                textSizeAttr = getInt(R.styleable.QkTextView_textSize, -1)
//                recycle()
//            }

//            is QkEditText -> textView.context.obtainStyledAttributes(attrs, R.styleable.QkEditText).run {
////                colorAttr = getInt(R.styleable.QkEditText_textColor, -1)
//                textSizeAttr = getInt(R.styleable.QkEditText_textSize, -1)
//                recycle()
//            }

            else -> return
        }

        setTextSize(textView, textSizeAttr,isMessage)

        if (textView is EditText) {
            val drawable = textView.resources.getDrawable(R.drawable.cursor)
                .apply { setTint(colors.theme().theme) }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                textView.textCursorDrawable = drawable
            }
        }
    }

    fun setTextSize(textView: TextView, textSizeAttr: Int, isMessage: Boolean) {
        val textSizePref = prefs.textSize.get()
        when (textSizeAttr) {
            SIZE_PRIMARY -> {
                if (isMessage) textView.textSize = textSizePref.toFloat()
                else textView.textSize = 16f
            }

            SIZE_SECONDARY -> {
                if (isMessage) textView.textSize = (textSizePref * 0.8).toFloat()
                else textView.textSize = 14f
            }

            SIZE_TERTIARY -> {
                if (isMessage)textView.textSize = (textSizePref * 0.6).toFloat()
                else textView.textSize = 12f
            }
            SIZE_TOOLBAR -> {
                if (isMessage)textView.textSize = (textSizePref * 1.2).toFloat()
                else textView.textSize = 20f
            }
            SIZE_DIALOG -> {
                if (isMessage)textView.textSize = (textSizePref * 1.6).toFloat()
                else textView.textSize = 18f
            }
            SIZE_EMOJI -> {
                if (isMessage)textView.textSize = (textSizePref * 2).toFloat()
                else textView.textSize = 32f
            }
            SIZE_NORMAL -> {
                textView.textSize = 16f
            }
//            SIZE_EMOJI -> textView.textSize = 32f
//            SIZE_PRIMARY -> textView.textSize = when (textSizePref) {
//////                Preferences.TEXT_SIZE_SMALL -> 14f
//////                Preferences.TEXT_SIZE_NORMAL -> 16f
//////                Preferences.TEXT_SIZE_LARGE -> 18f
//////                Preferences.TEXT_SIZE_LARGER -> 20f
//                else -> 16f
//            }
//
//            SIZE_SECONDARY -> textView.textSize = when (textSizePref) {
////                Preferences.TEXT_SIZE_SMALL -> 12f
////                Preferences.TEXT_SIZE_NORMAL -> 14f
////                Preferences.TEXT_SIZE_LARGE -> 16f
////                Preferences.TEXT_SIZE_LARGER -> 18f
//                else -> 14f
//            }
//
//            SIZE_TERTIARY -> textView.textSize = when (textSizePref) {
////                Preferences.TEXT_SIZE_SMALL -> 10f
////                Preferences.TEXT_SIZE_NORMAL -> 12f
////                Preferences.TEXT_SIZE_LARGE -> 14f
////                Preferences.TEXT_SIZE_LARGER -> 16f
//                else -> 12f
//            }
//
//            SIZE_TOOLBAR -> textView.textSize = when (textSizePref) {
////                Preferences.TEXT_SIZE_SMALL -> 18f
////                Preferences.TEXT_SIZE_NORMAL -> 20f
////                Preferences.TEXT_SIZE_LARGE -> 22f
////                Preferences.TEXT_SIZE_LARGER -> 26f
//                else -> 20f
//            }
//
//            SIZE_DIALOG -> textView.textSize = when (textSizePref) {
////                Preferences.TEXT_SIZE_SMALL -> 16f
////                Preferences.TEXT_SIZE_NORMAL -> 18f
////                Preferences.TEXT_SIZE_LARGE -> 20f
////                Preferences.TEXT_SIZE_LARGER -> 24f
//                else -> 18f
//            }
//
//            SIZE_EMOJI -> textView.textSize = when (textSizePref) {
////                Preferences.TEXT_SIZE_SMALL -> 28f
////                Preferences.TEXT_SIZE_NORMAL -> 32f
////                Preferences.TEXT_SIZE_LARGE -> 36f
////                Preferences.TEXT_SIZE_LARGER -> 40f
//                else -> 32f
//            }
        }
    }

}