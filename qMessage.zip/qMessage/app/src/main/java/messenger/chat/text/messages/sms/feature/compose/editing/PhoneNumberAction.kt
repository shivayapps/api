package messenger.chat.text.messages.sms.feature.compose.editing

enum class PhoneNumberAction {
    CANCEL,
    JUST_ONCE,
    ALWAYS
}
