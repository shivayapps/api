package messenger.chat.text.messages.sms.feature.backup

import messenger.chat.text.messages.sms.model.BackupFile
import messenger.chat.text.messages.sms.repository.BackupRepository

data class BackupState(
    val backupProgress: BackupRepository.Progress = BackupRepository.Progress.Idle(),
    val restoreProgress: BackupRepository.Progress = BackupRepository.Progress.Idle(),
    val lastBackup: String = "",
    val backups: List<BackupFile> = listOf(),
//    val upgraded: Boolean = true
)
