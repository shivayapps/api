package messenger.chat.text.messages.sms.feature.blocking

data class BlockingState(
    val blockingManager: String = "",
    val dropEnabled: Boolean = false
)
