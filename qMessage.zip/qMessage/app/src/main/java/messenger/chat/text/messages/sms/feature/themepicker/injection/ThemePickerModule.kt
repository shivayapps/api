package messenger.chat.text.messages.sms.feature.themepicker.injection

import messenger.chat.text.messages.sms.feature.themepicker.ThemePickerController
import messenger.chat.text.messages.sms.injection.scope.ControllerScope
import dagger.Module
import dagger.Provides
import javax.inject.Named

@Module
class ThemePickerModule(private val controller: ThemePickerController) {

    @Provides
    @ControllerScope
    @Named("recipientId")
    fun provideThreadId(): Long = controller.recipientId

}