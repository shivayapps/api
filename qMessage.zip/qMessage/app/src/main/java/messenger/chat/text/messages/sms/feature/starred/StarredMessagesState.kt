package messenger.chat.text.messages.sms.feature.starred

import io.realm.RealmResults
import messenger.chat.text.messages.sms.model.Message

data class StarredMessagesState(
    val data: RealmResults<Message>? = null,
    val selected: Int = 0
)
