package messenger.chat.text.messages.sms.appmanager

import android.app.ActivityManager
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.commons.extensions.*
import messenger.chat.text.messages.sms.commons.helpers.NavigationIcon
import messenger.chat.text.messages.sms.databinding.ActivityManageAppBinding

class ManageAppActivity : AppCompatActivity() {

    private lateinit var appListAdapter : AppListAdapter

    lateinit var binding:ActivityManageAppBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityManageAppBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateTextColors(binding.clManageApp)

//        setupToolbar(binding.customizationToolbar, NavigationIcon.Arrow, getColor(R.color.white))
//        binding.customizationToolbar.background=null
        binding.customizationToolbar.setBackgroundColor(Color.TRANSPARENT)
        binding.customizationToolbar.title = "Manage Apps"

        setSupportActionBar(binding.customizationToolbar)

        // Enable the back button
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)

        // Handle back button click
        binding.customizationToolbar.setNavigationOnClickListener { view ->
            // Finish the activity or handle the back navigation
            onBackPressed()
        }
        binding.btnOk.setOnClickListener { view ->
            // Finish the activity or handle the back navigation
            onBackPressed()
        }

//        usestatusbar=false
//        3774FF
        window.statusBarColor = ContextCompat.getColor(this, R.color.primary)

        val launcherViewModel = LauncherViewModel()
        val appList = launcherViewModel.retrieveInstalledApps(this)

        appListAdapter = AppListAdapter(this@ManageAppActivity, appList, object : AppListAdapter.IAppLaunchListener {
            override fun onAppSelected(appModel: AppModel) {
//                val optionsDialog=OptionsBottomSheetFragment(appModel)
//                optionsDialog.show(supportFragmentManager,optionsDialog.tag)
            }
        })

        binding.rvAppList.adapter = appListAdapter

        showRAMUsage()
        loadAd()
    }

    private fun loadAd() {

    }

    private fun showRAMUsage() {

        val totalRamValue = totalRamMemorySize()
        val freeRamValue = freeRamMemorySize()
        val usedRamValue = totalRamValue - freeRamValue

//        tvUsedMemory?.text = mResources.getString(R.string.used_memory) + "\t" + formatSize(usedRamValue)
//        tvFreeMemory?.text = mResources.getString(R.string.free) + "\t" + formatSize(freeRamValue)
//        tvTotalMemory?.text = mResources.getString(R.string.total) + "\t" + formatSize(totalRamValue)

        val usedPercent=calculatePercentage(usedRamValue.toDouble(), totalRamValue.toDouble()).toFloat()
        binding.tvPercent.setText("$usedPercent")
//        donutRAMUsage?.progress = Methods.calculatePercentage(usedRamValue.toDouble(), totalRamValue.toDouble()).toFloat()
    }
    fun calculatePercentage(value: Double, total: Double): Int {
        val usage = (value * 100.0f / total).toInt().toDouble()
        return usage.toInt()
    }

    private fun totalRamMemorySize(): Long {
        val mi = ActivityManager.MemoryInfo()
        val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        activityManager.getMemoryInfo(mi)
        return mi.totalMem
    }

    private fun freeRamMemorySize(): Long {
        val mi = ActivityManager.MemoryInfo()
        val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        activityManager.getMemoryInfo(mi)

        return mi.availMem
    }


}
