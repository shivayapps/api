package messenger.chat.text.messages.sms.commons.extensions

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.telecom.TelecomManager
import android.text.TextUtils
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.common.widget.StyledTextView
import messenger.chat.text.messages.sms.commons.helpers.BaseConfig
import messenger.chat.text.messages.sms.commons.helpers.Config
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_ACCESS_COARSE_LOCATION
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_ACCESS_FINE_LOCATION
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_CALL_PHONE
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_CAMERA
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_GET_ACCOUNTS
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_MEDIA_LOCATION
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_POST_NOTIFICATIONS
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_READ_CALENDAR
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_READ_CALL_LOG
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_READ_CONTACTS
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_READ_MEDIA_AUDIO
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_READ_MEDIA_IMAGES
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_READ_MEDIA_VIDEO
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_READ_MEDIA_VISUAL_USER_SELECTED
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_READ_PHONE_STATE
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_READ_SMS
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_READ_STORAGE
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_READ_SYNC_SETTINGS
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_RECORD_AUDIO
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_SEND_SMS
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_WRITE_CALENDAR
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_WRITE_CALL_LOG
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_WRITE_CONTACTS
import messenger.chat.text.messages.sms.commons.helpers.PERMISSION_WRITE_STORAGE
import messenger.chat.text.messages.sms.commons.helpers.PREFS_KEY
import messenger.chat.text.messages.sms.commons.helpers.TIME_FORMAT_12
import messenger.chat.text.messages.sms.commons.helpers.TIME_FORMAT_24
import messenger.chat.text.messages.sms.commons.helpers.isOnMainThread
import messenger.chat.text.messages.sms.commons.helpers.isQPlus
import messenger.chat.text.messages.sms.commons.views.MyAppCompatCheckbox
import messenger.chat.text.messages.sms.commons.views.MyAppCompatSpinner
import messenger.chat.text.messages.sms.commons.views.MyAutoCompleteTextView
import messenger.chat.text.messages.sms.commons.views.MyButton
import messenger.chat.text.messages.sms.commons.views.MyCompatRadioButton
import messenger.chat.text.messages.sms.commons.views.MyEditText
import messenger.chat.text.messages.sms.commons.views.MyFloatingActionButton
import messenger.chat.text.messages.sms.commons.views.MySeekBar
import messenger.chat.text.messages.sms.commons.views.MyTextInputLayout
import messenger.chat.text.messages.sms.common.widget.BabyTextView
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader

fun Context.getSharedPrefs() = getSharedPreferences(PREFS_KEY, Context.MODE_PRIVATE)
val Context.baseConfig: BaseConfig get() = BaseConfig.newInstance(this)
val Context.telecomManager: TelecomManager get() = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
fun Context.getTimeFormat() = if (baseConfig.use24HourFormat) TIME_FORMAT_24 else TIME_FORMAT_12

fun Context.getProperTextColor() = baseConfig.textColor

fun Context.getProperBackgroundColor() = baseConfig.backgroundColor
fun Context.getProperPrimaryColor() = baseConfig.primaryColor
fun Context.getProperTextCursorColor() = baseConfig.textCursorColor

@SuppressLint("NewApi")
fun Context.getBottomNavigationBackgroundColorFont(): Int {
    val baseColor = baseConfig.backgroundColor
    var bottomColor: Int =0
    bottomColor = when {
        baseColor == Color.WHITE -> resources.getColor(R.color.bottom_tabs_light_background, theme)
        baseColor == Color.BLACK -> resources.getColor(R.color.bottom_tabs_black_backgroundnew, theme)
        else ->
            baseConfig.backgroundColor.lightenColor(40)
    }
    return bottomColor
}

fun Context.updateTextColors(viewGroup: ViewGroup) {
    val textColor = baseConfig.textColor

    val backgroundColor = baseConfig.backgroundColor
    val accentColor = getProperPrimaryColor()
    val textCursorColor = getProperTextCursorColor()

    val cnt = viewGroup.childCount
    (0 until cnt).map { viewGroup.getChildAt(it) }.forEach {
        if (it.tag == null) {
            when (it) {
                is BabyTextView -> it.setColors(textColor, accentColor, backgroundColor)
                is StyledTextView -> it.setColors(textColor, accentColor, backgroundColor)
                is MyAppCompatSpinner -> it.setColors(textColor, accentColor, backgroundColor)
//                is QkSwitch -> it.setColors(textColor, accentColor, backgroundColor)
                is MyCompatRadioButton -> it.setColors(textColor, accentColor, backgroundColor)
                is MyAppCompatCheckbox -> it.setColors(textColor, accentColor, backgroundColor)
                is MyEditText -> it.setColors(textColor, accentColor, textCursorColor)
                is MyAutoCompleteTextView -> it.setColors(textColor, accentColor, textCursorColor)
                is MyFloatingActionButton -> it.setColors(textColor, accentColor, backgroundColor)
                is MySeekBar -> it.setColors(textColor, accentColor, backgroundColor.getContrastColor())
                is MyButton -> it.setColors(textColor, accentColor, backgroundColor)
                is MyTextInputLayout -> it.setColors(textColor, accentColor, backgroundColor)
                is ViewGroup -> updateTextColors(it)
            }
        }

    }
}

fun isMiUi(): Boolean {
    return !TextUtils.isEmpty(getSystemProperty("ro.miui.ui.version.name"))
}

fun getSystemProperty(propName: String): String? {
    val line: String
    var input: BufferedReader? = null
    try {
        val p = Runtime.getRuntime().exec("getprop $propName")
        input = BufferedReader(InputStreamReader(p.inputStream), 1024)
        line = input.readLine()
        input.close()
    } catch (ex: IOException) {
        return null
    } finally {
        if (input != null) {
            try {
                input.close()
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
    }
    return line
}

@SuppressLint("NewApi")
fun Context.getBottomNavigationBackgroundColorsetting(): Int {
    val baseColor = baseConfig.backgroundColor
    var bottomColor: Int = 0
    bottomColor = when {
        baseColor == Color.WHITE -> resources.getColor(R.color.dividersettind, theme)
        baseColor == Color.BLACK -> resources.getColor(R.color.bottom_tabs_black_backgroundsetting, theme)
        else ->
            resources.getColor(R.color.divider, theme)
    }
    return bottomColor
}

fun Context.getBottomNavigationBackgroundColor(): Int {
    val baseColor = baseConfig.backgroundColor
    var bottomColor: Int = 0
    if (baseColor == -1) {
        bottomColor = baseConfig.backgroundColor
    } else {
        bottomColor = when {
            baseColor == Color.BLACK -> resources.getColor(R.color.bottom_tabs_black_background, theme)
            else -> baseConfig.backgroundColor.lightenColor(40)
        }
    }
    return bottomColor
}


fun Context.toast(id: Int, length: Int = Toast.LENGTH_SHORT) {
    toast(getString(id), length)
}

fun Context.toast(msg: String, length: Int = Toast.LENGTH_SHORT) {
    try {
        if (isOnMainThread()) {
            doToast(this, msg, length)
        } else {
            Handler(Looper.getMainLooper()).post {
                doToast(this, msg, length)
            }
        }
    } catch (e: Exception) {

    }
}

private fun doToast(context: Context, message: String, length: Int) {
    if (context is Activity) {
        if (!context.isFinishing && !context.isDestroyed) {
            Toast.makeText(context, message, length).show()
        }
    } else {
        Toast.makeText(context, message, length).show()
    }
}

fun Context.showErrorToast(msg: String, length: Int = Toast.LENGTH_LONG) {
    toast(String.format(getString(R.string.error), msg), length)
}

fun Context.showErrorToast(exception: Exception, length: Int = Toast.LENGTH_LONG) {
    showErrorToast(exception.toString(), length)
}

val Context.config: Config get() = Config.newInstance(applicationContext)
fun Context.getDefaultKeyboardHeight() = resources.getDimensionPixelSize(R.dimen.default_keyboard_height)

@SuppressLint("MissingPermission")
fun Context.areMultipleSIMsAvailable(): Boolean {
    return try {
        telecomManager.callCapablePhoneAccounts.size > 1
    } catch (ignored: Exception) {
        false
    }
}

fun Context.copyToClipboard(text: String) {
    val clip = ClipData.newPlainText(getString(R.string.app_name), text)
    (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(clip)
//    val toastText = String.format(getString(R.string.value_copied_to_clipboard_show), text)
    val toastText = getString(R.string.value_copied_to_clipboard_new)
    toast(toastText)
}


fun Context.hasPermission(permId: Int) = ContextCompat.checkSelfPermission(this, getPermissionString(permId)) == PackageManager.PERMISSION_GRANTED

fun Context.hasAllPermissions(permIds: Collection<Int>) = permIds.all(this::hasPermission)

fun Context.getPermissionString(id: Int) = when (id) {
    PERMISSION_READ_STORAGE -> Manifest.permission.READ_EXTERNAL_STORAGE
    PERMISSION_WRITE_STORAGE -> Manifest.permission.WRITE_EXTERNAL_STORAGE
    PERMISSION_CAMERA -> Manifest.permission.CAMERA
    PERMISSION_RECORD_AUDIO -> Manifest.permission.RECORD_AUDIO
    PERMISSION_READ_CONTACTS -> Manifest.permission.READ_CONTACTS
    PERMISSION_WRITE_CONTACTS -> Manifest.permission.WRITE_CONTACTS
    PERMISSION_READ_CALENDAR -> Manifest.permission.READ_CALENDAR
    PERMISSION_WRITE_CALENDAR -> Manifest.permission.WRITE_CALENDAR
    PERMISSION_CALL_PHONE -> Manifest.permission.CALL_PHONE
    PERMISSION_READ_CALL_LOG -> Manifest.permission.READ_CALL_LOG
    PERMISSION_WRITE_CALL_LOG -> Manifest.permission.WRITE_CALL_LOG
    PERMISSION_GET_ACCOUNTS -> Manifest.permission.GET_ACCOUNTS
    PERMISSION_READ_SMS -> Manifest.permission.READ_SMS
    PERMISSION_SEND_SMS -> Manifest.permission.SEND_SMS
    PERMISSION_READ_PHONE_STATE -> Manifest.permission.READ_PHONE_STATE
    PERMISSION_MEDIA_LOCATION -> if (isQPlus()) Manifest.permission.ACCESS_MEDIA_LOCATION else ""
    PERMISSION_POST_NOTIFICATIONS -> Manifest.permission.POST_NOTIFICATIONS
    PERMISSION_READ_MEDIA_IMAGES -> Manifest.permission.READ_MEDIA_IMAGES
    PERMISSION_READ_MEDIA_VIDEO -> Manifest.permission.READ_MEDIA_VIDEO
    PERMISSION_READ_MEDIA_AUDIO -> Manifest.permission.READ_MEDIA_AUDIO
    PERMISSION_ACCESS_COARSE_LOCATION -> Manifest.permission.ACCESS_COARSE_LOCATION
    PERMISSION_ACCESS_FINE_LOCATION -> Manifest.permission.ACCESS_FINE_LOCATION
    PERMISSION_READ_MEDIA_VISUAL_USER_SELECTED -> Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
    PERMISSION_READ_SYNC_SETTINGS -> Manifest.permission.READ_SYNC_SETTINGS
    else -> ""
}

fun Context.isPackageInstalled(packageName: String?): Boolean {
    val packageManager = packageManager
    val intent = packageManager.getLaunchIntentForPackage(packageName!!) ?: return false
    val list = packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)
    return !list.isEmpty()
}