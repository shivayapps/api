package messenger.chat.text.messages.sms.feature.personalize

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import com.bumptech.glide.Glide
import dagger.android.AndroidInjection
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.common.base.QkThemedActivity
import messenger.chat.text.messages.sms.common.util.extensions.viewBinding
import messenger.chat.text.messages.sms.commons.extensions.applyColorFilter
import messenger.chat.text.messages.sms.commons.extensions.baseConfig
import messenger.chat.text.messages.sms.commons.extensions.beGone
import messenger.chat.text.messages.sms.commons.extensions.beVisible
import messenger.chat.text.messages.sms.commons.extensions.getBackgroundDrawable
import messenger.chat.text.messages.sms.commons.extensions.updateTextColors
import messenger.chat.text.messages.sms.databinding.ActivityThemePreviewBinding

class ThemeImagePreviewActivity : QkThemedActivity() {

//    var imagePath: String = "";
    var imageResource: Int = -1
    var primary_color: Int = 0;
    var jasin: String = "";
    var c_name: String = "";
    var statusbarcolorcheck: Int = 0
//    private lateinit var bitmap: Bitmap

    private val binding by viewBinding(ActivityThemePreviewBinding::inflate)
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        showBackButton(true)
        setTitle(R.string.themes)

        setUI()
        setUpListener()
        binding.ivBack.setOnClickListener {
            onBackPressed()
        }

        setUpTheme()
    }
    private fun setUpTheme() {

        Log.e("MainActivity", "setUpTheme.useImageResource:${baseConfig.useImageResource}")
        Log.e("MainActivity", "setUpTheme.storedImageResource:${baseConfig.storedImageResource}")

        updateTextColors(binding.contentView)
        binding.toolbarTitle.setTextColor(baseConfig.primaryColor)

        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
            binding.contentView.background = ColorDrawable(resources.getColor(R.color.bottom_tabs_black_backgroundnew))
            arrayListOf(binding.ivBack).forEach {
                val colorStateList = ColorStateList.valueOf(Color.WHITE)
                it.imageTintList = colorStateList
            }
        } else {
            binding.contentView.background = ColorDrawable(baseConfig.backgroundColor)
            arrayListOf(binding.ivBack).forEach {
//                val whiteColor = ContextCompat.getColor(this, R.color.black)
                val colorStateList = ColorStateList.valueOf(Color.BLACK)
                it.imageTintList = colorStateList
            }
        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                Log.i("onCreate", "onCreateitemselse11111: ")
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.contentView.background = drawable
                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
            }
        } else {
            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
            toolbar.setBackgroundColor(baseConfig.backgroundColor)
        }

    }

    private fun setUI() {
        binding.cardBackground.beGone()
        binding.ivBackgroundImage.beVisible()
//        imagePath = intent.getStringExtra("imagePath").toString()
//        imageResource = intent.getIntExtra("imageResource",R.drawable.spring_bg)
        c_name = intent.getStringExtra("c_name").toString()
        imageResource=getBackgroundDrawable(c_name)

        Log.e("MainActivity","setUpTheme.ThemeImagePreview.c_name:${c_name}")
        Log.e("MainActivity","setUpTheme.ThemeImagePreview.imageResource:${imageResource}")

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.root.background = drawable
            }
        }

        if (c_name.equals("spring",true)) {
            statusbarcolorcheck = Color.parseColor("#E8FFED")
            primary_color = Color.parseColor("#00A11F")

            val applyBackground = ResourcesCompat.getDrawable(resources, R.drawable.button_background_rounded, getTheme()) as RippleDrawable
            (applyBackground as LayerDrawable).findDrawableByLayerId(R.id.button_background_holder).applyColorFilter(primary_color)
            binding.btnApply.background = applyBackground

            Glide.with(this)
                .load(R.drawable.spring)
                .into(binding.ivBackgroundImage)

        }
        else if (c_name.equals("autumn",true)) {
            statusbarcolorcheck = Color.parseColor("#FFF8F2")
            primary_color = Color.parseColor("#FF833E")
            val applyBackground = ResourcesCompat.getDrawable(resources, R.drawable.button_background_rounded, getTheme()) as RippleDrawable
            (applyBackground as LayerDrawable).findDrawableByLayerId(R.id.button_background_holder).applyColorFilter(primary_color)
            binding.btnApply.background = applyBackground
            Glide.with(this)
                .load(R.drawable.autumn)
                .into(binding.ivBackgroundImage)
        }
        else if (c_name.equals("summer",true)) {
            statusbarcolorcheck = Color.parseColor("#EDF9FF")
            primary_color = Color.parseColor("#0183C9")
            val applyBackground = ResourcesCompat.getDrawable(resources, R.drawable.button_background_rounded, getTheme()) as RippleDrawable
            (applyBackground as LayerDrawable).findDrawableByLayerId(R.id.button_background_holder).applyColorFilter(primary_color)
            binding.btnApply.background = applyBackground
            Glide.with(this)
                .load(R.drawable.summer)
                .into(binding.ivBackgroundImage)

        }
        else if (c_name.equals("winter",true)) {
            statusbarcolorcheck = Color.parseColor("#F0F6FF")
            primary_color = Color.parseColor("#3774FF")
            val applyBackground = ResourcesCompat.getDrawable(resources, R.drawable.button_background_rounded, getTheme()) as RippleDrawable
            (applyBackground as LayerDrawable).findDrawableByLayerId(R.id.button_background_holder).applyColorFilter(primary_color)
            binding.btnApply.background = applyBackground
            Glide.with(this)
                .load(R.drawable.winter)
                .into(binding.ivBackgroundImage)

        }

    }

    private fun setUpListener() {

        binding.btnApply.setOnClickListener {

            baseConfig.themenameuri=""

            baseConfig.apply {
                themenameuri = c_name
                checkprimaryColortheme = context.resources.getColor(R.color.white);

                baseConfig.statusBarColor = statusbarcolorcheck

//            Log.i("onCreatecolor", "onCreateimage: "+primary_color)
                primaryColortheme = primary_color
                primaryColor = primary_color
                storedImageResource = imageResource
                accentColor = Color.parseColor("#FFFFFF")
                backgroundColor = Color.parseColor("#FFFFFF")
                toolbarcolor = Color.parseColor("#00FFFFFF")
                customTextColor = Color.parseColor("#000000")
                customAppIconColor = Color.parseColor("#000000")
                textColor = Color.parseColor("#000000")
                customAccentColor = Color.parseColor("#FFFFFF")
                customPrimaryColor = Color.parseColor("#FFFFFF")

                useImageResource = true

                if (baseConfig.useImageResource) {
                    if (baseConfig.storedImageResource==-1) {

                    } else {
//                        val drawable = BitmapDrawable(resources, baseConfig.storedBitmap)
                        val drawable = ContextCompat.getDrawable(this@ThemeImagePreviewActivity, baseConfig.storedImageResource)
                        binding.contentView.background = drawable
                    }
                }
                updateTextColors(binding.contentView)
//                getProperBackgroundColor()
//                getColoredMaterialStatusBarColor()
//                getProperAccentColor()
//                setupToolbar(binding.customizationToolbar, NavigationIcon.Arrow, baseConfig.toolbarcolor)
//                binding.llbackgroundimg.setBackgroundColor(Color.parseColor("#FFFFFF"))

            }
            Toast.makeText(this, "The theme has been applied successfully", Toast.LENGTH_SHORT).show()
//            onBackPressed()
        }

    }

}