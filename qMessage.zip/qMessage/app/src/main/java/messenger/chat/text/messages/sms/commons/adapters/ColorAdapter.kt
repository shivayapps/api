package messenger.chat.text.messages.sms.commons.adapters

import android.content.Context
import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import messenger.chat.text.messages.sms.commons.extensions.baseConfig
import messenger.chat.text.messages.sms.commons.extensions.updateTextColors
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.common.widget.BabyTextView

class ColorAdapter(
    private val itemList: List<String>,
    private val colorList: List<Int>,
    private val context: Context,
    private val onItemClickListener: OnItemClickListener
) : RecyclerView.Adapter<ColorAdapter.MyViewHolder>() {

    private var selectedItemPosition: Int = RecyclerView.NO_POSITION

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_theme_layout, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.textViewItem.text = itemList[position]
        context.updateTextColors(holder.main)

        holder.llcolor.backgroundTintList= ColorStateList.valueOf(colorList[position % colorList.size])

        if (context.baseConfig.primaryColortheme.equals(colorList.get(position))){
            selectedItemPosition=position
        } else {

        }

        if (position == selectedItemPosition) {
            holder.ivMain.setImageDrawable(ContextCompat.getDrawable(holder.ivMain.context, R.drawable.ic_select))
        } else {
            holder.ivMain.setImageDrawable(ContextCompat.getDrawable(holder.ivMain.context, R.drawable.transparent_button))
        }

        holder.itemView.setOnClickListener {
            // Update the selected item position and notify changes
            val previousItemPosition = selectedItemPosition
            selectedItemPosition = holder.adapterPosition


            notifyItemChanged(previousItemPosition)
            notifyItemChanged(selectedItemPosition)

            onItemClickListener.onItemClick(position,colorList.get(position),itemList[position])
        }
    }

    override fun getItemCount(): Int = itemList.size

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textViewItem: BabyTextView = itemView.findViewById(R.id.textViewItem)
        val ivMain: ImageView = itemView.findViewById(R.id.ivMain)
        val main: ConstraintLayout = itemView.findViewById(R.id.main)
        val llcolor: View = itemView.findViewById(R.id.llColor)
    }

    interface OnItemClickListener {
        fun onItemClick(position: Int, color: Int, name: String)
    }
}
