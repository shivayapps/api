package messenger.chat.text.messages.sms.appmanager

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.app.Dialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.core.app.NotificationCompat
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.commons.extensions.updateTextColors


import android.app.Notification
import android.app.Service
import android.content.Context.WINDOW_SERVICE
import android.content.IntentFilter
import android.graphics.Color
import android.media.AudioManager
import android.provider.Settings
import android.view.*
import androidx.core.app.NotificationCompat.PRIORITY_MIN
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import messenger.chat.text.messages.sms.databinding.DialogAppInstallBinding
import messenger.chat.text.messages.sms.feature.main.SplashActivity

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Timer


class NewAppReceiver : BroadcastReceiver() {

    private lateinit var repository: AppRepository

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onReceive(context: Context?, intent: Intent) {
        if (context != null) {
//            db = AppDatabase.getDatabase(context)
            repository = AppRepository()

            val packageName = intent.data?.encodedSchemeSpecificPart
            val appName = repository.getAppName(context, packageName.toString())

//            Log.e("AppReceiver","intent.action-${intent.action}")
//            if (intent.action.equals(Intent.ACTION_PACKAGE_REMOVED)) {
//                Log.e("AppReceiver","Intent.ACTION_001")
//                // Delete name and icon
//                CoroutineScope(Dispatchers.IO).launch {
//                    if (packageName != null) {
//                        repository.deleteApp(packageName)
//                    }
//                }
//            } else if (intent.action.equals(Intent.ACTION_PACKAGE_ADDED)) {
//                Log.e("AppReceiver","Intent.ACTION_002")
//                // Add name and icon
//                CoroutineScope(Dispatchers.IO).launch {
//                    if (packageName != null) {
//                        repository.addApp(nameApp, packageName)
//                    }
//                }
//            }

            when (intent.action) {
                Intent.ACTION_PACKAGE_REMOVED -> {
//                    Log.e("AppReceiver","Intent.ACTION_003")
//                    Toast.makeText(
//                        context,
//                        context.getString(
//                            R.string.app_removed,
//                            nameApp
//                        ),
//                        Toast.LENGTH_LONG
//                    ).show()
                }

                Intent.ACTION_PACKAGE_ADDED -> {
//                    Log.e("AppReceiver","Intent.ACTION_004")
//                    Toast.makeText(
//                        context,
//                        context.getString(
//                            R.string.app_added,
//                            nameApp
//                        ),
//                        Toast.LENGTH_LONG
//                    ).show()
                }
            }

            if (intent.action.equals(Intent.ACTION_PACKAGE_ADDED)) {
//                Log.e("AppReceiver","Intent.ACTION_005")
                Handler(Looper.getMainLooper()).post {
//                    showDialog(context)
                    displayWindow(context,appName)
                }
//                showNotification(
//                    context,
//                    context.getString(R.string.title_notif_app_added),
//                    nameApp
//                )
            }
        }
    }
    private fun displayWindow(mContext: Context,appName:String) {
        val metrics = mContext.resources.displayMetrics

        val height = metrics.heightPixels
        windowManager = mContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
//        floatView = LayoutInflater.from(mContext).inflate(R.layout.overlay_layout, null)
        binding = DialogAppInstallBinding.inflate(LayoutInflater.from(mContext), null, false)

        val layoutFlag: Int =
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;

        floatWindowLayoutParam = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                or WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )

        if (isWindowShowing) {
            if (Settings.canDrawOverlays(mContext)) {
                windowManager?.removeViewImmediate(binding!!.root)
            }
        }


        floatWindowLayoutParam?.gravity =  Gravity.CENTER
//        floatWindowLayoutParam?.windowAnimations = R.style.enterAnim
        floatWindowLayoutParam?.x = 0
        floatWindowLayoutParam?.y = 0

        val animSlideIn = AnimatorSet()
        animSlideIn.playTogether(
            ObjectAnimator.ofFloat(binding!!.root, "translationX", 0f),
            ObjectAnimator.ofFloat(binding!!.root, "translationY", 0f)
        )
        animSlideIn.duration = 5000
        animSlideIn.start()


//        val dialogcancelButton: TextView = dialogView.findViewById(R.id.dialogcancelButton)
//        val buttondialogok: TextView = dialogView.findViewById(R.id.buttondialogok)
//        val dialogmain: LinearLayout = dialogView.findViewById(R.id.dialogmain)
//        val newAppDesc: TextView = dialogView.findViewById(R.id.newAppDesc)


        val message = mContext.getString(
            R.string.hint_new_app_install,
            appName)


        binding?.newAppDesc!!.setText(message)

        mContext.updateTextColors(binding?.dialogmain as ViewGroup)

        binding?.buttondialogok!!.setOnClickListener {
            val intent = Intent(mContext, FindAppActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            mContext.startActivity(intent)
            windowManager?.removeView(binding?.root)
            binding!!.root.visibility = View.GONE
        }
        binding?.dialogcancelButton!!.setOnClickListener {
            windowManager?.removeView(binding?.root)
            binding!!.root.visibility = View.GONE
        }


        val audioManager = mContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager

        windowManager?.let { window ->
            Log.d("TAG", "displayWindow: windowManager $windowManager")
            binding?.let {
                Log.d("TAG", "displayWindow: binding $binding")
                if (Settings.canDrawOverlays(mContext)) {
                    window.addView(
                        it.root,
                        floatWindowLayoutParam
                    )
                }

            }
        }

        //  windowManager?.addView(binding?.root, layoutParams)

        binding?.root?.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = floatWindowLayoutParam?.x!!
                    initialY = floatWindowLayoutParam?.y!!
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    // Calculate the X and Y coordinates of the view.
                    floatWindowLayoutParam?.x = (initialX + (event.rawX - initialTouchX)).toInt()
                    floatWindowLayoutParam?.y = (initialY + (event.rawY - initialTouchY)).toInt()

                    // Update the layout with new X and Y coordinates
                    windowManager?.updateViewLayout(binding?.root, floatWindowLayoutParam)
                    true
                }
                else -> false
            }
        }



    }
    private var initialTouchX = 0.0f
    private var initialTouchY = 0.0f
    private var initialX = 0
    private var initialY = 0




    companion object {
        @SuppressLint("StaticFieldLeak")
        var binding: DialogAppInstallBinding? = null

        @SuppressLint("StaticFieldLeak")
        var floatWindowLayoutParam: WindowManager.LayoutParams? = null
        var windowManager: WindowManager? = null
        var isWindowShowing: Boolean = false
//        var timer: Timer? = null
//        var seconds = 0
    }
    @RequiresApi(Build.VERSION_CODES.M)
    private fun showNotification(context: Context, title: String, nameApp: String) {

        // Create notification channel
        val mNotificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID_1,
                CH_ID,
                NotificationManager.IMPORTANCE_DEFAULT
            )
            channel.description = R.string.notif_description.toString()
            mNotificationManager.createNotificationChannel(channel)
        }

        // Create an explicit intent for an Activity
        val intent = Intent(context, SplashActivity::class.java)

        intent.putExtra(MSG_TEXT_KEY, nameApp)

        intent.action = MESSAGE_ACTION

        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP;

        val pendingIntent = PendingIntent.getActivity(context, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val message = context.getString(
            R.string.app_added_notification,
            nameApp)

        // Set the notification content
        val mBuilder = NotificationCompat.Builder(context, CHANNEL_ID_1)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setOngoing(true)

        // Show notification
        mNotificationManager.notify(NOTIFICATION_ID, mBuilder.build())
    }
}
