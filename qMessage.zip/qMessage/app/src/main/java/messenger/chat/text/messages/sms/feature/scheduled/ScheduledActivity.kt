package messenger.chat.text.messages.sms.feature.scheduled

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import com.jakewharton.rxbinding2.view.clicks
import messenger.chat.text.messages.sms.common.QkDialog
import messenger.chat.text.messages.sms.common.base.QkThemedActivity
import messenger.chat.text.messages.sms.common.util.FontProvider
import messenger.chat.text.messages.sms.common.util.extensions.setBackgroundTint
import messenger.chat.text.messages.sms.common.util.extensions.setTint
import messenger.chat.text.messages.sms.common.util.extensions.viewBinding
import dagger.android.AndroidInjection
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.commons.extensions.baseConfig
import messenger.chat.text.messages.sms.commons.extensions.updateTextColors
import messenger.chat.text.messages.sms.databinding.ScheduledActivityBinding
import javax.inject.Inject


class ScheduledActivity : QkThemedActivity(), ScheduledView {

    @Inject
    lateinit var dialog: QkDialog

    @Inject
    lateinit var fontProvider: FontProvider

    @Inject
    lateinit var messageAdapter: ScheduledMessageAdapter

    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory

    override val messageClickIntent by lazy { messageAdapter.clicks }
    override val messageMenuIntent by lazy { dialog.adapter.menuItemClicks }
    override val composeIntent by lazy { binding.compose.clicks() }

    private val binding by viewBinding(ScheduledActivityBinding::inflate)
    private val viewModel by lazy { ViewModelProviders.of(this, viewModelFactory)[ScheduledViewModel::class.java] }

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        setTitle(R.string.scheduled_title)
        showBackButton(true)
        viewModel.bindView(this)

        dialog.title = getString(R.string.scheduled_options_title)
        dialog.adapter.setData(R.array.scheduled_options)

        messageAdapter.emptyView = binding.empty
        binding.messages.adapter = messageAdapter

        colors.theme().let { theme ->
            binding.sampleMessage.setBackgroundTint(theme.theme)
            binding.sampleMessage.setTextColor(theme.textPrimary)
            binding.compose.setTint(theme.textPrimary)
            binding.compose.setBackgroundTint(theme.theme)
//            binding.upgrade.setBackgroundTint(theme.theme)
//            binding.upgradeIcon.setTint(theme.textPrimary)
//            binding.upgradeLabel.setTextColor(theme.textPrimary)
        }
        setUpTheme()

        binding.ivBack.setOnClickListener {
            onBackPressed()
        }

    }

    private fun setUpTheme() {

        Log.e("MainActivity", "setUpTheme.useImageResource:${baseConfig.useImageResource}")
        Log.e("MainActivity", "setUpTheme.storedImageResource:${baseConfig.storedImageResource}")

        updateTextColors(binding.contentView)
        binding.toolbarTitle.setTextColor(baseConfig.primaryColor)

        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
            binding.contentView.background = ColorDrawable(resources.getColor(R.color.bottom_tabs_black_backgroundnew))
            arrayListOf(binding.ivBack).forEach {
                val colorStateList = ColorStateList.valueOf(Color.WHITE)
                it.imageTintList = colorStateList
            }
        } else {
            binding.contentView.background = ColorDrawable(baseConfig.backgroundColor)
            arrayListOf(binding.ivBack).forEach {
//                val whiteColor = ContextCompat.getColor(this, R.color.black)
                val colorStateList = ColorStateList.valueOf(Color.BLACK)
                it.imageTintList = colorStateList
            }
        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                Log.i("onCreate", "onCreateitemselse11111: ")
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.contentView.background = drawable
                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
            }
        } else {
            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
            toolbar.setBackgroundColor(baseConfig.backgroundColor)
        }

    }

    override fun render(state: ScheduledState) {
        messageAdapter.updateData(state.scheduledMessages)
        binding.compose.isVisible = state.upgraded
//        binding.upgrade.isVisible = !state.upgraded
    }

    override fun showMessageOptions() {
        dialog.show(this)
    }

}