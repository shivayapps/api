package messenger.chat.text.messages.sms.manager

interface ReferralManager {

    suspend fun trackReferrer()

}
