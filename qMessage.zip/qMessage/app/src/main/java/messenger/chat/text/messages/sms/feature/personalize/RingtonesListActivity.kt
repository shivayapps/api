package messenger.chat.text.messages.sms.feature.personalize

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import dagger.android.AndroidInjection
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.common.base.QkThemedActivity
import messenger.chat.text.messages.sms.common.util.extensions.viewBinding
import messenger.chat.text.messages.sms.commons.adapters.RingtoneListAdapter
import messenger.chat.text.messages.sms.commons.extensions.baseConfig
import messenger.chat.text.messages.sms.commons.extensions.updateTextColors
import messenger.chat.text.messages.sms.databinding.ActivityBubbleBinding
import messenger.chat.text.messages.sms.databinding.ActivityRintoneListBinding

class RingtonesListActivity : QkThemedActivity() {


    private lateinit var adapter: RingtoneListAdapter
    var mp: MediaPlayer? = null
    var ringtoneuri: String = ""

    var list: MutableList<Array<String>> = ArrayList()

    private val binding by viewBinding(ActivityRintoneListBinding::inflate)
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        showBackButton(true)
        setTitle(R.string.ringtone)

        setUI()
        setUpTheme()
        setUpListener()
    }

    private fun setUpTheme() {

        Log.e("MainActivity", "setUpTheme.useImageResource:${baseConfig.useImageResource}")
        Log.e("MainActivity", "setUpTheme.storedImageResource:${baseConfig.storedImageResource}")

        updateTextColors(binding.contentView)
        binding.toolbarTitle.setTextColor(baseConfig.primaryColor)

        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
            binding.contentView.background = ColorDrawable(resources.getColor(R.color.bottom_tabs_black_backgroundnew))
            arrayListOf(binding.ivBack).forEach {
                val colorStateList = ColorStateList.valueOf(Color.WHITE)
                it.imageTintList = colorStateList
            }
        } else {
            binding.contentView.background = ColorDrawable(baseConfig.backgroundColor)
            arrayListOf(binding.ivBack).forEach {
//                val whiteColor = ContextCompat.getColor(this, R.color.black)
                val colorStateList = ColorStateList.valueOf(Color.BLACK)
                it.imageTintList = colorStateList
            }
        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                Log.i("onCreate", "onCreateitemselse11111: ")
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.contentView.background = drawable
                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
            }
        } else {
            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
            toolbar.setBackgroundColor(baseConfig.backgroundColor)
        }

    }

    private fun setUI() {

        val manager = RingtoneManager(this)
        manager.setType(RingtoneManager.TYPE_RINGTONE)
        val cursor = manager.getCursor()

        list=ArrayList()
        while (cursor.moveToNext()) {
            val notificationTitle = cursor.getString(RingtoneManager.TITLE_COLUMN_INDEX)
            println(notificationTitle)
            val notificationUri = cursor.getString(RingtoneManager.URI_COLUMN_INDEX) + "/" + cursor.getString(
                RingtoneManager.ID_COLUMN_INDEX)
            val checked = notificationUri
            list.add(arrayOf(checked.toString(), notificationTitle, notificationUri))
        }

        binding.rvRingtone.layoutManager= GridLayoutManager(this,2)

        adapter = RingtoneListAdapter(this@RingtonesListActivity,list){name,position->

            if (mp!=null){
                if (mp!!.isPlaying) mp!!.stop()
                mp = MediaPlayer.create(this@RingtonesListActivity, Uri.parse(list.get(position).get(2)))
                mp?.setLooping(false)
                mp?.start()


                ringtoneuri= Uri.parse(list.get(position).get(2)).toString();
                baseConfig.ringtoneUri=ringtoneuri
                Toast.makeText(this,"Ringtone applied successfully", Toast.LENGTH_SHORT).show()

            }else{
                mp = MediaPlayer.create(this@RingtonesListActivity, Uri.parse(list.get(position).get(2)))
                mp?.setLooping(false)
                mp?.start()

                ringtoneuri= Uri.parse(list.get(position).get(2)).toString();

                baseConfig.ringtoneUri=ringtoneuri
                Toast.makeText(this,"Ringtone applied successfully", Toast.LENGTH_SHORT).show()

            }
        }

        binding.rvRingtone.adapter=adapter

    }

    private fun setUpListener() {
        binding.ivBack.setOnClickListener {
            onBackPressed()
        }

    }


    override fun onBackPressed() {
        super.onBackPressed()
        if (mp != null) {
            if (mp!!.isPlaying) mp!!.stop()
        }
    }

    override fun onPause() {
        super.onPause()

        if (mp != null) {
            if (mp!!.isPlaying) mp!!.stop()
        }
    }

}