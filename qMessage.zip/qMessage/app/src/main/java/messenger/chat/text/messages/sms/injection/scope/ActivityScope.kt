package messenger.chat.text.messages.sms.injection.scope

import javax.inject.Scope

@Scope
annotation class ActivityScope
