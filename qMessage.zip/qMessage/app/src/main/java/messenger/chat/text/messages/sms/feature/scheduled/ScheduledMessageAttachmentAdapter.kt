package messenger.chat.text.messages.sms.feature.scheduled

import android.content.Context
import android.net.Uri
import android.view.ViewGroup
import messenger.chat.text.messages.sms.common.base.QkAdapter
import messenger.chat.text.messages.sms.common.base.QkViewHolder
import messenger.chat.text.messages.sms.util.GlideApp
import messenger.chat.text.messages.sms.databinding.ScheduledMessageImageListItemBinding
import javax.inject.Inject

class ScheduledMessageAttachmentAdapter @Inject constructor(
    private val context: Context
) : QkAdapter<Uri, ScheduledMessageImageListItemBinding>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QkViewHolder<ScheduledMessageImageListItemBinding> {
        return QkViewHolder(parent, ScheduledMessageImageListItemBinding::inflate).apply {
            binding.thumbnail.clipToOutline = true
        }
    }

    override fun onBindViewHolder(holder: QkViewHolder<ScheduledMessageImageListItemBinding>, position: Int) {
        val attachment = getItem(position)

        GlideApp.with(context).load(attachment).into(holder.binding.thumbnail)
    }

}