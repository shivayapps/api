package messenger.chat.text.messages.sms.injection.android

import messenger.chat.text.messages.sms.feature.backup.RestoreBackupService
import messenger.chat.text.messages.sms.injection.scope.ActivityScope
import messenger.chat.text.messages.sms.receiver.SendSmsReceiver
import messenger.chat.text.messages.sms.service.HeadlessSmsSendService
import dagger.Module
import dagger.android.ContributesAndroidInjector
import messenger.chat.text.messages.sms.service.AutoDeleteService

@Module
abstract class ServiceBuilderModule {

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindAutoDeleteService(): AutoDeleteService

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindHeadlessSmsSendService(): HeadlessSmsSendService

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindRestoreBackupService(): RestoreBackupService

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindSendSmsReceiver(): SendSmsReceiver

}
