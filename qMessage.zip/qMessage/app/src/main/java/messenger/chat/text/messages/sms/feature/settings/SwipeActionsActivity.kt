package messenger.chat.text.messages.sms.feature.settings

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import androidx.core.content.ContextCompat
import com.bluelinelabs.conductor.Conductor
import com.bluelinelabs.conductor.Router
import com.bluelinelabs.conductor.RouterTransaction
import messenger.chat.text.messages.sms.common.base.QkThemedActivity
import messenger.chat.text.messages.sms.common.util.extensions.viewBinding
import dagger.android.AndroidInjection
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.commons.extensions.baseConfig
import messenger.chat.text.messages.sms.commons.extensions.updateTextColors
import messenger.chat.text.messages.sms.databinding.ContainerActivityBinding
import messenger.chat.text.messages.sms.feature.settings.swipe.SwipeActionsController

class SwipeActionsActivity : QkThemedActivity() {

    private val binding by viewBinding(ContainerActivityBinding::inflate)
    private lateinit var router: Router

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
//        setSupportActionBar(binding.toolbar)
        setTitle(R.string.swipe_gestures)
//        showBackButton(true)

        router = Conductor.attachRouter(this, binding.container, savedInstanceState)
        if (!router.hasRootController()) {
            router.setRoot(RouterTransaction.with(SwipeActionsController()))
        }

        binding.ivBack.setOnClickListener {
            onBackPressed()
        }

        setUpTheme()

    }

    private fun setUpTheme() {

        Log.e("MainActivity", "setUpTheme.useImageResource:${baseConfig.useImageResource}")
        Log.e("MainActivity", "setUpTheme.storedImageResource:${baseConfig.storedImageResource}")

        updateTextColors(binding.contentView)
        binding.toolbarTitle.setTextColor(baseConfig.primaryColor)

        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
            binding.contentView.background = ColorDrawable(resources.getColor(R.color.bottom_tabs_black_backgroundnew))
            arrayListOf(binding.ivBack).forEach {
                val colorStateList = ColorStateList.valueOf(Color.WHITE)
                it.imageTintList = colorStateList
            }
        } else {
            binding.contentView.background = ColorDrawable(baseConfig.backgroundColor)
            arrayListOf(binding.ivBack).forEach {
//                val whiteColor = ContextCompat.getColor(this, R.color.black)
                val colorStateList = ColorStateList.valueOf(Color.BLACK)
                it.imageTintList = colorStateList
            }
        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                Log.i("onCreate", "onCreateitemselse11111: ")
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.contentView.background = drawable
                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
            }
        } else {
            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
            toolbar.setBackgroundColor(baseConfig.backgroundColor)
        }

    }

    override fun onBackPressed() {
        if (!router.handleBack()) {
            super.onBackPressed()
        }
    }

}