package messenger.chat.text.messages.sms.interactor

import messenger.chat.text.messages.sms.repository.BackupRepository
import io.reactivex.Flowable
import javax.inject.Inject

class PerformRestore @Inject constructor(
    private val backupRepo: BackupRepository
) : Interactor<String>() {

    override fun buildObservable(params: String): Flowable<*> {
        return Flowable.just(params)
            .doOnNext(backupRepo::performRestore)
    }

}
