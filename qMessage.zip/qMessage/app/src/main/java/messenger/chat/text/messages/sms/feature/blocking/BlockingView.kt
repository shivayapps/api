package messenger.chat.text.messages.sms.feature.blocking

import messenger.chat.text.messages.sms.common.base.QkViewContract
import io.reactivex.Observable

interface BlockingView : QkViewContract<BlockingState> {

//    val blockingManagerIntent: Observable<*>
    val blockedNumbersIntent: Observable<*>
    val blockedMessagesIntent: Observable<*>
    val dropClickedIntent: Observable<*>

//    fun openBlockingManager()
    fun openBlockedNumbers()
    fun openBlockedMessages()
}
