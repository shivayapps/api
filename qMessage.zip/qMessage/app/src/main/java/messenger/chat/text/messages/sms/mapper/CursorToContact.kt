package messenger.chat.text.messages.sms.mapper

import android.database.Cursor
import messenger.chat.text.messages.sms.model.Contact

interface CursorToContact : Mapper<Cursor, Contact> {

    fun getContactsCursor(): Cursor?

}