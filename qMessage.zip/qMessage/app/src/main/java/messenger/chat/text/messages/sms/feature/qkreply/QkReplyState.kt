package messenger.chat.text.messages.sms.feature.qkreply

import messenger.chat.text.messages.sms.compat.SubscriptionInfoCompat
import messenger.chat.text.messages.sms.model.Conversation
import messenger.chat.text.messages.sms.model.Message
import io.realm.RealmResults

data class QkReplyState(
    val hasError: Boolean = false,
    val threadId: Long = 0,
    val title: String = "",
    val expanded: Boolean = false,
    val data: Pair<Conversation, RealmResults<Message>>? = null,
    val remaining: String = "",
    val subscription: SubscriptionInfoCompat? = null,
    val canSend: Boolean = false
)