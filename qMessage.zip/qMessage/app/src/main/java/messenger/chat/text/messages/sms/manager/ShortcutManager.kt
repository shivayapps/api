package messenger.chat.text.messages.sms.manager

interface ShortcutManager {

    fun updateBadge()

    fun updateShortcuts()

}