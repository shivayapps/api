package messenger.chat.text.messages.sms.feature.compose.part

import android.content.Context
import android.view.Gravity
import android.widget.FrameLayout
import messenger.chat.text.messages.sms.common.base.QkViewHolder
import messenger.chat.text.messages.sms.common.util.Colors
import messenger.chat.text.messages.sms.common.util.extensions.resolveThemeColor
import messenger.chat.text.messages.sms.common.util.extensions.setBackgroundTint
import messenger.chat.text.messages.sms.common.util.extensions.setTint
import messenger.chat.text.messages.sms.extensions.isVCard
import messenger.chat.text.messages.sms.extensions.mapNotNull
import messenger.chat.text.messages.sms.feature.compose.BubbleUtils
import messenger.chat.text.messages.sms.model.Message
import messenger.chat.text.messages.sms.model.MmsPart
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.databinding.MmsVcardListItemBinding
import ezvcard.Ezvcard
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import javax.inject.Inject

class VCardBinder @Inject constructor(
    colors: Colors,
    private val context: Context
) : PartBinder<MmsVcardListItemBinding>(MmsVcardListItemBinding::inflate) {

    override var theme = colors.theme()

    override fun canBindPart(part: MmsPart) = part.isVCard()

    override fun bindPartInternal(
        holder: QkViewHolder<MmsVcardListItemBinding>,
        part: MmsPart,
        message: Message,
        canGroupWithPrevious: Boolean,
        canGroupWithNext: Boolean
    ) {
        BubbleUtils.getBubble(false, canGroupWithPrevious, canGroupWithNext, message.isMe())
            .let(holder.binding.vCardBackground::setBackgroundResource)

        holder.binding.root.setOnClickListener { clicks.onNext(part.id) }

        Observable.just(part.getUri())
            .map(context.contentResolver::openInputStream)
            .mapNotNull { inputStream -> inputStream.use { Ezvcard.parse(it).first() } }
            .subscribeOn(Schedulers.computation())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe { vcard -> holder.binding.name?.text = vcard.formattedName.value }

        val params = holder.binding.vCardBackground.layoutParams as FrameLayout.LayoutParams
        if (!message.isMe()) {
            holder.binding.vCardBackground.layoutParams = params.apply { gravity = Gravity.START }
            holder.binding.vCardBackground.setBackgroundTint(theme.theme)
            holder.binding.vCardAvatar.setTint(theme.textPrimary)
            holder.binding.name.setTextColor(theme.textPrimary)
            holder.binding.label.setTextColor(theme.textTertiary)
        } else {
            holder.binding.vCardBackground.layoutParams = params.apply { gravity = Gravity.END }
            holder.binding.vCardBackground.setBackgroundTint(holder.binding.root.context.resolveThemeColor(R.attr.bubbleColor))
            holder.binding.vCardAvatar.setTint(holder.binding.root.context.resolveThemeColor(android.R.attr.textColorSecondary))
            holder.binding.name.setTextColor(holder.binding.root.context.resolveThemeColor(android.R.attr.textColorPrimary))
            holder.binding.label.setTextColor(holder.binding.root.context.resolveThemeColor(android.R.attr.textColorTertiary))
        }
    }

}
