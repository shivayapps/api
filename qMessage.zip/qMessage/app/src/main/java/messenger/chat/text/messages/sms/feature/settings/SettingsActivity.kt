package messenger.chat.text.messages.sms.feature.settings

import android.os.Bundle
import com.bluelinelabs.conductor.Conductor
import com.bluelinelabs.conductor.Router
import com.bluelinelabs.conductor.RouterTransaction
import messenger.chat.text.messages.sms.common.base.QkThemedActivity
import messenger.chat.text.messages.sms.common.util.extensions.viewBinding
import dagger.android.AndroidInjection
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.databinding.ContainerActivityBinding

class SettingsActivity : QkThemedActivity() {

    private val binding by viewBinding(ContainerActivityBinding::inflate)
    private lateinit var router: Router

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        setTitle(R.string.title_settings)
        showBackButton(true)

        router = Conductor.attachRouter(this, binding.container, savedInstanceState)
        if (!router.hasRootController()) {
            router.setRoot(RouterTransaction.with(SettingsController()))
        }
    }

    override fun onBackPressed() {
        if (!router.handleBack()) {
            super.onBackPressed()
        }
    }

}