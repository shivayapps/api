package messenger.chat.text.messages.sms.migration

import android.content.Context
import messenger.chat.text.messages.sms.blocking.QksmsBlockingClient
import messenger.chat.text.messages.sms.common.util.extensions.versionCode
import messenger.chat.text.messages.sms.repository.ConversationRepository
import messenger.chat.text.messages.sms.util.Preferences
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import javax.inject.Inject

class QkMigration @Inject constructor(
    private val context: Context,
    private val conversationRepo: ConversationRepository,
    private val prefs: Preferences,
    private val qksmsBlockingClient: QksmsBlockingClient
) {

    fun performMigration() {
        GlobalScope.launch {
            prefs.version.set(context.versionCode)
        }
    }


}
