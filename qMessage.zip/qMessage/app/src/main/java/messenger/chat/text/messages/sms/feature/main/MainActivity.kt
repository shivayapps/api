package messenger.chat.text.messages.sms.feature.main

import android.Manifest
import android.animation.ObjectAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.PopupMenu
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.appcompat.view.ContextThemeWrapper
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.viewpager.widget.ViewPager
import com.google.android.material.appbar.AppBarLayout
import com.google.android.material.snackbar.Snackbar
import com.jakewharton.rxbinding2.view.clicks
import com.jakewharton.rxbinding2.widget.editorActions
import com.jakewharton.rxbinding2.widget.textChanges
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import dagger.android.AndroidInjection
import io.reactivex.Observable
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import io.realm.RealmResults
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.common.Navigator
import messenger.chat.text.messages.sms.common.base.QkThemedActivity
import messenger.chat.text.messages.sms.common.util.extensions.autoScrollToStart
import messenger.chat.text.messages.sms.common.util.extensions.dismissKeyboard
import messenger.chat.text.messages.sms.common.util.extensions.hideKeyboard
import messenger.chat.text.messages.sms.common.util.extensions.resolveThemeColor
import messenger.chat.text.messages.sms.common.util.extensions.scrapViews
import messenger.chat.text.messages.sms.common.util.extensions.setBackgroundTint
import messenger.chat.text.messages.sms.common.util.extensions.setTint
import messenger.chat.text.messages.sms.common.util.extensions.showKeyboard
import messenger.chat.text.messages.sms.common.util.extensions.viewBinding
import messenger.chat.text.messages.sms.common.widget.QkDialog
import messenger.chat.text.messages.sms.commons.extensions.addAlpha
import messenger.chat.text.messages.sms.commons.extensions.baseConfig
import messenger.chat.text.messages.sms.commons.extensions.beGone
import messenger.chat.text.messages.sms.commons.extensions.beVisible
import messenger.chat.text.messages.sms.commons.extensions.beVisibleIf
import messenger.chat.text.messages.sms.commons.extensions.config
import messenger.chat.text.messages.sms.commons.extensions.setItemColors
import messenger.chat.text.messages.sms.commons.extensions.updateTextColors
import messenger.chat.text.messages.sms.databinding.MainActivityBinding
import messenger.chat.text.messages.sms.extensions.Optional
import messenger.chat.text.messages.sms.feature.blocking.BlockingDialog
import messenger.chat.text.messages.sms.feature.compose.ComposeActivity
import messenger.chat.text.messages.sms.feature.compose.editing.PhoneNumberAction
import messenger.chat.text.messages.sms.feature.compose.editing.PhoneNumberPickerAdapter
import messenger.chat.text.messages.sms.feature.contacts.ContactsActivity.Companion.ChipsKey
import messenger.chat.text.messages.sms.feature.contacts.GroupsActivity
import messenger.chat.text.messages.sms.feature.conversations.ConversationItemTouchCallback
import messenger.chat.text.messages.sms.feature.conversations.ConversationsAdapter
import messenger.chat.text.messages.sms.feature.fragments.contact.AllContactFragment
import messenger.chat.text.messages.sms.feature.settings.NewSettingsActivity
import messenger.chat.text.messages.sms.feature.settings.SettingsActivity
import messenger.chat.text.messages.sms.model.ContactData
import messenger.chat.text.messages.sms.model.ContactGroup
import messenger.chat.text.messages.sms.model.Conversation
import messenger.chat.text.messages.sms.model.MessageEvent
import messenger.chat.text.messages.sms.model.REFRESH_ARCHIVE
import messenger.chat.text.messages.sms.model.REFRESH_CONTACT_GROUP
import messenger.chat.text.messages.sms.model.REFRESH_MESSAGE
import messenger.chat.text.messages.sms.model.SYNC_MESSAGE
import messenger.chat.text.messages.sms.model.THEME_CHANGED
import messenger.chat.text.messages.sms.model.UPDATE_ALL_CONTACT
import messenger.chat.text.messages.sms.repository.SyncRepository
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import javax.inject.Inject

class MainActivity : QkThemedActivity(), MainView {
    private val binding by viewBinding(MainActivityBinding::inflate)

    @Inject
    lateinit var blockingDialog: BlockingDialog

    @Inject
    lateinit var disposables: CompositeDisposable

    @Inject
    lateinit var navigator: Navigator

    @Inject
    lateinit var conversationsAdapter: ConversationsAdapter

    @Inject
    lateinit var drawerBadgesExperiment: DrawerBadgesExperiment

    @Inject
    lateinit var searchAdapter: SearchAdapter

    @Inject
    lateinit var itemTouchCallback: ConversationItemTouchCallback

    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory
    var contacts: List<ContactData>? = null
    var recentContacts: List<ContactData>? = null
    var contactGroups: List<ContactGroup>? = null
    override val onNewIntentIntent: Subject<Intent> = PublishSubject.create()
    override val activityResumedIntent: Subject<Boolean> = PublishSubject.create()
    override val queryConversationChangedIntent by lazy { binding.messageTab.toolbarSearch.textChanges() }
    override val composeIntent by lazy { binding.messageTab.compose.clicks() }

    //    override val drawerOpenIntent: Observable<Boolean> by lazy {
//        binding.drawerLayout
//            .drawerOpen(Gravity.START)
//            .doOnNext { dismissKeyboard() }
//    }
    override val homeIntent: Subject<Unit> = PublishSubject.create()
    override val navigationIntent: Observable<NavItem> by lazy {
        Observable.merge(
            listOf(
                backPressedSubject,
//                binding.ivSetting.clicks().map { NavItem.SETTINGS },
//                binding.drawer.inbox.clicks().map { NavItem.INBOX },
//                binding.messageTab.archived.clicks().map { NavItem.ARCHIVED },
//                binding.drawer.backup.clicks().map { NavItem.BACKUP },
//                binding.drawer.scheduled.clicks().map { NavItem.SCHEDULED },
//                binding.drawer.blocking.clicks().map { NavItem.BLOCKING },
//                binding.drawer.settings.clicks().map { NavItem.SETTINGS },
//                 binding.drawer.plus.clicks().map { NavItem.PLUS },
//                 binding.drawer.help.clicks().map { NavItem.HELP },
//                binding.drawer.invite.clicks().map { NavItem.INVITE }
            )
        )
    }
    override val optionsItemIntent: Subject<Int> = PublishSubject.create()

    //    override val dismissRatingIntent by lazy { binding.drawer.rateDismiss.clicks() }+
//    override val rateIntent by lazy { binding.drawer.rateOkay.clicks() }

    override val conversationsSelectedIntent by lazy { conversationsAdapter.selectionChanges }
    override val confirmDeleteIntent: Subject<List<Long>> = PublishSubject.create()
    override val swipeConversationIntent by lazy { itemTouchCallback.swipes }
    override val undoArchiveIntent: Subject<Unit> = PublishSubject.create()
    override val refreshArchive: Subject<Unit> = PublishSubject.create()

//    override val queryChangedIntent: Observable<CharSequence> by lazy { binding.contactTab.searchContact.textChanges() }
//    override val queryClearedIntent: Observable<*> by lazy { binding.contactTab.cancel.clicks() }
//    override val queryEditorActionIntent: Observable<Int> by lazy { binding.contactTab.searchContact.editorActions() }

    override val phoneNumberSelectedIntent: Subject<Optional<Long>> by lazy { phoneNumberAdapter.selectedItemChanges }
    override val phoneNumberActionIntent: Subject<PhoneNumberAction> = PublishSubject.create()
    override val composeItemPressedIntent: Subject<ContactData> = PublishSubject.create()
    override val composeItemLongPressedIntent: Subject<ContactData> = PublishSubject.create()

    override val setAsDefaultClick by lazy { binding.messageTab.snackbar.snackbarButton.clicks() }

    private val viewModel by lazy {
        ViewModelProviders.of(
            this,
            viewModelFactory
        )[MainViewModel::class.java]
    }
    private val itemTouchHelper by lazy { ItemTouchHelper(itemTouchCallback) }
    private val progressAnimator by lazy {
        ObjectAnimator.ofInt(
            binding.messageTab.syncing.syncingProgress,
            "progress",
            0,
            0
        )
    }
    private val backPressedSubject: Subject<NavItem> = PublishSubject.create()
    private var isSnackBarClosed = false

    @Inject
    lateinit var phoneNumberAdapter: PhoneNumberPickerAdapter
    private val phoneNumberDialog by lazy {
        QkDialog(this).apply {
            titleRes = R.string.compose_number_picker_title
            adapter = phoneNumberAdapter
            positiveButton = R.string.compose_number_picker_always
            positiveButtonListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.ALWAYS) }
            negativeButton = R.string.compose_number_picker_once
            negativeButtonListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.JUST_ONCE) }
            cancelListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.CANCEL) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
//        binding=MainActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)
        viewModel.bindView(this)
        onNewIntentIntent.onNext(intent)
//        setSupportActionBar(binding.messageTab.toolbar)
        setSupportActionBar(binding.toolbar)
        isHomeBackClick = false
        if (!EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().register(this)


        config.saveData("checkfirst", true)

        /*binding.messageTab.toolbar.setNavigationOnClickListener {
            dismissKeyboard()
            homeIntent.onNext(Unit)
        }*/
//        binding.navView.setOnNavigationItemSelectedListener { item ->
//            when (item.itemId) {
//                R.id.messageFragment -> {
//                    setTitle(R.string.messages)
//                    binding.viewFlipper.displayedChild = 0
////                    binding.navView.selectedItemId = R.id.messageFragment
//                    true
//                }
//
//                R.id.contactFragment -> {
//                    setTitle(R.string.contacts)
//                    binding.viewFlipper.displayedChild = 1
////                    binding.navView.selectedItemId = R.id.contactFragment
//                    true
//                }
//
//                R.id.personalizeFragment -> {
//                    setTitle(R.string.personalize)
//                    binding.viewFlipper.displayedChild = 2
////                    binding.navView.selectedItemId = R.id.personalizeFragment
//                    true
//                }
//
//                R.id.settingFragment -> {
//                    setTitle(R.string.settings)
//                    binding.viewFlipper.displayedChild = 3
////                    binding.navView.selectedItemId = R.id.settingFragment
//                    true
//                }
//
//                else -> false
//            }
//        }
        itemTouchCallback.adapter = conversationsAdapter
        conversationsAdapter.autoScrollToStart(binding.messageTab.recyclerView)

        // Don't allow clicks to pass through the drawer layout
//        binding.drawer.root.clicks().autoDisposable(scope()).subscribe()

        binding.messageTab.snackbar.llDefault.background = backgroundchange()
        binding.messageTab.snackbar.ivClose.setOnClickListener {
            isSnackBarClosed = true
            binding.messageTab.snackbar.root.isVisible = false
        }

        binding.ivSetting.setOnClickListener {
            settingDialog()
        }
        binding.ivBack.setOnClickListener {
            backPressedSubject.onNext(NavItem.BACK)
            setTitle(R.string.messages)
            showBackButton(false)
        }
        binding.ivSelect.setOnClickListener {
            conversationsAdapter.toggleSelectAll(true)
        }

        // Set the theme color tint to the recyclerView, progressbar, and FAB
        theme
            .autoDisposable(scope())
            .subscribe { theme ->
                // Set the color for the drawer icons
                val states = arrayOf(
                    intArrayOf(android.R.attr.state_activated),
                    intArrayOf(-android.R.attr.state_activated)
                )

                resolveThemeColor(android.R.attr.textColorSecondary)
                    .let { textSecondary ->
                        ColorStateList(
                            states,
                            intArrayOf(theme.theme, textSecondary)
                        )
                    }
                    .let { tintList ->
//                        binding.drawer.inboxIcon.imageTintList = tintList
                        binding.messageTab.archivedIcon.imageTintList = tintList
                    }

                // Miscellaneous views
//                listOf(binding.drawer.plusBadge1, binding.drawer.plusBadge2).forEach { badge ->
//                    badge.setBackgroundTint(theme.theme)
//                    badge.setTextColor(theme.textPrimary)
//                }
                binding.messageTab.syncing.syncingProgress?.progressTintList =
                    ColorStateList.valueOf(theme.theme)
                binding.messageTab.syncing.syncingProgress?.indeterminateTintList =
                    ColorStateList.valueOf(theme.theme)
                binding.messageTab.compose.setBackgroundTint(theme.theme)
                binding.messageTab.compose.setTint(theme.textPrimary)
            }

        setUpTheme()
//        initContactView()
        initListener()
    }


    private fun settingDialog() {
        if (isFinishing || isDestroyed) {
            return
        }
        var alertDialog: AlertDialog? = null
        val dialogBuilder = AlertDialog.Builder(this)
        val view = layoutInflater.inflate(R.layout.dialog_setting, null)

        dialogBuilder.setView(view)

        val rlTheme = view.findViewById<RelativeLayout>(R.id.rlTheme)
        val reSetting = view.findViewById<RelativeLayout>(R.id.reSetting)

        rlTheme.setOnClickListener {
            alertDialog?.dismiss()

        }
        reSetting.setOnClickListener {
            alertDialog?.dismiss()
            val intent = Intent(this, NewSettingsActivity::class.java)
            startActivity(intent)
        }

        alertDialog = dialogBuilder.create()
        alertDialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        if (alertDialog?.isShowing == false) {
            alertDialog.show()
        }
    }

    private fun setUpTheme() {

        Log.e("MainActivity", "setUpTheme.useImageResource:${baseConfig.useImageResource}")
        Log.e("MainActivity", "setUpTheme.storedImageResource:${baseConfig.storedImageResource}")
//        if (baseConfig.useImageResource){
//            if (baseConfig.storedImageResource==-1){
//
//            }else{
////                val bitmapDrawable = BitmapDrawable(resources, baseConfig.storedBitmap)
//                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
//                binding.mainLayout.background = drawable
//            }
//        }

        updateTextColors(binding.mainLayout)
        binding.toolbarTitle.setTextColor(baseConfig.primaryColor)

        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
            binding.mainLayout.background =
                ColorDrawable(resources.getColor(R.color.bottom_tabs_black_backgroundnew))
            binding.llBottomAction.background =
                ColorDrawable(resources.getColor(R.color.bottom_tabs_black_backgroundnew))
            arrayListOf(
                binding.ivBack,
                binding.ivDelete,
                binding.ivMore,
                binding.ivArchive,
                binding.ivRead,
                binding.ivBlock
            ).forEach {
//                val whiteColor = ContextCompat.getColor(this, R.color.white)
                val colorStateList = ColorStateList.valueOf(Color.WHITE)
                it.imageTintList = colorStateList
            }
        } else {
            binding.mainLayout.background = ColorDrawable(baseConfig.backgroundColor)
            binding.llBottomAction.background = ColorDrawable(baseConfig.statusBarColor)
            arrayListOf(
                binding.ivBack,
                binding.ivDelete,
                binding.ivMore,
                binding.ivArchive,
                binding.ivRead,
                binding.ivBlock
            ).forEach {
//                val whiteColor = ContextCompat.getColor(this, R.color.black)
                val colorStateList = ColorStateList.valueOf(Color.BLACK)
                it.imageTintList = colorStateList
            }
        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                Log.i("onCreate", "onCreateitemselse11111: ")

//                binding.navView.setBackgroundColor(baseConfig.backgroundColor)
//                val bitmapDrawable = BitmapDrawable(resources, baseConfig.storedBitmap)
//                constraintLayout.background = bitmapDrawable
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.mainLayout.background = drawable

                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))

//                val colorWithAlpha = baseConfig.primaryColor.addAlpha(0.8F)
//                binding.navView.background = ColorDrawable(colorWithAlpha)

                val unselectedColor =
                    ContextCompat.getColor(this, android.R.color.darker_gray) // Unselected color
                val states = arrayOf(
                    intArrayOf(android.R.attr.state_checked), // Selected state
                    intArrayOf(-android.R.attr.state_checked) // Unselected state
                )

                val primaryColor = Color.parseColor("#FFFFFF")
                val colors = intArrayOf(
                    primaryColor, // Color for selected state
                    primaryColor // Color for unselected state
                )

                val colorStateList = ColorStateList(states, colors)
//                binding.navView.itemIconTintList = colorStateList
//                binding.navView.setItemColors(primaryColor, primaryColor)
                Log.e("MainActivity", "setUpTheme.navView.001")
//                binding.navView.itemRippleColor = ColorStateList.valueOf(primaryColor.addAlpha(0.08F))
//                binding.navView.itemActiveIndicatorColor = ColorStateList.valueOf(primaryColor.addAlpha(0.12F))

            }
        } else {

            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
//            binding.navView.setBackgroundColor(baseConfig.backgroundColor)
//            lloptionmenu.setBackgroundColor(baseConfig.backgroundColor)
            toolbar.setBackgroundColor(baseConfig.backgroundColor)

            val unselectedColor =
                ContextCompat.getColor(this, android.R.color.darker_gray) // Unselected color
            val states = arrayOf(
                intArrayOf(android.R.attr.state_checked), // Selected state
                intArrayOf(-android.R.attr.state_checked) // Unselected state
            )
            val colors = intArrayOf(
                primaryColor, // Color for selected state
                unselectedColor // Color for unselected state
            )

            if (baseConfig.backgroundColor.equals(Color.BLACK)) {
                val primaryColortext = Color.parseColor("#FFFFFF")
//                val colorstext = intArrayOf(
//                    primaryColortext, // Color for selected state
//                    unselectedColor // Color for unselected state
//                )
//                val colorStateListtext = ColorStateList(states, colorstext)
//                binding.navView.itemTextColor = colorStateListtext

            } else {
                val primaryColortext = Color.parseColor("#000000")
                val colorstext = intArrayOf(
                    primaryColortext, // Color for selected state
                    unselectedColor // Color for unselected state
                )
                val colorStateListtext = ColorStateList(states, colorstext)
//                binding.navView.itemTextColor = colorStateListtext

            }

            val colorStateList = ColorStateList(states, colors)
//            binding.navView.itemIconTintList = colorStateList
//            binding.navView.setItemColors(primaryColor, unselectedColor)
            Log.e("MainActivity", "setUpTheme.navView.002")
//            binding.navView.itemRippleColor = ColorStateList.valueOf(primaryColor.addAlpha(0.08F))
//            binding.navView.itemActiveIndicatorColor = ColorStateList.valueOf(primaryColor.addAlpha(0.12F))
        }

    }

    private fun initListener() {
        binding.messageTab.archived.setOnClickListener {
            startActivity(Intent(this@MainActivity, ArchiveActivity::class.java))
        }
        binding.llDelete.setOnClickListener {
            optionsItemIntent.onNext(R.id.delete)
        }
        binding.llArchiveTab.setOnClickListener {
            optionsItemIntent.onNext(R.id.archive)
        }
        binding.llMarkRead.setOnClickListener {
            optionsItemIntent.onNext(R.id.read)
        }
        binding.llBlock.setOnClickListener {
            optionsItemIntent.onNext(R.id.block)
        }
        binding.llMore.setOnClickListener {
            Log.e("initListener", "rlMore.click")
            val wrapper = if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
                ContextThemeWrapper(this@MainActivity, R.style.CustomPopUpStyleblack)
            } else {
                ContextThemeWrapper(this@MainActivity, R.style.CustomPopUpStyle)
            }

            val popupMenu = PopupMenu(wrapper, binding.llMore)
            // Inflating popup menu from popup_menu.xml file
            popupMenu.menuInflater.inflate(R.menu.desktop_menu, popupMenu.menu)
            val menu = popupMenu.menu

//                menu.findItem(R.id.archive)?.isVisible = currentPage is Inbox && selectedConversations != 0
//                menu.findItem(R.id.read)?.isVisible = markRead && selectedConversations != 0
//                menu.findItem(R.id.block)?.isVisible = selectedConversations != 0
//                menu.findItem(R.id.delete)?.isVisible = selectedConversations != 0
            menu.findItem(R.id.unarchive)?.isVisible =
                currentPage is Archived && selectedConversations != 0
            menu.findItem(R.id.add)?.isVisible = addContact && selectedConversations != 0
            menu.findItem(R.id.pin)?.isVisible = markPinned && selectedConversations != 0
            menu.findItem(R.id.unpin)?.isVisible = !markPinned && selectedConversations != 0
            menu.findItem(R.id.unread)?.isVisible = !markRead && selectedConversations != 0
            menu.findItem(R.id.unread)?.isVisible = selectedConversations != 0

            Log.e("initListener", "unarchive:${menu.findItem(R.id.unarchive).isVisible}")
            Log.e("initListener", "add:${menu.findItem(R.id.add).isVisible}")
            Log.e("initListener", "pin:${menu.findItem(R.id.pin).isVisible}")
            Log.e("initListener", "unpin:${menu.findItem(R.id.unpin).isVisible}")
            Log.e("initListener", "unread:${menu.findItem(R.id.unread).isVisible}")

            popupMenu.setOnMenuItemClickListener { menuItem ->

                when (menuItem.itemId) {
                    R.id.unarchive -> {
                        optionsItemIntent.onNext(R.id.unarchive)
                    }

                    R.id.add -> {
                        optionsItemIntent.onNext(R.id.add)
                    }

                    R.id.pin -> {
                        optionsItemIntent.onNext(R.id.pin)
                    }

                    R.id.unpin -> {
                        optionsItemIntent.onNext(R.id.unpin)
                    }

                    R.id.unread -> {
                        optionsItemIntent.onNext(R.id.unread)
                    }
                }
                true
            }

            // Showing the popup menu
            Log.e("initListener", "popupMenu.show")
            popupMenu.show()
        }
    }

    fun backgroundchange(): GradientDrawable {
        val drawable = GradientDrawable()
        drawable.shape = GradientDrawable.RECTANGLE
        val colorWithOpacity = baseConfig?.primaryColor

        val colorWith20Opacity =
            colorWithOpacity?.let { ColorUtils.setAlphaComponent(it, 20) } // 51 is 20% of 255

//                val colorWith20Opacity = Color.argb(51, Color.red(colorWithOpacity), Color.green(colorWithOpacity), Color.blue(colorWithOpacity))
        if (colorWith20Opacity != null) {
            drawable.setColor(colorWith20Opacity)
        }
        val strokeWidthInDp = 1.0f
        val strokeWidthInPixels =
            (strokeWidthInDp * resources?.displayMetrics!!.density + 0.5f).toInt()
        baseConfig?.let { drawable.setStroke(strokeWidthInPixels, it.primaryColor) }
        val cornerRadius = resources?.getDimension(R.dimen.normal_text_size)
        if (cornerRadius != null) {
            drawable.cornerRadius = cornerRadius
        }
        return drawable
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent?.run(onNewIntentIntent::onNext)
    }

    var addContact = false
    var markPinned = false
    var markRead = false
    var selectedConversations = 0
    var currentPage: MainPage = Inbox()
    override fun render(state: MainState) {
        if (state.hasError) {
            Log.e("render", "MainActivity:render.hasError:${state.hasError}")
            finish()
            return
        }
        if (state.selectedContact != null && !phoneNumberDialog.isShowing) {
            phoneNumberAdapter.data = state.selectedContact.numbers
            phoneNumberDialog.subtitle = state.selectedContact.name
            phoneNumberDialog.show()
        } else if (state.selectedContact == null && phoneNumberDialog.isShowing) {
            phoneNumberDialog.dismiss()
        }
        currentPage = state.page
        addContact = when (state.page) {
            is Inbox -> state.page.addContact
            is Archived -> state.page.addContact
            else -> false
        }

        markPinned = when (state.page) {
            is Inbox -> state.page.markPinned
            is Archived -> state.page.markPinned
            else -> true
        }

        markRead = when (state.page) {
            is Inbox -> state.page.markRead
            is Archived -> state.page.markRead
            else -> true
        }

        selectedConversations = when (state.page) {
            is Inbox -> state.page.selected
            is Archived -> state.page.selected
            else -> 0
        }

//        binding.toolbarSearch.setVisible(state.page is Inbox && state.page.selected == 0 || state.page is Searching)
//        binding.toolbarTitle.setVisible(binding.toolbarSearch.visibility != View.VISIBLE)
//        binding.toolbar.menu.findItem(R.id.selectAll)?.isVisible = selectedConversations != 0
        binding.ivSelect.beVisibleIf(selectedConversations != 0)

//        binding.toolbar.menu.findItem(R.id.unarchive)?.isVisible = state.page is Archived && selectedConversations != 0
//        binding.toolbar.menu.findItem(R.id.archive)?.isVisible = state.page is Inbox && selectedConversations != 0
//        binding.toolbar.menu.findItem(R.id.delete)?.isVisible = selectedConversations != 0
//        binding.toolbar.menu.findItem(R.id.add)?.isVisible = addContact && selectedConversations != 0
//        binding.toolbar.menu.findItem(R.id.pin)?.isVisible = markPinned && selectedConversations != 0
//        binding.toolbar.menu.findItem(R.id.unpin)?.isVisible = !markPinned && selectedConversations != 0
//        binding.toolbar.menu.findItem(R.id.read)?.isVisible = markRead && selectedConversations != 0
//        binding.toolbar.menu.findItem(R.id.unread)?.isVisible = !markRead && selectedConversations != 0
//        binding.toolbar.menu.findItem(R.id.block)?.isVisible = selectedConversations != 0

//        listOf(binding.drawer.plusBadge1, binding.drawer.plusBadge2).forEach { badge ->
//            badge.isVisible = drawerBadgesExperiment.variant && !state.upgraded
//        }
//        plus.isVisible = state.upgraded
//        binding.drawer.plusBanner.isVisible = !state.upgraded
//        binding.drawer.rateLayout.setVisible(state.showRating)

//        binding.compose.setVisible(state.page is Inbox || state.page is Archived)
        conversationsAdapter.emptyView =
            binding.messageTab.empty.takeIf { state.page is Inbox || state.page is Archived }
        searchAdapter.emptyView = binding.messageTab.empty.takeIf { state.page is Searching }

        when (state.page) {
            is Inbox -> {
//                binding.messageTab.llArchive.isVisible = (state.page.archiveMessages ?: 0) > 0
//                binding.messageTab.llArchive.layoutParams = CoordinatorLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
//                binding.messageTab.llArchive.layoutParams.height = 0
                val params =
                    binding.messageTab.recyclerView.layoutParams as CoordinatorLayout.LayoutParams
                if ((state.page.archiveMessages ?: 0) > 0) {
                    if (!binding.messageTab.llArchive.isVisible) {
                        binding.messageTab.llArchive.isVisible = true
                        params.behavior = AppBarLayout.ScrollingViewBehavior()
                        binding.messageTab.coordinatorLayout.requestLayout()
                    }

                } else {
                    if (binding.messageTab.llArchive.isVisible) {
                        binding.messageTab.llArchive.isVisible = false
                        params.behavior = null
                        binding.messageTab.coordinatorLayout.requestLayout()
                    }

                }

                binding.messageTab.archiveCount.text = state.page.archiveMessages.toString()
                binding.messageTab.compose.beVisible()
//                binding.navView.beVisible()
//                showBackButton(false)
//                binding.messageTab.toolbar.setNavigationIcon(null)
//                title = getString(R.string.main_title_selected, state.page.selected)
//                setTitle(getString(R.string.main_title_selected, state.page.selected))
                if (state.page.selected > 0) {
//                    setTitle(getString(R.string.main_title_selected, state.page.selected))
                    binding.actionbarTitle.text =
                        getString(R.string.main_title_selected, state.page.selected)

                    setCommonData(
                        showBottomAction = true
                    )
                } else {
                    setCommonData(
                        showBottomAction = false
                    )
                    setTitle(getString(R.string.messages))
//                    showBackButton(false)
                }
                setConversationAdapter(
                    state.page.data,
                    state.page.selected > 0,
                    R.string.inbox_empty_text,
                    true
                )
                Log.e("MainActivity", "render: Inbox ${state.page.data}")
                Log.e("MainActivity", "render: archiveMessages ${state.page.archiveMessages}")
            }

            is Searching -> {
//                showBackButton(false)
//                binding.messageTab.toolbar.setNavigationIcon(null)
                if (binding.messageTab.recyclerView.adapter !== searchAdapter) binding.messageTab.recyclerView.adapter =
                    searchAdapter
                searchAdapter.data = state.page.data ?: listOf()
                itemTouchHelper.attachToRecyclerView(null)
                binding.messageTab.empty.setText(R.string.inbox_search_empty_text)
            }

            is Archived -> {
//                binding.messageTab.llArchive.layoutParams.height = 0
                binding.messageTab.llArchive.beGone()
                binding.messageTab.compose.beGone()
//                binding.navView.beGone()
//                title = when (state.page.selected != 0) {
//                    true -> getString(R.string.main_title_selected, state.page.selected)
//                    false -> getString(R.string.title_archived)
//                }
                when (state.page.selected != 0) {
                    true -> {
//                        getString(R.string.main_title_selected, state.page.selected)
                        setCommonData(
                            showBottomAction = true
                        )
//                        setTitle(getString(R.string.main_title_selected, state.page.selected))
                        binding.actionbarTitle.text =
                            getString(R.string.main_title_selected, state.page.selected)
                    }

                    false -> {
                        setCommonData(
                            showBottomAction = false
                        )
                        setTitle(getString(R.string.title_archived))
                    }
                }
                setConversationAdapter(state.page.data, true, R.string.archived_empty_text, false)
            }

            else -> {}
        }
        when (state.contact) {
            is ContactPage -> {
                Log.e("fetchContact", "fetchContact: composeItems ${state.composeItems.size}")
                Log.e(
                    "fetchContact",
                    "fetchContact: composeRecentItems ${state.composeRecentItems.size}"
                )
                Log.e("fetchContact", "fetchContact: contactGroups ${state.composeGroupItems.size}")
                contacts = ArrayList(state.composeItems ?: ArrayList())
                recentContacts = ArrayList(state.composeRecentItems ?: ArrayList())
                contactGroups = ArrayList(state.composeGroupItems ?: ArrayList())
                EventBus.getDefault().post(MessageEvent(UPDATE_ALL_CONTACT))
            }

            else -> {}
        }

//        binding.drawer.inbox.isActivated = state.page is Inbox
//        if (binding.drawerLayout.isDrawerOpen(GravityCompat.START) && !state.drawerOpen) {
//            binding.drawerLayout.closeDrawer(GravityCompat.START)
//        } else if (!binding.drawerLayout.isDrawerVisible(GravityCompat.START) && state.drawerOpen) {
//            binding.drawerLayout.openDrawer(GravityCompat.START)
//        }

        when (state.syncing) {
            is SyncRepository.SyncProgress.Idle -> {
                binding.messageTab.syncing.root.isVisible = false
                if (!isSnackBarClosed) {
                    binding.messageTab.snackbar.root.isVisible =
                        !state.defaultSms || !state.smsPermission || !state.contactPermission || !state.notificationPermission
                }
            }

            is SyncRepository.SyncProgress.Running -> {
                binding.messageTab.syncing.root.isVisible = true
                binding.messageTab.syncing.syncingProgress.max = state.syncing.max
                progressAnimator.apply {
                    setIntValues(
                        binding.messageTab.syncing.syncingProgress.progress,
                        state.syncing.progress
                    )
                }.start()
                binding.messageTab.syncing.syncingProgress.isIndeterminate =
                    state.syncing.indeterminate
                binding.messageTab.snackbar.root.isVisible = false
            }
        }

        when {
            !state.defaultSms -> {
                binding.messageTab.snackbar.snackbarTitle?.setText(R.string.main_default_sms_title)
                binding.messageTab.snackbar.snackbarMessage?.setText(R.string.main_default_sms_message)
                binding.messageTab.snackbar.snackbarButton?.setText(R.string.set_now)
            }

            !state.smsPermission -> {
                binding.messageTab.snackbar.snackbarTitle?.setText(R.string.main_permission_required)
                binding.messageTab.snackbar.snackbarMessage?.setText(R.string.main_permission_sms)
                binding.messageTab.snackbar.snackbarButton?.setText(R.string.main_permission_allow)
            }

            !state.contactPermission -> {
                binding.messageTab.snackbar.snackbarTitle?.setText(R.string.main_permission_required)
                binding.messageTab.snackbar.snackbarMessage?.setText(R.string.main_permission_contacts)
                binding.messageTab.snackbar.snackbarButton?.setText(R.string.main_permission_allow)
            }

            !state.notificationPermission -> {
                binding.messageTab.snackbar.snackbarTitle?.setText(R.string.main_permission_required)
                binding.messageTab.snackbar.snackbarMessage?.setText(R.string.main_permission_notifications)
                binding.messageTab.snackbar.snackbarButton?.setText(R.string.main_permission_allow)
            }
        }
    }


    private fun setCommonData(
        showBottomAction: Boolean
    ) {

        if (showBottomAction) {
            binding.mainToolbar.beGone()
            binding.actionToolbar.beVisible()
            binding.llBottomAction.beVisible()
//            binding.navView.beGone()
        } else {
            binding.mainToolbar.beVisible()
            binding.actionToolbar.beGone()
            binding.llBottomAction.beGone()
//            binding.navView.beVisible()
        }
    }

    private fun setConversationAdapter(
        data: RealmResults<Conversation>?,
        backVisible: Boolean,
        inboxEmptyText: Int,
        isTouchHelper: Boolean
    ) {
        if (binding.messageTab.recyclerView.adapter !== conversationsAdapter) {
            binding.messageTab.recyclerView.apply {
                adapter = conversationsAdapter
            }
        }
        conversationsAdapter.updateData(data)
        itemTouchHelper.attachToRecyclerView(if (isTouchHelper) if (backVisible) null else binding.messageTab.recyclerView else null)
        binding.messageTab.empty.text = resources.getString(inboxEmptyText)
        binding.messageTab.recyclerView.post {
            if (conversationsAdapter.data?.isNotEmpty() ?: false) {
                binding.messageTab.empty.visibility = View.GONE
            } else {
                binding.messageTab.empty.visibility = View.VISIBLE
            }
        }
        showBackButton(backVisible)
    }

    override fun onResume() {
        super.onResume()
        activityResumedIntent.onNext(true)
    }

    override fun onPause() {
        super.onPause()
        activityResumedIntent.onNext(false)
    }

    override fun onDestroy() {
        super.onDestroy()
        disposables.dispose()
        if (EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().unregister(this)
    }

    override fun setTitle(titleId: Int) {
        //super.setTitle(titleId)
        binding.toolbarTitle.text = getString(titleId)
    }

    override fun setTitle(title: CharSequence?) {
        ///super.setTitle(title)
        binding.toolbarTitle.text = title
    }

    override fun showBackButton(show: Boolean) {

        if (show) {
            binding.mainToolbar.beGone()
            binding.actionToolbar.beVisible()
            binding.llBottomAction.beVisible()
//            binding.navView.beGone()
        } else {
            binding.mainToolbar.beVisible()
            binding.actionToolbar.beGone()
            binding.llBottomAction.beGone()
//            binding.navView.beVisible()
        }
//        super.showBackButton(show)
    }

    override fun requestDefaultSms() {
        navigator.showDefaultSmsDialog(this@MainActivity)
    }

    override fun requestPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.READ_SMS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CONTACTS
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions += Manifest.permission.POST_NOTIFICATIONS
        }

        ActivityCompat.requestPermissions(this, permissions.toTypedArray(), 0)
    }

    override fun clearSearch() {
        dismissKeyboard()
        binding.messageTab.toolbarSearch.text = null
    }

    override fun clearSelection() {
        conversationsAdapter.clearSelection()
    }

//    override fun onBackPressedFromArchive() {
//        backPressedSubject.onNext(NavItem.BACK)
//    }

    override fun themeChanged() {
        binding.messageTab.recyclerView.scrapViews()
        EventBus.getDefault().post(MessageEvent(THEME_CHANGED))
    }

    override fun showBlockingDialog(conversations: List<Long>, block: Boolean) {
        blockingDialog.show(this, conversations, block)
    }

    override fun showDeleteDialog(conversations: List<Long>) {
        val count = conversations.size
        AlertDialog.Builder(this)
            .setTitle(R.string.dialog_delete_title)
            .setMessage(resources.getQuantityString(R.plurals.dialog_delete_message, count, count))
            .setPositiveButton(R.string.button_delete) { _, _ ->
                confirmDeleteIntent.onNext(
                    conversations
                )
            }
            .setNegativeButton(R.string.button_cancel, null)
            .show()
    }


    override fun showArchivedSnackbar() {
        Snackbar.make(binding.messageTab.root, R.string.toast_archived, Snackbar.LENGTH_LONG)
            .apply {
                setAction(R.string.button_undo) { undoArchiveIntent.onNext(Unit) }
                setActionTextColor(colors.theme().theme)
                show()
                addCallback(object : Snackbar.Callback() {
                    override fun onDismissed(transientBottomBar: Snackbar?, event: Int) {
                        super.onDismissed(transientBottomBar, event)
                        refreshArchive.onNext(Unit)
                    }
                })
            }
    }

    //    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
//        menuInflater.inflate(R.menu.main, menu)
//        return super.onCreateOptionsMenu(menu)
//    }
//
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                backPressedSubject.onNext(NavItem.BACK)
                setTitle(R.string.messages)
                showBackButton(false)
                true
            }

//            R.id.selectAll -> {
//                conversationsAdapter.toggleSelectAll(true)
////                backPressedSubject.onNext(NavItem.BACK)
////                setTitle(R.string.messages)
////                showBackButton(false)
//                true
//            }

            else -> {
                optionsItemIntent.onNext(item.itemId)
                return true
            }
        }

    }

    override fun onBackPressed() {
        if (conversationsAdapter.isSelection()) {
            backPressedSubject.onNext(NavItem.BACK)
            setTitle(R.string.messages)
            showBackButton(false)
        } else {
            backPressedSubject.onNext(NavItem.BACK)
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        when (event.type) {
            REFRESH_MESSAGE -> {
                Log.e("onMessageEvent", "REFRESH_MESSAGE")
                viewModel.refreshMessages()
            }

            REFRESH_CONTACT_GROUP -> {
//                binding.contactTab.cancel.performClick()
            }

            THEME_CHANGED -> {
                binding.messageTab.recyclerView.scrapViews()
            }

            SYNC_MESSAGE -> {
                Log.e("onMessageEvent", "SYNC_MESSAGE")
                viewModel.forceRefreshMessages()
            }

            REFRESH_ARCHIVE -> {
                Log.e("onMessageEvent", "REFRESH_ARCHIVE")
                refreshArchive()
            }
        }

    }

    override fun clearQuery() {
//        binding.contactTab.searchContact.text = null
    }

    override fun refreshArchive() {
        refreshArchive.onNext(Unit)
    }

    override fun openKeyboard() {
//        binding.contactTab.searchContact.postDelayed({
//            binding.contactTab.searchContact.showKeyboard()
//        }, 200)
    }

    override fun finish(result: HashMap<String, String?>) {
//        binding.contactTab.searchContact.hideKeyboard()
        val intent =
            Intent(this@MainActivity, ComposeActivity::class.java).putExtra(ChipsKey, result)
        startActivity(intent)
//        finish()
    }

    fun onContactClick(contact: ContactData) {
        composeItemPressedIntent.onNext(contact)
    }

    fun onContactLongClick(contact: ContactData) {
        composeItemLongPressedIntent.onNext(contact)
    }

    fun onContactGroupClick(contact: ContactGroup) {
        startActivity(
            Intent(this, GroupsActivity::class.java).putExtra("groupId", contact.id)
                .putExtra("groupName", contact.title)
        )
    }

    fun onContactGroupLongClick(contact: ContactGroup) {
    }

//    private fun initContactView() {
//        val adapter = ViewPagerAdapter(this, supportFragmentManager)
////        adapter.addFragment(RecentContactFragment())
//        adapter.addFragment(AllContactFragment())
////        adapter.addFragment(ContactGroupFragment())
//
////        binding.contactTab.viewPager.offscreenPageLimit = 3
////        binding.contactTab.viewPager.adapter = adapter
////        binding.contactTab.loutTab.beGone()
//
//        val drawable = GradientDrawable()
//        drawable.shape = GradientDrawable.RECTANGLE
//        val colorWithOpacity = baseConfig?.primaryColor
//
//        val colorWith20Opacity =
//            colorWithOpacity?.let { ColorUtils.setAlphaComponent(it, 20) } // 51 is 20% of 255
//        if (colorWith20Opacity != null) {
//            drawable.setColor(colorWith20Opacity)
//        }
//        val strokeWidthInDp = 1.5f
//        val strokeWidthInPixels =
//            (strokeWidthInDp * resources?.displayMetrics!!.density + 0.5f).toInt()
//        baseConfig.let { drawable.setStroke(strokeWidthInPixels, it.primaryColor) }
//        val cornerRadius = resources?.getDimension(R.dimen.normal_text_size)
//        if (cornerRadius != null) {
//            drawable.cornerRadius = cornerRadius
//        }
//
//        binding.contactTab.loutTab.tabIndicator.indicatorDrawable = drawable
//        binding.contactTab.loutTab.apply {
//            observeIndexChange { fromIndex, toIndex, reselect, fromUser ->
//                binding.contactTab.viewPager.currentItem = toIndex
//            }
//            tabLayoutConfig?.tabDeselectColor = baseConfig.textColor
//            tabLayoutConfig?.tabSelectColor = baseConfig.textColor
//        }
//
//        binding.contactTab.viewPager.addOnPageChangeListener(object :
//            ViewPager.OnPageChangeListener {
//            override fun onPageScrolled(
//                position: Int,
//                positionOffset: Float,
//                positionOffsetPixels: Int
//            ) {
//
//            }
//
//            override fun onPageSelected(position: Int) {
//                binding.contactTab.loutTab.onPageSelected(position)
//
//            }
//
//            override fun onPageScrollStateChanged(state: Int) {
//
//            }
//        })
//    }

//    class ViewPagerAdapter(val activity: Activity, fm: FragmentManager) :
//        FragmentStatePagerAdapter(fm) {
//
//        private val fragments = mutableListOf<Fragment>()
//
//
//        fun addFragment(fragment: Fragment) {
//            fragments.add(fragment)
//            notifyDataSetChanged()
//        }
//
//        override fun getCount(): Int {
//            return fragments.size
//        }
//
//        override fun getItem(position: Int): Fragment {
//            return fragments[position]
//        }
//    }

}
