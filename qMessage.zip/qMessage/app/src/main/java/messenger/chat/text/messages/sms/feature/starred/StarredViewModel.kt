package messenger.chat.text.messages.sms.feature.starred

import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import messenger.chat.text.messages.sms.common.Navigator
import messenger.chat.text.messages.sms.common.base.QkViewModel
import messenger.chat.text.messages.sms.manager.PermissionManager
import messenger.chat.text.messages.sms.repository.StarredMessageRepository

import javax.inject.Inject

class StarredViewModel @Inject constructor(
    private val navigator: Navigator,
    scheduledMessageRepo: StarredMessageRepository,
    private val permissionManager: PermissionManager
) : QkViewModel<StarredMessagesView, StarredMessagesState>(
    StarredMessagesState(
        data = scheduledMessageRepo.getStarredMessages()
    )
) {
    override fun bindView(view: StarredMessagesView) {
        super.bindView(view)
        view.conversationClicks
            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
            .autoDisposable(view.scope())
            .subscribe { it-> navigator.showConversation(it.threadId, null,it.id) }
    }
}