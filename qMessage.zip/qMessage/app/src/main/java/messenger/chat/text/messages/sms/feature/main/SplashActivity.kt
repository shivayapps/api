package messenger.chat.text.messages.sms.feature.main

import android.content.Intent
import android.os.Bundle
import android.util.Log
import com.bluelinelabs.conductor.Conductor
import com.bluelinelabs.conductor.Router
import com.bluelinelabs.conductor.RouterTransaction
import messenger.chat.text.messages.sms.common.base.QkThemedActivity
import messenger.chat.text.messages.sms.common.util.extensions.viewBinding
import dagger.android.AndroidInjection
import messenger.chat.text.messages.sms.commons.extensions.baseConfig
import messenger.chat.text.messages.sms.commons.extensions.config
import messenger.chat.text.messages.sms.databinding.ContainerActivityBinding
import messenger.chat.text.messages.sms.manager.PermissionManager
import messenger.chat.text.messages.sms.manager.PermissionManagerImpl
import java.util.Locale

class SplashActivity : QkThemedActivity() {

//    private val binding by viewBinding(ContainerActivityBinding::inflate)
//    private lateinit var router: Router

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        launchHomeScreen()
    }

    private fun launchHomeScreen() {
        val cCodeDefault = Locale.getDefault().language
        baseConfig.checkpage=0
        if(config.getBooleanData("checkfirst")==false){
            if (!PermissionManagerImpl(this@SplashActivity).isDefaultSms() || !PermissionManagerImpl(
                    this@SplashActivity
                ).hasReadSms() || !PermissionManagerImpl(
                    this@SplashActivity
                ).hasContacts()
            ) {
                startActivity(Intent(this, PermissionActivity::class.java))
                finish()
            } else {
                Log.e("getConversations", "getConversations.launchHomeScreen.001")
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            }
        }else{
            Log.e("getConversations", "getConversations.launchHomeScreen.002")
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
//        }
    }


}