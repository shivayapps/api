
package messenger.chat.text.messages.sms.feature.backup

import android.content.Context
import android.text.format.Formatter
import android.view.ViewGroup
import messenger.chat.text.messages.sms.common.base.FlowableAdapter
import messenger.chat.text.messages.sms.common.base.QkViewHolder
import messenger.chat.text.messages.sms.common.util.DateFormatter
import messenger.chat.text.messages.sms.model.BackupFile
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.databinding.BackupListItemBinding
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import javax.inject.Inject

class BackupAdapter @Inject constructor(
    private val context: Context,
    private val dateFormatter: DateFormatter
) : FlowableAdapter<BackupFile, BackupListItemBinding>() {

    val backupSelected: Subject<BackupFile> = PublishSubject.create()
    val deleteSelected: Subject<BackupFile> = PublishSubject.create()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QkViewHolder<BackupListItemBinding> {
        return QkViewHolder(parent, BackupListItemBinding::inflate).apply {
            binding.root.setOnClickListener { backupSelected.onNext(getItem(adapterPosition)) }
            binding.delete.setOnClickListener {
                deleteSelected.onNext(getItem(adapterPosition))
            }
        }
    }

    override fun onBindViewHolder(holder: QkViewHolder<BackupListItemBinding>, position: Int) {
        val backup = getItem(position)
        val count = backup.messages

        holder.binding.title.text = dateFormatter.getDetailedTimestamp(backup.date)
//        holder.binding.messages.text = context.resources.getQuantityString(R.plurals.backup_message_count, count, count)
        holder.binding.size.text = Formatter.formatFileSize(context, backup.size)+" "+context.resources.getQuantityString(R.plurals.backup_message_count, count, count)
    }

}