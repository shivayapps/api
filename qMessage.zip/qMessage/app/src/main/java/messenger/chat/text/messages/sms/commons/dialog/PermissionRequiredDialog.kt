package messenger.chat.text.messages.sms.commons.dialog

import android.app.Activity
import androidx.appcompat.app.AlertDialog
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.databinding.DialogMessageBinding
import messenger.chat.text.messages.sms.interactor.MarkBlocked

class PermissionRequiredDialog(
    val activity: Activity,
    textId: Int,
    private val positiveActionCallback: () -> Unit,
    private val negativeActionCallback: (() -> Unit)? = null
) {
//    private var dialog: AlertDialog? = null

    init {
        val view = DialogMessageBinding.inflate(activity.layoutInflater, null, false)
        view.message.text = activity.getString(textId)

        android.app.AlertDialog.Builder(activity)
            .setTitle(
                activity.getString(R.string.permission_required)
            )
//            .setMessage(message)
            .setPositiveButton(R.string.grant_permission) { _, _ -> positiveActionCallback() }
            .setNegativeButton(R.string.cancel) { _, _ -> negativeActionCallback?.invoke() }
            .create()
            .show()

//        AlertDialog.Builder(activity)
//            .setPositiveButton(R.string.grant_permission) { _, _ -> positiveActionCallback() }
//            .setNegativeButton(R.string.cancel) { _, _ -> negativeActionCallback?.invoke() }.apply {
//                val title = activity.getString(R.string.permission_required)
//                activity.setupDialogStuff(view.root, this, titleText = title) { alertDialog ->
//                    dialog = alertDialog
//                }
//            }
    }
}
