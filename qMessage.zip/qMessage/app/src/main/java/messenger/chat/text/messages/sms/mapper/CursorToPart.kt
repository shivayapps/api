package messenger.chat.text.messages.sms.mapper

import android.database.Cursor
import messenger.chat.text.messages.sms.model.MmsPart

interface CursorToPart : Mapper<Cursor, MmsPart> {

    fun getPartsCursor(messageId: Long): Cursor?

}