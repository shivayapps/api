package messenger.chat.text.messages.sms.listener

import io.reactivex.Observable

interface ContactAddedListener {

    fun listen(): Observable<*>

}
