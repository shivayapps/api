package messenger.chat.text.messages.sms.injection

import messenger.chat.text.messages.sms.common.QKApplication
import messenger.chat.text.messages.sms.common.QkDialog
import messenger.chat.text.messages.sms.common.util.QkChooserTargetService
import messenger.chat.text.messages.sms.common.widget.AvatarView
import messenger.chat.text.messages.sms.common.widget.PagerTitleView
import messenger.chat.text.messages.sms.common.widget.PreferenceView
import messenger.chat.text.messages.sms.common.widget.QkEditText
import messenger.chat.text.messages.sms.common.widget.QkSwitch
import messenger.chat.text.messages.sms.common.widget.BabyTextView
import messenger.chat.text.messages.sms.common.widget.RadioPreferenceView
import messenger.chat.text.messages.sms.feature.backup.BackupController
import messenger.chat.text.messages.sms.feature.blocking.BlockingController
import messenger.chat.text.messages.sms.feature.blocking.manager.BlockingManagerController
import messenger.chat.text.messages.sms.feature.blocking.messages.BlockedMessagesController
import messenger.chat.text.messages.sms.feature.blocking.numbers.BlockedNumbersController
import messenger.chat.text.messages.sms.feature.compose.editing.DetailedChipView
import messenger.chat.text.messages.sms.feature.conversationinfo.injection.ConversationInfoComponent
import messenger.chat.text.messages.sms.feature.settings.SettingsController
import messenger.chat.text.messages.sms.feature.settings.swipe.SwipeActionsController
import messenger.chat.text.messages.sms.feature.themepicker.injection.ThemePickerComponent
import messenger.chat.text.messages.sms.feature.widget.WidgetAdapter
import messenger.chat.text.messages.sms.injection.android.ActivityBuilderModule
import messenger.chat.text.messages.sms.injection.android.BroadcastReceiverBuilderModule
import messenger.chat.text.messages.sms.injection.android.ServiceBuilderModule
import dagger.Component
import dagger.android.support.AndroidSupportInjectionModule
import messenger.chat.text.messages.sms.common.widget.MessageTextView
import messenger.chat.text.messages.sms.common.widget.StyledTextView
import messenger.chat.text.messages.sms.feature.settings.AdvanceSettingsController
import javax.inject.Singleton

@Singleton
@Component(
    modules = [
        AndroidSupportInjectionModule::class,
        AppModule::class,
        ActivityBuilderModule::class,
        BroadcastReceiverBuilderModule::class,
        ServiceBuilderModule::class]
)
interface AppComponent {

    fun conversationInfoBuilder(): ConversationInfoComponent.Builder
    fun themePickerBuilder(): ThemePickerComponent.Builder

    fun inject(application: QKApplication)

    fun inject(controller: BackupController)
    fun inject(controller: BlockedMessagesController)
    fun inject(controller: BlockedNumbersController)
    fun inject(controller: BlockingController)
    fun inject(controller: BlockingManagerController)
    fun inject(controller: SettingsController)
    fun inject(controller: AdvanceSettingsController)
    fun inject(controller: SwipeActionsController)

    fun inject(dialog: QkDialog)

    fun inject(service: WidgetAdapter)

    /**
     * This can't use AndroidInjection, or else it will crash on pre-marshmallow devices
     */
    fun inject(service: QkChooserTargetService)

    fun inject(view: AvatarView)
    fun inject(view: DetailedChipView)
    fun inject(view: PagerTitleView)
    fun inject(view: PreferenceView)
    fun inject(view: RadioPreferenceView)
    fun inject(view: QkEditText)
    fun inject(view: QkSwitch)
    fun inject(view: BabyTextView)
    fun inject(view: StyledTextView)
    fun inject(view: MessageTextView)

}
