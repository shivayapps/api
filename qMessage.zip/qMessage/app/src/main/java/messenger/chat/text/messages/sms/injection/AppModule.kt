package messenger.chat.text.messages.sms.injection

import android.app.Application
import android.content.ContentResolver
import android.content.Context
import android.content.SharedPreferences
import android.preference.PreferenceManager
import androidx.lifecycle.ViewModelProvider
import com.f2prateek.rx.preferences2.RxSharedPreferences
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import dagger.Module
import dagger.Provides
import messenger.chat.text.messages.sms.blocking.BlockingClient
import messenger.chat.text.messages.sms.blocking.BlockingManager
import messenger.chat.text.messages.sms.common.ViewModelFactory
import messenger.chat.text.messages.sms.common.util.NotificationManagerImpl
import messenger.chat.text.messages.sms.common.util.ShortcutManagerImpl
import messenger.chat.text.messages.sms.feature.conversationinfo.injection.ConversationInfoComponent
import messenger.chat.text.messages.sms.feature.themepicker.injection.ThemePickerComponent
import messenger.chat.text.messages.sms.listener.ContactAddedListener
import messenger.chat.text.messages.sms.listener.ContactAddedListenerImpl
import messenger.chat.text.messages.sms.manager.ActiveConversationManager
import messenger.chat.text.messages.sms.manager.ActiveConversationManagerImpl
import messenger.chat.text.messages.sms.manager.AlarmManager
import messenger.chat.text.messages.sms.manager.AlarmManagerImpl
import messenger.chat.text.messages.sms.manager.AnalyticsManager
import messenger.chat.text.messages.sms.manager.AnalyticsManagerImpl
import messenger.chat.text.messages.sms.manager.KeyManager
import messenger.chat.text.messages.sms.manager.KeyManagerImpl
import messenger.chat.text.messages.sms.manager.NotificationManager
import messenger.chat.text.messages.sms.manager.PermissionManager
import messenger.chat.text.messages.sms.manager.PermissionManagerImpl
import messenger.chat.text.messages.sms.manager.RatingManager
import messenger.chat.text.messages.sms.manager.ReferralManager
import messenger.chat.text.messages.sms.manager.ReferralManagerImpl
import messenger.chat.text.messages.sms.manager.ShortcutManager
import messenger.chat.text.messages.sms.manager.WidgetManager
import messenger.chat.text.messages.sms.manager.WidgetManagerImpl
import messenger.chat.text.messages.sms.mapper.CursorToContact
import messenger.chat.text.messages.sms.mapper.CursorToContactImpl
import messenger.chat.text.messages.sms.mapper.CursorToConversation
import messenger.chat.text.messages.sms.mapper.CursorToConversationImpl
import messenger.chat.text.messages.sms.mapper.CursorToMessage
import messenger.chat.text.messages.sms.mapper.CursorToMessageImpl
import messenger.chat.text.messages.sms.mapper.CursorToPart
import messenger.chat.text.messages.sms.mapper.CursorToPartImpl
import messenger.chat.text.messages.sms.mapper.CursorToRecipient
import messenger.chat.text.messages.sms.mapper.CursorToRecipientImpl
import messenger.chat.text.messages.sms.mapper.RatingManagerImpl
import messenger.chat.text.messages.sms.repository.BackupRepository
import messenger.chat.text.messages.sms.repository.BackupRepositoryImpl
import messenger.chat.text.messages.sms.repository.BlockingRepository
import messenger.chat.text.messages.sms.repository.BlockingRepositoryImpl
import messenger.chat.text.messages.sms.repository.ContactRepository
import messenger.chat.text.messages.sms.repository.ContactRepositoryImpl
import messenger.chat.text.messages.sms.repository.ConversationRepository
import messenger.chat.text.messages.sms.repository.ConversationRepositoryImpl
import messenger.chat.text.messages.sms.repository.MessageRepository
import messenger.chat.text.messages.sms.repository.MessageRepositoryImpl
import messenger.chat.text.messages.sms.repository.ScheduledMessageRepository
import messenger.chat.text.messages.sms.repository.ScheduledMessageRepositoryImpl
import messenger.chat.text.messages.sms.repository.StarredMessageRepository
import messenger.chat.text.messages.sms.repository.StarredMessageRepositoryImpl
import messenger.chat.text.messages.sms.repository.SyncRepository
import messenger.chat.text.messages.sms.repository.SyncRepositoryImpl
import javax.inject.Singleton

@Module(
    subcomponents = [
        ConversationInfoComponent::class,
        ThemePickerComponent::class]
)
class AppModule(private var application: Application) {

    @Provides
    @Singleton
    fun provideContext(): Context = application

    @Provides
    fun provideContentResolver(context: Context): ContentResolver = context.contentResolver

    @Provides
    @Singleton
    fun provideSharedPreferences(context: Context): SharedPreferences {
        return PreferenceManager.getDefaultSharedPreferences(context)
    }

    @Provides
    @Singleton
    fun provideRxPreferences(preferences: SharedPreferences): RxSharedPreferences {
        return RxSharedPreferences.create(preferences)
    }

    @Provides
    @Singleton
    fun provideMoshi(): Moshi {
        return Moshi.Builder()
            .add(KotlinJsonAdapterFactory())
            .build()
    }

    @Provides
    fun provideViewModelFactory(factory: ViewModelFactory): ViewModelProvider.Factory = factory

    // Listener

    @Provides
    fun provideContactAddedListener(listener: ContactAddedListenerImpl): ContactAddedListener = listener

    // Manager

    @Provides
    fun provideActiveConversationManager(manager: ActiveConversationManagerImpl): ActiveConversationManager = manager

    @Provides
    fun provideAlarmManager(manager: AlarmManagerImpl): AlarmManager = manager

    @Provides
    fun provideAnalyticsManager(manager: AnalyticsManagerImpl): AnalyticsManager = manager

    @Provides
    fun blockingClient(manager: BlockingManager): BlockingClient = manager


    @Provides
    fun provideKeyManager(manager: KeyManagerImpl): KeyManager = manager

    @Provides
    fun provideNotificationsManager(manager: NotificationManagerImpl): NotificationManager = manager

    @Provides
    fun providePermissionsManager(manager: PermissionManagerImpl): PermissionManager = manager

    @Provides
    fun provideRatingManager(manager: RatingManagerImpl): RatingManager = manager

    @Provides
    fun provideShortcutManager(manager: ShortcutManagerImpl): ShortcutManager = manager

    @Provides
    fun provideReferralManager(manager: ReferralManagerImpl): ReferralManager = manager

    @Provides
    fun provideWidgetManager(manager: WidgetManagerImpl): WidgetManager = manager

    // Mapper

    @Provides
    fun provideCursorToContact(mapper: CursorToContactImpl): CursorToContact = mapper

    @Provides
    fun provideCursorToConversation(mapper: CursorToConversationImpl): CursorToConversation = mapper

    @Provides
    fun provideCursorToMessage(mapper: CursorToMessageImpl): CursorToMessage = mapper

    @Provides
    fun provideCursorToPart(mapper: CursorToPartImpl): CursorToPart = mapper

    @Provides
    fun provideCursorToRecipient(mapper: CursorToRecipientImpl): CursorToRecipient = mapper

    // Repository

    @Provides
    fun provideBackupRepository(repository: BackupRepositoryImpl): BackupRepository = repository

    @Provides
    fun provideBlockingRepository(repository: BlockingRepositoryImpl): BlockingRepository = repository

    @Provides
    fun provideContactRepository(repository: ContactRepositoryImpl): ContactRepository = repository
    @Provides
    fun provideStarredMessageRepository(repository: StarredMessageRepositoryImpl): StarredMessageRepository = repository

    @Provides
    fun provideConversationRepository(repository: ConversationRepositoryImpl): ConversationRepository = repository

    @Provides
    fun provideMessageRepository(repository: MessageRepositoryImpl): MessageRepository = repository

    @Provides
    fun provideScheduledMessagesRepository(repository: ScheduledMessageRepositoryImpl): ScheduledMessageRepository = repository

    @Provides
    fun provideSyncRepository(repository: SyncRepositoryImpl): SyncRepository = repository

}