package messenger.chat.text.messages.sms.feature.contacts

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProviders
import com.jakewharton.rxbinding2.view.clicks
import com.jakewharton.rxbinding2.widget.editorActions
import com.jakewharton.rxbinding2.widget.textChanges
import messenger.chat.text.messages.sms.common.ViewModelFactory
import messenger.chat.text.messages.sms.common.base.QkThemedActivity
import messenger.chat.text.messages.sms.common.util.extensions.hideKeyboard
import messenger.chat.text.messages.sms.common.util.extensions.showKeyboard
import messenger.chat.text.messages.sms.common.util.extensions.viewBinding
import messenger.chat.text.messages.sms.common.widget.QkDialog
import messenger.chat.text.messages.sms.extensions.Optional
import messenger.chat.text.messages.sms.feature.compose.editing.ComposeItem
import messenger.chat.text.messages.sms.feature.compose.editing.ComposeItemAdapter
import messenger.chat.text.messages.sms.feature.compose.editing.PhoneNumberAction
import messenger.chat.text.messages.sms.feature.compose.editing.PhoneNumberPickerAdapter
import dagger.android.AndroidInjection
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.databinding.ContactsActivityBinding
import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messenger.chat.text.messages.sms.commons.extensions.baseConfig
import messenger.chat.text.messages.sms.commons.extensions.updateTextColors
import javax.inject.Inject

class ContactsActivity : QkThemedActivity(), ContactsContract {

    companion object {
        const val SharingKey = "sharing"
        const val ChipsKey = "chips"
    }

    @Inject
    lateinit var contactsAdapter: ComposeItemAdapter

    @Inject
    lateinit var phoneNumberAdapter: PhoneNumberPickerAdapter

    @Inject
    lateinit var viewModelFactory: ViewModelFactory

    override val queryChangedIntent: Observable<CharSequence> by lazy { binding.search.textChanges() }
    override val queryClearedIntent: Observable<*> by lazy { binding.cancel.clicks() }
    override val queryEditorActionIntent: Observable<Int> by lazy { binding.search.editorActions() }
    override val composeItemPressedIntent: Subject<ComposeItem> by lazy { contactsAdapter.clicks }
    override val composeItemLongPressedIntent: Subject<ComposeItem> by lazy { contactsAdapter.longClicks }
    override val phoneNumberSelectedIntent: Subject<Optional<Long>> by lazy { phoneNumberAdapter.selectedItemChanges }
    override val phoneNumberActionIntent: Subject<PhoneNumberAction> = PublishSubject.create()

    private val binding by viewBinding(ContactsActivityBinding::inflate)
    private val viewModel by lazy { ViewModelProviders.of(this, viewModelFactory)[ContactsViewModel::class.java] }

    private val phoneNumberDialog by lazy {
        QkDialog(this).apply {
            titleRes = R.string.compose_number_picker_title
            adapter = phoneNumberAdapter
            positiveButton = R.string.compose_number_picker_always
            positiveButtonListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.ALWAYS) }
            negativeButton = R.string.compose_number_picker_once
            negativeButtonListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.JUST_ONCE) }
            cancelListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.CANCEL) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        showBackButton(true)
        viewModel.bindView(this)

        binding.contacts.adapter = contactsAdapter

        setUpTheme()
    }


    private fun setUpTheme() {

        Log.e("MainActivity", "setUpTheme.useImageResource:${baseConfig.useImageResource}")
        Log.e("MainActivity", "setUpTheme.storedImageResource:${baseConfig.storedImageResource}")
//        if (baseConfig.useImageResource){
//            if (baseConfig.storedImageResource==-1){
//
//            }else{
////                val bitmapDrawable = BitmapDrawable(resources, baseConfig.storedBitmap)
//                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
//                binding.mainLayout.background = drawable
//            }
//        }

        updateTextColors(binding.contentView)
//        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
//            binding.llBottomAction.background = ColorDrawable(resources.getColor(R.color.bottom_tabs_black_backgroundnew))
//            arrayListOf(binding.ivDelete, binding.ivMore, binding.ivArchive, binding.ivRead, binding.ivBlock).forEach {
////                val whiteColor = ContextCompat.getColor(this, R.color.white)
//                val colorStateList = ColorStateList.valueOf(Color.WHITE)
//                it.imageTintList = colorStateList
//            }
//        } else {
//            binding.llBottomAction.background = ColorDrawable(baseConfig.statusBarColor)
//            arrayListOf(binding.ivDelete, binding.ivMore, binding.ivArchive, binding.ivRead, binding.ivBlock).forEach {
////                val whiteColor = ContextCompat.getColor(this, R.color.black)
//                val colorStateList = ColorStateList.valueOf(Color.BLACK)
//                it.imageTintList = colorStateList
//            }
//        }

        if (baseConfig.useImageResource == true) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                Log.i("onCreate", "onCreateitemselse11111: ")

//                val bitmapDrawable = BitmapDrawable(resources, baseConfig.storedBitmap)
//                constraintLayout.background = bitmapDrawable
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.contentView.background = drawable

                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))

            }
        } else {

            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
//            binding.navView.setBackgroundColor(baseConfig.backgroundColor)
//            lloptionmenu.setBackgroundColor(baseConfig.backgroundColor)
            toolbar.setBackgroundColor(baseConfig.backgroundColor)

        }

    }

    override fun render(state: ContactsState) {
        binding.cancel.isVisible = state.query.length > 1

        contactsAdapter.data = state.composeItems

        if (state.selectedContact != null && !phoneNumberDialog.isShowing) {
            phoneNumberAdapter.data = state.selectedContact.numbers
            phoneNumberDialog.subtitle = state.selectedContact.name
            phoneNumberDialog.show()
        } else if (state.selectedContact == null && phoneNumberDialog.isShowing) {
            phoneNumberDialog.dismiss()
        }
    }

    override fun clearQuery() {
        binding.search.text = null
    }

    override fun openKeyboard() {
        binding.search.postDelayed({
            binding.search.showKeyboard()
        }, 200)
    }

    override fun finish(result: HashMap<String, String?>) {
        binding.search.hideKeyboard()
        val intent = Intent().putExtra(ChipsKey, result)
        setResult(Activity.RESULT_OK, intent)
        finish()
    }

}
