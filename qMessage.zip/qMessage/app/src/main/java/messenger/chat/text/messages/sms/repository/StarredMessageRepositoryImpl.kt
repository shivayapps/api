package messenger.chat.text.messages.sms.repository

import io.realm.Realm
import io.realm.RealmResults
import messenger.chat.text.messages.sms.model.Conversation
import messenger.chat.text.messages.sms.model.Message

import javax.inject.Inject

class StarredMessageRepositoryImpl @Inject constructor() : StarredMessageRepository {

    override fun getStarredMessages(): RealmResults<Message> {
        return Realm.getDefaultInstance()
            .where(Message::class.java)
            .equalTo("starred", true)
            .findAll()
    }

    override fun getConversation(threadId: Long): Conversation? {
        return Realm.getDefaultInstance()
            .apply {
                try {
                    refresh()
                } catch (e: Exception) {

                }
            }
            .where(Conversation::class.java)
            .equalTo("id", threadId)
            .findFirst()
    }

    override fun getStarredMessages(id: Long): Message? {
        return Realm.getDefaultInstance()
            .apply { refresh() }
            .where(Message::class.java)
            .equalTo("starred", true)
            .findFirst()
    }

    override fun deleteStarredMessage(id: Long) {
        Realm.getDefaultInstance()
            .apply { refresh() }
            .use { realm ->
                val message = realm.where(Message::class.java)
                    .equalTo("id", id)
                    .findFirst()

                realm.executeTransaction { message?.deleteFromRealm() }
            }
    }

}