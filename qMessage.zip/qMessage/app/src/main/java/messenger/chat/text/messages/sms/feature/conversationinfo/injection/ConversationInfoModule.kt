package messenger.chat.text.messages.sms.feature.conversationinfo.injection

import messenger.chat.text.messages.sms.feature.conversationinfo.ConversationInfoController
import messenger.chat.text.messages.sms.injection.scope.ControllerScope
import dagger.Module
import dagger.Provides
import javax.inject.Named

@Module
class ConversationInfoModule(private val controller: ConversationInfoController) {

    @Provides
    @ControllerScope
    @Named("threadId")
    fun provideThreadId(): Long = controller.threadId

}