package messenger.chat.text.messages.sms.feature.blocking.numbers

import android.view.View
import androidx.appcompat.app.AlertDialog
import com.jakewharton.rxbinding2.view.clicks
import messenger.chat.text.messages.sms.common.base.QkController
import messenger.chat.text.messages.sms.common.util.Colors
import messenger.chat.text.messages.sms.common.util.extensions.setBackgroundTint
import messenger.chat.text.messages.sms.common.util.extensions.setTint
import messenger.chat.text.messages.sms.injection.appComponent
import messenger.chat.text.messages.sms.util.PhoneNumberUtils
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.databinding.BlockedNumbersAddDialogBinding
import messenger.chat.text.messages.sms.databinding.BlockedNumbersControllerBinding
import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import javax.inject.Inject

class BlockedNumbersController : QkController<BlockedNumbersView, BlockedNumbersState, BlockedNumbersPresenter,
        BlockedNumbersControllerBinding>(BlockedNumbersControllerBinding::inflate), BlockedNumbersView {

    @Inject
    override lateinit var presenter: BlockedNumbersPresenter

    @Inject
    lateinit var colors: Colors

    @Inject
    lateinit var phoneNumberUtils: PhoneNumberUtils

    private val adapter = BlockedNumbersAdapter()
    private val saveAddressSubject: Subject<String> = PublishSubject.create()

    init {
        appComponent.inject(this)
        retainViewMode = RetainViewMode.RETAIN_DETACH
    }

    override fun onAttach(view: View) {
        super.onAttach(view)
        presenter.bindIntents(this)
        setTitle(R.string.blocked_numbers_title)
//        showBackButton(true)
    }

    override fun onViewCreated() {
        super.onViewCreated()
        binding.add.setBackgroundTint(colors.theme().theme)
        binding.add.setTint(colors.theme().textPrimary)
        adapter.emptyView = binding.empty
        binding.numbers.adapter = adapter
    }

    override fun render(state: BlockedNumbersState) {
        adapter.updateData(state.numbers)
    }

    override fun unblockAddress(): Observable<Long> = adapter.unblockAddress
    override fun addAddress(): Observable<*> = binding.add.clicks()
    override fun saveAddress(): Observable<String> = saveAddressSubject

    override fun showAddDialog() {
        val binding = BlockedNumbersAddDialogBinding.inflate(activity?.layoutInflater!!)
        val textWatcher = BlockedNumberTextWatcher(binding.input, phoneNumberUtils)
        val dialog = AlertDialog.Builder(activity!!)
            .setView(binding.root)
            .setPositiveButton(R.string.blocked_numbers_dialog_block) { _, _ ->
                saveAddressSubject.onNext(binding.input.text.toString())
            }
            .setNegativeButton(R.string.button_cancel) { _, _ -> }
            .setOnDismissListener { textWatcher.dispose() }
        dialog.show()
    }

}
