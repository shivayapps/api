package messenger.chat.text.messages.sms.feature.settings.autodelete

import android.app.Activity
import android.content.DialogInterface
import android.view.LayoutInflater
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.databinding.SettingsAutoDeleteDialogBinding


class AutoDeleteDialog(context: Activity, style: Int, listener: (Int) -> Unit) :
    AlertDialog(context, style) {

    private val binding = SettingsAutoDeleteDialogBinding.inflate(context.layoutInflater)

    init {
        setView(binding.root)
        setTitle(R.string.settings_auto_delete)
        setMessage(context.getString(R.string.settings_auto_delete_dialog_message))
        setButton(
            DialogInterface.BUTTON_NEUTRAL,
            context.resources.getString(R.string.button_cancel)
        ) { _, _ ->
            invalidateSelection()
        }
        setButton(
            DialogInterface.BUTTON_NEGATIVE,
            context.resources.getString(R.string.settings_auto_delete_never)
        ) { _, _ ->
            listener(0)
            invalidateSelection()
        }
        setOnShowListener {
            getButton(BUTTON_POSITIVE).setTextColor(
                ContextCompat.getColor(
                    context,
                    R.color.color_app_theme
                )
            )
            getButton(BUTTON_NEGATIVE).setTextColor(
                ContextCompat.getColor(
                    context,
                    R.color.color_app_theme
                )
            )
            getButton(BUTTON_NEUTRAL).setTextColor(
                ContextCompat.getColor(
                    context,
                    R.color.color_app_theme
                )
            )
        }
        setButton(
            DialogInterface.BUTTON_POSITIVE,
            context.getString(R.string.button_save)
        ) { _, _ ->
//            val strDays = when (layout.field.text.toString()) {
//                "1" -> EventKeys.general_delete_msg_auto_daily
//                "7" -> EventKeys.general_delete_msg_auto_weekly
//                "30" -> EventKeys.general_delete_msg_auto_monthly
//                "365" -> EventKeys.general_delete_msg_auto_yearly
//                else -> EventKeys.general_delete_msg_auto_custom
//            }
//            AppUtils.logAdapterMessages(
//                EventKeys.settings,
//                EventKeys.click,
//                strDays
//            )
            listener(binding.field.text.toString().toIntOrNull() ?: 0)
        }
        binding.llDaily.setOnClickListener {
            setExpiry(1)
        }
        binding.llWeekly.setOnClickListener {
            setExpiry(7)
        }
        binding.llMonthly.setOnClickListener {
            setExpiry(30)
        }
        binding.llYearly.setOnClickListener {
            setExpiry(365)
        }
    }

    private fun invalidateSelection() {
        binding.ivDaily.isActivated = false
        binding.ivWeekly.isActivated = false
        binding.ivMonthly.isActivated = false
        binding.ivYearly.isActivated = false
    }

    fun setExpiry(days: Int): AutoDeleteDialog {
        invalidateSelection()
        when (days) {
            0 -> {
                binding.field.text = null
            }
            else -> {
                binding.field.setText(days.toString())
                binding.field.setSelection(days.toString().length)
                when (days) {
                    1 -> binding.ivDaily.isActivated = true
                    7 -> binding.ivWeekly.isActivated = true
                    30 -> binding.ivMonthly.isActivated = true
                    365 -> binding.ivYearly.isActivated = true
                }
            }
        }
        return this
    }

}
