package messenger.chat.text.messages.sms.feature.contacts

import messenger.chat.text.messages.sms.feature.compose.editing.ComposeItem
import messenger.chat.text.messages.sms.model.Contact

data class ContactsState(
    val query: String = "",
    val composeItems: List<ComposeItem> = ArrayList(),
    val selectedContact: Contact? = null // For phone number picker
)
