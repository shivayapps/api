package messenger.chat.text.messages.sms.feature.main

import android.view.inputmethod.EditorInfo
import androidx.recyclerview.widget.ItemTouchHelper
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.Observables
import io.reactivex.rxkotlin.plusAssign
import io.reactivex.rxkotlin.withLatestFrom
import io.reactivex.schedulers.Schedulers
import io.realm.Realm
import io.realm.RealmList
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.rx2.awaitFirst
import messenger.chat.text.messages.sms.R
import messenger.chat.text.messages.sms.common.Navigator
import messenger.chat.text.messages.sms.common.base.QkViewModel
import messenger.chat.text.messages.sms.extensions.mapNotNull
import messenger.chat.text.messages.sms.extensions.removeAccents
import messenger.chat.text.messages.sms.feature.compose.editing.PhoneNumberAction
import messenger.chat.text.messages.sms.filter.ContactFilter2
import messenger.chat.text.messages.sms.filter.ContactGroupFilter
import messenger.chat.text.messages.sms.interactor.DeleteConversations
import messenger.chat.text.messages.sms.interactor.MarkAllSeen
import messenger.chat.text.messages.sms.interactor.MarkArchived
import messenger.chat.text.messages.sms.interactor.MarkPinned
import messenger.chat.text.messages.sms.interactor.MarkRead
import messenger.chat.text.messages.sms.interactor.MarkRecycle
import messenger.chat.text.messages.sms.interactor.MarkUnarchived
import messenger.chat.text.messages.sms.interactor.MarkUnpinned
import messenger.chat.text.messages.sms.interactor.MarkUnread
import messenger.chat.text.messages.sms.interactor.MigratePreferences
import messenger.chat.text.messages.sms.interactor.SetDefaultPhoneNumber
import messenger.chat.text.messages.sms.interactor.SyncContacts
import messenger.chat.text.messages.sms.interactor.SyncMessages
import messenger.chat.text.messages.sms.listener.ContactAddedListener
import messenger.chat.text.messages.sms.manager.PermissionManager
import messenger.chat.text.messages.sms.manager.RatingManager
import messenger.chat.text.messages.sms.model.Contact
import messenger.chat.text.messages.sms.model.ContactData
import messenger.chat.text.messages.sms.model.ContactGroup
import messenger.chat.text.messages.sms.model.PhoneNumber
import messenger.chat.text.messages.sms.model.SyncLog
import messenger.chat.text.messages.sms.repository.ContactRepository
import messenger.chat.text.messages.sms.repository.ConversationRepository
import messenger.chat.text.messages.sms.repository.SyncRepository
import messenger.chat.text.messages.sms.util.PhoneNumberUtils
import messenger.chat.text.messages.sms.util.Preferences
import java.util.concurrent.TimeUnit
import javax.inject.Inject

class MainViewModel @Inject constructor(
    contactAddedListener: ContactAddedListener,
    markAllSeen: MarkAllSeen,
    migratePreferences: MigratePreferences,
    syncRepository: SyncRepository,
    private val conversationRepo: ConversationRepository,
    private val deleteConversations: DeleteConversations,
    private val markArchived: MarkArchived,
    private val markPinned: MarkPinned,
    private val markRead: MarkRead,
    private val markUnarchived: MarkUnarchived,
    private val markUnpinned: MarkUnpinned,
    private val markUnread: MarkUnread,
    private val markRecycle: MarkRecycle,
//    private val markUnRecycle: MarkUnRecycle,
    private val navigator: Navigator,
    private val permissionManager: PermissionManager,
    private val prefs: Preferences,
    private val ratingManager: RatingManager,
    private val syncContacts: SyncContacts,
    private val syncMessages: SyncMessages,
    private val contactsRepo: ContactRepository,
    private val phoneNumberUtils: PhoneNumberUtils,
    private val contactFilter: ContactFilter2,
    private val contactGroupFilter: ContactGroupFilter,
    private val setDefaultPhoneNumber: SetDefaultPhoneNumber
) : QkViewModel<MainView, MainState>(
    MainState(
        page = Inbox(data = conversationRepo.getConversations(), archiveMessages = conversationRepo.getArchiveCount()),
        contact = ContactPage(contacts = contactsRepo.getContactsList())
    )
) {
    private val contacts: Observable<List<ContactData>> by lazy { contactsRepo.getContactsListOb() }
    private val recentContacts: Observable<List<ContactData>> by lazy { contactsRepo.getContactsListRecentOb() }
    private val contactGroups: Observable<List<ContactGroup>> by lazy { contactsRepo.getUnmanagedContactGroups() }

    init {
        disposables += deleteConversations
        disposables += markRecycle
        disposables += markAllSeen
        disposables += markArchived
        disposables += markUnarchived
        disposables += migratePreferences
        disposables += syncContacts
        disposables += syncMessages

        // Show the syncing UI
        disposables += syncRepository.syncProgress.sample(16, TimeUnit.MILLISECONDS).distinctUntilChanged()
            .subscribe { syncing -> newState { copy(syncing = syncing) } }

        // Show the rating UI
        disposables += ratingManager.shouldShowRating.subscribe { show -> newState { copy(showRating = show) } }

        // Migrate the preferences from 2.7.3
        migratePreferences.execute(Unit)

        refreshMessages()
        // Sync contacts when we detect a change
        if (permissionManager.hasContacts()) {
            disposables += contactAddedListener.listen().debounce(1, TimeUnit.SECONDS).subscribeOn(Schedulers.io())
                .subscribe { syncContacts.execute(Unit) }
        }

        ratingManager.addSession()
        markAllSeen.execute(Unit)

    }

    fun refreshMessages() {

        // If we have all permissions and we've never run a sync, run a sync. This will be the case
        // when upgrading from 2.7.3, or if the app's data was cleared
        val lastSync = Realm.getDefaultInstance().use { realm -> realm.where(SyncLog::class.java)?.max("date") ?: 0 }
        if (lastSync == 0 && permissionManager.isDefaultSms() && permissionManager.hasReadSms() && permissionManager.hasContacts()) {
            syncMessages.execute(Unit)
        }

    }

    fun forceRefreshMessages() {

        if (permissionManager.isDefaultSms() && permissionManager.hasReadSms() && permissionManager.hasContacts()) {
            syncMessages.execute(Unit)
        }

    }

    override fun bindView(view: MainView) {
        super.bindView(view)

        when {
            !permissionManager.isDefaultSms() -> view.requestDefaultSms()
            !permissionManager.hasReadSms() || !permissionManager.hasContacts() -> view.requestPermissions()
        }

        val permissions = view.activityResumedIntent.filter { resumed -> resumed }.observeOn(Schedulers.io())
            .map { Triple(permissionManager.isDefaultSms(), permissionManager.hasReadSms(), permissionManager.hasContacts()) }.distinctUntilChanged()
            .share()

        // If the default SMS state or permission states change, update the ViewState
        permissions.doOnNext { (defaultSms, smsPermission, contactPermission) ->
            newState { copy(defaultSms = defaultSms, smsPermission = smsPermission, contactPermission = contactPermission) }
        }.autoDisposable(view.scope()).subscribe()

        // If we go from not having all permissions to having them, sync messages
        permissions.skip(1).filter { it.first && it.second && it.third }.take(1).autoDisposable(view.scope()).subscribe { syncMessages.execute(Unit) }

        // Launch screen from intent
        view.onNewIntentIntent.autoDisposable(view.scope()).subscribe { intent ->
            when (intent.getStringExtra("screen")) {
                "blocking" -> navigator.showBlockedConversations()
            }
        }

        view.queryConversationChangedIntent.debounce(200, TimeUnit.MILLISECONDS).observeOn(AndroidSchedulers.mainThread())
            .withLatestFrom(state) { query, state ->
                if (query.isEmpty() && state.page is Searching) {
                    newState { copy(page = Inbox(data = conversationRepo.getConversations(), archiveMessages = conversationRepo.getArchiveCount())) }
                }
                query
            }.filter { query -> query.length >= 2 }.doOnNext {
                newState {
                    val page = (page as? Searching) ?: Searching()
                    copy(page = page.copy(loading = true))
                }
            }.observeOn(Schedulers.io()).map(conversationRepo::searchConversations).autoDisposable(view.scope())
            .subscribe { data -> newState { copy(page = Searching(loading = false, data = data)) } }

        view.activityResumedIntent.filter { resumed -> !resumed }.switchMap {
            // Take until the activity is resumed
            prefs.keyChanges.filter { key -> key.contains("theme") }.map { true }.mergeWith(prefs.autoColor.asObservable().skip(1))
                .doOnNext { view.themeChanged() }.takeUntil(view.activityResumedIntent.filter { resumed -> resumed })
        }.autoDisposable(view.scope()).subscribe()

        view.composeIntent.autoDisposable(view.scope()).subscribe { navigator.showCompose() }

        view.homeIntent.withLatestFrom(state) { _, state ->
            when {
                state.page is Searching -> view.clearSearch()
                state.page is Inbox && state.page.selected > 0 -> view.clearSelection()
                state.page is Archived && state.page.selected > 0 -> view.clearSelection()
//                state.page is Archived -> {
//                    view.clearSelection()
//                    view.onBackPressedFromArchive()
//                }
//                else -> newState { copy(drawerOpen = true) }
            }
        }.autoDisposable(view.scope()).subscribe()

//        view.drawerOpenIntent.autoDisposable(view.scope()).subscribe { open -> newState { copy(drawerOpen = open) } }
        view.navigationIntent.withLatestFrom(state) { drawerItem, state ->
//            newState { copy(drawerOpen = false) }
            when (drawerItem) {
                NavItem.BACK -> when {
//                    state.drawerOpen -> Unit
                    state.page is Searching -> view.clearSearch()
                    state.page is Inbox && state.page.selected > 0 -> {
                        view.clearSelection()
                    }

                    state.page is Archived && state.page.selected > 0 -> view.clearSelection()
                    state.page !is Inbox -> {
                        newState {
                            copy(
                                page = Inbox(
                                    data = conversationRepo.getConversations(),
                                    archiveMessages = conversationRepo.getArchiveCount()
                                )
                            )
                        }
                    }

                    else -> newState { copy(hasError = true) }
                }

                NavItem.BACKUP -> navigator.showBackup()
                NavItem.SCHEDULED -> navigator.showScheduled()
                NavItem.BLOCKING -> navigator.showBlockedConversations()
                NavItem.SETTINGS -> navigator.showSettings()
                NavItem.HELP -> navigator.showSupport()
                NavItem.INVITE -> navigator.showInvite()
                else -> Unit
            }
            drawerItem
        }.distinctUntilChanged().doOnNext { drawerItem ->
            when (drawerItem) {
                NavItem.INBOX -> newState {
                    copy(
                        page = Inbox(
                            data = conversationRepo.getConversations(),
                            archiveMessages = conversationRepo.getArchiveCount()
                        )
                    )
                }

                NavItem.ARCHIVED -> {
                    navigator.showArchive()
//                    newState { copy(page = Archived(data = conversationRepo.getConversations(true))) }
                }
                else -> Unit
            }
        }.autoDisposable(view.scope()).subscribe()

        view.optionsItemIntent.filter { itemId -> itemId == R.id.archive }
            .withLatestFrom(view.conversationsSelectedIntent)
            { _, conversations ->
                markArchived.execute(conversations) {
                    view.refreshArchive()
                }
                view.clearSelection()

            }.autoDisposable(view.scope()).subscribe()

        view.optionsItemIntent.filter { itemId -> itemId == R.id.unarchive }.withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
            markUnarchived.execute(conversations){
                view.refreshArchive()
            }
            view.clearSelection()
        }.autoDisposable(view.scope()).subscribe()

        view.optionsItemIntent.filter { itemId -> itemId == R.id.delete }
            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                view.showDeleteDialog(conversations)
            }.autoDisposable(view.scope()).subscribe()

        view.optionsItemIntent.filter { itemId -> itemId == R.id.add }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations -> conversations }.doOnNext { view.clearSelection() }
            .filter { conversations -> conversations.size == 1 }.map { conversations -> conversations.first() }
            .mapNotNull(conversationRepo::getConversation).map { conversation -> conversation.recipients }
            .mapNotNull { recipients -> recipients[0]?.address?.takeIf { recipients.size == 1 } }.doOnNext(navigator::addContact)
            .autoDisposable(view.scope()).subscribe()

        view.optionsItemIntent.filter { itemId -> itemId == R.id.pin }.withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
            markPinned.execute(conversations)
            view.clearSelection()
        }.autoDisposable(view.scope()).subscribe()

        view.optionsItemIntent.filter { itemId -> itemId == R.id.unpin }.withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
            markUnpinned.execute(conversations)
            view.clearSelection()
        }.autoDisposable(view.scope()).subscribe()

        view.optionsItemIntent.filter { itemId -> itemId == R.id.read }
            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                markRead.execute(conversations)
                view.clearSelection()
            }.autoDisposable(view.scope()).subscribe()

        view.optionsItemIntent.filter { itemId -> itemId == R.id.unread }
            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                markUnread.execute(conversations)
                view.clearSelection()
            }.autoDisposable(view.scope()).subscribe()

        view.optionsItemIntent.filter { itemId -> itemId == R.id.block }.withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
            view.showBlockingDialog(conversations, true)
            view.clearSelection()
        }.autoDisposable(view.scope()).subscribe()


//        view.rateIntent.autoDisposable(view.scope()).subscribe {
//            navigator.showRating()
//            ratingManager.rate()
//        }
//
//        view.dismissRatingIntent.autoDisposable(view.scope()).subscribe { ratingManager.dismiss() }
//        view.refreshArchive.withLatestFrom(state) { _, state ->
//            if (state.page is Inbox) {
//                val page = state.page.copy(archiveMessages = conversationRepo.getArchiveCount())
//                newState { copy(page = page) }
//            }
//        }.autoDisposable(view.scope()).subscribe()
        view.refreshArchive.withLatestFrom(state) {_, state ->
            if (state.page is Inbox) {
                newState { copy(page = state.page.copy(archiveMessages = conversationRepo.getArchiveCount())) }
            }
        }.autoDisposable(view.scope()).subscribe()

        view.conversationsSelectedIntent.withLatestFrom(state) { selection, state ->
            val conversations = selection.mapNotNull(conversationRepo::getConversation)
            val add = conversations.firstOrNull()?.takeIf { conversations.size == 1 }
                ?.takeIf { conversation -> conversation.recipients.size == 1 }?.recipients?.first()
                ?.takeIf { recipient -> recipient.contact == null } != null
            val pin = conversations.sumBy { if (it.pinned) -1 else 1 } >= 0
            val read = conversations.sumBy { if (!it.unread) -1 else 1 } >= 0
            val selected = selection.size

            when (state.page) {
                is Inbox -> {
                    val page = state.page.copy(addContact = add, markPinned = pin, markRead = read, selected = selected)
                    newState { copy(page = page) }
                }

                is ContactPage -> {
                    val page = state.page.copy(selected = selected)
                    newState { copy(page = page) }
                }

                is Archived -> {
                    val page = state.page.copy(addContact = add, markPinned = pin, markRead = read, selected = selected)
                    newState { copy(page = page) }
                }

                is Searching -> {}
            }
        }.autoDisposable(view.scope()).subscribe()

        // Delete the conversation
        view.confirmDeleteIntent.autoDisposable(view.scope()).subscribe { conversations ->
//            deleteConversations.execute(conversations)
            markRecycle.execute(conversations)
            view.clearSelection()
        }

        view.swipeConversationIntent.autoDisposable(view.scope()).subscribe { (threadId, direction) ->
            val action = if (direction == ItemTouchHelper.RIGHT) prefs.swipeRight.get() else prefs.swipeLeft.get()
            when (action) {
                Preferences.SWIPE_ACTION_ARCHIVE -> markArchived.execute(listOf(threadId)) { view.showArchivedSnackbar() }
                Preferences.SWIPE_ACTION_DELETE -> view.showDeleteDialog(listOf(threadId))
                Preferences.SWIPE_ACTION_BLOCK -> view.showBlockingDialog(listOf(threadId), true)
                Preferences.SWIPE_ACTION_CALL -> conversationRepo.getConversation(threadId)?.recipients?.firstOrNull()?.address?.let(navigator::makePhoneCall)
                Preferences.SWIPE_ACTION_READ -> markRead.execute(listOf(threadId))
                Preferences.SWIPE_ACTION_UNREAD -> markUnread.execute(listOf(threadId))
            }
        }

        view.undoArchiveIntent.withLatestFrom(view.swipeConversationIntent) { _, pair -> pair.first }.autoDisposable(view.scope())
            .subscribe { threadId -> markUnarchived.execute(listOf(threadId)) }

        view.setAsDefaultClick.autoDisposable(view.scope()).subscribe {
            when {
                !permissionManager.isDefaultSms() -> view.requestDefaultSms()
                !permissionManager.hasReadSms() || !permissionManager.hasContacts() -> view.requestPermissions()
            }
        }

        // Update the state's query, so we know if we should show the cancel button
//        view.queryChangedIntent.autoDisposable(view.scope()).subscribe { query -> newState { copy(query = query.toString()) } }
//        // Clear the query
//        view.queryClearedIntent.autoDisposable(view.scope()).subscribe { view.clearQuery() }
//        Observables.combineLatest(
//            view.queryChangedIntent, contacts,
//        ) { query, contacts ->
//            val composeItems = mutableListOf<ContactData>()
//            if (query.isBlank()) {
//                composeItems += contacts
//            } else {
//                val normalizedQuery = query.removeAccents()
//                // If the entry is a valid destination, allow it as a recipient
//                if (phoneNumberUtils.isPossibleNumber(query.toString())) {
//                    val newAddress = phoneNumberUtils.formatNumber(query)
//                    val newContact = Contact(numbers = RealmList(PhoneNumber(address = newAddress)))
//                    composeItems += ContactData(
//                        newContact.lookupKey,
//                        ArrayList(newContact.numbers),
//                        newContact.name,
//                        newContact.photoUri,
//                        newContact.starred,
//                        newContact.lastUpdate
//                    )
//                }
//                composeItems += contacts.asSequence().filter { contact -> contactFilter.filter(contact, normalizedQuery) }
//            }
//
//            composeItems
//        }.subscribeOn(Schedulers.computation()).autoDisposable(view.scope()).subscribe { items -> newState { copy(composeItems = items) } }
//
//        //recent
//        Observables.combineLatest(
//            view.queryChangedIntent, recentContacts,
//        ) { query, contacts ->
//            val composeItems = mutableListOf<ContactData>()
//            if (query.isBlank()) {
//                composeItems += contacts
//            } else {
//                val normalizedQuery = query.removeAccents()
//                // If the entry is a valid destination, allow it as a recipient
//                if (phoneNumberUtils.isPossibleNumber(query.toString())) {
//                    val newAddress = phoneNumberUtils.formatNumber(query)
//                    val newContact = Contact(numbers = RealmList(PhoneNumber(address = newAddress)))
//                    composeItems += ContactData(
//                        newContact.lookupKey,
//                        ArrayList(newContact.numbers),
//                        newContact.name,
//                        newContact.photoUri,
//                        newContact.starred,
//                        newContact.lastUpdate
//                    )
//                }
//                composeItems += contacts.asSequence().filter { contact -> contactFilter.filter(contact, normalizedQuery) }
//            }
//
//            composeItems
//        }.subscribeOn(Schedulers.computation()).autoDisposable(view.scope()).subscribe { items -> newState { copy(composeRecentItems = items) } }
//
//        //Group
//        Observables.combineLatest(
//            view.queryChangedIntent, contactGroups,
//        ) { query, contactGroups ->
//            val composeItems = mutableListOf<ContactGroup>()
//            if (query.isBlank()) {
//                composeItems += contactGroups
//            } else {
//                val normalizedQuery = query.removeAccents()
//                composeItems += contactGroups
//                    .asSequence()
//                    .filter { group -> contactGroupFilter.filter(group, normalizedQuery) }
//            }
//            composeItems
//        }.subscribeOn(Schedulers.computation()).autoDisposable(view.scope()).subscribe { items -> newState { copy(composeGroupItems = items) } }
//
//        view.queryEditorActionIntent.filter { actionId -> actionId == EditorInfo.IME_ACTION_DONE }.withLatestFrom(state) { _, state -> state }
//            .mapNotNull { state -> state.composeItems.firstOrNull() }.mergeWith(view.composeItemPressedIntent)
//            .map { composeItem -> composeItem to false }.mergeWith(view.composeItemLongPressedIntent.map { composeItem -> composeItem to true })
//            .observeOn(Schedulers.io()).map { (composeItem, force) ->
//                HashMap(composeItem.getContacts().associate { contact ->
//                    if (contact.numbers.size == 1 || contact.getDefaultNumber() != null && !force) {
//                        val address = contact.getDefaultNumber()?.address ?: contact.numbers[0]!!.address
//                        address to contact.lookupKey
//                    } else {
//                        runBlocking {
//                            newState { copy(selectedContact = contact) }
//                            val action = view.phoneNumberActionIntent.awaitFirst()
//                            newState { copy(selectedContact = null) }
//                            val numberId = view.phoneNumberSelectedIntent.awaitFirst().value
//                            val number = contact.numbers.find { number -> number.id == numberId }
//
//                            if (action == PhoneNumberAction.CANCEL || number == null) {
//                                return@runBlocking null
//                            }
//
//                            if (action == PhoneNumberAction.ALWAYS) {
//                                val params = SetDefaultPhoneNumber.Params(contact.lookupKey, number.id)
//                                setDefaultPhoneNumber.execute(params)
//                            }
//
//                            number.address to contact.lookupKey
//                        } ?: return@map hashMapOf<String, String?>()
//                    }
//                })
//            }.filter { result -> result.isNotEmpty() }.observeOn(AndroidSchedulers.mainThread()).autoDisposable(view.scope())
//            .subscribe { result -> view.finish(result) }

        /* Observables
             .combineLatest(contactGroups, contacts) { contactGroups, contacts ->
                 val composeItems = mutableListOf<Contact>()
                 composeItems += contacts
                 composeItems
             }
             .subscribeOn(Schedulers.computation())
             .autoDisposable(view.scope())
             .subscribe { items -> newState { copy(contact = ContactPage(contacts = conversationRepo.getUnmanagedConversations())) } }
     */
    }

}