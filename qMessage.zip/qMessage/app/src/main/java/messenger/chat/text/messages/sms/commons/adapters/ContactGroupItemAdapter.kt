package messenger.chat.text.messages.sms.commons.adapters

import android.view.ViewGroup
import androidx.core.view.isVisible
import messenger.chat.text.messages.sms.common.base.QkAdapter
import messenger.chat.text.messages.sms.common.base.QkViewHolder
import messenger.chat.text.messages.sms.databinding.ContactListItemGroupBinding
import messenger.chat.text.messages.sms.feature.main.MainActivity
import messenger.chat.text.messages.sms.model.Contact
import messenger.chat.text.messages.sms.model.ContactGroup
import messenger.chat.text.messages.sms.model.Recipient

class ContactGroupItemAdapter : QkAdapter<ContactGroup, ContactListItemGroupBinding>() {

    init {
        setHasStableIds(true)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QkViewHolder<ContactListItemGroupBinding> {
        return QkViewHolder(parent, ContactListItemGroupBinding::inflate).apply {
            binding.root.setOnClickListener {
                val item = getItem(adapterPosition)
                (it.context as? MainActivity)?.onContactGroupClick(item)
            }

            binding.root.setOnLongClickListener {
                val item = getItem(adapterPosition)
                (it.context as? MainActivity)?.onContactGroupLongClick(item)
                true
            }


        }
    }

    override fun onBindViewHolder(holder: QkViewHolder<ContactListItemGroupBinding>, position: Int) {
        val group = getItem(position) ?: return
        holder.binding.avatars.recipientsGroup = group.contacts.map(::createRecipient)
        holder.binding.title.text = group.title
        holder.binding.subtitle.text = "${group.contacts.size} People"
//        holder.binding.subtitle.collapseEnabled = group.contacts.size > 1
        holder.binding.subtitle.isVisible = holder.binding.subtitle.text.isNotEmpty()

    }

    private fun createRecipient(contact: Contact): Recipient {
        return Recipient(
            address = contact.numbers.firstOrNull()?.address ?: "",
            contact = contact
        )
    }

    override fun areContentsTheSame(old: ContactGroup, new: ContactGroup): Boolean {
        val oldIds = old.contacts.map { contact -> contact.lookupKey }
        val newIds = new.contacts.map { contact -> contact.lookupKey }
        return oldIds == newIds
    }

    override fun areItemsTheSame(old: ContactGroup, new: ContactGroup): Boolean {
        return false
    }

}
