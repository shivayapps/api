package messenger.chat.text.messages.sms.feature.scheduled

import messenger.chat.text.messages.sms.common.base.QkView
import io.reactivex.Observable

interface ScheduledView : QkView<ScheduledState> {

    val messageClickIntent: Observable<Long>
    val messageMenuIntent: Observable<Int>
    val composeIntent: Observable<*>

    fun showMessageOptions()

}
