package messenger.chat.text.messages.sms.feature.scheduled

import messenger.chat.text.messages.sms.model.ScheduledMessage
import io.realm.RealmResults

data class ScheduledState(
    val scheduledMessages: RealmResults<ScheduledMessage>? = null,
    val upgraded: Boolean = true
)
