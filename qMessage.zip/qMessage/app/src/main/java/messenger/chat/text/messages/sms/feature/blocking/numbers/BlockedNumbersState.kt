package messenger.chat.text.messages.sms.feature.blocking.numbers

import messenger.chat.text.messages.sms.model.BlockedNumber
import io.realm.RealmResults

data class BlockedNumbersState(
    val numbers: RealmResults<BlockedNumber>? = null
)
