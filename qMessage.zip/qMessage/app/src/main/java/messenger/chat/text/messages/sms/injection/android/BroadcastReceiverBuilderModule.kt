package messenger.chat.text.messages.sms.injection.android

import messenger.chat.text.messages.sms.feature.widget.WidgetProvider
import messenger.chat.text.messages.sms.injection.scope.ActivityScope
import messenger.chat.text.messages.sms.receiver.BlockThreadReceiver
import messenger.chat.text.messages.sms.receiver.BootReceiver
import messenger.chat.text.messages.sms.receiver.DefaultSmsChangedReceiver
import messenger.chat.text.messages.sms.receiver.DeleteMessagesReceiver
import messenger.chat.text.messages.sms.receiver.MarkArchivedReceiver
import messenger.chat.text.messages.sms.receiver.MarkReadReceiver
import messenger.chat.text.messages.sms.receiver.MarkSeenReceiver
import messenger.chat.text.messages.sms.receiver.MmsReceivedReceiver
import messenger.chat.text.messages.sms.receiver.MmsReceiver
import messenger.chat.text.messages.sms.receiver.MmsSentReceiver
import messenger.chat.text.messages.sms.receiver.MmsUpdatedReceiver
//import messenger.chat.text.messages.sms.receiver.NightModeReceiver
import messenger.chat.text.messages.sms.receiver.RemoteMessagingReceiver
import messenger.chat.text.messages.sms.receiver.SendScheduledMessageReceiver
import messenger.chat.text.messages.sms.receiver.SmsDeliveredReceiver
import messenger.chat.text.messages.sms.receiver.SmsProviderChangedReceiver
import messenger.chat.text.messages.sms.receiver.SmsReceiver
import messenger.chat.text.messages.sms.receiver.SmsSentReceiver
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class BroadcastReceiverBuilderModule {

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindBlockThreadReceiver(): BlockThreadReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindBootReceiver(): BootReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindDefaultSmsChangedReceiver(): DefaultSmsChangedReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindDeleteMessagesReceiver(): DeleteMessagesReceiver

    @ActivityScope
    @ContributesAndroidInjector
    abstract fun bindMarkArchivedReceiver(): MarkArchivedReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindMarkReadReceiver(): MarkReadReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindMarkSeenReceiver(): MarkSeenReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindMmsReceivedReceiver(): MmsReceivedReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindMmsReceiver(): MmsReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindMmsSentReceiver(): MmsSentReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindMmsUpdatedReceiver(): MmsUpdatedReceiver

//    @ActivityScope
//    @ContributesAndroidInjector()
//    abstract fun bindNightModeReceiver(): NightModeReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindRemoteMessagingReceiver(): RemoteMessagingReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindSendScheduledMessageReceiver(): SendScheduledMessageReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindSmsDeliveredReceiver(): SmsDeliveredReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindSmsProviderChangedReceiver(): SmsProviderChangedReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindSmsReceiver(): SmsReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindSmsSentReceiver(): SmsSentReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindWidgetProvider(): WidgetProvider

}