package messenger.chat.text.messages.sms.feature.gallery

import messenger.chat.text.messages.sms.common.base.QkView
import messenger.chat.text.messages.sms.model.MmsPart
import io.reactivex.Observable

interface GalleryView : QkView<GalleryState> {

    fun optionsItemSelected(): Observable<Int>
    fun screenTouched(): Observable<*>
    fun pageChanged(): Observable<MmsPart>

    fun requestStoragePermission()

}