package messenger.chat.text.messages.sms.feature.gallery

import messenger.chat.text.messages.sms.model.MmsPart
import io.realm.RealmResults

data class GalleryState(
    val navigationVisible: Boolean = true,
    val title: String? = "",
    val parts: RealmResults<MmsPart>? = null
)
