package com.android.mms.util;

import android.util.Log;

import com.klinker.android.send_message.BuildConfig;

public class AppUtils {
    public static void LogE(String tag, String msg) {
        if (BuildConfig.DEBUG) {
            Log.e(tag, msg);
        }
    }
    public static void LogW(String tag, String msg) {
        if (BuildConfig.DEBUG) {
            Log.w(tag, msg);
        }
    }
}
