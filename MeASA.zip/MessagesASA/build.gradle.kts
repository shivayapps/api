//import org.jetbrains.kotlin.gradle.internal.KaptWithoutKotlincTask

buildscript {
    dependencies {
        classpath("io.realm:realm-gradle-plugin:10.15.1")
    }
}

plugins {
    id("com.android.application") version "8.11.0" apply false
    id("com.android.library") version "8.11.0" apply false
//    id("org.jetbrains.kotlin.android") version "1.9.23" apply false
//    id("com.google.devtools.ksp") version "1.9.10-1.0.13" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("com.google.devtools.ksp") version "2.0.21-1.0.25" apply false
    id("com.google.gms.google-services") version "4.4.2" apply false
    id("com.google.firebase.crashlytics") version "3.0.2" apply false
}

tasks.register<Delete>("clean") {
    delete(rootProject.buildDir)
}

subprojects {
    afterEvaluate {
        if (project.extensions.findByName("kapt") != null) {
            project.extensions.configure<org.jetbrains.kotlin.gradle.plugin.KaptExtension>("kapt") {
                javacOptions {
                    option("-source", "8")
                    option("-target", "8")
                }
            }
        }
    }
}

//tasks.withType<KaptWithoutKotlincTask>().configureEach {
//    kaptJvmOptions {
//        jvmArgs.addAll(
//            listOf(
//                "--add-opens", "jdk.compiler/com.sun.tools.javac.api=ALL-UNNAMED",
//                "--add-opens", "jdk.compiler/com.sun.tools.javac.main=ALL-UNNAMED"
//            )
//        )
//    }
//}
