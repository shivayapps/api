package com.data.receiver

import com.android.mms.transaction.PushReceiver

class MmsReceiver : PushReceiver()