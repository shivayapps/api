package com.domain.interactor

import io.reactivex.Flowable
import com.domain.extensions.LogE
import com.domain.repository.SyncRepository
import javax.inject.Inject

class SyncContacts @Inject constructor(private val syncManager: SyncRepository) :
    Interactor<Unit>() {

    override fun buildObservable(params: Unit): Flowable<Long> {
        return Flowable.just(System.currentTimeMillis())
            .doOnNext { syncManager.syncContacts() }
            .map { startTime -> System.currentTimeMillis() - startTime }
            .doOnNext { duration -> LogE("messageApp : ", "Completed sync in ${duration}ms") }
    }
}