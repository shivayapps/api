package com.three_cube.music.util

interface SongChangeNotifier {
    fun onCurrentSongChange()
}