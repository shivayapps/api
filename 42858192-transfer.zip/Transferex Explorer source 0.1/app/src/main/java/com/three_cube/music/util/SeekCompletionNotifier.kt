package com.three_cube.music.util

interface SeekCompletionNotifier {
    fun onSeekComplete()
}