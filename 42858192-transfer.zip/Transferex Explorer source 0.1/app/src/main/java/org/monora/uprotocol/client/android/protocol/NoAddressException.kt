package org.monora.uprotocol.client.android.protocol

import org.monora.uprotocol.core.protocol.communication.ProtocolException

class NoAddressException : ProtocolException()