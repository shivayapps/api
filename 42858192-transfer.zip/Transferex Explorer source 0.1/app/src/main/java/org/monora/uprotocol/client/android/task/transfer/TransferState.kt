package org.monora.uprotocol.client.android.task.transfer

sealed class TransferState {

}