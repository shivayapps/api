package org.monora.uprotocol.client.android.config

object AppConfig {
    const val SERVER_PORT_WEBSHARE = 58732

    const val DEFAULT_TIMEOUT_SOCKET = 5000

    const val DELAY_DEFAULT_NOTIFICATION = 1000

    const val PREFIX_ACCESS_POINT = "TS_"

    const val EXT_FILE_PART = "tshare"

    val DEFAULT_DISABLED_INTERFACES = arrayOf("rmnet")

    const val STORAGE_LOCATION = "STORAGE_LOCATION"

    const val CATEGORY = "CATEGORY"

    const val SHARE = "SHARE"

    const val INTENT_STORAGE_PATH = "intent_storage_path"

    const val BUFFER_LENGTH_DEFAULT = 4 * 1024 // IOUtils#DEFAULT_BUFFER_SIZE/8096

    const val DEFAULT_SOCKET_TIMEOUT = 5000

    const val SHOW_HIDDEN = "show_hidden"

    const val temporaryStopAds = "temporary_stop_ads"

    const val EXTRA_CATEGORY_TAB = "extraCategoryTab"

    const val CATEGORY_AUDIO = "Audios"
    const val CATEGORY_DOWNLOAD = "Downloads"
    const val CATEGORY_IMAGE = "Images"
    const val CATEGORY_VIDEO = "Videos"
    const val CATEGORY_DOCUMENT_OTHER = "Documents & other"
    const val CATEGORY_APP = "Apps"

    const val REFRESH_UPDATE = "ExplorerFragment.REFRESH_UPDATE"
}
