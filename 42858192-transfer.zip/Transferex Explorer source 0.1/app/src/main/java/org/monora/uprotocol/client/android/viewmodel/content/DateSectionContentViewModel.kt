package org.monora.uprotocol.client.android.viewmodel.content

import org.monora.uprotocol.client.android.model.DateSectionContentModel

class DateSectionContentViewModel(dateSectionContentModel: DateSectionContentModel) {
    val dateText = dateSectionContentModel.dateText
}