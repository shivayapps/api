package com.solid.color.wallpaper.hd.image.background.model

class StickerNewModel(var path: String, var isFree: Boolean)