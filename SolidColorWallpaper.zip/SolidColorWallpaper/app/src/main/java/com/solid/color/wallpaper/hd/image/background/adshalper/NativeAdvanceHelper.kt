package com.solid.color.wallpaper.hd.image.background.adshalper

//import com.google.android.gms.ads.formats.UnifiedNativeAdView
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import com.facebook.ads.*
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.VideoController.VideoLifecycleCallbacks
import com.google.android.gms.ads.formats.UnifiedNativeAd
import com.google.android.gms.ads.nativead.NativeAdView
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.appid.AppIDs
import com.solid.color.wallpaper.hd.image.background.R
import java.util.*

@SuppressLint("StaticFieldLeak")
object NativeAdvanceHelper {
    var TAG = "Ads_123"
    var nativeAd: com.google.android.gms.ads.nativead.NativeAd? = null
    var miAdNumber = 1
    private var nativeAdFb: NativeAd? = null
    private var adView: LinearLayout? = null
    private var isFbLoaded = false
    private const val isFbLoadedSmall = false
    public var onFbAdListner: onFbAdListnerNative? = null
    var facebookBanner = AppIDs.instnace!!.getFacebookBanner()
    var facebookNativeBanner = AppIDs.instnace!!.getFacebookNativeBanner()

    // 1. Add container in xml+
    /* add this dependency in app level gradle
     * implementation 'com.google.android.gms:play-services-ads:17.2.1'
     * */
    /* Add this style in style.xml

      <style name="AppTheme.AdAttribution">
        <item name="android:layout_width">wrap_content</item>
        <item name="android:layout_height">wrap_content</item>
        <item name="android:layout_gravity">left</item>
        <item name="android:textColor">#FFFFFF</item>
        <item name="android:textSize">12sp</item>
        <item name="android:text">@string/ad_attribution</item>
        <item name="android:background">@color/colorPrimaryDark</item>
        <item name="android:width">20dp</item>
        <item name="android:height">20dp</item>
    </style>

   */
    /* <FrameLayout
    android:id="@+id/fl_adplaceholder"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:layout_centerInParent="true" />*/
    // 2. Add in onCreate() method
    //   NativeAdvanceHelper.loadAd(mContext, (FrameLayout) findViewById(R.id.fl_adplaceholder));
    // 3. Add in onDestroy() method
    //       NativeAdvanceHelper.onDestroy();
    /**
     * Creates a request for a new native ad based on the boolean parameters and calls the
     * corresponding "populate" method when one is successfully returned.
     */
    fun loadAd(mContext: Context, frameLayout: FrameLayout) {
        /* if (!Share.isNeedToAdShow(mContext)){
            return;
        }*/
        var googleNative = AppIDs.instnace!!.getGoogleNative()

        val builder: AdLoader.Builder
        builder = if (miAdNumber == 1) {
            AdLoader.Builder(mContext, googleNative)
        } else if (miAdNumber == 2) {
            AdLoader.Builder(mContext, googleNative)
        } else {
            AdLoader.Builder(mContext, googleNative)
        }
        builder.forNativeAd { nativeAd ->
            if (nativeAd != null) {
                nativeAd!!.destroy()
            }
//            nativeAd = unifiedNativeAd
            val adView = (mContext as Activity).layoutInflater.inflate(R.layout.layout_native_large_demo, null) as NativeAdView
            populateUnifiedNativeAdView(nativeAd, adView)
            frameLayout.removeAllViews()
            frameLayout.addView(adView)
        }
        val adLoader = builder.withAdListener(object : AdListener() {

            override fun onAdFailedToLoad(p0: LoadAdError) {
                super.onAdFailedToLoad(p0)
                Log.i(TAG, "on Native AdFailedToLoad: $miAdNumber  errorCode: $p0")
                if (miAdNumber == 1) {
                    miAdNumber++
                } else if (miAdNumber == 2) {
                    miAdNumber = 0
                } else {
                    miAdNumber = 1
                }
                loadAd(mContext, frameLayout)
            }

            override fun onAdLoaded() {
                super.onAdLoaded()
                Log.i(TAG, "on Native AdLoaded: $miAdNumber")
                miAdNumber = 1
            }
        }).build()
        adLoader.loadAd(AdRequest.Builder().build())
    }

    @JvmStatic
    fun loadAdLarge(mContext: Context?, frameLayout: FrameLayout) {
        /* if (!Share.isNeedToAdShow(mContext)){
            return;
        }*/
        var googleNative = AppIDs.instnace!!.getGoogleNative()

        if (mContext != null) {
            val builder: AdLoader.Builder
            builder = if (miAdNumber == 1) {
                AdLoader.Builder(mContext, googleNative)
            } else if (miAdNumber == 2) {
                AdLoader.Builder(mContext, googleNative)
            } else {
                AdLoader.Builder(mContext, googleNative)
            }
            builder.forNativeAd { unifiedNativeAd ->
                if (nativeAd != null) {
                    nativeAd!!.destroy()
                }
                nativeAd = unifiedNativeAd
                val adView = (mContext as Activity).layoutInflater.inflate(R.layout.layout_native_large_demo, null) as NativeAdView
                populateUnifiedNativeAdView(unifiedNativeAd, adView)
                frameLayout.removeAllViews()
                frameLayout.addView(adView)
            }
            val adLoader = builder.withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(p0: LoadAdError) {
                    super.onAdFailedToLoad(p0)
                    Log.i(TAG, "on Native AdFailedToLoad: $miAdNumber  errorCode: $p0")
                    if (miAdNumber == 1) {
                        miAdNumber++
                    } else if (miAdNumber == 2) {
                        miAdNumber = 0
                    } else {
                        miAdNumber = 1
                    }
                    loadAd(mContext, frameLayout)
                }

                override fun onAdLoaded() {
                    super.onAdLoaded()
                    Log.i(TAG, "on Native AdLoaded: $miAdNumber")
                    miAdNumber = 1
                }
            }).build()
            adLoader.loadAd(AdRequest.Builder().build())
        }
    }

    fun loadAdSmallBannerNative(mContext: Context, frameLayout: FrameLayout) {
        /* if (!Share.isNeedToAdShow(mContext)){
            return;
        }*/
        var googleNative = AppIDs.instnace!!.getGoogleNative()
        val builder: AdLoader.Builder
        builder = if (miAdNumber == 1) {
            AdLoader.Builder(mContext, googleNative)
        } else if (miAdNumber == 2) {
            AdLoader.Builder(mContext, googleNative)
        } else {
            AdLoader.Builder(mContext, googleNative)
        }
        builder.forNativeAd { unifiedNativeAd ->
            if (nativeAd != null) {
                nativeAd!!.destroy()
            }
            nativeAd = unifiedNativeAd
            val adView = (mContext as Activity).layoutInflater.inflate(R.layout.layout_native_banner_google, null) as NativeAdView
            populateUnifiedNativeAdView(unifiedNativeAd, adView)
            frameLayout.removeAllViews()
            frameLayout.addView(adView)
        }
        val adLoader = builder.withAdListener(object : AdListener() {
            override fun onAdFailedToLoad(p0: LoadAdError) {
                super.onAdFailedToLoad(p0)
                Log.i(TAG, "on Native AdFailedToLoad: $miAdNumber  errorCode: $p0")
                if (miAdNumber == 1) {
                    miAdNumber++
                } else if (miAdNumber == 2) {
                    miAdNumber = 0
                } else {
                    miAdNumber = 1
                }
                // loadAd(mContext, frameLayout);
            }

            override fun onAdLoaded() {
                super.onAdLoaded()
                Log.i(TAG, "on Native AdLoaded: $miAdNumber")
                miAdNumber = 1
            }
        }).build()
        adLoader.loadAd(AdRequest.Builder().build())
    }

    fun loadAdSmall(mContext: Context, frameLayout: FrameLayout) {
//        AdLoader.Builder builder = new AdLoader.Builder(this, ADMOB_AD_UNIT_ID);

        /* if (!Share.isNeedToAdShow(mContext)){
            return;
        }*/
        var googleNative = AppIDs.instnace!!.getGoogleNative()
        val builder: AdLoader.Builder
        builder = if (miAdNumber == 1) {
            AdLoader.Builder(mContext, googleNative)
        } else if (miAdNumber == 2) {
            AdLoader.Builder(mContext, googleNative)
        } else {
            AdLoader.Builder(mContext, googleNative)
        }
        builder.forNativeAd { unifiedNativeAd ->
            if (nativeAd != null) {
                nativeAd!!.destroy()
            }
            nativeAd = unifiedNativeAd
            val adView = (mContext as Activity).layoutInflater.inflate(R.layout.layout_native_small, null) as NativeAdView
            populateUnifiedNativeAdView(unifiedNativeAd, adView)
            frameLayout.removeAllViews()
            frameLayout.addView(adView)
        }
        val adLoader = builder.withAdListener(object : AdListener() {
            override fun onAdFailedToLoad(p0: LoadAdError) {
                super.onAdFailedToLoad(p0)
                Log.i(TAG, "on Native AdFailedToLoad: $miAdNumber  errorCode: $p0")
                if (miAdNumber == 1) {
                    miAdNumber++
                } else if (miAdNumber == 2) {
                    miAdNumber = 0
                } else {
                    miAdNumber = 1
                }
                loadAdSmall(mContext, frameLayout)
            }

            override fun onAdLoaded() {
                super.onAdLoaded()
                Log.i(TAG, "on Native AdLoaded: $miAdNumber")
                miAdNumber = 1
            }
        }).build()
        adLoader.loadAd(AdRequest.Builder().build())
    }

    /**
     * Populates a [UnifiedNativeAdView] object with data from a given
     * [UnifiedNativeAd].
     *
     * @param nativeAd the object containing the ad's assets
     * @param adView   the view to be populated
     */
    private fun populateUnifiedNativeAdView(nativeAd: com.google.android.gms.ads.nativead.NativeAd, adView: NativeAdView) {
        val mediaView: com.google.android.gms.ads.nativead.MediaView = adView.findViewById(R.id.ad_media)
        val mainImageView = adView.findViewById<ImageView>(R.id.ad_image)
        val vc = nativeAd.mediaContent.videoController
        vc.videoLifecycleCallbacks = object : VideoLifecycleCallbacks() {
            override fun onVideoEnd() {
                super.onVideoEnd()
            }
        }
        if (vc.hasVideoContent()) {
            adView.mediaView = mediaView
            mainImageView.visibility = View.GONE
        } else {
            adView.imageView = mainImageView
            mediaView.visibility = View.GONE
            val images = nativeAd.images
            if (images.size != 0) {
                mainImageView.setImageDrawable(images[0].drawable)
            }
        }
        adView.headlineView = adView.findViewById(R.id.ad_headline)
        adView.bodyView = adView.findViewById(R.id.ad_body)
        adView.callToActionView = adView.findViewById(R.id.ad_call_to_action)
        adView.iconView = adView.findViewById(R.id.ad_app_icon)
        (adView.headlineView as TextView).text = nativeAd.headline
        (adView.bodyView as TextView).text = nativeAd.body
        (adView.callToActionView as Button).text = nativeAd.callToAction
        if (nativeAd.icon == null) {
            adView.iconView.visibility = View.GONE
        } else {
            (adView.iconView as ImageView).setImageDrawable(
                    nativeAd.icon.drawable)
            adView.iconView.visibility = View.VISIBLE
        }
        adView.setNativeAd(nativeAd)
    }

    @JvmStatic
    fun loadNativeAdFb(context: Context?, nativeAdLayout: NativeAdLayout, onFbAdListner: onFbAdListnerNative?): NativeAd? {
        // Instantiate a NativeAd object.
        // NOTE: the placement ID will eventually identify this as your App, you can ignore it for
        // now, while you are testing and replace it later when you have signed up.
        // While you are using this temporary code you will only get test ads and if you release
        // your code like this to the Google Play your users will not receive ads (you will get a no fill error).

        // You must call destroy on old ads when you are done with them,
        // otherwise you will have a memory leak.
        if (context != null) {

            var facebookNative = AppIDs.instnace!!.getRandomNative()

            NativeAdvanceHelper.onFbAdListner = onFbAdListner
            if (nativeAdFb != null) {
                nativeAdFb!!.destroy()
            }
            AdSettings.addTestDevice("b5c0da10-01f3-42b1-a585-i")
            nativeAdFb = NativeAd(context, facebookNative)
            nativeAdFb!!.buildLoadAdConfig().withAdListener(object : NativeAdListener {
                override fun onMediaDownloaded(ad: Ad) {
                    // Native ad finished downloading all assets
                    Log.e(TAG, "Native ad finished downloading all assets.")
                }

                override fun onError(ad: Ad, adError: AdError) {
                    // Native ad failed to load
                    isFbLoaded = false
                    if (NativeAdvanceHelper.onFbAdListner != null) {
                        NativeAdvanceHelper.onFbAdListner!!.isError(true)
                    }
                    Log.e(TAG, "Native ad failed to load: " + adError.errorMessage)
                }

                override fun onAdLoaded(ad: Ad) {
                    // Native ad is loaded and ready to be displayed
                    isFbLoaded = true
                    if (nativeAdFb == null || nativeAdFb !== ad) {
                        return
                    }
                    // Inflate Native Ad into Container
                    inflateAd(nativeAdFb, context, nativeAdLayout)
                    if (NativeAdvanceHelper.onFbAdListner != null) {
                        NativeAdvanceHelper.onFbAdListner!!.isLoadedAd(true)
                    }
                    Log.d(TAG, "Native ad is loaded and ready to be displayed!")
                }

                override fun onAdClicked(ad: Ad) {
                    // Native ad clicked
                    Log.d(TAG, "Native ad clicked!")
                }

                override fun onLoggingImpression(ad: Ad) {
                    // Native ad impression
                    Log.d(TAG, "Native ad impression logged!")
                }
            })

            // Request an ad
            nativeAdFb!!.loadAd()
        }
        return nativeAdFb
    }

    private fun inflateAd(nativeAd: NativeAd?, context: Context, nativeAdLayout: NativeAdLayout) {
        nativeAd!!.unregisterView()

        // Add the Ad view into the ad container.
        // frameLayout = findViewById(R.id.native_ad_container);
        val inflater = LayoutInflater.from(context)
        // Inflate the Ad view.  The layout referenced should be the one you created in the last step.
        adView = inflater.inflate(R.layout.layout_facebook_native, nativeAdLayout, false) as LinearLayout
        nativeAdLayout.addView(adView)

        // Add the AdOptionsView
        val adChoicesContainer = adView!!.findViewById<LinearLayout>(R.id.ad_choices_container)
        val adOptionsView = AdOptionsView(context, nativeAd, nativeAdLayout)
        adChoicesContainer.removeAllViews()
        adChoicesContainer.addView(adOptionsView, 0)

        // Create native UI using the ad metadata.
        val nativeAdIcon: com.facebook.ads.MediaView = adView!!.findViewById(R.id.native_ad_icon)
        val nativeAdTitle = adView!!.findViewById<TextView>(R.id.native_ad_title)
        val nativeAdMedia: com.facebook.ads.MediaView = adView!!.findViewById(R.id.native_ad_media)
        val nativeAdSocialContext = adView!!.findViewById<TextView>(R.id.native_ad_social_context)
        val nativeAdBody = adView!!.findViewById<TextView>(R.id.native_ad_body)
        val sponsoredLabel = adView!!.findViewById<TextView>(R.id.native_ad_sponsored_label)
        val nativeAdCallToAction = adView!!.findViewById<Button>(R.id.native_ad_call_to_action)

        // Set the Text.
        nativeAdTitle.text = nativeAd.advertiserName
        nativeAdBody.text = nativeAd.adBodyText
        nativeAdSocialContext.text = nativeAd.adSocialContext
        nativeAdCallToAction.visibility = if (nativeAd.hasCallToAction()) View.VISIBLE else View.INVISIBLE
        nativeAdCallToAction.text = nativeAd.adCallToAction
        sponsoredLabel.text = nativeAd.sponsoredTranslation

        // Create a list of clickable views
        val clickableViews: MutableList<View> = ArrayList()
        clickableViews.add(nativeAdTitle)
        clickableViews.add(nativeAdCallToAction)

        // Register the Title and CTA button to listen for clicks.
        nativeAd.registerViewForInteraction(
                adView,
                nativeAdMedia,
                nativeAdIcon,
                clickableViews)
    }

    fun loadNativeAdFbSmall(context: Context, nativeAdLayout: NativeAdLayout, onFbAdListner: onFbAdListnerNative?) {
        // Instantiate a NativeAd object.
        // NOTE: the placement ID will eventually identify this as your App, you can ignore it for
        // now, while you are testing and replace it later when you have signed up.
        // While you are using this temporary code you will only get test ads and if you release
        // your code like this to the Google Play your users will not receive ads (you will get a no fill error).
        NativeAdvanceHelper.onFbAdListner = onFbAdListner

        // You must call destroy on old ads when you are done with them,
        // otherwise you will have a memory leak.
        if (nativeAdFb != null) {
            nativeAdFb!!.destroy()
        }
        var facebookNative = AppIDs.instnace!!.getRandomNative()
        AdSettings.addTestDevice("68c66509-e5f3-462f-9b3c-734432ab111f")
        nativeAdFb = NativeAd(context, facebookNative)
        nativeAdFb!!.buildLoadAdConfig().withAdListener(object : NativeAdListener {
            override fun onMediaDownloaded(ad: Ad) {
                // Native ad finished downloading all assets
                Log.e(TAG, "Native ad finished downloading all assets.")
            }

            override fun onError(ad: Ad, adError: AdError) {
                // Native ad failed to load
                NativeAdvanceHelper.onFbAdListner!!.isError(true)
                Log.e(TAG, "Native ad failed to load: " + adError.errorMessage)
            }

            override fun onAdLoaded(ad: Ad) {
                // Native ad is loaded and ready to be displayed
                if (nativeAdFb == null || nativeAdFb !== ad) {
                    return
                }
                // Inflate Native Ad into Container
                inflateAdSmall(nativeAdFb, context, nativeAdLayout)
                NativeAdvanceHelper.onFbAdListner!!.isLoadedAd(true)
                Log.d(TAG, "Native ad is loaded and ready to be displayed!")
            }

            override fun onAdClicked(ad: Ad) {
                // Native ad clicked
                Log.d(TAG, "Native ad clicked!")
            }

            override fun onLoggingImpression(ad: Ad) {
                // Native ad impression
                Log.d(TAG, "Native ad impression logged!")
            }
        })

        // Request an ad
        nativeAdFb!!.loadAd()
    }

    private fun inflateAdSmall(nativeAd: NativeAd?, context: Context, nativeAdLayout: NativeAdLayout) {
        nativeAd!!.unregisterView()

        // Add the Ad view into the ad container.
        // frameLayout = findViewById(R.id.native_ad_container);
        val inflater = LayoutInflater.from(context)
        // Inflate the Ad view.  The layout referenced should be the one you created in the last step.
        adView = inflater.inflate(R.layout.native_fb_ad_small, nativeAdLayout, false) as LinearLayout
        nativeAdLayout.addView(adView)

        // Add the AdOptionsView
        val adChoicesContainer = adView!!.findViewById<LinearLayout>(R.id.ad_choices_container)
        val adOptionsView = AdOptionsView(context, nativeAd, nativeAdLayout)
        adChoicesContainer.removeAllViews()
        adChoicesContainer.addView(adOptionsView, 0)

        // Create native UI using the ad metadata.
        val nativeAdIcon: com.facebook.ads.MediaView = adView!!.findViewById(R.id.native_ad_icon)
        val nativeAdTitle = adView!!.findViewById<TextView>(R.id.native_ad_title)
        val nativeAdMedia: com.facebook.ads.MediaView = adView!!.findViewById(R.id.native_ad_media)
        val nativeAdSocialContext = adView!!.findViewById<TextView>(R.id.native_ad_social_context)
        val nativeAdBody = adView!!.findViewById<TextView>(R.id.native_ad_body)
        val sponsoredLabel = adView!!.findViewById<TextView>(R.id.native_ad_sponsored_label)
        val nativeAdCallToAction = adView!!.findViewById<Button>(R.id.native_ad_call_to_action)

        // Set the Text.
        nativeAdTitle.text = nativeAd.advertiserName
        nativeAdBody.text = nativeAd.adBodyText
        nativeAdSocialContext.text = nativeAd.adSocialContext
        nativeAdCallToAction.visibility = if (nativeAd.hasCallToAction()) View.VISIBLE else View.INVISIBLE
        nativeAdCallToAction.text = nativeAd.adCallToAction
        sponsoredLabel.text = nativeAd.sponsoredTranslation

        // Create a list of clickable views
        val clickableViews: MutableList<View> = ArrayList()
        clickableViews.add(nativeAdTitle)
        clickableViews.add(nativeAdCallToAction)

        // Register the Title and CTA button to listen for clicks.
        nativeAd.registerViewForInteraction(
                adView,
                nativeAdMedia,
                nativeAdIcon,
                clickableViews)
    }

    fun loadNativeAdFbSmallBanner(context: Context, nativeAdLayout: NativeAdLayout, onFbAdListner: onFbAdListnerNative?) {
        // Instantiate a NativeAd object.
        // NOTE: the placement ID will eventually identify this as your App, you can ignore it for
        // now, while you are testing and replace it later when you have signed up.
        // While you are using this temporary code you will only get test ads and if you release
        // your code like this to the Google Play your users will not receive ads (you will get a no fill error).
        NativeAdvanceHelper.onFbAdListner = onFbAdListner

        // You must call destroy on old ads when you are done with them,
        // otherwise you will have a memory leak.
        if (nativeAdFb != null) {
            nativeAdFb!!.destroy()
        }
        var facebookNative = AppIDs.instnace!!.getRandomNative()
        AdSettings.addTestDevice("68c66509-e5f3-462f-9b3c-734432ab111f")
        nativeAdFb = NativeAd(context, facebookNative)

//        if (Constants.isNativeAd1) {
//            Log.d("78945123", "loadNativeAdFbSmall: 1")
//            NativeAd(context, context.getString(R.string.facebook_native_ad_unit_id3))
//        }
//        else {
//            Log.d("78945123", "loadNativeAdFbSmall: 2")
//            NativeAd(context, context.getString(R.string.facebook_native_ad_unit_id2))
//        }
        nativeAdFb!!.buildLoadAdConfig().withAdListener(object : NativeAdListener {
            override fun onMediaDownloaded(ad: Ad) {
                // Native ad finished downloading all assets
                Log.e(TAG, "Native ad finished downloading all assets.")
            }

            override fun onError(ad: Ad, adError: AdError) {
                // Native ad failed to load
                NativeAdvanceHelper.onFbAdListner!!.isError(true)
                Log.e(TAG, "Native ad failed to load: " + adError.errorMessage)
            }

            override fun onAdLoaded(ad: Ad) {
                // Native ad is loaded and ready to be displayed
                if (nativeAdFb == null || nativeAdFb !== ad) {
                    return
                }
                // Inflate Native Ad into Container
                inflateAdSmallBanner(nativeAdFb, context, nativeAdLayout)
                NativeAdvanceHelper.onFbAdListner!!.isLoadedAd(true)
                Log.d(TAG, "Native ad is loaded and ready to be displayed!")
            }

            override fun onAdClicked(ad: Ad) {
                // Native ad clicked
                Log.d(TAG, "Native ad clicked!")
            }

            override fun onLoggingImpression(ad: Ad) {
                // Native ad impression
                Log.d(TAG, "Native ad impression logged!")
            }
        })

        // Request an ad
        nativeAdFb!!.loadAd()
    }

    fun loadNativeAdFbSmallBanner1(context: Context, nativeAdLayout: NativeAdLayout, onFbAdListner: onFbAdListnerNative?) {
        // Instantiate a NativeAd object.
        // NOTE: the placement ID will eventually identify this as your App, you can ignore it for
        // now, while you are testing and replace it later when you have signed up.
        // While you are using this temporary code you will only get test ads and if you release
        // your code like this to the Google Play your users will not receive ads (you will get a no fill error).
        NativeAdvanceHelper.onFbAdListner = onFbAdListner

        // You must call destroy on old ads when you are done with them,
        // otherwise you will have a memory leak.
        if (nativeAdFb != null) {
            nativeAdFb!!.destroy()
        }
        var facebookNative = AppIDs.instnace!!.getRandomNative()
        AdSettings.addTestDevice("68c66509-e5f3-462f-9b3c-734432ab111f")
        nativeAdFb = NativeAd(context, facebookNative)

//        if (Constants.isNativeAd1) {
//            Log.d("78945123", "loadNativeAdFbSmall: 1")
//            NativeAd(context, context.getString(R.string.facebook_native_ad_unit_id3))
//        }
//        else {
//            Log.d("78945123", "loadNativeAdFbSmall: 2")
//            NativeAd(context, context.getString(R.string.facebook_native_ad_unit_id2))
//        }
        nativeAdFb!!.buildLoadAdConfig().withAdListener(object : NativeAdListener {
            override fun onMediaDownloaded(ad: Ad) {
                // Native ad finished downloading all assets
                Log.e(TAG, "Native ad finished downloading all assets.")
            }

            override fun onError(ad: Ad, adError: AdError) {
                // Native ad failed to load
                NativeAdvanceHelper.onFbAdListner!!.isError(true)
                Log.e(TAG, "Native ad failed to load: " + adError.errorMessage)
            }

            override fun onAdLoaded(ad: Ad) {
                // Native ad is loaded and ready to be displayed
                if (nativeAdFb == null || nativeAdFb !== ad) {
                    return
                }
                // Inflate Native Ad into Container
                inflateAdSmallBanner(nativeAdFb, context, nativeAdLayout)
                NativeAdvanceHelper.onFbAdListner!!.isLoadedAd(true)
                Log.d(TAG, "Native ad is loaded and ready to be displayed!")
            }

            override fun onAdClicked(ad: Ad) {
                // Native ad clicked
                Log.d(TAG, "Native ad clicked!")
            }

            override fun onLoggingImpression(ad: Ad) {
                // Native ad impression
                Log.d(TAG, "Native ad impression logged!")
            }
        })

        // Request an ad
        nativeAdFb!!.loadAd()
    }

    private fun inflateAdSmallBanner(nativeAd: NativeAd?, context: Context, nativeAdLayout: NativeAdLayout) {
        nativeAd!!.unregisterView()

        // Add the Ad view into the ad container.
        // frameLayout = findViewById(R.id.native_ad_container);
        val inflater = LayoutInflater.from(context)
        // Inflate the Ad view.  The layout referenced should be the one you created in the last step.
        adView = inflater.inflate(R.layout.layout_native_banner_fb, nativeAdLayout, false) as LinearLayout
        nativeAdLayout.addView(adView)

        // Add the AdOptionsView
        val adChoicesContainer = adView!!.findViewById<LinearLayout>(R.id.ad_choices_container)
        val adOptionsView = AdOptionsView(context, nativeAd, nativeAdLayout)
        adChoicesContainer.removeAllViews()
        adChoicesContainer.addView(adOptionsView, 0)

        // Create native UI using the ad metadata.
        val nativeAdIcon: com.facebook.ads.MediaView = adView!!.findViewById(R.id.native_ad_icon)
        val nativeAdTitle = adView!!.findViewById<TextView>(R.id.native_ad_title)
        val nativeAdMedia: com.facebook.ads.MediaView = adView!!.findViewById(R.id.native_ad_media)
        val nativeAdSocialContext = adView!!.findViewById<TextView>(R.id.native_ad_social_context)
        val nativeAdBody = adView!!.findViewById<TextView>(R.id.native_ad_body)
        val sponsoredLabel = adView!!.findViewById<TextView>(R.id.native_ad_sponsored_label)
        val nativeAdCallToAction = adView!!.findViewById<Button>(R.id.native_ad_call_to_action)

        // Set the Text.
        nativeAdTitle.text = nativeAd.advertiserName
        //nativeAdBody.text = nativeAd.adBodyText
        //nativeAdSocialContext.text = nativeAd.adSocialContext
        nativeAdCallToAction.visibility = if (nativeAd.hasCallToAction()) View.VISIBLE else View.INVISIBLE
        nativeAdCallToAction.text = nativeAd.adCallToAction
        sponsoredLabel.text = nativeAd.sponsoredTranslation

        // Create a list of clickable views
        val clickableViews: MutableList<View> = ArrayList()
        clickableViews.add(nativeAdTitle)
        clickableViews.add(nativeAdCallToAction)

        // Register the Title and CTA button to listen for clicks.
        nativeAd.registerViewForInteraction(
                adView,
                nativeAdMedia,
                nativeAdIcon,
                clickableViews)
    }

    @JvmStatic
    fun onDestroy() {
        if (nativeAd != null) {
            nativeAd!!.destroy()
        }
        if (nativeAdFb != null) {
            nativeAdFb!!.destroy()
        }
    }

    interface onFbAdListnerNative {
        fun isLoadedAd(isLoaded: Boolean?)
        fun isError(isError: Boolean?)
    }
}