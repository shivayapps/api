package com.solid.color.wallpaper.hd.image.background.custom

import android.app.Activity
import android.app.Application
import android.os.Bundle

class ApplicationLifecycleManager : Application.ActivityLifecycleCallbacks {
    override fun onActivityCreated(activity: Activity, bundle: Bundle?) {}
    override fun onActivityDestroyed(activity: Activity) {}
    override fun onActivityResumed(activity: Activity) {
        foregroundActivityCount++
    }

    override fun onActivityPaused(activity: Activity) {
        foregroundActivityCount--
    }

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
    override fun onActivityStarted(activity: Activity) {
        visibleActivityCount++
    }

    override fun onActivityStopped(activity: Activity) {
        visibleActivityCount--
    }

    companion object {

        private var visibleActivityCount = 0

        private var foregroundActivityCount = 0

        val isAppInForeground: Boolean
            get() = foregroundActivityCount > 0

        val isAppVisible: Boolean
            get() = visibleActivityCount > 0
    }
}