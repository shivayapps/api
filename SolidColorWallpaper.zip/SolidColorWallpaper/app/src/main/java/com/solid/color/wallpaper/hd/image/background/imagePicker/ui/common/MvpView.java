package com.solid.color.wallpaper.hd.image.background.imagePicker.ui.common;

public interface MvpView {
}
