package com.solid.color.wallpaper.hd.image.background.model

import android.graphics.Color

class SolidColorModel {
    var color = 0
    var imagePosition = -1
    var imageColor = Color.WHITE

}