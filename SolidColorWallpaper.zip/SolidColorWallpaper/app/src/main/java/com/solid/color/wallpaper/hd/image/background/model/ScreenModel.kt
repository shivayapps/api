package com.solid.color.wallpaper.hd.image.background.model

class ScreenModel(var path: String, var isFree: Boolean)