package com.solid.color.wallpaper.hd.image.background.adData

import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.constants.Constants
import java.util.*

class AdsAdapter(private val context: Context, list: ArrayList<AdDetailModel?>, onItemClickListener: OnItemClickListener) : RecyclerView.Adapter<AdsAdapter.MyViewHolder>() {
    private var list = ArrayList<AdDetailModel?>()
    private val mOnItemClickListener: OnItemClickListener

    interface OnItemClickListener {
        fun onItemClick(view: View?, position: Int)
    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var imgAppIcon: ImageView
        var appName: TextView
        var progressBar: ProgressBar
        var btnInstall: Button

        init {
            imgAppIcon = itemView.findViewById(R.id.imgAppIcon)
            progressBar = itemView.findViewById(R.id.progressBar)
            appName = itemView.findViewById(R.id.appName)
            btnInstall = itemView.findViewById(R.id.btnInstall)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.layout_more_app_item_1, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        if (list[position] != null) {
            Glide.with(context)
                    .load(list[position]!!.thumb_image)
                    .thumbnail(0.1f)
                    .override(130, 130)
                    .listener(object : RequestListener<Drawable?> {
                        override fun onLoadFailed(e: GlideException?, model: Any, target: Target<Drawable?>, isFirstResource: Boolean): Boolean {
                            holder.progressBar.visibility = View.GONE
                            return false
                        }

                        override fun onResourceReady(resource: Drawable?, model: Any, target: Target<Drawable?>, dataSource: DataSource, isFirstResource: Boolean): Boolean {
                            holder.progressBar.visibility = View.GONE
                            return false
                        }
                    })
                    .into(holder.imgAppIcon)
            holder.appName.text = list[position]!!.name
            Constants.isAdsLoaded = true
            //holder.imgAppIcon.setImageDrawable(list.get(position).getThumb_image());
            holder.btnInstall.setOnClickListener { v -> mOnItemClickListener.onItemClick(v, position) }
        } else {
            Constants.isAdsLoaded = true
        }
    }

    fun addApp(mList: ArrayList<AdDetailModel?>) {
        list = mList
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int {
        return list.size
    }

    companion object {
        private const val TAG = "ShapeAdapter"
    }

    init {
        this.list = list
        mOnItemClickListener = onItemClickListener
    }
}