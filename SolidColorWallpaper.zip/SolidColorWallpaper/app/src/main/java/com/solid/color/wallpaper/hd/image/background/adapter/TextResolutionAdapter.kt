package com.solid.color.wallpaper.hd.image.background.adapter

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.Layout
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.custom.MatrixClonable
import com.solid.color.wallpaper.hd.image.background.model.ResolutionModel
import com.solid.color.wallpaper.hd.image.background.model.StickerModel
import com.xiaopo.flying.sticker.DrawableSticker
import com.xiaopo.flying.sticker.StickerView
import com.xiaopo.flying.sticker.TextSticker
import java.util.*

class TextResolutionAdapter(private val mContext: Context, private val mImageList: ArrayList<ResolutionModel>, private val onClickImage: OnClickImage) : RecyclerView.Adapter<TextResolutionAdapter.MyViewHolder>() {
    private var resolutionModel: ResolutionModel? = null
    private val mAllSticker: ArrayList<StickerModel?> = ArrayList()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val v = LayoutInflater.from(mContext).inflate(R.layout.row_text_wallpaper_resolution, null)
        return MyViewHolder(v)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        resolutionModel = mImageList[position]
        mAllSticker.clear()
        mAllSticker.addAll(resolutionModel!!.getmAllSticker()!!)
        if (resolutionModel!!.isCircle) {
            setCircleGradient(resolutionModel!!.isInner, holder)
        } else {
            setGradientDrawable(resolutionModel!!.orientation, holder)
        }
        holder.imgWallpaper.setOnClickListener { onClickImage.onClickImage(position) }
    }

    private fun addTextSticker(holder: MyViewHolder) {
        for (i in mAllSticker.indices) {
            val model = mAllSticker[i]
            if (model!!.isText) {
                val strk = TextSticker(mContext)
                strk.drawable = ContextCompat.getDrawable(mContext, R.drawable.sticker_transparent_background)!!
                strk.setTypeface(Typeface.createFromAsset(mContext.assets, model.typeface))
                strk.text = model.getText()
                strk.setTextColor(model.textColor)
                strk.setTextAlign(Layout.Alignment.ALIGN_CENTER)
                strk.alpha = model.textAlhpa
                strk.resizeText()
                holder.sticker_view.addSticker(strk)
            } else {
                val sticker1 = DrawableSticker(model.drawable)
                sticker1.color = model.drawableColor
                sticker1.alpha = model.drawableAlpha
                holder.sticker_view.addSticker(sticker1)
            }
        }
        holder.sticker_view.invalidate()
        holder.sticker_view.post { /* for (int i = 0; i < holder.sticker_view.getStickers().size(); i++) {
                    Sticker sticker = holder.sticker_view.getStickers().get(i);
                    sticker.setMatrix(mAllSticker.get(i).getMatrix());
                }
                holder.sticker_view.invalidate();*/
            for (i in holder.sticker_view.stickers.indices) {
                val sticker = holder.sticker_view.stickers[i]
                if (sticker is TextSticker) {
                    val sclH = holder.imgWallpaper.height.toFloat() / resolutionModel!!.mainHeight.toFloat()
                    val sclW = holder.imgWallpaper.width.toFloat() / resolutionModel!!.mainWidth.toFloat()
                    val matrix = MatrixClonable()
                    matrix.set(mAllSticker[i]!!.matrix)
                    matrix.postScale(sclW, sclH)
                    sticker.setMatrix(matrix)
                } else {
                    val sclH = holder.imgWallpaper.height.toFloat() / resolutionModel!!.mainHeight.toFloat()
                    val sclW = holder.imgWallpaper.width.toFloat() / resolutionModel!!.mainWidth.toFloat()
                    val matrix = MatrixClonable()
                    matrix.set(mAllSticker[i]!!.matrix)
                    matrix.postScale(sclW, sclH)
                    sticker.setMatrix(matrix)
                }
                holder.sticker_view.invalidate()
            }
        }
    }

    override fun getItemCount(): Int {
        return mImageList.size
    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var imgWallpaper: ImageView = itemView.findViewById(R.id.imgWallpaper)
        var sticker_view: StickerView = itemView.findViewById(R.id.sticker_viewnew)

        init {
            sticker_view.isLocked = true
        }
    }

    interface OnClickImage {
        fun onClickImage(i: Int)
    }

    private fun setGradientDrawable(orientation: GradientDrawable.Orientation?, holder: MyViewHolder) {
        val new_colors = intArrayOf(resolutionModel!!.color1, resolutionModel!!.color2)
        val shape = GradientDrawable(orientation, new_colors)
        shape.shape = GradientDrawable.RECTANGLE
        holder.imgWallpaper.background = shape
        addTextSticker(holder)
    }

    private fun setCircleGradient(isInner: Boolean, holder: MyViewHolder) {
        if (!isInner) {
            val new_colors = intArrayOf(resolutionModel!!.color2, resolutionModel!!.color1)
            val shape = GradientDrawable()
            shape.shape = GradientDrawable.RECTANGLE
            shape.colors = new_colors
            shape.gradientType = GradientDrawable.RADIAL_GRADIENT
            shape.gradientRadius = 400f
            holder.imgWallpaper.background = shape
        } else {
            val new_colors = intArrayOf(resolutionModel!!.color1, resolutionModel!!.color2)
            val shape = GradientDrawable()
            shape.shape = GradientDrawable.RECTANGLE
            shape.colors = new_colors
            shape.gradientType = GradientDrawable.RADIAL_GRADIENT
            shape.gradientRadius = 400f
            holder.imgWallpaper.background = shape
        }
        addTextSticker(holder)
    }

}