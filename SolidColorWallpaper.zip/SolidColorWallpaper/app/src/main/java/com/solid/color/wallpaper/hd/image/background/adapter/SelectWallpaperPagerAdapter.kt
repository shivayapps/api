package com.solid.color.wallpaper.hd.image.background.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.fragment.CreationSelectableFragment
import com.solid.color.wallpaper.hd.image.background.fragment.GradientSelectableFragment
import com.solid.color.wallpaper.hd.image.background.fragment.SolidSelectableFragment
import com.solid.color.wallpaper.hd.image.background.fragment.TextSelectableFragment

class SelectWallpaperPagerAdapter(fm: FragmentManager, private var solidSelectableFragment: SolidSelectableFragment, private var gradientSelectableFragment: GradientSelectableFragment, private var textSelectableFragment: TextSelectableFragment, private var creationSelectableFragment: CreationSelectableFragment, private val mContext: Context) : FragmentPagerAdapter(fm) {
    private val tabTitles = arrayOf("Solid", "Gradient", "Text", "Creation", "Gallery")
    override fun getItem(position: Int): Fragment {
        return when (position) {
            0 -> {
                if (solidSelectableFragment == null) {
                    solidSelectableFragment = SolidSelectableFragment()
                }
                solidSelectableFragment
            }
            1 -> {
                if (gradientSelectableFragment == null) {
                    gradientSelectableFragment = GradientSelectableFragment()
                }
                gradientSelectableFragment
            }
            2 -> {
                if (textSelectableFragment == null) {
                    textSelectableFragment = TextSelectableFragment()
                }
                textSelectableFragment
            }
            3 -> {
                if (creationSelectableFragment == null) {
                    creationSelectableFragment = CreationSelectableFragment()
                }
                creationSelectableFragment
            }
            4 -> SolidSelectableFragment()
            else -> null
        }!!
    }

    override fun getCount(): Int {
        return 5
    }

    fun getTabView(position: Int): View {
        // Given you have a custom layout in `res/layout/custom_tab.xml` with a TextView and ImageView
        val v = LayoutInflater.from(mContext).inflate(R.layout.rv_tab_item, null)
        val tv = v.findViewById<TextView>(R.id.textView)
        tv.text = tabTitles[position]
        return v
    }

}