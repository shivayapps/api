package com.solid.color.wallpaper.hd.image.background.model

class TextSelectableModel(var imgePath: String, var isDeletable: Boolean)