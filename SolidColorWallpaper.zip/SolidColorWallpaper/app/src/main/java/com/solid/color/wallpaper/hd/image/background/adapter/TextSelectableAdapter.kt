package com.solid.color.wallpaper.hd.image.background.adapter

import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.model.TextSelectableModel
import java.util.*

class TextSelectableAdapter(private val mContext: Context, private val mImageList: ArrayList<TextSelectableModel>, private val onClickImage: OnClickImage) : RecyclerView.Adapter<TextSelectableAdapter.MyViewHolder>() {
    private var isLongPressed = false
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val v = LayoutInflater.from(mContext).inflate(R.layout.rv_text_selectable, null)
        return MyViewHolder(v)
    }

    override fun onBindViewHolder(myViewHolder: MyViewHolder, i: Int) {
        Glide.with(mContext).load(mImageList[i].imgePath).into(object : CustomTarget<Drawable?>() {
            override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                myViewHolder.imgEmoji.background = resource
            }

            override fun onLoadCleared(placeholder: Drawable?) {}
        })
        if (isLongPressed) {
            myViewHolder.checkbox.visibility = View.VISIBLE
        } else {
            myViewHolder.checkbox.visibility = View.GONE
        }
        if (mImageList[i].isDeletable) {
            myViewHolder.checkbox.isChecked = true
        } else {
            myViewHolder.checkbox.isChecked = false
        }
        myViewHolder.checkbox.setOnClickListener {
            if (mImageList[i].isDeletable) {
                myViewHolder.checkbox.isChecked = false
                mImageList[i].isDeletable = false
            } else {
                myViewHolder.checkbox.isChecked = true
                mImageList[i].isDeletable = true
            }
        }
        myViewHolder.imgEmoji.setOnClickListener {
            if (myViewHolder.checkbox.visibility == View.VISIBLE) {
                if (myViewHolder.checkbox.isChecked) {
                    myViewHolder.checkbox.isChecked = false
                    mImageList[i].isDeletable = false
                } else {
                    myViewHolder.checkbox.isChecked = true
                    mImageList[i].isDeletable = true
                }
            } else {
                isLongPressed = true
                mImageList[i].isDeletable = true
                notifyDataSetChanged()
            }
            onClickImage.onClickImage(i)
        }

        /*  myViewHolder.imgEmoji.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (myViewHolder.checkbox.getVisibility() != View.VISIBLE){
                    isLongPressed=true;
                    mImageList.get(i).setDeletable(true);
                    notifyDataSetChanged();
                    return true;
                }else {
                    return false;
                }
            }
        });*/
    }

    override fun getItemCount(): Int {
        return mImageList.size
    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var imgEmoji: ImageView = itemView.findViewById(R.id.imgImage)
        var checkbox: CheckBox = itemView.findViewById(R.id.checkbox)

    }

    interface OnClickImage {
        fun onClickImage(i: Int)
    }

}