package com.solid.color.wallpaper.hd.image.background.adData

import android.os.AsyncTask
import android.util.Log
import com.solid.color.wallpaper.hd.image.background.activity.LetsStartActivity
import org.json.JSONException
import org.json.JSONObject
import java.util.*

class LoadApiData(private val activity: LetsStartActivity) : AsyncTask<Void?, Void?, LetsStartActivity?>() {
    override fun onPostExecute(aVoid: LetsStartActivity?) {
        super.onPostExecute(aVoid)
        /* Log.d(TAG, "onPostExecute: "+apiData.size());
       if (apiData.size()>0) {
           activity.isINternet();
           activity.exitDialog();
       }*/activity.isINternet
    }

    protected override fun doInBackground(vararg params: Void?): LetsStartActivity? {
        if (apiData.size <= 0) {
            val sh = HttpHandler()
            val jsonStr = sh.makeServiceCall(url)
            if (jsonStr != null) {
                try {
                    val jsonObject = JSONObject(jsonStr)
                    val data = jsonObject.getJSONArray("data")
                    for (i in 0 until data.length()) {
                        val `object` = data.getJSONObject(i)
                        val id = `object`.getInt("id")
                        val app_id = `object`.getInt("app_id")
                        val position = `object`.getInt("position")
                        val name = `object`.getString("name")
                        val thumb_image = `object`.getString("thumb_image")
                        val app_link = `object`.getString("app_link")
                        val package_name = `object`.getString("package_name")
                        val full_thumb_image = `object`.getString("full_thumb_image")
                        Log.d(TAG, "doInBackground: $name")
                        if (package_name != activity.packageName) {
                            val model = AdDetailModel(id, app_id, position, name, thumb_image, app_link, package_name, full_thumb_image)
                            apiData.add(model)
                        }
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            }
        }
        return null
    }

    companion object {
        private const val TAG = "LoadApiData"
        @JvmField
        var apiData = ArrayList<AdDetailModel?>()
        private const val url = "http://165.22.219.93/api/AdvertiseApplications"
    }

    init {
        apiData = ArrayList()
    }
}