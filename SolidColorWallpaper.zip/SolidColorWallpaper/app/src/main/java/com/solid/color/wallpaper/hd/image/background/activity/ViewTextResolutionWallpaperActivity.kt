package com.solid.color.wallpaper.hd.image.background.activity

import android.Manifest
import android.app.Activity
import android.app.ProgressDialog
import android.app.Service
import android.app.WallpaperManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.viewpager.widget.ViewPager
import androidx.viewpager.widget.ViewPager.OnPageChangeListener
import com.auto.wallpaper.live.background.changer.editor.receiver.EventReceiver
import com.auto.wallpaper.live.background.changer.editor.receiver.EventReceiver.Companion.cancelAlarm
import com.facebook.ads.Ad
import com.facebook.ads.AdError
import com.facebook.ads.InterstitialAdListener
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.snackbar.Snackbar
import com.solid.color.wallpaper.hd.image.background.BuildConfig
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.SolidWallpaperApplication
import com.solid.color.wallpaper.hd.image.background.SolidWallpaperApplication.Companion.instance
import com.solid.color.wallpaper.hd.image.background.activity.ViewTextResolutionWallpaperActivity
import com.solid.color.wallpaper.hd.image.background.adapter.ResolutionPagerAdapter
import com.solid.color.wallpaper.hd.image.background.constants.Constants
import com.solid.color.wallpaper.hd.image.background.custom.BottomSheetFragment
import com.solid.color.wallpaper.hd.image.background.live_wallpaper.CustomNewWallpaper
import com.solid.color.wallpaper.hd.image.background.model.ResolutionModel
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs.getBoolean
import com.solid.color.wallpaper.hd.image.background.shared_pref.MySharedPref
import com.solid.color.wallpaper.hd.image.background.sqlite_database.DBHelperAutoWallpaper
import com.solid.color.wallpaper.hd.image.background.sqlite_database.ResolutionExtractData
import com.willy.ratingbar.BaseRatingBar
import com.willy.ratingbar.BaseRatingBar.OnRatingChangeListener
import com.willy.ratingbar.ScaleRatingBar
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.*

class ViewTextResolutionWallpaperActivity constructor() : AppCompatActivity(), View.OnClickListener {
    private var btnShare: ImageView? = null
    private var btnSave: ImageView? = null
    private var btnBack: ImageView? = null
    private var btnEdit: ImageView? = null
    private var btnSetWallpaper: TextView? = null
    private var mBitmap: Bitmap? = null
    private var mPermissionGranted: Boolean = false
    private var mPermissionGrantedWallpaper: Boolean = false
    private var isShared: Boolean = false
    private val isCircle: Boolean = false
    private var mainLayout: RelativeLayout? = null
    private var progressBar: ProgressDialog? = null
    private var mySharedPref: MySharedPref? = null
    private var isSetWallpaper: Boolean = false
    private var vibrator: Vibrator? = null
    private var imgWallpaper: ImageView? = null
    private val resolutionModel: ResolutionModel? = null
    private var position: Int = 0
    private var mainViewPage: ViewPager? = null
    private var mImageList: ArrayList<ResolutionModel>? = null

    var bottomSheetFragment:BottomSheetFragment?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_text_resolution_wallpaper)
        System.gc()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted
            startActivity(Intent(this@ViewTextResolutionWallpaperActivity, MainStartActivity::class.java))
            finish()
        } else {
            Constants.savedPath = null
            mySharedPref = MySharedPref(this)
            if ( /*!mySharedPref.getAdsRemoved() &&*/!getBoolean(this@ViewTextResolutionWallpaperActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                Constants.isInstrastial1 = false
                loadInterstialAd()
                loadInterstialAdFb()
            }
            initViews()
            initViewAction()
            initListner()
        }
    }

    private fun initListner() {
        btnSave!!.setOnClickListener(this)
        btnShare!!.setOnClickListener(this)
        btnSetWallpaper!!.setOnClickListener(this)
        btnEdit!!.setOnClickListener(this)
        btnBack!!.setOnClickListener(this)
    }

    private fun initViewAction() {
        position = intent.extras!!.get("position") as Int
        Log.d("9712481212", "initViewAction: ")
        mImageList = ResolutionExtractData(this@ViewTextResolutionWallpaperActivity).resolutionModelList
        if (mySharedPref!!.vibration) {
            vibrator = getSystemService(Service.VIBRATOR_SERVICE) as Vibrator?
        }
        progressBar = ProgressDialog(this@ViewTextResolutionWallpaperActivity)
        progressBar!!.setMessage(getResources().getString(R.string.dialog_msg_please_wait))
        progressBar!!.setCancelable(false)
        mainViewPage!!.addOnPageChangeListener(object : OnPageChangeListener {
            public override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {}
            public override fun onPageSelected(position1: Int) {
                position = position1
            }

            public override fun onPageScrollStateChanged(state: Int) {}
        })
        setDataToAdapter()
    }

    private fun setDataToAdapter() {
        if (mImageList!!.size > 0) {
            Log.d("9712481212", "setDataToAdapter: ")
            /*ViewTextResolutionAdapter adapter = new ViewTextResolutionAdapter(this, mImageList);*/
            val adapter: ResolutionPagerAdapter = ResolutionPagerAdapter(supportFragmentManager, (mImageList)!!)
            mainViewPage!!.adapter = adapter
            mainViewPage!!.currentItem = position
        }
    }

    private fun initViews() {
        btnSave = findViewById(R.id.btnSave)
        btnSetWallpaper = findViewById(R.id.btnSetWallpaper)
        btnShare = findViewById(R.id.btnShare)
        btnEdit = findViewById(R.id.btnEdit)
        mainLayout = findViewById(R.id.mainLayout)
        btnBack = findViewById(R.id.btnBack)
        imgWallpaper = findViewById(R.id.imgWallpaper)
        mainViewPage = findViewById(R.id.mainViewPage)
    }

    public override fun onClick(view: View) {
        when (view.id) {
            R.id.btnSave -> {
                isSetWallpaper = false
                isShared = false
                if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this@ViewTextResolutionWallpaperActivity, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), READ_PERMISSION)
                } else {
                    mPermissionGranted = true
                }
                if (mPermissionGranted) {
                    if (Constants.savedPath == null) {
                        showSaveDialog()
                    } else {
                        showSnackbar(getResources().getString(R.string.wallpaper_already_exist))
                        //    Toast.makeText(this, "Wallpaper Already Exist.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
            R.id.btnSetWallpaper -> {
                isSetWallpaper = true
                isShared = false
                if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.SET_WALLPAPER) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this@ViewTextResolutionWallpaperActivity, arrayOf(Manifest.permission.SET_WALLPAPER), WALLPAPER_PERMISSION)
                } else {
                    mPermissionGrantedWallpaper = true
                }
                if (mPermissionGrantedWallpaper) {
                    if ( /*Constants.isText && */mySharedPref!!.scale.equals("Fit", ignoreCase = true)) {
                        try {
                            if (mBitmap == null) {
                                mBitmap = outputBitmap
                            }
                            Constants.mWallpaperBitmap = mBitmap
                            val intent: Intent = Intent(
                                    WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                            intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                                    ComponentName(this, CustomNewWallpaper::class.java))
                            startActivity(intent)
                        } catch (e: Exception) {
                            e.printStackTrace()
                            showSnackbar(getResources().getString(R.string.live_wallpaper_not_supported))
                        }
                    } else {
                        showCustomDialog()
                    }
                    //onclickSave();
                }
            }
            R.id.btnShare -> {
                isShared = true
                isSetWallpaper = false
                shareWallpaper()
            }
            R.id.btnBack -> onBackPressed()
            R.id.btnEdit -> {
                val intent: Intent = Intent(this@ViewTextResolutionWallpaperActivity, AddTextActivity::class.java)
                intent.putExtra("position", position)
                startActivity(intent)
            }
        }
    }

    private fun showCustomDialog() {
        btnSetWallpaper!!.isEnabled = false
        val builder1: BottomSheetDialog = BottomSheetDialog(this@ViewTextResolutionWallpaperActivity, R.style.BottomSheetDialog)
        val v: View = layoutInflater.inflate(R.layout.dialog_setwallpaper, null)
        builder1.setContentView(v)
        builder1.show()
        builder1.setOnDismissListener { btnSetWallpaper!!.isEnabled = true }
        val wallpaper: LinearLayout = v.findViewById(R.id.btnHomeScreen)
        val bothwallpaper: LinearLayout = v.findViewById(R.id.btnBoth)
        val lockscreen: LinearLayout = v.findViewById(R.id.btnLockScreen)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            bothwallpaper.visibility = View.GONE
            lockscreen.visibility = View.GONE
        }
        lockscreen.setOnClickListener {
            builder1.dismiss()
            mySharedPref!!.countExist = mySharedPref!!.countExist + 1
            progressBar!!.show()
            Handler().postDelayed({ //   progressBar.dismiss();
                btnSetWallpaper!!.isEnabled = true
                if (mySharedPref!!.countExist >= 3 && mySharedPref!!.visitPlay == null) {
                    //showRateDialog()
                }
            }, 3000)
            if (mySharedPref!!.alarmId != -1) {
                DBHelperAutoWallpaper(this@ViewTextResolutionWallpaperActivity).updateData()
                cancelAlarm(("2121" + mySharedPref!!.alarmId).toInt(), this@ViewTextResolutionWallpaperActivity, EventReceiver::class.java)
            }
            Handler().postDelayed({ lockScreenWallpaper() }, 400)
        }
        wallpaper.setOnClickListener {
            builder1.dismiss()
            //   Toast.makeText(ViewTextResolutionWallpaperActivity.this, "Please Wait...", Toast.LENGTH_SHORT).show();
            mySharedPref!!.countCreated = mySharedPref!!.countCreated + 1
            progressBar!!.show()
            Handler().postDelayed({ //  progressBar.dismiss();
                btnSetWallpaper!!.setEnabled(true)
                if (mySharedPref!!.countCreated >= 3 && mySharedPref!!.visitPlay == null) {
                    //showRateDialog()
                }
            }, 3000)
            if (mySharedPref!!.alarmId != -1) {
                DBHelperAutoWallpaper(this@ViewTextResolutionWallpaperActivity).updateData()
                cancelAlarm(("2121" + mySharedPref!!.alarmId).toInt(), this@ViewTextResolutionWallpaperActivity, EventReceiver::class.java)
            }
            Handler().postDelayed({ onclickWallpaper(false) }, 400)
        }
        bothwallpaper.setOnClickListener {
            builder1.dismiss()
            //  Toast.makeText(ViewTextResolutionWallpaperActivity.this, "Please Wait...", Toast.LENGTH_LONG).show();
            mySharedPref!!.countCreated = mySharedPref!!.countCreated + 1
            progressBar!!.show()
            Handler().postDelayed({ //  progressBar.dismiss();
                btnSetWallpaper!!.isEnabled = true
                if (mySharedPref!!.countCreated >= 3 && mySharedPref!!.visitPlay == null) {
                   // showRateDialog()
                }
            }, 3000)
            if (mySharedPref!!.alarmId != -1) {
                DBHelperAutoWallpaper(this@ViewTextResolutionWallpaperActivity).updateData()
                cancelAlarm(("2121" + mySharedPref!!.alarmId).toInt(), this@ViewTextResolutionWallpaperActivity, EventReceiver::class.java)
            }
            Handler().postDelayed({
                onclickWallpaper(true)
                lockScreenWallpaper()
            }, 400)
        }
    }

//    private fun showRateDialog() {
//        val viewGroup: ViewGroup = findViewById(android.R.id.content)
//        val dialogView: View = LayoutInflater.from(this).inflate(R.layout.dialog_rate_app, viewGroup, false)
//        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
//        builder.setView(dialogView)
//        val alertDialog: AlertDialog = builder.create()
//        Objects.requireNonNull(alertDialog.window)!!.setBackgroundDrawableResource(android.R.color.transparent)
//        alertDialog.setOnCancelListener { alertDialog.dismiss() }
//        val btnClose: ImageView = dialogView.findViewById(R.id.btnClose)
//        btnClose.setOnClickListener { alertDialog.dismiss() }
//        val ratingBar1: ScaleRatingBar = dialogView.findViewById(R.id.ratingBar)
//        ratingBar1.setOnRatingChangeListener { ratingBar, rating, fromUser ->
//            if (rating > 3) {
//                rate_app()
//                Handler().postDelayed({ alertDialog.dismiss() }, 1000)
//            } else {
//                sendMail()
//                //Toast.makeText(ViewTextResolutionWallpaperActivity.this, getResources().getString(R.string.thanks_for_review), Toast.LENGTH_SHORT).show();
//                Handler().postDelayed({ alertDialog.dismiss() }, 1000)
//            }
//        }
//        dialogView.findViewById<View>(R.id.btnNextTime).setOnClickListener {
//            mySharedPref!!.countExist = 0
//            alertDialog.dismiss()
//        }
//        if (!isFinishing) {
//            alertDialog.show()
//        }
//    }
//
//    private fun sendMail() {
//        mySharedPref!!.setVisitPlay()
//        /*   Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
//        emailIntent.setType("text/plain");
//        emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{"profagnesh009@gmail.com"});
//        emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Share your valuable feedback with us to improve app quality and add more features in Solid Color Wallpaper");
//        emailIntent.setType("message/rfc822");
//        try {
//            startActivity(Intent.createChooser(emailIntent,
//                    "Send email using..."));
//        } catch (android.content.ActivityNotFoundException ex) {
//            Toast.makeText(this,
//                    "No email clients installed.",
//                    Toast.LENGTH_SHORT).show();
//        }*/
//        val send: Intent = Intent(Intent.ACTION_SENDTO)
//        val uriText: String = ("mailto:" + Uri.encode("profagnesh009@gmail.com") +
//                "?subject=" + Uri.encode("Share valuable feedback to improve app quality of Solid Color Wallpaper") +
//                "&body=" + Uri.encode(""))
//        val uri: Uri = Uri.parse(uriText)
//        send.setData(uri)
//        startActivity(Intent.createChooser(send, "Send Email..."))
//    }
//
//    private fun rate_app() {
//        mySharedPref!!.setVisitPlay()
//        try {
//            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")))
//        } catch (anfe: ActivityNotFoundException) {
//            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName")))
//        }
//    }

    private fun lockScreenWallpaper() {
        mBitmap = outputBitmap
        if (mBitmap != null) {
            val wm: WallpaperManager = WallpaperManager.getInstance(this)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    wm.setBitmap(mBitmap, null, true, WallpaperManager.FLAG_LOCK) //For Lock screen
                    progressBar!!.dismiss()
                    if (vibrator != null) {
                        if (Build.VERSION.SDK_INT >= 26) {
                            vibrator!!.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
                        } else {
                            vibrator!!.vibrate(200)
                        }
                    }
                    //Toast.makeText(WallpaperViewActivity.this, "Wallpaper Set Successfully.", Toast.LENGTH_SHORT).show();
                    showSnackbar(getResources().getString(R.string.toast_wallpaper_set_seccessfully))
                } else {
                    Toast.makeText(this, "Lock Screen Wallpaper Not Supported",
                            Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun showSaveDialog() {
         bottomSheetFragment= BottomSheetFragment(getResources().getString(R.string.save), getResources().getString(R.string.do_you_want_to_save), getResources().getString(R.string.save), getResources().getString(R.string.cancel), R.drawable.ic_save_dialog, object : BottomSheetFragment.OnButtonClickListener {
            public override fun onPositive(bottomSheetDialo: BottomSheetFragment?) {
                bottomSheetDialo!!.dismiss()
                onclickSave()
            }

            public override fun onNegative(bottomSheetDialog: BottomSheetFragment?) {
                bottomSheetDialog!!.dismiss()
            }
        })
        bottomSheetFragment!!.show(supportFragmentManager, "dialog")
    }

    override fun onPause() {
        super.onPause()
        try {
            bottomSheetFragment!!.dismiss()
        }catch (e:Exception){

        }
    }

    private fun shareWallpaper() {
        Log.d("Uri", "shareWallpaper: " + Constants.savedPath)
        if (Constants.savedPath == null) {
            if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this@ViewTextResolutionWallpaperActivity, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), SHARE_PERMISSION)
            } else {
                mPermissionGranted = true
            }
            if (mPermissionGranted) {
                onclickSave()
            }
        } else {
            val uri: Uri? = FileProvider.getUriForFile(this@ViewTextResolutionWallpaperActivity, BuildConfig.APPLICATION_ID.toString() + ".provider", File(Constants.savedPath))
            if (uri != null) {
                val intent: Intent = Intent(Intent.ACTION_SEND)
                intent.type = "image/jpeg"
                intent.putExtra(Intent.EXTRA_STREAM, uri)
                var shareMessage: String = ""
                shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=com.solid.color.wallpaper.hd.image.background"
                intent.putExtra(Intent.EXTRA_TEXT, shareMessage)
                startActivityForResult(Intent.createChooser(intent, getResources().getString(R.string.share_wallpaper)), 100)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
//        if (requestCode == 100 && !getBoolean(this, AdsPrefs.IS_SUBSCRIBED, false)) {
//            if (instance!!.requestNewInterstitial()) {
//                instance!!.mInterstitialAd!!.adListener = object : AdListener() {
//                    public override fun onAdClosed() {
//                        super.onAdClosed()
//                        loadInterstialAd()
//                    }
//
//                    public override fun onAdFailedToLoad(i: Int) {
//                        super.onAdFailedToLoad(i)
//                        loadInterstialAd()
//                    }
//
//                    public override fun onAdLoaded() {
//                        super.onAdLoaded()
//                    }
//                }
//            }
//        }
    }

    private fun onclickWallpaper(isBoth: Boolean) {
        mBitmap = outputBitmap
        if (mBitmap != null) {
            val wallpaperManager: WallpaperManager = WallpaperManager.getInstance(applicationContext)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    wallpaperManager.setBitmap(mBitmap, null, true, WallpaperManager.FLAG_SYSTEM)
                } else {
                    wallpaperManager.setBitmap(mBitmap)
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
            if (!isBoth) {
                progressBar!!.dismiss()
                if (vibrator != null) {
                    if (Build.VERSION.SDK_INT >= 26) {
                        vibrator!!.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
                    } else {
                        vibrator!!.vibrate(200)
                    }
                }
                //Toast.makeText(WallpaperViewActivity.this, "Wallpaper Set Successfully.", Toast.LENGTH_SHORT).show();
                showSnackbar(getResources().getString(R.string.toast_wallpaper_set_seccessfully))
            }
        } else {
            showSnackbar(getResources().getString(R.string.try_again_later))
            //Toast.makeText(this, "Try Again Later!", Toast.LENGTH_SHORT).show();
        }
    }

    private fun showSnackbar(msg: String) {
        val snackbar: Snackbar = Snackbar.make(findViewById(R.id.mainContainer), msg, Snackbar.LENGTH_SHORT)
        val v: View = snackbar.view
        val params: CoordinatorLayout.LayoutParams = v.layoutParams as CoordinatorLayout.LayoutParams
        params.gravity = Gravity.BOTTOM
        params.width = FrameLayout.LayoutParams.MATCH_PARENT
        v.layoutParams = params
        v.setBackgroundColor(Color.WHITE)
        val textView: TextView = v.findViewById(com.google.android.material.R.id.snackbar_text)
        textView.setTextColor(resources.getColor(R.color.text_colour_new))
        snackbar.show()
    }

    private fun onclickSave() {
        mBitmap = outputBitmap
        if (mBitmap != null) {
            val myDir: File = File(Constants.path)
            myDir.mkdirs()
            val fname: String
            if (Constants.isTextWallpaper) {
                fname = "Text_" + (System.currentTimeMillis() / 1000) + ".png"
            } else {
                fname = "Gradient_" + (System.currentTimeMillis() / 1000) + ".png"
            }
            val file: File = File(myDir, fname)
            var out: FileOutputStream? = null
            try {
                out = FileOutputStream(file)
                mBitmap!!.compress(Bitmap.CompressFormat.PNG, 100, out)
                out.flush()
                out.close()
                Constants.savedPath = Constants.path + "/" + fname
                Constants.isDataChanges = true
                if (!isShared && !isSetWallpaper) {
                    showSnackbar(getResources().getString(R.string.wallpaper_saved))
                    // Toast.makeText(this, "Wallpaper Saved.", Toast.LENGTH_SHORT).show();
                } else if (isSetWallpaper) {
                    // setWall();
                    showCustomDialog()
                } else {
                    shareWallpaper()
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                val scanIntent: Intent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
                val contentUri: Uri = Uri.fromFile(file)
                scanIntent.data = contentUri
                sendBroadcast(scanIntent)
            } else {
                val intent: Intent = Intent(Intent.ACTION_MEDIA_MOUNTED, Uri.parse("file://" + Environment.getExternalStorageDirectory()))
                sendBroadcast(intent)
            }
        }
    }

    private val outputBitmap: Bitmap
        private get() {
            System.gc()
            Runtime.getRuntime().gc()
            val v: View = mainViewPage!!.findViewWithTag("myview" + mainViewPage!!.getCurrentItem())
            val bitmap: Bitmap = Bitmap.createBitmap(v.width, v.height, Bitmap.Config.ARGB_8888)
            val canvas: Canvas = Canvas(bitmap)
            v.draw(canvas)
            return bitmap
        }

    private fun loadInterstialAd() {
        if (instance!!.mInterstitialAd!=null) {
        } else {
            if (instance!!.mInterstitialAd!=null) {

                instance!!.mInterstitialAd!!.fullScreenContentCallback = null
                instance!!.mInterstitialAd = null
                instance!!.ins_adRequest = null
                instance!!.LoadAds()

                instance!!.mInterstitialAd!!.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
//                    Log.d(TAG, 'Ad was dismissed.')
                    }

                    override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
                        super.onAdFailedToShowFullScreenContent(p0)
                        loadInterstialAd()
                    }

                    override fun onAdShowedFullScreenContent() {
//                    Log.d(TAG, 'Ad showed fullscreen content.')
                        instance!!.mInterstitialAd = null;
                    }
                }
                instance!!.mInterstitialAd!!.show(this)

//            instance!!.mInterstitialAd!!.adListener = object : AdListener() {
//                public override fun onAdLoaded() {
//                    super.onAdLoaded()
//                }
//
//                public override fun onAdFailedToLoad(i: Int) {
//                    super.onAdFailedToLoad(i)
//                    loadInterstialAd()
//                    //  loadInterstialAdFb();
//                }
//            }
            }
        }
    }

    private fun loadInterstialAdFb() {
        if (instance!!.mInterstitialAdfb!!.isAdLoaded) {
        } else {
            instance!!.mInterstitialAdfb!!.buildLoadAdConfig().withAdListener(null)
            instance!!.mInterstitialAdfb = null
            instance!!.LoadAdsFb()
            instance!!.mInterstitialAdfb!!.buildLoadAdConfig().withAdListener(object : InterstitialAdListener {
                public override fun onError(ad: Ad, adError: AdError) {
                    // loadInterstialAdFb();
                    loadInterstialAd()
                }

                public override fun onAdLoaded(ad: Ad) {}
                public override fun onAdClicked(ad: Ad) {}
                public override fun onLoggingImpression(ad: Ad) {}
                public override fun onInterstitialDisplayed(ad: Ad) {}
                public override fun onInterstitialDismissed(ad: Ad) {
                    loadInterstialAdFb()
                }
            })
        }
    }

    public override fun onRequestPermissionsResult(requestCode: Int,
                                                   permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            READ_PERMISSION -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (Constants.savedPath == null) {
                        showSaveDialog()
                    } else {
                        showSnackbar(getResources().getString(R.string.wallpaper_already_exist))
                        // Toast.makeText(this, "Wallpaper Already Exist.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    val showRationale: Boolean = ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    if (!showRationale) {
                        pemissionDialog()
                    }
                    Toast.makeText(this, getResources().getString(R.string.permission_required), Toast.LENGTH_SHORT).show()
                }
                return
            }
            WALLPAPER_PERMISSION -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    showCustomDialog()
                } else {
                    val showRationale: Boolean = ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SET_WALLPAPER)
                    if (!showRationale) {
                        pemissionDialog()
                    }
                    Toast.makeText(this, getResources().getString(R.string.permission_required), Toast.LENGTH_SHORT).show()
                }
                return
            }
            SHARE_PERMISSION -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    shareWallpaper()
                } else {
                    val showRationale: Boolean = ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SET_WALLPAPER)
                    if (!showRationale) {
                        pemissionDialog()
                    }
                    Toast.makeText(this, getResources().getString(R.string.permission_required), Toast.LENGTH_SHORT).show()
                }
                return
            }
        }
    }

    fun pemissionDialog() {
        val alertDialog: android.app.AlertDialog
        val viewGroup: ViewGroup = findViewById(android.R.id.content)
        val dialogView: View = LayoutInflater.from(this).inflate(R.layout.permission_dialog, viewGroup, false)
        val builder1: android.app.AlertDialog.Builder = android.app.AlertDialog.Builder(this)
        builder1.setView(dialogView)
        alertDialog = builder1.create()
        val cancel: Button = dialogView.findViewById(R.id.btnCancel)
        cancel.setOnClickListener { alertDialog.dismiss() }
        val ok: Button = dialogView.findViewById(R.id.btnOk)
        ok.setOnClickListener {
            startInstalledAppDetailsActivity(this@ViewTextResolutionWallpaperActivity)
            alertDialog.dismiss()
        }
        alertDialog.show()
    }

    fun startInstalledAppDetailsActivity(context: Activity?) {
        if (context == null) {
            return
        }
        val i: Intent = Intent()
        i.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        i.addCategory(Intent.CATEGORY_DEFAULT)
        i.data = Uri.parse("package:" + context.packageName)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        i.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
        i.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
        context.startActivity(i)
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("787897789", "onRestart: ")
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted
            startActivity(Intent(this@ViewTextResolutionWallpaperActivity, MainStartActivity::class.java))
            finish()
        }
    }

    public override fun onBackPressed() {
        finish()
    }

    override fun onResume() {
        super.onResume()
        SolidWallpaperApplication.staticLanguage.Factory.create(this)
    }

    companion object {
        private val TAG: String = "ViewWallpaperActivity"
        private val READ_PERMISSION: Int = 101
        private val WALLPAPER_PERMISSION: Int = 235
        private val SHARE_PERMISSION: Int = 452
    }
}