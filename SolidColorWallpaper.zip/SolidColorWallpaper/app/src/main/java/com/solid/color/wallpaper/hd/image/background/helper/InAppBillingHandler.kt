package com.solid.color.wallpaper.hd.image.background.helper

import android.content.Context
import android.content.Intent

class InAppBillingHandler {
    constructor(context: Context?) {
        mContext = context!!
    }

    constructor() {
//        mContext = null
    }

    companion object {
        private var inAppBillingHandler: InAppBillingHandler? = null
        internal lateinit var mContext: Context
        fun getInstance(context: Context?): InAppBillingHandler? {
            if (inAppBillingHandler == null) {
                inAppBillingHandler = if (context != null) {
                    InAppBillingHandler(mContext)
                } else {
                    InAppBillingHandler()
                }
            }
            return inAppBillingHandler
        }

        @JvmStatic
        val bindServiceIntent: Intent
            get() {
                val intent = Intent("com.android.vending.billing.InAppBillingService.BIND")
                intent.setPackage("com.android.vending")
                return intent
            }

        fun isIabServiceAvailable(context: Context): Boolean {
            val packageManager = context.packageManager
            val list = packageManager.queryIntentServices(bindServiceIntent, 0)
            return list != null && list.size > 0
        }
    }
}