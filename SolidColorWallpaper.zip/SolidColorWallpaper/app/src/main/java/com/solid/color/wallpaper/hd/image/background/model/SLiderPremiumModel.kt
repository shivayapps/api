package com.solid.color.wallpaper.hd.image.background.model

data class SLiderPremiumModel(var image_id: Int, var title_msg: String, var sub_msg: String)