package com.solid.color.wallpaper.hd.image.background.fragment

import android.content.res.Resources
import android.os.Bundle
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.adapter.TextSelectableAdapter
import com.solid.color.wallpaper.hd.image.background.custom.GridSpacingItemDecoration
import com.solid.color.wallpaper.hd.image.background.model.TextSelectableModel
import java.io.File
import java.io.IOException
import java.util.*


class TextSelectableFragment constructor() : Fragment() {
    private var recyclerTextWallpaper: RecyclerView? = null
    private var mImageList: ArrayList<TextSelectableModel>? = null
    public override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                                     savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_text_selectable, container, false)
    }

    public override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        recyclerTextWallpaper = view.findViewById(R.id.recyclerTextWallpaper)
        System.gc()
        Runtime.getRuntime().gc()
        val manager: GridLayoutManager = GridLayoutManager(activity, 3)
        recyclerTextWallpaper!!.layoutManager = manager
        recyclerTextWallpaper!!.addItemDecoration(GridSpacingItemDecoration(3, dpToPx(8), true))
        recyclerTextWallpaper!!.itemAnimator = DefaultItemAnimator()
        mImageList = ArrayList()
        var files: Array<String?>? = arrayOfNulls(0)
        try {
            files = activity!!.assets.list("text_image")
        } catch (e: IOException) {
            e.printStackTrace()
        }
        assert(files != null)
        for (name: String? in files!!) {
            mImageList!!.add(TextSelectableModel("file:///android_asset/text_image" + File.separator + name, false))
        }
        val clickImage: TextSelectableAdapter.OnClickImage = object : TextSelectableAdapter.OnClickImage {
            public override fun onClickImage(i: Int) {}
        }
        val adapter: TextSelectableAdapter = TextSelectableAdapter(activity!!, mImageList!!, clickImage)
        recyclerTextWallpaper!!.adapter = adapter
    }

    /*  Glide.with(getActivity()).asBitmap().load(mImageList.get(i).getImgePath()).into(new CustomTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                        Log.d("7812787878", "onResourceReady: "+resource);
                        mList.add(resource);
                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {

                    }
                });*/
    val dataList: ArrayList<TextSelectableModel>
        get() {
            val mList: ArrayList<TextSelectableModel> = ArrayList()
            for (i in mImageList!!.indices) {
                if (mImageList!![i].isDeletable) {
                    /*  Glide.with(getActivity()).asBitmap().load(mImageList.get(i).getImgePath()).into(new CustomTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                        Log.d("7812787878", "onResourceReady: "+resource);
                        mList.add(resource);
                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {

                    }
                });*/
                    mList.add(mImageList!!.get(i))
                }
            }
            return mList
        }

    private fun dpToPx(dp: Int): Int {
        val r: Resources = resources
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), r.displayMetrics))
    }
}