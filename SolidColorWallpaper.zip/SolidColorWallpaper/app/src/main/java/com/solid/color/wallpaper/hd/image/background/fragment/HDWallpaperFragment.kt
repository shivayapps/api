package com.solid.color.wallpaper.hd.image.background.fragment

import android.os.Bundle
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.wifi_network.exceptions.ApiNotSupportedException
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.wifi_network.exceptions.NullWifiConfigurationException
import com.facebook.ads.AdSize
import com.facebook.ads.AdView
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.appid.AppIDs
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.custom.GridSpacingItemDecoration
import com.solid.color.wallpaper.hd.image.background.model.api.DataItem
import com.solid.color.wallpaper.hd.image.background.model.api.ImageItem
import com.solid.color.wallpaper.hd.image.background.retrofit.APIInterface
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs
import com.solid.color.wallpaper.hd.image.background.shared_pref.MySharedPref
import com.solid.color.wallpaper.hd.image.background.sqlite_database.DBHelper
import com.solid.color.wallpaper.hd.image.background.sqlite_database.DBHelperSuscription
import kotlinx.android.synthetic.main.fragment_h_d_wallpaper.*
import java.lang.reflect.InvocationTargetException
import java.util.*


class HDWallpaperFragment : Fragment() {

    private val apiInterface: APIInterface? = null
    private var mDataList: ArrayList<DataItem>? = null
    private var mImageList: ArrayList<ImageItem>? = null
    private val txtRetryOffline: TextView? = null
    private  var txtRetryError: TextView? = null
    private var mySharedPref: MySharedPref? = null
    private var dbHelper: DBHelper? = null
    private var dbHelperSuscription: DBHelperSuscription? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_h_d_wallpaper, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        mDataList = ArrayList<DataItem>()
        mImageList = ArrayList<ImageItem>()

        dbHelper = DBHelper(activity)
        dbHelperSuscription = DBHelperSuscription(activity)
        mySharedPref = MySharedPref(activity)
        var facebookBanner= AppIDs.instnace!!.getFacebookBanner()
        if (!AdsPrefs.getBoolean(activity, AdsPrefs.IS_SUBSCRIBED, false)) {
            var adView = AdView(activity, facebookBanner, AdSize.BANNER_HEIGHT_50)
            val adContainer = view.findViewById<View>(R.id.banner_container) as LinearLayout
            adContainer.removeAllViews()
            adContainer.addView(adView)
            adView.loadAd()
        }




        val manager = GridLayoutManager(activity, 3)
        recyclerWallpaper.layoutManager = manager
        recyclerWallpaper.addItemDecoration(GridSpacingItemDecoration(3, dpToPx(14), true))
        recyclerWallpaper.itemAnimator = DefaultItemAnimator()

        try {
          //  checkStatus()
        } catch (e: InvocationTargetException) {
            e.printStackTrace()
        } catch (e: NoSuchMethodException) {
            e.printStackTrace()
        } catch (e: ApiNotSupportedException) {
            e.printStackTrace()
        } catch (e: NoSuchFieldException) {
            e.printStackTrace()
        } catch (e: IllegalAccessException) {
            e.printStackTrace()
        } catch (e: NullWifiConfigurationException) {
        //    callApi()
            e.printStackTrace()
        }

    }

    private fun dpToPx(dp: Int): Int {
        val r = resources
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), r.displayMetrics))
    }
}