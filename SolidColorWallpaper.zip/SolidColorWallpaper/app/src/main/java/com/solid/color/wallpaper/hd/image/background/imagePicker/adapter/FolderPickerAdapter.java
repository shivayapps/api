package com.solid.color.wallpaper.hd.image.background.imagePicker.adapter;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.solid.color.wallpaper.hd.image.background.R;
import com.solid.color.wallpaper.hd.image.background.imagePicker.listener.OnFolderClickListener;
import com.solid.color.wallpaper.hd.image.background.imagePicker.model.Folder;
import com.solid.color.wallpaper.hd.image.background.imagePicker.ui.common.BaseRecyclerViewAdapter;
import com.solid.color.wallpaper.hd.image.background.imagePicker.ui.imagepicker.ImageLoader;

import java.util.ArrayList;
import java.util.List;

public class FolderPickerAdapter extends BaseRecyclerViewAdapter<FolderPickerAdapter.FolderViewHolder> {

    private List<Folder> folders = new ArrayList<>();
    private OnFolderClickListener itemClickListener;
    private Context context;

    public FolderPickerAdapter(Context context, ImageLoader imageLoader, OnFolderClickListener itemClickListener) {
        super(context, imageLoader);
        this.itemClickListener = itemClickListener;
        this.context=context;
    }

    @Override
    public FolderViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = getInflater().inflate(R.layout.imagepicker_item_folder, parent, false);
        return new FolderViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final FolderViewHolder holder, int position) {

        final Folder folder = folders.get(position);

        Log.d("8795846454654", "onBindViewHolder: "+folder.getFolderName());


//        Glide.with(context)
//                .load(folder.getImages().get(0).getPath())
//                .addListener(new RequestListener<Drawable>() {
//                    @Override
//                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
//                        Log.d("877894564564563", "onLoadFailed: ");
////                        imageView.setImageBitmap(bitmap);
//                        Glide.with(context).load(R.drawable.corrupt_file).into(holder.image);
//                        holder.image.setPadding(50,50,50,50);
//                        folder.getImages().get(0).setCorrupted(true);
//                        return true;
//                    }
//
//                    @Override
//                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
//                        Log.d("877894564564563", "onResourceReady: ");
//                        holder.image.setPadding(0,0,0,0);
//                        folder.getImages().get(0).setCorrupted(false);
//                        return false;
//                    }
//                })
//                .transition(DrawableTransitionOptions.withCrossFade())
//                .into(holder.image);

        RequestOptions options = new RequestOptions()
                .placeholder(R.drawable.imagepicker_image_placeholder)
                .error(R.drawable.imagepicker_image_placeholder)
                .centerCrop()
                .diskCacheStrategy(DiskCacheStrategy.RESOURCE);

        Glide.with(context)
                .load(folder.getImages().get(0).getPath())
                .apply(options)
                .addListener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        Log.d("877894564564563", "onLoadFailed: ");
                        holder.image.setImageDrawable(context.getResources().getDrawable(R.drawable.corrupt_file));
//                        Glide.with(holder.image.getContext()).load(BitmapFactory.decodeResource(context.getResources(), R.drawable.corrupt_file)).into(holder.image);
                        holder.image.setPadding(50,50,50,50);
                        folder.getImages().get(0).setCorrupted(true);
                        return true;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        Log.d("877894564564563", "onResourceReady: ");
                        holder.image.setPadding(0,0,0,0);
                        folder.getImages().get(0).setCorrupted(false);
                        return false;
                    }
                })
                .transition(DrawableTransitionOptions.withCrossFade())
                .into(holder.image);


//        getImageLoader().loadImage(folder.getImages().get(0), holder.image, BitmapFactory.decodeResource(context.getResources(), R.drawable.corrupt_file));

     /*   Glide.with(context).asBitmap().load(folder.getImages().get(0).getPath()).into(new CustomTarget<Bitmap>() {
            @Override
            public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                holder.image.setImageBitmap(blur(resource));
            }

            @Override
            public void onLoadCleared(@Nullable Drawable placeholder) {

            }
        });*/

        holder.name.setText(folder.getFolderName());

        final int count = folder.getImages().size();
        holder.count.setText(count+" Photos");

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                itemClickListener.onFolderClick(folder);
            }
        });

    }


 /*   private static final float BLUR_RADIUS = 16f;
    public Bitmap blur(Bitmap image) {
        if (null == image) return null;
        Bitmap outputBitmap = Bitmap.createBitmap(image);
        final RenderScript renderScript = RenderScript.create(context);
        Allocation tmpIn = Allocation.createFromBitmap(renderScript, image);
        Allocation tmpOut = Allocation.createFromBitmap(renderScript, outputBitmap);
        //Intrinsic Gausian blur filter
        ScriptIntrinsicBlur theIntrinsic = ScriptIntrinsicBlur.create(renderScript, Element.U8_4(renderScript));
        theIntrinsic.setRadius(BLUR_RADIUS);
        theIntrinsic.setInput(tmpIn);
        theIntrinsic.forEach(tmpOut);
        tmpOut.copyTo(outputBitmap);
        return outputBitmap;
    }*/

    public void setData(List<Folder> folders) {
        if (folders != null) {
            this.folders.clear();
            this.folders.addAll(folders);
        }
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return folders.size();
    }

    static class FolderViewHolder extends RecyclerView.ViewHolder {

        private ImageView image;
        private TextView name;
        private TextView count;

        public FolderViewHolder(View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.image_folder_thumbnail);
            name = itemView.findViewById(R.id.text_folder_name);
            count = itemView.findViewById(R.id.text_photo_count);
        }
    }

}
