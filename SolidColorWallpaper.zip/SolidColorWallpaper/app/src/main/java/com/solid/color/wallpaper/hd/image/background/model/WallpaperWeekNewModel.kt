package com.solid.color.wallpaper.hd.image.background.model

import android.os.Parcel
import android.os.Parcelable
import com.solid.color.wallpaper.hd.image.background.model.api.ImageItem

class WallpaperWeekNewModel : Parcelable {
    var imageItem: ImageItem? = null
    var isLocked: Boolean
    var path: String?
    var coins: Int

    constructor(imageItem: ImageItem?, isLocked: Boolean, path: String?, coins: Int) {
        this.imageItem = imageItem
        this.isLocked = isLocked
        this.path = path
        this.coins = coins
    }

    protected constructor(`in`: Parcel) {
        isLocked = `in`.readByte().toInt() != 0
        path = `in`.readString()
        coins = `in`.readInt()
    }

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeByte((if (isLocked) 1 else 0).toByte())
        dest.writeString(path)
        dest.writeInt(coins)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<WallpaperWeekNewModel> {
        override fun createFromParcel(parcel: Parcel): WallpaperWeekNewModel {
            return WallpaperWeekNewModel(parcel)
        }

        override fun newArray(size: Int): Array<WallpaperWeekNewModel?> {
            return arrayOfNulls(size)
        }
    }


}