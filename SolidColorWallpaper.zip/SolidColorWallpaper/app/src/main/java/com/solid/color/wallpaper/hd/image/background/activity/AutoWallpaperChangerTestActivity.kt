package com.solid.color.wallpaper.hd.image.background.activity

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.util.DisplayMetrics
import android.util.Log
import android.util.TypedValue
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.FragmentTransaction
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.airbnb.lottie.LottieAnimationView
import com.auto.wallpaper.live.background.changer.editor.receiver.EventReceiver
import com.auto.wallpaper.live.background.changer.editor.receiver.EventReceiver.Companion.cancelAlarm
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.SolidWallpaperApplication
import com.solid.color.wallpaper.hd.image.background.activity.AutoWallpaperChangerTestActivity
import com.solid.color.wallpaper.hd.image.background.adapter.LiveWallpaperListAdapter
import com.solid.color.wallpaper.hd.image.background.adapter.SettingsRecyclerAdapter
import com.solid.color.wallpaper.hd.image.background.adapter.SettingsRecyclerAdapter.OnLongClicked
import com.solid.color.wallpaper.hd.image.background.custom.BottomSheetFragment
import com.solid.color.wallpaper.hd.image.background.custom.BottomSheetFragmentDiscard
import com.solid.color.wallpaper.hd.image.background.custom.GridSpacingItemDecoration
import com.solid.color.wallpaper.hd.image.background.custom.TimePickerDialog
import com.solid.color.wallpaper.hd.image.background.fragment.*
import com.solid.color.wallpaper.hd.image.background.model.*
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs.getBoolean
import com.solid.color.wallpaper.hd.image.background.shared_pref.MySharedPref
import com.solid.color.wallpaper.hd.image.background.sqlite_database.DBHelperAutoWallpaper
import java.io.*
import java.util.*

class AutoWallpaperChangerTestActivity constructor() : AppCompatActivity(), View.OnClickListener {
    private var btnNext: ImageView? = null
    private var btnShare: ImageView? = null
    private var icBack: ImageView? = null
    private var icAdd: ImageView? = null
    private var imgCreationDD: LottieAnimationView? = null
    private var imgSolidDD: LottieAnimationView? = null
    var bottomSheetFragment:BottomSheetFragmentDiscard?=null
    // private LottieAnimationView icSubcription;
    private var layoutSelectWallpaper: ConstraintLayout? = null
    private var selectDDCreation: ConstraintLayout? = null
    private var selectDDSolid: ConstraintLayout? = null
    private var cstMainSettings: ConstraintLayout? = null
    private var bottomButtonEditSettings: ConstraintLayout? = null
    private var bottomButtonLayoutSettings: ConstraintLayout? = null
    private var layoutTopSetting: ConstraintLayout? = null
    private var llScreenMode: ConstraintLayout? = null
    private var llDelayTime: ConstraintLayout? = null
    private var recyclerSelectedWallpaper: RecyclerView? = null
    private var solidSelectableFragment: SolidSelectableFragment? = null
    private var gradientSelectableFragment: GradientSelectableFragment? = null
    private var textSelectableFragment: TextSelectableFragment? = null
    private var creationSelectableFragment: CreationSelectableFragment? = null
    private var gallerySelectableFragment: GallerySelectableFragment? = null
    private var solidSingleSelectableFragment: SolidSingleSelectableFragment? = null
    private var gradientSingleSelectableFragment: GradientSingleSelectableFragment? = null
    private var textSingleSelectableFragment: TextSingleSelectableFragment? = null
    private var creationSingleSelectableFragment: CreationSingleSelectableFragment? = null
    private var gallerySingleSelectableFragment: GallerySingleSelectableFragment? = null
    private var txtCreationDD: TextView? = null
    private var txtSolidDD: TextView? = null
    private var btnApplyWallpaperSettings: TextView? = null
    private var btnAddWallpaperSettings: TextView? = null
    private var txtScreenMode: TextView? = null
    private var txtDelayTime: TextView? = null
    private var btnDeleteWallpaperSettings: TextView? = null
    private var btnEditWallpaperSettings: TextView? = null
    private var spinnerSolidDD: Spinner? = null
    private var spinnerCreationDD: Spinner? = null
    private lateinit var items: Array<String>
    private lateinit var items2: Array<String>
    private var frameGallery: FrameLayout? = null
    private var frameCreation: FrameLayout? = null
    private var frameText: FrameLayout? = null
    private var frameGradient: FrameLayout? = null
    private var frameSolid: FrameLayout? = null
    private var isFirstS: Boolean = false
    private var isFirstC: Boolean = false
    private var isFirstS1: Boolean = false
    private var isFirstC1: Boolean = false
    private var positionSolid: Int = 0
    private var positionCreation: Int = 0
    private var progressFragment: ProgressBar? = null
    private var progressRecycler: ProgressBar? = null
    private var mSelectedList: ArrayList<Any>? = null
    private var delayTime: String? = "Random"
    private var screenMode: String? = "Home Screen"
    private var mBitmapList: ArrayList<Bitmap>? = null
    private var mSelectedImagesList: ArrayList<SettingsImagesModel>? = null
    private var dbHelperAutoWallpaper: DBHelperAutoWallpaper? = null
    private var isLongClicked: Boolean = false
    private var settingsRecyclerAdapter: SettingsRecyclerAdapter? = null
    private var isAddMenuOpen: Boolean = false
    private var isEditOpen: Boolean = false
    private var isApplyClicked: Boolean = false
    private var isSettingsOpen: Boolean = false
    private var settingsImagesModelEdit: SettingsImagesModel? = null
    private var mAllWallpaperList: ArrayList<AutoWallpaperModel>? = null
    private val liveWallpaperAdapter: LiveWallpaperListAdapter? = null
    private var glideLoadImageCount: Int = 0
    private var imageList: ArrayList<String>? = null
    private var isEditSettingsOpen: Boolean = false
    private var mySharedPref: MySharedPref? = null
    private var isEditClicked: Boolean = false
    private var autoWallpaperModelEdit: AutoWallpaperModel? = null
    private var isAnimRunning: Boolean = false
    private var mBitmapListUpdate: ArrayList<SettingsImagesModel>? = null
    private val progressDialog: ProgressDialog? = null
    private var isEditBottomClicked: Boolean = false
    var bottomSheetFragments:BottomSheetFragment?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_auto_wallpaper_changer_test)
        System.gc()
        Runtime.getRuntime().gc()
        mySharedPref = MySharedPref(this)
        initViews()
        initListner()
        val i: Intent = intent
        autoWallpaperModelEdit = i.getSerializableExtra("AutoObject") as AutoWallpaperModel?
        items = arrayOf(getResources().getString(R.string.solid), getResources().getString(R.string.gradient), getResources().getString(R.string.text_mywallpaper))
        items2 = arrayOf(getResources().getString(R.string.creation), getResources().getString(R.string.gallery))
        initViewAction()
    }

    private fun initViewAction() {
        mAllWallpaperList = ArrayList()
        dbHelperAutoWallpaper = DBHelperAutoWallpaper(this@AutoWallpaperChangerTestActivity)
        mAllWallpaperList = dbHelperAutoWallpaper!!.allAutoWallpaper
        mBitmapList = ArrayList()
        mSelectedImagesList = ArrayList()
        val manager: GridLayoutManager = GridLayoutManager(this@AutoWallpaperChangerTestActivity, 3)
        recyclerSelectedWallpaper!!.layoutManager = manager
        recyclerSelectedWallpaper!!.addItemDecoration(GridSpacingItemDecoration(3, dpToPx(6), true))
        recyclerSelectedWallpaper!!.itemAnimator = DefaultItemAnimator()
        isFirstC = false
        isFirstS = false
        positionCreation = 0
        positionSolid = 0
        val adapter: ArrayAdapter<String> = ArrayAdapter(this@AutoWallpaperChangerTestActivity, R.layout.spinner_item, R.id.text1, items)
        adapter.setDropDownViewResource(R.layout.sinner_dropdown_item)
        spinnerSolidDD!!.adapter = adapter
        val adapter2: ArrayAdapter<String> = ArrayAdapter(this@AutoWallpaperChangerTestActivity, R.layout.spinner_item, R.id.text1, items2)
        adapter2.setDropDownViewResource(R.layout.sinner_dropdown_item)
        spinnerCreationDD!!.adapter = adapter2

        /*  Animation anim = new AlphaAnimation(0.0f, 1.0f);
        anim.setDuration(1000);
        anim.setStartOffset(20);
        anim.setRepeatMode(Animation.REVERSE);
        anim.setRepeatCount(Animation.INFINITE);
        imgSolidDD.startAnimation(anim);
*/spinnerCreationDD!!.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            public override fun onItemSelected(parent: AdapterView<*>?, view: View, position: Int, id: Long) {
                if (isFirstC) {
                    positionCreation = position
                    txtCreationDD!!.text = items2[position]
                    if (position == 0) {
                        frameSolid!!.visibility = View.GONE
                        frameCreation!!.visibility = View.VISIBLE
                        frameGallery!!.visibility = View.GONE
                        frameGradient!!.visibility = View.GONE
                        frameText!!.visibility = View.GONE
                    } else if (position == 1) {
                        frameSolid!!.visibility = View.GONE
                        frameCreation!!.visibility = View.GONE
                        frameGallery!!.visibility = View.VISIBLE
                        frameGradient!!.visibility = View.GONE
                        frameText!!.visibility = View.GONE
                    }
                } else {
                    isFirstC = true
                }
            }

            public override fun onNothingSelected(parent: AdapterView<*>?) {
                isFirstC1 = true
            }
        }
        spinnerSolidDD!!.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            public override fun onItemSelected(parent: AdapterView<*>?, view: View, position: Int, id: Long) {
                if (isFirstS) {
                    positionSolid = position
                    txtSolidDD!!.text = items[position]
                    if (position == 0) {
                        frameSolid!!.visibility = View.VISIBLE
                        frameCreation!!.visibility = View.GONE
                        frameGallery!!.visibility = View.GONE
                        frameGradient!!.visibility = View.GONE
                        frameText!!.visibility = View.GONE
                    } else if (position == 1) {
                        frameSolid!!.visibility = View.GONE
                        frameCreation!!.visibility = View.GONE
                        frameGallery!!.visibility = View.GONE
                        frameGradient!!.visibility = View.VISIBLE
                        frameText!!.visibility = View.GONE
                    } else if (position == 2) {
                        frameSolid!!.visibility = View.GONE
                        frameCreation!!.visibility = View.GONE
                        frameGallery!!.visibility = View.GONE
                        frameGradient!!.visibility = View.GONE
                        frameText!!.visibility = View.VISIBLE
                    }
                } else {
                    isFirstS = true
                }
            }

            public override fun onNothingSelected(parent: AdapterView<*>?) {
                isFirstS1 = true
            }
        }
        if (autoWallpaperModelEdit == null) {
            setDataFragment()
        } else {
            findViewById<View>(R.id.linearLayout3).visibility = View.GONE
            editWallpaper(autoWallpaperModelEdit!!)
            btnApplyWallpaperSettings!!.isEnabled = false
        }
    }

    private fun setDataFragment() {
        progressFragment!!.visibility = View.VISIBLE
        txtCreationDD!!.alpha = 0.5f
        imgCreationDD!!.visibility = View.GONE
        txtSolidDD!!.alpha = 1f
        imgSolidDD!!.visibility = View.VISIBLE
        txtSolidDD!!.text = resources.getString(R.string.solid)
        txtCreationDD!!.text = resources.getString(R.string.creation)
        delayTime = "Random"
        screenMode = "Home Screen"
        txtDelayTime!!.text = delayTime
        txtScreenMode!!.text = screenMode
        frameSolid!!.visibility = View.GONE
        frameCreation!!.visibility = View.GONE
        frameGallery!!.visibility = View.GONE
        frameGradient!!.visibility = View.GONE
        frameText!!.visibility = View.GONE
        if (mSelectedList != null) {
            mSelectedList!!.clear()
        }
        if (mSelectedImagesList != null) {
            mSelectedImagesList!!.clear()
        }
        solidSelectableFragment = SolidSelectableFragment()
        gradientSelectableFragment = GradientSelectableFragment()
        textSelectableFragment = TextSelectableFragment()
        creationSelectableFragment = CreationSelectableFragment()
        gallerySelectableFragment = GallerySelectableFragment()
        layoutSelectWallpaper!!.visibility = View.VISIBLE
        layoutSelectWallpaper!!.translationY = layoutSelectWallpaper!!.height.toFloat()
        //  layoutMainWallpaperList.animate().translationYBy(-layoutMainWallpaperList.getHeight()).setDuration(300).start();
        layoutSelectWallpaper!!.animate().translationYBy(-layoutSelectWallpaper!!.height.toFloat()).setDuration(300).start()
        if (!getBoolean(this@AutoWallpaperChangerTestActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
            icAdd!!.animate().alpha(0f).withEndAction(object : Runnable {
                public override fun run() {
                    icAdd!!.visibility = View.INVISIBLE
                }
            }).setDuration(300).start()
            btnNext!!.alpha = 0f
            btnNext!!.visibility = View.VISIBLE
            btnNext!!.animate().alpha(1f).setDuration(300).start()
        } else {
            btnShare!!.animate().alpha(0f).withEndAction { btnShare!!.visibility = View.INVISIBLE }.setDuration(300).start()
            btnNext!!.alpha = 0f
            btnNext!!.visibility = View.VISIBLE
            btnNext!!.animate().alpha(1f).setDuration(300).start()
        }
        Handler().postDelayed(object : Runnable {
            public override fun run() {
                val transaction: FragmentTransaction = getSupportFragmentManager().beginTransaction()
                transaction.replace(R.id.frameSolid, solidSelectableFragment!!)
                transaction.replace(R.id.frameCreation, creationSelectableFragment!!)
                transaction.replace(R.id.frameGradient, gradientSelectableFragment!!)
                transaction.replace(R.id.frameText, textSelectableFragment!!)
                transaction.replace(R.id.frameGallery, gallerySelectableFragment!!)
                transaction.commitAllowingStateLoss()
                frameSolid!!.visibility = View.VISIBLE
                frameCreation!!.visibility = View.GONE
                frameGallery!!.visibility = View.GONE
                frameGradient!!.visibility = View.GONE
                frameText!!.visibility = View.GONE
                progressFragment!!.visibility = View.GONE
            }
        }, 300)
    }

    private fun editWallpaper(autoWallpaperModel: AutoWallpaperModel) {
        screenMode = autoWallpaperModel.screenmode
        delayTime = autoWallpaperModel.delaytime
        autoWallpaperModelEdit = autoWallpaperModel
        recyclerSelectedWallpaper!!.visibility = View.GONE
        cstMainSettings!!.visibility = View.VISIBLE
        progressRecycler!!.visibility = View.VISIBLE
        val time: String?
        if (delayTime!!.contains("C")) {
            time = delayTime!!.replace("C", "").trim({ it <= ' ' })
        } else {
            time = delayTime
        }
        txtDelayTime!!.text = time
        txtScreenMode!!.text = autoWallpaperModel.screenmode
        isEditClicked = true
        val gson: Gson = Gson()
        val token: TypeToken<ArrayList<String?>?> = object : TypeToken<ArrayList<String?>?>() {}
        imageList = gson.fromJson(autoWallpaperModel.imagespath, token.type)
        Handler().postDelayed({
            LoadImages().execute()
            isEditSettingsOpen = true
        }, 300)
        isSettingsOpen = true
        layoutTopSetting!!.visibility = View.VISIBLE
        bottomButtonLayoutSettings!!.visibility = View.VISIBLE
        btnNext!!.visibility = View.GONE
        layoutSelectWallpaper!!.post { layoutSelectWallpaper!!.translationY = layoutSelectWallpaper!!.height.toFloat() }
        icAdd!!.visibility = View.VISIBLE

        /*   if (!AdsPrefs.getBoolean(AutoWallpaperChangerTestActivity.this, AdsPrefs.IS_SUBSCRIBED, false)) {
            icSubcription.setVisibility(View.VISIBLE);
            icSubcription.animate().alpha(1f).setDuration(300).start();
        } else {
            btnShare.setVisibility(View.VISIBLE);
            btnShare.animate().alpha(1f).setDuration(300).start();
        }
*/
    }

    internal inner class LoadImages constructor() : AsyncTask<Void?, Boolean?, Boolean>() {
        var count: Int = 0
        override fun onPreExecute() {
            super.onPreExecute()
            System.gc()
            Runtime.getRuntime().gc()
        }

        override fun onPostExecute(aBoolean: Boolean) {
            super.onPostExecute(aBoolean)
            try {
                if (aBoolean) {
                    progressRecycler!!.visibility = View.GONE
                    btnApplyWallpaperSettings!!.isEnabled = true
                    if (!isAddMenuOpen) {
                        recyclerSelectedWallpaper!!.visibility = View.VISIBLE
                    }
                    val onLongClicked: OnLongClicked = object : OnLongClicked {
                        public override fun onLongClicked(isClicked: Boolean) {
                            isLongClicked = true
                            isEditBottomClicked = true
                            bottomButtonEditSettings!!.visibility = View.VISIBLE
                            bottomButtonEditSettings!!.translationY = bottomButtonLayoutSettings!!.height.toFloat()
                            bottomButtonLayoutSettings!!.post {
                                bottomButtonLayoutSettings!!.animate().translationYBy(bottomButtonLayoutSettings!!.height.toFloat()).setDuration(300).start()
                                bottomButtonEditSettings!!.animate().translationYBy(-bottomButtonLayoutSettings!!.height.toFloat()).setDuration(300).start()
                            }
                        }
                    }
                    settingsRecyclerAdapter = SettingsRecyclerAdapter((mSelectedImagesList)!!, this@AutoWallpaperChangerTestActivity, onLongClicked)
                    recyclerSelectedWallpaper!!.adapter = settingsRecyclerAdapter
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        protected override fun doInBackground(vararg params: Void?): Boolean? {
            mSelectedImagesList!!.clear()
            for (i in imageList!!.indices) {
                Glide.with(this@AutoWallpaperChangerTestActivity).asBitmap().load(imageList!![i]).into(object : CustomTarget<Bitmap?>() {
                    public override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap?>?) {
                        mSelectedImagesList!!.add(SettingsImagesModel(resource, false))
                        count++
                        if (count == imageList!!.size) {
                            onPostExecute(true)
                            count++
                        }
                    }

                    public override fun onLoadCleared(placeholder: Drawable?) {}
                })
            }
            return false
        }
    }

    private val dataWallpaper: Unit
        private get() {
            mAllWallpaperList!!.clear()
            mAllWallpaperList = dbHelperAutoWallpaper!!.allAutoWallpaper
        }

    private fun initListner() {
        icBack!!.setOnClickListener(this)
        icAdd!!.setOnClickListener(this)
        btnShare!!.setOnClickListener(this)
        btnNext!!.setOnClickListener(this)
        selectDDCreation!!.setOnClickListener(this)
        selectDDSolid!!.setOnClickListener(this)
        btnApplyWallpaperSettings!!.setOnClickListener(this)
        btnAddWallpaperSettings!!.setOnClickListener(this)
        llScreenMode!!.setOnClickListener(this)
        llDelayTime!!.setOnClickListener(this)
        btnDeleteWallpaperSettings!!.setOnClickListener(this)
        btnEditWallpaperSettings!!.setOnClickListener(this)
        findViewById<View>(R.id.toolbar).setOnClickListener(this)
    }

    private fun initViews() {
        icBack = findViewById(R.id.icBack)
        icAdd = findViewById(R.id.icAdd)
        btnNext = findViewById(R.id.btnNext)
        btnShare = findViewById(R.id.btnShare)
        layoutSelectWallpaper = findViewById(R.id.layoutSelectWallpaper)
        selectDDSolid = findViewById(R.id.selectDDSolidN)
        selectDDCreation = findViewById(R.id.selectDDCreationN)
        txtSolidDD = findViewById(R.id.txtSolidDD)
        txtCreationDD = findViewById(R.id.txtCreationDD)
        imgSolidDD = findViewById(R.id.imgSolidDD)
        imgCreationDD = findViewById(R.id.imgCreationDD)
        spinnerCreationDD = findViewById(R.id.spinnerCreationDD)
        spinnerSolidDD = findViewById(R.id.spinnerSolidDD)
        frameSolid = findViewById(R.id.frameSolid)
        frameGradient = findViewById(R.id.frameGradient)
        frameGallery = findViewById(R.id.frameGallery)
        frameCreation = findViewById(R.id.frameCreation)
        frameText = findViewById(R.id.frameText)
        progressFragment = findViewById(R.id.progressFragment)
        cstMainSettings = findViewById(R.id.cstMainSettings)
        layoutTopSetting = findViewById(R.id.layoutTopSetting)
        bottomButtonLayoutSettings = findViewById(R.id.bottomButtonLayoutSettings)
        recyclerSelectedWallpaper = findViewById(R.id.recyclerSelectedWallpaper)
        progressRecycler = findViewById(R.id.progressRecycler)
        btnAddWallpaperSettings = findViewById(R.id.btnAddWallpaperSettings)
        btnApplyWallpaperSettings = findViewById(R.id.btnApplyWallpaperSettings)
        llDelayTime = findViewById(R.id.llDelayTime)
        llScreenMode = findViewById(R.id.llScreenMode)
        txtDelayTime = findViewById(R.id.txtDelayTime)
        txtScreenMode = findViewById(R.id.txtScreenMode)
        bottomButtonEditSettings = findViewById(R.id.bottomButtonEditSettings)
        btnEditWallpaperSettings = findViewById(R.id.btnEditWallpaperSettings)
        btnDeleteWallpaperSettings = findViewById(R.id.btnDeleteWallpaperSettings)
    }

    public override fun onClick(v: View) {
        when (v.id) {
            R.id.icBack -> onBackPressed()
            R.id.icAdd -> {
                icAdd!!.isEnabled = false
                btnEditWallpaperSettings!!.isEnabled = false
                btnApplyWallpaperSettings!!.isEnabled = false
                Handler().postDelayed({
                    icAdd!!.isEnabled = true
                    btnApplyWallpaperSettings!!.isEnabled = true
                    btnEditWallpaperSettings!!.isEnabled = true
                }, 3000)
                isAnimRunning = true
                try {
                    onClickAddWallpaperSettings()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            R.id.btnShare -> shareApp()
            R.id.btnNext -> {
                btnNext!!.isEnabled = false
                icAdd!!.isEnabled = false
                btnApplyWallpaperSettings!!.isEnabled = false
                Handler().postDelayed({
                    icAdd!!.isEnabled = true
                    btnApplyWallpaperSettings!!.isEnabled = true
                }, 3000)
                onclickDone()
            }
            R.id.selectDDSolidN -> onClickSolidDropDown()
            R.id.selectDDCreationN -> onClickCreationDropDown()
            R.id.btnApplyWallpaperSettings -> {
                icAdd!!.isEnabled = false
                btnApplyWallpaperSettings!!.isEnabled = false
                Handler().postDelayed({
                    icAdd!!.isEnabled = true
                    btnApplyWallpaperSettings!!.isEnabled = true
                }, 3000)
                onClickApplyWallpaperSettings()
            }
            R.id.llDelayTime -> onClickDelayTime()
            R.id.llScreenMode -> onClickScreenMode()
            R.id.btnEditWallpaperSettings -> {
//                btnEditWallpaperSettings!!.isEnabled = false
                icAdd!!.isEnabled = false
                onClickEditWallpaper()
            }
            R.id.btnDeleteWallpaperSettings -> onClickDeleteWallpaper()
        }
    }

    /*  private void showAd() {
          if (!AdsPrefs.getBoolean(AutoWallpaperChangerTestActivity.this, AdsPrefs.IS_SUBSCRIBED, false)) {
              if (SolidWallpaperApplication.getInstance().requestNewInterstitial()) {
                  SolidWallpaperApplication.getInstance().mInterstitialAd.setAdListener(new AdListener() {

                      @Override
                      public void onAdClosed() {
                          super.onAdClosed();
                          loadInterstialAd();

                      }

                      @Override
                      public void onAdFailedToLoad(int i) {
                          super.onAdFailedToLoad(i);

                      }

                      @Override
                      public void onAdLoaded() {
                          super.onAdLoaded();
                      }
                  });

              } else {
                  Toast.makeText(AutoWallpaperChangerTestActivity.this, "Try again later.", Toast.LENGTH_SHORT).show();
              }
          }
      }
  */
    private fun shareApp() {
        val shareIntent: Intent = Intent(Intent.ACTION_SEND)
        shareIntent.type = "text/plain"
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Solid Color Wallpaper")
        var shareMessage: String = ""
        shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=com.solid.color.wallpaper.hd.image.background"
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
        startActivity(Intent.createChooser(shareIntent, getResources().getString(R.string.choose_one)))
    }

    private fun onClickEditWallpaper() {
//        Handler(Looper.getMainLooper()).postDelayed({
//            findViewById<TextView>(R.id.btnEditWallpaperSettings).isEnabled = true
//            findViewById<TextView>(R.id.btnAddWallpaperSettings).isEnabled = true
//            btnAddWallpaperSettings!!.isEnabled=true
//        },5000)

        layoutSelectWallpaper!!.visibility=View.VISIBLE
        cstMainSettings!!.visibility=View.GONE

        btnNext!!.visibility = View.VISIBLE
        icAdd!!.visibility=View.GONE

        if (mSelectedImagesList != null && mSelectedImagesList!!.size > 0) {
            var count: Int = 0
            var position: Int = 0
            for (i in mSelectedImagesList!!.indices) {
                if (mSelectedImagesList!!.get(i).isDeletable) {
                    count++
                    position = i
                }
            }
            if (count > 1) {
                layoutSelectWallpaper!!.visibility=View.GONE
                cstMainSettings!!.visibility=View.VISIBLE

                btnNext!!.visibility = View.GONE
                icAdd!!.visibility=View.VISIBLE
                Toast.makeText(this, getResources().getString(R.string.you_can_edit_one_image_at_a_time), Toast.LENGTH_SHORT).show()
//                btnEditWallpaperSettings!!.isEnabled = false
                icAdd!!.isEnabled = true
            } else if (count < 1) {
                layoutSelectWallpaper!!.visibility=View.GONE
                cstMainSettings!!.visibility=View.VISIBLE

                btnNext!!.visibility = View.GONE
                icAdd!!.visibility=View.VISIBLE
                Toast.makeText(this, getResources().getString(R.string.select_one_image_to_edit), Toast.LENGTH_SHORT).show()
//                btnEditWallpaperSettings!!.isEnabled = false
                icAdd!!.isEnabled = true
            } else {
//                btnEditWallpaperSettings!!.isEnabled=true
                isEditOpen = true
                isLongClicked = false
                settingsImagesModelEdit = mSelectedImagesList!!.get(position)
                val onItemClicked: SolidSingleSelectableFragment.OnItemClicked = object : SolidSingleSelectableFragment.OnItemClicked {
                    public override fun onItemClicked() {
                        gradientSingleSelectableFragment!!.setDataChanged()
                        textSingleSelectableFragment!!.setDataChanged()
                        creationSingleSelectableFragment!!.setDataChanged()
                        gallerySingleSelectableFragment!!.setDataChanged()
                    }
                }
                val onItemClicked1: GradientSingleSelectableFragment.OnItemClicked = object : GradientSingleSelectableFragment.OnItemClicked {
                    public override fun onItemClicked() {
                        solidSingleSelectableFragment!!.setDataChanged()
                        textSingleSelectableFragment!!.setDataChanged()
                        creationSingleSelectableFragment!!.setDataChanged()
                        gallerySingleSelectableFragment!!.setDataChanged()
                    }
                }
                val onItemClicked2: TextSingleSelectableFragment.OnItemClicked = object : TextSingleSelectableFragment.OnItemClicked {
                    public override fun onItemClicked() {
                        gradientSingleSelectableFragment!!.setDataChanged()
                        solidSingleSelectableFragment!!.setDataChanged()
                        creationSingleSelectableFragment!!.setDataChanged()
                        gallerySingleSelectableFragment!!.setDataChanged()
                    }
                }
                val onItemClicked3: CreationSingleSelectableFragment.OnItemClicked = object : CreationSingleSelectableFragment.OnItemClicked {
                    public override fun onItemClicked() {
                        gradientSingleSelectableFragment!!.setDataChanged()
                        textSingleSelectableFragment!!.setDataChanged()
                        solidSingleSelectableFragment!!.setDataChanged()
                        gallerySingleSelectableFragment!!.setDataChanged()
                    }
                }
                val onItemClicked4: GallerySingleSelectableFragment.OnItemClicked = object : GallerySingleSelectableFragment.OnItemClicked {
                    public override fun onItemClicked() {
                        gradientSingleSelectableFragment!!.setDataChanged()
                        textSingleSelectableFragment!!.setDataChanged()
                        solidSingleSelectableFragment!!.setDataChanged()
                        creationSingleSelectableFragment!!.setDataChanged()
                    }
                }
                solidSingleSelectableFragment = SolidSingleSelectableFragment(onItemClicked)
                gradientSingleSelectableFragment = GradientSingleSelectableFragment(onItemClicked1)
                textSingleSelectableFragment = TextSingleSelectableFragment(onItemClicked2)
                creationSingleSelectableFragment = CreationSingleSelectableFragment(onItemClicked3)
                gallerySingleSelectableFragment = GallerySingleSelectableFragment(onItemClicked4)
                val transaction: FragmentTransaction = supportFragmentManager.beginTransaction()
                try {
                    transaction.remove((Objects.requireNonNull(supportFragmentManager.findFragmentById(R.id.frameSolid)))!!)
                    transaction.remove((Objects.requireNonNull(supportFragmentManager.findFragmentById(R.id.frameCreation)))!!)
                    transaction.remove((Objects.requireNonNull(supportFragmentManager.findFragmentById(R.id.frameGallery)))!!)
                    transaction.remove((Objects.requireNonNull(supportFragmentManager.findFragmentById(R.id.frameText)))!!)
                    transaction.remove((Objects.requireNonNull(supportFragmentManager.findFragmentById(R.id.frameGradient)))!!)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                transaction.replace(R.id.frameSolid, solidSingleSelectableFragment!!)
                transaction.replace(R.id.frameCreation, creationSingleSelectableFragment!!)
                transaction.replace(R.id.frameGradient, gradientSingleSelectableFragment!!)
                transaction.replace(R.id.frameText, textSingleSelectableFragment!!)
                transaction.replace(R.id.frameGallery, gallerySingleSelectableFragment!!)
                transaction.commitAllowingStateLoss()
                layoutTopSetting!!.animate().translationYBy(-layoutTopSetting!!.height.toFloat()).setDuration(300).start()
                recyclerSelectedWallpaper!!.animate().alpha(0f).withEndAction {
                    recyclerSelectedWallpaper!!.visibility = View.GONE
                    recyclerSelectedWallpaper!!.alpha = 1f
                }.setDuration(200).start()
                bottomButtonEditSettings!!.animate().translationYBy(bottomButtonEditSettings!!.getHeight().toFloat()).withEndAction(object : Runnable {
                    public override fun run() {
                        layoutSelectWallpaper!!.animate().translationYBy(-layoutSelectWallpaper!!.getHeight().toFloat()).withEndAction(object : Runnable {
                            public override fun run() {
                                if (!getBoolean(this@AutoWallpaperChangerTestActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                                    icAdd!!.animate().alpha(0f).withEndAction(object : Runnable {
                                        public override fun run() {
                                            icAdd!!.visibility = View.INVISIBLE
                                        }
                                    }).setDuration(300).start()
                                    btnNext!!.alpha = 0f
                                    btnNext!!.visibility = View.VISIBLE
                                    btnNext!!.animate().alpha(1f).setDuration(300).start()
                                } else {
                                    btnShare!!.animate().alpha(0f).withEndAction { btnShare!!.visibility = View.INVISIBLE }.setDuration(300).start()
                                    btnNext!!.alpha = 0f
                                    btnNext!!.visibility = View.VISIBLE
                                    btnNext!!.animate().alpha(1f).setDuration(300).start()
                                }
                            }
                        }).setDuration(200).start()
                    }
                }).setDuration(300).start()
                btnEditWallpaperSettings!!.isEnabled = true
                icAdd!!.isEnabled = true
            }
            progressFragment!!.visibility = View.GONE
        }
    }

    private fun onClickDeleteWallpaper() {
        if (mSelectedImagesList != null && mSelectedImagesList!!.size > 0) {
            var count: Int = 0
            for (i in mSelectedImagesList!!.indices) {
                if (mSelectedImagesList!!.get(i).isDeletable) {
                    count++
                }
            }

            /*  Log.d(TAG, "onClickDeleteWallpaper: " + settingsRecyclerAdapter.getUpdatedData().size());

            for (int i = 0; i < settingsRecyclerAdapter.getUpdatedData().size(); i++) {
                Log.d(TAG, "onClickDeleteWallpaper: " + i + ". " + settingsRecyclerAdapter.getUpdatedData().get(i).isDeletable());
            }
*/if (count < 1) {
                Toast.makeText(this, getResources().getString(R.string.select_one_image_to_delete), Toast.LENGTH_SHORT).show()
            } else if (count == mSelectedImagesList!!.size) {
                Toast.makeText(this, getResources().getString(R.string.you_cant_remove_alla_images), Toast.LENGTH_SHORT).show()
            } else {
                showAlertDialog()
            }
        }
    }

    private fun showAlertDialog() {
         bottomSheetFragments = BottomSheetFragment(getResources().getString(R.string.remove), getResources().getString(R.string.are_you_want_to_remove), getResources().getString(R.string.remove), getResources().getString(R.string.cancel), R.drawable.ic_delete_dialog, object : BottomSheetFragment.OnButtonClickListener {
            public override fun onPositive(bottomSheetDialo: BottomSheetFragment?) {
                val iterator: MutableIterator<SettingsImagesModel> = mSelectedImagesList!!.iterator() // it will return iterator
                while (iterator.hasNext()) {
                    if (iterator.next().isDeletable) {
                        iterator.remove()
                    }
                }
                Handler().postDelayed(object : Runnable {
                    public override fun run() {
                        settingsRecyclerAdapter!!.setDataChanged()
                    }
                }, 200)
                bottomSheetDialo!!.dismiss()
                isLongClicked = false
                bottomButtonLayoutSettings!!.animate().translationYBy(-bottomButtonLayoutSettings!!.getHeight().toFloat()).setDuration(300).start()
                bottomButtonEditSettings!!.animate().withEndAction(object : Runnable {
                    public override fun run() {
                        settingsRecyclerAdapter!!.setDataChanged()
                    }
                }).translationYBy(bottomButtonLayoutSettings!!.getHeight().toFloat()).setDuration(300).start()
            }

            public override fun onNegative(bottomSheetDialog: BottomSheetFragment?) {
                bottomSheetDialog!!.dismiss()
            }
        })
        bottomSheetFragments!!.show(supportFragmentManager, "dialog")
    }

    private fun onClickScreenMode() {
        val dialog: Dialog = Dialog(this@AutoWallpaperChangerTestActivity)
        dialog.setContentView(R.layout.dialog_screenmode_select)
        Objects.requireNonNull(dialog.getWindow())!!.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)
        val txtBoth: TextView = dialog.findViewById(R.id.txtBoth)
        val txtLockScreen: TextView = dialog.findViewById(R.id.txtLockScreen)
        val txtHomeScreen: TextView = dialog.findViewById(R.id.txtHomeScreen)
        val btnPositive: Button = dialog.findViewById(R.id.btnPositive)
        val btnNagative: Button = dialog.findViewById(R.id.btnNagative)
        val checkBoth: ImageView = dialog.findViewById(R.id.checkBoth)
        val checkHome: ImageView = dialog.findViewById(R.id.checkHome)
        val checkLock: ImageView = dialog.findViewById(R.id.checkLock)
        val list: Array<Any> = arrayOf(checkBoth, checkHome, checkLock)
        if ((screenMode == "Home Screen")) {
            setSelection(checkHome, list)
        } else if ((screenMode == "Lock Screen")) {
            setSelection(checkLock, list)
        } else {
            setSelection(checkBoth, list)
        }
        val tempSceenMode: Array<String> = arrayOf("")
        txtBoth.setOnClickListener(View.OnClickListener { v: View? ->
            setSelection(checkBoth, list)
            tempSceenMode[0] = "Both"
        })
        txtLockScreen.setOnClickListener(View.OnClickListener { v: View? ->
            setSelection(checkLock, list)
            tempSceenMode[0] = "Lock Screen"
        })
        txtHomeScreen.setOnClickListener(View.OnClickListener { v: View? ->
            setSelection(checkHome, list)
            tempSceenMode[0] = "Home Screen"
        })
        btnNagative.setOnClickListener(View.OnClickListener({ v: View? -> dialog.dismiss() }))
        btnPositive.setOnClickListener(View.OnClickListener { v: View? ->
            dialog.dismiss()
            if (!(tempSceenMode.get(0) == "")) {
                screenMode = tempSceenMode.get(0)
            }
            txtScreenMode!!.setText(screenMode)
        })
        dialog.show()
    }

    private fun onClickDelayTime() {
        val dialog: Dialog = Dialog(this@AutoWallpaperChangerTestActivity)
        dialog.setContentView(R.layout.dialog_delaytime_select)
        Objects.requireNonNull(dialog.getWindow())!!.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)
        val textView5Sec: TextView = dialog.findViewById(R.id.txt5Second)
        val textView15Sec: TextView = dialog.findViewById(R.id.txt15Second)
        val textView30Sec: TextView = dialog.findViewById(R.id.txt30Second)
        val textView2Min: TextView = dialog.findViewById(R.id.txt2Min)
        val textView5Min: TextView = dialog.findViewById(R.id.txt5Min)
        val textView15Min: TextView = dialog.findViewById(R.id.txt15Min)
        val textViewRandom: TextView = dialog.findViewById(R.id.txtRandom)
        val textViewCustom: TextView = dialog.findViewById(R.id.txtCustom)
        val btnPositive: Button = dialog.findViewById(R.id.btnPositive)
        val btnNagative: Button = dialog.findViewById(R.id.btnNagative)
        val imgView5Sec: ImageView = dialog.findViewById(R.id.check5Sec)
        val imgView15Sec: ImageView = dialog.findViewById(R.id.check15Sec)
        val imgView30Sec: ImageView = dialog.findViewById(R.id.check30Sec)
        val imgView2Min: ImageView = dialog.findViewById(R.id.check2Min)
        val imgView5Min: ImageView = dialog.findViewById(R.id.check5Min)
        val imgView15Min: ImageView = dialog.findViewById(R.id.check15Min)
        val imgViewRandom: ImageView = dialog.findViewById(R.id.checkRandom)
        val imgViewCustom: ImageView = dialog.findViewById(R.id.checkCustom)
        val list: Array<Any> = arrayOf(imgView5Sec, imgView15Sec, imgView30Sec, imgView2Min, imgView5Min, imgView15Min, imgViewRandom, imgViewCustom)
        if (delayTime!!.contains("C")) {
            setSelection(imgViewCustom, list)
        } else {
            when (delayTime) {
                "00:00:05 Hour" -> setSelection(imgView5Sec, list)
                "00:00:15 Hour" -> setSelection(imgView15Sec, list)
                "00:00:30 Hour" -> setSelection(imgView30Sec, list)
                "00:02:00 Hour" -> setSelection(imgView2Min, list)
                "00:05:00 Hour" -> setSelection(imgView5Min, list)
                "00:15:00 Hour" -> setSelection(imgView15Min, list)
                else -> setSelection(imgViewRandom, list)
            }
        }
        val tempTime: Array<String> = arrayOf("")
        textView5Sec.setOnClickListener(View.OnClickListener { v: View? ->
            setSelection(imgView5Sec, list)
            tempTime[0] = "00:00:05 Hour"
        })
        textView15Sec.setOnClickListener(View.OnClickListener { v: View? ->
            setSelection(imgView15Sec, list)
            tempTime[0] = "00:00:15 Hour"
        })
        textView30Sec.setOnClickListener(View.OnClickListener { v: View? ->
            setSelection(imgView30Sec, list)
            tempTime[0] = "00:00:30 Hour"
        })
        textView2Min.setOnClickListener(View.OnClickListener { v: View? ->
            setSelection(imgView2Min, list)
            tempTime[0] = "00:02:00 Hour"
        })
        textView5Min.setOnClickListener(View.OnClickListener { v: View? ->
            setSelection(imgView5Min, list)
            tempTime[0] = "00:05:00 Hour"
        })
        textView15Min.setOnClickListener(View.OnClickListener { v: View? ->
            setSelection(imgView15Min, list)
            tempTime[0] = "00:15:00 Hour"
        })
        textViewRandom.setOnClickListener(View.OnClickListener { v: View? ->
            setSelection(imgViewRandom, list)
            tempTime[0] = "Random"
        })
        textViewCustom.setOnClickListener(View.OnClickListener { v: View? ->
            dialog.dismiss()
            val onButtonClickListener: TimePickerDialog.OnButtonClickListener =
                object : TimePickerDialog.OnButtonClickListener {
                    public override fun onPositive(
                        bottomSheetDialo: TimePickerDialog?,
                        time: String?
                    ) {
                        setSelection(imgViewCustom, list)
                        delayTime = "$time C"
                        txtDelayTime!!.setText(time)
                        bottomSheetDialo!!.dismiss()
                    }

                    public override fun onNegative(bottomSheetDialog: TimePickerDialog?) {
                        bottomSheetDialog!!.dismiss()
                    }
                }
            val timePickerDialog: TimePickerDialog = TimePickerDialog(onButtonClickListener)
            timePickerDialog.show(supportFragmentManager, "dialog")
        })
        btnNagative.setOnClickListener(View.OnClickListener { v: View? -> dialog.dismiss() })
        btnPositive.setOnClickListener(View.OnClickListener { v: View? ->
            dialog.dismiss()
            if (!(tempTime.get(0) == "")) {
                delayTime = tempTime.get(0)
            }
            val time: String?
            if (delayTime!!.contains("C")) {
                time = delayTime!!.replace("C", "").trim({ it <= ' ' })
            } else {
                time = delayTime
            }
            txtDelayTime!!.setText(time)
        })
        dialog.show()
    }

    fun setSelection(imageView: ImageView, list: Array<Any>) {
        for (o: Any in list) {
            if ((imageView == o)) {
                (o as ImageView).setVisibility(View.VISIBLE)
            } else {
                (o as ImageView).setVisibility(View.GONE)
            }
        }
    }

    private fun onClickApplyWallpaperSettings() {
        if (mSelectedImagesList != null && mSelectedImagesList!!.size > 0) {
            try {
                val cacheDir: String = "/Pictures/.autowallpaper"
                val fullCacheDir: File = File(Environment.getExternalStorageDirectory().toString(), cacheDir)
                deleteRecursive(fullCacheDir)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            if (isEditClicked) {
                isEditClicked = false
                UpdateData().execute()
            } else {
                SaveDataTOStorage().execute()
            }
        }
    }

    fun deleteRecursive(fileOrDirectory: File) {
        if (fileOrDirectory.isDirectory() && fileOrDirectory.listFiles() != null) for (child: File in fileOrDirectory.listFiles()) deleteRecursive(child)
        fileOrDirectory.delete()
    }

    internal inner class AddDataTOStorage constructor() : AsyncTask<Void?, Boolean?, Boolean>() {
        var mAllPathList: ArrayList<String>? = null
        override fun onPreExecute() {
            super.onPreExecute()
            System.gc()
            Runtime.getRuntime().gc()
        }

        override fun onPostExecute(aVoid: Boolean) {
            super.onPostExecute(aVoid)
            if (aVoid) {
                btnNext!!.setEnabled(true)
                if ((progressDialog != null) && progressDialog.isShowing() && !isFinishing()) {
                    progressDialog.dismiss()
                }
                try {
                    val model1: AutoWallpaperModel? = dbHelperAutoWallpaper!!.allAutoWallpaper.get(0)
                    val gson1: Gson = Gson()
                    val token: TypeToken<ArrayList<String?>?> = object : TypeToken<ArrayList<String?>?>() {}
                    if (model1 != null) {
                        val mImages: ArrayList<String> = gson1.fromJson(model1.imagespath, token.getType())
                        mAllPathList!!.addAll(mImages)
                    }
                    val gson: Gson = Gson()
                    val inputString: String = gson.toJson(mAllPathList)
                    val model: AutoWallpaperModel = AutoWallpaperModel()
                    model.screenmode = dbHelperAutoWallpaper!!.allAutoWallpaper.get(0).screenmode
                    model.delaytime = dbHelperAutoWallpaper!!.allAutoWallpaper.get(0).delaytime
                    model.imagespath = inputString
                    model.status = dbHelperAutoWallpaper!!.allAutoWallpaper.get(0).status
                    dbHelperAutoWallpaper!!.insertAutoWallpaper(model)
                    try {
                        setAlarmAuto(model)
                        setResult(Activity.RESULT_OK, Intent())
                        finish()
                    } catch (e: Exception) {
                        e.printStackTrace()
                        finish()
                        //Live Wallpaper not supported
                    }
                } catch (e: Exception) {
                    finish()
                    e.printStackTrace()
                }
            }
        }

        protected override fun doInBackground(vararg params: Void?): Boolean? {
            mAllPathList = ArrayList()
            val cacheDir: String = "/Pictures/.autowallpaper"
            val fullCacheDir: File = File(Environment.getExternalStorageDirectory().toString(), cacheDir)
            if (!fullCacheDir.exists()) {
                fullCacheDir.mkdirs()
            }
            var j: Int = 0
            for (i in mBitmapListUpdate!!.indices) {
                val bitmap: Bitmap = mBitmapListUpdate!!.get(i).bitmap
                val fileLocalName: String = System.currentTimeMillis().toString() + ".PNG"
                val fileUri: File = File(fullCacheDir.toString(), fileLocalName)
                mAllPathList!!.add(fileUri.getAbsolutePath())
                var outStream: FileOutputStream? = null
                try {
                    outStream = FileOutputStream(fileUri)
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, outStream)
                    outStream.flush()
                    outStream.close()
                } catch (e: FileNotFoundException) {
                    e.printStackTrace()
                } catch (e: IOException) {
                    Log.i("CACHE", "Error: File could not be stuffed!")
                    e.printStackTrace()
                }
                if (j >= mBitmapListUpdate!!.size - 1) {
                    return true
                }
                j++
            }
            return false
        }
    }

    internal inner class SaveDataTOStorage constructor() : AsyncTask<Void?, Void?, Void?>() {
        var mAllPathList: ArrayList<String>? = null
        var progressDialog: ProgressDialog? = null
        override fun onPreExecute() {
            super.onPreExecute()
            System.gc()
            Runtime.getRuntime().gc()
            try {
                progressDialog = ProgressDialog(this@AutoWallpaperChangerTestActivity)
                progressDialog!!.setMessage(getResources().getString(R.string.dialog_msg_please_wait))
                progressDialog!!.setCancelable(false)
                progressDialog!!.show()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        override fun onPostExecute(aVoid: Void?) {
            super.onPostExecute(aVoid)
            val gson: Gson = Gson()
            val inputString: String = gson.toJson(mAllPathList)
            val model: AutoWallpaperModel = AutoWallpaperModel()
            model.screenmode = screenMode
            model.delaytime = delayTime
            model.imagespath = inputString
            model.status = 1
            dbHelperAutoWallpaper!!.insertAutoWallpaper(model)
            if (progressDialog != null && progressDialog!!.isShowing()) {
                progressDialog!!.dismiss()
            }
            try {
                /*  Intent intent = new Intent(
                        WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
                intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                        new ComponentName(AutoWallpaperChangerTestActivity.this, LiveWallpaper.class));
                startActivity(intent);*/
                setAlarmAuto(model)
                //isApplyClicked = true;
                isApplyClicked = false
                isSettingsOpen = false
                isEditSettingsOpen = false
                dataWallpaper

                //removed from here
                if (isEditClicked) {
                    isEditClicked = false
                    /* if (!AdsPrefs.getBoolean(AutoWallpaperChangerTestActivity.this, AdsPrefs.IS_SUBSCRIBED, false)) {
                        btnNext.animate().alpha(0f).withEndAction(new Runnable() {
                            @Override
                            public void run() {
                                Log.d(TAG, "run: ");
                                btnNext.setVisibility(View.INVISIBLE);
                            }
                        }).setDuration(300).start();
                        icSubcription.setVisibility(View.VISIBLE);
                        icSubcription.animate().alpha(1f).setDuration(300).start();
                    } else {*/btnNext!!.animate().alpha(0f).withEndAction(object : Runnable {
                        public override fun run() {
                            btnNext!!.setVisibility(View.INVISIBLE)
                        }
                    }).setDuration(300).start()
                    icAdd!!.setVisibility(View.VISIBLE)
                    icAdd!!.animate().alpha(1f).setDuration(300).start()
                    //  }
                }

                //  layoutMainWallpaperList.animate().translationYBy(layoutMainWallpaperList.getHeight()).setDuration(300).start();
                //  cstMainSettings.animate().translationYBy(cstMainSettings.getHeight()).setDuration(300).start();
                //  cstMainSettings.setVisibility(View.GONE);
                setResult(Activity.RESULT_OK, Intent())
                finish()
            } catch (e: Exception) {
                e.printStackTrace()
                //Live Wallpaper not supported
            }
        }

        protected override fun doInBackground(vararg params: Void?): Void? {
            mAllPathList = ArrayList()
            val cacheDir: String = "/Pictures/.autowallpaper"
            val fullCacheDir: File = File(Environment.getExternalStorageDirectory().toString(), cacheDir)
            if (!fullCacheDir.exists()) {
                fullCacheDir.mkdirs()
            }
            for (i in mSelectedImagesList!!.indices) {
                val bitmap: Bitmap = mSelectedImagesList!!.get(i).bitmap
                val fileLocalName: String = System.currentTimeMillis().toString() + ".PNG"
                val fileUri: File = File(fullCacheDir.toString(), fileLocalName)
                mAllPathList!!.add(fileUri.getAbsolutePath())
                var outStream: FileOutputStream? = null
                try {
                    outStream = FileOutputStream(fileUri)
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, outStream)
                    outStream.flush()
                    outStream.close()
                } catch (e: FileNotFoundException) {
                    e.printStackTrace()
                } catch (e: IOException) {
                    Log.i("CACHE", "Error: File could not be stuffed!")
                    e.printStackTrace()
                }
            }
            return null
        }
    }

    internal inner class UpdateData constructor() : AsyncTask<Void?, Void?, Void?>() {
        var mAllPathList: ArrayList<String>? = null
        var progressDialog: ProgressDialog? = null
        override fun onPreExecute() {
            super.onPreExecute()
            System.gc()
            Runtime.getRuntime().gc()
            try {
                progressDialog = ProgressDialog(this@AutoWallpaperChangerTestActivity)
                progressDialog!!.setMessage(getResources().getString(R.string.dialog_msg_please_wait))
                progressDialog!!.setCancelable(false)
                progressDialog!!.show()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        override fun onPostExecute(aVoid: Void?) {
            super.onPostExecute(aVoid)
            val gson: Gson = Gson()
            val inputString: String = gson.toJson(mAllPathList)
            val model: AutoWallpaperModel = AutoWallpaperModel()
            model.id = autoWallpaperModelEdit!!.id
            model.screenmode = screenMode
            model.delaytime = delayTime
            model.imagespath = inputString
            model.status = 1
            dbHelperAutoWallpaper!!.updateDataToDB(model)
            if (progressDialog != null && progressDialog!!.isShowing()) {
                progressDialog!!.dismiss()
            }
            isApplyClicked = false
            isSettingsOpen = false
            isEditSettingsOpen = false
            icAdd!!.setEnabled(true)
            btnApplyWallpaperSettings!!.setEnabled(true)
            setResult(Activity.RESULT_OK, Intent())
            finish()
        }

        protected override fun doInBackground(vararg params: Void?): Void? {
            mAllPathList = ArrayList()
            val cacheDir: String = "/Pictures/.autowallpaper"
            val fullCacheDir: File = File(Environment.getExternalStorageDirectory().toString(), cacheDir)
            if (!fullCacheDir.exists()) {
                fullCacheDir.mkdirs()
            }
            for (i in mSelectedImagesList!!.indices) {
                val bitmap: Bitmap = mSelectedImagesList!!.get(i).bitmap
                val fileLocalName: String = System.currentTimeMillis().toString() + ".PNG"
                val fileUri: File = File(fullCacheDir.toString(), fileLocalName)
                mAllPathList!!.add(fileUri.getAbsolutePath())
                var outStream: FileOutputStream? = null
                try {
                    outStream = FileOutputStream(fileUri)
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, outStream)
                    outStream.flush()
                    outStream.close()
                } catch (e: FileNotFoundException) {
                    e.printStackTrace()
                } catch (e: IOException) {
                    Log.i("CACHE", "Error: File could not be stuffed!")
                    e.printStackTrace()
                }
            }
            return null
        }
    }

    private fun setAlarmAuto(model: AutoWallpaperModel) {
        val calendar: Calendar = Calendar.getInstance()
        val id: Int = 0
        if (mySharedPref!!.alarmId != -1) {
            cancelAlarm(("2121" + mySharedPref!!.alarmId).toInt(), this@AutoWallpaperChangerTestActivity, EventReceiver::class.java)
        }
        val myIntent: Intent = Intent(this@AutoWallpaperChangerTestActivity, EventReceiver::class.java)
        val pendingIntent: PendingIntent = PendingIntent.getBroadcast(this@AutoWallpaperChangerTestActivity, ("2121" + id).toInt(), myIntent, 0)
        val alarmManager: AlarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        mySharedPref!!.alarmId = 0
        var timeInterval: Int = 0
        var interval: String? = model.delaytime
        if ((interval == "Random")) {
            timeInterval = 60 * 1000
        } else {
            if (interval!!.contains("C")) {
                interval = interval.replace("C", "")
                interval = interval.trim({ it <= ' ' })
            }
            val time1: Array<String> = interval.split(" ".toRegex()).toTypedArray()
            if (time1.size == 0) {
                return
            }
            val mTime: String = time1.get(0)
            val intve: Array<String> = mTime.split(":".toRegex()).toTypedArray()
            if (intve.size == 0) {
                return
            }
            val hr: Int = intve.get(0).toInt() * 60 * 60 * 1000
            val mn: Int = intve.get(1).toInt() * 60 * 1000
            val sec: Int = intve.get(2).toInt() * 1000
            timeInterval = hr + mn + sec
        }
        /*    switch (model.getDelaytime()) {
            case "5 Sec":
                timeInterval = 5 * 1000;
                break;
            case "15 Sec":
                timeInterval = 15 * 1000;
                break;
            case "30 Sec":
                timeInterval = 30 * 1000;
                break;
            case "2 Min":
                timeInterval = 2 * 60 * 1000;
                break;
            case "5 Min":
                timeInterval = 5 * 60 * 1000;
                break;
            case "15 Min":
                timeInterval = 15 * 60 * 1000;
                break;
            default:
                timeInterval = 60 * 1000;
                break;
        }
*/if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    calendar.getTimeInMillis(),
                    pendingIntent
            )
        } else {
            alarmManager.set(
                    AlarmManager.RTC_WAKEUP,
                    calendar.getTimeInMillis(),
                    pendingIntent
            )
        }

        /*   if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M) {
            alarmManager.setRepeating(
                    AlarmManager.RTC_WAKEUP,
                    calendar.getTimeInMillis(),
                    timeInterval,
                    pendingIntent
            );
            new MySharedPref(AutoWallpaperChangerTestActivity.this).setAlarm(id, true);
            //  Constants.isSetEvent = true
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        calendar.getTimeInMillis() + timeInterval,
                        pendingIntent
                );
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                alarmManager.setExact(
                        AlarmManager.RTC_WAKEUP,
                        calendar.getTimeInMillis() + timeInterval,
                        pendingIntent
                );
            } else {
                alarmManager.set(
                        AlarmManager.RTC_WAKEUP,
                        calendar.getTimeInMillis() + timeInterval,
                        pendingIntent
                );
            }
        }*/
    }

    private fun onClickAddWallpaperSettings() {
        if (isEditBottomClicked) {
            settingsRecyclerAdapter!!.setDataChanged()
            isLongClicked = false
            isEditBottomClicked = false
            bottomButtonLayoutSettings!!.animate().translationYBy(-bottomButtonLayoutSettings!!.getHeight().toFloat()).setDuration(300).start()
            bottomButtonEditSettings!!.animate().translationYBy(bottomButtonLayoutSettings!!.getHeight().toFloat()).setDuration(300).start()
            isEditBottomClicked = false
        }
        isAddMenuOpen = true
        mBitmapList!!.clear()
        progressRecycler!!.setVisibility(View.GONE)
        solidSelectableFragment = SolidSelectableFragment()
        gradientSelectableFragment = GradientSelectableFragment()
        textSelectableFragment = TextSelectableFragment()
        creationSelectableFragment = CreationSelectableFragment()
        gallerySelectableFragment = GallerySelectableFragment()
        val transaction: FragmentTransaction = getSupportFragmentManager().beginTransaction()
        try {
            transaction.remove((Objects.requireNonNull(getSupportFragmentManager().findFragmentById(R.id.frameSolid)))!!)
            transaction.remove((Objects.requireNonNull(getSupportFragmentManager().findFragmentById(R.id.frameCreation)))!!)
            transaction.remove((Objects.requireNonNull(getSupportFragmentManager().findFragmentById(R.id.frameGallery)))!!)
            transaction.remove((Objects.requireNonNull(getSupportFragmentManager().findFragmentById(R.id.frameText)))!!)
            transaction.remove((Objects.requireNonNull(getSupportFragmentManager().findFragmentById(R.id.frameGradient)))!!)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        transaction.replace(R.id.frameSolid, solidSelectableFragment!!)
        transaction.replace(R.id.frameCreation, creationSelectableFragment!!)
        transaction.replace(R.id.frameGradient, gradientSelectableFragment!!)
        transaction.replace(R.id.frameText, textSelectableFragment!!)
        transaction.replace(R.id.frameGallery, gallerySelectableFragment!!)
        transaction.commitAllowingStateLoss()
        layoutSelectWallpaper!!.setVisibility(View.VISIBLE)
        layoutSelectWallpaper!!.setTranslationY(layoutSelectWallpaper!!.getHeight().toFloat())
        progressFragment!!.setVisibility(View.GONE)
        layoutTopSetting!!.animate().translationYBy(-layoutTopSetting!!.getHeight().toFloat()).setDuration(300).start()
        recyclerSelectedWallpaper!!.animate().alpha(0f).withEndAction(object : Runnable {
            public override fun run() {
                recyclerSelectedWallpaper!!.setVisibility(View.GONE)
                recyclerSelectedWallpaper!!.setAlpha(1f)
                isAnimRunning = false
            }
        }).setDuration(200).start()
        bottomButtonLayoutSettings!!.animate().translationYBy(bottomButtonLayoutSettings!!.getHeight().toFloat()).withEndAction(object : Runnable {
            public override fun run() {
                layoutSelectWallpaper!!.animate().translationYBy(-layoutSelectWallpaper!!.getHeight().toFloat()).withEndAction(object : Runnable {
                    public override fun run() {
                        if (!getBoolean(this@AutoWallpaperChangerTestActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                            icAdd!!.animate().alpha(0f).withEndAction(object : Runnable {
                                public override fun run() {
                                    icAdd!!.setVisibility(View.INVISIBLE)
                                    isAnimRunning = false
                                }
                            }).setDuration(300).start()
                            btnNext!!.setAlpha(0f)
                            btnNext!!.setVisibility(View.VISIBLE)
                            btnNext!!.animate().alpha(1f).setDuration(300).start()
                        } else {
                            btnShare!!.animate().alpha(0f).withEndAction(object : Runnable {
                                public override fun run() {
                                    btnShare!!.setVisibility(View.INVISIBLE)
                                    isAnimRunning = false
                                }
                            }).setDuration(300).start()
                            btnNext!!.setAlpha(0f)
                            btnNext!!.setVisibility(View.VISIBLE)
                            btnNext!!.animate().alpha(1f).setDuration(300).start()
                        }
                    }
                }).setDuration(200).start()
            }
        }).setDuration(300).start()
    }

    private fun onClickCreationDropDown() {
        txtSolidDD!!.setAlpha(0.5f)
        imgSolidDD!!.setVisibility(View.GONE)
        txtCreationDD!!.setAlpha(1f)
        imgCreationDD!!.setVisibility(View.VISIBLE)

        /*  Animation anim = new AlphaAnimation(0.0f, 1.0f);
        anim.setDuration(1000);
        anim.setStartOffset(20);
        anim.setRepeatMode(Animation.REVERSE);
        anim.setRepeatCount(Animation.INFINITE);
        imgCreationDD.startAnimation(anim);
        imgSolidDD.startAnimation(new AlphaAnimation(0f, 0f));*/if (positionCreation == 0) {
            frameSolid!!.setVisibility(View.GONE)
            frameCreation!!.setVisibility(View.VISIBLE)
            frameGallery!!.setVisibility(View.GONE)
            frameGradient!!.setVisibility(View.GONE)
            frameText!!.setVisibility(View.GONE)
        } else if (positionCreation == 1) {
            frameSolid!!.setVisibility(View.GONE)
            frameCreation!!.setVisibility(View.GONE)
            frameGallery!!.setVisibility(View.VISIBLE)
            frameGradient!!.setVisibility(View.GONE)
            frameText!!.setVisibility(View.GONE)
        }
        isFirstS1 = false
        if (isFirstC1) {
            spinnerCreationDD!!.performClick()
        } else {
            isFirstC1 = true
        }
    }

    private fun onClickSolidDropDown() {
        txtCreationDD!!.setAlpha(0.5f)
        imgCreationDD!!.setVisibility(View.GONE)
        txtSolidDD!!.setAlpha(1f)
        imgSolidDD!!.setVisibility(View.VISIBLE)

        /* Animation anim = new AlphaAnimation(0.0f, 1.0f);
        anim.setDuration(1000);
        anim.setStartOffset(20);
        anim.setRepeatMode(Animation.REVERSE);
        anim.setRepeatCount(Animation.INFINITE);
        imgSolidDD.startAnimation(anim);
        imgCreationDD.startAnimation(new AlphaAnimation(0f, 0f));*/if (positionSolid == 0) {
            frameSolid!!.setVisibility(View.VISIBLE)
            frameCreation!!.setVisibility(View.GONE)
            frameGallery!!.setVisibility(View.GONE)
            frameGradient!!.setVisibility(View.GONE)
            frameText!!.setVisibility(View.GONE)
        } else if (positionSolid == 1) {
            frameSolid!!.setVisibility(View.GONE)
            frameCreation!!.setVisibility(View.GONE)
            frameGallery!!.setVisibility(View.GONE)
            frameGradient!!.setVisibility(View.VISIBLE)
            frameText!!.setVisibility(View.GONE)
        } else if (positionSolid == 2) {
            frameSolid!!.setVisibility(View.GONE)
            frameCreation!!.setVisibility(View.GONE)
            frameGallery!!.setVisibility(View.GONE)
            frameGradient!!.setVisibility(View.GONE)
            frameText!!.setVisibility(View.VISIBLE)
        }
        isFirstC1 = false
        if (isFirstS1) {
            spinnerSolidDD!!.performClick()
        } else {
            isFirstS1 = true
        }
    }

    private fun onclickDone() {

        /* if (Constants.isAddWallpaperClicked) {
            mSelectedList = new ArrayList<>();

            if (solidSelectableFragment != null) {
                mSelectedList.addAll(solidSelectableFragment.getDataList());
            }
            if (gradientSelectableFragment != null) {
                mSelectedList.addAll(gradientSelectableFragment.getDataList());
            }
            if (textSelectableFragment != null) {
                mSelectedList.addAll(textSelectableFragment.getDataList());
            }
            if (creationSelectableFragment != null) {
                mSelectedList.addAll(creationSelectableFragment.getDataList());
            }
            if (gallerySelectableFragment != null) {
                mSelectedList.addAll(gallerySelectableFragment.getDataList());
            }

            if (mSelectedList.size() <= 0) {
                Toast.makeText(this, getResources().getString(R.string.please_select_atleast_one_image), Toast.LENGTH_SHORT).show();
                btnNext.setEnabled(true);
            } else {
                Constants.isAddWallpaperClicked = false;
                try {
                    progressDialog = new ProgressDialog(AutoWallpaperChangerTestActivity.this);
                    progressDialog.setMessage(getResources().getString(R.string.dialog_msg_please_wait));
                    progressDialog.setCancelable(false);
                    progressDialog.show();
                } catch (Exception e) {
                    e.printStackTrace();
                }

                try {
                    glideLoadImageCount = 0;
                    for (Object object :
                            mSelectedList) {
                        if (object instanceof TextSelectableModel || object instanceof SavedImageModel) {
                            glideLoadImageCount++;
                        }
                    }
                    new LoadImagesNew().execute();
                } catch (Exception e) {
                    btnNext.setEnabled(true);
                    e.printStackTrace();
                }
            }
            return;
        }*/
        Handler().postDelayed(object : Runnable {
            public override fun run() {
                btnNext!!.setEnabled(true)
            }
        }, 2000)
        if (isEditOpen) {
            val mTempList: ArrayList<Any> = ArrayList()
            if (solidSingleSelectableFragment != null) {
                mTempList.addAll(solidSingleSelectableFragment!!.dataList)
            }
            if (gradientSingleSelectableFragment != null) {
                mTempList.addAll(gradientSingleSelectableFragment!!.dataList)
            }
            if (textSingleSelectableFragment != null) {
                mTempList.addAll(textSingleSelectableFragment!!.dataList)
            }
            if (creationSingleSelectableFragment != null) {
                mTempList.addAll(creationSingleSelectableFragment!!.dataList)
            }
            if (gallerySingleSelectableFragment != null) {
                mTempList.addAll(gallerySingleSelectableFragment!!.dataList)
            }
            if (mTempList.size <= 0) {
                Toast.makeText(this, getResources().getString(R.string.please_select_atleast_one_image), Toast.LENGTH_SHORT).show()
            } else {
                isEditOpen = false
                isSettingsOpen = true
                if (settingsImagesModelEdit != null) {
                    val metrics: DisplayMetrics = DisplayMetrics()
                    getWindowManager().getDefaultDisplay().getMetrics(metrics)
                    val `object`: Any = mTempList.get(0)
                    if (`object` is SolidSelectableModel) {
                        val shape: GradientDrawable = GradientDrawable()
                        shape.setShape(GradientDrawable.RECTANGLE)
                        shape.setColors(intArrayOf(`object`.solidColorModel.color, `object`.solidColorModel.color))
                        settingsImagesModelEdit!!.bitmap = (convertToBitmap(shape, metrics.widthPixels, metrics.heightPixels))!!
                        settingsRecyclerAdapter!!.setDataChanged()
                    } else if (`object` is GradientSelectableModel) {
                        if (`object`.colorModel.circle) {
                            val shape: GradientDrawable = GradientDrawable()
                            shape.setShape(GradientDrawable.RECTANGLE)
                            shape.setColors(intArrayOf(`object`.colorModel.color1, `object`.colorModel.color2))
                            shape.setGradientType(GradientDrawable.RADIAL_GRADIENT)
                            shape.setGradientRadius(metrics.widthPixels.toFloat())
                            settingsImagesModelEdit!!.bitmap = (convertToBitmap(shape, metrics.widthPixels, metrics.heightPixels))!!
                            settingsRecyclerAdapter!!.setDataChanged()
                        } else {
                            val shape: GradientDrawable = GradientDrawable(`object`.colorModel.orientation, intArrayOf(`object`.colorModel.color1, `object`.colorModel.color2))
                            shape.setShape(GradientDrawable.RECTANGLE)
                            settingsImagesModelEdit!!.bitmap = (convertToBitmap(shape, metrics.widthPixels, metrics.heightPixels))!!
                            settingsRecyclerAdapter!!.setDataChanged()
                        }
                    } else if (`object` is TextSelectableModel) {
                        Glide.with(this@AutoWallpaperChangerTestActivity).asBitmap().load(`object`.imgePath).into(object : CustomTarget<Bitmap?>() {
                            public override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap?>?) {
                                settingsImagesModelEdit!!.bitmap = resource
                                settingsRecyclerAdapter!!.setDataChanged()
                            }

                            public override fun onLoadCleared(placeholder: Drawable?) {}
                        })
                    } else if (`object` is SavedImageModel) {
                        Glide.with(this@AutoWallpaperChangerTestActivity).asBitmap().load(`object`.path).into(object : CustomTarget<Bitmap?>() {
                            public override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap?>?) {
                                settingsImagesModelEdit!!.bitmap = resource
                                settingsRecyclerAdapter!!.setDataChanged()
                            }

                            public override fun onLoadCleared(placeholder: Drawable?) {}
                        })
                    }
                    cstMainSettings!!.setVisibility(View.VISIBLE)
                    progressRecycler!!.setVisibility(View.VISIBLE)
                    layoutTopSetting!!.setVisibility(View.INVISIBLE)
                    bottomButtonLayoutSettings!!.setVisibility(View.INVISIBLE)
                    layoutTopSetting!!.post(object : Runnable {
                        public override fun run() {
                            layoutTopSetting!!.setTranslationY(-layoutTopSetting!!.getHeight().toFloat())
                            layoutTopSetting!!.setVisibility(View.VISIBLE)
                            Handler().postDelayed(object : Runnable {
                                public override fun run() {
                                    layoutTopSetting!!.animate().translationYBy(layoutTopSetting!!.getHeight().toFloat()).setDuration(300).start()
                                }
                            }, 100)
                            layoutSelectWallpaper!!.animate().translationYBy(layoutSelectWallpaper!!.getHeight().toFloat()).withEndAction(object : Runnable {
                                public override fun run() {
                                    progressRecycler!!.setVisibility(View.GONE)
                                    if (!isAddMenuOpen) {
                                        recyclerSelectedWallpaper!!.setVisibility(View.VISIBLE)
                                    }
                                    bottomButtonLayoutSettings!!.setVisibility(View.VISIBLE)
                                    bottomButtonLayoutSettings!!.setTranslationY(bottomButtonLayoutSettings!!.getHeight().toFloat())
                                    bottomButtonLayoutSettings!!.post(object : Runnable {
                                        public override fun run() {
                                            bottomButtonLayoutSettings!!.animate().withEndAction(object : Runnable {
                                                public override fun run() {
                                                    icAdd!!.setEnabled(true)
                                                    btnApplyWallpaperSettings!!.setEnabled(true)
                                                }
                                            }).translationYBy(-bottomButtonLayoutSettings!!.getHeight().toFloat()).setDuration(300).start()
                                        }
                                    })
                                }
                            }).setDuration(300).start()
                            /*
                            if (!AdsPrefs.getBoolean(AutoWallpaperChangerTestActivity.this, AdsPrefs.IS_SUBSCRIBED, false)) {
                                btnNext.animate().alpha(0f).withEndAction(new Runnable() {
                                    @Override
                                    public void run() {
                                        Log.d(TAG, "run: ");
                                        btnNext.setVisibility(View.INVISIBLE);
                                    }
                                }).setDuration(300).start();
                                icSubcription.setVisibility(View.VISIBLE);
                                icSubcription.animate().alpha(1f).setDuration(300).start();
                            } else {*/btnNext!!.animate().alpha(0f).withEndAction(object : Runnable {
                                public override fun run() {
                                    btnNext!!.setVisibility(View.INVISIBLE)
                                }
                            }).setDuration(300).start()
                            icAdd!!.setVisibility(View.VISIBLE)
                            icAdd!!.animate().alpha(1f).setDuration(300).start()
                            //   }
                        }
                    })
                }
            }
        } else if (isAddMenuOpen) {
            mSelectedList = ArrayList()
            if (solidSelectableFragment != null) {
                mSelectedList!!.addAll(solidSelectableFragment!!.dataList)
            }
            if (gradientSelectableFragment != null) {
                mSelectedList!!.addAll(gradientSelectableFragment!!.dataList)
            }
            if (textSelectableFragment != null) {
                mSelectedList!!.addAll(textSelectableFragment!!.dataList)
            }
            if (creationSelectableFragment != null) {
                mSelectedList!!.addAll(creationSelectableFragment!!.dataList)
            }
            if (gallerySelectableFragment != null) {
                mSelectedList!!.addAll(gallerySelectableFragment!!.dataList)
            }
            if (mSelectedList!!.size <= 0) {
                Toast.makeText(this, getResources().getString(R.string.please_select_atleast_one_image), Toast.LENGTH_SHORT).show()
            } else {
                try {
                    glideLoadImageCount = 0
                    for (`object`: Any in mSelectedList!!) {
                        if (`object` is TextSelectableModel || `object` is SavedImageModel) {
                            glideLoadImageCount++
                        }
                    }
                    recyclerSelectedWallpaper!!.setVisibility(View.GONE)
                    LoadSelectedImages().execute()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                isSettingsOpen = true
                isAddMenuOpen = false
                cstMainSettings!!.setVisibility(View.VISIBLE)
                layoutTopSetting!!.setVisibility(View.INVISIBLE)
                recyclerSelectedWallpaper!!.setVisibility(View.GONE)
                bottomButtonLayoutSettings!!.setVisibility(View.INVISIBLE)
                layoutTopSetting!!.post(object : Runnable {
                    public override fun run() {
                        Log.d(TAG, "onclickDone: " + cstMainSettings!!.getHeight())
                        layoutTopSetting!!.setTranslationY(-layoutTopSetting!!.getHeight().toFloat())
                        layoutTopSetting!!.setVisibility(View.VISIBLE)
                        Handler().postDelayed(object : Runnable {
                            public override fun run() {
                                layoutTopSetting!!.animate().translationYBy(layoutTopSetting!!.getHeight().toFloat()).setDuration(300).start()
                            }
                        }, 100)
                        layoutSelectWallpaper!!.animate().translationYBy(layoutSelectWallpaper!!.getHeight().toFloat()).withEndAction(object : Runnable {
                            public override fun run() {
                                bottomButtonLayoutSettings!!.setVisibility(View.VISIBLE)
                                if (!isAddMenuOpen) {
                                    recyclerSelectedWallpaper!!.setVisibility(View.VISIBLE)
                                }
                                bottomButtonLayoutSettings!!.setTranslationY(bottomButtonLayoutSettings!!.getHeight().toFloat())
                                bottomButtonLayoutSettings!!.post(object : Runnable {
                                    public override fun run() {
                                        bottomButtonLayoutSettings!!.animate().withEndAction(object : Runnable {
                                            public override fun run() {
                                                icAdd!!.setEnabled(true)
                                                btnApplyWallpaperSettings!!.setEnabled(true)
                                            }
                                        }).translationYBy(-bottomButtonLayoutSettings!!.getHeight().toFloat()).setDuration(300).start()
                                    }
                                })
                            }
                        }).setDuration(300).start()
                        if (!isEditClicked) {
                            /* if (!AdsPrefs.getBoolean(AutoWallpaperChangerTestActivity.this, AdsPrefs.IS_SUBSCRIBED, false)) {
                                btnNext.animate().alpha(0f).withEndAction(new Runnable() {
                                    @Override
                                    public void run() {
                                        Log.d(TAG, "run: ");
                                        btnNext.setVisibility(View.INVISIBLE);
                                    }
                                }).setDuration(300).start();
                                icSubcription.setVisibility(View.VISIBLE);
                                icSubcription.animate().alpha(1f).setDuration(300).start();
                            } else {*/
                            btnNext!!.animate().alpha(0f).withEndAction(object : Runnable {
                                public override fun run() {
                                    btnNext!!.setVisibility(View.INVISIBLE)
                                }
                            }).setDuration(300).start()
                            icAdd!!.setVisibility(View.VISIBLE)
                            icAdd!!.animate().alpha(1f).setDuration(300).start()
                            //  }
                        }
                    }
                })
            }
        } else if (isEditClicked) {
            Log.d(TAG, "onclickDone: ")
            isEditClicked = false
            UpdateData().execute()
            /*if (isEditOpen) {
                onBackPressed();
            }*/
        } else {
            mSelectedList = ArrayList()
            if (solidSelectableFragment != null) {
                mSelectedList!!.addAll(solidSelectableFragment!!.dataList)
            }
            if (gradientSelectableFragment != null) {
                mSelectedList!!.addAll(gradientSelectableFragment!!.dataList)
            }
            if (textSelectableFragment != null) {
                mSelectedList!!.addAll(textSelectableFragment!!.dataList)
            }
            if (creationSelectableFragment != null) {
                mSelectedList!!.addAll(creationSelectableFragment!!.dataList)
            }
            if (gallerySelectableFragment != null) {
                mSelectedList!!.addAll(gallerySelectableFragment!!.dataList)
            }
            if (mSelectedList!!.size <= 0) {
                Toast.makeText(this, getResources().getString(R.string.please_select_atleast_one_image), Toast.LENGTH_SHORT).show()
            } else {
                try {
                    glideLoadImageCount = 0
                    for (`object`: Any in mSelectedList!!) {
                        if (`object` is TextSelectableModel || `object` is SavedImageModel) {
                            glideLoadImageCount++
                        }
                    }
                    recyclerSelectedWallpaper!!.setVisibility(View.GONE)
                    LoadSelectedImages().execute()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                isSettingsOpen = true
                isAddMenuOpen = false
                cstMainSettings!!.setVisibility(View.VISIBLE)
                layoutTopSetting!!.setVisibility(View.INVISIBLE)
                recyclerSelectedWallpaper!!.setVisibility(View.GONE)
                bottomButtonLayoutSettings!!.setVisibility(View.INVISIBLE)
                layoutTopSetting!!.post(object : Runnable {
                    public override fun run() {
                        Log.d(TAG, "onclickDone: " + cstMainSettings!!.getHeight())
                        layoutTopSetting!!.setTranslationY(-layoutTopSetting!!.getHeight().toFloat())
                        layoutTopSetting!!.setVisibility(View.VISIBLE)
                        Handler().postDelayed(object : Runnable {
                            public override fun run() {
                                layoutTopSetting!!.animate().translationYBy(layoutTopSetting!!.getHeight().toFloat()).setDuration(300).start()
                            }
                        }, 100)
                        layoutSelectWallpaper!!.animate().translationYBy(layoutSelectWallpaper!!.getHeight().toFloat()).withEndAction(object : Runnable {
                            public override fun run() {
                                bottomButtonLayoutSettings!!.setVisibility(View.VISIBLE)
                                if (!isAddMenuOpen) {
                                    recyclerSelectedWallpaper!!.setVisibility(View.VISIBLE)
                                }
                                bottomButtonLayoutSettings!!.setTranslationY(bottomButtonLayoutSettings!!.getHeight().toFloat())
                                bottomButtonLayoutSettings!!.post(object : Runnable {
                                    public override fun run() {
                                        bottomButtonLayoutSettings!!.animate().withEndAction(object : Runnable {
                                            public override fun run() {
                                                icAdd!!.setEnabled(true)
                                                btnApplyWallpaperSettings!!.setEnabled(true)
                                            }
                                        }).translationYBy(-bottomButtonLayoutSettings!!.getHeight().toFloat()).setDuration(300).start()
                                    }
                                })
                            }
                        }).setDuration(300).start()
                        if (!isEditClicked) {
                            /*  if (!AdsPrefs.getBoolean(AutoWallpaperChangerTestActivity.this, AdsPrefs.IS_SUBSCRIBED, false)) {
                                btnNext.animate().alpha(0f).withEndAction(new Runnable() {
                                    @Override
                                    public void run() {
                                        Log.d(TAG, "run: ");
                                        btnNext.setVisibility(View.INVISIBLE);
                                    }
                                }).setDuration(300).start();
                                icSubcription.setVisibility(View.VISIBLE);
                                icSubcription.animate().alpha(1f).setDuration(300).start();
                            } else {*/
                            btnNext!!.animate().alpha(0f).withEndAction(object : Runnable {
                                public override fun run() {
                                    btnNext!!.setVisibility(View.INVISIBLE)
                                }
                            }).setDuration(300).start()
                            icAdd!!.setVisibility(View.VISIBLE)
                            icAdd!!.animate().alpha(1f).setDuration(300).start()
                            //  }
                        }
                    }
                })
            }
        }
    }

    internal inner class LoadImagesNew constructor() : AsyncTask<Void?, Boolean?, Boolean?>() {
        var count: Int = 0
        var isTextOrGallery: Boolean = false
        override fun onPreExecute() {
            super.onPreExecute()
            System.gc()
            Runtime.getRuntime().gc()
        }

        override fun onPostExecute(isTrue: Boolean?) {
            super.onPostExecute(isTrue)
            try {
                runOnUiThread(object : Runnable {
                    public override fun run() {
                        AddDataTOStorage().execute()
                    }
                })
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        protected override fun doInBackground(vararg params: Void?): Boolean? {
            val metrics: DisplayMetrics = DisplayMetrics()
            getWindowManager().getDefaultDisplay().getMetrics(metrics)
            mBitmapListUpdate = ArrayList()
            for (`object`: Any? in mSelectedList!!) {
                if (`object` is SolidSelectableModel) {
                    val shape: GradientDrawable = GradientDrawable()
                    shape.setShape(GradientDrawable.RECTANGLE)
                    shape.setColors(intArrayOf(`object`.solidColorModel.color, `object`.solidColorModel.color))
                    mBitmapListUpdate!!.add(SettingsImagesModel((convertToBitmap(shape, metrics.widthPixels, metrics.heightPixels))!!, false))
                } else if (`object` is GradientSelectableModel) {
                    if (`object`.colorModel.circle) {
                        val shape: GradientDrawable = GradientDrawable()
                        shape.setShape(GradientDrawable.RECTANGLE)
                        shape.setColors(intArrayOf(`object`.colorModel.color1, `object`.colorModel.color2))
                        shape.setGradientType(GradientDrawable.RADIAL_GRADIENT)
                        shape.setGradientRadius(metrics.widthPixels.toFloat())
                        mBitmapListUpdate!!.add(SettingsImagesModel((convertToBitmap(shape, metrics.widthPixels, metrics.heightPixels))!!, false))
                    } else {
                        val shape: GradientDrawable = GradientDrawable(`object`.colorModel.orientation, intArrayOf(`object`.colorModel.color1, `object`.colorModel.color2))
                        shape.setShape(GradientDrawable.RECTANGLE)
                        mBitmapListUpdate!!.add(SettingsImagesModel((convertToBitmap(shape, metrics.widthPixels, metrics.heightPixels))!!, false))
                    }
                } else if (`object` is TextSelectableModel) {
                    isTextOrGallery = true
                    Glide.with(this@AutoWallpaperChangerTestActivity).asBitmap().override(1000).load(`object`.imgePath).into(object : CustomTarget<Bitmap?>() {
                        public override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap?>?) {
                            Log.d("1278912789", "onResourceReady: 1 " + count + " = " + glideLoadImageCount)
                            mBitmapListUpdate!!.add(SettingsImagesModel(resource, false))
                            count++
                            if (count == glideLoadImageCount) {
                                onPostExecute(true)
                                count++
                            }
                        }

                        public override fun onLoadCleared(placeholder: Drawable?) {}
                    })
                } else if (`object` is SavedImageModel) {
                    isTextOrGallery = true
                    Glide.with(this@AutoWallpaperChangerTestActivity).asBitmap().override(1000).load(`object`.path).into(object : CustomTarget<Bitmap?>() {
                        public override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap?>?) {
                            Log.d("1278912789", "onResourceReady: 2 " + count + " = " + glideLoadImageCount)
                            mBitmapListUpdate!!.add(SettingsImagesModel(resource, false))
                            count++
                            if (count == glideLoadImageCount) {
                                onPostExecute(true)
                                count++
                            }
                        }

                        public override fun onLoadCleared(placeholder: Drawable?) {}
                    })
                }
            }
            return false
        }
    }

    internal inner class LoadSelectedImages constructor() : AsyncTask<Void?, Boolean?, Boolean>() {
        var mBitmapList: ArrayList<SettingsImagesModel>? = null
        var count: Int = 0
        var isTextOrGallery: Boolean = false
        override fun onPreExecute() {
            super.onPreExecute()
            System.gc()
            Runtime.getRuntime().gc()
        }

        override fun onPostExecute(isTrue: Boolean) {
            super.onPostExecute(isTrue)
            try {
                runOnUiThread(object : Runnable {
                    public override fun run() {
                        Log.d("1278912789", "onPostExecute: " + isTrue + "  " + isTextOrGallery)
                        if (isTrue && isTextOrGallery) {
                            progressRecycler!!.setVisibility(View.GONE)
                            setDataToAdapter(mBitmapList)
                        }
                        if (!isTextOrGallery) {
                            progressRecycler!!.setVisibility(View.GONE)
                            setDataToAdapter(mBitmapList)
                        }
                    }
                })
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        protected override fun doInBackground(vararg params: Void?): Boolean? {
            val metrics: DisplayMetrics = DisplayMetrics()
            getWindowManager().getDefaultDisplay().getMetrics(metrics)
            mBitmapList = ArrayList()
            for (`object`: Any? in mSelectedList!!) {
                if (`object` is SolidSelectableModel) {
                    val shape: GradientDrawable = GradientDrawable()
                    shape.setShape(GradientDrawable.RECTANGLE)
                    shape.setColors(intArrayOf(`object`.solidColorModel.color, `object`.solidColorModel.color))
                    mBitmapList!!.add(SettingsImagesModel((convertToBitmap(shape, metrics.widthPixels, metrics.heightPixels))!!, false))
                } else if (`object` is GradientSelectableModel) {
                    if (`object`.colorModel.circle) {
                        val shape: GradientDrawable = GradientDrawable()
                        shape.setShape(GradientDrawable.RECTANGLE)
                        shape.setColors(intArrayOf(`object`.colorModel.color1, `object`.colorModel.color2))
                        shape.setGradientType(GradientDrawable.RADIAL_GRADIENT)
                        shape.setGradientRadius(metrics.widthPixels.toFloat())
                        mBitmapList!!.add(SettingsImagesModel((convertToBitmap(shape, metrics.widthPixels, metrics.heightPixels))!!, false))
                    } else {
                        val shape: GradientDrawable = GradientDrawable(`object`.colorModel.orientation, intArrayOf(`object`.colorModel.color1, `object`.colorModel.color2))
                        shape.setShape(GradientDrawable.RECTANGLE)
                        mBitmapList!!.add(SettingsImagesModel((convertToBitmap(shape, metrics.widthPixels, metrics.heightPixels))!!, false))
                    }
                } else if (`object` is TextSelectableModel) {
                    isTextOrGallery = true
                    Glide.with(this@AutoWallpaperChangerTestActivity).asBitmap().override(1000).load(`object`.imgePath).into(object : CustomTarget<Bitmap?>() {
                        public override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap?>?) {
                            Log.d("1278912789", "onResourceReady: 1 " + count + " = " + glideLoadImageCount)
                            mBitmapList!!.add(SettingsImagesModel(resource, false))
                            count++
                            if (count == glideLoadImageCount) {
                                onPostExecute(true)
                                count++
                            }
                        }

                        public override fun onLoadCleared(placeholder: Drawable?) {}
                    })
                } else if (`object` is SavedImageModel) {
                    isTextOrGallery = true
                    Glide.with(this@AutoWallpaperChangerTestActivity).asBitmap().override(1000).load(`object`.path).into(object : CustomTarget<Bitmap?>() {
                        public override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap?>?) {
                            Log.d("1278912789", "onResourceReady: 2 " + count + " = " + glideLoadImageCount)
                            mBitmapList!!.add(SettingsImagesModel(resource, false))
                            count++
                            if (count == glideLoadImageCount) {
                                onPostExecute(true)
                                count++
                            }
                        }

                        public override fun onLoadCleared(placeholder: Drawable?) {}
                    })
                }
            }
            return false
        }
    }

    fun getBitmap(path: String?): Bitmap? {
        try {
            var bitmap: Bitmap? = null
            val f: File = File(path)
            val options: BitmapFactory.Options = BitmapFactory.Options()
            options.inPreferredConfig = Bitmap.Config.ARGB_8888
            bitmap = BitmapFactory.decodeStream(FileInputStream(f), null, options)
            return bitmap
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    private fun setDataToAdapter(mBitmapList: ArrayList<SettingsImagesModel>?) {
        for (mo: SettingsImagesModel in mBitmapList!!) {
            Log.d("1278912789", "setDataToAdapter: " + mo.bitmap)
            this.mBitmapList!!.add(mo.bitmap)
        }
        mSelectedImagesList!!.addAll((mBitmapList))
        if (!isAddMenuOpen) {
            recyclerSelectedWallpaper!!.setVisibility(View.VISIBLE)
        }
        progressRecycler!!.setVisibility(View.GONE)
        val onLongClicked: OnLongClicked = object : OnLongClicked {
            public override fun onLongClicked(isClicked: Boolean) {
                isLongClicked = true
                isEditBottomClicked = true
                bottomButtonEditSettings!!.setVisibility(View.VISIBLE)
                bottomButtonEditSettings!!.setTranslationY(bottomButtonLayoutSettings!!.getHeight().toFloat())
                bottomButtonLayoutSettings!!.post(object : Runnable {
                    public override fun run() {
                        bottomButtonLayoutSettings!!.animate().translationYBy(bottomButtonLayoutSettings!!.getHeight().toFloat()).setDuration(300).start()
                        bottomButtonEditSettings!!.animate().translationYBy(-bottomButtonLayoutSettings!!.getHeight().toFloat()).setDuration(300).start()
                    }
                })
            }
        }
        settingsRecyclerAdapter = SettingsRecyclerAdapter((mSelectedImagesList)!!, this@AutoWallpaperChangerTestActivity, onLongClicked)
        recyclerSelectedWallpaper!!.setAdapter(settingsRecyclerAdapter)
    }

    private fun dpToPx(dp: Int): Int {
        val r: Resources = getResources()
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), r.getDisplayMetrics()))
    }

    fun convertToBitmap(drawable: GradientDrawable, widthPixels: Int, heightPixels: Int): Bitmap? {
        System.gc()
        Runtime.getRuntime().gc()
        var mutableBitmap: Bitmap? = null
        try {
            mutableBitmap = Bitmap.createBitmap(widthPixels, heightPixels, Bitmap.Config.ARGB_8888)
            val canvas: Canvas = Canvas(mutableBitmap)
            drawable.setBounds(0, 0, widthPixels, heightPixels)
            drawable.draw(canvas)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return mutableBitmap
    }

    public override fun onBackPressed() {
        if (!isAnimRunning) {
            icAdd!!.setEnabled(true)
            btnApplyWallpaperSettings!!.setEnabled(true)
            Log.d("78912781231", "onBackPressed: " + isSettingsOpen + "  " + isLongClicked + "  " + isAddMenuOpen + "  " + isEditOpen)
            if (isLongClicked && settingsRecyclerAdapter != null) {
                settingsRecyclerAdapter!!.setDataChanged()
                isLongClicked = false
                isEditBottomClicked = false
                bottomButtonLayoutSettings!!.animate().translationYBy(-bottomButtonLayoutSettings!!.getHeight().toFloat()).setDuration(300).start()
                bottomButtonEditSettings!!.animate().translationYBy(bottomButtonLayoutSettings!!.getHeight().toFloat()).setDuration(300).start()
                return
            }
            if (isAddMenuOpen) {
                isAddMenuOpen = false
                cstMainSettings!!.setVisibility(View.VISIBLE)
                layoutTopSetting!!.setVisibility(View.INVISIBLE)
                bottomButtonLayoutSettings!!.setVisibility(View.INVISIBLE)
                layoutTopSetting!!.post(object : Runnable {
                    public override fun run() {
                        layoutTopSetting!!.setTranslationY(-layoutTopSetting!!.getHeight().toFloat())
                        layoutTopSetting!!.setVisibility(View.VISIBLE)
                        Handler().postDelayed(object : Runnable {
                            public override fun run() {
                                layoutTopSetting!!.animate().translationYBy(layoutTopSetting!!.getHeight().toFloat()).setDuration(300).start()
                            }
                        }, 100)
                        layoutSelectWallpaper!!.animate().translationYBy(layoutSelectWallpaper!!.getHeight().toFloat()).withEndAction(object : Runnable {
                            public override fun run() {
                                progressRecycler!!.setVisibility(View.GONE)
                                bottomButtonLayoutSettings!!.setVisibility(View.VISIBLE)
                                bottomButtonLayoutSettings!!.setTranslationY(bottomButtonLayoutSettings!!.getHeight().toFloat())
                                bottomButtonLayoutSettings!!.post(object : Runnable {
                                    public override fun run() {
                                        bottomButtonLayoutSettings!!.animate().translationYBy(-bottomButtonLayoutSettings!!.getHeight().toFloat()).setDuration(300).start()
                                    }
                                })
                                recyclerSelectedWallpaper!!.setVisibility(View.VISIBLE)
                            }
                        }).setDuration(300).start()
                        if (!isEditClicked) {
                            /*  if (!AdsPrefs.getBoolean(AutoWallpaperChangerTestActivity.this, AdsPrefs.IS_SUBSCRIBED, false)) {
                                btnNext.animate().alpha(0f).withEndAction(new Runnable() {
                                    @Override
                                    public void run() {
                                        btnNext.setVisibility(View.INVISIBLE);
                                    }
                                }).setDuration(300).start();
                                icSubcription.setVisibility(View.VISIBLE);
                                icSubcription.animate().alpha(1f).setDuration(300).start();
                            } else {*/
                            btnNext!!.animate().alpha(0f).withEndAction(object : Runnable {
                                public override fun run() {
                                    btnNext!!.setVisibility(View.INVISIBLE)
                                }
                            }).setDuration(300).start()
                            icAdd!!.setVisibility(View.VISIBLE)
                            icAdd!!.animate().alpha(1f).setDuration(300).start()
                            //  }
                        }
                    }
                })
                return
            }
            Log.d("781212312313231", "onBackPressed: " + isEditOpen)
            if (isEditOpen) {
                isEditOpen = false
                if (settingsRecyclerAdapter != null) {
                    settingsRecyclerAdapter!!.setDataChanged()
                }
                cstMainSettings!!.setVisibility(View.VISIBLE)
                layoutTopSetting!!.setVisibility(View.INVISIBLE)
                bottomButtonLayoutSettings!!.setVisibility(View.INVISIBLE)
                layoutTopSetting!!.setTranslationY(-layoutTopSetting!!.getHeight().toFloat())
                layoutTopSetting!!.setVisibility(View.VISIBLE)
                Handler().postDelayed(object : Runnable {
                    public override fun run() {
                        layoutTopSetting!!.animate().translationYBy(layoutTopSetting!!.getHeight().toFloat()).setDuration(300).start()
                    }
                }, 100)
                Log.d("8745617688778", "run: " + layoutSelectWallpaper!!.getHeight())
                layoutSelectWallpaper!!.animate().translationYBy(layoutSelectWallpaper!!.getHeight().toFloat()).withEndAction(object : Runnable {
                    public override fun run() {
                        progressRecycler!!.setVisibility(View.GONE)
                        bottomButtonLayoutSettings!!.setVisibility(View.VISIBLE)
                        bottomButtonLayoutSettings!!.setTranslationY(bottomButtonLayoutSettings!!.getHeight().toFloat())
                        bottomButtonLayoutSettings!!.post(object : Runnable {
                            public override fun run() {
                                bottomButtonLayoutSettings!!.animate().translationYBy(-bottomButtonLayoutSettings!!.getHeight().toFloat()).setDuration(300).start()
                            }
                        })
                        recyclerSelectedWallpaper!!.setVisibility(View.VISIBLE)
                    }
                }).setDuration(300).start()
                /*   if (!AdsPrefs.getBoolean(AutoWallpaperChangerTestActivity.this, AdsPrefs.IS_SUBSCRIBED, false)) {
                    btnNext.animate().alpha(0f).withEndAction(new Runnable() {
                        @Override
                        public void run() {
                            btnNext.setVisibility(View.INVISIBLE);
                        }
                    }).setDuration(300).start();
                    icSubcription.setVisibility(View.VISIBLE);
                    icSubcription.animate().alpha(1f).setDuration(300).start();
                } else {*/btnNext!!.animate().alpha(0f).withEndAction(object : Runnable {
                    public override fun run() {
                        btnNext!!.setVisibility(View.INVISIBLE)
                    }
                }).setDuration(300).start()
                icAdd!!.setVisibility(View.VISIBLE)
                icAdd!!.animate().alpha(1f).setDuration(300).start()
                //   }
                return
            }
            if (isSettingsOpen) {
                showAlertDialogDiscard()
                return
            }
            setResult(Activity.RESULT_CANCELED, Intent())
            finish()
        }
    }

    private fun showAlertDialogDiscard() {
         bottomSheetFragment= BottomSheetFragmentDiscard(getResources().getString(R.string.dialog_home), getResources().getString(R.string.do_you_want_to_discard), getResources().getString(R.string.discard), getResources().getString(R.string.cancel), R.drawable.ic_discard_dialog, object : BottomSheetFragmentDiscard.OnButtonClickListener {
            public override fun onPositive(bottomSheetDialo: BottomSheetFragmentDiscard?) {
                bottomSheetDialo!!.dismiss()
                setResult(Activity.RESULT_CANCELED, Intent())
                finish()
            }

            public override fun onNegative(bottomSheetDialog: BottomSheetFragmentDiscard?) {
                bottomSheetDialog!!.dismiss()
            }
        })
        bottomSheetFragment!!.show(supportFragmentManager, "dialog")
    }

    override fun onPause() {
        super.onPause()
        try {
            bottomSheetFragment!!.dismiss()
        }catch (e:Exception){

        }

        try {
            bottomSheetFragments!!.dismiss()
        }catch (e:Exception){

        }
    }
    override fun onResume() {
        super.onResume()
        SolidWallpaperApplication.staticLanguage.Factory.create(this)
    }

    companion object {
        private val TAG: String = "AutoWallpaperChangerAct"
    }
}