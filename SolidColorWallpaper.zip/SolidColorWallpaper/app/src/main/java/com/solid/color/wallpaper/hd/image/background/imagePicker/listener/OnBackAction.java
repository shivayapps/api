package com.solid.color.wallpaper.hd.image.background.imagePicker.listener;



public interface OnBackAction {
    void onBackToFolder();

    void onFinishImagePicker();
}
