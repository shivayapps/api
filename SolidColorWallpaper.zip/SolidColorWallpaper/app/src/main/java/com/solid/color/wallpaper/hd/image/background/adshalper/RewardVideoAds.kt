package com.solid.color.wallpaper.hd.image.background.adshalper

import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.appid.AppIDs

class RewardVideoAds {

    val TAG = "Ads_123"
    var googleRewardVideo = AppIDs.instnace!!.getGoogleRewardVideo()

    companion object {

        var rewardedAd: RewardedAd? = null
        var rewardedAd1: RewardedAd? = null

        var instence: RewardVideoAds? = null
            get() {
                if (field == null) {
                    field = RewardVideoAds()
                }
                return field
            }

    }

    fun loadVideoAdMain(context: Context): RewardedAd? {
        var reward: RewardedAd? = null
        if (rewardedAd != null) {
            // return rewardedAd!!
            Log.e(TAG, "loadVideoAdMain: rewardedAd")

            reward = rewardedAd!!
        } else {
            Log.e(TAG, "loadVideoAdMain: rewardedAd else")
            loadRewardVideoAd(context)
        }
        if (rewardedAd1 != null) {

            Log.e(TAG, "loadVideoAdMain: rewardedAd1")

            //return rewardedAd1!!
            reward = rewardedAd1!!
        } else {
            loadRewardVideoAd1(context)
            Log.e(TAG, "loadVideoAdMain: rewardedAd1 else")

        }
        return reward
    }


    fun checkAdLoad(): RewardedAd? {
        var reward: RewardedAd? = null
        if (rewardedAd != null) {
            Log.e(TAG, "checkAdLoad: rewardedAd", )
            // return rewardedAd!!
            reward = rewardedAd!!
        }
        if (rewardedAd1 != null) {
            //return rewardedAd1!!
            Log.e(TAG, "checkAdLoad: rewardedAd1", )

            reward = rewardedAd1!!
        }

        return reward
    }


    fun loadRewardVideoAd(context: Context) {
        if (rewardedAd != null) {
            return
        }

//        rewardedAd = RewardedAd(
//                context,
//                googleRewardVideo
//        )


//        val adLoadCallback: RewardedAdLoadCallback = object : RewardedAdLoadCallback() {
//            override fun onRewardedAdLoaded() {
//                Log.e("hjdasjajsd=====>", "loaded 0")
//            }
//
//            override fun onRewardedAdFailedToLoad(errorCode: Int) {
//                /// loadRewardVideoAd(context)
//                Log.e("hjdasjajsd=====>", "falied 0  $errorCode")
//            }
//        }
//        RewardedAd.load(context,AdRequest.Builder().build(), adLoadCallback)

        RewardedAd.load(context, googleRewardVideo, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdFailedToLoad(adError: LoadAdError) {
                Log.d(TAG, adError?.message)
                rewardedAd = null
                Log.e(TAG, "onAdFailedToLoad: onAdFailedToLoad")
                loadRewardVideoAd(context)
            }

            override fun onAdLoaded(rewardedAd: RewardedAd) {
                Log.d(TAG, "Ad was loaded.")
                Companion.rewardedAd = rewardedAd
                loadRewardVideoAd(context)

            }
        })

        if (rewardedAd != null) {
            rewardedAd!!.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    Log.d(TAG, "Ad was dismissed.")
                    loadRewardVideoAd(context)

                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError?) {
                    Log.d(TAG, "Ad failed to show.")
                    loadRewardVideoAd(context)

                }

                override fun onAdShowedFullScreenContent() {
                    Log.d(TAG, "Ad showed fullscreen content.")
                    // Called when ad is dismissed.
                    // Don't set the ad reference to null to avoid showing the ad a second time.
                    rewardedAd = null
                    loadRewardVideoAd(context)

                }
            }
        }


    }

    fun loadRewardVideoAd1(context: Context) {

        if (rewardedAd1 != null) {
            return
        }

        RewardedAd.load(context, googleRewardVideo, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdFailedToLoad(adError: LoadAdError) {
                Log.d(TAG, adError?.message)
                rewardedAd1 = null
                loadRewardVideoAd1(context)
            }

            override fun onAdLoaded(rewardedAd: RewardedAd) {
                Log.d(TAG, "Ad was loaded.")
                Companion.rewardedAd1 = rewardedAd
            }
        })

        if (rewardedAd1 != null) {

            rewardedAd1!!.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    Log.d(TAG, "Ad was dismissed.")
                    loadRewardVideoAd1(context)
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError?) {
                    Log.d(TAG, "Ad failed to show.")
                    loadRewardVideoAd1(context)
                }

                override fun onAdShowedFullScreenContent() {
                    Log.d(TAG, "Ad showed fullscreen content.")
                    // Called when ad is dismissed.
                    // Don't set the ad reference to null to avoid showing the ad a second time.
                    rewardedAd1 = null
                    loadRewardVideoAd1(context)
                }
            }
        }

//        if (rewardedAd1 != null && rewardedAd1?.isLoaded!!) {
//            return
//        }
//
//        rewardedAd1 = RewardedAd(
//                context,
//                googleRewardVideo
//        )
//        val adLoadCallback: RewardedAdLoadCallback = object : RewardedAdLoadCallback() {
//            override fun onRewardedAdLoaded() {
//                Log.e("hjdasjajsd=====>", "loaded 1")
//            }
//
//            override fun onRewardedAdFailedToLoad(errorCode: Int) {
//                //  loadRewardVideoAd1(context)
//                Log.e("hjdasjajsd=====>", "failed 1 ${errorCode}")
//            }
//        }
//        rewardedAd1?.loadAd(AdRequest.Builder().build(), adLoadCallback)
    }
}