package com.solid.color.wallpaper.hd.image.background.activity

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.viewpager.widget.ViewPager
import androidx.viewpager.widget.ViewPager.OnPageChangeListener
import com.google.android.gms.ads.FullScreenContentCallback
import com.solid.color.wallpaper.hd.image.background.BuildConfig
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.SolidWallpaperApplication
import com.solid.color.wallpaper.hd.image.background.SolidWallpaperApplication.Companion.instance
import com.solid.color.wallpaper.hd.image.background.activity.MyCreationActivity
import com.solid.color.wallpaper.hd.image.background.adshalper.NativeAdvanceHelper
import com.solid.color.wallpaper.hd.image.background.constants.Constants
import com.solid.color.wallpaper.hd.image.background.fragment.GradientSavedFragment
import com.solid.color.wallpaper.hd.image.background.fragment.SolidSavedFragment
import com.solid.color.wallpaper.hd.image.background.fragment.TextSavedFragment
import com.solid.color.wallpaper.hd.image.background.model.SavedImageModel
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs.getBoolean
import com.solid.color.wallpaper.hd.image.background.shared_pref.MySharedPref
import java.io.File
import java.util.*

class MyCreationActivity : AppCompatActivity(), View.OnClickListener {
    private var viewpager: ViewPager? = null
    private var imgBack: ImageView? = null
    private var imgShare: ImageView? = null
    private val img_birthday_ad: ImageView? = null
    private var btnSolid: TextView? = null
    private var btnGradient: TextView? = null
    private var btnText: TextView? = null
    private var solidSavedFragment: SolidSavedFragment? = null
    private var gradientSavedFragment: GradientSavedFragment? = null
    private var textSavedFragment: TextSavedFragment? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_creation)
        System.gc()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted
            startActivity(Intent(this@MyCreationActivity, MainStartActivity::class.java))
            finish()
        } else {
            initViews()
            initViewAction()
            initListner()
        }
    }

    private fun initListner() {
        imgBack!!.setOnClickListener(this)
        imgShare!!.setOnClickListener(this)
        btnGradient!!.setOnClickListener(this)
        btnSolid!!.setOnClickListener(this)
        btnText!!.setOnClickListener(this)
        // img_birthday_ad.setOnClickListener(this);
    }

    private fun loadInterstialAd() {
        if (instance!!.mInterstitialAd != null) {
            Log.d("TAG", "loadInterstialAd: ")
        } else {

            if (instance!!.mInterstitialAd != null) {


                instance!!.mInterstitialAd!!.fullScreenContentCallback = null
                instance!!.mInterstitialAd = null
                instance!!.ins_adRequest = null
                instance!!.LoadAds()

                instance!!.mInterstitialAd!!.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
//                    Log.d(TAG, 'Ad was dismissed.')
                    }

                    override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
                        super.onAdFailedToShowFullScreenContent(p0)
                        loadInterstialAd()
                    }

                    override fun onAdShowedFullScreenContent() {
//                    Log.d(TAG, 'Ad showed fullscreen content.')
                        instance!!.mInterstitialAd = null;
                    }
                }
                instance!!.mInterstitialAd!!.show(this)

//            instance!!.mInterstitialAd!!.adListener = object : AdListener() {
//                override fun onAdLoaded() {
//                    super.onAdLoaded()
//                }
//
//                override fun onAdFailedToLoad(i: Int) {
//                    super.onAdFailedToLoad(i)
//                    loadInterstialAd()
//                    //  loadInterstialAdFb();
//                }
//            }
            }
        }
    }

    private fun initViewAction() {
        if (getBoolean(this, AdsPrefs.IS_SUBSCRIBED, false)) {
            // img_birthday_ad.setVisibility(View.GONE);
        } else {
            loadInterstialAd()
        }
        textSavedFragment = TextSavedFragment("TEXT")
        gradientSavedFragment = GradientSavedFragment("GRADIENT")
        solidSavedFragment = SolidSavedFragment("SOLID")
        viewpager!!.adapter = ViewPagerAdapter(supportFragmentManager)
        viewpager!!.currentItem = Constants.viewPagerPage
        viewpager!!.addOnPageChangeListener(object : OnPageChangeListener {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {}
            override fun onPageSelected(position: Int) {
                Constants.viewPagerPage = position
                if (position == 0) {
                    btnSolid!!.setTextColor(resources.getColor(R.color.text_colour_new))
                    btnGradient!!.setTextColor(resources.getColor(R.color.unselected_button))
                    btnText!!.setTextColor(resources.getColor(R.color.unselected_button))
                } else if (position == 1) {
                    btnGradient!!.setTextColor(resources.getColor(R.color.text_colour_new))
                    btnSolid!!.setTextColor(resources.getColor(R.color.unselected_button))
                    btnText!!.setTextColor(resources.getColor(R.color.unselected_button))
                } else {
                    btnGradient!!.setTextColor(resources.getColor(R.color.unselected_button))
                    btnSolid!!.setTextColor(resources.getColor(R.color.unselected_button))
                    btnText!!.setTextColor(resources.getColor(R.color.text_colour_new))
                }
            }

            override fun onPageScrollStateChanged(state: Int) {}
        })
        viewpager!!.offscreenPageLimit = 2

        if (MySharedPref(this).getAdsCreationClicked()) {
//            findViewById<View>(R.id.native_ad_container).visibility = View.VISIBLE
            findViewById<View>(R.id.img_birthday_ad).visibility = View.GONE

        } else {
//            findViewById<View>(R.id.native_ad_container).visibility = View.GONE
            if (!getBoolean(this@MyCreationActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                findViewById<View>(R.id.img_birthday_ad).visibility = View.VISIBLE
            } else {
                findViewById<View>(R.id.img_birthday_ad).visibility = View.GONE
            }
        }
        val onFbAdListner: NativeAdvanceHelper.onFbAdListnerNative = object : NativeAdvanceHelper.onFbAdListnerNative {
            override fun isLoadedAd(isLoaded: Boolean?) {
                Log.d("7456456123", "onCreate: $isLoaded")
            }

            override fun isError(isError: Boolean?) {
                Log.d("7456456123", "isError: ")
            }
        }
//        NativeAdvanceHelper.loadNativeAdFbSmallBanner1(this@MyCreationActivity, findViewById<NativeAdLayout>(R.id.native_ad_container), onFbAdListner)
        findViewById<View>(R.id.img_birthday_ad).setOnClickListener { v: View? ->
            MySharedPref(this).setAdsCreationClicked("getAdsCreationClicked", true)
            try {
                startActivityForResult(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.graphic.design.digital.businessadsmaker")), 1212)
//                startActivityForResult(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.crop.photo.image.resize.cut.tools")), 1212)
            } catch (anfe: ActivityNotFoundException) {
                startActivityForResult(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.graphic.design.digital.businessadsmaker")), 1212)

//                startActivityForResult(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.crop.photo.image.resize.cut.tools")), 1212)
            }
        }
    }

    inner class ViewPagerAdapter(fm: FragmentManager?) : FragmentPagerAdapter(fm!!) {
        override fun getItem(position: Int): Fragment {
            return return when (position) {
                0 -> solidSavedFragment!!
                1 -> gradientSavedFragment!!
        //                2 -> return textSavedFragment!!
                else -> textSavedFragment!!
            }
//            return null
        }

        override fun getCount(): Int {
            return 3
        }
    }

    private fun initViews() {
        viewpager = findViewById(R.id.viewpager)
        imgShare = findViewById(R.id.imgShare)
        imgBack = findViewById(R.id.imgBack)
        btnSolid = findViewById(R.id.btnSolid)
        btnGradient = findViewById(R.id.btnGradient)
        btnText = findViewById(R.id.btnText)
        //img_birthday_ad = findViewById(R.id.img_birthday_ad);
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
//        if (requestCode == 100 && !getBoolean(this, AdsPrefs.IS_SUBSCRIBED, false)) {
//            if (instance!!.requestNewInterstitial()) {
//                instance!!.mInterstitialAd!!.adListener = object : AdListener() {
//                    override fun onAdClosed() {
//                        super.onAdClosed()
//                        loadInterstialAd()
//                    }
//
//                    override fun onAdFailedToLoad(i: Int) {
//                        super.onAdFailedToLoad(i)
//                        loadInterstialAd()
//                    }
//
//                    override fun onAdLoaded() {
//                        super.onAdLoaded()
//                    }
//                }
//            }
//        }
        if (requestCode == 1212) {
            if (MySharedPref(this).getAdsCreationClicked()) {
//                findViewById<View>(R.id.native_ad_container).visibility = View.VISIBLE
                findViewById<View>(R.id.img_birthday_ad).visibility = View.GONE
            }
        }

    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.imgBack -> onBackPressed()
            R.id.imgShare -> shareApp()
            R.id.btnSolid -> onclickSolid()
            R.id.btnGradient -> onclickGradient()
            R.id.btnText -> onclickText()
        }
    }

    private fun onclickBirthday() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.name.photo.birthday.cake.quotes.frame.editor")))
        } catch (anfe: ActivityNotFoundException) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.name.photo.birthday.cake.quotes.frame.editor")))
        }
    }

    private fun shareApp() {
        if (viewpager!!.currentItem == 0) {
            if (solidSavedFragment != null && solidSavedFragment!!.updatedData != null && solidSavedFragment!!.updatedData!!.size > 0) {
                shareImage(solidSavedFragment!!.updatedData)
            } else {
                shareOwnApp()
            }
        } else if (viewpager!!.currentItem == 1) {
            if (gradientSavedFragment != null && gradientSavedFragment!!.updatedData != null && gradientSavedFragment!!.updatedData!!.size > 0) {
                shareImage(gradientSavedFragment!!.updatedData)
            } else {
                shareOwnApp()
            }
        } else if (viewpager!!.currentItem == 2) {
            if (textSavedFragment != null && textSavedFragment!!.updatedData != null && textSavedFragment!!.updatedData!!.size > 0) {
                shareImage(textSavedFragment!!.updatedData)
            } else {
                shareOwnApp()
            }
        }
    }

    private fun shareImage(updatedData: ArrayList<SavedImageModel>?) {
        val mSharedUri = ArrayList<Uri>()
        for (i in updatedData!!.indices) {
            if (updatedData[i].isDeletedEnable) {
                val uri = FileProvider.getUriForFile(this@MyCreationActivity, BuildConfig.APPLICATION_ID.toString() + ".provider", File(updatedData[i].path))
                mSharedUri.add(uri)
            }
        }
        val intent = Intent(Intent.ACTION_SEND_MULTIPLE)
        intent.type = "image/jpeg"
        intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, mSharedUri)
        var shareMessage = ""
        shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=com.solid.color.wallpaper.hd.image.background"
        intent.putExtra(Intent.EXTRA_TEXT, shareMessage)
        startActivityForResult(Intent.createChooser(intent, resources.getString(R.string.share_wallpaper)), 100)
    }

    private fun shareOwnApp() {
        val shareIntent = Intent(Intent.ACTION_SEND)
        shareIntent.type = "text/plain"
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Solid Color Wallpaper")
        var shareMessage = ""
        shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=com.solid.color.wallpaper.hd.image.background"
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
        startActivity(Intent.createChooser(shareIntent, resources.getString(R.string.choose_one)))
    }

    private fun onclickText() {
        btnText!!.setTextColor(Color.BLACK)
        btnGradient!!.setTextColor(resources.getColor(R.color.unselected_button))
        btnSolid!!.setTextColor(resources.getColor(R.color.unselected_button))
        viewpager!!.currentItem = 2
    }

    private fun onclickSolid() {
        btnSolid!!.setTextColor(Color.BLACK)
        btnGradient!!.setTextColor(resources.getColor(R.color.unselected_button))
        btnText!!.setTextColor(resources.getColor(R.color.unselected_button))
        viewpager!!.currentItem = 0
    }

    private fun onclickGradient() {
        btnGradient!!.setTextColor(Color.BLACK)
        btnSolid!!.setTextColor(resources.getColor(R.color.unselected_button))
        btnText!!.setTextColor(resources.getColor(R.color.unselected_button))
        viewpager!!.currentItem = 1
    }

    override fun onBackPressed() {
        if (viewpager!!.currentItem == 1 && gradientSavedFragment!!.allowBackPressed()) {
            super.onBackPressed()
        } else if (viewpager!!.currentItem == 0 && solidSavedFragment!!.allowBackPressed()) {
            super.onBackPressed()
        } else if (viewpager!!.currentItem == 2 && textSavedFragment!!.allowBackPressed()) {
            super.onBackPressed()
        }
    }

    override fun onResume() {
        super.onResume()
        SolidWallpaperApplication.staticLanguage.Factory.create(this)
    }
}