package com.solid.color.wallpaper.hd.image.background.imagePicker.listener;

import com.solid.color.wallpaper.hd.image.background.imagePicker.model.Image;

import java.util.List;


public interface OnImageSelectionListener {
    void onSelectionUpdate(List<Image> images);
}
