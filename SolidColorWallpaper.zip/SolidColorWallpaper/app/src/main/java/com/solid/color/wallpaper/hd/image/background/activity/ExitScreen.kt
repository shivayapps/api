package com.solid.color.wallpaper.hd.image.background.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.solid.color.wallpaper.hd.image.background.R

class ExitScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_exit_screen)

        Handler(Looper.getMainLooper()).postDelayed({
           finishAffinity()
        },2000)
    }

    override fun onBackPressed() {
        super.onBackPressed()
        finishAffinity()
    }

    override fun onPause() {
        super.onPause()
        finishAffinity()
    }
}