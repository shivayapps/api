package com.solid.color.wallpaper.hd.image.background.adapter

import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.ProgressBar
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.model.SavedImageModel
import java.util.*

class SavedImagesAdapter(val allUpdatedList: ArrayList<SavedImageModel>, private val mContext: Context, private val mListener: setOnItemClickListener) : RecyclerView.Adapter<SavedImagesAdapter.MyViewHolder>() {
    private var LastSelectedView: MyViewHolder? = null
    private val LastSelectedItem = 0
    private var isLongPressed = false
    private var checkedItem = -1

    interface setOnItemClickListener {
        fun OnItemClickedImage(position: Int)
        fun OnLongClickImage(position: Int)
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): MyViewHolder {
        return MyViewHolder(LayoutInflater.from(mContext).inflate(R.layout.saved_wallpaper_item, null))
    }

    override fun onBindViewHolder(myViewHolder: MyViewHolder, i: Int) {
        Glide.with(mContext).load(allUpdatedList[i].path).override(150).into(object : CustomTarget<Drawable?>() {
            override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                myViewHolder.progressBar.visibility = View.GONE
                myViewHolder.imgColor.setImageDrawable(resource)
            }

            override fun onLoadCleared(placeholder: Drawable?) {
                myViewHolder.progressBar.visibility = View.VISIBLE
            }
        })
        if (isLongPressed) {
            myViewHolder.deleteCheck.visibility = View.VISIBLE
        } else {
            myViewHolder.deleteCheck.visibility = View.GONE
        }

        /*  if (checkedItem==i){
            myViewHolder.deleteCheck.setChecked(true);
            mColors.get(i).setDeletedEnable(true);
        }else {
            myViewHolder.deleteCheck.setChecked(false);
            mColors.get(i).setDeletedEnable(false);
        }
*/if (allUpdatedList[i].isDeletedEnable) {
            myViewHolder.deleteCheck.isChecked = true
        } else {
            myViewHolder.deleteCheck.isChecked = false
        }
        myViewHolder.imgColor.setOnClickListener {
            if (myViewHolder.deleteCheck.visibility == View.VISIBLE) {
                if (myViewHolder.deleteCheck.isChecked) {
                    myViewHolder.deleteCheck.isChecked = false
                    allUpdatedList[i].isDeletedEnable = false
                } else {
                    allUpdatedList[i].isDeletedEnable = true
                    myViewHolder.deleteCheck.isChecked = true
                }
            } else {
                mListener.OnItemClickedImage(i)
                LastSelectedView = myViewHolder
            }
        }

        /*  myViewHolder.deleteCheck.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                Log.d("798546513123123312", "onCheckedChanged: "+b+"  "+i);
                if (b){
                    mColors.get(i).setDeletedEnable(true);
                }else {
                    mColors.get(i).setDeletedEnable(false);
                }
            }
        });*/myViewHolder.deleteCheck.setOnClickListener {
            if (allUpdatedList[i].isDeletedEnable) {
                allUpdatedList[i].isDeletedEnable = false
                myViewHolder.deleteCheck.isChecked = false
            } else {
                allUpdatedList[i].isDeletedEnable = true
                myViewHolder.deleteCheck.isChecked = true
            }
        }
        myViewHolder.imgColor.setOnLongClickListener(object : View.OnLongClickListener {
            override fun onLongClick(view: View): Boolean {
                return if (myViewHolder.deleteCheck.visibility != View.VISIBLE) {
                    isLongPressed = true
                    for (image in allUpdatedList) {
                        image.isDeletedEnable = false
                    }
                    allUpdatedList[i].isDeletedEnable = true
                    checkedItem = i
                    mListener.OnLongClickImage(i)
                    notifyDataSetChanged()
                    true
                } else {
                    false
                }
            }
        })
    }

    fun setDataChange() {
        isLongPressed = false
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int {
        return allUpdatedList.size
    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imgColor: ImageView = itemView.findViewById(R.id.imgColor)
        val progressBar: ProgressBar = itemView.findViewById(R.id.progressBar)
        val deleteCheck: CheckBox = itemView.findViewById(R.id.checkbox)

    }

}