package com.solid.color.wallpaper.hd.image.background.newModel

data class ScreenModelClass(var mName:String?,var mScreenList:ImagesItem?)