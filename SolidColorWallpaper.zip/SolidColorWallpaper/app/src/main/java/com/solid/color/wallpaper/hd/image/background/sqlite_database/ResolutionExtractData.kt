package com.solid.color.wallpaper.hd.image.background.sqlite_database

import android.content.Context
import android.database.SQLException
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.util.DisplayMetrics
import android.util.Log
import com.solid.color.wallpaper.hd.image.background.custom.MatrixClonable
import com.solid.color.wallpaper.hd.image.background.model.ResolutionModel
import com.solid.color.wallpaper.hd.image.background.model.StickerModel
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream
import java.util.*

class ResolutionExtractData(var ctx: Context) : SQLiteOpenHelper(ctx, DATABASE_NAME, null, DATABASE_VERSION) {
    @Throws(IOException::class)
    fun CopyDataBaseFromAsset() {
        var name = "Resolution3_0.db"
        val densityDpi = ctx.resources.displayMetrics.densityDpi
        when (densityDpi) {
            DisplayMetrics.DENSITY_LOW -> {
            }
            DisplayMetrics.DENSITY_MEDIUM -> {
            }
            DisplayMetrics.DENSITY_TV, DisplayMetrics.DENSITY_HIGH -> {
            }
            DisplayMetrics.DENSITY_XHIGH, DisplayMetrics.DENSITY_280 -> name = "Resolution2_0.db"
            DisplayMetrics.DENSITY_XXHIGH, DisplayMetrics.DENSITY_360, DisplayMetrics.DENSITY_400, DisplayMetrics.DENSITY_420 ->                 // XXHDPI
                name = "Resolution3_0.db"
            DisplayMetrics.DENSITY_XXXHIGH, DisplayMetrics.DENSITY_560 -> {
            }
        }
        val myInput = ctx.assets.open("databases/$name")
        // Path to the just created empty db
        val outFileName = ctx.applicationInfo.dataDir + DB_PATH_SUFFIX + DATABASE_NAME

        // if the path doesn't exist first, create it
        val f = File(ctx.applicationInfo.dataDir + DB_PATH_SUFFIX)
        if (!f.exists()) f.mkdirs()

        // Open the empty db as the output stream
        val myOutput: OutputStream = FileOutputStream(outFileName)

        // transfer bytes from the inputfile to the outputfile
        val buffer = ByteArray(1024)
        var length: Int
        while (myInput.read(buffer).also { length = it } > 0) {
            myOutput.write(buffer, 0, length)
        }
        // Close the streams
        myOutput.flush()
        myOutput.close()
        myInput.close()
    }

    val resolutionModelList: ArrayList<ResolutionModel>
        get() {
            val cursor = writableDatabase.rawQuery("SELECT * FROM resolution", null)
            val employees = ArrayList<ResolutionModel>()
            if (cursor.moveToFirst()) {
                do {
                    val resolutionModel = ResolutionModel()
                    resolutionModel.mainWidth = cursor.getInt(cursor.getColumnIndex(RESOLUTION_COLUMN_WIDTH))
                    resolutionModel.mainHeight = cursor.getInt(cursor.getColumnIndex(RESOLUTION_COLUMN_HEIGHT))
                    resolutionModel.color1 = cursor.getString(cursor.getColumnIndex(RESOLUTION_COLUMN_COLOUR_1)).toInt()
                    resolutionModel.color2 = cursor.getString(cursor.getColumnIndex(RESOLUTION_COLUMN_COLOUR_2)).toInt()
                    resolutionModel.isCircle = cursor.getString(cursor.getColumnIndex(RESOLUTION_COLUMN_IS_CIRCLE)) == "1"
                    resolutionModel.isInner = cursor.getString(cursor.getColumnIndex(RESOLUTION_COLUMN_IS_INNER)) == "1"
                    resolutionModel.orientation = getOrientation(cursor.getInt(cursor.getColumnIndex(RESOLUTION_COLUMN_ORIENTAION)))
                    resolutionModel.setmAllSticker(getAllSticker(cursor.getInt(cursor.getColumnIndex(RESOLUTION_COLUMN_ID))))
                    employees.add(resolutionModel)
                } while (cursor.moveToNext())
            }
            cursor.close()
            return employees
        }

    private fun getOrientation(anInt: Int): GradientDrawable.Orientation {
        val orientation: GradientDrawable.Orientation
        orientation = when (anInt) {
            0 -> GradientDrawable.Orientation.TOP_BOTTOM
            1 -> GradientDrawable.Orientation.TR_BL
            2 -> GradientDrawable.Orientation.RIGHT_LEFT
            3 -> GradientDrawable.Orientation.BR_TL
            4 -> GradientDrawable.Orientation.BOTTOM_TOP
            5 -> GradientDrawable.Orientation.BL_TR
            6 -> GradientDrawable.Orientation.LEFT_RIGHT
            7 -> GradientDrawable.Orientation.TL_BR
            else -> GradientDrawable.Orientation.TOP_BOTTOM
        }
        return orientation
    }

    private fun getAllSticker(anInt: Int): ArrayList<StickerModel?> {
        val cursor = writableDatabase.rawQuery("SELECT * FROM stickers WHERE id_sticker=$anInt", null)
        val mStickerList = ArrayList<StickerModel?>()
        if (cursor.moveToFirst()) {
            do {
                val model = StickerModel()
                if (cursor.getString(cursor.getColumnIndex(STICKER_ISTEXT)) == "1") {
                    model.typeface = cursor.getString(cursor.getColumnIndex(STICKER_TEXT_TYPEFACE))
                    model.text = cursor.getString(cursor.getColumnIndex(STICKER_TEXT))
                    model.textColor = cursor.getString(cursor.getColumnIndex(STICKER_TEXT_COLOR)).toInt()
                    model.textAlhpa = cursor.getInt(cursor.getColumnIndex(STICKER_TEXT_ALPHA))
                } else {
                    val photo = cursor.getBlob(cursor.getColumnIndex(STICKER_DRAWABLE))
                    val image: Drawable = BitmapDrawable(ctx.resources, BitmapFactory.decodeByteArray(photo, 0, photo.size))
                    model.drawable = image
                    model.drawableAlpha = cursor.getInt(cursor.getColumnIndex(STICKER_DRAWABLE_ALPHA))
                    model.drawableColor = cursor.getString(cursor.getColumnIndex(STICKER_DRAWABLE_COLOR)).toInt()
                }
                model.isText = cursor.getString(cursor.getColumnIndex(STICKER_ISTEXT)) == "1"
                val values = FloatArray(9)
                values[Matrix.MTRANS_X] = cursor.getString(cursor.getColumnIndex(MATRIX_MTRANSX)).toFloat()
                values[Matrix.MTRANS_Y] = cursor.getString(cursor.getColumnIndex(MATRIX_MTRANSY)).toFloat()
                values[Matrix.MSCALE_X] = cursor.getString(cursor.getColumnIndex(MATRIX_MSCALEX)).toFloat()
                values[Matrix.MSCALE_Y] = cursor.getString(cursor.getColumnIndex(MATRIX_MSCALEY)).toFloat()
                values[Matrix.MSKEW_X] = cursor.getString(cursor.getColumnIndex(MATRIX_MSKEW_X)).toFloat()
                values[Matrix.MSKEW_Y] = cursor.getString(cursor.getColumnIndex(MATRIX_MSKEW_Y)).toFloat()
                values[Matrix.MPERSP_0] = 0.0f
                values[Matrix.MPERSP_1] = 0.0f
                values[Matrix.MPERSP_2] = 1.0f
                val matrix = MatrixClonable()
                matrix.setValues(values)
                model.matrix = matrix
                mStickerList.add(model)
            } while (cursor.moveToNext())
        }
        cursor.close()
        return mStickerList
    }

    //Check database already exist or not
    fun checkDataBase(): Boolean {
        var checkDB = false
        try {
            val myPath = DATABASE_NAME
            val dbfile = File(myPath)
            checkDB = dbfile.exists()
        } catch (e: SQLiteException) {
        }
        return checkDB
    }

    @Throws(SQLException::class)
    fun openDataBase() {
        val dbFile = ctx.getDatabasePath(DATABASE_NAME)
        Log.d("782045456456", "openDataBase: " + dbFile.exists())
        if (!dbFile.exists()) {
            try {
                CopyDataBaseFromAsset()
            } catch (e: IOException) {
                throw RuntimeException("Error creating source database", e)
            }
        }
        // return SQLiteDatabase.openDatabase(dbFile.getPath(), null, SQLiteDatabase.NO_LOCALIZED_COLLATORS | SQLiteDatabase.CREATE_IF_NECESSARY);
    }

    override fun onCreate(db: SQLiteDatabase) {}
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    companion object {
        private const val DATABASE_VERSION = 1
        private const val DB_PATH_SUFFIX = "/databases/"
        private const val DATABASE_NAME = "ResolutionNew.db"
        const val RESOLUTION_COLUMN_ID = "id"
        const val RESOLUTION_COLUMN_WIDTH = "width"
        const val RESOLUTION_COLUMN_HEIGHT = "height"
        const val RESOLUTION_COLUMN_COLOUR_1 = "colour_1"
        const val RESOLUTION_COLUMN_COLOUR_2 = "colour_2"
        const val RESOLUTION_COLUMN_IS_CIRCLE = "iscircle"
        const val RESOLUTION_COLUMN_IS_INNER = "isinner"
        const val RESOLUTION_COLUMN_ORIENTAION = "orientation"
        const val STICKER_STICKER_ID = "id_sticker"
        const val STICKER_ISTEXT = "istext"
        const val STICKER_TEXT = "sticker_text"
        const val STICKER_TEXT_TYPEFACE = "sticker_typeface"
        const val STICKER_TEXT_COLOR = "sticker_text_color"
        const val STICKER_TEXT_ALPHA = "sticker_text_alpha"
        const val STICKER_DRAWABLE = "sticker_drawable"
        const val STICKER_DRAWABLE_COLOR = "sticker_drawable_color"
        const val STICKER_DRAWABLE_ALPHA = "sticker_drawable_alpha"
        const val MATRIX_MTRANSX = "mtransx"
        const val MATRIX_MTRANSY = "mtransy"
        const val MATRIX_MSCALEX = "mscalex"
        const val MATRIX_MSCALEY = "mscaley"
        const val MATRIX_MSKEW_X = "mskewx"
        const val MATRIX_MSKEW_Y = "mskewy"
//        private val databasePath: String
//            private get() = (ctx.getApplicationInfo().dataDir + DB_PATH_SUFFIX
//                    + DATABASE_NAME)
    }

}