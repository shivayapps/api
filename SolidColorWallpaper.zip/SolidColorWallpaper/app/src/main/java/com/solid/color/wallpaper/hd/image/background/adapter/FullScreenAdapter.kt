package com.solid.color.wallpaper.hd.image.background.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import com.scribble.animation.maker.video.effect.myadslibrary.fargments.ImageFragment
import java.util.*

class FullScreenAdapter(fm: FragmentManager?, private val mList: ArrayList<String>) : FragmentStatePagerAdapter(fm!!) {
    override fun getItem(position: Int): Fragment {
        return ImageFragment.getInstance(mList[position])
    }

    override fun getCount(): Int {
        return mList.size
    }

}