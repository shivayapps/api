package com.solid.color.wallpaper.hd.image.background.adapter

import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.ProgressBar
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.model.SavedImageModel
import java.util.*

class GallerySingleSelectableAdapter(val allUpdatedList: ArrayList<SavedImageModel>, private val mContext: Context, private val mListener: setOnItemClickListener) : RecyclerView.Adapter<GallerySingleSelectableAdapter.MyViewHolder>() {
    private var isLongPressed = false
    private var lastSelected = 0

    interface setOnItemClickListener {
        fun OnItemClickedImage(position: Int)
        fun OnLongClickImage(position: Int)
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): MyViewHolder {
        return MyViewHolder(LayoutInflater.from(mContext).inflate(R.layout.gallery_auto_wallpaper_item, null))
    }

    override fun onBindViewHolder(myViewHolder: MyViewHolder, i: Int) {
//        myViewHolder.setIsRecyclable(false)
//        myViewHolder.progressBar.visibility = View.VISIBLE
//        myViewHolder.imgColor.visibility = View.GONE
        Glide.with(mContext).load(allUpdatedList[i].path).centerCrop().override(300).into(object : CustomTarget<Drawable?>() {
            override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                myViewHolder.progressBar.visibility = View.GONE
                myViewHolder.imgColor.visibility = View.VISIBLE
                myViewHolder.imgColor.setImageDrawable(resource)
            }

            override fun onLoadCleared(placeholder: Drawable?) {
                myViewHolder.progressBar.visibility = View.VISIBLE
            }
        })
        if (isLongPressed) {
            myViewHolder.deleteCheck.visibility = View.VISIBLE
        } else {
            myViewHolder.deleteCheck.visibility = View.GONE
        }
        if (allUpdatedList[i].isDeletedEnable) {
            myViewHolder.deleteCheck.isChecked = true
        } else {
            myViewHolder.deleteCheck.isChecked = false
        }
        myViewHolder.imgColor.setOnClickListener { v: View? ->
            if (myViewHolder.deleteCheck.visibility == View.VISIBLE) {
                if (myViewHolder.deleteCheck.isChecked) {
                    myViewHolder.deleteCheck.isChecked = false
                    allUpdatedList[i].isDeletedEnable = false
                } else {
                    allUpdatedList[i].isDeletedEnable = true
                    myViewHolder.deleteCheck.isChecked = true
                    if (i != lastSelected) {
                        allUpdatedList[lastSelected].isDeletedEnable = false
                        notifyItemChanged(i)
                        notifyItemChanged(lastSelected)
                        lastSelected = i
                    }
                }
            } else {
                mListener.OnItemClickedImage(i)
                isLongPressed = true
                lastSelected = i
                for (image in allUpdatedList) {
                    image.isDeletedEnable = false
                }
                allUpdatedList[i].isDeletedEnable = true
                mListener.OnLongClickImage(i)
                notifyDataSetChanged()
            }
        }
        myViewHolder.deleteCheck.setOnClickListener { view: View? ->
            if (allUpdatedList[i].isDeletedEnable) {
                allUpdatedList[i].isDeletedEnable = false
                myViewHolder.deleteCheck.isChecked = false
            } else {
                allUpdatedList[i].isDeletedEnable = true
                myViewHolder.deleteCheck.isChecked = true
                if (i != lastSelected) {
                    allUpdatedList[lastSelected].isDeletedEnable = false
                    notifyItemChanged(i)
                    notifyItemChanged(lastSelected)
                    lastSelected = i
                }
            }
        }
    }

    fun setDataChange() {
        isLongPressed = false
        notifyDataSetChanged()
    }

    fun setDataChangeNew() {
        allUpdatedList[lastSelected].isDeletedEnable = false
        notifyItemChanged(lastSelected)
    }

    override fun getItemCount(): Int {
        return allUpdatedList.size
    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imgColor: ImageView = itemView.findViewById(R.id.imgColor)
        val progressBar: ProgressBar = itemView.findViewById(R.id.progressBar)
        val deleteCheck: CheckBox = itemView.findViewById(R.id.checkbox)

    }

}