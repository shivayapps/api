package com.solid.color.wallpaper.hd.image.background.adapter

import android.content.Context
import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs.getBoolean
import com.solid.color.wallpaper.hd.image.background.shared_pref.MySharedPref
import com.solid.color.wallpaper.hd.image.background.sqlite_database.DBHelper
import java.util.*

class FontAddTextAdapter(private val mFontNames: ArrayList<String>, private val mContext: Context, private val mListener: setOnItemClickListener, position: Int, mParam2: String) : RecyclerView.Adapter<FontAddTextAdapter.MyViewHolder>() {
    private var lastCheckedPosition = 0
    private val dbHelper: DBHelper
    private val sharedPreferences: MySharedPref
    private var mParam: String

    interface setOnItemClickListener {
        fun OnItemClicked(position: Int)
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): MyViewHolder {
        return MyViewHolder(LayoutInflater.from(mContext).inflate(R.layout.font_item_text, viewGroup, false))
    }

    override fun onBindViewHolder(myViewHolder: MyViewHolder, i: Int) {
        if (i == 19 && mFontNames.size == 20) {
            myViewHolder.imgMoreAPI.visibility = View.VISIBLE
            myViewHolder.txtFont.visibility = View.GONE
            myViewHolder.imgMoreAPI.setOnClickListener { mListener.OnItemClicked(i) }
        } else {
            myViewHolder.imgMoreAPI.visibility = View.GONE
            myViewHolder.txtFont.visibility = View.VISIBLE
            val typeface: Typeface = if (mFontNames[i].contains("fonts_neon")) {
                Typeface.createFromAsset(mContext.assets, mFontNames[i])
            } else {
                Typeface.createFromFile(mFontNames[i])
            }
            myViewHolder.txtFont.typeface = typeface
            myViewHolder.txtFont.setPadding(0, 0, 0, 0)
            myViewHolder.txtFont.text = "Hello"
            if (!dbHelper.checkPathExist(mFontNames[i]) /*&& !sharedPreferences.getAdsRemoved()*/ && !getBoolean(mContext, AdsPrefs.IS_SUBSCRIBED, false)) {
                myViewHolder.imgLock.visibility = View.VISIBLE
            } else {
                myViewHolder.imgLock.visibility = View.GONE
            }
        }
        if (mParam == mFontNames[i]) {
            myViewHolder.parentLayout.setBackgroundResource(R.drawable.rectangle_selected)
        } else {
            myViewHolder.parentLayout.setBackgroundResource(R.drawable.rectangle_unselected)
        }
        //myViewHolder.imgColor.setVisibility(View.GONE);
        myViewHolder.txtFont.setOnClickListener {
            mListener.OnItemClicked(i)
            lastCheckedPosition = i
            mParam = mFontNames[i]
            notifyDataSetChanged()
        }
    }

    override fun getItemCount(): Int {
        return mFontNames.size
    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var parentLayout: RelativeLayout = itemView.findViewById(R.id.parentLayout)
        val txtFont: TextView = itemView.findViewById(R.id.txtFont)
        val imgLock: ImageView = itemView.findViewById(R.id.imgLock)
        val imgMoreAPI: ImageView = itemView.findViewById(R.id.imgMoreAPI)

    }

    init {
        lastCheckedPosition = position
        dbHelper = DBHelper(mContext)
        sharedPreferences = MySharedPref(mContext)
        mParam = mParam2
    }
}