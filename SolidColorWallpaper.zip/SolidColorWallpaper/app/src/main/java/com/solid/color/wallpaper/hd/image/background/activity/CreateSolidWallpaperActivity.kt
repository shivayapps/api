package com.solid.color.wallpaper.hd.image.background.activity

//import com.google.android.gms.ads.rewarded.RewardedAdCallback
import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.ProgressDialog
import android.content.*
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.Uri
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.util.Base64
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.NetworkHelper
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.wifi_network.exceptions.ApiNotSupportedException
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.wifi_network.exceptions.NullWifiConfigurationException
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.wifi_network.wifi_proxy_changing_realisations.api_from_21_to_22.WifiConfiguration
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.facebook.ads.Ad
import com.facebook.ads.AdError
import com.facebook.ads.InterstitialAdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.OnUserEarnedRewardListener
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.jaredrummler.android.colorpicker.ColorPickerDialog
import com.jaredrummler.android.colorpicker.ColorPickerDialogListener
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.appid.AppIDs
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.SolidWallpaperApplication
import com.solid.color.wallpaper.hd.image.background.SolidWallpaperApplication.Companion.instance
import com.solid.color.wallpaper.hd.image.background.activity.CreateSolidWallpaperActivity
import com.solid.color.wallpaper.hd.image.background.adapter.ColorCreateAdepter
import com.solid.color.wallpaper.hd.image.background.adapter.ColorCreateAdepter.setOnItemClickListener
import com.solid.color.wallpaper.hd.image.background.adapter.EmojiImagesAdapter
import com.solid.color.wallpaper.hd.image.background.adapter.EmojiImagesAdapter.OnItemClickListener
import com.solid.color.wallpaper.hd.image.background.adapter.StickerAdapter
import com.solid.color.wallpaper.hd.image.background.adshalper.RewardVideoAds.Companion.instence
import com.solid.color.wallpaper.hd.image.background.constants.Constants
import com.solid.color.wallpaper.hd.image.background.custom.BottomSheetFragment
import com.solid.color.wallpaper.hd.image.background.custom.BottomSheetFragmentDiscard
import com.solid.color.wallpaper.hd.image.background.custom.MatrixClonable
import com.solid.color.wallpaper.hd.image.background.fragment.BottomsheetForgroundFragment
import com.solid.color.wallpaper.hd.image.background.fragment.BottomsheetStickerFragment
import com.solid.color.wallpaper.hd.image.background.imagePicker.ui.imagepicker.ImagePicker
import com.solid.color.wallpaper.hd.image.background.model.*
import com.solid.color.wallpaper.hd.image.background.model.StickerModel
import com.solid.color.wallpaper.hd.image.background.model.api.DataItem
import com.solid.color.wallpaper.hd.image.background.model.api.ImageItem
import com.solid.color.wallpaper.hd.image.background.model.api.Response
import com.solid.color.wallpaper.hd.image.background.newModel.ImagesItem
import com.solid.color.wallpaper.hd.image.background.newModel.WallpaperWeekModelNewResponse
import com.solid.color.wallpaper.hd.image.background.retrofit.APIClient.client
import com.solid.color.wallpaper.hd.image.background.retrofit.APIInterface
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs.getBoolean
import com.solid.color.wallpaper.hd.image.background.shared_pref.MySharedPref
import com.solid.color.wallpaper.hd.image.background.sqlite_database.DBHelper
import com.solid.color.wallpaper.hd.image.background.sqlite_database.DBHelperResolution
import com.willy.ratingbar.ScaleRatingBar
import com.xiaopo.flying.sticker.*
import com.xiaopo.flying.sticker.StickerView.OnStickerOperationListener
import retrofit2.Call
import retrofit2.Callback
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.lang.reflect.InvocationTargetException
import java.util.*

class CreateSolidWallpaperActivity constructor() : AppCompatActivity(), View.OnClickListener, ColorPickerDialogListener {
    private var imgEmoji: ImageView? = null
    private var icBack: ImageView? = null
    private var btnNext: ImageView? = null
    private var btnSticker:ImageView?=null
    private var txtSticker:TextView?=null
    private var layoutColor: LinearLayout? = null
    private var layoutOpacity: LinearLayout? = null
    private var layoutStickerColor: LinearLayout? = null
    private var layoutSticker: LinearLayout? = null
    private var bottomLayout: LinearLayout? = null
    private var mainBottomlayoutSelect: LinearLayout? = null
    private var layoutImage: LinearLayout? = null
    private var imgColor: CardView? = null
    private var mImageList: ArrayList<String>? = null
    private var mStickerList: ArrayList<String>? = null
    private var recyclerColor: RecyclerView? = null
    private var recyclerEmojiImage: RecyclerView? = null
    private var layoutEmojiRecycler: ConstraintLayout? = null
    private var layoutColorRecycler: ConstraintLayout? = null
    private var imgNoneColor: ImageView? = null
    private var imgGallery: ImageView? = null
//    private var cradientCancel: LinearLayout? = null
    private var layoutEmojiMoreAPI: LinearLayout? = null
    private var layoutNoneEmoji: LinearLayout? = null
    private var seekBarOpacity: SeekBar? = null
    private var mColors: ArrayList<Int>? = null
    private var isimageSelect: Boolean = false
    lateinit var stickerFragment: BottomsheetStickerFragment
    var forgroundFragment: BottomsheetForgroundFragment? = null

    var bottomSheetFragment:BottomSheetFragmentDiscard?=null

    //    private var layoutRecycler: RelativeLayout? = null
    private var mSelectedEmojiPosition: Int = -1
    private var mSelectedColor: Int = Color.WHITE
    private var opacity: Float = 1f
    private var emojiOpacity: Float = 1f
    private var lastpos: Int = 0
    private var progressBar: ProgressDialog? = null
    private var LayoutseekBarOpacity: LinearLayout? = null
    private var isEmojiSelected: Boolean = false
    private var isStickerSelected: Boolean = false
    private var isColorSelected: Boolean = false
    private var selectedColor: Int = Color.parseColor("#EBEBEB")
    private var isPrgressed: Boolean = false
    private var recyclerSticker: RecyclerView? = null
    private var layoutStickerRecycler: ConstraintLayout? = null
    private var layoutMoreAPI: LinearLayout? = null
    private var layoutNoneSticker: LinearLayout? = null
    private var sticker_view: StickerView? = null
    private var mSelectedSticker: DrawableSticker? = null
    private var colorView: View? = null
    private var adapter: EmojiImagesAdapter? = null
    private var txtHeader: TextView? = null
    private var colorAdepter: ColorCreateAdepter? = null
    private var isColorOpen: Boolean = false
    private var isOpacityOpen: Boolean = false
    private var mForegroundList: ArrayList<ImageItem>? = null
    private var mDataListNew: ArrayList<DataItem>? = null
    private var mSelectedEmojiPath: String? = null
    private var mySharedPref: MySharedPref? = null
    private var btnColorLayout: LinearLayout? = null
    private var imgForGallery: LinearLayout? = null
    private var btnNon: LinearLayout? = null
    private var receiver: Receiver? = null

    //new
    private var layoutMenu:LinearLayout?=null
    private var layoutColors:ConstraintLayout?=null

    //   private RewardedAd gameOverRewardedAd, gameOverRewardedAd2, gameOverRewardedAd3;
    private var dbHelper: DBHelper? = null
    private var stickerAdapter: StickerAdapter? = null
    private var mScreenModelList: ArrayList<ScreenModel>? = null
    private var mStickerModelList: ArrayList<StickerNewModel>? = null
    private var mAllStickers: ArrayList<StickerModel>? = null
    private var emojiPath: String? = null

    private var mDataListNewResponse: ArrayList<com.solid.color.wallpaper.hd.image.background.newModel.DataItem>? = null
    private var mForegroundListNewResponse: ArrayList<ImagesItem?>? = null
    private var mDataListNewResponseMain: ArrayList<com.solid.color.wallpaper.hd.image.background.newModel.DataItem>? = null
    private var mAllReadyDataNewResponse: ArrayList<ArrayList<WallpaperWeekModelNewResponse?>>? = null
    private var mAllReadyDataStickerNewResponse: ArrayList<ArrayList<WallpaperWeekModelNewResponse?>>? = null

    private var mAllReadyData: ArrayList<ArrayList<WallpaperWeekModel?>>? = null
    private var mAllReadyDataSticker: ArrayList<ArrayList<WallpaperWeekModel?>>? = null
    private var categoryNameList: ArrayList<CategoryNameIconModel>? = null
    private var categoryNameListSticker: ArrayList<CategoryNameIconModel>? = null


    private var isMoreAPIClicked: Boolean = false
    private lateinit var verticalView: View
    private lateinit var horizontalView: View

    private var isMoreAPIScreenClicked: Boolean = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_solid_wallpaper)
        System.gc()
        receiver = Receiver()

        mySharedPref = MySharedPref(this)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted
            startActivity(Intent(this@CreateSolidWallpaperActivity, MainStartActivity::class.java))
            finish()
        } else {
            initViews()
            initViewAction()
            initListner()
//            onStickerChange()
        }
        registerReceiver(receiver, IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"))
    }

    private fun initListner() {
        btnNon!!.setOnClickListener(this)
        layoutOpacity!!.setOnClickListener(this)
//        cradientCancel!!.setOnClickListener(this)
        layoutImage!!.setOnClickListener(this)
        layoutStickerColor!!.setOnClickListener(this)
        layoutColor!!.setOnClickListener(this)
        icBack!!.setOnClickListener(this)
        btnNext!!.setOnClickListener(this)
        layoutSticker!!.setOnClickListener(this)
        bottomLayout!!.setOnClickListener(this)
        mainBottomlayoutSelect!!.setOnClickListener(this)
        layoutMoreAPI!!.setOnClickListener(this)
        layoutNoneSticker!!.setOnClickListener(this)
        layoutEmojiMoreAPI!!.setOnClickListener(this)
        btnColorLayout!!.setOnClickListener(this)
        layoutNoneEmoji!!.setOnClickListener(this)
        imgNoneColor!!.setOnClickListener(this)
        imgForGallery!!.setOnClickListener(this)
        layoutMenu!!.setOnClickListener(this)
    }

    private fun initViewAction() {
        layoutColor!!.alpha = 0.5f
        layoutImage!!.alpha = 0.5f
        layoutOpacity!!.alpha = 0.5f
        layoutSticker!!.alpha = 0.5f
        layoutStickerColor!!.alpha =0.5f
        btnColorLayout!!.alpha=0.5f
        imgForGallery!!.alpha=0.5f

        layoutMenu!!.alpha=0.5f
        mAllStickers = ArrayList()
        mySharedPref = MySharedPref(this@CreateSolidWallpaperActivity)
        Constants.mGalleryBitmap = null
        /*     if (!mySharedPref.getAdsRemoved()) {
            //  loadInterstialAd();
        }*/
        dbHelper = DBHelper(this@CreateSolidWallpaperActivity)
        if (!getBoolean(this@CreateSolidWallpaperActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
            /*  gameOverRewardedAd = createAndLoadRewardedAd(getResources().getString(R.string.rewarded_ad_id));
            gameOverRewardedAd2 = createAndLoadRewardedAd(getResources().getString(R.string.rewarded_ad_id));
            gameOverRewardedAd3 = createAndLoadRewardedAd(getResources().getString(R.string.rewarded_ad_id));*/
            Constants.isInstrastial1 = false
            loadInterstialAd()
//            loadInterstialAdFb()
            if (isNetworkConnected()) {
                try {
                    if (instance != null) {
                        instence!!.loadVideoAdMain(this@CreateSolidWallpaperActivity)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }

            }
        }
        mForegroundList = ArrayList()
        mDataListNew = ArrayList()
        mDataListNewResponseMain = ArrayList()
        mDataListNewResponse = ArrayList()
        mForegroundListNewResponse = ArrayList()

        try {
            checkStatus()
        } catch (e: InvocationTargetException) {
            e.printStackTrace()
        } catch (e: NoSuchMethodException) {
            e.printStackTrace()
        } catch (e: ApiNotSupportedException) {
            e.printStackTrace()
        } catch (e: NoSuchFieldException) {
            e.printStackTrace()
        } catch (e: IllegalAccessException) {
            e.printStackTrace()
        } catch (e: NullWifiConfigurationException) {
//            callApi()
            callNewApi()
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        Constants.SOLID_CREATE_SELECTED_EMOJI_IMAGE = null
        Constants.SOLID_CREATE_SELECTED_EMOJI_IMAGE_COLOR = -1
        Constants.SOLID_CREATE_OPACITY = 1f
        MyEmojiList().execute()
        setStatusbarColor()
        val d: Drawable = CreateGradientWallpaperActivity.Companion.changeDrawableColor(this, R.drawable.ic_back_, resources.getColor(R.color.text_colour_new))
        icBack!!.setImageDrawable(d)

        //  fetchEmojiImages();
        fetchColors()
        seekBarOpacity!!.max = 255
        seekBarOpacity!!.progress = 255
        seekBarOpacity!!.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            public override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                if (isEmojiSelected || isStickerSelected) {
                    opacity = seekBar.progress.toFloat() / 255
                    if (opacity > 0.15f) {
                        emojiOpacity = opacity
                        imgEmoji!!.alpha = seekBar.progress.toFloat() / 255
                        Constants.SOLID_CREATE_OPACITY = opacity
                    }
                    if (progress > 25) {
                        if (mSelectedSticker != null) {
                            mSelectedSticker!!.alpha = progress
                            sticker_view!!.invalidate()
                        }
                    }
                } else {
                    Toast.makeText(this@CreateSolidWallpaperActivity, getResources().getString(R.string.toast_select_wallpaper_design_first), Toast.LENGTH_SHORT).show()
                    oncliEmoji()
                }
            }

            public override fun onStartTrackingTouch(seekBar: SeekBar) {}
            public override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })

        // openEmojiList();
        openColorList()
        if (Constants.isFromFrag) {
            layoutColor!!.visibility = View.GONE
            txtHeader!!.text = resources.getString(R.string.edit)
            colorView!!.setBackgroundColor(Constants.selectedWallpaper!!.color)
            btnNext!!.alpha = 1f
//            layoutColor!!.alpha = 0.5f
//            layoutImage!!.alpha = 0.5f
//            layoutOpacity!!.alpha = 0.5f
//            layoutSticker!!.alpha = 0.5f
//            layoutStickerColor!!.alpha = 0.5f
//            btnColorLayout!!.alpha=0.5f
//            imgForGallery!!.alpha=0.5f
            btnNext!!.isEnabled = true
            isColorSelected = true
            selectedColor = Constants.selectedWallpaper!!.color
            Constants.SOLID_CREATE_SELECTED_COLOR = Constants.selectedWallpaper!!.color
            isPrgressed = true
//            oncliEmoji()
            onclickMenu()
        } else {
            layoutColor!!.visibility = View.VISIBLE
            txtHeader!!.text = resources.getString(R.string.create)
            btnNext!!.isEnabled = false
            btnNext!!.alpha = 0.5f
//            layoutColor!!.alpha = 0.5f
//            layoutImage!!.alpha = 0.5f
//            layoutOpacity!!.alpha = 0.5f
//            layoutSticker!!.alpha = 0.5f
//            layoutStickerColor!!.alpha = 0.5f
//            btnColorLayout!!.alpha=0.5f
//            imgForGallery!!.alpha=0.5f
            //Open By Default Add Menu
            onclickMenu()
            onClick(mainBottomlayoutSelect as View)
        }
        addIcon()
        onStickerChange()

    }


    private val dataForegroundNewResponse: Unit
        private get() {

            for (i in mDataListNewResponse!!.indices) {
                if (mDataListNewResponse!!.get(i)!!.id == 4) {
                    mForegroundListNewResponse!!.addAll((mDataListNewResponse!!.get(i).images!!))
                }
            }

            var mTempForgroundList: ArrayList<WallpaperWeekModelNewResponse?>

            mAllReadyDataNewResponse = ArrayList()
            mAllReadyDataStickerNewResponse = ArrayList()
            if (mDataListNewResponseMain!!.size == 0) {
                return
            }
            categoryNameList = ArrayList()
            categoryNameListSticker = ArrayList()


            for (i in mDataListNewResponseMain!!.indices) {
                mForegroundListNewResponse!!.clear()
                if (mDataListNewResponseMain!![i].name!! == "Screen") {

                    for (j in mDataListNewResponseMain!![i].allChilds!!.indices){
                        Log.e("TAG", "assaasdasadsas: ${mDataListNewResponseMain!![i].allChilds?.get(j)!!.name} ${mDataListNewResponseMain!![i].allChilds?.get(j)!!.icon}   ")
                        categoryNameList!!.add(CategoryNameIconModel(mDataListNewResponseMain!![i].allChilds?.get(j)!!.name!!, mDataListNewResponseMain!![i].allChilds?.get(j)!!.icon.toString()))
                        mForegroundListNewResponse!!.addAll((mDataListNewResponseMain!![i].allChilds?.get(j)!!.images)!!)

                    }




                    val mWallpaperList1: ArrayList<WallpaperWeekModelNewResponse?> = ArrayList()
                    for (j in mForegroundListNewResponse!!.indices) {
                        mWallpaperList1.add(
                                WallpaperWeekModelNewResponse(
                                        mForegroundListNewResponse!![j],
                                        mForegroundListNewResponse!![j]!!.isPremium != 0,
                                        mForegroundListNewResponse!![j]!!.coins!!
                                )
                        )
                    }



                    Log.e("TAG", "asqwasqw:${mDataListNewResponseMain!![i].allChilds?.get(i)!!.name!!} = ${mDataListNewResponseMain!![i].icon} ")
                    Log.e("TAG", "asqwasaaaqw:${mDataListNewResponseMain!![i].allChilds?.get(i)!!.images} ")

                    mTempForgroundList = ArrayList()

                    if (getBoolean(this, AdsPrefs.IS_SUBSCRIBED, false)) {
                        for (j in mWallpaperList1.indices) {
                            mWallpaperList1[j]!!.isLocked = false
                        }
                        mTempForgroundList.addAll(mWallpaperList1)
                    } else {
                        for (k in mWallpaperList1.indices) {
                            val model: WallpaperWeekModelNewResponse? = mWallpaperList1[k]
                            if (dbHelper!!.checkPathExist((model!!.imageItem!!.image)!!)) {
                                model.isLocked = false
                            }
                            mTempForgroundList.add(model)
                        }
                    }
                    mTempForgroundList.shuffle()
                    mAllReadyDataNewResponse!!.add(mTempForgroundList)
                }else if (mDataListNewResponseMain!![i].name!! == "Sticker"){


                    for (j in mDataListNewResponseMain!![i].allChilds!!.indices){
                        Log.e("TAG", "assaasdasadsas: ${mDataListNewResponseMain!![i].allChilds?.get(j)!!.name} ${mDataListNewResponseMain!![i].allChilds?.get(j)!!.icon}   ")
                        categoryNameListSticker!!.add(CategoryNameIconModel(mDataListNewResponseMain!![i].allChilds?.get(j)!!.name!!, mDataListNewResponseMain!![i].allChilds?.get(j)!!.icon.toString()))
                        mForegroundListNewResponse!!.addAll((mDataListNewResponseMain!![i].allChilds?.get(j)!!.images)!!)

                    }

                    val mWallpaperList1: ArrayList<WallpaperWeekModelNewResponse?> = ArrayList()
                    for (j in mForegroundListNewResponse!!.indices) {
                        mWallpaperList1.add(
                                WallpaperWeekModelNewResponse(
                                        mForegroundListNewResponse!![j],
                                        mForegroundListNewResponse!![j]!!.isPremium != 0,
                                        mForegroundListNewResponse!![j]!!.coins!!
                                )
                        )
                    }

                    mTempForgroundList = ArrayList()

                    if (getBoolean(this@CreateSolidWallpaperActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                        for (j in mWallpaperList1.indices) {
                            mWallpaperList1[j]!!.isLocked = false
                        }
                        mTempForgroundList.addAll(mWallpaperList1)
                    } else {
                        for (k in mWallpaperList1.indices) {
                            val model: WallpaperWeekModelNewResponse? = mWallpaperList1[k]
                            if (dbHelper!!.checkPathExist((model!!.imageItem!!.image)!!)) {
                                model.isLocked = false
                            }
                            mTempForgroundList.add(model)
                        }
                    }
                    mTempForgroundList.shuffle()
                    mAllReadyDataStickerNewResponse!!.add(mTempForgroundList)

                }

            }

        }



    private val dataForeground: Unit
        private get() {
            var mTempForgroundList: ArrayList<WallpaperWeekModel?>
            mAllReadyData = ArrayList()
            mAllReadyDataSticker = ArrayList()
            if (mDataListNew!!.size == 0) {
                return
            }
            categoryNameList = ArrayList()
            categoryNameListSticker = ArrayList()
            for (i in mDataListNew!!.indices) {
                mForegroundList!!.clear()
                mForegroundList!!.addAll((mDataListNew!![i].image)!!)
                val mWallpaperList1: ArrayList<WallpaperWeekModel?> = ArrayList()
                for (j in mForegroundList!!.indices) {
                    mWallpaperList1.add(WallpaperWeekModel(mForegroundList!![j], mForegroundList!![j].isPremium != 0, mForegroundList!![j].coins))
                }
                // TODO: 29/02/20 For Screen
                if (mDataListNew!![i].name!!.contains("_Screen")) {
                    val name: Array<String> = mDataListNew!![i].name!!.split("_".toRegex()).toTypedArray()
                    if (name.isEmpty()) {
                        categoryNameList!!.add(CategoryNameIconModel((mDataListNew!![i].name)!!, mDataListNew!![i].icon.toString()))
                    } else {
                        categoryNameList!!.add(CategoryNameIconModel(name[name.size - 1], mDataListNew!![i].icon.toString()))
                    }
                    mTempForgroundList = ArrayList()
                    if (getBoolean(this@CreateSolidWallpaperActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                        for (j in mWallpaperList1.indices) {
                            mWallpaperList1[j]!!.isLocked = false
                        }
                        mTempForgroundList.addAll(mWallpaperList1)
                    } else {
                        for (k in mWallpaperList1.indices) {
                            val model: WallpaperWeekModel? = mWallpaperList1[k]
                            if (dbHelper!!.checkPathExist((model!!.imageItem!!.image)!!)) {
                                model.isLocked = false
                            }
                            mTempForgroundList.add(model)
                        }
                    }
                    mTempForgroundList.shuffle()
                    mAllReadyData!!.add(mTempForgroundList)
                } else if (mDataListNew!!.get(i).name!!.contains("_Sticker")) {
                    // TODO: 29/02/20 For Sticker
                    val name: Array<String> = mDataListNew!![i].name!!.split("_".toRegex()).toTypedArray()
                    if (name.isEmpty()) {
                        categoryNameListSticker!!.add(CategoryNameIconModel((mDataListNew!![i].name)!!, mDataListNew!![i].icon.toString()))
                    } else {
                        categoryNameListSticker!!.add(CategoryNameIconModel(name[name.size - 1], mDataListNew!![i].icon.toString()))
                    }
                    mTempForgroundList = ArrayList()
                    if (getBoolean(this@CreateSolidWallpaperActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                        for (j in mWallpaperList1.indices) {
                            mWallpaperList1[j]!!.isLocked = false
                        }
                        mTempForgroundList.addAll(mWallpaperList1)
                    } else {
                        for (k in mWallpaperList1.indices) {
                            val model: WallpaperWeekModel? = mWallpaperList1[k]
                            if (dbHelper!!.checkPathExist((model!!.imageItem!!.image)!!)) {
                                model.isLocked = false
                            }
                            mTempForgroundList.add(model)
                        }
                    }
                    mTempForgroundList.shuffle()
                    mAllReadyDataSticker!!.add(mTempForgroundList)
                }
            }
        }

    @Throws(InvocationTargetException::class, NoSuchMethodException::class, ApiNotSupportedException::class, NoSuchFieldException::class, IllegalAccessException::class, NullWifiConfigurationException::class)
    private fun checkStatus() {
        if (!NetworkHelper.isOnline(this)) {
            mForegroundList!!.clear()
        } else {
            if (NetworkHelper.isWifiConnected(this)) {
                val proxy: WifiConfiguration = WifiConfiguration(this)
                if (proxy.isProxySetted) {
                    mForegroundList!!.clear()
                    return
                }
            }
            if (NetworkHelper.isVpnRunning()) {
                mForegroundList!!.clear()
                return
            }
//            callApi()
            callNewApi()
        }
    }

    fun callApi() {
        val apiInterface: APIInterface = client!!.create(APIInterface::class.java)
        val call: Call<Response?>? = apiInterface.doGetListResources()
        call!!.enqueue(object : Callback<Response?> {
            public override fun onResponse(call: Call<Response?>, response: retrofit2.Response<Response?>) {
                val model: Response? = response.body()
                mDataListNew!!.clear()
                mForegroundList!!.clear()
                if (model?.data != null) {
                    mDataListNew!!.addAll(model.data)
                    dataForeground
                }
            }

            public override fun onFailure(call: Call<Response?>, t: Throwable) {
                mForegroundList!!.clear()
            }
        })
    }


    fun callNewApi() {
        val apiInterface: APIInterface = client!!.create(APIInterface::class.java)

        val call: Call<com.solid.color.wallpaper.hd.image.background.newModel.Response?>? = apiInterface.doGetNewListResources()
        call!!.enqueue(object : Callback<com.solid.color.wallpaper.hd.image.background.newModel.Response?> {
            public override fun onResponse(call: Call<com.solid.color.wallpaper.hd.image.background.newModel.Response?>, response: retrofit2.Response<com.solid.color.wallpaper.hd.image.background.newModel.Response?>) {
                val model: com.solid.color.wallpaper.hd.image.background.newModel.Response? = response.body()
                mDataListNewResponse!!.clear()
                mDataListNewResponseMain!!.clear()
                mForegroundListNewResponse!!.clear()
                if (model?.data != null) {
                    mDataListNewResponse!!.addAll(model.data)
                    mDataListNewResponseMain!!.addAll(model.data)
                    dataForegroundNewResponse
                }
            }

            public override fun onFailure(call: Call<com.solid.color.wallpaper.hd.image.background.newModel.Response?>, t: Throwable) {
                mForegroundListNewResponse!!.clear()
            }
        })
    }

    private fun setStatusbarColor() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = Color.WHITE
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = Color.WHITE
        }
    }

    private fun fetchColors() {
        mColors = ArrayList()
        val allColors: Array<String> = resources.getStringArray(R.array.colors_text)
        for (allColor: String in allColors) {
            mColors!!.add(Color.parseColor(allColor))
        }
    }

    private fun initViews() {
        imgColor = findViewById(R.id.imgColor)
        verticalView = findViewById(R.id.verticalView)
        horizontalView = findViewById(R.id.horizontalView)
//        cradientCancel = findViewById(R.id.cradientCancel)
        imgColor!!.setCardBackgroundColor(Color.parseColor("#EBEBEB"))
        recyclerColor = findViewById(R.id.recyclerColor)
        layoutColorRecycler = findViewById(R.id.layoutColorRecycler)
        recyclerEmojiImage = findViewById(R.id.recyclerEmojiImage)
        layoutEmojiRecycler = findViewById(R.id.layoutEmojiRecycler)
        seekBarOpacity = findViewById(R.id.seekBarOpacity)
        imgGallery = findViewById(R.id.imgGallery)
        btnNon = findViewById(R.id.btnNon)

//        layoutRecycler = findViewById(R.id.layoutRecycler)
        imgEmoji = findViewById(R.id.imgEmoji)
        icBack = findViewById(R.id.icBack)
        LayoutseekBarOpacity = findViewById(R.id.LayoutseekBarOpacity)
        btnNext = findViewById(R.id.btnNext)
        recyclerSticker = findViewById(R.id.recyclerSticker)
        layoutStickerRecycler = findViewById(R.id.layoutStickerRecycler)
        layoutNoneSticker = findViewById(R.id.layoutNoneSticker)
        layoutMoreAPI = findViewById(R.id.layoutMoreAPI)
        sticker_view = findViewById(R.id.sticker_view)
        colorView = findViewById(R.id.colorView)
        layoutColor = findViewById(R.id.layoutColor)
        bottomLayout = findViewById(R.id.bottomLayout)
        mainBottomlayoutSelect = findViewById(R.id.mainBottomlayoutSelect)
        txtHeader = findViewById(R.id.txtHeader)
        layoutImage = findViewById(R.id.layoutImage)
        layoutOpacity = findViewById(R.id.layoutOpacity)
        layoutStickerColor = findViewById(R.id.layoutStickerColor)
        layoutSticker = findViewById(R.id.layoutSticker1)
        layoutNoneEmoji = findViewById(R.id.layoutNoneEmoji)
        layoutEmojiMoreAPI = findViewById(R.id.layoutEmojiMoreAPI)
        imgNoneColor = findViewById(R.id.imgNoneColor)
        imgForGallery = findViewById(R.id.imgForGallery)
        btnColorLayout = findViewById(R.id.btnColorLayout)

        btnSticker=findViewById(R.id.btnSticker)
        txtSticker=findViewById(R.id.txtSticker)

        layoutMenu=findViewById(R.id.layoutMenu)
        layoutColors=findViewById(R.id.layoutColors)

    }

    fun addIcon() {
        val deleteIcon: BitmapStickerIcon = BitmapStickerIcon(ContextCompat.getDrawable(this,
                com.xiaopo.flying.sticker.R.drawable.sticker_ic_close_white_18dp),
                BitmapStickerIcon.LEFT_TOP, getResources().getDimension(R.dimen._12sdp))
        deleteIcon.iconEvent = DeleteIconEvent()
        val zoomIcon: BitmapStickerIcon = BitmapStickerIcon(ContextCompat.getDrawable(this,
                com.xiaopo.flying.sticker.R.drawable.sticker_ic_scale_white_18dp),
                BitmapStickerIcon.RIGHT_BOTOM, getResources().getDimension(R.dimen._12sdp))
        zoomIcon.iconEvent = ZoomIconEvent()
        val flipIcon: BitmapStickerIcon = BitmapStickerIcon(ContextCompat.getDrawable(this,
                com.xiaopo.flying.sticker.R.drawable.sticker_ic_flip_white_18dp),
                BitmapStickerIcon.RIGHT_TOP, getResources().getDimension(R.dimen._12sdp))
        flipIcon.iconEvent = FlipHorizontallyEvent()
        sticker_view!!.icons = Arrays.asList(deleteIcon, zoomIcon, flipIcon)
        sticker_view!!.setBackgroundColor(Color.TRANSPARENT)
        sticker_view!!.isLocked = false
        sticker_view!!.isConstrained = true
    }

    private fun onStickerChange() {
        sticker_view!!.onStickerOperationListener = object : OnStickerOperationListener {
            public override fun onStickerAdded(sticker: Sticker) {
                isStickerSelected = true
                isEmojiSelected = false
                mSelectedSticker = sticker as DrawableSticker?
                seekBarOpacity!!.progress = 255
                colorAdepter!!.setColor(Color.WHITE)
                //  btnNext.setAlpha(1f);
                //  btnNext.setEnabled(true);
                addIcon()
            }

            public override fun onStickerClicked(sticker: Sticker) {
                if (verticalView.visibility.equals(View.VISIBLE)) {
                    verticalView.visibility = View.GONE
                }
                if (horizontalView.visibility.equals(View.VISIBLE)) {
                    horizontalView.visibility = View.GONE
                }
            }

            public override fun onStickerDeleted(sticker: Sticker) {
                isEmojiSelected = false
                adapter!!.setSelectedPosition(-1)
                emojiPath = null
                mSelectedEmojiPosition = -1
                imgEmoji!!.setImageDrawable(null)

                if (sticker_view!!.stickers.size == 0) {
                    isStickerSelected = false
                }
                if (layoutOpacity!!.alpha == 1f) {
                    isOpacityOpen = true
                    isColorOpen = false
                    layoutColor!!.alpha = 0.5f
                    layoutImage!!.alpha = 0.5f
                    layoutOpacity!!.alpha = 0.5f
                    layoutSticker!!.alpha = 0.5f
                    layoutStickerColor!!.alpha = 0.5f
                    layoutMenu!!.alpha=0.5f
//                    layoutRecycler!!.visibility = View.INVISIBLE
                    layoutStickerRecycler!!.visibility = View.GONE
                    layoutColorRecycler!!.visibility = View.GONE
                    layoutEmojiRecycler!!.visibility = View.GONE
                    LayoutseekBarOpacity!!.visibility = View.GONE
                    layoutColors!!.visibility=View.GONE
                }
                if (layoutStickerColor!!.alpha == 1f) {
                    isColorOpen = true
                    isOpacityOpen = false
                    layoutColor!!.alpha = 0.5f
                    layoutImage!!.alpha = 0.5f
                    layoutOpacity!!.alpha = 0.5f
                    layoutSticker!!.alpha = 0.5f
                    layoutStickerColor!!.alpha = 0.5f
                    layoutMenu!!.alpha=0.5f
//                    layoutRecycler!!.visibility = View.INVISIBLE
                    layoutStickerRecycler!!.visibility = View.GONE
                    layoutColorRecycler!!.visibility = View.GONE
                    layoutEmojiRecycler!!.visibility = View.GONE
                    LayoutseekBarOpacity!!.visibility = View.GONE
                    layoutColors!!.visibility=View.GONE
                }
            }

            public override fun onStickerDragFinished(sticker: Sticker) {
                verticalView.visibility = View.GONE
                horizontalView.visibility = View.GONE
            }

            override fun onStickerDrag(sticker: Sticker) {
                verticalView.visibility = View.VISIBLE
                horizontalView.visibility = View.VISIBLE
            }

            public override fun onStickerTouchedDown(sticker: Sticker) {
                if (sticker is DrawableSticker) {
                    addIcon()
                    mSelectedSticker = sticker
                    seekBarOpacity!!.progress = mSelectedSticker!!.alphaS
                    colorAdepter!!.setColor(sticker.color)
                    if (isColorOpen) {
                        onclickBrush()
                    } else if (isOpacityOpen) {
                        onclickOpacity()
                    }
                }
            }

            public override fun onStickerZoomFinished(sticker: Sticker) {}
            public override fun onStickerFlipped(sticker: Sticker) {}
            public override fun onStickerDoubleTapped(sticker: Sticker) {}
            public override fun onStickerEditClick(sticker: Sticker) {}
            public override fun onStickerReleased() {
                if (!isEmojiSelected && layoutOpacity!!.alpha == 1f) {
                    isOpacityOpen = true
                    isColorOpen = false
                    layoutColor!!.alpha = 0.5f
                    layoutImage!!.alpha = 0.5f
                    layoutOpacity!!.alpha = 0.5f
                    layoutSticker!!.alpha = 0.5f
                    layoutStickerColor!!.alpha = 0.5f
                    layoutMenu!!.alpha=0.5f
//                    layoutRecycler!!.visibility = View.INVISIBLE
                    layoutStickerRecycler!!.visibility = View.GONE
                    layoutColorRecycler!!.visibility = View.GONE
                    layoutEmojiRecycler!!.visibility = View.GONE
                    LayoutseekBarOpacity!!.visibility = View.GONE
                    layoutColors!!.visibility=View.GONE
                }
                if (!isEmojiSelected && layoutStickerColor!!.alpha == 1f) {
                    isColorOpen = true
                    isOpacityOpen = false
                    layoutColor!!.alpha = 0.5f
                    layoutImage!!.alpha = 0.5f
                    layoutOpacity!!.alpha = 0.5f
                    layoutSticker!!.alpha = 0.5f
                    layoutStickerColor!!.alpha = 0.5f
                    layoutMenu!!.alpha=0.5f
//                    layoutRecycler!!.visibility = View.INVISIBLE
                    layoutStickerRecycler!!.visibility = View.GONE
                    layoutColorRecycler!!.visibility = View.GONE
                    layoutEmojiRecycler!!.visibility = View.GONE
                    LayoutseekBarOpacity!!.visibility = View.GONE
                    layoutColors!!.visibility=View.GONE
                }
            }
        }
    }

    public override fun onClick(v: View) {
        when (v.getId()) {
            R.id.layoutColor -> {
//                layoutRecycler!!.visibility = View.GONE
                layoutColorRecycler!!.visibility = View.GONE
                layoutEmojiRecycler!!.visibility = View.GONE
                bottomLayout!!.visibility = View.GONE
                mainBottomlayoutSelect!!.visibility = View.VISIBLE
                layoutStickerRecycler!!.visibility = View.GONE
                LayoutseekBarOpacity!!.visibility = View.GONE
                imgForGallery!!.isEnabled = true
                btnColorLayout!!.isEnabled = true
                layoutColor!!.alpha = 0.5f
                layoutImage!!.alpha = 0.5f
                layoutOpacity!!.alpha = 0.5f
                layoutSticker!!.alpha = 0.5f
                layoutStickerColor!!.alpha = 0.5f
            }
//            R.id.selectGradientColor -> {
//                findViewById<LinearLayout>(R.id.llAddColorOrImage).visibility = View.GONE
//                findViewById<LinearLayout>(R.id.llSelectGradient).visibility = View.VISIBLE
//
//            }
//            R.id.cradientCancel -> {
//                onBackPressed()
//            }
            R.id.btnColorLayout -> onclickAddColor()
            R.id.imgNoneColor -> onclickNoneColor()
            R.id.layoutNoneEmoji -> onclickNoneEmoji()
            R.id.layoutEmojiMoreAPI -> if (!isMoreAPIScreenClicked) {
                isMoreAPIScreenClicked = true
                onclickMoreAPIEmoji()
            }
            R.id.layoutNoneSticker -> {
                if (isStickerSelected && isEmojiSelected) {
                    isEmojiSelected = false
                    adapter!!.setSelectedPosition(-1)
                    emojiPath = null
                    mSelectedEmojiPosition = -1
                    imgEmoji!!.setImageDrawable(null)
                }
                isStickerSelected = false
                sticker_view!!.removeAllStickers()
                sticker_view!!.invalidate()
            }
            R.id.layoutMoreAPI -> if (!isMoreAPIClicked) {
                isMoreAPIClicked = true
                onclickMoreAPISticker()
            }
            R.id.btnNon -> {
                Constants.mGalleryBitmap = null
                Constants.mGalleryUri = null
                isimageSelect = false
                isColorSelected = false
                imgGallery!!.setImageBitmap(null)

                btnColorLayout!!.alpha=0.5f

                selectedColor = Color.parseColor("#EBEBEB")
               // btnColorLayout!!.setImageDrawable(resources.getDrawable(R.drawable.ic_gradient_select))

                val shape: GradientDrawable = GradientDrawable()
                shape.shape = GradientDrawable.RECTANGLE
                shape.setColor(selectedColor)
                colorView!!.setBackgroundColor(selectedColor)
                isPrgressed = false
                imgForGallery!!.isEnabled = true
                btnColorLayout!!.isEnabled = true

                layoutColors!!.visibility=View.VISIBLE
            }

            R.id.layoutStickerColor -> onclickBrush()
            R.id.layoutImage -> oncliEmoji()
            R.id.layoutOpacity -> onclickOpacity()
            R.id.icBack -> onBackPressed()
            R.id.btnNext -> onclickNext()
            R.id.layoutSticker1 -> onclickSticker()
            R.id.imgForGallery -> onclickGallery()
            R.id.layoutMenu->onclickMenu()
        }
    }

    private fun onclickMenu() {
        layoutStickerColor!!.alpha = 0.5f
        layoutImage!!.alpha = 0.5f
        layoutOpacity!!.alpha = 0.5f
        layoutSticker!!.alpha = 0.5f
        layoutMenu!!.alpha=1f

        layoutColors!!.visibility=View.VISIBLE
        layoutColorRecycler!!.visibility = View.GONE
        layoutEmojiRecycler!!.visibility = View.GONE
        layoutStickerRecycler!!.visibility = View.GONE
        LayoutseekBarOpacity!!.visibility = View.GONE


    }

    private fun onclickBrush() {
        if (isEmojiSelected || sticker_view!!.handlingSticker != null) {
            isOpacityOpen = false
            isColorOpen = true
            layoutStickerColor!!.alpha = 1f
            layoutImage!!.alpha = 0.5f
            layoutOpacity!!.alpha = 0.5f
            layoutSticker!!.alpha = 0.5f
            layoutColor!!.alpha = 0.5f
            btnColorLayout!!.alpha=0.5f
            imgForGallery!!.alpha=0.5f
            layoutMenu!!.alpha=0.5f
//            layoutRecycler!!.visibility = View.VISIBLE
            layoutColorRecycler!!.visibility = View.VISIBLE
            layoutEmojiRecycler!!.visibility = View.GONE
            layoutStickerRecycler!!.visibility = View.GONE
            LayoutseekBarOpacity!!.visibility = View.GONE

            layoutColors!!.visibility=View.GONE
        } else {
            Toast.makeText(this, getResources().getString(R.string.toast_select_wallpaper_design_first), Toast.LENGTH_SHORT).show()
            //  oncliEmoji();
        }
    }

    private fun oncliEmoji() {
        isOpacityOpen = false
        isColorOpen = false
        layoutImage!!.alpha = 1f
        layoutColor!!.alpha = 0.5f
        layoutOpacity!!.alpha = 0.5f
        layoutSticker!!.alpha = 0.5f
        layoutStickerColor!!.alpha = 0.5f
        btnColorLayout!!.alpha=0.5f
        imgForGallery!!.alpha=0.5f
        layoutMenu!!.alpha=0.5f
//        layoutRecycler!!.visibility = View.VISIBLE
        layoutColorRecycler!!.visibility = View.GONE
        layoutEmojiRecycler!!.visibility = View.VISIBLE
        layoutStickerRecycler!!.visibility = View.GONE
        LayoutseekBarOpacity!!.visibility = View.GONE

        layoutColors!!.visibility=View.GONE

        recyclerSticker!!.scrollToPosition(0)
    }

    private fun onclickOpacity() {
        if (isEmojiSelected || sticker_view!!.handlingSticker != null) {
            isOpacityOpen = true
            isColorOpen = false
            layoutColor!!.alpha = 0.5f
            layoutImage!!.alpha = 0.5f
            layoutOpacity!!.alpha = 1f
            layoutSticker!!.alpha = 0.5f
            layoutStickerColor!!.alpha = 0.5f
            imgForGallery!!.alpha=0.5f
            btnColorLayout!!.alpha=0.5f
            layoutMenu!!.alpha=0.5f
//            layoutRecycler!!.visibility = View.VISIBLE
            layoutColorRecycler!!.visibility = View.GONE
            layoutEmojiRecycler!!.visibility = View.GONE
            layoutStickerRecycler!!.visibility = View.GONE
            LayoutseekBarOpacity!!.visibility = View.VISIBLE

            layoutColors!!.visibility=View.GONE
        } else {
            Toast.makeText(this, getResources().getString(R.string.toast_select_wallpaper_design_first), Toast.LENGTH_SHORT).show()
            // oncliEmoji();
        }
    }

    private fun onclickSticker() {
        isOpacityOpen = false
        isColorOpen = false
        layoutColor!!.alpha = 0.5f
        layoutImage!!.alpha = 0.5f
        layoutOpacity!!.alpha = 0.5f
        layoutSticker!!.alpha = 1f
//        btnSticker!!.setColorFilter(ContextCompat.getColor(this,R.color.colorSelected))
//        txtSticker!!.setTextColor(ContextCompat.getColor(this,R.color.colorSelected))
        layoutStickerColor!!.alpha = 0.5f
        btnColorLayout!!.alpha=0.5f
//        layoutSticker!!.alpha=0.5f
        layoutMenu!!.alpha=0.5f

        layoutColorRecycler!!.visibility = View.GONE
        layoutEmojiRecycler!!.visibility = View.GONE
        layoutStickerRecycler!!.visibility = View.VISIBLE
        LayoutseekBarOpacity!!.visibility = View.GONE

        layoutColors!!.visibility=View.GONE
        recyclerEmojiImage!!.scrollToPosition(0)
    }

    private fun onclickGallery() {
//        layoutColor!!.alpha = 0.5f
//        layoutImage!!.alpha = 0.5f
//        layoutOpacity!!.alpha = 0.5f
//        layoutSticker!!.alpha = 0.5f
//        layoutStickerColor!!.alpha = 0.5f
//        btnColorLayout!!.alpha=0.5f
//        imgForGallery!!.alpha=1f
//        imgForGallery!!.isEnabled = false
//        btnColorLayout!!.isEnabled = false
        ImagePicker.with(this)
                .setFolderMode(true)
                .setFolderTitle("Album")
                .setMultipleMode(false)
                .setImageCount(1)
                .setMaxSize(10)
                .setBackgroundColor("#ffffff")
                .setAlwaysShowDoneButton(true)
                .setRequestCode(1111)
                .setKeepScreenOn(true)
                .start()

//        layoutColorRecycler!!.visibility = View.GONE
//        layoutEmojiRecycler!!.visibility = View.GONE
//        layoutStickerRecycler!!.visibility = View.GONE
//        LayoutseekBarOpacity!!.visibility = View.GONE


    }

    private fun onclickAddColor() {
        layoutColor!!.alpha = 0.5f
        layoutImage!!.alpha = 0.5f
        layoutOpacity!!.alpha = 0.5f
        layoutSticker!!.alpha = 0.5f
        layoutStickerColor!!.alpha = 0.5f
        btnColorLayout!!.alpha=1f
        imgForGallery!!.alpha=0.5f
//        layoutRecycler!!.visibility = View.INVISIBLE
        imgForGallery!!.isEnabled = false
        btnColorLayout!!.isEnabled = false

        layoutColorRecycler!!.visibility = View.GONE
        layoutEmojiRecycler!!.visibility = View.GONE
        layoutStickerRecycler!!.visibility = View.GONE
        LayoutseekBarOpacity!!.visibility = View.GONE

        openColorPicker()
    }

    private fun openColorPicker() {
        ColorPickerDialog.newBuilder()
            .setDialogType(ColorPickerDialog.TYPE_PRESETS)
            .setAllowPresets(false)
            .setDialogId(0)
            .setColor(selectedColor)
            .setShowAlphaSlider(true)
            .show(this)
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1111) {
            imgForGallery!!.isEnabled = true
            btnColorLayout!!.isEnabled = true
            if (Constants.mGalleryBitmap != null) {

                try {
                    selectedColor = Color.parseColor("#EBEBEB")

                    imgGallery!!.setImageBitmap(Constants.mGalleryBitmap)
                    btnNext!!.isEnabled = true
                    btnNext!!.alpha = 1f
                    isPrgressed = true
                    isimageSelect = true
                    btnNext!!.isEnabled = true
                   // btnColorLayout!!.setImageDrawable(resources.getDrawable(R.drawable.ic_gradient_select))
                   // onClick(cradientCancel as View)
                } catch (e: Exception) {

                }

            }
        }
    }

    private fun onclickNoneColor() {
        mSelectedColor = Color.WHITE
        colorAdepter!!.setColor(mSelectedColor)
        if (mSelectedSticker != null) {
            mSelectedSticker!!.color = mSelectedColor
            sticker_view!!.invalidate()
            return
        }
        if (mSelectedEmojiPath == null) {
            Glide.with(this@CreateSolidWallpaperActivity).load(mImageList!![mSelectedEmojiPosition]).into(object : CustomTarget<Drawable?>() {
                public override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                    resource.colorFilter = PorterDuffColorFilter(mSelectedColor, PorterDuff.Mode.SRC_IN)
                    imgEmoji!!.setImageDrawable(resource)
                }

                public override fun onLoadCleared(placeholder: Drawable?) {}
            })
        } else {
            Glide.with(this@CreateSolidWallpaperActivity).load(mSelectedEmojiPath).into(object : CustomTarget<Drawable?>() {
                public override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                    resource.colorFilter = PorterDuffColorFilter(mSelectedColor, PorterDuff.Mode.SRC_IN)
                    imgEmoji!!.setImageDrawable(resource)
                }

                public override fun onLoadCleared(placeholder: Drawable?) {}
            })
        }
    }

    private fun onclickMoreAPIEmoji() {
        if (!NetworkHelper.isOnline(this)) {
            isMoreAPIScreenClicked = false
            Toast.makeText(this, getResources().getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show()
            return
        }
        if (isFinishing) {
            return
        }
        try {
            val onItemSelected: BottomsheetForgroundFragment.OnItemSelected = object : BottomsheetForgroundFragment.OnItemSelected {
                public override fun onItemSelected(path: String?) {
                    if (path != null) {
                        findViewById<ProgressBar>(R.id.proDialog).visibility = View.VISIBLE
                        isEmojiSelected = true
                        isStickerSelected = false
                        btnNext!!.isEnabled = false
                        adapter!!.setSelectedPosition(-1)
                        mSelectedColor = Color.WHITE
                        mSelectedSticker = null
                        imgEmoji!!.alpha = 1f
                        seekBarOpacity!!.progress = 255
                        emojiPath = path
                        mSelectedEmojiPath = path
                        colorAdepter!!.setColor(mSelectedColor)
                        sticker_view!!.removeAllStickers()
                        sticker_view!!.invalidate()
                        Glide.with(this@CreateSolidWallpaperActivity).load(path).into(object : CustomTarget<Drawable?>() {
                            public override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                                resource.setColorFilter(mSelectedColor, PorterDuff.Mode.SRC_IN)
                                imgEmoji!!.setImageDrawable(resource)
                                findViewById<ProgressBar>(R.id.proDialog).visibility = View.GONE
                                btnNext!!.isEnabled = true
                            }

                            public override fun onLoadCleared(placeholder: Drawable?) {}
                            override fun onLoadFailed(errorDrawable: Drawable?) {
                                super.onLoadFailed(errorDrawable)
                                findViewById<ProgressBar>(R.id.proDialog).visibility = View.GONE
                            }
                        })

                    }
                }

                 override fun onDismiss() {
                    isMoreAPIScreenClicked = false
                }
            }

            if (!NetworkHelper.isOnline(this)) {
                isMoreAPIScreenClicked = false
                Toast.makeText(this, resources.getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show()
                return
            }

            else{
                forgroundFragment = BottomsheetForgroundFragment(this, mAllReadyDataNewResponse, categoryNameList, onItemSelected)
                forgroundFragment!!.show(supportFragmentManager, "forground_frag")
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun onclickNoneEmoji() {

        isEmojiSelected = false
        adapter!!.setSelectedPosition(-1)
        emojiPath = null
        mSelectedEmojiPosition = -1
        imgEmoji!!.setImageDrawable(null)
    }

    private fun isNetworkConnected(): Boolean {
        val cm: ConnectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo()!!.isConnected()
    }

    private fun onclickMoreAPISticker() {
        Log.d("TAG", "onclickMoreAPISticker: jkhslcfnakls;d;mdfls;bvdfsfb")
        if (!isNetworkConnected()) {
            isMoreAPIClicked = false
            Toast.makeText(this, getResources().getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val onItemSelected: BottomsheetStickerFragment.OnItemSelected = object : BottomsheetStickerFragment.OnItemSelected {
                public override fun onItemSelected(path: String?) {
                    isStickerSelected = true
                    adapter!!.setSelectedPosition(-1)
                    imgEmoji!!.setImageDrawable(null)
                    mSelectedEmojiPosition = -1
                    mSelectedEmojiPath = null
                    Glide.with(this@CreateSolidWallpaperActivity).load(path).into(object : CustomTarget<Drawable?>() {
                        public override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                            mSelectedSticker = DrawableSticker(resource)
                            mSelectedSticker!!.color = Color.WHITE
                            sticker_view!!.addSticker(mSelectedSticker!!)
                            sticker_view!!.invalidate()
                        }

                        public override fun onLoadCleared(placeholder: Drawable?) {}


                    })
                }

                 override fun onDismiss() {
                    isMoreAPIClicked = false
                }
            }

            if (!isNetworkConnected()) {
                isMoreAPIClicked = false
                Toast.makeText(this, resources.getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show()
                return
            }
            else{
                stickerFragment = BottomsheetStickerFragment(this, mAllReadyDataStickerNewResponse, categoryNameListSticker, onItemSelected)
                stickerFragment.show(supportFragmentManager, "forground_frag")
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun onclickNext() {
        mySharedPref!!.countExist = mySharedPref!!.countExist + 1
        Log.d("12345", "onclickNext: Create Solid ${mySharedPref!!.countExist}")

//            if (mainBottomlayoutSelect!!.visibility == View.VISIBLE) {
//            layoutColor!!.alpha = 0.5f
//            layoutImage!!.alpha = 0.5f
//            layoutOpacity!!.alpha = 0.5f
//            layoutSticker!!.alpha = 0.5f
//            layoutStickerColor!!.alpha = 0.5f
//            imgForGallery!!.alpha=0.5f
//            btnColorLayout!!.alpha=0.5f

            findViewById<LinearLayout>(R.id.bottomLayout).visibility = View.GONE
            findViewById<LinearLayout>(R.id.mainBottomlayoutSelect).visibility = View.VISIBLE
        if (isColorSelected || isimageSelect || isStickerSelected || isEmojiSelected) {
            Constants.SOLID_CREATE_SELECTED_EMOJI_IMAGE_COLOR = mSelectedColor
            if (!isColorSelected) {
                Constants.SOLID_CREATE_SELECTED_COLOR = Color.TRANSPARENT
            }
            if (mSelectedEmojiPosition != -1) {
                Constants.SOLID_CREATE_SELECTED_EMOJI_IMAGE = mImageList!!.get(mSelectedEmojiPosition)
            } else {
                Constants.SOLID_CREATE_SELECTED_EMOJI_IMAGE = null
            }
            sticker_view!!.releaseSticker()
            verticalView.visibility = View.GONE
            horizontalView.visibility = View.GONE
            findViewById<LinearLayout>(R.id.bottomLayout).visibility = View.GONE
            findViewById<LinearLayout>(R.id.mainBottomlayoutSelect).visibility = View.VISIBLE
            Constants.mSavedBitmap = outputBitmap
            val realImage: Bitmap = outputBitmap
            val baos: ByteArrayOutputStream = ByteArrayOutputStream()
            realImage.compress(Bitmap.CompressFormat.JPEG, 100, baos)
            val b: ByteArray = baos.toByteArray()
            val encodedImage: String = Base64.encodeToString(b, Base64.DEFAULT)
            mySharedPref!!.image = encodedImage
            sticker_view!!.releaseSticker()
            mAllStickers!!.clear()
            for (i in sticker_view!!.stickers.indices) {
                emojiPath = null
                val mSticker: Sticker = sticker_view!!.stickers[i]
                var model: StickerModel?
                val sticker1: DrawableSticker = DrawableSticker(mSticker.drawable)
                sticker1.color = (mSticker as DrawableSticker).color
                sticker1.alpha = mSticker.alpha
                val matrix: MatrixClonable = MatrixClonable()
                matrix.set(mSticker.getMatrix())
                model = StickerModel(matrix, false, "", null, 0, 0, sticker1.drawable, sticker1.color, sticker1.alpha)
                mAllStickers!!.add(model)
            }
            Constants.resolutionModelGradient = GradientResolutionModel(mAllStickers, imgColor!!.width, imgColor!!.height, selectedColor, selectedColor, false, false, GradientDrawable.Orientation.BL_TR, emojiPath, mSelectedColor, emojiOpacity)
            DBHelperResolution(this@CreateSolidWallpaperActivity).insertResolutionModelGradient(Constants.resolutionModelGradient!!)
            if (!getBoolean(this@CreateSolidWallpaperActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                if (instance!!.requestNewInterstitial()) {

                    showInterstitial()
                    loadInterstialAd1()
                } else if (instance!!.requestNewInterstitialfb()) {
                    instance!!.mInterstitialAdfb!!.buildLoadAdConfig().withAdListener(object : InterstitialAdListener {
                        public override fun onError(ad: Ad, adError: AdError) {
                            startActivity(Intent(this@CreateSolidWallpaperActivity, GradientResolutionActivity::class.java))
                        }

                        public override fun onAdLoaded(ad: Ad) {
                            Log.e("TAG", "--> onAdLoaded")
                        }

                        public override fun onAdClicked(ad: Ad) {
                            Log.e("TAG", "--> onAdClicked")
                        }

                        public override fun onLoggingImpression(ad: Ad) {
                            Log.e("TAG", "--> onLoggingImpression")
                        }

                        public override fun onInterstitialDisplayed(ad: Ad) {
                            Log.e("TAG", "--> onInterstitialDisplayed")
                        }

                        public override fun onInterstitialDismissed(ad: Ad) {
                            loadInterstialAdFb()
                            startActivity(Intent(this@CreateSolidWallpaperActivity, GradientResolutionActivity::class.java))
                        }
                    })
                } else {
                    showInterstitial()
//                    startActivity(Intent(this@CreateSolidWallpaperActivity, GradientResolutionActivity::class.java))
                }
            } else {
                startActivity(Intent(this@CreateSolidWallpaperActivity, GradientResolutionActivity::class.java))
            }

        } else {
            Toast.makeText(this, getString(R.string.select_color), Toast.LENGTH_SHORT).show()
        }
    }

    private fun showFB() {
        if (!getBoolean(this@CreateSolidWallpaperActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
            if (instance!!.requestNewInterstitialfb()) {
                instance!!.mInterstitialAdfb!!.buildLoadAdConfig().withAdListener(object : InterstitialAdListener {
                    public override fun onError(ad: Ad, adError: AdError) {
                        startActivity(Intent(this@CreateSolidWallpaperActivity, GradientResolutionActivity::class.java))
                    }

                    public override fun onAdLoaded(ad: Ad) {
                        Log.e("TAG", "--> onAdLoaded")
                    }

                    public override fun onAdClicked(ad: Ad) {
                        Log.e("TAG", "--> onAdClicked")
                    }

                    public override fun onLoggingImpression(ad: Ad) {
                        Log.e("TAG", "--> onLoggingImpression")
                    }

                    public override fun onInterstitialDisplayed(ad: Ad) {
                        Log.e("TAG", "--> onInterstitialDisplayed")
                    }

                    public override fun onInterstitialDismissed(ad: Ad) {
                        startActivity(Intent(this@CreateSolidWallpaperActivity, GradientResolutionActivity::class.java))
                    }
                })
            } else {
                startActivity(Intent(this@CreateSolidWallpaperActivity, GradientResolutionActivity::class.java))
            }
        } else {
            startActivity(Intent(this@CreateSolidWallpaperActivity, GradientResolutionActivity::class.java))
        }
    }

    private fun showGoogleAdHome() {
        if (instance!!.requestNewInterstitial()) {

            instance!!.mInterstitialAd!!.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
//                    Log.d(TAG, 'Ad was dismissed.')

                    startActivity(Intent(this@CreateSolidWallpaperActivity, GradientResolutionActivity::class.java))
                }

                override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
                    super.onAdFailedToShowFullScreenContent(p0)
                    startActivity(Intent(this@CreateSolidWallpaperActivity, GradientResolutionActivity::class.java))
                }

                override fun onAdShowedFullScreenContent() {
//                    Log.d(TAG, 'Ad showed fullscreen content.')
                    instance!!.mInterstitialAd = null;
                }
            }
            instance!!.mInterstitialAd!!.show(this)
        } else {
            startActivity(Intent(this@CreateSolidWallpaperActivity, GradientResolutionActivity::class.java))
        }
    }

    // colorView.draw(canvas);
    // sticker_view.draw(canvas);
    private val outputBitmap: Bitmap
        private get() {
            imgColor!!.setCardBackgroundColor(Color.parseColor("#EBEBEB"))

            val bitmap: Bitmap = Bitmap.createBitmap(imgColor!!.width, imgColor!!.height, Bitmap.Config.ARGB_8888)
            val canvas: Canvas = Canvas(bitmap)
            // colorView.draw(canvas);
            imgColor!!.draw(canvas)
            // sticker_view.draw(canvas);
            return bitmap
        }

    private fun openEmojiList() {
        val manager: LinearLayoutManager = LinearLayoutManager(this)
        manager.orientation = RecyclerView.HORIZONTAL
        recyclerEmojiImage!!.layoutManager = manager
        Handler().postDelayed(Runnable {
            if (adapter != null) {
                adapter!!.notifyDataSetChanged()
            }
        }, 1000)
        val listener: OnItemClickListener = label@ object : OnItemClickListener {
            override fun onItemClick(view: View?, position: Int, activity: Activity) {
                if (!mScreenModelList!![position].isFree) {
                    if (!NetworkHelper.isOnline(this@CreateSolidWallpaperActivity)) {
                        Toast.makeText(this@CreateSolidWallpaperActivity, getResources().getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show()
                        return
                    }
                    if (instence != null && instence!!.checkAdLoad() == null) {
                        Toast.makeText(this@CreateSolidWallpaperActivity, getResources().getString(R.string.try_again_later), Toast.LENGTH_SHORT).show()
                        return
                    }
                    if (instence != null && instence!!.loadVideoAdMain(this@CreateSolidWallpaperActivity) != null) {
                        val rewardedAd: RewardedAd? = instence!!.loadVideoAdMain(this@CreateSolidWallpaperActivity)
                        showAdDialog(position, true, rewardedAd)
                    } else {
                        //  assert RewardVideoAds.Companion.getInstence() != null;
                        //   RewardVideoAds.Companion.getInstence().loadVideoAdMain(CreateSolidWallpaperActivity.this);
                        Toast.makeText(this@CreateSolidWallpaperActivity, getResources().getString(R.string.try_again_later), Toast.LENGTH_SHORT).show()
                    }
                } else {
                    isEmojiSelected = true
                    isStickerSelected = false
                    emojiPath = mImageList!![position]
                    mSelectedEmojiPosition = position
                    mSelectedColor = Color.WHITE
                    mSelectedSticker = null
                    if (lastpos != position) {
                        imgEmoji!!.alpha = 1f
                        seekBarOpacity!!.progress = 255
                    }
                    lastpos = position
                    mSelectedEmojiPath = null
                    colorAdepter!!.setColor(mSelectedColor)
                    sticker_view!!.removeAllStickers()
                    sticker_view!!.invalidate()
                    Glide.with(this@CreateSolidWallpaperActivity).load(mImageList!![position]).into(object : CustomTarget<Drawable?>() {
                        public override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                            resource.setColorFilter(mSelectedColor, PorterDuff.Mode.SRC_IN)
                            imgEmoji!!.setImageDrawable(resource)
                        }

                        public override fun onLoadCleared(placeholder: Drawable?) {}
                    })
                }
            }
        }
        adapter = EmojiImagesAdapter(this, (mScreenModelList)!!, listener)
        recyclerEmojiImage!!.adapter = adapter
        recyclerEmojiImage!!.post(Runnable { adapter!!.notifyDataSetChanged() })
    }

    private fun openColorList() {
        val manager: LinearLayoutManager = LinearLayoutManager(this)
        manager.orientation = RecyclerView.HORIZONTAL
        recyclerColor!!.layoutManager = manager
        val listener: setOnItemClickListener = label@ object : setOnItemClickListener {
            override fun OnItemClicked(color: Int, activity: Activity) {
                if (isEmojiSelected || isStickerSelected) {
                    mSelectedColor = color
                    if (mSelectedSticker != null) {
                        mSelectedSticker!!.color = mSelectedColor
                        sticker_view!!.invalidate()
                        return
                    }
                    if (mSelectedEmojiPath == null) {
                        Glide.with(this@CreateSolidWallpaperActivity).load(mImageList!![mSelectedEmojiPosition]).into(object : CustomTarget<Drawable?>() {
                            public override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                                resource.colorFilter = PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN)
                                imgEmoji!!.setImageDrawable(resource)
                            }

                            public override fun onLoadCleared(placeholder: Drawable?) {}
                        })
                    } else {
                        Glide.with(this@CreateSolidWallpaperActivity).load(mSelectedEmojiPath).into(object : CustomTarget<Drawable?>() {
                            public override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                                resource.colorFilter = PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN)
                                imgEmoji!!.setImageDrawable(resource)
                            }

                            public override fun onLoadCleared(placeholder: Drawable?) {}
                        })
                    }
                } else {
                    Toast.makeText(this@CreateSolidWallpaperActivity, getResources().getString(R.string.toast_select_wallpaper_design_first), Toast.LENGTH_SHORT).show()
                    oncliEmoji()
                }
            }
        }
        colorAdepter = ColorCreateAdepter((mColors)!!, this, listener)
        recyclerColor!!.adapter = colorAdepter
    }

    public override fun onColorSelected(dialogId: Int, color: Int) {
        colorView!!.setBackgroundColor(color)
        btnNext!!.alpha = 1f
        btnNext!!.isEnabled = true
        isColorSelected = true
        selectedColor = color
        Constants.SOLID_CREATE_SELECTED_COLOR = color
        isPrgressed = true
        if (Constants.mGalleryBitmap != null && !Constants.mGalleryBitmap!!.isRecycled) {
            Constants.mGalleryBitmap!!.recycle()
            Constants.mGalleryBitmap = null
        }
        imgGallery!!.setImageBitmap(null)

        val shape: GradientDrawable = GradientDrawable()
        shape.shape = GradientDrawable.RECTANGLE
        shape.setColor(color)
        shape.cornerRadius = 18f
        shape.setStroke(3, Color.BLACK)
       // btnColorLayout!!.setImageDrawable(shape)
    }

    public override fun onDialogDismissed(dialogId: Int) {
        imgForGallery!!.isEnabled = true
        btnColorLayout!!.isEnabled = true


    }

    public override fun onBackPressed() {
//           if (mainBottomlayoutSelect!!.visibility == View.VISIBLE) {
            findViewById<LinearLayout>(R.id.bottomLayout).visibility = View.GONE
            findViewById<LinearLayout>(R.id.mainBottomlayoutSelect).visibility = View.VISIBLE
            btnNext!!.isEnabled = true
//            layoutColor!!.alpha = 0.5f
//            layoutImage!!.alpha = 0.5f
//            layoutOpacity!!.alpha = 0.5f
//            layoutSticker!!.alpha = 0.5f
//            imgForGallery!!.alpha=0.5f
//            layoutStickerColor!!.alpha = 0.5f
            btnNext!!.alpha = 1f
//        } else {
            if (isPrgressed || isEmojiSelected || isStickerSelected) {
                showAlertDialog()
            } else {
                finish()
            }
//        }
    }

    @SuppressLint("StaticFieldLeak")
    internal inner class MyEmojiList constructor() : AsyncTask<Void?, Void?, Void?>() {
        override fun onPreExecute() {
            super.onPreExecute()
            progressBar = ProgressDialog(this@CreateSolidWallpaperActivity)
            progressBar!!.setMessage(getResources().getString(R.string.dialog_msg_please_wait))
            progressBar!!.setCancelable(false)
            progressBar!!.show()
        }

        override fun onPostExecute(aVoid: Void?) {
            super.onPostExecute(aVoid)
            mStickerList!!.sort()
            mImageList!!.sort()
            mStickerModelList = ArrayList()
            for (i in mStickerList!!.indices) {
                mStickerModelList!!.add(StickerNewModel(mStickerList!![i], true))
            }
            if (!getBoolean(this@CreateSolidWallpaperActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                /*for (i in mStickerList!!.indices) {
                    if ((i + 1) % 5 == 0 && !dbHelper!!.checkPathExist(mStickerList!![i])) {
                        mStickerModelList!![i].isFree = false
                    }
                }*/
            }
            mScreenModelList = ArrayList()
            for (i in mImageList!!.indices) {
                mScreenModelList!!.add(ScreenModel(mImageList!![i], true))
            }
            if (!getBoolean(this@CreateSolidWallpaperActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                /*for (i in mImageList!!.indices) {
                    if ((i + 1) % 5 == 0 && !dbHelper!!.checkPathExist(mImageList!![i])) {
                        mScreenModelList!![i].isFree = false
                    }
                }*/
            }
            openEmojiList()
            openStickerList()
            try {
                if ((progressBar != null) && progressBar!!.isShowing) {
                    progressBar!!.dismiss()
                }
            } catch (e: IllegalArgumentException) {
                // Handle or log or ignore
            } catch (e: Exception) {
                // Handle or log or ignore
            }
        }

        protected override fun doInBackground(vararg params: Void?): Void? {
            mImageList = ArrayList()
            mStickerList = ArrayList()
            try {
                val files: Array<String>? = assets.list("screen")
                assert(files != null)
                for (name: String in files!!) {
                    mImageList!!.add("file:///android_asset/screen" + File.separator + name)
                }
                val files1: Array<String>? = assets.list("stickers")
                assert(files1 != null)
                for (name: String in files1!!) {
                    mStickerList!!.add("file:///android_asset/stickers" + File.separator + name)
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
            return null
        }
    }

    private fun openStickerList() {
        val manager: LinearLayoutManager = LinearLayoutManager(this)
        manager.orientation = RecyclerView.HORIZONTAL
        recyclerSticker!!.layoutManager = manager
        val onItemClickListener: StickerAdapter.OnItemClickListener = label@ object : OnItemClickListener, StickerAdapter.OnItemClickListener {
            override fun onItemClick(view: View?, position: Int, activity: Activity) {
                //null exception in samsung tab
                if (!mStickerModelList!![position].isFree) {
                    if (!NetworkHelper.isOnline(this@CreateSolidWallpaperActivity)) {
                        Toast.makeText(this@CreateSolidWallpaperActivity, getResources().getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show()
                        return
                    }
                    if (instence != null && instence!!.checkAdLoad() == null) {
                        Toast.makeText(this@CreateSolidWallpaperActivity, getResources().getString(R.string.try_again_later), Toast.LENGTH_SHORT).show()
                        return
                    }
                    if (instence != null && instence!!.loadVideoAdMain(this@CreateSolidWallpaperActivity) != null) {
                        val rewardedAd: RewardedAd? = instence!!.loadVideoAdMain(this@CreateSolidWallpaperActivity)
                        showAdDialog(position, false, rewardedAd)
                    } else {
                        //  assert RewardVideoAds.Companion.getInstence() != null;
                        //  RewardVideoAds.Companion.getInstence().loadVideoAdMain(CreateSolidWallpaperActivity.this);
                        Toast.makeText(this@CreateSolidWallpaperActivity, getResources().getString(R.string.try_again_later), Toast.LENGTH_SHORT).show()
                    }
                } else {
                    isStickerSelected = true
                    adapter!!.setSelectedPosition(-1)
                    imgEmoji!!.setImageDrawable(null)
                    mSelectedEmojiPosition = -1
                    mSelectedEmojiPath = null
                    Glide.with(this@CreateSolidWallpaperActivity).load(mStickerList!![position]).into(object : CustomTarget<Drawable?>() {
                        public override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                            mSelectedSticker = DrawableSticker(resource)
                            mSelectedSticker!!.color = Color.WHITE
                            sticker_view!!.addSticker(mSelectedSticker!!)
                            sticker_view!!.invalidate()
                        }

                        public override fun onLoadCleared(placeholder: Drawable?) {}
                    })
                }
            }

        }
        stickerAdapter = StickerAdapter(this@CreateSolidWallpaperActivity, (mStickerModelList)!!, onItemClickListener, true)
        recyclerSticker!!.adapter = stickerAdapter
    }

    private fun showAdDialog(position: Int, isEmoji: Boolean, rewardedAd: RewardedAd?) {
        val msg: String
        if (isEmoji) {
            msg = getResources().getString(R.string.wathch_video_to_unlock_screen)
        } else {
            msg = getResources().getString(R.string.wathch_video_to_unlock_sticker)
        }
        val bottomSheetFragment: BottomSheetFragment = BottomSheetFragment(getResources().getString(R.string.watch_video), msg, getResources().getString(R.string.watch), getResources().getString(R.string.cancel), R.drawable.ic_video, object : BottomSheetFragment.OnButtonClickListener {
            public override fun onPositive(bottomSheetDialo: BottomSheetFragment?) {
                bottomSheetDialo!!.dismiss()
                if (isEmoji) {
                    if (rewardedAd != null) {
                        showAd(position, rewardedAd)
                    } /*else if (gameOverRewardedAd2.isLoaded()) {
                        showAd(position, gameOverRewardedAd2);
                    } else if (gameOverRewardedAd3.isLoaded()) {
                        showAd(position, gameOverRewardedAd3);
                    }*/ else {
                        //   assert RewardVideoAds.Companion.getInstence() != null;
                        //   RewardVideoAds.Companion.getInstence().loadVideoAdMain(CreateSolidWallpaperActivity.this);
                        Toast.makeText(this@CreateSolidWallpaperActivity, getResources().getString(R.string.try_again_later), Toast.LENGTH_SHORT).show()
                    }
                } else {
                    if (rewardedAd != null) {
                        showAdSticker(position, rewardedAd)
                    } /*else if (gameOverRewardedAd2.isLoaded()) {
                        showAdSticker(position, gameOverRewardedAd2);
                    } else if (gameOverRewardedAd3.isLoaded()) {
                        showAdSticker(position, gameOverRewardedAd3);
                    } */ else {
                        //   assert RewardVideoAds.Companion.getInstence() != null;
                        //   RewardVideoAds.Companion.getInstence().loadVideoAdMain(CreateSolidWallpaperActivity.this);
                        Toast.makeText(this@CreateSolidWallpaperActivity, getResources().getString(R.string.try_again_later), Toast.LENGTH_SHORT).show()
                    }
                }
            }

            public override fun onNegative(bottomSheetDialog: BottomSheetFragment?) {
                bottomSheetDialog!!.dismiss()
            }
        })
        bottomSheetFragment.show(supportFragmentManager, "dialog")
    }

    private fun showAdSticker(position: Int, rewardedAd: RewardedAd?) {
        if (rewardedAd != null && rewardedAd != null) {

            rewardedAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    assert(instence != null)
                    try {
                        if (instance != null) {
                            instence!!.loadVideoAdMain(this@CreateSolidWallpaperActivity)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }

                override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
                    super.onAdFailedToShowFullScreenContent(p0)
                    assert(instence != null)
                    try {
                        if (instance != null) {
                            instence!!.loadVideoAdMain(this@CreateSolidWallpaperActivity)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                    Toast.makeText(this@CreateSolidWallpaperActivity, getResources().getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()

                }

                override fun onAdShowedFullScreenContent() {
//                    assert(instence != null)
//                    instence!!.loadVideoAdMain(this@CreateSolidWallpaperActivity)
//                    Toast.makeText(this@CreateSolidWallpaperActivity, resources.getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
//                    mRewardedAd = null
                }
            }

//            val adCallback: RewardedAdCallback = object : RewardedAdCallback() {
//                public override fun onRewardedAdOpened() {
//                    // Ad opened.
//                }
//
//                public override fun onRewardedAdClosed() {
//                    // Ad closed.
//                    assert(instence != null)
//                    instence!!.loadVideoAdMain(this@CreateSolidWallpaperActivity)
//                }
//
//                public override fun onUserEarnedReward(reward: RewardItem) {
//                    // User earned reward.
//                    dbHelper!!.insertPath(mStickerList!![position])
//                    mStickerModelList!![position].isFree = true
//                    // imageLock.setVisibility(View.GONE);
//                    if (stickerAdapter != null) {
//                        stickerAdapter!!.notifyItemChanged(position)
//                    }
//                    assert(instence != null)
//                    instence!!.loadVideoAdMain(this@CreateSolidWallpaperActivity)
//                    isStickerSelected = true
//                    adapter!!.setSelectedPosition(-1)
//                    imgEmoji!!.setImageDrawable(null)
//                    mSelectedEmojiPosition = -1
//                    mSelectedEmojiPath = null
//                    Glide.with(this@CreateSolidWallpaperActivity).load(mStickerList!![position]).into(object : CustomTarget<Drawable?>() {
//                        public override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
//                            mSelectedSticker = DrawableSticker(resource)
//                            mSelectedSticker!!.color = Color.WHITE
//                            sticker_view!!.addSticker(mSelectedSticker!!)
//                            sticker_view!!.invalidate()
//                        }
//
//                        public override fun onLoadCleared(placeholder: Drawable?) {}
//                    })
//                }
//
//                public override fun onRewardedAdFailedToShow(errorCode: Int) {
//                    // Ad failed to display.
//                    assert(instence != null)
//                    instence!!.loadVideoAdMain(this@CreateSolidWallpaperActivity)
//                    Toast.makeText(this@CreateSolidWallpaperActivity, getResources().getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
//                }
//            }

            rewardedAd.show(this, OnUserEarnedRewardListener() {
                dbHelper!!.insertPath(mStickerList!![position])
                mStickerModelList!![position].isFree = true
                // imageLock.setVisibility(View.GONE);
                if (stickerAdapter != null) {
                    stickerAdapter!!.notifyItemChanged(position)
                }
                assert(instence != null)
                try {
                    if (instance != null) {
                        instence!!.loadVideoAdMain(this@CreateSolidWallpaperActivity)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                isStickerSelected = true
                adapter!!.setSelectedPosition(-1)
                imgEmoji!!.setImageDrawable(null)
                mSelectedEmojiPosition = -1
                mSelectedEmojiPath = null
                Glide.with(this@CreateSolidWallpaperActivity).load(mStickerList!![position]).into(object : CustomTarget<Drawable?>() {
                    public override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                        mSelectedSticker = DrawableSticker(resource)
                        mSelectedSticker!!.color = Color.WHITE
                        sticker_view!!.addSticker(mSelectedSticker!!)
                        sticker_view!!.invalidate()
                    }

                    public override fun onLoadCleared(placeholder: Drawable?) {}
                })
                Log.d(GifLiveWallPaper.TAG, "User earned the reward.")
            })

//            rewardedAd.show(this@CreateSolidWallpaperActivity, adCallback)
        } else {
            //  showSnackBar(getResources().getString(R.string.something_went_wrong));
            Toast.makeText(this@CreateSolidWallpaperActivity, getResources().getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
        }
    }

    fun showAd(position: Int, rewardedAd: RewardedAd?) {
        if (rewardedAd != null && rewardedAd != null) {

            rewardedAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    assert(instence != null)
                    try {
                        if (instance != null) {
                            instence!!.loadVideoAdMain(this@CreateSolidWallpaperActivity)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }

                override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
                    super.onAdFailedToShowFullScreenContent(p0)
                    assert(instence != null)
                    try {
                        if (instance != null) {
                            instence!!.loadVideoAdMain(this@CreateSolidWallpaperActivity)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                    Toast.makeText(this@CreateSolidWallpaperActivity, getResources().getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()

                }

                override fun onAdShowedFullScreenContent() {

                }
            }

//            val adCallback: RewardedAdCallback = object : RewardedAdCallback() {
//                public override fun onRewardedAdOpened() {
//                    // Ad opened.
//                    assert(instence != null)
//                    instence!!.loadVideoAdMain(this@CreateSolidWallpaperActivity)
//                }
//
//                public override fun onRewardedAdClosed() {
//                    // Ad closed.
//                    assert(instence != null)
//                    instence!!.loadVideoAdMain(this@CreateSolidWallpaperActivity)
//                }
//
//                public override fun onUserEarnedReward(reward: RewardItem) {
//                    // User earned reward.
//                    dbHelper!!.insertPath(mImageList!![position])
//                    mScreenModelList!![position].isFree = true
//                    // imageLock.setVisibility(View.GONE);
//                    if (adapter != null) {
//                        adapter!!.notifyItemChanged(position)
//                    }
//                    assert(instence != null)
//                    instence!!.loadVideoAdMain(this@CreateSolidWallpaperActivity)
//                    isEmojiSelected = true
//                    isStickerSelected = false
//                    emojiPath = mImageList!![position]
//                    mSelectedEmojiPosition = position
//                    mSelectedColor = Color.WHITE
//                    mSelectedSticker = null
//                    if (lastpos != position) {
//                        imgEmoji!!.alpha = 1f
//                        seekBarOpacity!!.progress = 255
//                    }
//                    lastpos = position
//                    mSelectedEmojiPath = null
//                    colorAdepter!!.setColor(mSelectedColor)
//                    sticker_view!!.removeAllStickers()
//                    sticker_view!!.invalidate()
//                    Glide.with(this@CreateSolidWallpaperActivity).load(mImageList!![position]).into(object : CustomTarget<Drawable?>() {
//                        public override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
//                            resource.setColorFilter(mSelectedColor, PorterDuff.Mode.SRC_IN)
//                            imgEmoji!!.setImageDrawable(resource)
//                        }
//
//                        public override fun onLoadCleared(placeholder: Drawable?) {}
//                    })
//                }
//
//                public override fun onRewardedAdFailedToShow(errorCode: Int) {
//                    // Ad failed to display.
//                    assert(instence != null)
//                    instence!!.loadVideoAdMain(this@CreateSolidWallpaperActivity)
//                    Toast.makeText(this@CreateSolidWallpaperActivity, getResources().getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
//                }
//            }

            rewardedAd.show(this, OnUserEarnedRewardListener() {
                dbHelper!!.insertPath(mImageList!![position])
                mScreenModelList!![position].isFree = true
                // imageLock.setVisibility(View.GONE);
                if (adapter != null) {
                    adapter!!.notifyItemChanged(position)
                }
                assert(instence != null)
                try {
                    if (instance != null) {
                        instence!!.loadVideoAdMain(this@CreateSolidWallpaperActivity)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                isEmojiSelected = true
                isStickerSelected = false
                emojiPath = mImageList!![position]
                mSelectedEmojiPosition = position
                mSelectedColor = Color.WHITE
                mSelectedSticker = null
                if (lastpos != position) {
                    imgEmoji!!.alpha = 1f
                    seekBarOpacity!!.progress = 255
                }
                lastpos = position
                mSelectedEmojiPath = null
                colorAdepter!!.setColor(mSelectedColor)
                sticker_view!!.removeAllStickers()
                sticker_view!!.invalidate()
                Glide.with(this@CreateSolidWallpaperActivity).load(mImageList!![position]).into(object : CustomTarget<Drawable?>() {
                    public override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                        resource.setColorFilter(mSelectedColor, PorterDuff.Mode.SRC_IN)
                        imgEmoji!!.setImageDrawable(resource)
                    }

                    public override fun onLoadCleared(placeholder: Drawable?) {}
                })
                Log.d(GifLiveWallPaper.TAG, "User earned the reward.")
            })

//            rewardedAd.show(this@CreateSolidWallpaperActivity, adCallback)
        } else {
            //  showSnackBar(getResources().getString(R.string.something_went_wrong));
            Toast.makeText(this@CreateSolidWallpaperActivity, getResources().getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
        }
    }

    inner class Receiver : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            Log.d("dsfsdf", "onReceive: ads ")
            if (!NetworkHelper.isOnline(context)) {
                try {
                    stickerFragment!!.dismiss()
                } catch (e: java.lang.Exception) {
                    Log.d("dsfsdf", "catch: " + e.message)
                    e.printStackTrace()
                }
            }
            if (!NetworkHelper.isOnline(context)) {
                try {
                    forgroundFragment!!.dismiss()
                } catch (e: java.lang.Exception) {
                    Log.d("dsfsdf", "catch: " + e.message)
                    e.printStackTrace()
                }
            }
        }
    }

//    fun createAndLoadRewardedAd(adUnitId: String?): RewardedAd {
//        val rewardedAd: RewardedAd = RewardedAd(this, adUnitId)
//        val adLoadCallback: RewardedAdLoadCallback = object : RewardedAdLoadCallback() {
//            public override fun onRewardedAdLoaded() {
//                // Ad successfully loaded.
//            }
//
//            public override fun onRewardedAdFailedToLoad(errorCode: Int) {
//                // Ad failed to load.
//            }
//        }
//        rewardedAd.loadAd(AdRequest.Builder().build(), adLoadCallback)
//        return rewardedAd
//    }

    override fun onResume() {
        super.onResume()
        imgColor!!.setCardBackgroundColor(Color.parseColor("#EBEBEB"))
        SolidWallpaperApplication.staticLanguage.Factory.create(this)
        if (Constants.isSubscribedW) {
            recreate()
            Constants.isSubscribedW = false
        }
    }

    private fun loadInterstialAdFb() {
        if (instance!!.mInterstitialAdfb!!.isAdLoaded) {
            Log.d("TAG", "loadInterstialAdFb: ")
        } else {
            instance!!.mInterstitialAdfb!!.buildLoadAdConfig().withAdListener(null)
            instance!!.mInterstitialAdfb = null
            instance!!.LoadAdsFb()
            instance!!.mInterstitialAdfb!!.buildLoadAdConfig().withAdListener(object : InterstitialAdListener {
                public override fun onError(ad: Ad, adError: AdError) {
                    // loadInterstialAdFb();
                    loadInterstialAdFb()
                }

                public override fun onAdLoaded(ad: Ad) {}
                public override fun onAdClicked(ad: Ad) {}
                public override fun onLoggingImpression(ad: Ad) {}
                public override fun onInterstitialDisplayed(ad: Ad) {}
                public override fun onInterstitialDismissed(ad: Ad) {
                    loadInterstialAdFb()
                }
            })
        }
    }

    private fun loadInterstialAd() {
        if (instance!!.mInterstitialAd != null) {
            Log.d("TAG", "loadInterstialAd: ")
        } else {
            if (instance!!.mInterstitialAd != null) {
                instance!!.mInterstitialAd!!.fullScreenContentCallback = null
                instance!!.mInterstitialAd = null
                instance!!.ins_adRequest = null
                instance!!.LoadAds()

                instance!!.mInterstitialAd!!.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
//                    Log.d(TAG, 'Ad was dismissed.')
                    }

                    override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
                        super.onAdFailedToShowFullScreenContent(p0)
                        loadInterstialAdFb()
                    }

                    override fun onAdShowedFullScreenContent() {
//                    Log.d(TAG, 'Ad showed fullscreen content.')
                        instance!!.mInterstitialAd = null;
                    }
                }
                instance!!.mInterstitialAd!!.show(this)

//            instance!!.mInterstitialAd!!.adListener = object : AdListener() {
//                public override fun onAdLoaded() {
//                    super.onAdLoaded()
//                }
//
//                public override fun onAdFailedToLoad(i: Int) {
//                    super.onAdFailedToLoad(i)
//                    loadInterstialAdFb()
//                }
//            }
            }
        }
    }

    private var mInterstitialAd1: InterstitialAd? = null

    private fun loadInterstialAd1() {


        var adsId = AppIDs.instnace!!.getGoogleInterstitial()
//        mInterstitialAd = InterstitialAd()

        val ins_adRequest = AdRequest.Builder().build()
        InterstitialAd.load(this,
                adsId,
                ins_adRequest,
                object : InterstitialAdLoadCallback() {
                    override fun onAdLoaded(myAd: InterstitialAd) {
//                            Timber.d("Ad Loaded")
                        Log.d("MainStartActivity.TAG", "onAdLoaded: Ad Loaded")
                        mInterstitialAd1 = myAd
//                        startActivity(Intent(this@MainStartActivity, MyCreationActivity::class.java))
//                        mInterstitialAd=null

                    }

                    override fun onAdFailedToLoad(adError: LoadAdError) {
                        Log.d("MainStartActivity.TAG", "onAdLoaded: ${adError.message}")
//                        startActivity(Intent(this@MainStartActivity, MyCreationActivity::class.java))
                        mInterstitialAd1 = null
//                            Timber.d("Failed to load ad: ${adError.message}")
//                        mInterstitialAd = null
                    }

                })
    }

    fun showInterstitial() {
        if (mInterstitialAd1 != null) {

            mInterstitialAd1!!.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
//                    Log.d(MainStartActivity.TAG, "Ad was dismissed.")
                    mInterstitialAd1 = null
                    startActivity(Intent(this@CreateSolidWallpaperActivity, GradientResolutionActivity::class.java))

                    loadInterstialAd1()
//                    mInterstitialAd = null
                }

                override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
                    super.onAdFailedToShowFullScreenContent(p0)
//                    Log.d(MainStartActivity.TAG, "Ad was dismisdasdased.")
                    loadInterstialAd1()

                    startActivity(Intent(this@CreateSolidWallpaperActivity, GradientResolutionActivity::class.java))
//                loadInterstialAdFb()
                }

                override fun onAdShowedFullScreenContent() {
//                    Log.d(MainStartActivity.TAG, "Ad showed fullscreen content.")
//                    startActivity(Intent(this@MainStartActivity, MyCreationActivity::class.java))
//                    mInterstitialAd1 = null
                }
            }
            mInterstitialAd1?.show(this)
        } else {
            startActivity(Intent(this, GradientResolutionActivity::class.java))
        }
    }

    override fun onStop() {
        super.onStop()
        try {
            unregisterReceiver(receiver)
        } catch (e: java.lang.Exception) {

        }
    }


    override fun onPause() {
        super.onPause()

        try {
            bottomSheetFragment!!.dismiss()
        }catch (e:Exception){

        }
    }

    private fun showAlertDialog() {
        bottomSheetFragment= BottomSheetFragmentDiscard(getResources().getString(R.string.discard), getResources().getString(R.string.do_you_want_to_discard), getResources().getString(R.string.discard), getResources().getString(R.string.cancel), R.drawable.ic_discard_dialog, object : BottomSheetFragmentDiscard.OnButtonClickListener {
            public override fun onPositive(bottomSheetDialo: BottomSheetFragmentDiscard?) {
                bottomSheetDialo!!.dismiss()
                finish()
            }

            public override fun onNegative(bottomSheetDialog: BottomSheetFragmentDiscard?) {
                bottomSheetDialog!!.dismiss()
            }
        })
        bottomSheetFragment!!.show(supportFragmentManager, "dialog")
    }
}