package com.solid.color.wallpaper.hd.image.background.fragment

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.fragment.YouNeedCoinDialogFragment
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs.getInt

class YouNeedCoinDialogFragment constructor(private val mListener: OnButtonClickListener, coins: Int) : DialogFragment() {
    private val coins: String = coins.toString()
    private var iswatchadavalable: Boolean = false

    open interface OnButtonClickListener {
        fun onPositive(bottomSheetDialo: YouNeedCoinDialogFragment, isNoMoreCoin: Boolean)
        fun onNegative(bottomSheetDialog: YouNeedCoinDialogFragment, isWatchAdAvalable: Boolean)
    }

    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setStyle(BottomSheetDialogFragment.STYLE_NORMAL, R.style.materialButton);
        setStyle(STYLE_NO_TITLE, R.style.materialButton)
    }

    public override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.dialog_you_need_coin, container, false)
    }

    public override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val txtview: TextView = (view.findViewById(R.id.txtCoin))
        txtview.text = (coins.toInt() - getInt(activity, AdsPrefs.WALLET_COINS, 100)).toString()
        Log.d("TAG==>>>>>>>>", "onViewCreated: " + (coins.toInt()))
        val txtviewwatch_ad: TextView = view.findViewById(R.id.txt_watch_ad)
        if ((coins.toInt() <= 10)) {
            iswatchadavalable = true
            txtviewwatch_ad.visibility = View.VISIBLE
            txtviewwatch_ad.text = resources.getString(R.string.watch_ad)
        } else {
            //txtviewwatch_ad.setVisibility(View.GONE);
            txtviewwatch_ad.text = getResources().getString(R.string.cancel)
        }
        view.findViewById<View>(R.id.ll_skip_ad_using_10).setOnClickListener(View.OnClickListener { v: View? -> mListener.onPositive(this@YouNeedCoinDialogFragment, iswatchadavalable) })
        view.findViewById<View>(R.id.txt_watch_ad).setOnClickListener(View.OnClickListener { v: View? -> mListener.onNegative(this@YouNeedCoinDialogFragment, iswatchadavalable) })
    }

    public override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        val bottomSheetDialog: Dialog? = dialog
        // ((View) getView().getParent()).setPadding(0,0,0,);
        val displayMetrics: DisplayMetrics = DisplayMetrics()
        activity!!.windowManager.defaultDisplay.getMetrics(displayMetrics)
        val height: Int = displayMetrics.heightPixels
        var width: Int = displayMetrics.widthPixels
        width -= width / 4
        bottomSheetDialog!!.window!!.setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT)
        // setColoredNavBar(true);
    }

    public override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog: Dialog = super.onCreateDialog(savedInstanceState)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            //setWhiteNavigationBar(dialog);
        }
        return dialog
    }

    override fun onPause() {
        super.onPause()


    }
    public override fun onStart() {
        super.onStart()
    }

}