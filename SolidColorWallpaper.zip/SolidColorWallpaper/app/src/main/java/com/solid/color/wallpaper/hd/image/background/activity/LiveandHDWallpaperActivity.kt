package com.solid.color.wallpaper.hd.image.background.activity

import android.content.res.Configuration
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.SolidWallpaperApplication
import com.solid.color.wallpaper.hd.image.background.shared_pref.MySharedPref
import java.util.*

class LiveandHDWallpaperActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_liveand_h_d_wallpaper)

        System.gc()

        SolidWallpaperApplication.staticLanguage.Factory.create(this)

        initViewAction()

    }

    private fun initViewAction() {

    }
}