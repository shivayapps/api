package com.solid.color.wallpaper.hd.image.background.sqlite_database

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelperSuscription(context: Context?) : SQLiteOpenHelper(context, DATABASE_NAME, null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        // TODO Auto-generated method stub
        db.execSQL(
                "create table suscription " +
                        "(id integer primary key, path text)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // TODO Auto-generated method stub
        db.execSQL("DROP TABLE IF EXISTS suscription")
        onCreate(db)
    }

    fun insertPath(path: String): Boolean {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put("path", path)
        if (!checkPathExist(path)) {
            db.insert("suscription", null, contentValues)
        }
        return true
    }

    fun deleteAllData() {
        val db = this.writableDatabase
        db.execSQL("DELETE FROM suscription")
        db.close()
    }

    fun checkPathExist(path: String): Boolean {
        var res: Cursor? = null
        var isWathced = false
        try {
            val db = this.readableDatabase
            res = db.rawQuery("select * from suscription", null)
            res.moveToFirst()
            while (!res.isAfterLast) {
                if (res.getString(res.getColumnIndex(CONTACTS_COLUMN_NAME)) == path) {
                    isWathced = true
                    break
                }
                res.moveToNext()
            }
        } finally {
            // this gets called even if there is an exception somewhere above
            res?.close()
        }
        res!!.close()
        return isWathced
    }

    companion object {
        const val DATABASE_NAME = "MyDBNameD.db"
        const val CONTACTS_COLUMN_NAME = "path"
    }
}