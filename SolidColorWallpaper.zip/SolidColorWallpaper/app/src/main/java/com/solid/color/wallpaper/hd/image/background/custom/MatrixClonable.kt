package com.solid.color.wallpaper.hd.image.background.custom

import android.graphics.Matrix

class MatrixClonable : Matrix(), Cloneable {
    @Throws(CloneNotSupportedException::class)
    public override fun clone(): Any {
        return super.clone()
    }
}