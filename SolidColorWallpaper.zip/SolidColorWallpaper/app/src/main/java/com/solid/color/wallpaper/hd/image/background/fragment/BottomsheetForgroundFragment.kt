package com.solid.color.wallpaper.hd.image.background.fragment

//import com.google.android.gms.ads.rewarded.RewardedAdCallback
import android.app.Activity
import android.content.DialogInterface
import android.content.Intent
import android.content.res.Resources
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.util.TypedValue
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.airbnb.lottie.LottieAnimationView
import com.andrefrsousa.superbottomsheet.SuperBottomSheetFragment
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.NetworkHelper
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.wifi_network.exceptions.ApiNotSupportedException
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.wifi_network.exceptions.NullWifiConfigurationException
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.OnUserEarnedRewardListener
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.SolidWallpaperApplication.Companion.instance
import com.solid.color.wallpaper.hd.image.background.activity.CoinPurchaseActivity
import com.solid.color.wallpaper.hd.image.background.activity.GifLiveWallPaper
import com.solid.color.wallpaper.hd.image.background.activity.PremiumAccessActivity
import com.solid.color.wallpaper.hd.image.background.adapter.CategoryNewAdapter
import com.solid.color.wallpaper.hd.image.background.adapter.CategoryNewAdapter.OnCLickCategory
import com.solid.color.wallpaper.hd.image.background.adapter.ForegroundLiveAdapter
import com.solid.color.wallpaper.hd.image.background.adshalper.RewardVideoAds
import com.solid.color.wallpaper.hd.image.background.adshalper.RewardVideoAds.Companion.instence
import com.solid.color.wallpaper.hd.image.background.adshalper.RewardVideoAds.Companion.rewardedAd
import com.solid.color.wallpaper.hd.image.background.constants.Constants
import com.solid.color.wallpaper.hd.image.background.model.CategoryNameIconModel
import com.solid.color.wallpaper.hd.image.background.model.api.DataItem
import com.solid.color.wallpaper.hd.image.background.model.api.Response
import com.solid.color.wallpaper.hd.image.background.newModel.ImagesItem
import com.solid.color.wallpaper.hd.image.background.newModel.WallpaperWeekModelNewResponse
import com.solid.color.wallpaper.hd.image.background.retrofit.APIClient.client
import com.solid.color.wallpaper.hd.image.background.retrofit.APIInterface
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs.getBoolean
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs.getInt
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs.save
import com.solid.color.wallpaper.hd.image.background.shared_pref.MySharedPref
import com.solid.color.wallpaper.hd.image.background.sqlite_database.DBHelper
import com.solid.color.wallpaper.hd.image.background.sqlite_database.DBHelperSuscription
import retrofit2.Call
import retrofit2.Callback
import java.lang.reflect.InvocationTargetException
import java.util.*

class BottomsheetForgroundFragment : SuperBottomSheetFragment {
    private var progressBar: ProgressBar? = null
    private var mTempForgroundList: ArrayList<WallpaperWeekModelNewResponse?>? = null
    private var apiInterface: APIInterface? = null
    private var mDataList: ArrayList<DataItem>? = null
    private var mDataListNew: ArrayList<com.solid.color.wallpaper.hd.image.background.newModel.DataItem>? = null
    private var path: String? = null
    private var onItemSelected: OnItemSelected? = null
    private var icBack: ImageView? = null
    private var btnShare: ImageView? = null
    private var ic_premium: ImageView? = null
    private var btnAd: LottieAnimationView? = null
    private var mySharedPref: MySharedPref? = null
    private var dbHelper: DBHelper? = null
    private var txtHeaderText: TextView? = null
    private var dbHelperSuscription: DBHelperSuscription? = null
    private var mForgroundData: ArrayList<WallpaperWeekModelNewResponse?>? = null
    private var adLayout: RelativeLayout? = null
    private var mAContext: Activity? = null
    private var recyclerSnap: RecyclerView? = null
    private var recyclerCategoryData: RecyclerView? = null
    private var mAllReadyData: ArrayList<ArrayList<WallpaperWeekModelNewResponse?>>? = null
    private var categoryNameList: ArrayList<CategoryNameIconModel>? = null
    private var mCategoryName: String? = null

    //   private RewardedAd gameOverRewardedAd, gameOverRewardedAd2, gameOverRewardedAd3;
    private var isAdShow: Boolean = false
    private var frogroundAdapter: ForegroundLiveAdapter? = null

    var watchAdDialogFragment:YouNeedCoinDialogFragment?=null

    constructor() {
        // Required empty public constructor
    }

    constructor(activity: Activity, mDataList: ArrayList<ArrayList<WallpaperWeekModelNewResponse?>>?, categoryNameList: ArrayList<CategoryNameIconModel>?, onItemSelected: OnItemSelected?) {
        mAllReadyData = mDataList
        this.onItemSelected = onItemSelected
        this.mAContext = activity
        this.categoryNameList = categoryNameList
    }

    public override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                                     savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        super.onCreateView(inflater, container, savedInstanceState)
        return inflater.inflate(R.layout.fragment_bottomsheet_forground, container, false)
    }

    public override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupBackPressListener()
//        mAContext = activity
        mForgroundData = ArrayList()
        dbHelper = DBHelper(mAContext)
        dbHelperSuscription = DBHelperSuscription(mAContext)
        btnAd = view.findViewById(R.id.btnAd)
        icBack = view.findViewById(R.id.icBack)
        btnShare = view.findViewById(R.id.btnShare)
        ic_premium = view.findViewById(R.id.ic_premium)
        adLayout = view.findViewById(R.id.adLayout)
        recyclerSnap = view.findViewById(R.id.recyclerSnap)
        recyclerCategoryData = view.findViewById(R.id.recyclerCategoryData)
        txtHeaderText = view.findViewById(R.id.txtHeaderText)
        mySharedPref = MySharedPref(mAContext)
        if ( /*!mySharedPref.getAdsRemoved() &&*/!getBoolean(mAContext, AdsPrefs.IS_SUBSCRIBED, false)) {
            adLayout!!.visibility = View.VISIBLE
            btnShare!!.visibility = View.GONE
            loadInterstialAd()
            assert(instence != null)
            if (!(RewardVideoAds.rewardedAd == null || RewardVideoAds.rewardedAd1 == null)) {
                try {
                    if (instance != null) {
                        instence!!.loadVideoAdMain((activity)!!)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

        } else {
            adLayout!!.visibility = View.GONE
            btnShare!!.visibility = View.VISIBLE
        }
        progressBar = view.findViewById(R.id.progressBar)
        icBack!!.setOnClickListener(View.OnClickListener { v: View? -> onclickBack() })
        ic_premium!!.setOnClickListener(View.OnClickListener {
            com.vasundhara.vision.subscription.constants.Constants.subActivity = "sub"
            startActivity(Intent(mAContext, PremiumAccessActivity::class.java))
        })
        btnShare!!.setOnClickListener(View.OnClickListener { v: View? -> shareOwnApp() })
        mDataList = ArrayList()
        mDataListNew = ArrayList()
        Handler().postDelayed({
            if (mAllReadyData != null && mAllReadyData!!.size <= 0) {
                mAllReadyData = ArrayList()
                try {
                    checkStatus()
                } catch (e: InvocationTargetException) {
                    e.printStackTrace()
                } catch (e: NoSuchMethodException) {
                    e.printStackTrace()
                } catch (e: ApiNotSupportedException) {
                    e.printStackTrace()
                } catch (e: NoSuchFieldException) {
                    e.printStackTrace()
                } catch (e: IllegalAccessException) {
                    e.printStackTrace()
                } catch (e: NullWifiConfigurationException) {
//                    callApi()
                    callNewApi()
                    e.printStackTrace()
                }
            } else {
                setData()
            }
        }, 0)
    }

    private fun setupBackPressListener() {
        requireView().isFocusableInTouchMode = true
        requireView().requestFocus()
        requireView().setOnKeyListener(View.OnKeyListener { v: View?, keyCode: Int, event: KeyEvent ->
            if (event.action != KeyEvent.ACTION_DOWN) return@OnKeyListener true
            if (keyCode == KeyEvent.KEYCODE_BACK) {
                onclickBack()
                return@OnKeyListener true
            } else {
                return@OnKeyListener false
            }
        })
    }

    fun onclickBack(): Boolean {
        Log.e("TAG", "onclickBack: backkkk")
        if (recyclerCategoryData!!.visibility == View.VISIBLE) {
            txtHeaderText!!.text = "Screen"
            recyclerSnap!!.visibility = View.VISIBLE
            recyclerCategoryData!!.visibility = View.GONE
            return false
        } else {
            dismiss()
            return true
        }
    }

    private fun shareOwnApp() {
        val shareIntent: Intent = Intent(Intent.ACTION_SEND)
        shareIntent.type = "text/plain"
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Solid Color Wallpaper")
        var shareMessage: String = ""
        shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=com.solid.color.wallpaper.hd.image.background"
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
        startActivity(Intent.createChooser(shareIntent, getResources().getString(R.string.choose_one)))
    }

    private fun showAd() {
        if (instance!!.requestNewInterstitial()) {

            instance!!.mInterstitialAd!!.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
//                    Log.d(TAG, 'Ad was dismissed.')
                    loadInterstialAd()

                }

                override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
                    super.onAdFailedToShowFullScreenContent(p0)
//                    loadInterstialAdFb()
                }

                override fun onAdShowedFullScreenContent() {
//                    Log.d(TAG, 'Ad showed fullscreen content.')
                    instance!!.mInterstitialAd = null;
                }
            }
            instance!!.mInterstitialAd!!.show(requireActivity())

//            instance!!.mInterstitialAd!!.adListener = object : AdListener() {
//                public override fun onAdClosed() {
//                    super.onAdClosed()
//                    loadInterstialAd()
//                }
//
//                public override fun onAdFailedToLoad(i: Int) {
//                    super.onAdFailedToLoad(i)
//                }
//
//                public override fun onAdLoaded() {
//                    super.onAdLoaded()
//                }
//            }
        } else {
            Toast.makeText(mAContext, "Try again later.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setData() {
        var mNewList = arrayListOf<WallpaperWeekModelNewResponse?>()

        if (mAllReadyData != null && mAllReadyData!!.size > 0) {
            mForgroundData!!.clear()
            mForgroundData!!.addAll(mAllReadyData!![0])
            Log.e("TAG", "setData: ${mForgroundData!!.size}")


            val manager1: GridLayoutManager = GridLayoutManager(activity, 3)
            recyclerSnap!!.layoutManager = manager1
//            recyclerSnap!!.addItemDecoration(GridSpacingItemDecoration(3, dpToPx(18), true))
            recyclerSnap!!.itemAnimator = DefaultItemAnimator()
            val adapter: CategoryNewAdapter = CategoryNewAdapter((mAContext)!!, (categoryNameList)!!, object : OnCLickCategory {
                override fun onClickCategory(i: Int) {
                    mForgroundData!!.clear()
                    mNewList.clear()
                    mForgroundData!!.addAll(mAllReadyData!![0])
                    Constants.mCategoryName = categoryNameList!![i].categoryName

                    mForgroundData!!.filter {

                        if (it!!.imageItem!!.name == Constants.mCategoryName) {
                            mNewList.add(it)
                        }
                        true
                    }

                    txtHeaderText!!.text = categoryNameList!![i].categoryName
                    frogroundAdapter!!.notifyDataSetChanged()
                    recyclerCategoryData!!.scrollToPosition(0)
                    recyclerSnap!!.visibility = View.GONE
                    recyclerCategoryData!!.visibility = View.VISIBLE
                }
            })
            recyclerSnap!!.adapter = adapter
            recyclerSnap!!.visibility = View.VISIBLE
            progressBar!!.visibility = View.GONE


            val manager: GridLayoutManager = GridLayoutManager(activity, 3)
            recyclerCategoryData!!.layoutManager = manager
//            recyclerCategoryData!!.addItemDecoration(DividerItemDecoration(context, LinearLayoutManager.VERTICAL))
            recyclerCategoryData!!.itemAnimator = DefaultItemAnimator()

            val onItemSelectedListner: ForegroundLiveAdapter.OnItemSelectedListner = object : ForegroundLiveAdapter.OnItemSelectedListner {
                public override fun onItemClick(model: WallpaperWeekModelNewResponse?, position: Int) {

                    Log.e("TAG", "onItemClickCAt: ${model!!.imageItem!!.name}")
                    if (!model!!.isLocked) {
                        path = model.imageItem!!.image
                        dismiss()
                    } else {
                        if (getInt(mAContext, AdsPrefs.WALLET_COINS, 100) >= model.coins) {
                            showCoinAvalableDialog(model)
                        } else {
                            showBuyCoinDialog(model)
                        }
                    }
                }
            }
            recyclerCategoryData!!.isNestedScrollingEnabled = false

            Log.e("TAG", "setData: ${mNewList.size}")
            frogroundAdapter = ForegroundLiveAdapter(mNewList, mAContext!!, onItemSelectedListner)

            recyclerCategoryData!!.adapter = frogroundAdapter


        } else {
            try {
                checkStatus()
            } catch (e: InvocationTargetException) {
                e.printStackTrace()
            } catch (e: NoSuchMethodException) {
                e.printStackTrace()
            } catch (e: ApiNotSupportedException) {
                e.printStackTrace()
            } catch (e: NoSuchFieldException) {
                e.printStackTrace()
            } catch (e: IllegalAccessException) {
                e.printStackTrace()
            } catch (e: NullWifiConfigurationException) {
//                callApi()
                callNewApi()
                e.printStackTrace()
            }
        }
    }

    private fun showBuyCoinDialog(model: WallpaperWeekModelNewResponse) {
       watchAdDialogFragment = YouNeedCoinDialogFragment(object : YouNeedCoinDialogFragment.OnButtonClickListener {
            public override fun onPositive(bottomSheetDialo: YouNeedCoinDialogFragment, isNoMoreCoin: Boolean) {
                com.vasundhara.vision.subscription.constants.Constants.subActivity = "coin"
                startActivity(Intent(mAContext, CoinPurchaseActivity::class.java))
                bottomSheetDialo.dismiss()
            }

            public override fun onNegative(bottomSheetDialog: YouNeedCoinDialogFragment, iswatchadavalable: Boolean) {
                bottomSheetDialog.dismiss()
                if (iswatchadavalable) {
                    if (!NetworkHelper.isOnline(mAContext)) {
                        Toast.makeText(mAContext, getResources().getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show()
                        return
                    }
                    if (instence != null && instence!!.checkAdLoad() == null) {
                        Log.e("TAG", "onAdFailedToShowFullScreenContent: asdasdasdasdklmldksfg ijou opdihgopik as")

                        Toast.makeText(mAContext, getResources().getString(R.string.try_again_later), Toast.LENGTH_SHORT).show()
                        return
                    } else {
                        Log.e("TAG", "onAdFailedToShowFullScreenContent: ihgopik as")

                    }
                    if (instence != null && instence!!.loadVideoAdMain(requireActivity()) != null) {
                        val rewardedAd: RewardedAd? = instence!!.loadVideoAdMain(requireActivity())
                        if (rewardedAd != null) {
                            Log.e("TAG", "onAdFailedToShowFullScreenContent: dfbhksfh  uioujio  0")
                            showAdReward(model, rewardedAd)
                        } else {
                            Log.e("TAG", "onAdFailedToShowFullScreenContent: abgsdbdhs jkadhsjkfhadslfads")
                            Toast.makeText(mAContext, getResources().getString(R.string.try_again_later), Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Log.e("TAG", "onAdFailedToShowFullScreenContent: abgsdjkhadgsbfsdkh bdhs jkadhsjkfhadslfads")

                        Toast.makeText(mAContext, getResources().getString(R.string.try_again_later), Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }, model.coins)
        watchAdDialogFragment!!.show(requireActivity().supportFragmentManager, "dialog")
    }

    private fun showCoinAvalableDialog(model: WallpaperWeekModelNewResponse) {
        val watchAdDialogFragment: WatchAdDialogFragment = WatchAdDialogFragment(object : WatchAdDialogFragment.OnButtonClickListener {
            public override fun onPositive(bottomSheetDialo: WatchAdDialogFragment, isNoMoreCoin: Boolean) {
                val coins: Int = getInt(activity, AdsPrefs.WALLET_COINS, 100)
                save(mAContext, AdsPrefs.WALLET_COINS, coins - model.coins)
                dbHelper!!.insertPath((model.imageItem!!.image)!!)
                model.isLocked = false
                path = model.imageItem!!.image
                dismiss()
                bottomSheetDialo.dismiss()
            }

            public override fun onNegative(bottomSheetDialog: WatchAdDialogFragment, iswatchadavalable: Boolean) {
                bottomSheetDialog.dismiss()
                if (iswatchadavalable) {
                    if (!NetworkHelper.isOnline(mAContext)) {
                        Toast.makeText(mAContext, getResources().getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show()
                        return
                    }
                    if (instence != null && instence!!.checkAdLoad() == null) {

                        Log.e("TAG", "onAdFailedToShowFullScreenContent: asdasdasdas .;sfas dsf sa fs fs   ddas")

                        Toast.makeText(mAContext, getResources().getString(R.string.try_again_later), Toast.LENGTH_SHORT).show()
                        return
                    } else {
//                        Toast.makeText(mAContext, getResources().getString(R.string.try_again_later), Toast.LENGTH_SHORT).show()

                        Log.e("TAG", "onAdFailedToShowFullScreenContent: adsadsadsadfsadsadsads")

                    }
                    if (instence != null && instence!!.loadVideoAdMain(requireActivity()) != null) {
                        val rewardedAd: RewardedAd? = instence!!.loadVideoAdMain(requireActivity())
                        if (rewardedAd != null) {


                            showAdReward(model, rewardedAd)
                            Log.e("TAG", "onAdFailedToShowFullScreenContent: dsasdadsadsadsasd")

                        } else {
                            Log.e("TAG", "onAdFailedToShowFullScreenContent: asdasdasdasdas jkhasf hjksfho9u  ads")

                            Toast.makeText(mAContext, getResources().getString(R.string.try_again_later), Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Log.e("TAG", "onAdFailedToShowFullScreenContent: asdasdjkghfiu  ouhyfiuchdsl asdasdas")

                        Toast.makeText(mAContext, getResources().getString(R.string.try_again_later), Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }, java.lang.String.valueOf(model.coins))
        watchAdDialogFragment.show(requireActivity().supportFragmentManager, "dialog")

        /* BottomSheetFragment bottomSheetFragment = new BottomSheetFragment(getResources().getString(R.string.watch_video), getResources().getString(R.string.wathch_video_to_unlock_screen), getResources().getString(R.string.watch), getResources().getString(R.string.cancel), R.drawable.ic_video, new BottomSheetFragment.OnButtonClickListener() {
            @Override
            public void onPositive(BottomSheetFragment bottomSheetDialo) {
                bottomSheetDialo.dismiss();

                if (rewardedAd.isLoaded()) {
                    showAdReward(model, rewardedAd);
                } */
        /*else if (gameOverRewardedAd2.isLoaded()) {
                    showAdReward(model, gameOverRewardedAd2);
                } else if (gameOverRewardedAd3.isLoaded()) {
                    showAdReward(model, gameOverRewardedAd3);
                }*/
        /* else {
         */
        /*   assert RewardVideoAds.Companion.getInstence() != null;
                    RewardVideoAds.Companion.getInstence().loadVideoAdMain(getActivity());*/
        /*
                    Toast.makeText(mAContext, getResources().getString(R.string.try_again_later), Toast.LENGTH_SHORT).show();
                }

                //  showAdReward(position,model, gameOverRewardedAd3);
            }

            @Override
            public void onNegative(BottomSheetFragment bottomSheetDialog) {
                bottomSheetDialog.dismiss();
            }
        });
        bottomSheetFragment.show(getActivity().getSupportFragmentManager(), "dialog");*/
    }

    public override fun onPause() {
        super.onPause()
        if (!isAdShow) {
            dismiss()
        }

        try{
            watchAdDialogFragment!!.dismiss()
        }catch (e:Exception){

        }
    }

    fun showAdReward(model: WallpaperWeekModelNewResponse, gameOverRewa: RewardedAd?) {
        isAdShow = true
        if (gameOverRewa != null) {

            gameOverRewa?.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    assert(instence != null)
//                    rewardedAd = null
//                    RewardVideoAds.rewardedAd1 = null
                    try {
                        if (instance != null) {
                            instence!!.loadVideoAdMain((activity)!!)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                    Log.e("TAG", "1111111111111111: asdasdasdasdas")

                    isAdShow = false
                }

                override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
                    super.onAdFailedToShowFullScreenContent(p0)
                    Toast.makeText(mAContext, getResources().getString(R.string.try_again_later), Toast.LENGTH_SHORT).show()

                    assert(instence != null)


                    rewardedAd = null
                    RewardVideoAds.rewardedAd1 = null
                    try {
                        if (instance != null) {
                            instence!!.loadVideoAdMain((activity)!!)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                    //   showSnackBar(getResources().getString(R.string.something_went_wrong));
                    Log.e("TAG", "1111111111111111: asdasdasdasdas")
                    isAdShow = false
                }

                override fun onAdShowedFullScreenContent() {
                    isAdShow = true
                    assert(instence != null)
//                    rewardedAd = null
//                    RewardVideoAds.rewardedAd1 = null
                    Log.e("TAG", "1111111111111111: asdasdasdasdas")

                    try {
                        if (instance != null) {
                            instence!!.loadVideoAdMain((activity)!!)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
//                    rewardedAd
                }
            }

            gameOverRewa.show(requireActivity(), OnUserEarnedRewardListener() {
                dbHelper!!.insertPath((model.imageItem!!.image)!!)
                model.isLocked = false
                path = model.imageItem!!.image
                dismiss()
                assert(instence != null)
                try {
                    if (instance != null) {
                        instence!!.loadVideoAdMain((activity)!!)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                isAdShow = false
                Log.d(GifLiveWallPaper.TAG, "User earned the reward.")
            })

//            val adCallback: RewardedAdCallback = object : RewardedAdCallback() {
//                public override fun onRewardedAdOpened() {
//                    // Ad opened.
//                    isAdShow = true
//                    assert(instence != null)
//                    instence!!.loadVideoAdMain((activity)!!)
//                }
//
//                public override fun onRewardedAdClosed() {
//                    // Ad closed.
//                    assert(instence != null)
//                    instence!!.loadVideoAdMain((activity)!!)
//                    isAdShow = false
//                }
//
//                public override fun onUserEarnedReward(reward: RewardItem) {
//                    // User earned reward.
//                    dbHelper!!.insertPath((model.imageItem!!.image)!!)
//                    model.isLocked = false
//                    path = model.imageItem!!.image
//                    dismiss()
//                    assert(instence != null)
//                    instence!!.loadVideoAdMain((activity)!!)
//                    isAdShow = false
//                }
//
//                public override fun onRewardedAdFailedToShow(errorCode: Int) {
//                    // Ad failed to display.
//                    assert(instence != null)
//                    instence!!.loadVideoAdMain((activity)!!)
//
//                    //   showSnackBar(getResources().getString(R.string.something_went_wrong));
//                    Toast.makeText(mAContext, getResources().getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
//                    isAdShow = false
//                }
//            }
//            gameOverRewa.show(mAContext, adCallback)
        } else {
            isAdShow = false
            //showSnackBar(getResources().getString(R.string.something_went_wrong));
            Toast.makeText(mAContext, getResources().getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
        }
    }

    fun createAndLoadRewardedAd(adUnitId: String?): RewardedAd {
//        val rewardedAd: RewardedAd = RewardedAd(mAContext, adUnitId)

        var mRewardedAd: RewardedAd? = null

        var adRequest = AdRequest.Builder().build()

        RewardedAd.load(requireContext(), adUnitId, adRequest, object : RewardedAdLoadCallback() {
            override fun onAdFailedToLoad(adError: LoadAdError) {
//                Log.d(WallpaperOfWeekPagerViewActivity.TAG, adError?.message)
                mRewardedAd = null
            }

            override fun onAdLoaded(rewardedAd: RewardedAd) {
//                Log.d(WallpaperOfWeekPagerViewActivity.TAG, "Ad was loaded.")
                mRewardedAd = rewardedAd
            }
        })

//        val adLoadCallback: RewardedAdLoadCallback = object : RewardedAdLoadCallback() {
//            public override fun onRewardedAdLoaded() {
//                // Ad successfully loaded.
//            }
//
//            public override fun onRewardedAdFailedToLoad(errorCode: Int) {
//                // Ad failed to load.
//            }
//        }
//        rewardedAd.loadAd(AdRequest.Builder().build(), adLoadCallback)
        return mRewardedAd!!
    }

    public override fun onCancel(dialog: DialogInterface) {
        super.onCancel(dialog)
    }

    public override fun onDismiss(dialog: DialogInterface) {
        super.onDismiss(dialog)
        if (onItemSelected != null) onItemSelected!!.onDismiss()
        if (path != null && onItemSelected != null) {
            onItemSelected!!.onItemSelected(path)
        }
    }

    open interface OnItemSelected {
        fun onItemSelected(path: String?)
        fun onDismiss()
    }

    private fun dpToPx(dp: Int): Int {
        val r: Resources = resources
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), r.displayMetrics))
    }

    @Throws(InvocationTargetException::class, NoSuchMethodException::class, ApiNotSupportedException::class, NoSuchFieldException::class, IllegalAccessException::class, NullWifiConfigurationException::class)
    private fun checkStatus() {
//        callApi()
        callNewApi()
//        if (!NetworkHelper.isOnline(mAContext)) {
//            recyclerSnap!!.visibility = View.GONE
//            progressBar!!.visibility = View.GONE
//            Toast.makeText(mAContext, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show()
//            dismiss()
//        } else {
//            if (NetworkHelper.isWifiConnected(mAContext)) {
//                val proxy: WifiConfiguration = WifiConfiguration(mAContext)
//                if (proxy.isProxySetted) {
//                    recyclerSnap!!.visibility = View.GONE
//                    progressBar!!.visibility = View.GONE
//                    Toast.makeText(mAContext, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show()
//                    dismiss()
//                    return
//                }
//            }
//            if (NetworkHelper.isVpnRunning()) {
//                recyclerSnap!!.visibility = View.GONE
//                progressBar!!.visibility = View.GONE
//                Toast.makeText(mAContext, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show()
//                dismiss()
//                return
//            }
//            callApi()
//        }
    }

    fun callNewApi() {
        apiInterface = client!!.create(APIInterface::class.java)
        val call: Call<com.solid.color.wallpaper.hd.image.background.newModel.Response?>? = apiInterface!!.doGetNewListResources()
        call!!.enqueue(object : Callback<com.solid.color.wallpaper.hd.image.background.newModel.Response?> {

            override fun onResponse(call: Call<com.solid.color.wallpaper.hd.image.background.newModel.Response?>, response: retrofit2.Response<com.solid.color.wallpaper.hd.image.background.newModel.Response?>) {
                val model: com.solid.color.wallpaper.hd.image.background.newModel.Response? = response.body()
                mDataListNew!!.clear()

                if (model?.data != null) {
                    mDataListNew!!.addAll(model.data)
                    updateNewUI()
                } else {
                    Toast.makeText(mAContext, getResources().getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
                    dismiss()
                }
            }

            override fun onFailure(call: Call<com.solid.color.wallpaper.hd.image.background.newModel.Response?>, t: Throwable) {
                try {
                    Toast.makeText(mAContext, getResources().getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
                }catch (e:Exception){
                    e.printStackTrace()
                }finally {
                    dismiss()
                }

            }
        })
    }

    private fun callApi() {
        apiInterface = client!!.create(APIInterface::class.java)
        val call: Call<Response?>? = apiInterface!!.doGetListResources()
        call!!.enqueue(object : Callback<Response?> {
            override fun onResponse(call: Call<Response?>, response: retrofit2.Response<Response?>) {
                val model: Response? = response.body()
                mDataList!!.clear()
                if (model?.data != null) {
                    mDataList!!.addAll(model.data)
//                    updateUI()
                } else {
                    Toast.makeText(mAContext, getResources().getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
                    dismiss()
                }
            }

            override fun onFailure(call: Call<Response?>, t: Throwable) {
                Toast.makeText(mAContext, getResources().getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
                dismiss()
            }
        })
    }

    private fun loadInterstialAd() {
        if (instance!!.mInterstitialAd != null) {
            adLayout!!.visibility = View.VISIBLE
            btnShare!!.visibility = View.GONE
        } else {


            if (instance!!.mInterstitialAd != null) {

                instance!!.mInterstitialAd!!.fullScreenContentCallback = null
                instance!!.mInterstitialAd = null
                instance!!.ins_adRequest = null
                instance!!.LoadAds()

                instance!!.mInterstitialAd!!.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
//                    Log.d(TAG, 'Ad was dismissed.')
                    }

                    override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
                        super.onAdFailedToShowFullScreenContent(p0)
                        adLayout!!.visibility = View.GONE
                        btnShare!!.visibility = View.VISIBLE
                        loadInterstialAd()
                    }

                    override fun onAdShowedFullScreenContent() {
//                    Log.d(TAG, 'Ad showed fullscreen content.')
                        adLayout!!.visibility = View.VISIBLE
                        btnShare!!.visibility = View.GONE
                    }
                }
                instance!!.mInterstitialAd!!.show(requireActivity())

//            instance!!.mInterstitialAd!!.adListener = object : AdListener() {
//                 override fun onAdLoaded() {
//                    super.onAdLoaded()
//                    adLayout!!.visibility = View.VISIBLE
//                    btnShare!!.visibility = View.GONE
//                }
//
//                 override fun onAdFailedToLoad(i: Int) {
//                    super.onAdFailedToLoad(i)
//                    adLayout!!.visibility = View.GONE
//                    btnShare!!.visibility = View.VISIBLE
//                    loadInterstialAd()
//                }
//            }
            }
        }
    }

    private fun updateNewUI() {
        mAllReadyData = ArrayList()
        if (mDataListNew!!.size == 0) {
            dismiss()
            return
        }

        categoryNameList = ArrayList()


        for (i in mDataListNew!!.indices) {
            val mForegroundList: ArrayList<ImagesItem?> = ArrayList()

            if (mDataListNew!![i].name!! == "Screen") {
                mForegroundList!!.addAll((mDataListNew!![i].allChilds?.get(i)!!.images)!!)



                for (j in mDataListNew!![i].allChilds!!.indices) {
                    categoryNameList!!.add(CategoryNameIconModel(mDataListNew!![i].allChilds?.get(j)!!.name!!, mDataListNew!![i].allChilds?.get(j)!!.icon.toString()))
                    Log.e("TAG", "assaasdaaasasassaaasasdsas: ${mDataListNew!![i].allChilds?.get(j)!!.images}")

                    mForegroundList.addAll((mDataListNew!![i].allChilds?.get(j)!!.images)!!)

                }

                val mWallpaperList: ArrayList<WallpaperWeekModelNewResponse?> = ArrayList()
                for (j in mForegroundList.indices) {
                    mWallpaperList.add(WallpaperWeekModelNewResponse(mForegroundList[j], mForegroundList[j]!!.isPremium != 0, mForegroundList[j]!!.coins!!))
                }


                mTempForgroundList = ArrayList()

                if (mAContext != null && getBoolean(mAContext, AdsPrefs.IS_SUBSCRIBED, false)) {
                    for (j in mWallpaperList.indices) {
                        mWallpaperList[j]!!.isLocked = false
                    }
                    mTempForgroundList!!.addAll(mWallpaperList)
                } else {
                    for (k in mWallpaperList.indices) {
                        val model: WallpaperWeekModelNewResponse? = mWallpaperList[k]
                        if (dbHelper!!.checkPathExist((model!!.imageItem!!.image)!!)) {
                            model.isLocked = false
                        }
                        mTempForgroundList!!.add(model)
                    }
                }
                mTempForgroundList!!.shuffle()
                mAllReadyData!!.add(mTempForgroundList!!)

            }

        }
        setData()

    }


//    private fun updateUI() {
//        mAllReadyData = ArrayList()
//        if (mDataList!!.size == 0) {
//            dismiss()
//            return
//        }
//        categoryNameList = ArrayList()
//        for (i in mDataList!!.indices) {
//            val mForegroundList: ArrayList<ImageItem?> = ArrayList()
//            mForegroundList!!.addAll((mDataList!![i]!!.image)!!)
//            if (mDataList!![i]!!.name!!.contains("_Screen")) {
//                val name: Array<String> = mDataList!![i]!!.name!!.split("_".toRegex()).toTypedArray()
//                if (name.isEmpty()) {
//                    categoryNameList!!.add(CategoryNameIconModel((mDataList!![i].name)!!, mDataList!![i].icon.toString()))
//                } else {
//                    categoryNameList!!.add(CategoryNameIconModel(name[name.size - 1], mDataList!![i].icon.toString()))
//                }
//                val mWallpaperList: ArrayList<WallpaperWeekModel?> = ArrayList()
//                for (j in mForegroundList.indices) {
//                    mWallpaperList.add(WallpaperWeekModel(mForegroundList[j], mForegroundList[j]!!.isPremium != 0, mForegroundList[j]!!.coins))
//                }
//                mTempForgroundList = ArrayList()
//                if (mAContext != null && getBoolean(mAContext, AdsPrefs.IS_SUBSCRIBED, false)) {
//                    for (j in mWallpaperList.indices) {
//                        mWallpaperList[j]!!.isLocked = false
//                    }
//                    mTempForgroundList!!.addAll(mWallpaperList)
//                } else {
//                    dbHelperSuscription!!.deleteAllData()
//
//                    /*  if (mySharedPref.getAdsRemoved()) {
//                Log.d("456as", "updateUI: pur");
//
//                if (mWallpaperList.size() >= 6) {
//                    for (int i = 0; i < 6; i++) {
//                        mTempForgroundList.add(mWallpaperList.get(i));
//                    }
//                   */
//                    /* for (int i = 0; i < 6; i++) {
//                        mWallpaperList.remove(i);
//                    }*/
//                    /*
//                } else {
//                    mTempForgroundList.addAll(mWallpaperList);
//                    mWallpaperList.clear();
//                }
//
//                boolean flag = true;
//                int conter = 0;
//                int counterPrem = 0;
//                for (int i = 6; i < mWallpaperList.size(); i++) {
//                    WallpaperWeekModel model = mWallpaperList.get(i);
//
//                    if (flag) {
//                        model.setLocked(false);
//                        model.setFree(true);
//                        mTempForgroundList.add(model);
//                        conter++;
//                        if (conter > 5) {
//                            flag = false;
//                            conter = 0;
//                        }
//                    } else {
//                        model.setPremium(true);
//                        model.setFree(false);
//                        mTempForgroundList.add(model);
//                        counterPrem++;
//                        if (counterPrem > 2) {
//                            flag = true;
//                            counterPrem = 0;
//                        }
//                    }
//                }
//
//            } else {*/
///*
//                    if (mWallpaperList.size() >= 6) {
//                        for (int l = 0; l < 6; l++) {
//                            mTempForgroundList.add(mWallpaperList.get(l));
//                        }
//
//                    */
//                    /*for (int i = 0; i < 6; i++) {
//                        mWallpaperList.remove(i);
//                    }*/
//                    /*
//                    } else {
//                        mTempForgroundList.addAll(mWallpaperList);
//                        mWallpaperList.clear();
//                    }
//
//                    boolean flag = true;
//                    int conter = 0;
//                    int counterPrem = 0;*/
//                    for (k in mWallpaperList.indices) {
//                        val model: WallpaperWeekModelNewResponse? = mWallpaperList[k]
//                        if (dbHelper!!.checkPathExist((model!!.imageItem!!.image)!!)) {
//                            model.isLocked = false
//                        }
//                        mTempForgroundList!!.add(model)
//                        //  }
//                    }
//                }
//                //   }
//                mTempForgroundList!!.shuffle()
//                mAllReadyData!!.add(mTempForgroundList!!)
//            }
//        }
//        setData()
//    }
}