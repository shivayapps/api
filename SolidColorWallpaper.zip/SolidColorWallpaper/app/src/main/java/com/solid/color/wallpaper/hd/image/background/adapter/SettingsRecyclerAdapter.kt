package com.solid.color.wallpaper.hd.image.background.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.model.SettingsImagesModel
import java.util.*

class SettingsRecyclerAdapter(val updatedData: ArrayList<SettingsImagesModel>, private val mContext: Context, private val onLongClicked: OnLongClicked) : RecyclerView.Adapter<SettingsRecyclerAdapter.MyViewHolder>() {
    private var isLongPressed = false

    interface OnLongClicked {
        fun onLongClicked(isClicked: Boolean)
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): MyViewHolder {
        return MyViewHolder(LayoutInflater.from(mContext).inflate(R.layout.rv_settings_selectable, null))
    }

    override fun onBindViewHolder(myViewHolder: MyViewHolder, i: Int) {
        myViewHolder.colorImage.setImageBitmap(updatedData[i].bitmap)
        if (isLongPressed) {
            myViewHolder.checkbox.visibility = View.VISIBLE
        } else {
            myViewHolder.checkbox.visibility = View.GONE
        }
        myViewHolder.checkbox.isChecked = updatedData[i].isDeletable
        myViewHolder.checkbox.setOnClickListener {
            if (updatedData[i].isDeletable) {
                myViewHolder.checkbox.isChecked = false
                updatedData[i].isDeletable = false
            } else {
                myViewHolder.checkbox.isChecked = true
                updatedData[i].isDeletable = true
            }
        }
        myViewHolder.imgColor.setOnClickListener {
            if (myViewHolder.checkbox.visibility == View.VISIBLE) {
                if (myViewHolder.checkbox.isChecked) {
                    myViewHolder.checkbox.isChecked = false
                    updatedData[i].isDeletable = false
                } else {
                    myViewHolder.checkbox.isChecked = true
                    updatedData[i].isDeletable = true
                }
            } else {
                isLongPressed = true
                for (j in updatedData.indices) {
                    updatedData[j].isDeletable = false
                }
                updatedData[i].isDeletable = true
                notifyDataSetChanged()
                onLongClicked.onLongClicked(true)
            }
        }

        /*  myViewHolder.imgColor.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (myViewHolder.checkbox.getVisibility() != View.VISIBLE) {
                    isLongPressed = true;
                    for (int j = 0; j < mColors.size(); j++) {
                        mColors.get(j).setDeletable(false);
                    }
                    mColors.get(i).setDeletable(true);
                    notifyDataSetChanged();
                    onLongClicked.onLongClicked(true);
                    return true;
                } else {
                    return false;
                }
            }
        });*/
    }

    fun setDataChanged() {
        isLongPressed = false
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int {
        return updatedData.size
    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var imgColor: CardView = itemView.findViewById(R.id.imgColor)
        val colorImage: ImageView = itemView.findViewById(R.id.colorImage)
        val checkbox: CheckBox = itemView.findViewById(R.id.checkbox)

    }

}