package com.solid.color.wallpaper.hd.image.background.PaintViewFol.drawing

import android.graphics.Path
import android.text.TextPaint

data class FingerPath(var text:String,var mPath: Path?, var paint: TextPaint?)
