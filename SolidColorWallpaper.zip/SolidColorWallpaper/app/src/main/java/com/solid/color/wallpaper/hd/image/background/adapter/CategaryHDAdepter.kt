package com.solid.color.wallpaper.hd.image.background.adapter

import android.annotation.SuppressLint
import android.graphics.Color
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.activity.WallpaperOfWeekNewActivity
import com.solid.color.wallpaper.hd.image.background.constants.Constants
import com.solid.color.wallpaper.hd.image.background.imagePicker.model.Constant
import com.solid.color.wallpaper.hd.image.background.imagePicker.model.Image

class CategaryHDAdepter(
    var wallpaperOfWeekNewActivity: WallpaperOfWeekNewActivity,
    var newList: MutableList<String>,
    var mViewHD : OnClickHdListener
) : RecyclerView.Adapter<CategaryHDAdepter.MyViewHolder>() {
    
//    var mPosition = -1

    interface OnClickHdListener{
        fun onClickHD(position: Int,nCatName :String){}
    }


    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var txtCat = itemView.findViewById<TextView>(R.id.txtCat)
//        var imgseletion = itemView.findViewById<ImageView>(R.id.imgSelection)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): CategaryHDAdepter.MyViewHolder {

        val view = LayoutInflater.from(wallpaperOfWeekNewActivity).inflate(R.layout.hdcategory_layout,parent,false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: CategaryHDAdepter.MyViewHolder, @SuppressLint("RecyclerView") position: Int) {
        holder.txtCat.text = newList[position].trim()
        Log.d("TAG", "onBindViewHolder: "+newList[position].length)
        Log.d("TAG", "onBindViewHolder:sizw "+position +"==" + Constants.HDposition)
        if(position == Constants.HDposition){
            holder.txtCat.setTextColor(Color.WHITE)
            holder.txtCat.setBackgroundResource(R.drawable.ic_selection_cat_custom)
//            holder.txtCat.setBackgroundResource(Color.parseColor("#FF4551"))
            mViewHD.onClickHD(position,newList[position])
        }else{
            if (Constants.HDposition == 5){
                holder.txtCat.setTextColor(Color.WHITE)
                holder.txtCat.setBackgroundResource(R.drawable.ic_selection_cat_custom)
                mViewHD.onClickHD(5,newList[5])
            }else{
                holder.txtCat.setTextColor(Color.BLACK)
                holder.txtCat.setBackgroundResource(R.drawable.ic_selection_cat_custom_white)
            }
            holder.txtCat.setTextColor(Color.BLACK)
            holder.txtCat.setBackgroundResource(R.drawable.ic_selection_cat_custom_white)

//            holder.txtCat.setColorFilter(Color.parseColor("#f6f6f6"))
        }


        holder.itemView.setOnClickListener {
            Constants.HDposition = position
            mViewHD.onClickHD(position,newList[position])
            Log.e("TAG", "onBindViewHolder p: ${newList[position]}")
            notifyDataSetChanged()
        }
    }

    fun setData(newApples: MutableList<String>) {
        newList = newApples
    }

    override fun getItemCount(): Int {
        return newList.size
    }
}