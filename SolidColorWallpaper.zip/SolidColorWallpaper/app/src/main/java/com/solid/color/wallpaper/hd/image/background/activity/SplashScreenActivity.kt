package com.solid.color.wallpaper.hd.image.background.activity

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import android.util.TypedValue
import android.view.View
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.airbnb.lottie.LottieAnimationView
import com.google.android.gms.common.GooglePlayServicesUtil
import com.solid.color.wallpaper.hd.image.background.adshalper.AppOpenManager
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.Helper
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.SolidWallpaperApplication
import com.solid.color.wallpaper.hd.image.background.SolidWallpaperApplication.Companion.instance
import com.solid.color.wallpaper.hd.image.background.helper.InAppBillingHandler.Companion.bindServiceIntent
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs.getBoolean
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs.save
import com.solid.color.wallpaper.hd.image.background.shared_pref.MySharedPref
import com.vasundhara.vision.subscription.billing.subscriptionForSku
import com.vasundhara.vision.subscription.constants.Constants
import com.vasundhara.vision.subscription.constants.Constants.FIVE_HUNDRED
import com.vasundhara.vision.subscription.constants.Constants.TEN_THOUSAND
import com.vasundhara.vision.subscription.constants.Constants.TWO_THOUSAND
import com.vasundhara.vision.subscription.ui.SubSplashBaseActivity
import org.json.JSONException
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class SplashScreenActivity : SubSplashBaseActivity() {
    private val animation: LottieAnimationView? = null
    private val animation1: LottieAnimationView? = null

    //TODO: In App Purchase
    var LicenseKey: String = ""
    private var mContext: Context? = null
    private var productKeyMonth: String = "" /*productKeyMonthDiscount = "",*/
    private var productKey3Month: String = ""

    /*productKeyMonthDiscount = "",*/
    private var productKeyYear: String = ""
    private var productKeyRemoveAds: String = ""
    private var isAnimEnd: Boolean = false
    private var sharedPref: MySharedPref? = null
    private val txtSolidColor: ImageView? = null
    private val imgLogo: ImageView? = null
    private var view1: View? = null
    private var view2: View? = null
    private var view3: View? = null
    private var view4: View? = null
    private var view5: View? = null
    private var view6: View? = null

    var mServiceConn: ServiceConnection = object : ServiceConnection {
        public override fun onServiceDisconnected(name: ComponentName) {}
        public override fun onServiceConnected(name: ComponentName, service: IBinder) {
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)
        Helper().startDataSync(this, this)
//        mInterstitialAd = InterstitialAd(this)
        instance!!.openManager.fetchAd()
        if (!getBoolean(this@SplashScreenActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
            instance!!.openManager.fetchAd()
        }

        mContext = this@SplashScreenActivity
        sharedPref = MySharedPref(mContext)
        initBillingProcessor()
        hideSystemUI()
        view1 = findViewById(R.id.view1)
        view2 = findViewById(R.id.view2)
        view3 = findViewById(R.id.view3)
        view4 = findViewById(R.id.view4)
        view5 = findViewById(R.id.view5)
        view6 = findViewById(R.id.view6)
        findViewById<View>(R.id.bottom_text_cst).post {
            Log.d("TAG=====>", "run: " + findViewById<View>(R.id.bottom_text_cst).height)
            findViewById<View>(R.id.img_main_vector).animate().translationYBy(-findViewById<View>(R.id.bottom_text_cst).height.toFloat()).setDuration(1000).withEndAction {
                findViewById<View>(R.id.bottom_text_cst).visibility = View.VISIBLE
                findViewById<View>(R.id.bottom_text_cst).animate().alpha(1f).setDuration(400).start()
                view1!!.animate().alpha(0.15f).setDuration(100).withEndAction {
                    view2!!.animate().alpha(0.15f).setDuration(100).withEndAction {
                        view3!!.animate().alpha(0.15f).setDuration(100).withEndAction {
                            view4!!.animate().alpha(0.15f).setDuration(100).withEndAction {
                                view5!!.animate().alpha(0.15f).setDuration(100).withEndAction {
                                    view6!!.animate().alpha(0.15f).setDuration(100).withEndAction {
                                        view1!!.animate().translationX(-200f).setDuration(20000).start()
                                        view1!!.animate().translationY(200f).setDuration(20000).start()
                                        view2!!.animate().translationXBy(200f).setDuration(20000).start()
                                        view2!!.animate().translationYBy(-200f).setDuration(20000).start()
                                        view3!!.animate().translationX(-200f).setDuration(20000).start()
                                        view3!!.animate().translationYBy(200f).setDuration(20000).start()
                                        view4!!.animate().translationX(100f).setDuration(20000).start()
                                        view4!!.animate().translationY(-200f).setDuration(20000).start()
                                        view5!!.animate().translationXBy(-200f).setDuration(20000).start()
                                        view5!!.animate().translationY(-200f).setDuration(20000).start()
                                        view6!!.animate().translationX(200f).setDuration(20000).start()
                                        view6!!.animate().translationYBy(-100f).setDuration(20000).start()
                                    }.start()
                                }.start()
                            }.start()
                        }.start()
                    }.start()
                }.start()
            }.start()
        }

        Handler().postDelayed({
            if (!isFinishing) {
                if (sharedPref!!.needToshowLanguage()) {
                    val c: Date = Calendar.getInstance().time
                    val df: SimpleDateFormat = SimpleDateFormat("dd-MMM-yyyy")
                    val formattedDate: String = df.format(c)
                    instance!!.openManager?.showAdIfAvailable {
                        when (it) {
                            AppOpenManager.CallBackType.DISMISS -> {
                                if (isFinishing)
                                    return@showAdIfAvailable

                                save(this@SplashScreenActivity, AdsPrefs.ADS_FREE_DATE, formattedDate)
                                startActivity(Intent(this@SplashScreenActivity, LanguageSelectionActivity::class.java))
                                finish()
                            }
                            AppOpenManager.CallBackType.FAILED -> {
                                if (isFinishing)
                                    return@showAdIfAvailable


                                save(this@SplashScreenActivity, AdsPrefs.ADS_FREE_DATE, formattedDate)
                                startActivity(Intent(this@SplashScreenActivity, LanguageSelectionActivity::class.java))
                                finish()
                            }
                            AppOpenManager.CallBackType.ERROR -> {
                                if (isFinishing)
                                    return@showAdIfAvailable


                                save(this@SplashScreenActivity, AdsPrefs.ADS_FREE_DATE, formattedDate)
                                startActivity(Intent(this@SplashScreenActivity, LanguageSelectionActivity::class.java))
                                finish()
                            }
                        }
                    }

                } else if (!getBoolean(this@SplashScreenActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                    instance!!.openManager?.showAdIfAvailable {
                        when (it) {
                            AppOpenManager.CallBackType.DISMISS -> {
                                if (isFinishing)
                                    return@showAdIfAvailable
                                Handler(Looper.getMainLooper()).postDelayed({
                                    startActivity(Intent(this@SplashScreenActivity, MainStartActivity::class.java))
                                    finish()
                                }, 100)
                            }
                            AppOpenManager.CallBackType.FAILED -> {
                                if (isFinishing)
                                    return@showAdIfAvailable

                                startActivity(Intent(this@SplashScreenActivity, MainStartActivity::class.java))
                                finish()
                            }
                            AppOpenManager.CallBackType.ERROR -> {
                                if (isFinishing)
                                    return@showAdIfAvailable

                                startActivity(Intent(this@SplashScreenActivity, MainStartActivity::class.java))
                                finish()
                            }
                        }
                    }
                } else {
                    startActivity(Intent(this@SplashScreenActivity, MainStartActivity::class.java))
                    finish()

                }
            }
        }, 8000)
    }

    override fun registerPurchases(isSubscribe: Boolean, paymentState: Int, sku: String, orderId: String) {
        Log.e(TAG, "registerPurchases: isSubscribe : ${isSubscribe}  ${sku}  ${orderId}")
        if (sku == FIVE_HUNDRED || sku == TWO_THOUSAND || sku == TEN_THOUSAND){
            AdsPrefs.save(this@SplashScreenActivity, AdsPrefs.IS_SUBSCRIBED, false);
        }
        if (sku == Constants.BASIC_SKU || sku == Constants.PREMIUM_SKU || sku == Constants.PREMIUM_SIX_SKU){
            AdsPrefs.save(this@SplashScreenActivity, AdsPrefs.IS_SUBSCRIBED, isSubscribe);
        }
    }

    private fun initBillingProcessor() {
        //productKeyMonthDiscount = getString(R.string.ads_product_key_monthlydiscount);
        productKeyMonth = getString(R.string.ads_product_key_month)
        productKey3Month = getString(R.string.ads_product_key_month_3)
        productKeyYear = getString(R.string.ads_product_key_year)
        productKeyRemoveAds = getString(R.string.ads_product_key)
        LicenseKey = getString(R.string.licenseKey)
        Log.d("TAG=========>", "initBillingProcessor: ")
        bindServices()
    }

    private fun bindServices() {
        try {
            bindService(bindServiceIntent, mServiceConn, Context.BIND_AUTO_CREATE)
        } catch (e: Exception) {
            Log.d("TAG=====>>>>>", "bindServices: catch ")
            e.printStackTrace()
        }
    }

    private fun hideSystemUI() {
        // Set the IMMERSIVE flag.
        // Set the content to appear under the system bars so that the content
        // doesn't resize when the system bars hide and show.
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN /*
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION // hide nav bar*/
                or View.SYSTEM_UI_FLAG_FULLSCREEN // hide status bar
                or View.SYSTEM_UI_FLAG_IMMERSIVE)
        window.decorView.setOnSystemUiVisibilityChangeListener { i ->
            if (i == 0 && View.SYSTEM_UI_FLAG_FULLSCREEN == 0) {
                window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN /*
                                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION // hide nav bar*/
                        or View.SYSTEM_UI_FLAG_FULLSCREEN // hide status bar
                        or View.SYSTEM_UI_FLAG_IMMERSIVE)
            }
        }
    }

//    private fun checkSkuDetails() {
//        Log.d(TAG, "checkSkuDetails: ")
//        try {
//
//            val skuList: ArrayList<String> = ArrayList()
//
//            skuList.add(getResources().getString(R.string.ads_product_key_month))
//            skuList.add(getResources().getString(R.string.ads_product_key_year))
//            skuList.add(getResources().getString(R.string.ads_product_key_month_3))
//            skuList.add(getResources().getString(R.string.product_key_500_coin))
//            skuList.add(getResources().getString(R.string.product_key_2000_coin))
//            skuList.add(getResources().getString(R.string.product_key_10000_coin))
//            val querySkus: Bundle = Bundle()
//            querySkus.putStringArrayList("ITEM_ID_LIST", skuList)
//            val owned_sub: Bundle = mService!!.getSkuDetails(3, packageName, "subs", querySkus)
//            val responseSub: Int = owned_sub.getInt("RESPONSE_CODE")
//            val owned_sub1: Bundle = mService!!.getSkuDetails(3, packageName, "inapp", querySkus)
//            val responseSub1: Int = owned_sub1.getInt("RESPONSE_CODE")
//
//            Log.i(TAG, "checkSkuDetails: 11: $querySkus")
//
//            if (responseSub1 == 0) {
//                val responseList: ArrayList<String>? = owned_sub1.getStringArrayList("DETAILS_LIST")
//                Log.i(TAG, "checkSkuDetails: 11: " + responseList.toString())
//                for (i in responseList!!.indices) {
//                    try {
//                        val `object`: JSONObject = JSONObject(responseList.get(i))
//                        if (`object`.getString("productId").equals(getResources().getString(R.string.product_key_500_coin), ignoreCase = true)) {
//                            Log.e(TAG, "checkSkuDetails: 500 COIN PRICE : " + `object`.getString("price"))
//                            val price500: String = `object`.getString("price")
//                            save(mContext, AdsPrefs.PLAN_500_COIN, price500)
//                        }
//                        if (`object`.getString("productId").equals(getResources().getString(R.string.product_key_2000_coin), ignoreCase = true)) {
//                            Log.e(TAG, "checkSkuDetails: 2000 COIN PRICE : " + `object`.getString("price"))
//                            val price2000: String = `object`.getString("price")
//                            save(mContext, AdsPrefs.PLAN_2000_COIN, price2000)
//                        }
//                        if (`object`.getString("productId").equals(getResources().getString(R.string.product_key_10000_coin), ignoreCase = true)) {
//                            Log.e(TAG, "checkSkuDetails: 10000 COIN PRICE : " + `object`.getString("price"))
//                            val price10000: String = `object`.getString("price")
//                            save(mContext, AdsPrefs.PLAN_10000_COIN, price10000)
//                        }
//                    } catch (e1: JSONException) {
//                        e1.printStackTrace()
//                    }
//                }
//            }
//            if (responseSub == 0) {
//                val responseList: ArrayList<String>? = owned_sub.getStringArrayList("DETAILS_LIST")
//                Log.i(TAG, "checkSkuDetails: 11: " + responseList.toString())
//                for (i in responseList!!.indices) {
//                    try {
//                        val `object`: JSONObject = JSONObject(responseList[i])
//                        if (`object`.getString("productId").equals(productKeyMonth, ignoreCase = true)) {
//                            Log.e(TAG, "checkSkuDetails: MONTH PRICE : " + `object`.getString("price"))
//                            val priceYear: String = `object`.getString("price")
//                            save(mContext, AdsPrefs.PRICE_MONTH, priceYear)
//                        }
//                        if (`object`.getString("productId").equals(productKey3Month, ignoreCase = true)) {
//                            Log.e(TAG, "checkSkuDetails: MONTH 3 PRICE : " + `object`.getString("price"))
//                            val price3Month: String = `object`.getString("price")
//                            Log.e(TAG, "checkSkuDetails123: $price3Month" )
//                            save(mContext, AdsPrefs.PRICE_MONTH_3, price3Month)
//                        }
//
//
//                        if (`object`.getString("productId").equals(productKeyYear, ignoreCase = true)) {
//                            Log.e(TAG, "checkSkuDetails: YEAR PRICE : " + `object`.getString("price"))
//                            val priceYear: String = `object`.getString("price")
//                            save(mContext, AdsPrefs.PRICE_YEAR, priceYear)
//                        }
//                    } catch (e1: JSONException) {
//                        e1.printStackTrace()
//                    }
//                }
//            }
//            if (billingProcessor != null) {
//                val listBuySubscriptions: List<String> = billingProcessor!!.listOwnedSubscriptions()
//                Log.e(TAG, "checkSkuDetails: listBuySubscriptions size ::  " + listBuySubscriptions.size)
//                if (listBuySubscriptions.isNotEmpty()) {
//                    val subscriptionTransactionDetails: TransactionDetails? = billingProcessor!!.getSubscriptionTransactionDetails(listBuySubscriptions[listBuySubscriptions.size - 1])
//
//                    if (subscriptionTransactionDetails != null) {
//                        Log.e(TAG, "checkSkuDetails:  developerPayload :: -> " + subscriptionTransactionDetails.purchaseInfo.purchaseData.developerPayload)
//                        Log.e(TAG, "checkSkuDetails:  orderId :: -> " + subscriptionTransactionDetails.purchaseInfo.purchaseData.orderId)
//                        Log.e(TAG, "checkSkuDetails:  productId :: -> " + subscriptionTransactionDetails.purchaseInfo.purchaseData.productId)
//                        Log.e(TAG, "checkSkuDetails:  packageName :: -> " + subscriptionTransactionDetails.purchaseInfo.purchaseData.packageName)
//                        Log.e(TAG, "checkSkuDetails:  purchaseToken :: -> " + subscriptionTransactionDetails.purchaseInfo.purchaseData.purchaseToken)
//                        Log.e(TAG, "checkSkuDetails:  autoRenewing :: -> " + subscriptionTransactionDetails.purchaseInfo.purchaseData.autoRenewing)
//                        Log.e(TAG, "checkSkuDetails:  purchaseTime :: -> " + subscriptionTransactionDetails.purchaseInfo.purchaseData.purchaseTime.toGMTString())
//                        Log.e(TAG, "checkSkuDetails:  purchaseState :: -> " + subscriptionTransactionDetails.purchaseInfo.purchaseData.purchaseState)
//                        Log.e(TAG, "checkSkuDetails:  responseData :: -> " + subscriptionTransactionDetails.purchaseInfo.responseData)
//                        Log.e(TAG, "checkSkuDetails:  signature :: -> " + subscriptionTransactionDetails.purchaseInfo.signature)
//                        Log.e(TAG, "checkSkuDetails:  describeContents :: -> " + subscriptionTransactionDetails.purchaseInfo.purchaseData.describeContents())
//                    }
//
//                    if (billingProcessor!!.isSubscribed(listBuySubscriptions.get(listBuySubscriptions.size - 1)) && billingProcessor!!.loadOwnedPurchasesFromGoogle()) {
//                        Log.e(TAG, "checkSkuDetails:  isSubscribed :: -> true")
//                        Log.e(TAG, "checkSkuDetails: subscriptionTransactionDetails is not " + "null---- ")
//                        assert(subscriptionTransactionDetails != null)
//                        if (subscriptionTransactionDetails!!.purchaseInfo.purchaseData.productId.equals(productKeyMonth, ignoreCase = true)) {
//                            Log.e(TAG, "checkSkuDetails: product month match ")
//                            if (billingProcessor!!.isSubscribed(productKeyMonth)) {
//                                Log.e(TAG, "checkSkuDetails:  month is subscribed --")
//                                // TODO Maulik: 2019-08-06 12:50  for check autorenuing is
//                                //  true or not for year
//                                save(mContext, AdsPrefs.IS_AUTO_RENEW_MONTH, subscriptionTransactionDetails.purchaseInfo.purchaseData.autoRenewing)
//                                save(mContext, AdsPrefs.PURCHASED_PLAN_ID, "3")
//                                startMain(true)
//                            } else {
//                                startMain(false)
//                                Log.e(TAG, "checkSkuDetails:  Not Subscribe Month----")
//                            }
//                        } else if (subscriptionTransactionDetails.purchaseInfo.purchaseData.productId.equals(productKey3Month, ignoreCase = true)) {
//                            Log.e(TAG, "checkSkuDetails: product month match ")
//                            if (billingProcessor!!.isSubscribed(productKey3Month)) {
//                                Log.e(TAG, "checkSkuDetails:  month is subscribed --")
//                                // TODO Maulik: 2019-08-06 12:50  for check autorenuing is
//                                //  true or not for year
//                                save(mContext, AdsPrefs.IS_AUTO_RENEW_3_MONTH, subscriptionTransactionDetails.purchaseInfo.purchaseData.autoRenewing)
//                                save(mContext, AdsPrefs.PURCHASED_PLAN_ID, "5")
//                                startMain(true)
//                            } else {
//                                startMain(false)
//                                Log.e(TAG, "checkSkuDetails:  Not Subscribe Month----")
//                            }
//                        } else if (subscriptionTransactionDetails.purchaseInfo.purchaseData.productId.equals(productKeyYear, ignoreCase = true)) {
//                            Log.e(TAG, "checkSkuDetails: product year match ")
//                            if (billingProcessor!!.isSubscribed(productKeyYear)) {
//                                Log.e(TAG, "checkSkuDetails:  year is subscribed --")
//                                // TODO Maulik: 2019-08-06 12:50  for check autorenuing is
//                                //  true or not for year
//                                save(mContext, AdsPrefs.IS_AUTO_RENEW_YEAR, subscriptionTransactionDetails.purchaseInfo.purchaseData.autoRenewing)
//                                save(mContext, AdsPrefs.PURCHASED_PLAN_ID, "4")
//                                startMain(true)
//                            } else {
//                                startMain(false)
//                                Log.e(TAG, "checkSkuDetails:  Not Subscribe Year----")
//                            }
//                        }
//                    } else {
//                        Log.e(TAG, "checkSkuDetails:  isSubscribed :: -> false")
//                        Log.e(TAG, "checkSkuDetails: subscriptionTransactionDetails is NULL " + "WHAT TO DO NOW !!!")
//                        save(mContext, AdsPrefs.IS_AUTO_RENEW_WEEK, false)
//                        save(mContext, AdsPrefs.IS_AUTO_RENEW_MONTH_DISCOUNT, false)
//                        save(mContext, AdsPrefs.IS_AUTO_RENEW_MONTH, false)
//                        save(mContext, AdsPrefs.IS_AUTO_RENEW_3_MONTH, false)
//                        save(mContext, AdsPrefs.IS_AUTO_RENEW_YEAR, false)
//                        save(mContext, AdsPrefs.PURCHASED_PLAN_ID, "1")
//                        startMain(false)
//                    }
//                } else {
//                    Log.e(TAG, "checkSkuDetails:  isSubscribed :: -> false")
//                    Log.e(TAG, "checkSkuDetails: SIZE  zero of subscribe ------------")
//                    save(mContext, AdsPrefs.IS_AUTO_RENEW_WEEK, false)
//                    save(mContext, AdsPrefs.IS_AUTO_RENEW_MONTH_DISCOUNT, false)
//                    save(mContext, AdsPrefs.IS_AUTO_RENEW_MONTH, false)
//                    save(mContext, AdsPrefs.IS_AUTO_RENEW_YEAR, false)
//                    save(mContext, AdsPrefs.IS_AUTO_RENEW_3_MONTH, false)
//                    save(mContext, AdsPrefs.PURCHASED_PLAN_ID, "1")
//                    startMain(false)
//                }
//            } else {
//                startMain(false)
//            }
//            // }
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
//    }

    fun startMain(value: Boolean) {
        save(mContext, AdsPrefs.IS_SUBSCRIBED, value)
        Log.e(TAG, "checkSkuDetails:  isSubscribed :: ->$value")

        if (isAnimEnd) {
            if (sharedPref!!.needToshowLanguage()) {
                instance!!.openManager?.showAdIfAvailable {
                    when (it) {
                        AppOpenManager.CallBackType.DISMISS -> {
                            if (isFinishing)
                                return@showAdIfAvailable

                            startActivity(Intent(this@SplashScreenActivity, LanguageSelectionActivity::class.java))
                            finish()
                        }
                        AppOpenManager.CallBackType.FAILED -> {
                            if (isFinishing)
                                return@showAdIfAvailable


                            startActivity(Intent(this@SplashScreenActivity, LanguageSelectionActivity::class.java))
                            finish()
                        }
                        AppOpenManager.CallBackType.ERROR -> {
                            if (isFinishing)
                                return@showAdIfAvailable


                            startActivity(Intent(this@SplashScreenActivity, LanguageSelectionActivity::class.java))
                            finish()
                        }
                    }
                }

            } else if (!getBoolean(this@SplashScreenActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                instance!!.openManager?.showAdIfAvailable {
                    when (it) {
                        AppOpenManager.CallBackType.DISMISS -> {
                            if (isFinishing)
                                return@showAdIfAvailable
                            Handler(Looper.getMainLooper()).postDelayed({
                                startActivity(Intent(this@SplashScreenActivity, MainStartActivity::class.java))
                                finish()
                            }, 100)
                        }
                        AppOpenManager.CallBackType.FAILED -> {
                            if (isFinishing)
                                return@showAdIfAvailable

                            startActivity(Intent(this@SplashScreenActivity, MainStartActivity::class.java))
                            finish()
                        }
                        AppOpenManager.CallBackType.ERROR -> {
                            if (isFinishing)
                                return@showAdIfAvailable

                            startActivity(Intent(this@SplashScreenActivity, MainStartActivity::class.java))
                            finish()
                        }
                    }
                }
            } else {
                startActivity(Intent(this@SplashScreenActivity, MainStartActivity::class.java))
                finish()
            }
        } else {
            isAnimEnd = true
        }
    }

//    private lateinit var mInterstitialAd: InterstitialAd

//    private fun loadInterstialAd() {
//        var adsId = AppIDs.instnace!!.getGoogleInterstitial()
//        mInterstitialAd.adUnitId = adsId
//        mInterstitialAd.adListener = object : AdListener() {
//            override fun onAdLoaded() {
//                // Code to be executed when an ad finishes loading.
//            }
//
//            override fun onAdFailedToLoad(adError: LoadAdError) {
//                // Code to be executed when an ad request fails.
//            }
//
//            override fun onAdOpened() {
//                // Code to be executed when the ad is displayed.
//            }
//
//            override fun onAdClicked() {
//                // Code to be executed when the user clicks on an ad.
//            }
//
//            override fun onAdLeftApplication() {
//                // Code to be executed when the user has left the app.
//            }
//
//            override fun onAdClosed() {
//                startActivity(Intent(this@SplashScreenActivity, MainStartActivity::class.java))
//                finish()
//            }
//        }
//        mInterstitialAd.loadAd(AdRequest.Builder().build())
//    }

    override fun onResume() {
        super.onResume()
        SolidWallpaperApplication.staticLanguage.Factory.create(this)
    }

    public override fun onDestroy() {
        try {
            unbindService(mServiceConn)
        } catch (e: java.lang.Exception) {
        }
        super.onDestroy()
    }


    companion object {
        private val TAG: String = "SplashScreen12345"
        fun isPlayStoreInstalled(context: Context): Boolean {
            try {
                context.packageManager
                        .getPackageInfo(GooglePlayServicesUtil.GOOGLE_PLAY_STORE_PACKAGE, 0)
                return true
            } catch (e: PackageManager.NameNotFoundException) {
                return false
            }
        }
    }
}