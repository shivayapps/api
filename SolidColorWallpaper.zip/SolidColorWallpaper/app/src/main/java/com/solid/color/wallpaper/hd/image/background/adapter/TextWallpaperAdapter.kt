package com.solid.color.wallpaper.hd.image.background.adapter

import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.solid.color.wallpaper.hd.image.background.R
import java.util.*

class TextWallpaperAdapter(private val mContext: Context, private val mImageList: ArrayList<String>, private val onClickImage: OnClickImage) : RecyclerView.Adapter<TextWallpaperAdapter.MyViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val v = LayoutInflater.from(mContext).inflate(R.layout.row_text_wallpaper, null)
        return MyViewHolder(v)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        Glide.with(mContext).load(mImageList[position]).into(object : CustomTarget<Drawable?>() {
            override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                holder.imgEmoji.background = resource
            }

            override fun onLoadCleared(placeholder: Drawable?) {}
        })
        holder.imgEmoji.setOnClickListener { onClickImage.onClickImage(position) }
    }

    override fun getItemCount(): Int {
        return mImageList.size
    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var imgEmoji: ImageView

        init {
            imgEmoji = itemView.findViewById(R.id.imgImage)
        }
    }

    interface OnClickImage {
        fun onClickImage(i: Int)
    }

}