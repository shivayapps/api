package com.solid.color.wallpaper.hd.image.background.adapter

import android.content.Context
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.model.ColorModel
import java.util.*

class GradientColorAdapter(private val mColors: ArrayList<ColorModel>, private val mImageList: ArrayList<String>, private val mContext: Context, private val mListener: setOnItemClickListener) : RecyclerView.Adapter<GradientColorAdapter.MyViewHolder>() {
    private var LastSelectedView: MyViewHolder? = null
    private var LastSelectedItem: ColorModel? = null
    private var orientation = GradientDrawable.Orientation.TOP_BOTTOM
    private var mCurrentOrientation = 0
    private val orientations = arrayOf(
            GradientDrawable.Orientation.TOP_BOTTOM,
            GradientDrawable.Orientation.TR_BL,
            GradientDrawable.Orientation.RIGHT_LEFT,
            GradientDrawable.Orientation.BR_TL,
            GradientDrawable.Orientation.BOTTOM_TOP,
            GradientDrawable.Orientation.BL_TR,
            GradientDrawable.Orientation.LEFT_RIGHT,
            GradientDrawable.Orientation.TL_BR
    )

    interface setOnItemClickListener {
        fun OnItemClicked(color: ColorModel?, i: Int)
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): MyViewHolder {
        return MyViewHolder(LayoutInflater.from(mContext).inflate(R.layout.row_color, null))
    }

    override fun onBindViewHolder(myViewHolder: MyViewHolder, i: Int) {
        val colors = intArrayOf(mColors[i].color1, mColors[i].color2)
        mCurrentOrientation = (mCurrentOrientation + 1) % orientations.size
        orientation = orientations[mCurrentOrientation]
        if (mColors[i].circle) {
            val shape = GradientDrawable()
            shape.shape = GradientDrawable.RECTANGLE
            shape.setColors(colors)
            shape.gradientType = GradientDrawable.RADIAL_GRADIENT
            shape.gradientRadius = (if (myViewHolder.imgColor.width == 0) 200F else myViewHolder.imgColor.width.toFloat())
            myViewHolder.colorImage.background = shape
        } else {
            val shape = GradientDrawable(mColors[i].orientation, colors)
            shape.shape = GradientDrawable.RECTANGLE
            //shape.setColor(mColors.get(i));
            myViewHolder.colorImage.background = shape
        }
        if (mColors[i].imagePosition != -1) {
            Glide.with(mContext).load(mImageList[mColors[i].imagePosition]).into(object : CustomTarget<Drawable?>() {
                override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                    //  resource.setColorFilter(mColors.get(i).getColorFilterColor(), PorterDuff.Mode.SRC_IN);
                    myViewHolder.imgEmoji.setImageDrawable(resource)
                }

                override fun onLoadCleared(placeholder: Drawable?) {}
            })
        } else {
            myViewHolder.imgEmoji.setImageBitmap(null)
        }
        myViewHolder.imgColor.setOnClickListener {
            mListener.OnItemClicked(mColors[i], i)
            LastSelectedView = myViewHolder
            LastSelectedItem = mColors[i]
        }
    }

    override fun getItemCount(): Int {
        return mColors.size
    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var imgColor: CardView = itemView.findViewById(R.id.imgColor)
        val imgEmoji: ImageView = itemView.findViewById(R.id.imgEmoji)
        val colorImage: ImageView = itemView.findViewById(R.id.colorImage)

    }

}