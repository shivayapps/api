package com.solid.color.wallpaper.hd.image.background.model

import android.graphics.Bitmap

class SettingsImagesModel(var bitmap: Bitmap, var isDeletable: Boolean)