package com.solid.color.wallpaper.hd.image.background.model

class GradientSelectableModel(var colorModel: ColorModel, var isDeletable: Boolean)