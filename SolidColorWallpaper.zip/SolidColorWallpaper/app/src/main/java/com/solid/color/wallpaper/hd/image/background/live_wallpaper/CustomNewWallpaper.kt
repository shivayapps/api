package com.solid.color.wallpaper.hd.image.background.live_wallpaper

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.os.Handler
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import com.solid.color.wallpaper.hd.image.background.constants.Constants
import com.solid.color.wallpaper.hd.image.background.live_wallpaper.CustomNewWallpaper

class CustomNewWallpaper : WallpaperService() {
    var canvasWidth = 200
    var canvasHeight = 200
    var timeInterval = 8
    var mBitmap: Bitmap? = null

    internal inner class WallpaperEngine : Engine() {
        private var isVisibilityChanged = false
        private val paint: Paint? = null
        internal var surfaceHolder = getSurfaceHolder()
        private val handler = Handler()
        private val runnable = Runnable {
            try {
                WallpaperEng()
            } catch (throwable: Throwable) {
                throwable.printStackTrace()
            }
        }

        @Throws(Throwable::class)
        fun WallpaperEng() {
            var canvas: Canvas?
            var th: Throwable?
            try {
                canvas = surfaceHolder.lockCanvas()
                if (canvas != null) {
                    try {
                        canvasHeight = canvas.height
                        canvasWidth = canvas.width
                        val liveWallpaper = this@CustomNewWallpaper
                        liveWallpaper.mBitmap = Constants.mWallpaperBitmap
                        if (mBitmap == null) {
                            //  LiveWallpaper.this.i = BitmapFactory.decodeResource(LiveWallpaper.this.getResources(), R.drawable.k9);
                        }
                        assert(mBitmap != null)
                        mBitmap = Bitmap.createScaledBitmap(mBitmap!!, canvasWidth, canvasHeight, false)
                        canvas.drawBitmap(mBitmap!!, 0.0f, 0.0f, paint)
                    } catch (th2: Throwable) {
                        th = th2
                        if (canvas != null) {
                            surfaceHolder.unlockCanvasAndPost(canvas)
                        }
                        throw th
                    }
                }
                if (canvas != null) {
                    surfaceHolder.unlockCanvasAndPost(canvas)
                }
                handler.removeCallbacks(runnable)
                if (isVisibilityChanged) {
                    handler.postDelayed(runnable, timeInterval.toLong())
                }
            } catch (th3: Throwable) {
                canvas = null
                th = th3
                throw th
            }
        }

        private val data: Unit
            private get() {
                try {
                    timeInterval = 8
                    mBitmap = Constants.mWallpaperBitmap
                } catch (unused: Exception) {
                    unused.printStackTrace()
                }
            }

        override fun onDestroy() {
            super.onDestroy()
            isVisibilityChanged = false
            handler.removeCallbacks(runnable)
        }

        override fun onSurfaceChanged(surfaceHolder: SurfaceHolder, i: Int, i2: Int, i3: Int) {
            try {
                data
                WallpaperEng()
            } catch (unused: Exception) {
                unused.printStackTrace()
            } catch (throwable: Throwable) {
                throwable.printStackTrace()
            }
        }

        override fun onSurfaceCreated(surfaceHolder: SurfaceHolder) {
            data
            super.onSurfaceCreated(surfaceHolder)
        }

        override fun onSurfaceDestroyed(surfaceHolder: SurfaceHolder) {
            super.onSurfaceDestroyed(surfaceHolder)
            isVisibilityChanged = false
            handler.removeCallbacks(runnable)
        }

        override fun onVisibilityChanged(isChanged: Boolean) {
            isVisibilityChanged = isChanged
            if (isChanged) {
                data
                try {
                    WallpaperEng()
                } catch (throwable: Throwable) {
                    throwable.printStackTrace()
                }
                return
            }
            handler.removeCallbacks(runnable)
        }
    }

    override fun onCreate() {
        super.onCreate()
        timeInterval = 8
        mBitmap = Constants.mWallpaperBitmap
    }

    override fun onCreateEngine(): Engine {
        return WallpaperEngine()
    }

    override fun onDestroy() {
        super.onDestroy()
    }
}