package com.solid.color.wallpaper.hd.image.background.activity

//import com.solid.color.wallpaper.hd.image.background.newModel.DataItem
import android.content.Intent
import android.content.res.Resources
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.NetworkHelper
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.wifi_network.exceptions.ApiNotSupportedException
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.wifi_network.exceptions.NullWifiConfigurationException
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.wifi_network.wifi_proxy_changing_realisations.api_from_21_to_22.WifiConfiguration
import com.facebook.ads.*
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.OnUserEarnedRewardListener
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.material.snackbar.Snackbar
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.appid.AppIDs
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.SolidWallpaperApplication
import com.solid.color.wallpaper.hd.image.background.activity.GifLiveWallPaper.Companion.TAG
import com.solid.color.wallpaper.hd.image.background.adapter.CategaryHDAdepter
import com.solid.color.wallpaper.hd.image.background.adapter.WallpaperOfWeekAdapter
import com.solid.color.wallpaper.hd.image.background.adapter.WallpaperOfWeekAdapter.OnClickItem
import com.solid.color.wallpaper.hd.image.background.adapter.WallpaperOfWeekNewAdapter
import com.solid.color.wallpaper.hd.image.background.constants.Constants
import com.solid.color.wallpaper.hd.image.background.constants.Constants.catPosition
import com.solid.color.wallpaper.hd.image.background.custom.BottomSheetFragment
import com.solid.color.wallpaper.hd.image.background.custom.GridSpacingItemDecoration
import com.solid.color.wallpaper.hd.image.background.model.WallpaperWeekNewModel
import com.solid.color.wallpaper.hd.image.background.model.api.ImageItem
import com.solid.color.wallpaper.hd.image.background.model.api.Response
import com.solid.color.wallpaper.hd.image.background.newModel.DataItem
import com.solid.color.wallpaper.hd.image.background.newModel.ImagesItem
import com.solid.color.wallpaper.hd.image.background.newModel.WallpaperWeekNewModelClass
import com.solid.color.wallpaper.hd.image.background.retrofit.APIClient.client
import com.solid.color.wallpaper.hd.image.background.retrofit.APIInterface
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs.getBoolean
import com.solid.color.wallpaper.hd.image.background.shared_pref.MySharedPref
import com.solid.color.wallpaper.hd.image.background.sqlite_database.DBHelper
import com.solid.color.wallpaper.hd.image.background.sqlite_database.DBHelperSuscription
import retrofit2.Call
import retrofit2.Callback
import java.lang.reflect.InvocationTargetException
import java.util.*
import kotlin.collections.ArrayList

class WallpaperOfWeekNewActivity constructor() : AppCompatActivity(), View.OnClickListener {
    private var icBack: ImageView? = null
    private var icSubcription: ImageView? = null
    private var btnShare: ImageView? = null
    private var recyclerWallpaper: RecyclerView? = null
    private var layoutError: View? = null
    private var layoutOffline: View? = null
    private var layoutProgress: ProgressBar? = null
    private var apiInterface: APIInterface? = null
    private var mDataList: ArrayList<com.solid.color.wallpaper.hd.image.background.model.api.DataItem>? = null
    private var mDataNewList: ArrayList<DataItem>? = null
    private var mImageNewList: ArrayList<ImagesItem?>? = null
    private var mImageNewListData: ArrayList<ImagesItem?>? = null
    private var mImageList: ArrayList<ImageItem>? = null
    private var txtRetryOffline: TextView? = null
    private var txtRetryError: TextView? = null
    private var mySharedPref: MySharedPref? = null
    private var dbHelper: DBHelper? = null
    private var dbHelperSuscription: DBHelperSuscription? = null
    private var adapter: WallpaperOfWeekAdapter? = null
    private var adapterNew: WallpaperOfWeekNewAdapter? = null
    private var gameOverRewardedAd: RewardedAd? = null
    private var gameOverRewardedAd2: RewardedAd? = null
    private var gameOverRewardedAd3: RewardedAd? = null
    private var adViewa: LinearLayout? = null
    private var nativeBannerAd: NativeBannerAd? = null
    private var nativeAdLayout: NativeAdLayout? = null
    private var interstitialAd: InterstitialAd? = null
    private var mInterstitialAd1: com.facebook.ads.InterstitialAd? = null

    var mCategaryHDAdepter:CategaryHDAdepter? = null
    private var mRecyclerCategery: RecyclerView? = null
    var mNewListImage: ArrayList<String> = ArrayList()
    var mNewListImageNew: ArrayList<String> = ArrayList()

//    var mRewardedAd: RewardedAd? = null

var newList:MutableList<String> = arrayListOf()
     private var mRewardedAd: RewardedAd? = null

    //    private var adView: AdView? = null
    var googleRewardVideo = AppIDs.instnace!!.getGoogleRewardVideo()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_wallpaper_of_week_new)
        System.gc()
        SolidWallpaperApplication.staticLanguage.Factory.create(this)
        initViews()
        initViewAction()
        initListner()
        Constants.HDposition = 0
        if (!getBoolean(this@WallpaperOfWeekNewActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
            nativeBannerAds()
//            showFBInter()
            loadFBInter()
        }
    }

   var mInterstitialAd: InterstitialAd?=null

    private fun loadInterstialAd() {
        var adsId = AppIDs.instnace!!.getGoogleInterstitial()

        val ins_adRequest = AdRequest.Builder().build()
        InterstitialAd.load(this,
            adsId,
            ins_adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(myAd: InterstitialAd) {
//                            Timber.d("Ad Loaded")
                    mInterstitialAd = myAd
                }

                override fun onAdFailedToLoad(adError: LoadAdError) {
//                            Timber.d("Failed to load ad: ${adError.message}")
                        mInterstitialAd = null
                }

            })


        }


//        mInterstitialAd.adUnitId = adsId
//        mInterstitialAd.adListener = object : AdListener() {
//            override fun onAdLoaded() {
//                // Code to be executed when an ad finishes loading.
//            }
//
//            override fun onAdFailedToLoad(adError: LoadAdError) {
//                // Code to be executed when an ad request fails.
//            }
//
//            override fun onAdOpened() {
//                // Code to be executed when the ad is displayed.
//            }
//
//            override fun onAdClicked() {
//                // Code to be executed when the user clicks on an ad.
//            }
//
//            override fun onAdLeftApplication() {
//                // Code to be executed when the user has left the app.
//            }
//
//            override fun onAdClosed() {
//                finish()
//            }
//        }
//        mInterstitialAd.loadAd(AdRequest.Builder().build())
    fun showInter(){
    mInterstitialAd!!.fullScreenContentCallback = object : FullScreenContentCallback() {
        override fun onAdDismissedFullScreenContent() {
//                    Log.d(TAG, 'Ad was dismissed.')
            finish()
        }

        override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
            super.onAdFailedToShowFullScreenContent(p0)
        }

        override fun onAdShowedFullScreenContent() {
//                    Log.d(TAG, 'Ad showed fullscreen content.')
//               mInterstitialAd = null;
        }
    }
    SolidWallpaperApplication.instance!!.mInterstitialAd!!.show(this)
    }

    private fun loadFBInter() {

        /*AdSettings.addTestDevice("4d1f808f-4211-406b-942a-2a99f8af5299")
        var fbRandomInter = AppIDs.instnace!!.getRandomFacebookInterstitial()
//        interstitialAd = InterstitialAd(this, fbRandomInter)
//        interstitialAd!!.buildLoadAdConfig().withAdListener(object : InterstitialAdListener {
//            override fun onInterstitialDisplayed(ad: Ad) {
//            }
//
//            override fun onInterstitialDismissed(ad: Ad) {
//                finish()
//            }
//
//            override fun onError(ad: Ad, adError: AdError) {
//                loadInterstialAd()
//            }
//
//            override fun onAdLoaded(ad: Ad) {
//            }
//
//            override fun onAdClicked(ad: Ad) {
//            }
//
//            override fun onLoggingImpression(ad: Ad) {
//            }
//        })

        InterstitialAd.load(this, fbRandomInter, AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(myAd: InterstitialAd) {
                    Log.d(TAG, "onAdLoaded fb : Ad Loaded")
                    interstitialAd = myAd
                    loadFBInter()
                }

                override fun onAdFailedToLoad(adError: LoadAdError) {
//                            Timber.d("Failed to load ad: ${adError.message}")
//                        mInterstitialAd = null
                    Log.d(TAG, "onAdFailedToLoad fb: Ad Error")
                    loadFBInter()
                }

            })*/
        AdSettings.addTestDevice("68c66509-e5f3-462f-9b3c-734432ab111f")
        var fbRandomInter = AppIDs.instnace!!.getRandomFacebookInterstitial()
        mInterstitialAd1 = InterstitialAd(this, fbRandomInter)
        mInterstitialAd1!!.buildLoadAdConfig().withAdListener(object : InterstitialAdListener {
            override fun onInterstitialDisplayed(ad: Ad) {
            }

            override fun onInterstitialDismissed(ad: Ad) {
                finish()
            }

            override fun onError(ad: Ad, adError: AdError) {
                loadInterstialAd()
            }

            override fun onAdLoaded(ad: Ad) {
            }

            override fun onAdClicked(ad: Ad) {
            }

            override fun onLoggingImpression(ad: Ad) {
            }
        })

        // For auto play video ads, it's recommended to load the ad
        // at least 30 seconds before it is shown

        // For auto play video ads, it's recommended to load the ad
        // at least 30 seconds before it is shown
        mInterstitialAd1!!.loadAd()


    }


    fun showFBInter() {
        if (interstitialAd != null) {

            interstitialAd!!.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
//                    Log.d(TAG, 'Ad was dismissed.')
                    loadFBInter()

                    finish()
                }

                override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
                    super.onAdFailedToShowFullScreenContent(p0)
                    loadInterstialAd()
                    loadFBInter()
                }

                override fun onAdShowedFullScreenContent() {
//                    Log.d(TAG, 'Ad showed fullscreen content.')
                    loadFBInter()
                }
            }
            interstitialAd!!.show(this)
        }

    }


    private fun nativeBannerAds() {
        var nativeBannerId = AppIDs.instnace!!.getFacebookNativeBanner()
//        AdSettings.addTestDevice("68c66509-e5f3-462f-9b3c-734432ab111f")
        Log.e("TAG", "nativeBannerAds: hjdjksfhjkladsn")
        AdSettings.addTestDevice("98a80322-58c3-4f38-9d2a-801cf7549bfd")
        nativeBannerAd = NativeBannerAd(this, nativeBannerId)
        nativeBannerAd!!.buildLoadAdConfig().withAdListener(object : NativeAdListener {
            override fun onMediaDownloaded(ad: Ad?) {
                // Native ad finished downloading all assets
            }

            override fun onError(ad: Ad?, adError: AdError) {
                // Native ad failed to load
            }

            override fun onAdLoaded(ad: Ad?) {
                // Native ad is loaded and ready to be displayed
                if (nativeBannerAd == null || nativeBannerAd != ad) {
                    return;
                }
                // Inflate Native Banner Ad into Container
                inflateAd(nativeBannerAd!!);
            }

            override fun onAdClicked(ad: Ad?) {
                // Native ad clicked
            }

            override fun onLoggingImpression(ad: Ad?) {
                // Native ad impression
            }
        })
        // load the ad
        // load the ad
        nativeBannerAd!!.loadAd()
    }

    private fun inflateAd(nativeBannerAd: NativeBannerAd) {
        // Unregister last ad
        nativeBannerAd.unregisterView()

        // Add the Ad view into the ad container.
        nativeAdLayout = findViewById(R.id.native_ad_container)
        val inflater = LayoutInflater.from(this@WallpaperOfWeekNewActivity)
        // Inflate the Ad view.  The layout referenced is the one you created in the last step.
        adViewa = inflater.inflate(
            R.layout.layout_native_banner_fb,
            nativeAdLayout,
            false
        ) as LinearLayout
        nativeAdLayout!!.addView(adViewa)

        // Add the AdChoices icon
        val adChoicesContainer: LinearLayout = adViewa!!.findViewById(R.id.ad_choices_container)
        val adOptionsView =
            AdOptionsView(this@WallpaperOfWeekNewActivity, nativeBannerAd, nativeAdLayout)
        adChoicesContainer.removeAllViews()
        adChoicesContainer.addView(adOptionsView, 0)

        // Create native UI using the ad metadata.
        val nativeAdTitle = adViewa!!.findViewById<TextView>(R.id.native_ad_title)
        val nativeAdSocialContext = adViewa!!.findViewById<TextView>(R.id.native_ad_social_context)
        val sponsoredLabel = adViewa!!.findViewById<TextView>(R.id.native_ad_sponsored_label)
        val nativeAdIconView: com.facebook.ads.MediaView =
            adViewa!!.findViewById(R.id.native_icon_view)
        val nativeAdCallToAction: Button = adViewa!!.findViewById(R.id.native_ad_call_to_action)

        // Set the Text.
        nativeAdCallToAction.setText(nativeBannerAd.adCallToAction)
        nativeAdCallToAction.setVisibility(
            if (nativeBannerAd.hasCallToAction()) View.VISIBLE else View.INVISIBLE
        )
        nativeAdTitle.text = nativeBannerAd.advertiserName
        nativeAdSocialContext.text = nativeBannerAd.adSocialContext
        sponsoredLabel.text = nativeBannerAd.sponsoredTranslation

        // Register the Title and CTA button to listen for clicks.
        val clickableViews: ArrayList<View> = ArrayList()
        clickableViews.add(nativeAdTitle)
        clickableViews.add(nativeAdIconView)
        clickableViews.add(nativeAdCallToAction)
        nativeBannerAd.registerViewForInteraction(adViewa, nativeAdIconView, clickableViews)
    }

    private fun initListner() {
        icBack!!.setOnClickListener(this)
        icSubcription!!.setOnClickListener(this)
        txtRetryOffline!!.setOnClickListener(this)
        txtRetryError!!.setOnClickListener(this)
        btnShare!!.setOnClickListener(this)
    }

    private fun initViewAction() {
        var facebookBanner = AppIDs.instnace!!.getFacebookBanner()

        mDataList = ArrayList()
        mDataNewList = ArrayList()
        mImageNewList = ArrayList()
        mImageNewListData = ArrayList()
        mImageList = ArrayList()
        dbHelper = DBHelper(this)
        dbHelperSuscription = DBHelperSuscription(this)
        mySharedPref = MySharedPref(this)
        if (!getBoolean(this@WallpaperOfWeekNewActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
            if (mRewardedAd != null) {
                gameOverRewardedAd = createAndLoadRewardedAd(googleRewardVideo)
                gameOverRewardedAd2 = createAndLoadRewardedAd(googleRewardVideo)
                gameOverRewardedAd3 = createAndLoadRewardedAd(googleRewardVideo)
            }

//            gameOverRewardedAd = createAndLoadRewardedAd(googleRewardVideo)
//            gameOverRewardedAd2 = createAndLoadRewardedAd(googleRewardVideo)
//            gameOverRewardedAd3 = createAndLoadRewardedAd(googleRewardVideo)
//            adView = AdView(this, facebookBanner, AdSize.BANNER_HEIGHT_50)
//            val adContainer: LinearLayout = findViewById<View>(R.id.banner_container) as LinearLayout
//            adContainer.removeAllViews()
//            adContainer.addView(adView)
//            adView!!.loadAd()
        }
        if (getBoolean(this@WallpaperOfWeekNewActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
            btnShare!!.visibility = View.VISIBLE
            icSubcription!!.visibility = View.INVISIBLE
        } else {
            btnShare!!.visibility = View.GONE
            icSubcription!!.visibility = View.VISIBLE
        }
        val manager: GridLayoutManager = GridLayoutManager(this, 3)
        recyclerWallpaper!!.layoutManager = manager
        recyclerWallpaper!!.addItemDecoration(GridSpacingItemDecoration(3, dpToPx(14), true))
        recyclerWallpaper!!.itemAnimator = DefaultItemAnimator()
        try {
            checkStatus()
        } catch (e: InvocationTargetException) {
            e.printStackTrace()
        } catch (e: NoSuchMethodException) {
            e.printStackTrace()
        } catch (e: ApiNotSupportedException) {
            e.printStackTrace()
        } catch (e: NoSuchFieldException) {
            e.printStackTrace()
        } catch (e: IllegalAccessException) {
            e.printStackTrace()
        } catch (e: NullWifiConfigurationException) {
//            callApi()
            callNewApi()
            e.printStackTrace()
        }
    }

    private fun initViews() {
        icBack = findViewById(R.id.icBack)
        icSubcription = findViewById(R.id.icSubcription)
        recyclerWallpaper = findViewById(R.id.recyclerWallpaper)
        mRecyclerCategery = findViewById(R.id.recyclerCategery)
        layoutOffline = findViewById(R.id.layoutOffline)
        layoutError = findViewById(R.id.layoutError)
        layoutProgress = findViewById(R.id.layoutProgress)
        txtRetryOffline = findViewById(R.id.txtRetry)
        txtRetryError = findViewById(R.id.txtRetryError)
        btnShare = findViewById(R.id.btnShare)
    }

    fun createAndLoadRewardedAd(adUnitId: String?): RewardedAd? {


        var adRequest = AdRequest.Builder().build()

        RewardedAd.load(this, adUnitId, adRequest, object : RewardedAdLoadCallback() {
            override fun onAdFailedToLoad(adError: LoadAdError) {
                Log.d(TAG, adError?.message)
                mRewardedAd = null
            }

            override fun onAdLoaded(rewardedAd: RewardedAd) {
                Log.d(TAG, "Ad was loaded.")
                mRewardedAd = rewardedAd
            }
        })


//        val adLoadCallback: RewardedAdLoadCallback = object : RewardedAdLoadCallback() {
//            public override fun onRewardedAdLoaded() {
//                // Ad successfully loaded.
//            }
//
//            public override fun onRewardedAdFailedToLoad(errorCode: Int) {
//                // Ad failed to load.
//            }
//        }
//        rewardedAd.loadAd(AdRequest.Builder().build(), adLoadCallback)
        return mRewardedAd!!

    }

    public override fun onClick(v: View) {
        when (v.getId()) {
            R.id.icBack -> onBackPressed()
            R.id.icSubcription ->                 /*if (!AdsPrefs.getBoolean(WallpaperOfWeekNewActivity.this, AdsPrefs.IS_SUBSCRIBED, false)) {
                    startActivity(new Intent(WallpaperOfWeekNewActivity.this, PremiumAccessActivity.class));
                } else {
                    showSnackBar();
                }*/onclickGames()
            R.id.txtRetry -> retry()
            R.id.btnShare -> onclickShare()
            R.id.txtRetryError -> retry()
        }
    }

    private fun onclickGames() {
        if (!NetworkHelper.isOnline(this)) {
            Toast.makeText(
                this,
                getResources().getString(R.string.check_internet_connection),
                Toast.LENGTH_SHORT
            ).show()
            return
        }
        startActivity(Intent(this, GamezopActivity::class.java))

        /*  String url = "https://www.gamezop.com/?id=Y2_mvlugT";

        try {
            CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
            CustomTabsIntent customTabsIntent = builder.build();

            customTabsIntent.intent.setPackage("com.android.chrome");
            builder.setToolbarColor(ContextCompat.getColor(this, R.color.colorPrimary));
            builder.setShowTitle(true);
            builder.addDefaultShareMenuItem();

            builder.build().launchUrl(this, Uri.parse(url));
        } catch (Exception e) {
            CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();

            builder.setToolbarColor(getResources().getColor(R.color.colorPrimary));
            CustomTabsIntent customTabsIntent = builder.build();
            customTabsIntent.launchUrl(this, Uri.parse(url));
        }*/
    }

    private fun onclickShare() {
        val shareIntent: Intent = Intent(Intent.ACTION_SEND)
        shareIntent.type = "text/plain"
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Solid Color Wallpaper")
        var shareMessage: String = ""
        shareMessage += "https://play.google.com/store/apps/details?id=com.solid.color.wallpaper.hd.image.background"
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
        startActivity(
            Intent.createChooser(
                shareIntent,
                getResources().getString(R.string.choose_one)
            )
        )
    }

    private fun showSnackBar() {
        val snackbar: Snackbar =
            Snackbar.make(findViewById(R.id.mainLayout), "", Snackbar.LENGTH_LONG)
        val layout: Snackbar.SnackbarLayout = snackbar.view as Snackbar.SnackbarLayout
        val textView: TextView = layout.findViewById(com.google.android.material.R.id.snackbar_text)
        textView.visibility = View.INVISIBLE
        val snackView: View = LayoutInflater.from(this).inflate(R.layout.my_snackbar, null)
        layout.setPadding(0, 0, 0, 0)
        layout.addView(snackView, 0)
        snackbar.show()
    }

    private fun retry() {
        layoutProgress!!.visibility = View.VISIBLE
        layoutError!!.visibility = View.GONE
        recyclerWallpaper!!.visibility = View.VISIBLE
        layoutOffline!!.visibility = View.GONE
        try {
            checkStatus()
        } catch (e: InvocationTargetException) {
            e.printStackTrace()
        } catch (e: NoSuchMethodException) {
            e.printStackTrace()
        } catch (e: ApiNotSupportedException) {
            e.printStackTrace()
        } catch (e: NoSuchFieldException) {
            e.printStackTrace()
        } catch (e: IllegalAccessException) {
            e.printStackTrace()
        } catch (e: NullWifiConfigurationException) {
//            callApi()
            callNewApi()
            e.printStackTrace()
        }

        Toast.makeText(this, resources.getString(R.string.please_turn_on_internet), Toast.LENGTH_SHORT).show()
    }

    @Throws(
        InvocationTargetException::class,
        NoSuchMethodException::class,
        ApiNotSupportedException::class,
        NoSuchFieldException::class,
        IllegalAccessException::class,
        NullWifiConfigurationException::class
    )
    private fun checkStatus() {
        if (!NetworkHelper.isOnline(this)) {
            layoutError!!.visibility = View.GONE
            recyclerWallpaper!!.visibility = View.GONE
            layoutOffline!!.visibility = View.VISIBLE
            layoutProgress!!.visibility = View.GONE
        } else {
            if (NetworkHelper.isWifiConnected(this)) {
                val proxy: WifiConfiguration = WifiConfiguration(this)
                if (proxy.isProxySetted) {
                    layoutError!!.visibility = View.GONE
                    recyclerWallpaper!!.visibility = View.GONE
                    layoutOffline!!.visibility = View.VISIBLE
                    layoutProgress!!.visibility = View.GONE
                    return
                }
            }
            if (NetworkHelper.isVpnRunning()) {
                layoutError!!.visibility = View.GONE
                recyclerWallpaper!!.visibility = View.GONE
                layoutOffline!!.visibility = View.VISIBLE
                layoutProgress!!.visibility = View.GONE
                return
            }
//            callApi()
            callNewApi()
        }
        
    }

    fun callApi() {
        apiInterface = client!!.create(APIInterface::class.java)
        val call: Call<Response?>? = apiInterface!!.doGetListResources()
        call!!.enqueue(object : Callback<Response?> {
            override fun onResponse(call: Call<Response?>, response: retrofit2.Response<Response?>)
            {
                layoutProgress!!.visibility = View.GONE
                val model: Response? = response.body()
                mDataList!!.clear()
                mImageList!!.clear()
                if (model?.data != null)
                {
                    mDataList!!.addAll(model.data)
                    updateUI()
                }
                else {
                    runOnUiThread {
                        layoutError!!.visibility = View.VISIBLE
                        recyclerWallpaper!!.visibility = View.GONE
                        layoutOffline!!.visibility = View.GONE
                        layoutProgress!!.visibility = View.GONE
                    }
                }
            }

            override fun onFailure(call: Call<Response?>, t: Throwable) {
                runOnUiThread {
                    layoutError!!.visibility = View.VISIBLE
                    recyclerWallpaper!!.visibility = View.GONE
                    layoutOffline!!.visibility = View.GONE
                    layoutProgress!!.visibility = View.GONE
                }
            }
        })
    }


    fun callNewApi() {
        apiInterface = client!!.create(APIInterface::class.java)
        val call: Call<com.solid.color.wallpaper.hd.image.background.newModel.Response?>? =
            apiInterface!!.doGetNewListResources()
        call!!.enqueue(object :
            Callback<com.solid.color.wallpaper.hd.image.background.newModel.Response?> {

            @RequiresApi(Build.VERSION_CODES.N)
            override fun onResponse(call: Call<com.solid.color.wallpaper.hd.image.background.newModel.Response?>,
                response: retrofit2.Response<com.solid.color.wallpaper.hd.image.background.newModel.Response?>)
            {
                layoutProgress!!.visibility = View.GONE
                val model: com.solid.color.wallpaper.hd.image.background.newModel.Response? =
                    response.body()
                mDataNewList!!.clear()
                mImageNewList!!.clear()
                if (model?.data != null) {
                    mDataNewList!!.addAll(model.data)

                    updateNewUI()
                } else {
                    runOnUiThread {
                        layoutError!!.visibility = View.VISIBLE
                        recyclerWallpaper!!.visibility = View.GONE
                        layoutOffline!!.visibility = View.GONE
                        layoutProgress!!.visibility = View.GONE
                    }
                }
            }

            override fun onFailure(
                call: Call<com.solid.color.wallpaper.hd.image.background.newModel.Response?>,
                t: Throwable
            ) {
                runOnUiThread {
                    layoutError!!.visibility = View.VISIBLE
                    recyclerWallpaper!!.visibility = View.GONE
                    layoutOffline!!.visibility = View.GONE
                    layoutProgress!!.visibility = View.GONE
                }
            }
        })
    }


    private fun dpToPx(dp: Int): Int {
        val r: Resources = resources
        return Math.round(
            TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dp.toFloat(),
                r.displayMetrics
            )
        )
    }


//    private fun setRecyclerData(newList: MutableList<String>) {
//        mRecyclerCategery!!.layoutManager = LinearLayoutManager(this,RecyclerView.HORIZONTAL,false)
//        mRecyclerCategery!!.adapter = CategaryHDAdepter(this,newList,object : CategaryHDAdepter.OnClickHdListener{
//            override fun onClickHD(position: Int, nCatName: String) {
//                Log.d(TAG, "onClickHD: $nCatName")
//                mNewListImageNew.clear()
//                for (i in mImageNewList!!.indices){
//                    if(mImageNewList!![i]!!.name == nCatName){
//                        mNewListImageNew.add(mImageNewList!![i]!!.image!!)
//                        mImageNewListData!!.addAll(mDataNewList!![i].images!!)
//                    }
//                }
//                Log.d(TAG, "onClickHD: $mNewListImageNew")
//                Log.d(TAG, "onClickHD: $mImageNewListData")
//            }
//        })
//    }



    private fun updateUI() {
        for (i in mDataList!!.indices) {
            if (mDataList!![i].id == 3) {
                mImageList!!.addAll((mDataList!![i].image)!!)
                break
            }
        }
        val mWallpaperList: ArrayList<WallpaperWeekNewModel?> = ArrayList()
        for (i in mImageList!!.indices) {
            Log.d("TAG=====>>>>", "updateUI: " + mImageList!![i].coins)
            mWallpaperList.add(
                WallpaperWeekNewModel(
                    mImageList!![i],
                    mImageList!![i].isPremium != 0,
                    mImageList!![i].image,
                    mImageList!![i].coins
                )
            )
        }
        val mTempList: ArrayList<WallpaperWeekNewModel?> = ArrayList()
        if (getBoolean(this@WallpaperOfWeekNewActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
            for (image: ImageItem in mImageList!!) {
                dbHelperSuscription!!.insertPath((image.image)!!)
                Log.d("EWWWWWW", "updateUI: " + image.image)

            }
            for (i in mWallpaperList.indices) {
                mWallpaperList[i]!!.isLocked = false
            }
            mTempList.addAll(mWallpaperList)
        } else {
            dbHelperSuscription!!.deleteAllData()

            /* if (mySharedPref.getAdsRemoved()) {
                Log.d("456as", "updateUI: pur");

                if (mWallpaperList.size() >= 6) {
                    for (int i = 0; i < 6; i++) {
                        mTempList.add(mWallpaperList.get(i));
                    }
                   */
            /* for (int i = 0; i < 6; i++) {
                        mWallpaperList.remove(i);
                    }*/
            /*
                } else {
                    mTempList.addAll(mWallpaperList);
                    mWallpaperList.clear();
                }

                boolean flag = true;
                int conter = 0;
                int counterPrem = 0;
                for (int i = 6; i < mWallpaperList.size(); i++) {
                    WallpaperWeekNewModel model = mWallpaperList.get(i);

                    if (flag) {
                        model.setLocked(false);
                        model.setFree(true);
                        mTempList.add(model);
                        conter++;
                        if (conter > 5) {
                            flag = false;
                            conter = 0;
                        }
                    } else {
                        model.setPremium(true);
                        model.setFree(false);
                        mTempList.add(model);
                        counterPrem++;
                        if (counterPrem > 2) {
                            flag = true;
                            counterPrem = 0;
                        }
                    }
                }

            } else {*/
            /*  if (mWallpaperList.size() >= 6) {
                for (int i = 0; i < 6; i++) {
                    mTempList.add(mWallpaperList.get(i));
                }

                    */
            /*for (int i = 0; i < 6; i++) {
                        mWallpaperList.remove(i);
                    }*/
            /*
            } else {
                mTempList.addAll(mWallpaperList);
                mWallpaperList.clear();
            }

            boolean flag = true;
            int conter = 0;
            int counterPrem = 0;*/
            for (i in mWallpaperList.indices) {
                val model: WallpaperWeekNewModel? = mWallpaperList[i]
                if (dbHelper!!.checkPathExist((model!!.imageItem!!.image)!!)) {
                    model.isLocked = false
                }
                mTempList.add(model)

                //   }
            }
            mTempList.shuffle()
        }
        if (mImageList != null && mImageList!!.size > 0) {
            val onClickItem: OnClickItem = object : OnClickItem {
                 override fun onClickWallpaper(
                    wallpaperWeekNewModel: WallpaperWeekNewModel?,
                    position: Int
                ) {

                    /*  if (WallpaperWeekNewModel.isPremium()) {
                        startActivity(new Intent(WallpaperOfWeekNewActivity.this, PremiumAccessActivity.class));
                    } else if (WallpaperWeekNewModel.isFree()) {
                        Intent i = new Intent(WallpaperOfWeekNewActivity.this, WallpaperWeekViewActivity.class);
                        i.putExtra("imagepath", WallpaperWeekNewModel.getImageItem().getImage());
                        startActivity(i);
                    } else {
                        if (!NetworkHelper.isOnline(WallpaperOfWeekNewActivity.this)) {
                            Toast.makeText(WallpaperOfWeekNewActivity.this, getResources().getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show();
                            return;
                        }
                        showAdDialog(WallpaperWeekNewModel, position);
                    }*/
                    if (!NetworkHelper.isOnline(this@WallpaperOfWeekNewActivity)) {
                        Toast.makeText(
                            this@WallpaperOfWeekNewActivity,
                            getResources().getString(R.string.check_internet_connection),
                            Toast.LENGTH_SHORT
                        ).show()
                        return
                    }
                    val intent: Intent = Intent(
                        this@WallpaperOfWeekNewActivity,
                        WallpaperOfWeekPagerViewActivity::class.java
                    )
                    intent.putParcelableArrayListExtra("ARRAYLIST", mTempList)
                    intent.putExtra("position", position)
                    startActivity(intent)
                }

                public override fun startAnimation() {}
            }
            adapter =
                WallpaperOfWeekAdapter(mTempList, this@WallpaperOfWeekNewActivity, onClickItem)
            recyclerWallpaper!!.adapter = adapter
        }
        layoutError!!.visibility = View.GONE
        recyclerWallpaper!!.visibility = View.VISIBLE
        layoutOffline!!.visibility = View.GONE
        layoutProgress!!.visibility = View.GONE
    }

    @RequiresApi(Build.VERSION_CODES.N)
    private fun updateNewUI() {
        for (i in mDataNewList!!.indices) {
            if (mDataNewList!![i].id == 3) {
                mImageNewList!!.addAll(mDataNewList!![i].images!!)
                Log.e("TAG", "updateNewUI1111: ${mImageNewList!!.size}")
                Log.e("TAG", "updateNewUI1112: ${mDataNewList!![i].images!!.size}")
                break
            }
        }
        for( j in mImageNewList!!.indices){
//            if(mImageNewList!![j]!!.name!!.contains("")){
//
//            }else{
            mNewListImage.add(mImageNewList!![j]!!.name!!)
//            }
        }

        val hs = HashSet<String>()

        hs.addAll(mNewListImage) // demoArrayList= name of arrayList from which u want to remove duplicates
        mNewListImage.clear()
        mNewListImage.addAll(hs)

//        var newList = mNewListImage.stream().distinct().collect(Collectors.toList())
         newList = mNewListImage

        Log.d(TAG, "updateNewUIqqqq: ${newList.size}")
        Log.d(TAG, "updateNewUIqqqq: $newList")



//        try {
//            newList.remove("")
//        } catch (e: Exception) {
//        }
        val mWallpaperList: ArrayList<WallpaperWeekNewModelClass?> = ArrayList()
        mRecyclerCategery!!.layoutManager = LinearLayoutManager(this,RecyclerView.HORIZONTAL,false)

        mCategaryHDAdepter = CategaryHDAdepter(this,newList,object : CategaryHDAdepter.OnClickHdListener{
            override fun onClickHD(position: Int, nCatName: String) {
                mWallpaperList.clear()
                catPosition = position
                Log.e("TAG", "onClickHD: $nCatName")
                for (i in mImageNewList!!.indices){
                    if(mImageNewList!![i]!!.name == nCatName){
                        mWallpaperList.add(
                            WallpaperWeekNewModelClass(
                                mImageNewList!![i],
                                mImageNewList!![i]!!.isPremium != 0,
                                mImageNewList!![i]!!.image,
                                mImageNewList!![i]!!.coins!!
                            )
                        )
                    }
                }
                Log.e("TAG", "updateNewUI1113: ${mWallpaperList.size}")

                Log.d("TAGS", "onClickHD: $mNewListImageNew")
                Log.d("TAGS", "onClickHD11: ${mImageNewListData!!.size}")


                val mTempList: ArrayList<WallpaperWeekNewModelClass?> = ArrayList()
                if (getBoolean(this@WallpaperOfWeekNewActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                    for (image: ImagesItem? in mImageNewList!!) {
                        dbHelperSuscription!!.insertPath((image!!.image)!!)
                        Log.d("EWWWWWW", "updateUI: " + image.image)

                    }
                    for (i in mWallpaperList.indices) {
                        mWallpaperList[i]!!.isLocked = false
                    }
                    mTempList.addAll(mWallpaperList)

                }
                else {
                    dbHelperSuscription!!.deleteAllData()
                    for (i in mWallpaperList.indices) {
                        val model: WallpaperWeekNewModelClass? = mWallpaperList[i]
                        if (dbHelper!!.checkPathExist((model!!.imageItem!!.image)!!)) {
                            model.isLocked = false
                        }
                        mTempList.add(model)

                        //   }
                    }
                    mTempList.shuffle()

                }
                if (mImageNewList != null && mImageNewList!!.size > 0) {
                    val onClickItem: WallpaperOfWeekNewAdapter.OnClickItem =
                        object : WallpaperOfWeekNewAdapter.OnClickItem {

                            override fun onClickWallpaper(wallpaperWeekModel: WallpaperWeekNewModelClass?, pos: Int)
                            {
                                if (!NetworkHelper.isOnline(this@WallpaperOfWeekNewActivity)) {
                                    Toast.makeText(this@WallpaperOfWeekNewActivity, resources.getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show()
                                    return
                                }

                                val intent = Intent(this@WallpaperOfWeekNewActivity, WallpaperOfWeekPagerViewActivity::class.java)
                                intent.putParcelableArrayListExtra("ARRAYLIST", mTempList)
                                intent.putExtra("position", pos)
                                startActivity(intent)
                            }

                            override fun startAnimation() {}
                        }
                    adapterNew =
                        WallpaperOfWeekNewAdapter(mTempList, this@WallpaperOfWeekNewActivity, onClickItem)
                    recyclerWallpaper!!.adapter = adapterNew
                }
                layoutError!!.visibility = View.GONE
                recyclerWallpaper!!.visibility = View.VISIBLE
                layoutOffline!!.visibility = View.GONE
                layoutProgress!!.visibility = View.GONE

            }
        })

        mRecyclerCategery!!.adapter = mCategaryHDAdepter
        /*for (i in mImageNewList!!.indices) {
            Log.d("TAG=====>>>>", "updateUI: " + mImageNewList!![i]!!.coins)
            mWallpaperList.add(
                WallpaperWeekNewModelClass(
                    mImageNewList!![i],
                    mImageNewList!![i]!!.isPremium != 0,
                    mImageNewList!![i]!!.image,
                    mImageNewList!![i]!!.coins!!
                )
            )
            Log.e(TAG, "updateNewUI111: ${mWallpaperList.size}")
        }
        val mTempList: ArrayList<WallpaperWeekNewModelClass?> = ArrayList()
        if (getBoolean(this@WallpaperOfWeekNewActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
            for (image: ImagesItem? in mImageNewList!!) {
                dbHelperSuscription!!.insertPath((image!!.image)!!)
                Log.d("EWWWWWW", "updateUI: " + image.image)

            }
            for (i in mWallpaperList.indices) {
                mWallpaperList[i]!!.isLocked = false
            }
            mTempList.addAll(mWallpaperList)
        } else {
            dbHelperSuscription!!.deleteAllData()
            for (i in mWallpaperList.indices) {
                val model: WallpaperWeekNewModelClass? = mWallpaperList[i]
                if (dbHelper!!.checkPathExist((model!!.imageItem!!.image)!!)) {
                    model.isLocked = false
                }
                mTempList.add(model)

                //   }
            }
            mTempList.shuffle()

        }
        if (mImageNewList != null && mImageNewList!!.size > 0) {
            val onClickItem: WallpaperOfWeekNewAdapter.OnClickItem =
                object : WallpaperOfWeekNewAdapter.OnClickItem {

                    override fun onClickWallpaper(
                        wallpaperWeekModel: WallpaperWeekNewModelClass?,
                        pos: Int
                    ) {
                        if (!NetworkHelper.isOnline(this@WallpaperOfWeekNewActivity)) {
                            Toast.makeText(
                                this@WallpaperOfWeekNewActivity,
                                getResources().getString(R.string.check_internet_connection),
                                Toast.LENGTH_SHORT
                            ).show()
                            return
                        }
                        val intent: Intent = Intent(
                            this@WallpaperOfWeekNewActivity,
                            WallpaperOfWeekPagerViewActivity::class.java
                        )
                        intent.putParcelableArrayListExtra("ARRAYLIST", mTempList)
                        intent.putExtra("position", pos)
                        startActivity(intent)
                    }

                    public override fun startAnimation() {}
                }
            adapterNew =
                WallpaperOfWeekNewAdapter(mTempList, this@WallpaperOfWeekNewActivity, onClickItem)
            recyclerWallpaper!!.adapter = adapterNew
        }
        layoutError!!.visibility = View.GONE
        recyclerWallpaper!!.visibility = View.VISIBLE
        layoutOffline!!.visibility = View.GONE
        layoutProgress!!.visibility = View.GONE*/
    }

    private fun showAdDialog(model: WallpaperWeekNewModel, position: Int) {
        val bottomSheetFragment: BottomSheetFragment = BottomSheetFragment(
            getResources().getString(R.string.watch_video),
            getResources().getString(R.string.do_you_want_watch_video),
            getResources().getString(R.string.watch),
            getResources().getString(R.string.cancel),
            R.drawable.ic_video,
            object : BottomSheetFragment.OnButtonClickListener {
                public override fun onPositive(bottomSheetDialo: BottomSheetFragment?) {
                    bottomSheetDialo!!.dismiss()
                    if (gameOverRewardedAd != null) {
                        showAd(position, model, gameOverRewardedAd)
                    } else if (gameOverRewardedAd2 != null) {
                        showAd(position, model, gameOverRewardedAd2)
                    } else if (gameOverRewardedAd3 != null) {
                        showAd(position, model, gameOverRewardedAd3)
                    } else {
                        Toast.makeText(
                            this@WallpaperOfWeekNewActivity,
                            getResources().getString(R.string.try_again_later),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                public override fun onNegative(bottomSheetDialog: BottomSheetFragment?) {
                    bottomSheetDialog!!.dismiss()
                }
            })
        bottomSheetFragment.show(supportFragmentManager, "dialog")
    }

    fun showAd(position: Int, model: WallpaperWeekNewModel, rewardedAd: RewardedAd?) {
        val flag: BooleanArray = booleanArrayOf(false)
        if (rewardedAd != null) {

            rewardedAd.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    if (mRewardedAd != null) {

                        gameOverRewardedAd = createAndLoadRewardedAd(googleRewardVideo)
                        gameOverRewardedAd2 = createAndLoadRewardedAd(googleRewardVideo)
                        gameOverRewardedAd3 = createAndLoadRewardedAd(googleRewardVideo)
                    }

                    if (flag[0]) {
                        val i: Intent = Intent(
                            this@WallpaperOfWeekNewActivity,
                            WallpaperWeekViewActivity::class.java
                        )
                        i.putExtra("imagepath", model.imageItem!!.image)
                        startActivity(i)
                    }
                }

                override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
                    super.onAdFailedToShowFullScreenContent(p0)


                }

                override fun onAdShowedFullScreenContent() {
                    if (mRewardedAd != null) {

                        gameOverRewardedAd = createAndLoadRewardedAd(googleRewardVideo)
                        gameOverRewardedAd2 = createAndLoadRewardedAd(googleRewardVideo)
                        gameOverRewardedAd3 = createAndLoadRewardedAd(googleRewardVideo)
                    }
                    Log.d("11111111", "not loadeqwqwqwqes.")

                    Toast.makeText(
                        this@WallpaperOfWeekNewActivity,
                        getResources().getString(R.string.something_went_wrong),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

//            val adCallback: RewardedAdCallback = object : RewardedAdCallback() {
//                public override fun onRewardedAdOpened() {
//                    // Ad opened.
//                }
//
//                public override fun onRewardedAdClosed() {
//
//                    // Ad closed.
//                    gameOverRewardedAd = createAndLoadRewardedAd(googleRewardVideo)
//                    gameOverRewardedAd2 = createAndLoadRewardedAd(googleRewardVideo)
//                    gameOverRewardedAd3 = createAndLoadRewardedAd(googleRewardVideo)
//                    if (flag[0]) {
//                        val i: Intent = Intent(this@WallpaperOfWeekNewActivity, WallpaperWeekViewActivity::class.java)
//                        i.putExtra("imagepath", model.imageItem!!.image)
//                        startActivity(i)
//                    }
//                }
//
//                public override fun onUserEarnedReward(reward: RewardItem) {
//                    // User earned reward.
//                    dbHelper!!.insertPath((model.imageItem!!.image)!!)
//                    model.isLocked = false
//                    flag[0] = true
//                    if (adapter != null) {
//                        adapter!!.notifyItemChanged(position)
//                    }
//                    gameOverRewardedAd = createAndLoadRewardedAd(googleRewardVideo)
//                    gameOverRewardedAd2 = createAndLoadRewardedAd(googleRewardVideo)
//                    gameOverRewardedAd3 = createAndLoadRewardedAd(googleRewardVideo)
//                }
//
//                public override fun onRewardedAdFailedToShow(errorCode: Int) {
//                    // Ad failed to display.
//                    gameOverRewardedAd = createAndLoadRewardedAd(googleRewardVideo)
//                    gameOverRewardedAd2 = createAndLoadRewardedAd(googleRewardVideo)
//                    gameOverRewardedAd3 = createAndLoadRewardedAd(googleRewardVideo)
//                    Toast.makeText(this@WallpaperOfWeekNewActivity, getResources().getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
//                }
//            }

            rewardedAd.show(this, OnUserEarnedRewardListener() {
//                 User earned reward.
                dbHelper!!.insertPath((model.imageItem!!.image)!!)
                model.isLocked = false
                flag[0] = true
                if (adapterNew != null) {
                    adapterNew!!.notifyItemChanged(position)
                }
                if (mRewardedAd != null) {

                    gameOverRewardedAd = createAndLoadRewardedAd(googleRewardVideo)
                    gameOverRewardedAd2 = createAndLoadRewardedAd(googleRewardVideo)
                    gameOverRewardedAd3 = createAndLoadRewardedAd(googleRewardVideo)
                }

                Log.d(GifLiveWallPaper.TAG, "User earned the reward.")
            })

//            rewardedAd.show(this@WallpaperOfWeekNewActivity, adCallback)
        } else {
            Log.d("11111111", "not loades.")

            Toast.makeText(
                this@WallpaperOfWeekNewActivity,
                getResources().getString(R.string.something_went_wrong),
                Toast.LENGTH_SHORT
            ).show()
            gameOverRewardedAd = createAndLoadRewardedAd(googleRewardVideo)
            gameOverRewardedAd2 = createAndLoadRewardedAd(googleRewardVideo)
            gameOverRewardedAd3 = createAndLoadRewardedAd(googleRewardVideo)
        }
    }

    @RequiresApi(Build.VERSION_CODES.N)
    override fun onResume() {
        super.onResume()

        Log.d(TAG, "onResume: position ${Constants.catPosition}")
        
//        try {
//            if (mCategaryHDAdepter!=null && mRecyclerCategery!=null){
//                finish()
//                overridePendingTransition(0,0)
//                startActivity(intent)
//                overridePendingTransition(0,0)
//
//                mRecyclerCategery!!.postDelayed(
//                    Runnable { mRecyclerCategery!!.smoothScrollToPosition(catPosition) },
//                    300
//                )
//
//                mRecyclerCategery!!.postDelayed(Runnable {
//                    mRecyclerCategery!!.findViewHolderForAdapterPosition(
//                        catPosition
//                    )!!.itemView.performClick()
//                }, 400)
////                mRecyclerCategery!!.findViewHolderForAdapterPosition(catPosition)!!.itemView.performClick()
////                mRecyclerCategery!!.adapter!!.notifyItemChanged(catPosition)
//            }
//        } catch (e: Exception) {
////            mRecyclerCategery!!.findViewHolderForLayoutPosition()
//        }

        if (Constants.isSubscribedW) {
            recreate()
            Constants.isSubscribedW = false
        }
        if (Constants.isDataChaged) {
            Constants.isDataChaged = false
            if (mImageList != null) {
                mImageList!!.clear()
                mImageNewList!!.clear()
            }



//            updateUI()

            updateNewUI()
//            recreate()
            Log.d("14-10-2021", "onResume: ")
        }
    }

    override fun onDestroy() {
        if (interstitialAd != null) {
//            interstitialAd!!.destroy()
        }
        super.onDestroy()
    }


   override fun onBackPressed() {
       Log.d(TAG, "onBackPressed: clickckckc")
//       if (!getBoolean(this@WallpaperOfWeekNewActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
           if (mInterstitialAd1 != null && mInterstitialAd1!!.isAdLoaded) {
               Log.d(TAG, "onBackPressed: ads1")
               mInterstitialAd1!!.show();
           } else if (mInterstitialAd!= null) {
               Log.d(TAG, "onBackPressed: ads2")
               showInterstitial()
           } else {
               Log.d(TAG, "onBackPressed: ads3")
               finish()
           }
//       } else {
//           finish()
//       }
   }
    fun showInterstitial(){
        if (mInterstitialAd != null) {

            mInterstitialAd!!.fullScreenContentCallback = object: FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    loadInterstialAd()
//                    Log.d(TAG, 'Ad was dismissed.')
                    mInterstitialAd = null
                    finish()

                }

                override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
                    super.onAdFailedToShowFullScreenContent(p0)
//                loadInterstialAdFb()
                    loadInterstialAd()
                }

                override fun onAdShowedFullScreenContent() {
//                    Log.d(TAG, 'Ad showed fullscreen content.')
//                    finish()
                    mInterstitialAd = null
                }
            }
            mInterstitialAd!!.show(this)
        }else{
//            startActivity(Intent(this@MainStartActivity, MyCreationActivity::class.java))
        }
    }

}