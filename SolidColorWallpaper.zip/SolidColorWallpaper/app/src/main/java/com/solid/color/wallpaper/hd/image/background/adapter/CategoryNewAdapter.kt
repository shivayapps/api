package com.solid.color.wallpaper.hd.image.background.adapter

import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.model.CategoryNameIconModel
import kotlinx.android.synthetic.main.rv_screen_category_new.view.*

class CategoryNewAdapter(var context: Context, var mCategoryList: ArrayList<CategoryNameIconModel>, var onCLickCategory: OnCLickCategory) : RecyclerView.Adapter<CategoryNewAdapter.MyViewHolder>() {


    interface OnCLickCategory {
        fun onClickCategory(i: Int)
    }

    class MyViewHolder(view: View) : RecyclerView.ViewHolder(view)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(LayoutInflater.from(context).inflate(R.layout.rv_screen_category_new, parent, false))
    }

    override fun getItemCount(): Int {
        return mCategoryList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.itemView.txt_cat_name.text = mCategoryList[position].categoryName
        holder.itemView.ppBar.visibility=View.VISIBLE
        holder.itemView.img_category.visibility=View.GONE

        Glide.with(context).load(mCategoryList[position].categoryIcon).into(object : CustomTarget<Drawable?>() {
            override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                holder.itemView.img_category.setImageDrawable(resource)
                holder.itemView.img_category.visibility=View.VISIBLE
                holder.itemView.ppBar.visibility=View.GONE
            }

            override fun onLoadCleared(placeholder: Drawable?) {

            }
        })



        Glide.with(context).load(mCategoryList[position].categoryIcon).into(holder.itemView.img_category)
        holder.itemView.setOnClickListener {
            onCLickCategory.onClickCategory(position)
        }
    }
}