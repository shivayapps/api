package com.solid.color.wallpaper.hd.image.background.adapter

import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.widget.ContentLoadingProgressBar
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.model.WallpaperWeekNewModel
import com.solid.color.wallpaper.hd.image.background.newModel.WallpaperWeekNewModelClass
import java.util.*

class WeekPagerAdapter(private val context: Context, private val al_my_photos: ArrayList<WallpaperWeekNewModelClass?>, private val onClicklock: OnClicklock) : PagerAdapter() {
    override fun getCount(): Int {
        return al_my_photos.size
    }

    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return view === `object`
    }

    override fun getItemPosition(`object`: Any): Int {
        return POSITION_NONE
    }

    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        val inflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val view = inflater.inflate(R.layout.rv_week_pager, null)
        val iv = view.findViewById<ImageView>(R.id.adapterImage)
        val lockImage = view.findViewById<LinearLayout>(R.id.imageLock)
        val txtCoin = view.findViewById<TextView>(R.id.txtCoin)
        val imageVideoAd = view.findViewById<ImageView>(R.id.imageVideoAd)
        val progress: ContentLoadingProgressBar = view.findViewById(R.id.progress)
        lockImage.visibility = View.GONE
        imageVideoAd.visibility = View.GONE
        if (al_my_photos[position] != null) {
            progress.visibility = View.VISIBLE
            Glide.with(context).load(al_my_photos[position]!!.path).addListener(object : RequestListener<Drawable?> {
                override fun onLoadFailed(e: GlideException?, model: Any, target: Target<Drawable?>, isFirstResource: Boolean): Boolean {
                    progress.visibility = View.GONE
                    return true
                }

                override fun onResourceReady(resource: Drawable?, model: Any, target: Target<Drawable?>, dataSource: DataSource, isFirstResource: Boolean): Boolean {
                    iv.setImageDrawable(resource)
                    progress.visibility = View.GONE
                    if (al_my_photos[position]!!.isLocked) {
                        txtCoin.text = al_my_photos[position]!!.coins.toString()
                        lockImage.visibility = View.VISIBLE
                        imageVideoAd.visibility = View.GONE
                        if (al_my_photos[position]!!.coins!! <= 10) {
                            imageVideoAd.visibility = View.VISIBLE
                            lockImage.visibility = View.GONE
                        }
                    } else {
                        lockImage.visibility = View.GONE
                        imageVideoAd.visibility = View.GONE
                    }
                    return true
                }
            }).into(iv)
            val viewPager = container as ViewPager
            viewPager.addView(view, 0)
        }
        imageVideoAd.setOnClickListener { onClicklock.onClickPremium(position) }
        lockImage.setOnClickListener { onClicklock.onClickLock(position) }
        return view
    }

    override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
        val viewPager = container as ViewPager
        val view = `object` as View
        viewPager.removeView(view)
    }

    interface OnClicklock {
        fun onClickLock(position: Int)
        fun onClickPremium(position: Int)
    }

}