package com.solid.color.wallpaper.hd.image.background.imagePicker.ui.imagepicker;

import com.solid.color.wallpaper.hd.image.background.imagePicker.model.Folder;
import com.solid.color.wallpaper.hd.image.background.imagePicker.model.Image;
import com.solid.color.wallpaper.hd.image.background.imagePicker.ui.common.MvpView;

import java.util.List;



public interface ImagePickerView extends MvpView {

    void showLoading(boolean isLoading);

    void showFetchCompleted(List<Image> images, List<Folder> folders);

    void showError(Throwable throwable);

    void showEmpty();

    void showCapturedImage(List<Image> images);

    void finishPickImages(List<Image> images);

}