package com.solid.color.wallpaper.hd.image.background.adapter

import android.annotation.SuppressLint
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import com.solid.color.wallpaper.hd.image.background.fragment.ScreenCategoryFragment
import com.solid.color.wallpaper.hd.image.background.model.WallpaperWeekModel
import com.solid.color.wallpaper.hd.image.background.newModel.WallpaperWeekModelNewResponse
import java.util.*

class CategoryScreenPagerAdapter @SuppressLint("WrongConstant") constructor(fm: FragmentManager?, private val mResolutionModelList: ArrayList<ArrayList<WallpaperWeekModelNewResponse?>?>) : FragmentStatePagerAdapter(fm!!) {
    override fun getItem(position: Int): Fragment {
        var fragment: Fragment? = null
        fragment = ScreenCategoryFragment(mResolutionModelList[position])
        return fragment
    }

    override fun getCount(): Int {
        return mResolutionModelList.size
    }

}