package com.solid.color.wallpaper.hd.image.background.adapter

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.model.SolidSelectableModel
import java.util.*

class SolidColorSelectableAdapter(private val mColors: ArrayList<SolidSelectableModel>, private val mContext: Context, private val mListener: setOnItemClickListener) : RecyclerView.Adapter<SolidColorSelectableAdapter.MyViewHolder>() {
    private var isLongPressed = false

    interface setOnItemClickListener {
        fun OnItemClicked(model: SolidSelectableModel?, i: Int)
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): MyViewHolder {
        return MyViewHolder(LayoutInflater.from(mContext).inflate(R.layout.rv_solid_selectable, null))
    }

    override fun onBindViewHolder(myViewHolder: MyViewHolder, i: Int) {
        val shape = GradientDrawable()
        shape.shape = GradientDrawable.RECTANGLE
        shape.setColor(mColors[i].solidColorModel.color)
        shape.cornerRadius = 24f
        myViewHolder.colorImage.background = shape
        if (isLongPressed) {
            myViewHolder.checkbox.visibility = View.VISIBLE
        } else {
            myViewHolder.checkbox.visibility = View.GONE
        }
        if (mColors[i].isDeletable) {
            myViewHolder.checkbox.isChecked = true
        } else {
            myViewHolder.checkbox.isChecked = false
        }
        myViewHolder.checkbox.setOnClickListener {
            if (mColors[i].isDeletable) {
                myViewHolder.checkbox.isChecked = false
                mColors[i].isDeletable = false
            } else {
                myViewHolder.checkbox.isChecked = true
                mColors[i].isDeletable = true
            }
        }
        myViewHolder.imgColor.setOnClickListener {
            if (myViewHolder.checkbox.visibility == View.VISIBLE) {
                if (myViewHolder.checkbox.isChecked) {
                    myViewHolder.checkbox.isChecked = false
                    mColors[i].isDeletable = false
                } else {
                    myViewHolder.checkbox.isChecked = true
                    mColors[i].isDeletable = true
                }
            } else {
                isLongPressed = true
                mColors[i].isDeletable = true
                notifyDataSetChanged()
            }
            mListener.OnItemClicked(mColors[i], i)
        }

        /* myViewHolder.imgColor.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (myViewHolder.checkbox.getVisibility() != View.VISIBLE){
                 isLongPressed=true;
                 mColors.get(i).setDeletable(true);
                 notifyDataSetChanged();
                    return true;
                }else {
                    return false;
                }
            }
        });*/
    }

    override fun getItemCount(): Int {
        return mColors.size
    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var imgColor: CardView = itemView.findViewById(R.id.imgColor)
        val colorImage: ImageView = itemView.findViewById(R.id.colorImage)
        val checkbox: CheckBox = itemView.findViewById(R.id.checkbox)

    }

}