package com.solid.color.wallpaper.hd.image.background.PaintViewFol.constant

import android.graphics.Bitmap
import android.net.Uri
import android.os.Environment
import java.io.File

class Constants {
    companion object {
        const val EXTRA_BRUSH_ID = "brushId"
        const val EXTRA_BRUSH_TYPE = "brushType"
        var mSavedBitmap: Bitmap?=null
        var brushText: String? = null
        var textFontPath: String? = "fonts_neon/BPneon.otf"

        //Image Saving path
        val root = Environment.getExternalStorageDirectory().toString()
        val myDir = File("$root/Solid Color Wallpapers")
//        var mGalleryBitmap: Bitmap? = null
//        @JvmField
//        var mGalleryUri: Uri? = null

    }
}