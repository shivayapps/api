package com.solid.color.wallpaper.hd.image.background.imagePicker.ui.imagepicker;

import android.Manifest;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.ContentObserver;
import android.graphics.PorterDuff;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.solid.color.wallpaper.hd.image.background.R;
import com.solid.color.wallpaper.hd.image.background.activity.CropImageActivity;
import com.solid.color.wallpaper.hd.image.background.constants.Constants;
import com.solid.color.wallpaper.hd.image.background.imagePicker.helper.LogHelper;
import com.solid.color.wallpaper.hd.image.background.imagePicker.helper.PermissionHelper;
import com.solid.color.wallpaper.hd.image.background.imagePicker.listener.OnBackAction;
import com.solid.color.wallpaper.hd.image.background.imagePicker.listener.OnFolderClickListener;
import com.solid.color.wallpaper.hd.image.background.imagePicker.listener.OnImageClickListener;
import com.solid.color.wallpaper.hd.image.background.imagePicker.listener.OnImageSelectionListener;
import com.solid.color.wallpaper.hd.image.background.imagePicker.model.Config;
import com.solid.color.wallpaper.hd.image.background.imagePicker.model.Constant;
import com.solid.color.wallpaper.hd.image.background.imagePicker.model.Folder;
import com.solid.color.wallpaper.hd.image.background.imagePicker.model.Image;
import com.solid.color.wallpaper.hd.image.background.imagePicker.widget.ImagePickerToolbar;
import com.solid.color.wallpaper.hd.image.background.imagePicker.widget.ProgressWheel;
import com.solid.color.wallpaper.hd.image.background.imagePicker.widget.SnackBarView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;


public class ImagePickerActivity extends AppCompatActivity implements ImagePickerView {


    private ImagePickerToolbar toolbar;
    private RecyclerViewManager recyclerViewManager;
    private RecyclerView recyclerView;
    private ProgressWheel progressWheel;
    private View emptyLayout;
    private SnackBarView snackBar;

    private Config config;
    private Handler handler;
    private ContentObserver observer;
    private ImagePickerPresenter presenter;
    private LogHelper logger = LogHelper.getInstance();
    private boolean isImageOpen = false;
    private TextView txtToolbar;
    private ImageView imgBacks;
    private static final String SAMPLE_CROPPED_IMAGE_NAME = "SampleCropImage.jpg";
    //    private UCropFragment fragment;
    private boolean mShowLoader;
    private String mToolbarTitle;
    @DrawableRes
    private int mToolbarCancelDrawable;
    @DrawableRes
    private int mToolbarCropDrawable;
    // Enables dynamic coloring
    private int mToolbarColor;
    private int mStatusBarColor;
    private int mToolbarWidgetColor;

    //   public AdRequest ins_adRequest;
    //   public InterstitialAd mInterstitialAd;

    private OnImageClickListener imageClickListener = new OnImageClickListener() {
        @Override
        public boolean onImageClick(View view, int position, boolean isSelected) {
            return recyclerViewManager.selectImage();
        }
    };

    private OnFolderClickListener folderClickListener = new OnFolderClickListener() {
        @Override
        public void onFolderClick(Folder folder) {
            Constant.lastSelectedImage = -1;
            setImageAdapter(folder.getImages(), folder.getFolderName());
            isImageOpen = true;
        }
    };

    private View.OnClickListener backClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            onBackPressed();
        }
    };


    private View.OnClickListener doneClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            toolbar.setDoneDisable();
            onDone();
        }
    };
    private File imageFile;
    private Toolbar croptoolbar;
    private boolean isImageSaved = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //  MobileAds.initialize(this, String.valueOf(R.string.admob_app_id));

        Intent intent = getIntent();
        if (intent == null) {
            finish();
            return;
        }

        config = intent.getParcelableExtra(Config.EXTRA_CONFIG);
        if (config.isKeepScreenOn()) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
//        getWindow().getDecorView().setSystemUiVisibility(getResources().getColor(R.color.white));
        setContentView(R.layout.imagepicker_activity_picker);

        setupView();
        setupComponents();
        setupToolbar();

        imgBacks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        //     LoadAds();

        //    loadInterstialAd();
        //   clearApplicationData();

    }

    /* private void loadInterstialAd() {
         if (mInterstitialAd.isLoaded()) {
             //Log.e("if", "if");
             //iv_moreapp.setVisibility(View.VISIBLE);
         } else {
             mInterstitialAd.setAdListener(null);
             mInterstitialAd = null;
             ins_adRequest = null;
             LoadAds();
             mInterstitialAd.setAdListener(new AdListener() {
                 @Override
                 public void onAdLoaded() {
                     super.onAdLoaded();

                 }

                 @Override
                 public void onAdFailedToLoad(int i) {
                     super.onAdFailedToLoad(i);

                     loadInterstialAd();

                 }
             });
         }
     }

     public boolean requestNewInterstitial() {

         try {
             if (mInterstitialAd.isLoaded()) {
                 mInterstitialAd.show();
                 return true;
             }

         } catch (Exception e) {

         }
         return false;
     }

     public void LoadAds() {

         try {
             mInterstitialAd = new InterstitialAd(this);
             mInterstitialAd.setAdUnitId(getApplicationContext().getResources().getString(R.string.interstitial_ad_id));

             ins_adRequest = new AdRequest.Builder().addTestDevice("1430CCBBF6C738012B76659D054E081E") //SWIPE
                     .build();

             mInterstitialAd.loadAd(ins_adRequest);
             mInterstitialAd.setAdListener(new AdListener() {
                 @Override
                 public void onAdClosed() {
                     super.onAdClosed();
                     Log.e("ADS", "onAdClosed: ");
                 }

                 @Override
                 public void onAdFailedToLoad(int i) {
                     super.onAdFailedToLoad(i);
                     Log.e("ADS", "onAdFailedToLoad: ");

                 }

                 @Override
                 public void onAdLeftApplication() {
                     super.onAdLeftApplication();
                     Log.e("ADS", "onAdLeftApplication: ");

                     mInterstitialAd.show();
                 }

                 @Override
                 public void onAdOpened() {
                     super.onAdOpened();
                     Log.e("ADS", "onAdOpened: ");

                 }

                 @Override
                 public void onAdLoaded() {
                     super.onAdLoaded();
                     Log.e("ADS", "onAdLoaded: ");

                 }

                 @Override
                 public void onAdClicked() {
                     super.onAdClicked();
                     Log.e("ADS", "onAdClicked: ");

                 }

                 @Override
                 public void onAdImpression() {
                     super.onAdImpression();
                     Log.e("ADS", "onAdImpression: ");

                 }
             });

         } catch (Exception e) {

         }
     }
 */
    private void setupView() {
        Constant.activity = this;

        toolbar = findViewById(R.id.toolbar);
        recyclerView = findViewById(R.id.recyclerView);
        progressWheel = findViewById(R.id.progressWheel);
        emptyLayout = findViewById(R.id.layout_empty);
        snackBar = findViewById(R.id.snackbar);
        txtToolbar = findViewById(R.id.txtToolbar);
        imgBacks = findViewById(R.id.imgBacks);

        findViewById(R.id.txtToolbar).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        Window window = getWindow();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.setStatusBarColor(config.getStatusBarColor());
        }

        progressWheel.setBarColor(config.getProgressBarColor());
        findViewById(R.id.container).setBackgroundColor(config.getBackgroundColor());

        txtToolbar.setVisibility(View.VISIBLE);
        imgBacks.setVisibility(View.VISIBLE);
    }

    private void setupComponents() {
        recyclerViewManager = new RecyclerViewManager(getSupportFragmentManager(), recyclerView, config, getResources().getConfiguration().orientation);
        recyclerViewManager.setupAdapters(imageClickListener, folderClickListener);
        recyclerViewManager.setOnImageSelectionListener(new OnImageSelectionListener() {
            @Override
            public void onSelectionUpdate(List<Image> images) {
                invalidateToolbar(true);
                if (!config.isMultipleMode() && !images.isEmpty()) {
                    onDone();
                }
            }
        });

        presenter = new ImagePickerPresenter(new ImageFileLoader(this));
        presenter.attachView(this);
    }

    private void setupToolbar() {
        toolbar.config(config);
        toolbar.setTitle(getResources().getString(R.string.imagepicker_title_folder));
//        toolbar.setBackgroundColor(Color.parseColor("#FEAE31"));
        toolbar.setOnBackClickListener(backClickListener);
        toolbar.setOnDoneClickListener(doneClickListener);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (toolbar != null) {
            toolbar.setDoneEnable();
        }
        if (!isImageOpen) {
            getDataWithPermission();
        }
    }


    private void setImageAdapter(List<Image> images, String title) {
        txtToolbar.setVisibility(View.GONE);
        imgBacks.setVisibility(View.GONE);
        recyclerViewManager.setImageAdapter(images, title);
        invalidateToolbar(false);
    }

    private void setFolderAdapter(List<Folder> folders) {
        txtToolbar.setVisibility(View.VISIBLE);
        imgBacks.setVisibility(View.VISIBLE);
        recyclerViewManager.setFolderAdapter(folders);
        invalidateToolbar(false);
    }

    private void invalidateToolbar(Boolean aBoolean) {
        toolbar.setTitle(recyclerViewManager.getTitle());
        toolbar.showDoneButton(aBoolean);
        Log.d("456456465456", "invalidateToolbar: " + recyclerViewManager.isShowDoneButton());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == 3333) {
            setResult(2222);
            finish();
        }
    }

    private void onDone() {
        Log.d("TAG", "onDone: 12121");
        //    System.gc();
        //   Bitmap bitmap = BitmapFactory.decodeFile(recyclerViewManager.getSelectedImages().get(0).getPath());
        //    if (bitmap != null) {
        //showGoogleAdHomeBack();
        try {

//            setResult(1111);
            if (!recyclerViewManager.getSelectedImages().get(0).getPath().equalsIgnoreCase("")) {
                Constants.mGalleryUri = Uri.fromFile(new File(recyclerViewManager.getSelectedImages().get(0).getPath()));
                Intent data = new Intent(ImagePickerActivity.this, CropImageActivity.class);
                startActivityForResult(data, 3333);


            } else {
                Log.d("TAG", "onDone: ");
                Toast.makeText(this, "" + getResources().getString(R.string.dialog_msg_please_wait), Toast.LENGTH_SHORT).show();
            }

//            finish();
//finish();
//            startCrop(uri);
        } catch (Exception e) {
            e.printStackTrace();
        }
        //   } else {
        //       Toast.makeText(this, "Corrupted Image!", Toast.LENGTH_SHORT).show();
        //   }
    }

    /* private void showGoogleAdHomeBack() {

         if (requestNewInterstitial()) {
             mInterstitialAd.setAdListener(new AdListener() {

                 @Override
                 public void onAdClosed() {
                     super.onAdClosed();
                     Uri uri = Uri.fromFile(new File(recyclerViewManager.getSelectedImages().get(0).getPath()));
                     startCrop(uri);
                     loadInterstialAd();
                 }

                 @Override
                 public void onAdFailedToLoad(int i) {
                     super.onAdFailedToLoad(i);
                     Uri uri = Uri.fromFile(new File(recyclerViewManager.getSelectedImages().get(0).getPath()));
                     startCrop(uri);
                     loadInterstialAd();
                 }

                 @Override
                 public void onAdLoaded() {
                     super.onAdLoaded();
                 }
             });

         } else {
             Uri uri = Uri.fromFile(new File(recyclerViewManager.getSelectedImages().get(0).getPath()));
             startCrop(uri);
             loadInterstialAd();
         }
     }*/


    public void removeFragmentFromScreen() {
        try {
            croptoolbar.setVisibility(View.GONE);
            toolbar.setDoneEnable();
            isImageSaved = false;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(final Menu menu) {
        getMenuInflater().inflate(R.menu.ucrop_menu_activity, menu);

        // Change crop & loader menu icons color to match the rest of the UI colors

        MenuItem menuItemLoader = menu.findItem(R.id.menu_loader);
        Drawable menuItemLoaderIcon = menuItemLoader.getIcon();
        if (menuItemLoaderIcon != null) {
            try {
                menuItemLoaderIcon.mutate();
                menuItemLoaderIcon.setColorFilter(mToolbarWidgetColor, PorterDuff.Mode.SRC_ATOP);
                menuItemLoader.setIcon(menuItemLoaderIcon);
            } catch (IllegalStateException e) {
                Log.i(this.getClass().getName(), String.format("%s - %s", e.getMessage(), getString(R.string.ucrop_mutate_exception_hint)));
            }
            ((Animatable) menuItemLoader.getIcon()).start();
        }

        MenuItem menuItemCrop = menu.findItem(R.id.menu_crop);
        Drawable menuItemCropIcon = ContextCompat.getDrawable(this, mToolbarCropDrawable == 0 ? R.drawable.ucrop_ic_done : mToolbarCropDrawable);
        if (menuItemCropIcon != null) {
            menuItemCropIcon.mutate();
            menuItemCropIcon.setColorFilter(mToolbarWidgetColor, PorterDuff.Mode.SRC_ATOP);
            menuItemCrop.setIcon(menuItemCropIcon);
        }
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        menu.findItem(R.id.menu_crop).setVisible(!mShowLoader);
        menu.findItem(R.id.menu_loader).setVisible(mShowLoader);
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_crop) {
        } else if (item.getItemId() == android.R.id.home) {
            removeFragmentFromScreen();
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        recyclerViewManager.changeOrientation(newConfig.orientation);
    }


    private void getDataWithPermission() {

        final String[] permissions = new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE};

        PermissionHelper.checkPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE, new PermissionHelper.PermissionAskListener() {
            @Override
            public void onNeedPermission() {
                //  PermissionHelper.requestAllPermissions(ImagePickerActivity.this, permissions, Config.RC_WRITE_EXTERNAL_STORAGE_PERMISSION);
                finish();
            }

            @Override
            public void onPermissionPreviouslyDenied() {
                //PermissionHelper.requestAllPermissions(ImagePickerActivity.this, permissions, Config.RC_WRITE_EXTERNAL_STORAGE_PERMISSION);
                finish();
            }

            @Override
            public void onPermissionDisabled() {
//                snackBar.show(R.string.imagepicker_msg_no_write_external_storage_permission, new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//                        PermissionHelper.openAppSettings(ImagePickerActivity.this);
//                    }
//                });
                finish();
            }

            @Override
            public void onPermissionGranted() {
                getData();
            }
        });
    }

    private void getData() {
        presenter.abortLoading();
        presenter.loadImages(config.isFolderMode());
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        if (requestCode == Config.RC_WRITE_EXTERNAL_STORAGE_PERMISSION) {
            if (PermissionHelper.hasGranted(grantResults)) {
                logger.d("Write External permission granted");
                getData();
                return;
            }
            logger.e("Permission not granted: results len = " + grantResults.length +
                    " Result code = " + (grantResults.length > 0 ? grantResults[0] : "(empty)"));
            finish();
        }
        logger.d("Got unexpected permission result: " + requestCode);
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onStart() {
        super.onStart();

        if (handler == null) {
            handler = new Handler();
        }
        observer = new ContentObserver(handler) {
            @Override
            public void onChange(boolean selfChange) {
                getData();
                removeFragmentFromScreen();
            }
        };
        getContentResolver().registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, observer);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (presenter != null) {
            presenter.abortLoading();
            presenter.detachView();
        }

        if (observer != null) {
            getContentResolver().unregisterContentObserver(observer);
            observer = null;
        }

        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
            handler = null;
        }
    }

    @Override
    public void onBackPressed() {
        recyclerViewManager.handleBack(new OnBackAction() {
            @Override
            public void onBackToFolder() {
                invalidateToolbar(false);
                txtToolbar.setVisibility(View.VISIBLE);
                imgBacks.setVisibility(View.VISIBLE);
            }

            @Override
            public void onFinishImagePicker() {
                setResult(RESULT_CANCELED);
                finish();
            }
        });
    }

    /**
     * MVP view methods
     */

    @Override
    public void showLoading(boolean isLoading) {
        progressWheel.setVisibility(isLoading ? View.VISIBLE : View.GONE);
        recyclerView.setVisibility(isLoading ? View.GONE : View.VISIBLE);
        emptyLayout.setVisibility(View.GONE);
    }

    @Override
    public void showFetchCompleted(List<Image> images, List<Folder> folders) {
        if (config.isFolderMode()) {
            setFolderAdapter(folders);
        } else {
            setImageAdapter(images, config.getImageTitle());
        }
    }

    @Override
    public void showError(Throwable throwable) {
        String message = getString(R.string.imagepicker_error_unknown);
        if (throwable != null && throwable instanceof NullPointerException) {
            message = getString(R.string.imagepicker_error_images_not_exist);
        }
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void showEmpty() {
        progressWheel.setVisibility(View.GONE);
        recyclerView.setVisibility(View.GONE);
        emptyLayout.setVisibility(View.VISIBLE);
    }

    @Override
    public void showCapturedImage(List<Image> images) {
        boolean shouldSelect = recyclerViewManager.selectImage();
        if (shouldSelect) {
            recyclerViewManager.addSelectedImages(images);
        }
        getDataWithPermission();
    }

    @Override
    public void finishPickImages(List<Image> images) {
        Intent data = null;
        try {
            Log.d("87127894515", "finishPickImages: " + Config.RC_PICK_IMAGES);
            if (Config.RC_PICK_IMAGES == 102) {
                data = new Intent(ImagePickerActivity.this, Class.forName("com.solid.color.wallpaper.hd.image.background.activity.CreateGradientWallpaperActivity"));
                data.putParcelableArrayListExtra(Config.EXTRA_IMAGES, (ArrayList<? extends Parcelable>) images);
                setResult(RESULT_OK, data);
                startActivity(data);
            } else if (Config.RC_PICK_IMAGES == 100) {
                data = new Intent(ImagePickerActivity.this, Class.forName("com.echo.mirror.effects.photo.collage.editor.sticker.gif.maker.activity.FreeHandCropActivity"));
                data.putParcelableArrayListExtra(Config.EXTRA_IMAGES, (ArrayList<? extends Parcelable>) images);
                data.putExtra("status", "mirror");
                setResult(RESULT_OK, data);
                startActivity(data);
            } else if (Config.RC_PICK_IMAGES == 103) {
                data = new Intent(ImagePickerActivity.this, Class.forName("com.echo.mirror.effects.photo.collage.editor.sticker.gif.maker.activity.FreeHandCropActivity"));
                data.putParcelableArrayListExtra(Config.EXTRA_IMAGES, (ArrayList<? extends Parcelable>) images);
                data.putExtra("status", "clone");
                setResult(RESULT_OK, data);
                startActivity(data);
            }/*else if (Config.RC_PICK_IMAGES == 102){
                data=new Intent();
                data.putParcelableArrayListExtra(Config.EXTRA_IMAGES, (ArrayList<? extends Parcelable>) images);
                setResult(RESULT_OK, data);
                finish();
            }else if (Config.RC_PICK_IMAGES == 103){
                data=new Intent();
                data.putParcelableArrayListExtra(Config.EXTRA_IMAGES, (ArrayList<? extends Parcelable>) images);
                setResult(RESULT_OK, data);
                finish();
            }else {
                finish();
            }*/

            //   finish();
        } catch (ClassNotFoundException e) {
            Log.d("87127894515", "finishPickImages: ");
            finish();
            e.printStackTrace();
        }

    }

    public void clearApplicationData() {
        File cache = getCacheDir();
        File appDir = new File(cache.getParent());
        if (appDir.exists()) {
            String[] children = appDir.list();
            for (String s : children) {
                if (!s.equals("lib")) {
                    boolean b = deleteDir(new File(appDir, s));
                }
            }
        }

    }

    public static boolean deleteDir(File dir) {
        if (dir != null && dir.isDirectory()) {
            String[] children = dir.list();
            int i = 0;
            while (i < children.length) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
                i++;
            }
        }

        assert dir != null;
        return dir.delete();
    }
}
