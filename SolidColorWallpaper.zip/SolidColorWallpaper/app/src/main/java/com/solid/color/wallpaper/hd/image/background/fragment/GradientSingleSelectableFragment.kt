package com.solid.color.wallpaper.hd.image.background.fragment

import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.adapter.GradientSingleSelctableAdapter
import com.solid.color.wallpaper.hd.image.background.custom.GridSpacingItemDecoration
import com.solid.color.wallpaper.hd.image.background.model.ColorModel
import com.solid.color.wallpaper.hd.image.background.model.GradientSelectableModel
import java.util.*

class GradientSingleSelectableFragment : Fragment {
    private var recyclerColor: RecyclerView? = null
    private var mGradientColors: ArrayList<GradientSelectableModel>? = null
    private var colorAdepter: GradientSingleSelctableAdapter? = null
    private var orientation: GradientDrawable.Orientation = GradientDrawable.Orientation.TOP_BOTTOM
    private var mCurrentOrientation: Int = 0
    private val orientations: Array<GradientDrawable.Orientation> = arrayOf(
            GradientDrawable.Orientation.TOP_BOTTOM,
            GradientDrawable.Orientation.TR_BL,
            GradientDrawable.Orientation.RIGHT_LEFT,
            GradientDrawable.Orientation.BR_TL,
            GradientDrawable.Orientation.BOTTOM_TOP,
            GradientDrawable.Orientation.BL_TR,
            GradientDrawable.Orientation.LEFT_RIGHT,
            GradientDrawable.Orientation.TL_BR
    )
    private var onItemClicked: OnItemClicked? = null

    constructor() {
        // Required empty public constructor
    }

    constructor(onItemClicked: OnItemClicked?) {
        this.onItemClicked = onItemClicked
    }

    open interface OnItemClicked {
        fun onItemClicked()
    }

    public override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                                     savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_gradient_selectable, container, false)
    }

    public override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        System.gc()
        Runtime.getRuntime().gc()
        mGradientColors = ArrayList()
        val allGColors: Array<String> = getResources().getStringArray(R.array.gradient_colors)
        var i: Int = 0
        while (i < allGColors.size) {
            mCurrentOrientation = (mCurrentOrientation + 1) % orientations.size
            orientation = orientations.get(mCurrentOrientation)
            val model: ColorModel = ColorModel()
            model.color1 = Color.parseColor(allGColors.get(i))
            model.color2 = Color.parseColor(allGColors.get(i + 1))
            model.orientation = orientation
            model.imagePosition = -1
            if (i % 5 == 0) {
                model.circle = true
            } else {
                model.circle = false
            }
            mGradientColors!!.add(GradientSelectableModel(model, false))
            i += 2
        }
        recyclerColor = view.findViewById(R.id.recyclerColor)
        val manager: GridLayoutManager = GridLayoutManager(activity, 3)
        recyclerColor!!.layoutManager = manager
        recyclerColor!!.addItemDecoration(GridSpacingItemDecoration(3, dpToPx(8), true))
        recyclerColor!!.itemAnimator = DefaultItemAnimator()
        val listener: GradientSingleSelctableAdapter.setOnItemClickListener = object : GradientSingleSelctableAdapter.setOnItemClickListener {
            public override fun OnItemClicked(color: GradientSelectableModel?, i: Int) {
                onItemClicked!!.onItemClicked()
            }
        }
        colorAdepter = GradientSingleSelctableAdapter(mGradientColors!!, activity!!, listener)
        recyclerColor!!.adapter = colorAdepter
    }

    fun setDataChanged() {
        if (colorAdepter != null) {
            colorAdepter!!.setDataChange()
        }
    }

    val dataList: ArrayList<GradientSelectableModel>
        get() {
            val mList: ArrayList<GradientSelectableModel> = ArrayList()
            val metrics: DisplayMetrics = DisplayMetrics()
            try {
                activity!!.windowManager.defaultDisplay.getMetrics(metrics)
                for (i in mGradientColors!!.indices) {
                    if (mGradientColors!![i].isDeletable) {
                        mList.add(mGradientColors!![i])
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            return mList
        }

    fun convertToBitmap(drawable: GradientDrawable, widthPixels: Int, heightPixels: Int): Bitmap {
        val mutableBitmap: Bitmap = Bitmap.createBitmap(widthPixels, heightPixels, Bitmap.Config.ARGB_8888)
        val canvas: Canvas = Canvas(mutableBitmap)
        drawable.setBounds(0, 0, widthPixels, heightPixels)
        drawable.draw(canvas)
        return mutableBitmap
    }

    private fun dpToPx(dp: Int): Int {
        val r: Resources = resources
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), r.displayMetrics))
    }
}