package com.solid.color.wallpaper.hd.image.background.model.api

import com.google.gson.annotations.SerializedName

class ImageItem {
    @SerializedName("image")
    val image: String? = null

    @SerializedName("is_premium")
    val isPremium = 0

    @SerializedName("category_id")
    val categoryId = 0

    @SerializedName("thumb_image")
    val thumbImage: String? = null

    @SerializedName("coins")
    val coins = 0

    @SerializedName("id")
    val id = 0

}