package com.solid.color.wallpaper.hd.image.background.constants

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Environment
import com.solid.color.wallpaper.hd.image.background.model.ColorModel
import com.solid.color.wallpaper.hd.image.background.model.GradientResolutionModel
import com.solid.color.wallpaper.hd.image.background.model.ResolutionModel
import com.solid.color.wallpaper.hd.image.background.model.SolidColorModel
import java.util.*

object Constants {

    @JvmField
    var isCoin = false

    @JvmField
    var catPosition:Int = 0

    @JvmField
    var selectedWallpaper: SolidColorModel? = null

    @JvmField
    var mSolidColorWallpapers = ArrayList<SolidColorModel>()

    @JvmField
    var mGradientColorWallpapers = ArrayList<ColorModel>()

    @JvmField
    var solidPosition = 0

    @JvmField
    var gradientPosition = 0

    @JvmField
    var selectedGWallpaper: ColorModel? = null
    var selectedRotateWallpaper: ColorModel? = null

    @JvmField
    var isGradient = false
    var isCircle = false

    @JvmField
    var isColorSelected = false
    var orientation = GradientDrawable.Orientation.TOP_BOTTOM

    @JvmField
    var path = Environment.getExternalStorageDirectory().absolutePath + "/Pictures" + "/Solid Wallpaper"

    @JvmField
    var savedPath: String? = null

    @JvmField
    var SOLID_CREATE_SELECTED_COLOR = Color.TRANSPARENT

    @JvmField
    var SOLID_CREATE_SELECTED_EMOJI_IMAGE: String? = null

    @JvmField
    var SOLID_CREATE_SELECTED_EMOJI_IMAGE_COLOR = -1

    @JvmField
    var SOLID_CREATE_OPACITY = 1f
    var GRADIENT_CREATE_SELECTED_EMOJI_IMAGE: String? = null
    var GRADIENT_CREATE_SELECTED_EMOJI_IMAGE_COLOR = -1
    var GRADIENT_CREATE_OPACITY = 1f

    @JvmField
    var isNativeAd1 = false

    @JvmField
    var mSavedBitmap: Bitmap? = null

    @JvmField
    var isFromFrag = false

    @JvmField
    var mEmojiList = ArrayList<String>()

    @JvmField
    var selectedPosition = 0
    var mSavedImageList = ArrayList<String>()

    @JvmField
    var positions=0

    @JvmField
    var isAdsLoaded = false

    @JvmField
    var stickerTypeface: String? = null

    @JvmField
    var stickerText: String? = null

    @JvmField
    var isTextWallpaper = false

    @JvmField
    var viewpagerPos = 1
    var isBackPressed = false

    @JvmField
    var viewPagerPage = 1

    @JvmField
    var isDataChanges = false

    @JvmField
    var mWallpaperBitmap: Bitmap? = null

    @JvmField
    var mGalleryBitmap: Bitmap? = null

    @JvmField
    var mGalleryUri: Uri? = null

    @JvmField
    var isText = false

    @JvmField
    var isLanguageChanged = false

    @JvmField
    var resolutionModel: ResolutionModel? = null

    @JvmField
    var resolutionModelGradient: GradientResolutionModel? = null

    @JvmField
    var isInstrastial1 = true

    @JvmField
    var isSubscribedW = false

    @JvmField
    var isSubscribedH = false

    @JvmField
    var isSubscribedS = false

    @JvmField
    var isSubscribedG = false

    @JvmField
    var isSubscribedT = false
    var isLanguageChange = false

    @JvmField
    var isAddWallpaperClicked = false
    var isFirstTime = false

    @JvmField
    var isDataChaged = false

    @JvmField
    var mBitmapPath: ArrayList<Bitmap> = ArrayList()

    @JvmField
    var mCategoryName: String? = null

    @JvmField
    var mStickerName: String? = null

    @JvmField
    var mBitmapPathUndo: ArrayList<Bitmap> = ArrayList()

    @JvmField
    var HDposition = 0;
}