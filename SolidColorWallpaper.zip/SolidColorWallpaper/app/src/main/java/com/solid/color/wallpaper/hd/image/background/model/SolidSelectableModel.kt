package com.solid.color.wallpaper.hd.image.background.model

class SolidSelectableModel(var solidColorModel: SolidColorModel, var isDeletable: Boolean)