package com.solid.color.wallpaper.hd.image.background.activity

import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Layout
import android.util.DisplayMetrics
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.constants.Constants
import com.solid.color.wallpaper.hd.image.background.custom.MatrixClonable
import com.solid.color.wallpaper.hd.image.background.model.ResolutionModel
import com.solid.color.wallpaper.hd.image.background.model.StickerModel
import com.solid.color.wallpaper.hd.image.background.sqlite_database.DBHelperResolution
import com.xiaopo.flying.sticker.DrawableSticker
import com.xiaopo.flying.sticker.Sticker
import com.xiaopo.flying.sticker.StickerView
import com.xiaopo.flying.sticker.TextSticker
import java.util.*

class ResolutionTestActivity constructor() : AppCompatActivity() {
    private var imgWallpaper: ImageView? = null
    private var mAllSticker: ArrayList<StickerModel?>? = null
    private var resolutionModel: ResolutionModel? = null
    private var sticker_view: StickerView? = null
    private var mainFrame: FrameLayout? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resolution_test)
        imgWallpaper = findViewById(R.id.imgWallpaper)
        sticker_view = findViewById(R.id.sticker_viewnew)
        mainFrame = findViewById(R.id.mainFrame)
        sticker_view!!.isLocked = true
        initViewAction()
    }

    private fun initViewAction() {
        mAllSticker = ArrayList()
        val mList: ArrayList<ResolutionModel> = DBHelperResolution(this@ResolutionTestActivity).resolutionModelList
        /*  for (int i = 0; i < mList.size(); i++) {
            Log.d(TAG, "addTextSticker: "+mList.get(i).getMainWidth());
            Log.d(TAG, "addTextSticker: "+mList.get(i).getMainHeight());
            Log.d(TAG, "addTextSticker: "+mList.get(i).getColor1());
            Log.d(TAG, "addTextSticker: "+mList.get(i).getColor2());
            Log.d(TAG, "addTextSticker: "+mList.get(i).isCircle());
            Log.d(TAG, "addTextSticker: "+mList.get(i).isInner());
            Log.d(TAG, "addTextSticker: "+mList.get(i).getOrientation());
            Log.d(TAG, "addTextSticker: "+mList.get(i).getmAllSticker());
        }*/resolutionModel = Constants.resolutionModel
        /*  ConstraintLayout.LayoutParams params= (ConstraintLayout.LayoutParams) mainFrame.getLayoutParams();
        params.width=resolutionModel.getMainWidth();
        params.height=resolutionModel.getMainHeight();
        mainFrame.requestLayout();*/
        mAllSticker!!.addAll(resolutionModel!!.getmAllSticker()!!)
        addTextSticker()
        if (resolutionModel!!.isCircle) {
            setCircleGradient(resolutionModel!!.isInner)
        } else {
            setGradientDrawable(resolutionModel!!.orientation)
        }
    }

    fun addTextSticker() {
        for (i in mAllSticker!!.indices) {
            val model: StickerModel = mAllSticker!!.get(i)!!
            if (model.isText) {
                val strk: TextSticker = TextSticker(this@ResolutionTestActivity)
                strk.drawable = (ContextCompat.getDrawable(applicationContext, R.drawable.sticker_transparent_background))!!
                strk.setTypeface(Typeface.createFromAsset(assets, model.typeface))
                strk.text = model.getText()
                strk.setTextColor(model.textColor)
                strk.setTextAlign(Layout.Alignment.ALIGN_CENTER)
                strk.alpha = model.textAlhpa
                strk.resizeText()
                sticker_view!!.addSticker(strk)
            } else {
                val sticker1: DrawableSticker = DrawableSticker(model.drawable)
                sticker1.color = model.drawableColor
                sticker1.alpha = model.drawableAlpha
                sticker_view!!.addSticker(sticker1)
            }
        }
        sticker_view!!.post {
            imgWallpaper!!.post {
                for (i in sticker_view!!.stickers.indices) {
                    val sticker: Sticker = sticker_view!!.stickers[i]
                    sticker.setMatrix(mAllSticker!![i]!!.matrix)
                }
                sticker_view!!.invalidate()
                for (i in sticker_view!!.stickers.indices) {
                    val sticker: Sticker = sticker_view!!.stickers[i]
                    if (sticker is TextSticker) {
                        val sclH: Float = imgWallpaper!!.height.toFloat() / resolutionModel!!.mainHeight.toFloat()
                        val sclW: Float = imgWallpaper!!.width.toFloat() / resolutionModel!!.mainWidth.toFloat()
                        val matrix: MatrixClonable = MatrixClonable()
                        matrix.set(sticker.getMatrix())
                        matrix.postScale(sclW, sclH)
                        sticker.setMatrix(matrix)
                    } else {
                        val sclH: Float = imgWallpaper!!.height.toFloat() / resolutionModel!!.mainHeight.toFloat()
                        val sclW: Float = imgWallpaper!!.width.toFloat() / resolutionModel!!.mainWidth.toFloat()
                        val matrix: MatrixClonable = MatrixClonable()
                        matrix.set(sticker.matrix)
                        matrix.postScale(sclW, sclH)
                        sticker.setMatrix(matrix)
                    }
                }
                sticker_view!!.invalidate()
            }
        }
    }

    private fun setGradientDrawable(orientation: GradientDrawable.Orientation?) {
        val new_colors: IntArray = intArrayOf(resolutionModel!!.color1, resolutionModel!!.color2)
        val shape: GradientDrawable = GradientDrawable(orientation, new_colors)
        shape.shape = GradientDrawable.RECTANGLE
        imgWallpaper!!.background = shape
    }

    private fun setCircleGradient(isInner: Boolean) {
        val metrics: DisplayMetrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(metrics)
        if (!isInner) {
            val new_colors: IntArray = intArrayOf(resolutionModel!!.color2, resolutionModel!!.color1)
            val shape: GradientDrawable = GradientDrawable()
            shape.shape = GradientDrawable.RECTANGLE
            shape.colors = new_colors
            shape.gradientType = GradientDrawable.RADIAL_GRADIENT
            shape.gradientRadius = metrics.widthPixels.toFloat()
            imgWallpaper!!.background = shape
        } else {
            val new_colors: IntArray = intArrayOf(resolutionModel!!.color1, resolutionModel!!.color2)
            val shape: GradientDrawable = GradientDrawable()
            shape.shape = GradientDrawable.RECTANGLE
            shape.colors = new_colors
            shape.gradientType = GradientDrawable.RADIAL_GRADIENT
            shape.gradientRadius = metrics.widthPixels.toFloat()
            imgWallpaper!!.background = shape
        }
    }

    fun onClickSave(view: View?) {
        DBHelperResolution(this@ResolutionTestActivity).insertResolutionModel((Constants.resolutionModel)!!)
    }

    companion object {
        private val TAG: String = "ResolutionTestActiv212"
    }
}