package com.solid.color.wallpaper.hd.image.background.activity

import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.SolidWallpaperApplication
import com.solid.color.wallpaper.hd.image.background.activity.LanguageSelectionActivity
import com.solid.color.wallpaper.hd.image.background.adshalper.OfflineNativeAdvanced
import com.solid.color.wallpaper.hd.image.background.shared_pref.MySharedPref
import kotlinx.android.synthetic.main.activity_main_start.*
import java.util.*

class LanguageSelectionActivity constructor() : AppCompatActivity() {
    private var sharedPreferences: MySharedPref? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_language_selection)

        sharedPreferences = MySharedPref(this@LanguageSelectionActivity)
        val checkSpanish: ImageView = findViewById(R.id.checkSpanish)
        val checkEnglish: ImageView = findViewById(R.id.checkEnglish)
        val checkRussian: ImageView = findViewById(R.id.checkRussian)
        val checkPortuguese: ImageView = findViewById(R.id.checkPortuguese)
        val checkTurkish: ImageView = findViewById(R.id.checkTurkish)
        val checkArabic: ImageView = findViewById(R.id.checkArabic)
        val txtEnglish: TextView = findViewById(R.id.txtEnglish)
        val txtSpanish: TextView = findViewById(R.id.txtSpanish)
        val txtRussian: TextView = findViewById(R.id.txtRussian)
        val txtArabic: TextView = findViewById(R.id.txtArabic)
        val txtTurkish: TextView = findViewById(R.id.txtTurkish)
        val txtPortuguese: TextView = findViewById(R.id.txtPortuguese)
        val btnPositive: Button = findViewById(R.id.btnPositive)
//        val btnNagative: Button = findViewById(R.id.btnNagative)
        if (sharedPreferences!!.language.equals("English", ignoreCase = true)) {
            checkEnglish.visibility = View.VISIBLE
            checkTurkish.visibility = View.GONE
            checkRussian.visibility = View.GONE
            checkSpanish.visibility = View.GONE
            checkArabic.visibility = View.GONE
            checkPortuguese.visibility = View.GONE
        } else if (sharedPreferences!!.language.equals("Pусский", ignoreCase = true)) {
            checkEnglish.visibility = View.GONE
            checkRussian.visibility = View.VISIBLE
            checkTurkish.visibility = View.GONE
            checkSpanish.visibility = View.GONE
            checkArabic.visibility = View.GONE
            checkPortuguese.visibility = View.GONE
        } else if (sharedPreferences!!.language.equals("Portuguesa", ignoreCase = true)) {
            checkEnglish.visibility = View.GONE
            checkTurkish.visibility = View.GONE
            checkRussian.visibility = View.GONE
            checkSpanish.visibility = View.GONE
            checkArabic.visibility = View.GONE
            checkPortuguese.visibility = View.VISIBLE
        } else if (sharedPreferences!!.language.equals("Española", ignoreCase = true)) {
            checkEnglish.visibility = View.GONE
            checkRussian.visibility = View.GONE
            checkSpanish.visibility = View.VISIBLE
            checkTurkish.visibility = View.GONE
            checkArabic.visibility = View.GONE
            checkPortuguese.visibility = View.GONE
        } else if (sharedPreferences!!.language.equals("عربى", ignoreCase = true)) {
            checkEnglish.visibility = View.GONE
            checkRussian.visibility = View.GONE
            checkSpanish.visibility = View.GONE
            checkTurkish.visibility = View.GONE
            checkArabic.visibility = View.VISIBLE
            checkPortuguese.visibility = View.GONE
        } else{
            checkEnglish.visibility = View.GONE
            checkRussian.visibility = View.GONE
            checkSpanish.visibility = View.GONE
            checkArabic.visibility = View.GONE
            checkTurkish.visibility = View.VISIBLE
            checkPortuguese.visibility = View.GONE
        }
        txtEnglish.setOnClickListener {
            checkEnglish.visibility = View.VISIBLE
            checkRussian.visibility = View.GONE
            checkTurkish.visibility = View.GONE
            checkSpanish.visibility = View.GONE
            checkArabic.visibility = View.GONE
            checkPortuguese.visibility = View.GONE
            btnPositive.text = "Next"
        }
        txtSpanish.setOnClickListener {
            checkEnglish.visibility = View.GONE
            checkRussian.visibility = View.GONE
            checkSpanish.visibility = View.VISIBLE
            checkArabic.visibility = View.GONE
            checkTurkish.visibility = View.GONE
            checkPortuguese.visibility = View.GONE
            btnPositive.text = "Próxima"
        }
        txtRussian.setOnClickListener {
            checkEnglish.visibility = View.GONE
            checkRussian.visibility = View.VISIBLE
            checkSpanish.visibility = View.GONE
            checkTurkish.visibility = View.GONE
            checkArabic.visibility = View.GONE
            checkPortuguese.visibility = View.GONE
            btnPositive.text = "следующий"
        }
        txtPortuguese.setOnClickListener {
            checkEnglish.visibility = View.GONE
            checkRussian.visibility = View.GONE
            checkSpanish.visibility = View.GONE
            checkArabic.visibility = View.GONE
            checkTurkish.visibility = View.GONE
            checkPortuguese.visibility = View.VISIBLE
            btnPositive.text = "Próxima"
        }
        txtArabic.setOnClickListener {
            checkEnglish.visibility = View.GONE
            checkRussian.visibility = View.GONE
            checkSpanish.visibility = View.GONE
            checkTurkish.visibility = View.GONE
            checkArabic.visibility = View.VISIBLE
            checkPortuguese.visibility = View.GONE
            btnPositive.text = "التالى"
        }
        txtTurkish.setOnClickListener {
            checkEnglish.visibility = View.GONE
            checkRussian.visibility = View.GONE
            checkSpanish.visibility = View.GONE
            checkTurkish.visibility = View.VISIBLE
            checkArabic.visibility = View.GONE
            checkArabic.visibility = View.GONE
            checkPortuguese.visibility = View.GONE
            btnPositive.text = "Sonraki"
        }
        btnPositive.setOnClickListener {
            sharedPreferences!!.noNeedToShowLanguage()
            if (checkEnglish.visibility == View.VISIBLE) {
                sharedPreferences!!.language = "English"
            } else if (checkRussian.visibility == View.VISIBLE) {
                sharedPreferences!!.language = "Pусский"
            } else if (checkSpanish.visibility == View.VISIBLE) {
                sharedPreferences!!.language = "Española"
            } else if (checkPortuguese.visibility == View.VISIBLE) {
                sharedPreferences!!.language = "Portuguesa"
            } else if (checkArabic.visibility == View.VISIBLE) {
                sharedPreferences!!.language = "عربى"
            }else if (checkTurkish.visibility == View.VISIBLE) {
                sharedPreferences!!.language = "Türkçe"
            }
            SolidWallpaperApplication.staticLanguage.Factory.create(this)
            startActivity(Intent(this@LanguageSelectionActivity, MainStartActivity::class.java))
            finish()
        }
    }
}