package com.solid.color.wallpaper.hd.image.background.imagePicker.listener;

import com.solid.color.wallpaper.hd.image.background.imagePicker.model.Folder;

public interface OnFolderClickListener {
    void onFolderClick(Folder folder);
}
