package com.solid.color.wallpaper.hd.image.background.adapter

import android.app.Activity
import android.content.Context
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.model.StickerNewModel
import com.solid.color.wallpaper.hd.image.background.shared_pref.MySharedPref
import com.solid.color.wallpaper.hd.image.background.sqlite_database.DBHelper
import java.util.*

class StickerAdapter(private val context: Activity, private val list: ArrayList<StickerNewModel>, private val mOnItemClickListener: OnItemClickListener, private val isSolid: Boolean) : RecyclerView.Adapter<StickerAdapter.MyViewHolder>() {
    private val mySharedPref: MySharedPref
    private val dbHelper: DBHelper

    interface OnItemClickListener {
        fun onItemClick(view: View?, position: Int,context: Activity)
    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var iv_shape: ImageView = itemView.findViewById(R.id.iv_shape)
        var icLock: ImageView = itemView.findViewById(R.id.icLock)
        var txtMore: TextView = itemView.findViewById(R.id.txtMore)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.row_sticker_item, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        Glide.with(context).load(list[position].path).override(150, 150).into(object : CustomTarget<Drawable?>() {
            override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                resource.colorFilter = PorterDuffColorFilter(context.resources.getColor(R.color.text_colour_new), PorterDuff.Mode.SRC_IN)
                holder.iv_shape.background = context.resources.getDrawable(R.drawable.back_roundcorner)
                if (!list[position].isFree) {
                    holder.icLock.visibility = View.VISIBLE
                    holder.iv_shape.setImageDrawable(null)
                } else {
                    holder.icLock.visibility = View.GONE
                    holder.iv_shape.setImageDrawable(resource)
                }
            }

            override fun onLoadCleared(placeholder: Drawable?) {}
        })
        holder.iv_shape.setOnClickListener { v: View? -> mOnItemClickListener.onItemClick(v, position,context) }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    init {
        mySharedPref = MySharedPref(context)
        dbHelper = DBHelper(context)
    }
}