package com.solid.color.wallpaper.hd.image.background.model

class SavedImageModel {
    var path: String? = null
    var isDeletedEnable = false

    constructor() {}
    constructor(path: String?, isDeletedEnable: Boolean) {
        this.path = path
        this.isDeletedEnable = isDeletedEnable
    }

}