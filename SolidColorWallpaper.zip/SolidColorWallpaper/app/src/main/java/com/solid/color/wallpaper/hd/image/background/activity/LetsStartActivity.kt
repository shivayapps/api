package com.solid.color.wallpaper.hd.image.background.activity

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.util.TypedValue
import android.view.View
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.adData.AdDetailModel
import com.solid.color.wallpaper.hd.image.background.adData.AdsAdapter
import com.solid.color.wallpaper.hd.image.background.adData.LoadApiData
import com.solid.color.wallpaper.hd.image.background.custom.GridSpacingItemDecoration
import java.util.*

class LetsStartActivity : AppCompatActivity() {
    private var isInternetOn = false
    private var isDataLoaded = false
    var mList: ArrayList<AdDetailModel?>? = null
    private var viewNoInternet: RelativeLayout? = null
    private var adsAdapter: AdsAdapter? = null
    private var doubleBackToExitPressedOnce = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lets_start)
        System.gc()
        viewNoInternet = findViewById(R.id.viewNoInternet)
        mList = ArrayList()
        mList!!.add(null)
        mList!!.add(null)
        mList!!.add(null)
        mList!!.add(null)
        mList!!.add(null)
        mList!!.add(null)
        LoadApiData(this@LetsStartActivity).execute()
        isInternetOn = checkConnection(this@LetsStartActivity)
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerAds)
        val listener: AdsAdapter.OnItemClickListener = object : AdsAdapter.OnItemClickListener {
            override fun onItemClick(view: View?, position: Int) {
                if (LoadApiData.apiData.size > 0) {
                    val uri = Uri.parse(LoadApiData.apiData[position]!!.app_link)
                    val intent = Intent(Intent.ACTION_VIEW, uri)
                    startActivity(intent)
                }
            }
        }
        val mLayoutManager: RecyclerView.LayoutManager = GridLayoutManager(this, 2)
        recyclerView.layoutManager = mLayoutManager
        recyclerView.addItemDecoration(GridSpacingItemDecoration(2, dpToPx(24), true))
        recyclerView.itemAnimator = DefaultItemAnimator()
        viewNoInternet!!.setVisibility(View.GONE)
        adsAdapter = AdsAdapter(this@LetsStartActivity, mList!!, listener)
        recyclerView.adapter = adsAdapter
    }

    val isINternet: Unit
        get() {
            Log.d(TAG, "isINternet: " + isInternetOn + "  " + isDataLoaded + "  " + LoadApiData.apiData.size)
            if (isInternetOn) {
                if (LoadApiData.apiData.size > 0 && !isDataLoaded) {
                    viewNoInternet!!.visibility = View.GONE
                    adsAdapter!!.addApp(LoadApiData.apiData)
                    isDataLoaded = true
                }
            } else {
                isDataLoaded = false
                viewNoInternet!!.visibility = View.VISIBLE
            }
        }

    private fun dpToPx(dp: Int): Int {
        val r = resources
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), r.displayMetrics))
    }

    fun checkConnection(context: Context): Boolean {
        val connMgr = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetworkInfo = connMgr.activeNetworkInfo
        Log.d(TAG, "checkConnection: ")
        if (activeNetworkInfo != null) {
            if (activeNetworkInfo.type == ConnectivityManager.TYPE_WIFI) {
                return true
            } else if (activeNetworkInfo.type == ConnectivityManager.TYPE_MOBILE) {
                return true
            }
        }
        return false
    }

    fun onclickTryAgain(view: View?) {
        if (checkConnection(this@LetsStartActivity)) {
            LoadApiData(this@LetsStartActivity).execute()
            isInternetOn = true
            viewNoInternet!!.visibility = View.INVISIBLE
        } else {
            Toast.makeText(this, resources.getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show()
        }
    }

    override fun onBackPressed() {
        // exitDialog();
        if (doubleBackToExitPressedOnce) {
            finishAffinity()
            return
        }
        doubleBackToExitPressedOnce = true
        Toast.makeText(this, resources.getString(R.string.press_again_to_exit), Toast.LENGTH_SHORT).show()
        Handler().postDelayed({ doubleBackToExitPressedOnce = false }, 2000)
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    fun onClickStart(view: View?) {
        startActivity(Intent(this@LetsStartActivity, HomeActivity::class.java))
    }

    companion object {
        private const val TAG = "LetsStartActivity"
    }
}