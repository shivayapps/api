package com.solid.color.wallpaper.hd.image.background.activity

import android.Manifest
import android.app.*
import android.content.ComponentName
import android.content.ContentUris
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.viewpager.widget.ViewPager
import androidx.viewpager.widget.ViewPager.OnPageChangeListener
import com.auto.wallpaper.live.background.changer.editor.receiver.EventReceiver
import com.auto.wallpaper.live.background.changer.editor.receiver.EventReceiver.Companion.cancelAlarm
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.snackbar.Snackbar
import com.solid.color.wallpaper.hd.image.background.BuildConfig
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.SolidWallpaperApplication
import com.solid.color.wallpaper.hd.image.background.SolidWallpaperApplication.Companion.instance
import com.solid.color.wallpaper.hd.image.background.activity.WallpaperViewActivity
import com.solid.color.wallpaper.hd.image.background.adapter.GalleryPagerAdapter
import com.solid.color.wallpaper.hd.image.background.constants.Constants
import com.solid.color.wallpaper.hd.image.background.custom.BottomSheetFragment
import com.solid.color.wallpaper.hd.image.background.live_wallpaper.CustomNewWallpaper
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs.getBoolean
import com.solid.color.wallpaper.hd.image.background.shared_pref.MySharedPref
import com.solid.color.wallpaper.hd.image.background.sqlite_database.DBHelperAutoWallpaper
import com.willy.ratingbar.BaseRatingBar
import com.willy.ratingbar.BaseRatingBar.OnRatingChangeListener
import com.willy.ratingbar.ScaleRatingBar
import java.io.File
import java.io.FileFilter
import java.io.IOException
import java.util.*

class WallpaperViewActivity constructor() : AppCompatActivity() {
    private var myViewPager: ViewPager? = null
    private var mProgressBar: ProgressBar? = null
    private var btnShare: ImageView? = null
    private var btnDelete: ImageView? = null
    private var btnSetWallpaper1: TextView? = null
    private var position: Int = 0
    private var progressBar: ProgressDialog? = null
    private var mySharedPref: MySharedPref? = null
    private var imagePaths: ArrayList<String>? = null
    private var vibrator: Vibrator? = null
    private var isAd: Boolean = false

    var bottomSheetFragment:BottomSheetFragment?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_wallpaper_view)
        System.gc()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted
            startActivity(Intent(this@WallpaperViewActivity, MainStartActivity::class.java))
            finish()
        } else {
            if (!getBoolean(this, AdsPrefs.IS_SUBSCRIBED, false)) {
                loadInterstialAd()
            }
            initViews()
            initViewAction()
        }
    }

    private fun initViewAction() {
        mySharedPref = MySharedPref(this)
        position = Constants.selectedPosition
        Log.d("TAG======>>>>", "initViewAction: " + position)
        if (mySharedPref!!.vibration) {
            vibrator = getSystemService(Service.VIBRATOR_SERVICE) as Vibrator?
        }
        progressBar = ProgressDialog(this)
        progressBar!!.setMessage(getResources().getString(R.string.dialog_msg_please_wait))
        progressBar!!.setCancelable(false)
        photoes
        myViewPager!!.addOnPageChangeListener(object : OnPageChangeListener {
            public override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {}
            public override fun onPageSelected(position1: Int) {
                position = position1
            }

            public override fun onPageScrollStateChanged(state: Int) {}
        })
        mProgressBar!!.visibility = View.GONE
        btnDelete!!.setOnClickListener(View.OnClickListener { v: View? ->
            if (position < 0) {
                position = 0
            }
            showAlertDialog(position)
        })
        btnSetWallpaper1!!.setOnClickListener(View.OnClickListener { v: View? ->
            if (position < 0) {
                position = 0
            }
            if (Constants.isText && mySharedPref!!.scale.equals("Fit", ignoreCase = true)) {

                /*    WallpaperManager myWallpaperManager
                        = WallpaperManager.getInstance(getApplicationContext());
                try {

                    myWallpaperManager.clear();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }*/
                Constants.mWallpaperBitmap = BitmapFactory.decodeFile(imagePaths!!.get(position))
                try {
                    val intent: Intent = Intent(
                            WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                    intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                            ComponentName(this@WallpaperViewActivity, CustomNewWallpaper::class.java))
                    startActivity(intent)
                } catch (e: Exception) {
                    e.printStackTrace()
                    showSnackBar(resources.getString(R.string.live_wallpaper_not_supported))
                }
            } else {
                showCustomDialog(position)
            }
        })
        btnShare!!.setOnClickListener(View.OnClickListener { v: View? -> shareWallpaper() })
    }

    private fun loadInterstialAd() {
        if (instance!!.mInterstitialAd != null) {
        } else {
            if (instance!!.mInterstitialAd != null) {
                instance!!.mInterstitialAd!!.fullScreenContentCallback = null
                instance!!.mInterstitialAd = null
                instance!!.ins_adRequest = null
                instance!!.LoadAds()

                instance!!.mInterstitialAd!!.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
//                    Log.d(TAG, 'Ad was dismissed.')
                    }

                    override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
                        super.onAdFailedToShowFullScreenContent(p0)
                        loadInterstialAd()
                    }

                    override fun onAdShowedFullScreenContent() {
//                    Log.d(TAG, 'Ad showed fullscreen content.')
                        instance!!.mInterstitialAd = null;
                    }
                }
                instance!!.mInterstitialAd!!.show(this)

//            instance!!.mInterstitialAd!!.adListener = object : AdListener() {
//                public override fun onAdLoaded() {
//                    super.onAdLoaded()
//                }
//
//                public override fun onAdFailedToLoad(i: Int) {
//                    super.onAdFailedToLoad(i)
//                    loadInterstialAd()
//                }
//            }
            }
        }
    }

    private fun setWall() {
        val uri: Uri = FileProvider.getUriForFile(this@WallpaperViewActivity, BuildConfig.APPLICATION_ID.toString() + ".provider", File(imagePaths!!.get(position)))
        val intent: Intent = Intent("android.intent.action.ATTACH_DATA")
        intent.addCategory("android.intent.category.DEFAULT")
        intent.setDataAndType(uri, "image/jpeg")
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        intent.putExtra("mimeType", "image/jpeg")
        startActivity(Intent.createChooser(intent, getResources().getString(R.string.set_as)))
    }

    //  imagePaths.add(value.getAbsolutePath());
    private val photoes: Unit
        private get() {
            imagePaths = ArrayList()
            val file: File = File(Constants.path)
            if (file.isDirectory) {
                val files: Array<File>? = file.listFiles(FileFilter { pathname: File -> pathname.path.endsWith(".jpg") || pathname.path.endsWith(".jpeg") || pathname.path.endsWith(".png") })
                if (files != null && files.isNotEmpty()) {
                    var temp: File
                    for (i in files.indices) {
                        for (j in i + 1 until files.size) {
                            if (files[i].lastModified() < files[j].lastModified()) {
                                temp = files[i]
                                files[i] = files[j]
                                files[j] = temp
                            }
                        }
                    }
                    for (value: File in files) {
                        if (Constants.viewpagerPos == 0) {
                            if (value.absolutePath.contains("Solid_") || value.absolutePath.contains("Gradient_") || value.absolutePath.contains("Text_")) {
                                Log.d("TAG=========>>>>>>>", "getPhotoes: 0 ")
                                imagePaths!!.add(value.absolutePath)
                            }
                        } else if (Constants.viewpagerPos == 1) {
                            if (value.absolutePath.contains("API_")) {
                                Log.d("TAG=========>>>>>>>", "getPhotoes: 1 " + value.absolutePath)
                                imagePaths!!.add(value.absolutePath)
                            }
                        } else if (Constants.viewpagerPos == 2) {
                            if (value.absolutePath.contains("PAINT_")) {
                                Log.d("TAG=========>>>>>>>", "getPhotoes: 2 ")
                                imagePaths!!.add(value.absolutePath)
                            }
                        }
                        Log.d("TAG=========>>>>>", "getPhotoes: " + value.absolutePath)
                        //  imagePaths.add(value.getAbsolutePath());
                    }
                    Log.d("TAG=========>>>>>", "getPhotoes: " + imagePaths!!.size)
                }
            }
            if (imagePaths!!.size > 0) {
                setDataToAdapter()
            } else {
                finish()
            }
        }

    private fun setDataToAdapter() {
        if (imagePaths!!.size > 0) {
            val adapter: GalleryPagerAdapter = GalleryPagerAdapter(this, (imagePaths)!!)
            myViewPager!!.adapter = adapter
            myViewPager!!.currentItem = position
            Log.d("TAG======>>>>", "setDataToAdapter: " + myViewPager!!.currentItem + "  " + position)
        }
    }

    private fun initViews() {
        mProgressBar = findViewById(R.id.progressBar)
        myViewPager = findViewById(R.id.imageViewPager)
        btnDelete = findViewById(R.id.btnDelete)
        btnSetWallpaper1 = findViewById(R.id.btnSetWallpaper1)
        btnShare = findViewById(R.id.btnShare)
    }

    private fun shareWallpaper() {
        val uri: Uri? = FileProvider.getUriForFile(this@WallpaperViewActivity, BuildConfig.APPLICATION_ID.toString() + ".provider", File(imagePaths!!.get(position)))
        if (uri != null) {
            val intent: Intent = Intent(Intent.ACTION_SEND)
            intent.type = "image/jpeg"
            intent.putExtra(Intent.EXTRA_STREAM, uri)
            var shareMessage: String = ""
            shareMessage += "https://play.google.com/store/apps/details?id=com.solid.color.wallpaper.hd.image.background"
            intent.putExtra(Intent.EXTRA_TEXT, shareMessage)
            startActivityForResult(Intent.createChooser(intent, getResources().getString(R.string.share_wallpaper)), 100)
        }
    }


    private fun showCustomDialog(position: Int) {
        btnSetWallpaper1!!.isEnabled = false
        val mBottomSheetDialog: BottomSheetDialog = BottomSheetDialog(this@WallpaperViewActivity, R.style.BottomSheetDialog)
        val sheetView: View = layoutInflater.inflate(R.layout.dialog_setwallpaper, null)
        mBottomSheetDialog.setContentView(sheetView)
        mBottomSheetDialog.show()
        mBottomSheetDialog.setOnDismissListener(DialogInterface.OnDismissListener { dialog: DialogInterface? -> btnSetWallpaper1!!.isEnabled = true })
        val wallpaper: LinearLayout = sheetView.findViewById(R.id.btnHomeScreen)
        val bothwallpaper: LinearLayout = sheetView.findViewById(R.id.btnBoth)
        val lockscreen: LinearLayout = sheetView.findViewById(R.id.btnLockScreen)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            bothwallpaper.visibility = View.GONE
            lockscreen.visibility = View.GONE
        }
        lockscreen.setOnClickListener(View.OnClickListener { view: View? ->
            mySharedPref!!.countExist = mySharedPref!!.countExist + 1
            mBottomSheetDialog.dismiss()
            progressBar!!.show()
            Handler().postDelayed(Runnable {

                //   progressBar.dismiss();
                btnSetWallpaper1!!.isEnabled = true
                if (mySharedPref!!.countExist >= 3 && mySharedPref!!.visitPlay == null) {
                   // showRateDialog()
                }
            }, 3000)
            if (mySharedPref!!.alarmId != -1) {
                DBHelperAutoWallpaper(this@WallpaperViewActivity).updateData()
                cancelAlarm(("2121" + mySharedPref!!.alarmId).toInt(), this@WallpaperViewActivity, EventReceiver::class.java)
            }
            Handler().postDelayed(Runnable { lockScreenWallpaper(position) }, 400)
        })
        wallpaper.setOnClickListener(View.OnClickListener { v: View? ->
            mBottomSheetDialog.dismiss()
            //   Toast.makeText(ViewGradientCreatedWallpaperActivity.this, "Please Wait...", Toast.LENGTH_SHORT).show();
            mySharedPref!!.count = mySharedPref!!.count + 1
            progressBar!!.show()
            Handler().postDelayed(Runnable {

                //  progressBar.dismiss();
                btnSetWallpaper1!!.isEnabled = true
                if (mySharedPref!!.count >= 3 && mySharedPref!!.visitPlay == null) {
                    //showRateDialog()
                }
            }, 3000)
            if (mySharedPref!!.alarmId != -1) {
                DBHelperAutoWallpaper(this@WallpaperViewActivity).updateData()
                cancelAlarm(("2121" + mySharedPref!!.alarmId).toInt(), this@WallpaperViewActivity, EventReceiver::class.java)
            }
            Handler().postDelayed(Runnable { onclickWallpaper(position, false) }, 400)
        })
        bothwallpaper.setOnClickListener(View.OnClickListener { v: View? ->
            mBottomSheetDialog.dismiss()
            //  Toast.makeText(ViewGradientCreatedWallpaperActivity.this, "Please Wait...", Toast.LENGTH_LONG).show();
            mySharedPref!!.count = mySharedPref!!.count + 1
            progressBar!!.show()
            Handler().postDelayed(Runnable {

                //  progressBar.dismiss();
                btnSetWallpaper1!!.setEnabled(true)
                if (mySharedPref!!.count >= 3 && mySharedPref!!.visitPlay == null) {
                    //showRateDialog()
                }
            }, 3000)
            if (mySharedPref!!.alarmId != -1) {
                DBHelperAutoWallpaper(this@WallpaperViewActivity).updateData()
                cancelAlarm(("2121" + mySharedPref!!.alarmId).toInt(), this@WallpaperViewActivity, EventReceiver::class.java)
            }
            Handler().postDelayed(Runnable {
                onclickWallpaper(position, true)
                lockScreenWallpaper(position)
            }, 400)
        })
    }

//    private fun showRateDialog() {
//        val viewGroup: ViewGroup = findViewById(android.R.id.content)
//        val dialogView: View = LayoutInflater.from(this@WallpaperViewActivity).inflate(R.layout.dialog_rate_app, viewGroup, false)
//        val builder: AlertDialog.Builder = AlertDialog.Builder(this@WallpaperViewActivity)
//        builder.setView(dialogView)
//        val alertDialog: AlertDialog = builder.create()
//        Objects.requireNonNull(alertDialog.window)!!.setBackgroundDrawableResource(android.R.color.transparent)
//        alertDialog.setOnCancelListener(DialogInterface.OnCancelListener({ dialog: DialogInterface? -> alertDialog.dismiss() }))
//        val btnClose: ImageView = dialogView.findViewById(R.id.btnClose)
//        btnClose.setOnClickListener(View.OnClickListener({ v: View? -> alertDialog.dismiss() }))
//        val ratingBar1: ScaleRatingBar = dialogView.findViewById(R.id.ratingBar)
//        ratingBar1.setOnRatingChangeListener(OnRatingChangeListener { ratingBar: BaseRatingBar?, rating: Float, fromUser: Boolean ->
//            if (rating > 3) {
//                rate_app()
//            } else {
//                sendMail()
//                //Toast.makeText(WallpaperViewActivity.this, getResources().getString(R.string.thanks_for_review), Toast.LENGTH_SHORT).show();
//            }
//            Handler().postDelayed(Runnable { alertDialog.dismiss() }, 1000)
//        })
//
//
//        /*  dialogView.findViewById(R.id.txtNever).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                mySharedPref.setDoNotAsk();
//                alertDialog.dismiss();
//            }
//        });
//*/dialogView.findViewById<View>(R.id.btnNextTime).setOnClickListener {
//            mySharedPref!!.countExist = 0
//            alertDialog.dismiss()
//        }
//        if (!isFinishing) {
//            alertDialog.show()
//        }
//    }
//
//    private fun sendMail() {
//        mySharedPref!!.setVisitPlay()
//        /*   Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
//        emailIntent.setType("text/plain");
//        emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{"profagnesh009@gmail.com"});
//        emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Share your valuable feedback with us to improve app quality and add more features in Solid Color Wallpaper");
//        emailIntent.setType("message/rfc822");
//        try {
//            startActivity(Intent.createChooser(emailIntent,
//                    "Send email using..."));
//        } catch (android.content.ActivityNotFoundException ex) {
//            Toast.makeText(this,
//                    "No email clients installed.",
//                    Toast.LENGTH_SHORT).show();
//        }*/
//        val send: Intent = Intent(Intent.ACTION_SENDTO)
//        val uriText: String = ("mailto:" + Uri.encode("profagnesh009@gmail.com") +
//                "?subject=" + Uri.encode("Share valuable feedback to improve app quality of Solid Color Wallpaper") +
//                "&body=" + Uri.encode(""))
//        val uri: Uri = Uri.parse(uriText)
//        send.setData(uri)
//        startActivity(Intent.createChooser(send, "Send Email..."))
//    }
//
//    private fun rate_app() {
//        mySharedPref!!.setVisitPlay()
//        try {
//            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")))
//        } catch (anfe: Exception) {
//            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName")))
//        }
//    }

    private fun lockScreenWallpaper(position: Int) {
        val mBitmap: Bitmap? = BitmapFactory.decodeFile(imagePaths!![position])
        if (mBitmap != null) {
            val wm: WallpaperManager = WallpaperManager.getInstance(this@WallpaperViewActivity)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    wm.setBitmap(mBitmap, null, true, WallpaperManager.FLAG_LOCK) //For Lock screen
                    progressBar!!.dismiss()
                    if (vibrator != null) {
                        if (Build.VERSION.SDK_INT >= 26) {
                            vibrator!!.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
                        } else {
                            vibrator!!.vibrate(200)
                        }
                    }
                    //Toast.makeText(WallpaperViewActivity.this, "Wallpaper Set Successfully.", Toast.LENGTH_SHORT).show();
                    showSnackBar(getResources().getString(R.string.toast_wallpaper_set_seccessfully))
                } else {
                    Toast.makeText(this@WallpaperViewActivity, "Lock Screen Wallpaper Not Supported",
                            Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun onclickWallpaper(position: Int, isBoth: Boolean) {
        var position: Int = position
        if (position < 0) {
            position = 0
        }
        val mBitmap: Bitmap? = BitmapFactory.decodeFile(imagePaths!![position])
        if (mBitmap != null) {
            val wallpaperManager: WallpaperManager = WallpaperManager.getInstance(this@WallpaperViewActivity)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    wallpaperManager.setBitmap(mBitmap, null, true, WallpaperManager.FLAG_SYSTEM)
                } else {
                    wallpaperManager.setBitmap(mBitmap)
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
            if (!isBoth) {
                progressBar!!.dismiss()
                if (vibrator != null) {
                    if (Build.VERSION.SDK_INT >= 26) {
                        vibrator!!.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
                    } else {
                        vibrator!!.vibrate(200)
                    }
                }
                //Toast.makeText(WallpaperViewActivity.this, "Wallpaper Set Successfully.", Toast.LENGTH_SHORT).show();
                showSnackBar(getResources().getString(R.string.toast_wallpaper_set_seccessfully))
            }
        } else {
            Toast.makeText(this@WallpaperViewActivity, getResources().getString(R.string.try_again_later), Toast.LENGTH_SHORT).show()
        }
    }

    private fun showSnackBar(msg: String) {
        val snackbar: Snackbar = Snackbar.make(findViewById(R.id.layoutMain), msg, Snackbar.LENGTH_SHORT)
        val v: View = snackbar.view
        val params: CoordinatorLayout.LayoutParams = v.layoutParams as CoordinatorLayout.LayoutParams
        params.gravity = Gravity.BOTTOM
        params.width = FrameLayout.LayoutParams.MATCH_PARENT
        v.layoutParams = params
        v.setBackgroundColor(Color.WHITE)
        val textView: TextView = v.findViewById(com.google.android.material.R.id.snackbar_text)
        textView.setTextColor(resources.getColor(R.color.text_colour_new))
        snackbar.show()
    }

    private fun showAlertDialog(position1: Int) {
        val uris = arrayListOf<Uri>()

         bottomSheetFragment= BottomSheetFragment(getResources().getString(R.string.delete), getResources().getString(R.string.are_you_want_to_remove), getResources().getString(R.string.delete), getResources().getString(R.string.cancel), R.drawable.ic_delete_dialog, object : BottomSheetFragment.OnButtonClickListener {
            public override fun onPositive(bottomSheetDialo: BottomSheetFragment?) {
                var pos: Int = position1
                bottomSheetDialo!!.dismiss()
                if (pos >= imagePaths!!.size) {
                    pos--
                }
                val ffile: File = File(imagePaths!!.get(pos))
                var result = ffile.delete()

                if (!result && (Intent.FLAG_GRANT_WRITE_URI_PERMISSION) != PackageManager.PERMISSION_GRANTED) {
                    Log.d("showAlertDialog", "onPositive: " + Constants.isDataChanges)
                    try {
                        val projection = arrayOf<String>(MediaStore.Images.Media._ID)

                        // Match on the file path
                        val selection: String = MediaStore.Images.Media.DATA.toString() + " = ?"
                        val selectionArgs = arrayOf<String>(ffile.absolutePath)

                        // Query for the ID of the media matching the file path
                        val queryUri: Uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                        val contentResolver = contentResolver
                        val c: Cursor? = contentResolver.query(queryUri, projection, selection, selectionArgs, null)

                        if (c != null) {
                            if (c.moveToFirst()) {
                                // We found the ID. Deleting the item via the content provider will also remove the file
                                val id: Long = c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media._ID))
                                val deleteUri: Uri = ContentUris.withAppendedId(queryUri, id)
                                try {
                                    Log.d("showAlertDialog", "onPositive: " + uris!!.size)

                                    uris.add(deleteUri)
                                    //contentResolver.delete(deleteUri, null, null)
                                    //MediaStore.createDeleteRequest(requireContext().contentResolver, arrayOf(deleteUri).toList())
                                } catch (securityException: SecurityException) {
                                    securityException.printStackTrace()
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                        val recoverableSecurityException =
                                                securityException as? RecoverableSecurityException
                                                        ?: throw securityException

                                        // Signal to the Activity that it needs to request permission and
                                        // try the delete again if it succeeds.
                                        //pendingDeleteImage = image

                                        /*startIntentSenderForResult(
                                                recoverableSecurityException.userAction.actionIntent.intentSender,
                                                DELETE_PERMISSION_REQUEST,
                                                null,
                                                0,
                                                0,
                                                0,
                                                null
                                        )*/
                                    } else {
                                        throw securityException
                                    }
                                }
                            } else {
                                // File not found in media store DB
                            }
                            c.close()
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                } else {
                    try {
                        sendBroadcast(Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(File(ffile.absolutePath))))
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                }

                if (uris.isNotEmpty()) {
                    deleteImages(uris)
                    return
                }
                imagePaths!!.removeAt(pos)
                Constants.isDataChanges = true
                //  onBackPressed();
                Log.d("784564564564566", "onPositive: " + Constants.isDataChanges)
                //Toast.makeText(WallpaperViewActivity.this, "Wallpaper Deleted Successfully!", Toast.LENGTH_SHORT).show();
                showSnackBar(getResources().getString(R.string.wallpaper_deleted_successfully))
                position--
                if (position < 0) {
                    position = 0
                }
                photoes
            }

            public override fun onNegative(bottomSheetDialog: BottomSheetFragment?) {
                bottomSheetDialog!!.dismiss()
            }
        })
        bottomSheetFragment!!.show(supportFragmentManager, "dialog")
    }

    override fun onPause() {
        super.onPause()
        try {
            bottomSheetFragment!!.dismiss()
        }catch (e:Exception){

        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 4444 && resultCode == Activity.RESULT_OK) {
            try {
                var pos: Int = position
                if (pos >= imagePaths!!.size) {
                    pos--
                }
                Constants.isDataChanges = true
                val ffile: File = File(imagePaths!!.get(pos))
                imagePaths!!.removeAt(pos)
                var result = ffile.delete()
                showSnackBar(resources.getString(R.string.wallpaper_deleted_successfully))
                position--
                if (position < 0) {
                    position = 0
                }
            } catch (e: Exception) {
            }
            photoes
        }
    }


    private fun deleteImages(uris: List<Uri>) {
        val pendingIntent = MediaStore.createDeleteRequest(contentResolver, uris.filter {
            checkUriPermission(it, Binder.getCallingPid(), Binder.getCallingUid(), Intent.FLAG_GRANT_WRITE_URI_PERMISSION) != PackageManager.PERMISSION_GRANTED
        })
        startIntentSenderForResult(pendingIntent.intentSender, 4444, null, 0, 0, 0, null)
    }


    override fun onResume() {
        super.onResume()
        SolidWallpaperApplication.staticLanguage.Factory.create(this)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted
            startActivity(Intent(this@WallpaperViewActivity, MainStartActivity::class.java))
            finish()
        } /*else {
            if (!isAd) {
                initViews();
                initViewAction();
            } else {
                isAd = false;
            }
        }*/
    }
}