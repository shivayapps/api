package com.solid.color.wallpaper.hd.image.background.model

class CategoryNameIconModel(var categoryName: String, var categoryIcon: String)