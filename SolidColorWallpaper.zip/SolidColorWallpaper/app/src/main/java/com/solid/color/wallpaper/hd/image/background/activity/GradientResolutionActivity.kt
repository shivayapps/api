package com.solid.color.wallpaper.hd.image.background.activity

import android.Manifest
import android.app.Activity
import android.app.ProgressDialog
import android.app.Service
import android.app.WallpaperManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.*
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.auto.wallpaper.live.background.changer.editor.receiver.EventReceiver
import com.auto.wallpaper.live.background.changer.editor.receiver.EventReceiver.Companion.cancelAlarm
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.NetworkHelper
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.wifi_network.exceptions.ApiNotSupportedException
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.wifi_network.exceptions.NullWifiConfigurationException
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.wifi_network.wifi_proxy_changing_realisations.api_from_21_to_22.WifiConfiguration
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.facebook.ads.Ad
import com.facebook.ads.AdError
import com.facebook.ads.InterstitialAdListener
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.snackbar.Snackbar
import com.solid.color.wallpaper.hd.image.background.BuildConfig
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.SolidWallpaperApplication
import com.solid.color.wallpaper.hd.image.background.SolidWallpaperApplication.Companion.instance
import com.solid.color.wallpaper.hd.image.background.constants.Constants
import com.solid.color.wallpaper.hd.image.background.constants.Constants.mGalleryBitmap
import com.solid.color.wallpaper.hd.image.background.custom.BottomSheetFragment
import com.solid.color.wallpaper.hd.image.background.custom.MatrixClonable
import com.solid.color.wallpaper.hd.image.background.live_wallpaper.CustomNewWallpaper
import com.solid.color.wallpaper.hd.image.background.model.GradientResolutionModel
import com.solid.color.wallpaper.hd.image.background.model.StickerModel
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs.getBoolean
import com.solid.color.wallpaper.hd.image.background.shared_pref.MySharedPref
import com.solid.color.wallpaper.hd.image.background.sqlite_database.DBHelperAutoWallpaper
import com.solid.color.wallpaper.hd.image.background.sqlite_database.DBHelperResolution
import com.willy.ratingbar.ScaleRatingBar
import com.xiaopo.flying.sticker.DrawableSticker
import com.xiaopo.flying.sticker.Sticker
import com.xiaopo.flying.sticker.StickerView
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.lang.reflect.InvocationTargetException
import java.util.*

class GradientResolutionActivity constructor() : AppCompatActivity(), View.OnClickListener {
    private var btnShare: ImageView? = null
    private var imgEmoji: ImageView? = null
    private var btnSave: ImageView? = null
    private var imgFromG: ImageView? = null
    private var btnHome: ImageView? = null
    private var btnBack: ImageView? = null
    private var btnSetWallpaper: TextView? = null
    private var mBitmap: Bitmap? = null
    private var mPermissionGranted: Boolean = false
    private var mPermissionGrantedWallpaper: Boolean = false
    private var isShared: Boolean = false
    private val isCircle: Boolean = false
    private var mainLayout: RelativeLayout? = null
    private var progressBar: ProgressDialog? = null
    private var mySharedPref: MySharedPref? = null
    private var isSetWallpaper: Boolean = false
    private var vibrator: Vibrator? = null
    private var imgWallpaper: ImageView? = null
    private var mAllSticker: ArrayList<StickerModel>? = null
    private var resolutionModel: GradientResolutionModel? = null
    private var sticker_view: StickerView? = null
    private var mainFrame: FrameLayout? = null
    var mCheckNet: Boolean = false
    var bottomSheetFragment:BottomSheetFragment?=null


    private var progress_circular: ProgressBar? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gradient_resolution)
        System.gc()
//        checkStatus()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted
            startActivity(Intent(this@GradientResolutionActivity, MainStartActivity::class.java))
            finish()
        } else {
            Constants.savedPath = null
            mySharedPref = MySharedPref(this)
            if ( /*!mySharedPref.getAdsRemoved() &&*/!getBoolean(this@GradientResolutionActivity, AdsPrefs.IS_SUBSCRIBED, false)) {

                if (isNetworkConnected()){
                    Constants.isInstrastial1 = false
                    loadInterstialAd()
                }

                //   loadInterstialAdFb();
            }
            initViews()
            initViewAction()
            initListner()
        }

        if (mySharedPref!!.countExist % 3 ==0 && mySharedPref!!.visitPlay == null) {
            showRateDialog()
        }
    }

    private fun showRateDialog() {
        val viewGroup: ViewGroup = findViewById(android.R.id.content)
        val dialogView: View = LayoutInflater.from(this).inflate(R.layout.dialog_rate_app, viewGroup, false)
        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder.setView(dialogView)
        val alertDialog: AlertDialog = builder.create()
        Objects.requireNonNull(alertDialog.window)!!.setBackgroundDrawableResource(android.R.color.transparent)
        alertDialog.setOnCancelListener { alertDialog.dismiss() }
        val btnClose: ImageView = dialogView.findViewById(R.id.btnClose)
        btnClose.setOnClickListener { alertDialog.dismiss() }

        val ratingBar1: ScaleRatingBar = dialogView.findViewById(R.id.ratingBar)
        ratingBar1.setOnRatingChangeListener { ratingBar, rating, fromUser ->
            if (rating > 3) {
                rate_app()
                Handler(Looper.getMainLooper()).postDelayed({ alertDialog.dismiss() }, 1000)
            } else {
                mySharedPref!!.setVisitPlay()
//                sendMail()
                Toast.makeText(this, "Thanks for review", Toast.LENGTH_SHORT).show()
                //Toast.makeText(TextResolutionActivity.this, getResources().getString(R.string.thanks_for_review), Toast.LENGTH_SHORT).show();
                Handler(Looper.getMainLooper()).postDelayed({ alertDialog.dismiss() }, 1000)
            }
        }
        dialogView.findViewById<View>(R.id.btnNextTime).setOnClickListener {
            mySharedPref!!.countExist = 0
            alertDialog.dismiss()
        }
        if (!isFinishing) {
            alertDialog.show()
        }
    }

    private fun rate_app() {
        mySharedPref!!.setVisitPlay()
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")))
        } catch (anfe: ActivityNotFoundException) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName")))
        }
    }

    private fun isNetworkConnected(): Boolean {
        val cm: ConnectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return cm.activeNetworkInfo != null && cm.activeNetworkInfo!!.isConnected
    }

//    @Throws(InvocationTargetException::class, NoSuchMethodException::class, ApiNotSupportedException::class, NoSuchFieldException::class, IllegalAccessException::class, NullWifiConfigurationException::class)
//    private fun checkStatus() {
//        if (!NetworkHelper.isOnline(this)) {
//            mCheckNet = false
//            return
//        } else {
//            if (NetworkHelper.isWifiConnected(this)) {
//                val proxy: WifiConfiguration = WifiConfiguration(this)
//                if (proxy.isProxySetted) {
//
//                    mCheckNet = false
//
//                    return
//                }
//            }
//            if (NetworkHelper.isVpnRunning()) {
//                mCheckNet = false
//                return
//            }
//        }
//
//        mCheckNet = true
//
//    }

    private fun initListner() {
        btnSave!!.setOnClickListener(this)
        imgFromG!!.setOnClickListener(this)
        btnShare!!.setOnClickListener(this)
        btnSetWallpaper!!.setOnClickListener(this)
        btnHome!!.setOnClickListener(this)
        btnBack!!.setOnClickListener(this)
    }

    private fun initViewAction() {

        mAllSticker = ArrayList()
        if (resolutionModel == null) {
            val mData: ArrayList<GradientResolutionModel> = DBHelperResolution(this@GradientResolutionActivity).resolutionModelGradientList
            if (mData.size > 0) {
                resolutionModel = mData.get(mData.size - 1)
            }
        }
        if (resolutionModel == null) {
            resolutionModel = Constants.resolutionModelGradient
        }
        if (resolutionModel != null) {
            mAllSticker!!.addAll((resolutionModel!!.getmAllSticker())!!)
            try {
                if (mAllSticker!!.size > 0) {
                    addTextSticker()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            if (resolutionModel!!.isCircle) {
                setCircleGradient(resolutionModel!!.isInner)
            } else {
                setGradientDrawable(resolutionModel!!.orientation)
            }
            if (resolutionModel!!.emojiImage != null) {

                Glide.with(this@GradientResolutionActivity).load(resolutionModel!!.emojiImage).into(object : CustomTarget<Drawable?>() {
                    public override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                        resource.colorFilter = PorterDuffColorFilter(resolutionModel!!.emojiColor, PorterDuff.Mode.SRC_IN)
                        imgEmoji!!.setImageDrawable(resource)
                        imgEmoji!!.alpha = resolutionModel!!.opacityEmoji
                        progress_circular!!.visibility = View.GONE
                        mainLayout!!.visibility = View.VISIBLE
                    }

                    public override fun onLoadCleared(placeholder: Drawable?) {
                        progress_circular!!.visibility = View.GONE
                        mainLayout!!.visibility = View.VISIBLE
                    }
                })
            } else {
                if (sticker_view!!.stickers.size == 0) {
                    progress_circular!!.visibility = View.GONE
                    mainLayout!!.visibility = View.VISIBLE
                }
            }
            if (mySharedPref!!.vibration) {
                vibrator = getSystemService(Service.VIBRATOR_SERVICE) as Vibrator?
            }
            progressBar = ProgressDialog(this@GradientResolutionActivity)
            progressBar!!.setMessage(getResources().getString(R.string.dialog_msg_please_wait))
            progressBar!!.setCancelable(false)
        }

        try {
            if (mGalleryBitmap != null) {
                if (!mGalleryBitmap!!.isRecycled) {
                    imgFromG!!.setImageBitmap(mGalleryBitmap)
                }
            }


        } catch (e: Exception) {
            Log.d("EWEWEW", e.message!!)

        }

    }

    private fun initViews() {
        btnSave = findViewById(R.id.btnSave)
        imgFromG = findViewById(R.id.imgFromG)
        btnSetWallpaper = findViewById(R.id.btnSetWallpaper)
        btnShare = findViewById(R.id.btnShare)
        btnHome = findViewById(R.id.btnHome)
        mainLayout = findViewById(R.id.mainLayout)
        btnBack = findViewById(R.id.btnBack)
        imgWallpaper = findViewById(R.id.imgWallpaper)
        sticker_view = findViewById(R.id.sticker_viewnew)
        mainFrame = findViewById(R.id.mainFrame)
        imgEmoji = findViewById(R.id.imgEmoji)
        progress_circular = findViewById(R.id.progress_circular)
        sticker_view!!.setLocked(true)
    }

    public override fun onClick(view: View) {
        when (view.getId()) {
            R.id.btnSave -> {
                    isSetWallpaper = false
                    isShared = false
                    if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(this@GradientResolutionActivity, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), READ_PERMISSION)
                    } else {
                        mPermissionGranted = true
                    }
                    if (mPermissionGranted) {
                        if (Constants.savedPath == null) {
                            showSaveDialog()
                        } else {
                            showSnackbar(getResources().getString(R.string.wallpaper_already_exist))
                            //    Toast.makeText(this, "Wallpaper Already Exist.", Toast.LENGTH_SHORT).show();
                        }
                    }
            }
            R.id.btnSetWallpaper -> {
                isSetWallpaper = true
                isShared = false
                if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.SET_WALLPAPER) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this@GradientResolutionActivity, arrayOf(Manifest.permission.SET_WALLPAPER), WALLPAPER_PERMISSION)
                } else {
                    mPermissionGrantedWallpaper = true
                }
                if (mPermissionGrantedWallpaper) {
                    if (Constants.isText && mySharedPref!!.scale.equals("Fit", ignoreCase = true)) {
                        try {
                            if (mBitmap == null) {
                                mBitmap = outputBitmap
                            }
                            Constants.mWallpaperBitmap = mBitmap
                            val intent: Intent = Intent(
                                    WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                            intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                                    ComponentName(this, CustomNewWallpaper::class.java))
                            startActivity(intent)
                        } catch (e: Exception) {
                            e.printStackTrace()
                            showSnackbar(getResources().getString(R.string.live_wallpaper_not_supported))
                        }
                    } else {
                        showCustomDialog()
                    }
                    //onclickSave();
                }
            }
            R.id.btnShare -> {
                isShared = true
                isSetWallpaper = false
                shareWallpaper()
            }
            R.id.btnBack -> onBackPressed()
            R.id.btnHome -> {
                    mySharedPref!!.setImagePath("")
                    startActivity(Intent(this@GradientResolutionActivity, HomeActivity::class.java))
                    finish()
            }
        }
    }

    private fun setWall() {
        val uri: Uri = FileProvider.getUriForFile(this@GradientResolutionActivity, BuildConfig.APPLICATION_ID.toString() + ".provider", File(Constants.savedPath))
        val intent: Intent = Intent("android.intent.action.ATTACH_DATA")
        intent.addCategory("android.intent.category.DEFAULT")
        intent.setDataAndType(uri, "image/jpeg")
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        intent.putExtra("mimeType", "image/jpeg")
        startActivity(Intent.createChooser(intent, "Set as:"))
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
//        if (requestCode == 100 && !getBoolean(this, AdsPrefs.IS_SUBSCRIBED, false)) {
//            Log.d("TAG=====>>>>", "onActivityResult: " + requestCode)
//            if (instance!!.requestNewInterstitial()) {
//                instance!!.mInterstitialAd!!.adListener = object : AdListener() {
//                    public override fun onAdClosed() {
//                        super.onAdClosed()
//                        loadInterstialAd()
//                    }
//
//                    public override fun onAdFailedToLoad(i: Int) {
//                        super.onAdFailedToLoad(i)
//                        loadInterstialAd()
//                    }
//
//                    public override fun onAdLoaded() {
//                        super.onAdLoaded()
//                    }
//                }
//            }
//        }
    }

    private fun showCustomDialog() {
        btnSetWallpaper!!.isEnabled = false
        val builder1: BottomSheetDialog = BottomSheetDialog(this@GradientResolutionActivity, R.style.BottomSheetDialog)
        val v: View = layoutInflater.inflate(R.layout.dialog_setwallpaper, null)
        builder1.setContentView(v)
        builder1.show()
        builder1.setOnDismissListener { btnSetWallpaper!!.isEnabled = true }
        val wallpaper: LinearLayout = v.findViewById(R.id.btnHomeScreen)
        val bothwallpaper: LinearLayout = v.findViewById(R.id.btnBoth)
        val lockscreen: LinearLayout = v.findViewById(R.id.btnLockScreen)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            bothwallpaper.visibility = View.GONE
            lockscreen.visibility = View.GONE
        }
        lockscreen.setOnClickListener {
            builder1.dismiss()
            mySharedPref!!.countExist = mySharedPref!!.countExist + 1
            progressBar!!.show()
            Handler().postDelayed({ //   progressBar.dismiss();
                btnSetWallpaper!!.isEnabled = true
                if (mySharedPref!!.countExist >= 3 && mySharedPref!!.visitPlay == null) {
                  //  showRateDialog()
                }
            }, 3000)
            if (mySharedPref!!.alarmId != -1) {
                DBHelperAutoWallpaper(this@GradientResolutionActivity).updateData()
                cancelAlarm(("2121" + mySharedPref!!.alarmId).toInt(), this@GradientResolutionActivity, EventReceiver::class.java)
            }
            Handler().postDelayed({ lockScreenWallpaper() }, 400)
        }
        wallpaper.setOnClickListener {
            builder1.dismiss()
            //   Toast.makeText(GradientResolutionActivity.this, "Please Wait...", Toast.LENGTH_SHORT).show();
            mySharedPref!!.countCreated = mySharedPref!!.countCreated + 1
            progressBar!!.show()
            Handler().postDelayed({ //  progressBar.dismiss();
                btnSetWallpaper!!.isEnabled = true
                if (mySharedPref!!.countCreated >= 3 && mySharedPref!!.visitPlay == null) {
                   // showRateDialog()
                }
            }, 3000)
            if (mySharedPref!!.alarmId != -1) {
                DBHelperAutoWallpaper(this@GradientResolutionActivity).updateData()
                cancelAlarm(("2121" + mySharedPref!!.alarmId).toInt(), this@GradientResolutionActivity, EventReceiver::class.java)
            }
            Handler().postDelayed({ onclickWallpaper(false) }, 400)
        }
        bothwallpaper.setOnClickListener {
            builder1.dismiss()
            //  Toast.makeText(GradientResolutionActivity.this, "Please Wait...", Toast.LENGTH_LONG).show();
            mySharedPref!!.countCreated = mySharedPref!!.countCreated + 1
            progressBar!!.show()
            Handler().postDelayed({ //  progressBar.dismiss();
                btnSetWallpaper!!.isEnabled = true
                if (mySharedPref!!.countCreated >= 3 && mySharedPref!!.visitPlay == null) {
                   // showRateDialog()
                }
            }, 3000)
            if (mySharedPref!!.alarmId != -1) {
                DBHelperAutoWallpaper(this@GradientResolutionActivity).updateData()
                cancelAlarm(("2121" + mySharedPref!!.alarmId).toInt(), this@GradientResolutionActivity, EventReceiver::class.java)
            }
            Handler().postDelayed({
                onclickWallpaper(true)
                lockScreenWallpaper()
            }, 400)
        }
    }

    private fun lockScreenWallpaper() {
        mBitmap = outputBitmap
        if (mBitmap != null) {
            val wm: WallpaperManager = WallpaperManager.getInstance(this)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    wm.setBitmap(mBitmap, null, true, WallpaperManager.FLAG_LOCK) //For Lock screen
                    progressBar!!.dismiss()
                    if (vibrator != null) {
                        if (Build.VERSION.SDK_INT >= 26) {
                            vibrator!!.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
                        } else {
                            vibrator!!.vibrate(200)
                        }
                    }
                    //Toast.makeText(WallpaperViewActivity.this, "Wallpaper Set Successfully.", Toast.LENGTH_SHORT).show();
                    showSnackbar(resources.getString(R.string.toast_wallpaper_set_seccessfully))
                } else {
                    Toast.makeText(this, "Lock Screen Wallpaper Not Supported",
                            Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun showSaveDialog() {
         bottomSheetFragment= BottomSheetFragment(getResources().getString(R.string.save), getResources().getString(R.string.do_you_want_to_save), getResources().getString(R.string.save), getResources().getString(R.string.cancel), R.drawable.ic_save_dialog, object : BottomSheetFragment.OnButtonClickListener {
            public override fun onPositive(bottomSheetDialo: BottomSheetFragment?) {
                bottomSheetDialo!!.dismiss()
                onclickSave()
            }

            public override fun onNegative(bottomSheetDialog: BottomSheetFragment?) {
                bottomSheetDialog!!.dismiss()
            }
        })
        bottomSheetFragment!!.show(supportFragmentManager, "dialog")
    }

    override fun onPause() {
        super.onPause()

        try {
            bottomSheetFragment!!.dismiss()
        }catch (e:Exception){

        }
    }

    private fun shareWallpaper() {
        if (Constants.savedPath == null) {
            if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this@GradientResolutionActivity, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), SHARE_PERMISSION)
            } else {
                mPermissionGranted = true
            }
            if (mPermissionGranted) {
                onclickSave()
            }
        } else {
            val uri: Uri? = FileProvider.getUriForFile(this@GradientResolutionActivity, BuildConfig.APPLICATION_ID.toString() + ".provider", File(Constants.savedPath))
            if (uri != null) {
                val intent: Intent = Intent(Intent.ACTION_SEND)
                intent.type = "image/jpeg"
                intent.putExtra(Intent.EXTRA_STREAM, uri)
                var shareMessage: String = ""
                shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=com.solid.color.wallpaper.hd.image.background"
                intent.putExtra(Intent.EXTRA_TEXT, shareMessage)
                startActivityForResult(Intent.createChooser(intent, getResources().getString(R.string.share_wallpaper)), 100)
            }
        }
    }

    private fun onclickWallpaper(isBoth: Boolean) {
        mBitmap = outputBitmap
        if (mBitmap != null) {
            val wallpaperManager: WallpaperManager = WallpaperManager.getInstance(applicationContext)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    wallpaperManager.setBitmap(mBitmap, null, true, WallpaperManager.FLAG_SYSTEM)
                } else {
                    wallpaperManager.setBitmap(mBitmap)
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
            if (!isBoth) {
                progressBar!!.dismiss()
                if (vibrator != null) {
                    if (Build.VERSION.SDK_INT >= 26) {
                        vibrator!!.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
                    } else {
                        vibrator!!.vibrate(200)
                    }
                }
                //Toast.makeText(WallpaperViewActivity.this, "Wallpaper Set Successfully.", Toast.LENGTH_SHORT).show();
                showSnackbar(getResources().getString(R.string.toast_wallpaper_set_seccessfully))
            }
        } else {
            showSnackbar(getResources().getString(R.string.try_again_later))
            //Toast.makeText(this, "Try Again Later!", Toast.LENGTH_SHORT).show();
        }
    }

    private fun showSnackbar(msg: String) {
        val snackbar: Snackbar = Snackbar.make(findViewById(R.id.mainContainer), msg, Snackbar.LENGTH_SHORT)
        val v: View = snackbar.view
        val params: CoordinatorLayout.LayoutParams = v.layoutParams as CoordinatorLayout.LayoutParams
        params.gravity = Gravity.BOTTOM
        params.width = FrameLayout.LayoutParams.MATCH_PARENT
        v.layoutParams = params
        v.setBackgroundColor(Color.WHITE)
        val textView: TextView = v.findViewById(com.google.android.material.R.id.snackbar_text)
        textView.setTextColor(resources.getColor(R.color.text_colour_new))
        snackbar.show()
    }

    fun getRealPathFromUri(context: Context, contentUri: Uri?): String? {
        var cursor: Cursor? = null
        return try {
            val proj = arrayOf<String>(MediaStore.Images.Media.DATA)
            cursor = context.contentResolver.query(contentUri!!, proj, null, null, null)
            val column_index: Int = cursor!!.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
            cursor.moveToFirst()
            cursor.getString(column_index)
        } finally {
            cursor?.close()
        }
    }

    private fun onclickSave() {
        mBitmap = outputBitmap
        if (mBitmap != null) {

            val myDir: File = File(Environment.getExternalStorageDirectory().absolutePath + "/Pictures" + "/Solid Wallpaper")
            if (!myDir.exists()) {
                myDir.mkdirs()
            }
            val fname: String = if (Constants.isTextWallpaper) {
                "Text_" + (System.currentTimeMillis() / 1000).toString() + ".png"
            } else {
                "Gradient_" + (System.currentTimeMillis() / 1000).toString() + ".png"
            }
            val file: File = File(myDir, fname)
            var out: FileOutputStream? = null
            try {
                out = FileOutputStream(file)
                mBitmap!!.compress(Bitmap.CompressFormat.PNG, 100, out)
                out.flush()
                out.close()
                Constants.savedPath = Constants.path + "/" + fname
                Constants.isDataChanges = true
                if (!isShared && !isSetWallpaper) {
                    showSnackbar(getResources().getString(R.string.wallpaper_saved))
                    // Toast.makeText(this, "Wallpaper Saved.", Toast.LENGTH_SHORT).show();
                } else if (isSetWallpaper) {
                    // setWall();
                    showCustomDialog()
                } else {
                    shareWallpaper()
                }
            } catch (e: IOException) {
                Log.d(TAG, "onclickSave: ${e.message}")
                e.printStackTrace()
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                val scanIntent: Intent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
                val contentUri: Uri = Uri.fromFile(file)
                scanIntent.setData(contentUri)
                sendBroadcast(scanIntent)
            } else {
                val intent: Intent = Intent(Intent.ACTION_MEDIA_MOUNTED, Uri.parse("file://" + Environment.getExternalStorageDirectory()))
                sendBroadcast(intent)
            }
        }
    }

    /*   if (Constants.isColorSelected) {
            mainLayout.draw(canvas);
        } else {*/
    //  }
    // sticker_view.draw(canvas);
    private val outputBitmap: Bitmap?
        private get() {
            System.gc()
            Runtime.getRuntime().gc()
            val displayMetrics: DisplayMetrics = DisplayMetrics()
            windowManager.defaultDisplay.getMetrics(displayMetrics)
            val height: Int = displayMetrics.heightPixels
            val width: Int = displayMetrics.widthPixels
            try {
                val bitmap: Bitmap = Bitmap.createBitmap(mainFrame!!.width, mainFrame!!.height, Bitmap.Config.ARGB_8888)
                val canvas: Canvas = Canvas(bitmap)
                mainFrame!!.draw(canvas)
                return bitmap

            } catch (e: Exception) {
                return null
            }
            /*   if (Constants.isColorSelected) {
                mainLayout.draw(canvas);
            } else {*/
            //  }
            // sticker_view.draw(canvas);
        }

    private fun loadInterstialAd() {
        if (instance!!.mInterstitialAd != null) {
            Log.e(TAG, "loadInterstialAd: ajhjkbdhsfabsdcfads" )
        } else {
            if (instance!!.mInterstitialAd != null) {

                instance!!.mInterstitialAd!!.fullScreenContentCallback = null
                instance!!.mInterstitialAd = null
                instance!!.ins_adRequest = null
                instance!!.LoadAds()

                instance!!.mInterstitialAd!!.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
                    Log.d(TAG, "onAdFailedToShowFullScreenContent: Ad was dismissed.")
                    }

                    override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
                        super.onAdFailedToShowFullScreenContent(p0)
                        Log.e(TAG, "onAdFailedToShowFullScreenContent: hjbsadhbksbndcsdfcs" )
                        loadInterstialAdFb()
                    }

                    override fun onAdShowedFullScreenContent() {
                    Log.d(TAG, "onAdFailedToShowFullScreenContent: Ad showed fullsscreen content.")
                        instance!!.mInterstitialAd = null;
                    }
                }
                instance!!.mInterstitialAd!!.show(this)

//            instance!!.mInterstitialAd!!.adListener = object : AdListener() {
//                public override fun onAdLoaded() {
//                    super.onAdLoaded()
//                }
//
//                public override fun onAdFailedToLoad(i: Int) {
//                    super.onAdFailedToLoad(i)
//                    loadInterstialAd()
//                    //  loadInterstialAdFb();
//                }
//            }
            }
        }
    }

    private fun loadInterstialAdFb() {
        if (instance!!.mInterstitialAdfb!!.isAdLoaded) {
        } else {
            instance!!.mInterstitialAdfb!!.buildLoadAdConfig().withAdListener(null)
            instance!!.mInterstitialAdfb = null
            instance!!.LoadAdsFb()
            instance!!.mInterstitialAdfb!!.buildLoadAdConfig().withAdListener(object : InterstitialAdListener {
                public override fun onError(ad: Ad, adError: AdError) {
                    // loadInterstialAdFb();
                    Log.e(TAG, "onAdLoaded: bndsjkbnjksdnjcndsciojiodsjiopjsd;lkdfsl/kmdsv.mvs" )

                    loadInterstialAd()
                }

                public override fun onAdLoaded(ad: Ad) {
                    Log.e(TAG, "onAdLoaded: bndsjkbnjksdnjcndscs" )
                }
                public override fun onAdClicked(ad: Ad) {
                    Log.e(TAG, "onAdLoaded: bndsjkbnjsdfcasd ksdnjcndscs" )

                }
                public override fun onLoggingImpression(ad: Ad) {
                    Log.e(TAG, "onAdLoaded: bndsjkbnjksdnjcndscdsadfsa s" )

                }
                public override fun onInterstitialDisplayed(ad: Ad) {
                    Log.e(TAG, "onAdLoaded: bndsjkbnjksdnjcndsc656456456456s" )

                }
                public override fun onInterstitialDismissed(ad: Ad) {
                    Log.e(TAG, "onAdLoaded: bndsjkbnjksdnjcndscs564564sd48564sd" )

                    loadInterstialAdFb()
                }
            })
        }
    }

    public override fun onRequestPermissionsResult(requestCode: Int,
                                                   permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            READ_PERMISSION -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (Constants.savedPath == null) {
                        showSaveDialog()
                    } else {
                        showSnackbar(getResources().getString(R.string.wallpaper_already_exist))
                        // Toast.makeText(this, "Wallpaper Already Exist.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    val showRationale: Boolean = ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    if (!showRationale) {
                        pemissionDialog()
                    }
                    Toast.makeText(this, getResources().getString(R.string.permission_required), Toast.LENGTH_SHORT).show()
                }
                return
            }
            WALLPAPER_PERMISSION -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    showCustomDialog()
                } else {
                    val showRationale: Boolean = ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SET_WALLPAPER)
                    if (!showRationale) {
                        pemissionDialog()
                    }
                    Toast.makeText(this, getResources().getString(R.string.permission_required), Toast.LENGTH_SHORT).show()
                }
                return
            }
            SHARE_PERMISSION -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    shareWallpaper()
                } else {
                    val showRationale: Boolean = ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SET_WALLPAPER)
                    if (!showRationale) {
                        pemissionDialog()
                    }
                    Toast.makeText(this, getResources().getString(R.string.permission_required), Toast.LENGTH_SHORT).show()
                }
                return
            }
        }
    }

    fun pemissionDialog() {
        val alertDialog: android.app.AlertDialog
        val viewGroup: ViewGroup = findViewById(android.R.id.content)
        val dialogView: View = LayoutInflater.from(this).inflate(R.layout.permission_dialog, viewGroup, false)
        val builder1: android.app.AlertDialog.Builder = android.app.AlertDialog.Builder(this)
        builder1.setView(dialogView)
        alertDialog = builder1.create()
        val cancel: Button = dialogView.findViewById(R.id.btnCancel)
        cancel.setOnClickListener { alertDialog.dismiss() }
        val ok: Button = dialogView.findViewById(R.id.btnOk)
        ok.setOnClickListener {
            startInstalledAppDetailsActivity(this@GradientResolutionActivity)
            alertDialog.dismiss()
        }
        alertDialog.show()
    }

    fun startInstalledAppDetailsActivity(context: Activity?) {
        if (context == null) {
            return
        }
        val i: Intent = Intent()
        i.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        i.addCategory(Intent.CATEGORY_DEFAULT)
        i.data = Uri.parse("package:" + context.packageName)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        i.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
        i.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
        context.startActivity(i)
    }

    override fun onRestart() {
        super.onRestart()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted
            startActivity(Intent(this@GradientResolutionActivity, MainStartActivity::class.java))
            finish()
        }
    }

    public override fun onBackPressed() {
            finish()
    }

    override fun onResume() {
        super.onResume()
        SolidWallpaperApplication.staticLanguage.Factory.create(this)
    }

    fun addTextSticker() {
        for (i in mAllSticker!!.indices) {
            val model: StickerModel = mAllSticker!![i]
            val sticker1: DrawableSticker = DrawableSticker(model.drawable)
            sticker1.color = model.drawableColor
            sticker1.alpha = model.drawableAlpha
            sticker_view!!.addSticker(sticker1)
        }
        sticker_view!!.post {
            imgWallpaper!!.post {
                for (i in sticker_view!!.stickers.indices) {
                    val sticker: Sticker = sticker_view!!.stickers.get(i)
                    sticker.setMatrix(mAllSticker!![i].matrix)
                }
                sticker_view!!.invalidate()
                for (i in sticker_view!!.stickers.indices) {
                    val sticker: Sticker = sticker_view!!.stickers[i]
                    val sclH: Float = imgWallpaper!!.height.toFloat() / resolutionModel!!.mainHeight.toFloat()
                    val sclW: Float = imgWallpaper!!.width.toFloat() / resolutionModel!!.mainWidth.toFloat()
                    val matrix: MatrixClonable = MatrixClonable()
                    matrix.set(sticker.matrix)
                    matrix.postScale(sclW, sclH)
                    sticker.setMatrix(matrix)
                    if (i == sticker_view!!.stickers.size - 1) {
                        progress_circular!!.visibility = View.GONE
                        mainLayout!!.visibility = View.VISIBLE
                    }
                }
                sticker_view!!.invalidate()
                mainFrame!!.post { mBitmap = outputBitmap }
            }
        }
    }

    private fun setGradientDrawable(orientation: GradientDrawable.Orientation?) {
        val new_colors: IntArray = intArrayOf(resolutionModel!!.color1, resolutionModel!!.color2)
        val shape: GradientDrawable = GradientDrawable(orientation, new_colors)
        shape.shape = GradientDrawable.RECTANGLE
        imgWallpaper!!.background = shape
    }

    private fun setCircleGradient(isInner: Boolean) {
        val metrics: DisplayMetrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(metrics)
        if (!isInner) {
            val new_colors: IntArray = intArrayOf(resolutionModel!!.color2, resolutionModel!!.color1)
            val shape: GradientDrawable = GradientDrawable()
            shape.shape = GradientDrawable.RECTANGLE
            shape.colors = new_colors
            shape.gradientType = GradientDrawable.RADIAL_GRADIENT
            shape.gradientRadius = metrics.widthPixels.toFloat()
            imgWallpaper!!.background = shape
        } else {
            val new_colors: IntArray = intArrayOf(resolutionModel!!.color1, resolutionModel!!.color2)
            val shape: GradientDrawable = GradientDrawable()
            shape.shape = GradientDrawable.RECTANGLE
            shape.colors = new_colors
            shape.gradientType = GradientDrawable.RADIAL_GRADIENT
            shape.gradientRadius = metrics.widthPixels.toFloat()
            imgWallpaper!!.background = shape
        }
    }

    companion object {
        private val TAG: String = "GradientR534esolution"
        private val READ_PERMISSION: Int = 101
        private val WALLPAPER_PERMISSION: Int = 235
        private val SHARE_PERMISSION: Int = 452
    }
}