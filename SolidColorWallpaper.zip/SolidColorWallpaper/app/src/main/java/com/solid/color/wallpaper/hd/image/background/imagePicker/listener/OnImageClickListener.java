package com.solid.color.wallpaper.hd.image.background.imagePicker.listener;

import android.view.View;


public interface OnImageClickListener {
    boolean onImageClick(View view, int position, boolean isSelected);
}
