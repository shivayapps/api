package com.solid.color.wallpaper.hd.image.background.model

import android.graphics.drawable.Drawable
import com.solid.color.wallpaper.hd.image.background.custom.MatrixClonable

class StickerModel {
    var matrix: MatrixClonable? = null
    var isText = false
    internal var text: String? = null
    var typeface: String? = null
    var textColor = 0
    var textAlhpa = 0
    var drawable: Drawable? = null
    var drawableColor = 0
    var drawableAlpha = 0

    constructor() {}
    constructor(matrix: MatrixClonable?, isText: Boolean, text: String?, typeface: String?, textColor: Int, textAlhpa: Int, drawable: Drawable?, drawableColor: Int, drawableAlpha: Int) {
        this.matrix = matrix
        this.isText = isText
        this.text = text
        this.typeface = typeface
        this.textColor = textColor
        this.textAlhpa = textAlhpa
        this.drawable = drawable
        this.drawableColor = drawableColor
        this.drawableAlpha = drawableAlpha
    }

    fun getText(): String? {
        return text
    }

    fun setText(text: String?) {
        this.text = text
    }

}