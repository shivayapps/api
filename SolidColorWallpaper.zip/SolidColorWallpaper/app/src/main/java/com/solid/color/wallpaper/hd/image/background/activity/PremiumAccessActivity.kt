package com.solid.color.wallpaper.hd.image.background.activity

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.View
import android.view.WindowManager
import androidx.cardview.widget.CardView
import androidx.viewpager.widget.ViewPager.OnPageChangeListener
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.SolidWallpaperApplication
import com.solid.color.wallpaper.hd.image.background.adapter.SliderAdepter
import com.solid.color.wallpaper.hd.image.background.constants.Constants
import com.solid.color.wallpaper.hd.image.background.model.SLiderPremiumModel
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs
import com.vasundhara.vision.subscription.manager.PreferencesKeys
import com.vasundhara.vision.subscription.ui.BaseSubscriptionActivity
import kotlinx.android.synthetic.main.activity_premium_access.*
import kotlinx.android.synthetic.main.activity_subscription_new.*
import kotlinx.android.synthetic.main.activity_subscription_new.adSlider
import kotlinx.android.synthetic.main.activity_subscription_new.cst_1_month
import kotlinx.android.synthetic.main.activity_subscription_new.cst_1_year
import kotlinx.android.synthetic.main.activity_subscription_new.imgBackPremium
import kotlinx.android.synthetic.main.activity_subscription_new.iv_first
import kotlinx.android.synthetic.main.activity_subscription_new.iv_four
import kotlinx.android.synthetic.main.activity_subscription_new.iv_last
import kotlinx.android.synthetic.main.activity_subscription_new.iv_second
import kotlinx.android.synthetic.main.activity_subscription_new.iv_third
import kotlinx.android.synthetic.main.activity_subscription_new.mSixBestValue
import kotlinx.android.synthetic.main.activity_subscription_new.mYearBestValue
import kotlinx.android.synthetic.main.activity_subscription_new.textVie51
import kotlinx.android.synthetic.main.activity_subscription_new.txtMonthPrize
import kotlinx.android.synthetic.main.activity_subscription_new.txtPrivacyPolicy
import kotlinx.android.synthetic.main.activity_subscription_new.txtSave50
import kotlinx.android.synthetic.main.activity_subscription_new.txtTearmsCondition
import kotlinx.android.synthetic.main.activity_subscription_new.txtYearPrize
import java.util.*
import kotlin.collections.ArrayList

class PremiumAccessActivity : BaseSubscriptionActivity(), View.OnClickListener {

    private lateinit var adapter: SliderAdepter
    private lateinit var runnable: Runnable
    private lateinit var handler: Handler
    private lateinit var btnSubscribe: CardView
    private var currentPage = 0
    private var selectedSub = 0


    private var productKeyMonth = ""
    private var productKey3Month = ""
    private var productKeyYear: String? = ""
    private var licenseKey = ""
    private var mContext: Context? = null

    var mGetString: HashMap<String, String> = HashMap()

    var mSelectedKey = com.vasundhara.vision.subscription.constants.Constants.PREMIUM_SKU

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_subscription_new)

        mContext = this
        transparentStatusAndNavigation()

        btnSubscribe = findViewById(R.id.btnSubscribe)

        initViewAction()
//        setPlanPrice()
        initListner()

        liveDataPrice.observe(this, {

            Log.d(TAG, "onCreate: ${it[com.vasundhara.vision.subscription.constants.Constants.PREMIUM_SKU]}")
            Log.d(TAG, "onCreate: ${it[com.vasundhara.vision.subscription.constants.Constants.PREMIUM_SIX_SKU]}")
            Log.d(TAG, "onCreate: ${it[com.vasundhara.vision.subscription.constants.Constants.BASIC_SKU]}")

            txtYearPrize.text = it[com.vasundhara.vision.subscription.constants.Constants.PREMIUM_SKU]
            txtWeekPrize.text = it[com.vasundhara.vision.subscription.constants.Constants.PREMIUM_SIX_SKU]
            txtMonthPrize.text = it[com.vasundhara.vision.subscription.constants.Constants.BASIC_SKU]

//            try {
//                txtSave50.text = "Save" + " " + ((((subscriptionManager.getLong(
//                        PreferencesKeys.YEAR_PRICE_MICRO,
//                        2100000000
//                ) / 1000000) / 12) * 100).toInt() / (subscriptionManager.getLong(
//                        PreferencesKeys.MONTH_PRICE_MICRO,
//                        350000000
//                ) / 1000000).toInt()) + "%"
//            } catch (e: Exception) {
//                Log.e(TAG, "onCreate: ${e.message}")
//            }
//
//            try {
//
//                save1Months.text = "Save" + " " + ((((subscriptionManager.getLong(
//                        PreferencesKeys.YSIX_PRICE_MICRO,
//                        1400000000
//                ) / 1000000) / 6) * 100).toInt() / (subscriptionManager.getLong(
//                        PreferencesKeys.MONTH_PRICE_MICRO,
//                        350000000
//                ) / 1000000).toInt()) + "%"
//            } catch (e: Exception) {
//                Log.e(TAG, "onCreate: ${e.message}")
//            }
//
//            cst_1_year.performClick()

        })


        liveDataPriceMicro.observe(this, androidx.lifecycle.Observer {
            val x = ((it[com.vasundhara.vision.subscription.constants.Constants.PREMIUM_SIX_SKU]!! / 1000000)).toInt()
            val y = ((it[com.vasundhara.vision.subscription.constants.Constants.PREMIUM_SKU]!! / 1000000)).toInt()
            var z = ((it[com.vasundhara.vision.subscription.constants.Constants.BASIC_SKU]!! / 1000000)).toInt()

            val save1m = (4 * x) - z
            val save1y = (48 * x) - y
            val per1Month = (save1m * 100) / (4 * x)
            val per1Year = (save1y * 100) / (48 * x)


            save1Months.text = "Save\n$per1Month %"
            txtSave50.text = "Save\n$per1Year %"

//            per1WeekPrice.text =
//                "${currencyCode.value} ${((it[com.vasundhara.vision.subscription.constants.Constants.PREMIUM_SIX_SKU]!! / 1000000)).toInt() * 1}"
//            per1MonthPrice.text =
//                "${currencyCode.value} ${((it[com.vasundhara.vision.subscription.constants.Constants.BASIC_SKU]!! / 1000000)).toInt()}"
//            per12MonthPrice.text =
//                "${currencyCode.value} ${((it[com.vasundhara.vision.subscription.constants.Constants.PREMIUM_SKU]!! / 1000000) / 12).toInt()}"


        })
    }

    override fun onPurchases(orderId: String, str: String) {

        if (str == com.vasundhara.vision.subscription.constants.Constants.FIVE_HUNDRED || str == com.vasundhara.vision.subscription.constants.Constants.TWO_THOUSAND || str == com.vasundhara.vision.subscription.constants.Constants.TEN_THOUSAND) {
            AdsPrefs.save(mContext, AdsPrefs.IS_SUBSCRIBED, false)
            Constants.isSubscribedW = false
            Constants.isSubscribedH = false
            Constants.isSubscribedS = false
            Constants.isSubscribedG = false
            Constants.isSubscribedT = false
        } else {
            AdsPrefs.save(mContext, AdsPrefs.IS_SUBSCRIBED, true)
            Constants.isSubscribedW = true
            Constants.isSubscribedH = true
            Constants.isSubscribedS = true
            Constants.isSubscribedG = true
            Constants.isSubscribedT = true
            finish()
        }

}

private fun transparentStatusAndNavigation() {
    //make full transparent statusBar
    if (Build.VERSION.SDK_INT in 19..20) {
        setWindowFlag(
                WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, true
        )
    }
    if (Build.VERSION.SDK_INT >= 19) {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
    }
    if (Build.VERSION.SDK_INT >= 21) {
        setWindowFlag(
                (WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS), false
        )
        window.statusBarColor = Color.TRANSPARENT
    }

    statusBarView.layoutParams.height = getStatusBarHeight()
    statusBarView.requestLayout()
}

private fun setWindowFlag(bits: Int, on: Boolean) {
    val win = window
    val winParams = win.attributes
    if (on) {
        winParams.flags = winParams.flags or bits
    } else {
        winParams.flags = winParams.flags and bits.inv()
    }
    win.attributes = winParams
}

fun getStatusBarHeight(): Int {
    var result = 0
    val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
    if (resourceId > 0) {
        result = resources.getDimensionPixelSize(resourceId)
    }
    return result
}

private fun initListner() {
    cst_1_week.setOnClickListener(this)
    cst_1_year.setOnClickListener(this)
    cst_1_month.setOnClickListener(this)
    imgBackPremium.setOnClickListener(this)
    btnSubscribe.setOnClickListener {

        if (mSelectedKey == com.vasundhara.vision.subscription.constants.Constants.PREMIUM_SKU) {
            onYearPlan()
            Log.i("TAG", "initListener: $mSelectedKey")


        } else if (mSelectedKey == com.vasundhara.vision.subscription.constants.Constants.PREMIUM_SIX_SKU) {
            onSixPlan()
            Log.i("TAG", "initListener: $mSelectedKey")

        } else {
            onMonthPlan()
            Log.i("TAG", "initListener: $mSelectedKey")
        }


//            val productKey: String = when (selectedSub) {
//                1 -> {
//                    resources.getString(R.string.ads_product_key_month)
//                }
//                0 -> {
//                    resources.getString(R.string.ads_product_key_year)
//                }
//                else -> {
//                    resources.getString(R.string.ads_product_key_month_3)
//                }
//            }
//            setPlan(productKey)
    }
    txtPrivacyPolicy.setOnClickListener(this)
    txtTearmsCondition.setOnClickListener(this)
}

//    private fun initBillingProcessor() {
//
//        /*
//         *  You need 4 product key for this and you have to create this 4 key and give in office
//         * with
//         *  your email address, and they will join you in beta tester after uploading app in play
//         *  store
//         *   1 -> for week testing,  test Key
//         *   2 -> week live key
//         *   3 - > month live key
//         *   4 - > year live key
//         *
//         *   when you submit your first beta app you need to set productKeyWeek as test ID and other
//         *   2 are live and also live licence key
//         *
//         * */
//        //    productKeyMonthDiscount = getString(R.string.ads_product_key_monthlydiscount);
//        productKeyMonth = getString(R.string.ads_product_key_month)
//        productKey3Month = getString(R.string.ads_product_key_month_3)
//        productKeyYear = getString(R.string.ads_product_key_year)
//
//        /*
//         * Live licence Key
//         * */licenseKey = getString(R.string.licenseKey)
//        billingProcessor = BillingProcessor(mContext, licenseKey, this)
//        billingProcessor?.initialize()
//    }

private fun initViewAction() {

    adSlider.addOnPageChangeListener(object : OnPageChangeListener {
        override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {}
        override fun onPageSelected(position: Int) {
            currentPage = position
            when (position) {
                0 -> {
                    iv_first.setImageResource(R.drawable.ic_dot_dark)
                    iv_second.setImageResource(R.drawable.ic_dot_gray)
                    iv_third.setImageResource(R.drawable.ic_dot_gray)
                    iv_four.setImageResource(R.drawable.ic_dot_gray)
                    iv_last.setImageResource(R.drawable.ic_dot_gray)
                }
                1 -> {
                    iv_first.setImageResource(R.drawable.ic_dot_gray)
                    iv_second.setImageResource(R.drawable.ic_dot_dark)
                    iv_third.setImageResource(R.drawable.ic_dot_gray)
                    iv_four.setImageResource(R.drawable.ic_dot_gray)
                    iv_last.setImageResource(R.drawable.ic_dot_gray)
                }
                2 -> {
                    iv_first.setImageResource(R.drawable.ic_dot_gray)
                    iv_second.setImageResource(R.drawable.ic_dot_gray)
                    iv_last.setImageResource(R.drawable.ic_dot_gray)
                    iv_third.setImageResource(R.drawable.ic_dot_gray)
                    iv_four.setImageResource(R.drawable.ic_dot_dark)

                }
                3 -> {
                    iv_first.setImageResource(R.drawable.ic_dot_gray)
                    iv_second.setImageResource(R.drawable.ic_dot_gray)
                    iv_four.setImageResource(R.drawable.ic_dot_gray)
                    iv_last.setImageResource(R.drawable.ic_dot_gray)
                    iv_third.setImageResource(R.drawable.ic_dot_dark)

                }
                4 -> {
                    iv_first.setImageResource(R.drawable.ic_dot_gray)
                    iv_second.setImageResource(R.drawable.ic_dot_gray)
                    iv_third.setImageResource(R.drawable.ic_dot_gray)
                    iv_four.setImageResource(R.drawable.ic_dot_gray)
                    iv_last.setImageResource(R.drawable.ic_dot_dark)
                }
            }
        }

        override fun onPageScrollStateChanged(state: Int) {}
    })

    val list = ArrayList<SLiderPremiumModel>()
    list.add(SLiderPremiumModel(R.drawable.ic_premium_2, resources.getString(R.string.premium_title_2), resources.getString(R.string.premium_msg_2)))
    list.add(SLiderPremiumModel(R.drawable.ic_premium_3, resources.getString(R.string.premium_title_3), resources.getString(R.string.premium_msg_3)))
    list.add(SLiderPremiumModel(R.drawable.ic_premium_4, resources.getString(R.string.remove_ads), resources.getString(R.string.premium_msg_4)))
    list.add(SLiderPremiumModel(R.drawable.ic_premium_1, resources.getString(R.string.wallpapre_300_plus), resources.getString(R.string.wallpapre_300_plus_msg)))
    list.add(SLiderPremiumModel(R.drawable.ic_premium_5, resources.getString(R.string.premium_title_5), resources.getString(R.string.premium_msg_5)))

    adapter = SliderAdepter(supportFragmentManager, list)
    adSlider.adapter = adapter
    startAutoSlider()
}

private fun startAutoSlider() {
    handler = Handler()
    runnable = Runnable {
        currentPage++
        if (currentPage >= adapter.count) {
            currentPage = 0
        }
        adSlider.currentItem = currentPage
        handler.postDelayed(runnable, 3000)
    }
    handler.postDelayed(runnable, 3000)
}

override fun onClick(v: View?) {
    when (v!!.id) {
        R.id.cst_1_month -> {
            selectedSub = 1
            cst_1_month.setBackgroundResource(R.drawable.premium_round_pink_ring)
            cst_1_year.setBackgroundResource(R.drawable.premium_round_gray_ring)
            cst_1_week.setBackgroundResource(R.drawable.premium_round_gray_ring)
            txtSave50.setBackgroundColor(Color.parseColor("#A6A4A4"))
            textVie51.setBackgroundColor(Color.parseColor("#A6A4A4"))
            save1Months.setBackgroundColor(Color.parseColor("#FF4551"))

            mSixBestValue.visibility = View.VISIBLE
            mYearBestValue.visibility = View.INVISIBLE
            mSelectedKey = com.vasundhara.vision.subscription.constants.Constants.BASIC_SKU
        }
        R.id.cst_1_year -> {
            selectedSub = 0
            cst_1_week.setBackgroundResource(R.drawable.premium_round_gray_ring)
            cst_1_month.setBackgroundResource(R.drawable.premium_round_gray_ring)
            cst_1_year.setBackgroundResource(R.drawable.premium_round_pink_ring)
            txtSave50.setBackgroundColor(Color.parseColor("#FF4551"))
            save1Months.setBackgroundColor(Color.parseColor("#A6A4A4"))
            textVie51.setBackgroundColor(Color.parseColor("#A6A4A4"))
            mSixBestValue.visibility = View.INVISIBLE
            mYearBestValue.visibility = View.VISIBLE

            mSelectedKey = com.vasundhara.vision.subscription.constants.Constants.PREMIUM_SKU

        }
        R.id.cst_1_week -> {
            selectedSub = 2
            cst_1_month.setBackgroundResource(R.drawable.premium_round_gray_ring)
            cst_1_week.setBackgroundResource(R.drawable.premium_round_pink_ring)
            cst_1_year.setBackgroundResource(R.drawable.premium_round_gray_ring)
            textVie51.setBackgroundColor(Color.parseColor("#FF4551"))
            txtSave50.setBackgroundColor(Color.parseColor("#A6A4A4"))
            save1Months.setBackgroundColor(Color.parseColor("#A6A4A4"))
            mSixBestValue.visibility = View.INVISIBLE
            mYearBestValue.visibility = View.INVISIBLE

            mSelectedKey = com.vasundhara.vision.subscription.constants.Constants.PREMIUM_SIX_SKU
        }
        R.id.imgBackPremium -> {
            onBackPressed()
        }

        R.id.txtTearmsCondition -> {
            startActivity(Intent(this, TermsConditionActivity::class.java))
        }
        R.id.txtPrivacyPolicy -> {
            startActivity(Intent(this, PrivacyPolicyActivity::class.java))

        }
    }
}

override fun onBackPressed() {
    super.onBackPressed()
//        AdsPrefs.save(mContext, AdsPrefs.IS_SUBSCRIBED, true)
}

//    private fun setPlan(key: String) {
//        billingProcessor!!.consumePurchase(key)
//        billingProcessor!!.subscribe(this, key, "")
//    }


//
//    override fun onProductPurchased(productId: String, details: TransactionDetails?) {
//        try {
//            Log.e(TAG, "onProductPurchased:  developerPayload :: -> " + details!!.purchaseInfo.purchaseData.developerPayload)
//            Log.e(TAG, "onProductPurchased:  orderId :: -> " + details.purchaseInfo.purchaseData.orderId)
//            Log.e(TAG, "onProductPurchased:  packageName :: -> " + details.purchaseInfo.purchaseData.packageName)
//            Log.e(TAG, "onProductPurchased:  purchaseToken :: -> " + details.purchaseInfo.purchaseData.purchaseToken)
//            Log.e(TAG, "onProductPurchased:  autoRenewing :: -> " + details.purchaseInfo.purchaseData.autoRenewing)
//            Log.e(TAG, "onProductPurchased:  purchaseTime :: -> " + details.purchaseInfo.purchaseData.purchaseTime)
//            Log.e(TAG, "onProductPurchased:  purchaseState :: -> " + details.purchaseInfo.purchaseData.purchaseState)
//        } catch (e: java.lang.Exception) {
//
//        }
//        when (productId) {
//            productKey3Month -> {
//                AdsPrefs.save(mContext, AdsPrefs.IS_SUBSCRIBED, true);
//            }
//            productKeyMonth -> {
//                AdsPrefs.save(mContext, AdsPrefs.IS_SUBSCRIBED, true)
//            }
//            productKeyYear -> {
//                AdsPrefs.save(mContext, AdsPrefs.IS_SUBSCRIBED, true)
//            }
//        }
//        Constants.isSubscribedW = true
//        Constants.isSubscribedH = true
//        Constants.isSubscribedS = true
//        Constants.isSubscribedG = true
//        Constants.isSubscribedT = true
//        finish()
//    }
//
//    override fun onPurchaseHistoryRestored() {
//        Log.e(TAG, "onPurchaseHistoryRestored: :: ")
//    }
//
//    override fun onBillingError(errorCode: Int, error: Throwable?) {
//        try {
//            Log.e(TAG, "onBillingError: errorCode : $errorCode")
//            Log.e(TAG, "onBillingError: getCause : " + error!!.cause!!.message)
//            Log.e(TAG, "onBillingError: getMessage : " + error.message)
//        } catch (e: Exception) {
//            Log.e(TAG, "onBillingError: Exception Cause")
//        }
//    }
//
//    override fun onBillingInitialized() {
//        Log.e(TAG, "onBillingInitialized: :::::")
//    }

companion object {
    private const val TAG = "PremiumAccessActivity"
}


//    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        super.onActivityResult(requestCode, resultCode, data)
//        if (requestCode == 32459) {
//            if (billingProcessor != null) {
//                if (!billingProcessor!!.handleActivityResult(requestCode, resultCode, data)) {
//                    super.onActivityResult(requestCode, resultCode, data)
//                }
//            }
//        }
//    }

private fun hideSystemUI() {
    window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
//        window!!.decorView.systemUiVisibility=View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
        window.statusBarColor = Color.TRANSPARENT
    }
}

fun statusBar(): Int {
    var result: Int = 0
    try {
        result = 0
        val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
        if (resourceId > 0) {
            result = resources.getDimensionPixelSize(resourceId)
        }
    } catch (e: Exception) {
    }
    return result
}

override fun onResume() {
    super.onResume()
    SolidWallpaperApplication.staticLanguage.Factory.create(this)
}

}