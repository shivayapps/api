package com.solid.color.wallpaper.hd.image.background.activity

import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.AsyncTask
import android.os.Bundle
import android.os.Environment
import android.provider.ContactsContract
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.isEmpty
import androidx.core.view.isNotEmpty
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.constants.Constants
import com.solid.color.wallpaper.hd.image.background.constants.Constants.mGalleryBitmap
import com.solid.color.wallpaper.hd.image.background.shared_pref.MySharedPref
import com.theartofdev.edmodo.cropper.CropImageView

class CropImageActivity : AppCompatActivity() {
    internal lateinit var imgCropImage: CropImageView
    internal lateinit var llProgressBar: LinearLayout
    internal lateinit var btnCrop: ImageView
    internal lateinit var icBack: ImageView
    internal lateinit var mySharedPref: MySharedPref
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cop_image)
        mySharedPref = MySharedPref(this)
        imgCropImage = findViewById(R.id.cropImageView)
        llProgressBar = findViewById(R.id.llProgressBar)
        btnCrop = findViewById(R.id.btnCrop)
        icBack = findViewById(R.id.icBack)
        imgCropImage.setAspectRatio(9, 16)
//        imgCropImage.setImageUriAsync(Constants.mGalleryUri)
        Glide.with(this).load(Constants.mGalleryUri).override(1000,1000).into(object : CustomTarget<Drawable?>() {
            public override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                try {
                    runOnUiThread(){
                        imgCropImage.setImageBitmap(resource.toBitmap())
                        btnCrop.visibility = View.VISIBLE
                        llProgressBar.visibility = View.GONE
                    }

                } catch (e: java.lang.Exception) {
                    finish()
                    Toast.makeText(this@CropImageActivity, resources.getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
                }

            }

            override fun onLoadFailed(errorDrawable: Drawable?) {
                super.onLoadFailed(errorDrawable)
                finish()
                Toast.makeText(this@CropImageActivity, resources.getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
            }

            public override fun onLoadCleared(placeholder: Drawable?) {}
        })
        btnCrop.setOnClickListener {
            try {
                mGalleryBitmap = imgCropImage.croppedImage
                setResult(3333)
                finish()
            } catch (e: Exception) {
                finish()
                Toast.makeText(this, resources.getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
            }


        }
        icBack.setOnClickListener { finish() }
    }

    override fun onBackPressed() {
        finish()
    }
}