package com.solid.color.wallpaper.hd.image.background.adapter

import android.content.Context
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.adapter.ForegroundLiveAdapter.OnItemSelectedListner
import com.solid.color.wallpaper.hd.image.background.custom.GridSpacingItemDecoration
import com.solid.color.wallpaper.hd.image.background.model.WallpaperWeekModel
import com.solid.color.wallpaper.hd.image.background.newModel.WallpaperWeekModelNewResponse
import java.util.*

class RecyclerSnapAdapter(private val mResolutionModelList: ArrayList<ArrayList<WallpaperWeekModelNewResponse?>?>, private val mContext: Context, private val onItemChanged: OnItemChanged) : RecyclerView.Adapter<RecyclerSnapAdapter.MyViewHolder>() {
    private val recycledViewPool: RecyclerView.RecycledViewPool = RecyclerView.RecycledViewPool()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(LayoutInflater.from(mContext).inflate(R.layout.rv_snap_recycler, parent, false))
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
//        holder.setIsRecyclable(false);
        holder.recyclerScreenCategory.setRecycledViewPool(recycledViewPool)
        onItemChanged.onItemChanged(position)
        val onItemSelectedListner = object : OnItemSelectedListner {
            override fun onItemClick(model: WallpaperWeekModelNewResponse?, position: Int) {
                onItemChanged.onItemSelect(model)
            }
        }
        val adapter = ForegroundLiveAdapter(mResolutionModelList[position], mContext, onItemSelectedListner)
        holder.recyclerScreenCategory.adapter = adapter
    }

    override fun getItemCount(): Int {
        return mResolutionModelList.size
    }

    interface OnItemChanged {
        fun onItemChanged(position: Int)
        fun onItemSelect(model: WallpaperWeekModelNewResponse?)
    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var recyclerScreenCategory: RecyclerView = itemView.findViewById(R.id.recyclerScreenCategory)

        init {
            val manager = GridLayoutManager(mContext, 3)
            recyclerScreenCategory.layoutManager = manager
            recyclerScreenCategory.addItemDecoration(GridSpacingItemDecoration(3, dpToPx(22), true))
            recyclerScreenCategory.itemAnimator = DefaultItemAnimator()
            recyclerScreenCategory.isNestedScrollingEnabled = false
        }
    }

    private fun dpToPx(dp: Int): Int {
        val r = mContext.resources
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), r.displayMetrics))
    }

}