package com.solid.color.wallpaper.hd.image.background.activity

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.*
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.ConnectivityManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.renderscript.Allocation
import android.renderscript.Element
import android.renderscript.RenderScript
import android.renderscript.ScriptIntrinsicBlur
import android.util.Base64
import android.util.Log
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.NetworkHelper
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.firebase.analytics.FirebaseAnalytics
import com.scribble.animation.maker.video.effect.myadslibrary.Api.ApiNew
import com.scribble.animation.maker.video.effect.myadslibrary.ImagesItem
import com.scribble.animation.maker.video.effect.myadslibrary.Response
import com.scribble.animation.maker.video.effect.myadslibrary.helper.DBHelperNew
import com.scribble.animation.maker.video.effect.myadslibrary.interfaces.ApiInterface
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.Helper
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.appid.AppIDs
import com.scribble.animation.maker.video.effect.myadslibrary.utils.InternetConnection
import com.solid.color.wallpaper.hd.image.background.PaintViewFol.activity.PaintActivity
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.SolidWallpaperApplication
import com.solid.color.wallpaper.hd.image.background.adshalper.OfflineNativeAdvanced
import com.solid.color.wallpaper.hd.image.background.constants.Constants
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs.getBoolean
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs.getInt
import kotlinx.android.synthetic.main.activity_main_start.*
//import kotlinx.android.synthetic.main.activity_more_app.view.*
import org.jetbrains.anko.backgroundDrawable
import org.jetbrains.anko.networkStatsManager
import retrofit2.Call
import retrofit2.Callback
import java.lang.reflect.Executable
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException
import java.util.*
import kotlin.collections.ArrayList


class MainStartActivity : AppCompatActivity(), View.OnClickListener {
    private var firebaseAnalytics:FirebaseAnalytics?=null
    private val bundle = Bundle()
    private var is_pause = false
    var mViewBitmap: Drawable? = null
    var mBgDrawable: Drawable? = null
    private var apiInterface: ApiInterface? = null
    private var lastClickTime: Long = 0
    private var exitdialogFragment: com.scribble.animation.maker.video.effect.myadslibrary.dialog.ExitDialogFragment? =
        null
    private var isdialogSHown = false
    var receiver: BroadcastReceiver?=null
    var intentFilter: IntentFilter?=null
    var model: Response? = null
    private var dbHelper: DBHelperNew? = null
    var mDataImageLink: ArrayList<String> = ArrayList()
    var mDataList: ArrayList<ImagesItem>? = ArrayList()
    var mDataStoreList: ArrayList<String> = ArrayList()
    var isCursor = false
    var mAdsType = ""
    var dialog:Dialog?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_start)

        Log.d("NETs", "onCreate: ")
        System.gc()
        printHashKey(this)
        setBGExitDialog()
        SolidWallpaperApplication.staticLanguage.Factory.create(this)
        dbHelper = DBHelperNew(this@MainStartActivity)
        if ( /*!sharedPref.getAdsRemoved() &&*/!getBoolean(this@MainStartActivity, AdsPrefs.IS_SUBSCRIBED, false))
        {
            Constants.isNativeAd1 = true
            Constants.isInstrastial1 = true
            loadInterstialAd()

            Log.d("OfflineAds", "onCreate: Call onCreate")

            OfflineNativeAdvanced.loadOfflineNativeAdvanceBig(this@MainStartActivity, findViewById(R.id.fl_adplaceholder))
            {
                receiver=object :BroadcastReceiver()
                {
                    override fun onReceive(context: Context?, intent: Intent?) {
                        if(InternetConnection.checkConnection(context)) {
                            if (it == 1) {
                                adsLayout.visibility = View.VISIBLE
                                imgMain.visibility = View.GONE

//                                Handler(Looper.getMainLooper()).postDelayed({
//                                    adsLayout!!.isEnabled=false
//                                },5000)
//
//                                adsLayout!!.isEnabled=true

                            } else if (it == 0) {
                                adsLayout.visibility = View.GONE
                                imgMain.visibility = View.VISIBLE
                            }
                        }
                        else
                        {
                            adsLayout!!.visibility=View.GONE
                            imgMain!!.visibility=View.VISIBLE
                        }
                    }
                }
                registerReceiver(receiver, IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"))
            }

            findViewById<View>(R.id.cst_money_btn).visibility = View.VISIBLE
            findViewById<View>(R.id.adsLayout).visibility = View.VISIBLE
            findViewById<View>(R.id.imgplus).visibility = View.VISIBLE
            findViewById<View>(R.id.pro_user).visibility = View.GONE

//            Handler(Looper.getMainLooper()).postDelayed({
//                adsLayout!!.isEnabled=false
//            },5000)
//
//            adsLayout!!.isEnabled=true
        } else {
            findViewById<View>(R.id.cst_money_btn).visibility = View.GONE
            findViewById<View>(R.id.imgplus).visibility = View.GONE
            findViewById<View>(R.id.adsLayout).visibility = View.GONE
            findViewById<View>(R.id.imgMain).visibility = View.VISIBLE
            findViewById<View>(R.id.pro_user).visibility = View.VISIBLE
        }
        val btnMyCreation = findViewById<LinearLayout>(R.id.btnMyCreation)
        val btnCreate = findViewById<LinearLayout>(R.id.btnCreate)
        val ll_games = findViewById<LinearLayout>(R.id.ll_games)
        val btnPaint = findViewById<LinearLayout>(R.id.btnPaint)
        val btnHdWallpapers = findViewById<LinearLayout>(R.id.btnHdWallpapers)
        val btnSettings = findViewById<LinearLayout>(R.id.btnSettings)
        val cst_money_btn = findViewById<ConstraintLayout>(R.id.cst_money_btn)
        btnSettings.setOnClickListener(this)
        btnMyCreation.setOnClickListener(this)
        btnCreate.setOnClickListener(this)
        ll_games.setOnClickListener(this)
        btnPaint.setOnClickListener(this)
        btnHdWallpapers.setOnClickListener(this)
        cst_money_btn.setOnClickListener(this)

        try {
            callMoreAPi()
        }
        catch (e: Exception) {
        }

        firebaseAnalytics=FirebaseAnalytics.getInstance(this)

        bundle.clear()

        if (getBoolean(this@MainStartActivity, AdsPrefs.IS_SUBSCRIBED, false)){
            findViewById<View>(R.id.adsLayout).visibility = View.GONE
        }
    }

    private fun setBGExitDialog() {
        BitmapBlurTask().execute()
    }

    inner class BitmapBlurTask : AsyncTask<Void?, Void?, Void?>() {
        override fun doInBackground(vararg p0: Void?): Void? {
            Log.d(TAG, "doInBackground: ")
            Glide.with(this@MainStartActivity).asBitmap().load(R.drawable.ic_new_dashboard)
                .into(object : CustomTarget<Bitmap?>() {

                    override fun onLoadCleared(placeholder: Drawable?) {}

                    override fun onResourceReady(
                        resource: Bitmap,
                        transition: Transition<in Bitmap?>?
                    ) {
                        val bmp: Bitmap = BlurBuilder.blur(this@MainStartActivity, resource)
                        Helper.mDrawable = BitmapDrawable(resources, bmp)
                        mBgDrawable = BitmapDrawable(resources, bmp)
                    }
                })

            Log.d(TAG, "doInBackground: ")
            return null
        }
    }

    fun callMoreAPi() {
        apiInterface = ApiNew.client!!.create(ApiInterface::class.java)
        apiInterface!!.allAppNew.enqueue(object : Callback<Response> {
            override fun onResponse(call: Call<Response>, response: retrofit2.Response<Response>) {
                Log.d("API-RESPONSE", "onResponse: "+response.body()!!.responseCode)
                if (response.body()!!.responseCode == "1" && response.body()!!.data!!.isNotEmpty()) {
                    model = response.body()
                    Log.d("16-10-2021", "onResponse: $model")
                    if (model?.data != null) {
                        mDataList = model!!.data!![0].images
                        Log.d("16-10-2021", "onResponseqqqqq: ${mDataList!!.size}")
                        if (!isCursor) {
                            isCursor = true

                            Log.d(TAG, "onResponseiiiiiiii: call apiaaaa")
                            for (i in mDataList!!.indices) {
                                val appModel: ImagesItem = mDataList!![i]
                                if (appModel.size!!.contains("com.solid.color.wallpaper.hd.image.background")) {
                                    mDataList!!.remove(appModel)
                                    break
                                }
                                dbHelper!!.insertPath(
                                    model!!.data?.get(0)!!.images!![i].position!!,
                                    model!!.data?.get(0)!!.images!![i].name!!,
                                    model!!.data?.get(0)!!.images!![i].thumbImage!!,
                                    model!!.data?.get(0)!!.images!![i].size!!
                                )

                            }
                            val newListData = dbHelper!!.allMoreAppData
                            while (newListData.moveToNext()) {
                                mDataStoreList.add(
                                    newListData.getString(
                                        newListData.getColumnIndex(
                                            newListData.getColumnName(1)
                                        )
                                    )
                                )
                            }
                            newListData.close()
                        } else {
                            val mDataNewApi = dbHelper!!.allMoreAppData
                            mDataImageLink.clear()
                            while (mDataNewApi.moveToNext()) {
                                mDataImageLink.add(
                                    mDataNewApi.getString(
                                        mDataNewApi.getColumnIndex(
                                            mDataNewApi.getColumnName(3)
                                        )
                                    )
                                )
                            }
                            Log.d("TAG", "onResponsehfhfhfhfhhf: ${mDataList!!.size}")
                            for (k in mDataList!!.indices) {
                                if (mDataList!![k].thumbImage == mDataImageLink[k]) {
                                    Log.d("TAG", "onResponsehfhfhfhfhhf: same data")
                                } else {
                                    Log.d("TAG", "onResponsehfhfhfhfhhf: diffrent data")
                                    dbHelper!!.deleteData()
                                    for (i in mDataList!!.indices) {
                                        val appModel: ImagesItem = mDataList!![i]
                                        if (appModel.size!!.contains("com.solid.color.wallpaper.hd.image.background")) {
                                            mDataList!!.remove(appModel)
                                            break
                                        }
                                        dbHelper!!.insertPath(
                                            model!!.data?.get(0)!!.images!![i].position!!,
                                            model!!.data?.get(0)!!.images!![i].name!!,
                                            model!!.data?.get(0)!!.images!![i].thumbImage!!,
                                            model!!.data?.get(0)!!.images!![i].size!!
                                        )

                                    }

                                }
                            }
                        }
                    }
                }
            }

            override fun onFailure(call: Call<Response>, t: Throwable) {
                runOnUiThread {
                    try {
                        Thread.sleep(1000)
                    } catch (e: InterruptedException) {
                        e.printStackTrace()
                    }

                }
            }

        })
    }


    private fun onclickGames() {
        if (!NetworkHelper.isOnline(this)) {
            Toast.makeText(this, resources.getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(this@MainStartActivity, GamezopActivity::class.java))
    }

    fun onClickCreate() {
        if (ContextCompat.checkSelfPermission(
                this@MainStartActivity,
                Manifest.permission.READ_EXTERNAL_STORAGE
            )
            != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(
                this@MainStartActivity,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // Permission is not granted
            ActivityCompat.requestPermissions(
                this@MainStartActivity,
                arrayOf(
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                ),
                READ_PERMISSION
            )
        } else {
                startActivity(Intent(this@MainStartActivity, HomeActivity::class.java))
        }
    }

    private var mInterstitialAd: InterstitialAd? = null

    private fun loadInterstialAd() {


        var adsId = AppIDs.instnace!!.getGoogleInterstitial()
//        mInterstitialAd = InterstitialAd()

        val ins_adRequest = AdRequest.Builder().build()
        InterstitialAd.load(this,
            adsId,
            ins_adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(myAd: InterstitialAd) {
//                            Timber.d("Ad Loaded")
                    Log.d(TAG, "onAdLoaded: Ad Loaded")
                    mInterstitialAd = myAd
//                        startActivity(Intent(this@MainStartActivity, MyCreationActivity::class.java))
//                        mInterstitialAd=null

                }

                override fun onAdFailedToLoad(adError: LoadAdError) {
                    Log.d(TAG, "onAdLoaded: ${adError.message}")
//                        startActivity(Intent(this@MainStartActivity, MyCreationActivity::class.java))
                    mInterstitialAd = null
//                            Timber.d("Failed to load ad: ${adError.message}")
//                        mInterstitialAd = null
                }

            })
    }

    fun showInterstitial() {
        if (mInterstitialAd != null) {

            mInterstitialAd!!.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    Log.d(TAG, "Ad was dismissed.")
                    Log.e(TAG, "1212121: $mAdsType")
                    Log.d(TAG, "onAdDismissedFullScreenContent:1111 $mAdsType")
                    when (mAdsType) {
                        "Creation" -> {
                            Handler(Looper.getMainLooper()).postDelayed({
                                startActivity(
                                    Intent(
                                        this@MainStartActivity,
                                        MyCreationActivity::class.java
                                    )
                                )
                            }, 1)
                        }

                        "Paint" -> {
                            Handler(Looper.getMainLooper()).postDelayed({
                                startActivity(
                                    Intent(
                                        this@MainStartActivity,
                                        PaintActivity::class.java
                                    )
                                )
                            }, 1)
                        }
                    }

                    mInterstitialAd = null
                    loadInterstialAd()
//                    mInterstitialAd = null
                }

                override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
                    super.onAdFailedToShowFullScreenContent(p0)
                    Log.d(TAG, "Ad was dismisdasdased.")

                    startActivity(Intent(this@MainStartActivity, MyCreationActivity::class.java))
//                loadInterstialAdFb()
                }

                override fun onAdShowedFullScreenContent() {
                    Log.d(TAG, "Ad showed fullscreen content.")
//                    startActivity(Intent(this@MainStartActivity, MyCreationActivity::class.java))
                    mInterstitialAd = null
                }
            }
            mInterstitialAd?.show(this)
        } else {
            when (mAdsType) {
                "Creation" -> {
                    Handler(Looper.getMainLooper()).postDelayed({
                        startActivity(
                            Intent(
                                this@MainStartActivity,
                                MyCreationActivity::class.java
                            )
                        )
                    }, 1)
//                    startActivity(Intent(this@MainStartActivity, MyCreationActivity::class.java))
                }

                "Paint" -> {
                    Handler(Looper.getMainLooper()).postDelayed({
                        startActivity(Intent(this@MainStartActivity, PaintActivity::class.java))
                    }, 1)
                }
            }
        }
    }

    fun onClickMyCreation() {
        Constants.viewPagerPage = 1
//        Ads = "Creation"


        if (ContextCompat.checkSelfPermission(
                this@MainStartActivity,
                Manifest.permission.READ_EXTERNAL_STORAGE
            )
            != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(
                this@MainStartActivity,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // Permission is not granted
            ActivityCompat.requestPermissions(
                this@MainStartActivity,
                arrayOf(
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                ),
                READ_PERMISSION_CREATE
            )
        } else {
            if (!getBoolean(this@MainStartActivity, AdsPrefs.IS_SUBSCRIBED, false)) {

                showInterstitial()
            } else {
                startActivity(Intent(this@MainStartActivity, MyCreationActivity::class.java))
            }
        }


    }


    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == READ_PERMISSION) { // If request is cancelled, the result arrays are empty.
            if (grantResults.isNotEmpty()
                && grantResults[0] == PackageManager.PERMISSION_GRANTED
            ) {
                startActivity(Intent(this@MainStartActivity, HomeActivity::class.java))
                Log.d(TAG, "onRequestPermissionsResult: 1")
            } else {
                val showRationale = ActivityCompat.shouldShowRequestPermissionRationale(
                    this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                )
                Log.d(TAG, "onRequestPermissionsResult: 2 $showRationale")
                if (!showRationale) {
                    pemissionDialog()
                }
            }
        } else if (requestCode == READ_PERMISSION_CREATE) {

            // If request is cancelled, the result arrays are empty.
            if (grantResults.isNotEmpty()
                && grantResults[0] == PackageManager.PERMISSION_GRANTED
            ) {
                mAdsType = "Creation"
                startActivity(Intent(this@MainStartActivity, MyCreationActivity::class.java))
            } else {

                val showRationale = ActivityCompat.shouldShowRequestPermissionRationale(
                    this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                )
                if (!showRationale) {
                    pemissionDialog()
                }
            }
        } else if (requestCode == READ_PERMISSION_WEEK) { // If request is cancelled, the result arrays are empty.
            if (grantResults.isNotEmpty()
                && grantResults[0] == PackageManager.PERMISSION_GRANTED
            ) {
                startActivity(Intent(this, WallpaperOfWeekNewActivity::class.java))
            } else {
                val showRationale = ActivityCompat.shouldShowRequestPermissionRationale(
                    this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                )
                if (!showRationale) {
                    pemissionDialog()
                }
            }
        } else if (requestCode == READ_PERMISSION_PAINT) { // If request is cancelled, the result arrays are empty.

            if (grantResults.isNotEmpty()
                && grantResults[0] == PackageManager.PERMISSION_GRANTED
            ) {
                mAdsType = "Paint"
                startActivity(Intent(this, PaintActivity::class.java))
            } else {

                val showRationale = ActivityCompat.shouldShowRequestPermissionRationale(
                    this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                )
                if (!showRationale) {
                    pemissionDialog()
                }
            }
        }
    }

    fun pemissionDialog() {
        val alertDialog: AlertDialog
        val viewGroup = findViewById<ViewGroup>(android.R.id.content)
        val dialogView =
            LayoutInflater.from(this).inflate(R.layout.permission_dialog, viewGroup, false)
        val builder1 = AlertDialog.Builder(this)
        builder1.setView(dialogView)
        alertDialog = builder1.create()
        val cancel = dialogView.findViewById<Button>(R.id.btnCancel)
        cancel.setOnClickListener { v: View? ->
            alertDialog.dismiss()
            Toast.makeText(
                this@MainStartActivity,
                resources.getString(R.string.permission_required),
                Toast.LENGTH_SHORT
            ).show()
        }
        val ok = dialogView.findViewById<Button>(R.id.btnOk)
        ok.setOnClickListener { v: View? ->
            startInstalledAppDetailsActivity(this@MainStartActivity)
            alertDialog.dismiss()
        }
        alertDialog.show()
    }

    fun startInstalledAppDetailsActivity(context: Activity?) {
        if (context == null) {
            return
        }
        val i = Intent()
        i.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        i.addCategory(Intent.CATEGORY_DEFAULT)
        i.data = Uri.parse("package:" + context.packageName)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        i.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
        i.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
        context.startActivity(i)
    }

    override fun onStop() {
        super.onStop()
        is_pause = true
        if (exitdialogFragment != null) {
            exitdialogFragment!!.dismiss()
        }
        Log.d("789456456456456", "onStop: ")
    }

    override fun onDestroy() {
        super.onDestroy()

        unregisterReceiver(receiver)

        is_pause = true
        if (exitdialogFragment != null) {
            exitdialogFragment!!.dismiss()
        }
        OfflineNativeAdvanced.onDestroy()
        Log.d("789456456456456", "onDestroy: ")
    }



    override fun onBackPressed() {
        try {
            exitDialog()
        }catch (e:Exception){

        }

    }

    private fun exitDialog() {

        dialog = Dialog(this@MainStartActivity,R.style.DialogTheme)
        dialog!!.setContentView(R.layout.activity_exit)
        dialog!!.setCancelable(false)
//        val bgLayout: ConstraintLayout = dialog!!.findViewById<ConstraintLayout>(R.id.exitScreenMain)
//        val cardView: ConstraintLayout = dialog!!.findViewById<ConstraintLayout>(R.id.cardView)

        dialog!!.window!!.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            dialog!!.window!!.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            dialog!!.window!!.statusBarColor = Color.TRANSPARENT;
        }


//        receiver=object :BroadcastReceiver(){
//            override fun onReceive(context: Context?, intent: Intent?) {
//                if(InternetConnection.checkConnection(context)){
//                    setAdsInDialog()
//                }
//                else{
//                    noAdsAvilableForExitDialog()
//                }
//            }
//        }
//        registerReceiver(receiver, IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"))

        if (!getBoolean(this@MainStartActivity, AdsPrefs.IS_SUBSCRIBED, false)){
//            setAdsInDialog()
            if(InternetConnection.checkConnection(this)){
                setAdsInDialog()
            }
            else{
                noAdsAvilableForExitDialog()
            }
        }else{
            noAdsAvilableForExitDialog()
        }

        dialog!!.findViewById<TextView>(R.id.btnPositive).setOnClickListener {
            startActivity(Intent(this@MainStartActivity, ExitScreen::class.java))
            finishAffinity()
        }
        dialog!!.findViewById<TextView>(R.id.btnNagative).setOnClickListener {
//            loadNativeSh()
            loadInterstialAd()
            onResume()
            dialog!!.dismiss()
        }
        dialog!!.findViewById<TextView>(R.id.btnPositiveNoAds).setOnClickListener {
            startActivity(Intent(this@MainStartActivity, ExitScreen::class.java))
            finishAffinity()
        }
        dialog!!.findViewById<TextView>(R.id.btnNagativeNoAds).setOnClickListener {
            loadInterstialAd()
//            loadNativeSh()
            onResume()
            dialog!!.dismiss()
        }

        dialog!!.show()

    }

    private fun setAdsInDialog() {
        if (true){
            try {
//                dialog!!.findViewById<ConstraintLayout>(R.id.exitScreenMain).setBackgroundColor(Color.WHITE)
                dialog!!.findViewById<FrameLayout>(R.id.fl_adplaceholder).visibility = View.VISIBLE
              OfflineNativeAdvanced.loadOfflineNativeAdvanceBigExitScreen(this, dialog!!.findViewById<FrameLayout>(R.id.fl_adplaceholder)) {
                    try {
                        if (it == 1) {
                            dialog!!.findViewById<ConstraintLayout>(R.id.ads).visibility = View.VISIBLE
                            dialog!!.findViewById<ConstraintLayout>(R.id.noAds).visibility = View.GONE
                            dialog!!.findViewById<ConstraintLayout>(R.id.cardOfflineSlide).visibility = View.VISIBLE
                        } else {
                            noAdsAvilableForExitDialog()
                        }
                    } catch (e: Exception) {
                    }
                }
            } catch (e: Exception) {
            }
        }else{
            noAdsAvilableForExitDialog()
        }
    }

    private fun noAdsAvilableForExitDialog() {
//        dialog!!.findViewById<ConstraintLayout>(R.id.cardViewNoAds).setBackgroundResource(R.drawable.ic_home_background)
        //dialog!!.findViewById<ConstraintLayout>(R.id.cardViewNoAds).background = ContextCompat.getDrawable(this@HomeActivity, R.drawable.bg_main_border)
        dialog!!.findViewById<ConstraintLayout>(R.id.exitScreenMain).backgroundDrawable = mBgDrawable
        dialog!!.findViewById<FrameLayout>(R.id.fl_adplaceholder).visibility = View.GONE
        dialog!!.findViewById<CardView>(R.id.cardOfflineSlide).visibility = View.GONE
        dialog!!.findViewById<ConstraintLayout>(R.id.ads).visibility = View.GONE
        dialog!!.findViewById<ConstraintLayout>(R.id.noAds).visibility = View.VISIBLE
    }

//    private fun showExitDialog(mBitmap: Bitmap) {
//        Log.d("dsfdsfdsfdsfdsfds", "showExitDialog: ")
//        try {
//            Helper.mDrawable = BitmapDrawable(resources, mBitmap)
//        } catch (e: Exception) {
//        }
//
//        try {
//            exitdialogFragment =
//                com.scribble.animation.maker.video.effect.myadslibrary.dialog.ExitDialogFragment(
//                    getBoolean(this@MainStartActivity, AdsPrefs.IS_SUBSCRIBED, false),
//                    resources.getString(R.string.leave_app),
//                    resources.getString(R.string.do_you_want_to_leave_app),
//                    "Yes",
//                    "No",
//                    R.drawable.ic_exit_logo,
//                    object :
//                        com.scribble.animation.maker.video.effect.myadslibrary.dialog.ExitDialogFragment.OnButtonClickListener {
//                        override fun onPositive(exitDialogFragment: com.scribble.animation.maker.video.effect.myadslibrary.dialog.ExitDialogFragment?) {
//                            try {
//                                exitDialogFragment!!.dismiss()
//                                finishAffinity()
//                            } catch (e: Exception) {
//                            }
//                        }
//
//                        override fun onNegative(exitDialogFragment: com.scribble.animation.maker.video.effect.myadslibrary.dialog.ExitDialogFragment?) {
//                            try {
//                                isdialogSHown = false
//                                exitDialogFragment!!.dismiss()
//                            } catch (e: Exception) {
//                            }
//                        }
//
//                        override fun onDismiss() {
//
//                        }
//                    })
//            exitdialogFragment!!.show(supportFragmentManager, "dialog_exit")
//        } catch (e: java.lang.Exception) {
//            e.printStackTrace()
//        }
//        isdialogSHown = true
//    }

    object BlurBuilder {
        private const val BITMAP_SCALE = 1f
        private const val BLUR_RADIUS = 10f
        fun blur(context: Context?, image: Bitmap): Bitmap {
            val width = Math.round(image.width * BITMAP_SCALE)
            val height = Math.round(image.height * BITMAP_SCALE)
            val inputBitmap = Bitmap.createScaledBitmap(image, width, height, false)
            val outputBitmap = Bitmap.createBitmap(inputBitmap)
            val rs = RenderScript.create(context)
            var theIntrinsic: ScriptIntrinsicBlur? = null
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                theIntrinsic = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs))
            }
            val tmpIn = Allocation.createFromBitmap(rs, inputBitmap)
            val tmpOut = Allocation.createFromBitmap(rs, outputBitmap)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                theIntrinsic!!.setRadius(BLUR_RADIUS)
                theIntrinsic.setInput(tmpIn)
                theIntrinsic.forEach(tmpOut)
            }
            tmpOut.copyTo(outputBitmap)
            val canvas = Canvas(outputBitmap)
            canvas.drawColor(Color.parseColor("#48000000"))
            return outputBitmap
        }
    }

    fun printHashKey(pContext: Context) {
        try {
            val info: PackageInfo = pContext.packageManager.getPackageInfo(
                pContext.packageName,
                PackageManager.GET_SIGNATURES
            )
            for (signature in info.signatures) {
                val md: MessageDigest = MessageDigest.getInstance("SHA")
                md.update(signature.toByteArray())
                val hashKey = String(Base64.encode(md.digest(), 0))
                Log.i(
                    MainStartActivity.TAG,
                    "printHashKey() Hash Key: $hashKey    ${hashKey.length}"
                )
            }
        } catch (e: NoSuchAlgorithmException) {
            Log.e(MainStartActivity.TAG, "printHashKey()", e)
        } catch (e: Exception) {
            Log.e(MainStartActivity.TAG, "printHashKey()", e)
        }
    }

    private fun takeScreenShot(activity: Activity): Bitmap {
        val view = findViewById<View>(R.id.main_screen) //activity.getWindow().getDecorView();
        view.isDrawingCacheEnabled = true
        view.buildDrawingCache()
        val b1 = view.drawingCache
        val frame = Rect()
        activity.window.decorView.getWindowVisibleDisplayFrame(frame)
        val statusBarHeight = frame.top
        val width = view.width //activity.getWindowManager().getDefaultDisplay().getWidth();
        val height = view.height //activity.getWindowManager().getDefaultDisplay().getHeight();
        Log.d("TAG===>>>>>>", "takeScreenShot: $statusBarHeight  $width  $height")
        // view.destroyDrawingCache();
        return Bitmap.createBitmap(b1, 0, statusBarHeight, width, height - 2)
    }


    override fun onPause() {
        super.onPause()
//        if (exitdialogFragment != null) {
//            exitdialogFragment!!.dismiss()
//        }

//        dialog!!.dismiss()

        try {
            dialog!!.dismiss()
        }catch (e:Exception){

        }
    }

    override fun onStart() {
        super.onStart()
        intentFilter= IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION)
        registerReceiver(receiver,intentFilter)

        Log.d("OfflineAds", "onStart: ")
    }


    override fun onResume() {
        super.onResume()

        if(InternetConnection.checkConnection(this))
        {
            if (!getBoolean(this@MainStartActivity, AdsPrefs.IS_SUBSCRIBED, false)){
                OfflineNativeAdvanced.loadOfflineNativeAdvanceBig(this@MainStartActivity, findViewById(R.id.fl_adplaceholder))
                {
                    if (it == 1) {
                        Log.d(TAG, "onResume: loaded")
                        adsLayout.visibility = View.VISIBLE
                        imgMain.visibility = View.GONE

//                        Handler(Looper.getMainLooper()).postDelayed({
//                            adsLayout!!.isEnabled=false
//                        },5000)
//
//                        adsLayout!!.isEnabled=true

                    } else if (it == 0) {
                        Log.d(TAG, "onResume: failed")

                        OfflineNativeAdvanced.loadOfflineNativeAdvanceBig(this@MainStartActivity, findViewById(R.id.fl_adplaceholder))
                        {
                            when(it){
                                0->{
                                    Log.d(TAG, "onResume: if failed")
                                }
                                1->{
                                    Log.d(TAG, "onResume: else load")
                                }
                            }
                        }
                        adsLayout.visibility = View.GONE
                        imgMain.visibility = View.VISIBLE
                    }
                }
            }

            else{
                findViewById<View>(R.id.cst_money_btn).visibility = View.GONE
                findViewById<View>(R.id.imgplus).visibility = View.GONE
                findViewById<View>(R.id.adsLayout).visibility = View.GONE
                findViewById<View>(R.id.imgMain).visibility = View.VISIBLE
                findViewById<View>(R.id.pro_user).visibility = View.VISIBLE
            }

        }
        else{
            adsLayout!!.visibility=View.GONE
            imgMain!!.visibility=View.VISIBLE
        }

        if (getBoolean(this@MainStartActivity, AdsPrefs.IS_SUBSCRIBED, false)){
            findViewById<View>(R.id.adsLayout).visibility = View.GONE
        }

        Log.d("OfflineAds", "onResume: Call OnResume")
        receiver=object :BroadcastReceiver()
        {
            override fun onReceive(context: Context?, intent: Intent?) {

            }

        }
        registerReceiver(
            receiver,
            IntentFilter("android.net.conn.CONNECTIVITY_CHANGE")
        )
//

        callMoreAPi()
/*
        AdsPrefs.save(this,AdsPrefs.IS_SUBSCRIBED,true);
*/
        SolidWallpaperApplication.staticLanguage.Factory.create(this)


        if (Constants.isLanguageChanged) {
            recreate()
            Constants.isLanguageChanged = false
        }
        val txtCoins = findViewById<TextView>(R.id.txtCoins)
        txtCoins.text = getInt(this, AdsPrefs.WALLET_COINS, 100).toString()
//        if (getBoolean(this, AdsPrefs.IS_SUBSCRIBED, false)) {
//            findViewById<View>(R.id.cst_money_btn).visibility = View.GONE
//            findViewById<View>(R.id.imgplus).visibility = View.GONE
//            findViewById<View>(R.id.adsLayout).visibility = View.GONE
//            findViewById<View>(R.id.imgMain).visibility = View.VISIBLE
//            findViewById<View>(R.id.pro_user).visibility = View.VISIBLE
//        } else {
//            findViewById<View>(R.id.cst_money_btn).visibility = View.VISIBLE
//            findViewById<View>(R.id.adsLayout).visibility = View.VISIBLE
//            findViewById<View>(R.id.imgplus).visibility = View.VISIBLE
//            findViewById<View>(R.id.pro_user).visibility = View.GONE
//        }
        if (is_pause) {
            is_pause = false
        }
        if (!AppIDs.instnace!!.isUpToDate()) {
            Helper().startDataSync(this, this)
        }
    }

    override fun onClick(v: View) {
        if (SystemClock.elapsedRealtime() - lastClickTime < 1500) {
            return
        }
        lastClickTime = SystemClock.elapsedRealtime()
        when (v.id) {
            R.id.btnHdWallpapers -> {

                bundle.clear()
                bundle.putString("home_category","Wallpaper")
                firebaseAnalytics!!.logEvent("solidcolor_click",bundle)

                if (ContextCompat.checkSelfPermission(
                        this@MainStartActivity,
                        Manifest.permission.READ_EXTERNAL_STORAGE
                    )
                    != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(
                        this@MainStartActivity,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    // Permission is not granted
                    ActivityCompat.requestPermissions(
                        this@MainStartActivity,
                        arrayOf(
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                        ),
                        READ_PERMISSION_WEEK
                    )
                } else {
                    startActivity(Intent(this, WallpaperOfWeekNewActivity::class.java))
                }
            }
            R.id.btnPaint -> {
                //solidcolor_click - home_category - [Paint,Create,Wallpaper]
                bundle.clear()
                bundle.putString("home_category","Paint")
                firebaseAnalytics!!.logEvent("solidcolor_click",bundle)
                mAdsType = "Paint"

                // Toast.makeText(MainStartActivity.this, getResources().getString(R.string.we_are_working_on_it), Toast.LENGTH_SHORT).show();
                if (ContextCompat.checkSelfPermission(
                        this@MainStartActivity,
                        Manifest.permission.READ_EXTERNAL_STORAGE
                    )
                    != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(
                        this@MainStartActivity,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    // Permission is not granted
                    ActivityCompat.requestPermissions(
                        this@MainStartActivity,
                        arrayOf(
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                        ),
                        READ_PERMISSION_PAINT
                    )

                } else {

                    if (!getBoolean(this@MainStartActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                        showInterstitial()
                    } else {
                        startActivity(Intent(this, PaintActivity::class.java))
                    }


                }
            }
            R.id.ll_games -> {
                onclickGames()
            }
            R.id.btnCreate -> {
                bundle.clear()
                bundle.putString("home_category","Create")
                firebaseAnalytics!!.logEvent("solidcolor_click",bundle)
                onClickCreate()
            }
            R.id.btnMyCreation -> {
                mAdsType = "Creation"
                onClickMyCreation()
            }
            R.id.cst_money_btn -> {
                com.vasundhara.vision.subscription.constants.Constants.subActivity = "coin"
                startActivity(Intent(this, CoinPurchaseActivity::class.java))
            }
            R.id.btnSettings -> {
                startActivity(Intent(this, SettingsActivity::class.java))
            }
        }
    }



    companion object {
        private const val TAG = "MainStartActivity"
        private const val READ_PERMISSION = 101
        private const val READ_PERMISSION_CREATE = 111
        private const val READ_PERMISSION_WEEK = 123
        private const val READ_PERMISSION_PAINT = 121
        fun getBitmapFromView(view: View): Bitmap {
            val returnedBitmap =
                Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(returnedBitmap)
            val bgDrawable = view.background
            if (bgDrawable != null) bgDrawable.draw(canvas) else canvas.drawColor(Color.WHITE)
            view.draw(canvas)
            return returnedBitmap
        }
    }
}

