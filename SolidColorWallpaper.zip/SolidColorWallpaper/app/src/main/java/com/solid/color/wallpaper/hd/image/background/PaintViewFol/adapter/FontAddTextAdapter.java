package com.solid.color.wallpaper.hd.image.background.PaintViewFol.adapter;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.solid.color.wallpaper.hd.image.background.R;
import com.solid.color.wallpaper.hd.image.background.PaintViewFol.shared_preferences.AdsPrefsForText;
import com.solid.color.wallpaper.hd.image.background.PaintViewFol.shared_preferences.MySharedPrefForText;
import com.solid.color.wallpaper.hd.image.background.PaintViewFol.sqlite_db.DBHelperForText;

import java.util.ArrayList;

public class FontAddTextAdapter extends RecyclerView.Adapter<FontAddTextAdapter.MyViewHolder> {

    private ArrayList<String> mFontNames;
    private Context mContext;
    private FontAddTextAdapter.setOnItemClickListener mListener;
    private int lastCheckedPosition = 0;
    private DBHelperForText dbHelper;
    private MySharedPrefForText sharedPreferences;
    private String mParam;

    public interface setOnItemClickListener {
        void OnItemClicked(int position);
    }

    public FontAddTextAdapter(ArrayList<String> mFontNames, Context mContext, setOnItemClickListener mListener, int position, String mParam2) {
        this.mFontNames = mFontNames;
        this.mContext = mContext;
        this.mListener = mListener;
        this.lastCheckedPosition = position;
        dbHelper = new DBHelperForText(mContext);
        sharedPreferences = new MySharedPrefForText(mContext);
        this.mParam=mParam2;
    }

    @NonNull
    @Override
    public FontAddTextAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new FontAddTextAdapter.MyViewHolder(LayoutInflater.from(mContext).inflate(R.layout.rv_font_item_text, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull FontAddTextAdapter.MyViewHolder myViewHolder, final int i) {
        if (i == 19 && mFontNames.size() == 20) {
            myViewHolder.imgMoreAPI.setVisibility(View.VISIBLE);
            myViewHolder.txtFont.setVisibility(View.GONE);
            myViewHolder.imgMoreAPI.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mListener.OnItemClicked(i);
                }
            });
        } else {
            myViewHolder.imgMoreAPI.setVisibility(View.GONE);
            myViewHolder.txtFont.setVisibility(View.VISIBLE);
            Typeface typeface;
            if (mFontNames.get(i).contains("fonts_neon")){
                typeface = Typeface.createFromAsset(mContext.getAssets(),mFontNames.get(i));
            }else {
                typeface = Typeface.createFromFile(mFontNames.get(i));
            }
            myViewHolder.txtFont.setTypeface(typeface);
            myViewHolder.txtFont.setPadding(0, 0, 0, 0);
            myViewHolder.txtFont.setText("Hello");
            if (!dbHelper.checkPathExist(mFontNames.get(i))  /*&& !sharedPreferences.getAdsRemoved()*/ && !AdsPrefsForText.getBoolean(mContext,AdsPrefsForText.IS_SUBSCRIBED,false)) {
                myViewHolder.imgLock.setVisibility(View.VISIBLE);
            } else {
                myViewHolder.imgLock.setVisibility(View.GONE);
            }
        }
        if (mParam.equals(mFontNames.get(i))) {
            myViewHolder.parentLayout.setBackgroundResource(R.drawable.rectangle_selected);
        } else {
            myViewHolder.parentLayout.setBackgroundResource(R.drawable.rectangle_unselected);
        }
        //myViewHolder.imgColor.setVisibility(View.GONE);
        myViewHolder.txtFont.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.OnItemClicked(i);
                lastCheckedPosition = i;
                mParam=mFontNames.get(i);
                notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return mFontNames.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        public RelativeLayout parentLayout;
        private TextView txtFont;
        private ImageView imgLock, imgMoreAPI;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            txtFont = itemView.findViewById(R.id.txtFont);
            parentLayout = itemView.findViewById(R.id.parentLayout);
            imgLock = itemView.findViewById(R.id.imgLock);
            imgMoreAPI = itemView.findViewById(R.id.imgMoreAPI);

        }
    }
}
