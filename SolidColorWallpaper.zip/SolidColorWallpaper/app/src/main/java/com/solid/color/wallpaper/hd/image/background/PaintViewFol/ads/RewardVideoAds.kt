package com.solid.color.wallpaper.hd.image.background.PaintViewFol.ads

import android.content.Context
import android.util.Log
import com.example.paint_solidcolor.R
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.solid.color.wallpaper.hd.image.background.imagePicker.model.Constant.activity

class RewardVideoAds {

    val TAG = "Ads_123"

    companion object {

        var rewardedAd: RewardedAd? = null
        var rewardedAd1: RewardedAd? = null

        var instence: RewardVideoAds? = null
            get() {
                if (field == null) {
                    field = RewardVideoAds()
                }
                return field
            }
    }

    fun loadVideoAdMain(context: Context): RewardedAd? {
        var reward: RewardedAd? = null
        if (rewardedAd != null) {

            Log.e(TAG, "loadVideoAdMain: rewardedAd", )
            // return rewardedAd!!
            reward = rewardedAd!!
        } else {
            Log.e(TAG, "loadVideoAdMain: rewardedAd else", )

            loadRewardVideoAd(context)
        }
        if (rewardedAd1 != null) {
            //return rewardedAd1!!
            Log.e(TAG, "loadVideoAdMain: rewardedAd1", )

            reward = rewardedAd1!!
        } else {
            Log.e(TAG, "loadVideoAdMain: rewardedAd1 else", )

            loadRewardVideoAd1(context)
        }
        return reward
    }


    fun loadRewardVideoAd(context: Context) {
        if (rewardedAd != null) {
            return
        }


        var adRequest = AdRequest.Builder().build()

        RewardedAd.load(context, context.getString(R.string.rewarded_ad_id), adRequest, object : RewardedAdLoadCallback() {
            override fun onAdFailedToLoad(adError: LoadAdError) {
//                Log.d(WallpaperOfWeekPagerViewActivity.TAG, adError?.message)
                Log.e("hjdasjajsd1=====>", "falied 0  $adError")
                rewardedAd = null
            }

            override fun onAdLoaded(rewardedAd: RewardedAd) {
//                Log.d(WallpaperOfWeekPagerViewActivity.TAG, "Ad was loaded.")
                Log.e("hjdasjajsd1=====>", "loaded 0")
                Companion.rewardedAd = rewardedAd
            }
        })

        rewardedAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                Log.e("hjdasjajsd=====>", "loaded 0")
            }

            override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
                super.onAdFailedToShowFullScreenContent(p0)
                Log.e("hjdasjajsd=====>", "falied 0  $p0")
            }

            override fun onAdShowedFullScreenContent() {

            }
        }

//        rewardedAd = RewardedAd(
//                context,
//                context.getString(R.string.rewarded_ad_id)
//        )
//        val adLoadCallback: RewardedAdLoadCallback = object : RewardedAdLoadCallback() {
//            override fun onRewardedAdLoaded() {
//                Log.e("hjdasjajsd=====>", "loaded 0")
//            }
//
//            override fun onRewardedAdFailedToLoad(errorCode: Int) {
//                /// loadRewardVideoAd(context)
//                Log.e("hjdasjajsd=====>", "falied 0  $errorCode")
//            }
//        }
//        rewardedAd?.loadAd(AdRequest.Builder().build(), adLoadCallback)
    }

    fun loadRewardVideoAd1(context: Context) {
        if (rewardedAd1 != null) {
            return
        }

        var adRequest = AdRequest.Builder().build()

        RewardedAd.load(context, context.getString(R.string.rewarded_ad_id), adRequest, object : RewardedAdLoadCallback() {
            override fun onAdFailedToLoad(adError: LoadAdError) {
//                Log.d(WallpaperOfWeekPagerViewActivity.TAG, adError?.message)
                Log.e("hjdasjajsd1=====>", "falied 0  $adError")
                rewardedAd1 = null
            }

            override fun onAdLoaded(rewardedAd: RewardedAd) {
//                Log.d(WallpaperOfWeekPagerViewActivity.TAG, "Ad was loaded.")
                Log.e("hjdasjajsd1=====>", "loaded 0")
                Companion.rewardedAd1 = rewardedAd
            }
        })

        rewardedAd1?.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                Log.e("hjdasjajsd=====>", "loaded 0")
            }

            override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
                super.onAdFailedToShowFullScreenContent(p0)
                Log.e("hjdasjajsd=====>", "falied 0  $p0")
            }

            override fun onAdShowedFullScreenContent() {

            }
        }

//        rewardedAd1 = RewardedAd(
//                context,
//                context.getString(R.string.rewarded_ad_id)
//        )
//        val adLoadCallback: RewardedAdLoadCallback = object : RewardedAdLoadCallback() {
//            override fun onRewardedAdLoaded() {
//                Log.e("hjdasjajsd=====>", "loaded 1")
//            }
//
//            override fun onRewardedAdFailedToLoad(errorCode: Int) {
//                //  loadRewardVideoAd1(context)
//                Log.e("hjdasjajsd=====>", "failed 1 ${errorCode}")
//            }
//        }
//        rewardedAd1?.loadAd(AdRequest.Builder().build(), adLoadCallback)
    }

    fun checkAdLoad(): RewardedAd? {
        var reward: RewardedAd? = null
        if (rewardedAd != null) {
            // return rewardedAd!!
            reward = rewardedAd!!
        }
        if (rewardedAd1 != null) {
            //return rewardedAd1!!
            reward = rewardedAd1!!
        }

        return reward
    }
}