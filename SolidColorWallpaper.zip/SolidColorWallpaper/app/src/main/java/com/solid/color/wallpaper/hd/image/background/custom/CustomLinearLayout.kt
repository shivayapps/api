package com.solid.color.wallpaper.hd.image.background.custom

import android.content.Context
import android.util.AttributeSet
import android.widget.RelativeLayout
import androidx.coordinatorlayout.widget.CoordinatorLayout

@CoordinatorLayout.DefaultBehavior(MoveUpwardBehavior::class)
class CustomLinearLayout : RelativeLayout {
    constructor(context: Context?) : super(context) {}
    constructor(context: Context?, attrs: AttributeSet?) : super(context, attrs) {}
    constructor(context: Context?, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {}
}