package com.solid.color.wallpaper.hd.image.background.custom

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import com.github.stephenvinouze.materialnumberpickercore.MaterialNumberPicker
import com.solid.color.wallpaper.hd.image.background.R

class TimePickerDialog : DialogFragment {
    private var mListener: OnButtonClickListener? = null
    private var bottomSheetDialog: Dialog? = null

    constructor() {}
    constructor(mListener: OnButtonClickListener?) {
        this.mListener = mListener
    }

    interface OnButtonClickListener {
        fun onPositive(bottomSheetDialo: TimePickerDialog?, time: String?)
        fun onNegative(bottomSheetDialog: TimePickerDialog?)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NO_TITLE, R.style.materialButton)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.dialog_time_picker, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val np_min: MaterialNumberPicker = view.findViewById(R.id.np_min)
        val np_hour: MaterialNumberPicker = view.findViewById(R.id.np_hour)
        view.findViewById<View>(R.id.btnOk).setOnClickListener { v: View? ->
            val min = np_min.value
            val hour = np_hour.value
            Log.d("7812123123312", "onViewCreated: $min  $hour")
            if (min == 0 && hour == 0) {
                Toast.makeText(activity, "Select valid time.", Toast.LENGTH_SHORT).show()
            } else {
                var min1 = ""
                min1 = if (min < 10) {
                    "0$min"
                } else {
                    "" + min
                }
                var hour1 = ""
                hour1 = if (hour < 10) {
                    "0$hour"
                } else {
                    "" + hour
                }
                val time = "$hour1:$min1:00 Hour"
                mListener!!.onPositive(this@TimePickerDialog, time)
            }
        }
        view.findViewById<View>(R.id.btnCancel).setOnClickListener { v: View? -> mListener!!.onNegative(this@TimePickerDialog) }
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        bottomSheetDialog = dialog
        // ((View) getView().getParent()).setPadding(0,0,0,);
        val displayMetrics = DisplayMetrics()
        activity!!.windowManager.defaultDisplay.getMetrics(displayMetrics)
        val height = displayMetrics.heightPixels
        var width = displayMetrics.widthPixels
        width -= width / 8
        bottomSheetDialog!!.window!!.setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT)
        // setColoredNavBar(true);
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = super.onCreateDialog(savedInstanceState)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            //setWhiteNavigationBar(dialog);
        }
        return dialog
    }

    override fun onStart() {
        super.onStart()
    }
}