package com.solid.color.wallpaper.hd.image.background.fragment

//import com.google.android.gms.ads.rewarded.RewardedAdCallback
import android.app.Activity
import android.content.DialogInterface
import android.content.Intent
import android.content.res.Resources
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.PagerSnapHelper
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.SnapHelper
import com.airbnb.lottie.LottieAnimationView
import com.andrefrsousa.superbottomsheet.SuperBottomSheetFragment
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.NetworkHelper
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.wifi_network.exceptions.ApiNotSupportedException
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.wifi_network.exceptions.NullWifiConfigurationException
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.wifi_network.wifi_proxy_changing_realisations.api_from_21_to_22.WifiConfiguration
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.OnUserEarnedRewardListener
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.material.tabs.TabLayout
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.SolidWallpaperApplication.Companion.instance
import com.solid.color.wallpaper.hd.image.background.activity.CoinPurchaseActivity
import com.solid.color.wallpaper.hd.image.background.activity.GifLiveWallPaper
import com.solid.color.wallpaper.hd.image.background.adapter.RecyclerSnapStickerAdapter
import com.solid.color.wallpaper.hd.image.background.adshalper.RewardVideoAds.Companion.instence
import com.solid.color.wallpaper.hd.image.background.adshalper.RewardVideoAds.Companion.rewardedAd
import com.solid.color.wallpaper.hd.image.background.adshalper.RewardVideoAds.Companion.rewardedAd1
import com.solid.color.wallpaper.hd.image.background.model.CategoryNameIconModel
import com.solid.color.wallpaper.hd.image.background.model.WallpaperWeekModel
import com.solid.color.wallpaper.hd.image.background.model.api.DataItem
import com.solid.color.wallpaper.hd.image.background.model.api.ImageItem
import com.solid.color.wallpaper.hd.image.background.model.api.Response
import com.solid.color.wallpaper.hd.image.background.newModel.ImagesItem
import com.solid.color.wallpaper.hd.image.background.newModel.WallpaperWeekModelNewResponse
import com.solid.color.wallpaper.hd.image.background.retrofit.APIClient.client
import com.solid.color.wallpaper.hd.image.background.retrofit.APIInterface
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs.getBoolean
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs.getInt
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs.save
import com.solid.color.wallpaper.hd.image.background.shared_pref.MySharedPref
import com.solid.color.wallpaper.hd.image.background.sqlite_database.DBHelper
import com.solid.color.wallpaper.hd.image.background.sqlite_database.DBHelperSuscription
import retrofit2.Call
import retrofit2.Callback
import java.lang.reflect.InvocationTargetException
import java.util.*

class BottomsheetStickerCategoryFragment : SuperBottomSheetFragment {
    private var progressBar: ProgressBar? = null
    private var mTempForgroundList: ArrayList<WallpaperWeekModelNewResponse?>? = null
    private var apiInterface: APIInterface? = null
    private var mDataList: ArrayList<DataItem>? = null
    private var mDataListNew: ArrayList<com.solid.color.wallpaper.hd.image.background.newModel.DataItem>? = null

    private var path: String? = null
    private var onItemSelected: OnItemSelected? = null
    private var icBack: ImageView? = null
    private var btnShare: ImageView? = null
    private var btnAd: LottieAnimationView? = null
    private var mySharedPref: MySharedPref? = null
    private var dbHelper: DBHelper? = null
    private var dbHelperSuscription: DBHelperSuscription? = null
    private var adLayout: RelativeLayout? = null
    private var mAContext: Activity? = null

    //  private ViewPager viewPagerScreen;
    private var recyclerSnap: RecyclerView? = null
    private var tabLayoutScreen: TabLayout? = null
    private var snapAdapter: RecyclerSnapStickerAdapter? = null
    private var mAllReadyData: ArrayList<ArrayList<WallpaperWeekModelNewResponse?>?>? = null
    private var categoryNameList: ArrayList<String?>? = null
    private var isAdShows: Boolean = false
    private val gameOverRewardedAd: RewardedAd? = null
    private val gameOverRewardedAd2: RewardedAd? = null
    private val gameOverRewardedAd3: RewardedAd? = null

    constructor() {
        // Required empty public constructor
    }

    constructor(mDataList: ArrayList<ArrayList<WallpaperWeekModelNewResponse?>?>?, categoryNameList: ArrayList<String?>?, onItemSelected: OnItemSelected?) {
        mAllReadyData = mDataList
        this.onItemSelected = onItemSelected
        this.categoryNameList = categoryNameList
    }

    public override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                                     savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        super.onCreateView(inflater, container, savedInstanceState)
        return inflater.inflate(R.layout.fragment_bottomsheet_sticker_category, container, false)
    }

    public override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        mAContext = activity
        dbHelper = DBHelper(mAContext)
        dbHelperSuscription = DBHelperSuscription(mAContext)
        btnAd = view.findViewById(R.id.btnAd)
        icBack = view.findViewById(R.id.icBack)
        btnShare = view.findViewById(R.id.btnShare)
        adLayout = view.findViewById(R.id.adLayout)
        tabLayoutScreen = view.findViewById(R.id.tabLayoutScreen)
        //  viewPagerScreen = view.findViewById(R.id.viewPagerScreen);
        recyclerSnap = view.findViewById(R.id.recyclerSnap)
        mySharedPref = MySharedPref(mAContext)
        if ( /*!mySharedPref.getAdsRemoved() &&*/!getBoolean(mAContext, AdsPrefs.IS_SUBSCRIBED, false)) {
            adLayout!!.visibility = View.GONE
            btnShare!!.visibility = View.VISIBLE
            loadInterstialAd()
            /*       gameOverRewardedAd = createAndLoadRewardedAd(getResources().getString(R.string.rewarded_ad_id));
            gameOverRewardedAd2 = createAndLoadRewardedAd(getResources().getString(R.string.rewarded_ad_id));
            gameOverRewardedAd3 = createAndLoadRewardedAd(getResources().getString(R.string.rewarded_ad_id));*/
            /*  assert RewardVideoAds.Companion.getInstence() != null;
            RewardVideoAds.Companion.getInstence().loadVideoAdMain(getActivity());*/loadRewardAds()
        } else {
            adLayout!!.visibility = View.GONE
            btnShare!!.visibility = View.VISIBLE
        }
        progressBar = view.findViewById(R.id.progressBar)
        icBack!!.setOnClickListener { dismiss() }
        btnAd!!.setOnClickListener { showAd() }
        btnShare!!.setOnClickListener { shareOwnApp() }
        mDataList = ArrayList()
        Handler().postDelayed({
            if (mAllReadyData != null && mAllReadyData!!.size <= 0) {
                mAllReadyData = ArrayList()
                try {
                    checkStatus()
                } catch (e: InvocationTargetException) {
                    e.printStackTrace()
                } catch (e: NoSuchMethodException) {
                    e.printStackTrace()
                } catch (e: ApiNotSupportedException) {
                    e.printStackTrace()
                } catch (e: NoSuchFieldException) {
                    e.printStackTrace()
                } catch (e: IllegalAccessException) {
                    e.printStackTrace()
                } catch (e: NullWifiConfigurationException) {
                    callApi()
                    e.printStackTrace()
                }
            } else {
                setData()
            }
        }, 0)
    }

    private fun shareOwnApp() {
        val shareIntent: Intent = Intent(Intent.ACTION_SEND)
        shareIntent.type = "text/plain"
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Solid Color Wallpaper")
        var shareMessage: String = ""
        shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=com.solid.color.wallpaper.hd.image.background"
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
        startActivity(Intent.createChooser(shareIntent, getResources().getString(R.string.choose_one)))
    }

    private fun showAd() {
        if (instance!!.requestNewInterstitial()) {

            instance!!.mInterstitialAd!!.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
//                    Log.d(TAG, 'Ad was dismissed.')
                    loadInterstialAd()

                }

                override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
                    super.onAdFailedToShowFullScreenContent(p0)
//                    loadInterstialAdFb()
                }

                override fun onAdShowedFullScreenContent() {
//                    Log.d(TAG, 'Ad showed fullscreen content.')
                    instance!!.mInterstitialAd = null;
                }
            }
            instance!!.mInterstitialAd!!.show(requireActivity())

//            instance!!.mInterstitialAd!!.adListener = object : AdListener() {
//                public override fun onAdClosed() {
//                    super.onAdClosed()
//                    loadInterstialAd()
//                }
//
//                public override fun onAdFailedToLoad(i: Int) {
//                    super.onAdFailedToLoad(i)
//                }
//
//                public override fun onAdLoaded() {
//                    super.onAdLoaded()
//                }
//            }
        } else {
            Toast.makeText(mAContext, "Try again later.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setData() {
        if (mAllReadyData != null && mAllReadyData!!.size > 0) {
            for (i in categoryNameList!!.indices) {
                tabLayoutScreen!!.addTab(tabLayoutScreen!!.newTab().setText(categoryNameList!![i]))
            }
            tabLayoutScreen!!.tabGravity = TabLayout.GRAVITY_CENTER
            val manager: LinearLayoutManager = object : LinearLayoutManager(mAContext, HORIZONTAL, false) {
                public override fun canScrollHorizontally(): Boolean {
                    return false
                }
            }
            recyclerSnap!!.layoutManager = manager
            val snapHelper: SnapHelper = PagerSnapHelper()
            snapHelper.attachToRecyclerView(recyclerSnap)
            /*    CategoryScreenPagerAdapter pagerAdapter = new CategoryScreenPagerAdapter(getChildFragmentManager(), mAllReadyData);
            viewPagerScreen.setAdapter(pagerAdapter);
            viewPagerScreen.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

                }

                @Override
                public void onPageSelected(int position) {
                    System.gc();
                    Runtime.getRuntime().gc();
                }

                @Override
                public void onPageScrollStateChanged(int state) {

                }
            });
            viewPagerScreen.setOffscreenPageLimit(6);
            tabLayoutScreen.setupWithViewPager(viewPagerScreen);*/

            /*       recyclerSnap.addOnScrollListener(new RecyclerView.OnScrollListener() {

                @Override
                public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                    super.onScrollStateChanged(recyclerView, newState);
                    Log.e("Snapped Item Position:", "onScrollStateChanged: ");
                    // if (newState == RecyclerView.SCROLL_STATE_IDLE) {
                    View centerView = snapHelper.findSnapView(manager);
                    int pos = manager.getPosition(centerView);
                    Log.e("Snapped Item Position:", "" + pos);
                    try {
                        //tabLayoutScreen.setScrollPosition(position,0f,true);
                        tabLayoutScreen.getTabAt(pos).select();
                    } catch (Exception e) {
                        e.printStackTrace();
                        //       }
                    }
                }
            });*/
            val onItemChanged: RecyclerSnapStickerAdapter.OnItemChanged = object : RecyclerSnapStickerAdapter.OnItemChanged {
                override fun onItemChanged(position: Int) {}
                override fun onItemSelect(model: WallpaperWeekModelNewResponse?) {
                    /*  if (model.isPremium()) {
                        path = null;
                        dismiss();
                        startActivity(new Intent(mAContext, PremiumAccessActivity.class));
                    } else*/
                    if (!model!!.isLocked) {
                        path = model.imageItem!!.image
                        dismiss()
                    } else {
                        if (!NetworkHelper.isOnline(mAContext)) {
                            Toast.makeText(mAContext, getResources().getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show()
                            return
                        }
                        if (rewardedAd != null) {
                            //  RewardedAd rewardedAd=RewardVideoAds.Companion.getInstence().loadVideoAdMain(getActivity());
                            showAdDialog(model, rewardedAd)
                        } else if (rewardedAd1 != null) {
                            //  RewardedAd rewardedAd=RewardVideoAds.Companion.getInstence().loadVideoAdMain(getActivity());
                            showAdDialog(model, rewardedAd1)
                        } else {
                            /*  assert RewardVideoAds.Companion.getInstence() != null;
                            RewardVideoAds.Companion.getInstence().loadVideoAdMain(getActivity());*/
                            //  loadRewardAds();
                            Log.e("TAG", "onItemSelect: ghdkshfdhsdfsghdjkgndsfg" )
                            Toast.makeText(mAContext, getResources().getString(R.string.try_again_later), Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
            tabLayoutScreen!!.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
                override fun onTabSelected(tab: TabLayout.Tab) {
                    recyclerSnap!!.scrollToPosition(tab.position)
                    if (tabLayoutScreen!!.getTabAt(tab.position) != null) {
                        tabLayoutScreen!!.getTabAt(tab.position)!!.select()
                    }
                }

                override fun onTabUnselected(tab: TabLayout.Tab) {}
                override fun onTabReselected(tab: TabLayout.Tab) {}
            })
            snapAdapter = RecyclerSnapStickerAdapter(mAllReadyData!!, mAContext!!, onItemChanged)
            recyclerSnap!!.adapter = snapAdapter
            for (i in mAllReadyData!!.indices) {
                try {
                    tabLayoutScreen!!.getTabAt(i)!!.text = categoryNameList!![i]
                    val view: View = LayoutInflater.from(mAContext).inflate(R.layout.rv_tab, null)
                    tabLayoutScreen!!.getTabAt(i)!!.customView = view
                    val textView: TextView = view.findViewById(R.id.textTab)
                    textView.text = categoryNameList!![i]
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            Handler().postDelayed({
                tabLayoutScreen!!.visibility = View.VISIBLE
                //  viewPagerScreen.setVisibility(View.VISIBLE);
                recyclerSnap!!.visibility = View.VISIBLE
                progressBar!!.visibility = View.GONE
            }, 1000)
        } else {
            try {
                checkStatus()
            } catch (e: InvocationTargetException) {
                e.printStackTrace()
            } catch (e: NoSuchMethodException) {
                e.printStackTrace()
            } catch (e: ApiNotSupportedException) {
                e.printStackTrace()
            } catch (e: NoSuchFieldException) {
                e.printStackTrace()
            } catch (e: IllegalAccessException) {
                e.printStackTrace()
            } catch (e: NullWifiConfigurationException) {
                callApi()
                e.printStackTrace()
            }
        }
    }

    private fun loadRewardAds() {
        if (rewardedAd != null) {
            assert(instence != null)
            instence!!.loadRewardVideoAd((activity)!!)
        }
        if (rewardedAd1 != null) {
            assert(instence != null)
            instence!!.loadRewardVideoAd1((activity)!!)
        }
    }

    private fun showAdDialog(model: WallpaperWeekModelNewResponse, rewardedAd: RewardedAd?) {
        val watchAdDialogFragment: WatchAdDialogFragment = WatchAdDialogFragment(object : WatchAdDialogFragment.OnButtonClickListener {
            public override fun onPositive(bottomSheetDialo: WatchAdDialogFragment, isNoMoreCoin: Boolean) {
                val coins: Int = getInt(activity, AdsPrefs.WALLET_COINS, 100)
                if (coins < model.coins) {
                    val noEnoughCoinDialogFragment: NoEnoughCoinDialogFragment = NoEnoughCoinDialogFragment(object : NoEnoughCoinDialogFragment.OnButtonClickListener {
                        public override fun onPositive(bottomSheetDialo: NoEnoughCoinDialogFragment) {
                            com.vasundhara.vision.subscription.constants.Constants.subActivity = "coin"
                            startActivity(Intent(mAContext, CoinPurchaseActivity::class.java))
                            bottomSheetDialo.dismiss()
                            dismiss()
                        }

                        public override fun onNegative(bottomSheetDialog: NoEnoughCoinDialogFragment) {
                            bottomSheetDialog.dismiss()
                        }
                    }, getResources().getString(R.string.no_enough_coin))
                    noEnoughCoinDialogFragment.show(activity!!.supportFragmentManager, "dialog_no")
                } else {
                    save(mAContext, AdsPrefs.WALLET_COINS, coins - model.coins)
                    dbHelper!!.insertPath((model.imageItem!!.image)!!)
                    model.isLocked = false
                    path = model.imageItem!!.image
                    dismiss()
                }
                bottomSheetDialo.dismiss()
            }

            public override fun onNegative(bottomSheetDialog: WatchAdDialogFragment, iswatchadavalable: Boolean) {
                bottomSheetDialog.dismiss()
                if (rewardedAd != null) {
                    showAdReward(model, rewardedAd)
                } else if (gameOverRewardedAd2 !== null) {
                    showAdReward(model, gameOverRewardedAd2)
                } else if (gameOverRewardedAd3 != null) {
                    showAdReward(model, gameOverRewardedAd3)
                } else {
                    assert(instence != null)
                    try {
                        if (instance != null) {
                            instence!!.loadVideoAdMain((activity)!!)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                    //   loadRewardAds();
                    Log.e("TAG", "onItemSelect: ghdkshfdhsdhsdjklfhs sfsghdjkgndsfg" )

                    Toast.makeText(mAContext, getResources().getString(R.string.try_again_later), Toast.LENGTH_SHORT).show()
                }
            }
        }, java.lang.String.valueOf(model.coins))
        watchAdDialogFragment.show(requireActivity().supportFragmentManager, "dialog")


        /*
        BottomSheetFragment bottomSheetFragment = new BottomSheetFragment(getResources().getString(R.string.watch_video), getResources().getString(R.string.wathch_video_to_unlock_screen), getResources().getString(R.string.watch), getResources().getString(R.string.cancel), R.drawable.ic_video, new BottomSheetFragment.OnButtonClickListener() {
            @Override
            public void onPositive(BottomSheetFragment bottomSheetDialo) {
                bottomSheetDialo.dismiss();

                if (rewardedAd.isLoaded()) {
                    showAdReward(model, rewardedAd);
                } else if (gameOverRewardedAd2.isLoaded()) {
                    showAdReward(model, gameOverRewardedAd2);
                } else if (gameOverRewardedAd3.isLoaded()) {
                    showAdReward(model, gameOverRewardedAd3);
                } else {
                    assert RewardVideoAds.Companion.getInstence() != null;
                    RewardVideoAds.Companion.getInstence().loadVideoAdMain(getActivity());
                 //   loadRewardAds();
                    Toast.makeText(mAContext, getResources().getString(R.string.try_again_later), Toast.LENGTH_SHORT).show();
                }

                //  showAdReward(position,model, gameOverRewardedAd3);
            }

            @Override
            public void onNegative(BottomSheetFragment bottomSheetDialog) {
                bottomSheetDialog.dismiss();
            }
        });
        bottomSheetFragment.show(getActivity().getSupportFragmentManager(), "dialog");*/
    }

    fun showAdReward(model: WallpaperWeekModelNewResponse, gameOverRewa: RewardedAd?) {
        isAdShows = true
        if (gameOverRewa != null) {

            rewardedAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    loadRewardAds()
                    isAdShows = false
                }

                override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
                    super.onAdFailedToShowFullScreenContent(p0)
                    loadRewardAds()

                    //   showSnackBar(getResources().getString(R.string.something_went_wrong));
                    Log.e("TAG", "onItemSelect: ghdkshdsfiughiudhfgdhfdhsdhsdjklfhs sfsghdjkgndsfg" )

                    Toast.makeText(mAContext, getResources().getString(R.string.try_again_later), Toast.LENGTH_SHORT).show()
                    isAdShows = false

                }

                override fun onAdShowedFullScreenContent() {
                    loadRewardAds()
                    rewardedAd = null
                    rewardedAd1 = null
                    isAdShows = true
                }
            }

            gameOverRewa.show(requireActivity(), OnUserEarnedRewardListener() {
                // User earned reward.
                dbHelper!!.insertPath((model.imageItem!!.image)!!)
                model.isLocked = false
                path = model.imageItem!!.image
                dismiss()

                /*    assert RewardVideoAds.Companion.getInstence() != null;
                RewardVideoAds.Companion.getInstence().loadVideoAdMain(getActivity());*/
                loadRewardAds()
                isAdShows = false
                Log.d(GifLiveWallPaper.TAG, "User earned the reward.")
            })

//            val adCallback: RewardedAdCallback = object : RewardedAdCallback() {
//                public override fun onRewardedAdOpened() {
//                    // Ad opened.
//                    isAdShows = true
//                }
//
//                public override fun onRewardedAdClosed() {
//                    // Ad closed.
//                    /* gameOverRewardedAd = createAndLoadRewardedAd(getResources().getString(R.string.rewarded_ad_id));
//                    gameOverRewardedAd2 = createAndLoadRewardedAd(getResources().getString(R.string.rewarded_ad_id));
//                    gameOverRewardedAd3 = createAndLoadRewardedAd(getResources().getString(R.string.rewarded_ad_id));*/
//                    /*     assert RewardVideoAds.Companion.getInstence() != null;
//                    RewardVideoAds.Companion.getInstence().loadVideoAdMain(getActivity());*/
//                    loadRewardAds()
//                    isAdShows = false
//                }
//
//                public override fun onUserEarnedReward(reward: RewardItem) {
//                    // User earned reward.
//                    dbHelper!!.insertPath((model.imageItem!!.image)!!)
//                    model.isLocked = false
//                    path = model.imageItem!!.image
//                    dismiss()
//
//                    /*    assert RewardVideoAds.Companion.getInstence() != null;
//                    RewardVideoAds.Companion.getInstence().loadVideoAdMain(getActivity());*/loadRewardAds()
//                    isAdShows = false
//                }
//
//                public override fun onRewardedAdFailedToShow(errorCode: Int) {
//                    // Ad failed to display.
//                    /*   assert RewardVideoAds.Companion.getInstence() != null;
//                    RewardVideoAds.Companion.getInstence().loadVideoAdMain(getActivity());*/
//                    loadRewardAds()
//
//                    //   showSnackBar(getResources().getString(R.string.something_went_wrong));
//                    Toast.makeText(mAContext, getResources().getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
//                    isAdShows = false
//                }
//            }
//            gameOverRewa.show(mAContext, adCallback)
        } else {
            isAdShows = false
            //showSnackBar(getResources().getString(R.string.something_went_wrong));
            Toast.makeText(mAContext, getResources().getString(R.string.try_again_later), Toast.LENGTH_SHORT).show()
        }
    }

    fun createAndLoadRewardedAd(adUnitId: String?): RewardedAd {
//        val rewardedAd: RewardedAd = RewardedAd(mAContext, adUnitId)

        var mRewardedAd: RewardedAd? = null

        var adRequest = AdRequest.Builder().build()

        RewardedAd.load(requireContext(), adUnitId, adRequest, object : RewardedAdLoadCallback() {
            override fun onAdFailedToLoad(adError: LoadAdError) {
//                Log.d(WallpaperOfWeekPagerViewActivity.TAG, adError?.message)
                mRewardedAd = null
            }

            override fun onAdLoaded(rewardedAd: RewardedAd) {
//                Log.d(WallpaperOfWeekPagerViewActivity.TAG, "Ad was loaded.")
                mRewardedAd = rewardedAd
            }
        })

//        val adLoadCallback: RewardedAdLoadCallback = object : RewardedAdLoadCallback() {
//            public override fun onRewardedAdLoaded() {
//                // Ad successfully loaded.
//            }
//
//            public override fun onRewardedAdFailedToLoad(errorCode: Int) {
//                // Ad failed to load.
//            }
//        }
//        rewardedAd.loadAd(AdRequest.Builder().build(), adLoadCallback)
        return mRewardedAd!!
    }

    public override fun onCancel(dialog: DialogInterface) {
        super.onCancel(dialog)
    }

    public override fun onDismiss(dialog: DialogInterface) {
        super.onDismiss(dialog)
        if (onItemSelected != null) {
            onItemSelected!!.onDismiss()
        }
        if (path != null && onItemSelected != null) {
            onItemSelected!!.onItemSelected(path)
        }
    }

    open interface OnItemSelected {
        fun onItemSelected(path: String?)
        fun onDismiss()
    }

    private fun dpToPx(dp: Int): Int {
        val r: Resources = resources
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), r.displayMetrics))
    }

    @Throws(InvocationTargetException::class, NoSuchMethodException::class, ApiNotSupportedException::class, NoSuchFieldException::class, IllegalAccessException::class, NullWifiConfigurationException::class)
    private fun checkStatus() {
        if (!NetworkHelper.isOnline(mAContext)) {
            tabLayoutScreen!!.visibility = View.GONE
            recyclerSnap!!.visibility = View.GONE
            //viewPagerScreen.setVisibility(View.GONE);
            progressBar!!.visibility = View.GONE
            Toast.makeText(mAContext, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show()
            dismiss()
        } else {
            if (NetworkHelper.isWifiConnected(mAContext)) {
                val proxy: WifiConfiguration = WifiConfiguration(mAContext)
                if (proxy.isProxySetted) {
                    tabLayoutScreen!!.visibility = View.GONE
                    recyclerSnap!!.visibility = View.GONE
                    // viewPagerScreen.setVisibility(View.GONE);
                    progressBar!!.visibility = View.GONE
                    Toast.makeText(mAContext, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show()
                    dismiss()
                    return
                }
            }
            if (NetworkHelper.isVpnRunning()) {
                tabLayoutScreen!!.visibility = View.GONE
                recyclerSnap!!.visibility = View.GONE
                //  viewPagerScreen.setVisibility(View.GONE);
                progressBar!!.visibility = View.GONE
                Toast.makeText(mAContext, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show()
                dismiss()
                return
            }
            callApi()
        }
    }



    fun callNewApi() {
        apiInterface = client!!.create(APIInterface::class.java)
        val call: Call<com.solid.color.wallpaper.hd.image.background.newModel.Response?>? = apiInterface!!.doGetNewListResources()
        call!!.enqueue(object : Callback<com.solid.color.wallpaper.hd.image.background.newModel.Response?> {

            override fun onResponse(call: Call<com.solid.color.wallpaper.hd.image.background.newModel.Response?>, response: retrofit2.Response<com.solid.color.wallpaper.hd.image.background.newModel.Response?>) {
                val model: com.solid.color.wallpaper.hd.image.background.newModel.Response? = response.body()
                mDataListNew!!.clear()

                if (model?.data != null) {
                    mDataListNew!!.addAll(model.data)
                    updateNewUI()
                } else {
                    Toast.makeText(mAContext, getResources().getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
                    dismiss()
                }
            }

            override fun onFailure(call: Call<com.solid.color.wallpaper.hd.image.background.newModel.Response?>, t: Throwable) {
                Toast.makeText(mAContext, getResources().getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
                dismiss()
            }
        })
    }

    fun callApi() {
        apiInterface = client!!.create(APIInterface::class.java)
        val call: Call<Response?>? = apiInterface!!.doGetListResources()
        call!!.enqueue(object : Callback<Response?> {
            public override fun onResponse(call: Call<Response?>, response: retrofit2.Response<Response?>) {
                val model: Response? = response.body()
                mDataList!!.clear()
                if (model != null && model.data != null) {
                    mDataList!!.addAll(model.data)
//                    updateUI()
                } else {
                    Toast.makeText(mAContext, getResources().getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
                    dismiss()
                }
            }

            public override fun onFailure(call: Call<Response?>, t: Throwable) {
                Toast.makeText(mAContext, getResources().getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
                dismiss()
            }
        })
    }

    public override fun onPause() {
        super.onPause()
        if (!isAdShows) {
            dismiss()
        }
    }

    private fun loadInterstialAd() {
        if (instance!!.mInterstitialAd != null) {
            adLayout!!.visibility = View.VISIBLE
            btnShare!!.visibility = View.GONE
        } else {
            if (instance!!.mInterstitialAd != null) {
                instance!!.mInterstitialAd!!.fullScreenContentCallback = null
                instance!!.mInterstitialAd = null
                instance!!.ins_adRequest = null
                instance!!.LoadAds()

                instance!!.mInterstitialAd!!.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
//                    Log.d(TAG, 'Ad was dismissed.')
                    }

                    override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
                        super.onAdFailedToShowFullScreenContent(p0)
                        adLayout!!.visibility = View.GONE
                        btnShare!!.visibility = View.VISIBLE
                        loadInterstialAd()
                    }

                    override fun onAdShowedFullScreenContent() {
//                    Log.d(TAG, 'Ad showed fullscreen content.')
                        adLayout!!.visibility = View.VISIBLE
                        btnShare!!.visibility = View.GONE
                    }
                }
                instance!!.mInterstitialAd!!.show(requireActivity())

//            instance!!.mInterstitialAd!!.adListener = object : AdListener() {
//                public override fun onAdLoaded() {
//                    super.onAdLoaded()
//                    adLayout!!.visibility = View.VISIBLE
//                    btnShare!!.visibility = View.GONE
//                }
//
//                public override fun onAdFailedToLoad(i: Int) {
//                    super.onAdFailedToLoad(i)
//                    adLayout!!.visibility = View.GONE
//                    btnShare!!.visibility = View.VISIBLE
//                    loadInterstialAd()
//                }
//            }
            }
        }
    }

    private fun updateNewUI() {
        mAllReadyData = ArrayList()
        if (mDataListNew!!.size == 0) {
            dismiss()
            return
        }

        categoryNameList = ArrayList()


        for (i in mDataListNew!!.indices) {
            val mForegroundList: ArrayList<ImagesItem?> = ArrayList()


            if (mDataListNew!![i].name!! == "Sticker"){


                for (j in mDataListNew!![i].allChilds!!.indices){
                    Log.e("TAG", "assaasdasadsas: ${mDataListNew!![i].allChilds?.get(j)!!.name} ${mDataListNew!![i].allChilds?.get(j)!!.icon}   ")
                    categoryNameList!!.add(mDataListNew!![i].allChilds?.get(i)!!.name!!)
                    mForegroundList!!.addAll((mDataListNew!![i].allChilds?.get(j)!!.images)!!)

                }

                val mWallpaperList1: ArrayList<WallpaperWeekModelNewResponse?> = ArrayList()
                for (j in mForegroundList!!.indices) {
                    mWallpaperList1.add(
                            WallpaperWeekModelNewResponse(
                                    mForegroundList!![j],
                                    mForegroundList!![j]!!.isPremium != 0,
                                    mForegroundList!![j]!!.coins!!
                            )
                    )
                }

                mTempForgroundList = ArrayList()

                if (getBoolean(mAContext, AdsPrefs.IS_SUBSCRIBED, false)) {
                    for (j in mWallpaperList1.indices) {
                        mWallpaperList1[j]!!.isLocked = false
                    }
                    mTempForgroundList!!.addAll(mWallpaperList1)
                } else {
                    for (k in mWallpaperList1.indices) {
                        val model: WallpaperWeekModelNewResponse? = mWallpaperList1[k]
                        if (dbHelper!!.checkPathExist((model!!.imageItem!!.image)!!)) {
                            model.isLocked = false
                        }
                        mTempForgroundList!!.add(model)
                    }
                }
                mTempForgroundList!!.shuffle()
                mAllReadyData!!.add(mTempForgroundList!!)

            }


        }
        setData()

    }

//    private fun updateUI() {
//        mAllReadyData = ArrayList()
//        if (mDataList!!.size == 0) {
//            dismiss()
//            return
//        }
//        if (mDataList!!.size > 3) {
//        } else {
//            dismiss()
//            return
//        }
//        categoryNameList = ArrayList()
//        for (i in mDataList!!.indices) {
//            val mForegroundList: ArrayList<ImageItem> = ArrayList()
//            mForegroundList.addAll((mDataList!![i].image)!!)
//            if (mDataList!![i].name!!.contains("_Sticker")) {
//                val name: Array<String> = mDataList!![i].name!!.split("_".toRegex()).toTypedArray()
//                if (name.isEmpty()) {
//                    categoryNameList!!.add(mDataList!![i].name)
//                } else {
//                    categoryNameList!!.add(name[name.size - 1])
//                }
//                val mWallpaperList: ArrayList<WallpaperWeekModelNewResponse> = ArrayList()
//                for (j in mForegroundList.indices) {
//                    mWallpaperList.add(WallpaperWeekModel(mForegroundList[j], mForegroundList[j].isPremium != 0, mForegroundList[j].coins))
//                }
//
//                /*  if (mDataList.get(i).getName().contains("Popular") || mDataList.get(i).getName().contains("Special")) {
//                    mTempForgroundList = new ArrayList<>();
//
//                    if (AdsPrefs.getBoolean(mAContext, AdsPrefs.IS_SUBSCRIBED, false)) {
//                        mTempForgroundList.addAll(mWallpaperList);
//                    } else {
//                        for (WallpaperWeekModel model :
//                                mWallpaperList) {
//                            model.setFree(false);
//                            model.setPremium(true);
//                            mTempForgroundList.add(model);
//                        }
//                    }
//                } else {*/mTempForgroundList = ArrayList()
//                if (mAContext != null && getBoolean(mAContext, AdsPrefs.IS_SUBSCRIBED, false)) {
//                    mTempForgroundList!!.addAll(mWallpaperList)
//                } else {
//                    dbHelperSuscription!!.deleteAllData()
//
//                    /*  if (mWallpaperList.size() >= 6) {
//                            for (int l = 0; l < 6; l++) {
//                                mTempForgroundList.add(mWallpaperList.get(l));
//                            }
//
//
//                        } else {
//                            mTempForgroundList.addAll(mWallpaperList);
//                            mWallpaperList.clear();
//                        }
//
//                        boolean flag = true;
//                        int conter = 0;
//                        int counterPrem = 0;*/
//
//                    for (k in mWallpaperList.indices) {
//                        val model: WallpaperWeekModel = mWallpaperList[k]
//                        if (dbHelper!!.checkPathExist((model.imageItem!!.image)!!)) {
//                            model.isLocked = false
//                        }
//                        mTempForgroundList!!.add(model)
//
//                        /*    if (dbHelper.checkPathExist(model.getImageItem().getImage())) {
//                                model.setFree(true);
//                                model.setLocked(false);
//                            } else {
//                                model.setLocked(true);
//                                model.setFree(false);
//                            }
//                            mTempForgroundList.add(model);*/
//                    }
//                }
//                // }
//                mAllReadyData!!.add(mTempForgroundList!!)
//            }
//        }
//        setData()
//    }
}