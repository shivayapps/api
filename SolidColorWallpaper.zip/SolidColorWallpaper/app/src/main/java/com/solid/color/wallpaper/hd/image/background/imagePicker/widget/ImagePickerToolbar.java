package com.solid.color.wallpaper.hd.image.background.imagePicker.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.widget.AppCompatImageView;

import com.solid.color.wallpaper.hd.image.background.R;
import com.solid.color.wallpaper.hd.image.background.imagePicker.model.Config;


public class ImagePickerToolbar extends RelativeLayout {

    private TextView titleText;
    private ImageView doneText;
    private AppCompatImageView backImage;

    public ImagePickerToolbar(Context context) {
        super(context);
        init(context);
    }

    public ImagePickerToolbar(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public ImagePickerToolbar(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        View.inflate(context, R.layout.imagepicker_toolbar, this);
        if (isInEditMode()) {
            return;
        }

        titleText = findViewById(R.id.text_toolbar_title);
        doneText = findViewById(R.id.text_toolbar_done);
        backImage = findViewById(R.id.image_toolbar_back);
    }

    public void config(Config config) {
        setBackgroundColor(config.getToolbarColor());

        titleText.setText(config.isFolderMode() ? config.getFolderTitle() : config.getImageTitle());
        titleText.setTextColor(config.getToolbarTextColor());

     //   doneText.setText(config.getDoneTitle());
     //   doneText.setTextColor(config.getToolbarTextColor());

        backImage.setColorFilter(config.getToolbarIconColor());


       // doneText.setVisibility(GONE);
    }

    public void setTitle(String title) {
        titleText.setText(title);
    }

    public void showDoneButton(boolean isShow) {
        doneText.setVisibility(isShow ? VISIBLE : GONE);
//        doneText.setVisibility(View.VISIBLE);
    }

    public void showBackButton(){
        backImage.setVisibility(VISIBLE);
    }

    public void hideBackButton(){
        backImage.setVisibility(INVISIBLE);
    }

    public void setOnBackClickListener(OnClickListener clickListener) {
        backImage.setOnClickListener(clickListener);
    }


    public void setOnDoneClickListener(OnClickListener clickListener) {
        doneText.setOnClickListener(clickListener);
    }

    public void setDoneEnable(){
        doneText.setEnabled(true);
    }
    public void setVisible(){
        doneText.setVisibility(GONE);
    }
    public void setDoneDisable(){
        doneText.setEnabled(false);
    }
}
