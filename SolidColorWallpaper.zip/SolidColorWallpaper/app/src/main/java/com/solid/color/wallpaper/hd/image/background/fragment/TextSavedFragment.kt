package com.solid.color.wallpaper.hd.image.background.fragment

import android.app.Activity
import android.app.RecoverableSecurityException
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Resources
import android.database.Cursor
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Binder
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.solid.color.wallpaper.hd.image.background.PaintViewFol.activity.PaintActivity
import com.google.android.gms.ads.AdListener
import com.solid.color.wallpaper.hd.image.background.BuildConfig
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.SolidWallpaperApplication.Companion.instance
import com.solid.color.wallpaper.hd.image.background.activity.WallpaperViewActivity
import com.solid.color.wallpaper.hd.image.background.adapter.SavedImagesAdapter
import com.solid.color.wallpaper.hd.image.background.constants.Constants
import com.solid.color.wallpaper.hd.image.background.custom.BottomSheetFragment
import com.solid.color.wallpaper.hd.image.background.custom.GridSpacingItemDecoration
import com.solid.color.wallpaper.hd.image.background.model.SavedImageModel
import com.solid.color.wallpaper.hd.image.background.shared_pref.MySharedPref
import java.io.File
import java.io.FileFilter
import java.lang.Exception
import java.util.*

class TextSavedFragment : Fragment {
    // TODO: Rename and change types of parameters
    private var mParam1: String? = null
    private var mParam2: String? = null
    private var mListener: OnFragmentInteractionListener? = null
    private var recyclerWallpaper: RecyclerView? = null
    private var imagePaths: ArrayList<SavedImageModel>? = null
    private var adapter: SavedImagesAdapter? = null
    private var layoutDelete: LinearLayout? = null
    private var isMenuOpen: Boolean = false
    var taga: String? = null
    private var bottomSheetFragment: BottomSheetFragment? = null
        private set
    private val mySharedPref: MySharedPref? = null

    constructor(tag1: String?) {
        // Required empty public constructor
        taga = tag1
    }

    constructor() {}

    /*  // TODO: Rename and change types and number of parameters
    public static TextSavedFragment newInstance(String param1, String param2) {
        TextSavedFragment fragment = new TextSavedFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }*/
    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (arguments != null) {
            mParam1 = arguments!!.getString(ARG_PARAM1)
            mParam2 = arguments!!.getString(ARG_PARAM2)
        }
    }

    public override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                                     savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_text_saved, container, false)
    }

    public override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        /*mySharedPref=new MySharedPref(getActivity());
        if (!mySharedPref.getAdsRemoved()) {
            loadInterstialAd();
        }*/recyclerWallpaper = view.findViewById(R.id.recyclerWallpaper)
        layoutDelete = view.findViewById(R.id.layoutDelete)
        val manager: GridLayoutManager = GridLayoutManager(activity, 3)
        recyclerWallpaper!!.layoutManager = manager
        recyclerWallpaper!!.addItemDecoration(GridSpacingItemDecoration(3, dpToPx(8), true))
        recyclerWallpaper!!.itemAnimator = DefaultItemAnimator()
        view.findViewById<View>(R.id.txtCreate).setOnClickListener {
            //  Constants.isFromFrag = false;
            startActivity(Intent(activity, PaintActivity::class.java))
            //  getActivity().finish();
        }
        layoutDelete!!.setOnClickListener {
            var isEnable: Boolean = false
            for (i in adapter!!.allUpdatedList.indices) {
                val model: SavedImageModel = adapter!!.allUpdatedList.get(i)
                if (model.isDeletedEnable) {
                    isEnable = true
                    break
                }
            }
            if (isEnable) {
                showDeleteDialog()
            } else {
                Toast.makeText(activity, resources.getString(R.string.select_image_to_delete), Toast.LENGTH_SHORT).show()
            }
        }
        photoes
    }

    private val photoes: Unit
        private get() {
            imagePaths = ArrayList()
            val file: File = File(Constants.path)
            if (file.isDirectory) {
                val files: Array<File>? = file.listFiles(FileFilter { pathname: File -> pathname.getPath().endsWith(".jpg") || pathname.getPath().endsWith(".jpeg") || pathname.getPath().endsWith(".png") })
                if (files != null && files.size > 0) {
                    var temp: File
                    for (i in files.indices) {
                        for (j in i + 1 until files.size) {
                            if (files[i].lastModified() < files[j].lastModified()) {
                                temp = files[i]
                                files[i] = files[j]
                                files[j] = temp
                            }
                        }
                    }
                    for (value: File in files) {
                        Log.d("789456132", "getPhotoes: " + value.absolutePath)
                        if (value.absolutePath.contains("PAINT_")) {
                            val model: SavedImageModel = SavedImageModel()
                            model.path = value.absolutePath
                            model.isDeletedEnable = false
                            imagePaths!!.add(model)
                        }
                    }
                }
            }
            Log.d("784545456", "getPhotoes: " + imagePaths)
            if (imagePaths!!.size > 0) {
                setDataToAdapter()
                view!!.findViewById<View>(R.id.nowallpaper).visibility = View.GONE
                recyclerWallpaper!!.visibility = View.VISIBLE
            } else {
                view!!.findViewById<View>(R.id.nowallpaper).visibility = View.VISIBLE
                recyclerWallpaper!!.visibility = View.GONE
            }
        }

    val updatedData: ArrayList<SavedImageModel>?
        get() {
            Log.d("785645645121", "getUpdatedData: " + adapter)
            if (adapter != null) {
                return adapter!!.allUpdatedList
            }
            return imagePaths
        }

    fun shareData() {
        if (adapter != null) {
            shareImage(adapter!!.allUpdatedList)
        }
    }

    private fun shareImage(updatedData: ArrayList<SavedImageModel>) {
        Log.d("785645645121", "shareImage: " + updatedData.size)
        val mSharedUri: ArrayList<Uri> = ArrayList()
        for (i in updatedData.indices) {
            if (updatedData.get(i).isDeletedEnable) {
                val uri: Uri = FileProvider.getUriForFile((activity)!!, BuildConfig.APPLICATION_ID.toString() + ".provider", File(updatedData.get(i).path))
                mSharedUri.add(uri)
            }
        }
        val intent: Intent = Intent(Intent.ACTION_SEND_MULTIPLE)
        intent.type = "image/jpeg"
        intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, mSharedUri)
        var shareMessage: String = ""
        shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=com.solid.color.wallpaper.hd.image.background"
        intent.putExtra(Intent.EXTRA_TEXT, shareMessage)
        startActivity(Intent.createChooser(intent, getResources().getString(R.string.share_wallpaper)))
    }

    private fun setDataToAdapter() {
        val listener: SavedImagesAdapter.setOnItemClickListener = object : SavedImagesAdapter.setOnItemClickListener {
            public override fun OnItemClickedImage(position: Int) {
                /*Log.d("1223312", "OnItemClickedImage: "+imagePaths);
                FullscreenDialog.OnDialogDismissL dismissL=new FullscreenDialog.OnDialogDismissL() {
                    @Override
                    public void onDialogDismmissed() {
                       getPhotoes();
                       onDoubleTap();
                    }
                };
                 dialog = new FullscreenDialog(imagePaths,position,dismissL);
                dialog.setCancelable(true);
                dialog.show(getSupportFragmentManager(), "Dialog");*/
                Constants.selectedPosition = position
                Constants.viewpagerPos = 2
                Constants.isDataChanges = false
                /*
                if (!mySharedPref.getAdsRemoved()) {

                    if (SolidWallpaperApplication.getInstance().requestNewInterstitial()) {
                        SolidWallpaperApplication.getInstance().mInterstitialAd.setAdListener(new AdListener() {

                            @Override
                            public void onAdClosed() {
                                super.onAdClosed();
                                loadInterstialAd();
                                startActivity(new Intent(getActivity(), WallpaperViewActivity.class));
                            }

                            @Override
                            public void onAdFailedToLoad(int i) {
                                super.onAdFailedToLoad(i);
                                startActivity(new Intent(getActivity(), WallpaperViewActivity.class));
                            }

                            @Override
                            public void onAdLoaded() {
                                super.onAdLoaded();
                            }
                        });

                    } else {
                        startActivity(new Intent(getActivity(), WallpaperViewActivity.class));
                    }

                }else {*/Constants.isText = true
                startActivity(Intent(activity, WallpaperViewActivity::class.java))
                //}
            }

            public override fun OnLongClickImage(position: Int) {
                openMenu()
            }
        }
        adapter = SavedImagesAdapter(imagePaths!!, activity!!, listener)
        recyclerWallpaper!!.adapter = adapter
    }

    private fun openMenu() {
        isMenuOpen = true
        layoutDelete!!.animate().withStartAction { layoutDelete!!.visibility = View.VISIBLE }.translationYBy(-layoutDelete!!.height.toFloat()).setDuration(500).start()
    }

    private fun closeMenu() {
        isMenuOpen = false
        layoutDelete!!.animate().translationY(layoutDelete!!.height.toFloat()).setDuration(500).withEndAction { layoutDelete!!.visibility = View.GONE }.start()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 4444 && resultCode == Activity.RESULT_OK) {
            for (i in adapter!!.allUpdatedList.indices) {
                val model: SavedImageModel = adapter!!.allUpdatedList.get(i)
                if (model.isDeletedEnable) {
                    val ffile: File = File(model.path)
                    val result= ffile.delete()
                }
            }
            photoes
            closeMenu()
        }
    }
    private fun showDeleteDialog() {
        val uris = arrayListOf<Uri>()

         bottomSheetFragment = BottomSheetFragment(getResources().getString(R.string.delete), getResources().getString(R.string.are_you_want_to_remove), getResources().getString(R.string.delete), getResources().getString(R.string.cancel), R.drawable.ic_delete_dialog, object : BottomSheetFragment.OnButtonClickListener {
            public override fun onPositive(bottomSheetDialo: BottomSheetFragment?) {
                bottomSheetDialo!!.dismiss()
                for (i in adapter!!.allUpdatedList.indices) {
                    val model: SavedImageModel = adapter!!.allUpdatedList.get(i)
                    if (model.isDeletedEnable) {
                        val ffile: File = File(model.path)
                        val result= ffile.delete()
                        if (!result && (Intent.FLAG_GRANT_WRITE_URI_PERMISSION) != PackageManager.PERMISSION_GRANTED) {
                            try {
                                val projection = arrayOf<String>(MediaStore.Images.Media._ID)

                                // Match on the file path
                                val selection: String = MediaStore.Images.Media.DATA.toString() + " = ?"
                                val selectionArgs = arrayOf<String>(ffile.getAbsolutePath())

                                // Query for the ID of the media matching the file path
                                val queryUri: Uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                                val contentResolver = requireContext().contentResolver
                                val c: Cursor? = contentResolver.query(queryUri, projection, selection, selectionArgs, null)

                                if (c != null) {
                                    if (c.moveToFirst()) {
                                        // We found the ID. Deleting the item via the content provider will also remove the file
                                        val id: Long = c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media._ID))
                                        val deleteUri: Uri = ContentUris.withAppendedId(queryUri, id)
                                        try {
                                            uris.add(deleteUri)
                                            //contentResolver.delete(deleteUri, null, null)
                                            //MediaStore.createDeleteRequest(requireContext().contentResolver, arrayOf(deleteUri).toList())
                                        } catch (securityException: SecurityException) {
                                            securityException.printStackTrace()
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                                val recoverableSecurityException =
                                                        securityException as? RecoverableSecurityException
                                                                ?: throw securityException

                                                // Signal to the Activity that it needs to request permission and
                                                // try the delete again if it succeeds.
                                                //pendingDeleteImage = image

                                                /*startIntentSenderForResult(
                                                        recoverableSecurityException.userAction.actionIntent.intentSender,
                                                        DELETE_PERMISSION_REQUEST,
                                                        null,
                                                        0,
                                                        0,
                                                        0,
                                                        null
                                                )*/
                                            } else {
                                                throw securityException
                                            }
                                        }
                                    } else {
                                        // File not found in media store DB
                                    }
                                    c.close()
                                }
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }

                        } else {
                            try {
                                requireContext().sendBroadcast(Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(File(ffile.absolutePath))))
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }

                        }
                    }
                }
                if (uris.isNotEmpty())
                    deleteImages(uris)
                photoes
                closeMenu()
            }

            public override fun onNegative(bottomSheetDialog: BottomSheetFragment?) {
                bottomSheetDialog!!.dismiss()
            }
        })
        bottomSheetFragment!!.show(requireActivity().supportFragmentManager, "dialog")
    }
    fun allowBackPressed(): Boolean {
        if (isMenuOpen) {
            closeMenu()
            adapter!!.setDataChange()
            return false
        } else {
            return true
        }
    }
    @RequiresApi(Build.VERSION_CODES.R)
    private fun deleteImages(uris: List<Uri>) {
        val pendingIntent = MediaStore.createDeleteRequest(requireContext().contentResolver, uris.filter {
            requireActivity().checkUriPermission(it, Binder.getCallingPid(), Binder.getCallingUid(), Intent.FLAG_GRANT_WRITE_URI_PERMISSION) != PackageManager.PERMISSION_GRANTED
        })
        startIntentSenderForResult(pendingIntent.intentSender, 4444, null, 0, 0, 0, null)
    }

    // TODO: Rename method, update argument and hook method into UI event
    fun onButtonPressed(uri: Uri?) {
        if (mListener != null) {
            mListener!!.onFragmentInteraction(uri)
        }
    }

    private fun dpToPx(dp: Int): Int {
        val r: Resources = resources
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), r.displayMetrics))
    }

//    private fun loadInterstialAd() {
//        if (instance!!.mInterstitialAd!!.isLoaded) {
//        } else {
//            instance!!.mInterstitialAd!!.adListener = null
//            instance!!.mInterstitialAd = null
//            instance!!.ins_adRequest = null
//            instance!!.LoadAds()
//            instance!!.mInterstitialAd!!.adListener = object : AdListener() {
//                public override fun onAdLoaded() {
//                    super.onAdLoaded()
//                }
//
//                public override fun onAdFailedToLoad(i: Int) {
//                    super.onAdFailedToLoad(i)
//                    loadInterstialAd()
//                }
//            }
//        }
//    }

    public override fun onAttach(context: Context) {
        super.onAttach(context)
    }

    public override fun onDetach() {
        super.onDetach()
        mListener = null
    }

    public override fun onResume() {
        super.onResume()
        if (bottomSheetFragment != null) {
            bottomSheetFragment!!.dismiss()
        }

        if (Constants.isDataChanges && Constants.viewPagerPage == 2) {
            photoes
            Constants.isDataChanges = false
        }
    }

    override fun onPause() {
        super.onPause()
        if (bottomSheetFragment != null) {
            bottomSheetFragment!!.dismiss()
        }
    }

    open interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        fun onFragmentInteraction(uri: Uri?)
    }

    companion object {
        // TODO: Rename parameter arguments, choose names that match
        // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
        private val ARG_PARAM1: String = "param1"
        private val ARG_PARAM2: String = "param2"
    }
}