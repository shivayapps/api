package com.solid.color.wallpaper.hd.image.background.model

import android.graphics.drawable.GradientDrawable
import java.util.*

class GradientResolutionModel {
    private var mAllSticker: ArrayList<StickerModel>? = null
    var mainWidth = 0
    var mainHeight = 0
    var color1 = 0
    var color2 = 0
    var isCircle = false
    var isInner = false
    var orientation: GradientDrawable.Orientation? = null
    var emojiImage: String? = null
    var emojiColor = 0
    var opacityEmoji = 0f

    constructor() {}
    constructor(mAllSticker: ArrayList<StickerModel>?, mainWidth: Int, mainHeight: Int, color1: Int, color2: Int, isCircle: Boolean, isInner: Boolean, orientation: GradientDrawable.Orientation?, emojiImage: String?, emojiColor: Int, opacityEmoji: Float) {
        this.mAllSticker = mAllSticker
        this.mainWidth = mainWidth
        this.mainHeight = mainHeight
        this.color1 = color1
        this.color2 = color2
        this.isCircle = isCircle
        this.isInner = isInner
        this.orientation = orientation
        this.emojiImage = emojiImage
        this.emojiColor = emojiColor
        this.opacityEmoji = opacityEmoji
    }

    fun getmAllSticker(): ArrayList<StickerModel>? {
        return mAllSticker
    }

    fun setmAllSticker(mAllSticker: ArrayList<StickerModel>?) {
        this.mAllSticker = mAllSticker
    }

}