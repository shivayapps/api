package com.solid.color.wallpaper.hd.image.background.retrofit

import com.solid.color.wallpaper.hd.image.background.model.api.Response
import retrofit2.Call
import retrofit2.http.GET

interface APIInterface {
    @GET("app/2")
    fun doGetListResources(): Call<Response?>?
    @GET("application/2")
    fun doGetNewListResources(): Call<com.solid.color.wallpaper.hd.image.background.newModel.Response?>?
}