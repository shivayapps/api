package com.solid.color.wallpaper.hd.image.background

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.util.Log
import androidx.multidex.MultiDex
import com.facebook.ads.*
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.onesignal.OSNotificationAction.ActionType
import com.onesignal.OSNotificationOpenResult
import com.onesignal.OneSignal
import com.onesignal.OneSignal.NotificationOpenedHandler
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.appid.AppIDs
import com.solid.color.wallpaper.hd.image.background.PaintViewFol.drawing.Brushes.loadBrushList
import com.solid.color.wallpaper.hd.image.background.activity.SplashScreenActivity
import com.solid.color.wallpaper.hd.image.background.adshalper.AppOpenManager
import com.solid.color.wallpaper.hd.image.background.adshalper.RewardVideoAds.Companion.instence
import com.solid.color.wallpaper.hd.image.background.constants.Constants
import com.solid.color.wallpaper.hd.image.background.custom.ApplicationLifecycleManager
import com.solid.color.wallpaper.hd.image.background.custom.ExampleNotificationReceivedHandler
import com.solid.color.wallpaper.hd.image.background.imagePicker.model.Constant.activity
import com.solid.color.wallpaper.hd.image.background.shared_pref.MySharedPref
import com.vasundhara.vision.subscription.AppSubscription
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException
import java.util.*

class SolidWallpaperApplication : AppSubscription() {
    companion object {
        private var singleton: SolidWallpaperApplication? = null

        @JvmStatic
        val instance: SolidWallpaperApplication?
            get() {
                if (singleton == null) {
                    singleton = SolidWallpaperApplication()
                }
                return singleton
            }

        init {
            System.loadLibrary("native-lib")
        }
    }

    @JvmField
    var mInterstitialAdfb: com.facebook.ads.InterstitialAd? = null

    @JvmField
    var mInterstitialAd: InterstitialAd? = null

    lateinit var openManager: AppOpenManager

    @JvmField
    var ins_adRequest: AdRequest? = null
    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        MultiDex.install(this)
        loadBrushList(this)
    }

    class staticLanguage {
        companion object Factory {
            fun create(context: Context) {
                val locale: Locale
                val sharedPref = MySharedPref(context)
                locale = if (sharedPref.language.equals("English", ignoreCase = true)) {
                    Locale("en")
                } else if (sharedPref.language.equals("Española", ignoreCase = true)) {
                    Locale("es")
                } else if (sharedPref.language.equals("Pусский", ignoreCase = true)) {
                    Locale("ru")
                } else if (sharedPref.language.equals("Portuguesa", ignoreCase = true)) {
                    Locale("pt")
                } else if (sharedPref.language.equals("عربى", ignoreCase = true)) {
                    Locale("ar")
                } else {
                    Locale("tr")
                }
                Log.d("staticLanguage", "onResume: " + locale.displayLanguage)
//                //  if (!locale.equals(Locale.getDefault())) {
//                Locale.setDefault(locale)
//                val config1 = Configuration()
//                config1.locale = locale
//                context.resources.updateConfiguration(config1, context.resources.displayMetrics)

                if (locale != Locale.getDefault()) {
                    Locale.setDefault(locale)
                    val config1 = Configuration()
                    config1.locale = locale
                    context.resources.updateConfiguration(config1, context.resources.displayMetrics)
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        registerActivityLifecycleCallbacks(ApplicationLifecycleManager())

        // OneSignal Initialization
        OneSignal.startInit(this)
                .setNotificationReceivedHandler(ExampleNotificationReceivedHandler())
                .setNotificationOpenedHandler(ExampleNotificationOpenedHandler())
                .inFocusDisplaying(OneSignal.OSInFocusDisplayOption.Notification)
                .unsubscribeWhenNotificationsAreDisabled(true)
                .init()
        MultiDex.install(this)
        AudienceNetworkAds.initialize(this)
//        AudienceNetworkAds.isInAdsProcess(this)
//        MobileAds.initialize(this, R.string.admob_app_id.toString())

        MobileAds.initialize(this) {

        }
        //CrashHandler.init(getApplicationContext());
        AppIDs.init(applicationContext, AppIDs.SOLID_COLOR, false)
        openManager = AppOpenManager(this)
        try {
            singleton = this
            LoadAds()
            LoadAdsFb()
            assert(instence != null)
            if (instence != null){
                instence!!.loadVideoAdMain(this)
            }

            // Test calling play() immediately (before TTS initialization is complete).
            val info = packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES)
            for (signature in info.signatures) {
                val md = MessageDigest.getInstance("SHA")
                md.update(signature.toByteArray())
                //Log.e("TAG", "KeyHash: >>>> " + Base64.encodeToString(md.digest(), Base64.DEFAULT));
            }
        } catch (e: PackageManager.NameNotFoundException) {
        } catch (e: NoSuchAlgorithmException) {
        } catch (e: Exception) {
        }
    }

    public fun forLanguafe() {

    }

    fun requestNewInterstitial(): Boolean {
        try {
            if (mInterstitialAd != null) {
                mInterstitialAd!!.show(activity)
                return true
            }else{
                LoadAds()
            }
        } catch (e: Exception) {
        }
        return false
    }

    fun LoadAds() {
        try {
            var adsId = AppIDs.instnace!!.getGoogleInterstitial()
//            mInterstitialAd = InterstitialAd(applicationContext,mInterstitialAd)
//            mInterstitialAd = null

            ins_adRequest = AdRequest.Builder().build()
            InterstitialAd.load(this,
                    adsId,
                    ins_adRequest,
                    object : InterstitialAdLoadCallback() {
                        override fun onAdLoaded(myAd: InterstitialAd) {
//                            Timber.d("Ad Loaded")
                            mInterstitialAd = myAd
                        }

                        override fun onAdFailedToLoad(adError: LoadAdError) {
//                            Timber.d("Failed to load ad: ${adError.message}")
                            mInterstitialAd = null
                            LoadAds()
                        }

                    })

            mInterstitialAd!!.fullScreenContentCallback = object: FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
//                    Log.d(TAG, 'Ad was dismissed.')
                }

                override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
                    super.onAdFailedToShowFullScreenContent(p0)
//                    loadInterstialAd()
                }

                override fun onAdShowedFullScreenContent() {
//                    Log.d(TAG, 'Ad showed fullscreen content.')
//                   mInterstitialAd = null;
                }
            }
//
//            if (!isTest && adsId == "ca-app-pub-3940256099942544/1033173712") {
//                return
//            }
//            mInterstitialAd!!.adUnitId = adsId
//            Log.e("ADSOM", adsId)
//
//            ins_adRequest = AdRequest.Builder().addTestDevice("68c66509-e5f3-462f-9b3c-734432ab111f") //SWIPE
//                    .build()
//            mInterstitialAd!!.loadAd(ins_adRequest)
//            mInterstitialAd!!.adListener = object : AdListener() {
//                override fun onAdClosed() {
//                    super.onAdClosed()
//                    Log.e("ADS", "onAdClosed: ")
//                }
//
//                override fun onAdFailedToLoad(i: Int) {
//                    super.onAdFailedToLoad(i)
//                    Log.e("ADS", "onAdFailedToLoad: ")
//
//                }
//
//                override fun onAdLeftApplication() {
//                    super.onAdLeftApplication()
//                    Log.e("ADS", "onAdLeftApplication: ")
//                    mInterstitialAd!!.show()
//                }
//
//                override fun onAdOpened() {
//                    super.onAdOpened()
//                    Log.e("ADS", "onAdOpened: ")
//                }
//
//                override fun onAdLoaded() {
//                    super.onAdLoaded()
//                    Log.e("ADS", "onAdLoaded: ")
//                }
//
//                override fun onAdClicked() {
//                    super.onAdClicked()
//                    Log.e("ADS", "onAdClicked: ")
//                }
//
//                override fun onAdImpression() {
//                    super.onAdImpression()
//                    Log.e("ADS", "onAdImpression: ")
//                }
//            }
        } catch (e: Exception) {
        }
    }

    /*public static void adsGoogleBanner(Activity activity, int id) {

        boolean isNeedToShow = false;

        if (!SharedPrefs.contain(activity, SharedPrefs.IS_ADS_REMOVED)) {
            isNeedToShow = true;
        } else {
            if (!SharedPrefs.getBoolean(activity, SharedPrefs.IS_ADS_REMOVED))
                isNeedToShow = true;
            else
                isNeedToShow = false;
        }

        if (isNeedToShow) {
            try {
                final AdView mAdView = activity.findViewById(id);
                AdRequest adRequest = new AdRequest.Builder()
                        .addTestDevice("DDB94C276417D3D47927135DF4C5CDFA")
                        .build();

                mAdView.loadAd(adRequest);
                mAdView.setAdListener(new AdListener() {
                    @Override
                    public void onAdClosed() {
                        super.onAdClosed();
                    }

                    @Override
                    public void onAdFailedToLoad(int i) {
                        super.onAdFailedToLoad(i);
                        mAdView.setVisibility(View.GONE);
                    }

                    @Override
                    public void onAdLeftApplication() {
                        super.onAdLeftApplication();
                    }

                    @Override
                    public void onAdOpened() {
                        super.onAdOpened();
                    }

                    @Override
                    public void onAdLoaded() {
                        super.onAdLoaded();
                        mAdView.setVisibility(View.VISIBLE);
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static boolean isNeedToAdShow(Context context) {
        boolean isNeedToShow = true;

        if (!SharedPrefs.contain(context, SharedPrefs.IS_ADS_REMOVED)) {
            isNeedToShow = true;
        } else {
            if (!SharedPrefs.getBoolean(context, SharedPrefs.IS_ADS_REMOVED))
                isNeedToShow = true;

            else
                isNeedToShow = false;
        }
        return isNeedToShow;
    }*/
    fun LoadAdsFb() {
        try {
            AdSettings.addTestDevice("4d1f808f-4211-406b-942a-2a99f8af5299")
            var fbRandomInter = AppIDs.instnace!!.getRandomFacebookInterstitial()
            Log.e("EEEEEE", fbRandomInter)

            mInterstitialAdfb = if (Constants.isInstrastial1) {
                InterstitialAd(this, fbRandomInter)
            } else {
                InterstitialAd(this, fbRandomInter)
            }
            mInterstitialAdfb!!.loadAd()
            mInterstitialAdfb!!.buildLoadAdConfig().withAdListener(object : InterstitialAdListener {
                override fun onInterstitialDisplayed(ad: Ad) {
                    // Interstitial displayed callback
                    Log.e("TAG", "--> onInterstitialDisplayed")
                }

                override fun onInterstitialDismissed(ad: Ad) {
                    // Interstitial dismissed callback
                    Log.e("TAG", "--> onInterstitialDismissed")
                    LoadAdsFb()
                }

                override fun onError(ad: Ad, adError: AdError) {
                    // Ad error callback
                    Log.e("TAG", "onError --> " + adError.errorMessage)
                    //   LoadAdsFb();
                }

                override fun onAdLoaded(ad: Ad) {
                    // Show the ad when it's done loading.
                    Log.e("TAG", "--> onAdLoaded")
                }

                override fun onAdClicked(ad: Ad) {
                    // Ad clicked callback
                    Log.e("TAG", "--> onAdClicked")
                }

                override fun onLoggingImpression(ad: Ad) {
                    // Ad impression logged callback
                    Log.e("TAG", "--> onLoggingImpression")
                }
            })
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun requestNewInterstitialfb(): Boolean {
        try {
            if (mInterstitialAdfb!!.isAdLoaded) {
                mInterstitialAdfb!!.show()
                return true
            }
        } catch (e: Exception) {
        }
        return false
    }

    val isLoadedfnad: Boolean
        get() {
            try {
                if (mInterstitialAdfb!!.isAdLoaded && mInterstitialAdfb != null) {
                    return true
                }
            } catch (e: Exception) {
            }
            return false
        }

    inner class ExampleNotificationOpenedHandler : NotificationOpenedHandler {
        // This fires when a notification is opened by tapping on it.
        override fun notificationOpened(result: OSNotificationOpenResult) {
            val actionType = result.action.type
            val data = result.notification.payload.additionalData
            val launchUrl = result.notification.payload.launchURL // update docs launchUrl
            val customKey: String?
            var openURL: String? = null
            var activityToLaunch: Any = SplashScreenActivity::class.java
            if (data != null) {
                customKey = data.optString("customkey", null)
                openURL = data.optString("openURL", null)
                if (customKey != null) Log.i("OneSignalExample", "customkey set with value: $customKey")
                if (openURL != null) Log.i("OneSignalExample", "openURL to webview with URL value: $openURL")
            }
            if (actionType == ActionType.ActionTaken) {
                Log.i("OneSignalExample", "Button pressed with id: " + result.action.actionID)
                if (result.action.actionID == "id1") {
                    Log.i("OneSignalExample", "button id called: " + result.action.actionID)
                    activityToLaunch = SplashScreenActivity::class.java
                } else Log.i("OneSignalExample", "button id called: " + result.action.actionID)
            }
            if (ApplicationLifecycleManager.isAppVisible) {
                // App is running
            } else {
                // The following can be used to open an Activity of your choice.
                // Replace - getApplicationContext() - with any Android Context.
                // Intent intent = new Intent(getApplicationContext(), YourActivity.class);
                val intent = Intent(applicationContext, activityToLaunch as Class<*>)
                // intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_NEW_TASK
                intent.putExtra("openURL", openURL)
                Log.i("OneSignalExample", "openURL = $openURL")
                // startActivity(intent);
                applicationContext.startActivity(intent)
            }
            // Add the following to your AndroidManifest.xml to prevent the launching of your main Activity
            //   if you are calling startActivity above.
            /*
          <application ...>
            <meta-data android:name="com.onesignal.NotificationOpened.DEFAULT" android:value="DISABLE" />
          </application>
       */
        }
    }
}