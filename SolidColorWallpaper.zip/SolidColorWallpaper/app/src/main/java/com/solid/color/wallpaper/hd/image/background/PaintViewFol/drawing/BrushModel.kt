package com.solid.color.wallpaper.hd.image.background.PaintViewFol.drawing

import android.graphics.Bitmap

class BrushModel(var drawX: Float,var drawY:Float,var tipScale:Float, mPathLayer:Bitmap, tipSpeedAlpha:Float) {
}