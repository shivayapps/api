package com.solid.color.wallpaper.hd.image.background.fragment

import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.Layout
import android.util.DisplayMetrics
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.social.media.post.graphics.template.card.maker.utils.UiHelper.getHeightWidth
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.custom.MatrixClonable
import com.solid.color.wallpaper.hd.image.background.model.ResolutionModel
import com.solid.color.wallpaper.hd.image.background.model.StickerModel
import com.xiaopo.flying.sticker.DrawableSticker
import com.xiaopo.flying.sticker.Sticker
import com.xiaopo.flying.sticker.StickerView
import com.xiaopo.flying.sticker.TextSticker

class PagerItemFragment : Fragment {
    private var resolutionModel: ResolutionModel? = null
    var sticker_view: StickerView? = null
    var imgWallpaper: ImageView? = null
    var mainFrame: FrameLayout? = null

    constructor() {
        // Required empty public constructor
    }

    constructor(resolutionModel: ResolutionModel?) {
        this.resolutionModel = resolutionModel
    }

    public override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                                     savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_pager_item, container, false)
    }

    public override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        sticker_view = view.findViewById(R.id.sticker_viewnew)
        imgWallpaper = view.findViewById(R.id.imgWallpaper)
        mainFrame = view.findViewById(R.id.mainFrame)
        Log.d("TAGGAGG", "Density: " + resources.displayMetrics.density)
        /*  FrameLayout.LayoutParams params= (FrameLayout.LayoutParams) view.findViewById(R.id.mainLayout).getLayoutParams();
        params.height=1704;
        view.findViewById(R.id.mainLayout).setLayoutParams(params);*/
        sticker_view!!.isLocked = true
        view.findViewById<View>(R.id.mainLayout).post {
            addTextSticker(sticker_view, imgWallpaper)
            if (resolutionModel!!.isCircle) {
                setCircleGradient(resolutionModel!!.isInner, imgWallpaper)
            } else {
                setGradientDrawable(resolutionModel!!.orientation, imgWallpaper)
            }
        }
    }

    fun addTextSticker(sticker_view: StickerView?, imgWallpaper: ImageView?) {
        for (i in resolutionModel!!.getmAllSticker()!!.indices) {
            val model: StickerModel = resolutionModel!!.getmAllSticker()!![i]!!
            if (model.isText) {
                val strk: TextSticker = TextSticker((activity)!!)
                strk.drawable = (ContextCompat.getDrawable((activity)!!, R.drawable.sticker_transparent_background))!!
                strk.setTypeface(Typeface.createFromAsset(activity!!.assets, model.typeface))
                strk.text = model.getText()
                strk.setTextColor(model.textColor)
                strk.setTextAlign(Layout.Alignment.ALIGN_CENTER)
                strk.alpha = model.textAlhpa
                strk.resizeText()
                sticker_view!!.addSticker(strk)
            } else {
                val sticker1: DrawableSticker = DrawableSticker(model.drawable)
                sticker1.color = model.drawableColor
                sticker1.alpha = model.drawableAlpha
                sticker_view!!.addSticker(sticker1)
            }
        }
        sticker_view!!.post {
            imgWallpaper!!.post {
                for (i in sticker_view.stickers.indices) {
                    val sticker: Sticker = sticker_view.stickers[i]
                    /*  TextView textView=new TextView(getActivity());
                                    float[] val=new float[9];
                                    resolutionModel.getmAllSticker().get(i).getMatrix().getValues(val);
                                    textView.setText("Hello");
                                    textView.setX(val[Matrix.MTRANS_X]);
                                    textView.setY(val[Matrix.MTRANS_Y]);

                                    float angle= (float) (Math.atan2(val[Matrix.MSKEW_X],val[Matrix.MSCALE_X]) * (180/Math.PI));
                                    textView.setRotation(angle);
                                    textView.setWidth((int) (sticker.getWidth()*val[Matrix.MSCALE_X]));
                                    textView.setHeight((int) (sticker.getHeight()*val[Matrix.MSCALE_Y]));
                                    mainFrame.addView(textView);*/
                    val params: ViewGroup.LayoutParams = getHeightWidth((activity)!!, imgWallpaper.width, imgWallpaper.height, sticker.width, sticker.height, resources.displayMetrics.density)
                    Log.d("TAG895641231231231===>", "run: " + params.width + "  " + params.height)
                    sticker.setMatrix(resolutionModel!!.getmAllSticker()!![i]!!.matrix)
                }
                sticker_view.invalidate()
                for (i in sticker_view.stickers.indices) {
                    val sticker: Sticker = sticker_view.stickers[i]
                    if (sticker is TextSticker) {
                        val width: Int = 1080
                        val height: Int = 1920
                        val ratio: Float = height.toFloat() / width.toFloat()
                        val metrics: DisplayMetrics = DisplayMetrics()
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            activity!!.windowManager.defaultDisplay.getRealMetrics(metrics)
                        }
                        val dm: DisplayMetrics = resources.displayMetrics

                        //new phone 2.625
                        //10 or E 3.0
                        //nexus 5 3.0
                        //Gionee 2.0
                        Log.d("TAG===========>>>", "run: " + getResources().getDisplayMetrics().density + "  " + metrics.density)
                        var scale: Float
                        if (resources.displayMetrics.density > 3.0f) {
                            scale = (resources.displayMetrics.density) / 3.0f
                        } else {
                            scale = 3.0f / (resources.displayMetrics.density)
                        }
                        val sclH: Float = imgWallpaper.height.toFloat() / resolutionModel!!.mainHeight.toFloat()
                        val sclW: Float = imgWallpaper.width.toFloat() / resolutionModel!!.mainWidth.toFloat()
                        Log.d("TAG=====>", "run: SH " + sclH)
                        Log.d("TAG=====>", "run: SW " + sclW)
                        Log.d("TAG=====>", "run: SCALE " + scale)
                        val matrix: MatrixClonable = MatrixClonable()
                        matrix.set(sticker.getMatrix())
                        val data: FloatArray = FloatArray(9)
                        matrix.getValues(data)
                        Log.d("TAG=====>", "run: SHM " + data[Matrix.MSCALE_Y])
                        Log.d("TAG=====>", "run: SWM " + data[Matrix.MSCALE_X])
                        Log.d("TAG=====123>", "run: X TRANS " + data[Matrix.MTRANS_X] + "  =  " + resolutionModel!!.mainWidth)
                        Log.d("TAG=====123>", "run: Y TRANS " + data[Matrix.MTRANS_Y] + "  =  " + resolutionModel!!.mainHeight)
                        val x_trans: Float = ((imgWallpaper.width.toFloat() * data[Matrix.MTRANS_X]) / resolutionModel!!.mainWidth.toFloat())
                        val y_trans: Float = ((imgWallpaper.height.toFloat() * data[Matrix.MTRANS_Y]) / resolutionModel!!.mainHeight.toFloat())
                        Log.d("789245456", "run: " + i + ".  " + data[Matrix.MTRANS_X] + "   " + data[Matrix.MTRANS_Y])
                        Log.d("789245456", "run: " + i + ".  " + x_trans + "   " + y_trans)
                        matrix.postScale(sclW, sclH)
                        //  matrix.postTranslate(x_trans/6,y_trans/6);
                        sticker.setMatrix(matrix)
                    } else {
                        val sclH: Float = imgWallpaper.height.toFloat() / resolutionModel!!.mainHeight.toFloat()
                        val sclW: Float = imgWallpaper.width.toFloat() / resolutionModel!!.mainWidth.toFloat()
                        val matrix: MatrixClonable = MatrixClonable()
                        matrix.set(sticker.matrix)
                        matrix.postScale(sclW, sclH)
                        sticker.setMatrix(matrix)
                    }
                }
                sticker_view.invalidate()
            }
        }
    }

    private fun setGradientDrawable(orientation: GradientDrawable.Orientation?, imgWallpaper: ImageView?) {
        val new_colors: IntArray = intArrayOf(resolutionModel!!.color1, resolutionModel!!.color2)
        val shape: GradientDrawable = GradientDrawable(orientation, new_colors)
        shape.shape = GradientDrawable.RECTANGLE
        imgWallpaper!!.background = shape
    }

    private fun setCircleGradient(isInner: Boolean, imgWallpaper: ImageView?) {
        if (!isInner) {
            val new_colors: IntArray = intArrayOf(resolutionModel!!.color2, resolutionModel!!.color1)
            val shape: GradientDrawable = GradientDrawable()
            shape.shape = GradientDrawable.RECTANGLE
            shape.colors = new_colors
            shape.gradientType = GradientDrawable.RADIAL_GRADIENT
            shape.gradientRadius = 400f
            imgWallpaper!!.background = shape
        } else {
            val new_colors: IntArray = intArrayOf(resolutionModel!!.color1, resolutionModel!!.color2)
            val shape: GradientDrawable = GradientDrawable()
            shape.shape = GradientDrawable.RECTANGLE
            shape.colors = new_colors
            shape.gradientType = GradientDrawable.RADIAL_GRADIENT
            shape.gradientRadius = 400f
            imgWallpaper!!.background = shape
        }
    }
}