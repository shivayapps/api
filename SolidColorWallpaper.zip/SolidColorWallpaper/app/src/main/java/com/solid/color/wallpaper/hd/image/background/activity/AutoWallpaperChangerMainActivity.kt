package com.solid.color.wallpaper.hd.image.background.activity

import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.airbnb.lottie.LottieAnimationView
import com.auto.wallpaper.live.background.changer.editor.receiver.EventReceiver
import com.auto.wallpaper.live.background.changer.editor.receiver.EventReceiver.Companion.cancelAlarm
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.material.snackbar.Snackbar
import com.solid.color.wallpaper.hd.image.background.R
import com.solid.color.wallpaper.hd.image.background.SolidWallpaperApplication
import com.solid.color.wallpaper.hd.image.background.SolidWallpaperApplication.Companion.instance
import com.solid.color.wallpaper.hd.image.background.activity.AutoWallpaperChangerMainActivity
import com.solid.color.wallpaper.hd.image.background.adapter.LiveWallpaperListAdapter
import com.solid.color.wallpaper.hd.image.background.adapter.LiveWallpaperListAdapter.OnSelectAction
import com.solid.color.wallpaper.hd.image.background.constants.Constants
import com.solid.color.wallpaper.hd.image.background.custom.BottomSheetFragment
import com.solid.color.wallpaper.hd.image.background.custom.CustomLinearLayout
import com.solid.color.wallpaper.hd.image.background.model.AutoWallpaperModel
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs
import com.solid.color.wallpaper.hd.image.background.shared_pref.AdsPrefs.getBoolean
import com.solid.color.wallpaper.hd.image.background.shared_pref.MySharedPref
import com.solid.color.wallpaper.hd.image.background.sqlite_database.DBHelperAutoWallpaper
import java.io.File
import java.util.*

class AutoWallpaperChangerMainActivity constructor() : AppCompatActivity(), View.OnClickListener {
    private var btnNext: ImageView? = null
    private var btnShare: ImageView? = null
    private var icBack: ImageView? = null
    private var icSubcription: LottieAnimationView? = null
    private var layoutMainWallpaperList: ConstraintLayout? = null
    private var layoutNoWallpaper: ConstraintLayout? = null
    private var btnAddWallpaper: CustomLinearLayout? = null
    private var recyclerMainWallpaer: RecyclerView? = null
    private var mContext: Context? = null
    private var mAllWallpaperList: ArrayList<AutoWallpaperModel>? = null
    private var dbHelperAutoWallpaper: DBHelperAutoWallpaper? = null
    private var liveWallpaperAdapter: LiveWallpaperListAdapter? = null
    private var mySharedPref: MySharedPref? = null
    private var isEditClicked: Boolean = false
    private var isEdit: Boolean = false
    private var isDelete: Boolean = false
    var bottomSheetFragment:BottomSheetFragment?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_auto_wallpaper_changer_main)
        mContext = this@AutoWallpaperChangerMainActivity
        initViews()
        initViewAction()
        initListner()
    }

    private fun initViews() {
        icBack = findViewById(R.id.icBack)
        icSubcription = findViewById(R.id.icSubcription)
        btnNext = findViewById(R.id.btnNext)
        btnShare = findViewById(R.id.btnShare)
        btnAddWallpaper = findViewById(R.id.btnAddWallpaper)
        layoutMainWallpaperList = findViewById(R.id.layoutMainWallpaperList)
        recyclerMainWallpaer = findViewById(R.id.recyclerMainWallpaer)
        layoutNoWallpaper = findViewById(R.id.layoutNoWallpaper)
    }

    private fun initViewAction() {
        mySharedPref = MySharedPref(mContext)
        if (getBoolean(mContext, AdsPrefs.IS_SUBSCRIBED, false)) {
            btnShare!!.setVisibility(View.VISIBLE)
            icSubcription!!.setVisibility(View.GONE)
        } else {
            btnShare!!.setVisibility(View.GONE)
            icSubcription!!.setVisibility(View.VISIBLE)
            loadInterstialAd()
        }
        mAllWallpaperList = ArrayList()
        dbHelperAutoWallpaper = DBHelperAutoWallpaper(mContext)
        setDataToAdapter()
    }

    private val dataWallpaper: Unit
        private get() {
            mAllWallpaperList!!.clear()
            mAllWallpaperList = dbHelperAutoWallpaper!!.allAutoWallpaper
        }

    private fun setDataToAdapter() {
        val cacheDir: String = "/Pictures/.autowallpaper"
        val fullCacheDir: File = File(Environment.getExternalStorageDirectory().toString(), cacheDir)
        Log.d("78911789789126", "initViewAction: " + fullCacheDir.exists())
        mAllWallpaperList = dbHelperAutoWallpaper!!.allAutoWallpaper
        if (mAllWallpaperList!!.size > 0 && fullCacheDir.exists()) {
            recyclerMainWallpaer!!.setVisibility(View.VISIBLE)
            layoutNoWallpaper!!.setVisibility(View.GONE)
            recyclerMainWallpaer!!.setLayoutManager(LinearLayoutManager(mContext, RecyclerView.VERTICAL, false))
            liveWallpaperAdapter = LiveWallpaperListAdapter(mAllWallpaperList!!, (mContext)!!, object : OnSelectAction {
                public override fun onPlay(autoWallpaperModel: AutoWallpaperModel?) {
                    dbHelperAutoWallpaper!!.updateDataRow(autoWallpaperModel!!.id)
                    setAlarmAuto(autoWallpaperModel)
                }

                public override fun onEdit(autoWallpaperModel: AutoWallpaperModel?) {
                    editWallpaper(autoWallpaperModel)
                }

                public override fun onDelete(autoWallpaperModel: AutoWallpaperModel?) {
                    Log.d(TAG, "onDelete: " + isDelete)
                    if (!isDelete) {
                        showRemoveDialog(autoWallpaperModel)
                        isDelete = true
                    }
                }
            })
            recyclerMainWallpaer!!.setAdapter(liveWallpaperAdapter)
        } else {
            dbHelperAutoWallpaper!!.deleteAllData()
            recyclerMainWallpaer!!.setVisibility(View.GONE)
            layoutNoWallpaper!!.setVisibility(View.VISIBLE)
        }
    }

    private fun editWallpaper(autoWallpaperModel: AutoWallpaperModel?) {
        if (!isEdit) {
            isEditClicked = true
            isEdit = true
            val i: Intent = Intent(this@AutoWallpaperChangerMainActivity, AutoWallpaperChangerActivity::class.java)
            i.putExtra("AutoObject", autoWallpaperModel)
            startActivityForResult(i, 10)
        }
    }

    private fun initListner() {
        icBack!!.setOnClickListener(this)
        icSubcription!!.setOnClickListener(this)
        btnShare!!.setOnClickListener(this)
        btnNext!!.setOnClickListener(this)
        btnAddWallpaper!!.setOnClickListener(this)
        findViewById<View>(R.id.toolbar).setOnClickListener(this)
    }

    public override fun onClick(v: View) {
        when (v.getId()) {
            R.id.icBack -> onBackPressed()
            R.id.icSubcription -> showAd()
            R.id.btnShare -> shareApp()
            R.id.btnAddWallpaper -> onClickAddWallpaper()
        }
    }

    private fun showAd() {
        if (!getBoolean(mContext, AdsPrefs.IS_SUBSCRIBED, false)) {
            if (instance!!.requestNewInterstitial()) {

                instance!!.mInterstitialAd!!.fullScreenContentCallback = object: FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
//                    Log.d(TAG, 'Ad was dismissed.')
                        loadInterstialAd()
                    }

                    override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
                        super.onAdFailedToShowFullScreenContent(p0)
                        loadInterstialAd()
                    }

                    override fun onAdShowedFullScreenContent() {
//                    Log.d(TAG, 'Ad showed fullscreen content.')
                        instance!!.mInterstitialAd = null;
                    }
                }
                instance!!.mInterstitialAd!!.show(this)

//                instance!!.mInterstitialAd!!.setAdListener(object : AdListener() {
//                    public override fun onAdClosed() {
//                        super.onAdClosed()
//                        loadInterstialAd()
//                    }
//
//                    public override fun onAdFailedToLoad(i: Int) {
//                        super.onAdFailedToLoad(i)
//                    }
//
//                    public override fun onAdLoaded() {
//                        super.onAdLoaded()
//                    }
//                })
            } else {
                Toast.makeText(this@AutoWallpaperChangerMainActivity, "Try again later.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadInterstialAd() {
        if (instance!!.mInterstitialAd!=null) {
            icSubcription!!.setVisibility(View.VISIBLE)
            btnShare!!.setVisibility(View.GONE)
        } else {
            if (instance!!.mInterstitialAd!=null) {

                instance!!.mInterstitialAd!!.fullScreenContentCallback = null
                instance!!.mInterstitialAd = null
                instance!!.ins_adRequest = null
                instance!!.LoadAds()

                instance!!.mInterstitialAd!!.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
//                    Log.d(TAG, 'Ad was dismissed.')
                    }

                    override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
                        super.onAdFailedToShowFullScreenContent(p0)
                        icSubcription!!.setVisibility(View.GONE)
                        btnShare!!.setVisibility(View.VISIBLE)
                        loadInterstialAd()
                    }

                    override fun onAdShowedFullScreenContent() {
//                    Log.d(TAG, 'Ad showed fullscreen content.')
                        icSubcription!!.setVisibility(View.VISIBLE)
                        btnShare!!.setVisibility(View.GONE)
                        instance!!.mInterstitialAd = null;
                    }
                }
                instance!!.mInterstitialAd!!.show(this)

//            instance!!.mInterstitialAd!!.setAdListener(object : AdListener() {
//                public override fun onAdLoaded() {
//                    super.onAdLoaded()
//                    icSubcription!!.setVisibility(View.VISIBLE)
//                    btnShare!!.setVisibility(View.GONE)
//                }
//
//                public override fun onAdFailedToLoad(i: Int) {
//                    super.onAdFailedToLoad(i)
//                    icSubcription!!.setVisibility(View.GONE)
//                    btnShare!!.setVisibility(View.VISIBLE)
//                    loadInterstialAd()
//                }
//            })
            }
        }
    }

    private fun shareApp() {
        val shareIntent: Intent = Intent(Intent.ACTION_SEND)
        shareIntent.setType("text/plain")
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Solid Color Wallpaper")
        var shareMessage: String = ""
        shareMessage += "https://play.google.com/store/apps/details?id=com.solid.color.wallpaper.hd.image.background"
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
        startActivity(Intent.createChooser(shareIntent, getResources().getString(R.string.choose_one)))
    }

    private fun onClickAddWallpaper() {
        isEditClicked = false
        startActivityForResult(Intent(this@AutoWallpaperChangerMainActivity, AutoWallpaperChangerActivity::class.java), 10)
    }

    private fun setAlarmAuto(model: AutoWallpaperModel?) {
        val calendar: Calendar = Calendar.getInstance()
        val id: Int = 0
        Log.d("89712378161456", "setAlarmAuto: " + id)
        if (mySharedPref!!.alarmId != -1) {
            cancelAlarm(("2121" + mySharedPref!!.alarmId).toInt(), (mContext)!!, EventReceiver::class.java)
        }
        val myIntent: Intent = Intent(mContext, EventReceiver::class.java)
        val pendingIntent: PendingIntent = PendingIntent.getBroadcast(mContext, ("2121" + id).toInt(), myIntent, 0)
        val alarmManager: AlarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        mySharedPref!!.alarmId = 0
        var timeInterval: Int = 0
        when (model!!.delaytime) {
            "5 Sec" -> timeInterval = 5 * 1000
            "15 Sec" -> timeInterval = 15 * 1000
            "30 Sec" -> timeInterval = 30 * 1000
            "2 Min" -> timeInterval = 2 * 60 * 1000
            "5 Min" -> timeInterval = 5 * 60 * 1000
            "15 Min" -> timeInterval = 15 * 60 * 1000
            else -> timeInterval = 60 * 1000
        }
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M) {
            alarmManager.setRepeating(
                    AlarmManager.RTC_WAKEUP,
                    calendar.getTimeInMillis(),
                    timeInterval.toLong(),
                    pendingIntent
            )
            MySharedPref(mContext).setAlarm(id, true)
            //  Constants.isSetEvent = true
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        calendar.getTimeInMillis() + timeInterval,
                        pendingIntent
                )
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                alarmManager.setExact(
                        AlarmManager.RTC_WAKEUP,
                        calendar.getTimeInMillis() + timeInterval,
                        pendingIntent
                )
            } else {
                alarmManager.set(
                        AlarmManager.RTC_WAKEUP,
                        calendar.getTimeInMillis() + timeInterval,
                        pendingIntent
                )
            }
        }
        showSnackbar(getResources().getString(R.string.toast_wallpaper_set_seccessfully))
    }

    private fun showSnackbar(msg: String) {
        val snackbar: Snackbar = Snackbar.make(findViewById(R.id.mainLayout), msg, Snackbar.LENGTH_SHORT)
        val v: View = snackbar.getView()
        val params: CoordinatorLayout.LayoutParams = v.getLayoutParams() as CoordinatorLayout.LayoutParams
        params.gravity = Gravity.BOTTOM
        params.width = FrameLayout.LayoutParams.MATCH_PARENT
        v.setLayoutParams(params)
        v.setBackgroundColor(Color.WHITE)
        val textView: TextView = v.findViewById(com.google.android.material.R.id.snackbar_text)
        textView.setTextColor(getResources().getColor(R.color.text_colour_new))
        snackbar.show()
    }

    private fun showRemoveDialog(autoWallpaperModel: AutoWallpaperModel?) {
         bottomSheetFragment = BottomSheetFragment(getResources().getString(R.string.delete), getResources().getString(R.string.are_you_want_to_remove), getResources().getString(R.string.delete), getResources().getString(R.string.cancel), R.drawable.ic_delete_dialog, object : BottomSheetFragment.OnButtonClickListener {
            public override fun onPositive(bottomSheetDialo: BottomSheetFragment?) {
                if (dbHelperAutoWallpaper != null) {
                    if (autoWallpaperModel!!.status == 1) {
                        if (mySharedPref!!.alarmId != -1) {
                            cancelAlarm(("2121" + mySharedPref!!.alarmId).toInt(), (mContext)!!, EventReceiver::class.java)
                        }
                    }
                    dbHelperAutoWallpaper!!.deleteData(autoWallpaperModel.id)
                    dataWallpaper
                    if (mAllWallpaperList!!.size > 0) {
                        recyclerMainWallpaer!!.setVisibility(View.VISIBLE)
                        layoutNoWallpaper!!.setVisibility(View.GONE)
                        liveWallpaperAdapter = LiveWallpaperListAdapter((mAllWallpaperList)!!, (mContext)!!, object : OnSelectAction {
                            public override fun onPlay(autoWallpaperModel: AutoWallpaperModel?) {
                                dbHelperAutoWallpaper!!.updateDataRow(autoWallpaperModel!!.id)
                                setAlarmAuto(autoWallpaperModel)
                            }

                            public override fun onEdit(autoWallpaperModel: AutoWallpaperModel?) {
                                editWallpaper(autoWallpaperModel)
                            }

                            public override fun onDelete(autoWallpaperModel: AutoWallpaperModel?) {
                                Log.d(TAG, "onDelete: " + isDelete)
                                if (!isDelete) {
                                    showRemoveDialog(autoWallpaperModel)
                                    isDelete = true
                                }
                            }
                        })
                        recyclerMainWallpaer!!.setAdapter(liveWallpaperAdapter)
                    } else {
                        recyclerMainWallpaer!!.setVisibility(View.GONE)
                        layoutNoWallpaper!!.setVisibility(View.VISIBLE)
                    }
                }
                bottomSheetDialo!!.dismiss()
                isDelete = false
            }

            public override fun onNegative(bottomSheetDialog: BottomSheetFragment?) {
                bottomSheetDialog!!.dismiss()
                isDelete = false
            }
        })
        bottomSheetFragment!!.setCancelable(false)
        bottomSheetFragment!!.show(supportFragmentManager, "dialog")
    }

    override fun onPause() {
        super.onPause()
        try {
            bottomSheetFragment!!.dismiss()
        }catch (e:Exception){

        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 10) {
            if (resultCode == Activity.RESULT_OK) {
                Log.d(TAG, "onActivityResult: OK")
                setDataToAdapter()
                if (isEditClicked) {
                    isEditClicked = false
                    if (dbHelperAutoWallpaper != null) {
                        setAlarmAuto(dbHelperAutoWallpaper!!.wallpaperModel)
                    }
                }
            }
            if (resultCode == Activity.RESULT_CANCELED) {
                Log.d(TAG, "onActivityResult: CANCEL")
            }
        }
    }

    override fun onResume() {
        super.onResume()
        isEdit = false
        SolidWallpaperApplication.staticLanguage.Factory.create(this)
        if (Constants.isSubscribedW) {
            Constants.isSubscribedW = false
            recreate()
        }
    }

    companion object {
        private val TAG: String = "AutoWallpaperChangerMai"
    }
}