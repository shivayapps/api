package com.hd.wallpaper.solid.color.background.fragment

import android.os.Bundle
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import com.wifiproxysettingslibrary.wifi_network.exceptions.ApiNotSupportedException
import com.wifiproxysettingslibrary.wifi_network.exceptions.NullWifiConfigurationException

import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.custom.GridSpacingItemDecoration
import com.hd.wallpaper.solid.color.background.databinding.FragmentHDWallpaperBinding
import com.hd.wallpaper.solid.color.background.model.api.DataItem
import com.hd.wallpaper.solid.color.background.model.api.ImageItem
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs
import com.hd.wallpaper.solid.color.background.shared_pref.MySharedPref
import com.hd.wallpaper.solid.color.background.sqlite_database.DBHelper
import com.hd.wallpaper.solid.color.background.sqlite_database.DBHelperSuscription
import java.lang.reflect.InvocationTargetException
import java.util.*


class HDWallpaperFragment : Fragment() {

    private var mDataList: ArrayList<DataItem>? = null
    private var mImageList: ArrayList<ImageItem>? = null
    private val txtRetryOffline: TextView? = null
    private  var txtRetryError: TextView? = null
    private var mySharedPref: MySharedPref? = null
    private var dbHelper: DBHelper? = null
    private var dbHelperSuscription: DBHelperSuscription? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    lateinit var binding:FragmentHDWallpaperBinding
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment

        binding= FragmentHDWallpaperBinding.inflate(layoutInflater,container,false)
//        setContentView(binding.root)
        //return inflater.inflate(R.layout.fragment_h_d_wallpaper, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        mDataList = ArrayList<DataItem>()
        mImageList = ArrayList<ImageItem>()

        dbHelper = DBHelper(activity)
        dbHelperSuscription = DBHelperSuscription(activity)
        mySharedPref = MySharedPref(activity)

        if (!AdsPrefs.getBoolean(activity, AdsPrefs.IS_SUBSCRIBED, false)) {
//            var adView = AdView(activity, facebookBanner, AdSize.BANNER_HEIGHT_50)
            val adContainer = view.findViewById<View>(R.id.banner_container) as LinearLayout
            adContainer.removeAllViews()
//            adContainer.addView(adView)
//            adView.loadAd()
        }




        val manager = GridLayoutManager(activity, 3)
        binding.recyclerWallpaper.layoutManager = manager
        binding.recyclerWallpaper.addItemDecoration(GridSpacingItemDecoration(3, dpToPx(14), true))
        binding.recyclerWallpaper.itemAnimator = DefaultItemAnimator()

        try {
          //  checkStatus()
        } catch (e: InvocationTargetException) {
            e.printStackTrace()
        } catch (e: NoSuchMethodException) {
            e.printStackTrace()
        } catch (e: ApiNotSupportedException) {
            e.printStackTrace()
        } catch (e: NoSuchFieldException) {
            e.printStackTrace()
        } catch (e: IllegalAccessException) {
            e.printStackTrace()
        } catch (e: NullWifiConfigurationException) {
        //    callApi()
            e.printStackTrace()
        }

    }

    private fun dpToPx(dp: Int): Int {
        val r = resources
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), r.displayMetrics))
    }
}