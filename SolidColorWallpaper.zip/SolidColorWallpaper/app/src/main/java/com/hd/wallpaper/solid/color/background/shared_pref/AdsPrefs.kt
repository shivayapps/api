package com.hd.wallpaper.solid.color.background.shared_pref

import android.content.Context
import android.content.SharedPreferences

object AdsPrefs {
    const val DEVICE_ID = "device_id"
    const val IS_SUBSCRIBED = "subscribed"
    const val IS_NEED_TO_SHOW_SPOTLIGHT_GRADIENT = "spotlight_gradient"
    const val IS_NEED_TO_SHOW_SPOTLIGHT_SOLID = "spotlight_solid"
    const val IS_NEED_TO_SHOW_SPOTLIGHT_TEXT = "spotlight_text"
    const val WALLET_COINS = "wallet_coins"
    const val ADS_FREE_COUNT = "ads_free_count"
    const val ADS_FREE_DATE = "ads_free_date"

    private const val SHARED_PREFS_FILE_NAME = "app_center"
    private fun getPrefs(context: Context?): SharedPreferences {
        assert(context != null)
        return context!!.getSharedPreferences(SHARED_PREFS_FILE_NAME, Context.MODE_PRIVATE)
    }

    fun contain(context: Context?, key: String?): Boolean {
        return getPrefs(context).contains(key)
    }

    fun clearPrefs(context: Context?) {
        val device_id = getString(context, DEVICE_ID)
        getPrefs(context).edit().clear().commit()
        save(context, DEVICE_ID, device_id)
    }

    fun save(context: Context?, key: String?, value: Boolean) {
        getPrefs(context).edit().putBoolean(key, value).commit()
    }

    fun savePref(context: Context?, key: String?, value: Boolean) {
        getPrefs(context).edit().putBoolean(key, value).commit()
    }

    fun getBoolean(context: Context?, key: String?): Boolean {
        return getPrefs(context).getBoolean(key, false)
    }

    @JvmStatic
    fun getBoolean(context: Context?, key: String?, defaultValue: Boolean): Boolean {
        return getPrefs(context).getBoolean(key, defaultValue)
    }

    fun save(context: Context?, key: String?, value: String?) {
        getPrefs(context).edit().putString(key, value).commit()
    }

    fun getString(context: Context?, key: String?): String? {
        return getPrefs(context).getString(key, "")
    }

    @JvmStatic
    fun getString(context: Context?, key: String?, defaultValue: String?): String? {
        return getPrefs(context).getString(key, defaultValue)
    }

    fun save(context: Context?, key: String?, value: Int) {
        getPrefs(context).edit().putInt(key, value).commit()
    }

    fun getInt(context: Context?, key: String?): Int {
        return getPrefs(context).getInt(key, 0)
    }

    @JvmStatic
    fun getInt(context: Context?, key: String?, defaultValue: Int): Int {
        return getPrefs(context).getInt(key, defaultValue)
    }

    fun save(context: Context?, key: String?, value: Float) {
        getPrefs(context).edit().putFloat(key, value).commit()
    }

    fun getFloat(context: Context?, key: String?): Float {
        return getPrefs(context).getFloat(key, 0f)
    }

    fun getFloat(context: Context?, key: String?, defaultValue: Float): Float {
        return getPrefs(context).getFloat(key, defaultValue)
    }

    fun save(context: Context?, key: String?, value: Long) {
        getPrefs(context).edit().putLong(key, value).commit()
    }

    fun getLong(context: Context?, key: String?): Long {
        return getPrefs(context).getLong(key, 0)
    }

    fun getLong(context: Context?, key: String?, defaultValue: Long): Long {
        return getPrefs(context).getLong(key, defaultValue)
    }

    fun removeKey(context: Context?, key: String?) {
        getPrefs(context).edit().remove(key).commit()
    }
}