package com.hd.wallpaper.solid.color.background.imagePicker.model;

import android.app.Activity;
import android.graphics.Bitmap;

import java.util.ArrayList;
import java.util.List;

public class Constant {
    public static final int WRITE_EXTERNAL_STORAGE_CODE = 124;
    public static List<Image> selectedImage=new ArrayList<>();
    public static String imagePath=null;
    public static String cropedImage;
    public static String selectedImagePathFree;
    public static Activity activity;

    public static List<Image> viewImageList=new ArrayList<>();
    public static int viewImagePosition=0;
    public static int lastSelectedImage=-1;
    public static Bitmap finalBitmap;
    public static Bitmap cropedBitmapFree;
    public static String selectedPath;
    public static int selectedColor;
    public static String selectedRatio;
    public static String savedImagePath;

    public static boolean isInterstial1;
    public static boolean isInterstial2;
    public static boolean isInterstial3;

    public static boolean isNative1;
    public static boolean isNative2;
    public static boolean isNative3;

}
