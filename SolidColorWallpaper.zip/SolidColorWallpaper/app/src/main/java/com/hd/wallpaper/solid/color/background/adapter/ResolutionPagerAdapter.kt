package com.hd.wallpaper.solid.color.background.adapter

import android.annotation.SuppressLint
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import com.hd.wallpaper.solid.color.background.fragment.PagerItemFragment
import com.hd.wallpaper.solid.color.background.model.ResolutionModel
import java.util.*

class ResolutionPagerAdapter @SuppressLint("WrongConstant") constructor(fm: FragmentManager?, private val mResolutionModelList: ArrayList<ResolutionModel>) : FragmentStatePagerAdapter(fm!!) {
    override fun getItem(position: Int): Fragment {
        var fragment: Fragment? = null
        fragment = PagerItemFragment(mResolutionModelList[position])
        return fragment
    }

    override fun getCount(): Int {
        // Show 3 total pages.
        return mResolutionModelList.size
    }

}