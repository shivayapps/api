package com.hd.wallpaper.solid.color.background.activity

import android.content.Intent
import android.content.res.Configuration
import android.content.res.Resources
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import com.hd.wallpaper.solid.color.background.BuildConfig
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.SolidWallpaperApplication
import com.hd.wallpaper.solid.color.background.adapter.SavedImagesAdapter
import com.hd.wallpaper.solid.color.background.constants.Constants
import com.hd.wallpaper.solid.color.background.custom.BottomSheetFragment
import com.hd.wallpaper.solid.color.background.custom.GridSpacingItemDecoration
import com.hd.wallpaper.solid.color.background.databinding.ActivityMyCreationBinding
import com.hd.wallpaper.solid.color.background.databinding.ActivityMyCreationNewBinding
import com.hd.wallpaper.solid.color.background.model.SavedImageModel
import com.hd.wallpaper.solid.color.background.shared_pref.MySharedPref
import java.io.File
import java.io.FileFilter
import java.util.*

class MyCreationNewActivity constructor() : AppCompatActivity() {
//    private var recyclerWallpaper: RecyclerView? = null
    private var imagePaths: ArrayList<SavedImageModel>? = null
    private var adapter: SavedImagesAdapter? = null
//    private var layoutDelete: LinearLayout? = null
    private var isMenuOpen: Boolean = false
    private val tag: String? = null
//    private var imgBack: ImageView? = null
//    private var imgShare: ImageView? = null
    private val isDataChanged: Boolean = false
    private val mySharedPref: MySharedPref? = null

    lateinit var binding:ActivityMyCreationNewBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityMyCreationNewBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        setContentView(R.layout.activity_my_creation_new)
        System.gc()
//        recyclerWallpaper = findViewById(R.id.recyclerWallpaper)
//        layoutDelete = findViewById(R.id.layoutDelete)
//        imgShare = findViewById(R.id.imgShare)
//        imgBack = findViewById(R.id.imgBack)
        binding.imgShare!!.setOnClickListener {
            if (isMenuOpen) {
                shareImageAll()
            } else {
                showSnackbar(resources.getString(R.string.long_click_on_image_to_share))
            }
        }
        binding.imgBack!!.setOnClickListener { finish() }
        val manager: GridLayoutManager = GridLayoutManager(this, 3)
        binding.recyclerWallpaper!!.layoutManager = manager
        binding.recyclerWallpaper!!.addItemDecoration(GridSpacingItemDecoration(3, dpToPx(8), true))
        binding.recyclerWallpaper!!.itemAnimator = DefaultItemAnimator()
        binding.layoutDelete!!.setOnClickListener {
            var isEnable: Boolean = false
            for (i in adapter!!.allUpdatedList.indices) {
                val model: SavedImageModel = adapter!!.allUpdatedList.get(i)
                if (model.isDeletedEnable) {
                    isEnable = true
                    break
                }
            }
            if (isEnable) {
                showDeleteDialog()
            } else {
                Toast.makeText(this@MyCreationNewActivity, resources.getString(R.string.select_image_to_delete), Toast.LENGTH_SHORT).show()
            }
        }
        findViewById<View>(R.id.txtCreate).setOnClickListener {
            Constants.isFromFrag = false
            startActivity(Intent(this@MyCreationNewActivity, HomeActivity::class.java))
            // getActivity().finish();
        }
        photoes
    }

    private fun shareImageAll() {
        var mAllUpdatedData: ArrayList<SavedImageModel>? = ArrayList()
        if (adapter != null) {
            mAllUpdatedData = adapter!!.allUpdatedList
        }
        var isShare: Boolean = false
        if (mAllUpdatedData != null) {
            for (i in mAllUpdatedData.indices) {
                if (mAllUpdatedData[i].isDeletedEnable) {
                    isShare = true
                    break
                }
            }
        }
        if (mAllUpdatedData != null && isShare) {
            shareImage(mAllUpdatedData)
        } else {
            showSnackbar(getResources().getString(R.string.select_image_to_share))
        }
    }

    private fun showSnackbar(msg: String) {
        val snackbar: Snackbar = Snackbar.make(findViewById(R.id.mainLayout), msg, Snackbar.LENGTH_SHORT)
        val v: View = snackbar.view
        val params: CoordinatorLayout.LayoutParams = v.layoutParams as CoordinatorLayout.LayoutParams
        params.gravity = Gravity.BOTTOM
        params.width = FrameLayout.LayoutParams.MATCH_PARENT
        v.layoutParams = params
        v.setBackgroundColor(resources.getColor(R.color.colorStart))
        val textView: TextView = v.findViewById(com.google.android.material.R.id.snackbar_text)
        textView.setTextColor(resources.getColor(R.color.white))
        snackbar.show()
    }

    private fun shareImage(updatedData: ArrayList<SavedImageModel>) {
        Log.d("785645645121", "shareImage: " + updatedData.size)
        val mSharedUri: ArrayList<Uri> = ArrayList()
        for (i in updatedData.indices) {
            if (updatedData[i].isDeletedEnable) {
                val uri: Uri = FileProvider.getUriForFile(this@MyCreationNewActivity, BuildConfig.APPLICATION_ID.toString() + ".provider", File(updatedData.get(i).path))
                mSharedUri.add(uri)
            }
        }
        val intent: Intent = Intent(Intent.ACTION_SEND_MULTIPLE)
        intent.type = "image/jpeg"
        intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, mSharedUri)
        var shareMessage: String = ""
        shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=com.solid.color.wallpaper.hd.image.background"
        intent.putExtra(Intent.EXTRA_TEXT, shareMessage)
        startActivity(Intent.createChooser(intent, getResources().getString(R.string.share_wallpaper)))
    }

    private fun shareOwnApp() {
        val shareIntent: Intent = Intent(Intent.ACTION_SEND)
        shareIntent.type = "text/plain"
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Solid Color Wallpaper")
        var shareMessage: String = ""
        shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=com.solid.color.wallpaper.hd.image.background"
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
        startActivity(Intent.createChooser(shareIntent, getResources().getString(R.string.choose_one)))
    }

    private val photoes: Unit
        private get() {
            imagePaths = ArrayList()
            val file: File = File(Constants.path)
            if (file.isDirectory) {
                val files: Array<File> = file.listFiles { pathname -> pathname.getPath().endsWith(".jpg") || pathname.getPath().endsWith(".jpeg") || pathname.getPath().endsWith(".png") }
                if (files.isNotEmpty()) {
                    var temp: File
                    for (i in files.indices) {
                        for (j in i + 1 until files.size) {
                            if (files.get(i).lastModified() < files[j].lastModified()) {
                                temp = files.get(i)
                                files[i] = files[j]
                                files[j] = temp
                            }
                        }
                    }
                    for (value: File in files) {
                        val model: SavedImageModel = SavedImageModel()
                        model.path = value.absolutePath
                        model.isDeletedEnable = false
                        imagePaths!!.add(model)
                    }
                }
            }
            if (imagePaths!!.size > 0) {
                setDataToAdapter()
                findViewById<View>(R.id.nowallpaper).visibility = View.GONE
                binding.recyclerWallpaper!!.visibility = View.VISIBLE
            } else {
                findViewById<View>(R.id.nowallpaper).visibility = View.VISIBLE
                binding.recyclerWallpaper!!.visibility = View.GONE
            }
        }

    private fun setDataToAdapter() {
        val listener: SavedImagesAdapter.setOnItemClickListener = object : SavedImagesAdapter.setOnItemClickListener {
            public override fun OnItemClickedImage(position: Int) {
                Constants.selectedPosition = position
                Constants.viewpagerPos = 1
                Constants.isDataChanges = false

                /*  if (!mySharedPref.getAdsRemoved()) {
                    if (SolidWallpaperApplication.getInstance().requestNewInterstitial()) {
                        SolidWallpaperApplication.getInstance().mInterstitialAd.setAdListener(new AdListener() {

                            @Override
                            public void onAdClosed() {
                                super.onAdClosed();
                                loadInterstialAd();
                                startActivity(new Intent(getActivity(), WallpaperViewActivity.class));
                            }

                            @Override
                            public void onAdFailedToLoad(int i) {
                                super.onAdFailedToLoad(i);
                                startActivity(new Intent(getActivity(), WallpaperViewActivity.class));

                            }

                            @Override
                            public void onAdLoaded() {
                                super.onAdLoaded();
                            }
                        });

                    } else {
                        startActivity(new Intent(getActivity(), WallpaperViewActivity.class));

                    }
                }else {*/

                Constants.isText = false
                startActivity(Intent(this@MyCreationNewActivity, WallpaperViewActivity::class.java))
                //      }
            }

            public override fun OnLongClickImage(position: Int) {
                openMenu()
            }
        }
        adapter = SavedImagesAdapter((imagePaths)!!, this@MyCreationNewActivity, listener)
        binding.recyclerWallpaper!!.adapter = adapter
    }

    private fun openMenu() {
        isMenuOpen = true
        binding.imgShare!!.alpha = 1f
        binding.layoutDelete!!.animate().withStartAction { binding.layoutDelete!!.visibility = View.VISIBLE }.translationYBy(-binding.layoutDelete!!.height.toFloat()).setDuration(500).start()
    }

    private fun closeMenu() {
        isMenuOpen = false
        binding.layoutDelete!!.animate().translationY(binding.layoutDelete!!.height.toFloat()).setDuration(500).withEndAction { binding.layoutDelete!!.visibility = View.GONE }.start()
    }

    private fun showDeleteDialog() {
        val bottomSheetFragment: BottomSheetFragment = BottomSheetFragment(getResources().getString(R.string.delete), getResources().getString(R.string.are_you_want_to_remove), getResources().getString(R.string.delete), getResources().getString(R.string.cancel), R.drawable.ic_delete_dialog, object : BottomSheetFragment.OnButtonClickListener {
            public override fun onPositive(bottomSheetDialo: BottomSheetFragment?) {
                bottomSheetDialo!!.dismiss()
                for (i in adapter!!.allUpdatedList.indices) {
                    val model: SavedImageModel = adapter!!.allUpdatedList.get(i)
                    if (model.isDeletedEnable) {
                        val ffile: File = File(model.path)
                        ffile.delete()
                        MediaScannerConnection.scanFile(this@MyCreationNewActivity, arrayOf(ffile.absolutePath), null,
                                object : MediaScannerConnection.MediaScannerConnectionClient {
                                    public override fun onMediaScannerConnected() {}
                                    public override fun onScanCompleted(path: String, uri: Uri) {}
                                })
                    }
                }
                photoes
                closeMenu()
            }

            public override fun onNegative(bottomSheetDialog: BottomSheetFragment?) {
                bottomSheetDialog!!.dismiss()
            }
        })
        bottomSheetFragment.show(supportFragmentManager, "dialog")
    }

    private fun dpToPx(dp: Int): Int {
        val r: Resources = resources
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), r.displayMetrics))
    }

    override fun onResume() {
        super.onResume()
        SolidWallpaperApplication.staticLanguage.Factory.create(this)
        if (Constants.isDataChanges) {
            photoes
            Constants.isDataChanges = false
        }
    }

    public override fun onBackPressed() {
        if (isMenuOpen) {
            closeMenu()
            binding.imgShare!!.alpha = 0.6f
            adapter!!.setDataChange()
        } else {
            super.onBackPressed()
        }
    }
}