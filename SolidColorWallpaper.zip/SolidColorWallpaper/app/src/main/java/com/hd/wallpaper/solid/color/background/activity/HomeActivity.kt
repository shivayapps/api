package com.hd.wallpaper.solid.color.background.activity

import android.Manifest
import android.app.Activity
import android.app.ProgressDialog
import android.content.ActivityNotFoundException
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.interpolator.view.animation.FastOutSlowInInterpolator
import androidx.viewpager.widget.ViewPager
import androidx.viewpager.widget.ViewPager.OnPageChangeListener
import com.hd.wallpaper.solid.color.background.adhelper.NativeAdvancedModelHelper

import com.google.android.material.snackbar.Snackbar
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.SolidWallpaperApplication

import com.hd.wallpaper.solid.color.background.constants.Constants
import com.hd.wallpaper.solid.color.background.databinding.ActivityHomeBinding
import com.hd.wallpaper.solid.color.background.fragment.GradientWallpaperFragment
import com.hd.wallpaper.solid.color.background.fragment.GradientWallpaperFragment.onScrollChangeF
import com.hd.wallpaper.solid.color.background.fragment.SolidWallpaperFragment
import com.hd.wallpaper.solid.color.background.fragment.SolidWallpaperFragment.onScrollChange
import com.hd.wallpaper.solid.color.background.fragment.TextWallpaperFragment
import com.hd.wallpaper.solid.color.background.fragment.TextWallpaperFragment.onScrollChangeWall

import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs.getBoolean
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs.save
import com.hd.wallpaper.solid.color.background.shared_pref.MySharedPref
import com.willy.ratingbar.BaseRatingBar
import com.willy.ratingbar.ScaleRatingBar
import uk.co.samuelwall.materialtaptargetprompt.MaterialTapTargetPrompt
import java.util.*

class HomeActivity : AppCompatActivity(), View.OnClickListener {
    //    private var imgOpenDrawer: ImageView? = null
    private var imgBack: ImageView? = null
    private var btnAdd: ImageView? = null

    //    private var imgOpenDrawerD: ImageView? = null
//    private var imgSettings: ConstraintLayout? = null
    private var btnSolid: TextView? = null
    private var btnGradient: TextView? = null
    private var btnText: TextView? = null
    private var viewpager: ViewPager? = null
    private var isSolidWallpaper = false

    //    private var navigationView: NavigationView? = null
//    private var mainDrawer: DrawerLayout? = null
//    private var llMoreApps: LinearLayout? = null

    //    private var llMyWallpaper: LinearLayout? = null
//    private var llShareApps: LinearLayout? = null
//    private var llRateApps: LinearLayout? = null

    //    private val imgProUser: LinearLayout? = null
//    private var llWallaperOftheWeek: LinearLayout? = null
//    private var llAutoWallpaperChaneger: LinearLayout? = null
    private var mySharedPref: MySharedPref? = null
//    private var viewUpdate: View? = null

    //  private LockableNestedScrollView mNestedScrollView;
    private var titleText: TextView? = null
    private var solidWallpaperFragment: SolidWallpaperFragment? = null
    private var gradientWallpaperFragment: GradientWallpaperFragment? = null
    private var textWallpaperFragment: TextWallpaperFragment? = null
    private var ProductKey = ""
    private var LicenseKey = ""
    private var mUpgradeDialog: ProgressDialog? = null
    private var mActivity: Activity? = null
    private var currentVersion: String? = null

    private var viewpagerPosition = 1
    private var nativeAdLayout: FrameLayout? = null
    private var adViewa: LinearLayout? = null

    var isfirst = true
    private val TAG: String = HomeActivity::class.java.getSimpleName()

    lateinit var binding: ActivityHomeBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        setContentView(R.layout.activity_home)
        if (getBoolean(this@HomeActivity, AdsPrefs.IS_NEED_TO_SHOW_SPOTLIGHT_GRADIENT, true)) {
            Overlayshowbar()
            save(this@HomeActivity, AdsPrefs.IS_NEED_TO_SHOW_SPOTLIGHT_GRADIENT, false)
        }
        System.gc()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // Permission is not granted
            startActivity(Intent(this@HomeActivity, MainStartActivity::class.java))
            finish()
        } else {
            mActivity = this@HomeActivity
            try {
                currentVersion = packageManager.getPackageInfo(packageName, 0).versionName
            } catch (e: PackageManager.NameNotFoundException) {
                e.printStackTrace()
            }

            //    currentVersion="ds";
//            GetVersionCode().execute()
            ProductKey = getString(R.string.ads_product_key)
            LicenseKey = getString(R.string.licenseKey)
            mySharedPref = MySharedPref(this)
            if (!getBoolean(this@HomeActivity, AdsPrefs.IS_SUBSCRIBED, false)) {

                Constants.isInstrastial1 = true
//                loadInterstialAd()
//                loadInterstialAdFb()


            } else {
                findViewById<View>(R.id.ads).visibility = View.GONE
            }
            initViews()
//            llMoreApps = findViewById(R.id.llMoreApps)
//            //   imgProUser = findViewById(R.id.imgProUser);
//            viewUpdate = findViewById(R.id.viewUpdate)
//            if (mySharedPref!!.visitPlay != null) {
//                llRateApps!!.visibility = View.GONE
//            }


            setStatusbarColor()
            initViewAction()
            initListner()
            if (!getBoolean(this@HomeActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                nativeAdLayout = findViewById(R.id.native_ad_container) as FrameLayout
                NativeAdvancedModelHelper(this@HomeActivity).loadNativeAdvancedAd(
                    fSize = "NativeAdsSize.Medium",
                    fLayout = nativeAdLayout!!,
                    isAdLoaded = {}
                )
            }
        }
    }

    fun getEmojiByUnicode(unicode: Int): String {
        return String(Character.toChars(unicode))
    }

    private fun initViewAction() {


        //  mNestedScrollView = findViewById(R.id.nestedScrollview);
        //  mNestedScrollView.setSmoothScrollingEnabled(true);


        /* findViewById(R.id.appBar).getViewTreeObserver().addOnScrollChangedListener(new ViewTreeObserver.OnScrollChangedListener() {
            @Override
            public void onScrollChanged() {
                Log.d("78874564454547456153", "onScrollChanged: ");

                if (findViewById(R.id.appBar).getBottom() > 0) {
                    titleText.setText("Home");
                } else {
                    if (viewpager.getCurrentItem() == 0) {
                        titleText.setText("Solid");
                    } else if (viewpager.getCurrentItem() == 1) {
                        titleText.setText("Gradient");
                    } else if (viewpager.getCurrentItem() == 2) {
                        titleText.setText("Text");
                    }
                }
            }
        });
    */
        val onScrollChange: onScrollChange = object : onScrollChange {
            override fun onScrollChangeinit(dx: Int, dy: Int) {

            }
        }
        solidWallpaperFragment = SolidWallpaperFragment(onScrollChange)
        val onScrollChange1: onScrollChangeF = object : onScrollChangeF {
            override fun onScrollChangeinit(dx: Int, dy: Int) {

            }
        }
        gradientWallpaperFragment = GradientWallpaperFragment(onScrollChange1)
        val onScrollChange2: onScrollChangeWall = object : onScrollChangeWall {
            override fun onScrollChangeinit(dx: Int, dy: Int) {

            }
        }
        textWallpaperFragment = TextWallpaperFragment(onScrollChange2)


        /* mainDrawer.addDrawerListener(new DrawerLayout.DrawerListener() {
            @Override
            public void onDrawerSlide(@NonNull View drawerView, float slideOffset) {
                Log.d("78945612123", "onDrawerSlide: "+slideOffset);
                Log.d("78945612123", "initViewAction: "+findViewById(R.id.mainDrawerLay).getWidth());
                Log.d("78945612123", "initViewAction: "+mainDrawer.getWidth()*slideOffset);
                findViewById(R.id.home).setTranslationX(findViewById(R.id.mainDrawerLay).getWidth()*slideOffset);
            }

            @Override
            public void onDrawerOpened(@NonNull View drawerView) {

            }

            @Override
            public void onDrawerClosed(@NonNull View drawerView) {

            }

            @Override
            public void onDrawerStateChanged(int newState) {

            }
        });*/viewpager!!.adapter = ViewPagerAdapter(supportFragmentManager)
        viewpager!!.currentItem = 1
        viewpager!!.addOnPageChangeListener(object : OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {
            }

            override fun onPageSelected(position: Int) {
                if (!isfirst) {
                    if (prompt != null) {
                        prompt!!.dismiss()
                    }
                } else {
                    isfirst = false
                }
                viewpagerPosition = position
                if (position == 0) {
                    isSolidWallpaper = true
                    btnSolid!!.setTextColor(resources.getColor(R.color.text_colour_new))
                    btnGradient!!.setTextColor(resources.getColor(R.color.unselected_button))
                    btnText!!.setTextColor(resources.getColor(R.color.unselected_button))
                    if (getBoolean(
                            this@HomeActivity,
                            AdsPrefs.IS_NEED_TO_SHOW_SPOTLIGHT_SOLID,
                            true
                        )
                    ) {

                        /*  findViewById(R.id.frameSpotlight).setVisibility(View.VISIBLE);
                        SpotlightFragment fragment = new SpotlightFragment(new SpotlightFragment.OnItemClicked() {
                            @Override
                            public void onItemClicked() {
                                findViewById(R.id.frameSpotlight).setVisibility(View.GONE);
                                Constants.isFromFrag = false;
                                startActivity(new Intent(HomeActivity.this, CreateSolidWallpaperActivity.class));

                            }
                        }, 0);

                        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                        transaction.replace(R.id.frameSpotlight, fragment);
                        transaction.addToBackStack(null);
                        transaction.commit();
                        AdsPrefs.save(HomeActivity.this, AdsPrefs.IS_NEED_TO_SHOW_SPOTLIGHT_SOLID, false);*/
                        save(this@HomeActivity, AdsPrefs.IS_NEED_TO_SHOW_SPOTLIGHT_SOLID, false)
                        Overlayshowbar()
                    }
                } else if (position == 1) {
                    isSolidWallpaper = false
                    btnGradient!!.setTextColor(resources.getColor(R.color.text_colour_new))
                    btnSolid!!.setTextColor(resources.getColor(R.color.unselected_button))
                    btnText!!.setTextColor(resources.getColor(R.color.unselected_button))
                    if (getBoolean(
                            this@HomeActivity,
                            AdsPrefs.IS_NEED_TO_SHOW_SPOTLIGHT_GRADIENT,
                            true
                        )
                    ) {
                        /*  findViewById(R.id.frameSpotlight).setVisibility(View.VISIBLE);
                        SpotlightFragment fragment = new SpotlightFragment(new SpotlightFragment.OnItemClicked() {
                            @Override
                            public void onItemClicked() {
                                findViewById(R.id.frameSpotlight).setVisibility(View.GONE);
                                Constants.isFromFrag = false;
                                startActivity(new Intent(HomeActivity.this, CreateGradientWallpaperActivity.class));

                            }
                        }, 1);

                        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                        transaction.replace(R.id.frameSpotlight, fragment);
                        transaction.addToBackStack(null);
                        transaction.commit();
                        AdsPrefs.save(HomeActivity.this, AdsPrefs.IS_NEED_TO_SHOW_SPOTLIGHT_GRADIENT, false);*/
                        save(this@HomeActivity, AdsPrefs.IS_NEED_TO_SHOW_SPOTLIGHT_GRADIENT, false)
                        Overlayshowbar()
                    }
                } else {
                    isSolidWallpaper = false
                    btnGradient!!.setTextColor(resources.getColor(R.color.unselected_button))
                    btnSolid!!.setTextColor(resources.getColor(R.color.unselected_button))
                    btnText!!.setTextColor(resources.getColor(R.color.text_colour_new))
                    if (getBoolean(
                            this@HomeActivity,
                            AdsPrefs.IS_NEED_TO_SHOW_SPOTLIGHT_TEXT,
                            true
                        )
                    ) {

                        /*    findViewById(R.id.frameSpotlight).setVisibility(View.VISIBLE);
                        SpotlightFragment fragment = new SpotlightFragment(new SpotlightFragment.OnItemClicked() {
                            @Override
                            public void onItemClicked() {
                                findViewById(R.id.frameSpotlight).setVisibility(View.GONE);
                                Constants.isFromFrag = false;
                                startActivity(new Intent(HomeActivity.this, AddTextActivity.class));

                            }
                        }, 2);

                        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                        transaction.replace(R.id.frameSpotlight, fragment);
                        transaction.addToBackStack(null);
                        transaction.commit();
                        AdsPrefs.save(HomeActivity.this, AdsPrefs.IS_NEED_TO_SHOW_SPOTLIGHT_TEXT, false);*/
                        save(this@HomeActivity, AdsPrefs.IS_NEED_TO_SHOW_SPOTLIGHT_TEXT, false)
                        Overlayshowbar()
                    }
                }
            }

            override fun onPageScrollStateChanged(state: Int) {}
        })
    }

    private fun Overlayshowbar() {
        val text: String
        text = if (viewpagerPosition == 0) {
            resources.getString(R.string.create_solid_color_wallpaper)
        } else if (viewpagerPosition == 1) {
            resources.getString(R.string.create_gradient_color_wallpaper)
        } else {
            resources.getString(R.string.create_custom_text_wallpaper)
        }
        prompt = MaterialTapTargetPrompt.Builder(this)
            .setTarget(findViewById<View>(R.id.btnAdd))
            .setPrimaryText(resources.getString(R.string.create_custom_wallpaper))
            .setSecondaryText(text)
            .setBackgroundColour(resources.getColor(R.color.colorStart))
            .setAnimationInterpolator(FastOutSlowInInterpolator())
            .setIcon(R.drawable.spot_add)
            .setIconDrawableColourFilter(resources.getColor(R.color.colorPrimary))
            .setPromptStateChangeListener { prompt, state -> /*if (state == MaterialTapTargetPrompt.STATE_FOCAL_PRESSED) {
                            if (viewpagerPosition == 0) {
                                Constants.isFromFrag = false;
                                startActivity(new Intent(HomeActivity.this, CreateSolidWallpaperActivity.class));
                            } else if (viewpagerPosition == 1) {
                                Constants.isFromFrag = false;
                                startActivity(new Intent(HomeActivity.this, CreateGradientWallpaperActivity.class));
                            } else {
                                Constants.isFromFrag = false;
                                startActivity(new Intent(HomeActivity.this, AddTextActivity.class));
                            }
                        }*/
            }
            .show()
    }

    val statusBarHeight: Int
        get() {
            var result = 0
            val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
            if (resourceId > 0) {
                result = resources.getDimensionPixelSize(resourceId)
            }
            return result
        }

    private fun initListner() {
        btnGradient!!.setOnClickListener(this)
        btnSolid!!.setOnClickListener(this)
        btnAdd!!.setOnClickListener(this)
        btnText!!.setOnClickListener(this)
        imgBack!!.setOnClickListener(this)
//        imgOpenDrawerD!!.setOnClickListener(this)
//        llShareApps!!.setOnClickListener(this)
//        llRateApps!!.setOnClickListener(this)
//        llMoreApps!!.setOnClickListener(this)
//        llMyWallpaper!!.setOnClickListener(this)
        // imgProUser.setOnClickListener(this);
//        llWallaperOftheWeek!!.setOnClickListener(this)
//        imgSettings!!.setOnClickListener(this)
//        llAutoWallpaperChaneger!!.setOnClickListener(this)
    }

    private fun initViews() {
//        viewpager = findViewById(R.id.viewpager)
//        titleText = findViewById(R.id.titleText)
//        btnAdd = findViewById(R.id.btnAdd)
//        btnSolid = findViewById(R.id.btnSolid)
//        btnGradient = findViewById(R.id.btnGradient)
//        btnText = findViewById(R.id.btnText)
//        imgOpenDrawer = findViewById(R.id.imgOpenDrawer)
//        imgOpenDrawerD = findViewById(R.id.imgOpenDrawerD)
//        navigationView = findViewById(R.id.navigationView)
//        mainDrawer = findViewById(R.id.mainDrawer)
//        llRateApps = findViewById(R.id.llRateApps)
//        llMyWallpaper = findViewById(R.id.llMyWallpaper)
//        llShareApps = findViewById(R.id.llShareApps)
//        llWallaperOftheWeek = findViewById(R.id.llWallaperOftheWeek)
//        llAutoWallpaperChaneger = findViewById(R.id.llAutoWallpaperChaneger)
//        imgSettings = findViewById(R.id.imgSettings)

        viewpager = binding.viewpager
        titleText = binding.titleText
        btnAdd = binding.btnAdd
        btnSolid = binding.btnSolid
        btnGradient = binding.btnGradient
        btnText = binding.btnText
        imgBack = binding.icBack
//        imgOpenDrawerD = binding.imgOpenDrawerD
//        navigationView = binding.navigationView
//        mainDrawer = binding.mainDrawer
//        llRateApps = binding.llRateApps
//        llMyWallpaper = binding.llMyWallpaper
//        llShareApps = binding.llShareApps
//        llWallaperOftheWeek = binding.llWallaperOftheWeek
//        llAutoWallpaperChaneger = binding.llAutoWallpaperChaneger
//        imgSettings = binding.imgSettings

    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.btnGradient -> onclickGradient()
            R.id.btnSolid -> onclickSolid()
            R.id.btnText -> onclickText()
            R.id.icBack -> {
                onBackPressed()
//                Log.d(TAG, "onClick: ")
//                onclickOpenDrawer()
            }

            R.id.imgOpenDrawerD -> onclickCloseDrawer()
            R.id.llShareApps -> onclickShareApps()
            R.id.llMyWallpaper -> {
            }

            R.id.llRateApps -> showRateDialog()
            R.id.llAutoWallpaperChaneger -> onclickAutoWallpaperChanger()
            R.id.llMoreApps -> onclickMoreApps()
            R.id.llWallaperOftheWeek -> onclickWallpaperoftheweek()
            R.id.imgSettings -> onClickSettings()
            R.id.btnAdd -> {
                Constants.isFromFrag = false
                if (viewpager!!.currentItem == 0) {
                    startActivity(
                        Intent(
                            this@HomeActivity,
                            CreateSolidWallpaperActivity::class.java
                        )
                    )
                } else if (viewpager!!.currentItem == 1) {
                    startActivity(
                        Intent(
                            this@HomeActivity,
                            CreateGradientWallpaperActivity::class.java
                        )
                    )
                } else {
                    startActivity(Intent(this@HomeActivity, AddTextActivity::class.java))
                }
            }
        }
    }


    private fun onclickAutoWallpaperChanger() {
//        mainDrawer!!.closeDrawer(GravityCompat.START)
//        Handler().postDelayed({ startActivity(Intent(this@HomeActivity, AutoWallpaperChangerMainTestActivity::class.java)) }, 200)
    }

    private fun onClickSettings() {
//        mainDrawer!!.closeDrawer(GravityCompat.START)
//        Handler().postDelayed({ startActivity(Intent(this@HomeActivity, SettingsActivity::class.java)) }, 200)
    }

    private fun onclickWallpaperoftheweek() {
//        mainDrawer!!.closeDrawer(GravityCompat.START)
        //Handler().postDelayed({ startActivity(Intent(this@HomeActivity, WallpaperOfWeekNewActivity::class.java)) }, 200)
//        Handler().postDelayed({ startActivity(Intent(this@HomeActivity, WallPaperServerActivity::class.java)) }, 200)
    }

    private fun onclickProUser() {
//        mainDrawer!!.closeDrawer(GravityCompat.START)
//        showSnackBar(resources.getString(R.string.you_are_pro_user))
    }

    private fun showSnackBar(msg: String) {

        // Create the Snackbar
        val snackbar = Snackbar.make(findViewById(R.id.mainLayout), "", Snackbar.LENGTH_LONG)
        val layout = snackbar.view as Snackbar.SnackbarLayout
        val textView = layout.findViewById<TextView>(com.google.android.material.R.id.snackbar_text)
        textView.visibility = View.INVISIBLE
        val snackView = LayoutInflater.from(this).inflate(R.layout.my_snackbar, null)
        layout.setPadding(0, 0, 0, 0)
        layout.addView(snackView, 0)
        snackbar.show()
    }


    private fun onclickMoreApps() {
//        mainDrawer!!.closeDrawer(GravityCompat.START)
//        Handler().postDelayed({ startActivity(Intent(this@HomeActivity, MoreAppActivityNew::class.java)) }, 200)
    }

    private fun showRateDialog() {
//        mainDrawer!!.closeDrawer(GravityCompat.START)
        val viewGroup = findViewById<ViewGroup>(android.R.id.content)
        val dialogView =
            LayoutInflater.from(this).inflate(R.layout.dialog_rate_app, viewGroup, false)
        val builder = AlertDialog.Builder(this)
        builder.setView(dialogView)
        val alertDialog = builder.create()
        Objects.requireNonNull(alertDialog.window)!!
            .setBackgroundDrawableResource(android.R.color.transparent)
        alertDialog.setOnCancelListener { dialog: DialogInterface? -> alertDialog.dismiss() }
        val btnClose = dialogView.findViewById<ImageView>(R.id.btnClose)
        btnClose.setOnClickListener { v: View? -> alertDialog.dismiss() }
        val ratingBar1: ScaleRatingBar = dialogView.findViewById(R.id.ratingBar)
        ratingBar1.setOnRatingChangeListener { ratingBar: BaseRatingBar?, rating: Float, fromUser: Boolean ->
            if (rating > 3) {
//                llRateApps!!.visibility = View.GONE
                rate_app()
                Handler().postDelayed({ alertDialog.dismiss() }, 1000)
            } else {
//                llRateApps!!.visibility = View.GONE
                sendMail()
                //       Toast.makeText(ViewTextWallpaperActivity.this, getResources().getString(R.string.thanks_for_review), Toast.LENGTH_SHORT).show();
                Handler().postDelayed({ alertDialog.dismiss() }, 1000)
            }
        }
        dialogView.findViewById<View>(R.id.btnNextTime)
            .setOnClickListener { v: View? -> alertDialog.dismiss() }
        if (!isFinishing) {
            alertDialog.show()
        }
    }

    private fun sendMail() {
        mySharedPref!!.setVisitPlay()
        val send = Intent(Intent.ACTION_SENDTO)
        val uriText = "mailto:" + Uri.encode("profagnesh009@gmail.com") +
                "?subject=" + Uri.encode("Share your valuable feedback to improve app quality of Solid Color Wallpaper") +
                "&body=" + Uri.encode("")
        val uri = Uri.parse(uriText)
        send.data = uri
        startActivity(Intent.createChooser(send, "Send Email..."))
    }

    private fun rate_app() {
        mySharedPref!!.setVisitPlay()
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")))
        } catch (anfe: ActivityNotFoundException) {
            startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=$packageName")
                )
            )
        }
    }

    private fun onclickShareApps() {
//        mainDrawer!!.closeDrawer(GravityCompat.START)
        shareApp()
    }

    private fun shareApp() {
        val shareIntent = Intent(Intent.ACTION_SEND)
        shareIntent.type = "text/plain"
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Solid Color Wallpaper")
        var shareMessage = "\nGo with Solid Color Wallpaper and Make Colorful Wallpapers\n\n"
        shareMessage =
            shareMessage + "https://play.google.com/store/apps/details?id=com.solid.color.wallpaper.hd.image.background"
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
        startActivity(Intent.createChooser(shareIntent, resources.getString(R.string.choose_one)))
    }

    private fun onclickCloseDrawer() {
//        mainDrawer!!.closeDrawer(GravityCompat.START)
    }

    private fun onclickOpenDrawer() {
//        Log.d(TAG, "onclickOpenDrawer: " + mainDrawer!!.isDrawerOpen(GravityCompat.START))
//        mainDrawer!!.openDrawer(GravityCompat.START)
    }

    private fun onclickText() {
        btnText!!.setTextColor(Color.BLACK)
        btnGradient!!.setTextColor(resources.getColor(R.color.unselected_button))
        btnSolid!!.setTextColor(resources.getColor(R.color.unselected_button))
        viewpager!!.currentItem = 2
    }

    private fun onclickSolid() {
        btnSolid!!.setTextColor(Color.BLACK)
        btnGradient!!.setTextColor(resources.getColor(R.color.unselected_button))
        btnText!!.setTextColor(resources.getColor(R.color.unselected_button))
        viewpager!!.currentItem = 0
    }

    private fun onclickGradient() {
        btnGradient!!.setTextColor(Color.BLACK)
        btnSolid!!.setTextColor(resources.getColor(R.color.unselected_button))
        btnText!!.setTextColor(resources.getColor(R.color.unselected_button))
        viewpager!!.currentItem = 1
    }

    private fun setStatusbarColor() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = Color.WHITE
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = Color.WHITE
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == 1212) {
            if (MySharedPref(this).getAdsClicked()) {
                findViewById<View>(R.id.native_ad_container).visibility = View.VISIBLE
            } else {
                findViewById<View>(R.id.native_ad_container).visibility = View.GONE
            }
        }

    }

//    override fun onProductPurchased(productId: String, details: TransactionDetails?) {
//        if (mUpgradeDialog != null && mUpgradeDialog!!.isShowing) {
//            mUpgradeDialog!!.dismiss()
//        }
//        Toast.makeText(mActivity, resources.getString(R.string.successfully_purchased), Toast.LENGTH_SHORT).show()
//
//        //  mySharedPref.setAdsRemoved();
//        llMoreApps!!.visibility = View.GONE
//        Log.d(TAG, "onProductPurchased: ")
//        findViewById<View>(R.id.ads).visibility = View.GONE
//        recreate()
//    }

    inner class ViewPagerAdapter(fm: FragmentManager?) : FragmentPagerAdapter(fm!!) {
        override fun getItem(position: Int): Fragment {
            return return when (position) {
                0 -> solidWallpaperFragment!!
                1 -> gradientWallpaperFragment!!
                //                2 -> return textWallpaperFragment!!
                else -> textWallpaperFragment!!
            }
//            return null
        }

        override fun getCount(): Int {
            return 3
        }
    }

//    private fun loadInterstialAd() {
//        if (instance!!.mInterstitialAd!!.isLoaded) {
//        } else {
//            instance!!.mInterstitialAd!!.adListener = null
//            instance!!.mInterstitialAd = null
//            instance!!.ins_adRequest = null
//            instance!!.LoadAds()
//            instance!!.mInterstitialAd!!.adListener = object : AdListener() {
//                override fun onAdLoaded() {
//                    super.onAdLoaded()
//                }
//
//                override fun onAdFailedToLoad(i: Int) {
//                    super.onAdFailedToLoad(i)
//                    loadInterstialAd()
//                }
//            }
//        }
//    }

//    private fun loadInterstialAdFb() {
//        if (instance!!.mInterstitialAdfb!!.isAdLoaded) {
//        } else {
//            instance!!.mInterstitialAdfb!!.setAdListener(null)
//            instance!!.mInterstitialAdfb = null
//            instance!!.LoadAdsFb()
//            instance!!.mInterstitialAdfb!!.setAdListener(object : InterstitialAdListener {
//                override fun onError(ad: Ad, adError: AdError) {
//                    //loadInterstialAdFb();
//                    loadInterstialAd()
//                }
//
//                override fun onAdLoaded(ad: Ad) {}
//                override fun onAdClicked(ad: Ad) {}
//                override fun onLoggingImpression(ad: Ad) {}
//                override fun onInterstitialDisplayed(ad: Ad) {}
//                override fun onInterstitialDismissed(ad: Ad) {
//                    loadInterstialAd()
//                    loadInterstialAdFb()
//                }
//            })
//        }
//    }

//    override fun attachBaseContext(newBase: Context) {
//        super.attachBaseContext(newBase)
//        SolidWallpaperApplication.staticLanguage.Factory.create(newBase)
//
//    }


    override fun onResume() {
        super.onResume()
        SolidWallpaperApplication.staticLanguage.Factory.create(this)
        if (Constants.isSubscribedH) {
            recreate()
            Constants.isSubscribedH = false
        }
        if (Constants.isLanguageChanged) {
            recreate()
            Constants.isLanguageChanged = false
        }
//        if (!getBoolean(this@HomeActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
//            llMoreApps!!.visibility = View.VISIBLE
//        } else {
//            llMoreApps!!.visibility = View.GONE
//        }
//        if (mySharedPref != null && llShareApps != null && mySharedPref!!.visitPlay != null) {
//            llRateApps!!.visibility = View.GONE
//        }
    }

//    private val adSize: AdSize
//        private get() {
//            val display = windowManager.defaultDisplay
//            val outMetrics = DisplayMetrics()
//            display.getMetrics(outMetrics)
//            val widthPixels = outMetrics.widthPixels.toFloat()
//            val density = outMetrics.density
//            val adWidth = (widthPixels / density).toInt()
//            return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth)
//        }

    override fun onBackPressed() {
        if (findViewById<View>(R.id.frameSpotlight).visibility == View.VISIBLE) {
            findViewById<View>(R.id.frameSpotlight).visibility = View.GONE
            return
        }
//        if (mainDrawer != null && mainDrawer!!.isDrawerOpen(GravityCompat.START)) {
//            mainDrawer!!.closeDrawer(GravityCompat.START)
//        } else {
//        startActivity(Intent(this@HomeActivity, MainStartActivity::class.java))
//        finish()
        super.onBackPressed()
//        }
    }


    override fun onDestroy() {
        super.onDestroy()
        //  NativeAdvanceHelper.onDestroy();

    }

    companion object {
        private const val TAG = "HomeActivity123"
        var prompt: MaterialTapTargetPrompt? = null
    }
}