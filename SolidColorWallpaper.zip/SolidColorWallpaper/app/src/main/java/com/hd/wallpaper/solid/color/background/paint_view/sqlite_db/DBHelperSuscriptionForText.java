package com.hd.wallpaper.solid.color.background.paint_view.sqlite_db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelperSuscriptionForText extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "MyDBNameD.db";
    public static final String CONTACTS_COLUMN_NAME = "path";


    public DBHelperSuscriptionForText(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // TODO Auto-generated method stub
        db.execSQL(
                "create table suscription " +
                        "(id integer primary key, path text)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub
        db.execSQL("DROP TABLE IF EXISTS suscription");
        onCreate(db);
    }

    public boolean insertPath(String path) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("path", path);
        if (!checkPathExist(path)) {
            db.insert("suscription", null, contentValues);
        }
        return true;
    }

    public void deleteAllData(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM suscription");
        db.close();
    }


    public boolean checkPathExist(String path) {
        Cursor res=null;
        boolean isWathced = false;
        try {
            SQLiteDatabase db = this.getReadableDatabase();
             res = db.rawQuery("select * from suscription", null);
            res.moveToFirst();
            while (!res.isAfterLast()) {
                if (res.getString(res.getColumnIndex(CONTACTS_COLUMN_NAME)).equals(path)) {
                    isWathced = true;
                    break;
                }
                res.moveToNext();
            }
        } finally {
            // this gets called even if there is an exception somewhere above
            if (res != null)
                res.close();
        }
        res.close();
        return isWathced;
    }
}