package com.hd.wallpaper.solid.color.background.adapter

import android.annotation.SuppressLint
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import com.hd.wallpaper.solid.color.background.fragment.ScreenCategoryFragment
import com.hd.wallpaper.solid.color.background.model.WallpaperWeekModel
import com.hd.wallpaper.solid.color.background.newModel.WallpaperWeekModelNewResponse
import java.util.*

class CategoryScreenPagerAdapter @SuppressLint("WrongConstant") constructor(fm: FragmentManager?, private val mResolutionModelList: ArrayList<ArrayList<WallpaperWeekModelNewResponse?>?>) : FragmentStatePagerAdapter(fm!!) {
    override fun getItem(position: Int): Fragment {
        var fragment: Fragment? = null
        fragment = ScreenCategoryFragment(mResolutionModelList[position])
        return fragment
    }

    override fun getCount(): Int {
        return mResolutionModelList.size
    }

}