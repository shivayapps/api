package com.hd.wallpaper.solid.color.background.activity

import android.content.res.Configuration
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.SolidWallpaperApplication
import com.hd.wallpaper.solid.color.background.databinding.ActivityLiveandHDWallpaperBinding
import com.hd.wallpaper.solid.color.background.shared_pref.MySharedPref
import java.util.*

class LiveandHDWallpaperActivity : AppCompatActivity() {

    lateinit var binding:ActivityLiveandHDWallpaperBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_liveand_h_d_wallpaper)
        binding= ActivityLiveandHDWallpaperBinding.inflate(layoutInflater)
        setContentView(binding.root)

        System.gc()

        SolidWallpaperApplication.staticLanguage.Factory.create(this)

        initViewAction()

    }

    private fun initViewAction() {

    }
}