package com.hd.wallpaper.solid.color.background.adapter

import android.app.Activity
import android.content.Context
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CenterCrop
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.model.ScreenModel
import java.util.*

class EmojiImagesAdapter(private val context: Activity, private val list: ArrayList<String>, private val mOnItemClickListener: OnItemClickListener) : RecyclerView.Adapter<EmojiImagesAdapter.MyViewHolder>() {
    private var lastCheckedPosition = -1

    interface OnItemClickListener {
        fun onItemClick(view: View?, position: Int, activity: Activity)
    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var iv_shape: ImageView = itemView.findViewById(R.id.iv_shape)
        var icLock: ImageView = itemView.findViewById(R.id.icLock)
        var selectedView: ImageView = itemView.findViewById(R.id.selectedView)
        var txtMore: TextView = itemView.findViewById(R.id.txtMore)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.row_emoji_item, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.selectedView.visibility = View.GONE
        holder.icLock.visibility = View.GONE
        Glide.with(context).load(list[position]).override(50).transforms(CenterCrop(), RoundedCorners(16)).into(object : CustomTarget<Drawable?>() {
            override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                resource.colorFilter = PorterDuffColorFilter(context.resources.getColor(R.color.text_colour_new), PorterDuff.Mode.SRC_IN)
                holder.iv_shape.background = context.resources.getDrawable(R.drawable.back_roundcorner)
                holder.iv_shape.setPadding(3, 3, 3, 3)

                //if ((position + 1) % 5 == 0 && position != 0 /*&& !mySharedPref.getAdsRemoved()*/ && !AdsPrefs.getBoolean(context,AdsPrefs.IS_SUBSCRIBED,false) && !dbHelper.checkPathExist(list.get(position))) {
//                if (!list[position].isFree) {
//                    holder.icLock.visibility = View.VISIBLE
//                    holder.iv_shape.setImageDrawable(null)
//                } else {
                    holder.icLock.visibility = View.GONE
                    holder.iv_shape.setImageDrawable(resource)
//                }
                if (lastCheckedPosition == position && holder.icLock.visibility == View.GONE) {
                    holder.selectedView.visibility = View.VISIBLE
                } else {
                    holder.selectedView.visibility = View.GONE
                }
                //     }
            }

            override fun onLoadCleared(placeholder: Drawable?) {}
        })
        holder.iv_shape.setOnClickListener { v ->
            mOnItemClickListener.onItemClick(v, position, context)
            notifyItemChanged(position)
            notifyItemChanged(lastCheckedPosition)
            lastCheckedPosition = position
        }
    }

    fun setSelectedPosition(i: Int) {
        lastCheckedPosition = i
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int {
        return list.size
    }

    companion object {
        private const val TAG = "EmojiImagesAdapter"
    }

}