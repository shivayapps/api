package com.hd.wallpaper.solid.color.background.activity

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.graphics.Movie
import android.graphics.drawable.AnimatedImageDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.util.Log
import android.view.SurfaceHolder
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.databinding.ActivityTestBinding
import java.io.File
import java.io.IOException
import java.io.InputStream

class TestActivity : AppCompatActivity() {

    lateinit var binding:ActivityTestBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityTestBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        setContentView(R.layout.activity_test)

      //  Glide.with(this).load(R.drawable.test2).into(img_gif)

        val intent = Intent(
                WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
        intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                ComponentName(this, GifLiveWallPaper::class.java))
        startActivity(intent)

    }
}

class GifLiveWallPaper : WallpaperService() {
    override fun onCreateEngine(): Engine {
        return try {
            WallPaperEngine()
        } catch (e: IOException) {
            Log.w(TAG, "Error creating WallPaperEngine", e)
            stopSelf()
            null
        }!!
    }

    internal inner class WallPaperEngine : Engine() {
        private var liveMovie: Movie? = null
        private var duration = 0
        private val runnable: Runnable
        var mScaleX = 0f
        var mScaleY = 0f
        var mWhen: Int
        var mStart: Long = 0
        override fun onDestroy() {
            super.onDestroy()
            liveHandler.removeCallbacks(runnable)
        }

        override fun onVisibilityChanged(visible: Boolean) {
            super.onVisibilityChanged(visible)
            if (visible) {
                nyan()
            } else {
                liveHandler.removeCallbacks(runnable)
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int,
                                      width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            mScaleX = width / (1f * liveMovie!!.width())
            mScaleY = height / (1f * liveMovie!!.height())
            nyan()
        }

        override fun onOffsetsChanged(xOffset: Float, yOffset: Float,
                                      xOffsetStep: Float, yOffsetStep: Float, xPixelOffset: Int,
                                      yPixelOffset: Int) {
            super.onOffsetsChanged(xOffset, yOffset, xOffsetStep, yOffsetStep,
                    xPixelOffset, yPixelOffset)
            nyan()
        }

        private fun nyan() {
            tick()
            val surfaceHolder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = surfaceHolder.lockCanvas()
                canvas?.let { drawGif(it) }
            } finally {
                if (canvas != null) {
                    surfaceHolder.unlockCanvasAndPost(canvas)
                }
            }
            liveHandler.removeCallbacks(runnable)
            if (isVisible) {
                liveHandler.postDelayed(runnable, 1000L / 25L)
            }
        }

        private fun tick() {
            if (mWhen.toLong() == -1L) {
                mWhen = 0
                mStart = SystemClock.uptimeMillis()
            } else {
                val mDiff: Long = SystemClock.uptimeMillis() - mStart
                mWhen = (mDiff % duration).toInt()
            }
        }

        private fun drawGif(canvas: Canvas) {
            canvas.save()
            canvas.scale(mScaleX, mScaleY)
            liveMovie!!.setTime(mWhen)
            liveMovie!!.draw(canvas, 0f, 0f)
            canvas.restore()
        }

        init {
            val `is`: InputStream = resources.assets.open("test.webp")
            try {
                liveMovie = Movie.decodeStream(`is`)
                duration = liveMovie!!.duration()
            } finally {
                `is`.close()
            }
            mWhen = -1
            runnable = Runnable { nyan() }
        }
    }

    companion object {
        const val TAG = "LIVE_WALLPAPER"
        val liveHandler = Handler()
    }
}
