package com.hd.wallpaper.solid.color.background.fragment

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.fragment.NoEnoughCoinDialogFragment

class NoEnoughCoinDialogFragment : DialogFragment {
    private var mListener: OnButtonClickListener? = null
    private var bottomSheetDialog: Dialog? = null
    private var textTitle: String? = null

    constructor() {}
    constructor(mListener: OnButtonClickListener?, textTitle: String?) {
        this.mListener = mListener
        this.textTitle = textTitle
    }

    open interface OnButtonClickListener {
        fun onPositive(bottomSheetDialo: NoEnoughCoinDialogFragment)
        fun onNegative(bottomSheetDialog: NoEnoughCoinDialogFragment)
    }

    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setStyle(BottomSheetDialogFragment.STYLE_NORMAL, R.style.materialButton);
        setStyle(STYLE_NO_TITLE, R.style.materialButton)
    }

    public override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.dialog_no_enough_coin, container, false)
    }

    public override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val txt: TextView = view.findViewById(R.id.txtTitle)
        txt.text = textTitle
        view.findViewById<View>(R.id.ll_get_coins).setOnClickListener(View.OnClickListener { v: View? -> mListener!!.onPositive(this@NoEnoughCoinDialogFragment) })
        view.findViewById<View>(R.id.txtCancel).setOnClickListener(View.OnClickListener { v: View? -> mListener!!.onNegative(this@NoEnoughCoinDialogFragment) })
    }

    public override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        bottomSheetDialog = dialog
        // ((View) getView().getParent()).setPadding(0,0,0,);
        val displayMetrics: DisplayMetrics = DisplayMetrics()
        activity!!.windowManager.defaultDisplay.getMetrics(displayMetrics)
        val height: Int = displayMetrics.heightPixels
        var width: Int = displayMetrics.widthPixels
        width -= width / 8
        bottomSheetDialog!!.window!!.setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT)
        // setColoredNavBar(true);
    }

    public override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog: Dialog = super.onCreateDialog(savedInstanceState)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            //setWhiteNavigationBar(dialog);
        }
        return dialog
    }

    public override fun onStart() {
        super.onStart()
    }
}