package com.hd.wallpaper.solid.color.background.fragment

import android.content.Context
import android.content.res.Resources
import android.os.Bundle
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.adapter.ForegroundLiveAdapter
import com.hd.wallpaper.solid.color.background.custom.GridSpacingItemDecoration
import com.hd.wallpaper.solid.color.background.model.WallpaperWeekModel
import com.hd.wallpaper.solid.color.background.newModel.WallpaperWeekModelNewResponse
import java.util.*

class ScreenCategoryFragment : Fragment {
    private var recyclerScreen: RecyclerView? = null
    private var mAllData: ArrayList<WallpaperWeekModelNewResponse?>? = null
    private var adapter: ForegroundLiveAdapter? = null
    private var mAContext: Context? = null

    constructor() {
        // Required empty public constructor
    }

    constructor(mAllData: ArrayList<WallpaperWeekModelNewResponse?>?) {
        this.mAllData = mAllData
    }

    public override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                                     savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_screen_category, container, false)
    }

    public override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        mAContext = activity
        recyclerScreen = view.findViewById(R.id.recyclerScreen)
        val manager: GridLayoutManager = GridLayoutManager(activity, 3)
        recyclerScreen!!.layoutManager = manager
        recyclerScreen!!.addItemDecoration(GridSpacingItemDecoration(3, dpToPx(22), true))
        recyclerScreen!!.itemAnimator = DefaultItemAnimator()
        val onItemSelectedListner: ForegroundLiveAdapter.OnItemSelectedListner = object : ForegroundLiveAdapter.OnItemSelectedListner {
            public override fun onItemClick(model: WallpaperWeekModelNewResponse?, position: Int) {}
        }
        recyclerScreen!!.isNestedScrollingEnabled = false
        adapter = ForegroundLiveAdapter(mAllData!!, mAContext!!, onItemSelectedListner)
        recyclerScreen!!.adapter = adapter
    }

    private fun dpToPx(dp: Int): Int {
        val r: Resources = resources
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), r.displayMetrics))
    }
}