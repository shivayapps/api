package com.hd.wallpaper.solid.color.background.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.model.AutoWallpaperModel
import java.util.*

class LiveWallpaperListAdapter(private val modelArrayList: ArrayList<AutoWallpaperModel>, var mContext: Context, private val onSelectAction: OnSelectAction) : RecyclerView.Adapter<LiveWallpaperListAdapter.MyViewholder>() {
    private var lastSelected = -1
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewholder {
        return MyViewholder(LayoutInflater.from(mContext).inflate(R.layout.rv_wallpaper_live_list, parent, false))
    }

    interface OnSelectAction {
        fun onPlay(autoWallpaperModel: AutoWallpaperModel?)
        fun onEdit(autoWallpaperModel: AutoWallpaperModel?)
        fun onDelete(autoWallpaperModel: AutoWallpaperModel?)
    }

    override fun onBindViewHolder(holder: MyViewholder, position: Int) {
        val model = modelArrayList[position]
        if (model.status == 1) {
            holder.imgrandomWatch.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_random_select))
        } else {
            holder.imgrandomWatch.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_random_unselect))
        }
        holder.txtDelayTime.text = model.delaytime
        holder.btnDelete.setOnClickListener { v: View? -> onSelectAction.onDelete(model) }
        holder.btnEdit.setOnClickListener { v: View? -> onSelectAction.onEdit(model) }
        holder.btnPlay.setOnClickListener { v: View? ->
            if (lastSelected != position) {
                onSelectAction.onPlay(model)
                if (lastSelected != -1) {
                    modelArrayList[lastSelected].status = 0
                    notifyItemChanged(lastSelected)
                }
                model.status = 1
                notifyItemChanged(position)
            }
            lastSelected = position
        }
        val gson = Gson()
        val token: TypeToken<ArrayList<String?>?> = object : TypeToken<ArrayList<String?>?>() {}
        val mImages = gson.fromJson<ArrayList<String>>(model.imagespath, token.type)
        val adapter = WallpaperLiveSubImageAdapter(mContext, mImages)
        holder.recyclerWallpaper.adapter = adapter
    }

    fun setDataChanged() {
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int {
        return modelArrayList.size
    }

    inner class MyViewholder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var recyclerWallpaper: RecyclerView = itemView.findViewById(R.id.recyclerWallpaper)
        var imgrandomWatch: ImageView = itemView.findViewById(R.id.imgrandomWatch)
        var btnDelete: ImageView = itemView.findViewById(R.id.btnDelete)
        var btnEdit: ImageView = itemView.findViewById(R.id.btnEdit)
        var btnPlay: ImageView = itemView.findViewById(R.id.btnPlay)
        var txtDelayTime: TextView = itemView.findViewById(R.id.txtDelayTime)

        init {
            recyclerWallpaper.layoutManager = LinearLayoutManager(mContext, RecyclerView.HORIZONTAL, false)
        }
    }

    companion object {
        private const val TAG = "LiveWallpaperListAdapte"
    }

    init {
        for (i in modelArrayList.indices) {
            if (modelArrayList[i].status == 1) {
                lastSelected = i
                break
            }
        }
    }
}