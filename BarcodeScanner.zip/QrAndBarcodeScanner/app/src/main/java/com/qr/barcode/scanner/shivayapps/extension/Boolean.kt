package com.qr.barcode.scanner.shivayapps.extension

fun Boolean?.orFalse(): Boolean {
    return this ?: false
}