package com.qr.barcode.scanner.shivayapps.extension

import com.qr.barcode.scanner.shivayapps.model.Barcode
import com.google.zxing.Result

fun Result.equalTo(barcode: Barcode?): Boolean {
    return barcodeFormat == barcode?.format && text == barcode?.text
}