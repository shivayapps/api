package com.qr.barcode.scanner.shivayapps.extension

import androidx.appcompat.app.AppCompatActivity
import com.qr.barcode.scanner.shivayapps.feature.common.dialog.ErrorDialogFragment

fun AppCompatActivity.showError(error: Throwable?) {
    val errorDialog =
        ErrorDialogFragment.newInstance(
            this,
            error
        )
    errorDialog.show(supportFragmentManager, "")
}