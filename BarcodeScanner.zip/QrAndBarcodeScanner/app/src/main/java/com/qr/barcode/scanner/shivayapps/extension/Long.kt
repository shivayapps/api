package com.qr.barcode.scanner.shivayapps.extension

fun Long?.orZero(): Long {
    return this ?: 0L
}