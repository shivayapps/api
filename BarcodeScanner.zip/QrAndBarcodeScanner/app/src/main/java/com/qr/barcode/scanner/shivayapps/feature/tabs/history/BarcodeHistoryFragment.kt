package com.qr.barcode.scanner.shivayapps.feature.tabs.history

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isGone
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.paging.PagedList
import androidx.paging.RxPagedListBuilder
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.qr.barcode.scanner.shivayapps.R
import com.qr.barcode.scanner.shivayapps.di.barcodeDatabase
import com.qr.barcode.scanner.shivayapps.extension.applySystemWindowInsets
import com.qr.barcode.scanner.shivayapps.extension.showError
import com.qr.barcode.scanner.shivayapps.feature.barcode.BarcodeActivity
import com.qr.barcode.scanner.shivayapps.feature.common.dialog.DeleteConfirmationDialogFragment
import com.qr.barcode.scanner.shivayapps.feature.tabs.history.export.ExportHistoryActivity
import com.qr.barcode.scanner.shivayapps.feature.tabs.settings.SettingsActivity
import com.qr.barcode.scanner.shivayapps.model.Barcode
import io.reactivex.BackpressureStrategy
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.rxkotlin.addTo
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.fragment_barcode_history.*
import kotlinx.android.synthetic.main.fragment_barcode_history.recycler_view_history


class BarcodeHistoryFragment : Fragment(), DeleteConfirmationDialogFragment.Listener,
    BarcodeHistoryAdapter.Listener {

    companion object {
        private const val PAGE_SIZE = 20
        private const val TYPE_ALL = 0
        private const val TYPE_FAVORITES = 1
        private const val TYPE_KEY = "TYPE_KEY"
    }

    private val disposable = CompositeDisposable()
    private val scanHistoryAdapter = BarcodeHistoryAdapter(this)

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_barcode_history, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        supportEdgeToEdge()
//        initTabs()
        initRecyclerView()
        loadHistory()

        handleMenuClicked()
    }

    override fun onDeleteConfirmed() {
        clearHistory()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        disposable.clear()
    }


    private fun initRecyclerView() {
        recycler_view_history.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = scanHistoryAdapter
        }
    }

    private fun loadHistory() {
        val config = PagedList.Config.Builder()
            .setEnablePlaceholders(false)
            .setPageSize(PAGE_SIZE)
            .build()

        val dataSource = barcodeDatabase.getAll()
//            when (arguments?.getInt(TYPE_KEY).orZero()) {
//            TYPE_ALL -> barcodeDatabase.getAll()
//            TYPE_FAVORITES -> barcodeDatabase.getFavorites()
//            else -> return
//        }

        RxPagedListBuilder(dataSource, config)
            .buildFlowable(BackpressureStrategy.LATEST)
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(scanHistoryAdapter::submitList, ::showError)
            .addTo(disposable)
    }

    private fun supportEdgeToEdge() {
        app_bar_layout.applySystemWindowInsets(applyTop = true)
    }

//    private fun initTabs() {
//        view_pager.adapter = BarcodeHistoryViewPagerAdapter(requireContext(), childFragmentManager)
//        tab_layout.setupWithViewPager(view_pager)
//    }

    private fun handleMenuClicked() {

        item_export_history.setOnClickListener {
            navigateToExportHistoryScreen()
        }
        item_clear_history.setOnClickListener {
            showDeleteHistoryConfirmationDialog()
        }

        toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.item_settings -> {
                    requireActivity().isShowInterstitialAd{
                        startActivity(Intent(activity, SettingsActivity::class.java))
                    }
                }
//                R.id.item_export_history -> navigateToExportHistoryScreen()
//                R.id.item_clear_history -> showDeleteHistoryConfirmationDialog()
            }
            return@setOnMenuItemClickListener true
        }
        resetEmpty()
    }

    private fun resetEmpty() {

        Handler(Looper.getMainLooper()).postDelayed({
            tab_layout.apply {
                isGone = scanHistoryAdapter.currentList!!.size == 0
            }
            tab_layout.apply {
                isVisible = scanHistoryAdapter.currentList!!.size > 0
            }
            layout_empty.apply {
                isVisible = scanHistoryAdapter.currentList!!.size == 0
            }
            layout_empty.apply {
                isGone = scanHistoryAdapter.currentList!!.size > 0
            }
        },1500)

    }
    private fun navigateToExportHistoryScreen() {

        requireActivity().isShowInterstitialAd{
            ExportHistoryActivity.start(requireActivity())
        }
    }

    private fun showDeleteHistoryConfirmationDialog() {
        val dialog = DeleteConfirmationDialogFragment.newInstance(R.string.dialog_delete_clear_history_message)
        dialog.show(childFragmentManager, "")
    }

    private fun clearHistory() {
        barcodeDatabase.deleteAll()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { },
                ::showError
            )
            .addTo(disposable)

        resetEmpty()
    }

    override fun onBarcodeClicked(barcode: Barcode) {

        requireActivity().isShowInterstitialAd{
            BarcodeActivity.start(requireActivity(), barcode)
        }
    }
}