package com.qr.barcode.scanner.shivayapps.usecase


object Logger {
//    var isEnabled = BuildConfig.ERROR_REPORTS_ENABLED_BY_DEFAULT
    var isEnabled = true

    fun log(error: Throwable) {
        if (isEnabled) {
            //Sentry.captureException(error)
        }
    }
}