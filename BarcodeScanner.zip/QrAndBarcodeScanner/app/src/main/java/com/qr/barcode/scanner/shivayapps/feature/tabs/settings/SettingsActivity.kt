package com.qr.barcode.scanner.shivayapps.feature.tabs.settings

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.qr.barcode.scanner.shivayapps.R
import com.qr.barcode.scanner.shivayapps.adshelper.AdsManager
import com.qr.barcode.scanner.shivayapps.di.barcodeDatabase
import com.qr.barcode.scanner.shivayapps.di.settings
import com.qr.barcode.scanner.shivayapps.extension.applySystemWindowInsets
import com.qr.barcode.scanner.shivayapps.extension.showError
import com.qr.barcode.scanner.shivayapps.feature.common.dialog.DeleteConfirmationDialogFragment
import com.qr.barcode.scanner.shivayapps.feature.tabs.settings.camera.ChooseCameraActivity
import com.qr.barcode.scanner.shivayapps.feature.tabs.settings.formats.SupportedFormatsActivity
import com.qr.barcode.scanner.shivayapps.feature.tabs.settings.permissions.AllPermissionsActivity
import com.qr.barcode.scanner.shivayapps.feature.tabs.settings.search.ChooseSearchEngineActivity
import com.qr.barcode.scanner.shivayapps.adshelper.InAppActivity
import com.qr.barcode.scanner.shivayapps.feature.common.animation.Techniques
import com.qr.barcode.scanner.shivayapps.feature.common.animation.YoYo
import com.qr.barcode.scanner.shivayapps.feature.tabs.settings.theme.ChooseThemeActivity
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.rxkotlin.addTo
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_barcode.*
import kotlinx.android.synthetic.main.activity_settings.*
import kotlinx.android.synthetic.main.activity_settings.adViewContainer
import kotlinx.android.synthetic.main.activity_settings.scroll_view
import kotlinx.android.synthetic.main.activity_settings.toolbar

class SettingsActivity : AppCompatActivity(), DeleteConfirmationDialogFragment.Listener {

    private val TAG = "SettingsActivity"
    private val disposable = CompositeDisposable()
    private lateinit var mContext: Activity
    private var isSettingChanged = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        mContext = this@SettingsActivity

        initToolbar()
        supportEdgeToEdge()
        NativeAdvancedModelHelper(this@SettingsActivity)
            .loadNativeAdvancedAd(
                NativeAdsSize.Medium,
                adViewContainer
            )

    }

    private fun animatePro() {
        scroll_view.smoothScrollTo(0, 0, 1000)
        pro_button.requestFocus()

        YoYo.with(Techniques.Flash)
            .duration(1200)
            .repeat(1)
            .pivot(YoYo.CENTER_PIVOT, YoYo.CENTER_PIVOT)
            .playOn(pro_button)
    }

    private fun initToolbar() {
        toolbar.setNavigationOnClickListener {
//            if (isSettingChanged) {
//                isShowInterstitialAd {
//                    finish()
//                }
//            } else {
                onBackPressed()
//            }
        }
    }

    override fun onResume() {
        super.onResume()
        handleButtonCheckedChanged()
        handleButtonClicks()
        showSettings()
        showAppVersion()
    }

    override fun onDeleteConfirmed() {
        clearHistory()
    }

    override fun onDestroy() {
        super.onDestroy()
        disposable.clear()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        if (isSettingChanged) {
            isShowInterstitialAd {
                finish()
            }
        } else {
            onBackPressed()
        }
//        showInterstitialAd(this@SettingsActivity) {
//            finish()
//        }
    }

    fun supportEdgeToEdge() {
        app_bar_layout.applySystemWindowInsets(applyTop = true)
    }

    private fun handleButtonCheckedChanged() {

        Log.e(TAG, "handleButtonCheckedChanged")

//        if(AdsManager(this@SettingsActivity).isNeedToShowAds()) {
//
//            Log.e(TAG, "handleButtonCheckedChanged:isNeedToShowAds:yes")
//
//            pro_button_inverse_barcode_colors_in_dark_theme.visibility=View.VISIBLE
//            pro_button_confirm_scans_manually.visibility=View.VISIBLE
//            pro_button_continuous_scanning.visibility=View.VISIBLE
//            pro_button_do_not_save_duplicates.visibility=View.VISIBLE
//            pro_button_open_links_automatically.visibility=View.VISIBLE
//
//            button_inverse_barcode_colors_in_dark_theme.visibility=View.GONE
//            button_confirm_scans_manually.visibility=View.GONE
//            button_continuous_scanning.visibility=View.GONE
//            button_do_not_save_duplicates.visibility=View.GONE
//            button_open_links_automatically.visibility=View.GONE
//        }
//        else {
//
//            Log.e(TAG, "handleButtonCheckedChanged:isNeedToShowAds:no")
//
//            pro_button_inverse_barcode_colors_in_dark_theme.visibility=View.GONE
//            pro_button_confirm_scans_manually.visibility=View.GONE
//            pro_button_continuous_scanning.visibility=View.GONE
//            pro_button_do_not_save_duplicates.visibility=View.GONE
//            pro_button_open_links_automatically.visibility=View.GONE
//
//            button_inverse_barcode_colors_in_dark_theme.visibility=View.VISIBLE
//            button_confirm_scans_manually.visibility=View.VISIBLE
//            button_continuous_scanning.visibility=View.VISIBLE
//            button_do_not_save_duplicates.visibility=View.VISIBLE
//            button_open_links_automatically.visibility=View.VISIBLE
//        }

        button_inverse_barcode_colors_in_dark_theme.setCheckedChangedListener {
            isSettingChanged = true
            settings.areBarcodeColorsInversed = it
        }
        button_open_links_automatically.setCheckedChangedListener {
            isSettingChanged = true
            settings.openLinksAutomatically = it
        }
        button_copy_to_clipboard.setCheckedChangedListener {
            isSettingChanged = true
            settings.copyToClipboard = it
        }
        button_simple_auto_focus.setCheckedChangedListener {
            isSettingChanged = true
            settings.simpleAutoFocus = it
        }
        button_flashlight.setCheckedChangedListener {
            isSettingChanged = true
            settings.flash = it
        }
        button_vibrate.setCheckedChangedListener {
            isSettingChanged = true
            settings.vibrate = it
        }
        button_continuous_scanning.setCheckedChangedListener {
            isSettingChanged = true
            settings.continuousScanning = it
        }
        button_confirm_scans_manually.setCheckedChangedListener {
            isSettingChanged = true
            settings.confirmScansManually = it
        }
        button_save_scanned_barcodes.setCheckedChangedListener {
            isSettingChanged = true
            settings.saveScannedBarcodesToHistory = it
        }
        button_save_created_barcodes.setCheckedChangedListener {
            isSettingChanged = true
            settings.saveCreatedBarcodesToHistory = it
        }
        button_do_not_save_duplicates.setCheckedChangedListener {
            isSettingChanged = true
            settings.doNotSaveDuplicates = it
        }


//        button_enable_error_reports.setCheckedChangedListener { settings.areErrorReportsEnabled = it }
    }

    private fun handleButtonClicks() {
        button_choose_theme.setOnClickListener {
            isShowInterstitialAd {
                ChooseThemeActivity.start(mContext)
            }
        }
        button_choose_camera.setOnClickListener {
            isShowInterstitialAd {
                ChooseCameraActivity.start(mContext)
            }
        }
        button_select_supported_formats.setOnClickListener {
            isShowInterstitialAd {
                SupportedFormatsActivity.start(mContext)
            }
        }
        button_clear_history.setOnClickListener {
//            isShowInterstitialAd{
            showDeleteHistoryConfirmationDialog()
//            }
        }
        button_choose_search_engine.setOnClickListener {
            isShowInterstitialAd {
                ChooseSearchEngineActivity.start(mContext)
            }
        }
        button_permissions.setOnClickListener {
            isShowInterstitialAd {
                AllPermissionsActivity.start(mContext)
            }
        }
        button_check_updates.setOnClickListener { showAppInMarket() }
        button_privacy_policy.setOnClickListener { launchPrivacyPolicy() }
        button_share_app.setOnClickListener { shareApp() }

//        pro_button_inverse_barcode_colors_in_dark_theme.setOnClickListener { animatePro() }
//        pro_button_confirm_scans_manually.setOnClickListener { animatePro() }
//        pro_button_continuous_scanning.setOnClickListener { animatePro() }
//        pro_button_do_not_save_duplicates.setOnClickListener { animatePro() }
//        pro_button_open_links_automatically.setOnClickListener { animatePro() }
//        pro_button.setOnClickListener { InAppActivity.start(mContext) }

    }

    private fun clearHistory() {
        button_clear_history.isEnabled = false

        barcodeDatabase.deleteAll()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                {
                    button_clear_history.isEnabled = true
                },
                { error ->
                    button_clear_history.isEnabled = true
                    showError(error)
                }
            )
            .addTo(disposable)
    }

    private fun showSettings() {
        settings.apply {
            button_inverse_barcode_colors_in_dark_theme.isChecked = areBarcodeColorsInversed
            button_open_links_automatically.isChecked = openLinksAutomatically
            button_copy_to_clipboard.isChecked = copyToClipboard
            button_simple_auto_focus.isChecked = simpleAutoFocus
            button_flashlight.isChecked = flash
            button_vibrate.isChecked = vibrate
            button_continuous_scanning.isChecked = continuousScanning
            button_confirm_scans_manually.isChecked = confirmScansManually
            button_save_scanned_barcodes.isChecked = saveScannedBarcodesToHistory
            button_save_created_barcodes.isChecked = saveCreatedBarcodesToHistory
            button_do_not_save_duplicates.isChecked = doNotSaveDuplicates
//            button_enable_error_reports.isChecked = areErrorReportsEnabled
        }
    }

    private fun showDeleteHistoryConfirmationDialog() {
        isSettingChanged = true
        val dialog = DeleteConfirmationDialogFragment.newInstance(R.string.dialog_delete_clear_history_message)
        dialog.show(supportFragmentManager, "")
    }

    private fun showAppInMarket() {
        val uri = Uri.parse("market://details?id=" + mContext.packageName)
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            flags =
                Intent.FLAG_ACTIVITY_NO_HISTORY or Intent.FLAG_ACTIVITY_NEW_DOCUMENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK
        }
        if (intent.resolveActivity(mContext.packageManager) != null) {
            startActivity(intent)
        }
    }

    private fun launchPrivacyPolicy() {

        val marketUri = Uri.parse(getString(R.string.link_privacy_policy))
        val customIntent: CustomTabsIntent.Builder = CustomTabsIntent.Builder()
        customIntent.setToolbarColor(
            ContextCompat.getColor(
                this@SettingsActivity,
                R.color.color_primary_dark
            )
        )
        openCustomTab(this@SettingsActivity, customIntent.build(), marketUri)
    }

    private fun openCustomTab(activity: Activity, customTabsIntent: CustomTabsIntent, uri: Uri) {
        // package name is the default package
        // for our custom chrome tab
        try {
            customTabsIntent.intent.setPackage("com.android.chrome")
            customTabsIntent.launchUrl(activity, uri)
        } catch (e: Exception) {
            activity.startActivity(Intent(Intent.ACTION_VIEW, uri))
        }
    }

    private fun shareApp() {
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_SUBJECT, resources.getString(R.string.app_name))
        val appname = getString(R.string.app_name)
        val sAux = getString(R.string.msg_share_app, appname, packageName)
        i.putExtra(Intent.EXTRA_TEXT, sAux)
        startActivity(Intent.createChooser(i, "Choose one"))
    }

    private fun showAppVersion() {
        button_app_version.hint = com.qr.barcode.scanner.shivayapps.BuildConfig.VERSION_NAME
    }
}