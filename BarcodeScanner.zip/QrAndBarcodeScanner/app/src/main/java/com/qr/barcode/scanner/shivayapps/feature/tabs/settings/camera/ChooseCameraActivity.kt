package com.qr.barcode.scanner.shivayapps.feature.tabs.settings.camera

import android.content.Context
import android.content.Intent
import android.os.Bundle
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.qr.barcode.scanner.shivayapps.R
import com.qr.barcode.scanner.shivayapps.di.settings
import com.qr.barcode.scanner.shivayapps.extension.applySystemWindowInsets
import com.qr.barcode.scanner.shivayapps.feature.BaseActivity
import kotlinx.android.synthetic.main.activity_choose_camera.*
import kotlinx.android.synthetic.main.activity_choose_camera.adViewContainer
import kotlinx.android.synthetic.main.activity_choose_camera.root_view
import kotlinx.android.synthetic.main.activity_choose_camera.toolbar

class ChooseCameraActivity : BaseActivity() {

    companion object {
        fun start(context: Context) {
            val intent = Intent(context, ChooseCameraActivity::class.java)
            context.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_choose_camera)
        supportEdgeToEdge()
        handleToolbarBackClicked()
        NativeAdvancedModelHelper(this@ChooseCameraActivity)
            .loadNativeAdvancedAd(
                NativeAdsSize.Medium,
                adViewContainer
            )
    }

    override fun onResume() {
        super.onResume()
        showSelectedCamera()
        handleBackCameraButtonChecked()
        handleFrontCameraButtonChecked()
    }

    private fun showSelectedCamera() {
        val isBackCamera = settings.isBackCamera
        button_back_camera.isChecked = isBackCamera
        button_front_camera.isChecked = isBackCamera.not()
    }

    private fun supportEdgeToEdge() {
        root_view.applySystemWindowInsets(applyTop = true, applyBottom = true)
    }

    private fun handleToolbarBackClicked() {
        toolbar.setNavigationOnClickListener {
            onBackPressed()
//            showInterstitialAd(this@ChooseCameraActivity) {
//                finish()
//            }
        }
    }

    private fun handleBackCameraButtonChecked() {
        button_back_camera.setCheckedChangedListener { isChecked ->
            if (isChecked) {
                button_front_camera.isChecked = false
            }
            settings.isBackCamera = isChecked
        }
    }

    private fun handleFrontCameraButtonChecked() {
        button_front_camera.setCheckedChangedListener { isChecked ->
            if (isChecked) {
                button_back_camera.isChecked = false
            }
            settings.isBackCamera = isChecked.not()
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
//        showInterstitialAd(this@ChooseCameraActivity) {
//            finish()
//        }
    }

}