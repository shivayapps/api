package com.qr.barcode.scanner.shivayapps.feature.tabs.create

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.qr.barcode.scanner.shivayapps.R
import com.qr.barcode.scanner.shivayapps.extension.applySystemWindowInsets
import com.qr.barcode.scanner.shivayapps.extension.clipboardManager
import com.qr.barcode.scanner.shivayapps.extension.orZero
import com.qr.barcode.scanner.shivayapps.feature.tabs.create.barcode.CreateBarcodeAllActivity
import com.qr.barcode.scanner.shivayapps.feature.tabs.create.qr.CreateQrCodeAllActivity
import com.qr.barcode.scanner.shivayapps.feature.tabs.settings.SettingsActivity
import com.qr.barcode.scanner.shivayapps.model.schema.BarcodeSchema
import com.google.zxing.BarcodeFormat
import kotlinx.android.synthetic.main.fragment_create_barcode.*
import kotlinx.android.synthetic.main.fragment_create_barcode.app_bar_layout
import kotlinx.android.synthetic.main.fragment_create_barcode.toolbar

class CreateBarcodeFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_create_barcode, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        supportEdgeToEdge()
        handleButtonsClicked()
        handleMenuClicked()
    }
    private fun handleMenuClicked() {
        toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.item_settings -> {
                    requireActivity().isShowInterstitialAd{
                        startActivity(Intent(activity, SettingsActivity::class.java))
                    }
                }
            }
            return@setOnMenuItemClickListener true
        }
    }


    private fun supportEdgeToEdge() {
        app_bar_layout.applySystemWindowInsets(applyTop = true)
    }

    private fun handleButtonsClicked() {
        // QR code
        button_clipboard.setOnClickListener {
            CreateBarcodeActivity.start(
                requireActivity(),
                BarcodeFormat.QR_CODE,
                BarcodeSchema.OTHER,
                getClipboardContent()
            )
        }
        button_text.setOnClickListener {
            CreateBarcodeActivity.start(
                requireActivity(),
                BarcodeFormat.QR_CODE,
                BarcodeSchema.OTHER
            )
        }
        button_url.setOnClickListener {
            CreateBarcodeActivity.start(
                requireActivity(),
                BarcodeFormat.QR_CODE,
                BarcodeSchema.URL
            )
        }
        button_wifi.setOnClickListener {
            CreateBarcodeActivity.start(
                requireActivity(),
                BarcodeFormat.QR_CODE,
                BarcodeSchema.WIFI
            )
        }
        button_location.setOnClickListener {
            CreateBarcodeActivity.start(
                requireActivity(),
                BarcodeFormat.QR_CODE,
                BarcodeSchema.GEO
            )
        }
        button_contact_vcard.setOnClickListener {
            CreateBarcodeActivity.start(
                requireActivity(),
                BarcodeFormat.QR_CODE,
                BarcodeSchema.VCARD
            )
        }
        button_show_all_qr_code.setOnClickListener {

            requireActivity().isShowInterstitialAd{
                CreateQrCodeAllActivity.start(requireActivity())
            }
        }

        // Barcode
        button_create_barcode.setOnClickListener {
            requireActivity().isShowInterstitialAd{
                CreateBarcodeAllActivity.start(requireActivity())
            }
        }
    }

    private fun getClipboardContent(): String {
        val clip = requireActivity().clipboardManager?.primaryClip ?: return ""
        return when (clip.itemCount.orZero()) {
            0 -> ""
            else -> clip.getItemAt(0).text.toString()
        }
    }
}