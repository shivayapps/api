package com.qr.barcode.scanner.shivayapps.extension

fun Int?.orZero(): Int {
    return this ?: 0
}