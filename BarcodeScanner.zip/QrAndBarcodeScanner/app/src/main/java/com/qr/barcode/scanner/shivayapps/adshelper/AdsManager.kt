package com.qr.barcode.scanner.shivayapps.adshelper

import android.app.Activity
import android.util.Log

class AdsManager(mActivity: Activity) {

    // SP to be save & retrieve
    // SP to be save & retrieve
    private val isNeedToShow = "isNeedToShow"
    private val isSubscribe = "isSubscribe"
    private val sp: SharedPreferences = SharedPreferences(mActivity)

    fun onProductPurchased() {
        Log.e("IN_APP_BILLING","onProductPurchased")
        sp.save(isNeedToShow, true)
    }

    fun onProductSubscribed() {
        Log.e("IN_APP_BILLING","onProductSubscribed")
        sp.save(isSubscribe, true)
    }

    fun onProductExpired() {
        Log.e("IN_APP_BILLING","onProductExpired")
        sp.save(isNeedToShow, false)
    }
    fun onSubscribeExpired() {
        Log.e("IN_APP_BILLING","onProductExpired")
        sp.save(isSubscribe, false)
    }

    fun isNeedToShowAds(): Boolean {
//        com.example.app.ads.helper.isNeedToShowAds=true

        val isProductPurchased = sp.read(isNeedToShow, false)
        val isSubscribe = sp.read(isSubscribe, false)

//        if(BuildConfig.DEBUG) return false
        Log.e("IN_APP_BILLING", "isNeedToShowAds:isProductPurchased-$isProductPurchased")
        Log.e("IN_APP_BILLING", "isNeedToShowAds:isSubscribe-$isSubscribe")
        if(isProductPurchased || isSubscribe) return false
        return return true
    }

    /**
     *   SharedPreferences helper class
     */
    private inner class SharedPreferences//  Default constructor
    internal constructor(private val mActivity: Activity) {
        private val myPreferences = "ads_pref"

        //  Save boolean value
        fun save(key: String, value: Boolean) {
            val editor = mActivity.getSharedPreferences(myPreferences, 0).edit()
            editor.putBoolean(key, value)
            editor.apply()
        }

        //  Read Boolean value
        fun read(key: String, defValue: Boolean): Boolean {
            return mActivity.getSharedPreferences(myPreferences, 0).getBoolean(key, defValue)
        }

    }
}