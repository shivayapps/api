package com.qr.barcode.scanner.shivayapps.bottombar

interface OnItemReselectedListener {

    fun onItemReselect(pos: Int)
}
