package com.qr.barcode.scanner.shivayapps

import android.app.Activity
import com.example.app.ads.helper.VasuAdsConfig
import com.example.app.ads.helper.openad.AppOpenApplication
import com.example.app.ads.helper.openad.OpenAdHelper
import com.qr.barcode.scanner.shivayapps.adshelper.AdsManager
import com.qr.barcode.scanner.shivayapps.adshelper.InAppActivity
import com.qr.barcode.scanner.shivayapps.di.settings
import com.qr.barcode.scanner.shivayapps.usecase.Logger
import io.reactivex.plugins.RxJavaPlugins

class App : AppOpenApplication(), AppOpenApplication.AppLifecycleListener {

    override fun onCreate() {
        handleUnhandledRxJavaErrors()
        applyTheme()
        super.onCreate()

        setAppLifecycleListener(this)
        VasuAdsConfig.with(this)
            .isEnableOpenAd(true)
            .needToTakeAllTestAdID(false)
            .needToBlockInterstitialAd(false)
            .setAdmobAppId(getString(R.string.app_id))
            .setAdmobBannerAdId(getString(R.string.banner_ad_unit_id))
            .setAdmobInterstitialAdId(getString(R.string.inter_ad_unit_id))
            .setAdmobNativeAdvancedAdId(getString(R.string.native_ad_unit_id))
            .setAdmobOpenAdId(getString(R.string.open_ad_unit_id))
            .initialize()

        initMobileAds()
        OpenAdHelper.loadOpenAd(this)
    }

    private fun applyTheme() {
        settings.reapplyTheme()
    }

    private fun handleUnhandledRxJavaErrors() {
        RxJavaPlugins.setErrorHandler { error ->
            Logger.log(error)
        }
    }

    override fun onResumeApp(fCurrentActivity: Activity): Boolean {
        if (fCurrentActivity is InAppActivity) {
            return false
        } else if (AdsManager(fCurrentActivity).isNeedToShowAds()) {
            return true
        }
        return false
    }
}