package com.qr.barcode.scanner.shivayapps.bottombar

interface OnItemSelectedListener {

    fun onItemSelect(pos: Int): Boolean
}
