package com.qr.barcode.scanner.shivayapps.feature.tabs

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.qr.barcode.scanner.shivayapps.R
import com.qr.barcode.scanner.shivayapps.extension.applySystemWindowInsets
import com.qr.barcode.scanner.shivayapps.feature.BaseActivity
import com.qr.barcode.scanner.shivayapps.feature.tabs.create.CreateBarcodeFragment
import com.qr.barcode.scanner.shivayapps.feature.tabs.record.BarcodeHistoryFragment
import com.qr.barcode.scanner.shivayapps.feature.tabs.scan.ScanBarcodeFromCameraFragment
import kotlinx.android.synthetic.main.activity_bottom_tabs.*
import java.util.ArrayList

class BottomTabsActivity : BaseActivity() {

    companion object {
        private const val ACTION_CREATE_BARCODE = "${com.qr.barcode.scanner.shivayapps.BuildConfig.APPLICATION_ID}.CREATE_BARCODE"
        private const val ACTION_HISTORY = "${com.qr.barcode.scanner.shivayapps.BuildConfig.APPLICATION_ID}.HISTORY"
    }

    lateinit var viewPagerFragmentAdapter: ViewPagerFragmentAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bottom_tabs)

        supportEdgeToEdge()
        initBottomNavigationView()

        if (savedInstanceState == null) {
            showInitialFragment()
        }
        NativeAdvancedModelHelper(this@BottomTabsActivity)
            .loadBanner(
                adContainerView
            )
    }

//    override fun onNavigationItemSelected(item: MenuItem): Boolean {
//        if (item.itemId == bottom_navigation_view.selectedItemId) {
//            return false
//        }
//        showFragment(item.itemId)
//        return true
//    }

    override fun onBackPressed() {
//        if (bottom_navigation_view.selectedItemId == R.id.item_scan) {
            super.onBackPressed()
//        } else {
//            bottom_navigation_view.selectedItemId = R.id.item_scan
//        }
    }

    private fun supportEdgeToEdge() {
        bottom_navigation_view.applySystemWindowInsets(applyBottom = true)
    }

    private fun initBottomNavigationView() {

        viewPagerFragmentAdapter = ViewPagerFragmentAdapter(this)
        viewPagerFragmentAdapter.addFragment(ScanBarcodeFromCameraFragment())
        viewPagerFragmentAdapter.addFragment(CreateBarcodeFragment())
        viewPagerFragmentAdapter.addFragment(BarcodeHistoryFragment())

        viewPagerHome.apply {
            adapter = viewPagerFragmentAdapter
            offscreenPageLimit = 4
        }

        bottom_navigation_view.apply {
            setOnItemSelectedListener { position ->
                when (position) {
                    0 -> viewPagerHome.currentItem = 0
                    1 -> viewPagerHome.currentItem = 1
                    2 -> viewPagerHome.currentItem = 2
                }
            }
        }
        viewPagerHome.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback(){
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                when (position) {
                    0 -> bottom_navigation_view.itemActiveIndex=0
                    1 -> bottom_navigation_view.itemActiveIndex=1
                    2 -> bottom_navigation_view.itemActiveIndex=2
                }
            }
        })

    }

    private fun showInitialFragment() {
        when (intent?.action) {
            ACTION_CREATE_BARCODE -> {
                //bottom_navigation_view.selectedItemId = R.id.item_create
                viewPagerHome.currentItem = 1
            }
            ACTION_HISTORY -> {
                //bottom_navigation_view.selectedItemId = R.id.item_history
                viewPagerHome.currentItem = 2
            }
            else -> {
                //showFragment(R.id.item_scan)
                viewPagerHome.currentItem = 0
            }
        }
    }

//    private fun showFragment(bottomItemId: Int) {
//        val fragment = when (bottomItemId) {
//            R.id.item_scan -> ScanBarcodeFromCameraFragment()
//            R.id.item_create -> CreateBarcodeFragment()
//            R.id.item_history -> BarcodeHistoryFragment()
//            R.id.item_settings -> SettingsFragment()
//            else -> null
//        }
//        fragment?.apply(::replaceFragment)
//    }

//    private fun replaceFragment(fragment: Fragment) {
//        supportFragmentManager.beginTransaction()
//            .replace(R.id.layout_fragment_container, fragment)
//            .setReorderingAllowed(true)
//            .commit()
//    }

    class ViewPagerFragmentAdapter(activity: FragmentActivity) : FragmentStateAdapter(activity) {
        private val arrayList = ArrayList<Fragment>()
        fun addFragment(fragment: Fragment) {
            arrayList.add(fragment)
        }

        fun getFragment(position: Int): Fragment {
            return arrayList.get(position)
        }

        override fun getItemCount(): Int {
            return arrayList.size
        }

        override fun createFragment(position: Int): Fragment {
            return arrayList[position]
        }
    }
}