package com.transporter.main.activity

import android.view.View
import com.transporter.main.state.Rx3Life
import com.transporter.main.state.Rx3State
import io.reactivex.rxjava3.disposables.CompositeDisposable
import io.reactivex.rxjava3.subjects.BehaviorSubject
import io.reactivex.rxjava3.subjects.Subject

@Suppress("MemberVisibilityCanBePrivate")
abstract class BaseRx3StateTransportActivity<State : Any>(defaultState: State) :
    BaseTransportActivity(), Rx3State<State> {


    override val stateSubject: Subject<State> by lazyViewModelField("stateSubject") {
        BehaviorSubject.createDefault(defaultState).toSerialized()
    }

    protected val uiRxLife: Rx3Life by lazy {
        object : Rx3Life {
            override val lifeCompositeDisposable: CompositeDisposable = CompositeDisposable()
        }
    }

    protected val dataRxLife: Rx3Life by lazyViewModelField("dataRxLife") {
        object : Rx3Life {
            override val lifeCompositeDisposable: CompositeDisposable = CompositeDisposable()
        }
    }

    abstract fun Rx3Life.firstLaunchInitDataRx()

    final override fun firstLaunchInitData() {
        dataRxLife.firstLaunchInitDataRx()
    }

    abstract fun Rx3Life.bindContentViewRx(contentView: View)

    final override fun bindContentView(contentView: View) {
        uiRxLife.bindContentViewRx(contentView)
    }

    override fun onDestroy() {
        super.onDestroy()
        uiRxLife.lifeCompositeDisposable.clear()
    }

    override fun onViewModelCleared() {
        super.onViewModelCleared()
        dataRxLife.lifeCompositeDisposable.clear()
    }

}