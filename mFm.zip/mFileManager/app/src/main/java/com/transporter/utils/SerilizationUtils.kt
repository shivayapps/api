package com.transporter.utils

import com.squareup.moshi.Moshi



inline fun <reified T : Any> T.toJson(): String? {
    return try {
        Moshi.Builder().build().adapter(T::class.java).toJson(this)
    } catch (e: Throwable) {
        e.printStackTrace()
        null
    }
}

inline fun <reified T : Any> String.fromJson(): T? {
    return try {
        Moshi.Builder().build().adapter(T::class.java).fromJson(this)
    } catch (e: Throwable) {
        e.printStackTrace()
        null
    }
}

