package com.transporter.net.transferproto.qrscanconn

enum class QRCodeScanState { NoConnection, Requesting, Active }