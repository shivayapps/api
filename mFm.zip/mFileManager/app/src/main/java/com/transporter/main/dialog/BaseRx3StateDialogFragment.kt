package com.transporter.main.dialog

import com.transporter.main.state.Rx3Life
import com.transporter.main.state.Rx3State

abstract class BaseRx3StateDialogFragment<State: Any>(defaultState: State)
    : BaseDialogFragment(), Rx3State<State> by Rx3State(defaultState), Rx3Life by Rx3Life() {

    override fun onDestroy() {
        super.onDestroy()
        lifeCompositeDisposable.clear()
    }
}