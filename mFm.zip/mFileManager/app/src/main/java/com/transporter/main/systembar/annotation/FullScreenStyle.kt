package com.transporter.main.systembar.annotation

@Retention(AnnotationRetention.RUNTIME)
@Target(AnnotationTarget.CLASS)
annotation class FullScreenStyle(val sticky: Boolean = true, val ignoreCutoutArea: Boolean = true)
