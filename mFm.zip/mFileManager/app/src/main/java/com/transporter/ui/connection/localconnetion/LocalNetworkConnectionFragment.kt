package com.transporter.ui.connection.localconnetion

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.*
import android.net.wifi.p2p.WifiP2pManager
import android.os.Bundle
import android.view.View
import com.explorefile.filemanager.R
import com.explorefile.filemanager.databinding.LocalAddressItemLayoutBinding
import com.explorefile.filemanager.databinding.LocalNetworkConnectionFragmentBinding
import com.transporter.file.LOCAL_DEVICE
import com.transporter.logs.AndroidLog
import com.transporter.net.netty.findLocalAddressV4
import com.transporter.net.netty.toInetAddress
import com.transporter.net.transferproto.qrscanconn.QRCodeScanClient
import com.transporter.net.transferproto.qrscanconn.model.QRCodeShare
import com.transporter.net.transferproto.qrscanconn.requestFileTransferSuspend
import com.transporter.net.transferproto.qrscanconn.startQRCodeScanClientSuspend
import com.transporter.ui.filetransport.FileTransportTransportActivity
import com.transporter.ui.qrcodescan.ScanQrCodeTransportActivity
import com.transporter.utils.fromJson
import com.transporter.utils.showToastShort
import com.transporter.main.fragment.BaseCoroutineStateFragment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetAddress
import java.util.Optional
import kotlin.jvm.optionals.getOrNull
import androidx.core.content.getSystemService
import com.transporter.ui.connection.ConnectionTransportActivity
import com.transporter.main.actresult.startActivityResultSuspend
import com.transporter.main.adapter.impl.builders.SimpleAdapterBuilderImpl
import com.transporter.main.adapter.impl.databinders.DataBinderImpl
import com.transporter.main.adapter.impl.datasources.FlowDataSourceImpl
import com.transporter.main.adapter.impl.viewcreatators.SingleItemViewCreatorImpl
import com.transporter.main.view.clicks
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class LocalNetworkConnectionFragment : BaseCoroutineStateFragment<LocalNetworkConnectionFragment.Companion.LocalNetworkState>(
    defaultState = LocalNetworkState()
) {

    private val connectivityManager: ConnectivityManager? by lazy {
        requireActivity().getSystemService()
    }

    private val networkRequest: NetworkRequest by lazy {
        NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .addTransportType(NetworkCapabilities.TRANSPORT_ETHERNET)
            .build()
    }

    private val networkCallback: ConnectivityManager.NetworkCallback by lazy {
        object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                AndroidLog.d(TAG, "Network available: $network")
                updateAddress()
            }
            override fun onLost(network: Network) {
                AndroidLog.d(TAG, "Network lost: $network")
                updateAddress()
            }
        }
    }

    private val wifiP2pConnectionBroadcastReceiver: BroadcastReceiver by lazy {
        object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                AndroidLog.d(TAG, "Wifi p2p changed.")
                updateAddress()
            }
        }
    }
    override val layoutId: Int = R.layout.local_network_connection_fragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        connectivityManager?.registerNetworkCallback(networkRequest, networkCallback)
        val wifiP2pConnFilter = IntentFilter()
        wifiP2pConnFilter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
        wifiP2pConnFilter.addAction("android.net.wifi.WIFI_AP_STATE_CHANGED")
        requireContext().registerReceiver(wifiP2pConnectionBroadcastReceiver, wifiP2pConnFilter)
    }

    override fun CoroutineScope.firstLaunchInitDataCoroutine() {
        updateAddress(0L)
    }

    override fun CoroutineScope.bindContentViewCoroutine(contentView: View) {
        val viewBinding = LocalNetworkConnectionFragmentBinding.bind(contentView)

        val addressAdapterBuilder = SimpleAdapterBuilderImpl<Pair<InetAddress, Boolean>>(
            itemViewCreator = SingleItemViewCreatorImpl(R.layout.local_address_item_layout),
            dataSource = FlowDataSourceImpl(
                dataFlow = stateFlow
                    .map {
                        val selected = it.selectedAddress.getOrNull()
                        val available = it.availableAddresses
                        available.map { address ->
                            address to (address == selected)
                        }
                    },
                areDataItemsTheSameParam = { d1, d2 -> d1.first == d2.first },
                getDataItemsChangePayloadParam = { d1, d2 -> if (d1.first == d2.first && d1.second != d2.second) Unit else null }
            ),
            dataBinder = DataBinderImpl<Pair<InetAddress, Boolean>> { data, view, _ ->
                val itemViewBinding = LocalAddressItemLayoutBinding.bind(view)
                itemViewBinding.addressTv.text = data.first.toString().removePrefix("/")
                itemViewBinding.root.clicks(this@bindContentViewCoroutine) {
                    updateState { s ->
                        s.copy(selectedAddress = Optional.of(data.first))
                    }
                }
            }.addPayloadDataBinder(Unit) { data, view, _ ->
                val itemViewBinding = LocalAddressItemLayoutBinding.bind(view)
                itemViewBinding.addressRb.isChecked = data.second
            }
        )
        viewBinding.localAddressesRv.adapter = addressAdapterBuilder.build()

        // Scan QrCode
        viewBinding.scanQrCodeLayout.clicks(this) {
            val selectedAddress = currentState().selectedAddress.getOrNull()
            if (selectedAddress != null) {
                // Scan QRCode.
                val (_, resultData) = startActivityResultSuspend(Intent(requireActivity(), ScanQrCodeTransportActivity::class.java))
                if (resultData != null) {
                    val scanResultStrings = ScanQrCodeTransportActivity.getResult(resultData)
                    val qrcodeShare = scanResultStrings.map { it.fromJson<QRCodeShare>() }.firstOrNull()
                    if (qrcodeShare != null) {
                        val scanClient = QRCodeScanClient(AndroidLog)
                        runCatching {
                            val serverAddress = qrcodeShare.address.toInetAddress()
                            // Create request transfer file to QRCodeServer connection.
                            scanClient.startQRCodeScanClientSuspend(serverAddress)
                            AndroidLog.d(TAG, "Client connect address: $serverAddress success.")
                            withContext(Dispatchers.IO) {
                                // Request transfer file.
                                scanClient.requestFileTransferSuspend(targetAddress = serverAddress, deviceName = LOCAL_DEVICE)
                            }
                            serverAddress
                        }.onSuccess { serverAddress ->
                            withContext(Dispatchers.Main) {
                                requireActivity().startActivity(
                                    FileTransportTransportActivity.getIntent(
                                        context = requireContext(),
                                        localAddress = selectedAddress,
                                        remoteAddress = serverAddress,
                                        remoteDeviceInfo = qrcodeShare.deviceName,
                                        isServer = false,
                                        requestShareFiles = (requireActivity() as ConnectionTransportActivity).consumeRequestShareFiles()
                                    ))
                            }
                        }.onFailure {
                            withContext(Dispatchers.Main) {
                                requireActivity().showToastShort(getString(R.string.error_toast, it.message))
                            }
                        }
                    }
                }
            }
        }

        // Show QrCode
        viewBinding.showQrCodeLayout.clicks(this) {
            val selectedAddress = currentState().selectedAddress.getOrNull()
            if (selectedAddress != null) {
                val remoteAddress = childFragmentManager.showQRCodeServerDialogSuspend(selectedAddress)
                if (remoteAddress != null) {
                    withContext(Dispatchers.Main.immediate) {
                        requireActivity().startActivity(
                            FileTransportTransportActivity.getIntent(
                                context = requireContext(),
                                localAddress = selectedAddress,
                                remoteAddress = remoteAddress.remoteAddress.address,
                                remoteDeviceInfo = remoteAddress.deviceName,
                                isServer = true,
                                requestShareFiles = (requireActivity() as ConnectionTransportActivity).consumeRequestShareFiles()
                            ))
                    }
                }
            }
        }

        // Search Servers
        viewBinding.searchServerLayout.clicks(this) {
            val selectedAddress = currentState().selectedAddress.getOrNull()
            if (selectedAddress != null) {
                val remoteDevice =
                    childFragmentManager.showBroadcastReceiverDialogSuspend(selectedAddress)
                if (remoteDevice != null) {
                    withContext(Dispatchers.Main.immediate) {
                        startActivity(
                            FileTransportTransportActivity.getIntent(
                                context = requireContext(),
                                localAddress = selectedAddress,
                                remoteAddress = remoteDevice.remoteAddress.address,
                                remoteDeviceInfo = remoteDevice.deviceName,
                                isServer = false,
                                requestShareFiles = (requireActivity() as ConnectionTransportActivity).consumeRequestShareFiles()
                            )
                        )
                    }
                }
            }
        }

        // As Server
        viewBinding.asServerLayout.clicks(this) {
            val selectedAddress = currentState().selectedAddress.getOrNull()
            if (selectedAddress != null) {
                val remoteDevice = withContext(Dispatchers.Main) {
                    childFragmentManager.showBroadcastSenderDialogSuspend(selectedAddress)
                }
                if (remoteDevice != null) {
                    withContext(Dispatchers.Main.immediate) {
                        startActivity(
                            FileTransportTransportActivity.getIntent(
                                context = requireContext(),
                                localAddress = selectedAddress,
                                remoteAddress = remoteDevice.remoteAddress.address,
                                remoteDeviceInfo = remoteDevice.deviceName,
                                isServer = true,
                                requestShareFiles = (requireActivity() as ConnectionTransportActivity).consumeRequestShareFiles()
                            ))
                    }
                }
            }
        }
    }

    private val updateAddressLock: Mutex by lazy {
        Mutex()
    }

    private fun updateAddress(delay: Long = 1000L) {
        dataCoroutineScope?.launch {
            if (!updateAddressLock.isLocked) {
                updateAddressLock.withLock {
                    delay(delay)
                    val availableAddresses = findLocalAddressV4()
                    AndroidLog.d(TAG, "AvailableAddress: $availableAddresses")
                    updateState { oldState ->
                        if (availableAddresses.isEmpty()) {
                            oldState.copy(selectedAddress = Optional.empty(), availableAddresses = emptyList())
                        } else {
                            val oldSelectedAddress = oldState.selectedAddress
                            val newSelectedAddress = if (oldSelectedAddress.isPresent) {
                                if (availableAddresses.contains(oldSelectedAddress.get())) {
                                    oldSelectedAddress
                                } else {
                                    Optional.of(availableAddresses[0])
                                }
                            } else {
                                Optional.of(availableAddresses[0])
                            }
                            oldState.copy(
                                selectedAddress = newSelectedAddress,
                                availableAddresses = availableAddresses
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        connectivityManager?.unregisterNetworkCallback(networkCallback)
        requireContext().unregisterReceiver(wifiP2pConnectionBroadcastReceiver)
    }

    companion object {
        private const val TAG = "LocalNetworkConnectionFragment"
        data class LocalNetworkState(
            val selectedAddress: Optional<InetAddress> = Optional.empty(),
            val availableAddresses: List<InetAddress> = emptyList()
        )
    }
}