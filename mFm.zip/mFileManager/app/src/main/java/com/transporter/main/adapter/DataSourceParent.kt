package com.transporter.main.adapter

import androidx.annotation.MainThread
import com.transporter.main.assertMainThread
import com.transporter.main.Internal

@Internal
interface DataSourceParent<Data : Any> {

    @MainThread
    fun requestSubmitDataList(child: DataSource<Data>, data: List<Data>, callback: Runnable?) {
        assertMainThread { "DataSourceParent#requestSubmitDataList() need work on main thread." }
    }

}