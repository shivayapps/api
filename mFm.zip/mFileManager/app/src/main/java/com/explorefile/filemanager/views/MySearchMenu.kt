package com.explorefile.filemanager.views

import android.app.Activity
import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.BaseActivity
import com.explorefile.filemanager.databinding.MenuSearchBinding
import com.explorefile.filemanager.extensions.adjustAlpha
import com.explorefile.filemanager.extensions.applyColorFilter
import com.explorefile.filemanager.extensions.beGone
import com.explorefile.filemanager.extensions.beVisible
import com.explorefile.filemanager.extensions.hideKeyboard
import com.explorefile.filemanager.extensions.onTextChangeListener
import com.explorefile.filemanager.extensions.removeBit
import com.explorefile.filemanager.extensions.showKeyboard
import com.explorefile.filemanager.helpers.MEDIUM_ALPHA
import com.google.android.material.appbar.AppBarLayout

class MySearchMenu(context: Context, attrs: AttributeSet) : AppBarLayout(context, attrs) {
    var isSearchOpen = false
    var isNextPageOpen = false
    var useArrowIcon = false
//    var onSearchOpenListener: (() -> Unit)? = null
//    var onSearchClosedListener: (() -> Unit)? = null
    var onDrawerListener: (() -> Unit)? = null
    var onBackListener: (() -> Unit)? = null
//    var onSearchTextChangedListener: ((text: String) -> Unit)? = null
    var onNavigateBackClickListener: (() -> Unit)? = null

    val binding = MenuSearchBinding.inflate(LayoutInflater.from(context), this, true)

    fun getToolbar() = binding.topToolbar

    fun setupMenu() {
        binding.topToolbarDrawerIcon.setOnClickListener {
            if (isSearchOpen) {
                closeSearch()
            } else if (isNextPageOpen) {
                onBackListener?.invoke()
            } else if (useArrowIcon && onNavigateBackClickListener != null) {
                onNavigateBackClickListener!!()
            } else {
                onDrawerListener?.invoke()
            }
        }

//        binding.topToolbarSearchIcon.setOnClickListener {
//            binding.topToolbarName.beGone()
//            binding.topToolbarSearch.beVisible()
//            binding.topToolbarSearchIcon.beGone()
//            binding.topToolbarSearch.requestFocus()
//            (context as? Activity)?.showKeyboard(binding.topToolbarSearch)
//        }

//        post {
//            binding.topToolbarSearch.setOnFocusChangeListener { v, hasFocus ->
//                if (hasFocus) {
//                    openSearch()
//                }
//            }
//        }

//        binding.topToolbarSearch.onTextChangeListener { text ->
//            onSearchTextChangedListener?.invoke(text)
//        }
    }

    fun pageName(name: String) {
        binding.topToolbarName.text = name
    }

    fun nextPage() {
        isNextPageOpen = true
        binding.topToolbarDrawerIcon.setImageResource(R.drawable.ic_arrow_left_vector)
        binding.topToolbarDrawerIcon.contentDescription = resources.getString(R.string.back)
    }

    fun onHomePage() {
        isNextPageOpen = false
        if (!isSearchOpen) {
            binding.topToolbarDrawerIcon.setImageResource(R.drawable.ic_drawer_vector)
            binding.topToolbarDrawerIcon.contentDescription = resources.getString(R.string.drawer)
        }
    }

    private fun openSearch() {
//        isSearchOpen = true
//        onSearchOpenListener?.invoke()
//        binding.topToolbarDrawerIcon.setImageResource(R.drawable.ic_arrow_left_vector)
//        binding.topToolbarDrawerIcon.contentDescription = resources.getString(R.string.back)
    }


    fun closeSearch() {
//        isSearchOpen = false
//        onSearchClosedListener?.invoke()
//        binding.topToolbarSearch.setText("")
//        if (!isNextPageOpen) {
//            binding.topToolbarDrawerIcon.setImageResource(R.drawable.ic_drawer_vector)
//            binding.topToolbarDrawerIcon.contentDescription = resources.getString(R.string.drawer)
//        }
//        (context as? Activity)?.hideKeyboard()
//        binding.topToolbarSearch.beGone()
//        binding.topToolbarName.beVisible()
//        binding.topToolbarSearchIcon.beVisible()
    }


    fun toggleHideOnScroll(hideOnScroll: Boolean) {
        val params = binding.topAppBarLayout.layoutParams as LayoutParams
        if (hideOnScroll) {
            params.scrollFlags =
                LayoutParams.SCROLL_FLAG_SCROLL or LayoutParams.SCROLL_FLAG_ENTER_ALWAYS
        } else {
            params.scrollFlags =
                params.scrollFlags.removeBit(LayoutParams.SCROLL_FLAG_SCROLL or LayoutParams.SCROLL_FLAG_ENTER_ALWAYS)
        }
    }

    fun updateColors(textColor: Int, currentBackgroundColor: Int) {
        setBackgroundColor(currentBackgroundColor)
        binding.topAppBarLayout.setBackgroundColor(currentBackgroundColor)
        binding.topToolbarDrawerIcon.applyColorFilter(textColor)
//        binding.topToolbarSearchIcon.applyColorFilter(textColor)
        binding.topToolbarHolder.background?.applyColorFilter(currentBackgroundColor)
//        binding.topToolbarSearch.setTextColor(textColor)
        binding.topToolbarName.setTextColor(textColor)
//        binding.topToolbarSearch.setHintTextColor(textColor.adjustAlpha(MEDIUM_ALPHA))
        (context as? BaseActivity)?.updateTopBarColors(binding.topToolbar, currentBackgroundColor)
    }
}
