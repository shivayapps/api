package com.explorefile.filemanager.adapters

import android.content.Context
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.BaseActivity
import com.explorefile.filemanager.extensions.getContrastColor
import com.explorefile.filemanager.extensions.getProperBackgroundColor
import com.explorefile.filemanager.extensions.getProperPrimaryColor
import com.explorefile.filemanager.extensions.getProperTextColor
import com.explorefile.filemanager.models.AppInfo
import java.util.*

class AppAdapter(
    private val activity: BaseActivity,
    private val appType: String,
    private val onAppSelect: OnAppSelect
) : RecyclerView.Adapter<AppAdapter.ViewHolder>() {
    protected var textColor = activity.getProperTextColor()
    protected var backgroundColor = activity.getProperBackgroundColor()
    protected var properPrimaryColor = activity.getProperPrimaryColor()
    protected var contrastColor = properPrimaryColor.getContrastColor()
    private val appInfoList = mutableListOf<AppInfo>()
    private val appDefaultList = mutableListOf<AppInfo>()

    var isMultiSelect = false

    interface OnAppSelect {
        fun onAppClick(position: Int, appInfo: AppInfo)
        fun onAppSelect(position: Int, isChecked: Boolean, appInfo: AppInfo)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            LayoutInflater.from(activity)
                .inflate(R.layout.raw_list_of_app, parent, false)
        )
    }

    override fun getItemCount(): Int = appInfoList.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val appInfo = appInfoList[position]
        val uri = appInfo.appDrawableURI
        try {
            if (uri != Uri.EMPTY)
                Glide.with(activity)
                    .load(uri)
                    .into(holder.ivThumb)
            else {
                val img = ContextCompat.getDrawable(activity, R.drawable.ic_apk)
                holder.ivThumb.setImageDrawable(img)
            }
        } catch (e: Exception) {
            val img = ContextCompat.getDrawable(activity, R.drawable.ic_apk)
            holder.ivThumb.setImageDrawable(img)
        }

        holder.tvTitle?.setTextColor(textColor)
        holder.tvDetail?.setTextColor(textColor)
        holder.ivDelete.visibility=View.GONE
        holder.tvTitle.text = appInfo.appName
        holder.cbSelect.isChecked = appInfo.isSelected

            val size = String.format(Locale.ENGLISH, "%.2f", appInfo.appSize ?: 0.0)
            val installedOn = appInfo.installedOn ?: "Unknown"
            val usageTime = if (appInfo.usageTimeMillis > 0) {
                formatUsageTime(appInfo.usageTimeMillis)
            } else {
                "No usage data"
            }

            holder.tvDetail.text = "$size MB\nInstalled: $installedOn\nUsage: $usageTime"

        holder.cbSelect.setOnClickListener {
            appInfo.isSelected = holder.cbSelect.isChecked
            onAppSelect.onAppSelect(position, appInfo.isSelected, appInfo)
        }

        holder.llInfo.setOnClickListener {
            onAppSelect.onAppClick(position, appInfo)
        }

        holder.cbSelect.visibility =
            if (appType == "user") View.VISIBLE else View.GONE
    }

    private fun formatUsageTime(milliseconds: Long): String {
        val seconds = milliseconds / 1000
        val minutes = seconds / 60
        val hours = minutes / 60

        return when {
            hours > 0 -> String.format("%d hr %d min", hours, minutes % 60)
            minutes > 0 -> String.format("%d min %d sec", minutes, seconds % 60)
            else -> String.format("%d sec", seconds)
        }
    }
    fun updateList(newList: List<AppInfo>) {
        appInfoList.clear()
        appInfoList.addAll(newList)

        appDefaultList.clear()
        appDefaultList.addAll(newList)

        notifyDataSetChanged()
    }

    fun getAppList(): MutableList<AppInfo> = appInfoList

    fun deSelectAll() {
        appInfoList.forEach { it.isSelected = false }
        isMultiSelect = false
        notifyDataSetChanged()
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val tvTitle: TextView = itemView.findViewById(R.id.txt_name)
        val tvDetail: TextView = itemView.findViewById(R.id.tv_detail)
        val ivThumb: ImageView = itemView.findViewById(R.id.application_icon_image)
//        val ivOption: ImageView = itemView.findViewById(R.id.img_arrow)
        val ivDelete: ImageView = itemView.findViewById(R.id.img_delete)
        val cbSelect: CheckBox = itemView.findViewById(R.id.cb_select)
        val llInfo: LinearLayout = itemView.findViewById(R.id.ll_info)

    }
}