package com.explorefile.filemanager.adapters

import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.PopupMenu
import android.widget.RelativeLayout
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.resource.bitmap.CenterCrop
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.RequestOptions
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.BaseActivity
import com.explorefile.filemanager.activities.MainActivity
import com.explorefile.filemanager.databinding.ItemPdfListBinding
import com.explorefile.filemanager.dialogs.ConfirmationDialog
import com.explorefile.filemanager.dialogs.RenameDialog
import com.explorefile.filemanager.dialogs.RenameItemDialog
import com.explorefile.filemanager.dialogs.RenameItemsDialog
import com.explorefile.filemanager.extensions.baseConfig
import com.explorefile.filemanager.extensions.config
import com.explorefile.filemanager.extensions.dp
import com.explorefile.filemanager.extensions.getAndroidSAFUri
import com.explorefile.filemanager.extensions.getColoredDrawableWithColor
import com.explorefile.filemanager.extensions.getFilenameFromPath
import com.explorefile.filemanager.extensions.getProperPrimaryColor
import com.explorefile.filemanager.extensions.getProperTextColor
import com.explorefile.filemanager.extensions.getTimeFormat
import com.explorefile.filemanager.extensions.hasOTGConnected
import com.explorefile.filemanager.extensions.highlightTextPart
import com.explorefile.filemanager.extensions.isImageFast
import com.explorefile.filemanager.extensions.isPathOnOTG
import com.explorefile.filemanager.extensions.isPathOnRoot
import com.explorefile.filemanager.extensions.isRestrictedSAFOnlyRoot
import com.explorefile.filemanager.extensions.isVideoFast
import com.explorefile.filemanager.extensions.setupViewBackground
import com.explorefile.filemanager.extensions.toast
import com.explorefile.filemanager.extensions.toggleItemVisibility
import com.explorefile.filemanager.helpers.ensureBackgroundThread
import com.explorefile.filemanager.helpers.getFilePlaceholderDrawables
import com.explorefile.filemanager.models.FileDirItem
import com.explorefile.filemanager.models.ListItem
import com.stericson.RootTools.RootTools
import java.text.SimpleDateFormat
import java.util.ArrayList
import java.util.Calendar

class PdfScanAdapter(
    val activity: BaseActivity,
    private val dataList: List<ListItem>,
    val actionClick: (Int) -> Unit,
    val itemClick: (Int) -> Unit
) : RecyclerView.Adapter<PdfScanAdapter.ViewHolder>() {
    //    private lateinit var fileDrawable: Drawable
//    private lateinit var folderDrawable: Drawable
//    private var fileDrawables = HashMap<String, Drawable>()
    private var textToHighlight = ""
    private val hasOTGConnected = activity.hasOTGConnected()
    private var dateFormat = ""
    private var timeFormat = ""
    private val config = activity.config
    private val baseConfig = activity.baseConfig
    private val resources = activity.resources!!

    private val layoutParams = RelativeLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.MATCH_PARENT
    )

    private val layoutGridParams = RelativeLayout.LayoutParams(
        40.dp,
        40.dp
    )

    init {
//        initDrawables()
        dateFormat = config.dateFormat
        timeFormat = activity.getTimeFormat()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            ItemPdfListBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = dataList[position]
        bind(item, holder.binding)

        holder.binding.ivOptions.setOnClickListener {
            val popupMenu = PopupMenu(activity, holder.binding.ivOptions)
            popupMenu.inflate(R.menu.menu_pdf)

            popupMenu.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    R.id.menu_rename -> {
                        //actionClick.invoke(position,1)
                        displayRenameDialog(arrayListOf(dataList[position]))

                        true
                    }

                    R.id.menu_delete -> {
                        toggleFileVisibility(dataList[position], true)
                        true
                    }

                    else -> false
                }
            }
            popupMenu.show()
        }
        holder.binding.itemFrame.setOnClickListener {
            itemClick.invoke(position)
        }
    }

    private fun toggleFileVisibility(fileItem: FileDirItem, hide: Boolean) {
        val itemsCnt = 1
        val items = if (itemsCnt == 1) {
            "\"${fileItem.path.getFilenameFromPath()}\""
        } else {
            resources.getQuantityString(R.plurals.delete_items, itemsCnt, itemsCnt)
        }

        val question =
            String.format(resources.getString(R.string.move_to_trash_confirmation), items)

        ConfirmationDialog(
            activity,
            question,
            0,
            R.string.move_to_trash,
            R.string.no,
            true,
            R.string.file_will_move_to_trash
        ) {

            ensureBackgroundThread {
//                getSelectedFileDirItems().forEach {
                activity.toggleItemVisibility(fileItem.path, hide) {
                    actionClick.invoke(2)
                }
//                }
//                activity.runOnUiThread {
//                    MainActivity.itemMoment = true
//                    val files = ArrayList<FileDirItem>(1)
//                    val positions = ArrayList<Int>()
////                    selectedKeys.forEach { pos ->
//                        val position =
//                            listItems.indexOfFirst { item -> item.path.hashCode() == pos }
//                        if (position != -1) {
//                            positions.add(position)
//                            files.add(listItems[position])
//                        }
////                    }
//
//                    positions.sortDescending()
//                    removeSelectedItems(positions)
//                    positions.forEach { pos ->
//                        listItems.removeAt(pos)
//                    }
//                }
            }
        }
    }

    private fun displayRenameDialog(fileDirItems: ArrayList<FileDirItem>) {
//        val fileDirItems = getSelectedFileDirItems()
        val paths = fileDirItems.asSequence().map { it.path }.toMutableList() as ArrayList<String>
        when {
            paths.size == 1 -> {
                val oldPath = paths.first()
                RenameItemDialog(activity, oldPath) {
                    activity.runOnUiThread {
                        actionClick.invoke(1)
//                        MainActivity.itemMoment = true
                    }
                }
            }

            fileDirItems.any { it.isDirectory } -> RenameItemsDialog(activity, paths) {
                activity.runOnUiThread {
                    actionClick.invoke(1)
//                    MainActivity.itemMoment = true
                }
            }

            else -> RenameDialog(activity, paths, false) {
                activity.runOnUiThread {
//                    actionClick.invoke(0,1)
                }
            }
        }
    }

    override fun getItemCount(): Int {
        return if (dataList.size >= 10) 10 else dataList.size
    }

    inner class ViewHolder(var binding: ItemPdfListBinding) :
        RecyclerView.ViewHolder(binding.root)

    fun bind(listItem: ListItem, binding: ItemPdfListBinding) {
        binding.apply {
            root.setupViewBackground(activity)
            val fileName = listItem.name
            itemDate.text = getDate(listItem.mModified)
            itemName.text =
                if (textToHighlight.isEmpty()) fileName else fileName.highlightTextPart(
                    textToHighlight,
                    activity.getProperPrimaryColor()
                )
            val textColor = activity.baseConfig.textColor
            itemName.setTextColor(textColor)
            itemDate.setTextColor(textColor)

        }
    }

    private fun getDate(milliSeconds: Long): String {
        val formatter = SimpleDateFormat("EEE-MMM dd,yyyy")
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = milliSeconds
        return formatter.format(calendar.time)
    }

    private fun getImagePathToLoad(path: String): Any {
        var itemToLoad = if (path.endsWith(".apk", true)) {
            val packageInfo =
                activity.packageManager.getPackageArchiveInfo(path, PackageManager.GET_ACTIVITIES)
            if (packageInfo != null) {
                val appInfo = packageInfo.applicationInfo
                appInfo?.sourceDir = path
                appInfo?.publicSourceDir = path
                appInfo?.loadIcon(activity.packageManager)
            } else {
                path
            }
        } else {
            path
        }

        if (activity.isRestrictedSAFOnlyRoot(path)) {
            itemToLoad = activity.getAndroidSAFUri(path)
        } else if (hasOTGConnected && itemToLoad is String && activity.isPathOnOTG(itemToLoad) && baseConfig.OTGTreeUri.isNotEmpty() && baseConfig.OTGPartition.isNotEmpty()) {
            itemToLoad = getOTGPublicPath(itemToLoad)
        }

        return itemToLoad!!
    }

    private fun getOTGPublicPath(itemToLoad: String) =
        "${baseConfig.OTGTreeUri}/document/${baseConfig.OTGPartition}%3A${
            itemToLoad.substring(
                baseConfig.OTGPath.length
            ).replace("/", "%2F")
        }"

//    private fun initDrawables() {
//        folderDrawable =
//            resources.getColoredDrawableWithColor(
//                R.drawable.ic_folder_vector,
//                activity.getProperTextColor()
//            )
//        fileDrawable = resources.getDrawable(R.drawable.ic_file_generic)
//        fileDrawables = getFilePlaceholderDrawables(activity)
//    }

}