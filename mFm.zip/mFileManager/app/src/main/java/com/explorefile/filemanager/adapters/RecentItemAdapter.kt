package com.explorefile.filemanager.adapters

import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.RelativeLayout
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.resource.bitmap.CenterCrop
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.RequestOptions
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.BaseActivity
import com.explorefile.filemanager.databinding.ItemRecentFileGridBinding
import com.explorefile.filemanager.extensions.baseConfig
import com.explorefile.filemanager.extensions.config
import com.explorefile.filemanager.extensions.dp
import com.explorefile.filemanager.extensions.getAndroidSAFUri
import com.explorefile.filemanager.extensions.getColoredDrawableWithColor
import com.explorefile.filemanager.extensions.getProperPrimaryColor
import com.explorefile.filemanager.extensions.getProperTextColor
import com.explorefile.filemanager.extensions.getTimeFormat
import com.explorefile.filemanager.extensions.hasOTGConnected
import com.explorefile.filemanager.extensions.highlightTextPart
import com.explorefile.filemanager.extensions.isImageFast
import com.explorefile.filemanager.extensions.isPathOnOTG
import com.explorefile.filemanager.extensions.isRestrictedSAFOnlyRoot
import com.explorefile.filemanager.extensions.isVideoFast
import com.explorefile.filemanager.extensions.setupViewBackground
import com.explorefile.filemanager.helpers.getFilePlaceholderDrawables
import com.explorefile.filemanager.models.ListItem

class RecentItemAdapter(
    val activity: BaseActivity,
    private val dataList: List<ListItem>,
    val itemClick: (Int) -> Unit
) : RecyclerView.Adapter<RecentItemAdapter.ViewHolder>() {
    private lateinit var fileDrawable: Drawable
    private lateinit var folderDrawable: Drawable
    private var fileDrawables = HashMap<String, Drawable>()
    private var textToHighlight = ""
    private val hasOTGConnected = activity.hasOTGConnected()
    private var dateFormat = ""
    private var timeFormat = ""
    private val config = activity.config
    private val baseConfig = activity.baseConfig
    private val resources = activity.resources!!

    private val layoutParams = RelativeLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.MATCH_PARENT
    )

    private val layoutGridParams = RelativeLayout.LayoutParams(
        40.dp,
        40.dp
    )

    init {
        initDrawables()
        dateFormat = config.dateFormat
        timeFormat = activity.getTimeFormat()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            ItemRecentFileGridBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = dataList[position]
        bind(item, holder.binding)

        holder.binding.itemFrame.setOnClickListener {
            itemClick.invoke(position)
        }
    }

    override fun getItemCount(): Int {
        return if (dataList.size >= 10) 10 else dataList.size
    }

    inner class ViewHolder(var binding: ItemRecentFileGridBinding) :
        RecyclerView.ViewHolder(binding.root)

    fun bind(listItem: ListItem, binding: ItemRecentFileGridBinding) {
        binding.apply {
            root.setupViewBackground(activity)
            val fileName = listItem.name
            itemName.text =
                if (textToHighlight.isEmpty()) fileName else fileName.highlightTextPart(
                    textToHighlight,
                    activity.getProperPrimaryColor()
                )
            itemName.setTextColor(activity.getProperTextColor())

            if (listItem.isDirectory) {
                itemIcon.setImageDrawable(folderDrawable)
            } else {
                val drawable = fileDrawables.getOrElse(
                    fileName.substringAfterLast(".").toLowerCase()
                ) { fileDrawable }

                val options = RequestOptions()
                    .signature(listItem.getKey())
                    .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                    .error(drawable)
                    .transform(CenterCrop(), RoundedCorners(10))
                if (listItem.path.isImageFast()) {
                    itemIcon.layoutParams = layoutParams
                } else if (listItem.path.isVideoFast()) {
                    itemIcon.layoutParams = layoutParams
                } else {
                    itemIcon.layoutParams = layoutGridParams
                }
                val itemToLoad = getImagePathToLoad(listItem.path)
                if (!activity.isDestroyed) {
                    Glide.with(activity)
                        .load(itemToLoad)
                        .transition(DrawableTransitionOptions.withCrossFade())
                        .apply(options)
                        .into(itemIcon)
                }
            }

        }
    }

    private fun getImagePathToLoad(path: String): Any {
        var itemToLoad = if (path.endsWith(".apk", true)) {
            val packageInfo =
                activity.packageManager.getPackageArchiveInfo(path, PackageManager.GET_ACTIVITIES)
            if (packageInfo != null) {
                val appInfo = packageInfo.applicationInfo
                appInfo?.sourceDir = path
                appInfo?.publicSourceDir = path
                appInfo?.loadIcon(activity.packageManager)
            } else {
                path
            }
        } else {
            path
        }

        if (activity.isRestrictedSAFOnlyRoot(path)) {
            itemToLoad = activity.getAndroidSAFUri(path)
        } else if (hasOTGConnected && itemToLoad is String && activity.isPathOnOTG(itemToLoad) && baseConfig.OTGTreeUri.isNotEmpty() && baseConfig.OTGPartition.isNotEmpty()) {
            itemToLoad = getOTGPublicPath(itemToLoad)
        }

        return itemToLoad!!
    }

    private fun getOTGPublicPath(itemToLoad: String) =
        "${baseConfig.OTGTreeUri}/document/${baseConfig.OTGPartition}%3A${
            itemToLoad.substring(
                baseConfig.OTGPath.length
            ).replace("/", "%2F")
        }"

    private fun initDrawables() {
        folderDrawable =
            resources.getColoredDrawableWithColor(
                R.drawable.ic_folder_vector,
                activity.getProperTextColor()
            )
        fileDrawable = resources.getDrawable(R.drawable.ic_file_generic)
        fileDrawables = getFilePlaceholderDrawables(activity)
    }

}