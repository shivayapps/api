package com.explorefile.filemanager.extensions

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.fragment.app.FragmentActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.biometric.auth.AuthPromptCallback
import androidx.biometric.auth.AuthPromptHost
import androidx.biometric.auth.Class2BiometricAuthPrompt
import com.explorefile.filemanager.R


fun Activity.isSupportWithErrorInfo(
    ctx: Context,
    type: Int,
): Pair<Boolean, String> {
    val biometricManager = BiometricManager.from(ctx)
    val authStatusCode = biometricManager.canAuthenticate(type)

    Log.e(
        "BiometricManager",
        "isSupportWithErrorInfo\nauthStatusCode:$authStatusCode\n,type:$type"
    )

    if (authStatusCode == BiometricManager.BIOMETRIC_STATUS_UNKNOWN ||
        authStatusCode == BiometricManager.BIOMETRIC_ERROR_UNSUPPORTED ||
        authStatusCode == BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE
    ) {
//            return Pair(false, "Device_unsupported")
        return Pair(false, getString(R.string.device_unsupported))
    } else if (authStatusCode == BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE) {
        return Pair(false, getString(R.string.setting_biometric_error_hardware_unavailable))
    } else if (authStatusCode == BiometricManager.BIOMETRIC_ERROR_SECURITY_UPDATE_REQUIRED) {
        return Pair(false, getString(R.string.setting_biometric_error_not_secure))
    } else if (authStatusCode == BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED) {
        return Pair(false, getString(R.string.setting_biometric_error_none_enrolled))
    }
//        if (!isKeyguardSecure(ctx)) {
//            return Pair(false, ctx.getString(R.string.setting_biometric_error_pin_not_set))
//        }
//        if (!isSecureHardware()) {
//            return Pair(false, "isSecureHardware ${ctx.getString(R.string.setting_biometric_error_not_secure)}")
//        }
//        if (RootUtil.isDeviceRooted) {
//            return Pair(false, ctx.getString(R.string.setting_biometric_error_rooted))
//        }
    return Pair(true, "")
}


fun Activity.showBiometricPrompt(
    successCallback: (icSuccess: Boolean) -> Unit,
    failureCallback: (icFailed: Boolean, errorCode: Int, errString: CharSequence) -> Unit
) {
    Class2BiometricAuthPrompt.Builder(getText(R.string.authenticate), getText(R.string.cancel))
        .build()
        .startAuthentication(
            AuthPromptHost(this as FragmentActivity),
            object : AuthPromptCallback() {
                override fun onAuthenticationSucceeded(
                    activity: FragmentActivity?,
                    result: BiometricPrompt.AuthenticationResult
                ) {
                    successCallback.invoke(true)
                }

                override fun onAuthenticationError(
                    activity: FragmentActivity?,
                    errorCode: Int,
                    errString: CharSequence
                ) {
                    val isCanceledByUser =
                        errorCode == BiometricPrompt.ERROR_NEGATIVE_BUTTON || errorCode == BiometricPrompt.ERROR_USER_CANCELED
                    if (!isCanceledByUser) {
                        toast(errString.toString())
                    }
                    failureCallback.invoke(false, errorCode, errString)
                }

                override fun onAuthenticationFailed(activity: FragmentActivity?) {
                    successCallback.invoke(false)
                }
            }
        )
}