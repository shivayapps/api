package com.explorefile.filemanager.activities

import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.explorefile.filemanager.App
import com.explorefile.filemanager.databinding.ActivityFileViewerBinding
import com.explorefile.filemanager.extensions.getProperBackgroundColor
import com.explorefile.filemanager.extensions.viewBinding
import com.explorefile.filemanager.fragments.MediaFragment
import com.explorefile.filemanager.helpers.NavigationIcon
import com.explorefile.filemanager.models.ListItem
import com.explorefile.filemanager.models.delete
import com.explorefile.filemanager.models.share

class FileViewerActivity : BaseActivity() {

    private var fileList: ArrayList<ListItem> = ArrayList()
    private val binding by viewBinding(ActivityFileViewerBinding::inflate)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        fileList.addAll(App.displayListItem)
        val startPosition = intent.getIntExtra("POSITION", 0)

        fileList.getOrNull(startPosition)?.let {
            setTitle(it.mName.ifEmpty { it.name })
        }
        val adapter = MediaPagerAdapter(this@FileViewerActivity, fileList)
        binding.viewPager.adapter = adapter
        binding.viewPager.setCurrentItem(startPosition, false)
        binding.viewPager.registerOnPageChangeCallback(
            object : ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    super.onPageSelected(position)
                    val item = fileList.getOrNull(position)
                    item?.let {
                        setTitle(it.mName.ifEmpty { it.name })
                    }
                }
            }
        )


        setupToolbar()

        binding.llShare.setOnClickListener {
            getCurrentItem()?.let { shareFile(it) }
        }
        binding.llDelete.setOnClickListener {
            getCurrentItem()?.let { deleteFile(it) }
        }

    }

    private fun getCurrentItem(): ListItem? {
        val position = binding.viewPager.currentItem
        return if (position in fileList.indices) fileList[position] else null
    }

    private fun deleteFile(item: ListItem) {
        if (item.delete()) {
            val pos = binding.viewPager.currentItem
            fileList.removeAt(pos)
            binding.viewPager.adapter?.notifyItemRemoved(pos)
        }
    }

    private fun shareFile(item: ListItem) {
        item.share(this)
    }

    override fun onResume() {
        super.onResume()
        setupToolbar(binding.fileviewerToolbar, NavigationIcon.Arrow)
        updateTopBarColors(binding.fileviewerToolbar, getProperBackgroundColor())
    }

    private fun setupToolbar() {
        binding.fileviewerToolbar.title = ""
    }

    private fun setTitle(title: String) {
        binding.fileviewerToolbar.title = title
    }

    fun next() {
        Log.e("MediaFragment", "next")
    }

    fun prev() {
        Log.e("MediaFragment", "prev")
    }

    class MediaPagerAdapter(
        activity: FragmentActivity,
        private val items: List<ListItem>
    ) : FragmentStateAdapter(activity) {

        override fun getItemCount() = items.size

        override fun createFragment(position: Int): Fragment {
            return MediaFragment.newInstance(items[position].path)
        }
    }

}