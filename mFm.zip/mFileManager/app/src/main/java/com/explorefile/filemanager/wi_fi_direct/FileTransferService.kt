package com.explorefile.filemanager.wi_fi_direct

import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.OpenableColumns
import android.util.Log
import androidx.core.net.toUri
import androidx.documentfile.provider.DocumentFile
import com.explorefile.filemanager.wi_fi_direct.CryptoHelper
import kotlinx.coroutines.*
import java.io.*
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket

class FileTransferService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var serverSocket: ServerSocket? = null

    companion object {
        const val ACTION_SEND_FILE = "com.skl.securefastfiletransfer.SEND_FILE"
        const val ACTION_RECEIVE_FILE = "com.skl.securefastfiletransfer.RECEIVE_FILE"
        const val ACTION_STOP_SERVICE = "com.skl.securefastfiletransfer.STOP_SERVICE"

        // Changed: Use ArrayList<Uri> instead of single path/uri
        const val EXTRA_FILE_URIS = "file_uris"

        const val EXTRA_HOST = "host_address"
        const val EXTRA_SECRET = "shared_secret"
        const val EXTRA_SAVE_DIRECTORY_URI = "save_directory_uri"
        private const val FILE_TRANSFER_PORT = 8989
        private const val STATUS_NOTIFICATION_PORT = 8990

        // Progress broadcast actions
        const val ACTION_TRANSFER_PROGRESS = "com.skl.securefastfiletransfer.TRANSFER_PROGRESS"
        const val ACTION_TRANSFER_COMPLETE = "com.skl.securefastfiletransfer.FILE_TRANSFER_COMPLETE"
        const val ACTION_SENDER_STATUS_UPDATE = "com.skl.securefastfiletransfer.SENDER_STATUS_UPDATE"

        const val EXTRA_PROGRESS_BYTES = "progress_bytes"
        const val EXTRA_TOTAL_BYTES = "total_bytes"
        const val EXTRA_TRANSFER_SPEED = "transfer_speed"
        const val EXTRA_IS_SENDING = "is_sending"
        const val EXTRA_OPERATION_TYPE = "operation_type"
        const val EXTRA_VERIFICATION_PROGRESS = "verification_progress"

        // New Extras for Multi-file support
        const val EXTRA_CURRENT_FILE_INDEX = "current_file_index" // 1-based index
        const val EXTRA_TOTAL_FILES_COUNT = "total_files_count"
        const val EXTRA_CURRENT_FILE_NAME = "current_file_name"

        fun startService(
            context: Context,
            action: String,
            fileUris: ArrayList<Uri>? = null, // Changed from single Uri to ArrayList
            hostAddress: String? = null,
            secret: String,
            saveDirectoryUri: Uri? = null
        ) {
            val intent = Intent(context, FileTransferService::class.java).apply {
                this.action = action
                putExtra(EXTRA_SECRET, secret)
                // Pass the list of URIs
                fileUris?.let { putParcelableArrayListExtra(EXTRA_FILE_URIS, it) }
                hostAddress?.let { putExtra(EXTRA_HOST, it) }
                saveDirectoryUri?.let { putExtra(EXTRA_SAVE_DIRECTORY_URI, it.toString()) }
            }
            context.startService(intent)
        }

        fun stopService(context: Context) {
            val intent = Intent(context, FileTransferService::class.java).apply {
                action = ACTION_STOP_SERVICE
            }
            context.startService(intent)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent ?: return START_NOT_STICKY

        when (intent.action) {
            ACTION_SEND_FILE -> {
                // Retrieve the list of URIs
                val fileUris = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableArrayListExtra(EXTRA_FILE_URIS, Uri::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableArrayListExtra(EXTRA_FILE_URIS)
                }

                val hostAddress = intent.getStringExtra(EXTRA_HOST)
                val secret = intent.getStringExtra(EXTRA_SECRET)

                if (hostAddress != null && secret != null && !fileUris.isNullOrEmpty()) {
                    serviceScope.launch {
                        sendFilesFromUris(fileUris, hostAddress, secret)
                        stopSelf(startId)
                    }
                } else {
                    Log.e("FileTransferService", "Missing host, secret, or files")
                    stopSelf(startId)
                }
            }
            ACTION_RECEIVE_FILE -> {
                val secret = intent.getStringExtra(EXTRA_SECRET)
                val saveDirectoryUriString = intent.getStringExtra(EXTRA_SAVE_DIRECTORY_URI)
                val saveDirectoryUri = saveDirectoryUriString?.toUri()
                if (secret != null) {
                    serviceScope.launch {
                        receiveFiles(secret, saveDirectoryUri) // Updated function name
                        stopSelf(startId)
                    }
                } else {
                    stopSelf(startId)
                }
            }
            ACTION_STOP_SERVICE -> {
                stopSelf()
            }
        }

        return START_NOT_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        serverSocket?.close()
        serviceScope.cancel()
    }

    // Updated Sender Logic for Multiple Files
    private suspend fun sendFilesFromUris(fileUris: ArrayList<Uri>, hostAddress: String, secret: String) = withContext(Dispatchers.IO) {
        var socket: Socket? = null
        try {
            Log.d("FileTransferService", "Preparing to send ${fileUris.size} files")

            socket = Socket()
            socket.connect(InetSocketAddress(hostAddress, FILE_TRANSFER_PORT))
            socket.soTimeout = 0

            val outputStream = socket.getOutputStream()
            val dataOutputStream = DataOutputStream(outputStream)

            // 1. Protocol Start: Send the number of files to be transferred
            dataOutputStream.writeInt(fileUris.size)
            dataOutputStream.flush()

            var successCount = 0

            // Loop through each URI
            for ((index, uri) in fileUris.withIndex()) {
                val currentFileIndex = index + 1

                // Get file metadata
                val fileName = getFileName(uri) ?: "unknown_file_$index"
                val fileSize = getFileSize(uri)

                Log.d("FileTransferService", "Sending File $currentFileIndex/${fileUris.size}: $fileName ($fileSize bytes)")

                // 2. Send File Metadata (Name and Size) for the current file
                dataOutputStream.writeUTF(fileName)
                dataOutputStream.writeLong(fileSize)
                dataOutputStream.flush()

                // Progress callback for this specific file
                val progressCallback: (Long, Long, Float) -> Unit = { bytesProcessed, totalBytes, speed ->
                    launch(Dispatchers.Main) {
                        val progressIntent = Intent(ACTION_TRANSFER_PROGRESS)
                        progressIntent.setPackage(packageName)
                        progressIntent.putExtra(EXTRA_PROGRESS_BYTES, bytesProcessed)
                        progressIntent.putExtra(EXTRA_TOTAL_BYTES, totalBytes)
                        progressIntent.putExtra(EXTRA_TRANSFER_SPEED, speed)
                        progressIntent.putExtra(EXTRA_IS_SENDING, true)
                        progressIntent.putExtra(EXTRA_OPERATION_TYPE, "encrypting_and_sending")

                        // New fields for multi-file UI updates
                        progressIntent.putExtra(EXTRA_CURRENT_FILE_INDEX, currentFileIndex)
                        progressIntent.putExtra(EXTRA_TOTAL_FILES_COUNT, fileUris.size)
                        progressIntent.putExtra(EXTRA_CURRENT_FILE_NAME, fileName)

                        sendBroadcast(progressIntent)
                    }
                }

                // Open stream and encrypt
                contentResolver.openInputStream(uri)?.use { inputStream ->
                    val success = CryptoHelper.encryptFileStreamWithProgress(
                        inputStream,
                        dataOutputStream,
                        secret,
                        fileSize,
                        fileName,
                        progressCallback
                    )

                    if (success) {
                        successCount++
                        dataOutputStream.flush() // Ensure all bytes for this file are pushed
                        Log.d("FileTransferService", "Finished sending file: $fileName")
                    } else {
                        throw Exception("Failed to encrypt file: $fileName")
                    }
                } ?: throw Exception("Could not open stream for URI: $uri")
            }

            // All files sent
            dataOutputStream.close()
            socket.close()

            val broadcastIntent = Intent(ACTION_TRANSFER_COMPLETE)
            broadcastIntent.setPackage(packageName)
            broadcastIntent.putExtra("success", true)
            broadcastIntent.putExtra("message", "Sent $successCount of ${fileUris.size} files successfully")
            sendBroadcast(broadcastIntent)

        } catch (e: Exception) {
            Log.e("FileTransferService", "Error sending files: ${e.message}")
            socket?.close()
            val broadcastIntent = Intent(ACTION_TRANSFER_COMPLETE)
            broadcastIntent.setPackage(packageName)
            broadcastIntent.putExtra("success", false)
            broadcastIntent.putExtra("message", "Transfer failed: ${e.message}")
            sendBroadcast(broadcastIntent)
        }
    }

    // Updated Receiver Logic for Multiple Files
    private suspend fun receiveFiles(secret: String, saveDirectoryUri: Uri?) = withContext(Dispatchers.IO) {
        try {
            serverSocket = ServerSocket(FILE_TRANSFER_PORT)
            serverSocket?.soTimeout = 0
            Log.d("FileTransferService", "Waiting for connection...")

            // Notify UI waiting
            launch(Dispatchers.Main) {
                val intent = Intent(ACTION_TRANSFER_PROGRESS)
                intent.setPackage(packageName)
                intent.putExtra(EXTRA_OPERATION_TYPE, "waiting_for_connection")
                intent.putExtra(EXTRA_CURRENT_FILE_INDEX, 0)
                intent.putExtra(EXTRA_TOTAL_FILES_COUNT, 0)
                sendBroadcast(intent)
            }

            val socket = serverSocket?.accept()
            socket?.soTimeout = 0
            val inputStream = socket?.getInputStream()
            val dataInputStream = DataInputStream(inputStream)

            // 1. Protocol Start: Read number of files
            val totalFiles = dataInputStream.readInt()
            Log.d("FileTransferService", "Sender preparing to send $totalFiles files")

            var filesReceivedCount = 0
            val receivedFilePaths = ArrayList<String>()

            // Loop based on the number of files expected
            for (i in 0 until totalFiles) {
                val currentFileIndex = i + 1

                // 2. Read File Metadata
                val fileName = dataInputStream.readUTF()
                val fileSize = dataInputStream.readLong()

                Log.d("FileTransferService", "Receiving File $currentFileIndex/$totalFiles: $fileName ($fileSize bytes)")

                // Callback for this file
                var lastProgressUpdate = System.currentTimeMillis()
                var startTime = System.currentTimeMillis()

                val progressCallback: (Long, String?, Long?) -> Unit = { bytesProcessed, _, _ ->
                    val currentTime = System.currentTimeMillis()
                    if (currentTime - lastProgressUpdate > 100) {
                        launch(Dispatchers.Main) {
                            val progressIntent = Intent(ACTION_TRANSFER_PROGRESS)
                            progressIntent.setPackage(packageName)
                            progressIntent.putExtra(EXTRA_PROGRESS_BYTES, bytesProcessed)
                            progressIntent.putExtra(EXTRA_TOTAL_BYTES, fileSize)

                            val elapsedSeconds = (currentTime - startTime) / 1000f
                            val speed = if (elapsedSeconds > 0.1f) bytesProcessed / elapsedSeconds else 0f

                            progressIntent.putExtra(EXTRA_TRANSFER_SPEED, speed)
                            progressIntent.putExtra(EXTRA_IS_SENDING, false)
                            progressIntent.putExtra(EXTRA_OPERATION_TYPE, "receiving_and_decrypting")

                            // Multi-file extras
                            progressIntent.putExtra(EXTRA_CURRENT_FILE_INDEX, currentFileIndex)
                            progressIntent.putExtra(EXTRA_TOTAL_FILES_COUNT, totalFiles)
                            progressIntent.putExtra(EXTRA_CURRENT_FILE_NAME, fileName)

                            sendBroadcast(progressIntent)
                        }
                        lastProgressUpdate = currentTime
                    }
                }

                val integrityCheckCallback: () -> Unit = {
                    // Can broadcast "Verifying" state here if needed
                }

                // Determine save path
                val savedFilePath = determineSavePathAndDecrypt(
                    saveDirectoryUri,
                    fileName,
                    secret,
                    dataInputStream,
                    progressCallback,
                    integrityCheckCallback
                )

                receivedFilePaths.add(savedFilePath)
                filesReceivedCount++
                Log.d("FileTransferService", "File $currentFileIndex saved to $savedFilePath")
            }

            dataInputStream.close()
            serverSocket?.close()
            serverSocket = null

            // Final success broadcast
            val broadcastIntent = Intent(ACTION_TRANSFER_COMPLETE)
            broadcastIntent.setPackage(packageName)
            broadcastIntent.putExtra("success", true)
            broadcastIntent.putExtra("message", "Received $filesReceivedCount files successfully")
            broadcastIntent.putStringArrayListExtra("received_file_paths", receivedFilePaths)
            sendBroadcast(broadcastIntent)

        } catch (e: Exception) {
            Log.e("FileTransferService", "Error receiving files: ${e.message}")
            val broadcastIntent = Intent(ACTION_TRANSFER_COMPLETE)
            broadcastIntent.setPackage(packageName)
            broadcastIntent.putExtra("success", false)
            broadcastIntent.putExtra("message", "Error: ${e.message}")
            sendBroadcast(broadcastIntent)
        } finally {
            serverSocket?.close()
        }
    }

    // Helper to separate the saving logic from the loop
    private suspend fun determineSavePathAndDecrypt(
        saveDirectoryUri: Uri?,
        fileName: String,
        secret: String,
        dataInputStream: DataInputStream,
        progressCallback: (Long, String?, Long?) -> Unit,
        integrityCallback: () -> Unit
    ): String {

        // Logic to handle DocumentFile vs standard File (Same as your original logic, just extracted)
        if (saveDirectoryUri != null) {
            try {
                val directory = DocumentFile.fromTreeUri(this@FileTransferService, saveDirectoryUri)
                if (directory != null && directory.exists()) {
                    // Create temp file
                    val newFile = directory.createFile("*/*", "temp_${System.currentTimeMillis()}")
                    if (newFile != null) {
                        contentResolver.openOutputStream(newFile.uri)?.use { fileOutputStream ->
                            // DECRYPT
                            val success = CryptoHelper.decryptFileStreamWithProgress(
                                dataInputStream, fileOutputStream, secret, progressCallback, integrityCallback
                            )
                            if (!success) throw Exception("Decryption failed")
                        }

                        // Rename
                        // Note: DocumentFile rename is tricky, usually we just set the display name or copy
                        // For simplicity in this snippet, we assume the file content is safe.
                        if (newFile.renameTo(fileName)) {
                            return newFile.uri.toString()
                        }
                        return newFile.uri.toString()
                    }
                }
            } catch (e: Exception) {
                Log.w("FileTransferService", "Directory write failed, falling back to app storage")
            }
        }

        // Fallback or no directory selected
        val path = createFileForSaving(fileName, null)
        File(path).outputStream().use { fos ->
            val success = CryptoHelper.decryptFileStreamWithProgress(
                dataInputStream, fos, secret, progressCallback, integrityCallback
            )
            if (!success) throw Exception("Decryption failed")
        }
        return path
    }

    // Helper to get name from URI
    private fun getFileName(uri: Uri): String? {
        var result: String? = null
        if (uri.scheme == "content") {
            val cursor = contentResolver.query(uri, null, null, null, null)
            cursor?.use {
                if (it.moveToFirst()) {
                    val index = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (index != -1) result = it.getString(index)
                }
            }
        }
        if (result == null) {
            result = uri.path
            val cut = result?.lastIndexOf('/')
            if (cut != null && cut != -1) {
                result = result?.substring(cut + 1)
            }
        }
        return result
    }

    // Helper to get size from URI
    private fun getFileSize(uri: Uri): Long {
        return try {
            contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: -1L
        } catch (e: Exception) {
            -1L
        }
    }

    // ... (Keep existing createFileForSaving, listenForReceiverStatusUpdates, etc.) ...

    private fun createFileForSaving(fileName: String, saveDirectory: File?): String {
        return try {
            val targetDir = saveDirectory ?: filesDir
            val receivedFile = File(targetDir, fileName)
            var counter = 1
            var finalFile = receivedFile
            while (finalFile.exists()) {
                val nameWithoutExt = fileName.substringBeforeLast(".")
                val extension = if (fileName.contains(".")) ".${fileName.substringAfterLast(".")}" else ""
                finalFile = File(targetDir, "${nameWithoutExt}_$counter$extension")
                counter++
            }
            finalFile.absolutePath
        } catch (e: Exception) {
            val cacheFile = File(cacheDir, fileName)
            cacheFile.absolutePath
        }
    }
}
