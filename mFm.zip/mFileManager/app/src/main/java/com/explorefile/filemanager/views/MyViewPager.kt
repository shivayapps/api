package com.explorefile.filemanager.views

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import com.explorefile.filemanager.views.rtlviewpager.RtlViewPager


class MyViewPager : RtlViewPager {

    constructor(context: Context) : super(context)

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs)

    private var isPagingEnabled = true

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        return try {
            isPagingEnabled && super.onInterceptTouchEvent(ev)
        } catch (ignored: Exception) {
            false
        }
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        return try {
            isPagingEnabled && super.onTouchEvent(ev)
        } catch (ignored: Exception) {
            false
        }
    }

    fun setPagingEnabled(b: Boolean) {
        isPagingEnabled = b
    }
}
