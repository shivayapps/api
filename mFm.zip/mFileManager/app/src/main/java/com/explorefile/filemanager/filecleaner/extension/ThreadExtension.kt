package com.explorefile.filemanager.filecleaner.extension

import android.os.Looper

fun throwIfMainThread() {
    check(Looper.getMainLooper() != Looper.myLooper()) { "cur thread is main thread" }
}