package com.explorefile.filemanager.dialogs

import android.view.View
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.BaseActivity
import com.explorefile.filemanager.databinding.DialogCompressAsBinding
import com.explorefile.filemanager.extensions.config
import com.explorefile.filemanager.extensions.getAlertDialogBuilder
import com.explorefile.filemanager.extensions.getDoesFilePathExist
import com.explorefile.filemanager.extensions.getFilenameFromPath
import com.explorefile.filemanager.extensions.getIsPathDirectory
import com.explorefile.filemanager.extensions.getParentPath
import com.explorefile.filemanager.extensions.humanizePath
import com.explorefile.filemanager.extensions.isAValidFilename
import com.explorefile.filemanager.extensions.setupDialogStuff
import com.explorefile.filemanager.extensions.showKeyboard
import com.explorefile.filemanager.extensions.toast
import com.explorefile.filemanager.extensions.value

class CompressAsDialog(
    val activity: BaseActivity,
    val path: String,
    val callback: (destination: String, password: String?) -> Unit
) {
    private val binding = DialogCompressAsBinding.inflate(activity.layoutInflater)

    init {
        val filename = path.getFilenameFromPath()
        val indexOfDot =
            if (filename.contains('.') && !activity.getIsPathDirectory(path)) filename.lastIndexOf(".") else filename.length
        val baseFilename = filename.substring(0, indexOfDot)
        var realPath = path.getParentPath()

        binding.apply {
            filenameValue.setText(baseFilename)

            folder.setText(activity.humanizePath(realPath))
            folder.setOnClickListener {
                FilePickerDialog(
                    activity,
                    "",
                    realPath,
                    false,
                    activity.config.shouldShowHidden(),
                    true
                ) {
                    folder.setText(activity.humanizePath(it))
                    realPath = it
                }
            }

        }

        activity.getAlertDialogBuilder()
            .apply {
                activity.setupDialogStuff(binding.root, this) { alertDialog ->
                    alertDialog.showKeyboard(binding.filenameValue)
                    binding.txtOk.setOnClickListener(View.OnClickListener {
                        val name = binding.filenameValue.value
                        val password: String? = null
                        when {
                            name.isEmpty() -> activity.toast(R.string.empty_name)
                            name.isAValidFilename() -> {
                                val newPath = "$realPath/$name.zip"
                                if (activity.getDoesFilePathExist(newPath)) {
                                    activity.toast(R.string.name_taken)
                                    return@OnClickListener
                                }

                                alertDialog.dismiss()
                                callback(newPath, password)
                            }

                            else -> activity.toast(R.string.invalid_name)
                        }
                    })
                    binding.txtCancel.setOnClickListener {
                        alertDialog.dismiss()
                    }

                }
            }
    }
}
