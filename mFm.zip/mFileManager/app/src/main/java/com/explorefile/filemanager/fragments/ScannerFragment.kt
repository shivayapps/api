package com.explorefile.filemanager.fragments

import android.content.ContentResolver
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import android.util.AttributeSet
import android.util.Log
import androidx.core.os.bundleOf
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.explorefile.filemanager.activities.BaseActivity
import com.explorefile.filemanager.activities.MainActivity
import com.explorefile.filemanager.adapters.PdfScanAdapter
import com.explorefile.filemanager.adapters.RecentItemAdapter
import com.explorefile.filemanager.databinding.MainScannerFragmentBinding
import com.explorefile.filemanager.extensions.areSystemAnimationsEnabled
import com.explorefile.filemanager.extensions.beGone
import com.explorefile.filemanager.extensions.beGoneIf
import com.explorefile.filemanager.extensions.beVisibleIf
import com.explorefile.filemanager.extensions.config
import com.explorefile.filemanager.extensions.getProperPrimaryColor
import com.explorefile.filemanager.extensions.openListItem
import com.explorefile.filemanager.extensions.showErrorToast
import com.explorefile.filemanager.extensions.updateTextColors
import com.explorefile.filemanager.helpers.ensureBackgroundThread
import com.explorefile.filemanager.models.FileDirItem
import com.explorefile.filemanager.models.ListItem
import java.io.File


class ScannerFragment(context: Context, attributeSet: AttributeSet) :
    MyViewPagerFragment<MyViewPagerFragment.ScannerInnerBinding>(context, attributeSet) {


    lateinit var binding: MainScannerFragmentBinding

    override fun onFinishInflate() {
        super.onFinishInflate()
        binding = MainScannerFragmentBinding.bind(this)
        innerBinding = ScannerInnerBinding(binding)
    }

    override fun setupFragment(activity: BaseActivity) {
        if (this.activity == null) {
            this.activity = activity
        }
        refreshFragment()
    }

    override fun setupCategoriesBinding(activity: BaseActivity) {
        if (this.activity == null) {
            this.activity = activity
        }

        binding.ivScan.setOnClickListener {
            (activity as MainActivity).openScanner()
        }

        binding.pdfList.addOnScrollListener(object :
            RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                val firstPositon =
                    (binding.pdfList.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                binding.ivScan.beVisibleIf(firstPositon < 3)

//                if (firstPositon > 0) {
////                        setBubbleText(pictureAdapter?.getBubbleText(firstPositon)!!)
//                    val str = pictureAdapter?.getBubbleText(firstPositon)!!
//                    if (str.isNotEmpty()) binding.photosTab.photosBubbleText.text = str
//                    binding.photosTab.photosBubble.beVisible()
//                } else {
//                    binding.photosTab.photosBubble.beGone()
//                }
            }
        })
    }

    override fun onResume(textColor: Int) {
//        context.updateTextColors(binding.root)
//        val properPrimaryColor = context.getProperPrimaryColor()

    }

    private fun addItems(recents: java.util.ArrayList<ListItem>) {
        if (recents.isEmpty()) {
            return
        }
        PdfScanAdapter(activity as BaseActivity, recents, { action ->
            refreshFragment()
        }, { position ->
            activity!!.openListItem(recents, position)
//            activity!!.tryOpenPathIntent(path, false)
        })
            .apply {
                binding.pdfList.adapter = this
                binding.pdfList.layoutManager =
                    LinearLayoutManager(
                        activity,
                        LinearLayoutManager.VERTICAL,
                        false
                    )
            }
        if (context.areSystemAnimationsEnabled) {
            binding.pdfList.scheduleLayoutAnimation()
        }
        binding.pdfList.addOnScrollListener(object :
            RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                val firstPositon = (binding.pdfList.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                binding.ivScan.beVisibleIf(firstPositon < 3)
            }
        })
    }

    override fun refreshFragment() {
        ensureBackgroundThread {
            val dirPth =
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
                    .absolutePath + "/FileManager/Scanner"
            getPdfs(dirPth) { recents ->
                binding.apply {
                    pdfList.beVisibleIf(recents.isNotEmpty())
                    llEmpty.beVisibleIf(recents.isEmpty())
                }
                addItems(recents)
            }
        }
    }

    fun deleteFiles(files: java.util.ArrayList<FileDirItem>) {
        handleFileDeleting(files, false)
    }

    private fun getPdfs(
        folderPath: String,
        callback: (recents: ArrayList<ListItem>) -> Unit
    ) {
        val listItems = arrayListOf<ListItem>()

        try {
            val folder = File(folderPath)
            Log.e("getPdfs", "folderPath:$folderPath")

            if (folder.isDirectory) {
                Log.e("getPdfs", "folder.isDirectory:${folder.isDirectory}")
            }
            if (folder.exists()) {
                Log.e("getPdfs", "folder.exists:${folder.exists()}")
            }
            if (folder.exists() && folder.isDirectory) {
                folder.listFiles()?.forEach { file ->

                    Log.e("getPdfs", "file:${file.name}")
                    if (file.isFile && file.extension.equals("pdf", ignoreCase = true)) {

                        val item = ListItem(
                            mPath = file.absolutePath,
                            mName = file.name,
                            mIsDirectory = false,
                            mChildren = 0,
                            mSize = file.length(),
                            mModified = file.lastModified(),
                            isSectionTitle = false,
                            isGridTypeDivider = false
                        )

                        listItems.add(item)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("getPdfs", "Exception:$e")
            activity?.showErrorToast(e)
        }

        activity?.runOnUiThread {
            callback(listItems)
        }
    }

}