package com.explorefile.filemanager.fragments

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.os.Handler
import androidx.lifecycle.lifecycleScope
import android.os.storage.StorageManager
import android.provider.MediaStore
import android.provider.Settings
import android.util.AttributeSet
import android.util.Log
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.os.bundleOf
import androidx.core.view.children
import androidx.lifecycle.LifecycleOwner
import androidx.recyclerview.widget.LinearLayoutManager
import com.adconfig.AdsConfig
import com.adconfig.adsutil.Config.checkReInter
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.AppManagerActivity
import com.explorefile.filemanager.activities.BaseActivity
import com.explorefile.filemanager.activities.BreadCrumbActivity
import com.explorefile.filemanager.activities.MainActivity
import com.explorefile.filemanager.activities.FilesTypesActivity
import com.explorefile.filemanager.activities.LockActivity
import com.explorefile.filemanager.activities.LockedDirActivity
import com.explorefile.filemanager.activities.TrashedActivity
import com.explorefile.filemanager.adapters.ItemsAdapter
import com.explorefile.filemanager.adapters.RecentItemAdapter
import com.explorefile.filemanager.databinding.ItemStorageCategoriesBinding
import com.explorefile.filemanager.databinding.ItemStorageVolumeBinding
import com.explorefile.filemanager.databinding.MainHomeFragmentBinding
import com.explorefile.filemanager.extensions.*
import com.explorefile.filemanager.helpers.*
import com.explorefile.filemanager.interfaces.ItemOperationsListener
import com.explorefile.filemanager.models.FileDirItem
import com.explorefile.filemanager.models.ListItem
import com.explorefile.filemanager.views.MyGridLayoutManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.*

class MainHomeFragment(context: Context, attributeSet: AttributeSet) :
    MyViewPagerFragment<MyViewPagerFragment.HomeInnerBinding>(context, attributeSet),
    ItemOperationsListener {
    private val RECENTS_LIMIT = 50
    private val SIZE_DIVIDER = 100000
    private var allDeviceListItems = ArrayList<ListItem>()
    private var lastSearchedText = ""
    private lateinit var binding: MainHomeFragmentBinding
    private val volumes = mutableMapOf<String, ItemStorageVolumeBinding>()

    override fun onFinishInflate() {
        super.onFinishInflate()
        binding = MainHomeFragmentBinding.bind(this)
        innerBinding = HomeInnerBinding(binding)
    }

    override fun setupFragment(activity: BaseActivity) {
        if (this.activity == null) {
            this.activity = activity
        }

        val volumeNames = activity.getAllVolumeNames()
        volumeNames.forEach { volumeName ->
            val volumeBinding = ItemStorageVolumeBinding.inflate(activity.layoutInflater)
            volumes[volumeName] = volumeBinding
            volumeBinding.apply {
                if (volumeName == PRIMARY_VOLUME_NAME) {
                    storageName.setText(R.string.internal_storage)
                    root.children.filterNot { it == freeSpaceHolder }
                        .forEach { it.beVisible() }
                } else {
                    storageName.setText(R.string.sd_card)
                    root.children.filterNot { it == freeSpaceHolder }
                        .forEach { it.beGone() }
                }

                //expandButton.beGone()

                freeSpaceHolder.setOnClickListener {
                    if (volumeName == PRIMARY_VOLUME_NAME) {
                        activity.startActivity(Intent(activity, BreadCrumbActivity::class.java))
//                        (activity as MainActivity).binding.mainViewPager.currentItem = 1
//                        activity.binding.mainMenu.pageName(activity.getString(R.string.internal_storage))
//                        Handler().postDelayed({
//                            if (MainActivity.mLastPath != activity.internalStoragePath) {
//                                activity.getItemsFragment()
//                                    ?.openPath(activity.internalStoragePath, true)
//                            }
//                        }, 100)
                    } else {
                        activity.startActivity(Intent(activity, BreadCrumbActivity::class.java))
//                        (activity as MainActivity).binding.mainViewPager.currentItem = 1
//                        activity.binding.mainMenu.pageName(activity.getString(R.string.sd_card))
//                        Handler().postDelayed({
//                            if (MainActivity.mLastPath != activity.sdCardPath) {
//                                activity.getItemsFragment()
//                                    ?.openPath(activity.sdCardPath, true)
//                            }
//                        }, 100)
                    }
                }
            }
            binding.storageVolumesHolder.addView(volumeBinding.root)
        }

//                binding.recentHeader.setOnClickListener {
//                    (activity as MainActivity).binding.mainViewPager.currentItem = 2
//                    activity.binding.mainMenu.pageName(activity.getString(R.string.recent_files))
//                }
        binding.vaultHeader.setOnClickListener {
            Log.e("MMGGG", "vaultHeader clicked")
            (activity as MainActivity).openLockedDir()
        }
        binding.trashHeader.setOnClickListener {
            Log.e("MMGGG", "trashHeader clicked")
            activity.startActivity(Intent(activity, TrashedActivity::class.java))
        }
        binding.applicationHeader.setOnClickListener {
            Log.e("MMGGG", "applicationHeader clicked")
            (activity as MainActivity).openApplicationManager()
        }


//        val adId = activity.getString(R.string.native_all)
//        NativeAdHelper((activity as MainActivity), binding.frameAds, binding.frameAds, NativeLayoutType.NativeMedium, adId).loadAd()
        binding.toolbarSearch.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                //openSearch()
            } else {
                closeSearch()
            }
        }
        binding.searchClose.setOnClickListener {
            closeSearch()
        }
        binding.toolbarSearch.onTextChangeListener { text ->
            searchQueryChanged(text)
        }

        ensureBackgroundThread {
            getVolumeStorageStats(context)
        }
        refreshFragment()
    }


    fun openSearch() {
        binding.llMainHolder.beGone()
        binding.searchHolder.beVisible()
    }

    fun closeSearch() {
        binding.toolbarSearch.setText("")
        binding.toolbarSearch.clearFocus()
        (context as? Activity)?.hideKeyboard()
        binding.searchClose.beGone()
        binding.llMainHolder.beVisible()
        binding.searchHolder.beGone()
    }

//    private lateinit var categoriesBinding: ItemStorageCategoriesBinding

    //    val categoriesBinding = ItemStorageCategoriesBinding.inflate(activity.layoutInflater)
    override fun setupCategoriesBinding(activity: BaseActivity) {
        if (this.activity == null) {
            this.activity = activity
        }

        getSizes()

        val categoriesBinding = ItemStorageCategoriesBinding.inflate(activity.layoutInflater)

        categoriesBinding.apply {
            post {
//                volumes[volumeName]!!.apply {
                imagesSize.text = fileSizeImages.formatSize()
                videosSize.text = fileSizeVideos.formatSize()
                audioSize.text = fileSizeAudios.formatSize()
                documentsSize.text = fileSizeDocuments.formatSize()
                downloadSize.text = fileSizeDownloads.formatSize()
                apkSize.text = fileSizeAPKs.formatSize()
//                }
                if (activity is MainActivity) {
                    (activity as MainActivity).binding.headerTrash.text =
                        fileSizeDelete.formatSize()
                }
            }
            imagesHolder.setOnClickListener {
                AdsConfig.showInterstitialAd(activity) {
                    //launchMimetypeActivity(IMAGES, volumeName)
                    launchMimetypeActivity(IMAGES)
                }
            }
            videosHolder.setOnClickListener {
                AdsConfig.showInterstitialAd(activity) {
                    //launchMimetypeActivity(VIDEOS, volumeName)
                    launchMimetypeActivity(VIDEOS)
                }
            }
            audioHolder.setOnClickListener {
                AdsConfig.showInterstitialAd(activity) {
                    //launchMimetypeActivity(AUDIO, volumeName)
                    launchMimetypeActivity(AUDIO)
                }
            }
            documentsHolder.setOnClickListener {
                AdsConfig.showInterstitialAd(activity) {
                    //launchMimetypeActivity(DOCUMENTS, volumeName)
                    launchMimetypeActivity(DOCUMENTS)
                }
            }
            downloadHolder.setOnClickListener {
                AdsConfig.showInterstitialAd(activity) {
                    //launchMimetypeActivity(DOWNLOADS, volumeName)
                    launchMimetypeActivity(DOWNLOADS)
                }
            }
            apkHolder.setOnClickListener {
                AdsConfig.showInterstitialAd(activity) {
                    //launchMimetypeActivity(APKS, volumeName)
                    launchMimetypeActivity(APKS)
                }
            }

        }

//        binding.storageVolumesHolder.addView(categoriesBinding.root)
        binding.storageCategoriesHolder.addView(categoriesBinding.root)
    }

    override fun onResume(textColor: Int) {
        checkReInter {
            if (it) {
                AdmobIntersAdImpl().load(activity!!, activity!!.getString(R.string.inter_all))
            }
        }

        context.updateTextColors(binding.root)

        val properPrimaryColor = context.getProperPrimaryColor()

        fileSizeImages = 0L
        fileSizeVideos = 0L
        fileSizeAudios = 0L
        fileSizeDocuments = 0L
        fileSizeDownloads = 0L
        fileSizeAPKs = 0L
        fileSizeDelete = 0L
        volumes.entries.forEach { (it, volumeBinding) ->
//            getSizes(it)
            volumeBinding.apply {
//                mainStorageUsageProgressbar.setIndicatorColor(properPrimaryColor)
//                mainStorageUsageProgressbar.trackColor = context.getProperTextColor().adjustAlpha(LOWER_ALPHA)
                //expandButton.applyColorFilter(context.getProperTextColor())
            }
        }

        binding.apply {
            searchHolder.setBackgroundColor(context.getProperBackgroundColor())
            progressBar.setIndicatorColor(properPrimaryColor)
            progressBar.trackColor = properPrimaryColor.adjustAlpha(LOWER_ALPHA)
        }

        ensureBackgroundThread {
            getVolumeStorageStats(context)
        }
    }


    private fun launchMimetypeActivity(mimetype: String, volumeName: String) {
        Intent(context, FilesTypesActivity::class.java).apply {
            putExtra(SHOW_MIMETYPE, mimetype)
            putExtra(VOLUME_NAME, volumeName)
            context.startActivity(this)
        }
    }

    private fun launchMimetypeActivity(mimetype: String) {
        Intent(context, FilesTypesActivity::class.java).apply {
            putExtra(SHOW_MIMETYPE, mimetype)
//            putExtra(VOLUME_NAME, volumeName)
            context.startActivity(this)
        }
    }

    lateinit var filesSize: HashMap<String, Long>
    var fileSizeImages = 0L
    var fileSizeVideos = 0L
    var fileSizeAudios = 0L
    var fileSizeDocuments = 0L
    var fileSizeDownloads = 0L
    var fileSizeAPKs = 0L
    var fileSizeDelete = 0L

    private fun getSizes() {
        if (!isOreoPlus()) {
            return
        }

        ensureBackgroundThread {
            filesSize = getSizesByMimeType()
            fileSizeImages = filesSize[IMAGES]!!
            fileSizeVideos = filesSize[VIDEOS]!!
            fileSizeAudios = filesSize[AUDIO]!!
            fileSizeDocuments = filesSize[DOCUMENTS]!!
            fileSizeDownloads = filesSize[DOWNLOADS]!!
            fileSizeAPKs = filesSize[APKS]!!
            fileSizeDelete = filesSize[DELETE_SIZE]!!
        }

    }

    var imagesSize = 0L
    var videosSize = 0L
    var audioSize = 0L
    var documentsSize = 0L
    var downloadsSize = 0L
    var apksSize = 0L
    var trashedFileSize = 0L
    private fun getSizesByMimeType(): HashMap<String, Long> {

//        val uri = if (isQPlus()) {
//            MediaStore.Files.getContentUri(volumeName)
//        } else {
        val uri = MediaStore.Files.getContentUri("external")
//        }
        val showHidden = activity!!.config.shouldShowHidden()

        val projection = arrayOf(
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.MIME_TYPE,
            MediaStore.Files.FileColumns.DATA,
            MediaStore.Files.FileColumns.DISPLAY_NAME
        )


        try {
            context.queryCursor(uri, projection) { cursor ->
                try {
                    val mimeType = cursor.getStringValue(MediaStore.Files.FileColumns.MIME_TYPE)
                        ?.lowercase(Locale.getDefault())

                    val name = cursor.getStringValue(MediaStore.Files.FileColumns.DISPLAY_NAME)

                    if (name.startsWith(".trashed")) {
                        val size = cursor.getLongValue(MediaStore.Files.FileColumns.SIZE)
                        trashedFileSize += size
                        return@queryCursor
                    }

                    if (!showHidden && name.startsWith(".")) {
                        return@queryCursor
                    }

                    val size = cursor.getLongValue(MediaStore.Files.FileColumns.SIZE)

                    if (mimeType == null) {
                        return@queryCursor
                    }

                    when (mimeType.substringBefore("/")) {
                        "image" -> imagesSize += size
                        "video" -> videosSize += size
                        "audio" -> audioSize += size
                        "text" -> documentsSize += size
                        ".apk" -> apksSize += size
                        ".zip" -> apksSize += size
                        ".rar" -> apksSize += size
                        else -> {
                            when {
                                extraDocumentMimeTypes.contains(mimeType) -> documentsSize += size
                                extraAudioMimeTypes.contains(mimeType) -> audioSize += size
                                extraAPKMimeTypes.contains(mimeType) -> apksSize += size
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e("sujal", "queryCursor: $e")
                }
            }
        } catch (e: Exception) {
            Log.e("sujal", "Exception: $e")
        }

        try {
            context.queryCursor(
                uri, projection, MediaStore.Files.FileColumns.DATA + " like ?", arrayOf(
                    "${Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).path}%"
                )
            ) { cursor ->
                try {
                    val name = cursor.getStringValue(MediaStore.Files.FileColumns.DISPLAY_NAME)

                    if (name.startsWith(".trashed")) {
                        return@queryCursor
                    }

                    if (!showHidden && name.startsWith(".")) {
                        return@queryCursor
                    }
                    val size = cursor.getLongValue(MediaStore.Files.FileColumns.SIZE)
                    downloadsSize += size
                } catch (e: Exception) {
                }
            }
        } catch (_: Exception) {
        }

        val mimeTypeSizes = HashMap<String, Long>().apply {
            put(IMAGES, imagesSize)
            put(VIDEOS, videosSize)
            put(AUDIO, audioSize)
            put(DOCUMENTS, documentsSize)
            put(DOWNLOADS, downloadsSize)
            put(APKS, apksSize)
            put(DELETE_SIZE, trashedFileSize)
        }

        return mimeTypeSizes
    }

    @SuppressLint("NewApi")
    private fun getVolumeStorageStats(context: Context) {
        val externalDirs = context.getExternalFilesDirs(null)
        val storageManager =
            context.getSystemService(AppCompatActivity.STORAGE_SERVICE) as StorageManager

        fileSizeImages = 0L
        fileSizeVideos = 0L
        fileSizeAudios = 0L
        fileSizeDocuments = 0L
        fileSizeDownloads = 0L
        fileSizeAPKs = 0L
        fileSizeDelete = 0L
        externalDirs.forEach { file ->
            val volumeName: String
            val totalStorageSpace: Long
            val freeStorageSpace: Long
            val storageVolume = storageManager.getStorageVolume(file) ?: return
            if (storageVolume.isPrimary) {
                // internal storage
                volumeName = PRIMARY_VOLUME_NAME
                if (isOreoPlus()) {
                    val storageStatsManager =
                        context.getSystemService(AppCompatActivity.STORAGE_STATS_SERVICE) as StorageStatsManager
                    val uuid = StorageManager.UUID_DEFAULT
                    totalStorageSpace = storageStatsManager.getTotalBytes(uuid)
                    freeStorageSpace = storageStatsManager.getFreeBytes(uuid)
                } else {
                    totalStorageSpace = file.totalSpace
                    freeStorageSpace = file.freeSpace
                }
            } else {
                volumeName = storageVolume.uuid!!.lowercase(Locale.US)
                totalStorageSpace = file.totalSpace
                freeStorageSpace = file.freeSpace
                post {
                    ensureBackgroundThread {
                        scanVolume(volumeName, file)
                    }
                }
            }

            post {
                volumes[volumeName]?.apply {

                    val total = totalStorageSpace.toFloat()
                    val free = freeStorageSpace.toFloat()
                    val used = total - free

                    val percentage = if (total > 0) {
                        ((used / total) * 100).toInt()
                    } else 0

                    arrayOf(mainStorageUsageProgressbar).forEach {
                        it.max = (totalStorageSpace / SIZE_DIVIDER).toInt()
                    }

                    mainStorageUsageProgressbar.progress =
                        ((totalStorageSpace - freeStorageSpace) / SIZE_DIVIDER).toInt()

                    mainStorageUsageProgressbar.beVisible()

                    mainStorageUsagePercentage.text = "$percentage%"

                    freeSpaceValue.text =
                        "${freeStorageSpace.formatSizeThousand()} / ${totalStorageSpace.formatSizeThousand()}"

                    freeSpaceLabel.beGone()
                }
            }

//            post {
//                volumes[volumeName]?.apply {
//                    arrayOf(mainStorageUsageProgressbar).forEach {
//                        it.max = (totalStorageSpace / SIZE_DIVIDER).toInt()
//                    }
//                    mainStorageUsageProgressbar.progress = ((totalStorageSpace - freeStorageSpace) / SIZE_DIVIDER).toInt()
//                    mainStorageUsageProgressbar.beVisible()
//                    mainStorageUsagePercentage.setText("")
//
//                    freeSpaceValue.text = "${freeStorageSpace.formatSizeThousand()} / ${totalStorageSpace.formatSizeThousand()}"
//                    freeSpaceLabel.beGone()
//                }
//            }
        }
    }

    private fun scanVolume(volumeName: String, root: File) {
        val paths = mutableListOf<String>()
        if (context.isPathOnSD(root.path)) {
            File(context.sdCardPath).walkBottomUp().forEach {
                paths.add(it.path)
            }
        }
        var callbackCount = 0
        MediaScannerConnection.scanFile(context, paths.toTypedArray(), null) { _, _ ->
            callbackCount++
//            if (callbackCount == paths.size) {
//                getSizes(volumeName)
//            }
        }
    }

    private var searchJob: Job? = null
    fun searchQueryChanged(text: String) {
        lastSearchedText = text
        searchJob?.cancel()
        binding.apply {
            if (text.isNotEmpty()) {
                binding.searchClose.beVisible()
                if (searchHolder.alpha < 1f) {
                    searchHolder.fadeIn()
                }
            } else {
                searchHolder.animate().alpha(0f).setDuration(SHORT_ANIMATION_DURATION)
                    .withEndAction {
                        searchHolder.beGone()
                        (searchResultsList.adapter as? ItemsAdapter)?.updateItems(
                            allDeviceListItems,
                            text
                        )
                    }.start()
            }

            if (text.length < 1) {
                searchResultsList.beGone()
                searchPlaceholder.beVisible()
                imageNoData.beVisible()
                searchPlaceholder2.beVisible()
                hideProgressBar()
            } else if (text.isEmpty()) {
                searchResultsList.beGone()
                hideProgressBar()
            } else {
                showProgressBar()

                val scope = (context as? LifecycleOwner)?.lifecycleScope ?: return

                searchJob = scope.launch(Dispatchers.Default) {

//                    val filtered = allDeviceListItems.filter {
//                        it.mName.contains(
//                            text,
//                            ignoreCase = true
//                        )
//                    } as ArrayList<ListItem>
                    val filtered = withContext(Dispatchers.Default) {
                        allDeviceListItems.filter {
                            it.mName.contains(text, ignoreCase = true)
                        }
                    }


                    withContext(Dispatchers.Main) {

                        // Ignore stale search results
                        if (text != lastSearchedText) return@withContext

                        hideProgressBar()

                        if (filtered.isEmpty()) {
                            searchPlaceholder.beVisible()
                            imageNoData.beVisible()
                        } else {
                            (binding.searchResultsList.adapter as? ItemsAdapter)
                                ?.updateItems(ArrayList(filtered), text)
//                            (searchResultsList.adapter as? ItemsAdapter)?.updateItems(
//                                filtered,
//                                text
//                            )
                            searchResultsList.beVisible()
                            imageNoData.beGone()
                        }
                    }
                }
            }
        }
    }

    fun searchQueryChangedNew(text: String) {
        lastSearchedText = text
        searchJob?.cancel()

//        binding.apply {
        if (text.length < 2) {
            hideProgressBar()
            binding.searchResultsList.beGone()
            return
        }

        val scope = (context as? LifecycleOwner)?.lifecycleScope ?: return
        searchJob = scope.launch {
            delay(300) // 👈 debounce (very important)

            showProgressBar()

            val filtered = withContext(Dispatchers.Default) {
                allDeviceListItems.filter {
                    it.mName.contains(text, ignoreCase = true)
                }
            }

            // Ignore stale results
            if (text != lastSearchedText) return@launch

            hideProgressBar()

            if (filtered.isEmpty()) {
                binding.searchPlaceholder.beVisible()
                binding.imageNoData.beVisible()
            } else {
                (binding.searchResultsList.adapter as? ItemsAdapter)
                    ?.updateItems(ArrayList(filtered), text)
                binding.searchResultsList.beVisible()
                binding.imageNoData.beGone()
            }
        }
//        }
    }


    private fun setupLayoutManager() {
        if (context!!.config.getFolderViewType("") == VIEW_TYPE_GRID) {
            currentViewType = VIEW_TYPE_GRID
            setupGridLayoutManager()
        } else {
            currentViewType = VIEW_TYPE_LIST
            setupListLayoutManager()
        }

        binding.searchResultsList.adapter = null
        addItems()
    }

    private fun setupGridLayoutManager() {
        val layoutManager = binding.searchResultsList.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = context?.config?.fileColumnCnt ?: 3
    }

    private fun setupListLayoutManager() {
        val layoutManager = binding.searchResultsList.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = 1
    }

    private fun addItems(recents: ArrayList<ListItem>) {
        if (recents.isEmpty()) {
            return
        }
        RecentItemAdapter(activity as BaseActivity, recents) { position ->
            activity!!.openListItem(recents, position)
//            activity!!.tryOpenPathIntent(path, false)
        }.apply {
            binding.recentList.adapter = this
            binding.recentList.layoutManager =
                LinearLayoutManager(
                    activity,
                    LinearLayoutManager.HORIZONTAL,
                    false
                )
        }
        if (context.areSystemAnimationsEnabled) {
            binding.recentList.scheduleLayoutAnimation()
        }
    }

    private fun addItems() {
        ItemsAdapter(
            context as BaseActivity,
            ArrayList(),
            this,
            binding.searchResultsList,
            false,
            null,
            false
        ) {
            clickedPath((it as FileDirItem).path)
        }.apply {
            binding.searchResultsList.adapter = this
        }
    }

    private fun getAllFiles(volumeName: String): ArrayList<FileDirItem> {
        val fileDirItems = ArrayList<FileDirItem>()
        val showHidden = context?.config?.shouldShowHidden() ?: return fileDirItems
        val uri = if (isQPlus()) {
            MediaStore.Files.getContentUri(volumeName)
        } else {
            MediaStore.Files.getContentUri("external")
        }
        val projection = arrayOf(
            MediaStore.Files.FileColumns.DATA,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.DATE_MODIFIED
        )

        try {
            if (isOreoPlus()) {
                val queryArgs = bundleOf(
                    ContentResolver.QUERY_ARG_SORT_COLUMNS to arrayOf(MediaStore.Files.FileColumns.DATE_MODIFIED),
                    ContentResolver.QUERY_ARG_SORT_DIRECTION to ContentResolver.QUERY_SORT_DIRECTION_DESCENDING
                )
                context?.contentResolver?.query(uri, projection, queryArgs, null)
            } else {
                val sortOrder = "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
                context?.contentResolver?.query(uri, projection, null, null, sortOrder)
            }?.use { cursor ->
                if (cursor.moveToFirst()) {
                    do {
                        try {
                            val name =
                                cursor.getStringValue(MediaStore.Files.FileColumns.DISPLAY_NAME)
                            if (!showHidden && name.startsWith(".")) {
                                continue
                            }

                            val size = cursor.getLongValue(MediaStore.Files.FileColumns.SIZE)
                            if (size == 0L) {
                                continue
                            }

                            val path = cursor.getStringValue(MediaStore.Files.FileColumns.DATA)
                            val lastModified =
                                cursor.getLongValue(MediaStore.Files.FileColumns.DATE_MODIFIED) * 1000
                            fileDirItems.add(FileDirItem(path, name, false, 0, size, lastModified))
                        } catch (_: Exception) {
                        }
                    } while (cursor.moveToNext())
                }
            }
        } catch (e: Exception) {
            context?.showErrorToast(e)
        }

        return fileDirItems
    }

    private fun showProgressBar() {
        binding.progressBar.show()
    }

    private fun hideProgressBar() {
        binding.progressBar.hide()
    }

    private fun getRecyclerAdapter() = binding.searchResultsList.adapter as? ItemsAdapter

    override fun refreshFragment() {
        ensureBackgroundThread {
            val fileDirItems = volumes.keys.map { getAllFiles(it) }.flatten()
            allDeviceListItems = getListItemsFromFileDirItems(ArrayList(fileDirItems))

//            val recentDrawable = resources.getColoredDrawableWithColor(R.drawable.ic_recent, activity!!.getProperTextColor())
            getRecents { recents ->
                binding.apply {
                    recentList.beVisibleIf(recents.isNotEmpty())
                    recentHeader.beVisibleIf(recents.isNotEmpty())
                }
                addItems(recents)
            }
        }
        setupLayoutManager()
    }


    private fun getRecents(callback: (recents: ArrayList<ListItem>) -> Unit) {
        val showHidden = context?.config?.shouldShowHidden() ?: return
        val listItems = arrayListOf<ListItem>()

        val uri = MediaStore.Files.getContentUri("external")
        val projection = arrayOf(
            MediaStore.Files.FileColumns.DATA,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.DATE_MODIFIED,
            MediaStore.Files.FileColumns.SIZE
        )

        try {
            if (isOreoPlus()) {
                val queryArgs = bundleOf(
                    ContentResolver.QUERY_ARG_LIMIT to RECENTS_LIMIT,
                    ContentResolver.QUERY_ARG_SORT_COLUMNS to arrayOf(MediaStore.Files.FileColumns.DATE_MODIFIED),
                    ContentResolver.QUERY_ARG_SORT_DIRECTION to ContentResolver.QUERY_SORT_DIRECTION_DESCENDING
                )
                context?.contentResolver?.query(uri, projection, queryArgs, null)
            } else {
                val sortOrder =
                    "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC LIMIT $RECENTS_LIMIT"
                context?.contentResolver?.query(uri, projection, null, null, sortOrder)
            }?.use { cursor ->
                if (cursor.moveToFirst()) {
                    do {
                        val path = cursor.getStringValue(MediaStore.Files.FileColumns.DATA)
                        if (File(path).isDirectory) {
                            continue
                        }

                        val name = cursor.getStringValue(MediaStore.Files.FileColumns.DISPLAY_NAME)
                            ?: path.getFilenameFromPath()
                        val size = cursor.getLongValue(MediaStore.Files.FileColumns.SIZE)
                        val modified =
                            cursor.getLongValue(MediaStore.Files.FileColumns.DATE_MODIFIED) * 1000
                        val fileDirItem =
                            ListItem(path, name, false, 0, size, modified, false, false)
                        if ((showHidden || !name.startsWith(".")) && activity?.getDoesFilePathExist(
                                path
                            ) == true
                        ) {
                            if (wantedMimeTypes.any { isProperMimeType(it, path, false) }) {
                                listItems.add(fileDirItem)
                            }
                        }
                    } while (cursor.moveToNext())
                }
            }
        } catch (e: Exception) {
            activity?.showErrorToast(e)
        }

        activity?.runOnUiThread {
            callback(listItems)
        }
    }

    override fun deleteFiles(files: ArrayList<FileDirItem>) {
        handleFileDeleting(files, false)
    }

    override fun selectedPaths(paths: ArrayList<String>) {}

    override fun setupDateTimeFormat() {
        getRecyclerAdapter()?.updateDateTimeFormat()
    }

    override fun toggleFilenameVisibility() {
        getRecyclerAdapter()?.updateDisplayFilenamesInGrid()
    }

    override fun columnCountChanged() {
        (binding.searchResultsList.layoutManager as MyGridLayoutManager).spanCount =
            context!!.config.fileColumnCnt
        getRecyclerAdapter()?.apply {
            notifyItemRangeChanged(0, listItems.size)
        }
    }

    override fun finishActMode() {
        getRecyclerAdapter()?.finishActMode()
    }
}
