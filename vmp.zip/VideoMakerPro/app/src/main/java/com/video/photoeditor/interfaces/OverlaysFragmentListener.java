package com.video.photoeditor.interfaces;

public interface OverlaysFragmentListener {
    void onChristmas();

    void onEmoticons();

    void onFitness();

    void onFood();

    void onGeometry();

    void onHalloween();

    void onLove();

    void onMotivation();

    void onNative();

    void onPhrases();

    void onSayings();

    void onSummer();

    void onTravel();

    void onWinter();
}
