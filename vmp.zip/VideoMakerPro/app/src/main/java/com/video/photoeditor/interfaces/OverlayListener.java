package com.video.photoeditor.interfaces;

import android.graphics.Bitmap;

public interface OverlayListener {
    void onOverplayClick(Bitmap bitmap);
}
