package com.photo.effect.motion.editor

import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.multidex.MultiDex
import androidx.multidex.MultiDexApplication
import androidx.recyclerview.widget.DefaultItemAnimator
import com.adconfig.AdsConfig
import com.adconfig.adsutil.openad.AppOpenApplication
import com.adconfig.adsutil.openad.OpenAdHelper
import com.adconfig.adsutil.openad.WelcomeBackActivity
import com.google.android.gms.ads.MobileAds
import com.photo.effect.motion.editor.activities.SplashActivity
import io.github.album.EasyAlbum
import io.github.loader.album.DoodleImageLoader
import io.github.loader.application.GlobalConfig.setAppContext
import io.github.loader.application.Logger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asExecutor

class MyApplication : AppOpenApplication(),AppOpenApplication.AppLifecycleListener {

     override fun attachBaseContext(base: Context?) {
        super.attachBaseContext(base)
        MultiDex.install(this)
        initApplication(this)
    }

    private fun initApplication(context: Application) {
        setAppContext(context)
        EasyAlbum.config()
            .setLogger(Logger)
            .setExecutor(Dispatchers.IO.asExecutor())
            //.setImageLoader(GlideImageLoader)
            .setImageLoader(DoodleImageLoader)
            .setDefaultFolderComparator { o1, o2 -> o1.name.compareTo(o2.name)}
            .setItemAnimator(DefaultItemAnimator())


        val inter_ad=getString(R.string.ads_inter)
        val open_ad=getString(R.string.ads_open)

        AdsConfig.builder()
            .isEnableAds(true)
            .isEnableOpenAds(true)
            .setTestDeviceId("9B032261719C0E27EC3951981DEC9E59")
            .setAdmobAppOpenId(open_ad)
            .build(this)

//        MobileAds.initialize(this)
    }

    override fun onCreate() {
        super.onCreate()
    }

    override fun onResumeApp(fCurrentActivity: Activity): Boolean {
        if(fCurrentActivity is SplashActivity) return false
        else if (AdsConfig.isSystemDialogOpen) {
            AdsConfig.isSystemDialogOpen = false
            return false
        }
        return true
    }


    override fun onAppOpenCreatedEvent(fCurrentActivity: Activity) {
        if (onResumeApp(fCurrentActivity))
            if (!fCurrentActivity.isDestroyed && !fCurrentActivity.isFinishing) {
                if (OpenAdHelper.isAdAvailable()) {
                    val intent = Intent(fCurrentActivity, WelcomeBackActivity::class.java)
                    intent.putExtra("isAdLoading", OpenAdHelper.isAdLoading)
                    fCurrentActivity.startActivity(intent)
                }
            }
    }


    override fun onAppOpenShownEvent(fCurrentActivity: Activity) {
    }

    override fun onAppOpenFailedEvent(fCurrentActivity: Activity) {
    }
}
