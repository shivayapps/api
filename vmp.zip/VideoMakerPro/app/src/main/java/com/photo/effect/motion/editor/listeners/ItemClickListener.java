package com.photo.effect.motion.editor.listeners;

import android.view.View;

public interface ItemClickListener {
    void onItemClick(View view, int i);

    void onItemDeleteClick(View view, int i);
}
