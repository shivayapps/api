package com.photo.effect.motion.editor.activities;

import android.content.Context;

import androidx.appcompat.app.AppCompatActivity;

public class BaseActivity extends AppCompatActivity {

    public void attachBaseContext(Context context) {
        super.attachBaseContext(context);
    }
}
