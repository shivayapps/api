package com.photogallery.helper

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.photogallery.R

class SettingPermissionActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setting_permission)
//        findViewById<View>(R.id.iv_right).setOnClickListener { finish() }
//        findViewById<View>(R.id.lout_top).setOnClickListener { finish() }
    }
}