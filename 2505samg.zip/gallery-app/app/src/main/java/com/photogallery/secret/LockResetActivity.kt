package com.photogallery.secret

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.addTextChangedListener
import com.andrognito.patternlockview.PatternLockView
import com.andrognito.patternlockview.listener.PatternLockViewListener
import com.andrognito.patternlockview.utils.PatternLockUtils
import com.photogallery.R
import com.photogallery.base.BaseActivity
import com.photogallery.databinding.ActivityLockBinding
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.secret.activity.PrivateActivity
import com.photogallery.utils.Constant.EXTRA_RESET_PASS
import com.photogallery.utils.Preferences

class LockResetActivity : BaseActivity() {

    companion object {
        private const val TAG = "LockResetActivity"
    }

    lateinit var preferences: Preferences
    private lateinit var binding: ActivityLockBinding
    private lateinit var animation: Animation

    private var isShowPinLock = false
    private var isForgotPassOpen = false
    private var isChangePass = false

    private var temp = 0
    private var passcode = ""

    private val lockListener: (Boolean) -> Unit = { isUnlock ->
        if (isUnlock) setSuccess() else finish()
    }

    // =====================================================
    // Lifecycle
    // =====================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityLockBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        preferences= Preferences(this)
        //setTheme(getThemeId())
        init()
    }

    // =====================================================
    // Initialization
    // =====================================================

    private fun init() {
        isShowPinLock = preferences.isPinLock
        animation = AnimationUtils.loadAnimation(this, R.anim.anim_shake)

        initView()
        initListeners()

    }

    private fun setupInsets() {
    }

    private fun initView() {
        temp = 0
        passcode = ""

        binding.pass.setText("")
        binding.patterLockView.clearPattern()

        updateLockToggleUI()
        updateTitle()


    }

    // =====================================================
    // UI Updates
    // =====================================================

    private fun updateTitle() {
        with(binding) {
            if (isShowPinLock) {
                if (preferences.isPasscode) {
                    title.text = getString(R.string.enter_your_pin)
                    forgot.visibility = View.VISIBLE
//                    llSwitch.visibility = View.GONE
//                    llLockView.visibility = View.VISIBLE
                } else {
                    title.text = getString(R.string.set_your_pin)
                    forgot.visibility = View.GONE
//                    llSwitch.visibility = View.VISIBLE
//                    llLockView.visibility = View.GONE
                }
            } else {
                if (preferences.isPatternSet) {
                    title.text = getString(R.string.draw_your_pattern)
                    forgot.visibility = View.VISIBLE
//                    llSwitch.visibility = View.GONE
//                    llLockView.visibility = View.VISIBLE
                } else {
                    title.text = getString(R.string.draw_an_unlock_pattern)
                    forgot.visibility = View.GONE
//                    llSwitch.visibility = View.VISIBLE
//                    llLockView.visibility = View.GONE
                }
            }
        }
    }

    private fun updateLockToggleUI() {
        with(binding) {
            if (isShowPinLock) {
//                ivPasscode.setImageResource(R.drawable.ic_select_passcode)
//                ivPattern.setImageResource(R.drawable.ic_pattern)
//
//                tvPasscode.setTextColor(getColor(R.color.color_primary))
//                tvPattern.setTextColor(getColor(R.color.white_color))

                patterLockView.visibility = View.GONE
                loutPinNumber.visibility = View.VISIBLE
                loutPinDots.visibility = View.VISIBLE
            } else {
//                ivPasscode.setImageResource(R.drawable.ic_passcode)
//                ivPattern.setImageResource(R.drawable.ic_select_pattern)
//
//                tvPasscode.setTextColor(getColor(R.color.white_color))
//                tvPattern.setTextColor(getColor(R.color.color_primary))

                patterLockView.visibility = View.VISIBLE
                loutPinNumber.visibility = View.INVISIBLE
                loutPinDots.visibility = View.GONE
            }
        }
    }

    // =====================================================
    // Listeners
    // =====================================================

    private fun initListeners() = with(binding) {

        llPasscode.setOnClickListener {
            binding.llSwitch.beGone()
            binding.llLockView.beVisible()
            isShowPinLock = true
            initView()
        }

        llPattern.setOnClickListener {
            binding.llSwitch.beGone()
            binding.llLockView.beVisible()
            isShowPinLock = false
            initView()
        }

        forgot.setOnClickListener {
            isForgotPassOpen = true
            setQuestion(1)
        }

        setupPinButtons()
        setupPinTextWatcher()
        setupPatternListener()
    }

    private fun setupPinButtons() {
        val buttons = listOf(
            binding.btnZero to "0",
            binding.btnNo1 to "1",
            binding.btnNo2 to "2",
            binding.btnNo3 to "3",
            binding.btnNo4 to "4",
            binding.btnNo5 to "5",
            binding.btnNo6 to "6",
            binding.btnNo7 to "7",
            binding.btnNo8 to "8",
            binding.btnNo9 to "9"
        )

        buttons.forEach { (button, value) ->
            button.setOnClickListener {
                binding.pass.append(value)
            }
        }

        binding.btnNoClear.setOnClickListener {
            val text = binding.pass.text
            if (text.isNotEmpty()) {
                text.delete(text.length - 1, text.length)
            }
        }
    }

    private fun setupPinTextWatcher() {
        binding.pass.addTextChangedListener {
            updatePinDots(it?.length ?: 0)
            if (it?.length == 4) setNextScreen()
        }
    }

    private fun setupPatternListener() {
        binding.patterLockView.addPatternLockListener(
            object : PatternLockViewListener {

                override fun onStarted() {
                    binding.tvErrorMsg.visibility = View.INVISIBLE
                }

                override fun onProgress(progressPattern: List<PatternLockView.Dot>) {}

                override fun onComplete(pattern: List<PatternLockView.Dot>) {
                    val strPattern = PatternLockUtils.patternToString(
                        binding.patterLockView,
                        pattern
                    )

                    if (strPattern.length < 4) {
                        showPatternError(getString(R.string.patter_validation))
                    } else {
                        setNextPatternScreen(strPattern)
                    }
                }

                override fun onCleared() {}
            }
        )
    }

    // =====================================================
    // PIN Logic
    // =====================================================

    private fun setNextScreen() {
        val enteredPin = binding.pass.text.toString().trim()

        if (!preferences.isPasscode || (isChangePass && temp != -1)) {
            if (temp == 0) {
                passcode = enteredPin
                temp = 1
                updateTitleConfirmPin()
            } else {
                if (passcode == enteredPin) {
                    preferences.pincode = passcode
                    preferences.isPasscode = true
                    preferences.isSetLock = true
                    setPasswordSuccess()
                } else {
                    showPinError(R.string.pin_not_match)
                }
            }
        } else {
            if (preferences.pincode == enteredPin) {
                setPasswordSuccess()
            } else {
                showPinError(R.string.wrong_pin)
            }
        }
    }

    private fun updateTitleConfirmPin() {
        Handler(Looper.getMainLooper()).postDelayed({
            binding.title.text = getString(R.string.confirm_your_pin)
            binding.pass.setText("")
        }, 30)
    }

    private fun showPinError(message: Int) {
        binding.pass.setText("")
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        setErrorAnimation(binding.loutPinDots)
    }

    // =====================================================
    // Pattern Logic
    // =====================================================

    private fun setNextPatternScreen(pattern: String) {
        if (!preferences.isPatternSet || (isChangePass && temp != -1)) {
            if (temp == 0) {
                passcode = pattern
                temp = 1
                binding.patterLockView.clearPattern()
                binding.title.text = getString(R.string.draw_pattern_again)
            } else {
                if (passcode == pattern) {
                    preferences.pattern = passcode
                    setPasswordSuccess()
                } else {
                    showPatternError(getString(R.string.pattern_not_match))
                }
            }
        } else {
            if (preferences.pattern == pattern) {
                setPasswordSuccess()
            } else {
                showPatternError(getString(R.string.pattern_not_match))
            }
        }
    }

    private fun showPatternError(message: String) {
        binding.patterLockView.setViewMode(PatternLockView.PatternViewMode.WRONG)
        binding.tvErrorMsg.apply {
            visibility = View.VISIBLE
            text = message
            startAnimation(animation)
        }
    }

    // =====================================================
    // Success / Question Flow
    // =====================================================

    private fun setPasswordSuccess() {
        preferences.isSetLock = true
        preferences.isPinLock = isShowPinLock
        preferences.isPatternSet = !isShowPinLock

        if (preferences.getSetQuestion()) {
            lockListener(true)
        } else {
            setQuestion(0)
        }
    }

    private fun setQuestion(type: Int) {
        if (type == 1) {

            val intent = Intent(this@LockResetActivity, LockQuestionActivity::class.java)
            intent.putExtra("type", 1)
            questionResetLauncher.launch(intent)
//            val securityQuestionDialog =
//                SecurityQuestionDialog(
//                    this@LockResetActivity,
//                    preferences,
//                    type = 1,
//                    updateListener = {
//                        if (it) {
//                            preferences.isPatternSet = false
//                            preferences.isPasscode = false
//                            preferences.isPinLock = true
//                            resetLockResultLauncher.launch(
//                                Intent(
//                                    this@LockResetActivity,
//                                    LockResetActivity::class.java
//                                ).putExtra(EXTRA_RESET_PASS, true)
//                            )
//                        }
//                    })
//            securityQuestionDialog.show()
        } else {
            val intent = Intent(this@LockResetActivity, LockQuestionActivity::class.java)
            intent.putExtra("type", 0)
            questionSetLauncher.launch(intent)
//            val securityQuestionDialog =
//                SecurityQuestionDialog(
//                    this@LockResetActivity,
//                    preferences,
//                    type = 0,
//                    updateListener = {
//                        if (it) {
//                            if (!isChangePass) {
//                                Toast.makeText(
//                                    this@LockResetActivity,
//                                    if (isShowPinLock) getString(R.string.pin_set_successfully) else getString(
//                                        R.string.pattern_set_successfully
//                                    ),
//                                    Toast.LENGTH_SHORT
//                                ).show()
//                            }
//                            lockListener?.invoke(true)
//                        } else {
//                            preferences.isPatternSet=false
//                            preferences.isPasscode=false
//                            preferences.isPinLock=true
//                            lockListener?.invoke(false)
//                        }
//                    })
//            securityQuestionDialog.setCancelable(false)
//            securityQuestionDialog.show()
        }
    }

    var questionResetLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
            preferences.isPatternSet = false
            preferences.isPasscode = false
            preferences.isPinLock = true
            resetLockResultLauncher.launch(
                Intent(
                    this@LockResetActivity,
                    LockResetActivity::class.java
                ).putExtra(EXTRA_RESET_PASS, true)
            )
        }
    }
    var questionSetLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
            if (!isChangePass) {
                Toast.makeText(
                    this@LockResetActivity,
                    if (isShowPinLock) getString(R.string.pin_set_successfully) else getString(
                        R.string.pattern_set_successfully
                    ),
                    Toast.LENGTH_SHORT
                ).show()
            }
            lockListener?.invoke(true)
        } else {
            preferences.isPatternSet=false
            preferences.isPasscode=false
            preferences.isPinLock=true
            lockListener?.invoke(false)
        }
    }
    var resetLockResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
            val intent = Intent(this@LockResetActivity, PrivateActivity::class.java)
            startActivity(intent)
            lockListener?.invoke(false)
        } else {
        }
    }

    // =====================================================
    // Helpers
    // =====================================================

    private fun updatePinDots(length: Int) {
        val dots = listOf(
            binding.dot1,
            binding.dot2,
            binding.dot3,
            binding.dot4
        )

        dots.forEachIndexed { index, image ->
            image.setImageResource(
                if (index < length)
                    R.drawable.ic_pass_dot_fill
                else
                    R.drawable.ic_pass_dot_unfill
            )
        }
    }

    private fun setErrorAnimation(view: View) {
        view.startAnimation(animation)
    }

    private fun setSuccess() {
        setResult(RESULT_OK)
        finish()
    }
}

