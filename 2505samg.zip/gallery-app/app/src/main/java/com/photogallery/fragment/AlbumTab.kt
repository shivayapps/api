package com.photogallery.fragment

import android.app.Activity.RESULT_OK
import android.content.Intent
import android.util.Log
import android.view.View
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.photogallery.R
import com.photogallery.activities.AlbumExplorerActivity
import com.photogallery.activities.FavoritesListActivity
import com.photogallery.activities.HomeActivity
import com.photogallery.activities.MomentCategoriesActivity
import com.photogallery.activities.RecentlyDeleteActivity
import com.photogallery.activities.StorageScanActivity
import com.photogallery.activities.VideoGalleryActivity
import com.photogallery.adapter.AlbumListAdapter
import com.photogallery.customview.MyGridLayoutManager
import com.photogallery.customview.MyRecyclerView
import com.photogallery.databinding.MainTabAlbumBinding
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.jobs.LoaderUtilMedia
import com.photogallery.jobs.LoaderXMedia
import com.photogallery.jobs.fetchRecentMedia
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.secret.LockSetActivity
import com.photogallery.secret.activity.SelectImageActivity
import com.photogallery.utils.Constant
import com.photogallery.utils.FastScroller
import com.photogallery.utils.Utils
import kotlin.math.max
import kotlin.math.min

class AlbumTab(private val activity: HomeActivity, private val albumTab: MainTabAlbumBinding) {


    private var lastLongPressedAlbum = -1
    var selectedAlbumCount = 0

    var isEmptyAlbum = false
    var albumLoader: LoaderXMedia? = null

    var utilLoader: LoaderUtilMedia? = null

    var albumAdapter: AlbumListAdapter? = null
    private var mAlbumDragListener: MyRecyclerView.MyDragListener? = null

    fun onCreate() {
        albumLoader = LoaderXMedia(
            activity,
            sortOrder = Constant.ORDER_ASCENDING,//activity.preferences.getSortOrder("frag_0"),
            sortType = Constant.SORT_DATE,//activity.preferences.getSortType("frag_0"),
            addCustomAlbum = true,
            prefKey = "frag_0",
            limitAlbum = true
        )
        utilLoader = LoaderUtilMedia(
            activity,
            sortOrder = activity.preferences.getSortOrder("frag_0"),
            sortType = activity.preferences.getSortType("frag_0"),
            prefKey = "frag_3"
        )
    }

    fun setSelectionEnable() {
        for (i in activity.albumList.indices) {
            val model = activity.albumList[i] as AlbumData
            model.isCheckboxVisible = true
        }
        notifyAdapter()
        setSelectedAlbum()

    }


    private fun getUtilData() {
        utilLoader?.destroyLoader()
        utilLoader?.getAllAlbum({ portraitAlbum,
                                  hdAlbum,
                                  burstAlbum,
                                  animatedAlbum ->
            Log.d("LoaderUtil", "onSuccess.portraitAlbum:${portraitAlbum.mediaData.size}")
            Log.d("LoaderUtil", "onSuccess.hdAlbum:${hdAlbum.mediaData.size}")
            Log.d("LoaderUtil", "onSuccess.burstAlbum:${burstAlbum.mediaData.size}")
            Log.d("LoaderUtil", "onSuccess.animatedAlbum:${animatedAlbum.mediaData.size}")
            albumAdapter?.portraitList = portraitAlbum
            albumAdapter?.hdList = hdAlbum
            albumAdapter?.burstList = burstAlbum
            albumAdapter?.animatedList = animatedAlbum
            albumAdapter?.notifyDataSetChanged()
        })
    }
    private fun setAlbumData() {
        activity.runOnUiThread {
            //binding.albumTab.swipeRefreshAlbum.isRefreshing = false
            albumTab.refreshAlbum.beGone()

        }

        albumTab.albumRecycler.suppressLayout(false)
        if (albumAdapter != null) {
            albumTab.albumRecycler.post {
                if (albumAdapter != null) {
                    albumAdapter?.submitList(activity.albumList)
                    albumAdapter?.notifyItemRangeChanged(0, activity.albumList.size)
                }
            }
        } else initAlbumAdapter()
        setEmptyAlbum()
    }

    fun setEmptyAlbum() {
        if (activity.albumList != null && activity.albumList.size != 0) {
            isEmptyAlbum = false
            albumTab.albumRecycler.visibility = View.VISIBLE
            albumTab.loutNoAlbum.visibility = View.GONE
//            binding.llLimitedAccess.beGone()
//            if (hasLimitedPhotoAccess(this)) {
//                binding.llLimitedAccess.beVisible()
//            }

        } else {
            isEmptyAlbum = true
            albumTab.albumRecycler.visibility = View.GONE
            albumTab.loutNoAlbum.visibility = View.VISIBLE
//            binding.llLimitedAccess.beGone()
//            if (hasLimitedPhotoAccess(this)) {
//                binding.llLimitedAccess.beVisible()
//            }
        }
    }

    fun initAlbumAdapter() {

        albumAdapter = AlbumListAdapter(
            activity,
            clickListener = {
                val albumData = activity.albumList[it]
                if (albumData.isCheckboxVisible) {
                    if (!albumData.isCustomAlbum) {
                        albumData.isSelected = !albumData.isSelected
                        albumAdapter?.notifyItemChanged(it)
                        setSelectedAlbum()
                    }
                } else {
                    if (albumData.isCustomAlbum) {
                        if (albumData.mediaData.size != 0) {
                            if (albumData.title == activity.getString(R.string.all_videos)) {
                                val intent =
                                    Intent(activity, VideoGalleryActivity::class.java)
                                intent.putExtra("title", "${albumData.title}")
                                activity.startActivity(intent)
                            } else if (albumData.title == activity.getString(R.string.Favorite)) {
                                val intent =
                                    Intent(activity, FavoritesListActivity::class.java)
                                intent.putExtra("title", "${albumData.title}")
                                activity.startActivity(intent)
                            } else {
                                activity.openImageList(albumData)
                            }
                        } else if (albumData.isMoreAlbum) {
                            Constant.albumList = albumData.childAlbums
                            val intent = Intent(activity, AlbumExplorerActivity::class.java)
                            intent.putExtra("title", activity.getString(R.string.app_name))
                            activity.startActivity(intent)
                        } else {
                            //startActivity(Intent(this@HomeActivity, MediaActivity::class.java))
                        }
                    } else {
                        activity.openImageList(albumData)
                    }
                }
            },
            longClickListener = {
                if (!activity.albumList[it].isCustomAlbum) {
                    lastLongPressedAlbum = it
                    albumTab.albumRecycler.setDragSelectActive(it)
                    lastLongPressedAlbum = if (lastLongPressedAlbum == -1) {
                        it
                    } else {
                        val min = min(lastLongPressedAlbum, it)
                        val max = max(lastLongPressedAlbum, it)
                        for (i in min..max) {
                            activity.toggleMediaSelection(true, i, false)
                        }
                        it
                    }

                    val pictureData = activity.albumList[it] as AlbumData
                    for (i in activity.albumList.indices) {
                        val model = activity.albumList[i] as AlbumData
                        model.isCheckboxVisible = true
                    }
                    pictureData.isCheckboxVisible = true
                    pictureData.isSelected = true
                    notifyAdapter()
                    setSelectedAlbum()
                }
            },
            utilClickListener = { utilPos ->
                when (utilPos) {
                    10 -> {//portraitList
//                        activity.openImageList(albumAdapter?.portraitList!!)
                        val intent = Intent(activity, MomentCategoriesActivity::class.java)
                        activity.startActivity(intent)
                    }
                    11 -> {//portraitList
                        activity.openImageList(albumAdapter?.portraitList!!)
                    }
                    12 -> {//hdList
                        activity.openImageList(albumAdapter?.hdList!!)
                    }
                    13 -> {//burstList
                        activity.openImageList(albumAdapter?.burstList!!)
                    }
                    14 -> {//animatedList
                        activity.openImageList(albumAdapter?.animatedList!!)
                    }

                    0 -> {//llRecent

                        val recentList = fetchRecentMedia(activity)
                        val recentAlbum = AlbumData(
                            activity.getString(R.string.recent),
                            //mediaData = recentList,
                            isCustomAlbum = true
                        )
                        recentAlbum.mediaData.addAll(recentList)
                        activity.openImageList(recentAlbum)
                    }

                    1 -> {
                        //llAllVideo
//                        val recentAlbum=AlbumData(
//                            getString(R.string.Favorite),
//                            pictureData = recentList,
//                            isCustomAlbum = true
//                        )
                        val intent = Intent(activity, VideoGalleryActivity::class.java)
                        intent.putExtra("title", activity.getString(R.string.all_videos))
                        activity.startActivity(intent)
                    }

                    2 -> {//llFavorite
                        val intent = Intent(activity, FavoritesListActivity::class.java)
                        intent.putExtra("title", activity.getString(R.string.Favorite))
                        activity.startActivity(intent)
                    }

                    3 -> {//llHidden
                        val intent = Intent(activity, LockSetActivity::class.java)
                        activity.lockActivityResultLauncher.launch(intent)
                    }

                    4 -> {
                        //llDuplicate
                        activity.startActivity(Intent(activity, StorageScanActivity::class.java))
                    }

                    5 -> {
                        //llTrash
                        activity.startActivity(Intent(activity, RecentlyDeleteActivity::class.java))
                    }

                    6 -> {//llCleaner
                        activity.startActivity(Intent(activity, StorageScanActivity::class.java))
                    }

                    7 -> {//llEditor
                        activity.openEditorLauncher()
                    }

//                    8 -> {//llBrowser
//                        startActivity(Intent(this@HomeActivity, WebBrowserActivity::class.java))
//                    }

                    9 -> {//llPdf
                        val intent = Intent(activity, SelectImageActivity::class.java)
                        intent.putExtra(Constant.EXTRA_SELECT_TYPE, Constant.SELECT_TYPE_CRATE_PDF)
                        intent.putExtra(Constant.EXTRA_INCLUDE_VIDEO, false)
                        activity.startActivity(intent)
                    }

                }

            })
        albumAdapter?.submitList(activity.albumList)
        albumTab.albumRecycler.itemAnimator = null
        albumTab.albumRecycler.adapter = albumAdapter

        albumTab.albumRecycler.post {
            FastScroller(albumTab.albumHandle).bind(albumTab.albumRecycler)
        }

    }


    fun notifyAdapter() {

        albumTab.albumRecycler.post {
            if (albumAdapter != null) {
//            albumAdapter?.notifyDataSetChanged()
                albumAdapter?.submitList(activity.albumList)
                albumAdapter?.notifyItemRangeChanged(0, activity.albumList.size)
            }
        }
    }


    fun setRvLayoutManager() {


        try {
//            val gridCount = activity.preferences.getAlbumGridCount() ?: 0
            val isGridShow = activity.preferences.getShowGrid() ?: false

            if (isGridShow) {
                val layoutManager = albumTab.albumRecycler.layoutManager as MyGridLayoutManager
                layoutManager.orientation = RecyclerView.VERTICAL
                layoutManager.spanCount = 3
                layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                    override fun getSpanSize(position: Int): Int {
                        if (position >= 0 && position < activity.albumList.size) {
                            if (albumAdapter!!.getItemViewType(position) == albumAdapter!!.ITEM_ALBUM_UTIL_TYPE) {
                                return 3
                            } else return 1
                        } else {
                            return 1
                        }
                    }
                }
            } else {
                val layoutManager = albumTab.albumRecycler.layoutManager as MyGridLayoutManager
                layoutManager.spanCount = 1
                layoutManager.orientation = RecyclerView.VERTICAL
                layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                    override fun getSpanSize(position: Int): Int {
                        return 1
                    }
                }
//                mAlbumZoomListener = null

            }
        } catch (e: Exception) {
        }
    }

    private fun setSelectedAlbum() {
        var selected = 0
        var allItemCount = 0
        -1
        var photosCount = 0
        var photosSelectCount = 0

        for (i in activity.albumList.indices) {
            if (activity.albumList[i] is AlbumData) {
                val model = activity.albumList[i] as AlbumData
                allItemCount++
                photosCount++
                if (model.isSelected) {
                    selected++
                    photosSelectCount++
                }
            }
        }

        activity.longClickListener(true, selected, allItemCount == selected)
        albumTab.swipeRefreshAlbum.isEnabled = false
//        binding.swipeRefreshAlbum.isEnabled = selected == 0
        selectedAlbumCount = selected
    }

    fun getAlbumData() {

        albumTab.albumRecycler.suppressLayout(true)
        albumTab.refreshAlbum.beVisible()

        albumLoader?.destroyLoader()
        albumLoader?.getAllAlbum({ customAlbumList, allAlbumList, mediaList ->
            activity.albumList.clear()
            activity.albumList.addAll(customAlbumList)
            Constant.deviceAlbumList.clear()
            Constant.deviceAlbumList.addAll(allAlbumList)

            Log.e("AlbumRenameDialog", "albumList.size:${activity.albumList.size}")

            activity.runOnUiThread {
                albumTab.albumRecycler.suppressLayout(false)
                albumTab.refreshAlbum.beGone()
                setAlbumData()
                getUtilData()
            }
        })

        mAlbumDragListener = object : MyRecyclerView.MyDragListener {

            override fun selectItem(position: Int) {
                toggleAlbumSelection(true, position, true)
            }

            override fun selectRange(
                initialSelection: Int, lastDraggedIndex: Int, minReached: Int, maxReached: Int,
            ) {
                selectAlbumRange(
                    initialSelection,
                    Math.max(0, lastDraggedIndex),
                    Math.max(0, minReached),
                    maxReached
                )
                if (minReached != maxReached) {
                    lastLongPressedAlbum = -1
                }
            }

        }
        albumTab.albumRecycler.setupDragListener(mAlbumDragListener)
    }


    private fun selectAlbumRange(from: Int, to: Int, min: Int, max: Int) {
        if (from == to) {
            (min..max).filter { it != from }.forEach { toggleAlbumSelection(false, it, true) }
            return
        }

        if (to < from) {
            for (i in to..from) {
                toggleAlbumSelection(true, i, true)
            }

            if (min > -1 && min < to) {
                (min until to).filter { it != from }
                    .forEach { toggleAlbumSelection(false, it, true) }
            }

            if (max > -1) {
                for (i in from + 1..max) {
                    toggleAlbumSelection(false, i, true)
                }
            }
        } else {
            for (i in from..to) {
                toggleAlbumSelection(true, i, true)
            }

            if (max > -1 && max > to) {
                (to + 1..max).filter { it != from }
                    .forEach { toggleAlbumSelection(false, it, true) }
            }

            if (min > -1) {
                for (i in min until from) {
                    toggleAlbumSelection(false, i, true)
                }
            }
        }
    }

    protected fun toggleAlbumSelection(select: Boolean, pos: Int, updateTitle: Boolean = true) {

        if (activity.albumList[pos] is AlbumData) {
            if (select && !activity.albumList[pos].isCustomAlbum) {
                activity.albumList[pos].isSelected = true
//                albumList[pos].isCheckboxVisible = true
//                selectedKeys.add(itemKey)
            } else {
                activity.albumList[pos].isSelected = false
//                albumList[pos].isCheckboxVisible = true
//                selectedKeys.remove(itemKey)
            }
        }

        albumAdapter?.notifyItemChanged(pos)
        setSelectedAlbum()
    }



}