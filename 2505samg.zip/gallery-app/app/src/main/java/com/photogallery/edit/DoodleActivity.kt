package com.photogallery.edit

import android.content.Intent
import android.graphics.Color
import android.graphics.PorterDuff
import android.os.Bundle
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.AdapterView
import android.widget.SeekBar
import android.widget.SeekBar.OnSeekBarChangeListener
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.widget.AppCompatImageView
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.databinding.DataBindingUtil.setContentView
import com.bumptech.glide.Glide
import com.photogallery.R
import com.photogallery.base.BaseActivity
import com.photogallery.databinding.ActivityDoodleBinding
import com.photogallery.dialog.ProgressDialog
import com.photogallery.edit.adapter.ColorAdapter
import com.photogallery.edit.adapter.SelectDoodleAdapter
import com.photogallery.edit.model.EditData
import com.photogallery.extension.toast
import com.photogallery.extension.updateStatusBarColor
import com.photogallery.utils.Constant
import com.photogallery.views.CustomSpinner
import com.photoeditor.OnPhotoEditorListener
import com.photoeditor.PhotoEditor
import com.photoeditor.ViewType
import com.photoeditor.shape.ShapeBuilder
import com.photoeditor.shape.ShapeType

import io.reactivex.annotations.NonNull


class DoodleActivity : BaseActivity(), OnPhotoEditorListener {

    lateinit var binding: ActivityDoodleBinding

    var imagePath = ""
    var saveImageName = ""
    lateinit var mPhotoEditor: PhotoEditor
    private lateinit var mShapeBuilder: ShapeBuilder
    lateinit var spinnerAdapter: SelectDoodleAdapter
    var optionList: ArrayList<EditData> = ArrayList()
    var spinnerPos = -1
    var addViewTotal = 0
    var addViewShow = 0
    var isCallRedo = false

    override fun onCreate(savedInstanceState: Bundle?) {
        applyStatusBar = false
        super.onCreate(savedInstanceState)
        binding = ActivityDoodleBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        updateStatusBarColor(Color.parseColor("#151515"))

        intView()
    }

    override fun onResume() {
        applyStatusBar = false
        super.onResume()
    }

    override fun onPause() {
        super.onPause()
    }

    private fun intView() {
        intListener()
        setSelectButton(binding.btnBrush)
        setUndoRedoView(0)

        imagePath = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_PATH) ?: ""
        saveImageName = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_NAME) ?: ""

//        val matchParent = RelativeLayout.LayoutParams.MATCH_PARENT
//        binding.photoEditorView.source.layoutParams = RelativeLayout.LayoutParams(matchParent, matchParent)
//        binding.photoEditorView.source.requestLayout()
//        binding.photoEditorView.source.scaleType = ImageView.ScaleType.FIT_XY;

        mPhotoEditor = PhotoEditor.Builder(this, binding.photoEditorView)
            .setPinchTextScalable(false)
            .build() // build photo editor sdk

//        PhotoEditor.Builder(this,  binding.photoEditorView).build()
        mPhotoEditor.setOnPhotoEditorListener(this)
        mPhotoEditor.setBrushDrawingMode(true)
        mShapeBuilder = ShapeBuilder()
//        onColorChanged(R.color.white_color)
        onOpacityChanged(255)
        mPhotoEditor.setShape(mShapeBuilder)

        val width = getScreenWidth()
        val bitmap = getBitmapFromFilePath(imagePath)
        if (bitmap != null) {
            if (bitmap.width < width) {
                Thread {
                    val ratio: Float = bitmap.width / bitmap.height.toFloat()
                    val height = (width / ratio).toInt()
                    val newBitmap =
                        Glide.with(this.applicationContext).asBitmap()
                            .load(imagePath)
                            .submit(width, height)
                            .get()
                    runOnUiThread {
                        binding.photoEditorView.source.setImageBitmap(newBitmap)
                    }
                }.start()
            } else {
                runOnUiThread {
                    binding.photoEditorView.source.setImageBitmap(bitmap)
                }
            }

        } else {
//            runOnUiThread {
//                binding.photoEditorView.source.setImageBitmap(bitmap)
//            }
        }

        setSpinnerData()
        setColorAdapter()

    }

    private fun setColorAdapter() {
        val colorAdapter = ColorAdapter(this, clickListener = {
            onColorChanged(it)
        })
        binding.recyclerView.adapter = colorAdapter
        onColorChanged(colorAdapter.colorList[0])
    }

    private fun setSpinnerData() {
        optionList.add(
            EditData(
                getString(R.string.color),
                ContextCompat.getDrawable(this, R.drawable.ic_color)
            )
        )
        optionList.add(
            EditData(
                getString(R.string.size),
                ContextCompat.getDrawable(this, R.drawable.ic_size)
            )
        )
        optionList.add(
            EditData(
                getString(R.string.opacity),
                ContextCompat.getDrawable(this, R.drawable.ic_opacity)
            )
        )

        spinnerAdapter = SelectDoodleAdapter(this, optionList)
        binding.spinner.adapter = spinnerAdapter
        binding.spinner.setSelection(0)

        binding.spinner.onPopUpOpenedListener = { spinner: CustomSpinner ->
            // called when the pop-up is opened
            Log.e("SpinnerTag", "onPopUp Opened")
//            rotationAngle = if (rotationAngle == 0f) 180f else 0f
//            binding.ivDropDown.animate().rotation(rotationAngle).setDuration(500).start()
        }

        binding.spinner.onPopUpClosedListener = { spinner: CustomSpinner ->
            // called when the pop-up is closed
            Log.e("SpinnerTag", "onPopUp Closed")
//            rotationAngle = if (rotationAngle == 0f) 180f else 0f
//            binding.ivDropDown.animate().rotation(rotationAngle).setDuration(500).start()
        }

        binding.spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                if (position != -1)
                    binding.txtItemSpinner.text = optionList[position].name

                if (spinnerPos != position) {
                    spinnerPos = position

                    when (spinnerPos) {
                        0 -> {
                            binding.shapeOpacity.visibility = View.GONE
                            binding.shapeSize.visibility = View.GONE
                            binding.recyclerView.visibility = View.VISIBLE
                        }

                        1 -> {
                            binding.shapeSize.visibility = View.VISIBLE
                            binding.shapeOpacity.visibility = View.GONE
                            binding.recyclerView.visibility = View.GONE
                        }

                        2 -> {
                            binding.shapeOpacity.visibility = View.VISIBLE
                            binding.shapeSize.visibility = View.GONE
                            binding.recyclerView.visibility = View.GONE
                        }
                    }
                }
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
            }

        }

    }

    fun onColorChanged(colorCode: Int) {
        mPhotoEditor.setShape(mShapeBuilder.withShapeColor(colorCode))
    }

    fun onOpacityChanged(opacity: Int) {
        mPhotoEditor.setShape(mShapeBuilder.withShapeOpacity(opacity))
    }

    fun onShapeSizeChanged(shapeSize: Int) {
        mPhotoEditor.setShape(mShapeBuilder.withShapeSize(shapeSize.toFloat()))
    }

    private fun intListener() {
        binding.icBack.setOnClickListener { onBackPressed() }
        binding.ivDone.setOnClickListener {
            binding.ivDone.isEnabled = false

            val progressDialog = ProgressDialog(
                this@DoodleActivity,
                0,
                0,
                getString(R.string.saving),
                ""
            )

            progressDialog.show()
//        progressDialog.isCancelable = false

            mPhotoEditor.saveAsFile(getSaveEditPath(saveImageName), object :
                PhotoEditor.OnSaveListener {
                override fun onSuccess(@NonNull imagePath: String) {
                    Log.e("PhotoEditor", "Image Saved Successfully $imagePath")
                    val intent = Intent()
                    intent.putExtra(Constant.EXTRA_EDIT_SAVE_IMAGE, imagePath)
                    setResult(RESULT_OK, intent)
                    if(!isFinishing && !isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()
                    }
                    finish()
                }

                override fun onFailure(@NonNull exception: Exception) {
                    Log.e("PhotoEditor", "Failed to save Image")
                    binding.ivDone.isEnabled = true
                    if(!isFinishing && !isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()
                    }
                    toast(getString(R.string.image_editing_failed))

                }
            })
        }

        binding.btnBrush.setOnClickListener {
            setSelectButton(binding.btnBrush)
            setShareType(ShapeType.Brush)
        }
        binding.btnLine.setOnClickListener {
            setSelectButton(binding.btnLine)
            setShareType(ShapeType.Line)
        }
        binding.btnArrow.setOnClickListener {
            setSelectButton(binding.btnArrow)
            setShareType(ShapeType.Arrow())
        }
        binding.btnRectangle.setOnClickListener {
            setSelectButton(binding.btnRectangle)
            setShareType(ShapeType.Rectangle)
        }
        binding.btnCircle.setOnClickListener {
            setSelectButton(binding.btnCircle)
            setShareType(ShapeType.Oval)
        }

        binding.icUndo.setOnClickListener {
            if (addViewShow > 0) {
                mPhotoEditor.undo()
            }
        }
        binding.icRedo.setOnClickListener {
            if (addViewShow < addViewTotal) {
                isCallRedo = true
                mPhotoEditor.redo()
            }
        }

        binding.shapeSize.setOnSeekBarChangeListener(object : OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, i: Int, b: Boolean) {
                onShapeSizeChanged(i)
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {

            }

            override fun onStopTrackingTouch(p0: SeekBar?) {

            }

        })

        binding.shapeOpacity.setOnSeekBarChangeListener(object : OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, i: Int, b: Boolean) {
                onOpacityChanged(i)
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {

            }

            override fun onStopTrackingTouch(p0: SeekBar?) {

            }

        })
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }

    private fun setSelectButton(button: AppCompatImageView) {
        setUnSelectAll()
        button.background = ContextCompat.getDrawable(this, R.drawable.bg_squre_select)

        button.setColorFilter(
            Color.parseColor("#FFFFFF"),
            PorterDuff.Mode.SRC_IN
        )
    }

    private fun setUnSelectAll() {
        val drawable = ContextCompat.getDrawable(this, R.drawable.bg_squre)
//        val color = ContextCompat.getColor(this@DoodleActivity, R.color.home_unSelect_tab_icon)
        val color = Color.parseColor("#585858")

        binding.btnBrush.background = drawable
        binding.btnRectangle.background = drawable
        binding.btnLine.background = drawable
        binding.btnArrow.background = drawable
        binding.btnCircle.background = drawable

        binding.btnBrush.setColorFilter(color, PorterDuff.Mode.SRC_IN)
        binding.btnRectangle.setColorFilter(color, PorterDuff.Mode.SRC_IN)
        binding.btnLine.setColorFilter(color, PorterDuff.Mode.SRC_IN)
        binding.btnArrow.setColorFilter(color, PorterDuff.Mode.SRC_IN)
        binding.btnCircle.setColorFilter(color, PorterDuff.Mode.SRC_IN)

    }

    private fun setShareType(shapeType: ShapeType) {
        mPhotoEditor.setShape(mShapeBuilder.withShapeType(shapeType))
    }


    override fun onAddViewListener(viewType: ViewType?, numberOfAddedViews: Int) {
        Log.e("EDITTAG", "onAddViewListener numberOfAddedViews $numberOfAddedViews")
        if (isCallRedo)
            isCallRedo = false
        else
            addViewTotal++
        setUndoRedoView(numberOfAddedViews)
    }

    private fun setUndoRedoView(numberOfAddedViews: Int) {
        addViewShow = numberOfAddedViews
        val visibleColor = Color.parseColor("#FFFFFF")
        val unVisibleColor = Color.parseColor("#898F9B")

        binding.icUndo.setColorFilter(
            if (numberOfAddedViews == 0) unVisibleColor else visibleColor,
            PorterDuff.Mode.SRC_IN
        )

        binding.icRedo.setColorFilter(
            if (numberOfAddedViews == addViewTotal) unVisibleColor else visibleColor,
            PorterDuff.Mode.SRC_IN
        )
    }

    override fun onEditTextChangeListener(rootView: View?, text: String?, colorCode: Int) {

    }

    override fun onRemoveViewListener(viewType: ViewType?, numberOfAddedViews: Int) {
        Log.e("EDITTAG", "onRemoveViewListener numberOfAddedViews $numberOfAddedViews")
        setUndoRedoView(numberOfAddedViews)
    }

    override fun onStartViewChangeListener(viewType: ViewType?) {
        Log.e("EDITTAG", "onRemoveViewListener onStartViewChangeListener ${viewType.toString()}")
    }

    override fun onStopViewChangeListener(viewType: ViewType?) {
        Log.e("EDITTAG", "onRemoveViewListener onStopViewChangeListener ${viewType.toString()}")
    }

    override fun onTouchSourceImage(event: MotionEvent?) {
        Log.e("EDITTAG", "onRemoveViewListener onTouchSourceImage ${event.toString()}")
    }
}