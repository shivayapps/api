package com.photogallery.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.photogallery.R
import com.photogallery.databinding.ItemStoriesBinding
import com.photogallery.extension.beVisible
import com.photogallery.model.AlbumData
import com.photogallery.utils.Preferences


class StoryAdapter(
    var context: Context,
    val clickListener: (albumData: AlbumData) -> Unit
) : ListAdapter<AlbumData, RecyclerView.ViewHolder>(DiffCallBack()) {

    private class DiffCallBack : DiffUtil.ItemCallback<AlbumData>() {
        override fun areItemsTheSame(oldItem: AlbumData, newItem: AlbumData) = oldItem == newItem

        @SuppressLint("DiffUtilEquals")
        override fun areContentsTheSame(oldItem: AlbumData, newItem: AlbumData) = oldItem == newItem
    }

    var preferences: Preferences = Preferences(context)
    private val borderColors = listOf(
        Color.parseColor("#FF6B6B"),
        Color.parseColor("#4ECDC4"),
        Color.parseColor("#FFD93D"),
        Color.parseColor("#1A73E8"),
        Color.parseColor("#A29BFE")
    )

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = ItemStoriesBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return AlbumGridViewHolder(binding)
    }

    val fullOptions = RequestOptions()
        .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
        .skipMemoryCache(false)
        .format(DecodeFormat.PREFER_ARGB_8888)
        .dontAnimate()
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        holder.itemView.tag = holder

        val albumGridViewHolder = holder as AlbumGridViewHolder

        val albumData: AlbumData = getItem(position) as AlbumData

        albumGridViewHolder.itemView.setOnClickListener {
            clickListener(albumData)
        }

        albumGridViewHolder.binding.txtTitle.text = albumData.title
        if (albumData.mediaData.isNotEmpty()) {
            //albumGridViewHolder.binding.txtCount.text = "${albumData.mediaData.size}"
            albumGridViewHolder.binding.image.beVisible()
            Glide.with(context.applicationContext)
                .load(albumData.mediaData[0].filePath)
                .into(albumGridViewHolder.binding.image)

            val color = borderColors[position % borderColors.size]
            albumGridViewHolder.binding.image.setBorderColor(color)

        } else {
            albumGridViewHolder.binding.image.setImageDrawable(
                ContextCompat.getDrawable(
                    context,
                    R.drawable.ic_image_placeholder
                )
            )
            val color = borderColors[position % borderColors.size]
            albumGridViewHolder.binding.image.setBorderColor(color)
        }

    }

    class AlbumGridViewHolder(var binding: ItemStoriesBinding) :
        RecyclerView.ViewHolder(binding.root)



}