package com.photogallery.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface CategoriesDao {

    @Query("SELECT * FROM categories WHERE path = :path")
    fun getCategoriesEntity(path: String): Categories

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertCategoriesEntity(data: Categories)

    @Query("SELECT * FROM categories WHERE isCategoryFetch = 1")
    fun getMediaByCategoryFetchStatus(): List<Categories>

    @Query("SELECT * FROM categories WHERE isCategoryFetch = 1 ORDER BY RANDOM() LIMIT 4")
    fun getRandomFetchedCategories(): List<Categories>

    @Query("SELECT * FROM categories WHERE path = :path LIMIT 1")
    fun getByPath(path: String): Categories?


    @Query("SELECT * FROM categories WHERE path = :path")
    fun getCategories(path: String): Categories


    @Delete
    fun deleteCategoriesEntity(data: Categories)
}