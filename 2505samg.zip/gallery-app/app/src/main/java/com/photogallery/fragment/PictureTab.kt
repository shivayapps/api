package com.photogallery.fragment

import android.content.Intent
import android.util.Log
import android.view.View
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.photogallery.activities.HomeActivity
import com.photogallery.adapter.PhotoAdapter
import com.photogallery.customview.MyGridLayoutManager
import com.photogallery.customview.MyRecyclerView
import com.photogallery.databinding.MainTabPhotoBinding
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.jobs.LoaderXMedia
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.utils.Constant
import com.photogallery.utils.FastScroller
import com.photogallery.viewpager.PhotoVideoActivity
import kotlin.math.max
import kotlin.math.min

class PictureTab(private val activity: HomeActivity, private val photosTab: MainTabPhotoBinding) {


    var selectedPhotosCount = 0
    var photosLoader: LoaderXMedia? = null
    var pictureAdapter: PhotoAdapter? = null
    var isEmptyPhoto = false
    private var mPhotosDragListener: MyRecyclerView.MyDragListener? = null

    fun onCreate(){

        photosLoader = LoaderXMedia(
            activity,
            sortOrder = activity.preferences.getSortOrder("frag_1"),
            sortType = activity.preferences.getSortType("frag_1"),
            loadImage = true,
            loadVideo = true,
            prefKey = "frag_1"
        )


    }

    private var lastLongPressedMedia = -1

    fun getPhotoData() {
        photosTab.pictureRecycler.suppressLayout(true)
        photosTab.refreshPhotos.beVisible()

        photosLoader?.destroyLoader()
        photosLoader?.getAllMedia(onSuccess = { groupedMediaList, mediaList ->
            activity.allList.clear()
            activity.allList.addAll(mediaList)

            activity.pictures.clear()
            activity.pictures.addAll(groupedMediaList)

            activity.runOnUiThread {
                photosTab.pictureRecycler.suppressLayout(false)
                //binding.photosTab.swipeRefreshPhotos.isRefreshing = false
                photosTab.refreshPhotos.beGone()

                setPhotoData()
            }
        })
    }
    fun setPhotoData() {
        activity.runOnUiThread {
            //binding.photosTab.swipeRefreshPhotos.isRefreshing = false
            photosTab.refreshPhotos.beGone()
        }

        photosTab.pictureRecycler.suppressLayout(false)

        if (pictureAdapter != null) {
            photosTab.pictureRecycler.post {
                if (pictureAdapter != null) {
                    //pictureAdapter?.notifyDataSetChanged()
                    pictureAdapter?.submitList(activity.pictures)
                    pictureAdapter?.notifyItemRangeChanged(0, activity.pictures.size)
                }
            }
        } else initPhotoAdapter()
        setEmptyPhoto()

        mPhotosDragListener = object : MyRecyclerView.MyDragListener {
            override fun selectItem(position: Int) {
                activity.toggleMediaSelection(true, position, true)
            }

            override fun selectRange(
                initialSelection: Int,
                lastDraggedIndex: Int,
                minReached: Int,
                maxReached: Int
            ) {
                selectMediaRange(
                    initialSelection,
                    Math.max(0, lastDraggedIndex),
                    Math.max(0, minReached),
                    maxReached
                )
                if (minReached != maxReached) {
                    lastLongPressedMedia = -1
                }
            }

        }
        photosTab.pictureRecycler.setupDragListener(mPhotosDragListener)

    }

    fun setPhotoGroup() {
        //binding.photosTab.swipeRefreshPhotos.isRefreshing = true
        photosTab.refreshPhotos.beVisible()
        val currentGrouping =activity.preferences.getGroupBy()
        val groupOrder = activity.preferences.getGroupOrderBy()
        photosLoader?.applyMediaGrouping(
            activity.allList,
            currentGrouping = currentGrouping,
            groupOrder = groupOrder
        ) { groupedMediaList ->
            Log.e("PhotosFragment", "groupedMediaList size==>> ${groupedMediaList.size}")
            activity.pictures.clear()
            activity.pictures.addAll(groupedMediaList)
            ////binding.photosTab.swipeRefreshPhotos.isRefreshing = false
            photosTab.refreshPhotos.beGone()
            setPhotoData()
        }
    }

    fun setSelectionEnable() {
            for (i in activity.pictures.indices) {
                if (activity.pictures[i] != null)
                    if (activity.pictures[i] is AlbumData) {
                        val model = activity.pictures[i] as AlbumData
                        model.isCheckboxVisible = true
                    } else if (activity.pictures[i] is MediaData) {
                        val model = activity.pictures[i] as MediaData
                        model.isCheckboxVisible = true
                    }
            }
            notifyAdapter()
            setSelectedMedia()

    }

    fun notifyAdapter() {
        photosTab.pictureRecycler.post {
            if (pictureAdapter != null) {
                //pictureAdapter?.notifyDataSetChanged()
                pictureAdapter?.submitList(activity.pictures)
                pictureAdapter?.notifyItemRangeChanged(0, activity.pictures.size)
            }
        }
    }


    fun setRvLayoutManager() {

        try {
            val gridCount = activity.preferences.getGridCount()
            val layoutManager = photosTab.pictureRecycler.layoutManager as MyGridLayoutManager
            layoutManager.isItemPrefetchEnabled = true
            layoutManager.initialPrefetchItemCount = 10

            photosTab.pictureRecycler.setHasFixedSize(true)
            photosTab.pictureRecycler.setItemViewCacheSize(30)
            photosTab.pictureRecycler.recycledViewPool.setMaxRecycledViews(1, 30)
            photosTab.pictureRecycler.recycledViewPool.setMaxRecycledViews(2, 40)

            layoutManager.spanCount = gridCount
            layoutManager.orientation = RecyclerView.VERTICAL
            layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int): Int {
                    if (position >= 0 && position < activity.pictures.size) {
                        return if (pictureAdapter!!.getItemViewType(position) == pictureAdapter!!.ITEM_HEADER_TYPE) {
                            gridCount
                        } else 1
                    } else {
                        return 1
                    }
                }
            }
        } catch (e: Exception) {
        }


        try {
            photosTab.pictureRecycler.post {
                FastScroller(photosTab.photosHandle).bind(photosTab.pictureRecycler)
            }
        } catch (e: Exception) {
        }
    }
    fun setSelectedMedia() {
        var selected = 0
        var allItemCount = 0

        var currentHeaderPos = -1
        var photosCount = 0
        var photosSelectCount = 0

        for (i in activity.pictures.indices) {
            if (activity.pictures[i] is AlbumData) {
                if (i != currentHeaderPos) {
                    if (currentHeaderPos != -1) {
                        val model = activity.pictures[currentHeaderPos] as AlbumData
                        model.isSelected = photosCount == photosSelectCount
                        photosCount = 0
                        photosSelectCount = 0
                        pictureAdapter?.notifyItemChanged(currentHeaderPos)
                    }
                    currentHeaderPos = i
                }
            } else if (activity.pictures[i] is MediaData) {
                val model = activity.pictures[i] as MediaData
                allItemCount++
                photosCount++
                if (model.isSelected) {
                    selected++
                    photosSelectCount++
                }
            }
            if (i == activity.pictures.size - 1) {
                if (currentHeaderPos != -1) {
                    val model = activity.pictures[currentHeaderPos] as AlbumData
                    model.isSelected = photosCount == photosSelectCount
                    photosCount = 0
                    photosSelectCount = 0
                    pictureAdapter?.notifyItemChanged(currentHeaderPos)
                }
            }
        }

        activity.longClickListener(true, selected, allItemCount == selected)
        photosTab.swipeRefreshPhotos.isEnabled = false
        selectedPhotosCount = selected
    }
    private fun initPhotoAdapter() {
//        binding.mediaFastscroller.attachFastScrollerToRecyclerView(binding.pictureRecycler)
//        preferences.saveObjectList(pictures)
        pictureAdapter = PhotoAdapter(
            activity,
            clickListener = {
                if (activity.pictures[it] is MediaData) {
                    val mediaData = activity.pictures[it] as MediaData
                    if (mediaData.isCheckboxVisible) {
                        mediaData.isSelected = !mediaData.isSelected
                        pictureAdapter?.notifyItemChanged(it)
                        setSelectedMedia()
                    } else {
                        val dataList = ArrayList<MediaData>()
                        var displayPos = 0
                        for (i in activity.pictures.indices) {
                            if (activity.pictures[i] is MediaData) {
                                dataList.add(activity.pictures[i] as MediaData)
                                if (it == i) {
                                    displayPos = dataList.size - 1
                                }
                            }
                        }
                        Constant.displayImageList = ArrayList()
                        Constant.displayImageList.addAll(dataList)
                        Constant.selectedPosition = displayPos
//                        val intent = Intent(activity, ImageViewerActivity::class.java)
                        if (Constant.displayImageList.size > 0) {
                            val intent = Intent(activity, PhotoVideoActivity::class.java)
                            intent.putExtra(Constant.EXTRA_DISPLAY_POS, displayPos)
                            activity.startActivity(intent)
                        }
                        activity.setBackAlbumData()
                    }
                }
            },
            longClickListener = {

                lastLongPressedMedia = it
                photosTab.pictureRecycler.setDragSelectActive(it)
                lastLongPressedMedia = if (lastLongPressedMedia == -1) {
                    it
                } else {
                    val min = min(lastLongPressedMedia, it)
                    val max = max(lastLongPressedMedia, it)
                    for (i in min..max) {
                        activity.toggleMediaSelection(true, i, false)
                    }
//                    updateTitle()
                    it
                }

                if (activity.pictures[it] is MediaData) {
                    val mediaData = activity.pictures[it] as MediaData
                    for (i in activity.pictures.indices) {
                        if (activity.pictures[i] != null)
                            if (activity.pictures[i] is AlbumData) {
                                val model = activity.pictures[i] as AlbumData
                                model.isCheckboxVisible = true
                            } else if (activity.pictures[i] is MediaData) {
                                val model = activity.pictures[i] as MediaData
                                model.isCheckboxVisible = true
                            }
                    }
                    mediaData.isCheckboxVisible = true
                    mediaData.isSelected = true
                    notifyAdapter()
                    setSelectedMedia()
                }

            },
            headerSelectListener = {
                if (activity.pictures[it] is AlbumData) {
                    val albumData = activity.pictures[it] as AlbumData
                    val isSelectAll = !albumData.isSelected
                    albumData.isSelected = isSelectAll
                    var pos = it + 1
                    while (pos < activity.pictures.size) {
                        if (activity.pictures[pos] is MediaData) {
                            val model = activity.pictures[pos] as MediaData
                            model.isSelected = isSelectAll
                            pos++
                        } else if (activity.pictures[pos] is AlbumData) {
                            break
                        }
                    }
                    notifyAdapter()
                    setSelectedMedia()
                }
            },
            enableHeaderSelect = true
        )

        pictureAdapter?.submitList(activity.pictures)
        photosTab.pictureRecycler.itemAnimator = null
        photosTab.pictureRecycler.adapter = pictureAdapter

        photosTab.pictureRecycler.post {
            FastScroller(photosTab.photosHandle).bind(photosTab.pictureRecycler)
        }

    }

    protected fun selectMediaRange(from: Int, to: Int, min: Int, max: Int) {
        if (from == to) {
            (min..max).filter { it != from }.forEach { activity.toggleMediaSelection(false, it, true) }
            return
        }

        if (to < from) {
            for (i in to..from) {
                activity.toggleMediaSelection(true, i, true)
            }

            if (min > -1 && min < to) {
                (min until to).filter { it != from }
                    .forEach { activity.toggleMediaSelection(false, it, true) }
            }

            if (max > -1) {
                for (i in from + 1..max) {
                    activity.toggleMediaSelection(false, i, true)
                }
            }
        } else {
            for (i in from..to) {
                activity.toggleMediaSelection(true, i, true)
            }

            if (max > -1 && max > to) {
                (to + 1..max).filter { it != from }
                    .forEach { activity.toggleMediaSelection(false, it, true) }
            }

            if (min > -1) {
                for (i in min until from) {
                    activity.toggleMediaSelection(false, i, true)
                }
            }
        }
    }


    fun setEmptyPhoto() {
        if (activity.pictures != null && activity.pictures.size != 0) {
            isEmptyPhoto = false
            photosTab.pictureRecycler.visibility = View.VISIBLE
            photosTab.loutNoPhotos.visibility = View.GONE
        } else {
            isEmptyPhoto = true
            photosTab.pictureRecycler.visibility = View.GONE
            photosTab.loutNoPhotos.visibility = View.VISIBLE
        }
    }
}
