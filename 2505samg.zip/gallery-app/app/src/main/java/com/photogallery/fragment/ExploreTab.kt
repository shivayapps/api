package com.photogallery.fragment

import com.photogallery.activities.HomeActivity
import com.photogallery.databinding.MainTabExploreBinding

class ExploreTab(private val activity: HomeActivity, private val binding: MainTabExploreBinding)