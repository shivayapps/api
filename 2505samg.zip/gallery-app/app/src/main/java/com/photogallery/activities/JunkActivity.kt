package com.photogallery.activities

import android.Manifest
import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.util.Pair
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.airbnb.lottie.LottieAnimationView
import com.photogallery.R
import com.photogallery.adapter.JunkAdapter1
import com.photogallery.adapter.SelectAll
import com.photogallery.database.AppDatabase
import com.photogallery.databinding.ActivityJunkBinding
import com.photogallery.dialog.ProgressDialog
import com.photogallery.dialog.StopScanningDialog
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.extension.updateStatusBarColor
import com.photogallery.model.FileModel
import com.photogallery.model.MediaData
import com.photogallery.utils.AllPackagesFilter
import com.photogallery.utils.AllTempLogsFilter
import com.photogallery.utils.AllUninstalledFilter
import com.photogallery.utils.Preferences
import com.photogallery.utils.Utils
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import java.io.File
import java.util.ArrayList
import java.util.Arrays
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.Executor
import java.util.concurrent.Executors
import kotlin.collections.forEach

class JunkActivity : AppCompatActivity(), SelectAll {
    var mTAG = "JunkActivity"
    var apksExpended = false
    var tempExpanded = false
    var trashExpanded = false
    var emptyExpanded = false
    var uninstalledExpanded = false
    var apksSelectedAll = true
    var tempSelectedAll = true
    var trashSelectedAll = true
    var emptySelectedAll = true
    var uninstalledSelectedAll = true
    var scanning = false
    var totalType = 0


    var apksAdapter: JunkAdapter1? = null
    var tempAdapter: JunkAdapter1? = null
    var trashAdapter: JunkAdapter1? = null
    var emptyAdapter: JunkAdapter1? = null
    var uninstalledAdapter: JunkAdapter1? = null
    var apksList: MutableList<FileModel> = ArrayList()
    var tempList: MutableList<FileModel> = ArrayList()
    var trashList: MutableList<FileModel> = ArrayList()
    var emptyList: MutableList<FileModel> = ArrayList()
    var uninstalledList: MutableList<FileModel> = ArrayList()
    var total: Double = 0.0
    var apkTotal: Double = 0.0
    var tempTotal: Double = 0.0
    var trashTotal: Double = 0.0
    var emptyTotal: Double = 0.0
    var uninstalledTotal: Double = 0.0
    var calendar: Calendar? = null

    //    var getJunkData: GetJunkData? = null
    var getTempFiles: GetTempFiles? = null
    var getApkFiles: GetApkFiles? = null
    var getTrashFiles: GetTrashFiles? = null
    var getEmptyFiles: GetEmptyFiles? = null
    var getUninstalledFiles: GetUninstalledFiles? = null

    var apks: ArrayList<FileModel>? = null
    var tempLog: ArrayList<FileModel>? = null
    var trashCache: ArrayList<FileModel>? = null
    var emptyFolder: ArrayList<FileModel>? = null
    var uninstalledFolder: ArrayList<FileModel>? = null

    var filterTemps = ArrayList<String>()
    var filterTrash = ArrayList<String>()
    var filterInstalled = ArrayList<String>()
    var path = ""

    var onTaskListner: OnTaskCompleted? = null

    interface OnTaskCompleted {
        fun onTaskCompleted(type: Int)
    }

    private var preferences: Preferences? = null
    lateinit var binding: ActivityJunkBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityJunkBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        updateStatusBarColor(Color.parseColor("#3D79D2"))
        preferences = Preferences(this)

        binding.appCompatTextView13.isSelected = true
        binding.appCompatTextView16.isSelected = true
        binding.appCompatTextView19.isSelected = true
        binding.appCompatTextView20.isSelected = true
        binding.appCompatTextView21.isSelected = true

        path = Environment.getExternalStorageDirectory().toString()

        if (application != null) {
            val tempFiles: List<String> =
                ArrayList(Arrays.asList(*application!!.resources.getStringArray(R.array.generic_filter_files)))
            for (file in tempFiles) filterTemps.add(getRegexForFile(file))
        }


        if (application != null) {
            val trashFiles: List<String> =
                ArrayList(Arrays.asList(*application!!.resources.getStringArray(R.array.aggressive_filter_files)))
            for (file in trashFiles) filterTrash.add(getRegexForFile(file))
        }

        if (application != null) filterInstalled.addAll(getInstalledPackages(application!!.baseContext))



        calendar = Calendar.getInstance()


        binding.scrollViewJunkCalculated.visibility = View.GONE
        binding.clCalculating.visibility = View.VISIBLE
        onTaskListner = object :
            OnTaskCompleted {
            override fun onTaskCompleted(type: Int) {
                Log.e(mTAG, "onTaskCompleted:$type")
                if (type == 2) {
                    Log.e(mTAG, "onTaskCompleted:apks")
                    apks?.forEach { apks ->
                        if (apks != null) {
                            apksList.add(apks)
                            apkTotal += apks.getSize().toFloat()
                        }
                    }
                    try {
                        Log.e(mTAG, "onTaskCompleted:setApksRecyclerView")
                        totalType += 1
                        setApksRecyclerView(apksList)
                        total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal
                        val size = Utils.getDataSizeWithPrefix(applicationContext, total)
                        setSizeAnimation(size)
                        imagesDoneVisibility(true, 2)
                        lottieVisibility(false, 2)
                        if (totalType >= 5) {
                            junkCalculating()
                            countJunkSize()
                        }
                    } catch (e: Exception) {
                        Log.e(mTAG, "getApks-Exception:" + e)
                    }
                }
                if (type == 3) {
                    Log.e(mTAG, "onTaskCompleted:temps")
                    tempLog?.forEach { temps ->
                        if (temps != null) {
                            tempList.add(temps)
                            tempTotal += temps.getSize().toFloat()
                        }
                    }
                    try {
                        Log.e(mTAG, "onTaskCompleted:setTempRecyclerView")
                        totalType += 1
                        setTempRecyclerView(tempList)
                        total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal
                        val size = Utils.getDataSizeWithPrefix(applicationContext, total)
                        setSizeAnimation(size)
                        imagesDoneVisibility(true, 3)
                        lottieVisibility(false, 3)
                        if (totalType >= 5) {
                            junkCalculating()
                            countJunkSize()
                        }
                    } catch (e: Exception) {
                        Log.e(mTAG, "getTempLog-Exception:" + e)
                    }
                }
                if (type == 1) {
                    Log.e(mTAG, "onTaskCompleted:trash")
                    trashCache?.forEach { trash ->
                        if (trash != null) {
                            trashList.add(trash)
                            trashTotal += trash.getSize().toFloat()
                        }
                    }
                    try {
                        Log.e(mTAG, "onTaskCompleted:setTrashRecyclerView")
                        totalType += 1
                        setTrashRecyclerView(trashList)
                        total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal
                        val size = Utils.getDataSizeWithPrefix(applicationContext, total)
                        setSizeAnimation(size)
                        imagesDoneVisibility(true, 1)
                        lottieVisibility(false, 1)
                        if (totalType >= 5) {
                            junkCalculating()
                            countJunkSize()
                        }
                    } catch (e: Exception) {
                        Log.e(mTAG, "getTrashCache-Exception:" + e)
                    }
                }
                if (type == 4) {
                    Log.e(mTAG, "onTaskCompleted:empty")
                    emptyFolder?.forEach { empty ->
                        if (empty != null) {
                            emptyList.add(empty)
                            emptyTotal += empty.getSize().toFloat()
                        }
                    }
                    try {
                        Log.e(mTAG, "onTaskCompleted:setEmptyRecyclerView")
                        totalType += 1
                        setEmptyRecyclerView(emptyList)
                        total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal
                        val size = Utils.getDataSizeWithPrefix(applicationContext, total)
                        setSizeAnimation(size)
                        imagesDoneVisibility(true, 4)
                        lottieVisibility(false, 4)
                        if (totalType >= 5) {
                            junkCalculating()
                            countJunkSize()
                        }
                    } catch (e: Exception) {
                        Log.e(mTAG, "getEmptyFolder-Exception:" + e)
                    }

                }
                if (type == 5) {
                    Log.e(mTAG, "onTaskCompleted:uninstalled")
                    uninstalledFolder?.forEach { uninstalled ->
                        if (uninstalled != null) {
                            uninstalledList.add(uninstalled)
                            uninstalledTotal += uninstalled.getSize().toFloat()
                        }
                    }
                    try {
                        Log.e(mTAG, "onTaskCompleted:setUninstalledRecyclerView")
                        totalType += 1
                        setUninstalledRecyclerView(uninstalledList)
                        total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal
                        val size = Utils.getDataSizeWithPrefix(applicationContext, total)
                        setSizeAnimation(size)
                        imagesDoneVisibility(true, 5)
                        lottieVisibility(false, 5)
                        if (totalType >= 5) {
                            junkCalculating()
                            countJunkSize()
                        }
                    } catch (e: Exception) {
                        Log.e(mTAG, "getUninstalled-Exception:" + e)
                    }
                }
            }
        }
        runScanner()

        binding.clBlur.setOnClickListener {
            Toast.makeText(
                this,
                getString(R.string.cleaner_running_please_wait),
                Toast.LENGTH_SHORT
            ).show()
        }

        binding.btnScan.setOnClickListener(View.OnClickListener { v: View? ->

            if (apksAdapter != null) apkTotal = apksAdapter?.allTotal!!
            if (tempAdapter != null) tempTotal = tempAdapter?.allTotal!!
            if (trashAdapter != null) trashTotal = trashAdapter?.allTotal!!
            if (emptyAdapter != null) emptyTotal = emptyAdapter?.allTotal!!
            if (uninstalledAdapter != null) uninstalledTotal = uninstalledAdapter?.allTotal!!
            total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal

            if (total == 0.0) {
                Toast.makeText(this, getString(R.string.no_file_to_delete), Toast.LENGTH_SHORT)
                    .show()
                return@OnClickListener
            }
            binding.textViewStatus!!.beVisible()
            binding.constraintLayout2!!.beVisible()
//            changeLoading(lottie_loading!!, "cleaner_running.json")

            if (!scanning) {
//                binding.buttonScan?.isEnabled=false
                binding.clBlur.visibility = View.VISIBLE
//                process_dots.visibility = View.VISIBLE
//                binding.btnScan?.beGone()
                scanning = true

                val listModel = apksAdapter!!.getKillingApps()
                val tempModel = tempAdapter!!.getKillingApps()
                val trashModel = trashAdapter!!.getKillingApps()
                val emptyModel = emptyAdapter!!.getKillingApps()
                val uninstalledModel = uninstalledAdapter!!.getKillingApps()

                val allFiles = listModel+ tempModel+ trashModel+ emptyModel+ uninstalledModel

                if (apksAdapter != null) apksAdapter!!.justRemoveSelectedFile()
                if (tempAdapter != null) tempAdapter!!.justRemoveSelectedFile()
                if (trashAdapter != null) trashAdapter!!.justRemoveSelectedFile()
                if (emptyAdapter != null) emptyAdapter!!.justRemoveSelectedFile()
                if (uninstalledAdapter != null) uninstalledAdapter!!.justRemoveSelectedFile()

                binding.txtScan?.text = getString(R.string.cleaning)
                deleteModels(allFiles)
                cleanProgressAnimation(total)
            }
        })

        binding.imageViewBack1.setOnClickListener(View.OnClickListener { v: View? ->
            onBackPressed()
//            if (!scanning) {
//                finish()
//            }
        })
        binding.imageViewApksUpDownClick.setOnClickListener(View.OnClickListener { v: View? ->
            if (!apksExpended) {
//                binding.imageViewApksUpDown.setImageResource(R.drawable.ic_arrow_up);
                binding.imageViewApksUpDown.rotation = 270f
//                binding.clApksHead.setBackgroundResource(R.drawable.shape_stroke_above_curved_white_opacity_10);
                binding.clApksRecyclerView.visibility = View.VISIBLE
                apksExpended = true
            } else {
                binding.imageViewApksUpDown.rotation = 0f
                binding.imageViewApksUpDown.setImageResource(R.drawable.ic_arrow_down)
//                binding.clApksHead.setBackgroundResource(R.drawable.shape_stroke_curved_white_opacity_10);
                binding.clApksRecyclerView.visibility = View.GONE
                apksExpended = false
            }
        })
        binding.imageViewTempUpDownClick.setOnClickListener(View.OnClickListener { v: View? ->
            if (!tempExpanded) {
//                binding.imageViewTempUpDown.setImageResource(R.drawable.ic_arrow_up);
                binding.imageViewTempUpDown.rotation = 270f
//                binding.clTempHead.setBackgroundResource(R.drawable.shape_stroke_above_curved_white_opacity_10);
                binding.clTempRecyclerView.visibility = View.VISIBLE
                tempExpanded = true
            } else {
//                binding.imageViewTempUpDown.setImageResource(R.drawable.ic_arrow_down);
                binding.imageViewTempUpDown.rotation = 0f
//                binding.clTempHead.setBackgroundResource(R.drawable.shape_stroke_curved_white_opacity_10);
                binding.clTempRecyclerView.visibility = View.GONE
                tempExpanded = false
            }
        })
        binding.imageViewTrashUpDownClick.setOnClickListener(View.OnClickListener { v: View? ->
            if (!trashExpanded) {
//                binding.imageViewTrashUpDown.setImageResource(R.drawable.ic_arrow_up);
                binding.imageViewTrashUpDown.rotation = 270f
//                binding.clTrashHead.setBackgroundResource(R.drawable.shape_stroke_above_curved_white_opacity_10);
                binding.clTrashRecyclerView.visibility = View.VISIBLE
                trashExpanded = true
            } else {
//                binding.imageViewTrashUpDown.setImageResource(R.drawable.ic_arrow_down);
                binding.imageViewTrashUpDown.rotation = 0f
//                binding.clTrashHead.setBackgroundResource(   R.drawable.shape_stroke_curved_white_opacity_10);
                binding.clTrashRecyclerView.visibility = View.GONE
                trashExpanded = false
            }
        })
        binding.imageViewEmptyUpDownClick.setOnClickListener(View.OnClickListener { v: View? ->
            if (!emptyExpanded) {
//                binding.imageViewEmptyUpDown.setImageResource(R.drawable.ic_arrow_up);
                binding.imageViewEmptyUpDown.rotation = 270f
//                binding.clEmptyHead.setBackgroundResource(R.drawable.shape_stroke_above_curved_white_opacity_10);
                binding.clEmptyRecyclerView.visibility = View.VISIBLE
                emptyExpanded = true
            } else {
//                binding.imageViewEmptyUpDown.setImageResource(R.drawable.ic_arrow_down);
                binding.imageViewEmptyUpDown.rotation = 0f
//                binding.clEmptyHead.setBackgroundResource(R.drawable.shape_stroke_curved_white_opacity_10);
                binding.clEmptyRecyclerView.visibility = View.GONE
                emptyExpanded = false
            }
        })
        binding.imageViewUninstalledUpDownClick.setOnClickListener(View.OnClickListener { v: View? ->
            if (!uninstalledExpanded) {
                binding.imageViewUninstalledUpDown.rotation = 270f
                binding.clUninstalledRecyclerView.visibility = View.VISIBLE
                uninstalledExpanded = true
            } else {
                binding.imageViewUninstalledUpDown.rotation = 0f
                binding.clUninstalledRecyclerView.visibility = View.GONE
                uninstalledExpanded = false
            }
        })

    }

    private fun deleteModels(selectImage: List<FileModel>) {

        val deleteList = ArrayList<String>()

        val progressDialog = ProgressDialog(
            this,
            R.drawable.ic_drawer_delete,
            selectImage.size,
            getString(R.string.Deleting),
            ""
        )
        progressDialog.setCancelable(false)
        progressDialog.show()

//        preferences.refreshMedia = true
//        preferences.scanMedia = true

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(this)
            selectImage.forEach { model ->
                val isDelete = Utils.deleteFile(this, model.path, dataBase, true)
//                MediaScannerConnection.scanFile(
//                    this,
//                    arrayOf<String>(model.path),
//                    null
//                ) { path: String?, uri: Uri? -> }
                if (isDelete) {
                    deleteList.add(model.path)
                    runOnUiThread {
                        progressDialog.setProgress(deleteList.size, selectImage.size)
                    }
                }
            }

            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    try {
                        if (progressDialog != null
                            && progressDialog.isShowing
                            && !isFinishing
                            && !isDestroyed
                        )
                            progressDialog.dismiss()
                    } catch (e: Exception) {
                    }
                    setBeforeDeleteUpdate(deleteList)
                }
            }
            .onErrorReturn { false }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    try {
                        if (progressDialog != null
                            && progressDialog.isShowing
                            && !isFinishing
                            && !isDestroyed
                        )
                            progressDialog.dismiss()
                    } catch (e: Exception) {
                    }
                    setBeforeDeleteUpdate(deleteList)
                }
            }
    }

    private fun setBeforeDeleteUpdate(deleteList: ArrayList<String>) {
        cleanProgressAnimation(total)
    }

    override fun onPause() {
        super.onPause()
    }

    private fun getAllUninstalled(
        path: String,
        filterInstalled: ArrayList<String>
    ): List<FileModel> {
//        Log.e("Utils", "getAllUninstalled:" + path);
        val fold = File(path)
        val docList: MutableList<FileModel> = ArrayList()
        val mlist = fold.listFiles()
        val mFilelist = fold.listFiles(AllUninstalledFilter(filterInstalled))
        if (mlist != null) {
            for (f in mlist) {
                if (f.isDirectory && f.absolutePath.contains("Android")) {
                    if (!f.absolutePath.contains("RecoverMedia")) {
                        val fList = getAllUninstalled(f.absolutePath, filterInstalled)
                        docList.addAll(fList)
                    }
                }
            }
            if (mFilelist != null) {
                for (f in mFilelist) {
                    if (!f.name.isEmpty() || !f.absolutePath.contains("RecoverMedia")) {
                        setScanPath(f.path)
                        val doc = FileModel()
                        doc.name = f.name
                        doc.setSize(f.length())
                        doc.path = f.absolutePath
                        if (f.length() > 0) {
                            docList.add(doc)
                        }
                    }
                }
            }
        }
        return docList
    }

    private val emptyDocList: MutableList<FileModel> = ArrayList()
    private fun getAllEmptyNew(path: String): List<FileModel> {
        Log.e("Utils", "getAllEmptyNew:$path")
        val fold = File(path)
//        val docList: List<FileModel> = ArrayList()
        val mlist = fold.listFiles()
        if (mlist != null && mlist.size != 0) {
            for (f in mlist) {
                if (f.isDirectory) {
                    if (!f.toString().startsWith("/storage/emulated/0/Android/data")
                        && !f.toString().startsWith("/storage/emulated/0/Android/obb")
                    ) {
//                        docList.addAll(getAllEmptyNew(f.getAbsolutePath()));
                        getAllEmptyNew(f.absolutePath)
                    }
                }
            }
        } else {
            Log.e("Utils", "getAllEmptyNew:emptySize" + emptyDocList.size)
            Log.e("Utils", "getAllEmptyNew:fold:" + fold.path)
            if (fold.isDirectory) {
                if (!fold.toString().startsWith("/storage/emulated/0/Android/data")
                    && !fold.toString().startsWith("/storage/emulated/0/Android/obb")
                ) {
                    setScanPath(fold.path)
                    val doc = FileModel()
                    doc.name = fold.name
                    doc.setSize(fold.length())
                    doc.path = fold.absolutePath
                    if (fold.length() > 0) {
                        Log.e("Utils", "getAllEmptyNew:getPath_001:" + fold.path)
                        //                        docList.add(doc);
                        emptyDocList.add(doc)
                    }
                }
            }
        }
        //        return docList;
        return emptyDocList
    }

    private fun getAllTrash(path: String, trashFilters: ArrayList<String>): List<FileModel> {
//        Log.e("Utils", "getAllTrash:" + path);
        val fold = File(path)
        val docList: MutableList<FileModel> = ArrayList()
        val mlist = fold.listFiles()
        val mFilelist = fold.listFiles(AllTempLogsFilter(trashFilters))
        if (mlist != null) {
//            Log.e("Utils", "getAllTrash:mlist:" + mlist.length);
            for (f in mlist) {
                if (f.isDirectory) {
                    val fList = getAllTrash(f.absolutePath, trashFilters)
                    docList.addAll(fList)
                }
            }
            if (mFilelist != null) {
                for (f in mFilelist) {
                    if (!f.name.isEmpty() || !f.absolutePath.contains("RecoverMedia")) {
                        setScanPath(f.path)
                        val doc = FileModel()
                        doc.name = f.name
                        doc.setSize(f.length())
                        doc.path = f.absolutePath
                        if (f.length() > 0) {
                            docList.add(doc)
                        }
                    }
                }
            }
        }
        return docList
    }

    private fun getAllTempLogs(path: String, tempFilters: ArrayList<String>): List<FileModel> {
        Log.e("Utils", "getAllTempLogs:$path")
        val fold = File(path)
        val docList: MutableList<FileModel> = ArrayList()
        val mlist = fold.listFiles()
        val mFilelist = fold.listFiles(AllTempLogsFilter(tempFilters))
        if (mlist != null) {
            Log.e("Utils", "getAllTempLogs:mlist:" + mlist.size)
            for (f in mlist) {
                if (f.isDirectory) {
                    val fList = getAllTempLogs(f.absolutePath, tempFilters)
                    docList.addAll(fList)
                }
            }
            if (mFilelist != null) {
                for (f in mFilelist) {
                    if (!f.name.isEmpty() || !f.absolutePath.contains("RecoverMedia")) {
                        setScanPath(f.path)
                        val doc = FileModel()
                        doc.name = f.name
                        doc.setSize(f.length())
                        doc.path = f.absolutePath
                        if (f.length() > 0) {
                            docList.add(doc)
                        }
                    }
                }
            }
        }
        return docList
    }

    private fun getAllPackages(path: String): List<FileModel> {

//        Log.e("Utils", "getAllPackages:" + path);
        val fold = File(path)
        val docList: MutableList<FileModel> = ArrayList()
        val mlist = fold.listFiles()
        val mFilelist = fold.listFiles(AllPackagesFilter())

        if (mlist != null) {
            for (f in mlist) {
                if (f.isDirectory) {
                    val fList = getAllPackages(f.absolutePath)
                    docList.addAll(fList)
                }
            }
            if (mFilelist != null) {
                for (f in mFilelist) {
                    if (!f.name.isEmpty() || !f.absolutePath.contains("RecoverMedia")) {
                        setScanPath(f.path)
                        val doc = FileModel()
                        doc.name = f.name
                        doc.setSize(f.length())
                        doc.path = f.absolutePath
                        if (f.length() > 0) {
                            docList.add(doc)
                        }
                    }
                }
            }
        }
        return docList
    }

    private fun setScanPath(path: String) {
        runOnUiThread {
            binding.textViewFilePath?.text = path
        }
    }

    private fun getRegexForFolder(folder: String): String {
        return ".*(\\\\|/)$folder(\\\\|/|$).*"
    }

    private fun getRegexForFile(file: String): String {
        return ".+" + file.replace(".", "\\.") + "$"
    }

    private fun getInstalledPackages(context: Context): List<String> {
        val pm = context.packageManager
        val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val packagesString: MutableList<String> = ArrayList()
        for (packageInfo in packages) {
            packagesString.add(packageInfo.packageName)
        }
        return packagesString
    }


    private fun changeLoading(lottieView: LottieAnimationView, assetName: String) {
//        runOnUiThread {
//            lottieView.clearAnimation()
//            lottieView.setAnimation(assetName)
//            lottieView.loop(true)
//            lottieView.playAnimation()
//        }
    }

//    private fun givePermissions(permissions: List<String>) {
//        Dexter.withContext(this@JunkActivity).withPermissions(permissions)
//            .withListener(object : MultiplePermissionsListener {
//                override fun onPermissionsChecked(multiplePermissionsReport: MultiplePermissionsReport) {
//                    if (multiplePermissionsReport.areAllPermissionsGranted()) {
//                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
//                            checkAllFilePermission()
//                        } else {
//                            runScanner()
//                        }
//                        showSettingsDialog()
//                    } else if (multiplePermissionsReport.isAnyPermissionPermanentlyDenied) {
//                        showSettingsDialog()
//                    } else givePermissions(permissions)
//                }
//
//                override fun onPermissionRationaleShouldBeShown(
//                    list: List<PermissionRequest>,
//                    permissionToken: PermissionToken
//                ) {
//                    permissionToken.continuePermissionRequest()
//                }
//            })
//    }

//    private fun showSettingsDialog() {
//        val dialog = Dialog(this@JunkActivity)
//        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
//        dialog.setCancelable(false)
//        dialog.setContentView(R.layout.dialog_permission)
//        dialog.window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//        dialog.window.setLayout(
//            ViewGroup.LayoutParams.MATCH_PARENT,
//            ViewGroup.LayoutParams.WRAP_CONTENT
//        )
//        dialog.findViewById<View>(R.id.dialogButtonOk)
//            .setOnClickListener(View.OnClickListener {
//                MyApplication.isDialogOpen = false
//                dialog.cancel()
//                openSettings()
//            })
//        dialog.findViewById<View>(R.id.dialogButtonCancel)
//            .setOnClickListener {
//                MyApplication.isDialogOpen = false
//                dialog.cancel()
//
//                if (isFromOneSignal) {
//                    startActivity(NewHomeActivity.newIntent(this))
//                    finish()
//                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//                } else {
//                    finish()
//                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//                }
//            }
//        dialog.setOnDismissListener {
//            MyApplication.isDialogOpen = false
//        }
//        dialog.show()
//        MyApplication.isDialogOpen = true
//    }


//    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        super.onActivityResult(requestCode, resultCode, data)
//        if (requestCode == 2296) {
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
//                if (Environment.isExternalStorageManager()) {
//                    runScanner()
//                } else {
//                    Toast.makeText(
//                        this@JunkActivity,
//                        getString(R.string.permission_required),
//                        Toast.LENGTH_SHORT
//                    ).show()
//                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//                }
//            }
//        } else if (requestCode == 200) {
//            if (checkPermissionStorage(this@JunkActivity)) {
//                runScanner()
//            } else {
//                if (isFromOneSignal) {
//                    startActivity(NewHomeActivity.newIntent(this))
//                    finish()
//                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//                } else {
//                    finish()
//                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//                }
//                Toast.makeText(
//                    this@JunkActivity,
//                    getString(R.string.permission_required),
//                    Toast.LENGTH_SHORT
//                ).show()
//                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//            }
//        }
//    }


    var stopDialog: StopScanningDialog? = null
    private fun dialogStopScan() {
        stopDialog = StopScanningDialog(this@JunkActivity) { isExit ->
            if (isExit) {
                stopDialog?.cancel()

                if (getTempFiles?.status == AsyncTask.Status.RUNNING) {
                    getTempFiles?.cancel(true)
                }
                if (getApkFiles?.status == AsyncTask.Status.RUNNING) {
                    getApkFiles?.cancel(true)
                }
                if (getTrashFiles?.status == AsyncTask.Status.RUNNING) {
                    getTrashFiles?.cancel(true)
                }
                if (getEmptyFiles?.status == AsyncTask.Status.RUNNING) {
                    getEmptyFiles?.cancel(true)
                }
                if (getUninstalledFiles?.status == AsyncTask.Status.RUNNING) {
                    getUninstalledFiles?.cancel(true)
                }
                scanning = false
//                onBackPressed()

                Handler(Looper.getMainLooper()).postDelayed({ onBackPressed() }, 500)
            }
        }
//        stopDialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
        stopDialog?.setCancelable(false)
//        stopDialog?.setContentView(R.layout.dialog_stop_scanning)
//        stopDialog?.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//        stopDialog?.window!!.setLayout(
//            ViewGroup.LayoutParams.MATCH_PARENT,
//            ViewGroup.LayoutParams.WRAP_CONTENT
//        )
//
//        (stopDialog?.findViewById<View>(R.id.permission) as TextView).text = getString(R.string.scanning_in_progress)
//        (stopDialog?.findViewById<View>(R.id.permission_text) as TextView).text = getString(R.string.are_you_sure_you_want_to_stop_scanning_your_device)
//        (stopDialog?.findViewById<View>(R.id.dialogButtonOk) as TextView).text = getString(R.string.doit_close)
//        (stopDialog?.findViewById<View>(R.id.dialogButtonCancel) as TextView).text = getString(R.string.stop)
//        stopDialog?.findViewById<View>(R.id.dialogButtonOk).setOnClickListener {
//            stopDialog?.cancel()
//        }
//        stopDialog?.findViewById<View>(R.id.dialogButtonCancel)!!
//            .setOnClickListener {
//
//            }
        stopDialog?.show()
    }


    private fun runScanner() {
        if (!scanning) {
            scanning = true


            binding.btnScan?.beGone()
            binding.textViewStatus!!.beVisible()
            binding.textViewStatus!!.beVisible()
            binding.constraintLayout2!!.beVisible()
//            changeLoading(lottie_loading!!, "cleaner_running.json")

            binding.scrollViewJunkCalculated!!.visibility = View.GONE
            binding.clCalculating!!.visibility = View.VISIBLE
            imagesDoneVisibility(false, 1)
            lottieVisibility(true, 1)
            imagesDoneVisibility(false, 2)
            lottieVisibility(true, 2)
            imagesDoneVisibility(false, 3)
            lottieVisibility(true, 3)
            imagesDoneVisibility(false, 4)
            lottieVisibility(true, 4)
            imagesDoneVisibility(false, 5)
            lottieVisibility(true, 5)

//            getJunkData = GetJunkData(this@JunkActivity, repositoryStorage!!, onTaskListner)
            getTempFiles = GetTempFiles(this@JunkActivity, onTaskListner)
            getApkFiles = GetApkFiles(this@JunkActivity, onTaskListner)
            getTrashFiles = GetTrashFiles(this@JunkActivity, onTaskListner)
            getEmptyFiles = GetEmptyFiles(this@JunkActivity, onTaskListner)
            getUninstalledFiles = GetUninstalledFiles(this@JunkActivity, onTaskListner)

//            getJunkData?.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)

            getTempFiles?.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)

            getApkFiles?.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)

            getTrashFiles?.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)

            getEmptyFiles?.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)

            getUninstalledFiles?.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)

        }
    }


    inner class GetTempFiles(
        var context: Activity,
        var onTaskCompleted: OnTaskCompleted?
    ) : AsyncTask<String, String, String>() {

        override fun onPreExecute() {
            super.onPreExecute()
        }

        protected override fun doInBackground(vararg strings: String): String? {
            Log.e(mTAG, "AsyncTask-doInBackground:3")
            try {
//                initTempLogs()
//        tempLog = getTempLogs(path, filterTemps)
//        tempLog!!.addAll(getAllTempLogs(path,filterTemps))
                tempLog = ArrayList(getAllTempLogs(path, filterTemps))
            } catch (e: Exception) {
                Log.e(mTAG, "AsyncTask-3:Exception:$e")
            }
            System.gc()
            return null
        }

        override fun onPostExecute(str: String?) {
            super.onPostExecute(str)
            Log.e(mTAG, "AsyncTask-onTaskCompleted:3")
            onTaskCompleted!!.onTaskCompleted(3)
        }
    }

    inner class GetApkFiles(
        var context: Activity,
        var onTaskCompleted: OnTaskCompleted?
    ) : AsyncTask<String, String, String>() {

        override fun onPreExecute() {
            super.onPreExecute()
        }

        protected override fun doInBackground(vararg strings: String): String? {
            Log.e(mTAG, "AsyncTask-doInBackground:2")
            try {
//                initApks()
//        apks = getFilesApks(path)
//        apks!!.addAll(getAllPackages(path))
                apks = ArrayList(getAllPackages(path))
            } catch (e: Exception) {
                Log.e(mTAG, "AsyncTask-2:Exception:$e")
            }
            System.gc()
            return null
        }

        override fun onPostExecute(str: String?) {
            super.onPostExecute(str)
            Log.e(mTAG, "AsyncTask-onTaskCompleted:2")
            onTaskCompleted!!.onTaskCompleted(2)
        }
    }

    inner class GetTrashFiles(
        var context: Activity,
        var onTaskCompleted: OnTaskCompleted?
    ) : AsyncTask<String, String, String>() {

        override fun onPreExecute() {
            super.onPreExecute()
        }

        protected override fun doInBackground(vararg strings: String): String? {
            Log.e(mTAG, "AsyncTask-doInBackground:1")
            try {
                trashCache = ArrayList(getAllTrash(path, filterTrash))
            } catch (e: Exception) {
                Log.e(mTAG, "AsyncTask-1:Exception:$e")
            }
            System.gc()
            return null
        }

        override fun onPostExecute(str: String?) {
            super.onPostExecute(str)
            Log.e(mTAG, "AsyncTask+onTaskCompleted:1")
//            ShareConstants.isTrashInitialized=1
            onTaskCompleted!!.onTaskCompleted(1)
        }
    }

    inner class GetEmptyFiles(
        var context: Activity,
        var onTaskCompleted: OnTaskCompleted?
    ) : AsyncTask<String, String, String>() {

        override fun onPreExecute() {
            super.onPreExecute()
        }

        protected override fun doInBackground(vararg strings: String): String? {
            Log.e(mTAG, "AsyncTask+doInBackground:4")
            try {
//                initEmpty()
//        emptyFolder = getEmpty(path)
                emptyDocList.clear()
//        emptyFolder!!.addAll(getAllEmptyNew(path))
                emptyFolder = ArrayList(getAllEmptyNew(path))
            } catch (e: Exception) {
                Log.e(mTAG, "AsyncTask+4:Exception:$e")
            }
            System.gc()
            return null
        }

        override fun onPostExecute(str: String?) {
            super.onPostExecute(str)
            Log.e(mTAG, "AsyncTask+onTaskCompleted:4")
//            ShareConstants.isEmptyInitialized=1
            onTaskCompleted!!.onTaskCompleted(4)
        }
    }

    inner class GetUninstalledFiles(
        var context: Activity,
        var onTaskCompleted: OnTaskCompleted?
    ) : AsyncTask<String, String, String>() {

        override fun onPreExecute() {
            super.onPreExecute()
        }

        protected override fun doInBackground(vararg strings: String): String? {
            Log.e(mTAG, "AsyncTask+doInBackground:5")
            try {
//                initUninstalled()
//        uninstalledFolder = getUninstalled(path, filterInstalled)
//        uninstalledFolder!!.addAll(getAllUninstalled(path, filterInstalled))
                uninstalledFolder = ArrayList(getAllUninstalled(path, filterInstalled))
            } catch (e: Exception) {
                Log.e(mTAG, "AsyncTask+5:Exception:$e")
            }
            System.gc()
            return null
        }

        override fun onPostExecute(str: String?) {
            super.onPostExecute(str)
            Log.e(mTAG, "AsyncTask+onTaskCompleted:5")
            onTaskCompleted!!.onTaskCompleted(5)
        }
    }

    fun verifyInstallerId(context: Context, packageName: String?): Boolean {

        // A list with valid installers package name
        val validInstallers: List<String?> =
            ArrayList(Arrays.asList("com.android.vending", "com.google.android.feedback"))

        // The package name of the app that has installed your app
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val installer = context.packageManager.getInstallSourceInfo(
                    (packageName)!!
                )
                installer.initiatingPackageName
                //                installer.getInstallingPackageName();
                return validInstallers.contains(installer.initiatingPackageName) ||
                        validInstallers.contains(installer.installingPackageName)
            } catch (e: PackageManager.NameNotFoundException) {
                e.printStackTrace()
            }
        } else {
            val installer1 = context.packageManager.getInstallerPackageName(
                (packageName)!!
            )
            return installer1 != null && validInstallers.contains(installer1)
        }
        return false
    }

    fun imagesDoneVisibility(visible: Boolean, num: Int) {
        if (visible) {
            if (num == 1) {
                binding.imageViewTrash!!.visibility = View.VISIBLE
            } else if (num == 2) {
                binding.imageViewUselessApks!!.visibility = View.VISIBLE
            } else if (num == 3) {
                binding.imageViewTempFiles!!.visibility = View.VISIBLE
            } else if (num == 4) {
                binding.imageViewEmptyFolder!!.visibility = View.VISIBLE
            } else if (num == 5) {
                binding.imageViewUninstalled!!.visibility = View.VISIBLE
            }
        } else {
            if (num == 1) {
                binding.imageViewTrash!!.visibility = View.INVISIBLE
            } else if (num == 2) {
                binding.imageViewUselessApks!!.visibility = View.INVISIBLE
            } else if (num == 3) {
                binding.imageViewTempFiles!!.visibility = View.INVISIBLE
            } else if (num == 4) {
                binding.imageViewEmptyFolder!!.visibility = View.INVISIBLE
            } else if (num == 5) {
                binding.imageViewUninstalled!!.visibility = View.INVISIBLE
            }
        }
    }

    fun lottieVisibility(visible: Boolean, num: Int) {
        if (visible) {
            if (num == 1) {
                binding.lottieTrash!!.visibility = View.VISIBLE
            } else if (num == 2) {
                binding.lottieUselessApks!!.visibility = View.VISIBLE
            } else if (num == 3) {
                binding.lottieLogtemp!!.visibility = View.VISIBLE
            } else if (num == 4) {
                binding.lottieEmptyFolder!!.visibility = View.VISIBLE
            } else if (num == 5) {
                binding.lottieUninstalled!!.visibility = View.VISIBLE
            }
        } else {
            if (num == 1) {
                binding.lottieTrash!!.visibility = View.INVISIBLE
            } else if (num == 2) {
                binding.lottieUselessApks!!.visibility = View.INVISIBLE
            } else if (num == 3) {
                binding.lottieLogtemp!!.visibility = View.INVISIBLE
            } else if (num == 4) {
                binding.lottieEmptyFolder!!.visibility = View.INVISIBLE
            } else if (num == 5) {
                binding.lottieUninstalled!!.visibility = View.INVISIBLE
            }
        }
    }

    fun setApksRecyclerView(list: List<FileModel>) {
        val lm1 = LinearLayoutManager(this)
        lm1.orientation = LinearLayoutManager.VERTICAL
        val list1: List<FileModel> = ArrayList(list)
        val list2: List<FileModel> = ArrayList(list)
        apksAdapter = JunkAdapter1(this@JunkActivity, list1, list2, "apk", apkTotal)
        binding.recyclerViewApks.layoutManager = lm1
        binding.recyclerViewApks.adapter = apksAdapter
//        apksAdapter.setSendData(this)
        apksAdapter?.setSelectAll(this)
        apksAdapter?.submitList(list)
        if (list.isEmpty()) {
            binding.imageViewApksSelect.setImageResource(R.drawable.ic_radio_unselect)
        } else {
            binding.imageViewApksSelect.setImageResource(R.drawable.ic_test_check)
        }
        apkTotal = apksAdapter?.allTotal!!
        val size = Utils.getDataSizeWithPrefix(applicationContext, apkTotal)
        binding.textViewApksSize.text = "${size.first} ${size.second}"
        binding.imageViewApksSelectClick.setOnClickListener { v: View? ->
            if (apksSelectedAll) {
                binding.imageViewApksSelect.setImageResource(R.drawable.ic_radio_unselect)
                apksAdapter?.clearList()
                apksSelectedAll = false
//                total=total-apkTotal
                //total = apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal
                setSelectedAdapterJunkSize()
//                val size = Utils.getDataSizeWithPrefix(applicationContext, total)
//
//                binding.textViewJunkSize.setText(
//                    String.format(
//                        Locale.ENGLISH,
//                        "%.2f",
//                        size.first.toFloat()
//                    )
//                )
//                binding.textViewJunkPrefix?.setText(size.second)
            } else {
                apksSelectedAll = true
                apksAdapter!!.selectAll()
                binding.imageViewApksSelect.setImageResource(R.drawable.ic_test_check)
//                total=total+apkTotal
//                total = apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal

                setSelectedAdapterJunkSize()
//                val size = Utils.getDataSizeWithPrefix(applicationContext, total)
//                binding.textViewJunkSize.setText(
//                    String.format(
//                        Locale.ENGLISH,
//                        "%.2f",
//                        size.first.toFloat()
//                    )
//                )
//                binding.textViewJunkPrefix?.setText(size.second)
            }
        }
        if (apksList.isEmpty()) {
            binding.clApksHead.visibility = View.GONE
            binding.imageViewApksUpDown.visibility = View.INVISIBLE
            binding.imageViewApksSelect.visibility = View.INVISIBLE
            binding.imageViewApksUpDownClick.visibility = View.INVISIBLE
            binding.imageViewApksSelectClick.visibility = View.INVISIBLE
            binding.textViewApksSize.visibility = View.INVISIBLE
        } else {
            binding.clApksHead.visibility = View.VISIBLE
            binding.imageViewApksUpDown.visibility = View.VISIBLE
            binding.imageViewApksSelect.visibility = View.VISIBLE
            binding.imageViewApksUpDownClick.visibility = View.VISIBLE
            binding.imageViewApksSelectClick.visibility = View.VISIBLE
            binding.textViewApksSize.visibility = View.VISIBLE
        }
    }

    fun setTempRecyclerView(list: List<FileModel>) {
        val lm1 = LinearLayoutManager(this)
        lm1.orientation = LinearLayoutManager.VERTICAL
        val list1: List<FileModel> = ArrayList(list)
        val list2: List<FileModel> = ArrayList(list)
        tempAdapter = JunkAdapter1(this@JunkActivity, list1, list2, "temp", tempTotal)
        binding.recyclerViewTemps.layoutManager = lm1
        binding.recyclerViewTemps!!.adapter = tempAdapter
//        tempAdapter.setSendData(this)
        tempAdapter?.setSelectAll(this)
        tempAdapter?.submitList(list)
        if (!list.isEmpty()) {
            binding.imageViewTempSelect.setImageResource(R.drawable.ic_test_check)
        }
        tempTotal = tempAdapter!!.allTotal
//        binding.textViewTempSize.setText(
//            Formatter.formatFileSize(
//                this@JunkActivity,
//                tempTotal.toLong()
//            )
//        )

//        binding.textViewTempSize.setText("${String.format(Locale.ENGLISH,"%.2f", tempTotal)} ${getString(R.string.mb)}")

        val size = Utils.getDataSizeWithPrefix(applicationContext, tempTotal)
        binding.textViewTempSize.text = "${size.first} ${size.second}"
        binding.imageViewTempSelectClick.setOnClickListener { v: View? ->
            if (!tempSelectedAll) {
                tempSelectedAll = true
                binding.imageViewTempSelect.setImageResource(R.drawable.ic_test_check)
                tempAdapter!!.selectAll()
//                total=total+tempTotal
//                total = apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal

                setSelectedAdapterJunkSize()
//                val size = Utils.getDataSizeWithPrefix(applicationContext, total)
//                binding.textViewJunkSize.setText(
//                    String.format(
//                        Locale.ENGLISH,
//                        "%.2f",
//                        size.first.toFloat()
//                    )
//                )
//                binding.textViewJunkPrefix?.setText(size.second)
            } else {
                tempAdapter!!.clearList()
                tempSelectedAll = false
                binding.imageViewTempSelect.setImageResource(R.drawable.ic_radio_unselect)
//                total=total-tempTotal
//                total = apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal

                setSelectedAdapterJunkSize()
//                val size = Utils.getDataSizeWithPrefix(applicationContext, total)
//                binding.textViewJunkSize.setText(
//                    String.format(
//                        Locale.ENGLISH,
//                        "%.2f",
//                        size.first.toFloat()
//                    )
//                )
//                binding.textViewJunkPrefix?.setText(size.second)
            }
        }
        if (tempList.isEmpty()) {
            binding.clTempHead!!.visibility = View.GONE
            binding.imageViewTempUpDown!!.visibility = View.INVISIBLE
            binding.imageViewTempSelect!!.visibility = View.INVISIBLE
            binding.imageViewTempUpDownClick!!.visibility = View.INVISIBLE
            binding.imageViewTempSelectClick!!.visibility = View.INVISIBLE
            binding.textViewTempSize!!.visibility = View.INVISIBLE
        } else {
            binding.clTempHead!!.visibility = View.VISIBLE
            binding.imageViewTempUpDown!!.visibility = View.VISIBLE
            binding.imageViewTempSelect!!.visibility = View.VISIBLE
            binding.imageViewTempUpDownClick!!.visibility = View.VISIBLE
            binding.imageViewTempSelectClick!!.visibility = View.VISIBLE
            binding.textViewTempSize!!.visibility = View.VISIBLE
        }
    }

    fun setTrashRecyclerView(list: List<FileModel>) {
        val lm3 = LinearLayoutManager(this)
        lm3.orientation = LinearLayoutManager.VERTICAL
        val list1: List<FileModel> = ArrayList(list)
        val list2: List<FileModel> = ArrayList(list)
        trashAdapter = JunkAdapter1(this@JunkActivity, list1, list2, "trash", trashTotal)
        binding.recyclerViewTrash.layoutManager = lm3
        binding.recyclerViewTrash!!.adapter = trashAdapter
//        trashAdapter.setSendData(this)
        trashAdapter?.setSelectAll(this)
        trashAdapter?.submitList(list)
        if (!list.isEmpty()) {
            binding.imageViewTrashSelect.setImageResource(R.drawable.ic_test_check)
        }
        trashTotal = trashAdapter!!.allTotal
//        binding.textViewTrashSize.setText(
//            Formatter.formatFileSize(
//                this@JunkActivity,
//                trashTotal.toLong()
//            )
//        )
//        binding.textViewTrashSize.setText("${String.format(Locale.ENGLISH,"%.2f", trashTotal)} ${getString(R.string.mb)}")
        val size = Utils.getDataSizeWithPrefix(applicationContext, trashTotal)
        binding.textViewTrashSize.text = "${size.first} ${size.second}"
        binding.imageViewTrashSelectClick.setOnClickListener { v: View? ->
            if (!trashSelectedAll) {
                binding.imageViewTrashSelect.setImageResource(R.drawable.ic_test_check)
                trashAdapter!!.selectAll()
                trashSelectedAll = true
//                total=total+trashTotal
//                total = apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal

                setSelectedAdapterJunkSize()
//                val size = Utils.getDataSizeWithPrefix(applicationContext, total)
//                binding.textViewJunkSize.setText(
//                    String.format(
//                        Locale.ENGLISH,
//                        "%.2f",
//                        size.first.toFloat()
//                    )
//                )
//                binding.textViewJunkPrefix?.setText(size.second)
            } else {
                trashAdapter!!.clearList()
                trashSelectedAll = false
                binding.imageViewTrashSelect.setImageResource(R.drawable.ic_radio_unselect)
//                total=total-trashTotal
//                total = apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal

                setSelectedAdapterJunkSize()
//                val size = Utils.getDataSizeWithPrefix(applicationContext, total)
//                binding.textViewJunkSize.setText(
//                    String.format(
//                        Locale.ENGLISH,
//                        "%.2f",
//                        size.first.toFloat()
//                    )
//                )
//                binding.textViewJunkPrefix?.setText(size.second)
            }
        }
        if (trashList.isEmpty()) {
            binding.clTrashHead!!.visibility = View.GONE
            binding.imageViewTrashUpDownClick!!.visibility = View.INVISIBLE
            binding.imageViewTrashUpDown!!.visibility = View.INVISIBLE
            binding.textViewTrashSize!!.visibility = View.INVISIBLE
            binding.imageViewTrashSelect!!.visibility = View.INVISIBLE
            binding.imageViewTrashSelectClick!!.visibility = View.INVISIBLE
        } else {
            binding.clTrashHead!!.visibility = View.VISIBLE
            binding.imageViewTrashUpDownClick!!.visibility = View.VISIBLE
            binding.imageViewTrashUpDown!!.visibility = View.VISIBLE
            binding.textViewTrashSize!!.visibility = View.VISIBLE
            binding.imageViewTrashSelect!!.visibility = View.VISIBLE
            binding.imageViewTrashSelectClick!!.visibility = View.VISIBLE
        }
    }

    fun setEmptyRecyclerView(list: List<FileModel>) {
        val lm3 = LinearLayoutManager(this)
        lm3.orientation = LinearLayoutManager.VERTICAL
        val list1: List<FileModel> = ArrayList(list)
        val list2: List<FileModel> = ArrayList(list)
        emptyAdapter = JunkAdapter1(this@JunkActivity, list1, list2, "empty", emptyTotal)
        binding.recyclerViewEmpty.layoutManager = lm3
        binding.recyclerViewEmpty!!.adapter = emptyAdapter
//        emptyAdapter.setSendData(this)
        emptyAdapter?.setSelectAll(this)
        emptyAdapter?.submitList(list)
        if (!list.isEmpty()) {
            binding.imageViewEmptySelect.setImageResource(R.drawable.ic_test_check)
        }
        emptyTotal = emptyAdapter!!.allTotal
//        binding.textViewEmptySize.setText(
//            Formatter.formatFileSize(
//                this@JunkActivity,
//                emptyTotal.toLong()
//            )
//        )
//        binding.textViewEmptySize.setText("${String.format(Locale.ENGLISH,"%.2f", emptyTotal)} ${getString(R.string.mb)}")

        val size = Utils.getDataSizeWithPrefix(applicationContext, emptyTotal)
        binding.textViewEmptySize.text = "${size.first} ${size.second}"

        binding.imageViewEmptySelectClick.setOnClickListener { v: View? ->
            if (!emptySelectedAll) {
                binding.imageViewEmptySelect.setImageResource(R.drawable.ic_test_check)
                emptyAdapter!!.selectAll()
                emptySelectedAll = true
//                total=total+emptyTotal
//                total = apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal

                setSelectedAdapterJunkSize()
//                val size = Utils.getDataSizeWithPrefix(applicationContext, total)
//                binding.textViewJunkSize.setText(
//                    String.format(
//                        Locale.ENGLISH,
//                        "%.2f",
//                        size.first.toFloat()
//                    )
//                )
//                binding.textViewJunkPrefix?.setText(size.second)
            } else {
                emptyAdapter!!.clearList()
                emptySelectedAll = false
                binding.imageViewEmptySelect.setImageResource(R.drawable.ic_radio_unselect)
//                total=total-emptyTotal
//                total = apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal

                setSelectedAdapterJunkSize()
//                val size = Utils.getDataSizeWithPrefix(applicationContext, total)
//                binding.textViewJunkSize.setText(
//                    String.format(
//                        Locale.ENGLISH,
//                        "%.2f",
//                        size.first.toFloat()
//                    )
//                )
//                binding.textViewJunkPrefix?.setText(size.second)
            }
        }
        if (emptyList.isEmpty()) {
            binding.clEmptyHead!!.visibility = View.GONE
            binding.imageViewEmptyUpDownClick!!.visibility = View.INVISIBLE
            binding.imageViewEmptyUpDown!!.visibility = View.INVISIBLE
            binding.textViewEmptySize!!.visibility = View.INVISIBLE
            binding.imageViewEmptySelect!!.visibility = View.INVISIBLE
            binding.imageViewEmptySelectClick!!.visibility = View.INVISIBLE
        } else {
            binding.clEmptyHead!!.visibility = View.VISIBLE
            binding.imageViewEmptyUpDownClick!!.visibility = View.VISIBLE
            binding.imageViewEmptyUpDown!!.visibility = View.VISIBLE
            binding.textViewEmptySize!!.visibility = View.VISIBLE
            binding.imageViewEmptySelect!!.visibility = View.VISIBLE
            binding.imageViewEmptySelectClick!!.visibility = View.VISIBLE
        }
    }

    fun setUninstalledRecyclerView(list: List<FileModel>) {
        val lm3 = LinearLayoutManager(this)
        lm3.orientation = LinearLayoutManager.VERTICAL
        val list1: List<FileModel> = ArrayList(list)
        val list2: List<FileModel> = ArrayList(list)
        uninstalledAdapter =
            JunkAdapter1(this@JunkActivity, list1, list2, "uninstall", uninstalledTotal)
        binding.recyclerViewUninstalled.layoutManager = lm3
        binding.recyclerViewUninstalled!!.adapter = uninstalledAdapter
//        uninstalledAdapter.setSendData(this)
        uninstalledAdapter?.setSelectAll(this)
        uninstalledAdapter?.submitList(list)
        if (!list.isEmpty()) {
            binding.imageViewUninstalledSelect.setImageResource(R.drawable.ic_test_check)
        }
        uninstalledTotal = uninstalledAdapter!!.allTotal
//        binding.textViewUninstalledSize.setText(
//            Formatter.formatFileSize(
//                this@JunkActivity,
//                uninstalledTotal.toLong()
//            )
//        )
//        binding.textViewUninstalledSize.setText("${String.format(Locale.ENGLISH,"%.2f", uninstalledTotal)} ${getString(R.string.mb)}")

        val size = Utils.getDataSizeWithPrefix(applicationContext, uninstalledTotal)
        binding.textViewUninstalledSize.text = "${size.first} ${size.second}"
        binding.imageViewUninstalledSelectClick.setOnClickListener { v: View? ->
            if (!uninstalledSelectedAll) {
                binding.imageViewUninstalledSelect.setImageResource(R.drawable.ic_test_check)
                uninstalledAdapter!!.selectAll()
                uninstalledSelectedAll = true
//                total=total+uninstalledTotal
//                total = apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal
                setSelectedAdapterJunkSize()
//                val size = Utils.getDataSizeWithPrefix(applicationContext, total)
//                binding.textViewJunkSize.setText(
//                    String.format(
//                        Locale.ENGLISH,
//                        "%.2f",
//                        size.first.toFloat()
//                    )
//                )
//                binding.textViewJunkPrefix.setText(size.second)
            } else {
                uninstalledAdapter!!.clearList()
                uninstalledSelectedAll = false
                binding.imageViewUninstalledSelect.setImageResource(R.drawable.ic_radio_unselect)
//                total=total-uninstalledTotal
//                total = apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal

                setSelectedAdapterJunkSize()
//                val size = Utils.getDataSizeWithPrefix(applicationContext, total)
//                binding.textViewJunkSize.setText(
//                    String.format(
//                        Locale.ENGLISH,
//                        "%.2f",
//                        size.first.toFloat()
//                    )
//                )
//                binding.textViewJunkPrefix?.setText(size.second)
            }
        }
        if (uninstalledList.isEmpty()) {
            binding.clUninstalledHead.visibility = View.GONE
            binding.imageViewUninstalledUpDownClick.visibility = View.INVISIBLE
            binding.imageViewUninstalledUpDown.visibility = View.INVISIBLE
            binding.textViewUninstalledSize.visibility = View.INVISIBLE
            binding.imageViewUninstalledSelect.visibility = View.INVISIBLE
            binding.imageViewUninstalledSelectClick.visibility = View.INVISIBLE
        } else {
            binding.clUninstalledHead.visibility = View.VISIBLE
            binding.imageViewUninstalledUpDownClick.visibility = View.VISIBLE
            binding.imageViewUninstalledUpDown.visibility = View.VISIBLE
            binding.textViewUninstalledSize.visibility = View.VISIBLE
            binding.imageViewUninstalledSelect.visibility = View.VISIBLE
            binding.imageViewUninstalledSelectClick.visibility = View.VISIBLE
        }
    }

    fun junkCalculating() {
        //pre execute
        scanning = false
        binding.clCalculating.visibility = View.INVISIBLE
        binding.scrollViewJunkCalculated.visibility = View.VISIBLE
//        binding.textViewFilePath.setVisibility(View.GONE)
//                    if(stopDialog?.isShowing!!) stopDialog?.cancel()

        binding.clBlur.visibility = View.GONE
        binding.txtScan.text = getString(R.string.clean)
        binding.btnScan.beVisible()
        binding.progressLoading.beGone()
        binding.constraintLayout2.beGone()

        if (stopDialog != null) {
            if (stopDialog?.isShowing!!) stopDialog?.cancel()
        }

        binding.textViewStatus.beVisible()
        binding.constraintLayout2.beVisible()
        binding.textViewStatus.text = "Completed"

        setSelectedAdapterJunkSize()
        countJunkSize()

        binding.textViewFilePath.text =
            binding.textViewJunkSize.text.toString() + "" + binding.textViewJunkPrefix.text.toString()
        binding.selectedSize.text = "(${binding.textViewFilePath.text})"

        val executor: Executor = Executors.newSingleThreadExecutor()
        val handler = Handler(Looper.getMainLooper())
        executor.execute {
            handler.post {
                val size = Utils.getDataSizeWithPrefix(
                    applicationContext,
                    apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal
                )
                setSizeAnimation(size)
            }
        }

        if (total <= 0) scanningFinish(total)
    }

    private fun setSelectedAdapterJunkSize() {

        total =
            apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal
        //total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal
        val size = Utils.getDataSizeWithPrefix(applicationContext, total)
        if (total > 0) {
            var strFinal = String.format(
                Locale.ENGLISH,
                "%.2f",
                size.first.toFloat()
            ) + " " + size.second
            binding.selectedSize.text = "($strFinal)"
        } else {
            binding.selectedSize.text = ""
        }
    }

    private fun setSelectedJunkSize() {

        total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal
        val size = Utils.getDataSizeWithPrefix(applicationContext, total)
        binding.selectedSize.text = String.format(
            Locale.ENGLISH,
            "%.2f",
            size.first.toFloat()
        ) + " " + size.second
    }

    private fun countJunkSize() {

        var junkTotal: Double = 0.0
        for (apk in apksList) {
            junkTotal += apk.size
        }

        for (temp in tempList) {
            junkTotal += temp.size
        }

        for (trash in trashList) {
            junkTotal += trash.size
        }

        for (empty in emptyList) {
            junkTotal += empty.size
        }


        for (uninstall in uninstalledList) {
            junkTotal += uninstall.size
        }

        val size = Utils.getDataSizeWithPrefix(applicationContext, junkTotal)

        setSizeAnimation(size)

    }

    private fun cleanProgressAnimation(total: Double) {
        scanning = false
        binding.clBlur.visibility = View.GONE
        setSelectedAdapterJunkSize()

        this.total =
            apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal
        val size = Utils.getDataSizeWithPrefix(applicationContext, this.total)
        setSizeAnimation(size)

        if (total >= 20) {
            scanningFinish()
        } else {
            scanningFinish()
        }

    }

    @SuppressLint("DefaultLocale", "SetTextI18n")
    private fun setBackgroundColorAnimation(from: Int, to: Int) {
        val animator = ValueAnimator.ofInt(from, to)
        animator.duration = 5000
        animator.setEvaluator(ArgbEvaluator())
        animator.addUpdateListener { valueAnimator: ValueAnimator ->
            val value: Int = valueAnimator.animatedValue as Int
            binding.clCalculatingSuper.setBackgroundColor(value)
        }
        animator.start()
    }

    @SuppressLint("DefaultLocale", "SetTextI18n")
    private fun setSizeAnimation(size: Pair<String, String>) {

        Handler(Looper.getMainLooper()).post {
            binding.textViewJunkSize?.text = String.format(
                Locale.ENGLISH,
                "%.2f",
                size.first.toDouble()
            )
            binding.textViewJunkPrefix?.text = size.second

        }
    }

//    @SuppressLint("DefaultLocale")
//    private fun setApksPathAnimation(list: List<FileModel>, empty: Boolean) {
//        Handler(Looper.getMainLooper()).post {
//            Handler(Looper.getMainLooper()).postDelayed(
//                Runnable { apkInterface!!.done(true) },
//                3000
//            )
//        }
//    }

    override fun onBackPressed() {
        if (!scanning) {
            if (getTempFiles?.status == AsyncTask.Status.RUNNING) {
                getTempFiles?.cancel(true)
            }
            if (getApkFiles?.status == AsyncTask.Status.RUNNING) {
                getApkFiles?.cancel(true)
            }
            if (getTrashFiles?.status == AsyncTask.Status.RUNNING) {
                getTrashFiles?.cancel(true)
            }
            if (getEmptyFiles?.status == AsyncTask.Status.RUNNING) {
                getEmptyFiles?.cancel(true)
            }
            if (getUninstalledFiles?.status == AsyncTask.Status.RUNNING) {
                getUninstalledFiles?.cancel(true)
            }
            scanning = false

            super.onBackPressed()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//            }
        } else {
            dialogStopScan()
        }
    }

//    override fun data(data: String) {}

    override fun selectAll(isSelectAll: Boolean, type: String) {
        Log.e(mTAG, "selectAll-type:$type")

        if (apksAdapter != null) apkTotal = apksAdapter?.allTotal!!
        if (tempAdapter != null) tempTotal = tempAdapter?.allTotal!!
        if (trashAdapter != null) trashTotal = trashAdapter?.allTotal!!
        if (emptyAdapter != null) emptyTotal = emptyAdapter?.allTotal!!
        if (uninstalledAdapter != null) uninstalledTotal = uninstalledAdapter?.allTotal!!

        if (type.equals("apk", true)) {
            if (isSelectAll) {
                binding.imageViewApksSelect.setImageResource(R.drawable.ic_test_check)
                apksSelectedAll = true
            } else {
                apksSelectedAll = false
                binding.imageViewApksSelect.setImageResource(R.drawable.ic_radio_unselect)
            }
            setSelectedJunkSize()
        } else if (type.equals("temp", true)) {
            if (isSelectAll) {
                binding.imageViewTempSelect.setImageResource(R.drawable.ic_test_check)
                tempSelectedAll = true
            } else {
                tempSelectedAll = false
                binding.imageViewTempSelect.setImageResource(R.drawable.ic_radio_unselect)
            }
            setSelectedJunkSize()

        } else if (type.equals("trash", true)) {
            if (isSelectAll) {
                binding.imageViewTrashSelect.setImageResource(R.drawable.ic_test_check)
                trashSelectedAll = true
            } else {
                trashSelectedAll = false
                binding.imageViewTrashSelect.setImageResource(R.drawable.ic_radio_unselect)
            }
            setSelectedJunkSize()

        } else if (type.equals("empty", true)) {
            if (isSelectAll) {
                binding.imageViewEmptySelect.setImageResource(R.drawable.ic_test_check)
                emptySelectedAll = true
            } else {
                emptySelectedAll = false
                binding.imageViewEmptySelect.setImageResource(R.drawable.ic_radio_unselect)
            }
            setSelectedJunkSize()

        } else {
            if (isSelectAll) {
                binding.imageViewUninstalledSelect.setImageResource(R.drawable.ic_test_check)
                uninstalledSelectedAll = true
            } else {
                uninstalledSelectedAll = false
                binding.imageViewUninstalledSelect.setImageResource(R.drawable.ic_radio_unselect)
            }
            setSelectedJunkSize()
        }
    }

    fun scanningFinish(total: Double = 1.0) {
        scanning = false
        val calendar = Calendar.getInstance()
        calendar.add(Calendar.MINUTE, 2)

        if (stopDialog != null) {
            if (stopDialog?.isShowing!!) stopDialog?.cancel()
        }

//        binding.constraintLayout2!!.visibility = View.GONE
//        binding.textViewStatus!!.visibility = View.GONE
//        binding.textViewFilePath!!.visibility = View.GONE

    }
}