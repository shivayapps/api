package com.photogallery.edit

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Point
import android.graphics.PorterDuff
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.os.persistableBundleOf
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.photogallery.R
import com.photogallery.activities.HomeActivity
import com.photogallery.base.BaseActivity
import com.photogallery.database.AppDatabase


import com.photogallery.edit.AdjustActivity
import com.photogallery.edit.CropActivity
import com.photogallery.edit.DoodleActivity
import com.photogallery.edit.FilterActivity
import com.photogallery.edit.StickerActivity

import com.photogallery.databinding.ActivityEditImageBinding
import com.photogallery.dialog.ActionConfirmationDialog
import com.photogallery.dialog.EditConfirmationDialog
import com.photogallery.dialog.ProgressDialog
import com.photogallery.extension.toast
import com.photogallery.extension.updateStatusBarColor

import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences
import com.photogallery.utils.StorageUtils
import com.photogallery.utils.Utils
import com.photogallery.utils.sendEvent

import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers

import java.io.File
import java.text.SimpleDateFormat
import java.util.Date

class EditImageActivity : BaseActivity() {

    lateinit var preferences: Preferences
    lateinit var binding: ActivityEditImageBinding
    var imagePath = ""
    var mainImagePath = ""
    var saveImageName = ""
    var isEditImage = false
    var isFromFiles = false

    override fun onCreate(savedInstanceState: Bundle?) {
        applyStatusBar = false
        super.onCreate(savedInstanceState)
        binding = ActivityEditImageBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        updateStatusBarColor(Color.parseColor("#151515"))
        isFromFiles = intent.getBooleanExtra("isFromFiles", false)

        preferences = Preferences(this)

        intView()
    }

    private fun intView() {

        imagePath = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_PATH) ?: ""
        mainImagePath = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_PATH) ?: ""
        binding.txtTitle.text = getString(R.string.editor)

        val width = getScreenWidth()
//        Log.e("EditTag", "width $width")

        imageLoad()
        intListener()

        val timeStamp = SimpleDateFormat("HHmmss_ddMyy").format(Date())
        saveImageName = "IMG_$timeStamp.jpg"

        Thread {
            val size = mainImagePath.getImageResolution()
            Log.e("EditTag", "width $width imageWidth ${size.x}")
            if (size.x > width) {

                Log.e("EditTag", "resize image")
                val ratio: Float = size.x / size.y.toFloat()
                val height = (width / ratio).toInt()
                val newBitmap =
                    Glide.with(this.applicationContext).asBitmap()
                        .load(mainImagePath)
                        .submit(width, height)
                        .get()
                val imageResizePath = saveEditImage(newBitmap, "IMG_Resize$timeStamp.jpg", 40)
                if (!imageResizePath.isNullOrEmpty())
                    imagePath = imageResizePath
                runOnUiThread {
                    Log.e("EditTag", "resize image successfully")
                }
            }
        }.start()
    }

    private fun imageLoad() {
        Glide.with(this)
            .load(imagePath)
            .diskCacheStrategy(DiskCacheStrategy.NONE)
            .skipMemoryCache(true)
            .into(binding.imageDisplay)
    }

    var editLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val path = result.data?.getStringExtra(Constant.EXTRA_EDIT_SAVE_IMAGE)
                if (path != null) {
                    imagePath = path
                    isEditImage = true
                    binding.ivDone.alpha = 1.0f
                }
                imageLoad()
            }
        }

    fun String.getImageResolution(): Point {
        val options = BitmapFactory.Options()
        options.inJustDecodeBounds = true
        BitmapFactory.decodeFile(this, options)

        val width = options.outWidth
        val height = options.outHeight
        return if (width > 0 && height > 0) {
            Point(options.outWidth, options.outHeight)
        } else {
            Point(0, 0)
        }
    }


    override fun onBackPressed() {
        if (isEditImage) {
            val exitDialog = ActionConfirmationDialog(
                this,
                getString(R.string.discard),
                getString(R.string.exit_edit_msg),
                getString(R.string.ok),
                positiveBtnClickListener = {
                    if (isFromFiles) {
                        val intentHome = Intent(this, HomeActivity::class.java)
                        intentHome.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        startActivity(intentHome)
                    } else super.onBackPressed()
                })
            exitDialog.show()
        } else if (isFromFiles) {
            val intentHome = Intent(this, HomeActivity::class.java)
            intentHome.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(intentHome)
        } else
            super.onBackPressed()
    }

    override fun onPause() {
        super.onPause()
    }

    override fun onResume() {
        applyStatusBar = false
        super.onResume()

    }

    private fun intListener() {
        binding.ivDone.alpha = 0.5f
        binding.icBack.setOnClickListener { onBackPressed() }
        binding.ivDone.setOnClickListener {
            if (mainImagePath.isNotEmpty() && imagePath.isNotEmpty() && isEditImage) {
//                if (!preferences.isConfirmEditAction) {

                saveImage(1)
//                val confirmDialog = EditConfirmationDialog(
//                    this,
//                    btnClickListener = { action ->
//                        if (action != 2) {
//                            saveImage(action)
//                        }
//
//                    })
//                confirmDialog.show()
            } else
                binding.ivDone.isEnabled = true
        }


        binding.btnFilter.setOnClickListener {
            editLauncher.launch(
                Intent(
                    this,
                    FilterActivity::class.java
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_PATH,
                    imagePath
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_NAME,
                    saveImageName
                )
            )
        }

        binding.btnAdjust.setOnClickListener {
            editLauncher.launch(
                Intent(
                    this,
                    AdjustActivity::class.java
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_PATH,
                    imagePath
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_NAME,
                    saveImageName
                )
            )
        }

        binding.btnCrop.setOnClickListener {
            editLauncher.launch(
                Intent(
                    this,
                    CropActivity::class.java
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_PATH,
                    imagePath
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_NAME,
                    saveImageName
                )
            )
        }

        binding.btnDoodle.setOnClickListener {
            editLauncher.launch(
                Intent(
                    this,
                    DoodleActivity::class.java
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_PATH,
                    imagePath
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_NAME,
                    saveImageName
                )
            )
        }

//        binding.btnPerspective.setOnClickListener {
//            editLauncher.launch(
//                Intent(
//                    this,
//                    PerspectiveActivity::class.java
//                ).putExtra(
//                    Constant.EXTRA_EDIT_IMAGE_PATH,
//                    imagePath
//                ).putExtra(
//                    Constant.EXTRA_EDIT_IMAGE_NAME,
//                    saveImageName
//                )
//            )
//        }

        binding.btnText.setOnClickListener {
            editLauncher.launch(
                Intent(
                    this,
                    StickerActivity::class.java
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_PATH,
                    imagePath
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_NAME,
                    saveImageName
                )
            )
        }
    }

    private fun finishThis() {
        if (isFromFiles) {
            val intentHome = Intent(this, HomeActivity::class.java)
            intentHome.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(intentHome)
        } else {
            finish()
        }
    }

    private fun saveImage(action: Int) {

        val copyFile = File(imagePath)
        var targetFile = File(mainImagePath)
//        var targetFolder = File(mainImagePath.getParentPath())
        var targetFolder = File(Constant.EDIT_PATH)

//        if (action == 0) {//replace
//            try {
//                Glide.get(this).clearMemory()
//                Glide.get(this).clearDiskCache()
//            } catch (e: Exception) {
//            }
//
//            val dataBase = AppDatabase.getInstance(this)
//            mainImagePath
//            Utils.deleteFile(this, mainImagePath, dataBase, false)
//            MediaScannerConnection.scanFile(
//                this,
//                arrayOf<String>(mainImagePath),
//                null
//            ) { path: String?, uri: Uri? -> }
//            //saveImage(action)
//        } else
        if (action == 1) {//copy
            //saveImage(action)
            targetFolder = File(Constant.EDIT_PATH)
            if (!targetFolder.exists())
                targetFolder.mkdirs()

            val separated =
                copyFile.name.split("\\.".toRegex()).dropLastWhile { it.isEmpty() }
                    .toTypedArray()
            val name = separated[0]
            val type = separated[1]

            val targetPath =
                targetFolder.path + "/" + name + "_" + System.currentTimeMillis() + "." + type
//            val targetPath = targetFolder.path + File.separator + copyFileName
            targetFile = File(targetPath)
        }

        val copyFiles = java.util.ArrayList<String>()
        val progressDialog = ProgressDialog(
            this@EditImageActivity,
            0,
            0,
            getString(R.string.saving),
            ""
        )
        progressDialog.setCancelable(false)
        progressDialog.show()

        Observable.fromCallable {
            if (copyFile.exists()) {
                val isCopied: Boolean =
                    StorageUtils.copyFile(
                        copyFile,
                        targetFile,
                        this
                    )
                if (isCopied) {
                    copyFiles.add(targetFile.path)
                }
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    if (!isFinishing && !isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()
                    }
                    toast("Image saved at ${targetFile.path}")
                    MediaScannerConnection.scanFile(
                        this,
                        arrayOf<String>(targetFile.path),
                        null
                    ) { path: String?, uri: Uri? -> }
                    sendEvent("get_data")
                    preferences.refreshMedia = true
//                    runOnUiThread {
//                        val glide = Glide.get(applicationContext)
//                        glide.clearDiskCache()
//                        glide.clearMemory()
//                    }
                    finishThis()
                }
            }
            .onErrorReturn { false }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    if (!isFinishing && !isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()
                    }
                    toast("Image saved at ${targetFile.path}")
                    MediaScannerConnection.scanFile(
                        this,
                        arrayOf<String>(targetFile.path),
                        null
                    ) { path: String?, uri: Uri? -> }
                    sendEvent("get_data")
                    preferences.refreshMedia = true
                    finishThis()
                }
            }
    }
}