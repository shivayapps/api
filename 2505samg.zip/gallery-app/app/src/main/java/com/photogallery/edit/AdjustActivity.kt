package com.photogallery.edit

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.photogallery.R
import com.photogallery.base.BaseActivity
import com.photogallery.databinding.ActivityAdjustBinding
import com.photogallery.dialog.ProgressDialog
//import com.photogallery.edit.model.AdjustModel
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.extension.toast
import com.photogallery.extension.updateStatusBarColor
import com.photogallery.utils.Constant
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AdjustActivity : BaseActivity() {

    lateinit var binding: ActivityAdjustBinding
    private var imagePath = ""
    private var saveImageName = ""
    private var sourceImgBitmap: Bitmap? = null

    //    private var adjustList: ArrayList<AdjustModel> = ArrayList()
//    private lateinit var adjustModel: AdjustModel
    private var currentPos = -1
    private val brightnessPos = 0
    private val contrastPos = 1
    private val saturationPos = 2
    private val sharpenPos = 3

    private var brightnessLevel = 0f
    private var contrastLevel = 1f
    private var saturationLevel = 1f
    private var sharpenLevel = 1f

    val BASIC_FILTER_CONFIG =
        "@adjust brightness 0 @adjust contrast 1 @adjust saturation 1 @adjust sharpen 0"

    override fun onCreate(savedInstanceState: Bundle?) {
        applyStatusBar = false
        super.onCreate(savedInstanceState)
        binding = ActivityAdjustBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        updateStatusBarColor(Color.parseColor("#131624"))

        intView()
        loadBanner()
    }

    var isAdLoaded = false
    override fun onResume() {
        applyStatusBar = false
        super.onResume()
    }

    override fun onPause() {
        super.onPause()
    }

    private fun loadBanner() {

//        val isFirstSession=Preferences(this).splashCounter==1
//        val adId=if(isFirstSession) getString(R.string.b_editActivity) else getString(R.string.b_editActivity2)
//        BannerAdHelper.showBanner(this, binding.layoutBanner.mFLAd,binding.llAdPlace,adId,
//            AdCache.editAdView,{ isLoaded, adView, message ->
//                mAdView=adView
//                AdCache.editAdView=adView
//            isAdLoaded=isLoaded
//        })
    }

    private fun intView() {


        imagePath = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_PATH) ?: ""
        saveImageName = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_NAME) ?: ""

        binding.txtTitle.text = getString(R.string.Contrast)


        intListener()

        Glide.with(this)
            .asBitmap()
            .load(imagePath)
            .into(object : CustomTarget<Bitmap>() {

                override fun onResourceReady(
                    resource: Bitmap,
                    transition: Transition<in Bitmap>?
                ) {

                    sourceImgBitmap = resource

                    binding.editorView.setBitmap(resource)
                }

                override fun onLoadCleared(
                    placeholder: Drawable?
                ) {
                }
            })

//        binding.mainImageView.doOnPreDraw {
//            Log.e("EDITTAG", "doOnPreDraw")
//        }

        updateAdjustSelected(0)
    }

    private fun intListener() {
        binding.icBack.setOnClickListener { onBackPressed() }
        binding.ivDone.setOnClickListener {

            lifecycleScope.launch {

                val progressDialog = ProgressDialog(
                    this@AdjustActivity,
                    0,
                    0,
                    getString(R.string.saving),
                    ""
                )

                progressDialog.show()

                val bitmap = binding.editorView.getResultBitmap()

                if (bitmap == null) {

                    progressDialog.dismiss()

                    toast(getString(R.string.image_editing_failed))

                    return@launch
                }

                val imagePath = withContext(Dispatchers.IO) {
                    saveEditImage(
                        bitmap,
                        saveImageName
                    )
                }

                progressDialog.dismiss()

                if (imagePath != null) {

                    setResult(
                        RESULT_OK,
                        Intent().apply {

                            putExtra(
                                Constant.EXTRA_EDIT_SAVE_IMAGE,
                                imagePath
                            )
                        }
                    )
                }

                finish()
            }
        }

        seekListeners()

        binding.btnBrightness.setOnClickListener { updateAdjustSelected(brightnessPos) }
        binding.btnContrast.setOnClickListener { updateAdjustSelected(contrastPos) }
        binding.btnSaturation.setOnClickListener { updateAdjustSelected(saturationPos) }
        binding.btnSharpen.setOnClickListener { updateAdjustSelected(sharpenPos) }

    }

    private fun seekListeners() {

        binding.seekBrightness.max = 100
        binding.seekBrightness.progress = 50

        binding.seekContrast.max = 200
        binding.seekContrast.progress = 100

        binding.seekSaturation.max = 200
        binding.seekSaturation.progress = 100

        binding.seekBrightness.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {

                override fun onProgressChanged(
                    seekBar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {

                }

                override fun onStartTrackingTouch(
                    seekBar: SeekBar?
                ) {
                    binding.llProgress.beVisible()
                }

                override fun onStopTrackingTouch(
                    seekBar: SeekBar?
                ) {
                    brightnessLevel =
                        (binding.seekBrightness.progress - 50) * 2f

                    binding.editorView.brightness =
                        brightnessLevel

                    binding.editorView.render()

                    binding.llProgress.beGone()
                }
            })

        binding.seekContrast.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {

                override fun onProgressChanged(
                    seekBar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {

                }

                override fun onStartTrackingTouch(
                    seekBar: SeekBar?
                ) {
                    binding.llProgress.beVisible()
                }

                override fun onStopTrackingTouch(
                    seekBar: SeekBar?
                ) {
                    contrastLevel =
                        binding.seekContrast.progress / 100f

                    binding.editorView.contrast =
                        contrastLevel

                    binding.editorView.render()
                    binding.llProgress.beGone()
                }
            })

        binding.seekSaturation.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {

                override fun onProgressChanged(
                    seekBar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {

                }

                override fun onStartTrackingTouch(
                    seekBar: SeekBar?
                ) {
                    binding.llProgress.beVisible()
                }

                override fun onStopTrackingTouch(
                    seekBar: SeekBar?
                ) {
                    saturationLevel =
                        binding.seekSaturation.progress / 100f

                    binding.editorView.saturation =
                        saturationLevel

                    binding.editorView.render()
                    binding.llProgress.beGone()
                }
            })
        binding.seekSharpen.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {

                override fun onProgressChanged(
                    seekBar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {
//                    sharpenLevel = progress / 100f
//                    binding.editorView.sharpen = sharpenLevel
//                    binding.editorView.render()
                }

                override fun onStartTrackingTouch(
                    seekBar: SeekBar?
                ) {
                    binding.llProgress.beVisible()
                }

                override fun onStopTrackingTouch(
                    seekBar: SeekBar?
                ) {
                    sharpenLevel = binding.seekSharpen.progress / 100f

                    binding.editorView.sharpen = sharpenLevel

                    binding.editorView.render()
                    binding.llProgress.beGone()
                }
            })
    }

    private fun updateAdjustSelected(pos: Int) {
        binding.seekBrightness.beGone()
        binding.seekContrast.beGone()
        binding.seekSaturation.beGone()
        binding.seekSharpen.beGone()
        if (currentPos != pos) {
            currentPos = pos
//            adjustModel = adjustList[currentPos]
//            binding.adjustLevel.progress = (adjustModel.slierIntensity * (binding.adjustLevel.max.toFloat())).toInt()
            when (currentPos) {
                brightnessPos -> {
                    binding.seekBrightness.beVisible()
                    unSelectAll()
                    setSelectTab(binding.ivBrightness, binding.tvBrightness)
                    binding.txtTitle.text = getString(R.string.Brightness)
                }

                saturationPos -> {
                    binding.seekSaturation.beVisible()
                    unSelectAll()
                    setSelectTab(binding.ivSaturation, binding.tvSaturation)
                    binding.txtTitle.text = getString(R.string.Saturation)
                }

                contrastPos -> {
                    binding.seekContrast.beVisible()
                    unSelectAll()
                    setSelectTab(binding.ivContrast, binding.tvContrast)
                    binding.txtTitle.text = getString(R.string.Contrast)
                }

                sharpenPos -> {
                    binding.seekSharpen.beVisible()
                    unSelectAll()
                    setSelectTab(binding.ivSharpen, binding.tvSharpen)
                    binding.txtTitle.text = getString(R.string.Sharpen)
                }
            }
        }
    }

    private fun unSelectAll() {
//        val selectColor = ContextCompat.getColor(this, R.color.home_unSelect_tab_icon)
        val selectColor = Color.parseColor("#A1A2A7")
        binding.ivBrightness.setColorFilter(selectColor, PorterDuff.Mode.SRC_IN)
        binding.ivSaturation.setColorFilter(selectColor, PorterDuff.Mode.SRC_IN)
        binding.ivContrast.setColorFilter(selectColor, PorterDuff.Mode.SRC_IN)
        binding.ivSharpen.setColorFilter(selectColor, PorterDuff.Mode.SRC_IN)

        binding.tvBrightness.setTextColor(selectColor)
        binding.tvSaturation.setTextColor(selectColor)
        binding.tvContrast.setTextColor(selectColor)
        binding.tvSharpen.setTextColor(selectColor)

    }

    private fun setSelectTab(imageView: ImageView, textView: TextView) {
        val selectColor = ContextCompat.getColor(this, R.color.color_primary)
        imageView.setColorFilter(selectColor, PorterDuff.Mode.SRC_IN)
        textView.setTextColor(selectColor)
    }

}