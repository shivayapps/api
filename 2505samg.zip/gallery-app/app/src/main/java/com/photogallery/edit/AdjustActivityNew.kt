package com.photogallery.edit

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.doOnPreDraw
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.photogallery.R
import com.photogallery.base.BaseActivity

import com.photogallery.databinding.ActivityAdjustBinding
import com.photogallery.dialog.ProgressDialog
//import com.photogallery.edit.model.AdjustModel
import com.photogallery.edit.model.getSourceBitmap
import com.photogallery.edit.model.setBrightness
import com.photogallery.edit.model.setContrast
import com.photogallery.edit.model.setSaturation
import com.photogallery.edit.model.setSharpness
import com.photogallery.extension.toast
import com.photogallery.extension.updateStatusBarColor
import com.photogallery.utils.Constant
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
//import org.wysaid.view.ImageGLSurfaceView


//class AdjustActivityNew : BaseActivity() {
//
//    lateinit var binding: ActivityAdjustBinding
//    private var imagePath = ""
//    private var saveImageName = ""
//    private var sourceImgBitmap: Bitmap? = null
//    private var finalBitmap: Bitmap? = null
//
//    //    private var adjustList: ArrayList<AdjustModel> = ArrayList()
////    private lateinit var adjustModel: AdjustModel
//    private var currentPos = -1
//    private val brightnessPos = 0
//    private val contrastPos = 1
//    private val saturationPos = 2
//    private val sharpenPos = 3
//    private var brightnessLevel = 0f
//    private var contrastLevel = 1f
//    private var saturationLevel = 1f
//    private var sharpenLevel = 1f
//
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        applyStatusBar = false
//        super.onCreate(savedInstanceState)
//        binding = ActivityAdjustBinding.inflate(layoutInflater)
//        enableEdgeToEdge()
//        setContentView(binding.root)
//        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
//            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
//            insets
//        }
//        updateStatusBarColor(Color.parseColor("#151515"))
//
//        intView()
//    }
//
//    override fun onResume() {
//        applyStatusBar = false
//        super.onResume()
//    }
//
//    private var renderJob: Job? = null
//    private fun intView() {
//        imagePath = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_PATH) ?: ""
//        saveImageName = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_NAME) ?: ""
//
//        binding.txtTitle.text = getString(R.string.Contrast)
//
//        intListener()
//        Log.e("EDITTAG", "setSurfaceCreatedCallback")
//        Glide
//            .with(this)
//            .asBitmap()
//            .load(imagePath)
//            .into(object : CustomTarget<Bitmap>() {
//                override fun onResourceReady(
//                    resource: Bitmap,
//                    transition: Transition<in Bitmap>?
//                ) {
//                    sourceImgBitmap = resource
//                    binding.mainImageView.setImageBitmap(sourceImgBitmap)
//
//                }
//
//                override fun onLoadCleared(placeholder: Drawable?) {
//
//                }
//            })
//        binding.mainImageView.doOnPreDraw {
//            Log.e("EDITTAG", "doOnPreDraw")
//        }
//
//        updateAdjustSelected(0)
//        binding.adjustLevel.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
//            override fun onProgressChanged(
//                seekBar: SeekBar?,
//                progress: Int,
//                fromUser: Boolean
//            ) {
//
//                if (!fromUser || sourceImgBitmap == null) return
//
//                when (currentPos) {
//
//                    brightnessPos -> {
//                        brightnessLevel = (progress - 50) * 5f
//                    }
//
//                    contrastPos -> {
//                        contrastLevel = progress / 50f
//                    }
//
//                    saturationPos -> {
//                        saturationLevel = progress / 50f
//                    }
//
//                    sharpenPos -> {
//                        sharpenLevel = (progress / 20f).coerceAtLeast(1f)
//                    }
//                }
//
//                applyAdjustments()
//            }
//
//            override fun onStartTrackingTouch(p0: SeekBar?) {
//
//            }
//
//            override fun onStopTrackingTouch(p0: SeekBar?) {
//
//            }
//
//        })
//    }
//
//    private fun applyAdjustments() {
//
//        renderJob?.cancel()
//
//        renderJob = lifecycleScope.launch(Dispatchers.Default) {
//
//            var bitmap = sourceImgBitmap?.copy(
//                Bitmap.Config.ARGB_8888,
//                true
//            ) ?: return@launch
//
//            bitmap = setBrightness(
//                src = bitmap,
//                value = brightnessLevel
//            )
//
//            bitmap = setContrast(
//                src = bitmap,
//                value = contrastLevel
//            )
//
//            bitmap = setSaturation(
//                src = bitmap,
//                value = saturationLevel
//            )
//
//            bitmap = setSharpness(
//                src = bitmap,
//                value = sharpenLevel
//            )
//
//            withContext(Dispatchers.Main) {
//
//                finalBitmap = bitmap
//                binding.mainImageView.setImageBitmap(bitmap)
//            }
//        }
//    }
//
//    private fun intListener() {
//        binding.icBack.setOnClickListener { onBackPressed() }
//        binding.ivDone.setOnClickListener {
//
//            val bitmap = binding.mainImageView.getSourceBitmap()
//
//            runOnUiThread {
//
//                if (bitmap != null) {
//
//                    val progressDialog = ProgressDialog(
//                        this@AdjustActivity,
//                        0,
//                        0,
//                        getString(R.string.saving),
//                        ""
//                    )
//
//                    progressDialog.show()
//
//                    Thread {
//
//                        val imagePath = saveEditImage(bitmap, saveImageName)
//
//                        runOnUiThread {
//
//                            if (imagePath != null) {
//
//                                val intent = Intent()
//                                intent.putExtra(
//                                    Constant.EXTRA_EDIT_SAVE_IMAGE,
//                                    imagePath
//                                )
//
//                                setResult(RESULT_OK, intent)
//                            }
//
//                            if (!isFinishing && !isDestroyed) {
//                                if (progressDialog.isShowing) {
//                                    progressDialog.dismiss()
//                                }
//                            }
//
//                            finish()
//                        }
//
//                    }.start()
//
//                } else {
//
//                    toast(getString(R.string.image_editing_failed))
//                }
//            }
//        }
//
//
//        binding.btnBrightness.setOnClickListener { updateAdjustSelected(brightnessPos) }
//        binding.btnContrast.setOnClickListener { updateAdjustSelected(contrastPos) }
//        binding.btnSaturation.setOnClickListener { updateAdjustSelected(saturationPos) }
//        binding.btnSharpen.setOnClickListener { updateAdjustSelected(sharpenPos) }
//
//    }
//
//    private fun updateAdjustSelected(pos: Int) {
//
//        if (currentPos != pos) {
//
//            currentPos = pos
//
//            when (currentPos) {
//
//                brightnessPos -> {
//
//                    binding.adjustLevel.progress =
//                        ((brightnessLevel / 5f) + 50).toInt()
//
//                    unSelectAll()
//
//                    setSelectTab(
//                        binding.ivBrightness,
//                        binding.tvBrightness
//                    )
//                }
//
//                saturationPos -> {
//
//                    binding.adjustLevel.progress =
//                        (saturationLevel * 50).toInt()
//
//                    unSelectAll()
//
//                    setSelectTab(
//                        binding.ivSaturation,
//                        binding.tvSaturation
//                    )
//                }
//
//                contrastPos -> {
//
//                    binding.adjustLevel.progress =
//                        (contrastLevel * 50).toInt()
//
//                    unSelectAll()
//
//                    setSelectTab(
//                        binding.ivContrast,
//                        binding.tvContrast
//                    )
//                }
//
//                sharpenPos -> {
//
//                    binding.adjustLevel.progress =
//                        (sharpenLevel * 50).toInt()
//
//                    unSelectAll()
//
//                    setSelectTab(
//                        binding.ivSharpen,
//                        binding.tvSharpen
//                    )
//                }
//            }
//        }
//    }
//
//    private fun unSelectAll() {
//        val selectColor = Color.parseColor("#A1A2A7")
//        binding.ivBrightness.setColorFilter(selectColor, PorterDuff.Mode.SRC_IN)
//        binding.ivSaturation.setColorFilter(selectColor, PorterDuff.Mode.SRC_IN)
//        binding.ivContrast.setColorFilter(selectColor, PorterDuff.Mode.SRC_IN)
//        binding.ivSharpen.setColorFilter(selectColor, PorterDuff.Mode.SRC_IN)
//
//        binding.tvBrightness.setTextColor(selectColor)
//        binding.tvSaturation.setTextColor(selectColor)
//        binding.tvContrast.setTextColor(selectColor)
//        binding.tvSharpen.setTextColor(selectColor)
//
//    }
//
//    private fun setSelectTab(imageView: ImageView, textView: TextView) {
//        val selectColor = ContextCompat.getColor(this, R.color.color_primary)
//        imageView.setColorFilter(selectColor, PorterDuff.Mode.SRC_IN)
//        textView.setTextColor(selectColor)
//    }
//
//}