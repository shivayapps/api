package com.photogallery.edit.model;

import android.graphics.*
import android.graphics.drawable.BitmapDrawable
import android.widget.ImageView
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

fun ImageView.getSourceBitmap(): Bitmap {
    return (drawable as BitmapDrawable).bitmap.copy(Bitmap.Config.ARGB_8888, true)
}

fun setBrightness(src: Bitmap,value: Float) : Bitmap{

    //val src = source?:getSourceBitmap()

    val colorMatrix = ColorMatrix(
        floatArrayOf(
            1f, 0f, 0f, 0f, value,
            0f, 1f, 0f, 0f, value,
            0f, 0f, 1f, 0f, value,
            0f, 0f, 0f, 1f, 0f
        )
    )

    val bitmap = Bitmap.createBitmap(src.width, src.height, src.config!!)

    val canvas = Canvas(bitmap)
    val paint = Paint()
    paint.colorFilter = ColorMatrixColorFilter(colorMatrix)

    canvas.drawBitmap(src, 0f, 0f, paint)

    return bitmap
}

fun setContrast(src: Bitmap,value: Float): Bitmap {

//    val src = source?:getSourceBitmap()

    val scale = value
    val translate = (-0.5f * scale + 0.5f) * 255f

    val colorMatrix = ColorMatrix(
        floatArrayOf(
            scale, 0f, 0f, 0f, translate,
            0f, scale, 0f, 0f, translate,
            0f, 0f, scale, 0f, translate,
            0f, 0f, 0f, 1f, 0f
        )
    )

    val bitmap = Bitmap.createBitmap(src.width, src.height, src.config!!)

    val canvas = Canvas(bitmap)
    val paint = Paint()
    paint.colorFilter = ColorMatrixColorFilter(colorMatrix)

    canvas.drawBitmap(src, 0f, 0f, paint)

    return bitmap
}

fun setSaturation(src: Bitmap,value: Float): Bitmap {

//    val src = source?:getSourceBitmap()

    val colorMatrix = ColorMatrix()
    colorMatrix.setSaturation(value)

    val bitmap = Bitmap.createBitmap(src.width, src.height, src.config!!)

    val canvas = Canvas(bitmap)
    val paint = Paint()
    paint.colorFilter = ColorMatrixColorFilter(colorMatrix)

    canvas.drawBitmap(src, 0f, 0f, paint)

    return bitmap
}

private var sharpenJob: Job? = null
suspend fun setSharpness(
    src: Bitmap,
    value: Float
): Bitmap = withContext(Dispatchers.Default) {

    val sharpness = value.coerceAtLeast(0f)

    val kernel = floatArrayOf(
        0f, -1f, 0f,
        -1f, 4f + sharpness, -1f,
        0f, -1f, 0f
    )

    val convolution = ConvolutionMatrix(3)

    convolution.applyConfig(kernel)
    convolution.Factor = 1.0f
    convolution.Offset = 0.0f

    ConvolutionMatrix.computeConvolution3x3(
        src,
        convolution
    )
}

//fun ImageView.setSharpness(source: Bitmap?, value: Float) {
//
//    val src = source ?: getSourceBitmap()
//
//    // avoid divide by zero
//    val sharpness = value.coerceAtLeast(1f)
//
//    val kernel = floatArrayOf(
//        0f, -1f, 0f,
//        -1f, 4f + sharpness, -1f,
//        0f, -1f, 0f
//    )
//
//    val convolution = ConvolutionMatrix(3)
//    convolution.applyConfig(kernel)
//
//    convolution.Factor = 1.0F
//    convolution.Offset = 0.0F
//
//    val bitmap = ConvolutionMatrix.computeConvolution3x3(
//        src,
//        convolution
//    )
//
//    setImageBitmap(bitmap)
//}


//import org.wysaid.view.ImageGLSurfaceView;
//public class AdjustModel {
//    public int index;
//    public float intensity, slierIntensity = 0.5f;
//    public float minValue, originValue, maxValue;
//
//
//    public AdjustModel(int _index, float _minValue, float _originValue, float _maxValue) {
//        index = _index;
//        minValue = _minValue;
//        originValue = _originValue;
//        maxValue = _maxValue;
//        intensity = _originValue;
//    }
//
//    protected float calcIntensity(float _intensity) {
//        float result;
//        if (_intensity <= 0.0f) {
//            result = minValue;
//        } else if (_intensity >= 1.0f) {
//            result = maxValue;
//        } else if (_intensity <= 0.5f) {
//            result = minValue + (originValue - minValue) * _intensity * 2.0f;
//        } else {
//            result = maxValue + (originValue - maxValue) * (1.0f - _intensity) * 2.0f;
//        }
//        return result;
//    }
//
//    //_intensity range: [0.0, 1.0], 0.5 for the origin.
//    public void setIntensity(ImageGLSurfaceView mImageView, float _intensity, boolean shouldProcess) {
//        if (mImageView != null) {
//            slierIntensity = _intensity;
//            intensity = calcIntensity(_intensity);
//            mImageView.setFilterIntensityForIndex(intensity, index, shouldProcess);
//        }
//    }
//}
