package com.photogallery.jobs

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.util.Log
import com.photogallery.GalleryApp
import com.photogallery.R
import com.photogallery.extension.getFilenameFromPath
import com.photogallery.extension.getParentFolder
import com.photogallery.extension.isApng
import com.photogallery.extension.isGif
import com.photogallery.extension.isImageFast
import com.photogallery.extension.isPng
import com.photogallery.extension.isPortrait
import com.photogallery.extension.isSvg
import com.photogallery.extension.isVideoFast
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences
import com.photogallery.utils.TYPE_GIFS
import com.photogallery.utils.TYPE_IMAGES
import com.photogallery.utils.TYPE_VIDEOS
import com.photogallery.utils.Utils
import com.photogallery.utils.photoExtensions
import com.photogallery.utils.rawExtensions
import com.photogallery.utils.videoExtensions
import kotlinx.coroutines.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class LoaderUtilMedia(
    private val mContext: Context,
    private var filterMedia: Int = TYPE_IMAGES or TYPE_VIDEOS or TYPE_GIFS,
    private var sortType: Int = Constant.SORT_DATE,
    private var sortOrder: Int = Constant.ORDER_DESCENDING,
    private var groupBy: Int = Constant.GROUP_BY_DATE_DAILY,
    private var groupOrder: Int = Constant.GROUP_BY_NONE,
    var loadImage: Boolean = true,
    var loadVideo: Boolean = false,
    prefKey: String = "",
) {

    private var TAG = "LoaderUtil"
    private var ROOT_PATH = ""
    private var mJob: Job = Job()
    private var preferences: Preferences? = null

    private val albumList: ArrayList<AlbumData> = ArrayList()

    //    var recentList: ArrayList<MediaData> = ArrayList()
    var favouriteList: ArrayList<MediaData> = ArrayList()

    private val portraitList: ArrayList<MediaData> = ArrayList()
    private val hdList: ArrayList<MediaData> = ArrayList()
    private val burstList: ArrayList<MediaData> = ArrayList()
    private val animatedList: ArrayList<MediaData> = ArrayList()

    val projectionImage = arrayOf(
        MediaStore.Images.Media._ID,
        MediaStore.Images.Media.DATA,
        MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
        MediaStore.MediaColumns.DATE_MODIFIED,
        MediaStore.MediaColumns.DATE_TAKEN,
        MediaStore.MediaColumns.DISPLAY_NAME,
        MediaStore.MediaColumns.SIZE,
        MediaStore.Images.Media.WIDTH,
        MediaStore.Images.Media.HEIGHT,
        MediaStore.Images.Media.MIME_TYPE,
    )
    val projectionVideo = arrayOf(
        MediaStore.Video.VideoColumns._ID,
        MediaStore.Video.VideoColumns.DATA,
        MediaStore.Video.Media.DISPLAY_NAME,
        MediaStore.Video.VideoColumns.SIZE,
        MediaStore.Video.VideoColumns.DURATION,
        MediaStore.Video.VideoColumns.DATE_MODIFIED,
        MediaStore.Video.VideoColumns.DATE_TAKEN,
        MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
    )

    var favList = ArrayList<String>()

    fun refreshLoader(prefKey: String) {

        sortType = preferences?.getSortType(prefKey) ?: Constant.SORT_DATE
        sortOrder = preferences?.getSortOrder(prefKey) ?: Constant.ORDER_DESCENDING
        groupBy = preferences?.getGroupBy(prefKey) ?: Constant.GROUP_BY_DATE_DAILY
        groupOrder = preferences?.getGroupOrderBy(prefKey) ?: Constant.GROUP_BY_NONE
        filterMedia = preferences?.getFilterMedia() ?: (TYPE_IMAGES or TYPE_VIDEOS or TYPE_GIFS)

        favList.clear()
        favList.addAll(preferences?.getFavoriteList() ?: ArrayList())

    }

    init {
//        TAG = prefKey.ifEmpty { "LoaderUtil" }
        TAG = "LoaderUtil"
        refreshLoader(prefKey)
        preferences = GalleryApp.preferences
    }

    private fun getConstantData(): ArrayList<MediaData> {
        val data = Constant.albumData // Or load actual album based on folderPath
        val albumData =
            AlbumData(data.title, data.mediaData, data.folderPath, data.date, data.fileSize)
        val allList = ArrayList<MediaData>()
        allList.addAll(albumData.mediaData)
        allList.forEach { it.isFavorite = favList.contains(it.filePath) }
        return allList
    }

    fun getAllAlbum(
        onSuccess: ((
            portraitAlbum: AlbumData,
            hdAlbum: AlbumData,
            burstAlbum: AlbumData,
            animatedAlbum: AlbumData
        ) -> Unit)? = null,
        onFailed: ((error: String) -> Unit)? = null,
    ) {
        mJob = CoroutineScope(Dispatchers.IO).launch {
            try {
                val albums: ArrayList<AlbumData> = ArrayList()
                val sortedMedia: ArrayList<MediaData> = ArrayList()
                val allMedia: ArrayList<MediaData> = ArrayList()
                allMedia.clear()
                albumList.clear()

                portraitList.clear()
                hdList.clear()
                burstList.clear()
                animatedList.clear()

//                recentList.clear()
                favouriteList.clear()
//                videoList.clear()

                //get Images
                if (loadImage) allMedia.addAll(getImages())
                //get Videos
                if (loadVideo) allMedia.addAll(getVideos())

                applyMediaSorting(allMedia, sortType, sortOrder) { media ->
                    sortedMedia.addAll(media)

                    val groupedMedia = sortedMedia.groupBy { it.bucketPath }
                    Log.e(TAG, "groupedMedia size:${groupedMedia.size}")
                    groupedMedia.forEach { (bucketPath, media) ->

                        val folderName = media.first().folderName
                        val folderSize = media.sumOf { it.fileSize }
                        val albumData = AlbumData(
                            title = folderName,
                            mediaData = ArrayList(media),
                            folderPath = bucketPath,
                            date = media.maxOfOrNull { it.date } ?: 0L,
                            fileSize = folderSize
                        )
                        albums.add(albumData)
                    }
                }

                applyAlbumSorting(albums, sortType, sortOrder) { sortedAlbums ->
                    albumList.addAll(sortedAlbums)
                }

                portraitList
                hdList
                burstList
                animatedList

                val portraitAlbum = AlbumData(
                    title = "portrait",
                    mediaData = portraitList,
                    folderPath = "portrait",
                    date = portraitList.maxOfOrNull { it.date } ?: 0L,
                    fileSize = portraitList.sumOf { it.fileSize }
                )

                val hdAlbum = AlbumData(
                    title = "hd",
                    mediaData = hdList,
                    folderPath = "hd",
                    date = hdList.maxOfOrNull { it.date } ?: 0L,
                    fileSize = hdList.sumOf { it.fileSize }
                )

                val burstAlbum = AlbumData(
                    title = "burst",
                    mediaData = burstList,
                    folderPath = "burst",
                    date = burstList.maxOfOrNull { it.date } ?: 0L,
                    fileSize = burstList.sumOf { it.fileSize }
                )

                val animatedAlbum = AlbumData(
                    title = "animated",
                    mediaData = animatedList,
                    folderPath = "animated",
                    date = animatedList.maxOfOrNull { it.date } ?: 0L,
                    fileSize = animatedList.sumOf { it.fileSize }
                )

                withContext(Dispatchers.Main) {
                    Log.e(TAG, "onSuccess?.invoke")
                    onSuccess?.invoke(portraitAlbum, hdAlbum, burstAlbum, animatedAlbum)
                }

            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    onFailed?.invoke(e.message ?: "Error occurred while loading media.")
                }
            }
        }
    }


    private fun searchAlbum(key: String, albumList: ArrayList<AlbumData>): ArrayList<AlbumData> {
        val albumListCopy = ArrayList(albumList)
        val returnList = albumListCopy.filter {
            it.title.lowercase().contains(key, true)
        } as ArrayList<AlbumData>
        return returnList
    }

    private fun getImages(): ArrayList<MediaData> {
        Log.e(TAG, "getImages >>>>")
        val mediaList = ArrayList<MediaData>()
        try {
            val uri: Uri = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            val cursor = mContext.contentResolver.query(
                uri, projectionImage, getSelectionQuery(filterMedia),
                getSelectionArgsQuery(filterMedia).toTypedArray(),
                MediaStore.Images.Media.DATE_MODIFIED + " DESC"
            )

            var lastTimeTaken = 0L
            var lastBucket = ""

            cursor?.use {
                while (it.moveToNext()) {
                    val path = it.getString(it.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))
                    val title =
                        it.getString(it.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME))
                    val bucketPath = path.substring(0, path.lastIndexOf(title) - 1)

                    val width = it.getInt(it.getColumnIndexOrThrow(MediaStore.Images.Media.WIDTH))
                    val height = it.getInt(it.getColumnIndexOrThrow(MediaStore.Images.Media.HEIGHT))
                    val mimeType =
                        it.getString(it.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE))

                    val idColumn = it.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                    val id = it.getLong(idColumn)
                    val contentUri = ContentUris.withAppendedId(uri, id)

                    var bucketName =
                        it.getString(it.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME))
                            ?: path.getParentFolder()
                    if (bucketPath == ROOT_PATH) bucketName = "Root"

                    val fileSize =
                        it.getLong(it.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
                            .takeIf { size -> size > 0 } ?: File(path).length()
                    val date =
                        it.getLong(it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)) * 1000
                    val dateTaken =
                        it.getLong(it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)) * 1000

//                    if(lastTimeDetect compare dateTaken > 1 second) {
//                        this and previous image is burst
//                                burstList.add(AlbumData())
//                    }
//                    if(path.isGif()) {
//                        animatedList.add(AlbumData())
//                    }
//
//                    if(path.isHighDefination()) {
//                        hdList.add(AlbumData())
//                    }
//                    if(path.isPortrait()) {
//                        portraitList.add(AlbumData())
//                    }

                    if (fileSize > 0) {
                        val mediaData = MediaData(
                            filePath = path,
                            fileUri = contentUri.toString(),
                            fileName = title,
                            folderName = bucketName,
                            date = date,
                            bucketPath = bucketPath,
                            dateTaken = dateTaken.takeIf { it > 0 } ?: date,
                            fileSize = fileSize
                        ).apply {
                            isFavorite = favList.contains(path)
                        }

                        if (mediaData.isFavorite) favouriteList.add(mediaData)
                        mediaList.add(mediaData)

                        // --------------------------------------------------
                        // ✅ 1. PORTRAIT
                        // --------------------------------------------------
                        val isPortrait = height > width
                        if (isPortrait) {
                            portraitList.add(mediaData)
                        }

                        // --------------------------------------------------
                        // ✅ 2. HD (you can tweak threshold)
                        // --------------------------------------------------
                        val isHD = width >= 1920 || height >= 1920
                        if (isHD) {
                            hdList.add(mediaData)
                        }

                        // --------------------------------------------------
                        // ✅ 3. ANIMATED (GIF / WEBP)
                        // --------------------------------------------------
                        val isAnimated = mimeType?.contains("gif", true) == true ||
                                mimeType?.contains("webp", true) == true

                        if (isAnimated) {
                            animatedList.add(mediaData)
                        }

                        // --------------------------------------------------
                        // ✅ 4. BURST (time-based detection)
                        // --------------------------------------------------
                        val isSameFolder = bucketName == lastBucket
                        val isBurst =
                            isSameFolder && kotlin.math.abs(dateTaken - lastTimeTaken) <= 1000

                        if (isBurst) {
                            burstList.add(mediaData)
                        }

                        // update last values
                        lastTimeTaken = dateTaken
                        lastBucket = bucketName

                    }
                }
            }

        } catch (e: Exception) {
            Log.e(TAG, "getImages Exception:$e")
        }
        Log.e(TAG, "getImages <<<<")
        return mediaList
    }

    private fun getVideos(): ArrayList<MediaData> {
        Log.e(TAG, "getVideos >>>>")
        val mediaList = ArrayList<MediaData>()
        try {
            val uri: Uri = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)

            val cursor = mContext.contentResolver.query(
                uri, projectionVideo, getSelectionQuery(filterMedia),
                getSelectionArgsQuery(filterMedia).toTypedArray(),
                MediaStore.Video.Media.DATE_MODIFIED + " DESC"
            )

            cursor?.use {
                while (it.moveToNext()) {
                    val path = it.getString(it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA))
                    val title =
                        it.getString(it.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME))
                    val bucketPath = path.substring(0, path.lastIndexOf(title) - 1)

                    val idColumn = it.getColumnIndexOrThrow(MediaStore.Video.VideoColumns._ID)
                    val id = it.getLong(idColumn)
                    val contentUri = ContentUris.withAppendedId(uri, id)

                    var bucketName =
                        it.getString(it.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME))
                            ?: path.getParentFolder()
                    if (bucketPath == ROOT_PATH) bucketName = "Root"

                    val fileSize =
                        it.getLong(it.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.SIZE))
                            .takeIf { size -> size > 0 } ?: File(path).length()
                    val date =
                        it.getLong(it.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DATE_MODIFIED)) * 1000
                    val dateTaken =
                        it.getLong(it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)) * 1000
                    val duration =
                        it.getLong(it.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DURATION))

                    if (fileSize > 0) {
                        val mediaData = MediaData(
                            filePath = path,
                            fileUri = contentUri.toString(),
                            fileName = title,
                            folderName = bucketName,
                            date = date,
                            dateTaken = dateTaken.takeIf { it > 0 } ?: date,
                            fileSize = fileSize,
                            bucketPath = bucketPath,
                            isVideo = true,
                            videoDuration = duration
                        ).apply {
                            isFavorite = favList.contains(path)
                        }

                        if (mediaData.isFavorite) favouriteList.add(mediaData)
                        mediaList.add(mediaData)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "getVideos Exception:$e")
        }
        Log.e(TAG, "getVideos <<<<")
        return mediaList
    }

    fun applyMediaSorting(
        mediaList: MutableList<MediaData>,
        sortType: Int,
        sortOrder: Int,
        onSortingComplete: (List<MediaData>) -> Unit
    ) {
        Log.e(TAG, "applyMediaSorting >>>>")
        try {
            val comparator = when (sortType) {
                Constant.SORT_NAME -> compareBy<MediaData> { it.fileName.lowercase() }
                Constant.SORT_SIZE -> compareBy { it.fileSize }
                Constant.SORT_DATE -> compareBy { it.date }
                else -> compareBy { it.date }
            }

            val sortedList = if (sortOrder == Constant.ORDER_ASCENDING) {
                mediaList.sortedWith(comparator)
            } else {
                mediaList.sortedWith(Comparator { a, b ->
                    comparator.compare(
                        b,
                        a
                    )
                }) // Manual reverse
            }

            onSortingComplete(sortedList)
        } catch (e: Exception) {
            Log.e(TAG, "applyMediaSorting Exception:$e")
            onSortingComplete(mediaList)
        }

        Log.e(TAG, "applyMediaSorting <<<<")
    }

    fun applyMediaGrouping(
        mediaList: ArrayList<MediaData>,
        currentGrouping: Int,
        groupOrder: Int,
        onGroupComplete: ((groupedMediaList: ArrayList<Any>) -> Unit)? = null
    ) {
        Log.e(TAG, "applyMediaGrouping >>>>")
        val allList = ArrayList<Any>()
        val format = when (currentGrouping) {
            Constant.GROUP_BY_DATE_DAILY -> SimpleDateFormat(Constant.dateFormat, Locale.ENGLISH)
            Constant.GROUP_BY_DATE_MONTHLY -> SimpleDateFormat("MMMM yyyy", Locale.ENGLISH)
            else -> SimpleDateFormat(Constant.dateFormat, Locale.ENGLISH)
        }
        try {
            // Group media data based on the selected grouping
            val dateWisePictures = linkedMapOf<String, ArrayList<MediaData>>()

            if (mediaList.isNotEmpty()) {
                mediaList.forEach { pictureData ->
                    // Determine the group key based on the current grouping type
                    val strKey = getGroupKey(pictureData, currentGrouping, format)

                    // Add the media item to the corresponding group
                    dateWisePictures.getOrPut(strKey) { ArrayList() }.add(pictureData)
                }

                // Get the keys and order them based on groupOrder
                val listKeys = ArrayList(dateWisePictures.keys).apply {
                    if (groupOrder == Constant.ORDER_DESCENDING) reverse()
                }

                // If no groups are formed, just add all media items to the list
                if (listKeys.isEmpty()) {
                    allList.addAll(mediaList)
                }

                // inside the listKeys.forEach loop, before adding AlbumData:
                listKeys.forEach { key ->
                    dateWisePictures[key]?.let { imagesData ->
                        if (imagesData.isNotEmpty()) {
                            // sort items inside group by date
                            if (groupOrder == Constant.ORDER_DESCENDING) imagesData.sortByDescending { it.date }
                            else imagesData.sortBy { it.date }

                            allList.add(AlbumData(key, imagesData))
                            allList.addAll(imagesData)
                        }
                    }
                }

            }

            // Invoke the callback with the grouped media data
            onGroupComplete?.invoke(allList)

        } catch (e: Exception) {
            allList.addAll(mediaList)
            onGroupComplete?.invoke(allList)
            Log.e(TAG, "applyMediaGrouping Exception: $e")
        }

        Log.e(TAG, "applyMediaGrouping <<<<")
    }

    // Helper function to determine the group key based on the current grouping type
    private fun getGroupKey(
        pictureData: MediaData,
        currentGrouping: Int,
        format: SimpleDateFormat
    ): String {
        return when (currentGrouping) {
            Constant.GROUP_BY_NONE -> ""
            Constant.GROUP_BY_DATE_DAILY -> format.format(getDayStartTS(pictureData.date, false))
            Constant.GROUP_BY_DATE_MONTHLY -> format.format(getDayStartTS(pictureData.date, true))
            else -> format.format(getDayStartTS(pictureData.date, false))
        }
    }

    private fun getFileTypeString(fileName: String): String {
        Log.e("getFileTypeString", "getFileTypeString.001:$fileName")
        var stringId = R.string.images
        if (fileName.isImageFast() || fileName.isApng() || fileName.isPng()) stringId =
            R.string.images
        else if (fileName.isVideoFast()) stringId = R.string.videos
        else if (fileName.isPortrait()) stringId = R.string.portraits
        else if (fileName.isSvg()) stringId = R.string.svgs
        else if (fileName.isGif()) stringId = R.string.gifs

        return mContext.getString(stringId)
    }

    private fun getDayStartTS(ts: Long, resetDays: Boolean): Long {
        val calendar = Calendar.getInstance(Locale.ENGLISH).apply {
            timeInMillis = ts
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)

            if (resetDays) {
                set(Calendar.DAY_OF_MONTH, 1)
            }
        }

        return calendar.timeInMillis
    }

    fun applyAlbumSorting(
        albumList: ArrayList<AlbumData>,
        sortType: Int,
        sortOrder: Int,
        onSortingComplete: ((sortedList: ArrayList<AlbumData>) -> Unit)? = null
    ) {
        Log.e(TAG, "applyAlbumSorting size==>> ${albumList.size}")
        try {
            albumList.sortWith { p1, p2 ->
                when (sortType) {
                    Constant.SORT_NAME -> if (sortOrder == Constant.ORDER_ASCENDING)
                        p1.title.compareTo(p2.title, true) else p2.title.compareTo(p1.title, true)

                    Constant.SORT_SIZE -> if (sortOrder == Constant.ORDER_ASCENDING)
                        p1.fileSize.compareTo(p2.fileSize) else p2.fileSize.compareTo(p1.fileSize)

                    Constant.SORT_DATE -> if (sortOrder == Constant.ORDER_ASCENDING)
                        p1.date.compareTo(p2.date) else p2.date.compareTo(p1.date)

                    else -> p2.date.compareTo(p1.date)
                }
            }
            onSortingComplete?.invoke(albumList)
        } catch (e: Exception) {
            Log.e(TAG, "applyAlbumSorting Exception:$e")
        }
    }
//    private fun setCustomAlbum() {
//        Log.e(TAG, "setCustomAlbum >>>>")
//
//        try {
//
//                val topLay = AlbumData(
//                    "utility",
//                    isCustomAlbum = true
//                )
//                customAlbumList.add(
//                    0,
//                    topLay
//                )
//            if (limitAlbum) customAlbumList.add(AlbumData())
//
//            customAlbumList.addAll(albumList)
//        } catch (e: Exception) {
//            Log.e(TAG, "setCustomAlbum Exception:$e")
//        }
//        Log.e(TAG, "setCustomAlbum <<<<")
//    }

    private fun getSelectionQuery(filterMedia: Int): String {
        val query = StringBuilder()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")

            rawExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
        }

        if (filterMedia and TYPE_GIFS != 0) {
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }
        return query.toString().trim().removeSuffix("OR")
    }

    private fun getSelectionArgsQuery(filterMedia: Int): ArrayList<String> {
        val args = ArrayList<String>()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.jpg")
            args.add("%.jpeg")
            rawExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.svg")
        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                args.add("%$it")
            }
        }
        if (filterMedia and TYPE_GIFS != 0) {
            args.add("%.gif")
        }

        return args
    }

    fun destroyLoader() {
        mJob.cancel()
    }

}
