package com.photogallery.activities

import android.annotation.SuppressLint
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.photogallery.R
import com.photogallery.base.BaseActivity
import com.photogallery.databinding.ActivityOnBoardingBinding
import com.photogallery.utils.Constant
import com.zhpan.indicator.enums.IndicatorSlideMode
import com.zhpan.indicator.enums.IndicatorStyle
import com.zhpan.indicator.utils.IndicatorUtils
import kotlin.text.toFloat

class OnBoardingActivity : BaseActivity() {

    lateinit var binding: ActivityOnBoardingBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityOnBoardingBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        trySliderData()
    }


    var indicatorSize = 3
    var sliderData: ArrayList<Triple<String, String, Int>> = ArrayList()
    private fun trySliderData() {

        sliderData = arrayListOf(
            Triple(
                getString(R.string.intro_title_1),
                getString(R.string.intro_message_1),
                R.drawable.ic_onboarding_1
            ),
            Triple(
                getString(R.string.intro_title_2),
                getString(R.string.intro_message_2),
                R.drawable.ic_onboarding_2
            ),
            Triple(
                getString(R.string.intro_title_3),
                getString(R.string.intro_message_3),
                R.drawable.ic_onboarding_3
            )
        )

        indicatorSize = sliderData.size
//        val newSliderList = (listOf(sliderData.last()) + sliderData + listOf(sliderData.first())) as java.util.ArrayList
        val mAdapter = SliderAdapter(this@OnBoardingActivity, sliderData)

        binding.viewpager.offscreenPageLimit = 1
        binding.indicator.setPageSize(indicatorSize)
        binding.indicator.apply {
            setIndicatorStyle(IndicatorStyle.ROUND_RECT)
            setSliderGap(IndicatorUtils.dp2px(4f).toFloat())
            setSlideMode(IndicatorSlideMode.SCALE)
            setSliderHeight(
                resources.getDimensionPixelOffset(com.intuit.sdp.R.dimen._6sdp).toFloat()
            )
            setSliderColor(Color.parseColor("#BBBCC0"), Color.parseColor("#3478F6"))
            setSliderWidth(
                resources.getDimension(com.intuit.sdp.R.dimen._6sdp),
                resources.getDimension(com.intuit.sdp.R.dimen._10sdp)
            )
            notifyDataChanged()
        }

        with(binding.viewpager) {
            adapter = mAdapter
        }

        binding.viewpager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {
                super.onPageScrolled(position, positionOffset, positionOffsetPixels)
                binding.indicator.onPageScrolled(
                    position,
//                    (position % indicatorSize),
                    positionOffset,
                    positionOffsetPixels
                )
            }

            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                //binding.indicator.onPageSelected((position % indicatorSize))
                binding.indicator.onPageSelected(position)
                if (position == 2) {
                    binding.btnNext.text = getString(R.string.get_started)
                } else {
                    binding.btnNext.text = getString(R.string.Next)
                }

                try {
//                    val item = sliderData[position % indicatorSize]
                    val item = sliderData[position]
                    binding.tvTitle.text = item.first
                    binding.tvDescription.text = item.second
                } catch (e: Exception) {
                }
            }
        })

        binding.btnNext.setOnClickListener {
            if (binding.viewpager.currentItem < 2) {
                binding.viewpager.currentItem = (binding.viewpager.currentItem + 1)
            } else startActivity(nextScreen())
        }
        //loadAd()
    }

//    private fun loadAd() {
//        NativeAdHelper(
//            this,
//            binding.frameNative,
//            binding.llBottom,
//            NativeLayoutType.NativeBig,
//            getString(R.string.native_language)
//        ).loadAd();
//    }

    private fun nextScreen(): Intent {
        Log.e("SplashTag", "nextScreen call")

        var intent = Intent(this, HomeActivity::class.java)
        if (!checkStoragePermission()) {
            intent = Intent(
                this,
                PermissionActivity::class.java
            ).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        } else {
            intent = Intent(
                this,
                HomeActivity::class.java
            ).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        return intent
    }


    class SliderAdapter(
        val mContext: Context,
        private val modelList: ArrayList<Triple<String, String, Int>>
    ) : RecyclerView.Adapter<SliderAdapter.SliderViewHolder>() {

        class SliderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val image = itemView.findViewById<ImageView>(R.id.ivImage)
//            val frameNative = itemView.findViewById<FrameLayout>(R.id.frameNative)
            val llAdPlace = itemView.findViewById<LinearLayout>(R.id.llAdPlace)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SliderViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(
                R.layout.item_intro, parent, false
            )
            return SliderViewHolder(view)
        }

        override fun onBindViewHolder(holder: SliderViewHolder, position: Int) {
//            val realPos = position % modelList.size
            val item = modelList[position]

            holder.image.setImageResource(item.third)
//            loadAd(holder.frameNative, holder.llAdPlace)
//            holder.title.text = item.first
//            holder.description.text = item.second
        }


        override fun getItemCount(): Int = modelList.size
//        override fun getItemCount(): Int = Int.MAX_VALUE // infinite scrolling


    }

}