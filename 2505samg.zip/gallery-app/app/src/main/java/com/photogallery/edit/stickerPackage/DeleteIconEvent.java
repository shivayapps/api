package com.photogallery.edit.stickerPackage;

import android.view.MotionEvent;

import com.photogallery.edit.stickerPackage.StickerIconEvent;

public class DeleteIconEvent implements StickerIconEvent {
  @Override public void onActionDown(StickerView stickerView, MotionEvent event) {

  }

  @Override public void onActionMove( StickerView stickerView, MotionEvent event) {

  }

  @Override public void onActionUp( StickerView stickerView, MotionEvent event) {
    stickerView.removeCurrentSticker();
  }
}
