package com.photogallery.edit.model

import android.graphics.Bitmap
import android.graphics.Color

class ConvolutionMatrix(size: Int) {

    var Matrix = Array(size) { FloatArray(size) }

    var Factor = 1f
    var Offset = 0f

    fun applyConfig(config: FloatArray) {

        var index = 0

        for (i in Matrix.indices) {
            for (j in Matrix[i].indices) {

                Matrix[i][j] = config[index]
                index++
            }
        }
    }

    companion object {

        fun computeConvolution3x3(
            src: Bitmap,
            matrix: ConvolutionMatrix
        ): Bitmap {

            val width = src.width
            val height = src.height

            val result = Bitmap.createBitmap(
                width,
                height,
                src.config!!
            )

            for (x in 1 until width - 1) {

                for (y in 1 until height - 1) {

                    var r = 0f
                    var g = 0f
                    var b = 0f

                    for (i in -1..1) {

                        for (j in -1..1) {

                            val pixel = src.getPixel(
                                x + i,
                                y + j
                            )

                            val factor =
                                matrix.Matrix[i + 1][j + 1]

                            r += Color.red(pixel) * factor
                            g += Color.green(pixel) * factor
                            b += Color.blue(pixel) * factor
                        }
                    }

                    r = (r / matrix.Factor) + matrix.Offset
                    g = (g / matrix.Factor) + matrix.Offset
                    b = (b / matrix.Factor) + matrix.Offset

                    result.setPixel(
                        x,
                        y,
                        Color.rgb(
                            r.coerceIn(0f, 255f).toInt(),
                            g.coerceIn(0f, 255f).toInt(),
                            b.coerceIn(0f, 255f).toInt()
                        )
                    )
                }
            }

            return result
        }
    }
}