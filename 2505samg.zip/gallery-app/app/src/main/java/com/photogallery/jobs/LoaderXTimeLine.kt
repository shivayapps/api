package com.photogallery.jobs

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.util.Log
import com.photogallery.GalleryApp
import com.photogallery.extension.getFilenameFromPath
import com.photogallery.extension.getParentFolder
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences
import com.photogallery.utils.TYPE_GIFS
import com.photogallery.utils.TYPE_IMAGES
import com.photogallery.utils.TYPE_VIDEOS
import com.photogallery.utils.photoExtensions
import com.photogallery.utils.rawExtensions
import com.photogallery.utils.videoExtensions
import kotlinx.coroutines.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class LoaderXTimeLine(
    private val mContext: Context,
    private var filterMedia: Int = TYPE_IMAGES or TYPE_VIDEOS or TYPE_GIFS,
    private var sortType: Int = Constant.SORT_DATE,
    private var sortOrder: Int = Constant.ORDER_DESCENDING,
    private var groupBy: Int = Constant.GROUP_BY_DATE_DAILY,
    private var groupOrder: Int = Constant.GROUP_BY_NONE,
    private val loadImage: Boolean = true,
    private val loadVideo: Boolean = true,
    prefKey: String = "",
) {

    private var TAG = ""
    private var ROOT_PATH = ""
    private var mJob: Job = Job()
    private var preferences: Preferences? = null

    private val albumList: ArrayList<AlbumData> = ArrayList()

    var customStoryList: ArrayList<AlbumData> = ArrayList()
    var customMemoryList: ArrayList<AlbumData> = ArrayList()

    init {
        TAG = prefKey.ifEmpty { "MediaLoaderX" }
        refreshLoader(prefKey)
        preferences = GalleryApp.preferences
    }

    val projectionImage = arrayOf(
        MediaStore.Images.Media._ID,
        MediaStore.Images.Media.DATA,
        MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
        MediaStore.MediaColumns.DATE_MODIFIED,
        MediaStore.MediaColumns.DATE_TAKEN,
        MediaStore.MediaColumns.DISPLAY_NAME,
        MediaStore.MediaColumns.SIZE,
    )
    val projectionVideo = arrayOf(
        MediaStore.Video.VideoColumns._ID,
        MediaStore.Video.VideoColumns.DATA,
        MediaStore.Video.Media.DISPLAY_NAME,
        MediaStore.Video.VideoColumns.SIZE,
        MediaStore.Video.VideoColumns.DURATION,
        MediaStore.Video.VideoColumns.DATE_MODIFIED,
        MediaStore.Video.VideoColumns.DATE_TAKEN,
        MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
    )

    fun refreshLoader(prefKey: String) {
        sortType = preferences?.getSortType(prefKey) ?: Constant.SORT_DATE
        sortOrder = preferences?.getSortOrder(prefKey) ?: Constant.ORDER_DESCENDING
        groupBy = preferences?.getGroupBy(prefKey) ?: Constant.GROUP_BY_DATE_DAILY
        groupOrder = preferences?.getGroupOrderBy(prefKey) ?: Constant.GROUP_BY_NONE
        filterMedia = preferences?.getFilterMedia() ?: (TYPE_IMAGES or TYPE_VIDEOS or TYPE_GIFS)
    }

    fun getAllAlbum(
        onSuccess: ((storyAlbumList: ArrayList<AlbumData>, memoryAlbumList: ArrayList<AlbumData>, mediaList: ArrayList<MediaData>) -> Unit)? = null,
        onFailed: ((error: String) -> Unit)? = null,
    ) {

        mJob = CoroutineScope(Dispatchers.IO).launch {
            try {
//                val albums: ArrayList<AlbumData> = ArrayList()
                val sortedMedia: ArrayList<MediaData> = ArrayList()
                val allMedia: ArrayList<MediaData> = ArrayList()
                allMedia.clear()
                albumList.clear()

                //get Images
                if (loadImage) allMedia.addAll(getImages())
                //get Videos
                if (loadVideo) allMedia.addAll(getVideos())

                applyMediaSorting(allMedia, sortType, sortOrder) { media ->
                    sortedMedia.addAll(media)

//                    val groupedMedia = sortedMedia.groupBy { it.bucketPath }
//                    Log.e(TAG, "groupedMedia size:${groupedMedia.size}")
//                    groupedMedia.forEach { (bucketPath, media) ->
//
//                        val folderName = media.first().folderName
//                        val folderSize = media.sumOf { it.fileSize }
//                        val albumData = AlbumData(
//                            title = folderName,
//                            mediaData = ArrayList(media),
//                            folderPath = bucketPath,
//                            date = media.maxOfOrNull { it.date } ?: 0L,
//                            fileSize = folderSize
//                        )
//                        albums.add(albumData)
//                    }
                }

                setMemoryAlbum(allMedia)

                withContext(Dispatchers.Main) {
                    Log.e(TAG, "onSuccess?.invoke")
                    onSuccess?.invoke(customStoryList, customMemoryList, sortedMedia)
                }

            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    onFailed?.invoke(e.message ?: "Error occurred while loading media.")
                }
            }
        }
    }


    val allMedia: ArrayList<MediaData> = ArrayList()

    private fun getImages(folderPath: String = ""): ArrayList<MediaData> {
        Log.e(TAG, "getImages >>>>")
        val mediaList = ArrayList<MediaData>()
        try {
            val uri: Uri = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            val cursor = mContext.contentResolver.query(
                uri, projectionImage, getSelectionQuery(filterMedia),
                getSelectionArgsQuery(filterMedia).toTypedArray(),
                MediaStore.Images.Media.DATE_MODIFIED + " DESC"
            )

            cursor?.use {
                while (it.moveToNext()) {

                    val path = it.getString(it.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))
                    val title =
                        it.getString(it.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME))
                    val bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
                    val idColumn = it.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                    val id = it.getLong(idColumn)
                    val contentUri = ContentUris.withAppendedId(uri, id)

                    var bucketName =
                        it.getString(it.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME))
                            ?: path.getParentFolder()
                    if (bucketPath == ROOT_PATH) bucketName = "Root"

                    val fileSize =
                        it.getLong(it.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
                            .takeIf { size -> size > 0 } ?: File(path).length()
                    val date =
                        it.getLong(it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)) * 1000
                    val dateTaken =
                        it.getLong(it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)) * 1000

                    if (folderPath.isNotEmpty()) {
                        if (bucketName == folderPath.getFilenameFromPath() && File(path).exists()) {
                            if (fileSize > 0) {
                                val mediaData = MediaData(
                                    filePath = path,
                                    fileUri = contentUri.toString(),
                                    fileName = title,
                                    folderName = bucketName,
                                    date = date,
                                    bucketPath = bucketPath,
                                    dateTaken = dateTaken.takeIf { it > 0 } ?: date,
                                    fileSize = fileSize
                                )

                                //if (mediaData.isFavorite) favouriteList.add(mediaData)
                                mediaList.add(mediaData)
                            }
                        }
                    } else {
                        if (fileSize > 0) {
                            val mediaData = MediaData(
                                filePath = path,
                                fileUri = contentUri.toString(),
                                fileName = title,
                                folderName = bucketName,
                                date = date,
                                bucketPath = bucketPath,
                                dateTaken = dateTaken.takeIf { it > 0 } ?: date,
                                fileSize = fileSize
                            )

                            mediaList.add(mediaData)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "getImages Exception:$e")
        }
        Log.e(TAG, "getImages <<<<")
        return mediaList
    }

    private fun getVideos(folderPath: String = ""): ArrayList<MediaData> {
        Log.e(TAG, "getVideos >>>>")
        val mediaList = ArrayList<MediaData>()
        try {
            val uri: Uri = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)

            val cursor = mContext.contentResolver.query(
                uri, projectionVideo, getSelectionQuery(filterMedia),
                getSelectionArgsQuery(filterMedia).toTypedArray(),
                MediaStore.Video.Media.DATE_MODIFIED + " DESC"
            )

            cursor?.use {
                while (it.moveToNext()) {
                    val path = it.getString(it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA))
                    val title =
                        it.getString(it.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME))
                    val bucketPath = path.substring(0, path.lastIndexOf(title) - 1)

                    var bucketName =
                        it.getString(it.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME))
                            ?: path.getParentFolder()
                    if (bucketPath == ROOT_PATH) bucketName = "Root"

                    val fileSize =
                        it.getLong(it.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
                            .takeIf { size -> size > 0 } ?: File(path).length()
                    val date =
                        it.getLong(it.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DATE_MODIFIED)) * 1000
                    val dateTaken =
                        it.getLong(it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)) * 1000
                    val duration =
                        it.getLong(it.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DURATION))

                    val idColumn = it.getColumnIndexOrThrow(MediaStore.Video.VideoColumns._ID)
                    val id = it.getLong(idColumn)
                    val contentUri = ContentUris.withAppendedId(uri, id)


                    if (folderPath.isNotEmpty()) {
                        if (bucketName == folderPath.getFilenameFromPath() && File(path).exists()) {
                            if (fileSize > 0) {
                                val mediaData = MediaData(
                                    filePath = path,
                                    fileUri = contentUri.toString(),
                                    fileName = title,
                                    folderName = bucketName,
                                    date = date,
                                    dateTaken = dateTaken.takeIf { it > 0 } ?: date,
                                    fileSize = fileSize,
                                    bucketPath = bucketPath,
                                    isVideo = true,
                                    videoDuration = duration
                                )

                                mediaList.add(mediaData)
                            }
                        }
                    } else {
                        if (fileSize > 0) {
                            val mediaData = MediaData(
                                filePath = path,
                                fileUri = contentUri.toString(),
                                fileName = title,
                                folderName = bucketName,
                                date = date,
                                dateTaken = dateTaken.takeIf { it > 0 } ?: date,
                                fileSize = fileSize,
                                bucketPath = bucketPath,
                                isVideo = true,
                                videoDuration = duration
                            )

                            mediaList.add(mediaData)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "getVideos Exception:$e")
        }
        Log.e(TAG, "getVideos <<<<")
        return mediaList
    }

    fun applyMediaSorting(
        mediaList: MutableList<MediaData>,
        sortType: Int,
        sortOrder: Int,
        onSortingComplete: (List<MediaData>) -> Unit
    ) {
        Log.e(TAG, "applyMediaSorting >>>>")
        try {
            val comparator = when (sortType) {
                Constant.SORT_NAME -> compareBy<MediaData> { it.fileName.lowercase() }
//                Constant.SORT_PATH -> compareBy { it.filePath.lowercase() }
                Constant.SORT_SIZE -> compareBy { it.fileSize }
                Constant.SORT_DATE -> compareBy { it.date }
//                Constant.SORT_DATE_TAKEN -> compareBy { it.dateTaken }
                else -> compareBy { it.date }
            }

            val sortedList = if (sortOrder == Constant.ORDER_ASCENDING) {
                mediaList.sortedWith(comparator)
            } else {
                mediaList.sortedWith(Comparator { a, b ->
                    comparator.compare(
                        b,
                        a
                    )
                }) // Manual reverse
//                mediaList.sortedWith(comparator.reversed()) // works on all SDKs
            }

            onSortingComplete(sortedList)
        } catch (e: Exception) {
            Log.e(TAG, "applyMediaSorting Exception:$e")
            onSortingComplete(mediaList)
        }

        Log.e(TAG, "applyMediaSorting <<<<")
    }


    private fun getDayStartTS(ts: Long, resetDays: Boolean): Long {
        val calendar = Calendar.getInstance(Locale.ENGLISH).apply {
            timeInMillis = ts
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)

            if (resetDays) {
                set(Calendar.DAY_OF_MONTH, 1)
            }
        }

        return calendar.timeInMillis
    }
    private fun setMemoryAlbum(allBackList: ArrayList<MediaData>) {
        Log.e(TAG, "setMemoryAlbum >>>>")

        try {
            customStoryList.clear()
            customMemoryList.clear()
            albumList.clear()

            if (allBackList.isEmpty()) return

            val sortedList = allBackList.sortedByDescending { it.date }

            // ================= MEMORY =================
            val dateWisePictures = LinkedHashMap<String, ArrayList<MediaData>>()

            val monthYearFormat = SimpleDateFormat("MMM yyyy", Locale.ENGLISH)
            val yearFormat = SimpleDateFormat("yyyy", Locale.ENGLISH)

            val calendarNow = Calendar.getInstance()

            val thisMonth = monthYearFormat.format(calendarNow.time)

            val calLastMonth = Calendar.getInstance().apply {
                add(Calendar.MONTH, -1)
            }
            val lastMonth = monthYearFormat.format(calLastMonth.time)

            val thisYear = calendarNow.get(Calendar.YEAR)

            val calLastYear = Calendar.getInstance().apply {
                add(Calendar.YEAR, -1)
            }
            val lastYear = calLastYear.get(Calendar.YEAR)

            for (media in sortedList) {
                val mediaCal = Calendar.getInstance().apply {
                    timeInMillis = media.date
                }

                val mediaMonth = monthYearFormat.format(media.date)
                val mediaYear = mediaCal.get(Calendar.YEAR)

                val key = when {
                    mediaMonth == thisMonth -> "This Month"
                    mediaMonth == lastMonth -> "Last Month"
                    mediaYear == thisYear -> "This Year"
                    mediaYear == lastYear -> "Last Year"
                    else -> yearFormat.format(media.date)
                }

                val list = dateWisePictures.getOrPut(key) { ArrayList() }
                list.add(media)
            }

            // ✅ Limit each memory album to 8 random items
            dateWisePictures.forEach { (title, mediaList) ->
                if (mediaList.isNotEmpty()) {

                    val randomList = if (mediaList.size > 8) {
                        mediaList.shuffled().take(8)
                    } else {
                        mediaList
                    }

                    albumList.add(AlbumData(title, ArrayList(randomList)))
                }
            }

            customMemoryList.addAll(albumList)

            // ================= STORIES =================
            val storyMap = LinkedHashMap<String, ArrayList<MediaData>>()
            val dayFormat = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)

            val calLimit = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, -15)
            }
            val minDate = calLimit.timeInMillis

            for (media in sortedList) {

                // Only last 15 days
                if (media.date < minDate) continue

                val dayKey = dayFormat.format(media.date)

                val list = storyMap.getOrPut(dayKey) { ArrayList() }
                list.add(media)
            }

            // ✅ Max 15 stories, each with 3 random images
            var count = 0
            storyMap.forEach { (day, mediaList) ->

                if (count >= 15) return@forEach

                if (mediaList.isNotEmpty()) {

                    val randomList = if (mediaList.size > 3) {
                        mediaList.shuffled().take(3)
                    } else {
                        mediaList
                    }

                    customStoryList.add(
                        AlbumData(day, ArrayList(randomList))
                    )

                    count++
                }
            }

        } catch (e: Exception) {
            Log.e(TAG, "setMemoryAlbum Exception:$e")
        }

        Log.e(TAG, "setMemoryAlbum <<<<")
    }


    private fun getSelectionQuery(filterMedia: Int): String {
        val query = StringBuilder()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")

            rawExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
        }

        if (filterMedia and TYPE_GIFS != 0) {
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }
        return query.toString().trim().removeSuffix("OR")
    }

    private fun getSelectionArgsQuery(filterMedia: Int): ArrayList<String> {
        val args = ArrayList<String>()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.jpg")
            args.add("%.jpeg")
            rawExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.svg")
        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                args.add("%$it")
            }
        }
        if (filterMedia and TYPE_GIFS != 0) {
            args.add("%.gif")
        }

        return args
    }

    fun destroyLoader() {
        mJob.cancel()
    }

}
