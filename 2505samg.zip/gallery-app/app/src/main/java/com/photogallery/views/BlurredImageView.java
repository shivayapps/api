package com.photogallery.views;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;

public class BlurredImageView extends androidx.appcompat.widget.AppCompatImageView {

    private Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Bitmap blurredBitmap;

    public BlurredImageView(Context context) {
        super(context);
        init();
    }

    public BlurredImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public BlurredImageView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setScaleType(ScaleType.FIT_CENTER); // foreground behavior
    }

    @Override
    protected void onDraw(Canvas canvas) {
        Drawable drawable = getDrawable();
        if (drawable == null) return;

        Bitmap bitmap = drawableToBitmap(drawable);

        // Generate blurred background if needed
        if (blurredBitmap == null || blurredBitmap.isRecycled()) {
            blurredBitmap = blur(bitmap);
        }

        // 1. Draw blurred background (centerCrop)
        drawCenterCrop(canvas, blurredBitmap);

        // 2. Draw original image (fitCenter)
        drawFitCenter(canvas, bitmap);
    }

    private void drawCenterCrop(Canvas canvas, Bitmap bitmap) {
        RectF dst = new RectF(0, 0, getWidth(), getHeight());
        Matrix matrix = new Matrix();

        float scale;
        float dx = 0, dy = 0;

        if (bitmap.getWidth() * getHeight() > getWidth() * bitmap.getHeight()) {
            scale = (float) getHeight() / bitmap.getHeight();
            dx = (getWidth() - bitmap.getWidth() * scale) * 0.5f;
        } else {
            scale = (float) getWidth() / bitmap.getWidth();
            dy = (getHeight() - bitmap.getHeight() * scale) * 0.5f;
        }

        matrix.setScale(scale, scale);
        matrix.postTranslate(dx, dy);

        canvas.drawBitmap(bitmap, matrix, paint);
    }

    private void drawFitCenter(Canvas canvas, Bitmap bitmap) {
        RectF dst = new RectF(0, 0, getWidth(), getHeight());
        Matrix matrix = new Matrix();

        float scale = Math.min(
                (float) getWidth() / bitmap.getWidth(),
                (float) getHeight() / bitmap.getHeight()
        );

        float dx = (getWidth() - bitmap.getWidth() * scale) / 2f;
        float dy = (getHeight() - bitmap.getHeight() * scale) / 2f;

        matrix.setScale(scale, scale);
        matrix.postTranslate(dx, dy);

        canvas.drawBitmap(bitmap, matrix, paint);
    }

    private Bitmap drawableToBitmap(Drawable drawable) {
        if (drawable instanceof BitmapDrawable) {
            return ((BitmapDrawable) drawable).getBitmap();
        }

        Bitmap bitmap = Bitmap.createBitmap(
                drawable.getIntrinsicWidth(),
                drawable.getIntrinsicHeight(),
                Bitmap.Config.ARGB_8888
        );

        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);

        return bitmap;
    }

    private Bitmap blur(Bitmap src) {
        // ⚠️ Replace with fast blur (Stack Blur) or RenderEffect for API 31+
        return src; // placeholder
    }
}