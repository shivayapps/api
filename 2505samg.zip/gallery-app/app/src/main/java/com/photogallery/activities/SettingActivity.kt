package com.photogallery.activities

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.photogallery.R
import com.photogallery.base.BaseActivity
import com.photogallery.database.AppDatabase
import com.photogallery.databinding.ActivitySettingBinding
import com.photogallery.dialog.BiometricErrorDialog
import com.photogallery.dialog.ChangLockStyleDialog
import com.photogallery.dialog.ActionConfirmationDialog
import com.photogallery.dialog.DateTimeDialog
import com.photogallery.dialog.RateUsDialog
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.extension.beVisibleIf
import com.photogallery.extension.getPreviousActivity
import com.photogallery.extension.isVisible
import com.photogallery.extension.isBiometricIdAvailable
import com.photogallery.extension.isSupportWithErrorInfo
import com.photogallery.extension.sendEmail
import com.photogallery.secret.LockChangeActivity
import com.photogallery.secret.LockSetActivity
import com.photogallery.secret.activity.PrivateActivity
import com.photogallery.utils.Constant
import com.photogallery.utils.Constant.ROTATE_BY_DEVICE_ROTATION
import com.photogallery.utils.Constant.ROTATE_BY_SYSTEM_SETTING
import com.photogallery.utils.Preferences
import com.photogallery.views.SwitchButton

class SettingActivity : BaseActivity() {

    //    var themeType = 0
    lateinit var preferences: Preferences
//    lateinit var adsPref: PrefCalls

    lateinit var binding: ActivitySettingBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        binding = ActivitySettingBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

//        adsPref = PrefCalls(this)
//        themeType = preferences.getThemeValue()

        initView()
        intListener()
    }

    private fun initView() {
        binding.cbTheme.isChecked = preferences.getThemeValue() == Constant.THEME_DARK
        binding.txtTitle.text = getString(R.string.settings)

        val selectLanguage = preferences.selectLanguageCode
        val langStr = getLanguage(selectLanguage)
        binding.tvLanguage.text = langStr
    }

    fun getLanguage(langPos: String): String {
        val langStr: String = when (langPos) {
            "en" -> getString(R.string.united_states)
            "es" -> getString(R.string.spain)
            "hi" -> getString(R.string.india)
            "fa" -> getString(R.string.iran)
            "fr" -> getString(R.string.france)
            "de" -> getString(R.string.germany)
            "zh" -> getString(R.string.china)
            "ja" -> getString(R.string.japan)
            "ko" -> getString(R.string.Korean)
            "ru" -> getString(R.string.russia)
            "pt" -> getString(R.string.portugal)
            "it" -> getString(R.string.italy)
            "tr" -> getString(R.string.turkey)
            "ar" -> getString(R.string.arabic)
            "th" -> getString(R.string.thailand)
            "da" -> getString(R.string.denmark)
            "no" -> getString(R.string.norway)
            "sv" -> getString(R.string.sweden)
            "pl" -> getString(R.string.poland)
            "fil" -> getString(R.string.philippines)
            "in" -> getString(R.string.indonesia)
            "fi" -> getString(R.string.finland)
            "ms" -> getString(R.string.malaysia)
            "nl" -> getString(R.string.nederlands)
            "sk" -> getString(R.string.slovakia)
            "vi" -> getString(R.string.vietnam)
            "iw" -> getString(R.string.israel)
            "bn" -> getString(R.string.bangladesh)
            "ur" -> getString(R.string.pakistan)
            else -> getString(R.string.united_states)
        }
        return langStr
    }

    fun toggleExpand(mainView: View, actionView: View) {
        if (mainView.isVisible()) {
            mainView.beGone()
            actionView.animate()
                .rotation(0f)
                .setDuration(500).start()
        } else {
            mainView.beVisible()
            actionView.animate()
                .rotation(180f)
                .setDuration(500).start()
        }
    }

    var isFingerprintAvailable = Pair(false, "")
    private fun intListener() {

        binding.icBack.setOnClickListener {
            finish()
        }

//        binding.llActionGeneral.setOnClickListener {
//            toggleExpand(binding.llGeneral, binding.ivActionGeneral)
////            binding.llGeneral.beVisibleIf(binding.llGeneral.isGone())
//        }
//        binding.llActionVideo.setOnClickListener {
//            toggleExpand(binding.llVideo, binding.ivActionVideo)
////            binding.llVideo.beVisibleIf(binding.llVideo.isGone())
//        }
//        binding.llActionFullScreen.setOnClickListener {
//            toggleExpand(binding.llFullScreen, binding.ivActionFullScreen)
//            binding.llFullScreen.beVisibleIf(binding.llFullScreen.isGone())
//        }
//        binding.llActionDeepZoom.setOnClickListener {
//            toggleExpand(binding.llDeepZoom, binding.ivActionDeepZoom)
////            binding.llDeepZoom.beVisibleIf(binding.llDeepZoom.isGone())
//        }
//        binding.llActionSecurity.setOnClickListener {
//            toggleExpand(binding.llSecurity, binding.ivActionSecurity)
////            binding.llSecurity.beVisibleIf(binding.llSecurity.isGone())
//        }
//        binding.llActionFileOperation.setOnClickListener {
//            toggleExpand(binding.llFileOperation, binding.ivActionFileOperation)
////            binding.llFileOperation.beVisibleIf(binding.llFileOperation.isGone())
//        }
//        binding.llActionVisibility.setOnClickListener {
//            toggleExpand(binding.llVisibility, binding.ivActionVisibility)
////            binding.llVisibility.beVisibleIf(binding.llVisibility.isGone())
//        }
//        binding.llActionRecycleBin.setOnClickListener {
//            toggleExpand(binding.llRecycleBin, binding.ivActionRecycleBin)
////            binding.llRecycleBin.beVisibleIf(binding.llRecycleBin.isGone())
//        }
//        binding.llActionMore.setOnClickListener {
//            toggleExpand(binding.llMore, binding.ivActionMore)
////            binding.llMore.beVisibleIf(binding.llMore.isGone())
//        }

        binding.cbTheme.setOnCheckedChangeListener(object : SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                themeType = if (isChecked) {
                    Constant.THEME_DARK
                } else {
                    Constant.THEME_LIGHT
                }
                preferences.putTheme(themeType)

                val intent = Intent(this@SettingActivity, SettingActivity::class.java)
                setResult(RESULT_OK)
                finish()
                overridePendingTransition(0, 0)
                startActivity(intent)
                overridePendingTransition(0, 0)
//                ThemeChanger(this@SettingActivity, binding.cbTheme).switchTheme()
//                if(com.anter.library_circular_reveal_theme_changer.utils.ThemeUtilsImpl().isDarkTheme(this@SettingActivity)) {
//                    preferences.putTheme(Constant.THEME_DARK)
//                } else {
//                    preferences.putTheme(Constant.THEME_LIGHT)
//                }
//                val intent = Intent(this@SettingActivity, SettingActivity::class.java)
//                setResult(RESULT_OK)
//                finish()
//                overridePendingTransition(0, 0)
//                startActivity(intent)
//                overridePendingTransition(0, 0)
            }
        })

        binding.cbDeleteAfter30Days.isChecked = preferences.deleteAfter30Days
        binding.cbDeleteAfter30Days.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.deleteAfter30Days = isChecked
            }
        })
        binding.llClearRecycleBin.setOnClickListener {
            val confirmationDialog = ActionConfirmationDialog(
                this,
                getString(R.string.clear_recycle_bin),
                getString(R.string.are_you_sure_you_want_to_clear_recycle_bin),
                getString(R.string.clear),
                positiveBtnClickListener = {
                    AppDatabase.getInstance(this@SettingActivity).dataDao().removeAllRecentDelete()
                })
            confirmationDialog.show()
        }
//        binding.cbCall.isChecked = adsPref.isShowCallInfo
//        binding.hintCall.beVisibleIf(!adsPref.isShowCallInfo)
//        binding.icCall.beVisibleIf(!adsPref.isShowCallInfo)
//
//        binding.cbCall.setOnCheckedChangeListener(object :
//            SwitchButton.OnCheckedChangeListener {
//            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
//                if (isChecked) {
//                    checkCaller()
//                } else {
//                    adsPref.isShowCallInfo = isChecked
//                }
//            }
//        })

//        binding.cbRememberLast.isChecked = preferences.rememberLastVideoPosition
//        binding.cbRememberLast.setOnCheckedChangeListener(object :
//            SwitchButton.OnCheckedChangeListener {
//            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
//                preferences.rememberLastVideoPosition = isChecked
//            }
//        })

        binding.cbAutoPlay.isChecked = preferences.autoplayVideos
        binding.cbAutoPlay.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.autoplayVideos = isChecked
            }
        })

        binding.llPrivate.setOnClickListener {
            val intent = Intent(this, LockSetActivity::class.java)
            privateActivityResultLauncher.launch(intent)
        }

//        binding.cbLoopVideos.isChecked = preferences.loopVideos
//        binding.cbLoopVideos.setOnCheckedChangeListener(object :
//            SwitchButton.OnCheckedChangeListener {
//            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
//                preferences.loopVideos = isChecked
//            }
//        })
//        binding.cbVerticalGestures.isChecked = preferences.allowVideoGestures
//        binding.cbVerticalGestures.setOnCheckedChangeListener(object :
//            SwitchButton.OnCheckedChangeListener {
//            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
//                preferences.allowVideoGestures = isChecked
//            }
//        })


//        binding.cbAllowDownGesture.isChecked = preferences.allowDownGesture
//        binding.cbAllowDownGesture.setOnCheckedChangeListener(object :
//            SwitchButton.OnCheckedChangeListener {
//            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
//                preferences.allowDownGesture = isChecked
//            }
//        })
//        binding.cbAllowRotatingGestures.isChecked = preferences.allowRotatingWithGestures
//        binding.cbAllowRotatingGestures.setOnCheckedChangeListener(object :
//            SwitchButton.OnCheckedChangeListener {
//            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
//                preferences.allowRotatingWithGestures = isChecked
//            }
//        })
//        binding.cbAllowDoubleTaps.isChecked = preferences.allowOneToOneZoom
//        binding.cbAllowDoubleTaps.setOnCheckedChangeListener(object :
//            SwitchButton.OnCheckedChangeListener {
//            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
//                preferences.allowOneToOneZoom = isChecked
//            }
//        })
//        binding.cbAllowInstantChange.isChecked = preferences.allowInstantChange
//        binding.cbAllowInstantChange.setOnCheckedChangeListener(object :
//            SwitchButton.OnCheckedChangeListener {
//            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
//                preferences.allowInstantChange = isChecked
//            }
//        })
//        binding.cbAllowDeepZooming.isChecked = preferences.allowZoomingImages
//        binding.cbAllowDeepZooming.setOnCheckedChangeListener(object :
//            SwitchButton.OnCheckedChangeListener {
//            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
//                preferences.allowZoomingImages = isChecked
//            }
//        })
//        binding.cbAllowBrightnessGesture.isChecked = preferences.allowPhotoGestures
//        binding.cbAllowBrightnessGesture.setOnCheckedChangeListener(object :
//            SwitchButton.OnCheckedChangeListener {
//            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
//                preferences.allowPhotoGestures = isChecked
//            }
//        })


//        binding.cbHighestQuality.isChecked = preferences.showHighestQuality
//        binding.cbHighestQuality.setOnCheckedChangeListener(object :
//            SwitchButton.OnCheckedChangeListener {
//            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
//                preferences.showHighestQuality = isChecked
//            }
//        })
        binding.cbBlackBackground.isChecked = preferences.blackBackground
        binding.cbBlackBackground.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.blackBackground = isChecked
            }
        })

        binding.cbMaxBrightness.isChecked = preferences.maxBrightness
        binding.cbMaxBrightness.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.maxBrightness = isChecked
            }
        })
//        binding.cbHideSystemUi.isChecked = preferences.hideSystemUI
//        binding.cbHideSystemUi.setOnCheckedChangeListener(object :
//            SwitchButton.OnCheckedChangeListener {
//            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
//                preferences.hideSystemUI = isChecked
//            }
//        })
        val isSupportFingerprint = isBiometricIdAvailable()
        Log.e("BiometricManager", "\nisSupportFingerprint:$isSupportFingerprint")

        isFingerprintAvailable =
            isSupportWithErrorInfo(this, BiometricManager.Authenticators.BIOMETRIC_STRONG)

        binding.llFingerprint.beVisibleIf(isSupportFingerprint)
        binding.cbFingerprint.isChecked =
            preferences.enableFingerprint && isFingerprintAvailable.first

        binding.cbFingerprint.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                if (isChecked) {
                    if (isFingerprintAvailable.first) {
                        preferences.enableFingerprint = true
                    } else {
                        val biometricErrorDialog =
                            BiometricErrorDialog(this@SettingActivity) { isEnable ->
                                if (isEnable) {
                                    val enrollIntent = Intent(Settings.ACTION_BIOMETRIC_ENROLL)
                                    enrollIntent.putExtra(
                                        Settings.EXTRA_BIOMETRIC_AUTHENTICATORS_ALLOWED,
                                        BiometricManager.Authenticators.BIOMETRIC_STRONG
                                    )
                                    biomatricLauncher.launch(enrollIntent)
                                } else {
                                    binding.cbFingerprint.isChecked = false
                                }

                            }
                        preferences.enableFingerprint = false
                        biometricErrorDialog.setOnDismissListener {
                            binding.cbFingerprint.isChecked = false
                        }
                        biometricErrorDialog.show()

                    }
                } else {
                    preferences.enableFingerprint = false
                }

            }
        })


//        binding.cbVaultVisibility.isChecked = preferences.hideVault
//        binding.cbVaultVisibility.setOnCheckedChangeListener(object :
//            SwitchButton.OnCheckedChangeListener {
//            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
//                preferences.hideVault = isChecked
//                if (isChecked) {
//                    val hintDialog = HintDialog(
//                        getString(R.string.hide_hidden_album),
//                        R.drawable.ic_hint_vault,
//                        updateListener = {
//                            //preferences.hideVault=true
//                        })
//                    hintDialog.show(supportFragmentManager, hintDialog.tag)
//                }
//            }
//        })

//        binding.llCameraVisibility.setOnClickListener {
//            val hintDialog = HintDialog(
//                getString(R.string.hide_camera),
//                R.drawable.ic_hint_camera,
//                updateListener = {
//                    //preferences.hideCamera=true
//                })
//            hintDialog.show(supportFragmentManager, hintDialog.tag)
//        }
//        binding.cbCameraVisibility.isChecked = preferences.hideCamera
//        binding.cbCameraVisibility.setOnCheckedChangeListener(object :
//            SwitchButton.OnCheckedChangeListener {
//            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
//                preferences.hideCamera = isChecked
//                if (isChecked) {
//                    val hintDialog = HintDialog(
//                        getString(R.string.hide_camera),
//                        R.drawable.ic_hint_camera,
//                        updateListener = {
//                            //preferences.hideCamera=true
//                        })
//                    hintDialog.show(supportFragmentManager, hintDialog.tag)
//                }
//            }
//        })

//        binding.tvRotateFullscreen.text = getScreenRotationText()
//        binding.llRotateFullscreen.setOnClickListener {
//
//            val items = arrayListOf(
//                RadioItem(
//                    ROTATE_BY_SYSTEM_SETTING,
//                    getString(R.string.screen_rotation_system_setting)
//                ),
//                RadioItem(
//                    ROTATE_BY_DEVICE_ROTATION,
//                    getString(R.string.screen_rotation_device_rotation)
//                ),
//                RadioItem(ROTATE_BY_ASPECT_RATIO, getString(R.string.screen_rotation_aspect_ratio))
//            )
//
//            val radioGroupDialog = RadioGroupDialog(items, preferences.screenRotation) {
//                preferences.screenRotation = it
//                binding.tvRotateFullscreen.text = getScreenRotationText()
//            }
//            radioGroupDialog.show(supportFragmentManager, radioGroupDialog.tag)
//        }

        binding.llLanguage.setOnClickListener {
            languageLauncher.launch(Intent(this, LanguageSelectionActivity::class.java))
//                .putExtra(Constant.EXTRA_IS_OPEN_FROM_SPLASH, false)
        }

        binding.llDateTime.setOnClickListener {
            val dateTimeDialog = DateTimeDialog(this, updateListener = {

            })
            dateTimeDialog.show()

        }

//        binding.llIncludedFolder.setOnClickListener {
//            dirsActivityResultLauncher.launch(
//                Intent(this, DirsActivity::class.java)
//                    .putExtra("dirType", Constant.TYPE_INCLUDED)
//            )
//        }


        binding.llRateUs.setOnClickListener {

            val rateDialog = RateUsDialog(this) { isExit ->
//                if (isExit) {
//                    finishAffinity()
//                }else{
//                    launchAppStore()
//                }
            }
            rateDialog.show()
        }

//        binding.llExcludedFolder.setOnClickListener {
//            dirsActivityResultLauncher.launch(
//                Intent(this, DirsActivity::class.java)
//                    .putExtra("dirType", Constant.TYPE_EXCLUDED)
//            )
//        }

        binding.llChangePassword.setOnClickListener {
            val intent = Intent(this, LockSetActivity::class.java)
            lockCahngeActivityResultLauncher.launch(intent)
        }

        binding.llFeedbackSuggestions.setOnClickListener {
            sendEmail("solutionsventuras@gmail.com", "GalleryApp Feedback/Suggestion", "Message:\n")
        }

        binding.llPrivacyPolicy.setOnClickListener {
            openPrivacyPolicy()
        }
        binding.llShareApp.setOnClickListener {

            try {
                val sendIntent = Intent()
                sendIntent.action = Intent.ACTION_SEND
                sendIntent.putExtra(
                    Intent.EXTRA_TEXT,
                    "Check out the App at: https://play.google.com/store/apps/details?id=$packageName"
                )
                sendIntent.type = "text/plain"
                startActivity(sendIntent)
            } catch (e: Exception) {

            }
        }

    }



    var privateActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        Log.e("POST_NOTIFICATIONS", "lockActivityResultLauncher:${result.resultCode}")
        if (result.resultCode == RESULT_OK) {
            val intent = Intent(this@SettingActivity, PrivateActivity::class.java)
            startActivity(intent)
        }
    }
    var lockCahngeActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        Log.e("POST_NOTIFICATIONS", "lockActivityResultLauncher:${result.resultCode}")
        if (result.resultCode == RESULT_OK) {
            val intent = Intent(this, LockChangeActivity::class.java)
            intent.putExtra(Constant.EXTRA_RESET_PASS, true)
            intent.putExtra(Constant.EXTRA_CHANGE_PASS, true)
            startActivity(intent)
        }
    }

    private fun launchAppStore() {
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("http://play.google.com/store/apps/details?id=${packageName}")
        )
        startActivity(intent)
    }


    var languageLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                setResult(RESULT_OK)
                recreate()
                Constant.isChangeLanguage = true
            }
        }
    var biomatricLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
//            if (result.resultCode == Activity.RESULT_OK) {
//            val isFingerprintAvailable = isBiometricIdAvailable()
            isFingerprintAvailable =
                isSupportWithErrorInfo(this, BiometricManager.Authenticators.BIOMETRIC_STRONG)
            if (isFingerprintAvailable.first) {
                preferences.enableFingerprint = true
                binding.cbFingerprint.isChecked = true
            } else {
                preferences.enableFingerprint = false
                binding.cbFingerprint.isChecked = false
            }
//            }
        }

    fun openPrivacyPolicy() {
        val url = getPrivacyPolicy()
        if (url != null && url.isNotEmpty()) {
            try {
                val builder: CustomTabsIntent.Builder = CustomTabsIntent.Builder()
                builder.setToolbarColor(ContextCompat.getColor(this, R.color.color_primary))
                val customTabsIntent: CustomTabsIntent = builder.build()
                customTabsIntent.intent.setPackage("com.android.chrome")
                customTabsIntent.launchUrl(this, Uri.parse(url))

            } catch (e: Exception) {
                val i = Intent(Intent.ACTION_VIEW)
                i.data = Uri.parse(url)
                startActivity(i)
            }
        }
    }

    override fun onBackPressed() {
        val previousActivity = getPreviousActivity()
        if (previousActivity.contains("HomeActivity")) {
            finish()
        } else {
            val intent = Intent(this, HomeActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(intent)
        }
    }

    private fun getScreenRotationText() = getString(
        when (preferences.screenRotation) {
            ROTATE_BY_SYSTEM_SETTING -> R.string.screen_rotation_system_setting
            ROTATE_BY_DEVICE_ROTATION -> R.string.screen_rotation_device_rotation
            else -> R.string.screen_rotation_aspect_ratio
        }
    )

    var dirsActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
//            photosFragment.getData()
//            albumFragment.getData()
        }
    }
}