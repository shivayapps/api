package com.photogallery.edit.stickerPackage;

public class FlipVerticallyEvent extends AbstractFlipEvent {

  @Override @ StickerView.Flip protected int getFlipDirection() {
    return  StickerView.FLIP_VERTICALLY;
  }
}
