package com.photogallery.adapter;

public interface SelectAll {
    void selectAll(boolean isSelectAll,String type);
}
