package com.photogallery.utils;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;

public class AllUninstalledFilter implements FileFilter {
    ArrayList<String> filterInstalled;

    public AllUninstalledFilter(ArrayList<String> filterInstalled) {
        this.filterInstalled = filterInstalled;
    }

    @Override
    public boolean accept(File pathname) {
        if (pathname.getParentFile() != null && pathname.getParentFile().getParentFile() != null) {
            if (pathname.getParentFile().getName().equals("data") && pathname.getParentFile().getParentFile().getName().equals("Android"))
                return !filterInstalled.contains(pathname.getName()) && !pathname.getName().equals(".nomedia");
        }

        return false;
    }
}
