package com.photogallery.secret.adapter

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.photogallery.R
import com.photogallery.databinding.ItemHeaderBinding
import com.photogallery.databinding.ItemHeaderDarkBinding
import com.photogallery.databinding.ItemPictureBinding
import com.photogallery.databinding.ItemPictureDarkBinding
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class SelectImageAdapter(
    var context: Activity,
    var pictures: ArrayList<Any>,
    val clickListener: (pos: Int) -> Unit,
    val singleSelection: Boolean = false,
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

//    private var selectedImageList: ArrayList<MediaData> = ArrayList()

    val ITEM_PHOTOS_TYPE = 2
    val ITEM_HEADER_TYPE = 1

    private val format = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)

    override fun getItemViewType(position: Int): Int {
        return if (position >= 0 && position < pictures.size) {
            if (pictures[position] is AlbumData) {
                ITEM_HEADER_TYPE
            } else {
                ITEM_PHOTOS_TYPE
            }
        } else -1
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecyclerView.ViewHolder {

        return if (viewType == ITEM_HEADER_TYPE) {

            val binding = ItemHeaderBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )

            HeaderViewHolder(binding)

        } else {

            val binding = ItemPictureBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )

            PictureViewHolder(binding)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

        if (position < 0 || position >= pictures.size) return

        if (getItemViewType(position) == ITEM_HEADER_TYPE) {

            val headerViewHolder = holder as HeaderViewHolder
            val albumData = pictures[position] as AlbumData

            var strDate = albumData.title

            val calendar = Calendar.getInstance()

            val today = format.format(calendar.timeInMillis)

            calendar.add(Calendar.DATE, -1)

            val yesterday = format.format(calendar.timeInMillis)

            if (albumData.title == today) {
                strDate = context.getString(R.string.Today)
            } else if (albumData.title == yesterday) {
                strDate = context.getString(R.string.Yesterday)
            }

            headerViewHolder.binding.txtHeader.text = strDate

            headerViewHolder.binding.txtSelect.beGone()

            headerViewHolder.binding.btnSelect.setImageDrawable(
                if (albumData.isSelected) {
                    ContextCompat.getDrawable(
                        context,
                        R.drawable.ic_check_right
                    )
                } else {
                    ContextCompat.getDrawable(
                        context,
                        R.drawable.ic_check_off
                    )
                }
            )

        } else {

            val pictureViewHolder = holder as PictureViewHolder

            val pictureData = pictures[position] as MediaData

            Glide.with(context.application)
                .load(pictureData.filePath)
                .into(pictureViewHolder.binding.image)

            pictureViewHolder.binding.icVideo.visibility =
                if (pictureData.isVideo) View.VISIBLE else View.GONE

            updateSelectionUI(
                pictureViewHolder,
                pictureData.isSelected
            )

            holder.binding.loutMain.setOnClickListener {

                val pos = holder.adapterPosition
                if (pos == RecyclerView.NO_POSITION) return@setOnClickListener
                clickListener.invoke(pos)
            }

            pictureViewHolder.binding.icFavourite.visibility = View.GONE
        }
    }


    override fun getItemCount(): Int {
        return pictures.size
    }

    fun toggleSelection(position: Int): MediaData? {

        val item = pictures[position] as? MediaData ?: return null

        item.isSelected = !item.isSelected

        notifyItemChanged(position)

        return item
    }

    fun selectSingle(
        position: Int,
        prevPosition: Int
    ): MediaData? {

        if (prevPosition >= 0 &&
            prevPosition < pictures.size &&
            pictures[prevPosition] is MediaData
        ) {

            val prevItem = pictures[prevPosition] as MediaData

            prevItem.isSelected = false

            notifyItemChanged(prevPosition)
        }

        val currentItem = pictures[position] as? MediaData ?: return null

        currentItem.isSelected = true

        notifyItemChanged(position)

        return currentItem
    }

    private fun updateSelectionUI(
        holder: PictureViewHolder,
        isSelected: Boolean
    ) {

        holder.binding.icUnSelect.visibility =
            if (isSelected) View.GONE else View.VISIBLE

        holder.binding.icSelect.visibility =
            if (isSelected) View.VISIBLE else View.GONE
    }

    /**
     * Get Selected Images
     */
//    fun getSelectedImages(): ArrayList<MediaData> {
//        return ArrayList(selectedImageList)
//    }

    /**
     * Get Selected Count
     */
//    fun getSelectedCount(): Int {
//        return selectedImageList.size
//    }

    /**
     * Deselect Single Item
     */
    fun deselectMedia(mediaData: MediaData): MediaData? {

        val position = pictures.indexOf(mediaData)

        if (position < 0 || position >= pictures.size) {
            return null
        }

        val item = pictures[position] as? MediaData ?: return null

        item.isSelected = false

        notifyItemChanged(position)

        return item
    }

    fun deselect(position: Int): MediaData? {

        if (position < 0 || position >= pictures.size) {
            return null
        }

        val item = pictures[position] as? MediaData ?: return null

        item.isSelected = false

        notifyItemChanged(position)

        return item
    }

    fun clearSelection() {

        val changedPositions = ArrayList<Int>()

        pictures.forEachIndexed { index, item ->

            if (item is MediaData && item.isSelected) {

                item.isSelected = false
                changedPositions.add(index)
            }
        }

        changedPositions.forEach {
            notifyItemChanged(it)
        }
    }

    /**
     * Clear All Selection
     */
//    fun clearSelection() {
//
//        selectedImageList.forEach {
//            it.isSelected = false
//        }
//
//        selectedImageList.clear()
//
//        notifyDataSetChanged()
//    }

    /**
     * Select All Media Items
     */
//    fun selectAll() {
//
//        selectedImageList.clear()
//
//        pictures.forEach { item ->
//
//            if (item is MediaData) {
//
//                item.isSelected = true
//
//                selectedImageList.add(item)
//            }
//        }
//
//        notifyDataSetChanged()
//    }

    class HeaderViewHolder(var binding: ItemHeaderBinding) :
        RecyclerView.ViewHolder(binding.root)

    class PictureViewHolder(var binding: ItemPictureBinding) :
        RecyclerView.ViewHolder(binding.root)
}