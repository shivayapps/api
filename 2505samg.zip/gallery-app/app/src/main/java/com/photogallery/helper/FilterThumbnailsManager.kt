package com.photogallery.helper

import android.content.Context
import android.graphics.Bitmap
import com.photogallery.R
import com.photogallery.edit.model.FilterItem

class FilterThumbnailsManager {
    private var filterThumbnails = ArrayList<FilterItem>(10)
    private var processedThumbnails = ArrayList<FilterItem>(10)

    fun addThumb(filterItem: FilterItem) {
        filterThumbnails.add(filterItem)
    }

    fun processThumbs(context: Context): List<FilterItem> {
        for (thumb in filterThumbnails) {
            // scaling down the image
            val size = context.resources.getDimension(R.dimen.bottom_filters_thumbnail_size)
            thumb.bitmap = Bitmap.createScaledBitmap(
                thumb.bitmap!!, size.toInt(), size.toInt(), false
            )
            thumb.bitmap = thumb.filter.processFilter(thumb.bitmap)!!
            //cropping circle
//            thumb.bitmap = GeneralUtils.generateCircularBitmap(thumb.bitmap)
            processedThumbnails.add(thumb)
        }

        return processedThumbnails
    }

    fun clearThumbs() {
        filterThumbnails = ArrayList()
        processedThumbnails = ArrayList()
    }
}
