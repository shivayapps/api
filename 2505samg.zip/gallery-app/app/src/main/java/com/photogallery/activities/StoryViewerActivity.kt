package com.photogallery.activities

import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.enableEdgeToEdge
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CenterCrop
import jp.wasabeef.glide.transformations.BlurTransformation
import com.funrisestudio.stories.StoriesView
import com.funrisestudio.stories.StoryContent
import com.photogallery.R
import com.photogallery.base.BaseActivity
import com.photogallery.databinding.ActivityStoryViewerBinding
import com.photogallery.databinding.ItemShareBinding
import com.photogallery.dialog.SimpleProgressDialog
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.extension.isVisible
import com.photogallery.extension.openEditorIntent
import com.photogallery.extension.toast
import com.photogallery.jobs.ImageSlideshowEncoder
import com.photogallery.utils.Constant
import com.photogallery.utils.Mp4Maker
import com.photogallery.utils.Preferences
import com.photogallery.views.SwitchButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

class StoryViewerActivity : BaseActivity() {

    lateinit var preferences: Preferences
    lateinit var binding: ActivityStoryViewerBinding
    var progressDialog : SimpleProgressDialog?=null
    var asVideo = false
    var targetVideoPath = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        binding = ActivityStoryViewerBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val myImagePaths = intent.getStringArrayListExtra("IMAGE_PATHS") ?: arrayListOf()
        val mTitle = intent.getStringExtra("TITLE") ?: ""
        binding.txtTitle.text = mTitle

        val stories = listOf(
            myImagePaths.map { path ->
                StoryContent(path)
            }
        )

        targetVideoPath = generateFileName()
        binding.vStories.init(this)
        binding.vStories.setStories(stories)
        binding.vStories.setStoriesListener(object : StoriesView.StoriesListener {
            override fun onComplete() {
                finish()
            }

            override fun onPageSelected(position: Int) {
                val currentPath = myImagePaths[binding.vStories.getCurrentPosition()]
                binding.txtSubTitle.text = formatDate(File(currentPath).lastModified())
            }

        })

        binding.ivClose.setOnClickListener {
            finish()
        }
        binding.ivEdit.setOnClickListener {
            val currentPath = myImagePaths[binding.vStories.getCurrentPosition()]
            val newPath = currentPath.removePrefix("file://")
            openEditorIntent(newPath)
        }

        val shareAdapter = ShareImageAdapter(myImagePaths)
        binding.vpShare.adapter = shareAdapter
//        binding.vpShare.centerVertically()
        binding.vpShare.set3DItem(false)
        binding.vpShare.setAlpha(false)
        binding.vpShare.setInfinite(false)

        Glide.with(this)
            .load(myImagePaths[0])
            .transform(
                CenterCrop(),
                BlurTransformation(30, 3)
            )
            .into(binding.ivShareBlur)

        binding.ivShare.setOnClickListener {
            shareAdapter.selectAll()
            shareAdapter.notifyDataSetChanged()
            asVideo = false
//            binding.cbShareAs.isChecked = false
            binding.txtShareImage.backgroundTintList =
                ColorStateList.valueOf(ContextCompat.getColor(this, R.color.color_primary))
            binding.txtShareVideo.backgroundTintList =
                ColorStateList.valueOf(Color.parseColor("#7E7E7E"))
            asVideo = false
            binding.vStories.pause()
            binding.clShareView.beVisible()
//            binding.clMainView.beGone()
            binding.vpShare.scrollToPosition(binding.vStories.getCurrentPosition())
        }
//        binding.outView.setOnClickListener {
//            binding.clShareView.beGone()
////            binding.clMainView.beVisible()
//            binding.vStories.resume()
//        }
        binding.ivCancelShare.setOnClickListener {
            binding.clShareView.beGone()
//            binding.clMainView.beVisible()
            binding.vStories.resume()
        }

        binding.txtShareImage.setOnClickListener {
            binding.txtShareImage.backgroundTintList =
                ColorStateList.valueOf(ContextCompat.getColor(this, R.color.color_primary))
            binding.txtShareVideo.backgroundTintList =
                ColorStateList.valueOf(Color.parseColor("#7E7E7E"))
            asVideo = false
        }
        binding.txtShareVideo.setOnClickListener {
            binding.txtShareImage.backgroundTintList =
                ColorStateList.valueOf(Color.parseColor("#7E7E7E"))
            binding.txtShareVideo.backgroundTintList =
                ColorStateList.valueOf(ContextCompat.getColor(this, R.color.color_primary))

            asVideo = true
        }

//        binding.cbShareAs.setOnCheckedChangeListener(object : SwitchButton.OnCheckedChangeListener {
//            override fun onCheckedChanged(
//                view: SwitchButton?,
//                isChecked: Boolean
//            ) {
//                if (isChecked) binding.txtShareAs.setText(getString(R.string.share_video))
//                else binding.txtShareAs.setText(getString(R.string.share_image))
//                asVideo = isChecked
//            }
//        })
        binding.llFaceBook.setOnClickListener {
            val pathList = shareAdapter.getSelectedList()
            if (asVideo) shareAsVideo(pathList, Constant.FACEBOOK)
            else shareToApp(this, pathList, Constant.FACEBOOK)
        }

        binding.llTwitter.setOnClickListener {
            val pathList = shareAdapter.getSelectedList()
            if (asVideo) shareAsVideo(pathList, Constant.TWITTER)
            else shareToApp(this, pathList, Constant.TWITTER)
        }

        binding.llWhatsApp.setOnClickListener {
            val pathList = shareAdapter.getSelectedList()
            if (asVideo) shareAsVideo(pathList, Constant.WHATSAPP)
            else shareToApp(this, pathList, Constant.WHATSAPP)
        }

        binding.llSnapchat.setOnClickListener {
            val pathList = shareAdapter.getSelectedList()
            if (asVideo) shareAsVideo(pathList, Constant.SNAPCHAT)
            else shareToApp(this, pathList, Constant.SNAPCHAT)
        }

        binding.llOther.setOnClickListener {
            val pathList: List<String> = shareAdapter.getSelectedList()
            if (asVideo) shareAsVideo(pathList, null)
            else shareToApp(this, pathList, null) // system chooser
        }

        progressDialog = SimpleProgressDialog(
            this@StoryViewerActivity,
            getString(R.string.please_wait),
        )
        progressDialog?.setCancelable(false)

    }

    override fun onBackPressed() {
        if (binding.clShareView.isVisible()) {
            binding.clShareView.beGone()
//            binding.clMainView.beVisible()
            binding.vStories.resume()
        } else super.onBackPressed()
    }

    override fun onResume() {
        super.onResume()
        if (binding.clShareView.isVisible()) binding.vStories.pause()
    }

    fun formatDate(timestamp: Long): String {
        val sdf = java.text.SimpleDateFormat("dd/yy/MMMM", java.util.Locale.getDefault())
        return sdf.format(java.util.Date(timestamp))
    }

    fun generateFileName(): String {
        val targetFolder = File(Constant.EDIT_PATH)
        if (!targetFolder.exists())
            targetFolder.mkdirs()

        val name = "Vid"
        val type = "MP4"

        val targetPath =
            targetFolder.path + "/" + name + "_" + System.currentTimeMillis() + "." + type

        Log.e("Mp4Maker", "targetPath:$targetPath")

        return targetPath
    }

    fun shareAsVideo(pathList: List<String>, packageName: String? = null) {

        val targetFile = File(targetVideoPath)
        if (targetFile.exists()) {
            Log.e("Mp4Maker", "Using cached video")
            shareVideo(this@StoryViewerActivity, targetVideoPath, packageName)
            return
        }

        Log.e("Mp4Maker", "targetVideoPath:$targetVideoPath")

        if(progressDialog==null) {
            progressDialog = SimpleProgressDialog(
                this@StoryViewerActivity,
                getString(R.string.please_wait),
            )
            progressDialog?.setCancelable(false)
        }

        progressDialog?.show()

        lifecycleScope.launch(Dispatchers.IO) {
            val encoder = ImageSlideshowEncoder(width = 720, height = 1280)

            encoder.createVideo(
                imagePaths = pathList,
                outputFile = targetVideoPath,
                secondsPerImage = 3,
                object : ImageSlideshowEncoder.EncodeListener {

                    override fun onStart(totalFrames: Int) {}

                    override fun onProgress(current: Int, total: Int) {}

                    override fun onCompleted(outputPath: String) {
                        runOnUiThread {
                            shareVideo(this@StoryViewerActivity, outputPath, packageName)
                            progressDialog?.dismiss()
                        }
                    }

                    override fun onError(e: Exception) {
                        runOnUiThread {
                            toast("Error occurred, please try again.")
                            progressDialog?.dismiss()
                        }
                    }
                }
            )
        }


    }

//    fun shareAsVideo1(pathList: List<String>, packageName: String? = null) {
//
//        val targetFile = File(targetVideoPath)
//        if (targetFile.exists()) {
//            Log.e("Mp4Maker", "Using cached video")
//            shareVideo(this@StoryViewerActivity, targetVideoPath, packageName)
//            return
//        }
//
//        Log.e("Mp4Maker", "targetVideoPath:$targetVideoPath")
//
//        val progressDialog = SimpleProgressDialog(
//            this@StoryViewerActivity,
//            getString(R.string.please_wait),
//        )
//        progressDialog.setCancelable(false)
//        progressDialog.show()
//
//        Mp4Maker().makeMp4FromPath(this, pathList, targetVideoPath, 2, object : Mp4Maker.OnMp4Listener {
//            override fun onStart(totalFrames: Int) {
//                Log.e("Mp4Maker", "onStart:$totalFrames")
//            }
//
//            override fun onProgress(current: Int, total: Int) {
//                Log.e("Mp4Maker", "onProgress:$current/$total")
//            }
//
//            override fun onCompleted(outputPath: String) {
//                Log.e("Mp4Maker", "onCompleted:$outputPath")
//                shareVideo(this@StoryViewerActivity, outputPath, packageName)
//                progressDialog.dismiss()
//            }
//
//            override fun onError(e: java.lang.Exception?) {
//                Log.e("Mp4Maker", "onError:$e")
//                toast("Error occurred, please try again.")
//                progressDialog.dismiss()
//            }
//        })
//
//    }

    fun shareVideo(
        context: Context,
        videoPath: String,
        packageName: String? = null
    ) {
        val file = File(videoPath)

        val uri = FileProvider.getUriForFile(
            context,
            context.packageName + ".provider",
            file
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "video/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            packageName?.let { setPackage(it) }
        }

        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            // fallback to chooser
            context.startActivity(
                Intent.createChooser(intent, "Share Video")
            )
        }
    }

    fun shareToApp(
        context: Context,
        paths: List<String>,
        packageName: String? = null
    ) {
        val uris = getUris(context, paths)

        val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "image/*"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            setPackage(packageName)
        }

        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            // fallback
            shareMultipleImages(context, paths)
        }
    }

    fun shareMultipleImages(context: Context, paths: List<String>) {
        val uris = getUris(context, paths)

        val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "image/*"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        context.startActivity(Intent.createChooser(intent, "Share images"))
    }

    fun getUris(context: Context, paths: List<String>): ArrayList<Uri> {
        val uris = ArrayList<Uri>()

        paths.forEach { path ->
            val file = File(path)
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.provider",
                file
            )
            uris.add(uri)
        }

        return uris
    }

    class ShareImageAdapter(
        private val images: List<String>
    ) : RecyclerView.Adapter<ShareImageAdapter.ImageViewHolder>() {

        // ✅ holds selected items
        private val selectedSet = mutableSetOf<String>()

        inner class ImageViewHolder(val binding: ItemShareBinding) :
            RecyclerView.ViewHolder(binding.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImageViewHolder {
            val binding = ItemShareBinding.inflate(
                LayoutInflater.from(parent.context), parent, false
            )
            return ImageViewHolder(binding)
        }

        override fun getItemCount() = images.size

        // ✅ return selected list
        fun getSelectedList(): List<String> {
            return selectedSet.toList()
        }

        fun selectAll() {
            selectedSet.addAll(images)
        }

        override fun onBindViewHolder(
            holder: ImageViewHolder,
            position: Int,
            payloads: MutableList<Any>
        ) {
            if (payloads.isNotEmpty()) {
                val item = images[position]
                val isSelected = selectedSet.contains(item)

                holder.binding.icSelect.visibility =
                    if (isSelected) View.VISIBLE else View.GONE

                return
            }

            super.onBindViewHolder(holder, position, payloads)
        }

        override fun onBindViewHolder(holder: ImageViewHolder, position: Int) {
            val item = images[position]

            Glide.with(holder.itemView)
                .load(item)
                .into(holder.binding.image)

            val isSelected = selectedSet.contains(item)
            holder.binding.icSelect.visibility =
                if (isSelected) View.VISIBLE else View.GONE
            holder.binding.image.setOnClickListener {
                if (selectedSet.contains(item)) {
                    selectedSet.remove(item)
                } else {
                    selectedSet.add(item)
                }
                notifyItemChanged(position, "selection")
            }

            holder.binding.icUnSelect.setOnClickListener {
                selectedSet.add(item)
                notifyItemChanged(position, "selection")
            }

            holder.binding.icSelect.setOnClickListener {
                selectedSet.remove(item)
                notifyItemChanged(position, "selection")
            }
        }

    }

}