package com.photogallery.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.text.format.DateFormat
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.photogallery.R
import com.photogallery.databinding.ItemStoryCardBinding
import com.photogallery.extension.beVisible
import com.photogallery.model.AlbumData
import com.photogallery.utils.Preferences
import java.io.File


class StoryCardAdapter(
    var context: Context,
    val clickListener: (albumData: AlbumData) -> Unit
) : ListAdapter<AlbumData, RecyclerView.ViewHolder>(DiffCallBack()) {

    private class DiffCallBack : DiffUtil.ItemCallback<AlbumData>() {
        override fun areItemsTheSame(oldItem: AlbumData, newItem: AlbumData) = oldItem == newItem

        @SuppressLint("DiffUtilEquals")
        override fun areContentsTheSame(oldItem: AlbumData, newItem: AlbumData) = oldItem == newItem
    }

    var preferences: Preferences = Preferences(context)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = ItemStoryCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return AlbumGridViewHolder(binding)
    }


    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        holder.itemView.tag = holder

        val albumGridViewHolder = holder as AlbumGridViewHolder

        val albumData: AlbumData = getItem(position) as AlbumData

        albumGridViewHolder.binding.viewFront.setOnClickListener {
            clickListener(albumData)
        }

        albumGridViewHolder.binding.txtSubTitle.text = albumData.title
        if (albumData.mediaData.isNotEmpty()) {
            var strTitle = DateFormat.format("MMMM yyyy", albumData.mediaData[0].date).toString()
            albumGridViewHolder.binding.txtTitle.text = strTitle
            albumGridViewHolder.binding.image.beVisible()
            Glide.with(context.applicationContext)
                .load(albumData.mediaData[0].filePath)
                .into(albumGridViewHolder.binding.image)

        } else {
            albumGridViewHolder.binding.txtTitle.text = ""
            albumGridViewHolder.binding.image.setImageDrawable(
                ContextCompat.getDrawable(
                    context,
                    R.drawable.ic_image_placeholder
                )
            )
        }
    }

    class AlbumGridViewHolder(var binding: ItemStoryCardBinding) :
        RecyclerView.ViewHolder(binding.root)



}