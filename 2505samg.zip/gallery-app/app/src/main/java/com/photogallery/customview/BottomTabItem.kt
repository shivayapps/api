package com.photogallery.customview

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import com.photogallery.R
import com.photogallery.extension.applyColorFilter
import com.photogallery.extension.beGone
import com.photogallery.extension.beGoneIf
import com.photogallery.extension.beVisible

class BottomTabItem @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    private val container: LinearLayout
    private val icon: ImageView
    private val selected: ImageView
    private val title: TextView

    private var selectedIconRes: Int = 0
    private var unselectedIconRes: Int = 0
    private val mediumFont by lazy {
        ResourcesCompat.getFont(context, R.font.sf_medium)
    }

    private val boldFont by lazy {
        ResourcesCompat.getFont(context, R.font.sf_bold)
    }
    var isSelectedTab = false
        set(value) {
            field = value
            updateState()
        }

    init {
        LayoutInflater.from(context).inflate(R.layout.item_bottom_tab, this, true)
        container = findViewById(R.id.container)
        icon = findViewById(R.id.icon)
        selected = findViewById(R.id.selected)
        title = findViewById(R.id.title)

        updateState()
    }

    fun setData(selectedIcon: Int, unselectedIcon: Int, text: String) {
        this.selectedIconRes = selectedIcon
        this.unselectedIconRes = unselectedIcon

        title.text = text
        updateState()
    }

    private fun updateState() {
        if (isSelectedTab) {
            //container.orientation = LinearLayout.HORIZONTAL
            selected.beVisible()
            val colorState = context.resources.getColor(R.color.black)
            title.setPadding(0, 0, 0, 0)
            title.setTextColor(colorState)
            title.typeface = boldFont
            title.isSelected = true

            icon.setImageResource(selectedIconRes)
//            icon.applyColorFilter(colorState)
            icon.imageTintList= ColorStateList.valueOf(colorState)
        } else {
            selected.beGone()
            val colorState = context.resources.getColor(R.color.menu_inactive)
            container.setBackgroundResource(android.R.color.transparent)
            title.setPadding(0, 4, 0, 0)
            title.setTextColor(colorState)
            title.typeface = mediumFont
            title.isSelected = false

            icon.setImageResource(unselectedIconRes)
//            icon.applyColorFilter(colorState)
            icon.imageTintList= ColorStateList.valueOf(colorState)
        }
    }
}
