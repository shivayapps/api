package com.photogallery.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.photogallery.utils.Constant

@Database(
    entities = [HiddenData::class, RecentDeleteData::class, LocationEntity::class, RecoverData::class, Categories::class],
    version = 2
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun dataDao(): DatabaseDao
    abstract fun vaultDao(): VaultDao
    abstract fun categoriesDao(): CategoriesDao

    companion object {
        private var instance: AppDatabase? = null

        @Synchronized
        fun getInstance(ctx: Context): AppDatabase {
            if (instance == null)
                instance = Room.databaseBuilder(
                    ctx.applicationContext,
                    AppDatabase::class.java,
                    "sDatabase.crypt"
//                    Constant.ROOT_PATH + "/.Gallery/sDatabase.crypt"
                )

                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration().build()

            return instance!!

        }
    }
}