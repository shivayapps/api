package com.photogallery.activities

import android.app.Activity
import android.graphics.Color
import android.graphics.PorterDuff
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.format.Formatter
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.enableEdgeToEdge
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

import com.photogallery.R
import com.photogallery.activities.StorageScanActivity.Companion.selectedRealPhotoData
import com.photogallery.adapter.StorageJunkAdapter
import com.photogallery.base.BaseActivity
import com.photogallery.customview.MyGridLayoutManager
import com.photogallery.customview.MyRecyclerView
import com.photogallery.database.AppDatabase
import com.photogallery.databinding.ActivityJunkCleanerBinding
import com.photogallery.dialog.DeleteDialog
import com.photogallery.dialog.ContentPreviewDialog
import com.photogallery.dialog.ProgressDialog
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.extension.toast
import com.photogallery.extension.updateStatusBarColor
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData

import com.photogallery.utils.Constant
import com.photogallery.utils.FastScroller
import com.photogallery.utils.Preferences
import com.photogallery.utils.Utils
import com.photogallery.utils.sendEvent
import com.photogallery.views.SwitchButton

import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class StorageCleanerActivity : BaseActivity() {

    var pictures = ArrayList<Any>()
    lateinit var preferences: Preferences
    lateinit var dataBase: AppDatabase
    var junkAdapter: StorageJunkAdapter? = null
    private var lastLongPressedItem = -1
    var selectedItem = 0
    var actResult = RESULT_CANCELED
    var isCheckSearchOn = false
    var isSelectAll = false

    var isSmartSelected = false
    var category = ""

    private var mDragListener: MyRecyclerView.MyDragListener? = null

    lateinit var binding: ActivityJunkCleanerBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        binding = ActivityJunkCleanerBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
//        updateStatusBarColor(Color.parseColor("#1878F3"))

        intView()
        intListener()
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    private fun intView() {
        category = intent.getStringExtra("cate") ?: ""
        if (category == "largemedia") {
            binding.btnSmartChoice.beGone()
            binding.txtSelectCount.text = getString(R.string.large_media)
        } else if (category == "duplicate_photo") {
            binding.btnSmartChoice.beVisible()
            binding.txtSelectCount.text = getString(R.string.duplicate_photos)
        } else if (category == "duplicate_video") {
            binding.btnSmartChoice.beVisible()
            binding.txtSelectCount.text = getString(R.string.duplicate_video)
        } else if (category == "duplicate_document") {
            binding.btnSmartChoice.beVisible()
            binding.txtSelectCount.text = getString(R.string.duplicate_document)
        } else if (category == "duplicate_audio") {
            binding.btnSmartChoice.beVisible()
            binding.txtSelectCount.text = getString(R.string.duplicate_audio)
        }
//        if (category == "duplicate") {
//            binding.btnSmartChoice.beVisible()
//        } else {
//            binding.btnSmartChoice.beGone()
//        }
        pictures = ArrayList(selectedRealPhotoData)

//        binding.groupToolbarSelectHeader.visibility = View.VISIBLE
//        binding.groupToolbarHeader.visibility = View.GONE

        initAdapter()
    }

    var isManualSelect = false
    private fun intListener() {
        binding.icClose.setOnClickListener {
            setCloseToolbar()
        }
        binding.icSelect.setOnClickListener {
            isManualSelect = true
            isSmartSelected = false
            binding.cbSmartChoice.isChecked = false
            isSelectAll = !isSelectAll
            setSelectClick(isSelectAll)
            Handler(Looper.getMainLooper()).postDelayed({
                isManualSelect = false
            }, 1000)

        }
        binding.cbSmartChoice.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                if (!isManualSelect) {
                    isSmartSelected = isChecked
                    setSmartSelectClick(isSmartSelected)
                }
            }
        })
        binding.btnDelete.setOnClickListener {
            showDeleteDialog()
        }
        binding.frameProgress.setOnClickListener {
            toast(getString(R.string.please_wait))
        }
    }

    fun showDeleteDialog() {
        if (selectedItem == 0) {
            toast(getString(R.string.PleaseSelectImage))
        } else {
            val deleteDialog = DeleteDialog.newInstance(
                this,
                btnClickListener = {
                    deletePhoto(it)
                })
            deleteDialog.show()
        }
    }

    override fun onBackPressed() {
        setCloseToolbar()
    }

    fun setCloseToolbar() {
        if (selectedItem == 0) {
            setResult(actResult)
            finish()
        } else {
            setClose()
            longClickListener(false, 0, false)
        }
    }

//    var finalProgressDialog: ProgressDialog? = null

    private fun deletePhoto(isPermanent: Boolean) {
        val deleteList = ArrayList<String>()

        preferences.refreshMedia = true
        preferences.scanMedia = true
        sendEvent("refresh")

        val progressDialog = ProgressDialog(
            this,
            R.drawable.ic_drawer_delete,
            selectedItem,
            getString(R.string.Deleting),
            ""
        )
        progressDialog.setCancelable(false)
        progressDialog.show()


        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(this)
            for (i in pictures.indices) {
                if (pictures[i] != null)
                    if (pictures[i] is MediaData) {
                        val model = pictures[i] as MediaData
                        if (model.isSelected) {

                            val entity = dataBase.dataDao().getLocationEntity(model.filePath)
                            if (entity != null) {
                                dataBase.dataDao().deleteLocationEntity(entity)
                            }

                            val isDelete =
                                Utils.deleteFile(this, model.filePath, dataBase, isPermanent)
                            MediaScannerConnection.scanFile(
                                this,
                                arrayOf<String>(model.filePath),
                                null
                            ) { path: String?, uri: Uri? -> }

                            if (isDelete) {
                                deleteList.add(model.filePath)
                                runOnUiThread {
                                    progressDialog.setProgress(deleteList.size, selectedItem)
                                }
                            }

                            model.isCheckboxVisible = false
                            model.isSelected = false
                        } else {
                            model.isSelected = false
                            model.isCheckboxVisible = false
                        }
                    } else if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false
                    }
            }

            var i = 0
            while (i < pictures.size) {
                if (pictures[i] != null)
                    if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false

                    } else if (pictures[i] is MediaData) {
                        val model = pictures[i] as MediaData
                        if (model.isSelected) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is AlbumData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                        } else {
                            model.isSelected = false
                            model.isCheckboxVisible = false
                        }
                    }
                i++
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    binding.frameProgress.visibility = View.VISIBLE
                    if (!isFinishing && !isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()

//                        finalProgressDialog?.show()
                    }
                    setBeforeDeleteUpdate(deleteList)
                }
            }
            .onErrorReturn { false }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    binding.frameProgress.visibility = View.VISIBLE
                    if (!isFinishing && !isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()
//                        finalProgressDialog?.show()
                    }
                    setBeforeDeleteUpdate(deleteList)
                }
            }
    }

    private fun setBeforeDeleteUpdate(deleteList: ArrayList<String>) {

        selectedItem = 0
        notifyAdapter()

        isSelectAll = false
        binding.btnDelete.isEnabled = false
        binding.txtSelectCount.text = "$selectedItem ${getString(R.string.items_selected)}"
//        setEmptyData()

        toast(getString(R.string.Delete_successfully))

        deleteMainList(deleteList) {
//            if (finalProgressDialog?.isShowing!!)
//                finalProgressDialog?.dismiss()
//            if (category == "screenshots") {
//                Constant.ssRealPhotoData = pictures
//            }
            if (category == "largemedia") {
                Constant.largeRealPhotoData = pictures
            }
            if (category == "duplicate_photo") {
                Constant.duplicateRealPhotoData = pictures
            }
            if (category == "duplicate_video") {
                Constant.duplicateRealVideoData = pictures
            }
            if (category == "duplicate_document") {
                Constant.duplicateRealDocumentData = pictures
            }
            if (category == "duplicate_audio") {
                Constant.duplicateRealAudioData = pictures
            }

            runOnUiThread {
                binding.frameProgress.visibility = View.GONE
                if (pictures.size == 0) {
                    actResult = RESULT_OK
                    setCloseToolbar()
//                setResult(Activity.RESULT_OK)
//                finish()
                } else {
                    junkAdapter?.submitList(pictures)
                    actResult = RESULT_OK
                    longClickListener(false, 0, false)
                    isSelectAll = false
                    setSelectClick(isSelectAll)
                }
            }
        }

    }

    private fun setEmptyData() {
        if (pictures != null && pictures.size != 0) {
            binding.pictureRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
            binding.layoutBottomAd.beVisible()
        } else {
            binding.pictureRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
            binding.layoutBottomAd.beGone()
        }
    }

    private fun deleteMainList(deleteList: ArrayList<String>, callback: () -> Unit) {
        if (deleteList.isNotEmpty()) {
            pictures.removeAll { pictureData ->
                pictureData is MediaData && deleteList.contains(pictureData.filePath)
            }
        }

        CoroutineScope(Dispatchers.IO).launch {
            withContext(Dispatchers.IO) {
                //remove deleted data
//                pictures.removeIf { item ->
//                    item is MediaData && !File(item.filePath).exists()
//                }
                //remove empty album
                val indicesToRemove = mutableListOf<Int>()
                for (i in pictures.indices) {
                    if (pictures[i] is AlbumData) {
                        var hasMediaData = false
                        for (j in (i + 1) until pictures.size) {
                            if (pictures[j] is MediaData) {
                                hasMediaData = true
                            } else if (pictures[j] is AlbumData) {
                                break
                            }
                        }
                        if (!hasMediaData) {
                            indicesToRemove.add(i)
                        }
                    }
                }
                for (index in indicesToRemove.reversed()) {
                    pictures.removeAt(index)
                }
                // Remove AlbumData with only one MediaData between them
                if (
                    category == "duplicate_photo"
                    || category == "duplicate_video"
                    || category == "duplicate_document"
                    || category == "duplicate_audio"
                ) {
                    val result = removeSingles(pictures)
                    pictures = result
                }
                callback.invoke()
            }
        }
    }

    fun removeSingles(pictures: ArrayList<Any>): ArrayList<Any> {
        val result = ArrayList<Any>()
        var tempAlbumData: AlbumData? = null
        val tempMediaData = ArrayList<MediaData>()

        for (item in pictures) {
            when (item) {
                is AlbumData -> {
                    if (tempMediaData.size > 1 || tempAlbumData == null) {
                        // If there are more than 1 MediaData or this is the first AlbumData, add them all
                        tempAlbumData?.let { result.add(it) }
                        result.addAll(tempMediaData)
                    }
                    tempAlbumData = item
                    tempMediaData.clear()
                }

                is MediaData -> {
                    tempMediaData.add(item)
                }
            }
        }

        // Add remaining AlbumData and MediaData after the loop
        if (tempMediaData.size > 1 || tempAlbumData == null) {
            tempAlbumData?.let { result.add(it) }
            result.addAll(tempMediaData)
        }

        return result
    }

    fun setSmartSelectClick(isSelectAll: Boolean) {
        var selected = 0
        var isSmartSelected = false
        if (isSelectAll) {
            for (i in pictures.indices) {
                if (pictures[i] != null)
                    if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isSelected = true
                        isSmartSelected = true
                    } else if (pictures[i] is MediaData) {
                        val model = pictures[i] as MediaData
                        if (isSmartSelected) {
                            model.isSelected = false
                            isSmartSelected = false
                        } else {
                            model.isSelected = true
                            if (isSelectAll)
                                selected++
                        }
                    }
            }
        } else {
            for (i in pictures.indices) {
                if (pictures[i] != null)
                    if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isSelected = false
                    } else if (pictures[i] is MediaData) {
                        val model = pictures[i] as MediaData
                        model.isSelected = false
                    }
            }
        }
        notifyAdapter()
        longClickListener(true, selected, false)
        selectedItem = selected
    }

    fun setSelectClick(isSelectAll: Boolean) {
        var selected = 0
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    model.isSelected = isSelectAll
                } else if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData
                    model.isSelected = isSelectAll
                    if (isSelectAll)
                        selected++
                }
        }
        notifyAdapter()
        longClickListener(true, selected, isSelectAll)
        selectedItem = selected
    }

    private fun setClose() {
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    model.isSelected = false
                    model.isCheckboxVisible = false
                } else if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData
                    model.isCheckboxVisible = false
                    model.isSelected = false
                }
        }
        notifyAdapter()
        selectedItem = 0
    }

    fun setRvLayoutManager() {
        try {
            var spanCount = 3
            if (category == "largemedia") {
                spanCount = 3
            } else if (category == "duplicate_photo") {
                spanCount = 3
            } else if (category == "duplicate_video") {
                spanCount = 3
            } else if (category == "duplicate_document") {
                spanCount = 1
            } else if (category == "duplicate_audio") {
                spanCount = 1
            }
            val layoutManager = binding.pictureRecycler.layoutManager as MyGridLayoutManager
            layoutManager.spanCount = spanCount
            layoutManager.orientation = RecyclerView.VERTICAL
            binding.pictureRecycler.layoutManager = layoutManager
            layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int): Int {
                    if (position >= 0 && position < pictures.size) {
                        return if (junkAdapter!!.getItemViewType(position) == junkAdapter!!.ITEM_HEADER_TYPE) {
                            spanCount
                        } else 1
                    } else {
                        return 1
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }


    }

    private fun initAdapter() {
        setRvLayoutManager()
//        binding.cleanerFastscroller.attachFastScrollerToRecyclerView(binding.pictureRecycler)
        junkAdapter = StorageJunkAdapter(
            this,
            category,
            clickListener = {
                if (pictures[it] is MediaData) {
                    val mediaData = pictures[it] as MediaData
                    if (!isCheckSearchOn) {
                        mediaData.isSelected = !mediaData.isSelected
                        if (::binding.isInitialized)
                            binding.pictureRecycler.recycledViewPool.clear()
                        junkAdapter?.notifyItemChanged(it, "showCheckBox")
                        setSelectedFile()
                    } else {
                        val dataList = ArrayList<MediaData>()
                        var displayPos = 0
                        for (i in pictures.indices) {
                            if (pictures[i] is MediaData) {
                                dataList.add(pictures[i] as MediaData)
                                if (it == i) {
                                    displayPos = dataList.size - 1
                                }
                            }
                        }
                        Constant.displayImageList = ArrayList()
                        Constant.displayImageList.addAll(dataList)
                        Constant.selectedPosition = displayPos
                        if (Constant.displayImageList.size > 0) {
//                        val intent = Intent(this, PhotoVideoActivity::class.java)
//                        intent.putExtra(Constant.EXTRA_DISPLAY_POS, displayPos)
//                        photoVideoLauncher.launch(intent)
                        }
                    }
                }
            },
            longClickListener = {
                if (pictures[it] is MediaData) {
                    val mediaData = pictures[it] as MediaData

                    val detailsDialog = ContentPreviewDialog(this, mediaData)
                    detailsDialog.show()
                }
            },
            headerSelectListener = {
                if (pictures[it] is AlbumData) {
                    val albumData = pictures[it] as AlbumData
                    val isSelectAll = !albumData.isSelected
                    albumData.isSelected = isSelectAll
                    var pos = it + 1
                    while (pos < pictures.size) {
                        if (pictures[pos] is MediaData) {
                            val model = pictures[pos] as MediaData
                            model.isSelected = isSelectAll
                            junkAdapter?.notifyItemChanged(pos, "showCheckBox")
                            pos++
                        } else if (pictures[pos] is AlbumData) {
                            break
                        }
                    }
//                notifyAdapter()
                    setSelectedFile()
                }
            })

        binding.pictureRecycler.setDragSelectActive(-1)
        junkAdapter?.submitList(pictures)
        binding.pictureRecycler.adapter = junkAdapter


//        binding.pictureRecycler.post {
//            FastScroller(binding.handleView).bind(binding.pictureRecycler)
//        }

        initDragListener()
        setupDragListener(mDragListener)

//        setSelectClick(isSelectAll)
    }

    private fun notifyAdapter() {
        if (junkAdapter != null) {

            runOnUiThread {
                junkAdapter?.submitList(pictures.toList())
//                junkAdapter?.notifyItemChanged(0, pictures.size)
                junkAdapter?.notifyItemRangeChanged(0, pictures.size, "showCheckBox")
                //junkAdapter?.notifyDataSetChanged()
            }
//            }
        }
    }

    private fun initDragListener() {

        mDragListener = object : MyRecyclerView.MyDragListener {
            override fun selectItem(position: Int) {
                toggleItemSelection(true, position, true)
            }

            override fun selectRange(
                initialSelection: Int,
                lastDraggedIndex: Int,
                minReached: Int,
                maxReached: Int,
            ) {
                selectItemRange(
                    initialSelection,
                    Math.max(0, lastDraggedIndex),
                    Math.max(0, minReached),
                    maxReached
                )
                if (minReached != maxReached) {
                    lastLongPressedItem = -1
                }
            }

        }
    }

    fun setupDragListener(dragListener: MyRecyclerView.MyDragListener?) {
        binding.pictureRecycler.setupDragListener(dragListener)
    }

    protected fun selectItemRange(from: Int, to: Int, min: Int, max: Int) {
        if (from == to) {
            (min..max).filter { it != from }.forEach { toggleItemSelection(false, it, true) }
            return
        }

        if (to < from) {
            for (i in to..from) {
                toggleItemSelection(true, i, true)
            }

            if (min > -1 && min < to) {
                (min until to).filter { it != from }
                    .forEach { toggleItemSelection(false, it, true) }
            }

            if (max > -1) {
                for (i in from + 1..max) {
                    toggleItemSelection(false, i, true)
                }
            }
        } else {
            for (i in from..to) {
                toggleItemSelection(true, i, true)
            }

            if (max > -1 && max > to) {
                (to + 1..max).filter { it != from }.forEach { toggleItemSelection(false, it, true) }
            }

            if (min > -1) {
                for (i in min until from) {
                    toggleItemSelection(false, i, true)
                }
            }
        }
    }

    protected fun toggleItemSelection(select: Boolean, pos: Int, updateTitle: Boolean = true) {
//        pictureAdapter.getItemViewType(pos)
//        if (select && !getIsItemSelectable(pos)) {
        try {
            if (select && pictures[pos] is AlbumData) {
                return
            }

            if (pictures[pos] is MediaData) {

                if (select) {
                    (pictures[pos] as MediaData).isSelected = true
//                (pictures[pos] as PictureData).isCheckboxVisible = true
//                selectedKeys.add(itemKey)
                } else {
                    (pictures[pos] as MediaData).isSelected = false
//                (pictures[pos] as PictureData).isCheckboxVisible = false
//                selectedKeys.remove(itemKey)
                }
            }
        } catch (e: Exception) {

        }

        if (::binding.isInitialized)
            binding.pictureRecycler.recycledViewPool.clear()
        junkAdapter?.notifyItemChanged(pos, "showCheckBox")
        setSelectedFile()
    }

    private fun setSelectedFile() {
        var selected = 0
        var allItemCount = 0

        var currentHeaderPos = -1
        var photosCount = 0
        var photosSelectCount = 0

        for (i in pictures.indices) {
            if (pictures[i] is AlbumData) {
                if (i != currentHeaderPos) {
                    if (currentHeaderPos != -1) {
                        val model = pictures[currentHeaderPos] as AlbumData
                        model.isSelected = photosCount == photosSelectCount
                        photosCount = 0
                        photosSelectCount = 0
                        if (::binding.isInitialized)
                            binding.pictureRecycler.recycledViewPool.clear()
                        junkAdapter?.notifyItemChanged(currentHeaderPos, "showCheckBox")
                    }
                    currentHeaderPos = i
                }
            } else if (pictures[i] is MediaData) {
                val model = pictures[i] as MediaData
                allItemCount++
                photosCount++
                if (model.isSelected) {
                    selected++
                    photosSelectCount++
                }
            }
            if (i == pictures.size - 1) {
                if (currentHeaderPos != -1) {
                    val model = pictures[currentHeaderPos] as AlbumData
                    model.isSelected = photosCount == photosSelectCount
                    photosCount = 0
                    photosSelectCount = 0
                    if (::binding.isInitialized)
                        binding.pictureRecycler.recycledViewPool.clear()
                    junkAdapter?.notifyItemChanged(currentHeaderPos, "showCheckBox")
                }
            }
        }

        longClickListener(true, selected, allItemCount == selected)
        selectedItem = selected

    }

    private fun longClickListener(
        isShowSelection: Boolean,
        selectedItem: Int,
        isAllSelect: Boolean,
    ) {

        isSelectAll = isAllSelect
        binding.btnDelete.isEnabled = isShowSelection && selectedItem != 0
        binding.txtSelectCount.text = "$selectedItem ${getString(R.string.items_selected)}"

        setSelectAllColor()

        val totalSelectedFileSize: Long =
            pictures.filterIsInstance<MediaData>().filter { it.isSelected }.sumOf { it.fileSize }
        Log.e("JunkScanActivity", "totalSelectedFileSize:${totalSelectedFileSize}")
        val size = Formatter.formatShortFileSize(this@StorageCleanerActivity, totalSelectedFileSize)
        binding.selectedSize.text = "($size)"
    }

    private fun setSelectAllColor() {
//        val color =
//            ContextCompat.getColor(this, if (isSelectAll) R.color.black else R.color.un_check_color)
//        binding.icSelect.setColorFilter(color, PorterDuff.Mode.SRC_IN)
        binding.icSelect.setImageResource(if (isSelectAll) R.drawable.ic_select_all else R.drawable.ic_unselect_all)
    }

}