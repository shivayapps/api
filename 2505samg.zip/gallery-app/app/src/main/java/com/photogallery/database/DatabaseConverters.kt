package com.photogallery.database

import androidx.room.TypeConverter

class DatabaseConverters {
    @TypeConverter
    fun fromBucketIds(bucketIds: List<String>): String {
        return bucketIds.joinToString(",")
    }

    @TypeConverter
    fun toBucketIds(data: String): List<String> {
        return if (data.isEmpty()) emptyList() else data.split(",")
    }
}
