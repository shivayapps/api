package com.photogallery.edit.model

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.util.AttributeSet
import android.view.TextureView

class ImageEditorTextureView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : TextureView(context, attrs), TextureView.SurfaceTextureListener {

    private var bitmap: Bitmap? = null

    var brightness = 0f
    var contrast = 1f
    var saturation = 1f
    var sharpen = 0f

    init {
        surfaceTextureListener = this
    }

    fun setBitmap(bm: Bitmap) {
        bitmap = bm
        render()
    }

//    fun getResultBitmap(): Bitmap? {
//
//        if (!isAvailable) return null
//
//        return bitmap?.copy(
//            Bitmap.Config.ARGB_8888,
//            false
//        )
//    }

    fun getResultBitmap(): Bitmap? {

        val source = bitmap ?: return null

        var workingBitmap = source.copy(
            Bitmap.Config.ARGB_8888,
            true
        )

        // Apply sharpen
        if (sharpen > 0f) {
            workingBitmap = sharpenBitmap(
                workingBitmap,
                sharpen
            )
        }

        val resultBitmap = Bitmap.createBitmap(
            workingBitmap.width,
            workingBitmap.height,
            Bitmap.Config.ARGB_8888
        )

        val canvas = Canvas(resultBitmap)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        val contrastMatrix = ColorMatrix(
            floatArrayOf(
                contrast, 0f, 0f, 0f, brightness,
                0f, contrast, 0f, 0f, brightness,
                0f, 0f, contrast, 0f, brightness,
                0f, 0f, 0f, 1f, 0f
            )
        )

        val saturationMatrix = ColorMatrix()
        saturationMatrix.setSaturation(saturation)

        contrastMatrix.postConcat(saturationMatrix)

        paint.colorFilter =
            ColorMatrixColorFilter(contrastMatrix)

        canvas.drawBitmap(
            workingBitmap,
            0f,
            0f,
            paint
        )

        return resultBitmap
    }
    fun render() {

        if (!isAvailable) return

        var workingBitmap = bitmap ?: return

        // Apply sharpen first
        if (sharpen > 0f) {
            workingBitmap = sharpenBitmap(
                workingBitmap,
                sharpen
            )
        }

        val canvas = lockCanvas() ?: return

        canvas.drawColor(Color.BLACK)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        val contrastMatrix = ColorMatrix(
            floatArrayOf(
                contrast, 0f, 0f, 0f, brightness,
                0f, contrast, 0f, 0f, brightness,
                0f, 0f, contrast, 0f, brightness,
                0f, 0f, 0f, 1f, 0f
            )
        )

        val saturationMatrix = ColorMatrix()
        saturationMatrix.setSaturation(saturation)

        contrastMatrix.postConcat(saturationMatrix)

        paint.colorFilter =
            ColorMatrixColorFilter(contrastMatrix)

//        canvas.drawBitmap(
//            workingBitmap,
//            null,
//            Rect(0, 0, width, height),
//            paint
//        )

        val viewWidth = width.toFloat()
        val viewHeight = height.toFloat()

        val bitmapWidth = workingBitmap.width.toFloat()
        val bitmapHeight = workingBitmap.height.toFloat()

        val scale = minOf(
            viewWidth / bitmapWidth,
            viewHeight / bitmapHeight
        )

        val scaledWidth = bitmapWidth * scale
        val scaledHeight = bitmapHeight * scale

        val left = (viewWidth - scaledWidth) / 2f
        val top = (viewHeight - scaledHeight) / 2f

        val destRect = RectF(
            left,
            top,
            left + scaledWidth,
            top + scaledHeight
        )

        canvas.drawBitmap(
            workingBitmap,
            null,
            destRect,
            paint
        )

        unlockCanvasAndPost(canvas)
    }

    private fun sharpenBitmap(
        src: Bitmap,
        amount: Float
    ): Bitmap {

        val kernel = floatArrayOf(
            0f, -1f, 0f,
            -1f, 5f + amount, -1f,
            0f, -1f, 0f
        )

        val convolution = ConvolutionMatrix(3)
        convolution.applyConfig(kernel)
        convolution.Factor = amount + 1f
        convolution.Offset = 0f

        return ConvolutionMatrix.computeConvolution3x3(
            src,
            convolution
        )
    }

    override fun onSurfaceTextureAvailable(
        surface: SurfaceTexture,
        width: Int,
        height: Int
    ) {
        render()
    }

    override fun onSurfaceTextureSizeChanged(
        surface: SurfaceTexture,
        width: Int,
        height: Int
    ) {}

    override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
        return true
    }

    override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
}