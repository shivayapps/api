package com.photogallery.activities

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.ContentUris
import android.content.Intent
import android.database.Cursor
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.PopupWindow
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.doOnPreDraw
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

import com.bumptech.glide.Glide
import com.photogallery.BuildConfig
import com.photogallery.R
import com.photogallery.adapter.PhotoAdapter
import com.photogallery.base.BaseActivity
import com.photogallery.customview.MyGridLayoutManager
import com.photogallery.customview.MyRecyclerView
import com.photogallery.database.AppDatabase
import com.photogallery.database.LocationEntity
import com.photogallery.databinding.ActivitySearchBinding
import com.photogallery.databinding.PopBottomMenuBinding
import com.photogallery.dialog.ActionConfirmationDialog
import com.photogallery.dialog.CreateAlbumDialog
import com.photogallery.dialog.DeleteDialog
import com.photogallery.dialog.DetailsDialog
import com.photogallery.dialog.FileRenameDialog
import com.photogallery.dialog.ProgressDialog
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.extension.beVisibleIf
import com.photogallery.extension.getFinalUriFromPath
import com.photogallery.extension.getParentFolder
import com.photogallery.extension.getUriMimeType
import com.photogallery.extension.isGif
import com.photogallery.extension.onTextChangeListener
import com.photogallery.extension.openEditorIntent
import com.photogallery.extension.showErrorToast
import com.photogallery.extension.toast
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.utils.Constant
import com.photogallery.utils.PopupWindowHelper
import com.photogallery.utils.Preferences
import com.photogallery.utils.TYPE_GIFS
import com.photogallery.utils.TYPE_IMAGES
//import com.photogallery.utils.TYPE_PORTRAITS
//import com.photogallery.utils.TYPE_RAWS
//import com.photogallery.utils.TYPE_SVGS
import com.photogallery.utils.TYPE_VIDEOS
import com.photogallery.utils.Utils
import com.photogallery.utils.ensureBackgroundThread
import com.photogallery.utils.photoExtensions
import com.photogallery.utils.rawExtensions
import com.photogallery.utils.sendEvent
import com.photogallery.utils.videoExtensions
import com.photogallery.viewpager.PhotoVideoActivity
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max
import kotlin.math.min


class SearchActivity : BaseActivity() {

    var pictures = ArrayList<Any>()
    var allBackList = ArrayList<MediaData>()
    lateinit var dataBase: AppDatabase
    var searchAdapter: PhotoAdapter? = null

    var placeList: ArrayList<AlbumData> = ArrayList()

    lateinit var preferences: Preferences
    var isSearch: Boolean = false
    var isStopSearch: Boolean = false
    var startDate = 0L
    var endDate = 0L

    lateinit var binding: ActivitySearchBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        binding = ActivitySearchBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        dataBase = AppDatabase.getInstance(this)
        initView()
        intListener()
    }

    private fun initView() {
//        binding.icBack.setOnClickListener {
//            onBackPressed()
//        }

        binding.icSearchClear.setOnClickListener {
            binding.edtSearch.setText("")
            hideKeyboard(binding.edtSearch)
            //search()
        }

        binding.edtSearch.onTextChangeListener { str ->
            if (str.isEmpty()) {
                binding.icSearchClear.visibility = View.GONE
                searchHandle.removeCallbacks(searchRunnable)
                search()
            } else {
                binding.icSearchClear.visibility = View.VISIBLE
                searchHandle.removeCallbacks(searchRunnable)
                searchHandle.postDelayed(searchRunnable, 800)
            }
        }

        initAdapters()

        initDragListener()
        setupDragListener(mDragListener)

        setPlaceData()
        getData()

    }

    private fun intListener() {
        binding.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.icClose.setOnClickListener {
            setCloseToolbar()
        }
        binding.icSelect.setOnClickListener {
            isSelectAll = !isSelectAll
            setSelectClick(isSelectAll)
            setSelectAllColor()
        }
        binding.btnShare.setOnClickListener {
            shareImages()
        }
        binding.btnDelete.setOnClickListener {
            showDeleteDialog(getSelectedMedia())
        }
        binding.btnHide.setOnClickListener {
            setHideData()
        }
        binding.btnMore.setOnClickListener {
            showDropDown(binding.btnMore)
        }

//        binding.ivScrollTop.setOnClickListener {
//            binding.pictureRecycler.scrollToPosition(0)
//            binding.ivScrollTop.beGone()
//        }

//        binding.root.doOnPreDraw {
//            binding.pictureRecycler.addOnScrollListener(object :
//                RecyclerView.OnScrollListener() {
//                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
//                    val firstPositon =
//                        (binding.pictureRecycler.layoutManager as MyGridLayoutManager).findFirstVisibleItemPosition()
//                    binding.ivScrollTop.beVisibleIf(firstPositon > 3)
//                }
//            })
//        }
    }

    private fun favoriteClick() {
        var needToAddFav = false
        var needToRemoveFav = false
        for (i in pictures.indices) {
            if (pictures[i] is MediaData) {
                val model: MediaData = pictures[i] as MediaData
                if (model.isSelected) {
//                    if (model.isVideo || model.filePath.isGif()) isVideoSelected = true

                    if (model.isFavorite)
                        needToRemoveFav = true
                    else
                        needToAddFav = true
                }
            }
        }


        if(needToAddFav) {
            setFavorite(true)
        }else{
            setFavorite(false)
        }

    }


    lateinit var popupWindow: PopupWindow

    private fun showDropDown(view: View) {
        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopBottomMenuBinding.inflate(layoutInflater)
        val popupWindow = PopupWindowHelper(popUpBinding.root)

        var needToAddFav = false
        var needToRemoveFav = false
        var isVideoSelected = false

        for (i in pictures.indices) {
            if (pictures[i] is MediaData) {
                val model: MediaData = pictures[i] as MediaData
                if (model.isSelected) {
                    if (model.isVideo || model.filePath.isGif()) isVideoSelected = true

                    if (model.isFavorite)
                        needToRemoveFav = true
                    else
                        needToAddFav = true
                }
            }
        }

        popUpBinding.menuEdit.beVisibleIf(selectedItem == 1 && !isVideoSelected)
        popUpBinding.menuSetAs.beVisibleIf(selectedItem == 1 && !isVideoSelected)
//        popUpBinding.menuResize.beVisibleIf(selectedItem == 1 && !isVideoSelected)
        popUpBinding.menuRename.beVisibleIf(selectedItem == 1)
        popUpBinding.menuInfo.beVisibleIf(selectedItem == 1)
//        popUpBinding.menuAddFavourite.beVisibleIf(needToAddFav)
//        popUpBinding.menuRemoveFavourite.beVisibleIf(needToRemoveFav)
        popUpBinding.menuPdf.beVisibleIf(!isVideoSelected)

        popUpBinding.menuPdf.setOnClickListener {
            popupWindow.dismiss()
            if (selectedItem == 0) {
                toast(getString(R.string.PleaseSelectImage))
            } else {
                val selectImage = ArrayList<MediaData>() // Use a set to avoid duplicates
                pictures.filterIsInstance<MediaData>() // Filter only MediaData objects
                    .filter { it.isSelected } // Filter selected MediaData objects
                    .forEach { selectImage.add(it) } // Add to the set

                Utils.generatePdf(this@SearchActivity, selectImage)
            }
        }

//        popUpBinding.menuCover.beGone()
//        popUpBinding.menuExclude.beGone()

        popUpBinding.loutMain.setOnClickListener {
            popupWindow.dismiss()
        }
        popUpBinding.menuRename.setOnClickListener {
            popupWindow.dismiss()
            if (selectedItem == 1) {
                showRenameDialog()
            }
        }
        popUpBinding.menuSetAs.setOnClickListener {
            popupWindow.dismiss()
            setAs()
        }
//        popUpBinding.menuResize.setOnClickListener {
//            popupWindow.dismiss()
//            showResizeDialog()
//        }
//        popUpBinding.menuAddFavourite.setOnClickListener {
//            popupWindow.dismiss()
//            setFavorite(true)
//        }
//
//        popUpBinding.menuRemoveFavourite.setOnClickListener {
//            popupWindow.dismiss()
//            setFavorite(false)
//        }
        popUpBinding.menuEdit.setOnClickListener {
            popupWindow.dismiss()
//            requestStoragePermission(app_edit_AFA_allow_nf, app_edit_AFA_denied_nf, getActivityName()) {
//                if (it) {
            try {
                openEditor()
            } catch (e: Exception) {
                e.printStackTrace()
            }
//                }
//            }

        }
        popUpBinding.menuInfo.setOnClickListener {
            popupWindow.dismiss()
            showDetailsDialog()
        }

        popUpBinding.menuCopy.setOnClickListener {
//            showAddAlbumDialog(Constant.albumList, true)

            val selectedAlbum = ArrayList<String>()
            val selectImage = ArrayList<MediaData>() // Use a set to avoid duplicates
            pictures.filterIsInstance<MediaData>() // Filter only MediaData objects
                .filter { it.isSelected } // Filter selected MediaData objects
                .forEach { selectImage.add(it) } // Add to the set
            showAddAlbumDialog(
                Constant.deviceAlbumList,
                selectImage,
                selectedAlbum,
                true
            )
            popupWindow.dismiss()
        }
        popUpBinding.menuMove.setOnClickListener {
            popupWindow.dismiss()
//            requestStoragePermission(app_move_to_AFA_allow_nf, app_move_to_AFA_denied_nf, getActivityName()) {
//                if (it) {

            val selectedAlbum = ArrayList<String>()
            val selectImage = ArrayList<MediaData>() // Use a set to avoid duplicates
            pictures.filterIsInstance<MediaData>() // Filter only MediaData objects
                .filter { it.isSelected } // Filter selected MediaData objects
                .forEach { selectImage.add(it) } // Add to the set
            showAddAlbumDialog(
                Constant.deviceAlbumList,
                selectImage,
                selectedAlbum,
                false
            )
//                }
//            }
        }
        popupWindow.showAsPopUp(view)
    }


    private var isCopyForResult: Boolean = false
    private lateinit var selectImageForResult: ArrayList<MediaData>
    private val addAlbumLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                val data = result.data
                when (data?.getStringExtra("action")) {
                    "create" -> {
                        val createDialog = CreateAlbumDialog(this, createPathListener = { path ->
                            setCopyMove(isCopyForResult, path, selectImageForResult)
                        })
                        createDialog.show()
                    }

                    else -> {
                        data?.getStringExtra("selectedPath")?.let { path ->
                            setCopyMove(isCopyForResult, path, selectImageForResult)
                        }
                    }
                }
            }
        }


    private fun setCopyMove(
        isCopy: Boolean,
        selectPath: String,
        selectImage: java.util.ArrayList<MediaData>,
    ) {
        Log.e("ImageListActivity", "setCopyMove.selectPath:$selectPath")
        if (isCopy)
            Utils.copyFiles(
                this,
                selectPath,
                selectImage,
                selectImage.size,
                copyListener = {
                    toast(getString(R.string.copy_successfully))
                    MediaScannerConnection.scanFile(
                        this,
                        arrayOf<String>(selectPath),
                        null
                    ) { path, uri -> }
                    refreshData()
                    selectedItem = 0
                    preferences.refreshMedia = true
                    preferences.scanMedia = true
//                    setList()
                    longClickListener(false, 0, false)
                    setClose()
                    sendEvent("refresh")
                })
        else
            Utils.moveFiles(
                this,
                selectPath,
                selectImage,
                selectImage.size,
                moveListener = {
                    toast(getString(R.string.move_successfully))
                    MediaScannerConnection.scanFile(
                        this,
                        arrayOf<String>(selectPath),
                        null
                    ) { path, uri -> }
                    refreshData()
                    selectedItem = 0
                    preferences.refreshMedia = true
                    preferences.scanMedia = true
//                    setList()
                    longClickListener(false, 0, false)
                    setClose()
                    sendEvent("refresh")
                })

//        if(pictures.size == 0) {
//            finish()
//        }
    }

    private fun refreshData() {
        //getData()
    }

    private fun showAddAlbumDialog(
        albums: ArrayList<AlbumData>,
        selectedMedia: ArrayList<MediaData>,
        selectedAlbum: ArrayList<String>,
        isCopy: Boolean
    ) {
        val uniqueSelectImage = ArrayList(selectedMedia.distinctBy { it.filePath })

        for (media in uniqueSelectImage) {
            Log.e("uniqueSelectImage", "uniqueSelectImage-->:${media.filePath}")
        }



        isCopyForResult = isCopy
        selectImageForResult = uniqueSelectImage
        val selectAlbumIntent = Intent(this, AlbumSelectorActivity::class.java)
        selectAlbumIntent.putExtra("selectedAlbum", selectedAlbum)
        selectAlbumIntent.putExtra("isCopy", isCopy)
        addAlbumLauncher.launch(selectAlbumIntent)

    }

    fun showDetailsDialog() {

        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is MediaData) {
                    val model: MediaData = pictures[i] as MediaData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }
        try {
            val pictureData = selectImage[0]

            val detailsDialog = DetailsDialog(this, pictureData, false)
            detailsDialog.show()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


    fun openEditor() {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is MediaData) {
                    val model: MediaData = pictures[i] as MediaData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }
        val pictureData = selectImage[0]
        val path = pictureData.filePath
        val newPath = path.removePrefix("file://")
        openEditorIntent(newPath)
    }

    fun setFavorite(isFavorite: Boolean) {

        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())
        for (i in pictures.indices) {
            if (pictures[i] is MediaData) {
                val model: MediaData = pictures[i] as MediaData
//                (pictures[i] as PictureData).isFavorite=isFavorite
                if (model.isSelected) {
                    if (isFavorite) {
                        if (!favList.contains(model.filePath))
                            favList.add(model.filePath)
                    } else {
                        if (favList.contains(model.filePath))
                            favList.remove(model.filePath)
                    }
                }
            }
        }
        preferences.setFavoriteList(favList)
        preferences.refreshMedia = true
//        refreshData(allList)
        runOnUiThread {
            setCloseToolbar()
//            refreshData()
            getData()
        }

//        setData()
//        pictures.removeAll(allList.toSet())
//        getData()
//        setList()
    }

    fun setAs() {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is MediaData) {
                    val model: MediaData = pictures[i] as MediaData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }

        try {
            val pictureData = selectImage[0]

            val intent = Intent(this@SearchActivity, WallpaperSettingsActivity::class.java)
            intent.putExtra(
                Constant.EXTRA_WALL_PAPER,
                pictureData.filePath
            )
            startActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    fun showRenameDialog() {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is MediaData) {
                    val model: MediaData = pictures[i] as MediaData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }


        try {
            val pictureData = selectImage[0]
            val renameDialog =
                FileRenameDialog(
                    this,
                    pictureData,
                    positiveBtnClickListener = { renamePath, oldPath ->
                        notifyAdapter()
                    })
            renameDialog.show()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showDeleteDialog(selectImage: ArrayList<MediaData>) {
        if (selectImage.size == 0) {
            toast(getString(R.string.PleaseSelectImage))
        } else {
            val deleteDialog =
                DeleteDialog.newInstance(this@SearchActivity, btnClickListener = {
                    deletePhoto(selectImage, it)
                })
            deleteDialog.show()
        }
    }


    fun shareImages() {
        if (selectedItem == 0) {

            toast(getString(R.string.PleaseSelectImage))
        } else {
            ensureBackgroundThread {
                val uris = ArrayList<Uri>()
                for (i in pictures.indices) {
                    if (pictures[i] is MediaData) {
                        val model = pictures[i] as MediaData
                        if (model.isSelected) {
                            val uri = FileProvider.getUriForFile(
                                this,
                                this.packageName + ".provider",
                                File(model.filePath)
                            )
                            uris.add(uri)
                        }
                    }
                }
                runOnUiThread {
                    Utils.shareFilesList(this, uris)
                }
            }
        }
    }

    fun setHideData() {
        if (selectedItem == 0) {
            toast(
                this.getString(R.string.PleaseSelectImage)
            )
        } else {
            val hideDialog = ActionConfirmationDialog(
                this,
                getString(R.string.Private),
                getString(R.string.hide_msg),
                getString(R.string.hide),
                positiveBtnClickListener = {
                    hidePhoto()
                })
            hideDialog.show()


        }
    }


    private fun hidePhoto() {
        val selectImage: ArrayList<MediaData> = ArrayList()
        val deleteList = ArrayList<String>()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is MediaData) {
                    val model: MediaData = pictures[i] as MediaData
                    if (model.isSelected) {
                        selectImage.add(model)
                        deleteList.add(model.filePath)
                    }
                }
        }

        Utils.hideFiles(this, selectImage, selectedItem, hideListener = {
            toast(getString(R.string.hide_successfully))
            selectedItem = 0
            preferences.refreshMedia = true
            sendEvent("refresh")
            longClickListener(false, 0, false)
            setClose()
            deleteMainList(deleteList)
//            refreshData(selectImage)
            refreshData()
        })
    }

    private fun deleteMainList(deleteList: ArrayList<String>) {
        try {
            if (deleteList.size != 0) {
                allBackList.iterator().let { iterator ->
                    while (iterator.hasNext()) {
                        if (iterator.next().filePath in deleteList) {
                            iterator.remove()
                        }
                    }
                }

                notifyAdapter()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


    private fun deletePhoto(selectImage: ArrayList<MediaData>, isPermanent: Boolean) {

        val deleteList = ArrayList<String>()
        val progressDialog = ProgressDialog(
            this,
            R.drawable.ic_drawer_delete,
            selectImage.size,
            getString(R.string.Deleting),
            ""
        )
        progressDialog.setCancelable(false)
        progressDialog.show()

        preferences.refreshMedia = true
        preferences.scanMedia = true

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(this)
            selectImage.forEach { model ->

                val entity = dataBase.dataDao().getLocationEntity(model.filePath)
                if (entity != null) {
                    dataBase.dataDao().deleteLocationEntity(entity)
                }
                val isDelete = Utils.deleteFile(this, model.filePath, dataBase, isPermanent)
                MediaScannerConnection.scanFile(
                    this,
                    arrayOf<String>(model.filePath),
                    null
                ) { path: String?, uri: Uri? -> }
                if (isDelete) {
                    deleteList.add(model.filePath)
                    runOnUiThread {
                        progressDialog.setProgress(deleteList.size, selectImage.size)
                    }
                }
            }

            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    progressDialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
            .onErrorReturn { false }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    progressDialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
    }

    private fun setBeforeDeleteUpdate(deleteList: ArrayList<String>) {
        selectedItem = 0
        deleteMainList(deleteList)
        notifyAdapter()
        longClickListener(false, 0, false)
        setEmptyData()
        setCloseToolbar()

        Log.e("refresh_map", "send_event")
        sendEvent("refresh_map")
        sendEvent("refresh")
        toast(getString(R.string.Delete_successfully))
    }

    fun setSelectClick(isSelectAll: Boolean) {
//        if (isSelectAll) {
        var selected = 0
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    if (!model.isCustomAlbum) {
                        model.isSelected = isSelectAll
                    }
                } else if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData
                    model.isSelected = isSelectAll
                    if (isSelectAll)
                        selected++

                }
        }
        notifyAdapter()
        longClickListener(true, selected, isSelectAll)
        selectedItem = selected
//        } else {
//            longClickListener(false, 0, false)
//            setClose()
//        }
    }

    fun setCloseToolbar() {
        setClose()
        longClickListener(false, 0, false)
    }

    private fun setClose() {
        try {
            for (i in pictures.indices) {
                if (pictures[i] != null)
                    if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false
                    } else if (pictures[i] is MediaData) {
                        val model = pictures[i] as MediaData
                        model.isCheckboxVisible = false
                        model.isSelected = false
                    }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        notifyAdapter()
        selectedItem = 0
    }

    private fun getSelectedMedia(): ArrayList<MediaData> {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is MediaData) {
                    val model: MediaData = pictures[i] as MediaData
                    if (model.isSelected) {
                        selectImage.add(model)
//                        favList.add(model.filePath)
                    }
                }
        }
        return selectImage
    }

    private var lastLongPressedItem = -1

    private val searchHandle = Handler(Looper.getMainLooper())
    private val searchRunnable = Runnable {
        search()
    }

    private fun search() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val strSearch = binding.edtSearch.text.toString().lowercase()
                Log.e("setSearch", "strSearch:$strSearch")

                val filteredList = if (strSearch.isNotEmpty()) {
                    allBackList.filter {
                        it.fileName.lowercase().contains(strSearch, true) ||
                                it.folderName.lowercase().contains(strSearch, true)
                    }
                } else {
                    emptyList()
                }

                withContext(Dispatchers.Main) {
                    pictures.clear()
                    pictures.addAll(filteredList)

                    //binding.txtCount.text = "${allList.size} ${getString(R.string.photos)}"

                    chunkAndSubmitList(pictures)
                    if (pictures.size != 0) {
                        binding.pictureRecycler.beVisible()
                        binding.loutNoData.beGone()
                    } else {
                        binding.pictureRecycler.beGone()
                        binding.loutNoData.beVisible()
                    }

                }
            } catch (e: Exception) {
                Log.e("setSearch", "exception:$e")
            }
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()

    }

    fun hideKeyboard(view: EditText) {
        view.clearFocus()
        val methodManager = (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.hideSoftInputFromWindow(view.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
    }

    private fun showKeyboard(view: EditText) {
        view.requestFocus()
        val methodManager = (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun openImageList(albumData: AlbumData) {
        Constant.albumData = AlbumData(
            albumData.title,
            albumData.mediaData,
            "",
            0,
            0,
            isCustomAlbum = true
        )
        val intent = Intent(this, ImageGalleryActivity::class.java)
        if (albumData.lati > 0 && albumData.long > 0) {
            intent.putExtra("isFromMap", true)
            intent.putExtra("lati", albumData.lati)
            intent.putExtra("long", albumData.long)
        }
        startActivity(intent)
    }

    private var mDragListener: MyRecyclerView.MyDragListener? = null

    private fun initDragListener() {

        mDragListener = object : MyRecyclerView.MyDragListener {
            override fun selectItem(position: Int) {
                toggleItemSelection(true, position, true)
            }

            override fun selectRange(
                initialSelection: Int,
                lastDraggedIndex: Int,
                minReached: Int,
                maxReached: Int,
            ) {
                selectItemRange(
                    initialSelection,
                    Math.max(0, lastDraggedIndex),
                    Math.max(0, minReached),
                    maxReached
                )
                if (minReached != maxReached) {
                    lastLongPressedItem = -1
                }
            }

        }
    }

    fun setupDragListener(dragListener: MyRecyclerView.MyDragListener?) {
        binding.pictureRecycler.setupDragListener(dragListener)
    }

    protected fun selectItemRange(from: Int, to: Int, min: Int, max: Int) {
        if (from == to) {
            (min..max).filter { it != from }.forEach { toggleItemSelection(false, it, true) }
            return
        }

        if (to < from) {
            for (i in to..from) {
                toggleItemSelection(true, i, true)
            }

            if (min > -1 && min < to) {
                (min until to).filter { it != from }
                    .forEach { toggleItemSelection(false, it, true) }
            }

            if (max > -1) {
                for (i in from + 1..max) {
                    toggleItemSelection(false, i, true)
                }
            }
        } else {
            for (i in from..to) {
                toggleItemSelection(true, i, true)
            }

            if (max > -1 && max > to) {
                (to + 1..max).filter { it != from }.forEach { toggleItemSelection(false, it, true) }
            }

            if (min > -1) {
                for (i in min until from) {
                    toggleItemSelection(false, i, true)
                }
            }
        }
    }

    protected fun toggleItemSelection(select: Boolean, pos: Int, updateTitle: Boolean = true) {
//        pictureAdapter.getItemViewType(pos)
//        if (select && !getIsItemSelectable(pos)) {
        try {
            if (select && pictures[pos] is AlbumData) {
                return
            }

            if (pictures[pos] is MediaData) {

                if (select) {
                    (pictures[pos] as MediaData).isSelected = true
//                (pictures[pos] as PictureData).isCheckboxVisible = true
//                selectedKeys.add(itemKey)
                } else {
                    (pictures[pos] as MediaData).isSelected = false
//                (pictures[pos] as PictureData).isCheckboxVisible = false
//                selectedKeys.remove(itemKey)
                }
            }
        } catch (e: Exception) {

        }

//        if (::binding.isInitialized)
//            binding.pictureRecycler.recycledViewPool.clear()
        searchAdapter?.notifyItemChanged(pos)
        setSelectedFile()
    }

    private fun setSelectedFile() {
        var selected = 0
        var allItemCount = 0

        var currentHeaderPos = -1
        var photosCount = 0
        var photosSelectCount = 0

        try {

            for (i in pictures.indices) {
                if (pictures[i] is AlbumData) {
                    if (i != currentHeaderPos) {
                        if (currentHeaderPos != -1) {
                            val model = pictures[currentHeaderPos] as AlbumData
                            model.isSelected = photosCount == photosSelectCount
                            photosCount = 0
                            photosSelectCount = 0
                            searchAdapter?.notifyItemChanged(currentHeaderPos)
                        }
                        currentHeaderPos = i
                    }
                } else if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData
                    allItemCount++
                    photosCount++
                    if (model.isSelected) {
                        selected++
                        photosSelectCount++
                    }
                }
                if (i == pictures.size - 1) {
                    if (currentHeaderPos != -1) {
                        val model = pictures[currentHeaderPos] as AlbumData
                        model.isSelected = photosCount == photosSelectCount
                        photosCount = 0
                        photosSelectCount = 0
//                    if (::binding.isInitialized)
//                        binding.pictureRecycler.recycledViewPool.clear()
                        searchAdapter?.notifyItemChanged(currentHeaderPos)
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        longClickListener(true, selected, allItemCount == selected)
        selectedItem = selected
    }


    var selectedItem = 0
    var isSelectAll = false
    private var lastLongPressedMedia = -1
    var selectedPhotosCount = 0
    fun initAdapters() {
        pictures = ArrayList()
        searchAdapter = PhotoAdapter(
            this,
            clickListener = {
                if (pictures[it] is MediaData) {
                    val mediaData = pictures[it] as MediaData
                    if (mediaData.isCheckboxVisible) {
                        mediaData.isSelected = !mediaData.isSelected
                        searchAdapter?.notifyItemChanged(it)
                        setSelectedMedia()
                    } else {
                        val dataList = ArrayList<MediaData>()
                        var displayPos = 0
                        for (i in pictures.indices) {
                            if (pictures[i] is MediaData) {
                                dataList.add(pictures[i] as MediaData)
                                if (it == i) {
                                    displayPos = dataList.size - 1
                                }
                            }
                        }
                        Constant.displayImageList = ArrayList()
                        Constant.displayImageList.addAll(dataList)
                        Constant.selectedPosition = displayPos
//                        val intent = Intent(activity, ImageViewerActivity::class.java)
                        if (Constant.displayImageList.size > 0) {
                            val intent = Intent(this, PhotoVideoActivity::class.java)
                            intent.putExtra(Constant.EXTRA_DISPLAY_POS, displayPos)
                            startActivity(intent)
                        }
//                        setBackAlbumData()
                    }
                }
            },
            longClickListener = {

                lastLongPressedMedia = it
                binding.pictureRecycler.setDragSelectActive(it)
                lastLongPressedMedia = if (lastLongPressedMedia == -1) {
                    it
                } else {
                    val min = min(lastLongPressedMedia, it)
                    val max = max(lastLongPressedMedia, it)
                    for (i in min..max) {
                        toggleMediaSelection(true, i, false)
                    }
//                    updateTitle()
                    it
                }

                if (pictures[it] is MediaData) {
                    val mediaData = pictures[it] as MediaData
                    for (i in pictures.indices) {
                        if (pictures[i] != null)
                            if (pictures[i] is AlbumData) {
                                val model = pictures[i] as AlbumData
                                model.isCheckboxVisible = true
                            } else if (pictures[i] is MediaData) {
                                val model = pictures[i] as MediaData
                                model.isCheckboxVisible = true
                            }
                    }
                    mediaData.isCheckboxVisible = true
                    mediaData.isSelected = true
                    notifyAdapter()
                    setSelectedMedia()
                }

            },
            headerSelectListener = {
                if (pictures[it] is AlbumData) {
                    val albumData = pictures[it] as AlbumData
                    val isSelectAll = !albumData.isSelected
                    albumData.isSelected = isSelectAll
                    var pos = it + 1
                    while (pos < pictures.size) {
                        if (pictures[pos] is MediaData) {
                            val model = pictures[pos] as MediaData
                            model.isSelected = isSelectAll
                            pos++
                        } else if (pictures[pos] is AlbumData) {
                            break
                        }
                    }
                    notifyAdapter()
                    setSelectedMedia()
                }
            },
            enableHeaderSelect = true
        )

        chunkAndSubmitList(pictures)
//        val gridCount = preferences.getGridCount()
        val layoutManager = binding.pictureRecycler.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = 3
        layoutManager.orientation = RecyclerView.VERTICAL
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                if (position >= 0 && position < pictures.size) {
                    return if (searchAdapter!!.getItemViewType(position) === searchAdapter!!.ITEM_HEADER_TYPE) {
                        3
                    } else 1
                } else {
                    return 1
                }
            }
        }
        binding.pictureRecycler.adapter = searchAdapter
    }

    fun toggleMediaSelection(select: Boolean, pos: Int, updateTitle: Boolean = true) {
        try {

            if (select && pictures[pos] is AlbumData) {
                return
            }

            if (pictures[pos] is MediaData) {

                if (select) {
                    (pictures[pos] as MediaData).isSelected = true
                } else {
                    (pictures[pos] as MediaData).isSelected = false
                }
            }
            searchAdapter?.notifyItemChanged(pos)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        setSelectedMedia()

    }

    fun setSelectedMedia() {
        var selected = 0
        var allItemCount = 0

        var currentHeaderPos = -1
        var photosCount = 0
        var photosSelectCount = 0

        for (i in pictures.indices) {
            if (pictures[i] is AlbumData) {
                if (i != currentHeaderPos) {
                    if (currentHeaderPos != -1) {
                        val model = pictures[currentHeaderPos] as AlbumData
                        model.isSelected = photosCount == photosSelectCount
                        photosCount = 0
                        photosSelectCount = 0
                        searchAdapter?.notifyItemChanged(currentHeaderPos)
                    }
                    currentHeaderPos = i
                }
            } else if (pictures[i] is MediaData) {
                val model = pictures[i] as MediaData
                allItemCount++
                photosCount++
                if (model.isSelected) {
                    selected++
                    photosSelectCount++
                }
            }
            if (i == pictures.size - 1) {
                if (currentHeaderPos != -1) {
                    val model = pictures[currentHeaderPos] as AlbumData
                    model.isSelected = photosCount == photosSelectCount
                    photosCount = 0
                    photosSelectCount = 0
                    searchAdapter?.notifyItemChanged(currentHeaderPos)
                }
            }
        }

        longClickListener(true, selected, allItemCount == selected)
        selectedPhotosCount = selected
    }

    private fun longClickListener(
        isShowSelection: Boolean,
        selectedItem: Int,
        isAllSelect: Boolean,
    ) {

        binding.groupToolbarSelectHeader.visibility =
            if (isShowSelection) View.VISIBLE else View.GONE
        isSelectAll = isAllSelect
        binding.loutSelectOption.visibility =
            if (isShowSelection && selectedItem != 0) View.VISIBLE else View.GONE
        binding.groupToolbarHeader.visibility = if (isShowSelection) View.GONE else View.VISIBLE

        binding.txtSelectCount.text = "$selectedItem ${getString(R.string.items_selected)}"

        setSelectAllColor()
    }


    private fun setSelectAllColor() {
//        val color = ContextCompat.getColor(this, if (isSelectAll) R.color.black else R.color.un_check_color)
//        binding.icSelect.setColorFilter(color, PorterDuff.Mode.SRC_IN)
        binding.icSelect.setImageResource(if (isSelectAll) R.drawable.ic_select_all else R.drawable.ic_unselect_all)
    }

    var mSelectedItem = 0

    private fun chunkAndSubmitList(data: List<Any>, chunkSize: Int = 100) {
        CoroutineScope(Dispatchers.Main).launch {
            try {

                // Clear old list first
                searchAdapter?.submitList(emptyList())

                val finalList = ArrayList<Any>()

                val totalSize = data.size
                var start = 0

                while (start < totalSize) {

                    val end = (start + chunkSize).coerceAtMost(totalSize)
                    val chunk = data.subList(start, end)

                    finalList.addAll(chunk)

                    searchAdapter?.submitList(ArrayList(finalList))

                    start = end

                    delay(50)
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun chunkAndSubmitList1(data: List<Any>, chunkSize: Int = 100) {
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val totalSize = data.size
                var start = 0
                while (start < totalSize) {
                    val end = (start + chunkSize).coerceAtMost(totalSize)
                    val chunk = data.subList(start, end)
                    searchAdapter?.submitList(searchAdapter?.currentList.orEmpty() + chunk)
                    start = end
                    delay(50) // Introduce a slight delay to ensure UI responsiveness
                }
            } catch (e: java.lang.IndexOutOfBoundsException) {
                e.printStackTrace()
            } catch (e: IndexOutOfBoundsException) {
                e.printStackTrace()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun setPlaceData() {
        val place = dataBase.dataDao().getLocationEntityList()
        if (place.isNotEmpty()) {
            sortPlace(place)
        }
        //else binding.llPlace.beGone()
    }

    private fun sortPlace(places: List<LocationEntity>) {
        Log.e("MapExploreActivity", "sortImage:::placeList.${placeList.size}")

        places.forEach { data ->
            val strKey = data.title

            var imagesData1: ArrayList<MediaData> = ArrayList()

            val file = File(data.path)
            val pictureData = MediaData(
                file.path,
                Utils.getUriFromPath(this@SearchActivity, file.path).toString(),
                file.name,
                file.parentFile.name,
                file.lastModified(),
                file.lastModified(),
                file.length()
            )
            for (i in placeList.indices) {
//                if (placeList[i] is AlbumData) {
                if (placeList[i].title == strKey) {
                    placeList[i].mediaData.add(pictureData)
                }
//                }
            }

            if (placeList.filter { it.title == strKey }.isNullOrEmpty()) {
                imagesData1.add(pictureData)
//                val placeData = PlaceData(imagesData1, data.title, data.latitude, data.longitude)
                val placeData = AlbumData(
                    title = data.title,
                    mediaData = imagesData1,
                    lati = data.latitude,
                    long = data.longitude
                )
                placeList.add(placeData)
            }
        }
        setData()
    }

    @SuppressLint("CheckResult")
    fun setSearch(searchText: String) {

        val strSearch = searchText.lowercase()
        if (isSearch) isStopSearch = true

        Observable.fromCallable<Boolean> {
            isSearch = true
            pictures.clear()
            if (strSearch.isEmpty()) {
                pictures.clear()
            } else {

                val list = allBackList.filter {
                    it.fileName.lowercase().contains(strSearch)
                            || it.folderName.lowercase().contains(strSearch)
                }

                if (!isStopSearch) {
                    if (list.isNotEmpty()) {
                        pictures.addAll(list)
                    }
                }
            }
            //if (!isStopSearch) setList()

            true
        }.subscribeOn(Schedulers.io())
            .doOnError { throwable: Throwable? ->
                runOnUiThread {
                    isSearch = false
                    isStopSearch = false

                    setData()
                }
            }
            .subscribe { result: Boolean? ->
                runOnUiThread {
                    isStopSearch = false
                    isSearch = false

                    setData()
                }
            }
    }

    private fun setData() {
        Log.e("gettingListPhoto", "Data is show")
        isUpadteList = false
//        enableScroll()

        runOnUiThread {
            //if (searchAdapter != null)
            notifyAdapter()
            setEmptyData()
        }

    }


    private fun setEmptyData() {
        if (pictures != null && pictures.size != 0) {
            binding.pictureRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
        } else {
            binding.pictureRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
        }
    }


    var isUpadteList = false
    fun setFilterData() {
        isUpadteList = true
//        disableScroll()
//        GlobalScope.launch(Dispatchers.IO) {
////            setList()
////            runOnUiThread {
////                setData()
//            getTimeLine()
////            }
//        }
    }

    fun getData() {

        isUpadteList = true
        Glide.get(this).clearMemory()
        Observable.fromCallable {
            Glide.get(this).clearDiskCache()
            pictures.clear()

            getImages()
            getVideos()
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { throwable: Throwable? ->
                setFilterData()
            }
            .subscribe { result: Boolean? ->
                setFilterData()
            }
    }

    private fun getImages() {
        Log.e("gettingListPhoto", "getImages")
        val mCursor: Cursor?
        val folderList: MutableList<String> = ArrayList<String>()
//        folderList.addAll(preferencesManager.getExcludeFolderList())
        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())
        try {
            val BUCKET_DISPLAY_NAME: String
            BUCKET_DISPLAY_NAME = MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
            val projection = arrayOf(
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DATA,
                BUCKET_DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_MODIFIED,
                MediaStore.MediaColumns.DATE_TAKEN,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.SIZE,
            )
            val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            } else {
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            }

            val filterMedia = preferences.getFilterMedia()
            val selection = getSelectionQuery(filterMedia)
            val selectionArgs = getSelectionArgsQuery(filterMedia).toTypedArray()

            mCursor = contentResolver.query(
                uri,  // Uri
                projection,  // Projection
                selection,
                selectionArgs,
                MediaStore.MediaColumns.DATE_MODIFIED + " DESC"
            )
            if (mCursor != null) {
                mCursor.moveToFirst()
                ArrayList<MediaData>()
                mCursor.moveToFirst()
                while (!mCursor.isAfterLast) {
                    //2sec
                    val path =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))
                    val title =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME))
                    var bucketPath = ""
                    bucketPath = path.substring(0, path.lastIndexOf(title) - 1)

                    var bucketName =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(BUCKET_DISPLAY_NAME))
                    if (bucketName == null) bucketName = path.getParentFolder()

                    val fileSizeLength =
                        mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
                    val idColumn = mCursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                    val id = mCursor.getLong(idColumn)
                    val contentUri = ContentUris.withAppendedId(uri, id)


                    if (!folderList.contains(bucketPath) && !bucketName.isNullOrEmpty()) {
                        var d =
                            mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED))
                        d *= 1000
                        var dt =
                            mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))
                        dt *= 1000
                        if (dt == 0L)
                            dt = d

                        val pictureData =
                            MediaData(
                                path,
                                contentUri.toString(),
                                title, bucketName, d, dt, fileSizeLength, false
                            )
                        pictureData.isFavorite = favList.contains(path)
//                        allList.add(pictureData)
                        allBackList.add(pictureData)

//                        imageCount++
                    }
                    mCursor.moveToNext()
                }
                mCursor.close()
            }
        } catch (e: Exception) {
            Log.e("printStackTrace", "printStackTrace:$e")
        }
    }

    private fun getVideos() {
        Log.e("gettingListPhoto", "getVideos")
        var title: String
        var path: String
        val duration: Int
        val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Video.VideoColumns._ID,
            MediaStore.Video.VideoColumns.DATA,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.VideoColumns.SIZE,
            MediaStore.Video.VideoColumns.DURATION,
            MediaStore.Video.VideoColumns.DATE_MODIFIED,
            MediaStore.Video.VideoColumns.DATE_TAKEN,
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
        )
        val folderList: MutableList<String> = ArrayList<String>()
//        folderList.addAll(preferencesManager.getExcludeFolderList())
        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())
        try {
            val filterMedia = preferences.getFilterMedia()
            val selection = getSelectionQuery(filterMedia)
            val selectionArgs = getSelectionArgsQuery(filterMedia).toTypedArray()

            val cursor = contentResolver.query(
                uri,
                projection,
                selection,
                selectionArgs,
                MediaStore.Video.VideoColumns.DATE_MODIFIED + " DESC"
            )
            if (cursor != null) {
                duration = cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DURATION)
                cursor.moveToFirst()
                while (!cursor.isAfterLast) {
                    path =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA))
                    title =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME))
                    var bucketName =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME))
                    if (bucketName == null) bucketName = path.getParentFolder()
                    val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns._ID)
                    val id = cursor.getLong(idColumn)
                    val contentUri = ContentUris.withAppendedId(uri, id)

                    var bucketPath = ""
                    bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
                    if (!folderList.contains(bucketPath)) {
                        var d =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DATE_MODIFIED))
                        d *= 1000
                        val fileSizeLength =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
                        var dt =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))
                        dt *= 1000
                        if (dt == 0L)
                            dt = d
                        val pictureData = MediaData(
                            path,
                            contentUri.toString(),
                            title,
                            bucketName,
                            d,
                            dt,
                            fileSizeLength,
                            true,
                            cursor.getLong(duration)
                        )
                        pictureData.isFavorite = favList.contains(path)
                        pictureData.isVideo = true
//                        allList.add(pictureData)
                        allBackList.add(pictureData)

//                        videoCount++
                    }
                    cursor.moveToNext()
                }
                cursor.close()
            }
        } catch (exp: java.lang.Exception) {
            exp.printStackTrace()
        }
    }

    private fun notifyAdapter() {
        if (searchAdapter != null) {
            searchAdapter?.notifyDataSetChanged()
        }
    }


    private fun getSelectionQuery(filterMedia: Int): String {
        val query = StringBuilder()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")

            rawExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }


        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
        }


        if (filterMedia and TYPE_GIFS != 0) {
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }


        return query.toString().trim().removeSuffix("OR")
    }

    private fun getSelectionArgsQuery(filterMedia: Int): ArrayList<String> {
        val args = ArrayList<String>()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.jpg")
            args.add("%.jpeg")
            rawExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.svg")
        }


        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                args.add("%$it")
            }
        }

        if (filterMedia and TYPE_GIFS != 0) {
            args.add("%.gif")
        }


        return args
    }


}