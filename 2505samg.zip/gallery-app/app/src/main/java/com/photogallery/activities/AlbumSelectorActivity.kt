package com.photogallery.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.photogallery.R
import com.photogallery.adapter.AlbumCreationAdapter
import com.photogallery.base.BaseActivity
import com.photogallery.databinding.DialogAddAlbumFullBinding
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.extension.toast
import com.photogallery.jobs.LoaderXMedia
import com.photogallery.model.AlbumData
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences


class AlbumSelectorActivity : BaseActivity() {

    private lateinit var binding: DialogAddAlbumFullBinding
    private lateinit var albumAdapter: AlbumCreationAdapter
    private var albumList: ArrayList<AlbumData> = ArrayList()
    private var selectPos = -1
    private lateinit var preferences: Preferences

    private var albumDataList: ArrayList<AlbumData> = ArrayList()
    private var selectedAlbum: ArrayList<String> = ArrayList()

    private var isCopy: Boolean = false
    var albumLoader: LoaderXMedia? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DialogAddAlbumFullBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        selectedAlbum =
            intent.getSerializableExtra("selectedAlbum") as? ArrayList<String> ?: arrayListOf()
//        selectedAlbum = intent.getStringExtra("selectedAlbum")?:""
        isCopy = intent.getBooleanExtra("isCopy", false)

        preferences = Preferences(this)


        initView()
        initListener()
        albumLoader = LoaderXMedia(
            this,
            sortOrder = Constant.ORDER_ASCENDING,//activity.preferences.getSortOrder("frag_0"),
            sortType = Constant.SORT_DATE,//activity.preferences.getSortType("frag_0"),
            addCustomAlbum = false,
            prefKey = "frag_0",
            limitAlbum = false
        )
        binding.refreshAlbum.beVisible()
        albumLoader?.destroyLoader()
        albumLoader?.getAllAlbumOnly({ allAlbumList ->
            albumDataList.clear()
            albumDataList.addAll(allAlbumList)
            Constant.deviceAlbumList.clear()
            Constant.deviceAlbumList.addAll(allAlbumList)
            Log.e("AlbumRenameDialog", "onSuccess.size:${albumDataList.size}")
            runOnUiThread {
                binding.refreshAlbum.beGone()
                initAdapter()
            }
        },{
            Log.e("AlbumRenameDialog", "onFailed:${it}")
        })

    }

    private fun initView() {
        binding.txtTitle.text =
            if (isCopy) getString(R.string.copy_to_album) else getString(R.string.move_to_album)

    }

    private fun initAdapter() {
        albumDataList.removeIf { it.folderPath in selectedAlbum }
        albumList.clear()
        albumList.addAll(albumList.size, albumDataList)
        albumAdapter = AlbumCreationAdapter(this, albumList, clickListener = {
            selectPos = it
        })
        val gridLayoutManager = GridLayoutManager(this, 1, RecyclerView.VERTICAL, false)
        binding.albumRecycler.layoutManager = gridLayoutManager
        binding.albumRecycler.adapter = albumAdapter
    }

    private fun initListener() {
        binding.btnClose.setOnClickListener {
            finish()
        }

        binding.btnDone.setOnClickListener {
            if (selectPos >= 0) {
                val albumData = albumList[selectPos]
                if (albumData.isCustomAlbum) {
                    if (albumData.title == getString(R.string.add)) {
                        setResult(RESULT_OK, Intent().putExtra("action", "create"))
                        finish()
                    } else if (albumData.folderPath.isNotEmpty()) {
                        setResult(
                            RESULT_OK,
                            Intent().putExtra("selectedPath", albumData.folderPath)
                        )
                        finish()
                    }
                } else {
                    setResult(RESULT_OK, Intent().putExtra("selectedPath", albumData.folderPath))
                    finish()
                }
            } else {
                toast(getString(R.string.PleaseSelectAlbum))
            }
        }
    }
}
