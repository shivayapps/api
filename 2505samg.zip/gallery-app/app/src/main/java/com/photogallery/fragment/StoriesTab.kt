package com.photogallery.fragment

import android.util.Log
import androidx.recyclerview.widget.GridLayoutManager
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.photogallery.activities.HomeActivity
import com.photogallery.adapter.StoryAdapter
import com.photogallery.adapter.StoryCardAdapter
import com.photogallery.databinding.MainTabStoriesBinding
import com.photogallery.jobs.LoaderXTimeLine
import com.photogallery.model.AlbumData

class StoriesTab(
    private val activity: HomeActivity,
    private val storiesTab: MainTabStoriesBinding
) {

    var storiesAdapter: StoryAdapter? = null
    var memoryAdapter: StoryCardAdapter? = null
    var storiesLoader: LoaderXTimeLine? = null

    fun onCreate() {
        storiesLoader = LoaderXTimeLine(
            activity,
            sortOrder = activity.preferences.getSortOrder("frag_0"),
            sortType = activity.preferences.getSortType("frag_0"),
            prefKey = "frag_0",
            loadVideo = false,
        )
        initAdapters()
    }

    fun getData() {
        storiesLoader?.getAllAlbum({ storyAlbumList, memoryAlbumList, mediaList ->
            Log.d("StoriesTab", "onSuccess.storyAlbumList:${storyAlbumList.size}")
            Log.d("StoriesTab", "onSuccess.memoryAlbumList:${memoryAlbumList.size}")
            Log.d("StoriesTab", "onSuccess.mediaList:${mediaList.size}")

            storiesList.clear()
            storiesList.addAll(storyAlbumList)
            memoryList.clear()
            memoryList.addAll(memoryAlbumList)

            activity.runOnUiThread {
                storiesTab.rvStories.suppressLayout(false)
                storiesTab.rvMemory.suppressLayout(false)

                if (storiesAdapter != null)
                    storiesAdapter?.notifyDataSetChanged()

                if (memoryAdapter != null)
                    memoryAdapter?.notifyDataSetChanged()

                try {
                    val memoryPaths =
                        memoryList.flatMap { it.mediaData.map { media -> media.filePath } }
                    val storyPaths =
                        storiesList.flatMap { it.mediaData.map { media -> media.filePath } }
                    val allFilePaths = memoryPaths + storyPaths
                    preLoad(allFilePaths)
                } catch (e: Exception) {
                    Log.d("StoriesTab", "preLoad.Exception:$e")
                }
            }
        })

    }

    val fullOptions = RequestOptions()
        .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
        .skipMemoryCache(false)
        .format(DecodeFormat.PREFER_ARGB_8888)
        .dontAnimate()

    fun preLoad(allFilePaths: List<String>) {
        val dm = activity.resources.displayMetrics
        allFilePaths.forEach { media ->
            Glide.with(activity)
                .load(media)
                .apply(fullOptions.override(dm.widthPixels, dm.heightPixels))
                .preload()
        }
    }

    var storiesList: ArrayList<AlbumData> = ArrayList()
    var memoryList: ArrayList<AlbumData> = ArrayList()

    private fun initAdapters() {
        Log.e("StoriesTab", "storiesAdapter >>>")
        storiesAdapter = StoryAdapter(activity, clickListener = { albumData ->
            activity.openStoryView(albumData)
        })
        storiesAdapter?.submitList(storiesList)

        storiesTab.rvStories.layoutManager =
            GridLayoutManager(activity, 1, GridLayoutManager.HORIZONTAL, false)
        storiesTab.rvStories.setHasFixedSize(false)
        storiesTab.rvStories.adapter = storiesAdapter

        Log.e("StoriesTab", "storiesAdapter <<<")


        Log.e("StoriesTab", "memoryAdapter >>>")
        memoryAdapter = StoryCardAdapter(activity, clickListener = { albumData ->
            activity.openStoryView(albumData)
        })
        memoryAdapter?.submitList(memoryList)

        storiesTab.rvMemory.layoutManager =
            GridLayoutManager(activity, 1, GridLayoutManager.VERTICAL, false)
        storiesTab.rvMemory.setHasFixedSize(false)
        storiesTab.rvMemory.adapter = memoryAdapter
        Log.e("StoriesTab", "memoryAdapter <<<")
    }

}