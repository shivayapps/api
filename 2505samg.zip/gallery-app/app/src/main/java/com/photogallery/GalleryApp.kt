package com.photogallery

import android.app.Activity
import android.content.Intent
import android.content.res.Resources
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.appcompat.app.AppCompatDelegate
import androidx.multidex.MultiDexApplication
import com.github.ajalt.reprint.core.Reprint
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseApp
import com.photogallery.BuildConfig
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.crashlytics.FirebaseCrashlytics
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.squareup.picasso.Downloader
import com.squareup.picasso.Picasso
import com.photogallery.activities.PermissionActivity
import com.photogallery.extension.getValidLanguageCode
import com.photogallery.messaging.Notifier
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences
import com.photogallery.utils.TIME_FORMAT_12
import com.photogallery.utils.TIME_FORMAT_24
import okhttp3.Request
import okhttp3.Response
import java.util.Locale

class GalleryApp : MultiDexApplication(){

    lateinit var remoteConfig: FirebaseRemoteConfig
    override fun onCreate() {
        super.onCreate()

        Reprint.initialize(this)
        Picasso.setSingletonInstance(Picasso.Builder(this).downloader(object : Downloader {
            override fun load(request: Request) = Response.Builder().build()

            override fun shutdown() {}
        }).build())

        preferences =
            Preferences(applicationContext)
        FirebaseApp.initializeApp(applicationContext)
        FirebaseCrashlytics.getInstance()
            .setCrashlyticsCollectionEnabled(!BuildConfig.VERSION_NAME.contains("test"))

        remoteConfig = FirebaseRemoteConfig.getInstance()
        remoteConfig.reset()
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(applicationContext)

        val defaultLanguage = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            getValidLanguageCode(Resources.getSystem().configuration.locale.language)
        } else {
            getValidLanguageCode(Locale.getDefault().language)
        }
        preferences.systemLocalLanguage = defaultLanguage

        fireBaseConfigGet()

        Constant.themeType = preferences.getThemeValue()
        setAppTheme(Constant.themeType)
        val dateFormat = preferences.dateFormat
        val timeFormat = if (preferences.use24HourFormat) TIME_FORMAT_24 else TIME_FORMAT_12
        Constant.dateFormat = dateFormat
        Constant.timeFormat = timeFormat

        Notifier.scheduleDailyWorker(this)
    }
    fun setAppTheme(themeType:Int) {
        Log.d("GalleryApp", "setAppTheme")
//        themeType = Preferences(this).getThemeValue()
        when (themeType) {
            Constant.THEME_LIGHT -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }

            Constant.THEME_DARK -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            }
        }
        Log.d("GalleryApp", "setAppTheme.002")
    }

    private fun fireBaseConfigGet() {
        try {
            remoteConfig.setConfigSettingsAsync(
                FirebaseRemoteConfigSettings.Builder()
                    .setMinimumFetchIntervalInSeconds(0)
                    .setFetchTimeoutInSeconds(3)
                    .build()
            )

            remoteConfig.setDefaultsAsync(R.xml.remote_config_defaults)
            remoteConfig.fetch(0)
                .addOnCompleteListener { task: Task<Void?> ->
                    var errorString = ""
                    if (task.isSuccessful) {
                        Log.e("fireBaseConfigGet", "Successful")
                        remoteConfig.fetchAndActivate()

                        errorString = " task is successful  "

                    } else {
                        Log.e("fireBaseConfigGet", "Failed:${task.exception}")
                        errorString = "task is canceled"
                    }
                }
        } catch (e: java.lang.Exception) {
            Log.e("printStackTrace", "printStackTrace:$e")
        }
    }

    companion object {
//        private lateinit var mContext: Context
        lateinit var mFirebaseAnalytics: FirebaseAnalytics
        lateinit var preferences: Preferences

    }

}
