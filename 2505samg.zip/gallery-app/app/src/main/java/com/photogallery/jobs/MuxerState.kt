package com.photogallery.jobs

data class MuxerState(
    var trackIndex: Int = -1,
    var started: Boolean = false
)