package com.photogallery.utils;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;

public class AllTempLogsFilter implements FileFilter {

    ArrayList<String> filters;

    public AllTempLogsFilter(ArrayList<String> filters) {
        this.filters = filters;
    }

    @Override
    public boolean accept(File pathname) {
        String path = pathname.getAbsolutePath();
        for (String filter : filters)
            if (path.toLowerCase().matches(filter.toLowerCase()) && !path.contains("RecoverMedia"))
                return true;
        return false;
    }
}