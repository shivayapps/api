package com.photogallery.utils;

import java.io.File;
import java.io.FileFilter;

public class AllPackagesFilter implements FileFilter {
        @Override
        public boolean accept(File pathname) {
            String path = pathname.getPath();
            return (pathname.getAbsolutePath().endsWith(".apk") ||
                    pathname.getAbsolutePath().endsWith(".xapk"));
        }
    }