package com.photogallery.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;


import com.photogallery.R;
import com.photogallery.model.FileModel;
import com.photogallery.utils.Utils;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class JunkAdapter1 extends ListAdapter<FileModel, JunkAdapter1.FileHolder> {
    Context context;
    View view;
    FileHolder holder;
    String type;
    SelectAll selectAll;
    double total = 0f;

    List<FileModel> killingApps;
    List<FileModel> adapterApps;


    public JunkAdapter1(Context context, List<FileModel> killingApps, List<FileModel> adapterApps, String type, double total) {
        super(DIFF_CALLBACK);
        this.context = context;
        this.killingApps = killingApps;
        this.adapterApps = adapterApps;
        this.type = type;
        this.total = total;
    }

    public double getAllTotal() {
        double appTotal = 0f;
        for (FileModel app : killingApps) {
            appTotal += app.getSize();

        }
        return appTotal;
    }

    public double getTotal() {
        return total;
    }

    public static final DiffUtil.ItemCallback<FileModel> DIFF_CALLBACK = new DiffUtil.ItemCallback<FileModel>() {
        @Override
        public boolean areItemsTheSame(@NonNull FileModel oldItem, @NonNull FileModel newItem) {
            return oldItem.equals(newItem);
        }

        @SuppressLint("DiffUtilEquals")
        @Override
        public boolean areContentsTheSame(@NonNull FileModel oldItem, @NonNull FileModel newItem) {
            return oldItem.equals(newItem);
        }
    };


    public void setAdapterApps(List<FileModel> adapterApps) {
        this.adapterApps = adapterApps;
    }

    public void setKillingApps(List<FileModel> killingApps) {
        this.killingApps = killingApps;
    }

    public List<FileModel> getKillingApps() {
        return killingApps;
    }

    public void clearFile() {
        Log.e("JunkAdapter1", "clearFile-->" + type);

        Iterator<FileModel> iterator = killingApps.iterator();

        while (iterator.hasNext()) {
            FileModel fileModel = iterator.next();
            File file = new File(fileModel.getPath());

            try {
                if (file.exists() && file.delete()) {
                    Log.e("JunkAdapter1", "Deleted: " + file.getPath());

                    // Remove from adapter list as well
                    adapterApps.remove(fileModel);

                    // Remove safely while iterating
                    iterator.remove();
                }
            } catch (Exception e) {
                Log.e("JunkAdapter1", "Error: " + e);
            }
        }

        submitList(new ArrayList<>(adapterApps));

        Log.e("JunkAdapter1", "clearFile-->exit");
    }

    public void justRemoveSelectedFile() {
        Log.e("JunkAdapter1", "clearFile-->" + type);

        Iterator<FileModel> iterator = killingApps.iterator();

        while (iterator.hasNext()) {
            FileModel fileModel = iterator.next();

            try {

                // Remove from adapter list as well
                adapterApps.remove(fileModel);

                // Remove safely while iterating
                iterator.remove();
            } catch (Exception e) {
                Log.e("JunkAdapter1", "Error: " + e);
            }
        }

        submitList(new ArrayList<>(adapterApps));

        Log.e("JunkAdapter1", "clearFile-->exit");
    }

    @NonNull
    @Override
    public FileHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_item_1, parent, false);
        holder = new FileHolder(view);
        //return new FileHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull FileHolder holder, int position) {
        holder.textView_app_name.setText(getItem(position).getPath());
        holder.textView_app_path.setText(getItem(position).getPath());
        holder.textView_app_name.setSelected(true);
        holder.textView_app_path.setSelected(true);

        holder.checkbox.setBackground(ContextCompat.getDrawable(context, R.drawable.selector_custom_checkbox_red));

        holder.checkbox.setChecked(killingApps.contains(getItem(position)));
        Pair<String, String> size = Utils.INSTANCE.getDataSizeWithPrefix(context, (float) getItem(position).getSize());
        holder.textView_size.setText(size.first + " " + size.second);
        Log.e("JunkAdapter1", "size01:" + new File(getItem(position).getPath()).length());


        holder.itemView.setOnClickListener(v -> {
            if (killingApps.contains(getItem(position))) {
                killingApps.remove(getItem(position));
                total = total - getItem(position).getSize();
                selectAll.selectAll(false, type);
                holder.checkbox.setChecked(false);
            } else {
                holder.checkbox.setChecked(true);
                killingApps.add(getItem(position));
                total = total + getItem(position).getSize();
                selectAll.selectAll(killingApps.size() == getCurrentList().size(), type);
            }
            notifyItemChanged(position);
        });

    }

    public Drawable getIconFromApk(String apkPath) {
        PackageManager packageManager = context.getPackageManager();
        PackageInfo packageInfo = packageManager.getPackageArchiveInfo(apkPath, 0);

        // you need to set this variables manually for some reason to get icon from APK file that has not been installed
        Drawable icon = null;
        if (packageInfo != null) {
            packageInfo.applicationInfo.sourceDir = apkPath;
            packageInfo.applicationInfo.publicSourceDir = apkPath;
            icon = packageInfo.applicationInfo.loadIcon(packageManager);
        }

        return icon;
    }

    public void selectAll() {
        if (!killingApps.isEmpty()) {
            killingApps.clear();
        }
        killingApps.addAll(adapterApps);
        notifyDataSetChanged();

    }

    public void clearList() {
        if (!killingApps.isEmpty()) {
            killingApps.clear();
        }
        notifyDataSetChanged();
    }


    static class FileHolder extends RecyclerView.ViewHolder {

        CheckBox checkbox;
        TextView textView_app_name, textView_app_path, textView_size;

        public FileHolder(@NonNull View itemView) {
            super(itemView);
            checkbox = itemView.findViewById(R.id.checkbox);
            textView_app_name = itemView.findViewById(R.id.textView_app_name);
            textView_app_path = itemView.findViewById(R.id.textView_app_path);
            textView_size = itemView.findViewById(R.id.textView_size);

        }
    }

    public void setSelectAll(SelectAll selectAll) {
        this.selectAll = selectAll;
    }

}
