package com.photogallery.model

data class MomentModel(val name: String, val sub_categories: ArrayList<String>)