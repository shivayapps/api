package com.photogallery.dialog

import android.app.Dialog
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.media.MediaMetadataRetriever
import android.os.Bundle
import android.text.format.Formatter
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.photogallery.model.MediaData
import com.photogallery.R
import com.photogallery.databinding.DialogPreviewBinding
import com.photogallery.utils.DIALOG_DIM_AMOUNT
import com.photogallery.utils.Utils
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.Objects

class ContentPreviewDialog(val mContext: Context, var mediaData: MediaData) :
    Dialog(mContext) {

    lateinit var bindingDialog: DialogPreviewBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.navigationBarColor = ContextCompat.getColor(mContext, R.color.dialogBg)
        window?.setGravity(Gravity.BOTTOM)
        window?.setDimAmount(DIALOG_DIM_AMOUNT)
        window?.attributes?.windowAnimations = android.R.style.Animation_Dialog

        bindingDialog = DialogPreviewBinding.inflate(layoutInflater)
//        bindingDialog.root.setPadding(0, 0, 0, mContext.navigationBarHeight)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
    }

    private fun intView() {
        intListener()

        val glideOptions = RequestOptions()
            .format(DecodeFormat.PREFER_ARGB_8888)
            .diskCacheStrategy(DiskCacheStrategy.NONE)
            .skipMemoryCache(false)
        Glide.with(mContext)
            .asBitmap()
            .apply(glideOptions)
            .override(180)
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .load(mediaData.filePath)
            .into(bindingDialog.zoomableImageView)

        bindingDialog.loutDetails.visibility = View.VISIBLE

        val formatDetails = SimpleDateFormat("dd/MM/yyyy, hh:mm aa", Locale.ENGLISH)
        bindingDialog.txtName.text = mediaData.fileName
        bindingDialog.txtPath.text = mediaData.filePath
        val strDate = formatDetails.format(mediaData.date)

        bindingDialog.txtTime.text = strDate
        bindingDialog.txtFormat.text = Utils.getFilenameExtension(mediaData.filePath)

        bindingDialog.txtSize.text = Formatter.formatShortFileSize(mContext, mediaData.fileSize)

        var resolution = ""
        if (mediaData.isVideo) {
            resolution = try {
                val metaRetriever = MediaMetadataRetriever()
                metaRetriever.setDataSource(mediaData.filePath)
                val height =
                    Objects.requireNonNull(metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT))!!
                        .toInt()
                val width =
                    Objects.requireNonNull(metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH))!!
                        .toInt()
                "$width X $height"
            } catch (e: Exception) {
                Log.e("printStackTrace", "printStackTrace:$e")
                "--"
            }
        } else {
            resolution = try {
                val options = BitmapFactory.Options()
                options.inJustDecodeBounds = true
                BitmapFactory.decodeFile(mediaData.filePath, options)
                val imageHeight = options.outHeight
                val imageWidth = options.outWidth
                "$imageWidth X $imageHeight"
            } catch (e: Exception) {
                Log.e("printStackTrace", "printStackTrace:$e")
                "--"
            }
        }

        bindingDialog.txtResolution.text = resolution
    }

    private fun intListener() {

        bindingDialog.btnOK.setOnClickListener {
            dismiss()
        }
    }

//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)
}