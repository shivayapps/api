package com.photogallery.utils

import android.content.Context
import android.graphics.*
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.intuit.sdp.R
import kotlin.math.hypot

class GridScaleGestureManager(
    private val recyclerView: RecyclerView,
    context: Context,
    private var currentSpan: Int,
    private val minSpan: Int = 2,
    private val maxSpan: Int = 8,
    private val onSpanUpdated: (Int) -> Unit
) : RecyclerView.ItemDecoration() {

    init {
        recyclerView.addItemDecoration(this)
        recyclerView.setOnTouchListener { _, event ->
            scaleGestureDetector.onTouchEvent(event)
            if (event.action == MotionEvent.ACTION_UP || event.action == MotionEvent.ACTION_CANCEL) {
                if (isScaling) applyTempSpan()
            }
            false
        }
    }
    private val gridLayoutManager: GridLayoutManager?
        get() = recyclerView.layoutManager as? GridLayoutManager
    private var gestureCenterX = -1f
    private var gestureCenterY = -1f

    private var tempSpan = currentSpan
    private var scaleAccumulator = 1f
    private var isScaling = false

    private var overlayVisible = false

    private val scaleGestureDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {

            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                if (gridLayoutManager == null) return false

                isScaling = true
                overlayVisible = true
//                tempSpan = currentSpan
                tempSpan = currentSpan.coerceIn(minSpan, maxSpan)
                scaleAccumulator = 1f
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                if (gridLayoutManager == null) return false

                gestureCenterX = detector.focusX
                gestureCenterY = detector.focusY


                scaleAccumulator *= detector.scaleFactor
                val threshold = 1.10f
                val previousSpan = tempSpan

                // Zoom Out → decrease columns = bigger items
                if (scaleAccumulator > threshold) {
                    tempSpan = (tempSpan - 1).coerceAtLeast(minSpan)
                    scaleAccumulator = 1f
                }
                // Zoom In → increase columns = smaller items
                else if (scaleAccumulator < (1f / threshold)) {
                    tempSpan = (tempSpan + 1).coerceAtMost(maxSpan)
                    scaleAccumulator = 1f
                }

                if (tempSpan != previousSpan) {
                    performHaptic()
                }

                tempSpan = tempSpan.coerceIn(minSpan, maxSpan)
                recyclerView.invalidateItemDecorations()
                return true
            }


            override fun onScaleEnd(detector: ScaleGestureDetector) {
                applyTempSpan()
            }
        })

    private fun performHaptic() {
        recyclerView.performHapticFeedback(
            HapticFeedbackConstants.VIRTUAL_KEY,
            HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
        )
    }


    private fun applyTempSpan() {
        if (gridLayoutManager == null) return

        isScaling = false
        overlayVisible = false
        currentSpan = tempSpan.coerceIn(minSpan, maxSpan)
        onSpanUpdated(currentSpan)

    }

    private val gridPaint = Paint().apply {
        color = Color.WHITE
        strokeWidth = 4f
        alpha = 140
    }

    private val mainBgPaint = Paint().apply {
        isAntiAlias = true
    }

    var titleSize = context.resources.getDimension(R.dimen._45sdp)
    private val textPaint = Paint().apply {
        color = Color.WHITE
        textSize = titleSize
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }


    override fun onDrawOver(c: Canvas, parent: RecyclerView, state: RecyclerView.State) {
        if (!overlayVisible || gridLayoutManager == null) return

//        if (!overlayVisible) return

        val width = parent.width
        val height = parent.height

        // ===== FULL SCREEN DIM BACKGROUND =====
//        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), mainBgPaint)
        val centerX = width / 2f
        val centerY = height / 2f
//        val centerX = if (gestureCenterX > 0) gestureCenterX else width / 2f
//        val centerY = if (gestureCenterY > 0) gestureCenterY else height / 2f

        val radius = hypot(width.toFloat(), height.toFloat()) / 1.2f

        val gradient = RadialGradient(
            centerX,
            centerY,
            radius,
            intArrayOf(
                Color.parseColor("#CC000000"), // dark center
                Color.parseColor("#88000000"), // mid
                Color.parseColor("#22000000")  // outer light
            ),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )

        mainBgPaint.shader = gradient
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), mainBgPaint)

        // ===== CENTER CAPSULE WITH SPAN NUMBER =====
        val text = tempSpan.toString()
        val textBounds = Rect()
        textPaint.getTextBounds(text, 0, text.length, textBounds)

        // centered text
        val textX = centerX
        val textY = centerY - textBounds.exactCenterY()
        c.drawText(text, textX, textY, textPaint)

        // ===== GRID (VERTICAL + HORIZONTAL) =====
        val colWidth = width.toFloat() / tempSpan

        // vertical lines
        for (i in 1 until tempSpan) {
            val x = i * colWidth
            c.drawLine(x, 0f, x, height.toFloat(), gridPaint)
        }

        // horizontal lines
        val rowHeight = colWidth
        val rowCount = (height / rowHeight).toInt()
        for (i in 1 until rowCount) {
            val y = i * rowHeight
            c.drawLine(0f, y, width.toFloat(), y, gridPaint)
        }
    }


}
