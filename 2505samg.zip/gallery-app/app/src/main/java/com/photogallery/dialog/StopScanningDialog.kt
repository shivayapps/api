package com.photogallery.dialog

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import com.photogallery.R
import com.photogallery.databinding.DialogStopScanningBinding
import com.photogallery.utils.DIALOG_DIM_AMOUNT

class StopScanningDialog(
    val activity: Activity,
    val clickListener: (isExit: Boolean) -> Unit
) : Dialog(activity) {

    lateinit var binding: DialogStopScanningBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        window?.setDimAmount(DIALOG_DIM_AMOUNT)
        window?.attributes?.windowAnimations = android.R.style.Animation_Dialog
//        window?.decorView!!.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        binding = DialogStopScanningBinding.inflate(layoutInflater)

        binding.permission.text = activity.getString(R.string.scanning_in_progress)
        binding.permissionText.text = activity.getString(R.string.are_you_sure_you_want_to_stop_scanning_your_device)
        binding.dialogButtonOk.text = activity.getString(R.string.doit_close)
        binding.dialogButtonCancel.text = activity.getString(R.string.stop)

        setContentView(binding.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT
        )
        binding.dialogButtonOk.setOnClickListener {
            dismiss()
            clickListener.invoke(true)
        }
        binding.dialogButtonCancel.setOnClickListener {
            dismiss()
        }

    }


}