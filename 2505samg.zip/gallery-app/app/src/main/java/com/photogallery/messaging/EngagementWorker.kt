package com.photogallery.messaging

import android.content.Context
import android.provider.MediaStore
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.photogallery.utils.Preferences

class EngagementWorker(
    val context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {

        val ctx = applicationContext
        val preferences = Preferences(ctx)

        // Cooldown: avoid spam
        if (preferences.notificationSentToday(ctx)) return Result.success()

//        val now = System.currentTimeMillis()
//        val lastOpen = preferences.lastAppOpen(ctx)

//        val hoursSinceOpen = (now - lastOpen) / (1000 * 60 * 60)
//        // 1. Inactivity trigger (48h)
//        if (hoursSinceOpen >= 48) {
//            Notifier.show(
//                ctx,
//                "We miss you 📸",
//                "Rediscover your gallery memories"
//            )
//            return Result.success()
//        }
//
//        // 2. Media burst trigger
//        val recentCount = getRecentPhotoCount(ctx)
//        if (recentCount > 15) {
//            Notifier.show(
//                ctx,
//                "Create something amazing ✨",
//                "Turn your recent photos into a video"
//            )
//            return Result.success()
//        }
//
//        // 3. Default → memory notification
//        Notifier.show(
//            ctx,
//            "Relive your memories 📸",
//            "See what you captured on this day"
//        )

        val (title, body,image) = Notifier.getRandomMessage()

        Notifier.showNotification(
            context,
            title,
            body,
            0,
            image
        )

        return Result.success()
    }

    // Query MediaStore for last 48h images
    private fun getRecentPhotoCount(context: Context): Int {

        val uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI

        val projection = arrayOf(MediaStore.Images.Media.DATE_ADDED)

        val cutoff = (System.currentTimeMillis() / 1000) - (48 * 60 * 60)

        val selection = "${MediaStore.Images.Media.DATE_ADDED} > ?"
        val selectionArgs = arrayOf(cutoff.toString())

        var count = 0

        context.contentResolver.query(
            uri,
            projection,
            selection,
            selectionArgs,
            null
        )?.use {
            count = it.count
        }

        return count
    }
}