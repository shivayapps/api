package com.photogallery.interfaces

import android.content.Context
import android.util.Log
import com.google.gson.Gson
import com.photogallery.GalleryApp
import com.photogallery.extension.readJsonFromAssets
import com.photogallery.extension.toList
import com.photogallery.model.MomentModel
import org.json.JSONObject
import kotlin.ranges.until

object MemoryCategoryAppsConfig {

//    fun getConfig(remoteConfig: FirebaseRemoteConfig) {
//        try {
//            val jsonArrayString = remoteConfig.getString("appMemoryCategory")
//            if (jsonArrayString.isNotEmpty()) {
//                GalleryApp.preferences.appMemoryCategory = jsonArrayString
//            }
//            Log.e("MemoryCategoryAppsConfig", "appMemoryCategory:$jsonArrayString")
//        } catch (e: Exception) {
//
//            e.printStackTrace()
//            GalleryApp.preferences.appMemoryCategory = ""
//        }
//    }

    fun getMomentLists(context: Context): ArrayList<MomentModel> {
        val momentModelList = kotlin.collections.ArrayList<MomentModel>()
        try {

//            val jsonObjFamily = JSONObject(GalleryApp.preferences.appMemoryCategory)
            val jsonString = context.readJsonFromAssets("appMomentCategory.json")
            val jsonObjFamily = JSONObject(jsonString)
            val jsonArray = jsonObjFamily.getJSONArray("categories")
            for (i in 0 until jsonArray.length()) {
                val jsonObject = jsonArray.getJSONObject(i)
                momentModelList.add(
                    MomentModel(
                        jsonObject.getString("name"),
                        jsonObject.getJSONArray("sub_categories").toList()
                    )
                )
            }
            Log.e("MomentCategory", "categories:${Gson().toJson(jsonArray)}")
            return momentModelList
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return kotlin.collections.ArrayList()
    }

    fun getMomentAccuracyLevel(): Double {
        try {
//            val jsonObjFamily = JSONObject(GalleryApp.preferences.appMemoryCategory)
//            Log.e(
//                "MomentCategory",
//                "getMomentAccuracyLevel:${Gson().toJson(jsonObjFamily)}"
//            )
            return 90 / 100.0
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return 0.90
    }

}