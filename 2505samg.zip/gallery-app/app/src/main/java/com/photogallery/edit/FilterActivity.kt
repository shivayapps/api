package com.photogallery.edit

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.target.Target
import com.bumptech.glide.request.transition.Transition
import com.photogallery.R
import com.photogallery.base.BaseActivity
import com.photogallery.databinding.ActivityFilterBinding
import com.photogallery.dialog.ProgressDialog
import com.photogallery.edit.adapter.FilterAdapter
import com.photogallery.edit.model.FilterItem
import com.photogallery.extension.updateStatusBarColor
import com.photogallery.helper.FilterThumbnailsManager
import com.photogallery.utils.Constant
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import com.photofilters.FilterPack
import com.photofilters.imageprocessors.Filter
import java.io.File

class FilterActivity : BaseActivity() {
    lateinit var binding: ActivityFilterBinding
    var filterNewList: ArrayList<FilterItem> = ArrayList()
    var imagePath = ""
    var saveImageName = ""
    var sourceImgBitmap: Bitmap? = null
    var filterBitmap: Bitmap? = null
    lateinit var adapter: FilterAdapter
    var selectPos = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        applyStatusBar = false
        super.onCreate(savedInstanceState)
        binding = ActivityFilterBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
//        System.loadLibrary("NativeImageProcessor")
        updateStatusBarColor(Color.parseColor("#151515"))

        intView()
    }

    override fun onResume() {
        applyStatusBar = false
        super.onResume()
    }

    override fun onPause() {
        super.onPause()
    }



    private fun intView() {

        imagePath = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_PATH) ?: ""
        saveImageName = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_NAME) ?: ""
        binding.txtTitle.text = getString(R.string.Filter)

        intListener()

//        setFilterData()
        val file = File(imagePath)
        if (file.exists()) {
            Glide.with(this)
                .load(imagePath)
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .skipMemoryCache(false)
                .into(binding.imageDisplay)

            Glide
                .with(this)
                .asBitmap()
                .load(imagePath)
                .into(object : CustomTarget<Bitmap>() {
                    override fun onResourceReady(
                        resource: Bitmap,
                        transition: Transition<in Bitmap>?
                    ) {
                        sourceImgBitmap = resource


                    }

                    override fun onLoadCleared(placeholder: Drawable?) {

                    }
                })

            getFilterData()
        } else {
            Toast.makeText(this, getString(R.string.image_not_support), Toast.LENGTH_SHORT).show()
        }
    }

    private fun getFilterData() {
        var bitmap: Bitmap? = null
        Observable.fromCallable {
            val thumbnailSize = 70
            bitmap = try {
                Glide.with(this)
                    .asBitmap()
                    .load(imagePath).listener(object : RequestListener<Bitmap> {
                        override fun onLoadFailed(
                            e: GlideException?,
                            model: Any?,
                            target: Target<Bitmap>,
                            isFirstResource: Boolean
                        ): Boolean {

                            return false
                        }

                        override fun onResourceReady(
                            resource: Bitmap,
                            model: Any,
                            target: Target<Bitmap>,
                            dataSource: DataSource,
                            isFirstResource: Boolean
                        ) = false
                    })
                    .submit(thumbnailSize, thumbnailSize)
                    .get()
            } catch (e: Exception) {
                null
            }

            true
        }.subscribeOn(Schedulers.io())
            .doOnError { throwable: Throwable? ->
                runOnUiThread {
                    getThumbList(bitmap)
                }
            }
            .subscribe { result: Boolean? ->
                runOnUiThread {
                    getThumbList(bitmap)
                }
            }
    }


    private fun getThumbList(bm: Bitmap?) {

        val bitmap = bm
            ?: getBitmapFromDrawable(
                ContextCompat.getDrawable(
                    this,
                    R.drawable.ic_filter_none
                )
            )

        val filterThumbnailsManager = FilterThumbnailsManager()
        filterThumbnailsManager.clearThumbs()

        val noFilter = Filter(getString(R.string.None))
        filterThumbnailsManager.addThumb(FilterItem(bitmap, noFilter))

        FilterPack.getFilterPack(this).forEach {
            val filterItem = FilterItem(bitmap, it)
            filterThumbnailsManager.addThumb(filterItem)
        }
        val filterItems = filterThumbnailsManager.processThumbs(this@FilterActivity)
        filterNewList.addAll(filterItems)

        setFilterData()
    }


    private fun intListener() {
        binding.icBack.setOnClickListener { onBackPressed() }
        binding.ivDone.setOnClickListener {
            if (selectPos != 0 && filterBitmap != null) {
                val progressDialog = ProgressDialog(
                    this@FilterActivity,
                    0,
                    0,
                    getString(R.string.saving),
                    ""
                )
                progressDialog.setCancelable(false)
                progressDialog.show()
//        progressDialog.isCancelable = false
                Thread {
                    val imagePath = saveEditImage(filterBitmap!!, saveImageName)
                    runOnUiThread {
                        if (imagePath != null) {
                            val intent = Intent()
                            intent.putExtra(Constant.EXTRA_EDIT_SAVE_IMAGE, imagePath)
                            setResult(RESULT_OK, intent)
                        }
                        if(!isFinishing && !isDestroyed) {
                            if (progressDialog.isShowing)
                                progressDialog.dismiss()
                        }
                        finish()
                    }
                }.start()
            } else
                finish()
        }
    }

    private fun setFilterData() {
        adapter = FilterAdapter(this, filterNewList, clickListener = {
            selectPos = it
            applyNewFilter(filterNewList[it])
//            if (selectPos == 0) {
//                filterBitmap = sourceImgBitmap
//                binding.imageDisplay.setImageBitmap(sourceImgBitmap)
//            } else
//                applyFilter(filterList[selectPos].filter)
        })
        binding.recyclerView.adapter = adapter

    }

    private fun applyNewFilter(filterItem: FilterItem) {
        val progressDialog = ProgressDialog(
            this@FilterActivity,
            0,
            0,
            getString(R.string.applying),
            ""
        )

        progressDialog.show()
//        progressDialog.isCancelable = false
//        Thread {
        try {
            val newBitmap = Bitmap.createBitmap(sourceImgBitmap!!)
            filterBitmap = filterItem.filter.processFilter(newBitmap)
            runOnUiThread {
                if (filterBitmap != null)
                    binding.imageDisplay.setImageBitmap(filterBitmap)
                if(!isFinishing && !isDestroyed) {
                    if (progressDialog.isShowing)
                        progressDialog.dismiss()
                }
            }
        } catch (e: Exception) {
            Log.e("printStackTrace","printStackTrace:$e")
            runOnUiThread {
                if(!isFinishing && !isDestroyed) {
                    if (progressDialog.isShowing)
                        progressDialog.dismiss()
                }
            }
        }

//        }.start()
    }

}