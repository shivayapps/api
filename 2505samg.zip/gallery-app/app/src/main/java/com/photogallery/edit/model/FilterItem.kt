package com.photogallery.edit.model

import android.graphics.Bitmap
import com.photofilters.imageprocessors.Filter

data class FilterItem(var bitmap: Bitmap, val filter: Filter)
