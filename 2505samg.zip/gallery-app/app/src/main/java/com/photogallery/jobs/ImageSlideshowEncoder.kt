package com.photogallery.jobs

import android.graphics.*
import android.media.*
import android.os.Build
import androidx.annotation.RequiresApi
import java.io.File
import android.view.Surface
import java.nio.ByteBuffer

class ImageSlideshowEncoder(
    private val width: Int = 720,
    private val height: Int = 1280,
    private val bitRate: Int = 2_000_000,
    private val frameRate: Int = 30,
    private val iFrameInterval: Int = 1
) {

    interface EncodeListener {
        fun onStart(totalFrames: Int)
        fun onProgress(current: Int, total: Int)
        fun onCompleted(outputPath: String)
        fun onError(e: Exception)
    }

    fun createVideo(
        imagePaths: List<String>,
        outputFile: String,
        secondsPerImage: Int = 2,
        listener: EncodeListener? = null
    ) {
        try {
            val mediaCodec = MediaCodec.createEncoderByType("video/avc")

            val format = MediaFormat.createVideoFormat("video/avc", width, height).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, bitRate)
                setInteger(MediaFormat.KEY_FRAME_RATE, frameRate)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, iFrameInterval)
            }

            mediaCodec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val surface = mediaCodec.createInputSurface()
            mediaCodec.start()

            val muxer = MediaMuxer(outputFile, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            val bufferInfo = MediaCodec.BufferInfo()
            val muxerState = MuxerState()

            val totalFramesPerImage = frameRate * secondsPerImage
            val totalFrames = totalFramesPerImage * imagePaths.size

            listener?.onStart(totalFrames)

            var currentFrame = 0

            // ⏱️ Frame pacing time
            val frameTimeMs = 1000L / frameRate

            for (path in imagePaths) {
                val bitmap = BitmapFactory.decodeFile(path) ?: continue

                // ✅ create blur ONLY ONCE per image
                val bgBitmap = createBlurBackground(bitmap)

                repeat(totalFramesPerImage) {

                    val frameStart = System.currentTimeMillis()

                    val canvas = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        surface.lockHardwareCanvas()
                    } else {
                        surface.lockCanvas(null)
                    }

                    // Draw background
                    val bgRect = Rect(0, 0, width, height)
                    canvas.drawBitmap(bgBitmap, null, bgRect, null)

                    // Draw foreground
                    val fgRect = getFitCenterRect(bitmap, width, height)
                    canvas.drawBitmap(bitmap, null, fgRect, null)

                    surface.unlockCanvasAndPost(canvas)

                    drainEncoder(mediaCodec, muxer, bufferInfo, muxerState)

                    currentFrame++
                    listener?.onProgress(currentFrame, totalFrames)

                    // ⏱️ Maintain consistent frame rate
                    val elapsed = System.currentTimeMillis() - frameStart
                    val sleep = frameTimeMs - elapsed
                    if (sleep > 0) Thread.sleep(sleep)
                }

                bitmap.recycle()
                bgBitmap.recycle()
            }

            mediaCodec.signalEndOfInputStream()
            drainEncoder(mediaCodec, muxer, bufferInfo, muxerState, true)

            mediaCodec.stop()
            mediaCodec.release()

            muxer.stop()
            muxer.release()

            listener?.onCompleted(outputFile)

        } catch (e: Exception) {
            listener?.onError(e)
        }
    }


    private fun drainEncoder(
        codec: MediaCodec,
        muxer: MediaMuxer,
        bufferInfo: MediaCodec.BufferInfo,
        muxerState: MuxerState,
        endOfStream: Boolean = false
    ) {
        while (true) {
            val outputBufferId = codec.dequeueOutputBuffer(bufferInfo, 10_000)

            when {
                outputBufferId == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (!endOfStream) return
                }

                outputBufferId == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    if (muxerState.started) {
                        throw IllegalStateException("Format changed twice")
                    }

                    val newFormat = codec.outputFormat
                    muxerState.trackIndex = muxer.addTrack(newFormat)
                    muxer.start()
                    muxerState.started = true
                }

                outputBufferId >= 0 -> {
                    val encodedData = codec.getOutputBuffer(outputBufferId)
                        ?: throw RuntimeException("Encoder output buffer null")

                    if (bufferInfo.size > 0) {
                        if (!muxerState.started) {
                            // 🔥 THIS prevents your crash
                            throw IllegalStateException("Muxer not started")
                        }

                        encodedData.position(bufferInfo.offset)
                        encodedData.limit(bufferInfo.offset + bufferInfo.size)

                        muxer.writeSampleData(
                            muxerState.trackIndex,
                            encodedData,
                            bufferInfo
                        )
                    }

                    codec.releaseOutputBuffer(outputBufferId, false)

                    if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                        return
                    }
                }
            }
        }
    }

    private fun createBlurBackground(src: Bitmap): Bitmap {
        // scale up to fill screen (crop)
        val scale = maxOf(
            width.toFloat() / src.width,
            height.toFloat() / src.height
        )

        val matrix = Matrix().apply {
            postScale(scale, scale)
        }

        val scaled = Bitmap.createBitmap(
            src, 0, 0, src.width, src.height, matrix, true
        )

        // apply simple blur (fast fallback)
        return fastBlur(scaled, 25)
    }
    private fun fastBlur(sentBitmap: Bitmap, radius: Int): Bitmap {
        val bitmap = sentBitmap.config?.let { sentBitmap.copy(it, true) }

        val w = bitmap?.width?:0
        val h = bitmap?.height?:0

        val pixels = IntArray(w * h)
        bitmap?.getPixels(pixels, 0, w, 0, 0, w, h)

        for (i in pixels.indices) {
            val c = pixels[i]
            val r = (c shr 16 and 0xFF) / 2
            val g = (c shr 8 and 0xFF) / 2
            val b = (c and 0xFF) / 2
            pixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }

        bitmap?.setPixels(pixels, 0, w, 0, 0, w, h)
        return bitmap!!
    }
    private fun getFitCenterRect(bitmap: Bitmap, width: Int, height: Int): Rect {
        val scale = minOf(
            width.toFloat() / bitmap.width,
            height.toFloat() / bitmap.height
        )

        val scaledWidth = bitmap.width * scale
        val scaledHeight = bitmap.height * scale

        val left = (width - scaledWidth) / 2
        val top = (height - scaledHeight) / 2

        return Rect(
            left.toInt(),
            top.toInt(),
            (left + scaledWidth).toInt(),
            (top + scaledHeight).toInt()
        )
    }
}