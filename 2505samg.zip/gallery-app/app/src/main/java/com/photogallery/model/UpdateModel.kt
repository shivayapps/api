package com.photogallery.model


data class UpdateModel(
    val isNeedToShow: Boolean = false,
    val isCancelable: Boolean = false,
    val latestVersion: String = "",
    val mainTitle: String = "",
    val subTitle: String = "",
    val displayFromVersion: Int = 0,
    val redirectUrl: String = "",
    val btnText: String = "",
)

