package com.photogallery.customview

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Path
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import androidx.annotation.ColorInt
import androidx.appcompat.widget.AppCompatImageView

class RoundedBorderImageView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : AppCompatImageView(context, attrs, defStyleAttr) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private val rect = RectF()
    private val borderRect = RectF()

    var cornerRadius = 25f
    var borderWidth = 3f
    var mBorderColor = Color.parseColor("#FFA500") // Orange
    var innerPadding = 5f

    init {
        scaleType = ScaleType.CENTER_CROP

        borderPaint.style = Paint.Style.STROKE
        borderPaint.strokeWidth = borderWidth
        borderPaint.color = mBorderColor
    }

    fun setBorderColor(@ColorInt color: Int) {
        mBorderColor = color
        borderPaint.color = color
        invalidate() // redraw view
    }

    override fun onDraw(canvas: Canvas) {
        val save = canvas.save()

        // Outer border rect
        borderRect.set(
            borderWidth / 2,
            borderWidth / 2,
            width - borderWidth / 2,
            height - borderWidth / 2
        )

        // Inner image rect (with padding)
        rect.set(
            borderWidth + innerPadding,
            borderWidth + innerPadding,
            width - borderWidth - innerPadding,
            height - borderWidth - innerPadding
        )

        // Draw border
        canvas.drawRoundRect(borderRect, cornerRadius, cornerRadius, borderPaint)

        // Clip for image
        val path = Path().apply {
            addRoundRect(rect, cornerRadius, cornerRadius, Path.Direction.CW)
        }

        canvas.clipPath(path)

        super.onDraw(canvas)

        canvas.restoreToCount(save)
    }
}