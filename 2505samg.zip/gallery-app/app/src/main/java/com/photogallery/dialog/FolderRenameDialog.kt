package com.photogallery.dialog

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Point
import android.graphics.drawable.ColorDrawable
import android.media.MediaScannerConnection
import android.media.MediaScannerConnection.OnScanCompletedListener
import android.net.Uri
import android.os.Bundle
import android.text.InputFilter
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import androidx.core.content.FileProvider
import androidx.core.widget.addTextChangedListener
import com.photogallery.R
import com.photogallery.databinding.DialogRenameBinding
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.extension.rescanPath
import com.photogallery.extension.scanPathRecursively
import com.photogallery.extension.toast
import com.photogallery.extension.updateInMediaStore
import com.photogallery.model.AlbumData
import com.photogallery.utils.DIALOG_DIM_AMOUNT
import com.photogallery.utils.Preferences
import com.photogallery.utils.Utils
import com.photogallery.utils.sendEvent
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class FolderRenameDialog(
    var mContext: Activity,
    var albumData: AlbumData,
    val positiveBtnClickListener: (renamePath: String, oldPath: String) -> Unit,
) : Dialog(mContext) {

    lateinit var bindingDialog: DialogRenameBinding
    var preferences: Preferences = Preferences(mContext)
    var oldName = ""
//    var type = ""


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        window?.setDimAmount(DIALOG_DIM_AMOUNT)
        window?.attributes?.windowAnimations = android.R.style.Animation_Dialog

        bindingDialog = DialogRenameBinding.inflate(layoutInflater)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
        intListener()
    }


    private fun intView() {
        oldName = albumData.title
        Log.e("", "oldName $oldName")
        bindingDialog.edtName.setText(oldName)
        bindingDialog.edtName.requestFocus()
        bindingDialog.tvCount.text =
            "${bindingDialog.edtName.text?.length ?: 0}/150"

    }

    var isRenameClicked = false
    private fun intListener() {
        bindingDialog.edtName.filters = arrayOf(
            InputFilter.LengthFilter(150),
            InputFilter { source, _, _, _, _, _ ->
                val blocked = Regex("[\\\\/:*?\"<>|]")
                if (blocked.containsMatchIn(source)) "" else null
            }
        )
        bindingDialog.edtName.addTextChangedListener {
            val text = bindingDialog.edtName.text?.trim().toString()

            bindingDialog.icClear.visibility =
                if (text.isNotEmpty()) View.VISIBLE else View.GONE

            bindingDialog.tvCount.text = "${text.length}/150"
        }

        bindingDialog.icClear.setOnClickListener {
            bindingDialog.edtName.setText("")
        }
        bindingDialog.btnCancel.setOnClickListener { dismiss() }

        bindingDialog.btnRename.setOnClickListener {
            if (!isRenameClicked) {
                mContext.runOnUiThread {
                    bindingDialog.llProgress.beVisible()
                }
                isRenameClicked = true
                val strNewFileName = bindingDialog.edtName.text.toString().trim()
                if (strNewFileName.isNotEmpty()) {
                    val renameFile = File(albumData.folderPath.replace(oldName, strNewFileName))
                    if (!renameFile.exists() || oldName == strNewFileName) {
                        if (oldName != strNewFileName) {
                            val oldFileCount = File(albumData.folderPath).listFiles()?.count() ?: 0
                            Log.e("TAG", "renameEvent: pictureData.folderPath ${albumData.folderPath}")

                            renameFile(strNewFileName) { renamePath ->
                                if (renamePath.isNotEmpty()) {
                                    setRename(oldFileCount, albumData.folderPath, renamePath)
                                    mContext.toast(mContext.getString(R.string.rename_successfully))
                                    bindingDialog.llProgress.beGone()
                                    isRenameClicked = false
                                    positiveBtnClickListener.invoke(renamePath, albumData.folderPath)
                                    dismiss()
                                } else {
                                    bindingDialog.llProgress.beGone()
                                    isRenameClicked = false
                                    mContext.toast(mContext.getString(R.string.failed))
                                    dismiss()
                                }
                            }

                        } else {
                            dismiss()
                            bindingDialog.llProgress.beGone()
                            isRenameClicked = false
                        }
                    } else {
                        bindingDialog.llProgress.beGone()
                        isRenameClicked = false
                        mContext.toast(mContext.getString(R.string.rename_validation2))
                    }
                } else {
                    bindingDialog.llProgress.beGone()
                    isRenameClicked = false
                    mContext.toast(mContext.getString(R.string.rename_validation))
                }
            }
        }
    }

    private fun getViewValue(view: EditText): Int {
        val textValue = view.text.toString().trim()
        return if (textValue.isEmpty()) 0 else textValue.toInt()
    }

    private fun setRename(oldFileCount: Int, oldPath: String, renamePath: String) {
        sendEvent("rename", oldPath)
        sendEvent("rename", renamePath)
        val list = preferences.getFavoriteList()
        if (list.contains(oldPath)) {
            list.remove(oldPath)
            list.add(0, renamePath)
            preferences.setFavoriteList(list)
        }
    }

    private fun renameFile(strNewFileName: String, callback: (String) -> Unit) {

        var renamed = false
        val renameFilePath: String = File(albumData.folderPath).parent.toString() + File.separator + strNewFileName
        val oldFile: File = File(albumData.folderPath)
        val renameFile = File(renameFilePath)
        val oldPath = albumData.folderPath
        renamed = oldFile.renameTo(renameFile)
        mContext.updateInMediaStore(oldPath, renameFilePath){
            mContext.rescanPath(renameFilePath) {
                if (!oldPath.equals(renameFilePath, true)) {
                    Utils.deleteFromMediaStore(mContext, oldPath)
                }
                mContext.scanPathRecursively(renameFilePath)
            }

            MediaScannerConnection.scanFile(context, arrayOf<String>(renameFile.path), null,
                OnScanCompletedListener { path: String?, uri: Uri? -> })

            MediaScannerConnection.scanFile(context, arrayOf<String>(albumData.folderPath), null,
                OnScanCompletedListener { path: String?, uri: Uri? -> })

            if (renamed) {
                callback.invoke(renameFilePath)
            } else {
                callback.invoke("")
            }
        }

    }


    fun String.getFilenameExtension() = substring(lastIndexOf(".") + 1)

}
