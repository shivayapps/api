package com.photogallery.activities

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.RecyclerView

import com.photogallery.R
import com.photogallery.adapter.AlbumListAdapter
import com.photogallery.base.BaseActivity
import com.photogallery.customview.MyGridLayoutManager
import com.photogallery.database.AppDatabase
import com.photogallery.databinding.ActivityMomentCategoriesBinding
import com.photogallery.dialog.DisplayedColumnsDialog
import com.photogallery.dialog.FilterMediaDialog
import com.photogallery.dialog.GroupDialog
import com.photogallery.dialog.MainMenuDialog
import com.photogallery.dialog.SortingOptionsDialog
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible

import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData

import com.photogallery.utils.Constant
import com.photogallery.utils.FastScroller
import com.photogallery.utils.Preferences
import com.photogallery.utils.sendEvent
import org.greenrobot.eventbus.EventBus

class MomentCategoriesActivity : BaseActivity() {


    var allList = ArrayList<Any>()

    var albumList: ArrayList<AlbumData> = ArrayList()

    var albumAdapter: AlbumListAdapter? = null
    lateinit var preferences: Preferences

    private val dataBase: AppDatabase by lazy { AppDatabase.getInstance(this) }

    lateinit var activity: Activity
    private lateinit var binding: ActivityMomentCategoriesBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityMomentCategoriesBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        preferences = Preferences(this)
        //loadBanner()
        activity = this@MomentCategoriesActivity

        getData()
        initView()

    }

    fun getData() {
//        dataBase = NewDatabase.getInstance(this)
        val categoriesList = dataBase.categoriesDao().getMediaByCategoryFetchStatus()
        Log.e("CategoriesList", "categoriesList:${categoriesList.size}")
        Log.e("CategoriesList", "categoriesList:${categoriesList}")
        val groupedData = categoriesList.groupBy {
            it.categories.firstOrNull() ?: "Unknown"
        }

        groupedData.forEach { (categoryName, categoryItems) ->
            val mediaList = ArrayList<MediaData>()
            categoryItems.forEach { category ->
                mediaList.add(
                    MediaData(
                        filePath = category.path,
                        fileUri = category.path,
//                        fileUri = getUriFromPath(category.path).toString(),
                        fileName = category.path.substringAfterLast("/"),
                        folderName = category.path.substringBeforeLast("/"),
                        date = 0L,
                        dateTaken = 0L,
                        fileSize = 0L,
                        isVideo = false
                    )
                )
            }

            albumList.add(
                AlbumData(
                    title = categoryName,
                    mediaData = mediaList,
                    folderPath = "",
                    date = 0L,
                    fileSize = mediaList.sumOf { it.fileSize },
                    isCustomAlbum = true
                )
            )
        }

        albumAdapter?.submitList(albumList)
    }

    private fun disableScroll() {
        binding.albumRecycler.suppressLayout(true)
    }

    private fun enableScroll() {
        binding.albumRecycler.suppressLayout(false)
    }


    private fun initView() {
        if (intent.hasExtra("title")) {
            binding.txtTitle.text = intent.getStringExtra("title")
        }

        intListener()
        initAdapter()
    }

    private fun initAdapter() {
        setRvLayoutManager()

        albumAdapter = AlbumListAdapter(
            activity,
            clickListener = {
                val albumData = albumList[it]
                openImageList(albumData)
            },
            longClickListener = {
            })

        albumAdapter?.submitList(albumList)
        binding.albumRecycler.adapter = albumAdapter


        binding.albumRecycler.post {
            FastScroller(binding.handleView).bind(binding.albumRecycler)
        }
    }

    fun openImageList(albumData: AlbumData) {

        Constant.albumData = AlbumData(
            albumData.title,
            albumData.mediaData,
            albumData.folderPath,
            albumData.date,
            albumData.fileSize
        )

        val intent = Intent(activity, ImageGalleryActivity::class.java)
        if (albumData.lati > 0 && albumData.long > 0) {
            intent.putExtra("isFromMap", true)
            intent.putExtra("lati", albumData.lati)
            intent.putExtra("long", albumData.long)
        }
        startActivity(intent)
//        setBackAlbumData()
    }

    fun setBackAlbumData() {
        Constant.albumList.clear()
        for (albumData in albumList) {
            Constant.albumList.add(
                AlbumData(
                    albumData.title,
                    albumData.mediaData,
                    albumData.folderPath,
                    albumData.date,
                    albumData.fileSize
                )
            )
        }
    }

    fun setRvLayoutManager() {
        val gridCount = preferences.getAlbumGridCount()
        val isGridShow = preferences.getShowGrid()
        if (isGridShow) {
            val layoutManager = binding.albumRecycler.layoutManager as MyGridLayoutManager
            layoutManager.orientation = RecyclerView.VERTICAL
            layoutManager.spanCount = gridCount
//            layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
//                override fun getSpanSize(position: Int): Int {
//                    if (position >= 0 && position < albumList.size) {
////                        if (albumAdapter!!.getItemViewType(position) === albumAdapter!!.ITEM_ALBUM_HEADER_TYPE) {
//                        return gridCount
////                        } else return  1
//                    } else {
//                        return 1
//                    }
//                }
//            }
        } else {
            val layoutManager = binding.albumRecycler.layoutManager as MyGridLayoutManager
            layoutManager.spanCount = 1
            layoutManager.orientation = RecyclerView.VERTICAL
//            mZoomListener = null
        }
    }

    private fun setEmptyData() {
        if (albumList != null && albumList.size != 0) {
            binding.albumRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
            binding.llAdPlace.beVisible()
        } else {
            binding.albumRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
            binding.llAdPlace.beGone()
        }
    }

    private fun intListener() {

        binding.icBack.setOnClickListener {
            onBackPressed()
        }

        binding.icMenu.setOnClickListener {
            showMenu()
        }

    }

    private fun showMenu() {

        val dialog = MainMenuDialog(this, 1, clickListener = {
            when (it) {
                1 -> {//btnSortBy
                    showSortDialog()
                }

                2 -> {//btnGroup
                    showGroupByDialog()
                }

//                3 -> {//btnFilterMedia
//                    val filterMediaDialog =
//                        FilterMediaDialog(this@MomentCategoriesActivity, updateListener = {
//                            //getData()
//                        })
//                    filterMediaDialog.show()
//                }

                4 -> {
                    // displayed Columns
                    val displayColumnsDialog = DisplayedColumnsDialog(
                        this, folderPath = "pref_0",
                        true,
                        updateListener = {
                            setRvLayoutManager()
                            sendEvent("refresh_layoutmanager")
                        })
                    displayColumnsDialog.show()
                }

                21 -> {
                    setRvLayoutManager()
                    sendEvent("refresh_layoutmanager")
                }

                22 -> {
                    setRvLayoutManager()
                    setListGridData()
                    sendEvent("refresh_layoutmanager")
                }

                5 -> {
                    recycleLauncher.launch(Intent(this, RecentlyDeleteActivity::class.java))
                }

                6 -> {
                    settingLauncher.launch(Intent(this, SettingActivity::class.java))
                }
            }
        })
        dialog.show()
    }

    private fun showSortDialog() {
        val sortDialog = SortingOptionsDialog(this, folderPath = "pref_0", updateListener = {
            //getData()
        })
        sortDialog.show()
    }

    private fun showGroupByDialog() {
        val groupDialog = GroupDialog(this, folderPath = "pref_0", updateListener = {
            //getData()
        })
        groupDialog.show()
    }

    fun setListGridData() {
        setRvLayoutManager()
        if (albumAdapter != null) {
//            albumAdapter!!.notifyDataSetChanged()
            albumAdapter?.notifyItemRangeChanged(0, albumList.size)
        }
    }

    var recycleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->

        }


    override fun onDestroy() {
        super.onDestroy()
//        EventBus.getDefault().unregister(this)
    }


    override fun onBackPressed() {
        if (binding.groupToolbarSelectHeader.visibility == View.VISIBLE) {
//            setCloseToolbar()
        } else {
            super.onBackPressed()
        }
    }


}