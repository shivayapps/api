package com.photogallery.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.media.MediaMuxer;
import android.media.MediaScannerConnection;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Surface;

//import com.arthenica.ffmpegkit.FFmpegKit;
//import com.arthenica.ffmpegkit.ReturnCode;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

public class Mp4Maker {

    private static final String MIME_TYPE = "video/avc"; // H.264
    private static final int FRAME_RATE = 10; // fps
    private static final int IFRAME_INTERVAL = 1;
    private static final int BIT_RATE = 2_000_000;

//    public interface OnMp4Listener {
//        void onStart(int totalFrames);
//
//        void onProgress(int current, int total);
//
//        void onCompleted(String outputPath);
//
//        void onError(Exception e);
//    }
//
//    private Handler mainHandler = new Handler(Looper.getMainLooper());
//
//    private void post(Runnable r) {
//        mainHandler.post(r);
//    }
//
//
//    public void makeMp4FromPath(
//            Context context,
//            List<String> pathList,
//            String outputPath,
//            int durationSec,
//            OnMp4Listener listener
//    ) {
//
//        if (pathList == null || pathList.isEmpty()) {
//            if (listener != null) {
//                post(() -> listener.onError(new Exception("Empty image list")));
//            }
//            return;
//        }
//
//        post(() -> {
//            if (listener != null) listener.onStart(pathList.size());
//        });
//
//        new Thread(() -> {
//            try {
//                // ✅ Step 1: Create concat file
//                File listFile = new File(context.getCacheDir(), "ffmpeg_list.txt");
//                FileOutputStream fos = new FileOutputStream(listFile);
//
//                StringBuilder builder = new StringBuilder();
//
//                for (int i = 0; i < pathList.size(); i++) {
//                    String path = pathList.get(i);
//
//                    builder.append("file '")
//                            .append(path.replace("'", "'\\''"))
//                            .append("'\n");
//
//                    // duration for each image
//                    builder.append("duration ").append(durationSec).append("\n");
//
//                    final int progress = i + 1;
//                    post(() -> {
//                        if (listener != null) {
//                            listener.onProgress(progress, pathList.size());
//                        }
//                    });
//                }
//
//                // FFmpeg requirement: repeat last file without duration
//                builder.append("file '")
//                        .append(pathList.get(pathList.size() - 1).replace("'", "'\\''"))
//                        .append("'\n");
//
//                fos.write(builder.toString().getBytes());
//                fos.close();
//
//                String cmd1 = "-y -f concat -safe 0 -i \"" + listFile.getAbsolutePath() + "\" " +
//                        "-vf \"scale=1280:720,format=yuv420p\" " +
//                        "-r 30 -c:v mpeg4 -q:v 5 \"" + outputPath + "\"";
//
//                String cmd = "-y -f concat -safe 0 -i \"" + listFile.getAbsolutePath() + "\" " +
//                        "-vf \"scale=1280:720:force_original_aspect_ratio=decrease," +
//                        "pad=1280:720:(ow-iw)/2:(oh-ih)/2:color=black,format=yuv420p\" " +
//                        "-r 30 -c:v mpeg4 -q:v 5 \"" + outputPath + "\"";
//
//                Log.e("Mp4Maker","FFMPEG_CMD:"+ cmd);
//
//                // ✅ Step 3: Execute
//                FFmpegKit.executeAsync(cmd, session -> {
//
//
//                    String logs = session.getAllLogsAsString();
//                    String fail = session.getFailStackTrace();
//
//
//                    Log.e("Mp4Maker","FFMPEG_FULL_LOG:"+ logs);
//                    Log.e("Mp4Maker","FFMPEG_FAIL:"+ String.valueOf(fail));
//                    Log.e("Mp4Maker","FFMPEG_RC:"+ String.valueOf(session.getReturnCode()));
//
//                    if (ReturnCode.isSuccess(session.getReturnCode())) {
//
//                        // Scan so it appears in gallery
//                        MediaScannerConnection.scanFile(
//                                context,
//                                new String[]{outputPath},
//                                new String[]{"video/mp4"},
//                                null
//                        );
//
//                        post(() -> {
//                            if (listener != null) listener.onCompleted(outputPath);
//                        });
//
//                    } else {
//                        post(() -> {
//                            if (listener != null) {
//                                listener.onError(new Exception(
//                                        "RC=" + session.getReturnCode() +
//                                                "\nFAIL=" + fail +
//                                                "\nLOGS=\n" + logs
//                                ));
//                            }
//                        });
//                    }
//                });
//
//            } catch (Exception e) {
//                e.printStackTrace();
//                post(() -> {
//                    if (listener != null) listener.onError(e);
//                });
//            }
//        }).start();
//    }
//
//
//
//    private Bitmap decodeFrame(Context context, String path) {
//        try {
//            if (path.endsWith(".mp4") || path.endsWith(".mkv") || path.endsWith(".avi")) {
//
//                MediaMetadataRetriever retriever = new MediaMetadataRetriever();
//                retriever.setDataSource(path);
//
//                // Get frame at 1 second
//                Bitmap bmp = retriever.getFrameAtTime(
//                        1_000_000, // microseconds
//                        MediaMetadataRetriever.OPTION_CLOSEST
//                );
//
//                retriever.release();
//                return bmp;
//
//            } else {
//                return BitmapFactory.decodeFile(path);
//            }
//
//        } catch (Exception e) {
//            e.printStackTrace();
//            return null;
//        }
//    }
//
//    public boolean makeVideo(List<Bitmap> bitmaps, String outputPath) {
//        try {
//            int width = bitmaps.get(0).getWidth();
//            int height = bitmaps.get(0).getHeight();
//
//            MediaCodec encoder = MediaCodec.createEncoderByType(MIME_TYPE);
//
//            MediaFormat format = MediaFormat.createVideoFormat(MIME_TYPE, width, height);
//            format.setInteger(MediaFormat.KEY_COLOR_FORMAT,
//                    MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
//            format.setInteger(MediaFormat.KEY_BIT_RATE, BIT_RATE);
//            format.setInteger(MediaFormat.KEY_FRAME_RATE, FRAME_RATE);
//            format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, IFRAME_INTERVAL);
//
//            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
//            Surface inputSurface = encoder.createInputSurface();
//            encoder.start();
//
//            MediaMuxer muxer = new MediaMuxer(outputPath,
//                    MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
//
//            InputSurface surface = new InputSurface(inputSurface);
//            surface.makeCurrent();
//
//            int trackIndex = -1;
//            boolean muxerStarted = false;
//
//            for (int i = 0; i < bitmaps.size(); i++) {
//                Bitmap bmp = bitmaps.get(i);
//
//                surface.drawBitmap(bmp);
//                surface.setPresentationTime(computePresentationTime(i));
//                surface.swapBuffers();
//            }
//
//            encoder.signalEndOfInputStream();
//
//            MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
//
//            while (true) {
//                int outputIndex = encoder.dequeueOutputBuffer(bufferInfo, 10000);
//
//                if (outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
//                    MediaFormat newFormat = encoder.getOutputFormat();
//                    trackIndex = muxer.addTrack(newFormat);
//                    muxer.start();
//                    muxerStarted = true;
//                } else if (outputIndex >= 0) {
//                    ByteBuffer encodedData = encoder.getOutputBuffer(outputIndex);
//
//                    if (bufferInfo.size != 0 && muxerStarted) {
//                        encodedData.position(bufferInfo.offset);
//                        encodedData.limit(bufferInfo.offset + bufferInfo.size);
//                        muxer.writeSampleData(trackIndex, encodedData, bufferInfo);
//                    }
//
//                    encoder.releaseOutputBuffer(outputIndex, false);
//
//                    if ((bufferInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
//                        break;
//                    }
//                }
//            }
//
//            encoder.stop();
//            encoder.release();
//            muxer.stop();
//            muxer.release();
//
//            return true;
//
//        } catch (Exception e) {
//            e.printStackTrace();
//            return false;
//        }
//    }
//
//    private long computePresentationTime(int frameIndex) {
//        return 132 + frameIndex * 1_000_000 / FRAME_RATE;
//    }
}