package com.photogallery.edit.model

enum class FilterName {
    BRIGHTNESS,
    CONTRAST,
    SATURATION,
    SHARPEN,
    VIGNETTE
}