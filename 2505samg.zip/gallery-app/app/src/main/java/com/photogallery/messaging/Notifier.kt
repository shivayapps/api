package com.photogallery.messaging

import android.app.Notification.VISIBILITY_PUBLIC
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Build
import android.provider.MediaStore
import android.service.notification.StatusBarNotification
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.bumptech.glide.Glide
import com.photogallery.R
import com.photogallery.SplashActivity
import com.photogallery.extension.realScreenSize
import com.photogallery.utils.Preferences
import java.util.Calendar
import java.util.concurrent.TimeUnit

object Notifier {
    private const val CHANNEL_ID = "gallery_engagement"
    private const val NOTIFICATION_ID = 1001



    fun showNotification(
        context: Context,
        title: String,
        body: String,
        actionId: Long?,
        image: Int,
    ) {
        val bitmap = try {
            BitmapFactory.decodeResource(context.resources, image)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }

        var intent = if (actionId != null) {
//            isFromNotification = true
//            isNeedNotificationInterAd = true
            Intent(context, SplashActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .setAction("FINISH_AFFINITY").putExtra("actionId", actionId)
        } else {
            Intent(context, SplashActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .setAction("FINISH_AFFINITY").putExtra("screen", "memoryTab")
        }

//        if (isAppInBackground(context)) {
//            Log.e(TAG, "AppInBackground")
//            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
//            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
//            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
//        }

        intent.putExtra("isFromNotification", true)
        val pendingIntent = PendingIntent.getActivity(
            context, 1, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notificationBuilder =
            NotificationCompat.Builder(context, "StoryNotification").setContentTitle(title)
                .setContentText(body).setSmallIcon(R.drawable.ic_notification_logo)
                .setPriority(NotificationCompat.PRIORITY_HIGH).setContentIntent(pendingIntent)
                .setDefaults(NotificationCompat.DEFAULT_ALL).setAutoCancel(true)
                .setOnlyAlertOnce(true)
//        if (bitmap != null) {
//            val style = NotificationCompat.BigPictureStyle().bigPicture(bitmap)
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
//                style.showBigPictureWhenCollapsed(true)
//            }
//            notificationBuilder.setStyle(style)
//        }
        if (bitmap != null) {
            val style = NotificationCompat.BigPictureStyle()
                .bigPicture(bitmap)
                .bigLargeIcon(null as Bitmap?)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                style.showBigPictureWhenCollapsed(true)
            }

            notificationBuilder.setStyle(style)
        }
        notificationBuilder.setVibrate(LongArray(0))

        notificationBuilder.setChannelId("StoryNotification")
        val mChannel = NotificationChannel(
            "StoryNotification", "StoryNotification", NotificationManager.IMPORTANCE_HIGH
        )
        mChannel.description = "Notifications are info related."
        mChannel.lockscreenVisibility = VISIBILITY_PUBLIC
        mChannel.enableLights(true)
        mChannel.lightColor = Color.RED
        mChannel.enableVibration(true)
        mChannel.setShowBadge(true)
        mChannel.vibrationPattern = longArrayOf(100, 200, 300, 400, 500, 400, 300, 200, 400)
        notificationBuilder.setBadgeIconType(NotificationCompat.BADGE_ICON_SMALL)
        notificationManager.createNotificationChannel(mChannel)
        cancelFCMDefaultNotification(context)
        notificationManager.notify(actionId.hashCode(), notificationBuilder.build())
    }

    private fun cancelFCMDefaultNotification(context: Context) {
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notifications: Array<StatusBarNotification> = notificationManager.activeNotifications

        Log.e("StoryNotification", "notifications Size: " + notifications.size)
        notifications.forEach {
            Log.e(
                "StoryNotification",
                "data : ${it.id} -- ${it.key} -- ${it.tag} -- ${it.notification.extras} -- ${it.notification.extras["title"]}" + " channelid --> " + it.notification.channelId
            )
            if ((it.tag != null && it.tag.contains(
                    "fcm", ignoreCase = true
                )) || it.notification.channelId.equals(
                    "silentFirebase", ignoreCase = true
                ) || it.notification.channelId.equals(
                    "fcm_fallback_notification_channel", ignoreCase = true
                ) || it.notification.channelId.equals(
                    "fcm_notification", ignoreCase = true
                )
            ) {
                notificationManager.cancel(it.tag, it.id)
            }
        }


    }

    fun show(context: Context, title: String, msg: String) {

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Create channel (Android O+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Engagement",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            manager.createNotificationChannel(channel)
        }

        // Cancel previous notification (ensures only one visible)
        manager.cancel(NOTIFICATION_ID)

        val intent = Intent(context, SplashActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(msg)
            .setSmallIcon(R.drawable.ic_notification_logo)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        // Show notification (replaces previous)
        manager.notify(NOTIFICATION_ID, notification)

        Preferences(context).setLastNotificationTime(context)
    }

    fun scheduleRandomWorker(context: Context) {
//        val type = when {
//            isUserInactive(context) -> "INACTIVE"
//            hasRecentPhotos(context) -> "CREATION"
//            else -> "MEMORY"
//        }

        val (title, body,image) = Notifier.getRandomMessage()

        Notifier.showNotification(
            context,
            title,
            body,
            0,
            image
        )
    }
    fun scheduleDailyWorker15Min(context: Context) {
        val workRequest = PeriodicWorkRequestBuilder<NotificationWorker>(
            15, TimeUnit.MINUTES // minimum allowed by WorkManager
        ).build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "notification_work",
            ExistingPeriodicWorkPolicy.UPDATE,
            workRequest
        )

    }

    fun scheduleDailyWorker(context: Context) {
        scheduleWorker(
            context = context,
            uniqueName = "gallery_engagement_morning",
            hour = 7,
            minute = 30
        )

        scheduleWorker(
            context = context,
            uniqueName = "gallery_engagement_evening",
            hour = 19,
            minute = 30
        )
    }

    private fun scheduleWorker(
        context: Context,
        uniqueName: String,
        hour: Int,
        minute: Int
    ) {
        val now = Calendar.getInstance()

        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)

            if (before(now)) {
                add(Calendar.DAY_OF_MONTH, 1)
            }
        }

        val delay = target.timeInMillis - now.timeInMillis

        val request = PeriodicWorkRequestBuilder<EngagementWorker>(
            1,
            TimeUnit.DAYS
        )
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            uniqueName,
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    fun isUserInactive(context: Context): Boolean {
        val lastOpen = Preferences(context).lastAppOpen(context)
        val hours = (System.currentTimeMillis() - lastOpen) / (1000 * 60 * 60)
        return hours > 48
    }
    fun hasRecentPhotos(context: Context): Boolean {

        val uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Images.Media.DATE_ADDED)

        val cutoff = (System.currentTimeMillis() / 1000) - (48 * 60 * 60)

        val selection = "${MediaStore.Images.Media.DATE_ADDED} > ?"
        val selectionArgs = arrayOf(cutoff.toString())

        context.contentResolver.query(
            uri,
            projection,
            selection,
            selectionArgs,
            null
        )?.use {
            return it.count > 15
        }

        return false
    }

    private val notificationMessages = listOf(
        Triple(
            "Clean Your Device Instantly",
            "Remove junk files and free space.",
            R.drawable.noti_1
        ),
        Triple(
            "Transform Photos with Stunning Filters",
            "Apply beautiful tones to every picture.",
            R.drawable.noti_2
        ),
        Triple(
            "Turn Photos into Amazing Collages",
            "Arrange pictures with modern collage templates.",
            R.drawable.noti_3
        ),
        Triple(
            "AI Background Editor for Photos",
            "Transform pictures with creative background effects",
            R.drawable.noti_4
        ),
        Triple(
            "Free Up Storage With Smart Cleanup",
            "Clear duplicate files and save space",
            R.drawable.noti_5
        ),
        Triple(
            "Future Baby Predictor For Couples",
            "See realistic baby face results instantly",
            R.drawable.noti_6
        ),
        Triple(
            "AI Future Baby Face Generator",
            "Create cute baby predictions from photos",
            R.drawable.noti_7
        ),
        Triple(
            "AI Object Remover for Photos",
            "Erase unwanted elements for cleaner pictures",
            R.drawable.noti_8
        ),
        Triple(
            "Enhance Portraits with AI Beauty",
            "Create flawless selfies in just seconds",
            R.drawable.noti_9
        ),
        Triple(
            "Smart Photo Vault and Gallery",
            "Secure your memories with advanced privacy features",
            R.drawable.noti_10
        ),
        Triple(
            "Turn Blurry Shots into HD",
            "Restore details with smart AI enhancement",
            R.drawable.noti_11
        ),
        Triple(
            "Instant Photo Retouch and Glow",
            "Enhance selfies with natural skin smoothing",
            R.drawable.noti_12
        )
    )

    fun getRandomMessage(): Triple<String, String, Int> {
        return notificationMessages.random()
    }
    fun getRandomMessage(type: String): Pair<String, String> {

        return when (type) {

            "MEMORY" -> {
                val titles = listOf(
                    "Relive your memories 📸",
                    "Moments from this day",
                    "Your memories are waiting"
                )
                val bodies = listOf(
                    "See what you captured on this day",
                    "Photos from past years are ready",
                    "Take a look at your gallery"
                )
                Pair(titles.random(), bodies.random())
            }

            "CREATION" -> {
                val titles = listOf(
                    "Create something amazing ✨",
                    "Turn photos into magic"
                )
                val bodies = listOf(
                    "Make a collage from recent photos",
                    "Create a video in seconds"
                )
                Pair(titles.random(), bodies.random())
            }

            "INACTIVE" -> {
                val titles = listOf(
                    "We miss you 📸",
                    "Come back to your gallery"
                )
                val bodies = listOf(
                    "Your memories are waiting",
                    "Check your latest photos"
                )
                Pair(titles.random(), bodies.random())
            }

            else -> Pair("Check your gallery 📸", "You have new moments to explore")
        }
    }
}