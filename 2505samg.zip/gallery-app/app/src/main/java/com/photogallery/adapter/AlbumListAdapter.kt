package com.photogallery.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.photogallery.R
import com.photogallery.databinding.ItemAlbumGridBinding
import com.photogallery.databinding.ItemAlbumListBinding
import com.photogallery.databinding.ItemHeaderDividerBinding
import com.photogallery.databinding.LayoutExtraUtilBinding
import com.photogallery.model.AlbumData
import com.photogallery.utils.Preferences
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.extension.beVisibleIf
import com.photogallery.extension.loadImage
import com.photogallery.model.MediaData

class AlbumListAdapter(
    var context: Context,
    val clickListener: (pos: Int) -> Unit,
    val longClickListener: (pos: Int) -> Unit,
    val utilClickListener: ((utilPos: Int) -> Unit)? = null,
) : ListAdapter<AlbumData, RecyclerView.ViewHolder>(DiffCallBack()) {


    var portraitList: AlbumData = AlbumData()
    var hdList: AlbumData = AlbumData()
    var burstList: AlbumData = AlbumData()
    var animatedList: AlbumData = AlbumData()

    private class DiffCallBack : DiffUtil.ItemCallback<AlbumData>() {
        override fun areItemsTheSame(oldItem: AlbumData, newItem: AlbumData) = oldItem == newItem

        @SuppressLint("DiffUtilEquals")
        override fun areContentsTheSame(oldItem: AlbumData, newItem: AlbumData) = oldItem == newItem
    }

    val ITEM_ALBUM_UTIL_TYPE = 1
    val ITEM_ALBUM_GRID_TYPE = 2
    val ITEM_ALBUM_LIST_TYPE = 3
//    val ITEM_ALBUM_EXTRA_TYPE = 4

    var preferences: Preferences = Preferences(context)

    override fun getItemViewType(position: Int): Int {
        return if (preferences.getShowGrid()) {

            if (getItem(position).isCustomAlbum && getItem(position).title.equals("utility")) {
                ITEM_ALBUM_UTIL_TYPE
            } else {
                ITEM_ALBUM_GRID_TYPE
            }
        } else {
            if (getItem(position).isCustomAlbum && getItem(position).title.equals("utility")) {
                ITEM_ALBUM_UTIL_TYPE
            } else {
                ITEM_ALBUM_LIST_TYPE
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == ITEM_ALBUM_GRID_TYPE) {
            val binding =
                ItemAlbumGridBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            AlbumGridViewHolder(binding)
        } else if (viewType == ITEM_ALBUM_LIST_TYPE) {
            val binding =
                ItemAlbumListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            AlbumListViewHolder(binding)
        } else if (viewType == ITEM_ALBUM_UTIL_TYPE) {
            val binding =
                LayoutExtraUtilBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            UtilViewHolder(binding)
        } else {
            val binding =
                ItemHeaderDividerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            HeaderViewHolder(binding)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        holder.itemView.tag = holder
        if (getItemViewType(holder.adapterPosition) == ITEM_ALBUM_GRID_TYPE) {
            val albumGridViewHolder = holder as AlbumGridViewHolder
            val albumData: AlbumData = getItem(holder.adapterPosition) as AlbumData


            albumGridViewHolder.binding.txtTitle.text = albumData.title
            if (albumData.mediaData.isNotEmpty()) {
                albumGridViewHolder.binding.txtCount.text = "${albumData.mediaData.size}"
                albumGridViewHolder.binding.icVideo.visibility =
                    if (albumData.mediaData[0].isVideo) View.VISIBLE else View.GONE

                albumGridViewHolder.binding.cardImage.beVisible()
                albumGridViewHolder.binding.cardMore.beGone()
                context.loadImage(
                    path = albumData.mediaData[0].filePath,
                    target = albumGridViewHolder.binding.image,
                    signature = albumData.mediaData[0].getKey(),
                    onError = {
                        albumGridViewHolder.binding.image.scaleType =
                            ImageView.ScaleType.CENTER_CROP
                        albumGridViewHolder.binding.image.setImageDrawable(
                            AppCompatResources.getDrawable(
                                context,
                                R.drawable.ic_image_placeholder
                            )
                        )
                    }
                )
                try {
                    albumGridViewHolder.binding.ivGif!!.beVisibleIf(
                        albumData.mediaData[0].filePath.endsWith(
                            "gif",
                            true
                        )
                    )
                } catch (e: Exception) {
                }
//                }
            } else {

                if (albumData.isMoreAlbum) {
                    albumGridViewHolder.binding.cardImage.beGone()
                    albumGridViewHolder.binding.cardMore.beVisible()
                    albumGridViewHolder.binding.txtCount.text =
                        "${albumData.childAlbums.size} ${context.getString(R.string.albums)}"

                    bindChildAlbumImages(
                        albumData = albumData,
                        image1 = holder.binding.image1,
                        image2 = holder.binding.image2,
                        image3 = holder.binding.image3,
                        image4 = holder.binding.image4
                    )

                } else {
                    albumGridViewHolder.binding.txtCount.text = "0 ${context.getString(R.string.album)}"
                    albumGridViewHolder.binding.image.setImageDrawable(
                        ContextCompat.getDrawable(
                            context,
                            R.drawable.ic_image_placeholder
                        )
                    )
                }


            }

            if (albumData.isCheckboxVisible && !albumData.isCustomAlbum) {

                if (albumData.isSelected) {
                    albumGridViewHolder.binding.icUnSelect.beGone()
                    albumGridViewHolder.binding.icSelect.beVisible()
                } else {
                    albumGridViewHolder.binding.icUnSelect.beVisible()
                    albumGridViewHolder.binding.icSelect.beGone()
                }
//                albumGridViewHolder.binding.icUnSelect.visibility = View.VISIBLE
//                albumGridViewHolder.binding.icSelect.visibility =
//                    if (albumData.isSelected) View.VISIBLE else View.GONE
            } else {
                albumGridViewHolder.binding.icUnSelect.visibility = View.GONE
                albumGridViewHolder.binding.icSelect.visibility = View.GONE
//                albumGridViewHolder.binding.icFavourite.visibility =
//                    if (albumData.isFavorite) View.VISIBLE else View.GONE
            }

            albumGridViewHolder.binding.root.setOnClickListener {
                clickListener(holder.adapterPosition)
            }
            albumGridViewHolder.binding.root.setOnLongClickListener {
                longClickListener(holder.adapterPosition)
                true
            }
        } else if (getItemViewType(holder.adapterPosition) == ITEM_ALBUM_LIST_TYPE) {
            val albumGridViewHolder = holder as AlbumListViewHolder
            val albumData: AlbumData = getItem(holder.adapterPosition) as AlbumData


            albumGridViewHolder.binding.txtTitle.text = albumData.title


            if (albumData.mediaData.isNotEmpty()) {
                albumGridViewHolder.binding.txtCount.text =
                    "${albumData.mediaData.size} ${context.getString(R.string.items)}"
                albumGridViewHolder.binding.icVideo.visibility =
                    if (albumData.mediaData[0].isVideo) View.VISIBLE else View.GONE

                albumGridViewHolder.binding.cardImage.beVisible()
                albumGridViewHolder.binding.cardMore.beGone()
                context.loadImage(
                    path = albumData.mediaData[0].filePath,
                    target = albumGridViewHolder.binding.image,
                    signature = albumData.mediaData[0].getKey(),
                    onError = {
                        albumGridViewHolder.binding.image.scaleType =
                            ImageView.ScaleType.CENTER_CROP
                        albumGridViewHolder.binding.image.setImageDrawable(
                            AppCompatResources.getDrawable(
                                context,
                                R.drawable.ic_image_placeholder
                            )
                        )
                    }
                )
                try {
                    albumGridViewHolder.binding.ivGif.beVisibleIf(
                        albumData.mediaData[0].filePath.endsWith(
                            "gif",
                            true
                        )
                    )
                } catch (e: Exception) {
                }

            } else {

                if (albumData.isMoreAlbum) {
                    albumGridViewHolder.binding.cardImage.beGone()
                    albumGridViewHolder.binding.cardMore.beVisible()
                    albumGridViewHolder.binding.txtCount.text =
                        "${albumData.childAlbums.size} ${context.getString(R.string.albums)}"

                    bindChildAlbumImages(
                        albumData = albumData,
                        image1 = holder.binding.image1,
                        image2 = holder.binding.image2,
                        image3 = holder.binding.image3,
                        image4 = holder.binding.image4
                    )
                } else {
                    albumGridViewHolder.binding.txtCount.text = "0 ${context.getString(R.string.album)}"
                }
                albumGridViewHolder.binding.image.setImageDrawable(
                    ContextCompat.getDrawable(
                        context,
                        R.drawable.ic_image_placeholder
                    )
                )
            }

            if (albumData.isCheckboxVisible && !albumData.isCustomAlbum) {

                if (albumData.isSelected) {
                    albumGridViewHolder.binding.icUnSelect.beGone()
                    albumGridViewHolder.binding.icSelect.beVisible()
                } else {
                    albumGridViewHolder.binding.icUnSelect.beVisible()
                    albumGridViewHolder.binding.icSelect.beGone()
                }
//                albumGridViewHolder.binding.icUnSelect.visibility = View.VISIBLE
//                albumGridViewHolder.binding.icSelect.visibility =
//                    if (albumData.isSelected) View.VISIBLE else View.GONE
            } else {
                albumGridViewHolder.binding.icUnSelect.visibility = View.GONE
                albumGridViewHolder.binding.icSelect.visibility = View.GONE
            }

            albumGridViewHolder.binding.root.setOnClickListener {
                clickListener(position)
            }
            albumGridViewHolder.binding.root.setOnLongClickListener {
                longClickListener(position)
                true
            }
        } else if (getItemViewType(position) == ITEM_ALBUM_UTIL_TYPE) {
            val albumData: AlbumData = getItem(position) as AlbumData
            val albumHeaderViewHolder = holder as UtilViewHolder

            if (albumData.folderPath == "utility") {
                albumHeaderViewHolder.binding.extraAlbum.beGone()
                albumHeaderViewHolder.binding.extraTop.beVisible()

                albumHeaderViewHolder.binding.llRecent.setOnClickListener {
                    if (!albumData.isCheckboxVisible) utilClickListener?.invoke(0)
                }
                albumHeaderViewHolder.binding.llFavorite.setOnClickListener {
                    if (!albumData.isCheckboxVisible) utilClickListener?.invoke(2)
                }
                albumHeaderViewHolder.binding.llHidden.setOnClickListener {
                    if (!albumData.isCheckboxVisible) utilClickListener?.invoke(3)
                }
                albumHeaderViewHolder.binding.llDuplicate.setOnClickListener {
                    if (!albumData.isCheckboxVisible) utilClickListener?.invoke(4)
                }
                albumHeaderViewHolder.binding.llTrash.setOnClickListener {
                    if (!albumData.isCheckboxVisible) utilClickListener?.invoke(5)
                }
                albumHeaderViewHolder.binding.llCleaner.setOnClickListener {
                    if (!albumData.isCheckboxVisible) utilClickListener?.invoke(6)
                }
                albumHeaderViewHolder.binding.llEditor.setOnClickListener {
                    if (!albumData.isCheckboxVisible) utilClickListener?.invoke(7)
                }
            } else if (albumData.folderPath == "extra_album") {
                albumHeaderViewHolder.binding.extraAlbum.beVisible()
                albumHeaderViewHolder.binding.extraTop.beGone()

//                albumHeaderViewHolder.binding.txtMoment.text = "${context.getString(R.string.moments)} (${portraitList.mediaData.size})"
                albumHeaderViewHolder.binding.llMoment.setOnClickListener {
                    if (!albumData.isCheckboxVisible) utilClickListener?.invoke(10)
                }

//                albumHeaderViewHolder.binding.txtPortrait.text = "${context.getString(R.string.portrait)} (${portraitList.mediaData.size})"
                albumHeaderViewHolder.binding.llPortrait.setOnClickListener {
                    if (!albumData.isCheckboxVisible) utilClickListener?.invoke(11)
                }

//                albumHeaderViewHolder.binding.txtHd.text = "${context.getString(R.string.high_definition)} (${hdList.mediaData.size})"
                albumHeaderViewHolder.binding.llHd.setOnClickListener {
                    if (!albumData.isCheckboxVisible) utilClickListener?.invoke(12)
                }

//                albumHeaderViewHolder.binding.txtBurst.text = "${context.getString(R.string.burst)} (${burstList.mediaData.size})"
                albumHeaderViewHolder.binding.llBurst.setOnClickListener {
                    if (!albumData.isCheckboxVisible) utilClickListener?.invoke(13)
                }

//                albumHeaderViewHolder.binding.txtAnimated.text = "${context.getString(R.string.animated)} (${animatedList.mediaData.size})"
                albumHeaderViewHolder.binding.llAnimated.setOnClickListener {
                    if (!albumData.isCheckboxVisible) utilClickListener?.invoke(14)
                }
            }

            if (albumData.isCheckboxVisible) {
                albumHeaderViewHolder.binding.root.alpha = 0.5f
            } else {
                albumHeaderViewHolder.binding.root.alpha = 1.0f
            }
        }
    }

    private fun bindChildAlbumImages(
        albumData: AlbumData,
        image1: ImageView,
        image2: ImageView,
        image3: ImageView,
        image4: ImageView
    ) {

        val imageViews = listOf(
            image1,
            image2,
            image3,
            image4
        )

        // Hide all initially
        imageViews.forEach { it.beGone() }

        // Maximum 4 child albums
        val childAlbums = albumData.childAlbums.take(4)

        childAlbums.forEachIndexed { index, childAlbum ->

            val imageView = imageViews[index]

            // First media safely
            val media = childAlbum.mediaData.firstOrNull()

            imageView.beVisible()

            if (media != null) {

                imageView.scaleType = ImageView.ScaleType.CENTER_CROP

                context.loadImage(
                    path = media.filePath,
                    target = imageView,
                    signature = media.getKey(),
                    onError = {

                        imageView.scaleType = ImageView.ScaleType.CENTER_INSIDE

                        imageView.setImageDrawable(
                            AppCompatResources.getDrawable(
                                context,
                                R.drawable.ic_image_placeholder
                            )
                        )
                    }
                )

            } else {

                imageView.scaleType = ImageView.ScaleType.CENTER_INSIDE

                imageView.setImageDrawable(
                    AppCompatResources.getDrawable(
                        context,
                        R.drawable.ic_image_placeholder
                    )
                )
            }
        }
    }

    class UtilViewHolder(var binding: LayoutExtraUtilBinding) :
        RecyclerView.ViewHolder(binding.root)

    class HeaderViewHolder(var binding: ItemHeaderDividerBinding) :
        RecyclerView.ViewHolder(binding.root)

    class AlbumGridViewHolder(var binding: ItemAlbumGridBinding) :
        RecyclerView.ViewHolder(binding.root)

    class AlbumListViewHolder(var binding: ItemAlbumListBinding) :
        RecyclerView.ViewHolder(binding.root)

    fun getBubbleText(adapterPosition: Int): String {
        return getItem(adapterPosition).title
    }

//    private fun getBubbleText(
//        albumData: AlbumData,
//        sorting: Int,
//        dateFormat: String? = null,
//        timeFormat: String? = null
//    ): String {
//        var strKey = ""
//
//        when (sorting) {
//            Constant.SORT_NAME -> strKey = albumData.title
//            Constant.SORT_PATH -> strKey = albumData.title
//            Constant.SORT_SIZE -> strKey = albumData.title
//            Constant.SORT_LAST_MODIFIED -> {
//                strKey = DateFormat.format("$dateFormat, $timeFormat", albumData.date).toString()
//            }
//            Constant.SORT_DATE_TAKEN -> {
//                strKey = DateFormat.format("$dateFormat, $timeFormat", albumData.date).toString()
//            }
//        }
//
//        Log.e("PictureAdapter", "getBubbleText.002:$sorting, $strKey")
//        return strKey
//    }

}