package com.photoeditor


enum class ViewType {
    BRUSH_DRAWING,
    TEXT,
    IMAGE,
    EMOJI
}