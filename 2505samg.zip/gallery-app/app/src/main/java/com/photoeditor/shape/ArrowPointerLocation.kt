package com.photoeditor.shape

enum class ArrowPointerLocation { START, END, BOTH }