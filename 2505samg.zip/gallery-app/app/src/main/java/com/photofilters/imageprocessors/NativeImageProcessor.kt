package com.photofilters.imageprocessors

object NativeImageProcessor {
//    external fun applyRGBCurve(pixels: IntArray?, rgb: IntArray?, width: Int, height: Int): IntArray?
//    external fun applyChannelCurves(pixels: IntArray?, r: IntArray?, g: IntArray?, b: IntArray?, width: Int, height: Int): IntArray?
//    external fun doBrightness(pixels: IntArray?, value: Int, width: Int, height: Int): IntArray?
//    external fun doContrast(pixels: IntArray?, value: Float, width: Int, height: Int): IntArray?
//    external fun doColorOverlay(pixels: IntArray?, depth: Int, red: Float, green: Float, blue: Float, width: Int, height: Int): IntArray?
//    external fun doSaturation(pixels: IntArray?, level: Float, width: Int, height: Int): IntArray?

    private fun hslToRgbSubfunction(temp1: Float, temp2: Float, temp3: Float): Int {
        val cFloat = when {
            temp3 * 6f < 1f -> (temp2 + (temp1 - temp2) * 6f * temp3) * 100f
            temp3 * 2f < 1f -> temp1 * 100f
            temp3 * 3f < 2f -> (temp2 + (temp1 - temp2) * (0.66666f - temp3) * 6f) * 100f
            else -> temp2 * 100f
        }
        return cFloat.toInt()
    }

    // Saturation (HSL) adjustment — port of `saturation` from C++
    // `level` is the multiplier for saturation (1.0 = no change)
    fun doSaturation(pixels: IntArray, level: Float, width: Int, height: Int): IntArray {
        val size = width * height
        for (i in 0 until size) {
            val px = pixels[i]
            val a = px and -0x1000000 // 0xFF000000
            val r = (px shr 16) and 0xFF
            val g = (px shr 8) and 0xFF
            val b = px and 0xFF

            var rPct = r / 255f
            var gPct = g / 255f
            var bPct = b / 255f

            // max and min
            val maxColor = maxOf(rPct, gPct, bPct)
            val minColor = minOf(rPct, gPct, bPct)

            var L = (maxColor + minColor) / 2f
            var S: Float
            var H = 0f

            if (maxColor == minColor) {
                S = 0f
                H = 0f
            } else {
                S = if (L < 0.5f) {
                    (maxColor - minColor) / (maxColor + minColor)
                } else {
                    (maxColor - minColor) / (2f - maxColor - minColor)
                }

                H = when (maxColor) {
                    rPct -> (gPct - bPct) / (maxColor - minColor)
                    gPct -> 2f + (bPct - rPct) / (maxColor - minColor)
                    else -> 4f + (rPct - gPct) / (maxColor - minColor)
                }
            }

            // Convert to scales used in original code
            var S_percent = (S * 100f)
            var L_percent = (L * 100f)
            var H_deg = H * 60f
            if (H_deg < 0f) H_deg += 360f

            // apply level multiplier and clamp
            S_percent *= level
            S_percent = S_percent.coerceIn(0f, 100f)

            // convert back to normalized values
            L = L_percent / 100f
            S = S_percent / 100f
            var H_norm = H_deg / 360f

            var outR = 0
            var outG = 0
            var outB = 0

            if (S == 0f) {
                // achromatic (grey)
                val v = (L * 100f).toInt()
                outR = v
                outG = v
                outB = v
            } else {
                val temp1 = if (L < 0.5f) L * (1f + S) else L + S - (L * S)
                val temp2 = 2f * L - temp1

                // red
                var temp3 = H_norm + 0.33333f
                if (temp3 > 1f) temp3 -= 1f
                outR = hslToRgbSubfunction(temp1, temp2, temp3)

                // green
                temp3 = H_norm
                outG = hslToRgbSubfunction(temp1, temp2, temp3)

                // blue
                temp3 = H_norm - 0.33333f
                if (temp3 < 0f) temp3 += 1f
                outB = hslToRgbSubfunction(temp1, temp2, temp3)
            }

            val finalR = (((outR / 100f) * 255f).toInt()).coerceIn(0, 255)
            val finalG = (((outG / 100f) * 255f).toInt()).coerceIn(0, 255)
            val finalB = (((outB / 100f) * 255f).toInt()).coerceIn(0, 255)

            pixels[i] = a or (finalR shl 16) or (finalG shl 8) or finalB
        }
        return pixels
    }

    // Color overlay — port of colorOverlay
    // depth: intensity (as in C++), red/green/blue are floats (0..255 multipliers)
    fun doColorOverlay(pixels: IntArray, depth: Int, red: Float, green: Float, blue: Float, width: Int, height: Int): IntArray {
        val size = width * height
        for (i in 0 until size) {
            val px = pixels[i]
            val a = px and -0x1000000
            var R = ((px shr 16) and 0xFF).toFloat()
            var G = ((px shr 8) and 0xFF).toFloat()
            var B = (px and 0xFF).toFloat()

            R += depth * red
            if (R > 255f) R = 255f
            G += depth * green
            if (G > 255f) G = 255f
            B += depth * blue
            if (B > 255f) B = 255f

            val rI = R.toInt() and 0xFF
            val gI = G.toInt() and 0xFF
            val bI = B.toInt() and 0xFF

            pixels[i] = a or (rI shl 16) or (gI shl 8) or bI
        }
        return pixels
    }

    // Contrast adjustment — port of contrast
    // value: contrast multiplier (1.0 = no change)
    fun doContrast(pixels: IntArray, value: Float, width: Int, height: Int): IntArray {
        val size = width * height
        for (i in 0 until size) {
            val px = pixels[i]
            val a = px and -0x1000000
            val red = ((px shr 16) and 0xFF)
            val green = ((px shr 8) and 0xFF)
            val blue = (px and 0xFF)

            var r = ((((red / 255f) - 0.5f) * value) + 0.5f) * 255f
            var g = ((((green / 255f) - 0.5f) * value) + 0.5f) * 255f
            var b = ((((blue / 255f) - 0.5f) * value) + 0.5f) * 255f

            r = r.coerceIn(0f, 255f)
            g = g.coerceIn(0f, 255f)
            b = b.coerceIn(0f, 255f)

            pixels[i] = a or ((r.toInt() and 0xFF) shl 16) or ((g.toInt() and 0xFF) shl 8) or (b.toInt() and 0xFF)
        }
        return pixels
    }

    // Brightness adjustment — port of brightness
    // value: integer offset added to R,G,B
    fun doBrightness(pixels: IntArray, value: Int, width: Int, height: Int): IntArray {
        val size = width * height
        for (i in 0 until size) {
            val px = pixels[i]
            val a = px and -0x1000000
            var red = ((px shr 16) and 0xFF) + value
            var green = ((px shr 8) and 0xFF) + value
            var blue = (px and 0xFF) + value

            red = red.coerceIn(0, 255)
            green = green.coerceIn(0, 255)
            blue = blue.coerceIn(0, 255)

            pixels[i] = a or ((red and 0xFF) shl 16) or ((green and 0xFF) shl 8) or (blue and 0xFF)
        }
        return pixels
    }

    // applyChannelCurves — r/g/b are optional lookup tables (IntArray of 256 values each)
    // Each table should contain values in range [0..255] or full rgb-int as in original C++
    fun applyChannelCurves(pixels: IntArray, r: IntArray?, g: IntArray?, b: IntArray?, width: Int, height: Int): IntArray {
        val size = width * height
        for (i in 0 until size) {
            val px = pixels[i]
            val a = px and -0x1000000
            val rVal = (px shr 16) and 0xFF
            val gVal = (px shr 8) and 0xFF
            val bVal = px and 0xFF

            val red = if (r != null) ((r[rVal] and 0xFF) shl 16) and 0x00FF0000 else (rVal shl 16) and 0x00FF0000
            val green = if (g != null) ((g[gVal] and 0xFF) shl 8) and 0x0000FF00 else (gVal shl 8) and 0x0000FF00
            val blue = if (b != null) (b[bVal] and 0xFF) else bVal and 0x000000FF

            pixels[i] = a or red or green or blue
        }
        return pixels
    }

    // applyRGBCurve — rgb is a 256-entry table mapping [0..255] -> [0..255]
    fun applyRGBCurve(pixels: IntArray, rgb: IntArray, width: Int, height: Int): IntArray {
        // Precompute R/G/B tables like the C++ version
        val R = IntArray(256)
        val G = IntArray(256)
        val B = IntArray(256)
        for (i in 0 until 256) {
            val v = rgb[i] and 0xFF
            R[i] = (v shl 16) and 0x00FF0000
            G[i] = (v shl 8) and 0x0000FF00
            B[i] = v and 0x000000FF
        }

        val size = width * height
        for (i in 0 until size) {
            val px = pixels[i]
            val a = px and -0x1000000
            val rVal = (px shr 16) and 0xFF
            val gVal = (px shr 8) and 0xFF
            val bVal = px and 0xFF

            pixels[i] = a or R[rVal] or G[gVal] or B[bVal]
        }
        return pixels
    }
}
