//https://docs.google.com/document/d/1No6Am7hqHCE0TtGSSekTHCCyO4jb5QgRWYSgXb2539I/edit?tab=t.0
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
        maven { setUrl("https://maven.wysaid.org/") }
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        jcenter()
        maven { setUrl("https://maven.wysaid.org/") }
        maven { setUrl("https://maven.google.com/") }
        maven { setUrl("https://jitpack.io") }
    }
}

//rootProject.name = "NewGallery"
include(":app")
//include(":ads")
include(":stories")
include(":imagestopdf")
//include(":android-pdf-viewer")
//include(":tabswitcher")
