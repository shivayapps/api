package com.photo.collage.frames.grid.filters.maker.model

import java.io.File
import java.io.Serializable

data class SavedImageModel(var file:File,var isVisible:Boolean,var isSelected:Boolean):Serializable