package com.photo.collage.frames.grid.filters.maker.adepters;

import android.content.Context;
import android.graphics.Color;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.photo.collage.frames.grid.filters.maker.R;
import com.photo.collage.frames.grid.filters.maker.model.OptionModel;

import java.util.ArrayList;

public class ImageOptionAdepter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final String TAG = "ImageOptionAdepter";

    private Context mContext;
    private ArrayList<OptionModel> mList;
    private OnOptionItemClick mListner;

    public int mSelectedItem = -1;
    public int mSelectedLatItem = -1;

    public ImageOptionAdepter(Context mContext, ArrayList<OptionModel> mList, OnOptionItemClick mListner) {
        this.mContext = mContext;
        this.mList = mList;
        this.mListner = mListner;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ImageOptionViewHolder(LayoutInflater.from(mContext).inflate(R.layout.layout_image_option, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        if (holder instanceof ImageOptionViewHolder) {


            if (mSelectedItem == position) {
                startBottomMenuAnimation(((ImageOptionViewHolder) holder).txtOptionText, ((ImageOptionViewHolder) holder).imgOptionLogo, ((ImageOptionViewHolder) holder).viewOptionUnderline);
            } else {
                stopBottomMenuAnimation(((ImageOptionViewHolder) holder).txtOptionText, ((ImageOptionViewHolder) holder).imgOptionLogo, ((ImageOptionViewHolder) holder).viewOptionUnderline);
            }

            ((ImageOptionViewHolder) holder).imgOptionLogo.setImageResource(mList.get(position).getImageResource());
            ((ImageOptionViewHolder) holder).imgOptionLogo.setColorFilter(Color.WHITE);

            ((ImageOptionViewHolder) holder).txtOptionText.setText(mList.get(position).getName());

            holder.itemView.setOnClickListener(view -> {
                mSelectedLatItem = mSelectedItem;
               // startBottomMenuAnimation(((ImageOptionViewHolder) holder).txtOptionText, ((ImageOptionViewHolder) holder).imgOptionLogo, ((ImageOptionViewHolder) holder).viewOptionUnderline);
                notifyItemChanged(mSelectedItem);
                mSelectedItem = position;
                notifyItemChanged(mSelectedItem);

                /*stopBottomMenuAnimation(((ImageOptionViewHolder) holder).txtOptionText, ((ImageOptionViewHolder) holder).imgOptionLogo, ((ImageOptionViewHolder) holder).viewOptionUnderline);
                notifyItemChanged(mSelectedLatItem);*/

                if (mListner != null)
                    mListner.onOptionItemClick(mList.get(position));
            });

            if (mList.get(position).getName().equals("Vertical")) {
                Log.d(TAG, "onBindViewHolder: ");
                //((ImageOptionViewHolder) holder).imgOptionLogo.setRotation(90);
            }

            if (mList.size() > 2) {

                if (position == 5) {
                    //((ImageOptionViewHolder) holder).imgOptionLogo.setRotation(90);
                    ((ImageOptionViewHolder) holder).txtOptionText.setMaxLines(1);
                    ((ImageOptionViewHolder) holder).txtOptionText.setEllipsize(TextUtils.TruncateAt.END);
                }
            }

            /*((ImageOptionViewHolder) holder).topLayout.post(() -> {
                ((ImageOptionViewHolder) holder).topLayout.getLayoutParams().width = ((ImageOptionViewHolder) holder).topLayout.getHeight();
                ((ImageOptionViewHolder) holder).txtOptionText.requestLayout();

                Log.d(TAG, "onBindViewHolder: "+((ImageOptionViewHolder) holder).topLayout.getWidth() + " + "+((ImageOptionViewHolder) holder).topLayout.getHeight());
            });*/

        }

    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    private class ImageOptionViewHolder extends RecyclerView.ViewHolder {

        private ImageView imgOptionLogo;
        private TextView txtOptionText;
        private ConstraintLayout topLayout;
        private View viewOptionUnderline;

        public ImageOptionViewHolder(@NonNull View itemView) {
            super(itemView);

            txtOptionText = itemView.findViewById(R.id.txtOptionName);
            imgOptionLogo = itemView.findViewById(R.id.imgOptionLogo);
            topLayout = itemView.findViewById(R.id.topLayout);
            viewOptionUnderline = itemView.findViewById(R.id.viewOptionUnderline);
        }
    }

    //Bottom menu animation
    private void startBottomMenuAnimation(View textView, View btnAdd, View view) {
        view.animate().alpha(1f).setDuration(200);
        view.setVisibility(View.VISIBLE);
        btnAdd.animate().alpha(1f).translationY(-8f).scaleX(1.2f).scaleY(1.2f).setDuration(350);
        textView.animate().alpha(1f).translationY(-6f).setDuration(350);
    }

    private void stopBottomMenuAnimation(View textView, View btnAdd, View view) {
        view.animate().alpha(0.5f).setDuration(10);
        view.setVisibility(View.GONE);
        btnAdd.animate().alpha(0.5f).translationY(0f).scaleX(1f).scaleY(1f).setDuration(10);
        textView.animate().alpha(0.5f).translationY(0f).setDuration(10);
    }

    public interface OnOptionItemClick {
        void onOptionItemClick(OptionModel model);
    }


}
