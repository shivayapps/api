package com.photo.collage.frames.grid.filters.maker.utils

import android.content.Context
import android.content.SharedPreferences

class SharedPrefs {
    private var mSharedPreferences:SharedPreferences?=null
    private var mContext:Context?=null
    private val mPref: SharedPreferences?=null

    constructor(mContext: Context?) {
        this.mContext = mContext
        mSharedPreferences = mContext!!.getSharedPreferences("info", Context.MODE_PRIVATE)
    }


    fun saveRatingSharedPrefsData(){
        mSharedPreferences = mContext!!.getSharedPreferences("myRatingPrefs",Context.MODE_PRIVATE)
        var editor:SharedPreferences.Editor = mSharedPreferences!!.edit()
        editor.putBoolean("isRated",true)
        editor.apply()
    }

    fun getRatingSharedPrefsData():Boolean{
        mSharedPreferences = mContext!!.getSharedPreferences("myRatingPrefs",Context.MODE_PRIVATE)
        return mSharedPreferences!!.getBoolean("isRated",false)
    }

    fun saveOpenAppAdShownCount(){
        mSharedPreferences = mContext!!.getSharedPreferences("myRatingPrefs",Context.MODE_PRIVATE)
        var editor:SharedPreferences.Editor = mSharedPreferences!!.edit()
        val i = mSharedPreferences!!.getInt("isAdShownCount",1)
        editor.putInt("isAdShownCount",i+1)
        editor.apply()
    }
    fun nullOpenAppAdShownCount(){
        mSharedPreferences = mContext!!.getSharedPreferences("myRatingPrefs",Context.MODE_PRIVATE)
        var editor:SharedPreferences.Editor = mSharedPreferences!!.edit()
        editor.putInt("isAdShownCount",1)
        editor.apply()
    }
    fun getOpenAppAdShown():Boolean{
        mSharedPreferences = mContext!!.getSharedPreferences("myRatingPrefs",Context.MODE_PRIVATE)
        val i:Int = mSharedPreferences?.getInt("isAdShownCount",0)!!
        return i % 3==0
    }

    var deviceWidth: Int
        get() = mPref!!.getInt("device_width", 0)
        set(width) {
            val mEditor = mPref?.edit()
            mEditor?.putInt("device_width", width)
            mEditor?.apply()
        }
    var deviceHeight: Int
        get() = mPref!!.getInt("device_height", 0)
        set(height) {
            val mEditor = mPref?.edit()
            mEditor?.putInt("device_height", height)
            mEditor?.apply()
        }

    fun savePhotoList(str:String){
        mSharedPreferences = mContext!!.getSharedPreferences("myPhotoList",Context.MODE_PRIVATE)
        var editor:SharedPreferences.Editor = mSharedPreferences!!.edit()
        editor.putString("photoList",str)
        editor.apply()
    }

    fun getPhotoList():String{
        mSharedPreferences = mContext!!.getSharedPreferences("myPhotoList",Context.MODE_PRIVATE)
        return mSharedPreferences?.getString("photoList","")!!
    }
}