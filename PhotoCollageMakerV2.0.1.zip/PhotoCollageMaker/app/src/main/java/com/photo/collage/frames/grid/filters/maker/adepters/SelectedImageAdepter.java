package com.photo.collage.frames.grid.filters.maker.adepters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.photo.collage.frames.grid.filters.maker.comman.Constants;
import com.photo.collage.frames.grid.filters.maker.R;
import com.photo.collage.frames.grid.filters.maker.interfaces.OnRefreshListener;
import com.photo.collage.frames.grid.filters.maker.model.PhotoModel;

import java.util.ArrayList;

public class SelectedImageAdepter extends RecyclerView.Adapter<SelectedImageAdepter.MyViewHolder> {

    private Context mContext;
    private ArrayList<PhotoModel> mList;
    private TextView textView;
    private ImageButton imageButton;
    private ImageButton imgBtnDone;

    private OnRefreshListener listener;

    public SelectedImageAdepter(Context mContext, ArrayList<PhotoModel> mList, TextView textView, ImageButton imageButton, ImageButton imgBtnDone) {
        this.mContext = mContext;
        this.mList = mList;
        this.textView = textView;
        this.imageButton = imageButton;
        this.imgBtnDone = imgBtnDone;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(mContext).inflate(R.layout.layout_selected_image,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        Glide.with(mContext).load(mList.get(position).getImagePath()).into(holder.imgShow);

        holder.imgBtnDelete.setOnClickListener(view -> {
            mList.get(position).setCount(mList.get(position).getCount() - 1);
            PhotoModel model = mList.get(position);
            mList.remove(position);
            if(mList.size() <=0){
                imageButton.setEnabled(true);
                imgBtnDone.setVisibility(View.INVISIBLE);
            }
            notifyDataSetChanged();
            textView.setText("("+String.valueOf(Constants.mSelectedImageList.size())+")");

            if(listener != null){
                listener.onRefresh(model);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public void setListener(OnRefreshListener listener) {
        this.listener = listener;
    }

    public void OnRefresh(PhotoModel model){
        if(listener != null){
            listener.onRefresh(model);
        }
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        private ImageView imgShow;
        private ImageButton imgBtnDelete;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            imgBtnDelete = itemView.findViewById(R.id.imgBtnDelete);
            imgShow = itemView.findViewById(R.id.imgPhoto);
        }
    }
}
