package com.photo.collage.frames.grid.filters.maker.moreframes.sqlite_database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.core.util.Pair;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "MyDBName.db";
    public static final String CONTACTS_COLUMN_NAME = "path";
    public static final String COLUMN_NAME_COUNT = "count";


    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // TODO Auto-generated method stub
        db.execSQL(
                "create table contacts " +
                        "(id integer primary key, path text,count integer)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub
        db.execSQL("DROP TABLE IF EXISTS contacts");
        onCreate(db);
    }

    public boolean insertPath(String path) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("path", path);
        if (!checkPathExist(path)) {
            db.insert("contacts", null, contentValues);
        }
        return true;
    }

    public boolean insertPath(String path, int count) {
        Log.e("qwertyuj", "insertPath");
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("path", path);
        contentValues.put("count", count);
        if (!checkPathExist(path)) {
            long l = db.insert("contacts", null, contentValues);
            if (l > 0) {
                Log.e("qwertyuj", "insertPath: " + l);
            } else {
                Log.e("qwertyuj", "insertPath: " + l);
            }
        }
        return true;
    }


    public boolean checkPathExist(String path) {
        Cursor res = null;
        boolean isWathced = false;
        try {
            SQLiteDatabase db = this.getReadableDatabase();
            res = db.rawQuery("select * from contacts WHERE path = '" + path + "'", null);
            res.moveToFirst();
            if (res.getCount() > 0) {
                isWathced = true;
            }
        } finally {
            if (res != null)
                res.close();
        }
        res.close();
        return isWathced;
    }

    public Pair<Boolean, Integer> isExist(String path) {
        Cursor res = null;
        boolean isWathced = false;
        Pair<Boolean, Integer> value = new Pair<Boolean, Integer>(isWathced, -1);
        Log.e("qwertyuj", "isExist");
        try {
            Log.e("qwertyuj", "try");
            SQLiteDatabase db = this.getReadableDatabase();
            res = db.rawQuery("select * from contacts WHERE path = '" + path + "'", null);
            res.moveToFirst();
            if (res.getCount() > 0) {
                isWathced = true;
                value = new Pair<Boolean, Integer>(isWathced, res.getInt(res.getColumnIndex("count")));
                Log.e("qwertyuj", "exit");
            } else {
                Log.e("qwertyuj", "Not exit");
            }
        } finally {
            Log.e("qwertyuj", "final");
            // this gets called even if there is an exception somewhere above
            if (res != null)
                res.close();
        }
        res.close();
        return value;
    }

    public int getCount(String path) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from contacts WHERE path = '" + path + "'", null);
        if (res != null && res.getCount() > 0) {
            res.moveToFirst();
            return res.getInt(res.getColumnIndex("count"));
        }
        return -1;
    }

    public boolean updateCount(String path, int count) {
        Log.e("qwertyuj", "updateCount");
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("count", count);
        int result = 0;
        result = db.update("contacts", contentValues, " path = ?", new String[]{path});
        if (result <= 0) {
            Log.e("qwertyuj", "updateCount: " + result);
            return false;
        } else {
            Log.e("qwertyuj", "updateCount");
            return true;
        }
    }
}