package com.photo.collage.frames.grid.filters.maker.widgets;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.LinearLayout;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import com.photo.collage.frames.grid.filters.maker.utils.MoveUpwardBehavior;

@CoordinatorLayout.DefaultBehavior(MoveUpwardBehavior.class)
public class MovableLayout extends ConstraintLayout {

    public MovableLayout(Context context) {
        super(context);
    }

    public MovableLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public MovableLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
