package com.photo.collage.frames.grid.filters.maker.model;

import java.io.Serializable;
import java.util.ArrayList;

public class AlbumModel implements Serializable {


    private String AlbumName;
    private ArrayList<PhotoModel> photos;

    public AlbumModel(String albumName, ArrayList<PhotoModel> photos) {
        AlbumName = albumName;
        this.photos = photos;
    }

    public String getAlbumName() {
        return AlbumName;
    }

    public ArrayList<PhotoModel> getPhotos() {
        return photos;
    }

}
