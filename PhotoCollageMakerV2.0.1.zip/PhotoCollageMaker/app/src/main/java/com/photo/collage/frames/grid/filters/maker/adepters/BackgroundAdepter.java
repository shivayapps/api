package com.photo.collage.frames.grid.filters.maker.adepters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.photo.collage.frames.grid.filters.maker.R;

import java.util.ArrayList;

public class BackgroundAdepter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Context mContext;
    private ArrayList<String> mList;
    private OnBackgroundImageClick mListener;

    public BackgroundAdepter(Context mContext, ArrayList<String> mList, OnBackgroundImageClick mListener) {
        this.mContext = mContext;
        this.mList = mList;
        this.mListener = mListener;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new BackgroundHolder(LayoutInflater.from(mContext).inflate(R.layout.layout_backgound_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewholder, int position) {

        BackgroundHolder holder = ((BackgroundHolder) viewholder);

        //set height
        holder.imgBackground.post(() -> {
            holder.imgBackground.getLayoutParams().height = holder.imgBackground.getWidth();
            holder.imgBackground.requestLayout();
        });

        //load background images
        Glide.with(mContext)
                .load(mList.get(position))
                .into(holder.imgBackground);

        //handle Click Event
        holder.imgBackground.setOnClickListener(view -> {
            if(mListener != null){
                mListener.onBackgroundImageClick(mList.get(position));
            }
        });

    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public class BackgroundHolder extends RecyclerView.ViewHolder {

        private ImageView imgBackground;

        public BackgroundHolder(@NonNull View itemView) {
            super(itemView);

            imgBackground = itemView.findViewById(R.id.imgBackground);
        }
    }

    public interface OnBackgroundImageClick{
        void onBackgroundImageClick(String uri);
    }
}
