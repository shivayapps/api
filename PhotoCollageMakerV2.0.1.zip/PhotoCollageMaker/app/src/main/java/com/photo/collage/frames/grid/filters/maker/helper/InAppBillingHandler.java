package com.photo.collage.frames.grid.filters.maker.helper;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;

import java.util.List;

public class InAppBillingHandler {
    private static InAppBillingHandler inAppBillingHandler;
    private static Context mContext;

    public InAppBillingHandler(Context context) {
        mContext = context;
    }

    public InAppBillingHandler() {
        mContext = null;
    }

    public static InAppBillingHandler getInstance(Context context) {
        if (inAppBillingHandler == null) {
            if (context != null) {
                inAppBillingHandler = new InAppBillingHandler(mContext);
            } else {
                inAppBillingHandler = new InAppBillingHandler();
            }
        }
        return inAppBillingHandler;
    }

    public static Intent getBindServiceIntent() {
        Intent intent = new Intent("com.android.vending.billing.InAppBillingService.BIND");
        intent.setPackage("com.android.vending");
        return intent;
    }

    public static boolean isIabServiceAvailable(Context context) {
        final PackageManager packageManager = context.getPackageManager();
        List<ResolveInfo> list = packageManager.queryIntentServices(getBindServiceIntent(), 0);
        return list != null && list.size() > 0;
    }
}
