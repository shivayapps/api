package com.photo.collage.frames.grid.filters.maker.moreframes.callbacks;


import com.photo.collage.frames.grid.filters.maker.model.TemplateItem;

public interface OnRewardEarn {

    void onRewardEarn(TemplateItem imageItem);

}
