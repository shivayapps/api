package com.photo.collage.frames.grid.filters.maker.utils

import android.content.Context
import android.content.Intent
import android.net.Uri

class SharingUtility {
    companion object{
        fun sendEmail(fContext: Context) {

            val intent1 = Intent("android.intent.action.SENDTO")
            intent1.data = Uri.parse("mailto:")
            intent1.putExtra(
                    Intent.EXTRA_EMAIL, arrayOf("profagnesh009@gmail.com")
            )
           /* intent1.putExtra(
                    Intent.EXTRA_SUBJECT,
                    "Photo Collage Maker"
            )*/
            intent1.putExtra(
                    Intent.EXTRA_SUBJECT,
                    "Share valuable feedback to improve app quality of Photo Collage Maker"
            )

            if (intent1.resolveActivity(fContext.packageManager) != null) {
                fContext.startActivity(intent1)
            } else {
                fContext.showToast("Email have been not installed")
            }
        }
    }
}