package com.photo.collage.frames.grid.filters.maker.moreframes.adapters;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.photo.collage.frames.grid.filters.maker.R;
import com.photo.collage.frames.grid.filters.maker.activitys.BaseTemplateDetailActivity;
import com.photo.collage.frames.grid.filters.maker.activitys.FrameDetailActivity;
import com.photo.collage.frames.grid.filters.maker.model.PhotoItem;
import com.photo.collage.frames.grid.filters.maker.model.TemplateItem;
import com.photo.collage.frames.grid.filters.maker.moreframes.sqlite_database.AdsPrefs;
import com.photo.collage.frames.grid.filters.maker.utils.ImageUtils;
import com.photo.collage.frames.grid.filters.maker.widgets.FrameImageView;
import com.photo.collage.frames.grid.filters.maker.widgets.FramePhotoLayout;

import java.util.ArrayList;
import java.util.List;

public class CakeLiveAdapter extends RecyclerView.Adapter<CakeLiveAdapter.MyViewholder> implements FramePhotoLayout.OnQuickActionClickListener {

    private ArrayList<TemplateItem> mTemplateItemList;
    private Context mContext;
    private OnItemSelectedListner onItemSelectedListner;
    private List<String> mSelectedPhotoPaths = new ArrayList<>();
    public FramePhotoLayout mFramePhotoLayout;
    private Bitmap mBackgroundImage;
    int viewHeight;
    int viewWidth;
    protected float mOutputScale = 1;
    private float mSpace = FrameDetailActivity.DEFAULT_SPACE;
    private float mCorner = FrameDetailActivity.DEFAULT_CORNER;
    private int mMainWidth;
    private int mMainHeight;

    public CakeLiveAdapter(ArrayList<TemplateItem> mForegroundList, List<String> mSelectedPhotoPaths, Context mContext, OnItemSelectedListner onItemSelectedListner) {
        this.mTemplateItemList = mForegroundList;
        this.mContext = mContext;
        this.onItemSelectedListner = onItemSelectedListner;
        this.mSelectedPhotoPaths = mSelectedPhotoPaths;

    }

    @NonNull
    @Override
    public MyViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.rv_frame_live, parent, false);
        MyViewholder viewholder = new MyViewholder(view);
        changeRatio("1 : 1", viewholder);

        return viewholder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewholder holder, int position) {
            holder.progressContent.setVisibility(View.VISIBLE);
            holder.imgForeground.setVisibility(View.GONE);
            holder.layoutLi.setVisibility(View.GONE);

            holder.mainContainer.post(() -> {
                mMainHeight = holder.mainContainer.getHeight();
                mMainWidth = holder.mainContainer.getWidth();

                // if (item != mSelectedTemplateItem) {
                // mSelectedTemplateItem.setSelected(false);
                for (int idx = 0; idx < mTemplateItemList.get(position).getPhotoItemList().size(); idx++) {
                    PhotoItem photoItem = mTemplateItemList.get(position).getPhotoItemList().get(idx);
                    if (photoItem.imagePath != null && photoItem.imagePath.length() > 0) {
                        if (idx < mSelectedPhotoPaths.size()) {
                            mSelectedPhotoPaths.add(idx, photoItem.imagePath);
                            Log.d("qwertyTag", "onPreviewTemplateClick: if" + photoItem.maskPath);

                        } else {
                            mSelectedPhotoPaths.add(photoItem.imagePath);
                            Log.d("qwertyTag", "onPreviewTemplateClick: else" + photoItem.maskPath);

                        }
                    }
                }

                final int size = Math.min(mSelectedPhotoPaths.size(), mTemplateItemList.get(position).getPhotoItemList().size());
                for (int idx = 0; idx < size; idx++) {
                    PhotoItem photoItem = mTemplateItemList.get(position).getPhotoItemList().get(idx);
                    if (photoItem.imagePath == null || photoItem.imagePath.length() < 1) {
                        photoItem.imagePath = mSelectedPhotoPaths.get(idx);
                    }
                }

                // mSelectedTemplateItem = item;
                // mSelectedTemplateItem.setSelected(true);
                buildLayout(mTemplateItemList.get(position), true, holder, position);

            });

            boolean isSubscribed = AdsPrefs.getBoolean(mContext, AdsPrefs.IS_SUBSCRIBED);
            if (mTemplateItemList.get(position).isLocked() && !isSubscribed) {
                if (mTemplateItemList.get(position).getAdCount() >= 5) {
                    holder.layoutLi.setVisibility(View.GONE);
                    holder.layoutPremium.setVisibility(View.VISIBLE);
                    holder.tvAdCount.setVisibility(View.GONE);
                } else {
                    holder.layoutLi.setVisibility(View.VISIBLE);
                    holder.layoutPremium.setVisibility(View.GONE);
                    holder.tvAdCount.setVisibility(View.VISIBLE);
                }
                if (mTemplateItemList.get(position).getAdCount() > 1 && !isSubscribed) {
                    holder.tvAdCount.setText(String.valueOf(mTemplateItemList.get(position).getAdCount()));
                } else {
                    holder.tvAdCount.setVisibility(View.GONE);
                }
            } else if (mTemplateItemList.get(position).isPremium() && !isSubscribed) {
                holder.layoutLi.setVisibility(View.GONE);
                holder.layoutPremium.setVisibility(View.VISIBLE);
            } else {
                holder.layoutLi.setVisibility(View.GONE);
                holder.layoutPremium.setVisibility(View.GONE);
            }

        /*String strPath = mTemplateItemList.get(position).getPreview().replace("assets://", "file:///android_asset/");
        Glide.with(mContext).load(strPath).into(new CustomTarget<Drawable>() {
            @Override
            public void onResourceReady(@NonNull Drawable resource, @Nullable Transition<? super Drawable> transition) {
                holder.imgForeground.setImageDrawable(resource);
                // holder.imgForeground.setVisibility(View.VISIBLE);
                holder.progressContent.setVisibility(View.GONE);

                if (mTemplateItemList.get(position).isLocked()) {
                    holder.layoutLock.setVisibility(View.VISIBLE);
                    holder.layoutPremium.setVisibility(View.GONE);
                    holder.tvAdCount.setVisibility(View.VISIBLE);
                    if (mTemplateItemList.get(position).getAdCount() > 1) {
                        holder.tvAdCount.setText(String.valueOf(mTemplateItemList.get(position).getAdCount()));
                    } else {
                        holder.tvAdCount.setVisibility(View.GONE);
                    }
                } else if (mTemplateItemList.get(position).isPremium()) {
                    holder.layoutLock.setVisibility(View.GONE);
                    holder.layoutPremium.setVisibility(View.VISIBLE);
                } else {
                    holder.layoutLock.setVisibility(View.GONE);
                    holder.layoutPremium.setVisibility(View.GONE);
                }
            }

            @Override
            public void onLoadCleared(@Nullable Drawable placeholder) {
                holder.imgForeground.setVisibility(View.VISIBLE);
                holder.progressContent.setVisibility(View.GONE);
            }
        });*/

        holder.mConstraintClickable.setOnClickListener(v -> {
                    mTemplateItemList.get(position).setTemplateLoaded(true);
                    onItemSelectedListner.onItemClick(position, mTemplateItemList.get(position));
                }
        );
    }


    private void buildLayout(TemplateItem item, boolean isAspectRatio, MyViewholder holder, int pos) {
        if (isAspectRatio) {
            holder.mainContainer.post(() -> {
                mFramePhotoLayout = new FramePhotoLayout(mContext, item.getPhotoItemList());
                mFramePhotoLayout.setQuickActionClickListener(this);
                mFramePhotoLayout.setEnabled(false);
                mFramePhotoLayout.setBackgroundColor(ContextCompat.getColor(mContext, R.color.colorSettingText));

                if (viewHeight == 0 || viewWidth == 0) {
                    viewWidth = holder.mContainerLayout.getWidth();
                    viewHeight = holder.mContainerLayout.getHeight();
                }

                mOutputScale = ImageUtils.calculateOutputScaleFactor(viewWidth, viewHeight);
                mFramePhotoLayout.build(viewWidth, viewHeight, mOutputScale, mSpace, mCorner);

                ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams(viewWidth, viewHeight);
                params.startToStart = mFramePhotoLayout.getId();
                params.topToTop = mFramePhotoLayout.getTop();
                params.bottomToBottom = mFramePhotoLayout.getTop();
                params.endToEnd = mFramePhotoLayout.getTop();
                holder.mContainerLayout.removeAllViews();
                holder.mContainerLayout.addView(mFramePhotoLayout, params);


                ConstraintLayout.LayoutParams params1 = (ConstraintLayout.LayoutParams) holder.mainContainer.getLayoutParams();
                params1.width = viewWidth;
                params1.height = viewHeight;
                holder.mainContainer.setLayoutParams(params1);

                Log.d("1235689", "buildLayout: " + holder.mainContainer.getWidth() + "  " + holder.mainContainer.getHeight() + "  " + viewWidth + "  " + viewHeight);

                holder.progressContent.setVisibility(View.GONE);
            });
        }
    }

    private void changeRatio(String ratio, MyViewholder viewholder) {
        viewholder.mainContainer.post(() -> {

            if (!ratio.toLowerCase().equals("full")) {
                String[] ratioArray = ratio.split(" ");

                int width = getScreenWidth();
                int height = viewholder.mContainerLayout.getHeight();

                int outWidth = width;
                int outHeight = height;

                int ratioX = Integer.parseInt(ratioArray[0]);
                int ratioY = Integer.parseInt(ratioArray[ratioArray.length - 1]);

                float collageRatio = (float) ratioY / (float) ratioX;

                int h, w;
                if (ratioX > ratioY) {
                    int temp = mMainWidth / ratioX;
                    h = temp * ratioY;
                    w = mMainWidth;
                } else if (ratioY > ratioX) {
                    int temp = mMainHeight / ratioY;
                    w = temp * ratioX;
                    h = mMainHeight;
                } else {
                    h = w = mMainWidth;

                }


                outHeight = Math.round(width * collageRatio);
                //outHeight = Math
                viewWidth = w;
                viewHeight = h;

            } else {
                viewWidth = mMainWidth;
                viewHeight = mMainHeight;
            }
            // buildLayout(mTemplateItemList.get(pos), true, viewholder, pos);
        });
    }

    public int getScreenWidth() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((Activity) mContext).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int width = displayMetrics.widthPixels;
        return width;
    }

    @Override
    public void onImageClick(FrameImageView v, int photoPosition) {
//        Toast.makeText(mContext, "LoL", Toast.LENGTH_SHORT).show();
    }


    public interface OnItemSelectedListner {
        void onItemClick(int position, TemplateItem imagesItem);
    }

    @Override
    public int getItemCount() {
        return mTemplateItemList.size();
    }

    class MyViewholder extends RecyclerView.ViewHolder {
        ImageView imgForeground, imgBack;
        ProgressBar progressContent;
        LinearLayout layoutLi;
        RelativeLayout layoutPremium;
        TextView tvAdCount;
        ConstraintLayout mContainerLayout, mainContainer, mConstraintClickable;

        public MyViewholder(@NonNull View itemView) {
            super(itemView);
            imgForeground = itemView.findViewById(R.id.imgForeground);
            imgBack = itemView.findViewById(R.id.imgBack);
            progressContent = itemView.findViewById(R.id.progressContent);
            layoutLi = itemView.findViewById(R.id.layoutLi);
            layoutPremium = itemView.findViewById(R.id.layoutPremium);
            tvAdCount = itemView.findViewById(R.id.tvAdCount);
            mContainerLayout = itemView.findViewById(R.id.containerLayout1);
            mainContainer = itemView.findViewById(R.id.mainContainer1);
            mConstraintClickable = itemView.findViewById(R.id.constraintClickable);
        }
    }
}
