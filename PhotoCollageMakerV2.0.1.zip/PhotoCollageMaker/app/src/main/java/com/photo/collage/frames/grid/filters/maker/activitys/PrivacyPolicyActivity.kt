package com.photo.collage.frames.grid.filters.maker.activitys

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import com.photo.collage.frames.grid.filters.maker.R

class PrivacyPolicyActivity : AppCompatActivity() {
    private var mPrivacyPolicyActivity:PrivacyPolicyActivity?=null

    private var mWebview: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_privacy_policy)
        mPrivacyPolicyActivity = this@PrivacyPolicyActivity

        mWebview = findViewById(R.id.webView)

        mWebview!!.settings.javaScriptEnabled = true // enable javascript

        mWebview!!.webViewClient = object : WebViewClient() {
            override fun onReceivedError(view: WebView, errorCode: Int, description: String, failingUrl: String) {
                Toast.makeText(mPrivacyPolicyActivity, description, Toast.LENGTH_SHORT).show()
            }
        }
        mWebview!!.loadUrl("https://agneshpipaliya.blogspot.com/2019/03/image-crop-n-wallpaper-changer.html")
    }
}