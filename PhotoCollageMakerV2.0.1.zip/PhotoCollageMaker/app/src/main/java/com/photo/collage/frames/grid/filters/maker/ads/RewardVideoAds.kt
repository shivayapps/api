package com.photo.collage.frames.grid.filters.maker.ads

import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.photo.collage.frames.grid.filters.maker.R

class RewardVideoAds {

    val TAG = "Ads_123"

    companion object {

        var rewardedAd: RewardedAd? = null
        var rewardedAd1: RewardedAd? = null

        var instence: RewardVideoAds? = null
            get() {
                if (field == null) {
                    field = RewardVideoAds()
                }
                return field
            }
    }

    fun loadVideoAdMain(context: Context): RewardedAd? {
        var reward: RewardedAd? = null
        if (rewardedAd != null && rewardedAd?.isLoaded!!) {
            // return rewardedAd!!
            reward = rewardedAd!!
        } else {
            loadRewardVideoAd(context)
        }
        if (rewardedAd1 != null && rewardedAd1?.isLoaded!!) {
            //return rewardedAd1!!
            reward = rewardedAd1!!
        } else {
            loadRewardVideoAd1(context)
        }
        return reward
    }


    fun loadRewardVideoAd(context: Context) {
        if (rewardedAd != null && rewardedAd?.isLoaded!!) {
            return
        }

        val rewardedAdId = context.resources.getString(R.string.rewarded_ad_id)

        rewardedAd = RewardedAd(
                context,
                rewardedAdId
        )
        val adLoadCallback: RewardedAdLoadCallback = object : RewardedAdLoadCallback() {
            override fun onRewardedAdLoaded() {
                Log.e("hjdasjajsd=====>", "loaded 0")
            }

            override fun onRewardedAdFailedToLoad(errorCode: Int) {
                /// loadRewardVideoAd(context)
                Log.e("hjdasjajsd=====>", "falied 0  $errorCode")
            }
        }
        rewardedAd?.loadAd(AdRequest.Builder().build(), adLoadCallback)
    }

    fun loadRewardVideoAd1(context: Context) {
        if (rewardedAd1 != null && rewardedAd1?.isLoaded!!) {
            return
        }

        val rewardedAdId = context.resources.getString(R.string.rewarded_ad_id)

        rewardedAd1 = RewardedAd(
                context,
                rewardedAdId
        )
        val adLoadCallback: RewardedAdLoadCallback = object : RewardedAdLoadCallback() {
            override fun onRewardedAdLoaded() {
                Log.e("hjdasjajsd=====>", "loaded 1")
            }

            override fun onRewardedAdFailedToLoad(errorCode: Int) {
                //  loadRewardVideoAd1(context)
                Log.e("hjdasjajsd=====>", "failed 1 ${errorCode}")
            }
        }
        rewardedAd1?.loadAd(AdRequest.Builder().build(), adLoadCallback)
    }
}