package com.photo.collage.frames.grid.filters.maker.model;

import android.graphics.Typeface;
import android.widget.TextView;

public class TextModel {

    private TextView textView;
    private int textSize;
    private int padding;
    private int color;
    private int backgroundColor;
    private int cornerRadius;
    private Typeface typeface;
    private String text;

    public TextModel() {
    }

    public TextModel(TextView textView, int textSize, int padding, int color, int backgroundColor, int cornerRadius, Typeface typeface, String text) {
        this.textView = textView;
        this.textSize = textSize;
        this.padding = padding;
        this.color = color;
        this.backgroundColor = backgroundColor;
        this.cornerRadius = cornerRadius;
        this.typeface = typeface;
        this.text = text;
    }

    public TextView getTextView() {
        return textView;
    }

    public void setTextView(TextView textView) {
        this.textView = textView;
    }

    public int getTextSize() {
        return textSize;
    }

    public void setTextSize(int textSize) {
        this.textSize = textSize;
    }

    public int getPadding() {
        return padding;
    }

    public void setPadding(int padding) {
        this.padding = padding;
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public int getBackgroundColor() {
        return backgroundColor;
    }

    public void setBackgroundColor(int backgroundColor) {
        this.backgroundColor = backgroundColor;
    }

    public int getCornerRadius() {
        return cornerRadius;
    }

    public void setCornerRadius(int cornerRadius) {
        this.cornerRadius = cornerRadius;
    }

    public Typeface getTypeface() {
        return typeface;
    }

    public void setTypeface(Typeface typeface) {
        this.typeface = typeface;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
