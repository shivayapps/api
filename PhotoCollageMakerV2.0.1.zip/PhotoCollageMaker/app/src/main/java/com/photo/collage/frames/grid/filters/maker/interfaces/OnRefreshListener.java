package com.photo.collage.frames.grid.filters.maker.interfaces;

import com.photo.collage.frames.grid.filters.maker.model.PhotoModel;

public interface OnRefreshListener {
    void onRefresh(PhotoModel photoModel);
}
