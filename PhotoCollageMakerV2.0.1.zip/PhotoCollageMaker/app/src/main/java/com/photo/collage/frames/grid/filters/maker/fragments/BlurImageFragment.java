package com.photo.collage.frames.grid.filters.maker.fragments;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.ItemTouchHelper;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.photo.collage.frames.grid.filters.maker.comman.Constants;
import com.photo.collage.frames.grid.filters.maker.R;
import com.photo.collage.frames.grid.filters.maker.blurry.ExifUtils;
import com.photo.collage.frames.grid.filters.maker.blurry.GPUImageFilterTools;
import com.photo.collage.frames.grid.filters.maker.blurry.RadialBlur;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import jp.co.cyberagent.android.gpuimage.GPUImage;
import jp.co.cyberagent.android.gpuimage.filter.GPUImageBoxBlurFilter;
import jp.co.cyberagent.android.gpuimage.filter.GPUImageGaussianBlurFilter;
import jp.co.cyberagent.android.gpuimage.filter.GPUImagePixelationFilter;

/*
import jp.co.cyberagent.android.gpuimage.GPUImage;
import jp.co.cyberagent.android.gpuimage.filter.GPUImageBoxBlurFilter;
import jp.co.cyberagent.android.gpuimage.filter.GPUImagePixelationFilter;
*/

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the

 * to handle interaction events.
 * Use the {@link BlurImageFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class BlurImageFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private static final String TAG = "BlurImageFragment";

    // TODO: Rename and change types of parameters

    private Context context;

    private String mImagePath;
    private ImageView imgMain;
    private ImageView imgMainBack;
    private SeekBar seekbarRadius;
    private LinearLayout btnBox,btnGaussian,btnPixel,btnMotion,btnLine;
    private ImageView imgBox,imgGaussian,imgPixel,imgMotion,imgLine;
    private Bitmap effectBitmap;
    private Bitmap mBitmap,mTemp;

  //  private OnFragmentInteractionListener mListener;

    public BlurImageFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment BlurImageFragment.
     */
    // TODO: Rename and change types and number of parameters

    public static BlurImageFragment newInstance(String uri) {
        BlurImageFragment fragment = new BlurImageFragment();
        Bundle args = new Bundle();
        args.putString("URI", uri);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mImagePath = getArguments().getString("PATH");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_blur_image, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        context = getContext();
        bindViews(view);

        if (mImagePath!=null){
            Glide.with(this).asBitmap().load(mImagePath).into(new CustomTarget<Bitmap>() {
                @Override
                public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                    imgMainBack.setImageBitmap(resource);
                    imgMain.setImageBitmap(resource);
                    imgGaussian.setImageBitmap(resource);
                    imgPixel.setImageBitmap(resource);
                    imgLine.setImageBitmap(resource);
                    imgMotion.setImageBitmap(resource);
                    imgBox.setImageBitmap(resource);
                    mBitmap=resource;
                    makeBoxblur();
                    //setBottomImages();
                }

                @Override
                public void onLoadCleared(@Nullable Drawable placeholder) {

                }
            });

        }

        imgMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        seekbarRadius.setMax(25);
        seekbarRadius.setProgress(25);
        seekbarRadius.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                imgMain.setAlpha((float) seekbarRadius.getProgress()/25);
                Log.d("456456456", "onProgressChanged: "+i+"  "+i/25+"  "+imgMain.getAlpha());
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


    }

    private void setBottomImages() {

        new AsyncTask<Void, Void, Void>(){

            @Override
            protected Void doInBackground(Void... voids) {

                Bitmap bitmap = Bitmap.createScaledBitmap(mBitmap, 50, 50, false);

                mTemp = ExifUtils.fastblur1(bitmap, 1.0f, 60);
                getActivity().runOnUiThread(() ->{
                    imgGaussian.setImageBitmap(mTemp);
                });

                mTemp.recycle();
                mTemp = null;
                mTemp = pxlrBlur(bitmap);
                getActivity().runOnUiThread(() ->{
                    imgPixel.setImageBitmap(mTemp);
                });

                mTemp.recycle();
                mTemp = null;
                mTemp =boxBlur(bitmap);
                getActivity().runOnUiThread(() ->{
                    imgBox.setImageBitmap(mTemp);
                });

                mTemp.recycle();
                mTemp = null;
                mTemp = gaussinBlur(bitmap);
                getActivity().runOnUiThread(() ->{
                    imgLine.setImageBitmap(mTemp);
                });

                mTemp.recycle();
                mTemp = null;
                mTemp = RadialBlur.doRadialBlur(bitmap, (float) (bitmap.getWidth() / 2), (float) (bitmap.getHeight() / 2), 0.02f);
                getActivity().runOnUiThread(() ->{
                    imgMotion.setImageBitmap(mTemp);
                });



                return null;
            }
        }.execute();
    }

    private void bindViews(View view) {
        btnBox=view.findViewById(R.id.btnBox);
        btnBox.setOnClickListener(listener);
        btnPixel=view.findViewById(R.id.btnPixel);
        btnPixel.setOnClickListener(listener);
        btnLine=view.findViewById(R.id.btnLine);
        btnLine.setOnClickListener(listener);
        btnGaussian=view.findViewById(R.id.btnGaussin);
        btnGaussian.setOnClickListener(listener);
        btnMotion=view.findViewById(R.id.btnMotion);
        btnMotion.setOnClickListener(listener);
        imgMain=view.findViewById(R.id.imgMain);
        seekbarRadius=view.findViewById(R.id.seekbarRadius);
        imgMainBack=view.findViewById(R.id.imgMainBack);

        imgBox=view.findViewById(R.id.imgBox);
        imgPixel=view.findViewById(R.id.imgPixel);
        imgLine=view.findViewById(R.id.imgLine);
        imgMotion=view.findViewById(R.id.imgMotion);
        imgGaussian=view.findViewById(R.id.imgGaussin);
    }

    private final View.OnClickListener listener=new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            switch (view.getId()){
                case R.id.btnBox:
                    makeBoxblur();
                    break;
                case R.id.btnPixel:
                    makePixelblur();
                    break;
                case R.id.btnLine:
                    makeLineblur();
                    break;
                case R.id.btnGaussin:
                    makeGaussinblur();
                    break;
                case R.id.btnMotion:
                    makeMotionblur();
                    break;
            }
        }
    };

    private void makeMotionblur() {
        btnBox.setBackgroundResource(0);
        btnPixel.setBackgroundResource(0);
        btnLine.setBackgroundResource(0);
        btnGaussian.setBackgroundResource(0);
        btnMotion.setBackgroundResource(R.drawable.rectangle_shape);

        new AsyncTask<Void, Void, Bitmap>() {

            @Override
            protected Bitmap doInBackground(Void... voids) {

                effectBitmap = RadialBlur.doRadialBlur(mBitmap, (float) (mBitmap.getWidth() / 2), (float) (mBitmap.getHeight() / 2), 0.02f);

                return effectBitmap;
            }

            @Override
            protected void onPostExecute(Bitmap bitmap) {
                super.onPostExecute(bitmap);
                imgMain.setImageBitmap(bitmap);
            }
        }.execute();
        //imgMain.setImageBitmap(effectBitmap);
    }

    private void makeGaussinblur() {
        btnBox.setBackgroundResource(0);
        btnPixel.setBackgroundResource(0);
        btnLine.setBackgroundResource(0);
        btnGaussian.setBackgroundResource(R.drawable.rectangle_shape);
        btnMotion.setBackgroundResource(0);

        effectBitmap=mBitmap.copy(mBitmap.getConfig(),true);

        new AsyncTask<Void, Void, Bitmap>() {

            @Override
            protected Bitmap doInBackground(Void... voids) {

                effectBitmap = ExifUtils.fastblur1(effectBitmap, 1.0f, 60);
                return effectBitmap;
            }

            @Override
            protected void onPostExecute(Bitmap bitmap) {
                super.onPostExecute(bitmap);
                imgMain.setImageBitmap(bitmap);
            }
        }.execute();

       // imgMain.setImageBitmap(effectBitmap);
    }

    private void makeLineblur() {
        btnBox.setBackgroundResource(0);
        btnPixel.setBackgroundResource(0);
        btnLine.setBackgroundResource(R.drawable.rectangle_shape);
        btnGaussian.setBackgroundResource(0);
        btnMotion.setBackgroundResource(0);

        new AsyncTask<Void, Void, Bitmap>() {

            @Override
            protected Bitmap doInBackground(Void... voids) {

                effectBitmap = gaussinBlur(mBitmap);
                return effectBitmap;
            }

            @Override
            protected void onPostExecute(Bitmap bitmap) {
                super.onPostExecute(bitmap);
                imgMain.setImageBitmap(bitmap);
            }
        }.execute();

    }

    private void makePixelblur() {
        btnBox.setBackgroundResource(0);
        btnPixel.setBackgroundResource(R.drawable.rectangle_shape);
        btnLine.setBackgroundResource(0);
        btnGaussian.setBackgroundResource(0);
        btnMotion.setBackgroundResource(0);

        new AsyncTask<Void, Void, Bitmap>() {

            @Override
            protected Bitmap doInBackground(Void... voids) {
                effectBitmap = pxlrBlur(mBitmap);
                return effectBitmap;
            }

            @Override
            protected void onPostExecute(Bitmap bitmap) {
                super.onPostExecute(bitmap);
                imgMain.setImageBitmap(bitmap);
            }
        }.execute();


    }

    private void makeBoxblur() {

        btnBox.setBackgroundResource(R.drawable.rectangle_shape);
        btnPixel.setBackgroundResource(0);
        btnLine.setBackgroundResource(0);
        btnGaussian.setBackgroundResource(0);
        btnMotion.setBackgroundResource(0);

        new AsyncTask<Void, Void, Bitmap>() {

            @Override
            protected Bitmap doInBackground(Void... voids) {
                effectBitmap=boxBlur(mBitmap);
                return effectBitmap;
            }

            @Override
            protected void onPostExecute(Bitmap bitmap) {
                super.onPostExecute(bitmap);
                imgMain.setImageBitmap(bitmap);
            }
        }.execute();


    }

    public Bitmap pxlrBlur(Bitmap bitmap) {

        GPUImage gPUImage = new GPUImage(context);
        GPUImagePixelationFilter gPUImagePixelationFilter = new GPUImagePixelationFilter();
        gPUImage.setFilter(gPUImagePixelationFilter);
        new GPUImageFilterTools.FilterAdjuster(gPUImagePixelationFilter).adjust(10);
        gPUImage.requestRender();
        return gPUImage.getBitmapWithFilterApplied(bitmap);

    }

    public Bitmap gaussinBlur(Bitmap bitmap) {
        GPUImage gPUImage = new GPUImage(context);
        GPUImageGaussianBlurFilter gPUImageGaussianBlurFilter = new GPUImageGaussianBlurFilter();
        gPUImage.setFilter(gPUImageGaussianBlurFilter);
        new GPUImageFilterTools.FilterAdjuster(gPUImageGaussianBlurFilter).adjust(100);
        gPUImage.requestRender();
        return gPUImage.getBitmapWithFilterApplied(bitmap);
    }

    public Bitmap boxBlur(Bitmap bitmap) {
        GPUImage gPUImage = new GPUImage(context);
        GPUImageBoxBlurFilter gPUImageBoxBlurFilter = new GPUImageBoxBlurFilter();
        gPUImage.setFilter(gPUImageBoxBlurFilter);
        new GPUImageFilterTools.FilterAdjuster(gPUImageBoxBlurFilter).adjust(ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION);
        gPUImage.requestRender();
        return gPUImage.getBitmapWithFilterApplied(bitmap);
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
      /*  if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }*/
    }

    public void saveImage(){
        Bitmap saveBitmap =generateBitmap();
        Log.d(TAG, "onClick: blur-bitmap"+saveBitmap);
        if (saveBitmap!=null){
            storeImage(saveBitmap);
        }
    }

    private Bitmap generateBitmap(){
        if (imgMain.getWidth() > 0) {
            Bitmap bitmap = Bitmap.createBitmap(imgMain.getWidth(), imgMain.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            //   mContainerLayout.draw(canvas);
            imgMainBack.draw(canvas);
            imgMain.draw(canvas);
            return bitmap;
        } else {
            return null;
        }
    }

    private void storeImage(Bitmap image) {
        Constants.mBlurBitmap=image;
        File pictureFile = getOutputMediaFile();
        if (pictureFile == null) {
            Log.d(TAG,
                    "Error creating media file, check storage permissions: ");// e.getMessage());
            return;
        }
        try {
            FileOutputStream fos = new FileOutputStream(pictureFile);
            image.compress(Bitmap.CompressFormat.PNG, 90, fos);
            fos.close();
            Constants.blurImagePath=pictureFile.getAbsolutePath();
            getActivity().onBackPressed();
        } catch (FileNotFoundException e) {
            Log.d(TAG, "File not found: " + e.getMessage());
        } catch (IOException e) {
            Log.d(TAG, "Error accessing file: " + e.getMessage());
        }
    }

    private  File getOutputMediaFile(){
        File mediaStorageDir = new File(Environment.getExternalStorageDirectory()
                + "/Android/data/com.codetho.photocollage/Files/.myCroppedImage");

        if (! mediaStorageDir.exists()){
            if (! mediaStorageDir.mkdirs()){
                return null;
            }
        }
        String timeStamp = new SimpleDateFormat("ddMMyyyy_HHmm").format(new Date());
        File mediaFile;
        String mImageName="MI_"+ timeStamp +".jpg";
        Constants.croppedImagePath=mediaStorageDir.getPath() + File.separator + mImageName;
        mediaFile = new File(mediaStorageDir.getPath() + File.separator + mImageName);

        return mediaFile;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
       /* if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }*/
    }

    @Override
    public void onDetach() {
        super.onDetach();
        //mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
   /* public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }*/
}
