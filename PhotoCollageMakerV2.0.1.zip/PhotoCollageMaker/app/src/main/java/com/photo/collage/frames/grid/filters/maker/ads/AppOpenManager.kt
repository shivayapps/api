package com.photo.collage.frames.grid.filters.maker.ads

import android.app.Activity
import android.app.Application
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.ProcessLifecycleOwner
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.appopen.AppOpenAd
import com.photo.collage.frames.grid.filters.maker.PhotoCollageMakerApplication
import com.photo.collage.frames.grid.filters.maker.activitys.SplashScreen1
import com.photo.collage.frames.grid.filters.maker.utils.SharedPrefs
import java.util.*

class AppOpenManager : LifecycleObserver, Application.ActivityLifecycleCallbacks {

    private val LOG_TAG = "AppOpenManager"
    private var AD_UNIT_ID_TEST = "ca-app-pub-3940256099942544/1033173712"
    private var AD_UNIT_ID = "ca-app-pub-2033413118114270/5864979316"
    private var appOpenAd: AppOpenAd? = null

    private var loadTime: Long = 0

    private var loadCallback: AppOpenAd.AppOpenAdLoadCallback? = null

    private var myApplication: PhotoCollageMakerApplication? = null

    private var currentActivity: Activity? = null

    private var isShowingAd = false

    private var isInBackgorund = false
    public var isShare = false


    private var mOnOpenAppAdLoaded: OnOpenAppAdLoaded? = null

    private var mSharedPrefs: SharedPrefs? = null

    interface OnOpenAppAdLoaded {
        fun openAppAddLoaded()
    }


    enum class CallBackType {
        DISMISS,
        FAILED,
        ERROR
    }

    /** Constructor  */
    constructor(myApplication: Context?) {
        this.myApplication = myApplication as PhotoCollageMakerApplication?
        this.myApplication?.registerActivityLifecycleCallbacks(this)
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)
        fetchAd()
        //AD_UNIT_ID = AppIDs.instnace!!.getGoogleInterstitial(0)
        mSharedPrefs = SharedPrefs(myApplication)
    }


    fun setOnOpenAppAdLoaded(onOpenAppAdLoaded: OnOpenAppAdLoaded) {
        mOnOpenAppAdLoaded = onOpenAppAdLoaded
    }

    /** LifecycleObserver methods  */
    /*@OnLifecycleEvent(ON_START)
    fun onStart() {
        showAdIfAvailable()
        Log.d(LOG_TAG, "onStart")
    }*/

    /** Request an ad  */
    fun fetchAd() {
        // Have unused ad, no need to fetch another.
        Log.d(LOG_TAG, "fetchAd: ${isAdAvailable()}")
        if (isAdAvailable()) {
            return
        }
        loadCallback = object : AppOpenAd.AppOpenAdLoadCallback() {
            /**
             * Called when an app open ad has loaded.
             *
             * @param ad the loaded app open ad.
             */
            override fun onAppOpenAdLoaded(ad: AppOpenAd) {
                appOpenAd = ad
                loadTime = Date().time
                Log.d(LOG_TAG, "onAppOpenAdLoaded: $loadTime")
                mOnOpenAppAdLoaded?.openAppAddLoaded()
            }

            /**
             * Called when an app open ad has failed to load.
             *
             * @param loadAdError the error.
             */
            override fun onAppOpenAdFailedToLoad(loadAdError: LoadAdError?) {
                // Handle the error.
                Log.d(LOG_TAG, "onAppOpenAdFailedToLoad: ")
            }

        }

        val request = getAdRequest()
        Log.d(LOG_TAG, "fetchAd: ")
        AppOpenAd.load(
                myApplication, AD_UNIT_ID, request,
                AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, loadCallback)
    }

    /** Creates and returns ad request.  */
    private fun getAdRequest(): AdRequest? {
        return AdRequest.Builder().build()
    }

    /** Utility method that checks if ad exists and can be shown.  */
    fun isAdAvailable(): Boolean {
        return appOpenAd != null && wasLoadTimeLessThanNHoursAgo(4)
    }

    /** Shows the ad if one isn't already showing.  */
    fun showAdIfAvailable(callback: (CallBackType) -> Unit = {}) {
        // Only show ad if there is not already an app open ad currently showing
        // and an ad is available.
        Log.d(LOG_TAG, "showAdIfAvailable: $isShowingAd ${isAdAvailable()}")
        if (!isShowingAd && isAdAvailable()) {
            Log.d(LOG_TAG, "Will show ad.")
            try {
                val fullScreenContentCallback: FullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
                        // Set the reference to null so isAdAvailable() returns false.
                        appOpenAd = null
                        isShowingAd = false
                        callback(CallBackType.DISMISS)
                        //fetchAd()
                    }

                    override fun onAdFailedToShowFullScreenContent(adError: AdError?) {
                        callback(CallBackType.FAILED)
                    }

                    override fun onAdShowedFullScreenContent() {
                        isShowingAd = true
                    }
                }
                appOpenAd?.show(currentActivity, fullScreenContentCallback)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        } else {
            Log.d(LOG_TAG, "Can not show ad.")
            callback(CallBackType.ERROR)
            //fetchAd()
        }
    }

    /** Utility method to check if ad was loaded more than n hours ago.  */
    private fun wasLoadTimeLessThanNHoursAgo(numHours: Long): Boolean {
        val dateDifference = Date().time - loadTime
        val numMilliSecondsPerHour: Long = 3600000
        return dateDifference < numMilliSecondsPerHour * numHours
    }


    override fun onActivityPaused(activity: Activity) {
        Log.e("qwerty1234","onActivityPaused")
    }

    override fun onActivityStarted(activity: Activity) {
        currentActivity = activity;
        Log.e("qwerty1234","onActivityStarted")
    }

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {
        Log.e("qwerty1234","onActivitySaveInstanceState")
    }

    override fun onActivityStopped(activity: Activity) {
        Log.e("qwerty1234","onActivityStopped")
        isInBackgorund = true
       /* if(myApplication?.isAppOnForeground(activity).toString() == "true"){
            mSharedPrefs?.saveOpenAppAdShownCount()
        }*/
       // Toast.makeText(activity, myApplication?.isAppOnForeground(activity).toString(), Toast.LENGTH_SHORT).show()
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
        Log.e("qwerty1234","onActivityCreated")
    }

    override fun onActivityResumed(activity: Activity) {
        currentActivity = activity
        /*if (mSharedPrefs!!.getOpenAppAdShown() && isInBackgorund || isShare) {
            showAdIfAvailable() {
                when (it) {
                    AppOpenManager.CallBackType.DISMISS -> {
                        fetchAd()
                    }
                    AppOpenManager.CallBackType.FAILED -> {
                    }
                    AppOpenManager.CallBackType.ERROR -> {
                    }
                }
            }
        }
        isInBackgorund = false*/

        Log.e("qwerty1234","onActivityResumed")
    }

    override fun onActivityDestroyed(activity: Activity) {
        currentActivity = null
        Log.e("qwerty1234","onActivityDestroyed")
    }
}