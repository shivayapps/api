package com.photo.collage.frames.grid.filters.maker.fragments

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.media.MediaScannerConnection
import android.os.AsyncTask
import android.os.Bundle
import android.os.Environment
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.photo.collage.frames.grid.filters.maker.R
import com.photo.collage.frames.grid.filters.maker.activitys.MyCreationActivity
import com.photo.collage.frames.grid.filters.maker.adepters.CollageImageListAdapter
import com.photo.collage.frames.grid.filters.maker.comman.GridSpacingItemDecoration
import com.photo.collage.frames.grid.filters.maker.model.SavedImageModel
import com.photo.collage.frames.grid.filters.maker.utils.showToast
import java.io.File
import java.lang.Exception
import java.util.*
import kotlin.collections.ArrayList

class ScrapbookCreationFragment : Fragment, CollageImageListAdapter.OnLongDeleteShow {

    private var mRecyclerCollageImages: RecyclerView? = null
    private var mProgressCollageImage: ProgressBar? = null
    private var mConstraintImagesNotFound: ConstraintLayout? = null
    private var mCollageImageLists: ArrayList<SavedImageModel> = ArrayList()
    private var mImageListAdapter: CollageImageListAdapter? = null

    private var mActivity: MyCreationActivity? = null

    constructor() : super()
    constructor(mActivity: MyCreationActivity?) : super() {
        this.mActivity = mActivity
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_scrapbook_creation, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initView(view)

        loadSavedImages()

        mRecyclerCollageImages!!.addItemDecoration(
                GridSpacingItemDecoration(
                        3, resources.getDimension(R.dimen._9sdp).toInt(), true
                )
        )
    }

    private fun initView(view: View) {
        mRecyclerCollageImages = view.findViewById(R.id.recyclerCollageImages)
        mProgressCollageImage = view.findViewById(R.id.progressCollageImage)
        mConstraintImagesNotFound = view.findViewById(R.id.constraintImagesNotFound)
    }

    fun loadSavedImages() {
        MyCreationActivity.mImgBtnDelete!!.alpha = 0.5f
        //MyCreationActivity.mImgBtnDelete!!.isEnabled = false
        mCollageImageLists.clear()
        FilesTask().execute()
    }

    private fun readPhotoCollageFolder() {
        mCollageImageLists.clear()
        val mediaStorageDir = File(
                Environment.getExternalStorageDirectory().absolutePath, getString(R.string.app_name))

        val fileList: ArrayList<SavedImageModel> = ArrayList()
        var listAllFiles = mediaStorageDir.listFiles()
        Log.e("downloadFilePath", mediaStorageDir.toString())

        if (listAllFiles != null && listAllFiles.size > 0) {
            Arrays.sort(listAllFiles) { a, b -> b.lastModified().compareTo(a.lastModified()) }
            for (currentFile in listAllFiles) {
                if (currentFile.name.contains("scrapbook")) {
                    Log.e("downloadFilePath", currentFile.getAbsolutePath())
                    Log.e("downloadFileName", currentFile.getName())
                    fileList.add(SavedImageModel(currentFile.absoluteFile, false, false))
                }
            }
            Log.w("fileList", "" + fileList.size)
        }

        mCollageImageLists = fileList

    }

    fun callOnBackPressedFromActivity() {
        if (mCollageImageLists.size != 0) {
            if (mImageListAdapter!!.isLongPressClicked()) {
                mImageListAdapter!!.makeAllVisible(false)
            } else {
                mActivity!!.finish()
            }
        } else {
            mActivity!!.finish()
        }
    }

    fun deleteSelectedImages() {
        if (mImageListAdapter!!.getTrueDeleteImageList().size != 0) {

            val deleteDialog = Dialog(mActivity!!)
            deleteDialog.setContentView(R.layout.dialog_delete)
            deleteDialog.getWindow()!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            deleteDialog.window!!.setLayout(ConstraintLayout.LayoutParams.MATCH_PARENT, ConstraintLayout.LayoutParams.WRAP_CONTENT)
            val btnCancel = deleteDialog.findViewById<TextView>(R.id.btnCancel)
            val btnDelete = deleteDialog.findViewById<TextView>(R.id.btnDelete)

            btnCancel.setOnClickListener {
                deleteDialog.cancel()
            }
            btnDelete.setOnClickListener {
                deleteDialog.dismiss()
                deleteImages()
            }
            if (!mActivity!!.isFinishing) {
                deleteDialog.show()
            }
        } else {
            mActivity!!.showToast("First select image to delete")
        }
    }

    private fun deleteImages() {
        var mDeleteFiles: ArrayList<SavedImageModel> = ArrayList()
        mDeleteFiles = mImageListAdapter!!.getDeleteImageList()
        for (i in mDeleteFiles.indices) {
            if (mDeleteFiles[i].isSelected) {
                if (mDeleteFiles[i].file.exists()) {
                    if (mDeleteFiles[i].file.delete()) {

                        MediaScannerConnection.scanFile(
                                mActivity,
                                arrayOf(mDeleteFiles[i].file.absolutePath),
                                null
                        ) { path, uri ->
                            Log.i("ExternalStorage", "Scanned $path:")
                            Log.i("ExternalStorage", "-> uri=$uri")
                        }
                        //mImageListAdapter!!.refreshAdapter(i)
                        print("file Deleted :${mDeleteFiles[i].file}")
                    } else {
                        print("file not Deleted :${mDeleteFiles[i].file}")
                    }
                }
            }
        }
        mImageListAdapter!!.makeAllVisible(false)
        loadSavedImages()
    }

    val delImages:() -> Unit = {
        try {
            deleteSelectedImages()
        }catch (ex:Exception){

        }
    }

    inner class FilesTask : AsyncTask<String, String, String>() {
        override fun onPreExecute() {
            super.onPreExecute()
            mProgressCollageImage!!.visibility = View.VISIBLE
            mRecyclerCollageImages!!.visibility = View.GONE
        }

        override fun doInBackground(vararg p0: String?): String {
            readPhotoCollageFolder()
            return ""
        }

        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)
            mProgressCollageImage!!.visibility = View.GONE
            mRecyclerCollageImages!!.visibility = View.VISIBLE

            if (mCollageImageLists.size != 0) {
                mRecyclerCollageImages!!.visibility = View.VISIBLE
                mConstraintImagesNotFound!!.visibility = View.GONE

                mImageListAdapter = CollageImageListAdapter(mActivity, mCollageImageLists, this@ScrapbookCreationFragment)
                mRecyclerCollageImages!!.layoutManager = GridLayoutManager(context, 3)
                mRecyclerCollageImages!!.adapter = mImageListAdapter
            } else {
                mRecyclerCollageImages!!.visibility = View.GONE
                mConstraintImagesNotFound!!.visibility = View.VISIBLE
            }
        }

    }

    override fun OnDeleteShow(isPressed: Boolean) {
        if (isPressed) {
            MyCreationActivity.mImgBtnDelete!!.animate().alpha(1f)
            //MyCreationActivity.mImgBtnDelete!!.isEnabled = true

        } else {
            MyCreationActivity.mImgBtnDelete!!.animate().alpha(0.5f)
            //MyCreationActivity.mImgBtnDelete!!.isEnabled = false
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        (context as MyCreationActivity).delImages = delImages
    }
}