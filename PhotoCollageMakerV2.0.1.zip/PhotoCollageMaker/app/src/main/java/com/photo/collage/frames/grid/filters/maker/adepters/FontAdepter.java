package com.photo.collage.frames.grid.filters.maker.adepters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.photo.collage.frames.grid.filters.maker.R;
import com.photo.collage.frames.grid.filters.maker.utils.FontProvider;

import java.util.List;

public class FontAdepter extends RecyclerView.Adapter<FontAdepter.MyViewHolder> {

    private List<String> mFontNames;
    private Context mContext;
    private setOnItemClickListener mListener;
    private String mText;
    public int mLastPostion = 0;
    private String mSelectedItem = "";

    public interface setOnItemClickListener {
        void OnItemClicked(int position);
    }

    public FontAdepter(List<String> mFontNames, Context mContext, setOnItemClickListener mListener, String mText) {
        this.mFontNames = mFontNames;
        this.mContext = mContext;
        this.mListener = mListener;
        this.mText = mText;
    }

    @NonNull
    @Override
    public FontAdepter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(mContext).inflate(R.layout.layout_font_item, null));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, final int i) {

        FontProvider fontProvider = new FontProvider(mContext.getResources());
        myViewHolder.txtFont.setTypeface(fontProvider.getTypeface(mFontNames.get(i)));
        myViewHolder.txtFont.setText(mText);
        myViewHolder.selectedView.setVisibility(View.INVISIBLE);
        if (mLastPostion == i || mSelectedItem.equals(mFontNames.get(i))) {

            myViewHolder.selectedView.setVisibility(View.VISIBLE);
        }

        myViewHolder.txtFont.setOnClickListener(view -> {
            mListener.OnItemClicked(i);
            mLastPostion = i;
            this.mSelectedItem = "";
            notifyDataSetChanged();
        });

    }

    public void setSelectedItem(String mSelectedItem) {
        this.mSelectedItem = mSelectedItem;
        mLastPostion = -1;
        notifyDataSetChanged();
    }

    public void setText(String text) {
        mText = text;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return mFontNames.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        private TextView txtFont;
        private View selectedView;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            txtFont = itemView.findViewById(R.id.txtFont);
            selectedView = itemView.findViewById(R.id.selectedView);
        }
    }
}
