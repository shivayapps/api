package com.photo.collage.frames.grid.filters.maker.activitys

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.google.android.gms.ads.InterstitialAd
import com.photo.collage.frames.grid.filters.maker.PhotoCollageMakerApplication
import com.photo.collage.frames.grid.filters.maker.R
import com.photo.collage.frames.grid.filters.maker.ads.AppOpenManager

class SplashScreen1 : AppCompatActivity() {

    val TAG = "SplashScreen111"

    private var mHandler: Handler? = null
    private var mRunnable: Runnable? = null
    private var isInterstitialAdLoaded = false
    private var interstitial: InterstitialAd? = null
    private var mSharedPreferences: SharedPreferences? = null
    private var mEdit: SharedPreferences.Editor? = null
    private var mContext: Context? = null

    var appOpenManager: AppOpenManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)
        mContext = this
        initAction()

        appOpenManager = AppOpenManager(applicationContext)

    }

    private fun initAction() {
        /*val imageView = findViewById<ImageView>(R.id.splash_iv_Background)
        Glide.with(this).load(R.drawable.ic_bg_splash_2).placeholder(R.drawable.ic_bg_splash_2).into(imageView)*/
        mHandler = Handler()
        mRunnable = Runnable {
            if (!isFinishing) {
                loadOpenAppAd()
                /*interstitial = null
                val intent = Intent(this@SplashScreen1, MainActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()*/
            }
        }
        mSharedPreferences = getSharedPreferences("splash", Context.MODE_PRIVATE)
        mEdit = mSharedPreferences!!.edit()
        if (!mSharedPreferences!!.getBoolean("isShow", false)) {
            mEdit!!.putBoolean("isShow", true)
            mEdit!!.commit()
            mHandler!!.postDelayed(mRunnable, 3000)
        } else {
            //interstitial = InterstitialAdHelper.getInstance().load(mContext, this)
            mHandler!!.postDelayed(mRunnable, 8000)
        }

        /*appOpenManager?.setOnOpenAppAdLoaded(object : AppOpenManager.OnOpenAppAdLoaded {
            override fun openAppAddLoaded() {
                if (mSharedPreferences!!.getBoolean("isShow", false)) {
                    Log.d(TAG, "startMain: 12")
                    loadOpenAppAd()
                }
            }
        })*/
    }

    /*override fun onLoad() {
        isInterstitialAdLoaded = true
        if (interstitial != null && !isFinishing) {
            mHandler!!.removeCallbacks(mRunnable)
            interstitial!!.show()
        }
    }

    override fun onFailed() {
        isInterstitialAdLoaded = false
        //interstitial = InterstitialAdHelper.getInstance().load(mContext, this);
        mHandler!!.removeCallbacks(mRunnable)
        if (!isFinishing) {
            val intent = Intent(this@SplashScreen1, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }
    }

    override fun onClosed() {
        isInterstitialAdLoaded = false
        //interstitial = InterstitialAdHelper.getInstance().load(mContext, this);

        // perform your action
        mHandler!!.removeCallbacks(mRunnable)
        if (!isFinishing) {
            val intent = Intent(this@SplashScreen1, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }
    }*/

    private fun loadOpenAppAd() {
        if (mHandler != null) {
            mHandler!!.removeCallbacks(mRunnable)
        }

        appOpenManager!!.showAdIfAvailable {
            when (it) {
                AppOpenManager.CallBackType.DISMISS -> {
                    Log.d(TAG, "loadOpenAppAd: DISMISS")
                    openNextActivity()
                }
                AppOpenManager.CallBackType.FAILED -> {
                    Log.d(TAG, "loadOpenAppAd: FAILED")
                    openNextActivity()
                }
                AppOpenManager.CallBackType.ERROR -> {
                    Log.d(TAG, "loadOpenAppAd: ERROR")
                    openNextActivity()
                }
            }
        }
    }

    private fun openNextActivity() {
        if (!isFinishing) {
            Handler(Looper.getMainLooper()).postDelayed(Runnable {
                val intent = Intent(this@SplashScreen1, MainActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
            }, 50)
        }
    }
}