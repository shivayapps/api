package com.photo.collage.frames.grid.filters.maker.activitys;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.bumptech.glide.Glide;
import com.google.android.material.snackbar.Snackbar;
import com.photo.collage.frames.grid.filters.maker.BuildConfig;
import com.photo.collage.frames.grid.filters.maker.PhotoCollageMakerApplication;
import com.photo.collage.frames.grid.filters.maker.comman.Constants;
import com.photo.collage.frames.grid.filters.maker.R;
import com.photo.collage.frames.grid.filters.maker.fragments.FullScreenDialog;
import com.photo.collage.frames.grid.filters.maker.moreframes.sqlite_database.AdsPrefs;

import java.io.File;

public class ViewImageActivity extends AppCompatActivity {

    private static final String TAG = "ViewImageActivity";

    private String imagePath;
    private ImageView viewImage, ivViewImageFull;
    private ImageButton imgBtnHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_image);


        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        }


        initView();

        initListener();

        initAction();

    }

    private void initListener() {

        imgBtnHome.setOnClickListener(v -> {
            startActivity(new Intent(ViewImageActivity.this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP));
            finish();
        });

        ivViewImageFull.setOnClickListener(v -> {
            imagePath = Constants.path;
            FullScreenDialog dialog = new FullScreenDialog(imagePath, null);
            dialog.show(getSupportFragmentManager(), "ImageView");
        });
    }

    private void initAction() {
        Log.d(TAG, "onCreate: path " + Constants.path);
        imagePath = Constants.path;
        if (imagePath != null) {
            Glide.with(ViewImageActivity.this)
                    .load(imagePath)
                    .into(viewImage);
        }
    }

    private void initView() {
        viewImage = findViewById(R.id.full_image);
        ivViewImageFull = findViewById(R.id.ivViewImage);
        imgBtnHome = findViewById(R.id.imgBtnHome);
    }

    public void onclickBack(View view) {
        finish();
    }

    public void onClickShareFacebook(View view) {

        Intent intent = getPackageManager().getLaunchIntentForPackage("com.facebook.katana");
        if (intent != null) {

            Uri imageUri = FileProvider.getUriForFile(this, getPackageName() + ".provider", new File(imagePath));

            Intent sendIntent = new Intent(Intent.ACTION_VIEW);
            sendIntent.setType("image/*");
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_STREAM, imageUri);
            sendIntent.setPackage("com.facebook.katana");
            sendIntent.putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id=" + getPackageName());
            sendIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(sendIntent);
        } else {
            // bring user to the market to download the app.
            // or let them choose an app?
                /*intent = new Intent(Intent.ACTION_VIEW);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.setData(Uri.parse("https://play.google.com/store/apps/details?id=com.facebook.katana&hl=en"));
                startActivity(intent);*/
            //Toast.makeText(this, "Facebook have not been install.", Toast.LENGTH_SHORT).show();
            //Snackbar.make(findViewById(R.id.coordinatorLayout), "Facebook have not been install.", Snackbar.LENGTH_SHORT).show();
            showSnackBar("Facebook have not been install.");
        }

    }

    public void onClickShareInstagram(View view) {

        Intent intent = getPackageManager().getLaunchIntentForPackage("com.instagram.android");
        if (intent != null) {

            Uri imageUri = FileProvider.getUriForFile(this, getPackageName() + ".provider", new File(imagePath));

            Intent sendIntent = new Intent(Intent.ACTION_VIEW);
            sendIntent.setType("image/*");
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_STREAM, imageUri);
            sendIntent.setPackage("com.instagram.android");
            sendIntent.putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id=" + getPackageName());
            sendIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(sendIntent);
        } else {
            // bring user to the market to download the app.
            // or let them choose an app?
                /*intent = new Intent(Intent.ACTION_VIEW);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.setData(Uri.parse("https://play.google.com/store/apps/details?id=com.instagram.android&hl=en"));
                startActivity(intent);*/
            //Toast.makeText(this, "Instagram have not been install.", Toast.LENGTH_SHORT).show();
            //Snackbar.make(findViewById(R.id.coordinatorLayout),"Facebook have not been install.",Snackbar.LENGTH_SHORT).show();
            showSnackBar("Instagram have not been install.");
        }

    }

    public void showSnackBar(String msg) {
        Snackbar snackbar = Snackbar.make(findViewById(R.id.coordinatorLayout), msg, Snackbar.LENGTH_SHORT);
        View v = snackbar.getView();
        CoordinatorLayout.LayoutParams params = (CoordinatorLayout.LayoutParams) v.getLayoutParams();
        params.gravity = Gravity.BOTTOM;
        v.setPadding(0, 0, 0, 0);
        params.setMargins(0,0,0,0);
        params.width = CoordinatorLayout.LayoutParams.MATCH_PARENT;
        v.setLayoutParams(params);
        v.setBackgroundColor(Color.WHITE);
        TextView textView = v.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextColor(Color.parseColor("#282828"));
        snackbar.show();
    }

    public void onClickShareWhatsapp(View view) {

        Intent intent = getPackageManager().getLaunchIntentForPackage("com.whatsapp");
        if (intent != null) {

            Uri imageUri = FileProvider.getUriForFile(this, getPackageName() + ".provider", new File(imagePath));

            Intent sendIntent = new Intent(Intent.ACTION_VIEW);
            sendIntent.setType("image/*");
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_STREAM, imageUri);
            sendIntent.setPackage("com.whatsapp");
            sendIntent.putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id=" + getPackageName());
            sendIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

            startActivity(sendIntent);
        } else {
            // bring user to the market to download the app.
            // or let them choose an app?
               /* intent = new Intent(Intent.ACTION_VIEW);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.setData(Uri.parse("market://details?id=" + "com.whatsapp"));
                startActivity(intent);*/
            //Toast.makeText(this, "Whatsapp have not been install.", Toast.LENGTH_SHORT).show();

            showSnackBar("Whatsapp have not been install.");
        }

    }

    public void onClickShareOther(View view) {

        Uri uri = FileProvider.getUriForFile(ViewImageActivity.this, BuildConfig.APPLICATION_ID + ".provider", new File(imagePath));

        if (uri != null) {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("image/jpeg");
            intent.putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id=" + getPackageName());
            intent.putExtra(Intent.EXTRA_SUBJECT, "Collage Photo Maker");
            intent.putExtra(Intent.EXTRA_STREAM, uri);
            startActivity(Intent.createChooser(intent, "Share Image"));
        }

        if (!AdsPrefs.getBoolean(this, AdsPrefs.IS_SUBSCRIBED)) {
            PhotoCollageMakerApplication.Companion.getInstance1().getAppOpenManager().setShare(false);
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        PhotoCollageMakerApplication.Companion.getInstance1().getAppOpenManager().setShare(false);
    }
}
