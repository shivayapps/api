package com.photo.collage.frames.grid.filters.maker.model;

import java.io.Serializable;

public class PhotoModel implements Serializable {

    private String ImagePath;
    private String date;
    private String fulldate;
    private boolean isShowHeader;
    private int count;

    public PhotoModel(String imagePath, String date, String fulldate) {
        ImagePath = imagePath;
        this.date = date;
        this.fulldate = fulldate;
    }

    public PhotoModel(String imagePath, String date, String fulldate, boolean isShowHeader, int count) {
        ImagePath = imagePath;
        this.date = date;
        this.fulldate = fulldate;
        this.isShowHeader = isShowHeader;
        this.count = count;
    }

    public PhotoModel(boolean isShowHeader, String date) {
        this.isShowHeader = isShowHeader;
        this.date = date;
    }

    public void setShowHeader(boolean showHeader) {
        isShowHeader = showHeader;
    }

    public String getImagePath() {
        return ImagePath;
    }

    public void setImagePath(String imagePath) {
        ImagePath = imagePath;
    }



    public String getDate() {
        return date;
    }

    public String getFulldate() {
        return fulldate;
    }

    public boolean isShowHeader() {
        return isShowHeader;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
