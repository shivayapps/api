package com.photo.collage.frames.grid.filters.maker.adepters;

import android.app.Activity;
import android.content.Context;
import android.graphics.PorterDuff;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.photo.collage.frames.grid.filters.maker.R;
import com.photo.collage.frames.grid.filters.maker.model.TemplateItem;


import java.util.ArrayList;

import dauroi.photoeditor.utils.PhotoUtils;

public class HorizontalPreviewTemplateAdapter extends RecyclerView.Adapter<HorizontalPreviewTemplateAdapter.PreviewTemplateViewHolder> {
    public static class PreviewTemplateViewHolder extends RecyclerView.ViewHolder {
        private ImageView mImageView;
        private View mSelectedView;

        PreviewTemplateViewHolder(View itemView) {
            super(itemView);
            mImageView = (ImageView) itemView.findViewById(R.id.imageView);
            mSelectedView = itemView.findViewById(R.id.selectedView);
        }
    }

    public static interface OnPreviewTemplateClickListener {
        void onPreviewTemplateClick(TemplateItem item);
    }

    private ArrayList<TemplateItem> mTemplateItems;
    private OnPreviewTemplateClickListener mListener;
    private Context mContext;

    public HorizontalPreviewTemplateAdapter(Context context,ArrayList<TemplateItem> items, OnPreviewTemplateClickListener listener) {
        mTemplateItems = items;
        mListener = listener;
        mContext = context;
    }

    @Override
    public PreviewTemplateViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_preview_template_hor, parent, false);
        return new PreviewTemplateViewHolder(v);
    }

    @Override
    public void onBindViewHolder(PreviewTemplateViewHolder holder, final int position) {
        PhotoUtils.loadImageWithGlide(holder.mImageView.getContext(), holder.mImageView, mTemplateItems.get(position).getPreview());
        holder.mImageView.setColorFilter(ContextCompat.getColor(mContext,R.color.colorPrimary), PorterDuff.Mode.OVERLAY);
        if (mTemplateItems.get(position).isSelected()) {
            //holder.mSelectedView.setVisibility(View.VISIBLE);
            //holder.mImageView.setBackgroundResource(R.drawable.bg_select_item);
            holder.mImageView.setAlpha(1f);
        } else {
            //holder.mSelectedView.setVisibility(View.INVISIBLE);
            holder.mImageView.setBackgroundResource(android.R.color.transparent);
            holder.mImageView.setAlpha(0.6f);
        }

        holder.mImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mListener != null) {
                    mListener.onPreviewTemplateClick(mTemplateItems.get(position));
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return mTemplateItems.size();
    }
}
