package com.photo.collage.frames.grid.filters.maker.activitys

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.photo.collage.frames.grid.filters.maker.R
import com.photo.collage.frames.grid.filters.maker.fragments.AddTextFragment

class TestMainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_test_main)

        var list = assets.list("fonts/")

        Log.e("dsdwdaas",list!!.size.toString())

        val ft = supportFragmentManager.beginTransaction()
        ft.add(R.id.frmTextFragment, AddTextFragment())
        ft.commit()

    }
}