package com.photo.collage.frames.grid.filters.maker.widgets;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.Button;

import androidx.coordinatorlayout.widget.CoordinatorLayout;

import com.photo.collage.frames.grid.filters.maker.utils.MoveUpwardBehavior;

@CoordinatorLayout.DefaultBehavior(MoveUpwardBehavior.class)
public class MovableButton extends Button {
    public MovableButton(Context context) {
        super(context);
    }

    public MovableButton(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public MovableButton(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
