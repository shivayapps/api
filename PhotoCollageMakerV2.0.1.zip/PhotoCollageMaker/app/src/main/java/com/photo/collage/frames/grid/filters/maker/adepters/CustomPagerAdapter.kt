package com.photo.collage.frames.grid.filters.maker.adepters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.viewpager.widget.PagerAdapter
import com.photo.collage.frames.grid.filters.maker.R
import com.photo.collage.frames.grid.filters.maker.activitys.ViewMyCreationActivity
import com.photo.collage.frames.grid.filters.maker.model.SavedImageModel
import com.photo.collage.frames.grid.filters.maker.utils.loadFromUrl

class CustomPagerAdapter(
        private var mImageLists: ArrayList<SavedImageModel>,
        private var mSavePhotoActivity: ViewMyCreationActivity
) : PagerAdapter() {

    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        var inflater = LayoutInflater.from(mSavePhotoActivity)
        val layout = inflater.inflate(R.layout.vp_view_creation_item,container,false)
        val imgView = layout.findViewById<ImageView>(R.id.full_image)
        imgView.loadFromUrl(mImageLists[position].file.absolutePath)
        container.addView(layout)
        return layout
    }

    fun removeView(index: Int) {
        mImageLists.removeAt(index)
        notifyDataSetChanged()
    }

    override fun getItemPosition(`object`: Any): Int {
            return PagerAdapter.POSITION_NONE
    }

    override fun destroyItem(container: ViewGroup, position: Int, view: Any) {
        container.removeView(view as View)
    }

    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return view === `object`
    }

    override fun getCount(): Int {
        return mImageLists.size
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return super.getPageTitle(position)
    }
}