package com.photo.collage.frames.grid.filters.maker.adepters;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.photo.collage.frames.grid.filters.maker.R;

import java.util.ArrayList;

public class ColorAdepter extends RecyclerView.Adapter<ColorAdepter.MyViewHolder> {

    private static final String TAG = "ColorAdepter";

    private ArrayList<Integer> mColors;
    private Context mContext;
    private setOnItemClickListener mListener;
    public int mItemPosition = -1;
    public int LastSelectedItem = -2;
    private int FirstPosition = 0;
    private boolean isShowGallery;

    public interface setOnItemClickListener {
        void OnItemClicked(int color);
    }

    public ColorAdepter(ArrayList<Integer> mColors, Context mContext, setOnItemClickListener mListener, boolean isShowGallery) {
        this.mColors = mColors;
        this.mContext = mContext;
        this.mListener = mListener;
        this.isShowGallery = isShowGallery;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(mContext).inflate(R.layout.row_color, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder myViewHolder, final int i) {

        if (FirstPosition == i && isShowGallery) {
            Log.d(TAG, "onBindViewHolder: " + i);
            myViewHolder.imgColor.setImageResource(R.drawable.ic_gallery_new);
            myViewHolder.imgColor.setScaleType(ImageView.ScaleType.CENTER_CROP);
            myViewHolder.imgColor.setPadding((int) mContext.getResources().getDimension(R.dimen._3sdp), (int) mContext.getResources().getDimension(R.dimen._3sdp), (int) mContext.getResources().getDimension(R.dimen._3sdp), (int) mContext.getResources().getDimension(R.dimen._3sdp));
            myViewHolder.imgColor.setBackgroundColor(Color.TRANSPARENT);

            myViewHolder.imgColor.setOnClickListener(v -> {
                mListener.OnItemClicked(mColors.get(i));
            });

        } else {
            if (!isShowGallery) {
                myViewHolder.imgColor.getLayoutParams().height = (int) mContext.getResources().getDimension(R.dimen._25sdp);
                myViewHolder.imgColor.getLayoutParams().width = (int) mContext.getResources().getDimension(R.dimen._25sdp);
                myViewHolder.imgColor.requestLayout();
            }
            myViewHolder.imgColor.setImageResource(0);

            final GradientDrawable shape = new GradientDrawable();
            shape.setShape(GradientDrawable.RECTANGLE);
            shape.setColor(mColors.get(i));
            shape.setCornerRadius(10);
            shape.setStroke(8, Color.TRANSPARENT);
            myViewHolder.imgColor.setBackground(shape);

            if (mItemPosition == i || mColors.get(i) == LastSelectedItem) {
                final GradientDrawable shape1 = new GradientDrawable();
                shape1.setShape(GradientDrawable.RECTANGLE);
                shape1.setColor(LastSelectedItem);
                shape1.setCornerRadius(10);
                shape1.setStroke(8, Color.parseColor("#E9E9E9"));
                myViewHolder.imgColor.setBackground(shape1);
            }

            myViewHolder.imgColor.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    final GradientDrawable shape = new GradientDrawable();
                    shape.setShape(GradientDrawable.RECTANGLE);
                    shape.setColor(mColors.get(i));
                    shape.setCornerRadius(10);
                    shape.setStroke(8, Color.parseColor("#E9E9E9"));
                    myViewHolder.imgColor.setBackground(shape);
                    mListener.OnItemClicked(mColors.get(i));

                    mItemPosition = i;
                    LastSelectedItem = mColors.get(i);
                    notifyDataSetChanged();
                }
            });
        }
    }

    public void setLastSelectedItem(int lastSelectedItem) {
        LastSelectedItem = lastSelectedItem;
        mItemPosition = -1;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return mColors.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {

        ImageButton imgColor;

        MyViewHolder(@NonNull View itemView) {
            super(itemView);
            imgColor = itemView.findViewById(R.id.imgColor);
        }
    }
}
