package com.photo.collage.frames.grid.filters.maker

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.multidex.MultiDex
import com.facebook.ads.AudienceNetworkAds
import com.google.android.gms.ads.MobileAds
import com.onesignal.OSNotificationAction.ActionType
import com.onesignal.OSNotificationOpenResult
import com.onesignal.OneSignal
import com.onesignal.OneSignal.NotificationOpenedHandler
import com.photo.collage.frames.grid.filters.maker.activitys.MainActivity
import com.photo.collage.frames.grid.filters.maker.ads.AppOpenManager
import com.photo.collage.frames.grid.filters.maker.handler.ExampleNotificationReceivedHandler
import com.photo.collage.frames.grid.filters.maker.helper.ActivityLifeCycleHelper
import dauroi.photoeditor.PhotoEditorApp

class PhotoCollageMakerApplication : PhotoEditorApp() {
    var appOpenManager: AppOpenManager? = null
    override fun onCreate() {
        super.onCreate()
        instance1 = this
        registerActivityLifecycleCallbacks(ActivityLifeCycleHelper())
        MultiDex.install(this)
        MobileAds.initialize(this)
        AudienceNetworkAds.initialize(this)
        appOpenManager = AppOpenManager(applicationContext)
        isTest = true

        // OneSignal Initialization
        OneSignal.startInit(this)
                .setNotificationReceivedHandler(ExampleNotificationReceivedHandler())
                .setNotificationOpenedHandler(ExampleNotificationOpenedHandler())
                .inFocusDisplaying(OneSignal.OSInFocusDisplayOption.Notification)
                .unsubscribeWhenNotificationsAreDisabled(true)
                .init()
    }

    inner class ExampleNotificationOpenedHandler : NotificationOpenedHandler {
        // This fires when a notification is opened by tapping on it.
        override fun notificationOpened(result: OSNotificationOpenResult) {
            val actionType = result.action.type
            val data = result.notification.payload.additionalData
            val launchUrl = result.notification.payload.launchURL // update docs launchUrl
            val customKey: String?
            var openURL: String? = null
            var activityToLaunch: Any = MainActivity::class.java
            if (data != null) {
                customKey = data.optString("customkey", null)
                openURL = data.optString("openURL", null)
                if (customKey != null) Log.i("OneSignalExample", "customkey set with value: $customKey")
                if (openURL != null) Log.i("OneSignalExample", "openURL to webview with URL value: $openURL")
            }
            if (actionType == ActionType.ActionTaken) {
                Log.i("OneSignalExample", "Button pressed with id: " + result.action.actionID)
                if (result.action.actionID == "id1") {
                    Log.i("OneSignalExample", "button id called: " + result.action.actionID)
                    activityToLaunch = MainActivity::class.java
                } else Log.i("OneSignalExample", "button id called: " + result.action.actionID)
            }
            if (ActivityLifeCycleHelper.isApplicationInForeground()) {
                // App is running
            } else {
                // The following can be used to open an Activity of your choice.
                // Replace - getApplicationContext() - with any Android Context.
                // Intent intent = new Intent(getApplicationContext(), YourActivity.class);
                val intent = Intent(applicationContext, activityToLaunch as Class<*>)
                // intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_NEW_TASK
                intent.putExtra("openURL", openURL)
                Log.i("OneSignalExample", "openURL = $openURL")
                // startActivity(intent);
                applicationContext.startActivity(intent)
            }

            // Add the following to your AndroidManifest.xml to prevent the launching of your main Activity
            //   if you are calling startActivity above.
            /*
           <application ...>
             <meta-data android:name="com.onesignal.NotificationOpened.DEFAULT" android:value="DISABLE" />
           </application>
        */
        }
    }

    companion object {
        @JvmField
        var isTest = true
        var instance1: PhotoCollageMakerApplication? = null
            private set
    }

    open fun isAppOnForeground(context: Context): Boolean {
        val activityManager: ActivityManager =
                context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val appProcesses: List<ActivityManager.RunningAppProcessInfo> =
                activityManager.runningAppProcesses
                        ?: return false
        val packageName = context.packageName
        for (appProcess in appProcesses) {
            if (appProcess.importance === ActivityManager.RunningAppProcessInfo.IMPORTANCE_BACKGROUND && appProcess.processName.equals(
                            packageName
                    )
            ) {
                return true
            }
        }
        return false
    }
}