package com.photo.collage.frames.grid.filters.maker.activitys;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.Image;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.InterstitialAd;
import com.photo.collage.frames.grid.filters.maker.R;
import com.photo.collage.frames.grid.filters.maker.ads.InterstitialAdHelper;

public class SplashScreen extends AppCompatActivity implements InterstitialAdHelper.onInterstitialAdListener {

    private Handler mHandler;
    private Runnable mRunnable;

    private boolean isInterstitialAdLoaded = false;
    private InterstitialAd interstitial;

    private SharedPreferences mSharedPreferences;
    private SharedPreferences.Editor mEdit;

    private Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        mContext = this;

        initAction();
    }

    private void initAction() {
        //ImageView imageView = findViewById(R.id.splash_iv_Background);
        //Glide.with(this).load(R.drawable.ic_bg_splash_2).placeholder(R.drawable.ic_bg_splash_2).into(imageView);
        mHandler = new Handler();
        mRunnable = new Runnable() {
            @Override
            public void run() {
                if (!isFinishing()) {
                    interstitial = null;
                    Intent intent = new Intent(SplashScreen.this, MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                }
            }
        };

        mSharedPreferences = getSharedPreferences("splash", Context.MODE_PRIVATE);
        mEdit = mSharedPreferences.edit();
        if (!mSharedPreferences.getBoolean("isShow", false)) {
            mEdit.putBoolean("isShow", true);
            mEdit.commit();
            mHandler.postDelayed(mRunnable, 3000);
        } else {
            interstitial = InterstitialAdHelper.getInstance().load(mContext, this);
            mHandler.postDelayed(mRunnable, 8000);
        }
    }

    @Override
    public void onLoad() {
        isInterstitialAdLoaded = true;
        if (interstitial != null && !isFinishing()) {
            mHandler.removeCallbacks(mRunnable);
            interstitial.show();
        }
    }

    @Override
    public void onFailed() {
        isInterstitialAdLoaded = false;
        //interstitial = InterstitialAdHelper.getInstance().load(mContext, this);
        mHandler.removeCallbacks(mRunnable);

        if (!isFinishing()) {
            Intent intent = new Intent(SplashScreen.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        }
    }

    @Override
    public void onClosed() {
        isInterstitialAdLoaded = false;
        //interstitial = InterstitialAdHelper.getInstance().load(mContext, this);

        // perform your action
        mHandler.removeCallbacks(mRunnable);
        if (!isFinishing()) {
            Intent intent = new Intent(SplashScreen.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        }
    }
}
