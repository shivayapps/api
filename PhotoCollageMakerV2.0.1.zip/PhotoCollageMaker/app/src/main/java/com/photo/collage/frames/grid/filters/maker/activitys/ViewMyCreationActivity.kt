package com.photo.collage.frames.grid.filters.maker.activitys

import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.FileProvider
import androidx.viewpager.widget.ViewPager
import com.photo.collage.frames.grid.filters.maker.BuildConfig
import com.photo.collage.frames.grid.filters.maker.PhotoCollageMakerApplication
import com.photo.collage.frames.grid.filters.maker.R
import com.photo.collage.frames.grid.filters.maker.adepters.CustomPagerAdapter
import com.photo.collage.frames.grid.filters.maker.model.SavedImageModel
import com.photo.collage.frames.grid.filters.maker.moreframes.sqlite_database.AdsPrefs
import com.photo.collage.frames.grid.filters.maker.utils.showToast

class ViewMyCreationActivity : AppCompatActivity() {

    private var mViewMyCreationActivity: ViewMyCreationActivity? = null

    //Widgets
    private var mViewPager: ViewPager? = null
    private var mTxtBtnShare: TextView? = null

    //Others
    private var imgUri: Uri? = null
    private var mImageLists: ArrayList<SavedImageModel> = ArrayList()
    private var mCustomPagerAdapter: CustomPagerAdapter? = null
    private var imgCurPosition = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_my_creation)
        mViewMyCreationActivity = this@ViewMyCreationActivity

        initView()

        initViewAction()

        imgCurPosition = intent.getIntExtra("imgPosition", 0)
        val myArrayList = intent.extras!!.get("imgListKey") as ArrayList<SavedImageModel>
        mImageLists = myArrayList

        mCustomPagerAdapter = CustomPagerAdapter(mImageLists, mViewMyCreationActivity!!)
        mViewPager!!.adapter = mCustomPagerAdapter
        mViewPager!!.setCurrentItem(imgCurPosition, false)

    }

    override fun onResume() {
        super.onResume()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                finish()
            }
        }
    }

    private fun initView() {
        mViewPager = findViewById(R.id.viewPager)
        mTxtBtnShare = findViewById(R.id.txtBtnShare)
    }

    private fun initViewAction() {
        val back_image = findViewById<ImageView>(R.id.back_image)
        val imgBtnDelete = findViewById<ImageView>(R.id.imgBtnDelete)
        back_image.setOnClickListener {
            onBackPressed()
        }

        imgBtnDelete.setOnClickListener {
            val deleteDialog = Dialog(mViewMyCreationActivity!!)
            deleteDialog.setContentView(R.layout.dialog_delete)
            deleteDialog.getWindow()!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            deleteDialog.window!!.setLayout(ConstraintLayout.LayoutParams.MATCH_PARENT, ConstraintLayout.LayoutParams.WRAP_CONTENT)
            val btnCancel = deleteDialog.findViewById<TextView>(R.id.btnCancel)
            val btnDelete = deleteDialog.findViewById<TextView>(R.id.btnDelete)

            btnCancel.setOnClickListener {
                deleteDialog.cancel()
            }
            btnDelete.setOnClickListener {
                deleteDialog.dismiss()
                if (mImageLists[mViewPager!!.currentItem].file.exists()) {
                    if (mImageLists[mViewPager!!.currentItem].file.delete()) {

                        MediaScannerConnection.scanFile(
                                this,
                                arrayOf(mImageLists[mViewPager!!.currentItem].file.absolutePath),
                                null
                        ) { path, uri ->
                            Log.i("ExternalStorage", "Scanned $path:")
                            Log.i("ExternalStorage", "-> uri=$uri")
                        }
                        print("file Deleted :${mImageLists[mViewPager!!.currentItem].file}")
                    } else {
                        print("file not Deleted :${mImageLists[mViewPager!!.currentItem].file}")
                    }
                    mCustomPagerAdapter!!.removeView(mViewPager!!.currentItem)
                    if (mImageLists.size != 0) {
                        // mViewPager!!.setCurrentItem(imgCurPosition, false)
                    } else {
                        finish()
                    }
                }
            }
            if (!isFinishing) {
                deleteDialog.show()
            }
        }
    }

    fun onClickShareFacebook(view: View?) {
        val intent = packageManager.getLaunchIntentForPackage("com.facebook.katana")
        if (intent != null) {
            val imageUri = FileProvider.getUriForFile(this, "$packageName.provider", mImageLists[mViewPager!!.currentItem].file)
            val sendIntent = Intent(Intent.ACTION_VIEW)
            sendIntent.type = "image/*"
            sendIntent.action = Intent.ACTION_SEND
            sendIntent.putExtra(Intent.EXTRA_STREAM, imageUri)
            sendIntent.setPackage("com.facebook.katana")
            sendIntent.putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id=$packageName")
            sendIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(sendIntent)
        } else {
            // bring user to the market to download the app.
            // or let them choose an app?
            /*intent = new Intent(Intent.ACTION_VIEW);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.setData(Uri.parse("https://play.google.com/store/apps/details?id=com.facebook.katana&hl=en"));
                startActivity(intent);*/
            //Toast.makeText(this, "Facebook have not been install.", Toast.LENGTH_SHORT).show();
            //Snackbar.make(findViewById(R.id.coordinatorLayout), "Facebook have not been install.", Snackbar.LENGTH_SHORT).show();
            showToast("Facebook have not been install.")
        }
    }

    fun onClickShareInstagram(view: View?) {
        val intent = packageManager.getLaunchIntentForPackage("com.instagram.android")
        if (intent != null) {
            val imageUri = FileProvider.getUriForFile(this, "$packageName.provider", mImageLists[mViewPager!!.currentItem].file)
            val sendIntent = Intent(Intent.ACTION_VIEW)
            sendIntent.type = "image/*"
            sendIntent.action = Intent.ACTION_SEND
            sendIntent.putExtra(Intent.EXTRA_STREAM, imageUri)
            sendIntent.setPackage("com.instagram.android")
            sendIntent.putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id=$packageName")
            sendIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(sendIntent)
        } else {
            // bring user to the market to download the app.
            // or let them choose an app?
            /*intent = new Intent(Intent.ACTION_VIEW);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.setData(Uri.parse("https://play.google.com/store/apps/details?id=com.instagram.android&hl=en"));
                startActivity(intent);*/
            //Toast.makeText(this, "Instagram have not been install.", Toast.LENGTH_SHORT).show();
            //Snackbar.make(findViewById(R.id.coordinatorLayout),"Facebook have not been install.",Snackbar.LENGTH_SHORT).show();
            showToast("Instagram have not been install.")
        }
    }

    fun onClickShareWhatsapp(view: View?) {
        val intent = packageManager.getLaunchIntentForPackage("com.whatsapp")
        if (intent != null) {
            val imageUri = FileProvider.getUriForFile(this, "$packageName.provider", mImageLists[mViewPager!!.currentItem].file)
            val sendIntent = Intent(Intent.ACTION_VIEW)
            sendIntent.type = "image/*"
            sendIntent.action = Intent.ACTION_SEND
            sendIntent.putExtra(Intent.EXTRA_STREAM, imageUri)
            sendIntent.setPackage("com.whatsapp")
            sendIntent.putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id=$packageName")
            sendIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(sendIntent)
        } else {
            // bring user to the market to download the app.
            // or let them choose an app?
            /* intent = new Intent(Intent.ACTION_VIEW);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.setData(Uri.parse("market://details?id=" + "com.whatsapp"));
                startActivity(intent);*/
            //Toast.makeText(this, "Whatsapp have not been install.", Toast.LENGTH_SHORT).show();
            showToast("Whatsapp have not been install.")
        }
    }

    fun onClickShareOther(view: View?) {
        val uri = FileProvider.getUriForFile(mViewMyCreationActivity!!, BuildConfig.APPLICATION_ID + ".provider", mImageLists[mViewPager!!.currentItem].file)
        if (uri != null) {
            val intent = Intent(Intent.ACTION_SEND)
            intent.type = "image/jpeg"
            intent.putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id=$packageName")
            intent.putExtra(Intent.EXTRA_SUBJECT, "Collage Photo Maker")
            intent.putExtra(Intent.EXTRA_STREAM, uri)
            startActivity(Intent.createChooser(intent, "Share Image"))
        }

        if (!AdsPrefs.getBoolean(this@ViewMyCreationActivity, AdsPrefs.IS_SUBSCRIBED)) {
            PhotoCollageMakerApplication.instance1?.appOpenManager?.isShare = true
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        PhotoCollageMakerApplication.instance1?.appOpenManager?.isShare = false
    }
}