package com.photo.collage.frames.grid.filters.maker.fragments

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.text.Editable
import android.text.TextWatcher
import android.util.DisplayMetrics
import android.util.Log
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.flask.colorpicker.ColorPickerView
import com.flask.colorpicker.builder.ColorPickerDialogBuilder
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.photo.collage.frames.grid.filters.maker.R
import com.photo.collage.frames.grid.filters.maker.adepters.ColorAdepter
import com.photo.collage.frames.grid.filters.maker.adepters.ColorTextAdepter
import com.photo.collage.frames.grid.filters.maker.adepters.FontAddTextAdapter
import com.photo.collage.frames.grid.filters.maker.comman.Constants
import com.photo.collage.frames.grid.filters.maker.comman.GridSpacingItemDecoration
import com.photo.collage.frames.grid.filters.maker.model.FontsModel
import com.photo.collage.frames.grid.filters.maker.utils.showToast
import java.io.File
import java.io.IOException

class AddTextFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var mParam1: String? = null
    private var mParam2: String? = null
    private var mParam3: Int? = null
    private var recyclerFont: RecyclerView? = null
    private var edtTextSticker: EditText? = null
    private var onClickMain: FrameLayout? = null
    private var mListener: OnFragmentInteractionListener? = null
    private var fontList: ArrayList<FontsModel>? = null
    private val position = 0

    private var mActivity: Activity? = null

    private var mRecyclerColors: RecyclerView? = null
    private val mColors: ArrayList<Int>? = ArrayList()
    private var mSelectedColor = 0

    // private RewardedAd gameOverRewardedAd, gameOverRewardedAd2, gameOverRewardedAd3;
    private var adepter: FontAddTextAdapter? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (arguments != null) {
            mParam1 = requireArguments().getString(ARG_PARAM1)
            mParam2 = requireArguments().getString(ARG_PARAM2)
            mParam3 = requireArguments().getInt(ARG_PARAM3)
        }
    }

    override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(
                R.layout.fragment_add_text,
                container,
                false
        )
    }

    override fun onViewCreated(
            view: View,
            savedInstanceState: Bundle?
    ) {
        super.onViewCreated(view, savedInstanceState)

        mActivity = activity

        recyclerFont = view.findViewById(R.id.recyclerFont)
        mRecyclerColors = view.findViewById(R.id.recyclerColors)
        edtTextSticker =
                view.findViewById(R.id.edtTextSticker)
        onClickMain =
                view.findViewById(R.id.onClickMain)
        onClickMain!!.setOnClickListener(View.OnClickListener { })
        if (mParam1 != null) {
            Constants.stickerText = mParam1
            edtTextSticker!!.setText(mParam1)
        }
        if (mParam2 != null) {
            //Constants.stickerTypeface = mParam2;
            if (mParam2!!.contains("fonts")) {
                edtTextSticker!!.typeface = Typeface.createFromAsset(
                        requireActivity().assets,
                        mParam2
                )
            } else {
                edtTextSticker!!.setTypeface(Typeface.createFromFile(mParam2))
            }
            //  edtTextSticker.setTypeface(Typeface.createFromAsset(getActivity().getAssets(), mParam2));
            Log.d("78945654123312", "onViewCreated: $mParam2")
        }

        edtTextSticker!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(
                    charSequence: CharSequence,
                    i: Int,
                    i1: Int,
                    i2: Int
            ) {
            }

            override fun onTextChanged(
                    charSequence: CharSequence,
                    i: Int,
                    i1: Int,
                    i2: Int
            ) {
                Constants.stickerText = charSequence.toString().trim()
            }

            override fun afterTextChanged(editable: Editable) {}
        })
        val manager = GridLayoutManager(activity, 3)
        recyclerFont!!.setLayoutManager(manager)
        recyclerFont!!.addItemDecoration(GridSpacingItemDecoration(3, dpToPx(13), true))
        recyclerFont!!.setItemAnimator(DefaultItemAnimator())
        loadFonts()
        loadColors()
    }

    private fun loadFonts() {
        fontList = ArrayList()
        val list: Array<String>?
        try {
            list = mActivity!!.assets.list("fonts")

            Log.e("dsd", list!!.size.toString())
            for (i in list!!.indices) {
                fontList!!.add(FontsModel("fonts/" + list[i], 0, true))
            }

            fontList!!.add(1, FontsModel("", R.drawable.ic_color_picker, false))
            //fontList!!.add("null")
            /*val file = File(
                    Environment.getExternalStorageDirectory()
                            .toString() + "/.fonts/fontsun/Solid Color Fonts"
            )
            val files = file.listFiles()
            if (files != null && files.size > 5) {
                fontList!!.removeAt(19)
                for (i in files.indices) {
                    Log.d("798978778", "checkStatus: " + files[i].name)
                    if (files[i].name.contains(".otf") || files[i].name
                                    .contains(".ttf")
                    ) {
                        fontList!!.add(files[i].absolutePath)
                    }
                }
            }*/
        } catch (e: IOException) {
            e.printStackTrace()
        }
        Log.d("79877897878789", "loadFonts: $mParam2")
        setFontsList()
    }

    private fun loadColors() {
        val allColors = resources.getStringArray(R.array.colors)
        mColors!!.clear()
        for (allColor in allColors) {
            mColors.add(Color.parseColor(allColor))
        }

        mRecyclerColors!!.layoutManager = LinearLayoutManager(context, RecyclerView.HORIZONTAL, false)
        mRecyclerColors!!.itemAnimator = DefaultItemAnimator()
        val listener = ColorTextAdepter.setOnItemClickListener { color ->
            if (color != -10) {
                mSelectedColor = color
                Constants.textStickerColor = color
                edtTextSticker!!.setTextColor(color)
            } else {
                /*Imagetype = 0
                chooseImageFromGallery()*/
            }
        }
        val mColor: ArrayList<Int> = ArrayList<Int>(mColors)
        //mColor.add(0, -10)
        //val colorAdepter = ColorTextAdepter(mColor, context, listener, true)
        //mRecyclerColors!!.adapter = colorAdepter

        if (mParam3 != null) {
            edtTextSticker!!.setTextColor(mParam3!!)
            //colorAdepter.setLastSelectedItem(mParam3!!)
            mSelectedColor = mParam3!!
        }
    }

    private fun setFontsList() {
        if (mParam2 == null) {
            //Constants.stickerTypeface = fontList.get(0);
            Constants.textFontPath = fontList!![0].fontPath
            mParam2 = fontList!![0].fontPath
            edtTextSticker!!.typeface = Typeface.createFromAsset(
                    requireActivity().assets,
                    fontList!![0].fontPath
            )
        }
        val listener = FontAddTextAdapter.setOnItemClickListener { position ->
            if (position == 1) {
                colorPickerDialog()
            } else {
                if (fontList!![position].fontPath.contains("fonts")) {
                    edtTextSticker!!.typeface = Typeface.createFromAsset(
                            requireActivity().assets,
                            fontList!![position].fontPath
                    )
                } else {
                    edtTextSticker!!.typeface = Typeface.createFromFile(
                            fontList!![position].fontPath
                    )
                }
                Constants.textFontPath = fontList!![position].fontPath
            }
        }

        //Log.d("78945654123312", "OnItemClicked: " + Constants.stickerTypeface);
        adepter = FontAddTextAdapter(fontList, activity, listener, position, mParam2)
        recyclerFont!!.adapter = adepter
    }

    private fun colorPickerDialog() {
        Log.e("qwertyui", mSelectedColor.toString() + " ;dsasfasf")
        if (mSelectedColor == Color.BLACK) {
            mSelectedColor = Color.WHITE
        }
        ColorPickerDialogBuilder
                .with(context)
                .setTitle("Choose Color")
                .initialColor(mSelectedColor)
                .wheelType(ColorPickerView.WHEEL_TYPE.FLOWER)
                .density(12)
                .setOnColorSelectedListener {

                }
                .setPositiveButton("ok") { d, lastSelectedColor, allColors ->
                    //if (lastSelectedColor != -10) {
                    mSelectedColor = lastSelectedColor
                    Constants.textStickerColor = lastSelectedColor
                    edtTextSticker!!.setTextColor(lastSelectedColor)
                    //} else {
                    /*Imagetype = 0
                    chooseImageFromGallery()*/
                    //}

                }
                .setNegativeButton("cancel") { dialog, which ->

                }
                .build()
                .show()
    }


    fun loadData() {
        val file = File(
                Environment.getExternalStorageDirectory()
                        .toString() + "/.fonts/fontsun/Solid Color Fonts"
        )
        val files = file.listFiles()
        if (files != null && files.size > 5) {
            fontList!!.removeAt(19)
            for (i in files.indices) {
                Log.d("798978778", "checkStatus: " + files[i].name)
                if (files[i].name.contains(".otf") || files[i].name
                                .contains(".ttf")
                ) {
                    fontList!!.add(FontsModel(files[i].absolutePath, 0, true))

                }
            }
            setFontsList()
        } else {

        }
    }

    // TODO: Rename method, update argument and hook method into UI event
    fun onButtonPressed(uri: Uri?) {
        if (mListener != null) {
            mListener!!.onFragmentInteraction(uri)
        }
    }

    fun createAndLoadRewardedAd(adUnitId: String?): RewardedAd {
        val rewardedAd = RewardedAd(activity, adUnitId)
        val adLoadCallback: RewardedAdLoadCallback = object : RewardedAdLoadCallback() {
            override fun onRewardedAdLoaded() {
                // Ad successfully loaded.
            }

            override fun onRewardedAdFailedToLoad(errorCode: Int) {
                // Ad failed to load.
            }
        }
        rewardedAd.loadAd(AdRequest.Builder().build(), adLoadCallback)
        return rewardedAd
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
    }

    override fun onDetach() {
        super.onDetach()
        mListener = null
    }

    private fun dpToPx(dp: Int): Int {
        val r = resources
        return Math.round(
                TypedValue.applyDimension(
                        TypedValue.COMPLEX_UNIT_DIP,
                        dp.toFloat(),
                        r.displayMetrics
                )
        )
    }

    interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        fun onFragmentInteraction(uri: Uri?)
    }

    companion object {
        // TODO: Rename parameter arguments, choose names that match
        // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
        private const val ARG_PARAM1 = "param1"
        private const val ARG_PARAM2 = "param2"
        private const val ARG_PARAM3 = "param3"
        val zipURL: String?
            external get

        // TODO: Rename and change types and number of parameters
        fun newInstance(param1: String?, param2: String?, param3: Int?): AddTextFragment {
            val fragment = AddTextFragment()
            val args = Bundle()
            args.putString(ARG_PARAM1, param1)
            args.putString(ARG_PARAM2, param2)
            args.putInt(ARG_PARAM3, param3!!)
            fragment.arguments = args
            return fragment
        }
    }
}