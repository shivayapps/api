package com.photo.collage.frames.grid.filters.maker.adepters;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.photo.collage.frames.grid.filters.maker.comman.Constants;
import com.photo.collage.frames.grid.filters.maker.R;
import com.photo.collage.frames.grid.filters.maker.model.PhotoModel;

import java.util.ArrayList;

public class PhotoAdepter extends RecyclerView.Adapter<PhotoAdepter.MyViewHolder> {

    private static final String TAG = "PhotoAdepter";


    private Context mCtx;
    private ArrayList<PhotoModel> mList;
    private OnPhotoSelectedListener mListener;
    private boolean isClickable = false;

    public interface OnPhotoSelectedListener {
        void onPhotoSelect(PhotoModel photoModel);
    }


    public PhotoAdepter(Context mCtx, ArrayList<PhotoModel> mList) {
        this.mCtx = mCtx;
        this.mList = mList;
    }

    public void setmListener(OnPhotoSelectedListener mListener) {
        this.mListener = mListener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(mCtx).inflate(R.layout.layout_photo_item, viewGroup, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder myViewHolder, int i) {
        PhotoModel model = mList.get(i);
        Glide.with(mCtx).load(model.getImagePath()).placeholder(R.drawable.place_holder_photo).error(R.drawable.corrupt_file).override(150).listener(new RequestListener<Drawable>() {
            @Override
            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                try {
                    myViewHolder.imgPhoto.setTag("corrupted");
                    myViewHolder.imgPhoto.setPadding(50, 50, 50, 50);
                    myViewHolder.imgPhoto.setBackgroundColor(Color.WHITE);
                    myViewHolder.imgPhoto.setImageDrawable((Drawable) target);
                    Log.d(TAG, "onLoadFailed: ");
                    clickEvent(myViewHolder, i);
                } catch (Exception exception) {
                    exception.printStackTrace();
                }
                return false;
            }

            @Override
            public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                myViewHolder.imgPhoto.setTag("ok");
                myViewHolder.imgPhoto.setPadding(0, 0, 0, 0);
                Log.d(TAG, "onResourceReady: ");
                clickEvent(myViewHolder, i);
                return false;
            }
        }).into(myViewHolder.imgPhoto);

        myViewHolder.imgPhoto.post(() -> {
            myViewHolder.imgPhoto.getLayoutParams().height = myViewHolder.imgPhoto.getWidth();
            myViewHolder.imgPhoto.requestLayout();
        });

        myViewHolder.txtCount.setVisibility(View.GONE);

        if (mList.get(i).getCount() > 0) {
            myViewHolder.txtCount.setVisibility(View.VISIBLE);
            myViewHolder.txtCount.setText(String.valueOf(mList.get(i).getCount()));
        } else {
            int count = 0;
            for (PhotoModel photoModel : Constants.mSelectedImageList) {
                if (photoModel.getImagePath().equals(mList.get(i).getImagePath())) {
                    count++;
                }
            }
            if (count > 0) {
                mList.get(i).setCount(count);
                myViewHolder.txtCount.setVisibility(View.VISIBLE);
                myViewHolder.txtCount.setText(String.valueOf(mList.get(i).getCount()));
            }
        }

    }

    private void clickEvent(@NonNull MyViewHolder myViewHolder, int i) {
        myViewHolder.imgPhoto.setOnClickListener(view -> {

            if (isClickable) {
                return;
            }
            isClickable = true;
            if (view.getTag() == null) {
                return;
            }

            if (view.getTag().equals("ok")) {
                if (mListener != null) {
                    if (Constants.mSelectedImageList.size() < 8) {
                        mListener.onPhotoSelect(mList.get(i));
                        mList.get(i).setCount(mList.get(i).getCount() + 1);

                        if (mList.get(i).getCount() > 0) {
                            myViewHolder.txtCount.setVisibility(View.VISIBLE);
                            myViewHolder.txtCount.setText(String.valueOf(mList.get(i).getCount()));
                        } else {
                            myViewHolder.txtCount.setVisibility(View.GONE);
                        }
                    } else {
                        Toast.makeText(mCtx, "Select maximum 8 images!", Toast.LENGTH_SHORT).show();
                    }
                }
                new Handler().postDelayed(() -> {
                    isClickable = false;
                }, 200);
            } else {
                AlertDialog.Builder builder = new AlertDialog.Builder(mCtx);
                builder.setMessage("This image is corrupted. Please select another image.");
                builder.setPositiveButton("OK", (dialog, which) -> dialog.dismiss());
                builder.show();
                new Handler().postDelayed(() -> {
                    isClickable = false;
                }, 200);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {

        private ImageView imgPhoto;
        private TextView txtCount;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            txtCount = itemView.findViewById(R.id.txtCountImage);
            imgPhoto = itemView.findViewById(R.id.imgPhoto);

        }
    }
}
