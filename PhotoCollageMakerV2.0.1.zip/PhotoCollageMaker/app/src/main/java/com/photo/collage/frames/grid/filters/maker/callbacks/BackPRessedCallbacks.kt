package com.photo.collage.frames.grid.filters.maker.callbacks

interface BackPRessedCallbacks {
    fun onBackPRessedFromActivity()
}