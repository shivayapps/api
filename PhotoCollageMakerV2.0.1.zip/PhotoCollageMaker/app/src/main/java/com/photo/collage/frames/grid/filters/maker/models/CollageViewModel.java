package com.photo.collage.frames.grid.filters.maker.models;

import com.jcmore2.collage.CardView;

public class CollageViewModel {

    private CardView view;
    private float scale;
    private float changeScale;
    private float rotation;

    public CollageViewModel(CardView view, float scale) {
        this.view = view;
        this.scale = scale;
        changeScale = 0;
    }

    public CollageViewModel(CardView view) {
        this.view = view;
    }

    public CardView getView() {
        return view;
    }

    public void setView(CardView view) {
        this.view = view;
    }

    public float getScale() {
        return scale;
    }

    public void setScale(float scale) {
        this.scale = scale;
    }

    public float getChangeScale() {
        return changeScale;
    }

    public void setChangeScale(float changeScale) {
        this.changeScale = changeScale;
    }

    public float getRotation() {
        return rotation;
    }

    public void setRotation(float rotation) {
        this.rotation = rotation;
    }
}
