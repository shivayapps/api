package com.photo.collage.frames.grid.filters.maker.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import com.photo.collage.frames.grid.filters.maker.services.MyService;


public class BootReceiver extends BroadcastReceiver
{

    public void onReceive(Context context, Intent intent)
    {


        // Your code to execute when Boot Completd

        Intent i = new Intent(context, MyService.class);
       // context.startService(i);

        if (Build.VERSION.SDK_INT>= Build.VERSION_CODES.O) {
            context.startForegroundService(i);
        }
        else {
            context.startService(i);
        }

      // Toast.makeText(context, "Booting Completed", Toast.LENGTH_LONG).show();

    }

}