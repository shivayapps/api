package com.photo.collage.frames.grid.filters.maker.moreframes.dialog;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.DialogFragment;

import com.photo.collage.frames.grid.filters.maker.R;


public class WatchVideoDialog extends DialogFragment {

    private String mTitle;
    private String mMessage, positive, negative;
    private OnButtonClickListener mListener;
    private Dialog bottomSheetDialog;
    private int titleImagel;

    public WatchVideoDialog() {

    }

    public WatchVideoDialog(String mTitle, String mMessage, String positive1, String negative1, int titleImage, OnButtonClickListener mListener) {
        this.mTitle = mTitle;
        this.mMessage = mMessage;
        this.positive = positive1;
        this.negative = negative1;
        this.mListener = mListener;
        this.titleImagel = titleImage;
    }

    public interface OnButtonClickListener {
        void onPositive(WatchVideoDialog watchVideoDialog);

        void onNegative(WatchVideoDialog watchVideoDialog);
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setStyle(BottomSheetDialogFragment.STYLE_NORMAL, R.style.materialButton);
        setStyle(DialogFragment.STYLE_NO_TITLE, R.style.materialButton);

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.dialog_watch_video, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TextView tvTitle = view.findViewById(R.id.txtTitle);
        TextView tvMessgae = view.findViewById(R.id.txtMessage);


        tvMessgae.setText(mMessage);
        tvTitle.setText(mTitle);

        ((ImageView) view.findViewById(R.id.iv_dialog_logo)).setImageDrawable(getActivity().getResources().getDrawable(titleImagel));

        ((Button) view.findViewById(R.id.btnPositive)).setText(positive);
        ((Button) view.findViewById(R.id.btnNagative)).setText(negative);

        view.findViewById(R.id.btnPositive).setOnClickListener(v -> {
            mListener.onPositive(this);
        });

        view.findViewById(R.id.btnNagative).setOnClickListener(v -> {
            dismiss();
            mListener.onNegative(this);
        });

        view.findViewById(R.id.textView31).setOnClickListener(v -> {
            dismiss();
        });
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        bottomSheetDialog = getDialog();
        // ((View) getView().getParent()).setPadding(0,0,0,);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int height = displayMetrics.heightPixels;
        int width = displayMetrics.widthPixels;
        width -= width / 8;
        bottomSheetDialog.getWindow().setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT);
        // setColoredNavBar(true);
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Dialog dialog = super.onCreateDialog(savedInstanceState);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            //setWhiteNavigationBar(dialog);
        }
        return dialog;
    }

    private void setColoredNavBar(boolean coloredNavigationBar) {
        if (coloredNavigationBar && bottomSheetDialog.getWindow() != null && Build.VERSION.SDK_INT >= 21) {
            //if (isColorLight(Color.WHITE)) {
            bottomSheetDialog.getWindow().setNavigationBarColor(Color.WHITE);
            if (Build.VERSION.SDK_INT >= 26) {
                bottomSheetDialog.getWindow().setNavigationBarColor(Color.WHITE);
                int flags = bottomSheetDialog.getWindow().getDecorView().getSystemUiVisibility();
                flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                bottomSheetDialog.getWindow().getDecorView().setSystemUiVisibility(flags);
            }
           /* } else {


                if (Build.VERSION.SDK_INT >= 26) {
                    int flags = bottomSheetDialog.getWindow().getDecorView().getSystemUiVisibility();
                    flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    bottomSheetDialog.getWindow().getDecorView().setSystemUiVisibility(flags);
                }
            }*/
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        /*if (getDialog() != null && getDialog().getWindow() != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Window window = getDialog().getWindow();
            window.findViewById(com.google.android.material.R.id.container).setFitsSystemWindows(false);
            // dark navigation bar icons
            View decorView = window.getDecorView();
            decorView.setSystemUiVisibility(decorView.getSystemUiVisibility() | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        }*/
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void setWhiteNavigationBar(@NonNull Dialog dialog) {
        Window window = dialog.getWindow();

        if (window != null) {
            DisplayMetrics metrics = new DisplayMetrics();
            window.getWindowManager().getDefaultDisplay().getMetrics(metrics);

            GradientDrawable dimDrawable = new GradientDrawable();
            // ...customize your dim effect here

            GradientDrawable navigationBarDrawable = new GradientDrawable();
            navigationBarDrawable.setShape(GradientDrawable.RECTANGLE);
            navigationBarDrawable.setColor(Color.WHITE);

            Drawable[] layers = {dimDrawable, navigationBarDrawable};

            LayerDrawable windowBackground = new LayerDrawable(layers);
            windowBackground.setLayerInsetTop(1, metrics.heightPixels);

            window.setBackgroundDrawable(windowBackground);

            int flags = dialog.getWindow().getDecorView().getSystemUiVisibility();
            flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            window.getDecorView().setSystemUiVisibility(flags);
        }
    }

    private boolean isColorLight(@ColorInt int color) {
        if (color == Color.BLACK) return false;
        else if (color == Color.WHITE || color == Color.TRANSPARENT) return true;
        final double darkness = 1 - (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255;
        return darkness < 0.4;
    }
}