package com.photo.collage.frames.grid.filters.maker.comman;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;

import com.photo.collage.frames.grid.filters.maker.model.PhotoModel;

import java.util.ArrayList;

public class Constants {

    public static final int PICK_IMAGE_CODE = 1001;
    public static final int PICK_IMAGE_ADD = 563;

    public static ArrayList<PhotoModel> mSelectedImageList = new ArrayList<>();
    public static ArrayList<PhotoModel> mSelectedImageListTemp = new ArrayList<>();

    public static PhotoModel photoModel;

    public static Bitmap mInputBitmap = null;

    public static Bitmap mCropBitmap = null;

    public static Bitmap mSavedBitmap;
    public static Bitmap mBlurBitmap;
    public static String croppedImagePath;
    public static String blurImagePath;
    public static Uri savedImageUri;
    public static String path;

    public static boolean isChange = false;
    public static String mRatio = "full";
    public static boolean isAddImage = false;

    public static final int COLLAGE_IMAGE_DISCARD_REQUEST_CODE = 1002;
    public static final int SCRAPBOOK_IMAGE_DISCARD_REQUEST_CODE = 1003;

    public static String stickerText = "";
    public static String textFontPath = "fonts/1.ttf";
    public static int textStickerColor = Color.BLACK;

    public static boolean isSubscribed = false;
    public static boolean isSubscribedHome = false;
}
