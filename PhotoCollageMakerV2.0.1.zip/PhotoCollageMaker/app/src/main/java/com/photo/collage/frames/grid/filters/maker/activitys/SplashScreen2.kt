package com.photo.collage.frames.grid.filters.maker.activitys

import android.content.*
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.android.vending.billing.IInAppBillingService
import com.anjlab.android.iab.v3.BillingProcessor
import com.anjlab.android.iab.v3.TransactionDetails
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.InterstitialAd
import com.photo.collage.frames.grid.filters.maker.PhotoCollageMakerApplication
import com.photo.collage.frames.grid.filters.maker.R
import com.photo.collage.frames.grid.filters.maker.ads.AppOpenManager
import com.photo.collage.frames.grid.filters.maker.helper.InAppBillingHandler
import com.photo.collage.frames.grid.filters.maker.moreframes.sqlite_database.AdsPrefs
import com.photo.collage.frames.grid.filters.maker.utils.SharedPrefs
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.Helper
import com.vasundhara.vision.subscription.ui.SubSplashBaseActivity
import org.json.JSONException
import org.json.JSONObject
import java.util.ArrayList

class SplashScreen2 : SubSplashBaseActivity() {
    private var mHandler: Handler? = null
    private var mRunnable: Runnable? = null
    private var is_pause = false

    //TODO: In App Purchase
    var billingProcessor: BillingProcessor? = null
    var LicenseKey = ""
    private var mContext: Context? = null
    private var isAnimEnd = false
    private var mSharedPrefs:SharedPrefs?=null


    private val TAG = "SplashActivity12345"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)
        mContext = this@SplashScreen2

        mSharedPrefs = SharedPrefs(mContext)
        mSharedPrefs?.nullOpenAppAdShownCount()

        if (!AdsPrefs.getBoolean(this@SplashScreen2, AdsPrefs.IS_SUBSCRIBED, false)) {
            PhotoCollageMakerApplication.instance1?.appOpenManager?.fetchAd()
        }

        Helper().startDataSync(this, this)

        mHandler = Handler()
        mRunnable = Runnable {
            if (isAnimEnd) {
                if (!AdsPrefs.getBoolean(this@SplashScreen2, AdsPrefs.IS_SUBSCRIBED)) {
                    //if (MyAdsPrefs(this@SplashScreen2).isFirstForInApp) {
                        loadOpenAppAd()
                    /*} else {
                        MyAdsPrefs(this@SplashScreen2).setFirstInApp()
                        openNextActivity()
                    }*/
                } else {
                    openNextActivity()
                }
            } else {
                isAnimEnd = true
            }
        }
        mHandler!!.postDelayed(mRunnable, 8000)

    }

    override fun registerPurchases(isSubscribe: Boolean) {
        startMain(isSubscribe)
    }


    fun startMain(value: Boolean) {
        AdsPrefs.save(mContext, AdsPrefs.IS_SUBSCRIBED, value)
        if (isAnimEnd) {
            if (mHandler != null) {
                mHandler!!.removeCallbacks(mRunnable)
            }
            if (!AdsPrefs.getBoolean(this@SplashScreen2, AdsPrefs.IS_SUBSCRIBED) && !isFinishing) {
                Log.d(TAG, "startMain: 11")
                loadOpenAppAd()
                return
                /*if (!AdsPrefs.getBoolean(this@SplashScreen2, AdsPrefs.IS_FIRSTTIME, true)) {
                    if (PIPCameraApplication.instance!!.requestNewInterstitial()) {
                        PIPCameraApplication.instance!!.mInterstitialAd!!.adListener = object : AdListener() {
                            override fun onAdClosed() {
                                super.onAdClosed()
                                Log.e("qwerty", "2222")
                                Handler(Looper.getMainLooper()).postDelayed(Runnable {
                                    startActivity(Intent(this@SplashScreen2, MainActivity::class.java))
                                    finish()
                                }, 50)
                            }

                            override fun onAdFailedToLoad(i: Int) {
                                super.onAdFailedToLoad(i)
                                Log.e("qwerty", "3333")
                                startActivity(Intent(this@SplashScreen2, MainActivity::class.java))
                                finish()
                            }

                            override fun onAdLoaded() {
                                super.onAdLoaded()
                            }
                        }
                    } else {
                        Log.e("qwerty", "4444")
                        startActivity(Intent(this@SplashScreen2, MainActivity::class.java))
                        finish()
                    }
                } else {*/
                    /*Log.e("qwerty", "5555")
                    AdsPrefs.save(this@SplashScreen2, AdsPrefs.IS_FIRSTTIME, false)
                    startActivity(Intent(this@SplashScreen2, MainActivity::class.java))
                    finish()*/
                //}
            } else {
                Log.e("qwerty", "6666")
                startActivity(Intent(this@SplashScreen2, MainActivity::class.java))
                finish()
            }
        } else {
            isAnimEnd = true
        }
    }

    private fun loadOpenAppAd() {
        if (mHandler != null) {
            mHandler!!.removeCallbacks(mRunnable)
        }

        if (isFinishing) {
            return
        }

        PhotoCollageMakerApplication.instance1?.appOpenManager?.showAdIfAvailable {
            when (it) {
                AppOpenManager.CallBackType.DISMISS -> {
                    Log.d(TAG, "loadOpenAppAd: DISMISS")
                    openNextActivity()
                }
                AppOpenManager.CallBackType.FAILED -> {
                    Log.d(TAG, "loadOpenAppAd: FAILED")
                    openNextActivity()
                }
                AppOpenManager.CallBackType.ERROR -> {
                    Log.d(TAG, "loadOpenAppAd: ERROR")
                    openNextActivity()
                }
            }
        }
    }

    private fun openNextActivity() {
        Handler(Looper.getMainLooper()).postDelayed(Runnable {
            if (!isFinishing) {
                startActivity(Intent(this@SplashScreen2, MainActivity::class.java))
                finish()
            }
        }, 50)
    }

    /*override fun onPause() {
        super.onPause()
        is_pause = true
        if (mHandler != null) mHandler!!.removeCallbacks(mRunnable)
    }*/

    override fun onStop() {
        super.onStop()
        is_pause = true
        //if (mHandler != null) mHandler!!.removeCallbacks(mRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        is_pause = true
        if (mHandler != null) mHandler!!.removeCallbacks(mRunnable)
    }

    override fun onResume() {
        super.onResume()
        /*if (is_pause) {
            is_pause = false
            //showAd()
            startMain(false)
        }*/
    }
}