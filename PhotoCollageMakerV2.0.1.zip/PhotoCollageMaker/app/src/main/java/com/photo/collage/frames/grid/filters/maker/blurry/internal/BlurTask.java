package com.photo.collage.frames.grid.filters.maker.blurry.internal;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.View;

import java.lang.ref.WeakReference;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* renamed from: jp.wasabeef.blurry.internal.BlurTask */
public class BlurTask {
    private static ExecutorService THREAD_POOL = Executors.newCachedThreadPool();
    /* access modifiers changed from: private */
    public Bitmap bitmap;
    /* access modifiers changed from: private */
    public Callback callback;
    /* access modifiers changed from: private */
    public WeakReference<Context> contextWeakRef;
    /* access modifiers changed from: private */
    public BlurFactor factor;
    /* access modifiers changed from: private */
    public Resources res;

    /* renamed from: jp.wasabeef.blurry.internal.BlurTask$Callback */
    public interface Callback {
        void done(BitmapDrawable bitmapDrawable);
    }

    public BlurTask(View target, BlurFactor factor2, Callback callback2) {
        this.res = target.getResources();
        this.factor = factor2;
        this.callback = callback2;
        this.contextWeakRef = new WeakReference<>(target.getContext());
        target.setDrawingCacheEnabled(true);
        target.destroyDrawingCache();
        target.setDrawingCacheQuality(View.DRAWING_CACHE_QUALITY_HIGH);
        this.bitmap = target.getDrawingCache();
    }

    public BlurTask(Context context, Bitmap bitmap2, BlurFactor factor2, Callback callback2) {
        this.res = context.getResources();
        this.factor = factor2;
        this.callback = callback2;
        this.contextWeakRef = new WeakReference<>(context);
        this.bitmap = bitmap2;
    }

    public void execute() {
        THREAD_POOL.execute(new Runnable() {
            public void run() {
                final BitmapDrawable bitmapDrawable = new BitmapDrawable(BlurTask.this.res, Blur.m1886of((Context) BlurTask.this.contextWeakRef.get(), BlurTask.this.bitmap, BlurTask.this.factor));
                if (BlurTask.this.callback != null) {
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        public void run() {
                            BlurTask.this.callback.done(bitmapDrawable);
                        }
                    });
                }
            }
        });
    }
}
