package com.photo.collage.frames.grid.filters.maker.widgets;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import androidx.core.content.ContextCompat;

import com.photo.collage.frames.grid.filters.maker.R;

public class CollageView extends ImageView {

    private static final String TAG = "CollageView";

    private static final int PADDING = 50;
    public static final float STROKE_WIDTH = 12.0f;
    public static final float MAIN_STROKE_WIDTH = 12.0f;
    private Paint mBorderPaint, mMainBorderPaint, mTransparentPaint, mCirclePaint, mShadowPaint;

    private boolean isTouch = true;
    private float storkeWidth = STROKE_WIDTH;
    private int offset = 4;
    private float mainStorkeWidth = MAIN_STROKE_WIDTH;

    private Bitmap mBitmap;
    private float scaleWidth;
    private float scaleHeight;

    public CollageView(Context context) {
        this(context, null);
    }

    public CollageView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
        setPadding(PADDING - 6, PADDING - 6, PADDING - 6, PADDING - 6);
        setScaleType(ScaleType.FIT_XY);
    }

    public CollageView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        initBorderPaint();
    }

    public void setTouch(boolean touch) {
        isTouch = touch;
        invalidate();
    }

    private void initBorderPaint() {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);

        mBorderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mBorderPaint.setAntiAlias(true);
        mBorderPaint.setFilterBitmap(true);
        mBorderPaint.setDither(true);
        mBorderPaint.setStyle(Paint.Style.STROKE);
        mBorderPaint.setColor(Color.WHITE);
        mBorderPaint.setStrokeWidth(STROKE_WIDTH);
        mBorderPaint.setFilterBitmap(true);

        mCirclePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mCirclePaint.setAntiAlias(true);
        mCirclePaint.setStyle(Paint.Style.FILL_AND_STROKE);
        mCirclePaint.setColor(ContextCompat.getColor(getContext(), R.color.colorBorder));

        mMainBorderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mMainBorderPaint.setAntiAlias(true);
        mMainBorderPaint.setFilterBitmap(true);
        mMainBorderPaint.setDither(true);
        mMainBorderPaint.setStyle(Paint.Style.STROKE);
        mMainBorderPaint.setStrokeCap(Paint.Cap.ROUND);
        mMainBorderPaint.setStrokeJoin(Paint.Join.ROUND);
        mMainBorderPaint.setColor(ContextCompat.getColor(getContext(), R.color.colorBorder));
        mMainBorderPaint.setStrokeWidth(MAIN_STROKE_WIDTH);

        mTransparentPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mTransparentPaint.setAntiAlias(true);
        mTransparentPaint.setFilterBitmap(true);
        mTransparentPaint.setDither(true);
        mTransparentPaint.setStyle(Paint.Style.STROKE);
        mTransparentPaint.setStrokeCap(Paint.Cap.ROUND);
        mTransparentPaint.setStrokeJoin(Paint.Join.ROUND);
        mTransparentPaint.setColor(Color.TRANSPARENT);
        mTransparentPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        mTransparentPaint.setStrokeWidth(6);

        mShadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mShadowPaint.setAntiAlias(true);
        mShadowPaint.setFilterBitmap(true);
        mShadowPaint.setDither(true);
        //mShadowPaint.setShader(new LinearGradient(0,0,0,getHeight(),Color.argb( 100,255, 255, 255),Color.rgb( 0, 0, 0),Shader.TileMode.CLAMP));
        mShadowPaint.setStyle(Paint.Style.STROKE);
        mShadowPaint.setShadowLayer(6,0,0,Color.BLACK);
        mShadowPaint.setColor(Color.WHITE);
        //mTransparentPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        mShadowPaint.setStrokeWidth(4);


    }

    public void setStorkeWidth(float storkeWidth) {
        this.storkeWidth = storkeWidth;
        mBorderPaint.setStrokeWidth(storkeWidth);
        mTransparentPaint.setStrokeWidth(storkeWidth / 4);
    }

    public void setMainStorkeWidth(float mainStorkeWidth) {
        this.mainStorkeWidth = mainStorkeWidth;
    }

    public float getStorkeWidth() {
        return storkeWidth;
    }

    public float getMainStorkeWidth() {
        return mainStorkeWidth;
    }

    public void setCloseIcon(Bitmap mBitmap) {
        this.mBitmap = mBitmap;
        invalidate();
    }

    public boolean isTouch() {
        return isTouch;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);



        //canvas.drawRect(PADDING, PADDING, getWidth() - (PADDING), getHeight() - (PADDING), mBorderPaint);

        //canvas.drawRect(PADDING , PADDING , getWidth() - (PADDING ), getHeight() - (PADDING ), mShadowPaint);

        //canvas.drawRect(PADDING - offset, PADDING - offset, getWidth() - (PADDING - offset), getHeight() - (PADDING - offset), mShadowPaint);

        canvas.drawRect(PADDING, PADDING, getWidth() - (PADDING), getHeight() - (PADDING), mBorderPaint);

        canvas.drawRect(PADDING - offset, PADDING - offset, getWidth() - (PADDING - offset), getHeight() - (PADDING - offset), mTransparentPaint);


        if (isTouch) {
            canvas.drawRect(PADDING - offset - storkeWidth, PADDING - offset - storkeWidth, getWidth() - (PADDING - offset - storkeWidth), getHeight() - (PADDING - offset - storkeWidth), mMainBorderPaint);
            int offset1 = offset + 4;

            canvas.drawRect(PADDING - offset1 - storkeWidth, PADDING - offset1 - storkeWidth, getWidth() - (PADDING - offset1 - storkeWidth), getHeight() - (PADDING - offset1 - storkeWidth), mTransparentPaint);

            canvas.drawCircle(40, 40, 40, mCirclePaint);

            if (mBitmap != null) {
                Log.d(TAG, "onDraw: ");
                canvas.drawBitmap(mBitmap, 40 - mBitmap.getWidth() / 2, 40 - mBitmap.getHeight() / 2, new Paint());
            }

        }


    }


}
