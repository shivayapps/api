package com.photo.collage.frames.grid.filters.maker.activitys;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.InterstitialAd;
import com.google.gson.Gson;
import com.photo.collage.frames.grid.filters.maker.comman.Constants;
import com.photo.collage.frames.grid.filters.maker.R;
import com.photo.collage.frames.grid.filters.maker.adepters.PhotoAdepter;
import com.photo.collage.frames.grid.filters.maker.adepters.SelectedImageAdepter;
import com.photo.collage.frames.grid.filters.maker.ads.InterstitialAdHelper;
import com.photo.collage.frames.grid.filters.maker.fragments.AlbumFragment;
import com.photo.collage.frames.grid.filters.maker.interfaces.OnRefreshListener;
import com.photo.collage.frames.grid.filters.maker.model.PhotoModel;
import com.photo.collage.frames.grid.filters.maker.moreframes.sqlite_database.AdsPrefs;
import com.photo.collage.frames.grid.filters.maker.utils.SharedPrefs;

import java.io.File;
import java.util.ArrayList;

public class GalleryActivity extends BaseActivity implements PhotoAdepter.OnPhotoSelectedListener, InterstitialAdHelper.onInterstitialAdListener {


    private static final String TAG = "GalleryActivity";

    public static final String EXTRA_IMAGE_COUNT = "image_count";
    public static final String EXTRA_IS_MAX_IMAGE_COUNT = "max_image_count";


    public static final String EXTRA_SELECTED_IMAGES = "selectedImages";
    public static final String EXTRA_SELCTED_IMAGES_SIZE = "selected_image_size";

    //object
    private Context mContext;
    private SelectedImageAdepter selectedImageAdepter;

    //AspectRatioImageView
    private ImageButton imgBtnDone, imgBtnDelete;
    private ImageView imgBtnBack;
    private TextView txtTitle, txtCountImage, txtNext;
    private RecyclerView mSelectedImageRecyclerView;


    //var
    private String type;
    private boolean isSingle;
    private boolean hasCollage;
    private int index = 0;

    //ads
    private boolean isInterstitialAdLoaded = false;
    private InterstitialAd interstitial;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery);

        //init Context
        mContext = GalleryActivity.this;

        if (ContextCompat.checkSelfPermission(mContext, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            startActivity(new Intent(mContext, MainActivity.class));
            finish();
        }

        if (!getIntent().hasExtra("collage"))
            Constants.mSelectedImageList.clear();


        //Load ads
        if (!AdsPrefs.getBoolean(this, AdsPrefs.IS_SUBSCRIBED)) {
            interstitial = InterstitialAdHelper.getInstance().load(mContext, this);
        }

        // checkPermission();

        initView();

        initListener();

        initAction();

    }

    @Override
    protected void onStart() {
        super.onStart();
        imgBtnDone.setEnabled(true);
        if (Constants.mSelectedImageList != null && Constants.mSelectedImageList.size() > 0) {
            deleteFile(0, true);
            txtCountImage.setText("(" + String.valueOf(Constants.mSelectedImageList.size()) + ")");
            if (selectedImageAdepter != null) {
                selectedImageAdepter.notifyDataSetChanged();

            }
        }
    }

    public boolean deleteFile(int in, boolean isExits) {
        if (!isExits) {
            Constants.mSelectedImageList.remove(in);
            return true;
        } else {
            for (int i = 0; i < Constants.mSelectedImageList.size(); i++) {
                if (!new File(Constants.mSelectedImageList.get(i).getImagePath()).exists()) {
                    if (deleteFile(i, false)) {
                        i--;
                    }
                }
            }
        }
        return false;
    }


    private void initView() {
        imgBtnBack = findViewById(R.id.imgBtnBack);
        imgBtnDone = findViewById(R.id.imgBtnDone);
        imgBtnDelete = findViewById(R.id.imgBtnDeleteAll);
        txtTitle = findViewById(R.id.toolbar_title);
        txtCountImage = findViewById(R.id.txtImageCount);
        txtNext = findViewById(R.id.txtNext);
        mSelectedImageRecyclerView = findViewById(R.id.selected_image_list);
    }

    private void initListener() {
        imgBtnBack.setOnClickListener(view -> onBackPressed());

        imgBtnDelete.setOnClickListener(view -> {

            Log.d(TAG, "initListener: " + Constants.mSelectedImageList.size());

            if (Constants.mSelectedImageList.size() > 0) {

                new AlertDialog.Builder(this)
                        .setMessage("Are you sure want to delete all image?")
                        .setPositiveButton("OK", (dialog, which) -> {
                            for (int i = 0; i < Constants.mSelectedImageList.size(); i++) {
                                Constants.mSelectedImageList.get(i).setCount(Constants.mSelectedImageList.get(i).getCount() - 1);
                                selectedImageAdepter.OnRefresh(Constants.mSelectedImageList.get(i));
                            }
                            Constants.mSelectedImageList.clear();
                            imgBtnDelete.setEnabled(true);
                            imgBtnDone.setVisibility(View.INVISIBLE);
                            txtCountImage.setText("(0)");
                        })
                        .setNegativeButton("Cancel", (dialog, which) -> {
                            dialog.dismiss();
                        })
                        .show();
            } else {
                Toast.makeText(mContext, "No Image Selected", Toast.LENGTH_SHORT).show();
            }


        });

        imgBtnDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "onClick: ");

                imgBtnDone.setEnabled(false);
                getDataas();
            }
        });
    }


    private void initAction() {

        type = getIntent().getStringExtra("type");
        hasCollage = getIntent().hasExtra("collage");
        isSingle = getIntent().getBooleanExtra("single", false);

        Log.d(TAG, "initAction: " + type);

        if (mPermissionGranted) {

            if (!getIntent().hasExtra("collage")) {
                imgBtnDone.setVisibility(View.INVISIBLE);
                txtNext.setVisibility(View.INVISIBLE);
            }

            setupRecyclerView();

            addAlbumFragment();

            if (isSingle) {
                findViewById(R.id.constraintLayout).setVisibility(View.GONE);
            }

        }
    }

    private void setupRecyclerView() {
        mSelectedImageRecyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        // mSelectedImageRecyclerView.setItemAnimator(new DefaultItemAnimator());


        selectedImageAdepter = new SelectedImageAdepter(mContext, Constants.mSelectedImageList, txtCountImage, imgBtnDelete, imgBtnDone);
        mSelectedImageRecyclerView.setAdapter(selectedImageAdepter);
    }

    private void addAlbumFragment() {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.add(R.id.container, new AlbumFragment());
        fragmentTransaction.commit();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        txtTitle.setText("Choose Image");

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_PERMISSION_CODE: {
                if (grantResults.length > 0) {
                    if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                        mPermissionGranted = true;

                    } else {
                        mPermissionGranted = false;
                    }
                }

                if (!mPermissionGranted) {
                    boolean showRationale = ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE);

                   /* if (showRationale) {
                        showRationale = ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
                    }*/

                    if (!showRationale) {

                        /*android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this, R.style.MyDialogTheme);
                        builder.setTitle("Permission Required");
                        builder.setMessage("Storage Permission are required to save Image into External Storage");
                        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                                //ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, Constants.WRITE_EXTERNAL_STORAGE_CODE);
                                startInstalledAppDetailsActivity((Activity) mContext);
                            }
                        });
                        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                        builder.create().show();*/

                        new AlertDialog.Builder(this)
                                .setTitle("Permission Required")
                                .setMessage("Storage Permission are required to save Image into External Storage")
                                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                        //ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, Constants.WRITE_EXTERNAL_STORAGE_CODE);
                                        startInstalledAppDetailsActivity((Activity) mContext);
                                    }
                                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        }).show();

                        // user also CHECKED "never ask again"
                        // you can either enable some fall back,
                        // disable features of your app
                        // or open another dialog explaining
                        // again the permission and directing to
                        // the app setting
                    }
                }
            }
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    public void setListener(@NonNull OnRefreshListener listener) {
        new Handler().postDelayed(() -> {
            if (listener != null && selectedImageAdepter != null)
                selectedImageAdepter.setListener(listener);
        }, 500);
    }

    @Override
    public void onPhotoSelect(PhotoModel photoModel) {
        if (!isSingle) {
            Constants.mSelectedImageList.add(photoModel);
            selectedImageAdepter.notifyDataSetChanged();
            txtCountImage.setText("(" + String.valueOf(Constants.mSelectedImageList.size()) + ")");
            if (Constants.mSelectedImageList.size() > 0) {
                imgBtnDone.setVisibility(View.VISIBLE);
                imgBtnDelete.setEnabled(true);
            }
        } else {
            Intent intentBack = new Intent();
            setResult(4055, intentBack);
            Constants.photoModel = photoModel;
            finish();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

    }

    @Override
    public void onLoad() {
        isInterstitialAdLoaded = true;
    }

    @Override
    public void onFailed() {
        imgBtnDone.setEnabled(true);
        isInterstitialAdLoaded = false;
        //interstitial = InterstitialAdHelper.getInstance().load(mContext, this);
    }

    @Override
    public void onClosed() {
        getDataas();
    }

    private void getDataas() {
        isInterstitialAdLoaded = false;
        imgBtnDone.setEnabled(true);

       /* new Thread(){
            @Override
            public void run() {
                try {
                    Thread.sleep(15);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                // perform your action


            }
        }.start();*/
        if (type != null && type.equals("scrapbook")) {
            startActivityForResult(new Intent(GalleryActivity.this, ScrapbookActivity.class), Constants.SCRAPBOOK_IMAGE_DISCARD_REQUEST_CODE);
            //finish();
        } else {
            Gson gson = new Gson();
            Intent data = new Intent(GalleryActivity.this, FrameDetailActivity.class);

            Constants.mSelectedImageListTemp.clear();
            Constants.mSelectedImageListTemp.addAll(Constants.mSelectedImageList);
            Log.d(TAG, "onClick: " + Constants.mSelectedImageListTemp.size());

            ArrayList<String> temp = new ArrayList<>();
            for (PhotoModel model : Constants.mSelectedImageList) {
                temp.add(model.getImagePath());
            }

            if (!hasCollage) {
                String jsonText = gson.toJson(temp);

                SharedPrefs mSharedPrefs = new SharedPrefs(mContext);
                mSharedPrefs.savePhotoList(jsonText);
                //data.putExtra(EXTRA_SELECTED_IMAGES, temp);
                data.putExtra(EXTRA_SELCTED_IMAGES_SIZE, temp.size());
                startActivityForResult(data, Constants.COLLAGE_IMAGE_DISCARD_REQUEST_CODE);
            } else {
                Constants.isChange = true;
            }
            finish();
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            if (requestCode == Constants.SCRAPBOOK_IMAGE_DISCARD_REQUEST_CODE && data.getStringExtra("finishData").equals("nulled")) {
                finish();
            } else if (requestCode == Constants.COLLAGE_IMAGE_DISCARD_REQUEST_CODE && data.getStringExtra("finishData").equals("nulled")) {
                finish();
            } else {
            }
        } catch (Exception e) {

        }
    }
}
