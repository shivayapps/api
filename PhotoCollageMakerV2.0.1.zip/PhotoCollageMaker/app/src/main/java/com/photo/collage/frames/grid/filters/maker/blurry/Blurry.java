package com.photo.collage.frames.grid.filters.maker.blurry;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.photo.collage.frames.grid.filters.maker.blurry.internal.Blur;
import com.photo.collage.frames.grid.filters.maker.blurry.internal.BlurFactor;
import com.photo.collage.frames.grid.filters.maker.blurry.internal.BlurTask;
import com.photo.collage.frames.grid.filters.maker.blurry.internal.Helper;


/* renamed from: jp.wasabeef.blurry.Blurry */
public class Blurry {
    /* access modifiers changed from: private */
    public static final String TAG = Blurry.class.getSimpleName();

    /* renamed from: jp.wasabeef.blurry.Blurry$BitmapComposer */
    public static class BitmapComposer {
        private boolean async;
        private Bitmap bitmap;
        private Context context;
        private BlurFactor factor;
        /* access modifiers changed from: private */
        public ImageComposer.ImageComposerListener listener;

        public BitmapComposer(Context context2, Bitmap bitmap2, BlurFactor factor2, boolean async2, ImageComposer.ImageComposerListener listener2) {
            this.context = context2;
            this.bitmap = bitmap2;
            this.factor = factor2;
            this.async = async2;
            this.listener = listener2;
        }

        public void into(final ImageView target) {
            this.factor.width = this.bitmap.getWidth();
            this.factor.height = this.bitmap.getHeight();
            if (this.async) {
                new BlurTask(target.getContext(), this.bitmap, this.factor, new BlurTask.Callback() {
                    public void done(BitmapDrawable drawable) {
                        if (BitmapComposer.this.listener == null) {
                            target.setImageDrawable(drawable);
                        } else {
                            BitmapComposer.this.listener.onImageReady(drawable);
                        }
                    }
                }).execute();
            } else {
                target.setImageDrawable(new BitmapDrawable(this.context.getResources(), Blur.m1886of(target.getContext(), this.bitmap, this.factor)));
            }
        }
    }

    /* renamed from: jp.wasabeef.blurry.Blurry$Composer */
    public static class Composer {
        private boolean animate;
        private boolean async;
        private View blurredView;
        private Context context;
        private int duration = 300;
        private BlurFactor factor;
        private ImageComposer.ImageComposerListener listener;

        public Composer(Context context2) {
            this.context = context2;
            this.blurredView = new View(context2);
            this.blurredView.setTag(Blurry.TAG);
            this.factor = new BlurFactor();
        }

        public Composer radius(int radius) {
            this.factor.radius = radius;
            return this;
        }

        public Composer sampling(int sampling) {
            this.factor.sampling = sampling;
            return this;
        }

        public Composer color(int color) {
            this.factor.color = color;
            return this;
        }

        public Composer async() {
            this.async = true;
            return this;
        }

        public Composer async(ImageComposer.ImageComposerListener listener2) {
            this.async = true;
            this.listener = listener2;
            return this;
        }

        public Composer animate() {
            this.animate = true;
            return this;
        }

        public Composer animate(int duration2) {
            this.animate = true;
            this.duration = duration2;
            return this;
        }

        public ImageComposer capture(View capture) {
            return new ImageComposer(this.context, capture, this.factor, this.async, this.listener);
        }

        public BitmapComposer from(Bitmap bitmap) {
            return new BitmapComposer(this.context, bitmap, this.factor, this.async, this.listener);
        }

        public void onto(final ViewGroup target) {
            this.factor.width = target.getMeasuredWidth();
            this.factor.height = target.getMeasuredHeight();
            if (this.async) {
                new BlurTask(target, this.factor, new BlurTask.Callback() {
                    public void done(BitmapDrawable drawable) {
                        Composer.this.addView(target, drawable);
                    }
                }).execute();
            } else {
                addView(target, new BitmapDrawable(this.context.getResources(), Blur.m1887of(target, this.factor)));
            }
        }

        /* access modifiers changed from: private */
        public void addView(ViewGroup target, Drawable drawable) {
            Helper.setBackground(this.blurredView, drawable);
            target.addView(this.blurredView);
            if (this.animate) {
                Helper.animate(this.blurredView, this.duration);
            }
        }
    }

    /* renamed from: jp.wasabeef.blurry.Blurry$ImageComposer */
    public static class ImageComposer {
        private boolean async;
        private View capture;
        private Context context;
        private BlurFactor factor;
        /* access modifiers changed from: private */
        public ImageComposerListener listener;

        /* renamed from: jp.wasabeef.blurry.Blurry$ImageComposer$ImageComposerListener */
        public interface ImageComposerListener {
            void onImageReady(BitmapDrawable bitmapDrawable);
        }

        public ImageComposer(Context context2, View capture2, BlurFactor factor2, boolean async2, ImageComposerListener listener2) {
            this.context = context2;
            this.capture = capture2;
            this.factor = factor2;
            this.async = async2;
            this.listener = listener2;
        }

        public void into(final ImageView target) {
            this.factor.width = this.capture.getMeasuredWidth();
            this.factor.height = this.capture.getMeasuredHeight();
            if (this.async) {
                new BlurTask(this.capture, this.factor, new BlurTask.Callback() {
                    public void done(BitmapDrawable drawable) {
                        if (ImageComposer.this.listener == null) {
                            target.setImageDrawable(drawable);
                        } else {
                            ImageComposer.this.listener.onImageReady(drawable);
                        }
                    }
                }).execute();
            } else {
                target.setImageDrawable(new BitmapDrawable(this.context.getResources(), Blur.m1887of(this.capture, this.factor)));
            }
        }
    }

    public static Composer with(Context context) {
        return new Composer(context);
    }

    public static void delete(ViewGroup target) {
        View view = target.findViewWithTag(TAG);
        if (view != null) {
            target.removeView(view);
        }
    }
}
