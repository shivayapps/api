package com.photo.collage.frames.grid.filters.maker.adepters

import android.app.Activity
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.photo.collage.frames.grid.filters.maker.R
import com.photo.collage.frames.grid.filters.maker.activitys.ViewMyCreationActivity
import com.photo.collage.frames.grid.filters.maker.model.SavedImageModel
import com.photo.collage.frames.grid.filters.maker.utils.loadFromUrl
import kotlinx.android.synthetic.main.rv_creation_item.view.*
import java.io.Serializable

class CollageImageListAdapter(
        private var fContext: Activity?,
        private var mCollageImageLists: ArrayList<SavedImageModel>,
        private var mOnDeleteShow: OnLongDeleteShow
) : RecyclerView.Adapter<CollageImageListAdapter.ViewHolder>() {

    private var isLongPressed = false

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder =
        ViewHolder(LayoutInflater.from(fContext).inflate(R.layout.rv_creation_item,parent,false))

    override fun getItemCount(): Int = mCollageImageLists.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.itemView.imgThumb.loadFromUrl(mCollageImageLists[position].file.absolutePath)

        if(mCollageImageLists[position].isVisible){
            holder.itemView.chkDelete.visibility = View.VISIBLE
        }else{
            holder.itemView.chkDelete.visibility = View.GONE
        }

        if(mCollageImageLists[position].isSelected){
            holder.itemView.chkDelete.isChecked = true
            holder.itemView.viewForeground.visibility = View.VISIBLE
        }else{
            holder.itemView.chkDelete.isChecked = false
            holder.itemView.viewForeground.visibility = View.GONE
        }

        holder.itemView.setOnLongClickListener {
            if(!isLongPressed) {
                isLongPressed = true
                makeAllVisible(true)
                mOnDeleteShow.OnDeleteShow(isLongPressed)
                //holder.itemView.chkDelete.visibility = View.VISIBLE
                holder.itemView.chkDelete.isChecked = true
                mCollageImageLists[position].isSelected = true
                notifyDataSetChanged()
            }else{

            }
            return@setOnLongClickListener false
        }

        holder.itemView.setOnClickListener {
            if(isLongPressed){
                if(!holder.itemView.chkDelete.isChecked) {
                    holder.itemView.chkDelete.isChecked = true
                    mCollageImageLists[position].isSelected = true
                    notifyDataSetChanged()
                }else{
                    holder.itemView.chkDelete.isChecked = false
                    mCollageImageLists[position].isSelected = false
                    notifyDataSetChanged()
                }
                Log.e("sasasasa",position.toString())
            }else{
                holder.itemView.chkDelete.visibility = View.GONE
                val openImageIntent = Intent(fContext, ViewMyCreationActivity::class.java)
                openImageIntent.putExtra("imgUrlKey",mCollageImageLists[position].file.absolutePath)
                openImageIntent.putExtra("imgFromWhere",1)
                openImageIntent.putExtra("imgPosition",position)
                openImageIntent.putExtra("imgListKey",mCollageImageLists as Serializable)
                fContext!!.startActivity(openImageIntent)
            }
        }

        holder.itemView.chkDelete.setOnClickListener {
            if(holder.itemView.chkDelete.isChecked){
               // holder.itemView.chkDelete.isChecked = true
                mCollageImageLists[position].isSelected = true
                notifyDataSetChanged()
            }else{
                //holder.itemView.chkDelete.isChecked = false
                mCollageImageLists[position].isSelected = false
                notifyDataSetChanged()
            }
        }
    }

    fun getDeleteImageList():ArrayList<SavedImageModel>{
        var mDeleteImageList:ArrayList<SavedImageModel> = ArrayList()
        for(i in mCollageImageLists.indices){
            //if(mImageLists[i].isSelected){
                mDeleteImageList.add(mCollageImageLists[i])
           // }
        }
        return mDeleteImageList
    }

    fun getTrueDeleteImageList():ArrayList<SavedImageModel>{
        var mDeleteImageList:ArrayList<SavedImageModel> = ArrayList()
        for(i in mCollageImageLists.indices){
            if(mCollageImageLists[i].isSelected){
            mDeleteImageList.add(mCollageImageLists[i])
             }
        }
        return mDeleteImageList
    }

    fun makeAllVisible(isVisible:Boolean){
        for(i in mCollageImageLists.indices){
            mCollageImageLists[i].isVisible = isVisible
            if(!isVisible){
                mCollageImageLists[i].isSelected = isVisible
            }
        }
        notifyDataSetChanged()
        if(!isVisible){
            isLongPressed = false
            mOnDeleteShow.OnDeleteShow(isLongPressed)
        }
    }

    fun isLongPressClicked():Boolean{
        return isLongPressed
    }

    fun refreshAdapter(position: Int){
        mCollageImageLists.removeAt(position)
        notifyItemRemoved(position)
        notifyItemChanged(position)
        notifyDataSetChanged()
    }

    class ViewHolder(itemView:View):RecyclerView.ViewHolder(itemView)

    interface OnLongDeleteShow{
        fun OnDeleteShow(isPressed:Boolean)
    }
}