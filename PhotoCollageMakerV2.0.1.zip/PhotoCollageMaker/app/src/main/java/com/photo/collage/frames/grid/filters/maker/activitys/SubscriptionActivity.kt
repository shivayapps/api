package com.photo.collage.frames.grid.filters.maker.activitys

import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.lifecycle.Observer
import com.anjlab.android.iab.v3.BillingProcessor
import com.anjlab.android.iab.v3.BillingProcessor.IBillingHandler
import com.anjlab.android.iab.v3.TransactionDetails
import com.bumptech.glide.Glide
import com.photo.collage.frames.grid.filters.maker.R
import com.photo.collage.frames.grid.filters.maker.comman.Constants
import com.photo.collage.frames.grid.filters.maker.comman.Constants.isSubscribed
import com.photo.collage.frames.grid.filters.maker.comman.Constants.isSubscribedHome
import com.photo.collage.frames.grid.filters.maker.moreframes.sqlite_database.AdsPrefs
import com.vasundhara.vision.subscription.ui.BaseSubscriptionActivity
import kotlinx.android.synthetic.main.activity_subscription.*

class SubscriptionActivity : BaseSubscriptionActivity() {
    private val imgBack: ImageView? = null
    private var icClose: ImageView? = null
    private var cstOneYear: ConstraintLayout? = null
    private var cstOneMonth: ConstraintLayout? = null
    private var btnSubscribe: Button? = null

    // private var rdoOneMonth: RadioButton? = null
    // private var rdoOneYear: RadioButton? = null
    private var productKeyMonth = "" /*, productKeyMonthDiscount = ""*/
    private var productKeyYear = ""
    private var licenseKey = ""

    //private var billingProcessor: BillingProcessor? = null
    private var mContext: Context? = null
    private var txtYearPrize: TextView? = null
    private var txtMonthPrize: TextView? = null

    //private var txtFreeTrialMonth: TextView? = null
    //private var txtFreeTrialYear: TextView? = null
    private var txtPrivacyPolicy: TextView? = null
    private var txtTearmsCondition: TextView? = null

    private var mlinearBestOfferMonth: LinearLayout? = null
    private var mlinearBestOfferYear: LinearLayout? = null
    private var mLinearPlanMonth: LinearLayout? = null
    private var mLinearPlanYear: LinearLayout? = null

    private var plans = com.vasundhara.vision.subscription.constants.Constants.PREMIUM_SKU


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_subscription)
        mContext = this@SubscriptionActivity
        initBillingProcessor()
        initViews()
        setPlanPrice()
        initViewAction()
        scrollview.post {
            try {
                val animator = ValueAnimator.ofInt(0, scrollview.bottom)
                animator.interpolator = LinearInterpolator()
                animator.addUpdateListener {
                    scrollview?.smoothScrollBy(0, it.animatedValue as Int)
                }
                animator.duration = 3000
                animator.startDelay = 1000
                animator.start()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    override fun onPurchases(str: String) {
        AdsPrefs.save(mContext, AdsPrefs.IS_SUBSCRIBED, true)

        isSubscribed = true
        isSubscribedHome = true
        finish()
    }

    private fun initViewAction() {
        plans = com.vasundhara.vision.subscription.constants.Constants.PREMIUM_SKU
        mlinearBestOfferMonth!!.visibility = View.GONE
        mlinearBestOfferYear!!.visibility = View.VISIBLE
        cstOneMonth!!.setBackgroundResource(R.drawable.ic_sub_btn_stroke1)
        cstOneYear!!.setBackgroundResource(R.drawable.ic_sub_btn_stroke)

        icClose!!.setOnClickListener { onBackPressed() }
        cstOneMonth!!.setOnClickListener {
            //rdoOneMonth!!.isChecked = true
            //rdoOneYear!!.isChecked = false
            //txtFreeTrialMonth!!.visibility = View.VISIBLE
            //txtFreeTrialYear!!.visibility = View.GONE
            plans = com.vasundhara.vision.subscription.constants.Constants.BASIC_SKU
            mlinearBestOfferMonth!!.visibility = View.VISIBLE
            mlinearBestOfferYear!!.visibility = View.GONE
            cstOneMonth!!.setBackgroundResource(R.drawable.ic_sub_btn_stroke)
            cstOneYear!!.setBackgroundResource(R.drawable.ic_sub_btn_stroke1)
        }
        cstOneYear!!.setOnClickListener {
            //rdoOneMonth!!.isChecked = false
            //rdoOneYear!!.isChecked = true
            //txtFreeTrialMonth!!.visibility = View.GONE
            //txtFreeTrialYear!!.visibility = View.VISIBLE
            plans = com.vasundhara.vision.subscription.constants.Constants.PREMIUM_SKU
            mlinearBestOfferMonth!!.visibility = View.GONE
            mlinearBestOfferYear!!.visibility = View.VISIBLE
            cstOneMonth!!.setBackgroundResource(R.drawable.ic_sub_btn_stroke1)
            cstOneYear!!.setBackgroundResource(R.drawable.ic_sub_btn_stroke)
        }
        /*rdoOneYear!!.setOnClickListener {
            rdoOneMonth!!.isChecked = false
            rdoOneYear!!.isChecked = true
            txtFreeTrialMonth!!.visibility = View.GONE
            txtFreeTrialYear!!.visibility = View.VISIBLE
            plans = com.vasundhara.vision.subscription.constants.Constants.PREMIUM_SKU
        }*/
        /*rdoOneMonth!!.setOnClickListener {
            rdoOneMonth!!.isChecked = true
            rdoOneYear!!.isChecked = false
            txtFreeTrialMonth!!.visibility = View.VISIBLE
            txtFreeTrialYear!!.visibility = View.GONE
            plans = com.vasundhara.vision.subscription.constants.Constants.BASIC_SKU
        }*/
        btnSubscribe!!.setOnClickListener {
            /*var productKey = ""
            productKey = if (rdoOneMonth!!.isChecked) {
                resources.getString(R.string.ads_product_key_month)
            } else {
                resources.getString(R.string.ads_product_key_year)
            }
            setPlan(productKey)*/
            when (plans) {
                com.vasundhara.vision.subscription.constants.Constants.BASIC_SKU -> {
                    onMonthPlan()
                }
                com.vasundhara.vision.subscription.constants.Constants.PREMIUM_SKU -> {
                    onYearPlan()
                }
            }

        }


        txtTearmsCondition!!.setOnClickListener { startActivity(Intent(this@SubscriptionActivity, TermsConditionActivity::class.java)) }
        txtPrivacyPolicy!!.setOnClickListener { startActivity(Intent(this@SubscriptionActivity, PrivacyPolicyActivity::class.java)) }

        liveDataPrice.observe(this, Observer {
            txtMonthPrize?.text = it[com.vasundhara.vision.subscription.constants.Constants.BASIC_SKU]
            txtYearPrize?.text = it[com.vasundhara.vision.subscription.constants.Constants.PREMIUM_SKU]
        })

        liveDataPeriod.observe(this, Observer {
            //txtFreeTrialMonth?.text = getTrial(it[com.vasundhara.vision.subscription.constants.Constants.BASIC_SKU]!!)
            //txtFreeTrialYear?.text = getTrial(it[com.vasundhara.vision.subscription.constants.Constants.PREMIUM_SKU]!!)
        })

    }


    private fun setPlan(key: String) {
        // billingProcessor!!.consumePurchase(key)
        // billingProcessor!!.subscribe(this, key, "")
    }

    private fun initViews() {
        icClose = findViewById(R.id.icClose)
        cstOneYear = findViewById(R.id.cstOneYear)
        cstOneMonth = findViewById(R.id.cstOneMonth)
        btnSubscribe = findViewById(R.id.btnSubscribe)
        //rdoOneYear = findViewById(R.id.rdoOneYear)
        //rdoOneMonth = findViewById(R.id.rdoOneMonth)
        txtMonthPrize = findViewById(R.id.txtMonthPrize)
        txtYearPrize = findViewById(R.id.txtYearPrize)
        //txtFreeTrialYear = findViewById(R.id.txtFreeTrialYear)
        //txtFreeTrialMonth = findViewById(R.id.txtFreeTrialMonth)
        txtTearmsCondition = findViewById(R.id.txtTearmsCondition)
        txtPrivacyPolicy = findViewById(R.id.txtPrivacyPolicy)

        mLinearPlanMonth = findViewById(R.id.linearPlanMonth)
        mLinearPlanYear = findViewById(R.id.linearPlanYear)
        mlinearBestOfferMonth = findViewById(R.id.linearBestOfferMonth)
        mlinearBestOfferYear = findViewById(R.id.linearBestOfferYear)
    }

    private fun setPlanPrice() {
        val plan_year = AdsPrefs.getString(mContext, AdsPrefs.PRICE_YEAR, AdsPrefs.DEFAULT_PRICE_YEAR)
        val plan_month = AdsPrefs.getString(mContext, AdsPrefs.PRICE_MONTH, AdsPrefs.DEFAULT_PRICE_MONTH)
        val plan_week = AdsPrefs.getString(mContext, AdsPrefs.PRICE_WEEK, AdsPrefs.DEFAULT_PRICE_WEEK)
        Log.d("78123123123123", "setPlanPrice: $plan_month")

        //  tvYearPrice.setText(MessageFormat.format("{0}{1}", plan_year.substring(0, 2), String.valueOf(i / 12)));
        txtYearPrize!!.text = plan_year.substring(0, plan_year.length - 3)
        txtMonthPrize!!.text = plan_month.substring(0, plan_month.length - 3)

        //  tvWeeklyDesc.setText("Monthly cost of plan is " + plan_month);
    }

    private fun initBillingProcessor() {

        /*
         *  You need 4 product key for this and you have to create this 4 key and give in office
         * with
         *  your email address, and they will join you in beta tester after uploading app in play
         *  store
         *   1 -> for week testing,  test Key
         *   2 -> week live key
         *   3 - > month live key
         *   4 - > year live key
         *
         *   when you submit your first beta app you need to set productKeyWeek as test ID and other
         *   2 are live and also live licence key
         *
         * */
        //    productKeyMonthDiscount = getString(R.string.ads_product_key_monthlydiscount);
        productKeyMonth = getString(R.string.ads_product_key_month)
        productKeyYear = getString(R.string.ads_product_key_year)

        /*
         * Live licence Key
         * */licenseKey = getString(R.string.licenseKey)
        // billingProcessor = BillingProcessor(mContext, licenseKey, this)
        // billingProcessor!!.initialize()
    }

    public override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 32459) {
            /* if (billingProcessor != null) {
                 if (!billingProcessor!!.handleActivityResult(requestCode, resultCode, data)) {
                     super.onActivityResult(requestCode, resultCode, data)
                 }
             }*/
        }
    }

    override fun onResume() {
        super.onResume()
    }

    private fun getTrial(trial: String): String? {
        return try {
            val size = trial.length
            val period = trial.substring(1, size - 1)
            val str = trial.substring(size - 1, size)
            Log.d(TAG, "getTrial: ${size} $period - $str")
            when (str) {
                "D" -> "$period Day Free Trial"
                "M" -> "$period Month Free Trial"
                "Y" -> "$period Year Free Trial"
                else -> "$period Day Free Trial"
            }
        } catch (e: Exception) {
            "3 Day Free Trial"
        }
    }

    /*override fun onProductPurchased(productId: String, details: TransactionDetails?) {
        Log.e(TAG, "onProductPurchased:  developerPayload :: -> " + details!!.purchaseInfo.purchaseData.developerPayload)
        Log.e(TAG, "onProductPurchased:  orderId :: -> " + details.purchaseInfo.purchaseData.orderId)
        Log.e(TAG, "onProductPurchased:  packageName :: -> " + details.purchaseInfo.purchaseData.packageName)
        Log.e(TAG, "onProductPurchased:  purchaseToken :: -> " + details.purchaseInfo.purchaseData.purchaseToken)
        Log.e(TAG, "onProductPurchased:  autoRenewing :: -> " + details.purchaseInfo.purchaseData.autoRenewing)
        Log.e(TAG, "onProductPurchased:  purchaseTime :: -> " + details.purchaseInfo.purchaseData.purchaseTime)
        Log.e(TAG, "onProductPurchased:  purchaseState :: -> " + details.purchaseInfo.purchaseData.purchaseState)

           if (productId.equals(productKeyMonthDiscount)) {
            AdsPrefs.save(mContext, AdsPrefs.IS_ADS_REMOVED, true);
        } elseif (productId == productKeyMonth) {
            AdsPrefs.save(mContext, AdsPrefs.IS_SUBSCRIBED, true)
            mSharedPreference!!.setRemoveAds()
        } else if (productId == productKeyYear) {
            AdsPrefs.save(mContext, AdsPrefs.IS_SUBSCRIBED, true)
            mSharedPreference!!.setRemoveAds()
        }
        isSubscribed = true
        isSubscribedHome = true
        finish()
    }

    override fun onPurchaseHistoryRestored() {
        Log.e(TAG, "onPurchaseHistoryRestored: :: ")
    }

    override fun onBillingError(errorCode: Int, error: Throwable?) {
        try {
            Log.e(TAG, "onBillingError: errorCode : $errorCode")
            Log.e(TAG, "onBillingError: getCause : " + error!!.cause!!.message)
            Log.e(TAG, "onBillingError: getMessage : " + error.message)
        } catch (e: Exception) {
            Log.e(TAG, "onBillingError: Exception Cause")
        }
    }

    override fun onBillingInitialized() {
        Log.e(TAG, "onBillingInitialized: :::::")
    }*/

    companion object {
        private const val TAG = "SubscriptionActivity"
    }
}
