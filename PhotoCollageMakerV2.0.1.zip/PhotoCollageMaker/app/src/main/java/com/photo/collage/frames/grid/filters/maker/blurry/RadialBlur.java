package com.photo.collage.frames.grid.filters.maker.blurry;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;

public class RadialBlur {
    public static Bitmap doRadialBlur(Bitmap bitmap, int i, int i2) {
        return doRadialBlur(bitmap, i, i2, 20);
    }

    public static Bitmap doRadialBlur(Bitmap bitmap, int i, int i2, int i3) {
        Bitmap createBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        Matrix matrix = new Matrix();
        Paint paint = new Paint();
        canvas.drawBitmap(bitmap, matrix, paint);
        paint.setAlpha(51);
        for (int i4 = 0; i4 < i3; i4++) {
            matrix.setTranslate((float) (i4 * i), (float) (i4 * i2));
            canvas.drawBitmap(bitmap, matrix, paint);
        }
        return createBitmap;
    }

    public static Bitmap doRadialBlur(Bitmap bitmap, float f, float f2, float f3) {
        return doRadialBlur(bitmap, f, f2, f3, 5);
    }

    public static Bitmap doRadialBlur(Bitmap bitmap, float f, float f2, float f3, int i) {
        Bitmap createBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        Matrix matrix = new Matrix();
        Paint paint = new Paint();
        canvas.drawBitmap(bitmap, matrix, paint);
        paint.setAlpha(51);
        for (int i2 = 0; i2 < i; i2++) {
            float f4 = (((float) i2) * f3) + 1.0f;
            matrix.setScale(f4, f4, f, f2);
            canvas.drawBitmap(bitmap, matrix, paint);
        }
        return createBitmap;
    }
}