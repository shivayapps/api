package com.photo.collage.frames.grid.filters.maker.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.photo.collage.frames.grid.filters.maker.R;
import com.photo.collage.frames.grid.filters.maker.adepters.BackgroundAdepter;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class BottomDialogFragment extends BottomSheetDialogFragment {

    //Constants
    private static final String TAG = "BottomSheetDialog";

    //AspectRatioImageView
    private RecyclerView mRecyclerView;

    //var
    private ArrayList<String> mImageList;

    //object
    private BackgroundAdepter.OnBackgroundImageClick mListener;

    public BottomDialogFragment(BackgroundAdepter.OnBackgroundImageClick mListener) {
        this.mListener = mListener;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.layout_bottom_sheet_dialog, container, false);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //setStyle(BottomSheetDialogFragment.STYLE_NORMAL,R.style.SheetDialog);
        //init
        initView(view);

        initAction();
    }

    private void initAction() {

        //setup recycler view
        mRecyclerView.setLayoutManager(new GridLayoutManager(getContext(), 3));
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());

        //fetch all Images
        //fetchBackgroundImages();

        Log.d(TAG, "initAction: "+mImageList.size());

        //init Adepter
        BackgroundAdepter adepter = new BackgroundAdepter(getContext(),mImageList,mListener);
        mRecyclerView.setAdapter(adepter);
    }

    private void fetchBackgroundImages() {

        mImageList = new ArrayList<>();

        try {
            String[] files = getActivity().getAssets().list("background");
            for (String name : files) {
                mImageList.add("file:///android_asset/background" + File.separator + name);
                Log.e("pathList item", "file:///android_asset/background"  + File.separator + name);
            }
        } catch (IOException e) {
            e.printStackTrace();
            Log.e(TAG, "fetchBackgroundImages: "+e.getMessage());
        }
    }

    private void initView(View view) {
        mRecyclerView = view.findViewById(R.id.recyclerView);
    }
}
