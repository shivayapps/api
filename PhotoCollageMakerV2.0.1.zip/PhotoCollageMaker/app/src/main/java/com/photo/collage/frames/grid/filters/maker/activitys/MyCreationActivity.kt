package com.photo.collage.frames.grid.filters.maker.activitys

import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import com.photo.collage.frames.grid.filters.maker.R
import com.photo.collage.frames.grid.filters.maker.ads.NativeAdvanceHelper
import com.photo.collage.frames.grid.filters.maker.fragments.CollageCreationFragment
import com.photo.collage.frames.grid.filters.maker.fragments.ScrapbookCreationFragment
import java.lang.Exception

class MyCreationActivity : AppCompatActivity() {

    private var mMyCreationActivity: MyCreationActivity? = null

    //Widgets
    private var mConstraintCollage: ConstraintLayout? = null
    private var mConstraintScrapbook: ConstraintLayout? = null
    private var mImgCollage:ImageView?=null
    private var mImgScrapbook:ImageView?=null
    private var mTxtCollage:TextView?=null
    private var mTxtScrapbook:TextView?=null

    //Others
    private var mFragments: Fragment? = null
    private var isFragment1 = true

    companion object {
        var mImgBtnDelete: ImageView? = null
    }

    var delImages:() -> Unit = {

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_creation)
        mMyCreationActivity = this@MyCreationActivity

        initView()

        initViewAction()

        loadFragment()

        mImgBtnDelete!!.setOnClickListener {
            if (isFragment1) {
                //(mFragments as CollageCreationFragment).deleteSelectedImages()
                delImages?.let {
                    it()
                }
            } else {
                //(mFragments as ScrapbookCreationFragment).deleteSelectedImages()
                delImages?.let {
                    it()
                }
            }
        }


    }

    override fun onResume() {
        super.onResume()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                finish()
            } else {
                try {
                    if (isFragment1) {
                        (mFragments as CollageCreationFragment).loadSavedImages()
                    } else {
                        (mFragments as ScrapbookCreationFragment).loadSavedImages()
                    }
                }catch (ex: Exception){

                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        NativeAdvanceHelper.onDestroy()
    }

    private fun initView() {
        mImgBtnDelete = findViewById(R.id.imgBtnDelete)
        mConstraintCollage = findViewById(R.id.constraintCollage)
        mConstraintScrapbook = findViewById(R.id.constraintScrapbook)
        mImgCollage = findViewById(R.id.imgCollage)
        mImgScrapbook = findViewById(R.id.imgScrapbook)
        mTxtCollage = findViewById(R.id.txtCollage)
        mTxtScrapbook = findViewById(R.id.txtScrapbook)
    }

    private fun initViewAction() {
        var imgBtnBack: ImageView = findViewById(R.id.imgBtnBack)
        imgBtnBack.setOnClickListener {
            onBackPressed()
        }
    }

    private fun loadFragment() {
        mFragments = CollageCreationFragment(mMyCreationActivity)
        supportFragmentManager.beginTransaction()
                .add(R.id.frameFragment, mFragments!!)
                .commit()

        mConstraintCollage!!.setOnClickListener {
            //mConstraintCollage!!.setBackgroundResource(R.drawable.btn_creation2_background)
            //mConstraintScrapbook!!.setBackgroundResource(R.drawable.btn_creation1_background)
            //mImgCollage!!.setColorFilter(ContextCompat.getColor(mMyCreationActivity!!,R.color.colorSettingText))
            //mTxtCollage!!.setTextColor(ContextCompat.getColor(mMyCreationActivity!!,R.color.colorSettingText))
            mImgCollage!!.animate().alpha(1f).duration = 100
            mTxtCollage!!.animate().alpha(1f).duration = 100
            mImgScrapbook!!.animate().alpha(0.5f).duration = 100
            mTxtScrapbook!!.animate().alpha(0.5f).duration = 100
            isFragment1 = true
            mFragments = CollageCreationFragment(mMyCreationActivity)
            supportFragmentManager.beginTransaction()
                    .replace(R.id.frameFragment, mFragments!!)
                    .commit()
        }

        mConstraintScrapbook!!.setOnClickListener {
            //mConstraintCollage!!.setBackgroundResource(R.drawable.btn_creation1_background)
            //mConstraintScrapbook!!.setBackgroundResource(R.drawable.btn_creation2_background)
            mImgCollage!!.animate().alpha(0.5f).duration = 100
            mTxtCollage!!.animate().alpha(0.5f).duration = 100
            mImgScrapbook!!.animate().alpha(1f).duration = 100
            mTxtScrapbook!!.animate().alpha(1f).duration = 100
            isFragment1 = false
            mFragments = ScrapbookCreationFragment(mMyCreationActivity)
            supportFragmentManager.beginTransaction()
                    .replace(R.id.frameFragment, mFragments!!)
                    .commit()
        }
    }

    override fun onBackPressed() {
        try {
            if (isFragment1) {
                (mFragments as CollageCreationFragment).callOnBackPressedFromActivity()
            } else {
                (mFragments as ScrapbookCreationFragment).callOnBackPressedFromActivity()
            }
        }catch (ex:Exception){

        }
    }
}
