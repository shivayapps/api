package com.photo.collage.frames.grid.filters.maker.adepters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.photo.collage.frames.grid.filters.maker.R;

import java.util.ArrayList;

public class BackgroundCollageAdepter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Context mContext;
    private ArrayList<String> mList;
    private OnRatioSelect mListener;

    public BackgroundCollageAdepter(Context mContext, ArrayList<String> mList, OnRatioSelect mListener) {
        this.mContext = mContext;
        this.mList = mList;
        this.mListener = mListener;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new RatioViewHolder(LayoutInflater.from(mContext).inflate(R.layout.item_background,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof RatioViewHolder) {

            //PhotoUtils.loadImageWithGlide(mContext,((RatioViewHolder) holder).imgBack,mList.get(position));

            Glide.with(mContext).load(mList.get(position)).into(((RatioViewHolder) holder).imgBack);

            //handle Click Event
            ((RatioViewHolder) holder).imgBack.setOnClickListener(view -> {
                if(mListener != null){
                    mListener.onRatioSelected(mList.get(position),position);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    private class RatioViewHolder extends RecyclerView.ViewHolder{

        private ImageView imgBack;

        public RatioViewHolder(@NonNull View itemView) {
            super(itemView);

            imgBack = itemView.findViewById(R.id.imgBack);
        }
    }

    public interface OnRatioSelect {
        void onRatioSelected(String ratio, int position);
    }
}
