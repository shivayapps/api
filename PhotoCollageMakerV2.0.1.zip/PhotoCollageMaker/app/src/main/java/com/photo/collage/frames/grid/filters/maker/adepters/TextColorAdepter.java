package com.photo.collage.frames.grid.filters.maker.adepters;

public class TextColorAdepter {
}
