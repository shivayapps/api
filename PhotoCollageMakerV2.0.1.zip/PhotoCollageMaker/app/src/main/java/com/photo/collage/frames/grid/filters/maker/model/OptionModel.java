package com.photo.collage.frames.grid.filters.maker.model;

public class OptionModel {

    private int id;
    private int ImageResource;
    private String name;

    public OptionModel(int id, int imageResource, String name) {
        this.id = id;
        ImageResource = imageResource;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getImageResource() {
        return ImageResource;
    }

    public void setImageResource(int imageResource) {
        ImageResource = imageResource;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
