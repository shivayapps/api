package com.photo.collage.frames.grid.filters.maker.adepters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.photo.collage.frames.grid.filters.maker.R;
import com.photo.collage.frames.grid.filters.maker.model.RatioModel;

import java.util.ArrayList;

public class RatioAdepter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Context mContext;
    private ArrayList<RatioModel> mList;
    private OnRatioSelect mListener;
    private int mLastPosition = 0;

    public RatioAdepter(Context mContext, ArrayList<RatioModel> mList, OnRatioSelect mListener) {
        this.mContext = mContext;
        this.mList = mList;
        this.mListener = mListener;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new RatioViewHolder(LayoutInflater.from(mContext).inflate(R.layout.layout_ratio_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof RatioViewHolder) {

            ((RatioViewHolder) holder).mSelectedView.setVisibility(View.INVISIBLE);

            //set Text
            ((RatioViewHolder) holder).txtRatio.setText(mList.get(position).getRatio());
            ((RatioViewHolder) holder).imgRatio.setImageResource(mList.get(position).getRatioImage());

            if (mLastPosition == position) {
                //((RatioViewHolder) holder).mSelectedView.setVisibility(View.VISIBLE);
                //((RatioViewHolder) holder).txtRatio.setBackgroundResource(R.drawable.bg_select_item);
                ((RatioViewHolder) holder).imgRatio.setAlpha(1f);
                ((RatioViewHolder) holder).txtRatio.setAlpha(1f);
            } else {
                //((RatioViewHolder) holder).txtRatio.setBackgroundResource(R.drawable.bg_ratio_item);
                ((RatioViewHolder) holder).imgRatio.setAlpha(0.5f);
                ((RatioViewHolder) holder).txtRatio.setAlpha(0.5f);
            }

            //handle Click Event
            ((RatioViewHolder) holder).imgRatio.setOnClickListener(view -> {
                if (mListener != null) {
                    mListener.onRatioSelected(mList.get(position).getRatio());
                }
                mLastPosition = position;
                notifyDataSetChanged();
            });
        }
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    private class RatioViewHolder extends RecyclerView.ViewHolder {

        private TextView txtRatio;
        private ImageView imgRatio;
        private View mSelectedView;


        public RatioViewHolder(@NonNull View itemView) {
            super(itemView);

            txtRatio = itemView.findViewById(R.id.txtRatio);
            imgRatio = itemView.findViewById(R.id.imgRatio);
            mSelectedView = itemView.findViewById(R.id.selectedView);
        }
    }

    public interface OnRatioSelect {
        void onRatioSelected(String ratio);
    }
}
