package com.photo.collage.frames.grid.filters.maker.ads;


import com.google.android.gms.ads.AdRequest;

public class AdsHelper {

    /*
     // Step - 1 Add Dependency in gradle

     implementation 'com.google.android.gms:play-services-ads:17.2.0'


    <com.google.android.gms.ads.AdView
        android:id="@+id/ad_view"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_alignParentBottom="true"
        android:layout_centerHorizontal="true"
        android:visibility="gone"
        ads:adSize="BANNER"
        ads:adUnitId="@string/banner_ad_id"
        app:layout_constraintBottom_toBottomOf="@+id/constraintLayout2"
        tools:layout_editor_absoluteX="-44dp" />

   // Step - 2 Add Ads id in string.xml
    <string name="admob_app_id">ca-app-pub-3940256099942544~3347511713</string>
    <string name="banner_ad_id">ca-app-pub-3940256099942544/6300978111</string>
    <string name="interstitial_ad_id">ca-app-pub-3940256099942544/1033173712</string>
    <string name="native_ad_id">ca-app-pub-3940256099942544/2247696110</string>
    <string name="ads_product_key">android.test.purchased</string>
    <string name="licenseKey">bGoa+V7g/yqDXvKRqq+JTFn4uQZbPiQJo4pf9RzJ</string>

    // Step - 3 Add meta deta in AndroidManifest.xml
    <meta-data
    android:name="com.google.android.gms.ads.APPLICATION_ID"
    android:value="@string/admob_app_id" />

    // Step - 4 initialize ads in launcher activity
    //  MobileAds.initialize(this, getString(R.string.admob_app_id));

    // Step - 5 Add Style in style.xml
    <style name="AppTheme.AdAttribution">
    <item name="android:layout_width">wrap_content</item>
    <item name="android:layout_height">wrap_content</item>
    <item name="android:layout_gravity">left</item>
    <item name="android:textColor">#FFFFFF</item>
    <item name="android:textSize">12sp</item>
    <item name="android:text">@string/ad_attribution</item>
    <item name="android:background">#FFCC66</item>
    <item name="android:width">15dp</item>
    <item name="android:height">15dp</item>
    </style>

*/

    public static AdRequest getRequestId() {
        return new AdRequest.Builder()
                .addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
                .addTestDevice("E19949FB5E7C5A28C30A875934AC8181") //SWIPE
                .addTestDevice("41E9C9F5D1F985FB36C9760EFC8F3916") //Lenovo
                .addTestDevice("64A3A22A05D9DCDBEC68395FF5048CD1")  //Coolpad
                .addTestDevice("9553140774085061E51D99BE4FBB3C5E") //XOLO
                .addTestDevice("F9EBC1840023CB004A83005514278635") //MI 6otu (No SIM)
                .addTestDevice("4C9C29EFCCC3AFE714623A702F482AEE") //Micromax New
                .addTestDevice("553B57A7B0422031839D1F2CC0607EB8")  //INTEX
                .addTestDevice("A7A19E06342F7D3868ABA7863D707BD7") //Samsung Tab
                .addTestDevice("78E289C0CB209B06541CB844A1744650") //LAVA
                .addTestDevice("C458AB4E076325EA5FE91458A1A1FDC3")//X-ZIOX
                .addTestDevice("567DB1C5EC4A5D581176C2652228829D") //Celkon
                .addTestDevice("BEAA671BEA6C971FE461AC6E423B2ADE") //Karbonn
                .addTestDevice("74527FD0DD7B0489CFB68BAED192733D") //Nexus TAB
                .addTestDevice("BB5542D48765B65F516CF440C3545896") //Samsung j2
                .addTestDevice("E56855A0C493CEF11A7098FE6EA840CB") //Videocon
                .addTestDevice("86FCAEF9B8F88A7136E69ED879B12CE8") //jivi
                .addTestDevice("ACFC7B7082B3F3FD4E0AC8E92EA10D53") //MI Tab
                .addTestDevice("863D8BAE88E209F38FF3C94A0403C776") //Samsung old
                .addTestDevice("C458AB4E076325EA5FE91458A1A1FDC3")//Samsung new
                .addTestDevice("517048997101BE4535828AC2360582C2") //motorola
                .addTestDevice("8BB4BCB27396AB8ED222B7F902E13420") //micromax old
                .addTestDevice("BFAE6D8DB020BF475077F41CED4D4B5B") //Gionee
                .addTestDevice("EB3DAD0B99C5B3658E0C2ACB31F8BE5B") //Mi Chhotu JIO
                .addTestDevice("CEF2CF599FA65D8072F04888C122999E") //iVoomi
                .addTestDevice("BB5542D48765B65F516CF440C3545896") //samusung j2
                .addTestDevice("DD0A309E21D1F24C324C107BE78C1B88") //Ronak Oreo
                .addTestDevice("B05DBFFC98F6E3E7A8E75E2FE96C2D65") //Nokia Oreo
                .addTestDevice("E19949FB5E7C5A28C30A875934AC8181") //HiTech
                .addTestDevice("1969289F3928DDBAA65020B884860E7A") //lava
                .addTestDevice("EB3DAD0B99C5B3658E0C2ACB31F8BE5B") //Mi Chhotu JIO new
                .addTestDevice("1CF5E374F11F517A8A5C3F26BFD9A14A")
                .addTestDevice("355890BDA9D8DF2D87AD2B53BFCA2B2B")
                .addTestDevice("C048D4FE66E2D9E7B4F84A3FA9C4CF51")
                .addTestDevice("A8640CC0F3136BBBADA3A846485CD7C0")
                .addTestDevice("2A6E3914633DA48BB7E9B7E5BE42E0A3")
                .addTestDevice("DD838FA2B53F6627A623F956FC91650F")
                .addTestDevice("2BB0D9F486B0D37BDD65599D2FD151AF")//samsung j2
                .addTestDevice("2C8C750E8DA3A361411636901E87430E")//nokia
                .addTestDevice("F599D1A9A67703BC9BB3DEEC5F694D05")//nokia 1
                .addTestDevice("217721D34C4B2D4BD20BE6077C153A5C")//Realme
                .addTestDevice("55105A85E87A86A66780A77237BD0D1C")//nokia
                .addTestDevice("35BFFAB134DE8961215FD8F37C935429")//mi red 5
                .addTestDevice("A4BAD897036553E09164BBECC9030A21")//Gionee
                .addTestDevice("1DE891388E038CB97EE1D778D08FD311")//nokia
                .addTestDevice("2B9F1CD1FD47C27FA3C3DB8317627A98")//LENOVO
                .addTestDevice("41EB3CB1055836195F00FDD8CE9DECBE")//j2
                .addTestDevice("4EE8F8D8948C6A250B4437666879DFCF")//comio
                .addTestDevice("E3B60CE263CD4E5886434E9F34FB21E5")
                .addTestDevice("152B6C19B7D96AACCA727D2A6A3EDE36")
                .addTestDevice("3776319271499D1FB661B9E1F01C4807")
                .addTestDevice("F8B9A708AB468BFFE3D3F79324C8BD9D")
                .addTestDevice("74EB0D80BBB7A2CD6A71EAF4726DB4B6")
                .addTestDevice("E27554AA24AB4D996C79D0C69E4B9290") //Gionee
                .addTestDevice("8D06405BAE661E8FD887D36CCD79DE47")
                .addTestDevice("C9A4EC8B86692E53985E9E827DB9E890")//xolo
                .addTestDevice("CDAA7D2CCD15934AFB80D4D38ED2718E")//Nokia Pie
                .addTestDevice("BD26DA87E39D4D80FDAB9A544B479627")//Mi black
                .build();
    }
}
