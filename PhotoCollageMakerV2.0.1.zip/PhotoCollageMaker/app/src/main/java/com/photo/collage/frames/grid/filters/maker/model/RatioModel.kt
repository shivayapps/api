package com.photo.collage.frames.grid.filters.maker.model

data class RatioModel(var ratio:String, var ratioImage:Int){

}