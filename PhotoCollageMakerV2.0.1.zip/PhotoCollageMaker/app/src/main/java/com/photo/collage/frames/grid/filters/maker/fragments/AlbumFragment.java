package com.photo.collage.frames.grid.filters.maker.fragments;


import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.provider.MediaStore;
import android.text.format.DateFormat;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.photo.collage.frames.grid.filters.maker.comman.GridSpacingItemDecoration;
import com.photo.collage.frames.grid.filters.maker.R;
import com.photo.collage.frames.grid.filters.maker.adepters.AlbumAdepter;
import com.photo.collage.frames.grid.filters.maker.model.AlbumModel;
import com.photo.collage.frames.grid.filters.maker.model.PhotoModel;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;


public class AlbumFragment extends Fragment {

    //constant var
    private static final String TAG = "AlbumFragment";

    //AspectRatioImageView
    private RecyclerView mAlbumRecyclerView;
    private ProgressBar mProgressBar;

    //object
    private Context mContext;
    private Handler mHandler;
    private Runnable mRunnable;

    //var
    private ArrayList<AlbumModel> mAlbumList;
    private ArrayList<PhotoModel> mPhotoList;

    private TextView txtTitle;
    private TextView txtNoImageFound;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_album, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //init Context
        mContext = getContext();

        //init RecyclerView
        mAlbumRecyclerView = view.findViewById(R.id.album_list);
        mProgressBar = view.findViewById(R.id.progressBar);
        txtNoImageFound = view.findViewById(R.id.textNoImgFound);

        //init var
        mAlbumList = new ArrayList<>();
        mPhotoList = new ArrayList<>();

        setupRecyclerView();


    }

    @Override
    public void onStart() {
        super.onStart();
        new AsyncTask<Void, Void, Void>() {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                mProgressBar.setVisibility(View.VISIBLE);
            }

            @Override
            protected Void doInBackground(Void... voids) {
                getAllAlbum();

                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                mProgressBar.setVisibility(View.GONE);
                AlbumAdepter albumAdepter = new AlbumAdepter(mContext, mAlbumList, model -> {
                    txtTitle.setText(model.getAlbumName());
                    addPhotoFragment(model);
                });
                mAlbumRecyclerView.setAdapter(albumAdepter);
                if (mAlbumList.size() == 0) {
                    txtNoImageFound.setVisibility(View.VISIBLE);
                } else {
                    txtNoImageFound.setVisibility(View.GONE);
                }
            }
        }.execute();
    }

    private int dpToPx(int dp) {
        Resources r = getResources();
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, r.getDisplayMetrics()));
    }

    private void setupRecyclerView() {
        GridLayoutManager gridLayoutManager = new GridLayoutManager(mContext, 2);
        mAlbumRecyclerView.setLayoutManager(gridLayoutManager);
        mAlbumRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mAlbumRecyclerView.addItemDecoration(new GridSpacingItemDecoration(2, dpToPx(5), true));
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        txtTitle = ((Activity) context).findViewById(R.id.toolbar_title);
    }

    /*private void getAllAlbum() {

        String[] projection = new String[]{"DISTINCT " + MediaStore.Images.ImageColumns.BUCKET_DISPLAY_NAME};
        String orderBy = MediaStore.Images.ImageColumns.DATE_ADDED;
        Cursor cur = mContext.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, null, null, orderBy);
        Log.d(TAG, "getAllAlbum: " + cur.getCount());

        while (cur.moveToNext()) {

            if (cur != null && cur.getCount() > 0) {
                String bucketname = cur.getString(cur.getColumnIndex(MediaStore.Images.ImageColumns.BUCKET_DISPLAY_NAME));

                Cursor cur1 = mContext.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, null, MediaStore.Images.ImageColumns.BUCKET_DISPLAY_NAME + " = ?", new String[]{bucketname}, MediaStore.Images.ImageColumns.DATE_ADDED + " DESC");

                mPhotoList = new ArrayList<>();


                while (cur1.moveToNext()) {
                    // Log.d(TAG, "getAllAlbum: " + getDate(Long.parseLong(cur1.getString(cur1.getColumnIndex(MediaStore.Images.ImageColumns.DATE_MODIFIED)))));
                    *//*if(mPhotoList.size() == 0) {
                        mPhotoList.add(new PhotoModel(cur1.getString(cur1.getColumnIndex(MediaStore.Images.ImageColumns.DATA)), getDate(Long.parseLong(cur1.getString(cur1.getColumnIndex(MediaStore.Images.ImageColumns.DATE_MODIFIED)))),getFullDate(Long.parseLong(cur1.getString(cur1.getColumnIndex(MediaStore.Images.ImageColumns.DATE_MODIFIED))));
                    }*//*
                    try {
                        mPhotoList.add(new PhotoModel(cur1.getString(cur1.getColumnIndex(MediaStore.Images.ImageColumns.DATA)), getDate(Long.parseLong(cur1.getString(cur1.getColumnIndex(MediaStore.Images.ImageColumns.DATE_MODIFIED)))), getFullDate(Long.parseLong(cur1.getString(cur1.getColumnIndex(MediaStore.Images.ImageColumns.DATE_MODIFIED))))));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                }


                mAlbumList.add(new AlbumModel(bucketname, mPhotoList));
                //Log.d(TAG, "getAllAlbum: photo " + cur1.getCount());
            }
        }
        //Log.d(TAG, "getAllAlbum: List Size"+mAlbumList.size());


    }*/

    private void getAllAlbum() {

        mAlbumList.clear();
        mPhotoList.clear();

        ArrayList<String> temp = new ArrayList<>();

        String[] projection = new String[]{MediaStore.Images.ImageColumns.BUCKET_DISPLAY_NAME, MediaStore.Images.Media.DATA, MediaStore.Images.Media.DATE_MODIFIED, MediaStore.Images.Media._ID};
        String orderBy = MediaStore.Images.ImageColumns.DATE_ADDED + " DESC";
        //String BUCKET_GROUP_BY = "1) GROUP BY 1,(2";
        Cursor cur = mContext.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, "NOT " + MediaStore.Images.Media.MIME_TYPE + " = 'image/gif'", null, orderBy);
        Log.d(TAG, "getAllAlbum: " + cur.getCount());
        if (cur != null && cur.getCount() > 0) {
            String bucketName;
            String data;
            String imageId;
            int bucketNameColumn = cur.getColumnIndex(MediaStore.Images.Media.BUCKET_DISPLAY_NAME);
            int imageUriColumn = cur.getColumnIndex(MediaStore.Images.Media.DATA);
            int imageIdColumn = cur.getColumnIndex(MediaStore.Images.Media._ID);
            while (cur.moveToNext()) {

                bucketName = cur.getString(bucketNameColumn);
                data = cur.getString(imageUriColumn);
                imageId = cur.getString(imageIdColumn);
                if(new File(data).exists()) {
                    if (temp.contains(bucketName)) {
                        if (!data.contains("/.")) {
                            AlbumModel photoModel = mAlbumList.get(temp.indexOf(bucketName));
                            photoModel.getPhotos().add(new PhotoModel(data, "", ""));
                            Log.e("qwerty1122a", photoModel + " ;dfsf");
                        }
                    } else {
                        if (!data.contains("/.")) {
                            temp.add(bucketName);
                            mPhotoList = new ArrayList<>();
                            mPhotoList.add(new PhotoModel(data, "", ""));
                            mAlbumList.add(new AlbumModel(bucketName, mPhotoList));
                            Log.e("qwerty1122a", mPhotoList.size() + " ;dfsf");
                        }
                    }
                }


                /*//String bucketname = cur.getString(cur.getColumnIndex(MediaStore.Images.ImageColumns.BUCKET_DISPLAY_NAME));

                Cursor cur1 = mContext.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, null, MediaStore.Images.ImageColumns.BUCKET_DISPLAY_NAME + " = ?", new String[]{bucketname}, MediaStore.Images.ImageColumns.DATE_ADDED + " DESC");



                while (cur1.moveToNext()) {
                    // Log.d(TAG, "getAllAlbum: " + getDate(Long.parseLong(cur1.getString(cur1.getColumnIndex(MediaStore.Images.ImageColumns.DATE_MODIFIED)))));
                    *//*if(mPhotoList.size() == 0) {
                        mPhotoList.add(new PhotoModel(cur1.getString(cur1.getColumnIndex(MediaStore.Images.ImageColumns.DATA)), getDate(Long.parseLong(cur1.getString(cur1.getColumnIndex(MediaStore.Images.ImageColumns.DATE_MODIFIED)))),getFullDate(Long.parseLong(cur1.getString(cur1.getColumnIndex(MediaStore.Images.ImageColumns.DATE_MODIFIED))));
                    }*//*
                    try {
                        mPhotoList.add(new PhotoModel(cur1.getString(cur1.getColumnIndex(MediaStore.Images.ImageColumns.DATA)), getDate(Long.parseLong(cur1.getString(cur1.getColumnIndex(MediaStore.Images.ImageColumns.DATE_MODIFIED)))), getFullDate(Long.parseLong(cur1.getString(cur1.getColumnIndex(MediaStore.Images.ImageColumns.DATE_MODIFIED))))));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                }


                mAlbumList.add(new AlbumModel(bucketname, mPhotoList));*/
                //Log.d(TAG, "getAllAlbum: photo " + cur1.getCount());
            }
            int i = mAlbumList.size();
            Log.d(TAG, "getAllAlbum: " + mAlbumList.size());
        }

        //Log.d(TAG, "getAllAlbum: List Size"+mAlbumList.size());


    }


    private void addPhotoFragment(AlbumModel model) {
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        fragmentTransaction.add(R.id.container, PhotoFragment.getInstance(model));
        fragmentTransaction.addToBackStack("back");
        fragmentTransaction.commit();
    }

    private String getDate(long time) {
        Calendar today = Calendar.getInstance(Locale.ENGLISH);
        Calendar cal = Calendar.getInstance(Locale.ENGLISH);

        String Today = DateFormat.format("dd-M-yyyy", today).toString();

        cal.setTimeInMillis(time * 1000);

        String date = "";

        if (Today.equals(DateFormat.format("dd-M-yyyy", cal).toString())) {
            date = "Today";
        } else if (!DateFormat.format("yyyy", today).toString().equals(DateFormat.format("yyyy", cal).toString())) {
            date = DateFormat.format("E, MMM d, yyyy", cal).toString();
        } else {
            date = DateFormat.format("E, MMM d", cal).toString();
        }

        return date;
    }

    private String getFullDate(long time) {
        Calendar cal = Calendar.getInstance(Locale.ENGLISH);
        cal.setTimeInMillis(time * 1000);
        return DateFormat.format("dd-M-yyyy", cal).toString();
    }
}
