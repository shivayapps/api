package com.photo.collage.frames.grid.filters.maker.adepters;

import android.content.Context;
import android.graphics.Typeface;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.photo.collage.frames.grid.filters.maker.R;
import com.photo.collage.frames.grid.filters.maker.model.FontsModel;

import java.util.ArrayList;

public class FontAddTextAdapter extends RecyclerView.Adapter<FontAddTextAdapter.MyViewHolder> {

    private ArrayList<FontsModel> mFontNames;
    private Context mContext;
    private FontAddTextAdapter.setOnItemClickListener mListener;
    private int lastCheckedPosition = 0;
    private String mParam;

    public interface setOnItemClickListener {
        void OnItemClicked(int position);
    }

    public FontAddTextAdapter(ArrayList<FontsModel> mFontNames, Context mContext, setOnItemClickListener mListener, int position, String mParam2) {
        this.mFontNames = mFontNames;
        this.mContext = mContext;
        this.mListener = mListener;
        this.lastCheckedPosition = position;
        this.mParam = mParam2;
    }

    @NonNull
    @Override
    public FontAddTextAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new FontAddTextAdapter.MyViewHolder(LayoutInflater.from(mContext).inflate(R.layout.rv_font_item_text, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull FontAddTextAdapter.MyViewHolder myViewHolder, final int i) {
        if (mFontNames.get(i).isFont()) {
            myViewHolder.parentLayout.setVisibility(View.VISIBLE);
            myViewHolder.imgColorPicker.setVisibility(View.GONE);
            if (i == 19 && mFontNames.size() == 20) {
                //myViewHolder.imgMoreAPI.setVisibility(View.VISIBLE);
                myViewHolder.txtFont.setVisibility(View.GONE);
            /*myViewHolder.imgMoreAPI.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mListener.OnItemClicked(i);
                }
            });*/
            } else {
                //myViewHolder.imgMoreAPI.setVisibility(View.GONE);
                myViewHolder.txtFont.setVisibility(View.VISIBLE);
                Typeface typeface;
                Log.e("myyFonts", mFontNames.get(i).getFontPath());
                if (mFontNames.get(i).getFontPath().contains("fonts")) {
                    typeface = Typeface.createFromAsset(mContext.getAssets(), mFontNames.get(i).getFontPath());
                } else {
                    typeface = Typeface.createFromFile(mFontNames.get(i).getFontPath());
                }
                myViewHolder.txtFont.setTypeface(typeface);
                myViewHolder.txtFont.setPadding(0, 0, 0, 0);
                // myViewHolder.txtFont.setText("Hello");
            }
            if (mParam.equals(mFontNames.get(i).getFontPath())) {
                myViewHolder.parentLayout.setBackgroundResource(R.drawable.rectangle_selected);
            } else {
                //myViewHolder.parentLayout.setBackgroundResource(R.drawable.rectangle_unselected);
                myViewHolder.parentLayout.setBackgroundResource(0);
            }

            myViewHolder.txtFont.setOnClickListener(v -> {
                if (mFontNames.get(i).isFont()) {
                    mListener.OnItemClicked(i);
                    lastCheckedPosition = i;
                    mParam = mFontNames.get(i).getFontPath();
                    notifyDataSetChanged();
                }
            });
        } else {
            myViewHolder.parentLayout.setVisibility(View.GONE);
            myViewHolder.imgColorPicker.setVisibility(View.VISIBLE);
            Glide.with(mContext).load(mFontNames.get(i).getImageDrawable()).into(myViewHolder.imgColorPicker);

            myViewHolder.imgColorPicker.setOnClickListener(v -> mListener.OnItemClicked(i));
        }
        //myViewHolder.imgColor.setVisibility(View.GONE);
    }

    @Override
    public int getItemCount() {
        return mFontNames.size()-1;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        public RelativeLayout parentLayout;
        private TextView txtFont;
        private ImageView imgLock;// imgMoreAPI;
        private ImageView imgColorPicker;// imgMoreAPI;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            txtFont = itemView.findViewById(R.id.txtFont);
            parentLayout = itemView.findViewById(R.id.parentLayout);
            imgColorPicker = itemView.findViewById(R.id.imgColorPicker);

        }
    }
}
