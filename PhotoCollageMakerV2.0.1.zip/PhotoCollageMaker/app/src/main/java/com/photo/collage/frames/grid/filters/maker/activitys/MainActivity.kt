package com.photo.collage.frames.grid.filters.maker.activitys

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.AsyncTask
import android.os.Bundle
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.google.android.gms.ads.InterstitialAd
import com.karumi.dexter.Dexter
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionDeniedResponse
import com.karumi.dexter.listener.PermissionGrantedResponse
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.single.PermissionListener
import com.photo.collage.frames.grid.filters.maker.R
import com.photo.collage.frames.grid.filters.maker.activitys.MainActivity
import com.photo.collage.frames.grid.filters.maker.activitys.MyCreationActivity
import com.photo.collage.frames.grid.filters.maker.ads.InterstitialAdHelper
import com.photo.collage.frames.grid.filters.maker.ads.InterstitialAdHelper.onInterstitialAdListener
import com.photo.collage.frames.grid.filters.maker.ads.NativeAdvanceHelper
import com.photo.collage.frames.grid.filters.maker.moreframes.sqlite_database.AdsPrefs
import com.photo.collage.frames.grid.filters.maker.utils.BitmapUtility
import com.photo.collage.frames.grid.filters.maker.utils.BitmapUtility.getBitmapFromView
import com.photo.collage.frames.grid.filters.maker.utils.BlurBuilder
import com.photo.collage.frames.grid.filters.maker.utils.StatusBarUtil
import com.scribble.animation.maker.video.effect.myadslibrary.dialog.ExitDialogFragment1
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.Helper
import com.scribble.animation.maker.video.effect.myadslibrary.ui.MoreAppActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup

class MainActivity : AppCompatActivity(), onInterstitialAdListener {
    //object
    private var mContext: Context? = null
    private var sharedPreferences: SharedPreferences? = null
    private var editor: SharedPreferences.Editor? = null
    private var interstitial: InterstitialAd? = null

    //Widgets
    private var mCLCollage: ConstraintLayout? = null
    private var mCLScrapbook: ConstraintLayout? = null
    private var mBtnImgCreation: ConstraintLayout? = null
    private var mBtnImgMore: ConstraintLayout? = null
    private var mBtnImgSettings: ConstraintLayout? = null
    private var fl_adplaceholder: FrameLayout? = null

    //Var
    private var currentVersion = ""
    private var mPermissionGranted = false
    private val permissions = arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
    private var isCollage = false

    //private var mIsBack = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        mContext = this@MainActivity
        fl_adplaceholder = findViewById(R.id.fl_adplaceholder)
        //Load Native Ads
        if (!AdsPrefs.getBoolean(this, AdsPrefs.IS_SUBSCRIBED)) {
            NativeAdvanceHelper.loadAd(mContext, fl_adplaceholder) {
                findViewById<View>(R.id.ivLogo).visibility = View.INVISIBLE
                findViewById<View>(R.id.ivTitle).visibility = View.INVISIBLE
            }
        }

        //check version
        try {
            currentVersion = packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
        }

        //new GetVersionCode().execute();
        initView()
        intiListener()
        initAction()
        initBottomMenu()
        sharedPreferences = getSharedPreferences("data", Context.MODE_PRIVATE)
        editor = sharedPreferences!!.edit()

        /*if (!sharedPreferences.getBoolean("isFirst", false)) {
            startAlarm();
        }*/if (!AdsPrefs.getBoolean(this, AdsPrefs.IS_SUBSCRIBED)) {
            interstitial = InterstitialAdHelper.getInstance().load(this, this)
        }
    }

    /*private void startAlarm() {
        Log.d(TAG, "startAlarm: ");
        AlarmManager manager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent myIntent;
        PendingIntent pendingIntent;

        // SET TIME HERE
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 16);
        //calendar.set(Calendar.MINUTE, 00);

        myIntent = new Intent(MainActivity.this, NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(this, 0, myIntent, 0);

        if (!sharedPreferences.getBoolean("isFirst", false)) {
            manager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
            editor.putBoolean("isFirst", true);
            editor.commit();
        }
        manager.setInexactRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), 3 * AlarmManager.INTERVAL_DAY
                , pendingIntent);
        //Log.d(TAG, "startAlarm: " + AlarmManager.INTERVAL_DAY * 3);
    }*/
    override fun onStart() {
        super.onStart()
        mCLScrapbook!!.isEnabled = true
        mCLCollage!!.isEnabled = true
        for (i in 0 until mCLScrapbook!!.childCount) {
            mCLScrapbook!!.getChildAt(i).isEnabled = true
        }
        for (i in 0 until mCLCollage!!.childCount) {
            mCLCollage!!.getChildAt(i).isEnabled = true
        }
    }

    override fun onResume() {
        super.onResume()
        try {
            if (AdsPrefs.getBoolean(this, AdsPrefs.IS_SUBSCRIBED)) {
                fl_adplaceholder?.visibility = View.GONE
                findViewById<View>(R.id.ivLogo).visibility = View.VISIBLE
                findViewById<View>(R.id.ivTitle).visibility = View.VISIBLE
            }
        } catch (e: Exception) {
        }
    }

    private fun initView() {
        //init AspectRatioImageView
        mCLCollage = findViewById(R.id.cl_collage)
        mCLScrapbook = findViewById(R.id.cl_scrapbook)
        mBtnImgCreation = findViewById(R.id.btnImgCreation)
        mBtnImgMore = findViewById(R.id.btnImgMore)
        mBtnImgSettings = findViewById(R.id.btnImgSettings)
    }

    private fun intiListener() {

        //handle event of AspectRatioImageView
        mCLCollage!!.setOnClickListener { view: View? ->
            Dexter.withContext(this@MainActivity)
                    .withPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    .withListener(object : PermissionListener {
                        override fun onPermissionGranted(response: PermissionGrantedResponse) {
                            isCollage = true
                            mCLCollage!!.isEnabled = false
                            mCLScrapbook!!.isEnabled = false
                            mCLCollage!!.isEnabled = false
                            mCLCollage!!.getChildAt(0).isEnabled = false
                            mCLCollage!!.getChildAt(1).isEnabled = false
                            openGallery("collage")
                        }

                        override fun onPermissionDenied(response: PermissionDeniedResponse) {
                            if (response.isPermanentlyDenied) {
                                openPermissionSettingDialog()
                            }
                        }

                        override fun onPermissionRationaleShouldBeShown(permission: PermissionRequest, token: PermissionToken) {
                            token.continuePermissionRequest()
                        }
                    })
                    .onSameThread()
                    .check()
        }

        /*for (int i = 0; i < mCLCollage.getChildCount(); i++) {
            isCollage = true;
            int finalI = i;
            mCLCollage.getChildAt(i).setOnClickListener(v -> {
                checkPermission();
                if (mPermissionGranted) {
                    mCLCollage.getChildAt(finalI).setEnabled(false);
                    mCLCollage.setEnabled(false);
                    openGallery("collage");
                }
            });
        }*/mCLScrapbook!!.setOnClickListener { view: View? ->
            Dexter.withContext(this@MainActivity)
                    .withPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    .withListener(object : PermissionListener {
                        override fun onPermissionGranted(response: PermissionGrantedResponse) {
                            isCollage = false
                            mCLCollage!!.isEnabled = false
                            mCLScrapbook!!.isEnabled = false
                            mCLScrapbook!!.isEnabled = false
                            mCLScrapbook!!.getChildAt(0).isEnabled = false
                            mCLScrapbook!!.getChildAt(1).isEnabled = false
                            openGallery("scrapbook")
                        }

                        override fun onPermissionDenied(response: PermissionDeniedResponse) {
                            if (response.isPermanentlyDenied) {
                                openPermissionSettingDialog()
                            }
                        }

                        override fun onPermissionRationaleShouldBeShown(permission: PermissionRequest, token: PermissionToken) {
                            token.continuePermissionRequest()
                        }
                    })
                    .onSameThread()
                    .check()
        }

        /*for (int i = 0; i < mCLScrapbook.getChildCount(); i++) {
            isCollage = false;
            int finalI = i;
            mCLScrapbook.getChildAt(i).setOnClickListener(v -> {
                checkPermission();
                if (mPermissionGranted) {
                    mCLScrapbook.getChildAt(finalI).setEnabled(false);
                    mCLScrapbook.setEnabled(false);
                    openGallery("scrapbook");
                }
            });
        }*/
    }

    private fun openGallery(collage: String) {
        val intent = Intent(this@MainActivity, GalleryActivity::class.java)
        intent.putExtra("type", collage)
        intent.putExtra("single", false)
        startActivity(intent)
        mCLCollage!!.isEnabled = true
        mCLScrapbook!!.isEnabled = true
    }

    private fun initAction() {
        StatusBarUtil.setTransparent(window, this@MainActivity)
        StatusBarUtil.setDarkIconStatusBar(window.decorView, this@MainActivity)
    }

    private fun initBottomMenu() {
        mBtnImgMore!!.setOnClickListener {
            val moreAppsIntent = Intent(this@MainActivity, MoreAppActivity::class.java)
            startActivity(moreAppsIntent)
        }
        mBtnImgSettings!!.setOnClickListener {
            val settingIntent = Intent(this@MainActivity, SettingsActivity::class.java)
            startActivity(settingIntent)
        }
        mBtnImgCreation!!.setOnClickListener {
            Dexter.withContext(this@MainActivity)
                    .withPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    .withListener(object : PermissionListener {
                        override fun onPermissionGranted(response: PermissionGrantedResponse) {
                            if (!AdsPrefs.getBoolean(this@MainActivity, AdsPrefs.IS_SUBSCRIBED) && interstitial != null && interstitial!!.isLoaded) {
                                interstitial!!.show()
                            } else {
                                val creationIntent = Intent(this@MainActivity, MyCreationActivity::class.java)
                                startActivity(creationIntent)
                            }
                        }

                        override fun onPermissionDenied(response: PermissionDeniedResponse) {
                            if (response.isPermanentlyDenied) {
                                openPermissionSettingDialog()
                            }
                        }

                        override fun onPermissionRationaleShouldBeShown(permission: PermissionRequest, token: PermissionToken) {
                            token.continuePermissionRequest()
                        }
                    })
                    .onSameThread()
                    .check()
        }
    }

    private fun openPermissionSettingDialog() {
        val permissionDialog = AlertDialog.Builder(this@MainActivity)
        permissionDialog.setTitle("Allow Permission")
        permissionDialog.setMessage("Storage Permission is required to save Image into External Storage")
        permissionDialog.setPositiveButton("Yes") { dialog, which ->
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", packageName, null)))
        }
        permissionDialog.setNegativeButton("No") { dialog, which -> Toast.makeText(mContext, "Permission required", Toast.LENGTH_SHORT).show() }
        permissionDialog.show()
    }

    private fun showUpdateDailog() {
        val alertDialogBuilder = AlertDialog.Builder(this)
        val textView = TextView(this)
        textView.textSize = 14f
        textView.setTextColor(ContextCompat.getColor(this, R.color.colorUpdateDialogText))
        //String msg = "A New version of Image Crop is available. <ul style='list-style-type:circle;'> <li><b> Remove ads. </b></li> <li><b> Add more functionality.</b></li> </ul>";
        val msg = "A newer version of the app is available.\nPlease update on Google Play."

        /*if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            alertDialogBuilder.setMessage(Html.fromHtml(msg, Html.FROM_HTML_MODE_LEGACY));
        } else {
            alertDialogBuilder.setMessage(Html.fromHtml(msg));
        }*/textView.text = msg
        textView.setPadding(50, 50, 50, 5)
        //alertDialogBuilder.setMessage(msg);
        alertDialogBuilder.setView(textView)
        alertDialogBuilder.setCancelable(true)
        alertDialogBuilder.setPositiveButton("CONTINUE") { dialog, id ->
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")))
            //rateUs();
            dialog.cancel()
        }
        alertDialogBuilder.show()
    }

    //check permission
    private fun checkPermission() {
        if (ContextCompat.checkSelfPermission(mContext!!, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            if (ContextCompat.checkSelfPermission(mContext!!, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                mPermissionGranted = true
            } else {
                mPermissionGranted = false
                //request permission
                if (isCollage) {
                    ActivityCompat.requestPermissions((mContext as Activity?)!!, permissions, REQUEST_PERMISSION_CODE)
                } else {
                    ActivityCompat.requestPermissions((mContext as Activity?)!!, permissions, REQUEST_PERMISSION_CODE2)
                }
            }
        } else {
            mPermissionGranted = false
            //request permission
            if (isCollage) {
                ActivityCompat.requestPermissions((mContext as Activity?)!!, permissions, REQUEST_PERMISSION_CODE)
            } else {
                ActivityCompat.requestPermissions((mContext as Activity?)!!, permissions, REQUEST_PERMISSION_CODE2)
            }
        }
    }

    protected fun startInstalledAppDetailsActivity(activity: Activity?) {
        if (activity == null) {
            return
        }
        val i = Intent()
        i.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        i.addCategory(Intent.CATEGORY_DEFAULT)
        i.data = Uri.parse("package:" + activity.packageName)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        i.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
        i.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
        activity.startActivity(i)
    }

    private var bottomSheetFragment: ExitDialogFragment1? = null
    private fun showAlertDialog() {
        try {
            bottomSheetFragment = ExitDialogFragment1("Leave App", "Do You Want To Leave App?", "Yes", "No", R.drawable.ic_exit_logout, mViewBitmap!!, AdsPrefs.getBoolean(this@MainActivity, AdsPrefs.IS_SUBSCRIBED), object : ExitDialogFragment1.OnButtonClickListener {
                override fun onPositive(bottomSheetDialo: ExitDialogFragment1?) {
                    bottomSheetDialo!!.dismiss()
                    findViewById<View>(R.id.mainBG).visibility = View.GONE
                    finishAffinity()
                }

                override fun onNegative(bottomSheetDialog: ExitDialogFragment1?) {
                    bottomSheetDialog!!.dismiss()
                    findViewById<View>(R.id.mainBG).visibility = View.GONE
                }

                override fun onDismiss() {
                    findViewById<View>(R.id.mainBG).visibility = View.GONE
                }
            })
            bottomSheetFragment!!.show(supportFragmentManager, "dialog_exit")
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onPause() {
        super.onPause()
        try {
            bottomSheetFragment?.dismiss()
        } catch (e: Exception) {
        }
    }

    private fun runBitmapTask(): Boolean {

        GlobalScope.launch {
            try {
                BitmapUtility.getBitmapFromView(findViewById<View>(R.id.rootView), findViewById<ImageView>(R.id.mainBG)).also {
                    it?.let {
                        try {
                            val bitmap = com.scribble.animation.maker.video.effect.myadslibrary.kotlin.helper.BlurBuilder.blur(mContext, it)
                            mViewBitmap = BitmapDrawable(resources, bitmap)
                            withContext(Dispatchers.Main) {
                                showAlertDialog()
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                            finish()
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                finish()
            }
        }
        return true
    }

    var mViewBitmap: Drawable? = null

    inner class BitmapBlurTask : AsyncTask<Void?, Void?, Void?>() {
        override fun doInBackground(vararg voids: Void?): Void? {
            findViewById<View>(R.id.rootView).post {
                val bitmap = getBitmapFromView(null)
                Glide.with(this@MainActivity).asBitmap().load(bitmap).into(object : CustomTarget<Bitmap?>() {
                    override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap?>?) {
                        try {
                            val bmp = BlurBuilder.blur(this@MainActivity, resource)
                            mViewBitmap = BitmapDrawable(resources, bmp)
                            Helper.mDrawable = mViewBitmap
                            Log.e(TAG, "onResourceReady: ")
                        } catch (ex: OutOfMemoryError) {
                            ex.printStackTrace()
                        } catch (ex: Exception) {
                            ex.printStackTrace()
                        }
                        //findViewById(R.id.mainBG).setVisibility(View.VISIBLE);
                    }

                    override fun onLoadCleared(placeholder: Drawable?) {}
                })
            }
            return null
        }
    }

    override fun onLoad() {}
    override fun onFailed() {}
    override fun onClosed() {
        interstitial = InterstitialAdHelper.getInstance().load(this, this)
        val creationIntent = Intent(this@MainActivity, MyCreationActivity::class.java)
        startActivity(creationIntent)
    }

    private inner class GetVersionCode : AsyncTask<Void?, String?, String?>() {
        protected override fun doInBackground(vararg voids: Void?): String? {
            var newVersion: String? = null
            return try {
                newVersion = Jsoup.connect("https://play.google.com/store/apps/details?id=" + mContext!!.packageName)
                        .timeout(30000)
                        .userAgent("Mozilla/5.0 (Windows; U; WindowsNT 5.1; en-US; rv1.8.1.6) Gecko/20070725 Firefox/2.0.0.6")
                        .referrer("http://www.google.com")
                        .get()
                        .select(".hAyfc .htlgb")[7]
                        .ownText()

                /* Document doc = Jsoup.parse(newVersion);
                //select the divs
                Elements divs = doc.select("img");

                for(Element e: divs){
                    Log.d(TAG, "doInBackground: "+e.attr("src"));
                    Log.d(TAG, "doInBackground: "+e.attr("data-src"));
                }*/

                //Log.d(TAG, "doInBackground:\n"+newVersion);
                newVersion
            } catch (e: Exception) {
                newVersion
            }
        }

        override fun onPostExecute(onlineVersion: String?) {
            super.onPostExecute(onlineVersion)
            if (onlineVersion != null && !onlineVersion.isEmpty()) {
                /*double cureentVersion = Double.parseDouble(currentVersion);
                double newVersion = Double.parseDouble(currentVersion);*/
                if (currentVersion != onlineVersion) {
                    showUpdateDailog()
                }
            }
            Log.d("update", "Current version " + currentVersion + "playstore version " + onlineVersion)
        }
    }

    fun getBitmapFromView(view: View?): Bitmap {
        var view = view
        if (view == null) {
            view = findViewById(R.id.rootView)
        }
        var width = view!!.width
        var height = view.height
        if (width == 0 || height == 0) {
            val displayMetrics = DisplayMetrics()
            windowManager.defaultDisplay.getMetrics(displayMetrics)
            height = displayMetrics.heightPixels
            width = displayMetrics.widthPixels
        }
        val returnedBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(returnedBitmap)
        var bgDrawable = view.background
        if (bgDrawable != null) bgDrawable.draw(canvas) else {
            bgDrawable = (findViewById<View>(R.id.mainBG) as ImageView).drawable
            if (bgDrawable != null) {
                bgDrawable.draw(canvas)
            } else {
                //Drawable drawable = ContextCompat.getDrawable()
                canvas.drawColor(Color.WHITE)
            }
        }
        view.draw(canvas)
        return returnedBitmap
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        when (requestCode) {
            REQUEST_PERMISSION_CODE -> {
                if (grantResults.size > 0) {
                    mPermissionGranted = if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                        grantResults[1] == PackageManager.PERMISSION_GRANTED
                    } else {
                        false
                    }
                }
                mCLCollage!!.isEnabled = true
                mCLScrapbook!!.isEnabled = true
                if (!mPermissionGranted) {
                    var showRationale = ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    if (showRationale) {
                        showRationale = ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    }
                    if (!showRationale) {

                        /*android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(new ContextThemeWrapper(this, R.style.MyDialogTheme));
                        builder.setTitle("Permission Required");
                        builder.setMessage("Storage Permission are required to save Image into External Storage");
                        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                                //ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, Constants.WRITE_EXTERNAL_STORAGE_CODE);
                                startInstalledAppDetailsActivity((Activity) mContext);
                            }
                        });
                        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                        builder.create().show();*/
                        android.app.AlertDialog.Builder(this)
                                .setTitle("Permission Required")
                                .setMessage("Storage Permission are required to save Image into External Storage")
                                .setPositiveButton("OK") { dialog, which ->
                                    dialog.dismiss()
                                    //ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, Constants.WRITE_EXTERNAL_STORAGE_CODE);
                                    startInstalledAppDetailsActivity(mContext as Activity?)
                                }.setNegativeButton("Cancel") { dialog, which -> dialog.dismiss() }.show()

                        // user also CHECKED "never ask again"
                        // you can either enable some fall back,
                        // disable features of your app
                        // or open another dialog explaining
                        // again the permission and directing to
                        // the app setting
                    }
                } else {
                    openGallery("collage")
                }
            }
            REQUEST_PERMISSION_CODE2 -> {
                if (grantResults.size > 0) {
                    mPermissionGranted = if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                        grantResults[1] == PackageManager.PERMISSION_GRANTED
                    } else {
                        false
                    }
                }
                if (!mPermissionGranted) {
                    var showRationale = ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    if (showRationale) {
                        showRationale = ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    }
                    if (!showRationale) {

                        /*android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(new ContextThemeWrapper(this, R.style.MyDialogTheme));
                        builder.setTitle("Permission Required");
                        builder.setMessage("Storage Permission are required to save Image into External Storage");
                        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                                //ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, Constants.WRITE_EXTERNAL_STORAGE_CODE);
                                startInstalledAppDetailsActivity((Activity) mContext);
                            }
                        });
                        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                        builder.create().show();*/

                        /* new android.app.AlertDialog.Builder(this)
                                .setTitle("Permission Required")
                                .setMessage("Storage Permission are required to save Image into External Storage")
                                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                        //ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, Constants.WRITE_EXTERNAL_STORAGE_CODE);
                                        startInstalledAppDetailsActivity((Activity) mContext);
                                    }
                                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        }).show();*/
                        openPermissionSettingDialog()

                        // user also CHECKED "never ask again"
                        // you can either enable some fall back,
                        // disable features of your app
                        // or open another dialog explaining
                        // again the permission and directing to
                        // the app setting
                    }
                } else {
                    openGallery("scrapbook")
                }
            }
            else -> super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        }
    }

    override fun onBackPressed() {
        /*if (!mIsBack) {
            mIsBack = true
            Toast.makeText(mContext, "Press again to exit", Toast.LENGTH_SHORT).show()
        } else {
            super.onBackPressed()
        }*/

        if (mViewBitmap == null) {
            runBitmapTask()
        } else {
            showAlertDialog()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        NativeAdvanceHelper.onDestroy()
    }

    companion object {
        //constant var
        private const val TAG = "MainActivity"
        private const val REQUEST_PERMISSION_CODE = 1001
        private const val REQUEST_PERMISSION_CODE2 = 1002
    }
}