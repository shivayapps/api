package com.photo.collage.frames.grid.filters.maker.ads;

import android.content.Context;
import android.util.Log;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.InterstitialAd;
import com.photo.collage.frames.grid.filters.maker.PhotoCollageMakerApplication;
import com.photo.collage.frames.grid.filters.maker.R;


public class InterstitialAdHelper {


    // InterstitialAdHelper

  /*

   // implement in your activity/fragment
            implements InterstitialAdHelper.onInterstitialAdListener

   // declare global variable
            private boolean isInterstitialAdLoaded = false;
            private InterstitialAd interstitial;


   // add/replace implemented methods

    @Override
    public void onLoad() {
        isInterstitialAdLoaded = true;
    }

    @Override
    public void onFailed() {
        isInterstitialAdLoaded = false;
        interstitial = InterstitialAdHelper.getInstance().load(mContext, this);
    }

    @Override
    public void onClosed() {
        isInterstitialAdLoaded = false;
        interstitial = InterstitialAdHelper.getInstance().load(mContext, this);

        // perform your action

    }

    //  load ad in oncreate method
            interstitial = InterstitialAdHelper.getInstance().load(mContext, this);


    // check if ad is loaded or not while want to show

    if (Share.isNeedToAdShow(mContext)) {
           if (isInterstitialAdLoaded) {
               interstitial.show();
           } else {
              // perform your action
           }
     }

    */


    private static InterstitialAdHelper instance;
    private String TAG = "Ads_Ads";

    public static InterstitialAdHelper getInstance() {
        if (instance == null) {
            synchronized (InterstitialAdHelper.class) {
                if (instance == null) {
                    instance = new InterstitialAdHelper();
                }
            }
        }
        return instance;
    }

    public InterstitialAd load(Context mContext, final onInterstitialAdListener adListener) {
        InterstitialAd interstitial = new InterstitialAd(mContext);
        try {
            String id = "";
            if(PhotoCollageMakerApplication.isTest)
                 id = mContext.getString(R.string.inter_ad_unit_id);
            else
                id = new ReferenceClass().getKeys("l_i");

            interstitial.setAdUnitId(id);
            interstitial.loadAd(AdsHelper.getRequestId());
            // Log.i(TAG, "Load Apps: " + Share.EnableAds);
            interstitial.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                    Log.i(TAG, "onAdLoaded: InterstitialAd");
                    adListener.onLoad();
                    // Code to be executed when an ad finishes loading.
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                    Log.i(TAG, "onAdFailedToLoad: InterstitialAd, Ad failed to load : " + errorCode);
                    adListener.onFailed();
                    // Code to be executed when an ad request fails.
                }

                @Override
                public void onAdOpened() {
                    Log.i(TAG, "onAdOpened: InterstitialAd");
                    // Code to be executed when the ad is displayed.
                }

                @Override
                public void onAdLeftApplication() {
                    Log.i(TAG, "onAdLeftApplication: InterstitialAd");
                    // Code to be executed when the user has left the app.
                }

                @Override
                public void onAdClosed() {
                    Log.i(TAG, "onAdClosed: InterstitialAd");
                    adListener.onClosed();
                    // Code to be executed when the interstitial ad is closed.
                }
            });

            return interstitial;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    public interface onInterstitialAdListener {
        void onLoad();

        void onFailed();

        void onClosed();
    }
}
