package com.photo.collage.frames.grid.filters.maker.fragments;

import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.photo.collage.frames.grid.filters.maker.comman.Constants;
import com.photo.collage.frames.grid.filters.maker.comman.GridSpacingItemDecoration;
import com.photo.collage.frames.grid.filters.maker.R;
import com.photo.collage.frames.grid.filters.maker.activitys.GalleryActivity;
import com.photo.collage.frames.grid.filters.maker.adepters.PhotoAdepter;
import com.photo.collage.frames.grid.filters.maker.interfaces.OnRefreshListener;
import com.photo.collage.frames.grid.filters.maker.model.AlbumModel;
import com.photo.collage.frames.grid.filters.maker.model.PhotoModel;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;

public class PhotoFragment extends Fragment implements OnRefreshListener {


    private RecyclerView mPhotoRecyclerView;
    private AlbumModel model;
    private PhotoAdepter photoAdepter;
    private ArrayList<PhotoModel> mList;

    private int index;


    public static PhotoFragment getInstance(AlbumModel albumModel) {
        PhotoFragment fragment = new PhotoFragment();
        Bundle bundle = new Bundle();
        bundle.putSerializable("albumModel", albumModel);
        fragment.setArguments(bundle);
        return fragment;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_photo, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mPhotoRecyclerView = view.findViewById(R.id.photo_list);
        mList = new ArrayList<>();

        setupRecyclerView();

        model = (AlbumModel) getArguments().getSerializable("albumModel");
        mList = model.getPhotos();
        if (model != null && mList != null) {
                Log.e("qwerty675675", "IF");
            photoAdepter = new PhotoAdepter(getContext(), mList);
            photoAdepter.setmListener((PhotoAdepter.OnPhotoSelectedListener) getActivity());
            mPhotoRecyclerView.setAdapter(photoAdepter);
            Log.e("qwerty675675", "IF= "+mList.size());
        }else{
            Log.e("qwerty675675", "ELSE");
        }
    }

    @Override
    public void onStart() {
        super.onStart();


        if (mList != null && mList.size() > 0) {
            deleteFile(0, true);
        }

        photoAdepter.notifyDataSetChanged();

    }


    public boolean deleteFile(int index, boolean isExits) {

        if (!isExits) {
            mList.remove(index);
            return true;
        } else {
            for (int i = 0; i < mList.size(); i++) {
                if (!new File(mList.get(i).getImagePath()).exists())
                    if (deleteFile(i, false)) {
                        i--;
                    }
            }
        }
        return false;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        ((GalleryActivity) context).setListener(this);
    }

    private void setupRecyclerView() {
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 3);
        mPhotoRecyclerView.setLayoutManager(gridLayoutManager);
        mPhotoRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mPhotoRecyclerView.addItemDecoration(new GridSpacingItemDecoration(3, dpToPx(5), true));
    }

    private int dpToPx(int dp) {
        Resources r = getResources();
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, r.getDisplayMetrics()));
    }

    @Override
    public void onRefresh(PhotoModel model) {
        if (model != null) {
            int position = this.model.getPhotos().indexOf(model);
            if (position == -1) {
                for (int i = 0; i < this.model.getPhotos().size(); i++) {
                    if (this.model.getPhotos().get(i).getImagePath().equals(model.getImagePath())) {
                        this.model.getPhotos().get(i).setCount(model.getCount());
                        model = this.model.getPhotos().get(i);
                        position = i;
                        break;
                    }
                }
            }
            photoAdepter.notifyItemChanged(position, model);
        } else {
            photoAdepter.notifyDataSetChanged();
        }
    }
}
