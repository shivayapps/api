package com.photo.collage.frames.grid.filters.maker.fragments;

import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.bumptech.glide.Glide;
import com.photo.collage.frames.grid.filters.maker.R;
import com.photo.collage.frames.grid.filters.maker.widgets.TouchImageView;


public class FullScreenDialog extends DialogFragment {

    private String imagePath;
    private Bitmap bitmap;

    public FullScreenDialog(String imagePath, Bitmap bitmap) {
        this.imagePath = imagePath;
        this.bitmap = bitmap;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NORMAL, R.style.FullScreenDialogStyle);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.layout_fullscreen_dialog, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TouchImageView touchImageView = view.findViewById(R.id.fullImageView);


        Glide.with(getActivity()).load(imagePath).into(touchImageView);

        view.findViewById(R.id.imgBtnClose).setOnClickListener(view1 -> {
            dismiss();
        });

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        Dialog dialog = getDialog();
        if (dialog != null) {
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            //dialog.getWindow().setBackgroundDrawable(new BitmapDrawable(getResources(), bitmap));
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#B5E9E9E9")));
        }
    }
}
