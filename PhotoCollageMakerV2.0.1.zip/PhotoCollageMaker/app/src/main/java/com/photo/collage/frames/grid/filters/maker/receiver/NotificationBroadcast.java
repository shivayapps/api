package com.photo.collage.frames.grid.filters.maker.receiver;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.util.Log;

import androidx.core.app.NotificationCompat;


import com.photo.collage.frames.grid.filters.maker.R;
import com.photo.collage.frames.grid.filters.maker.activitys.MainActivity;

import static android.app.PendingIntent.FLAG_ONE_SHOT;
import static android.content.Context.NOTIFICATION_SERVICE;

public class NotificationBroadcast extends BroadcastReceiver {
    private static final String TAG = "NotificationBroadcast";

    public static final String NOTIFICATION_CHANNEL_ID = "channel_id";
    public static final String CHANNEL_NAME = "Notification Channel";

    int unicode = 0x2764;
    int unicode1 = 0x1F3DE;
    int unicode2 = 0x1F4F7;
    String emoji,emoji1,emoji2;

    @Override
    public void onReceive(Context context, Intent intent) {

        Log.d(TAG, "onReceive: Notification");
        //if (!mySharedPref.getIsFirstNotification()) {
            setNotification(context);
          //  mySharedPref.setIsFirstNotification();
        //}
    }

    private void setNotification(Context context) {
        NotificationManager notificationManager = (NotificationManager)context.getSystemService(NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT);
            notificationChannel.enableLights(true);
            notificationChannel.enableVibration(true);
            notificationChannel.setLightColor(Color.GREEN);
            notificationChannel.setVibrationPattern(new long[] {
                    500,
                    500,
                    500,
                    500,
                    500
            });
            notificationChannel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            notificationManager.createNotificationChannel(notificationChannel);
            Log.d(TAG, "onReceive: "+notificationManager.getNotificationChannel("channel_id"));
        }


        NotificationCompat.Builder builder = new NotificationCompat.Builder(context,NOTIFICATION_CHANNEL_ID);

        Intent myIntent = new Intent(context, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context,
                0,
                myIntent,
                FLAG_ONE_SHOT );

        Log.d(TAG, "onReceive: Hello"+emoji);

        emoji=getEmojiByUnicode(unicode);
        emoji1=getEmojiByUnicode(unicode1);
        emoji2=getEmojiByUnicode(unicode2);

        builder.setAutoCancel(true)
                .setDefaults(Notification.DEFAULT_ALL)
                .setLargeIcon(BitmapFactory.decodeResource(context.getResources(), R.drawable.appicon))
                .setContentTitle("Loving Your New Photos?"+emoji)
                .setSmallIcon(R.drawable.appicon)
                .setContentIntent(pendingIntent)
                .setStyle(new NotificationCompat.BigTextStyle().bigText("Make It More Awesome Picture With Collage photo maker."+emoji2))
                .setContentText("Make It More Awesome Picture With Collage photo maker."+emoji2)
                .setSubText("Click Here")
                .setDefaults(Notification.DEFAULT_LIGHTS | Notification.DEFAULT_SOUND);


        notificationManager.notify(1,builder.build());

    }
    public String getEmojiByUnicode(int unicode){
        return new String(Character.toChars(unicode));
    }
}