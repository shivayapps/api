package com.photo.collage.frames.grid.filters.maker.moreframes

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.content.DialogInterface
import android.content.Intent
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.*
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.airbnb.lottie.LottieAnimationView
import com.airbnb.lottie.SimpleColorFilter
import com.andrefrsousa.superbottomsheet.SuperBottomSheetDialog
import com.andrefrsousa.superbottomsheet.SuperBottomSheetFragment
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.NetworkHelper
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.InterstitialAd
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardItem
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdCallback
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.photo.collage.frames.grid.filters.maker.BuildConfig
import com.photo.collage.frames.grid.filters.maker.R
import com.photo.collage.frames.grid.filters.maker.activitys.SubscriptionActivity
import com.photo.collage.frames.grid.filters.maker.ads.RewardVideoAds
import com.photo.collage.frames.grid.filters.maker.ads.RewardVideoAds.Companion.instence
import com.photo.collage.frames.grid.filters.maker.comman.GridSpacingItemDecoration
import com.photo.collage.frames.grid.filters.maker.model.TemplateItem
import com.photo.collage.frames.grid.filters.maker.moreframes.adapters.CakeLiveAdapter
import com.photo.collage.frames.grid.filters.maker.moreframes.callbacks.OnRewardEarn
import com.photo.collage.frames.grid.filters.maker.moreframes.dialog.WatchVideoDialog
import com.photo.collage.frames.grid.filters.maker.moreframes.sqlite_database.AdsPrefs
import com.photo.collage.frames.grid.filters.maker.moreframes.sqlite_database.DBHelper
import java.util.*

class FramesCategorySheet : SuperBottomSheetFragment, OnRewardEarn {
    private var progressBar: ProgressBar? = null
    private var onItemSelected: OnItemSelected? = null
    private var icBack: ImageView? = null
    private var btnShare: ImageView? = null
    private var tattoo_new_gift: LottieAnimationView? = null
    private var btnAd: ImageView? = null
    private var mRecyclerCollageFrames: RecyclerView? = null

    //private var mViewPagerCard: ViewPager? = null
    //private var mViewpagertab: TabLayout? = null
    private var imageItem1: TemplateItem? = null
    private var dbHelper: DBHelper? = null
    private var mTemplateItemList = ArrayList<TemplateItem>()
    private val mTempCakeList: ArrayList<TemplateItem>? = null
    private var adLayout: RelativeLayout? = null
    private var mActivity: Activity? = null
    private var isAdShow = false
    private var mType: String? = null
    private var mCakeType = 0
    private var mPosition = 0
    private var mCakeLiveAdapter: CakeLiveAdapter? = null
    private var mOnRewardEarn: OnRewardEarn? = null
    private var mSelectedPhotoPaths: List<String> = ArrayList()

    constructor()

    constructor(mForegroundList: ArrayList<TemplateItem>, lSelectedPhotoPaths: List<String>, onItemSelected: OnItemSelected?, cakeType: Int) {
        this.onItemSelected = onItemSelected
        this.mTemplateItemList = mForegroundList
        mType = "Stickers"
        mCakeType = cakeType
        mSelectedPhotoPaths = lSelectedPhotoPaths
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        super.onCreateView(inflater, container, savedInstanceState)
        val view = inflater.inflate(R.layout.fragment_frames_category_sheet, container, false)

        mOnRewardEarn = this

        dialog!!.setOnShowListener { dialog ->
            val d = dialog as SuperBottomSheetDialog
            val coordinatorLayout = d.findViewById<View>(R.id.coordinator) as CoordinatorLayout?
            val bottomSheet = coordinatorLayout!!.findViewById<FrameLayout>(R.id.super_bottom_sheet)
            val touch_outside = coordinatorLayout.findViewById<View>(R.id.touch_outside)
            val behavior: BottomSheetBehavior<*> = BottomSheetBehavior.from(bottomSheet)

            //BottomSheetBehavior.from(bottomSheet).peekHeight = Resources.getSystem().displayMetrics.heightPixels

            behavior.addBottomSheetCallback(object : BottomSheetBehavior.BottomSheetCallback() {
                override fun onStateChanged(bottomSheet: View, newState: Int) {
                    if (newState == BottomSheetBehavior.STATE_EXPANDED) {
                        try {
                            behavior.peekHeight = getPeekHeight()
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                }

                override fun onSlide(bottomSheet: View, slideOffset: Float) {
                    Log.d(TAG, "onSlide: $slideOffset")
                }
            })
            try {
                val valueAnimator = ValueAnimator.ofInt(getPeekHeight(), resources.displayMetrics.heightPixels)
                valueAnimator.interpolator = LinearInterpolator()
                valueAnimator.addUpdateListener { animation -> behavior.peekHeight = animation.animatedValue as Int }
                valueAnimator.addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        super.onAnimationEnd(animation)
                        //
                        try {
                            setStatusBarColor(0f)
                            setCornerRadius(0f)
                            behavior.state = BottomSheetBehavior.STATE_EXPANDED
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                })
                valueAnimator.duration = 800
                valueAnimator.start()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        return view
    }

    var mInterstitialAd: InterstitialAd? = null
    private fun setAndLoadInterstitialAds() {
        mInterstitialAd = InterstitialAd(mActivity)
        //var adsId = AppIDs.instnace!!.getGoogleInterstitial()
        mInterstitialAd!!.adUnitId = requireContext().resources.getString(R.string.inter_ad_unit_id)
        mInterstitialAd!!.loadAd(AdRequest.Builder().build())
        mInterstitialAd!!.adListener = object : AdListener() {
            override fun onAdLoaded() {
                super.onAdLoaded()
                tattoo_new_gift!!.visibility = View.VISIBLE
            }

            override fun onAdImpression() {
                super.onAdImpression()
                Log.d("InterstitialAds", "onAdImpression")

            }

            override fun onAdLeftApplication() {
                super.onAdLeftApplication()
                Log.d("InterstitialAds", "onAdLeftApplication")

            }

            override fun onAdClicked() {
                super.onAdClicked()
                Log.d("InterstitialAds", "onAdClicked")

            }

            override fun onAdFailedToLoad(p0: LoadAdError?) {
                super.onAdFailedToLoad(p0)
                Log.d("InterstitialAds", "LoadAdError")

            }

            override fun onAdClosed() {
                super.onAdClosed()
                tattoo_new_gift!!.visibility = View.GONE
                mInterstitialAd!!.loadAd(AdRequest.Builder().build())

            }

        }
    }

    val statusBarHeight: Int
        get() {
            var result = 0
            val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
            if (resourceId > 0) {
                result = resources.getDimensionPixelSize(resourceId)
            }
            return result
        }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        mActivity = activity
        dbHelper = DBHelper(activity)
        btnAd = view.findViewById(R.id.btnAd)
        icBack = view.findViewById(R.id.icBack)
        btnShare = view.findViewById(R.id.btnShare)
        tattoo_new_gift = view.findViewById(R.id.tattoo_new_gift)
        adLayout = view.findViewById(R.id.adLayout)
        mRecyclerCollageFrames = view.findViewById(R.id.recyclerCollageFrames)
        //mViewPagerCard = view.findViewById(R.id.viewPagerCard)
        //mViewpagertab = view.findViewById(R.id.meterialTabLayout)
        progressBar = view.findViewById(R.id.progressBar)

        if (AdsPrefs.getBoolean(context, AdsPrefs.IS_SUBSCRIBED)) {
            btnAd?.visibility = View.GONE
            btnShare?.visibility = View.VISIBLE
        }

        //NativeAdvanceHelper.loadAdSmall(activity, view.findViewById<FrameLayout>(R.id.fl_adplaceholder))

        try {
            progressBar!!.indeterminateDrawable.colorFilter = SimpleColorFilter(ContextCompat.getColor(requireActivity(), R.color.color_white))
        } catch (e: Exception) {
            e.printStackTrace()
        }
        if (!AdsPrefs.getBoolean(activity, AdsPrefs.IS_SUBSCRIBED, false)) {
            if (instence != null) {
                instence!!.loadVideoAdMain(mActivity!!)
//                loadInterstialAd()
            }
        } else {
        }
        icBack!!.setOnClickListener { dismiss() }
        tattoo_new_gift!!.setOnClickListener {
            if (mInterstitialAd != null && mInterstitialAd!!.isLoaded) {
                mInterstitialAd!!.show()
            }
        }
        btnAd!!.setOnClickListener {
            dismiss()
            startActivity(Intent(activity, SubscriptionActivity::class.java))
        }
        btnShare!!.setOnClickListener(View.OnClickListener { shareOwnApp() })

        if (mTemplateItemList != null && mTemplateItemList.size > 0) {
            progressBar!!.visibility = View.GONE
            setupViewPager()
        }
        try {
            //setAndLoadInterstitialAds()
        } catch (e: Exception) {

        }
    }

    var imagesIte1: TemplateItem? = null
    private fun setupViewPager() {
        val onItemSelectedListnerCake: CakeLiveAdapter.OnItemSelectedListner = CakeLiveAdapter.OnItemSelectedListner { position, imagesIte ->
            val isSubscribed = AdsPrefs.getBoolean(context, AdsPrefs.IS_SUBSCRIBED)
            if (imagesIte.isLocked && !isSubscribed) {
                if (NetworkHelper.isOnline(mActivity)) {
                    if (imagesIte.adCount >= 5) {
                        dismiss()
                        startActivity(Intent(activity, SubscriptionActivity::class.java))
                        return@OnItemSelectedListner
                    }

                    if (RewardVideoAds.Companion.instence != null && RewardVideoAds.Companion.instence?.loadVideoAdMain(mActivity!!) != null) {
//                        imagesIte1 = imagesIte

                        val rewardedAd: RewardedAd = RewardVideoAds.Companion.instence?.loadVideoAdMain(mActivity!!)!!
                        showAdDialog(position, rewardedAd, imagesIte.adCount)
                    } else {
                        Toast.makeText(activity, resources.getString(R.string.try_again_later), Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(mActivity, "Please check internet connection.", Toast.LENGTH_SHORT).show()
                }
            } else if (imagesIte.isPremium && !isSubscribed) {
                //if (parentFragment!!.fragmentManager!!.findFragmentByTag("Card_Category_Dialog") != null) {
                Log.d(TAG, "onUserEarnedReward: 4")
                //(parentFragment!!.fragmentManager!!.findFragmentByTag("Card_Category_Dialog") as FramesCategorySheet?)!!.dismiss()
                dismiss()
                //}
            } else {
                if (NetworkHelper.isOnline(mActivity)) {
                    if (mOnRewardEarn != null) {
                        mOnRewardEarn!!.onRewardEarn(imagesIte)
                        imagesIte1 = imagesIte
                    }
                    //if (parentFragment!!.fragmentManager!!.findFragmentByTag("Card_Category_Dialog") != null) {
                    Log.d(TAG, "onUserEarnedReward: 5")
                    dismiss()
                    // }
                } else {
                    Toast.makeText(mActivity, "Please check internet connection", Toast.LENGTH_SHORT).show()
                }
            }
        }
        val manager = GridLayoutManager(activity, 2)
        mRecyclerCollageFrames?.layoutManager = manager
        mRecyclerCollageFrames?.addItemDecoration(GridSpacingItemDecoration(2, dpToPx(18), true))
        mRecyclerCollageFrames?.itemAnimator = DefaultItemAnimator()

        mRecyclerCollageFrames?.setItemViewCacheSize(50)

        object : AsyncTask<Void?, Void?, Void?>() {
            override fun doInBackground(vararg voids: Void?): Void? {
                val mWallpaperList: ArrayList<TemplateItem> = ArrayList<TemplateItem>()
                try {
                    if (AdsPrefs.getBoolean(activity, AdsPrefs.IS_SUBSCRIBED, false)) {
                        /* if (mList != null) {
                             mTempList.addAll(mWallpaperList)
                         }*/
                    } else {
                        for (i in mTemplateItemList.indices) {
                            if (!AdsPrefs.getBoolean(context, AdsPrefs.IS_SUBSCRIBED)) {
                                val pair = dbHelper!!.isExist(mTemplateItemList[i].preview)
                                if (pair.first == true) {
                                    if (pair.second != -1) {
                                        mTemplateItemList[i].adCount = mTemplateItemList[i].adCount - 1
                                    }
                                    if (pair.second!! <= 0) {
                                        mTemplateItemList[i].isLocked = false
                                        mTemplateItemList[i].isPremium = false
                                        mTemplateItemList[i].isFree = true
                                    }
                                    Log.e("qwertyuuuu", pair.first.toString() + " == " + pair.second)
                                }
                            }

                            /* if (pair.first!!) {
                                 mTemplateItemList?.add(TemplateItem(
                                         mParamList.get(i),
                                         false,
                                         pair.second != 0,
                                         pair.second == 0,
                                         pair.second
                                 ))
                             } else {
                                 mTemplateItemList?.add(TemplateItem(
                                         mParamList.get(i),
                                         false,
                                         mParamList.get(i).getIs_premium() !== 0,
                                         false,
                                         numberOfAd(mParamList.get(i).getCoins())
                                 ))
                             }*/
                        }
                    }
                } catch (ex: java.lang.Exception) {
                    ex.stackTrace
                }
                return null
            }

            override fun onPostExecute(aVoid: Void?) {
                super.onPostExecute(aVoid)
                progressBar?.visibility = View.GONE
                mCakeLiveAdapter = CakeLiveAdapter(mTemplateItemList, mSelectedPhotoPaths, mActivity, onItemSelectedListnerCake)
                mRecyclerCollageFrames?.adapter = mCakeLiveAdapter

            }
        }.execute()

        /*mViewPagerCard!!.addOnPageChangeListener(object : OnPageChangeListener {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {}
            override fun onPageSelected(position: Int) {
                mPosition = position
                //Constants.mSelectTattooCategoryposition = position
            }

            override fun onPageScrollStateChanged(state: Int) {}
        })
        for (i in mForegroundParaList!!.indices) {
            mViewpagertab!!.addTab(mViewpagertab!!.newTab().setText(getCategoryName(i)))
        }
        val cardCategoryPagerAdepter = FrameCategoryPagerAdepter(childFragmentManager, null, mForegroundParaList, mType)
        mViewPagerCard!!.adapter = cardCategoryPagerAdepter
        mViewpagertab!!.setupWithViewPager(mViewPagerCard)

        try {
            if (mForegroundList != null) {
                for (i in mForegroundList!!.indices) {
                    try {
                        val view1 = LayoutInflater.from(activity).inflate(R.layout.rv_tab, null)
                        mViewpagertab!!.getTabAt(i)!!.customView = view1
                        val textView = view1.findViewById<TextView>(R.id.textTab)
                        textView.text = getCategoryName(i)
                        Log.d(TAG, "setupViewPager: " + textView.text)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            } else {
                for (i in mForegroundParaList!!.indices) {
                    try {
                        val view1 = LayoutInflater.from(activity).inflate(R.layout.rv_tab, null)
                        mViewpagertab!!.getTabAt(i)!!.customView = view1
                        val textView = view1.findViewById<TextView>(R.id.textTab)
                        textView.text = getCategoryName(i)
                        Log.d(TAG, "setupViewPager: " + textView.text)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        BottomSheetUtils.setupViewPager(mViewPagerCard)*/
    }

    private fun showAdDialog(position: Int, gameOverRewardedAd: RewardedAd, numberOfAd: Int) {
        var s = resources.getString(R.string.do_you_want_watch_video)
        s = resources.getString(R.string.do_you_want_watch_video_cake)

        val bottomSheetFragment = WatchVideoDialog(resources.getString(R.string.watch_video), s, resources.getString(R.string.watch_ad), resources.getString(R.string.subscribe), R.drawable.ic_video, object : WatchVideoDialog.OnButtonClickListener {
            override fun onPositive(bottomSheetDialo: WatchVideoDialog) {
                bottomSheetDialo.dismiss()
                showAdReward(position, gameOverRewardedAd, numberOfAd)
            }

            override fun onNegative(bottomSheetDialog: WatchVideoDialog) {
                bottomSheetDialog.dismiss()
                imagesIte1=null
                dismiss()
                startActivity(Intent(activity, SubscriptionActivity::class.java))
            }
        })
        bottomSheetFragment.show(childFragmentManager, "dialog")
    }


    private fun getCategoryName(position: Int): String {
        /*return try {
            if (mForegroundList != null) {
                val arr = mForegroundList!![position].name*//*.split("_".toRegex()).toTypedArray()*//*
                arr
                *//*if (arr.size > 0) {
                    arr[arr.size - 1]
                } else {
                    arr[0]
                }*//*
            } else {
                val arr = mForegroundParaList!![position].name*//*.split("_".toRegex()).toTypedArray()*//*
                arr
                *//*if (arr.size > 0) {
                    arr[arr.size - 1]
                } else {
                    arr[0]
                }*//*
            }
        } catch (e: Exception) {
            e.printStackTrace()
            "Default"
        }*/
        return ""
    }

    private fun shareOwnApp() {
        val shareIntent = Intent(Intent.ACTION_SEND)
        shareIntent.type = "text/plain"
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Photo Collage Maker")
        var shareMessage = "\nGo with Photo Collage Maker and Make Someone's day very special....\n\n"
        shareMessage += "https://play.google.com/store/apps/details?id=${requireContext().packageName}"
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
        startActivity(Intent.createChooser(shareIntent, "Choose One"))
    }

    private fun showAd() {
        /*Log.e("dfsfsdf", "clicked")
        if (App.instance!!.requestNewInterstitial()) {
            App.instance!!.mInterstitialAd!!.adListener = object : AdListener() {
                override fun onAdClosed() {
                    super.onAdClosed()
                    loadInterstialAd()
                    Log.e("dfsfsdf", "onAdClosed")
                }

                override fun onAdFailedToLoad(i: Int) {
                    super.onAdFailedToLoad(i)
                    Log.e("dfsfsdf", "onAdFailedToLoad")

                }

                override fun onAdLoaded() {
                    super.onAdLoaded()
                    Log.e("dfsfsdf", "onAdLoaded")
                }
            }
        } else {
            Log.e("dfsfsdf", "try again")
            Toast.makeText(activity, "Try again later.", Toast.LENGTH_SHORT).show()
        }*/
    }

    private fun setData() {
        if (mTemplateItemList != null && mTemplateItemList.size > 0) {
            progressBar!!.visibility = View.GONE
            setupViewPager()
        } else {
            mTemplateItemList = ArrayList()
            //checkStatus()
            updateUI()
        }
    }

    override fun onDismiss(dialog: DialogInterface) {
        super.onDismiss(dialog)
        //if (imageItem != null && mCakeType == NAME_ON_CAKE) {
        //   onItemSelected!!.onItemSelected(imageItem)
        //} else if (imageItem1 != null) {
        if (imageItem1 != null) {
            onItemSelected!!.onItemSelected(imageItem1)
        } else {
            if (imagesIte1 != null) {
                onItemSelected!!.onItemSelected(imagesIte1)
            }
        }
        //}
        onItemSelected!!.dismiss()
    }

    /*fun showAdReward(position: Int, gameOverRewardedAd: RewardedAd) {
        isAdShow = true
        if (gameOverRewardedAd.isLoaded) {
            val adCallback: RewardedAdCallback = object : RewardedAdCallback() {
                override fun onRewardedAdOpened() {
                    // Ad opened.
                    isAdShow = true
                }

                override fun onRewardedAdClosed() {
                    // Ad closed.
                    if (instence != null) {
                        instence!!.loadVideoAdMain(mActivity!!)
                    }
                    isAdShow = false
                }

                override fun onUserEarnedReward(reward: RewardItem) {
                    // User earned reward.
                    dbHelper!!.insertPath(mTemplateItemList!![mPosition].preview)
                    *//*if (mTempForgroundList != null) {
                        mTempForgroundList[position].isFree = true
                        mTempForgroundList[position].isLocked = false
                    }*//*
                        imageItem1 = mTemplateItemList!![mPosition]
                    isAdShow = false
                    dismiss()
                    if (instence != null) {
                        instence!!.loadVideoAdMain(mActivity!!)
                    }
                }

                override fun onRewardedAdFailedToShow(errorCode: Int) {
                    // Ad failed to display.
                    isAdShow = false
                    if (instence != null) {
                        instence!!.loadVideoAdMain(mActivity!!)
                    }
                    Toast.makeText(activity, "Please try again later.", Toast.LENGTH_SHORT).show()
                }
            }
            gameOverRewardedAd.show(activity, adCallback)
        } else {
            isAdShow = false
            if (instence != null) {
                instence!!.loadVideoAdMain(mActivity!!)
            }
            Toast.makeText(activity, "Please try again later.", Toast.LENGTH_SHORT).show()
        }
    }*/
    open fun showAdReward(position: Int, gameOverRewardedAd: RewardedAd, numberOfAd: Int) {
        isAdShow = true
        if (gameOverRewardedAd.isLoaded) {
            val adCallback: RewardedAdCallback = object : RewardedAdCallback() {
                override fun onRewardedAdOpened() {
                    // Ad opened.
                    isAdShow = true
                }

                override fun onRewardedAdClosed() {
                    // Ad closed.
                    if (BuildConfig.DEBUG && instence == null) {
                        error("Assertion failed")
                    }
                    instence?.loadVideoAdMain(mActivity!!)
                    isAdShow = false
                }

                override fun onUserEarnedReward(reward: RewardItem) {
                    // User earned reward.
                    var count = numberOfAd
                    Log.d("ADSASASAS", "onUserEarnedReward ${mTemplateItemList[position].adCount}")
                    if (!dbHelper!!.isExist(mTemplateItemList[position].preview).first!!) {
                        dbHelper!!.insertPath(mTemplateItemList[position].preview, --count)
                    } else {
                        dbHelper!!.updateCount(mTemplateItemList[position].preview, --count)
                    }
                    if (mTemplateItemList.size != 0) {
                        if (numberOfAd > 1) {
                            imagesIte1=null
                            mTemplateItemList[position].isFree = false
                            mTemplateItemList[position].isLocked = true
                            mTemplateItemList[position].adCount = numberOfAd-1
                            mCakeLiveAdapter!!.notifyItemChanged(position)
                            Log.d("ADSASASAS", "if ${mTemplateItemList[position].adCount}")

                        } else {
                            mTemplateItemList[position].isFree = true
                            mTemplateItemList[position].isLocked = false
                            mTemplateItemList[position].adCount = 0
                            Log.d("ADSASASAS", "else ${mTemplateItemList[position].adCount}")
                            mCakeLiveAdapter!!.notifyItemChanged(position)
                            if (NetworkHelper.isOnline(mActivity)) {
                                if (mOnRewardEarn != null) {
                                    mOnRewardEarn!!.onRewardEarn(imagesIte1)
                                    dismiss()
                                }
                                //if (parentFragment!!.fragmentManager!!.findFragmentByTag("Card_Category_Dialog") != null) {
                                //    Log.d(TAG, "onUserEarnedReward: 1")
                                //(parentFragment!!.fragmentManager!!.findFragmentByTag("Card_Category_Dialog") as FramesCategorySheet?)!!.dismiss()
                                Log.d("ADSASASAS", "dismiss ${mTemplateItemList[position].adCount}")

                                //}
                            } else {
                                Toast.makeText(mActivity, "Please check internet connection", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }

                    /*if (mTempCakeList != null) {
                    mTempCakeList.get(position).setFree(true);
                    mTempCakeList.get(position).setLocked(false);
                }*/

                    //imageItem = mForegroundList.get(0).getImage().get(position);
                    isAdShow = false
                    assert(RewardVideoAds.Companion.instence != null)
                    RewardVideoAds.Companion.instence!!.loadVideoAdMain(mActivity!!)
                }

                override fun onRewardedAdFailedToShow(errorCode: Int) {
                    // Ad failed to display.
                    imagesIte1=null
                    isAdShow = false
                    assert(RewardVideoAds.Companion.instence != null)
                    RewardVideoAds.Companion.instence!!.loadVideoAdMain(mActivity!!)
                    Toast.makeText(activity, "Please try again later", Toast.LENGTH_SHORT).show()
                }
            }
            gameOverRewardedAd.show(activity, adCallback)
        } else {
            isAdShow = false
            imagesIte1=null
            assert(RewardVideoAds.Companion.instence != null)
            RewardVideoAds.Companion.instence!!.loadVideoAdMain(mActivity!!)
            Toast.makeText(activity, "Please try again later", Toast.LENGTH_SHORT).show()
        }
    }


    override fun onRewardEarn(imageItem: TemplateItem) {
        this.imageItem1 = imageItem
    }

    interface OnItemSelected {
        fun onItemSelected(imagesItem: TemplateItem?)
        fun dismiss()
    }

    private fun dpToPx(dp: Int): Int {
        val r = resources
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), r.displayMetrics))
    }

    private fun checkStatus() {
        /*   try {
               if (!NetworkHelper.isOnline(Objects.requireNonNull(activity))) {
                   Log.i("789412312332", "You are offline")
                   progressBar!!.visibility = View.GONE
                   Toast.makeText(activity, resources.getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show()
                   dismiss()
               } else {
                   if (NetworkHelper.isWifiConnected(activity)) {
                       val proxy = WifiConfiguration(activity)
                       if (proxy.isProxySetted) {
                           progressBar!!.visibility = View.GONE
                           Toast.makeText(activity, resources.getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show()
                           dismiss()
                           return
                       }
                   }
                   if (NetworkHelper.isVpnRunning()) {
                       Log.d("789412312332", "checkStatus: VPN Activated")
                       progressBar!!.visibility = View.GONE
                       Toast.makeText(activity, resources.getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show()
                       dismiss()
                       return
                   }
                   callParamAPI()
               }
           } catch (e: Exception) {
               e.printStackTrace()
           }*/
    }

    private fun callParamAPI() {
        /*apiInterface = APIClient.getClient()!!.create(APIInterface::class.java)
        val call = apiInterface!!.parameterList
        call.enqueue(object : Callback<Response> {
            override fun onResponse(call: Call<Response>, response: retrofit2.Response<Response>) {
                Log.d("789412312331", "onResponse: " + response.body())
                if (isAdded) {
                    val model = response.body()
                    if (mDataParaList == null) {
                        mDataParaList = ArrayList()
                        mForegroundParaList = ArrayList()
                    }
                    mDataParaList!!.clear()
                    mForegroundParaList!!.clear()
                    if (model != null && model.parameters != null) {
                        mDataParaList!!.addAll(model.parameters)
                        updateUI()
                    } else {
                        Toast.makeText(activity, resources.getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
                        dismiss()
                        Objects.requireNonNull(activity)!!.runOnUiThread {
                            progressBar!!.visibility = View.GONE
                        }
                    }
                }
            }

            override fun onFailure(call: Call<Response>, t: Throwable) {
                dismiss()
            }
        })*/
    }

    fun createAndLoadRewardedAd(adUnitId: String?): RewardedAd {
        val rewardedAd = RewardedAd(activity, adUnitId)
        val adLoadCallback: RewardedAdLoadCallback = object : RewardedAdLoadCallback() {
            override fun onRewardedAdLoaded() {
                // Ad successfully loaded.
            }

            override fun onRewardedAdFailedToLoad(errorCode: Int) {
                // Ad failed to load.
            }
        }
        rewardedAd.loadAd(AdRequest.Builder().build(), adLoadCallback)
        return rewardedAd
    }

    private fun loadInterstialAd() {
        /*App.instance!!.mInterstitialAd!!.adListener = null
        App.instance!!.mInterstitialAd = null
        App.instance!!.ins_adRequest = null
        App.instance!!.LoadAds()
        App.instance!!.mInterstitialAd!!.adListener = object : AdListener() {
            override fun onAdLoaded() {
                super.onAdLoaded()
            }

            override fun onAdClosed() {
                super.onAdClosed()
            }

            override fun onAdFailedToLoad(i: Int) {
                super.onAdFailedToLoad(i)
                loadInterstialAd()
            }
        }*/
    }

    private fun updateUI() {
        /*       for (i in mDataParaList!!.indices) {
                       val imageItems = mDataParaList!![i].categoryParameters
                       if (imageItems == null || imageItems != null && imageItems.size <= 0) continue
       //                Collections.shuffle(imageItems)
                       mDataParaList!![i].categoryParameters = imageItems
                       mForegroundParaList!!.add(mDataParaList!![i])
               }*/
        setData()
    }

    fun getFilePath(path: String): String {
        return "file:///android_asset/$path"
    }

    companion object {
        private const val TAG = "CardCategorySheet"
        const val NAME_ON_CAKE = 0
        const val PHOTO_ON_CAKE = 1
        const val TEXTART = 2
    }

}