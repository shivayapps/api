package com.photo.collage.frames.grid.filters.maker.adepters;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.photo.collage.frames.grid.filters.maker.R;
import com.photo.collage.frames.grid.filters.maker.model.AlbumModel;
import com.photo.collage.frames.grid.filters.maker.model.PhotoModel;

import java.util.ArrayList;

public class AlbumAdepter extends RecyclerView.Adapter<AlbumAdepter.MyViewHolder>  {

    private static final String TAG = "AlbumAdepter";

    private Context mCtx;
    private ArrayList<AlbumModel> mList;
    private OnAlbumClickListener mListener;

    public AlbumAdepter(Context mCtx, ArrayList<AlbumModel> mList, OnAlbumClickListener mListener) {
        this.mCtx = mCtx;
        this.mList = mList;
        this.mListener = mListener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(mCtx).inflate(R.layout.layout_album_item,null);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int i) {

        holder.txtAlbumName.setText(mList.get(i).getAlbumName());
        /*holder.imgAlbum.post(() -> {
            holder.imgAlbum.getLayoutParams().height = holder.imgAlbum.getWidth();
            holder.imgAlbum.requestLayout();
        });*/

        Glide.with(mCtx).load(mList.get(i).getPhotos().get(0).getImagePath()).error(R.drawable.corrupt_file).override(300).listener(new RequestListener<Drawable>() {
            @Override
            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                Log.e("qwerty123123123","onLoadFailed");
                holder.imgAlbum.setTag("corrupted");
                holder.imgAlbum.setPadding(50, 50, 50, 50);
                holder.imgAlbum.setBackgroundColor(Color.WHITE);

                holder.imgAlbum.setOnClickListener(view -> {
                    mListener.onAlbumClick(mList.get(i));
                });
                return false;
            }

            @Override
            public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                Log.e("qwerty123123123","onResourceReady");
                holder.imgAlbum.setTag("ok");
                holder.imgAlbum.setPadding(0, 0, 0, 0);

                holder.imgAlbum.setOnClickListener(view -> {
                    mListener.onAlbumClick(mList.get(i));
                });
                return false;
            }
        }).into(holder.imgAlbum);


        holder.txtCount.setText(String.valueOf(mList.get(i).getPhotos().size()) + " Photos");
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{

        private ImageView imgAlbum;
        private TextView txtAlbumName,txtCount;

         MyViewHolder(@NonNull View itemView) {
            super(itemView);

            imgAlbum = itemView.findViewById(R.id.imAlbumImg);
            txtAlbumName = itemView.findViewById(R.id.txtAlbumName);
            txtCount = itemView.findViewById(R.id.txtCount);


        }
    }


    public interface OnAlbumClickListener{
        void onAlbumClick(AlbumModel model);
    }
}
