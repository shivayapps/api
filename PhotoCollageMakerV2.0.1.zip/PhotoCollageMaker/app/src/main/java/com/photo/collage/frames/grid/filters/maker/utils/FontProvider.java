package com.photo.collage.frames.grid.filters.maker.utils;

import android.content.res.Resources;
import android.graphics.Typeface;
import android.text.TextUtils;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FontProvider {
    private static final String DEFAULT_FONT_NAME = "1";

    private final Map<String, Typeface> typefaces;
    private final Map<String, String> fontNameToTypefaceFile;
    private final Resources resources;
    private final List<String> fontNames;

    public FontProvider(Resources resources) {
        this.resources = resources;

        typefaces = new HashMap<>();
        // populate fonts
        fontNameToTypefaceFile = new HashMap<>();
        fontNameToTypefaceFile.put("1", "1.ttf");
        fontNameToTypefaceFile.put("6", "6.ttf");
        fontNameToTypefaceFile.put("ardina_script", "ardina_script.ttf");
        fontNameToTypefaceFile.put("beyondwonderland", "beyondwonderland.ttf");
        fontNameToTypefaceFile.put("c", "c.ttf");
        fontNameToTypefaceFile.put("coventry_garden_nf", "coventry_garden_nf.ttf");
        fontNameToTypefaceFile.put("font3", "font3.ttf");
        fontNameToTypefaceFile.put("font6", "font6.ttf");
        fontNameToTypefaceFile.put("font10", "font10.ttf");
        fontNameToTypefaceFile.put("font16", "font16.ttf");
        fontNameToTypefaceFile.put("font20", "font20.ttf");
        fontNameToTypefaceFile.put("g", "g.ttf");
        fontNameToTypefaceFile.put("h", "h.ttf");
        fontNameToTypefaceFile.put("h2", "h2.ttf");
        fontNameToTypefaceFile.put("h3", "h3.ttf");
        fontNameToTypefaceFile.put("h6", "h6.ttf");
        fontNameToTypefaceFile.put("h7", "h7.ttf");
        fontNameToTypefaceFile.put("h8", "h8.ttf");
        fontNameToTypefaceFile.put("h15", "h15.ttf");
        fontNameToTypefaceFile.put("h18", "h18.ttf");
        fontNameToTypefaceFile.put("h19", "h19.ttf");
        fontNameToTypefaceFile.put("h20", "h20.ttf");
        fontNameToTypefaceFile.put("m", "m.ttf");
        fontNameToTypefaceFile.put("o", "o.ttf");
        fontNameToTypefaceFile.put("saman", "saman.ttf");
        fontNameToTypefaceFile.put("variane", "variane.ttf");
        fontNameToTypefaceFile.put("youmurdererbb", "youmurdererbb.ttf");
        fontNameToTypefaceFile.put("neon", "neon.ttf");

        fontNames = new ArrayList<>(fontNameToTypefaceFile.values());
    }

    /**
     * @param typefaceName must be one of the font names provided from {@link FontProvider#getFontNames()}
     * @return the Typeface associated with {@code typefaceName}, or {@link Typeface#DEFAULT} otherwise
     */
    public Typeface getTypeface(@Nullable String typefaceName) {
        if (TextUtils.isEmpty(typefaceName)) {
            return Typeface.DEFAULT;
        } else {
            //noinspection Java8CollectionsApi
            if (typefaces.get(typefaceName) == null) {
                typefaces.put(typefaceName,
                        Typeface.createFromAsset(resources.getAssets(), "fonts/" + fontNameToTypefaceFile.get(typefaceName)));
            }
            return typefaces.get(typefaceName);
        }
    }

    /**
     * use {@link FontProvider#getTypeface(String) to get Typeface for the font name}
     *
     * @return list of available font names
     */
    public List<String> getFontNames() {
        return fontNames;
    }

    /**
     * @return Default Font Name - <b>Helvetica</b>
     */
    public String getDefaultFontName() {
        return DEFAULT_FONT_NAME;
    }
}
