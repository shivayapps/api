package com.photo.collage.frames.grid.filters.maker.blurry.internal;

/* renamed from: jp.wasabeef.blurry.internal.BlurFactor */
public class BlurFactor {
    public static final int DEFAULT_RADIUS = 25;
    public static final int DEFAULT_SAMPLING = 1;
    public int color = 0;
    public int height;
    public int radius = 25;
    public int sampling = 1;
    public int width;
}
