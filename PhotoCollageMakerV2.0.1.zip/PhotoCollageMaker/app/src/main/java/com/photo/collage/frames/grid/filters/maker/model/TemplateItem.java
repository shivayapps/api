package com.photo.collage.frames.grid.filters.maker.model;


import java.util.ArrayList;
import java.util.List;

import dauroi.photoeditor.model.ImageTemplate;


public class TemplateItem extends ImageTemplate {
    private int mSectionManager;
    private int mSectionFirstPosition;
    private boolean mIsHeader = false;
    private String mHeader;
    private boolean isLocked = false;
    private boolean isPremium = false;
    private boolean isFree = true;
    private int adCount = 0;

    private boolean isTemplateLoaded = false;

    private boolean mIsAds = false;
    private ArrayList<PhotoItem> mPhotoItemList = new ArrayList<>();

    public TemplateItem() {

    }

    public TemplateItem(ImageTemplate template) {
        setLanguages(template.getLanguages());
        setPackageId(template.getPackageId());
        setPreview(template.getPreview());
        setTemplate(template.getTemplate());
        setChild(template.getChild());
        setTitle(template.getTitle());
        setThumbnail(template.getThumbnail());
        setSelectedThumbnail(template.getSelectedThumbnail());
        setSelected(template.isSelected());
        // To be used to display
        setShowingType(template.getShowingType());
        // To be used in database
        setLastModified(template.getLastModified());
        setStatus(template.getStatus());
        setId(template.getId());
        mPhotoItemList = PhotoLayout.parseImageTemplate(template);
    }

    public boolean isTemplateLoaded() {
        return isTemplateLoaded;
    }

    public void setTemplateLoaded(boolean templateLoaded) {
        isTemplateLoaded = templateLoaded;
    }

    public int getAdCount() {
        return adCount;
    }

    public void setAdCount(int adCount) {
        this.adCount = adCount;
    }

    public boolean isFree() {
        return isFree;
    }

    public void setFree(boolean free) {
        isFree = free;
    }

    public boolean isLocked() {
        return isLocked;
    }

    public void setLocked(boolean locked) {
        isLocked = locked;
    }

    public boolean isPremium() {
        return isPremium;
    }

    public void setPremium(boolean premium) {
        isPremium = premium;
    }

    public void setHeader(String header) {
        mHeader = header;
    }

    public String getHeader() {
        return mHeader;
    }

    public ArrayList<PhotoItem> getPhotoItemList() {
        return mPhotoItemList;
    }

    public void setmPhotoItemList(ArrayList<PhotoItem> mPhotoItemList) {
        this.mPhotoItemList = mPhotoItemList;
    }

    public void setSectionFirstPosition(int sectionFirstPosition) {
        mSectionFirstPosition = sectionFirstPosition;
    }

    public int getSectionFirstPosition() {
        return mSectionFirstPosition;
    }

    public void setSectionManager(int sectionManager) {
        mSectionManager = sectionManager;
    }

    public int getSectionManager() {
        return mSectionManager;
    }

    public boolean isHeader() {
        return mIsHeader;
    }

    public void setIsHeader(boolean isHeader) {
        mIsHeader = isHeader;
    }

    public void setIsAds(boolean isAds) {
        mIsAds = isAds;
    }

    public boolean isAds() {
        return mIsAds;
    }
}
