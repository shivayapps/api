package com.photo.collage.frames.grid.filters.maker.utils

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.view.View
import android.widget.ImageView

object BitmapUtility {

    fun getBitmapFromView(view: View?, image: ImageView?): Bitmap {

        var width = view!!.width
        var height = view.height

        if (width == 0 || height == 0) {
            val shared = SharedPrefs(view.context)
            height = shared.deviceHeight
            width = shared.deviceWidth
        }
        val returnedBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(returnedBitmap)
        /*  var bgDrawable = view.background
          if (bgDrawable != null)
              bgDrawable.draw(canvas)
          else {*/
        var bgDrawable = image?.drawable
        if (bgDrawable != null) {
            bgDrawable.draw(canvas)
        } else {
            //Drawable drawable = ContextCompat.getDrawable()
            canvas.drawColor(Color.WHITE)
        }
        //}
        view.draw(canvas)
        return returnedBitmap
    }

}