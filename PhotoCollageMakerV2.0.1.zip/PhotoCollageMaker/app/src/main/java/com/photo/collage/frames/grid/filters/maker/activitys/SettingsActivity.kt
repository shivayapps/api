package com.photo.collage.frames.grid.filters.maker.activitys

import android.app.Dialog
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.AsyncTask
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.airbnb.lottie.LottieAnimationView
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.InterstitialAd
import com.photo.collage.frames.grid.filters.maker.R
import com.photo.collage.frames.grid.filters.maker.ads.InterstitialAdHelper
import com.photo.collage.frames.grid.filters.maker.broadcastNetwork.NetworkChangeReceiver
import com.photo.collage.frames.grid.filters.maker.moreframes.sqlite_database.AdsPrefs
import com.photo.collage.frames.grid.filters.maker.utils.SharedPrefs
import com.photo.collage.frames.grid.filters.maker.utils.SharingUtility
import com.photo.collage.frames.grid.filters.maker.utils.isNetworkAvailable
import com.photo.collage.frames.grid.filters.maker.utils.showToast
import com.scribble.animation.maker.video.effect.myadslibrary.utils.InternetConnection
import com.willy.ratingbar.ScaleRatingBar
import org.jsoup.Jsoup

class SettingsActivity : AppCompatActivity(), View.OnClickListener, InterstitialAdHelper.onInterstitialAdListener {

    private var mSettingsActivity: SettingsActivity? = null

    //Widgets
    private var mLinearUpdate: LinearLayout? = null
    private var mLinearRateApp: LinearLayout? = null
    private var mLinearShareApp: LinearLayout? = null
    private var mProgressUpdate: ProgressBar? = null
    private var mImgUpdateAvailable: ImageView? = null
    private var mImgUpdateDone: LottieAnimationView? = null
    private var mIcSubcription: LinearLayout? = null

    private var mRlSubscription: RelativeLayout?=null
    private var txtProUser: TextView? = null
    private var imgGo:ImageView? = null
    private var subscribeAnimation:LottieAnimationView? = null

    //Others
    private var currentVersion = ""
    private var isNewversionAvailable = false

    private var mSharedPrefs: SharedPrefs? = null

    private var interstitial: InterstitialAd? = null

    private var receiver: Receiver? = null
    private var mNetworkReceiver: NetworkChangeReceiver? = null
    private var isCalled = false

    //Ads
    var ins_adRequest: AdRequest? = null
    var mInterstitialAd: InterstitialAd? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        mSettingsActivity = this@SettingsActivity
        mSharedPrefs = SharedPrefs(mSettingsActivity)

        initView()

        initViewAction()

        initViewListener()

        checkAppUpdate()

        mLinearUpdate!!.setEnabled(false)

        if (!mSharedPrefs!!.getRatingSharedPrefsData()) {
            mLinearRateApp!!.visibility = View.VISIBLE
        } else {
            mLinearRateApp!!.visibility = View.GONE
        }

        if(!AdsPrefs.getBoolean(this, AdsPrefs.IS_SUBSCRIBED)) {
            interstitial = InterstitialAdHelper.getInstance().load(this, this)
        }else{
            mIcSubcription!!.visibility = View.VISIBLE
        }

    }

    override fun onResume() {
        super.onResume()
        if (AdsPrefs.getBoolean(this, AdsPrefs.IS_SUBSCRIBED)) {
            mIcSubcription!!.visibility = View.GONE
            imgGo!!.visibility = View.GONE
            findViewById<View>(R.id.txtProUserLabal).visibility = View.GONE
            subscribeAnimation!!.visibility = View.VISIBLE
            txtProUser!!.visibility = View.VISIBLE
        }

    }
    override fun onRestart() {
        super.onRestart()
        if (!mSharedPrefs!!.getRatingSharedPrefsData()) {
            mLinearRateApp!!.visibility = View.VISIBLE
        } else {
            mLinearRateApp!!.visibility = View.GONE
        }
    }

    private fun initView() {
        mLinearUpdate = findViewById(R.id.linearUpdate)
        mLinearRateApp = findViewById(R.id.linearRateApp)
        mLinearShareApp = findViewById(R.id.linearShareApp)
        mProgressUpdate = findViewById(R.id.progressUpdate)
        mImgUpdateAvailable = findViewById(R.id.imgUpdateAvailable)
        mImgUpdateDone = findViewById(R.id.imgUpdateDone)
        mIcSubcription = findViewById(R.id.icSubcription)

        mRlSubscription = findViewById(R.id.rlSubscription)
        txtProUser = findViewById(R.id.txtProUser)
        imgGo = findViewById<ImageView>(R.id.imgGo)
        subscribeAnimation = findViewById(R.id.subscribeAnimation)

        //init Receiver
        receiver = Receiver()
        mNetworkReceiver = NetworkChangeReceiver()

        registerReceiver(mNetworkReceiver, IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"))
        registerReceiver(receiver, IntentFilter("com.pip.camera.art.filter.photo.effect.editor.custom"))

        if (!AdsPrefs.getBoolean(this, AdsPrefs.IS_SUBSCRIBED)) {
            //rlMoreApps.setVisibility(View.VISIBLE)
            mIcSubcription!!.visibility = View.VISIBLE
            txtProUser!!.visibility = View.GONE
        } else {
            //rlMoreApps.setVisibility(View.GONE)
            mIcSubcription!!.visibility = View.GONE
            imgGo!!.visibility = View.GONE
            findViewById<View>(R.id.txtProUserLabal).visibility = View.GONE
            subscribeAnimation!!.visibility = View.VISIBLE
            txtProUser!!.visibility = View.VISIBLE
        }

        object : AsyncTask<Void?, Void?, Void?>() {
            override fun doInBackground(vararg voids: Void?): Void? {
                if (InternetConnection.checkConnection(mSettingsActivity)) {
                    isCalled = true
                    runOnUiThread {
                        if (!AdsPrefs.getBoolean(this@SettingsActivity, AdsPrefs.IS_SUBSCRIBED) && !isLoaded) {
                            loadAds()
                        } else {
                            if(!AdsPrefs.getBoolean(this@SettingsActivity, AdsPrefs.IS_SUBSCRIBED)) {
                                mIcSubcription!!.visibility = View.VISIBLE
                            }else{
                                mIcSubcription!!.visibility = View.GONE
                            }
                        }
                    }
                } else {
                    runOnUiThread {
                        if (!isLoaded) {
                            mIcSubcription!!.visibility = View.GONE
                        }
                    }
                }
                return null
            }
        }.execute()
    }

    private fun initViewAction() {
        var imgBtnBack: ImageView = findViewById(R.id.imgBtnBack)
        imgBtnBack.setOnClickListener {
            onBackPressed()
        }

        mIcSubcription!!.setOnClickListener {
            //Show Ad
            showAd()
        }
    }

    private fun initViewListener() {
        mLinearUpdate!!.setOnClickListener(this)
        mLinearRateApp!!.setOnClickListener(this)
        mLinearShareApp!!.setOnClickListener(this)
        mRlSubscription!!.setOnClickListener(this)
    }

    private fun showAd() {
        if (isNetworkAvailable(mSettingsActivity) || isLoaded) {
            if (!AdsPrefs.getBoolean(this, AdsPrefs.IS_SUBSCRIBED) && requestNewInterstitial()) {
                mInterstitialAd!!.adListener = object : AdListener() {
                    override fun onAdClosed() {
                        super.onAdClosed()
                        loadAds()
                        mIcSubcription!!.visibility = View.GONE
                    }

                    override fun onAdFailedToLoad(i: Int) {
                        super.onAdFailedToLoad(i)
                        loadAds()
                    }

                    override fun onAdLoaded() {
                        super.onAdLoaded()
                        mIcSubcription!!.visibility = View.VISIBLE
                    }
                }
            } else {
                showToast("Loading...")
            }
        } else {
            showToast("no internet connection")
        }
    }

    private fun checkAppUpdate() {
        GetVersionCode().execute()
        try {
            currentVersion = packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
        }
    }

    private fun setRatingDialog() {
        val ratingDialog = Dialog(mSettingsActivity!!)
        ratingDialog.setContentView(R.layout.rating_dialog_layout)
        ratingDialog.window!!.setLayout(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        )
        ratingDialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val ratingBar: ScaleRatingBar = ratingDialog.findViewById(R.id.ratingBar)
        val txtBtnNextTime: TextView = ratingDialog.findViewById(R.id.txtBtnNextTime)
        val imgCloseRating: ImageView = ratingDialog.findViewById(R.id.imgCloseRating)
        txtBtnNextTime.setOnClickListener { ratingDialog.cancel() }
        imgCloseRating.setOnClickListener { ratingDialog.cancel() }
        ratingBar.setOnRatingChangeListener { ratingBar, rating, fromUser ->
            if (rating <= 3) {
                //Toast.makeText(mSettingsActivity, "Thanks for rating", Toast.LENGTH_SHORT).show()
                Handler().postDelayed({
                    ratingDialog.dismiss()
                    SharingUtility.sendEmail(mSettingsActivity!!)
                }, 1100)
            } else {
                Handler().postDelayed({
                    ratingDialog.dismiss()
                    rateApp()
                }, 1000)
            }
            mSharedPrefs!!.saveRatingSharedPrefsData()
        }

        if (!isFinishing) {
            ratingDialog.show()
        }
    }

    private fun rateApp() {
        val uri: Uri? = Uri.parse("market://details?id=$packageName")
        val goToMarket = Intent(Intent.ACTION_VIEW, uri)
        try {
            startActivity(goToMarket)
        } catch (e: ActivityNotFoundException) {
            startActivity(
                    Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("http://play.google.com/store/apps/details?id=$packageName")
                    )
            )
        }
    }

    private fun shareApp() {
        try {
            val shareIntent =
                    Intent(Intent.ACTION_SEND)
            shareIntent.type = "text/plain"
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Photo Collage Maker")
            var shareMessage = "\n" /*+
                    "Go with CV Resume Maker and make Innovative Resume\n" +
                    "\n"*/

            shareMessage =
                    """
                ${shareMessage}https://play.google.com/store/apps/details?id=${packageName}
                
                
                """.trimIndent()
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
            startActivity(Intent.createChooser(shareIntent, "choose one"))
        } catch (e: Exception) {
            //e.toString();
        }
    }

    // Check Update Bg Task
    inner private class GetVersionCode :
            AsyncTask<Void?, String?, String?>() {
        override fun doInBackground(vararg voids: Void?): String? {
            var newVersion: String? = null
            return try {
                newVersion =
                        Jsoup.connect("https://play.google.com/store/apps/details?id=" + packageName + "&hl=it")
                                .timeout(30000)
                                .userAgent("Mozilla/5.0 (Windows; U; WindowsNT 5.1; en-US; rv1.8.1.6) Gecko/20070725 Firefox/2.0.0.6")
                                .referrer("http://www.google.com")
                                .get()
                                .select(".hAyfc .htlgb")
                                .get(7)
                                .ownText()
                newVersion

            } catch (e: java.lang.Exception) {
                newVersion
            }
        }

        override fun onPostExecute(onlineVersion: String?) {
            super.onPostExecute(onlineVersion)
            if (onlineVersion != null && !onlineVersion.isEmpty()) {
                if (currentVersion != onlineVersion) {
                    isNewversionAvailable = true
                    mLinearUpdate!!.setEnabled(true)
                    mImgUpdateAvailable!!.setVisibility(View.VISIBLE)
                    mProgressUpdate!!.setVisibility(View.GONE)
                } else {
                    isNewversionAvailable = false
                    mLinearUpdate!!.setEnabled(false)
                    mImgUpdateDone!!.setVisibility(View.VISIBLE)
                    mProgressUpdate!!.setVisibility(View.GONE)
                }
            }
        }
    }

    inner class Receiver : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            Log.d("myReceiver", "onReceive: ads ")
            object : AsyncTask<Void?, Void?, Void?>() {
                override fun doInBackground(vararg voids: Void?): Void? {
                    if (InternetConnection.checkConnection(mSettingsActivity)) {
                            runOnUiThread {
                                if (!isLoaded && !AdsPrefs.getBoolean(this@SettingsActivity, AdsPrefs.IS_SUBSCRIBED)) {
                                    loadAds()
                                } else {
                                    if(!AdsPrefs.getBoolean(this@SettingsActivity, AdsPrefs.IS_SUBSCRIBED)) {
                                        mIcSubcription!!.visibility = View.VISIBLE
                                    }else{
                                        mIcSubcription!!.visibility = View.GONE
                                    }
                                }

                                if (mProgressUpdate!!.visibility == View.VISIBLE) {
                                    GetVersionCode().execute()
                                }
                            }
                    } else {
                        isCalled = false
                        runOnUiThread {
                            if(!isLoaded) {
                                mIcSubcription!!.visibility = View.GONE
                            }
                        }
                    }
                    return null
                }
            }.execute()
        }
    }

    //Ads
    private val isLoaded: Boolean
        get() {
            try {
                if (!AdsPrefs.getBoolean(this, AdsPrefs.IS_SUBSCRIBED) && mInterstitialAd!!.isLoaded && mInterstitialAd != null) {
                    return true
                }
            } catch (e: Exception) {
            }
            return false
        }

    private fun requestNewInterstitial(): Boolean {
        try {
            if (mInterstitialAd!!.isLoaded) {
                mInterstitialAd!!.show()
                return true
            }
        } catch (e: Exception) {
        }
        return false
    }

    private fun loadAds() {
        try {
            mInterstitialAd = InterstitialAd(this)

            /*val interstialAdId = AppIDs().getGoogleInterstitial(0)

            mInterstitialAd!!.adUnitId = interstialAdId

            if (!AppIDs.isTest && interstialAdId == getString(R.string.inter_ad_unit_id)) {
                return
            }*/
            mInterstitialAd!!.adUnitId = resources.getString(R.string.inter_ad_unit_id)


            ins_adRequest = AdRequest.Builder().addTestDevice("1430CCBBF6C738012B76659D054E081E") //SWIPE
                    .build()

            mInterstitialAd!!.loadAd(ins_adRequest)
            mInterstitialAd!!.adListener = object : AdListener() {
                override fun onAdClosed() {
                    super.onAdClosed()
                    Log.e("ADS", "onAdClosed: ")
                    mIcSubcription!!.visibility = View.GONE
                }

                override fun onAdFailedToLoad(i: Int) {
                    super.onAdFailedToLoad(i)
                    Log.e("ADS", "onAdFailedToLoad: ")
                }

                override fun onAdLeftApplication() {
                    super.onAdLeftApplication()
                    Log.e("ADS", "onAdLeftApplication: ")
                }

                override fun onAdOpened() {
                    super.onAdOpened()
                    Log.e("ADS", "onAdOpened: ")
                }

                override fun onAdLoaded() {
                    super.onAdLoaded()
                    Log.e("ADS", "onAdLoaded: ")
                    if(!AdsPrefs.getBoolean(this@SettingsActivity, AdsPrefs.IS_SUBSCRIBED)) {
                        mIcSubcription!!.visibility = View.VISIBLE
                    }
                }

                override fun onAdClicked() {
                    super.onAdClicked()
                    Log.e("ADS", "onAdClicked: ")
                }

                override fun onAdImpression() {
                    super.onAdImpression()
                    Log.e("ADS", "onAdImpression: ")
                }
            }
        } catch (e: Exception) {
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }

    override fun onClick(v: View?) {
        when (v!!.id) {
            R.id.linearUpdate -> {
                rateApp()
            }
            R.id.linearRateApp -> {
                setRatingDialog()
            }
            R.id.linearShareApp -> {
                shareApp()
            }
            R.id.rlSubscription -> {
                if (!AdsPrefs.getBoolean(this, AdsPrefs.IS_SUBSCRIBED)) {
                    startActivity(Intent(this@SettingsActivity, SubscriptionActivity::class.java))
                } else {
                }
            }
        }
    }

    override fun onLoad() {

    }

    override fun onFailed() {

    }

    override fun onClosed() {
        interstitial = InterstitialAdHelper.getInstance().load(this, this)
    }
}
