package com.photo.collage.frames.grid.filters.maker.interfaces;


import com.photo.collage.frames.grid.filters.maker.multitouch.controller.MultiTouchEntity;
import com.photo.collage.frames.grid.filters.maker.multitouch.custom.PhotoView;

public interface OnDoubleClickListener {
	public void onPhotoViewDoubleClick(PhotoView view, MultiTouchEntity entity);
	public void onBackgroundDoubleClick();
}
