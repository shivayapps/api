package com.photo.collage.frames.grid.filters.maker.activitys;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.PopupWindow;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.background.eraser.remover.photo.layers.stickerview.Sticker;
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.NetworkHelper;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.photo.collage.frames.grid.filters.maker.R;
import com.photo.collage.frames.grid.filters.maker.adepters.ImageOptionAdepter;
import com.photo.collage.frames.grid.filters.maker.comman.Constants;
import com.photo.collage.frames.grid.filters.maker.model.OptionModel;
import com.photo.collage.frames.grid.filters.maker.model.PhotoItem;
import com.photo.collage.frames.grid.filters.maker.model.TemplateItem;
import com.photo.collage.frames.grid.filters.maker.moreframes.FramesCategorySheet;
import com.photo.collage.frames.grid.filters.maker.multitouch.controller.MultiTouchEntity;
import com.photo.collage.frames.grid.filters.maker.multitouch.custom.PhotoView;
import com.photo.collage.frames.grid.filters.maker.utils.ImageDecoder;
import com.photo.collage.frames.grid.filters.maker.utils.ImageUtils;
import com.photo.collage.frames.grid.filters.maker.utils.SharedPrefs;
import com.photo.collage.frames.grid.filters.maker.widgets.FrameImageView;
import com.photo.collage.frames.grid.filters.maker.widgets.FramePhotoLayout;

import java.util.ArrayList;

import dauroi.photoeditor.PhotoEditorApp;
import dauroi.photoeditor.utils.FileUtils;

import static android.widget.Toast.LENGTH_SHORT;


public class FrameDetailActivity extends BaseTemplateDetailActivity implements FramePhotoLayout.OnQuickActionClickListener {

    private static final int REQUEST_SELECT_PHOTO = 99;
    private static final float MAX_SPACE = ImageUtils.pxFromDp(PhotoEditorApp.getAppContext(), 30);
    private static final float MAX_CORNER = ImageUtils.pxFromDp(PhotoEditorApp.getAppContext(), 60);
    public static final float DEFAULT_SPACE = ImageUtils.pxFromDp(PhotoEditorApp.getAppContext(), 2);
    public static final float DEFAULT_CORNER = ImageUtils.pxFromDp(PhotoEditorApp.getAppContext(), 1);
    private static final float MAX_SPACE_PROGRESS = 300.0f;
    private static final float MAX_CORNER_PROGRESS = 630.0f;


    private SeekBar mSpaceBar;
    private SeekBar mCornerBar;
    private float mSpace = DEFAULT_SPACE;
    private float mCorner = DEFAULT_CORNER;
    //Background
    private int mBackgroundColor = Color.WHITE;
    private Bitmap mBackgroundImage;
    private Uri mBackgroundUri = null;
    private Bundle mSavedInstanceState;
    RecyclerView recyclerView;
    private FramesCategorySheet forgroundFragment;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (ContextCompat.checkSelfPermission(mContext, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            startActivity(new Intent(mContext, MainActivity.class));
            finish();
        }

        initViews();
        initViewAction();

       /* //restore old params
        if (savedInstanceState != null) {
            mSpace = savedInstanceState.getFloat("mSpace");
            mCorner = savedInstanceState.getFloat("mCorner");
            mBackgroundColor = savedInstanceState.getInt("mBackgroundColor");
            mBackgroundUri = savedInstanceState.getParcelable("mBackgroundUri");
            mSavedInstanceState = savedInstanceState;
            if (mBackgroundUri != null)
                mBackgroundImage = ImageDecoder.decodeUriToBitmap(this, mBackgroundUri);
        }*/
        Log.d("DSDSDSDDSD", "onCreate: " + Constants.mSelectedImageListTemp.size());
    }

    private void initViewAction() {
        seekbarChange();
        initPopupWindow();
    }

    private void seekbarChange() {
        mSpaceBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                mSpace = MAX_SPACE * seekBar.getProgress() / MAX_SPACE_PROGRESS;
                if (mFramePhotoLayout != null)
                    mFramePhotoLayout.setSpace(mSpace, mCorner);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        mCornerBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                mCorner = MAX_CORNER * seekBar.getProgress() / MAX_CORNER_PROGRESS;
                if (mFramePhotoLayout != null)
                    mFramePhotoLayout.setSpace(mSpace, mCorner);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        mBtnMoreAPI.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (NetworkHelper.isOnline(mContext)) {
                    onClickMoreAPI();
                } else {
                    Toast.makeText(mContext, "Please check internet connection", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void initViews() {
        mSpaceBar = findViewById(R.id.spaceBar);
        recyclerViewBGImage = findViewById(R.id.recyclerViewBGImage);
        mCornerBar = findViewById(R.id.cornerBar);
    }

    private void initPopupWindow() {
        Log.d("102356", "initPopupWindow: ");
        View view = LayoutInflater.from(this).inflate(R.layout.layout_popup_window, null);

        int width = getScreenWidth();
        mPopupWindow = new PopupWindow(
                view,
                width,
                ConstraintLayout.LayoutParams.WRAP_CONTENT
        );

        if (Build.VERSION.SDK_INT >= 21) {
            //mPopupWindow.setElevation(5.0f);
        }

        recyclerView = view.findViewById(R.id.recyclerViewImageOption);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        mOptionList = new ArrayList<>();
        prepareImageOptions();

        adepter = new ImageOptionAdepter(this, mOptionList, model -> {
            Log.d("465132", "initPopupWindow: " + model + "  " + mOptionList.size());
            if (mOptionList.size() > 2)
                handleOptionClick(model);
            else
                handleTextOptionClick(model);

        });
        recyclerView.setAdapter(adepter);
    }


    private void prepareImageOptions() {
        mOptionList.clear();
        //mOptionList.add(new OptionModel(0,R.drawable.ic_blur,"BLUR IMAGE"));
        mOptionList.add(new OptionModel(3, R.drawable.ic_sub_menu_crop, "Crop"));
        mOptionList.add(new OptionModel(2, R.drawable.ic_sub_menu_swap, "Swap"));
        mOptionList.add(new OptionModel(7, R.drawable.ic_sub_menu_horizontal, "Horizontal"));
        mOptionList.add(new OptionModel(14, R.drawable.ic_sub_menu_fill, "Fill"));
        mOptionList.add(new OptionModel(5, R.drawable.ic_sub_menu_rotate, "Rotate"));
        //mOptionList.add(new OptionModel(5, R.drawable.ic_rotate_right_black_24dp, "RIGHT"));
        mOptionList.add(new OptionModel(8, R.drawable.ic_sub_menu_zoom, "Zoom In"));
        mOptionList.add(new OptionModel(9, R.drawable.ic_sub_menu_zoomout, "Zoom Out"));
        mOptionList.add(new OptionModel(10, R.drawable.ic_left, "Left"));
        mOptionList.add(new OptionModel(11, R.drawable.ic_right, "Right"));
        mOptionList.add(new OptionModel(12, R.drawable.ic_up, "Up"));
        mOptionList.add(new OptionModel(13, R.drawable.ic_down, "Down"));
        mOptionList.add(new OptionModel(1, R.drawable.ic_delete_new, "Delete"));
    }

    private boolean isNetworkConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        return cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo().isConnected();
    }

    private void onClickMoreAPI() {
        Log.e("qwerqre", "Clicked");
        //if (isNetworkConnected()) {
        mBtnMoreAPI.setEnabled(false);
        openBottomStickerSheet();
        //}else{
        //    Log.e("qwerqre","ELSE");
        //}
    }

    private void openBottomStickerSheet() {
        try {
            FramesCategorySheet.OnItemSelected onItemSelected = new FramesCategorySheet.OnItemSelected() {
                @Override
                public void onItemSelected(TemplateItem imagesItem) {
                    closePopupWindow();
                    if (imagesItem != mSelectedTemplateItem) {
                        mSelectedTemplateItem.setSelected(false);
                        for (int idx = 0; idx < mSelectedTemplateItem.getPhotoItemList().size(); idx++) {
                            PhotoItem photoItem = mSelectedTemplateItem.getPhotoItemList().get(idx);
                            if (photoItem.imagePath != null && photoItem.imagePath.length() > 0) {
                                if (idx < mSelectedPhotoPaths.size()) {
                                    mSelectedPhotoPaths.add(idx, photoItem.imagePath);
                                    Log.d("qwerty", "onPreviewTemplateClick: if" + photoItem.imagePath);

                                } else {
                                    mSelectedPhotoPaths.add(photoItem.imagePath);
                                    Log.d("qwerty", "onPreviewTemplateClick: else" + photoItem.imagePath);
                                }
                            }
                        }

                        final int size = Math.min(mSelectedPhotoPaths.size(), imagesItem.getPhotoItemList().size());
                        for (int idx = 0; idx < size; idx++) {
                            PhotoItem photoItem = imagesItem.getPhotoItemList().get(idx);
                            if (photoItem.imagePath == null || photoItem.imagePath.length() < 1) {
                                photoItem.imagePath = mSelectedPhotoPaths.get(idx);
                            }
                        }

                        mSelectedTemplateItem = imagesItem;
                        mSelectedTemplateItem.setSelected(true);
                        mTemplateAdapter.notifyDataSetChanged();
                        buildLayout(imagesItem, false);
                    }
                }

                @Override
                public void dismiss() {
                    Log.e("qwertyyy", "Dismiss()");
                    mBtnMoreAPI.setEnabled(true);
                }
            };

            forgroundFragment = new FramesCategorySheet(mTemplateItemListMoreTemp, mSelectedPhotoPaths, onItemSelected, FramesCategorySheet.TEXTART);
            forgroundFragment.show(getSupportFragmentManager(), "Card_Category_Dialog");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putFloat("mSpace", mSpace);
        outState.putFloat("mCornerBar", mCorner);
        outState.putInt("mBackgroundColor", mBackgroundColor);
        outState.putParcelable("mBackgroundUri", mBackgroundUri);
        if (mFramePhotoLayout != null) {
            mFramePhotoLayout.saveInstanceState(outState);
        }
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_frame_detail;
    }

    @Override
    public Bitmap createOutputImage() {
        Bitmap bitmap = Bitmap.createBitmap(mainContainer.getWidth(), mainContainer.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        mContainerLayout.draw(canvas);
//        mFramePhotoLayout.draw(canvas);
        textContainerLayout.draw(canvas);
        mStickerView.draw(canvas);
        return bitmap;


    }

    @Override
    protected void buildLayout(TemplateItem item, boolean isAspectRatio) {

        mFramePhotoLayout = new FramePhotoLayout(this, item.getPhotoItemList());
        mFramePhotoLayout.setQuickActionClickListener(this);
        mFramePhotoLayout.setBackgroundColor(Color.WHITE);
        if (mBackgroundImage != null && !mBackgroundImage.isRecycled()) {
            if (Build.VERSION.SDK_INT >= 16)
                mContainerLayout.setBackground(new BitmapDrawable(getResources(), mBackgroundImage));
            else
                mContainerLayout.setBackgroundDrawable(new BitmapDrawable(getResources(), mBackgroundImage));
        } else {
            mContainerLayout.setBackgroundColor(mBackgroundColor);
        }
        if (viewHeight == 0 || viewWidth == 0) {
            viewWidth = mContainerLayout.getWidth();
            viewHeight = mContainerLayout.getHeight();
        }

        if (mSelectedBG != null) {
            Glide.with(this).load(mSelectedBG).into(new CustomTarget<Drawable>() {
                @Override
                public void onResourceReady(@NonNull Drawable resource, @Nullable Transition<? super Drawable> transition) {
                    mFramePhotoLayout.setBackground(resource);
                    mSelectedColor = -1;
                }

                @Override
                public void onLoadCleared(@Nullable Drawable placeholder) {

                }
            });
        }
        if (mSelectedColor != -1) {
            mFramePhotoLayout.setBackground(null);
            mFramePhotoLayout.setBackgroundColor(mSelectedColor);
            mSelectedBG = null;
        }

        mOutputScale = ImageUtils.calculateOutputScaleFactor(viewWidth, viewHeight);
        mFramePhotoLayout.build(viewWidth, viewHeight, mOutputScale, mSpace, mCorner);
        if (mSavedInstanceState != null) {
            mFramePhotoLayout.restoreInstanceState(mSavedInstanceState);
            mSavedInstanceState = null;
        }
        ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams(viewWidth, viewHeight);
        params.startToStart = mFramePhotoLayout.getId();
        params.topToTop = mFramePhotoLayout.getTop();
        params.bottomToBottom = mFramePhotoLayout.getTop();
        params.endToEnd = mFramePhotoLayout.getTop();
        mContainerLayout.removeAllViews();
        mContainerLayout.addView(mFramePhotoLayout, params);

        ConstraintLayout.LayoutParams params1 = (ConstraintLayout.LayoutParams) mainContainer.getLayoutParams();
        params1.width = viewWidth;
        params1.height = viewHeight;
        mainContainer.setLayoutParams(params1);

        mStickerView.getLayoutParams().width = viewWidth;
        mStickerView.getLayoutParams().height = viewHeight;
        mStickerView.requestLayout();

        Log.d("1235689", "buildLayout: " + mainContainer.getWidth() + "  " + mainContainer.getHeight() + "  " + viewWidth + "  " + viewHeight);

        //reset space and corner seek bars
        mSpaceBar.setProgress((int) (MAX_SPACE_PROGRESS * mSpace / MAX_SPACE));
        mCornerBar.setProgress((int) (MAX_CORNER_PROGRESS * mCorner / MAX_CORNER));

        disableEnableControls(true, mButtonLayout);
        imgBtnDone.setEnabled(true);
        if (isAspectRatio) {
            mainContainer.post(() -> {
                mStickerView.centerAllSticker();

                /*ArrayList<Sticker> stickers = new ArrayList<>(mStickerView.getStickers());
                mStickerView.removeAllStickers();
                for (Sticker sticker : stickers) {
                    mStickerView.addSticker(sticker);
                    mStickerView.centerAllSticker();
                    // mStickerView.centerAllSticker();
                }*/
            });
        }
    }


    @Override
    public void onImageClick(FrameImageView v, int photoPosition) {
        angle = 0;
        hideView();
        mSelectedFrameImageView = v;
        mSelectedPostion = photoPosition;
        prepareImageOptions();
        /*if (mPopupWindow.isShowing())
            mPopupWindow.dismiss();*/

        if (adepter != null) {
            adepter.mSelectedLatItem = -1;
            adepter.mSelectedItem = -1;
            adepter.notifyDataSetChanged();
            recyclerView.scrollToPosition(0);
        }

        mPopupWindow.setWidth(ConstraintLayout.LayoutParams.MATCH_PARENT);
        mPopupWindow.setHeight(ConstraintLayout.LayoutParams.WRAP_CONTENT);

        if (!mPopupWindow.isShowing()) {
            mPopupWindow.showAtLocation(mContainerLayout, Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM, 0, /*(int) (findViewById(R.id.bottomLayout).getHeight() * 2f)*/0);
            //imgBtnClose.setVisibility(View.VISIBLE);
        }

    }


    @Override
    protected void resultEditImage(Uri uri) {
        if (mSelectedFrameImageView != null) {
            mSelectedFrameImageView.setImagePath(FileUtils.getPath(this, uri));
        }
    }

    @Override
    protected void resultFromPhotoEditor(Uri image) {
        if (mSelectedFrameImageView != null) {
            mSelectedFrameImageView.setImagePath(FileUtils.getPath(this, image));
        }
    }

    private void recycleBackgroundImage() {
        if (mBackgroundImage != null && !mBackgroundImage.isRecycled()) {
            mBackgroundImage.recycle();
            mBackgroundImage = null;
            System.gc();
        }
    }

    @Override
    protected void resultBackground(Uri uri) {
        recycleBackgroundImage();
        mBackgroundUri = uri;
        mBackgroundImage = ImageDecoder.decodeUriToBitmap(this, uri);
        if (Build.VERSION.SDK_INT >= 16)
            mContainerLayout.setBackground(new BitmapDrawable(getResources(), mBackgroundImage));
        else
            mContainerLayout.setBackgroundDrawable(new BitmapDrawable(getResources(), mBackgroundImage));
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_SELECT_PHOTO && resultCode == RESULT_OK) {
            SharedPrefs mSharedPrefs = new SharedPrefs(mContext);
            Gson gson = new Gson();
            ArrayList<String> gsonModelArrayList = gson.fromJson(mSharedPrefs.getPhotoList(),
                    new TypeToken<ArrayList<String>>() {
                    }.getType());
            //ArrayList<String> mSelectedImages = data.getStringArrayListExtra(GalleryActivity.EXTRA_SELECTED_IMAGES);
            ArrayList<String> mSelectedImages = gsonModelArrayList;
            if (mSelectedFrameImageView != null && mSelectedImages != null && !mSelectedImages.isEmpty()) {
                mSelectedFrameImageView.setImagePath(mSelectedImages.get(0));
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void finish() {
        recycleBackgroundImage();
        if (mFramePhotoLayout != null) {
            mFramePhotoLayout.recycleImages();
        }
        super.finish();
    }


    @Override
    public void onPhotoViewDoubleClick(PhotoView view, MultiTouchEntity entity) {

    }

    private Dialog discardDialog;

    @Override
    public void onBackPressed() {
        selectItem(null, null, null);
        if (isFragmentLoaded) {
            removeFragment();
        } else {
            if (mPopupWindow.isShowing()) {
                mPopupWindow.dismiss();
                imgBtnClose.setVisibility(View.GONE);
                mFramePhotoLayout.removeSelection();
            } else if (findViewById(R.id.bottomRecycler).getVisibility() == View.VISIBLE) {
                findViewById(R.id.bottomRecycler).setVisibility(View.GONE);
                imgBtnClose.setVisibility(View.GONE);

            } else {

            /*new AlertDialog.Builder(this)
                    .setMessage("Are you sure want to discard?")
                    .setPositiveButton("OK", (dialog, which) -> {
                        super.onBackPressed();
                    })
                    .setNegativeButton("Cancel", (dialog, which) -> {
                        dialog.dismiss();
                    })
                    .show();*/

                discardDialog = new Dialog(this);
                discardDialog.setContentView(R.layout.dialog_discard);
                discardDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                discardDialog.getWindow().setLayout(ConstraintLayout.LayoutParams.MATCH_PARENT, ConstraintLayout.LayoutParams.WRAP_CONTENT);
                TextView btnCancel = discardDialog.findViewById(R.id.btnCancel);
                TextView btnDiscard = discardDialog.findViewById(R.id.btnDiscard);
                btnCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        discardDialog.dismiss();
                    }
                });

                btnDiscard.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        discardDialog.dismiss();
                        Intent discardIntent = new Intent();
                        discardIntent.putExtra("finishData", "nulled");
                        setResult(Constants.COLLAGE_IMAGE_DISCARD_REQUEST_CODE, discardIntent);
                        FrameDetailActivity.super.onBackPressed();
                    }
                });
                if (!isFinishing()) {
                    discardDialog.show();
                }

            }
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if (discardDialog != null && discardDialog.isShowing()) {
            discardDialog.dismiss();
        }

        if (forgroundFragment != null && forgroundFragment.getShowsDialog()) {
//            forgroundFragment.dismiss();
        }
    }
}
