package com.photo.collage.frames.grid.filters.maker.interfaces;

import android.view.MotionEvent;

public interface OnFrameTouchListener {
	public void onFrameTouch(MotionEvent event);
	public void onFrameDoubleClick(MotionEvent event);
}
