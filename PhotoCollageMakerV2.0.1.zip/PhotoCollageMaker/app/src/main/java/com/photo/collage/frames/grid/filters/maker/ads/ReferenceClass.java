package com.photo.collage.frames.grid.filters.maker.ads;

public class ReferenceClass {
    static {
        System.loadLibrary("native-lib");
    }

    public static native String getKeys(String type);
}
