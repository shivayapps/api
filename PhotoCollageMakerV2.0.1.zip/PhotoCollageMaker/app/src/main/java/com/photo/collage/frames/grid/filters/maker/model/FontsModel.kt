package com.photo.collage.frames.grid.filters.maker.model

data class FontsModel(var fontPath:String,var imageDrawable:Int,var isFont:Boolean) {
}