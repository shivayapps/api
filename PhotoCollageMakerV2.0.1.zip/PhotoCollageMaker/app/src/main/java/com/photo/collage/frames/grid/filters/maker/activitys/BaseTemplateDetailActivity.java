package com.photo.collage.frames.grid.filters.maker.activitys;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.Layout;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.airbnb.lottie.LottieAnimationView;
import com.background.eraser.remover.photo.layers.stickerview.Sticker;
import com.background.eraser.remover.photo.layers.stickerview.StickerView;
import com.background.eraser.remover.photo.layers.stickerview.TextSticker;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.material.appbar.AppBarLayout;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.jcmore2.collage.CardView;
import com.jcmore2.collage.MultiTouchListener;
import com.photo.collage.frames.grid.filters.maker.comman.Constants;
import com.photo.collage.frames.grid.filters.maker.R;
import com.photo.collage.frames.grid.filters.maker.adepters.BackgroundCollageAdepter;
import com.photo.collage.frames.grid.filters.maker.adepters.ColorAdepter;
import com.photo.collage.frames.grid.filters.maker.adepters.FontAdepter;
import com.photo.collage.frames.grid.filters.maker.adepters.HorizontalPreviewTemplateAdapter;
import com.photo.collage.frames.grid.filters.maker.adepters.ImageOptionAdepter;
import com.photo.collage.frames.grid.filters.maker.adepters.RatioAdepter;
import com.photo.collage.frames.grid.filters.maker.ads.InterstitialAdHelper;
import com.photo.collage.frames.grid.filters.maker.fragments.AddTextFragment;
import com.photo.collage.frames.grid.filters.maker.fragments.BlurImageFragment;
import com.photo.collage.frames.grid.filters.maker.fragments.TextEditorDialogFragment;
import com.photo.collage.frames.grid.filters.maker.helper.ActivityLifeCycleHelper;
import com.photo.collage.frames.grid.filters.maker.interfaces.KeyboardHeightObserver;
import com.photo.collage.frames.grid.filters.maker.interfaces.OnDoubleClickListener;
import com.photo.collage.frames.grid.filters.maker.model.OptionModel;
import com.photo.collage.frames.grid.filters.maker.model.PhotoItem;
import com.photo.collage.frames.grid.filters.maker.model.PhotoModel;
import com.photo.collage.frames.grid.filters.maker.model.RatioModel;
import com.photo.collage.frames.grid.filters.maker.model.TemplateItem;
import com.photo.collage.frames.grid.filters.maker.model.TextModel;
import com.photo.collage.frames.grid.filters.maker.moreframes.sqlite_database.AdsPrefs;
import com.photo.collage.frames.grid.filters.maker.utils.FontProvider;
import com.photo.collage.frames.grid.filters.maker.utils.ImageUtils;
import com.photo.collage.frames.grid.filters.maker.utils.KeyboardHeightProvider;
import com.photo.collage.frames.grid.filters.maker.utils.SharedPrefs;
import com.photo.collage.frames.grid.filters.maker.utils.frame.FrameImageUtils;
import com.photo.collage.frames.grid.filters.maker.widgets.FrameImageView;
import com.photo.collage.frames.grid.filters.maker.widgets.FramePhotoLayout;
import com.yalantis.ucrop.UCrop;
import com.yalantis.ucrop.util.FileUtils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import dauroi.photoeditor.colorpicker.ColorPickerDialog;
import dauroi.photoeditor.utils.PhotoUtils;

import static android.widget.Toast.LENGTH_SHORT;

public abstract class BaseTemplateDetailActivity extends BasePhotoActivity implements MultiTouchListener.OnTouchEvent,
        HorizontalPreviewTemplateAdapter.OnPreviewTemplateClickListener, OnDoubleClickListener,
        TextEditorDialogFragment.OnTextLayerCallback, KeyboardHeightObserver, InterstitialAdHelper.onInterstitialAdListener {

    private static final String TAG = BaseTemplateDetailActivity.class.getSimpleName();
    private static final String PREF_NAME = "templateDetailPref";

    private static final int HORIZONTAL = 1;
    private static final int VERTICAL = 2;
    private static final String SAMPLE_CROPPED_IMAGE_NAME = "SampleCrop";

    public FrameImageView mSelectedFrameImageView;

    protected ConstraintLayout mContainerLayout;
    protected RecyclerView mTemplateView;
    protected RecyclerView recyclerViewRatio;
    protected RecyclerView recyclerViewBGImage;
    protected RecyclerView recyclerViewText;
    protected ProgressBar mProgressBar;

    protected ImageButton imgBtnClose;

    protected View mViewSelectedMenuAdd;
    protected View mViewSelectedMenuLayout;
    protected View mViewSelectedMenuBackground;
    protected View mViewSelectedMenuSpace;
    protected View mViewSelectedMenuRatio;
    protected View mViewSelectedMenuText;
    protected LottieAnimationView mBtnMoreAPI;

    protected float mOutputScale = 1;

    public TemplateItem mSelectedTemplateItem;
    protected ArrayList<TemplateItem> mTemplateItemList = new ArrayList<>();
    protected ArrayList<TemplateItem> mTemplateItemListTemp = new ArrayList<>();
    protected ArrayList<TemplateItem> mTemplateItemListMoreTemp = new ArrayList<>();
    public int mSelectedPostion;
    public View mSelectedView;

    private ColorAdepter colorAdepter;

    private float mScale;
    private float mTranslateX, mTranslateY;
    protected HorizontalPreviewTemplateAdapter mTemplateAdapter;
    protected List<String> mSelectedPhotoPaths = new ArrayList<>();
    private boolean mIsFrameImage = true;
    private int mSelectedImageSize;
    private ArrayList<RatioModel> mRatioList;
    int viewHeight;
    int viewWidth;

    private int mMainWidth;
    private int mMainHeight;

    private KeyboardHeightProvider keyboardHeightProvider;


    private FontAdepter fontAdepter;

    public PopupWindow mPopupWindow;
    public ArrayList<String> extraImagePaths;
    public FramePhotoLayout mFramePhotoLayout;
    private BlurImageFragment blurImageFragment;
    protected StickerView mStickerView;
    private boolean isCropViewOpen = false;
    private boolean isBlurViewOpen = false;
    public int angle = 0;
    private ArrayList<TextModel> mTextViewList;
    public ArrayList<OptionModel> mOptionList;
    public ImageOptionAdepter adepter;
    public ConstraintLayout textContainerLayout;
    public ConstraintLayout mainContainer, mButtonLayout, mainCenterConstraint;
    public ArrayList<String> mImageList;
    public ConstraintLayout mTextLayout;
    private RelativeLayout mRootLayout;

    protected ImageView imgBtnDone;
    private TextView txtColor, txtStyle;

    public Uri mSelectedBG = null;
    public int mSelectedColor = -1;
    private ArrayList<Integer> mColors;
    private int Imagetype = 1;

    private Sticker mSticker;
    private TextEditorDialogFragment fragment;
    private int originalBottomPoint;

    //ads
    private boolean isInterstitialAdLoaded = false;
    private InterstitialAd interstitial;
    private boolean isSave = false;
    private File file;
    private String errMsg;

    private boolean isMultiClicked = true;

    //Text code
    private AddTextFragment addTextFragment;

    public Boolean isFragmentLoaded = false;

    private View mToolbar1;
    private View mToolbarText;
    private ImageView mImgBtnBackText;
    private ImageView mBtnDoneText;

    //abstract methods
    protected abstract int getLayoutId();

    protected abstract void buildLayout(TemplateItem templateItem, boolean isAspectRatio);

    protected abstract Bitmap createOutputImage();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(getLayoutId());

        initViews();
        initViewAction();
        initListner();

        imgBtnDone.setEnabled(false);
        imgBtnDone.setAlpha(0.5f);

        mainContainer.post(() -> {
            mMainHeight = mainContainer.getHeight();
            mMainWidth = mainContainer.getWidth();
        });

        addTextFragment = new AddTextFragment();

      /*  //loading data
        if (savedInstanceState != null) {
            final int idx = savedInstanceState.getInt("mSelectedTemplateItemIndex", 0);
            mIsFrameImage = savedInstanceState.getBoolean("mIsFrameImage", false);
            loadFrameImages(mIsFrameImage);
            mSelectedTemplateItem = mTemplateItemList.get(0);

            if (mSelectedTemplateItem != null) {
                ArrayList<String> imagePaths = savedInstanceState.getStringArrayList("photoItemImagePaths");
                if (imagePaths != null) {
                    int size = Math.min(imagePaths.size(), mSelectedTemplateItem.getPhotoItemList().size());
                    for (int i = 0; i < size; i++) {
                        mSelectedTemplateItem.getPhotoItemList().get(i).imagePath = imagePaths.get(i);
                        Log.d("123654", "onCreate: " + mSelectedTemplateItem.getPhotoItemList().get(i).imagePath);
                    }
                }
            }

        } else {
            setFramesImages();
        }*/

    }


    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "onStart: ");
        if (keyboardHeightProvider != null)
            keyboardHeightProvider.setKeyboardHeightObserver(this);

        Log.d(TAG, "onStart: " + isSave);

        if (isSave) {
            openViewImage();
        }

        if (Constants.isChange) {
            Constants.isChange = false;

            mSelectedImageSize = Constants.mSelectedImageListTemp.size();
            extraImagePaths.clear();
            mSelectedPhotoPaths.clear();
            for (PhotoModel model : Constants.mSelectedImageListTemp) {
                mSelectedPhotoPaths.add(model.getImagePath());
                Log.d(TAG, "onStart: EWEWEWE"+model.getImagePath());
                extraImagePaths.add(model.getImagePath());
            }
            //Constants.mSelectedImageListTemp.clear();
            setFramesImages(false, "");

        }

        if (Constants.photoModel != null) {

            if (Imagetype == 1) {
                try {
                    System.gc();
                    Bitmap bitmap = BitmapFactory.decodeFile(Constants.photoModel.getImagePath());
                    mSelectedFrameImageView.setImage(bitmap);
                    mSelectedFrameImageView.invalidate();
                } catch (Exception e) {
                    e.printStackTrace();
                }

                try {
                    String imagePath = Constants.photoModel.getImagePath();

                    if (mSelectedPhotoPaths.size() > 0) {
                        mSelectedPhotoPaths.remove(mSelectedPostion);
                        mSelectedPhotoPaths.add(mSelectedPostion, imagePath);

                        if (Constants.mSelectedImageListTemp.size() > 0) {
                            Constants.mSelectedImageListTemp.remove(mSelectedPostion);
                            Constants.mSelectedImageListTemp.add(mSelectedPostion, Constants.photoModel);
                        }

                        if (extraImagePaths != null && extraImagePaths.size() > 0 && extraImagePaths.size() > mSelectedPostion) {
                            extraImagePaths.remove(mSelectedPostion);
                            extraImagePaths.add(mSelectedPostion, imagePath);
                        }

                        for (int idx = 0; idx < mTemplateItemList.size(); idx++) {
                            TemplateItem item = mTemplateItemList.get(idx);
                            for (int i = 0; i < item.getPhotoItemList().size(); i++) {
                                PhotoItem photoItem = item.getPhotoItemList().get(i);
                                photoItem.imagePath = mSelectedPhotoPaths.get(i);
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                mSelectedColor = -1;
                mSelectedBG = getImageContentUri(this, new File(Constants.photoModel.getImagePath()));
                Glide.with(BaseTemplateDetailActivity.this).load(Constants.photoModel.getImagePath()).into(new CustomTarget<Drawable>() {
                    @Override
                    public void onResourceReady(@NonNull Drawable resource, @Nullable Transition<? super Drawable> transition) {
                        mFramePhotoLayout.setBackground(resource);
                        if (mPopupWindow.isShowing()) {
                            closePopupWindow();
                        }
                        mFramePhotoLayout.removeSelection();
                        findViewById(R.id.bottomRecycler).setVisibility(View.GONE);
                        imgBtnClose.setVisibility(View.GONE);
                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {

                    }
                });
            }
            Constants.photoModel = null;
        }
    }

    private void openViewImage() {
        isSave = false;
        if (file != null) {
            Constants.savedImageUri = Uri.fromFile(file);
            Constants.path = file.getAbsolutePath();
            Toast.makeText(mContext, "Image Saved at Photo Collage Maker.", Toast.LENGTH_SHORT).show();

            if (!AdsPrefs.getBoolean(this, AdsPrefs.IS_SUBSCRIBED) && isInterstitialAdLoaded) {
                interstitial.show();
            } else {
                startActivity(new Intent(BaseTemplateDetailActivity.this, ViewImageActivity.class));
                Log.d(TAG, "onPostExecute: " + Constants.savedImageUri + "   " + file.getAbsolutePath());
            }

        } else if (errMsg != null) {
            Toast.makeText(BaseTemplateDetailActivity.this, "Please try again", Toast.LENGTH_LONG).show();
        }
    }

    protected void hideView() {

        findViewById(R.id.bottomRecycler).setVisibility(View.GONE);
        findViewById(R.id.backimageLayout).setVisibility(View.INVISIBLE);
        findViewById(R.id.recyclerViewBGImage).setVisibility(View.INVISIBLE);
        findViewById(R.id.spaceLayout).setVisibility(View.INVISIBLE);
        findViewById(R.id.templateLayout).setVisibility(View.INVISIBLE);
        findViewById(R.id.ratioLayout).setVisibility(View.INVISIBLE);
        findViewById(R.id.textLayout).setVisibility(View.GONE);
        if (!mPopupWindow.isShowing())
            findViewById(R.id.imgBtnSmallClose).setVisibility(View.GONE);
    }

    private void initListner() {
        imgBtnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mPopupWindow.isShowing()) {
                    closePopupWindow();
                }
                mFramePhotoLayout.removeSelection();
                findViewById(R.id.bottomRecycler).setVisibility(View.GONE);
                imgBtnClose.setVisibility(View.GONE);
            }
        });

        txtStyle.setOnClickListener(v -> {
            txtStyle.setBackgroundColor(Color.parseColor("#63A2D5"));
            txtColor.setBackgroundColor(ContextCompat.getColor(this, R.color.colorSubBottomBar));

            openFontMenu();
        });

        txtColor.setOnClickListener(v -> {
            txtColor.setBackgroundColor(Color.parseColor("#63A2D5"));
            txtStyle.setBackgroundColor(ContextCompat.getColor(this, R.color.colorSubBottomBar));

            openTextColorMenu();
        });

        findViewById(R.id.btnAdd).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isMultiClicked) {
                    if (isFragmentLoaded) {
                        removeFragment();
                    }
                    selectItem(v, findViewById(R.id.textView20), mViewSelectedMenuAdd);
                    findViewById(R.id.bottomRecycler).setVisibility(View.INVISIBLE);
                    findViewById(R.id.spaceLayout).setVisibility(View.INVISIBLE);
                    findViewById(R.id.templateLayout).setVisibility(View.INVISIBLE);
                    findViewById(R.id.recyclerViewBGImage).setVisibility(View.INVISIBLE);
                    findViewById(R.id.ratioLayout).setVisibility(View.INVISIBLE);
                    findViewById(R.id.backimageLayout).setVisibility(View.INVISIBLE);
                    findViewById(R.id.textLayout).setVisibility(View.INVISIBLE);

                    imgBtnClose.setVisibility(View.GONE);
                    closePopupWindow();

                    Log.d(TAG, "onClick: " + Constants.mSelectedImageListTemp.size());
                    Constants.mSelectedImageList.clear();
                    Constants.mSelectedImageList.addAll(Constants.mSelectedImageListTemp);

                    Intent intent = new Intent(BaseTemplateDetailActivity.this, GalleryActivity.class);
                    intent.putExtra("type", "collage");
                    intent.putExtra("single", false);
                    intent.putExtra("collage", true);
                    startActivityForResult(intent, 4055);
                }
            }
        });

        findViewById(R.id.btnBGColor).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isMultiClicked) {
                    if (isFragmentLoaded) {
                        removeFragment();
                    }
                    closePopupWindow();

                    selectItem(view, findViewById(R.id.textView10), mViewSelectedMenuBackground);
                    //imgBtnClose.setVisibility(View.VISIBLE);

                    findViewById(R.id.bottomRecycler).setVisibility(View.VISIBLE);

                    findViewById(R.id.backimageLayout).setVisibility(View.VISIBLE);
                    findViewById(R.id.recyclerViewBGImage).setVisibility(View.INVISIBLE);
                    findViewById(R.id.spaceLayout).setVisibility(View.INVISIBLE);
                    findViewById(R.id.templateLayout).setVisibility(View.INVISIBLE);
                    findViewById(R.id.ratioLayout).setVisibility(View.INVISIBLE);
                    findViewById(R.id.textLayout).setVisibility(View.GONE);

                    openColorMenu();
                }
            }
        });

        findViewById(R.id.btnFrames).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mTemplateItemListTemp.size() == 1){
                    return;
                }

                if (isMultiClicked) {
                    if (isFragmentLoaded) {
                        removeFragment();
                    }
                    selectItem(view, findViewById(R.id.textView9), mViewSelectedMenuLayout);
                    //imgBtnClose.setVisibility(View.VISIBLE);

                    findViewById(R.id.bottomRecycler).setVisibility(View.VISIBLE);

                    closePopupWindow();
                    findViewById(R.id.spaceLayout).setVisibility(View.INVISIBLE);
                    findViewById(R.id.templateLayout).setVisibility(View.VISIBLE);
                    findViewById(R.id.recyclerViewBGImage).setVisibility(View.INVISIBLE);
                    findViewById(R.id.ratioLayout).setVisibility(View.INVISIBLE);
                    findViewById(R.id.backimageLayout).setVisibility(View.INVISIBLE);
                    findViewById(R.id.textLayout).setVisibility(View.GONE);
                }
            }
        });

        findViewById(R.id.btnBorder).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isMultiClicked) {
                    if (isFragmentLoaded) {
                        removeFragment();
                    }
                    selectItem(view, findViewById(R.id.textView11), mViewSelectedMenuSpace);
                    //imgBtnClose.setVisibility(View.VISIBLE);

                    findViewById(R.id.bottomRecycler).setVisibility(View.VISIBLE);
                    closePopupWindow();
                    findViewById(R.id.spaceLayout).setVisibility(View.VISIBLE);
                    findViewById(R.id.templateLayout).setVisibility(View.INVISIBLE);
                    findViewById(R.id.recyclerViewBGImage).setVisibility(View.INVISIBLE);
                    findViewById(R.id.ratioLayout).setVisibility(View.INVISIBLE);
                    findViewById(R.id.backimageLayout).setVisibility(View.INVISIBLE);
                    findViewById(R.id.textLayout).setVisibility(View.GONE);
                }
            }
        });

        findViewById(R.id.btnRatio).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isMultiClicked) {
                    if (isFragmentLoaded) {
                        removeFragment();
                    }
                    closePopupWindow();

                    selectItem(view, findViewById(R.id.textView12), mViewSelectedMenuRatio);

                    //imgBtnClose.setVisibility(View.VISIBLE);
                    findViewById(R.id.bottomRecycler).setVisibility(View.VISIBLE);

                    findViewById(R.id.spaceLayout).setVisibility(View.INVISIBLE);
                    findViewById(R.id.templateLayout).setVisibility(View.INVISIBLE);
                    findViewById(R.id.recyclerViewBGImage).setVisibility(View.INVISIBLE);
                    findViewById(R.id.ratioLayout).setVisibility(View.VISIBLE);
                    findViewById(R.id.backimageLayout).setVisibility(View.INVISIBLE);
                    findViewById(R.id.textLayout).setVisibility(View.GONE);
                }
            }
        });

        findViewById(R.id.btnSelectBG).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //loadBackground();
            }
        });

        findViewById(R.id.btnSelectColor).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // openColorMenu();
            }
        });

        imgBtnDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isFragmentLoaded) {
                    removeFragment();
                } else {
                    closePopupWindow();
                    selectItem(null, null, null);
                    imgBtnDone.setEnabled(false);
                    Dialog saveDialog = new Dialog(BaseTemplateDetailActivity.this);
                    saveDialog.setContentView(R.layout.dialog_save);
                    saveDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                    saveDialog.getWindow().setLayout(ConstraintLayout.LayoutParams.MATCH_PARENT, ConstraintLayout.LayoutParams.WRAP_CONTENT);
                    TextView btnCancel = saveDialog.findViewById(R.id.btnCancel);
                    TextView btnSave = saveDialog.findViewById(R.id.btnSave);
                    btnCancel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            saveDialog.dismiss();
                        }
                    });

                    btnSave.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            saveDialog.dismiss();
                            //imgBtnDone.setEnabled(false);
                            closePopupWindow();
                            if (isBlurViewOpen) {
                                Log.d(TAG, "onClick: blur");
                                blurImageFragment.saveImage();
                                //imgBtnDone.setEnabled(true);
                            } else {
                                mFramePhotoLayout.removeSelection();
                                findViewById(R.id.bottomRecycler).setVisibility(View.GONE);
                                imgBtnClose.setVisibility(View.GONE);
                                asyncSaveAndShare();
                                //imgBtnDone.setEnabled(true);
                            }
                        }
                    });
                    saveDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override
                        public void onDismiss(DialogInterface dialog) {
                            imgBtnDone.setEnabled(true);
                        }
                    });
                    if (!isFinishing()) {
                        saveDialog.show();
                    }
                }
            }
        });

        findViewById(R.id.imgBtnBack).setOnClickListener(v -> {
            onBackPressed();
        });

        findViewById(R.id.btnText).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isMultiClicked) {
                    selectItem(view, findViewById(R.id.textView13), mViewSelectedMenuText);
                    //imgBtnClose.setVisibility(View.VISIBLE);

                    findViewById(R.id.bottomRecycler).setVisibility(View.INVISIBLE);

                    findViewById(R.id.spaceLayout).setVisibility(View.INVISIBLE);
                    findViewById(R.id.templateLayout).setVisibility(View.INVISIBLE);
                    findViewById(R.id.recyclerViewBGImage).setVisibility(View.INVISIBLE);
                    findViewById(R.id.ratioLayout).setVisibility(View.INVISIBLE);
                    findViewById(R.id.backimageLayout).setVisibility(View.INVISIBLE);
                    findViewById(R.id.textLayout).setVisibility(View.INVISIBLE);

                    closePopupWindow();
                    mSelectedView = null;
                    // addText();

                    if (!isFragmentLoaded) {
                        initTextSticker();
                    }
                }
            }
        });
    }

    //Text Sticker
    private void initTextSticker() {
        if (!isFragmentLoaded) {
            onclickText(0);
        }
    }

    private void onclickText(int fromWhere) {
        mToolbarText.setVisibility(View.VISIBLE);
        mToolbar1.setVisibility(View.INVISIBLE);

        findViewById(R.id.btnText).setEnabled(false);
        String defaultText = "";
        String defaultTypeface = "fonts/1.ttf";
        int defaultTextColor = Color.BLACK;
        try {
            if (fromWhere == 1) {
                defaultText = ((TextSticker) mSticker).getText();
                defaultTypeface = ((TextSticker) mSticker).getTypefacePath();
                defaultTextColor = ((TextSticker) mSticker).getColor();
                Constants.textStickerColor = defaultTextColor;
            } else {
                defaultText = "";
                defaultTypeface = "fonts/1.ttf";
                defaultTextColor = Color.BLACK;
                Constants.textStickerColor = defaultTextColor;
            }
        } catch (Exception e) {
            defaultText = "";
            defaultTypeface = "fonts/1.ttf";
            defaultTextColor = Color.BLACK;
            Constants.textStickerColor = defaultTextColor;
        }

        addTextFragment =
                new AddTextFragment().Companion.newInstance(defaultText, defaultTypeface, defaultTextColor);
        FragmentTransaction ft =
                getSupportFragmentManager().beginTransaction();
        ft.add(R.id.frmTextFragment, addTextFragment);
        ft.commit();
        isFragmentLoaded = true;

        mBtnDoneText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Constants.stickerText.length() != 0) {
                    removeFragment();
                    if (fromWhere == 1) {
                        replaceText(Constants.stickerText);
                    } else {
                        addText(Constants.stickerText);
                    }
                } else {
                    Toast.makeText(mContext, "Add some text", LENGTH_SHORT).show();
                }
            }
        });
        mImgBtnBackText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    public void removeFragment() {
        try {
            findViewById(R.id.btnText).setEnabled(true);
            getSupportFragmentManager().beginTransaction()
                    .remove(addTextFragment)
                    .commitAllowingStateLoss();
            selectItem(null, null, null);
            //imgColor!!.visibility = View.VISIBLE
            //mLinearUndoRedo!!.visibility = View.VISIBLE
            //mLblHeaderTextBrush!!.visibility = View.GONE
            //mImgBack!!.setImageResource(R.drawable.ic_back)
            mToolbarText.setVisibility(View.INVISIBLE);
            mToolbar1.setVisibility(View.VISIBLE);
            isFragmentLoaded = false;
            hideKeyboard(this);
            //mImgDone!!.alpha = 0.5f
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void hideKeyboard(Activity activity) {
        InputMethodManager imm =
                (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = activity.getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public void closePopupWindow() {
        if (mPopupWindow.isShowing()) {
            mPopupWindow.dismiss();
            imgBtnClose.setVisibility(View.GONE);
        }
    }

    private void openFontMenu() {
        FontProvider provider = new FontProvider(getResources());
        fontAdepter = new FontAdepter(provider.getFontNames(), this, position -> {
            if (mSticker != null) {
                TextSticker sticker = (TextSticker) mSticker;
                sticker.setTypeface(provider.getTypeface(provider.getFontNames().get(position)));
                sticker.setTypefacePath(provider.getFontNames().get(position));
                mStickerView.invalidate();
            }
        }, "Aa");

        recyclerViewText.setAdapter(fontAdepter);

        fontAdepter.mLastPostion = provider.getFontNames().indexOf(((TextSticker) mSticker).getTypefacePath());
        fontAdepter.notifyDataSetChanged();

    }

    protected void selectItem(View view, View view1, View view2) {
        findViewById(R.id.btnAdd).setAlpha(0.5f);
        findViewById(R.id.textView20).setAlpha(0.5f);
        stopBottomMenuAnimation(findViewById(R.id.textView20), findViewById(R.id.btnAdd), mViewSelectedMenuAdd);

        findViewById(R.id.btnFrames).setAlpha(0.5f);
        findViewById(R.id.textView9).setAlpha(0.5f);
        stopBottomMenuAnimation(findViewById(R.id.textView9), findViewById(R.id.btnFrames), mViewSelectedMenuLayout);

        findViewById(R.id.btnBGColor).setAlpha(0.5f);
        findViewById(R.id.textView10).setAlpha(0.5f);
        stopBottomMenuAnimation(findViewById(R.id.textView10), findViewById(R.id.btnBGColor), mViewSelectedMenuBackground);

        findViewById(R.id.btnBorder).setAlpha(0.5f);
        findViewById(R.id.textView11).setAlpha(0.5f);
        stopBottomMenuAnimation(findViewById(R.id.textView11), findViewById(R.id.btnBorder), mViewSelectedMenuSpace);

        findViewById(R.id.btnRatio).setAlpha(0.5f);
        findViewById(R.id.textView12).setAlpha(0.5f);
        stopBottomMenuAnimation(findViewById(R.id.textView12), findViewById(R.id.btnRatio), mViewSelectedMenuRatio);

        findViewById(R.id.btnText).setAlpha(0.5f);
        findViewById(R.id.textView13).setAlpha(0.5f);
        stopBottomMenuAnimation(findViewById(R.id.textView13), findViewById(R.id.btnText), mViewSelectedMenuText);

        if (view != null && view1 != null && view2 != null) {
            view.setAlpha(1);
            view1.setAlpha(1);
            startBottomMenuAnimation(view1, view, view2);
        }
    }

    private void startBottomMenuAnimation(View textView, View btnAdd, View view) {
        view.animate().alpha(1f).setDuration(200);
        view.setVisibility(View.VISIBLE);
        btnAdd.animate().alpha(1f).translationY(-8f).scaleX(1.2f).scaleY(1.2f).setDuration(350);
        textView.animate().alpha(1f).translationY(-6f).setDuration(350);
    }

    private void stopBottomMenuAnimation(View textView, View btnAdd, View view) {
        view.animate().alpha(0.5f).setDuration(200);
        view.setVisibility(View.GONE);
        btnAdd.animate().alpha(0.5f).translationY(0f).scaleX(1f).scaleY(1f).setDuration(350);
        textView.animate().alpha(0.5f).translationY(0f).setDuration(350);
    }

    private void openColorMenu() {
        recyclerViewBGImage.setVisibility(View.VISIBLE);
        recyclerViewBGImage.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        recyclerViewBGImage.setItemAnimator(new DefaultItemAnimator());
        ColorAdepter.setOnItemClickListener listener = new ColorAdepter.setOnItemClickListener() {
            @Override
            public void OnItemClicked(int color) {

                if (color != -10) {

                    mSelectedBG = null;
                    mSelectedColor = color;
                    mFramePhotoLayout.setBackground(null);
                    mFramePhotoLayout.setBackgroundColor(color);
                } else {
                    Imagetype = 0;
                    chooseImageFromGallery();
                }
            }
        };
        ArrayList<Integer> mColor = new ArrayList<>(mColors);
        mColor.add(0, -10);
        ColorAdepter colorAdepter = new ColorAdepter(mColor, this, listener, true);
        recyclerViewBGImage.setAdapter(colorAdepter);
    }


    /*private void chooseImageFromGallery() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(galleryIntent, Constants.PICK_IMAGE_CODE);
    }*/

    public void loadBackground() {
        recyclerViewBGImage.setVisibility(View.VISIBLE);
        recyclerViewBGImage.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        recyclerViewBGImage.setItemAnimator(new DefaultItemAnimator());
        fetchBackgroundImages();

        BackgroundCollageAdepter.OnRatioSelect onRatioSelect1 = new BackgroundCollageAdepter.OnRatioSelect() {
            @Override
            public void onRatioSelected(String ratio, int position) {
                //mSelectedBG = position;
                mSelectedColor = -1;
                //buildLayout(mSelectedTemplateItem);

                Glide.with(BaseTemplateDetailActivity.this).load(mSelectedBG).into(new CustomTarget<Drawable>() {
                    @Override
                    public void onResourceReady(@NonNull Drawable resource, @Nullable Transition<? super Drawable> transition) {
                        mFramePhotoLayout.setBackground(resource);
                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {

                    }
                });

            }
        };

        BackgroundCollageAdepter adepter1 = new BackgroundCollageAdepter(this, mImageList, onRatioSelect1);
        recyclerViewBGImage.setAdapter(adepter1);

    }

    private void fetchBackgroundImages() {

        mImageList = new ArrayList<>();

        try {
            String[] files = this.getAssets().list("background");
            for (String name : files) {
                mImageList.add("file:///android_asset/background" + File.separator + name);
                Log.e("pathList item", "file:///android_asset/background" + File.separator + name);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void initViewAction() {


        deleteRecursive(new File(Environment.getExternalStorageDirectory().getPath() + File.separator + getString(R.string.app_name) + File.separator + ".tmp"));

        //Load ads
        if (!AdsPrefs.getBoolean(this, AdsPrefs.IS_SUBSCRIBED)) {
            interstitial = InterstitialAdHelper.getInstance().load(BaseTemplateDetailActivity.this, this);
        }

        //keyboard height provider
        keyboardHeightProvider = new KeyboardHeightProvider(this);

        mRootLayout.post(new Runnable() {
            @Override
            public void run() {
                if (keyboardHeightProvider != null)
                    keyboardHeightProvider.start();
            }
        });

        disableEnableControls(false, mButtonLayout);
        imgBtnDone.setEnabled(false);

        mColors = new ArrayList<>();
        String[] allColors = getResources().getStringArray(R.array.colors);
        mColors.clear();
        for (String allColor : allColors) {
            mColors.add(Color.parseColor(allColor));
        }

        mTextViewList = new ArrayList<>();
        mSelectedImageSize = getIntent().getIntExtra(GalleryActivity.EXTRA_SELCTED_IMAGES_SIZE, 0);

        SharedPrefs mSharedPrefs = new SharedPrefs(mContext);
        Gson gson = new Gson();
        ArrayList<String> gsonModelArrayList = gson.fromJson(mSharedPrefs.getPhotoList(),
                new TypeToken<ArrayList<String>>() {
                }.getType());
        extraImagePaths = gsonModelArrayList;
        //extraImagePaths = getIntent().getStringArrayListExtra(GalleryActivity.EXTRA_SELECTED_IMAGES);
        imgBtnDone.setEnabled(false);
        mProgressBar.setVisibility(View.VISIBLE);
        setFramesImages(true, "");

        mStickerView.setLocked(false);
        mStickerView.setConstrained(true);

        mStickerView.setOnStickerOperationListener(new StickerView.OnStickerOperationListener() {
            @Override
            public void onStickerAdded(@NonNull Sticker sticker) {

                mSticker = sticker;
                if (colorAdepter != null && mSticker instanceof TextSticker)
                    colorAdepter.setLastSelectedItem(((TextSticker) mSticker).getColor());

                if (fontAdepter != null) {
                    fontAdepter.setSelectedItem(((TextSticker) mSticker).getTypefacePath());
                }

               /* Matrix newMatrix = new Matrix();
                sticker.getMatrix().postTranslate( mMainWidth / 2, mMainHeight / 2);
                mStickerView.centerAllSticker();
                mStickerView.invalidate();*/
            }

            @Override
            public void onStickerClicked(@NonNull Sticker sticker) {
                closePopupWindow();
                mFramePhotoLayout.removeSelection();

                mSticker = sticker;
                /*if (colorAdepter != null && mSticker instanceof TextSticker)
                    colorAdepter.setLastSelectedItem((((TextSticker) mSticker).getColor()));

                if (fontAdepter != null)
                    fontAdepter.setSelectedItem(((TextSticker) mSticker).getTypefacePath());

                imgBtnClose.setVisibility(View.VISIBLE);

                findViewById(R.id.bottomRecycler).setVisibility(View.VISIBLE);

                findViewById(R.id.spaceLayout).setVisibility(View.INVISIBLE);
                findViewById(R.id.templateLayout).setVisibility(View.INVISIBLE);
                findViewById(R.id.recyclerViewBGImage).setVisibility(View.INVISIBLE);
                findViewById(R.id.ratioLayout).setVisibility(View.INVISIBLE);
                findViewById(R.id.backimageLayout).setVisibility(View.INVISIBLE);

                mSelectedView = null;*/
                selectItem(findViewById(R.id.btnText), findViewById(R.id.textView13), mViewSelectedMenuText);
                //findViewById(R.id.textLayout).setVisibility(View.VISIBLE);

            }

            @Override
            public void onStickerDeleted(@NonNull Sticker sticker) {
                if (mStickerView.getStickers().size() == 0) {
                    hideView();
                }
                if (colorAdepter != null)
                    colorAdepter.setLastSelectedItem(-2);
            }

            @Override
            public void onStickerDragFinished(@NonNull Sticker sticker) {

            }

            @Override
            public void onStickerTouchedDown(@NonNull Sticker sticker) {
                /*closePopupWindow();
                mFramePhotoLayout.removeSelection();

                mSticker = sticker;
                if (colorAdepter != null && mSticker instanceof TextSticker)
                    colorAdepter.setLastSelectedItem((((TextSticker) mSticker).getColor()));

                if (fontAdepter != null)
                    fontAdepter.setSelectedItem(((TextSticker) mSticker).getTypefacePath());

                selectItem(findViewById(R.id.btnText), findViewById(R.id.textView13));
                imgBtnClose.setVisibility(View.VISIBLE);

                findViewById(R.id.bottomRecycler).setVisibility(View.VISIBLE);

                findViewById(R.id.spaceLayout).setVisibility(View.INVISIBLE);
                findViewById(R.id.templateLayout).setVisibility(View.INVISIBLE);
                findViewById(R.id.recyclerViewBGImage).setVisibility(View.INVISIBLE);
                findViewById(R.id.ratioLayout).setVisibility(View.INVISIBLE);
                findViewById(R.id.backimageLayout).setVisibility(View.INVISIBLE);
                findViewById(R.id.textLayout).setVisibility(View.VISIBLE);

                mSelectedView = null;*/
            }

            @Override
            public void onStickerZoomFinished(@NonNull Sticker sticker) {

            }

            @Override
            public void onStickerFlipped(@NonNull Sticker sticker) {

            }

            @Override
            public void onStickerDoubleTapped(@NonNull Sticker sticker) {
                /*if (sticker instanceof TextSticker) {
                    mSticker = sticker;
                    TextSticker sticker1 = (TextSticker) mSticker;
                    String text = "";
                    if (!sticker1.isFirst()) {
                        text = sticker1.getText();
                    }

                    fragment = TextEditorDialogFragment.getInstance(text);
                    fragment.show(getSupportFragmentManager(), TextEditorDialogFragment.class.getName());
                }*/
            }

            @Override
            public void onStickerViewTouch() {
                //hideView();
            }

            @Override
            public void onStickerEditClicked(@NonNull Sticker sticker) {
                if (isMultiClicked) {
                    isMultiClicked = false;

                    selectItem(findViewById(R.id.btnText), findViewById(R.id.textView13), mViewSelectedMenuText);

                    closePopupWindow();
                    findViewById(R.id.bottomRecycler).setVisibility(View.INVISIBLE);

                    findViewById(R.id.spaceLayout).setVisibility(View.INVISIBLE);
                    findViewById(R.id.templateLayout).setVisibility(View.INVISIBLE);
                    findViewById(R.id.recyclerViewBGImage).setVisibility(View.INVISIBLE);
                    findViewById(R.id.ratioLayout).setVisibility(View.INVISIBLE);
                    findViewById(R.id.backimageLayout).setVisibility(View.INVISIBLE);
                    findViewById(R.id.textLayout).setVisibility(View.INVISIBLE);


                    mFramePhotoLayout.removeSelection();
                    findViewById(R.id.bottomRecycler).setVisibility(View.GONE);
                    imgBtnClose.setVisibility(View.GONE);

                    onclickText(1);

                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            isMultiClicked = true;
                        }
                    }, 400);
                }
            }
        });

        //openTextColorMenu();
    }

    protected void disableEnableControls(boolean enable, ViewGroup vg) {
        for (int i = 0; i < vg.getChildCount(); i++) {
            View child = vg.getChildAt(i);
            child.setEnabled(enable);
            if (child instanceof ViewGroup) {
                disableEnableControls(enable, (ViewGroup) child);
            }
        }
    }

    private void openTextColorMenu() {
        recyclerViewText.setVisibility(View.VISIBLE);
        recyclerViewText.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        recyclerViewText.setItemAnimator(new DefaultItemAnimator());
        ColorAdepter.setOnItemClickListener listener = new ColorAdepter.setOnItemClickListener() {
            @Override
            public void OnItemClicked(int color) {
                if (mSticker != null) {
                    TextSticker sticker = (TextSticker) mSticker;
                    sticker.setTextColor(color);
                    mStickerView.invalidate();
                }
            }
        };
        colorAdepter = new ColorAdepter(mColors, this, listener, false);
        recyclerViewText.setAdapter(colorAdepter);
    }

    private void setRatioAdapter() {
        RatioAdepter.OnRatioSelect onRatioSelect = new RatioAdepter.OnRatioSelect() {
            @Override
            public void onRatioSelected(String ratio) {
                closePopupWindow();
                Constants.mRatio = ratio;
                changeRatio(ratio);

            }
        };

        RatioAdepter adepter = new RatioAdepter(this, mRatioList, onRatioSelect);
        recyclerViewRatio.setAdapter(adepter);
    }

    private void changeRatio(String ratio) {
        if (!ratio.toLowerCase().equals("full")) {
            String[] ratioArray = ratio.split(" ");

            int width = getScreenWidth();
            int height = mContainerLayout.getHeight();

            int outWidth = width;
            int outHeight = height;

            int ratioX = Integer.parseInt(ratioArray[0]);
            int ratioY = Integer.parseInt(ratioArray[ratioArray.length - 1]);

            float collageRatio = (float) ratioY / (float) ratioX;

            int h, w;
            if (ratioX > ratioY) {
                int temp = mMainWidth / ratioX;
                h = temp * ratioY;
                w = mMainWidth;
            } else if (ratioY > ratioX) {
                int temp = mMainHeight / ratioY;
                w = temp * ratioX;
                h = mMainHeight;
            } else {
                h = w = mMainWidth;
            }


            outHeight = Math.round(width * collageRatio);
            //outHeight = Math
            viewWidth = w;
            viewHeight = h;

            mStickerView.getLayoutParams().width = w;
            mStickerView.getLayoutParams().height = h;
            mStickerView.requestLayout();

        } else {
            viewWidth = mMainWidth;
            viewHeight = mMainHeight;

            mStickerView.getLayoutParams().width = mainCenterConstraint.getWidth();
            mStickerView.getLayoutParams().height = mainCenterConstraint.getHeight();
            mStickerView.requestLayout();
        }
        textInCenter();
        buildLayout(mSelectedTemplateItem, true);
    }

    private void initViews() {
        mToolbar1 = findViewById(R.id.toolbarLayout);
        mToolbarText = findViewById(R.id.toolbarLayout_text);
        mContainerLayout = findViewById(R.id.containerLayout);
        mButtonLayout = findViewById(R.id.bottomLayout);
        mRootLayout = findViewById(R.id.rootPhotoLayout);
        mTemplateView = findViewById(R.id.templateView);
        textContainerLayout = findViewById(R.id.textContainerLayout);
        mainContainer = findViewById(R.id.mainContainer);
        mainCenterConstraint = findViewById(R.id.mainCenterConstraint);
        mStickerView = findViewById(R.id.stickerView);
        recyclerViewRatio = findViewById(R.id.recyclerViewRatio);
        mTextLayout = findViewById(R.id.textLayout);
        recyclerViewText = findViewById(R.id.colorRv);
        mProgressBar = findViewById(R.id.progressBar3);

        txtColor = findViewById(R.id.txtColor);
        txtStyle = findViewById(R.id.txtStyle);
        imgBtnClose = findViewById(R.id.imgBtnSmallClose);
        imgBtnDone = findViewById(R.id.btnDone);

        mImgBtnBackText = findViewById(R.id.imgBtnBackText);
        mBtnDoneText = findViewById(R.id.btnDoneText);

        mViewSelectedMenuAdd = findViewById(R.id.viewSelectedMenuAdd);
        mViewSelectedMenuLayout = findViewById(R.id.viewSelectedMenuLayout);
        mViewSelectedMenuBackground = findViewById(R.id.viewSelectedMenuBackground);
        mViewSelectedMenuSpace = findViewById(R.id.viewSelectedMenuSpace);
        mViewSelectedMenuRatio = findViewById(R.id.viewSelectedMenuRatio);
        mViewSelectedMenuText = findViewById(R.id.viewSelectedMenuText);
        mBtnMoreAPI = findViewById(R.id.btnMoreAPI);
    }

    private void prepareTextOptions() {
        mOptionList.clear();
        mOptionList.add(new OptionModel(1, R.drawable.ic_delete_black_24dp, "DELETE"));
        mOptionList.add(new OptionModel(2, R.drawable.ic_edit, "EDIT"));
    }

    private void textInCenter() {

        for (TextModel model : mTextViewList) {
            model.getTextView().setTranslationX(0);
            model.getTextView().setTranslationY(0);
        }

    }

    @Override
    public void textChanged(@NonNull String text) {
        TextSticker sticker = (TextSticker) mSticker;
        if (sticker.isFirst()) {
            sticker.setFirst(false);
        }
        text = text.trim();
        if (text.equals("")) {
            text = "Hello";
            sticker.setFirst(true);
        }


        sticker.setText(text);
        sticker.resizeText();
        mStickerView.replace(sticker);
        mStickerView.invalidate();
    }

    private void addText(String myText) {

        /*EditTextDialog textDialog = null;

        TextModel textModel = null;

        for (TextModel view : mTextViewList) {
            if (mSelectedView != null && mSelectedView.equals(view.getTextView())) {
                textModel = view;
                break;
            }
        }

        if (mSelectedView != null && mSelectedView instanceof TextView) {
            textDialog = new EditTextDialog(textModel);
        } else {
            textDialog = new EditTextDialog(null);
        }

        textDialog.setListener(model -> {

            boolean isExist = false;
            for (TextModel viewmodel : mTextViewList) {
                if (model.getTextView().equals(viewmodel.getTextView())) {
                    isExist = true;
                    break;
                }
            }
            if (!isExist) {
                TextView textView = model.getTextView();
                MultiTouchListener multiTouchListener = new MultiTouchListener();
                multiTouchListener.setEvent(this);

                textView.setOnTouchListener(multiTouchListener);

                textView.setId(Integer.parseInt(textContainerLayout.getChildCount() + "101"));
                textContainerLayout.addView(textView);
                mTextViewList.add(model);
*//*
                ConstraintLayout.LayoutParams params= (ConstraintLayout.LayoutParams) textView.getLayoutParams();
                params.startToStart=textContainerLayout.getId();
                params.topToTop=textContainerLayout.getTop();
                params.bottomToBottom=textContainerLayout.getTop();
                params.endToEnd=textContainerLayout.getTop();
                textView.setLayoutParams(params);*//*
                ConstraintSet set = new ConstraintSet();

                set.clone(textContainerLayout);

                set.connect(textView.getId(), ConstraintSet.TOP, textContainerLayout.getId(), ConstraintSet.TOP, 0);
                set.connect(textView.getId(), ConstraintSet.LEFT, textContainerLayout.getId(), ConstraintSet.LEFT, 0);
                set.connect(textView.getId(), ConstraintSet.RIGHT, textContainerLayout.getId(), ConstraintSet.RIGHT, 0);
                set.connect(textView.getId(), ConstraintSet.BOTTOM, textContainerLayout.getId(), ConstraintSet.BOTTOM, 0);

                set.applyTo(textContainerLayout);
            }
        });

        textDialog.show(getSupportFragmentManager(), "EditTextDialog");*/
        FontProvider provider = new FontProvider(getResources());
        TextSticker sticker = new TextSticker(this);
        sticker.setText(myText);
        sticker.setTextColor(Constants.textStickerColor);
        sticker.setTextAlign(Layout.Alignment.ALIGN_CENTER);
        sticker.setTypeface(Typeface.createFromAsset(getAssets(), Constants.textFontPath));
        sticker.setTypefacePath(Constants.textFontPath);
        sticker.resizeText();
        sticker.setFirst(true);
        mSticker = sticker;
        mStickerView.addSticker(mSticker);
    }

    private void replaceText(String myText) {
        FontProvider provider = new FontProvider(getResources());
        TextSticker sticker = new TextSticker(this);

        if (sticker.isFirst()) {
            sticker.setFirst(false);
        }

        sticker.setText(myText);
        sticker.setTextColor(Constants.textStickerColor);
        sticker.setTypeface(Typeface.createFromAsset(getAssets(), Constants.textFontPath));
        sticker.setTypefacePath(Constants.textFontPath);
        sticker.resizeText();
        mSticker = sticker;
        mStickerView.replace(mSticker);
    }


    @SuppressLint("StaticFieldLeak")
    private void setFramesImages(boolean isOnCreation, String isHandle) {
        new AsyncTask<Void, Void, Void>() {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                imgBtnDone.setEnabled(false);
                mProgressBar.setVisibility(View.VISIBLE);
            }

            @Override
            protected Void doInBackground(Void... voids) {
                loadFrameImages(mIsFrameImage);

                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                mProgressBar.setVisibility(View.GONE);
                imgBtnDone.setEnabled(true);
                imgBtnDone.setAlpha(1f);
                mSelectedTemplateItem = mTemplateItemList.get(0);
                mSelectedTemplateItem.setSelected(true);
                if (extraImagePaths != null) {
                    int size = Math.min(extraImagePaths.size(), mSelectedTemplateItem.getPhotoItemList().size());
                    for (int i = 0; i < size; i++) {
                        Log.d(TAG, "setFramesImages: " + extraImagePaths.get(i));
                        mSelectedTemplateItem.getPhotoItemList().get(i).imagePath = extraImagePaths.get(i);
                    }
                }
                setFrames();
                if (isOnCreation) {
                    //Create after initializing
                    mContainerLayout.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                        @Override
                        public void onGlobalLayout() {
                            mOutputScale = ImageUtils.calculateOutputScaleFactor(mContainerLayout.getWidth(), mContainerLayout.getHeight());
                            buildLayout(mSelectedTemplateItem, false);
                            // remove listener
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                                mContainerLayout.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                            } else {
                                mContainerLayout.getViewTreeObserver().removeGlobalOnLayoutListener(this);
                            }
                        }
                    });
                    viewWidth = mContainerLayout.getWidth();
                    viewHeight = mContainerLayout.getHeight();

                    recyclerViewRatio.setLayoutManager(new LinearLayoutManager(mContext, RecyclerView.HORIZONTAL, false));
                    recyclerViewRatio.setItemAnimator(new DefaultItemAnimator());

                    getRatio();
                    setRatioAdapter();

                    for (int idx = 0; idx < mSelectedTemplateItem.getPhotoItemList().size(); idx++) {
                        PhotoItem photoItem = mSelectedTemplateItem.getPhotoItemList().get(idx);
                        if (photoItem.imagePath != null && photoItem.imagePath.length() > 0) {
                            if (idx < mSelectedPhotoPaths.size()) {
                                mSelectedPhotoPaths.add(idx, photoItem.imagePath);
                            } else {
                                mSelectedPhotoPaths.add(photoItem.imagePath);
                            }
                        }
                    }
                } else {
                    if (isHandle.equals("")) {
                        changeRatio(Constants.mRatio);
                    } else {
                        buildLayout(mSelectedTemplateItem, false);

                    }
                }
            }
        }.execute();

    }

    private void setFrames() {
        for (int i = 0; i < mTemplateItemList.size(); i++) {
            if (i <= 6) {
                mTemplateItemListTemp.add(mTemplateItemList.get(i));
            } else {
                mTemplateItemListMoreTemp.add(mTemplateItemList.get(i));
            }
        }
//        Collections.shuffle(mTemplateItemListMoreTemp);
        mTemplateAdapter = new HorizontalPreviewTemplateAdapter(mContext, mTemplateItemListTemp, this);
        //Show templates
        mTemplateView.setHasFixedSize(true);
        mTemplateView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        mTemplateView.setAdapter(mTemplateAdapter);
    }


    public void getRatio() {

        mRatioList = new ArrayList<>();
        mRatioList.add(new RatioModel("Full", R.drawable.ic_ratio_frame_1));
        mRatioList.add(new RatioModel("1 : 1", R.drawable.ic_ratio_frame_1));
        mRatioList.add(new RatioModel("2 : 1", R.drawable.ic_ratio_frame_3));
        mRatioList.add(new RatioModel("3 : 2", R.drawable.ic_ratio_frame_4));
        mRatioList.add(new RatioModel("2 : 3", R.drawable.ic_ratio_frame_1));
        mRatioList.add(new RatioModel("4 : 3", R.drawable.ic_ratio_frame_6));
        mRatioList.add(new RatioModel("3 : 4", R.drawable.ic_ratio_frame_1));
        mRatioList.add(new RatioModel("16 : 9", R.drawable.ic_ratio_frame_8));
        mRatioList.add(new RatioModel("4 : 5", R.drawable.ic_ratio_frame_1));
        mRatioList.add(new RatioModel("5 : 4", R.drawable.ic_ratio_frame_10));
        mRatioList.add(new RatioModel("5 : 7", R.drawable.ic_ratio_frame_1));


    }

    private AlertDialog mDeleteAlertDialog;

    public void handleOptionClick(OptionModel model) {
        Log.d("102356", "handleOptionClick: " + mSelectedFrameImageView + " position:" + mSelectedPostion);
        if (mSelectedFrameImageView != null) {
            if (model.getId() == 0) {

                blurImageFragment();

            } else if (model.getId() == 1) {
                if (mSelectedImageSize > 1) {

                    Log.d(TAG, "handleOptionClick: " + mSelectedColor);
                    Log.d(TAG, "handleOptionClick: " + mSelectedBG);

                    mDeleteAlertDialog = new AlertDialog.Builder(this)
                            .setMessage("Are you sure want to delete?")
                            .setPositiveButton("Delete", (dialog, which) -> {

                                try {
                                    mSelectedImageSize -= 1;
                                    String path = mSelectedTemplateItem.getPhotoItemList().get(mSelectedPostion).imagePath;
                                    int pos = extraImagePaths.indexOf(path);
                                    extraImagePaths.remove(pos);
                                    mSelectedPhotoPaths.remove(path);
                                    if (Constants.mSelectedImageListTemp != null) {
                                        Constants.mSelectedImageListTemp.remove(pos);
                                    }
                                    setFramesImages(false, "build");
                                    selectItem(null, null, null);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }


                                closePopupWindow();
                            })
                            .setNegativeButton("Cancel", (dialog, which) -> {
                                dialog.dismiss();
                            })
                            .show();

                } else {
                    Toast.makeText(this, "You Need At Least One Image.", Toast.LENGTH_SHORT).show();
                }


            } else if (model.getId() == 2) {
                Imagetype = 1;
                Constants.isAddImage = true;
                chooseImageFromGallery();

            } else if (model.getId() == 3) {
                openCropView();

            } else if (model.getId() == 4) {

                angle = -90;
                mSelectedFrameImageView.setImage(rotateBitmap(mSelectedFrameImageView.getImage(), angle));
                mSelectedFrameImageView.invalidate();

            } else if (model.getId() == 5) {

                angle = 90;
                mSelectedFrameImageView.setImage(rotateBitmap(mSelectedFrameImageView.getImage(), angle));
                mSelectedFrameImageView.invalidate();

            } else if (model.getId() == 7) {
                flipImage(HORIZONTAL);

            } else if (model.getId() == 6) {
                flipImage(VERTICAL);

            } else if (model.getId() == 8) {
                mScale = mSelectedFrameImageView.getScaleX();
                mScale += 0.15f;
              /*  if (mScale >= 1.5f) {
                    mScale = 1.5f;
                }*/
                //  Log.d("456123", "handleOptionClick: "+mSelectedFrameImageView.getImage().getWidth()+" "+mSelectedFrameImageView.getImage().getHeight());
                //  mSelectedFrameImageView.setImage(zoomIn(mSelectedFrameImageView.getImage(),mScale));
                //  mSelectedFrameImageView.invalidate();
                //   Log.d("456123", "handleOptionClick: "+mSelectedFrameImageView.getImage().getWidth()*mScale+" "+mSelectedFrameImageView.getImage().getHeight()*mScale);
                mSelectedFrameImageView.setScaleXY(true, mScale);

            } else if (model.getId() == 9) {
                mScale = mSelectedFrameImageView.getScaleX();
                mScale -= 0.15f;
                /*if (mScale <= 0.25f) {
                    mScale = 0.25f;
                }*/
                // Log.d("456123", "handleOptionClick: "+mSelectedFrameImageView.getImage().getWidth()+" "+mSelectedFrameImageView.getImage().getHeight());
                // mSelectedFrameImageView.setImage(zoomOut(mSelectedFrameImageView.getImage(),mScale));
                //  mSelectedFrameImageView.invalidate();
                //  Log.d("456123", "handleOptionClick: "+mSelectedFrameImageView.getImage().getWidth()*mScale+" "+mSelectedFrameImageView.getImage().getHeight()*mScale);
                mSelectedFrameImageView.setScaleXY(false, mScale);

            } else if (model.getId() == 10) {
                mTranslateX = mSelectedFrameImageView.getTranslationX();
                mTranslateY = mSelectedFrameImageView.getTranslationY();
                mTranslateX -= 8;
                mSelectedFrameImageView.setTrasnlateXY(mTranslateX, mTranslateY);

            } else if (model.getId() == 11) {
                mTranslateX = mSelectedFrameImageView.getTranslationX();
                mTranslateY = mSelectedFrameImageView.getTranslationY();
                mTranslateX += 8;
                mSelectedFrameImageView.setTrasnlateXY(mTranslateX, mTranslateY);

            } else if (model.getId() == 12) {
                mTranslateY = mSelectedFrameImageView.getTranslationY();
                mTranslateX = mSelectedFrameImageView.getTranslationX();
                mTranslateY -= 8;
                mSelectedFrameImageView.setTrasnlateXY(mTranslateX, mTranslateY);

            } else if (model.getId() == 13) {
                mTranslateY = mSelectedFrameImageView.getTranslationY();
                mTranslateX = mSelectedFrameImageView.getTranslationX();
                mTranslateY += 8;
                mSelectedFrameImageView.setTrasnlateXY(mTranslateX, mTranslateY);
            } else if (model.getId() == 14) {
                mSelectedFrameImageView.fillImage();
            }
        }
    }

    private void blurImageFragment() {

        Constants.blurImagePath = null;
        Constants.mBlurBitmap = null;

        isBlurViewOpen = true;
        findViewById(R.id.fragmentContainer).setVisibility(View.VISIBLE);
        mainContainer.setEnabled(false);
        closePopupWindow();
        Bundle b = new Bundle();
        b.putString("PATH", mSelectedTemplateItem.getPhotoItemList().get(mSelectedPostion).imagePath);
        blurImageFragment = new BlurImageFragment();
        blurImageFragment.setArguments(b);
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.add(R.id.fragmentContainer, blurImageFragment);
        transaction.addToBackStack("back");
        transaction.commit();

    }

    public void handleTextOptionClick(OptionModel model) {
        Log.d("102356", "handleOptionClick: text");
        if (mSelectedView != null) {
            if (model.getId() == 1) {

                for (TextModel viewModel : mTextViewList) {

                    if (viewModel.getTextView().equals(mSelectedView)) {
                        mTextViewList.remove(viewModel);
                        textContainerLayout.removeView(mSelectedView);
                        mSelectedView = null;
                        break;
                    }
                }
                closePopupWindow();

            } else {
                closePopupWindow();
                addText(Constants.stickerText);
            }
        }
    }


    private void openCropView() {

        /*findViewById(R.id.fragmentContainer).setVisibility(View.VISIBLE);
        Constants.croppedImagePath = null;
        Constants.mCropBitmap = null;

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        cropViewFragment = CropViewFragment.newInstance(String.valueOf(getImageContentUri(this, new File(mSelectedTemplateItem.getPhotoItemList().get(mSelectedPostion).imagePath))));
        transaction.add(R.id.fragmentContainer, cropViewFragment);
        transaction.addToBackStack("back");
        transaction.commit();*/

        startCrop(mSelectedTemplateItem.getPhotoItemList().get(mSelectedPostion).imagePath);

        //closePopupWindow();
    }

    private void startCrop(String path) {
        try {
            String destinationFileName = SAMPLE_CROPPED_IMAGE_NAME;

            UCrop uCrop = UCrop.of(getImageContentUri(this, new File(path)), Uri.fromFile(new File(getCacheDir(), destinationFileName)));
            uCrop = advancedConfig(uCrop);

            uCrop.start(BaseTemplateDetailActivity.this);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void deleteRecursive(File fileOrDirectory) {
        try {
            if (fileOrDirectory != null && fileOrDirectory.isDirectory())
                for (File child : Objects.requireNonNull(fileOrDirectory.listFiles()))
                    deleteRecursive(child);
            assert fileOrDirectory != null;
            fileOrDirectory.delete();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private UCrop advancedConfig(@NonNull UCrop uCrop) {
        UCrop.Options options = new UCrop.Options();

        options.setFreeStyleCropEnabled(true);

        return uCrop.withOptions(options);
    }


    public static Uri getImageContentUri(Context context, File imageFile) {
        String filePath = imageFile.getAbsolutePath();
        Cursor cursor = context.getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Images.Media._ID},
                MediaStore.Images.Media.DATA + "=? ",
                new String[]{filePath}, null);
        if (cursor != null && cursor.moveToFirst()) {
            int id = cursor.getInt(cursor.getColumnIndex(MediaStore.MediaColumns._ID));
            cursor.close();
            return Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "" + id);
        } else {
            if (imageFile.exists()) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DATA, filePath);
                return context.getContentResolver().insert(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            } else {
                return null;
            }
        }
    }


    private void chooseImageFromGallery() {
        /*Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(galleryIntent, Constants.PICK_IMAGE_CODE);*/

        Intent intent = new Intent(BaseTemplateDetailActivity.this, GalleryActivity.class);
        intent.putExtra("type", "collage");
        intent.putExtra("single", true);
        startActivity(intent);
    }

  /*  private void chooseImageForAdd() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(galleryIntent, Constant.PICK_IMAGE_ADD);
    }*/

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        switch (requestCode) {
            case Constants.PICK_IMAGE_CODE:
                if (resultCode == RESULT_OK) {
                    if (Imagetype == 1) {
                        Constants.isAddImage = false;
                        try {
                            Bitmap bitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(data.getData()));
                            mSelectedFrameImageView.setImage(bitmap);
                            mSelectedFrameImageView.invalidate();
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }

                        String imagePath = getRealPathFromURI(data.getData());

                        if (mSelectedPhotoPaths.size() > 0) {
                            mSelectedPhotoPaths.remove(mSelectedPostion);
                            mSelectedPhotoPaths.add(mSelectedPostion, imagePath);

                            for (int idx = 0; idx < mTemplateItemList.size(); idx++) {
                                TemplateItem item = mTemplateItemList.get(idx);
                                for (int i = 0; i < item.getPhotoItemList().size(); i++) {
                                    PhotoItem photoItem = item.getPhotoItemList().get(i);
                                    photoItem.imagePath = mSelectedPhotoPaths.get(i);
                                }
                            }
                        }
                    } else {
                        mSelectedColor = -1;
                        mSelectedBG = data.getData();
                        Glide.with(BaseTemplateDetailActivity.this).load(data.getData()).into(new CustomTarget<Drawable>() {
                            @Override
                            public void onResourceReady(@NonNull Drawable resource, @Nullable Transition<? super Drawable> transition) {
                                mFramePhotoLayout.setBackground(resource);

                            }

                            @Override
                            public void onLoadCleared(@Nullable Drawable placeholder) {

                            }
                        });
                    }
                }
                break;
            case Constants.PICK_IMAGE_ADD:
               /* if (resultCode == RESULT_OK){

                    String path=getRealPathFromURI(data.getData());

                    mSelectedPhotoPaths.add(path);
                    for (int idx = 0; idx < mTemplateItemList.size(); idx++) {
                        TemplateItem item = mTemplateItemList.get(idx);
                        for (int i = 0; i < item.getPhotoItemList().size(); i++) {
                            PhotoItem photoItem = item.getPhotoItemList().get(i);
                            photoItem.imagePath = mSelectedPhotoPaths.get(i);
                        }
                    }
                }*/
                break;
            case UCrop.REQUEST_CROP:
                if (resultCode == RESULT_OK) {
                    Log.d(TAG, "onActivityResult: " + data.getData());

                    handleCropResult(data);
                }
                break;
            case 4055:
                selectItem(null, null, null);
            default:
                super.onActivityResult(requestCode, resultCode, data);
                selectItem(null, null, null);
        }
    }

    private void handleCropResult(@NonNull Intent result) {
        final Uri resultUri = UCrop.getOutput(result);
        if (resultUri != null && !resultUri.equals("")) {
            String copyPath = Environment.getExternalStorageDirectory().getPath() + File.separator + getString(R.string.app_name) + File.separator + ".tmp" + File.separator + "IM_" + System.currentTimeMillis() + ".png";

            try {

                try {
                    if (!new File(copyPath).getParentFile().exists()) {
                        new File(copyPath).getParentFile().mkdir();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

                try {
                    if (!new File(copyPath).exists()) {
                        new File(copyPath).createNewFile();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
                FileUtils.copyFile(resultUri.getPath(), copyPath);
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (!new File(copyPath).exists()) {
                return;
            }
            Log.d(TAG, "handleCropResult: " + resultUri);
            Constants.croppedImagePath = copyPath;

            Glide.with(this).load(copyPath).into(new CustomTarget<Drawable>() {
                @Override
                public void onResourceReady(@NonNull Drawable resource, @Nullable Transition<? super Drawable> transition) {
                    BitmapDrawable bitmapDrawable = (BitmapDrawable) resource;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            mSelectedFrameImageView.setImage(bitmapDrawable.getBitmap());
                            mSelectedTemplateItem.getPhotoItemList().get(mSelectedPostion).imagePath = Constants.croppedImagePath;
                            mSelectedFrameImageView.invalidate();
                        }
                    });

                    String imagePath = Constants.croppedImagePath;

                    File f = new File(imagePath);
                    if (f.exists() && mSelectedPhotoPaths.size() > 0) {
//                    mSelectedFrameImageView.setImagePath(Constant.croppedImagePath);

                        mSelectedPhotoPaths.remove(mSelectedPostion);
                        mSelectedPhotoPaths.add(mSelectedPostion, imagePath);

                        for (int idx = 0; idx < mTemplateItemList.size(); idx++) {
                            TemplateItem item = mTemplateItemList.get(idx);
                            for (int i = 0; i < item.getPhotoItemList().size(); i++) {
                                PhotoItem photoItem = item.getPhotoItemList().get(i);
                                photoItem.imagePath = mSelectedPhotoPaths.get(i);
                            }
                        }
                    }
                }

                @Override
                public void onLoadCleared(@Nullable Drawable placeholder) {

                }
            });


            //ResultActivity.startWithUri(SelectCropActivity.this, resultUri, UCrop.getInput(result), width, height);
        } else {
            Toast.makeText(BaseTemplateDetailActivity.this, "Error for crop image", LENGTH_SHORT).show();
        }
    }


    public String getRealPathFromURI(Uri contentUri) {
        String[] proj = {MediaStore.Audio.Media.DATA};
        Cursor cursor = managedQuery(contentUri, proj, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }

    public Bitmap rotateBitmap(Bitmap source, float angle) {
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true);
    }

  /*  public Bitmap zoomIn(Bitmap source, float scale) {
        Matrix matrix = new Matrix();
        matrix.postScale(scale, scale);
       *//* Bitmap bitmap=Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true);
        mSelectedFrameImageView.setImage(bitmap);
        mSelectedFrameImageView.invalidate();
        if(bitmap.getHeight()>bitmap.getWidth())
        {
            redundantXSpace = bitmap.getWidth() - (mScale * bitmap.getWidth());
            redundantXSpace /= 2;
        }
        else
        {
            redundantYSpace = bitmap.getHeight() - (mScale * bitmap.getHeight()) ;
            redundantYSpace /= 2;
        }
        Log.d(TAG, "zoomIn: out"+redundantXSpace+"   "+redundantYSpace);
        matrix.postTranslate(redundantXSpace , redundantYSpace );*//*
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true);
    }

    public Bitmap zoomOut(Bitmap source, float scale) {
        Matrix matrix = new Matrix();
        matrix.postScale(scale, scale);
       *//* Bitmap bitmap=Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true);
        mSelectedFrameImageView.setImage(bitmap);
        mSelectedFrameImageView.invalidate();
        if(bitmap.getHeight()>bitmap.getWidth())
        {
            redundantXSpace = bitmap.getWidth() - (mScale * bitmap.getWidth());
            redundantXSpace /= 2;
            redundantYSpace=redundantXSpace;
        }
        else
        {
            redundantYSpace = bitmap.getHeight() - (mScale * bitmap.getHeight()) ;
            redundantYSpace /= 2;
            redundantXSpace=redundantYSpace;
        }
        Log.d(TAG, "zoomIn: out"+redundantXSpace+"   "+redundantYSpace);
        matrix.postTranslate(redundantXSpace , redundantYSpace );*//*
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true);
    }*/

    private void flipImage(int direction) {

        Bitmap bitmap = mSelectedFrameImageView.getmImage();
        switch (direction) {
            case HORIZONTAL:
                Matrix matrix = new Matrix();
                matrix.preScale(1.0f, -1.0f);
                Bitmap horizontal = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
                mSelectedFrameImageView.setImage(horizontal);
                mSelectedFrameImageView.invalidate();
                break;
            case VERTICAL:
                Matrix matrix1 = new Matrix();
                matrix1.preScale(-1.0f, 1.0f);
                Bitmap vertical = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix1, true);
                mSelectedFrameImageView.setImage(vertical);
                mSelectedFrameImageView.invalidate();
                break;
        }

    }

    public int getScreenWidth() {

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int width = displayMetrics.widthPixels;
        return width;
    }

    public void loadFrameImages(boolean isFrameImage) {


        ArrayList<TemplateItem> mAllTemplateItemList = new ArrayList<>();

        mAllTemplateItemList.addAll(FrameImageUtils.loadFrameImages(this));


        Log.d(TAG, "loadFrameImages: " + mAllTemplateItemList.size());

        mTemplateItemList = new ArrayList<>();
        mTemplateItemListTemp = new ArrayList<>();
        mTemplateItemListMoreTemp = new ArrayList<>();
        if (mSelectedImageSize > 0) {
            for (TemplateItem item : mAllTemplateItemList) {
                Log.d(TAG, "loadFrameImages: " + item.getPhotoItemList().size() + "  " + item.getPhotoItemList().get(0).imagePath);
                if (item.getPhotoItemList().size() == mSelectedImageSize) {
                    mTemplateItemList.add(item);
                    Log.d(TAG, "EOFGKDOFPKDF: " + item.getTitle());

                }
            }
        } else {
            mTemplateItemList.addAll(mAllTemplateItemList);
        }

        mSelectedTemplateItem = mTemplateItemList.get(0);
        Log.d(TAG, "loadFrameImages: " + mSelectedTemplateItem.getPhotoItemList().get(0).imagePath + "  " + mSelectedTemplateItem);

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        int idx = mTemplateItemList.indexOf(mSelectedTemplateItem);
        if (idx < 0) idx = 0;
        Log.d("123654", "onSaveInstanceState: " + mSelectedTemplateItem);
        outState.putInt("mSelectedTemplateItemIndex", idx);
        //saved all image path of template item
        ArrayList<String> imagePaths = new ArrayList<>();
        for (PhotoItem item : mSelectedTemplateItem.getPhotoItemList()) {
            if (item.imagePath == null) item.imagePath = "";
            imagePaths.add(item.imagePath);
            Log.d("123654", "onSaveInstanceState: " + item.imagePath);
        }
        outState.putStringArrayList("photoItemImagePaths", imagePaths);
        // outState.putInt("mImageInTemplateCount", mImageInTemplateCount);
        outState.putBoolean("mIsFrameImage", mIsFrameImage);
    }


    @Override
    public void onBackgroundDoubleClick() {

    }

    @Override
    public void onPreviewTemplateClick(TemplateItem item) {
        closePopupWindow();
        Log.d(TAG, "onPreviewTemplateClick: ");
        if (item != mSelectedTemplateItem) {
            mSelectedTemplateItem.setSelected(false);
            for (int idx = 0; idx < mSelectedTemplateItem.getPhotoItemList().size(); idx++) {
                PhotoItem photoItem = mSelectedTemplateItem.getPhotoItemList().get(idx);
                if (photoItem.imagePath != null && photoItem.imagePath.length() > 0) {
                    if (idx < mSelectedPhotoPaths.size()) {
                        mSelectedPhotoPaths.add(idx, photoItem.imagePath);
                        Log.d(TAG, "onPreviewTemplateClick: if" + photoItem.imagePath);

                    } else {
                        mSelectedPhotoPaths.add(photoItem.imagePath);
                        Log.d(TAG, "onPreviewTemplateClick: else" + photoItem.imagePath);

                    }
                }
            }

            final int size = Math.min(mSelectedPhotoPaths.size(), item.getPhotoItemList().size());
            for (int idx = 0; idx < size; idx++) {
                PhotoItem photoItem = item.getPhotoItemList().get(idx);
                if (photoItem.imagePath == null || photoItem.imagePath.length() < 1) {
                    photoItem.imagePath = mSelectedPhotoPaths.get(idx);
                }
            }

            mSelectedTemplateItem = item;
            mSelectedTemplateItem.setSelected(true);
            mTemplateAdapter.notifyDataSetChanged();
            buildLayout(item, false);
        }

    }


    private void asyncSaveAndShare() {
        @SuppressLint("StaticFieldLeak") AsyncTask<Void, Void, File> task = new AsyncTask<Void, Void, File>() {
            Dialog dialog;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                mStickerView.setHandleStickerNull();
                dialog = ProgressDialog.show(BaseTemplateDetailActivity.this, getString(R.string.app_name), getString(R.string.creating));
            }

            @Override
            protected File doInBackground(Void... params) {
                try {
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    System.gc();

                    Bitmap image = createOutputImage();


                    //Constants.mSavedBitmap = image;
                    /*String fileName = DateTimeUtils.getCurrentDateTime().replaceAll(":", "-").concat(".png");
                    File collageFolder = new File(ImageUtils.OUTPUT_COLLAGE_FOLDER);
                    if (!collageFolder.exists()) {
                        collageFolder.mkdirs();
                    }*/
                    File filepath = Environment.getExternalStorageDirectory();
                    File dir = new File(filepath.getAbsolutePath() + "/" + getString(R.string.app_name));

                    if (!dir.exists()) {
                        dir.mkdirs();
                    }

                    String FileName = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + "_collage.jpeg";
                    File photoFile = new File(dir, FileName);
                    if (!photoFile.exists()) {
                        photoFile.createNewFile();
                    }
                    if (image == null) {
                        return null;
                    }
                    image.compress(Bitmap.CompressFormat.PNG, 100, new FileOutputStream(photoFile));

                    try {
                        isSave = true;
                        PhotoUtils.addImageToGallery(photoFile.getAbsolutePath(), BaseTemplateDetailActivity.this);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return photoFile;
                } catch (Exception ex) {
                    ex.printStackTrace();
                    errMsg = ex.toString();
                }
                Log.d(TAG, "doInBackground: " + errMsg);
                return null;
            }

            @Override
            protected void onPostExecute(File f) {
                super.onPostExecute(f);
                try {
                    dialog.dismiss();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }


                // perform your action
                file = f;

                Log.d(TAG, "onPostExecute: " + ActivityLifeCycleHelper.isApplicationInForeground() + " = " + isSave);
                if (ActivityLifeCycleHelper.isApplicationInForeground()) {
                    openViewImage();
                }

            }
        };
        task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
    }

    @Override
    public void onLoad() {
        isInterstitialAdLoaded = true;
    }

    @Override
    public void onFailed() {
        isInterstitialAdLoaded = false;
        //interstitial = InterstitialAdHelper.getInstance().load(BaseTemplateDetailActivity.this, this);
    }

    @Override
    public void onClosed() {
        isInterstitialAdLoaded = false;
        interstitial = InterstitialAdHelper.getInstance().load(BaseTemplateDetailActivity.this, this);

        // perform your action
        startActivity(new Intent(BaseTemplateDetailActivity.this, ViewImageActivity.class));
    }

    public float calculateScaleRatio(int imageWidth, int imageHeight) {
        float ratioWidth = ((float) imageWidth) / getPhotoViewWidth();
        float ratioHeight = ((float) imageHeight) / getPhotoViewHeight();
        return Math.max(ratioWidth, ratioHeight);
    }

    public int[] calculateThumbnailSize(int imageWidth, int imageHeight) {
        int[] size = new int[2];
        float ratioWidth = ((float) imageWidth) / getPhotoViewWidth();
        float ratioHeight = ((float) imageHeight) / getPhotoViewHeight();
        float ratio = Math.max(ratioWidth, ratioHeight);
        if (ratio == ratioWidth) {
            size[0] = getPhotoViewWidth();
            size[1] = (int) (imageHeight / ratio);
        } else {
            size[0] = (int) (imageWidth / ratio);
            size[1] = getPhotoViewHeight();
        }

        return size;
    }

    private int getPhotoViewWidth() {
        return mContainerLayout.getWidth();
    }

    private int getPhotoViewHeight() {
        return mContainerLayout.getHeight();
    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    public void resultStickers(Uri[] uri) {

    }

    @Override
    public void onTouchDown(View view) {
        if (view instanceof TextView) {
            mSelectedView = view;

            /*if (mPopupWindow.isShowing())
                mPopupWindow.dismiss();*/

            //prepareTextOptions();

            if (adepter != null)
                adepter.notifyDataSetChanged();

            mPopupWindow.setWidth(ConstraintLayout.LayoutParams.MATCH_PARENT);
            mPopupWindow.setHeight(ConstraintLayout.LayoutParams.WRAP_CONTENT);

            if (!mPopupWindow.isShowing()) {
                mPopupWindow.showAtLocation(mContainerLayout, Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM, 0, /*(int) ((findViewById(R.id.bottomLayout).getHeight() * 2.0f))*/0);
                //imgBtnClose.setVisibility(View.VISIBLE);
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (isFragmentLoaded) {
            removeFragment();
        } else {
            if (isBlurViewOpen) {
                Log.d(TAG, "onClick: blur" + Constants.mBlurBitmap);

                isBlurViewOpen = false;
                if (Constants.mBlurBitmap != null) {
                    mSelectedFrameImageView.setImage(Constants.mBlurBitmap);
                    mSelectedFrameImageView.invalidate();
                    String imagePath = Constants.blurImagePath;
                    File f = new File(imagePath);
                    if (f.exists() && mSelectedPhotoPaths.size() > 0) {
//                    mSelectedFrameImageView.setImagePath(Constant.croppedImagePath);

                        mSelectedPhotoPaths.remove(mSelectedPostion);
                        mSelectedPhotoPaths.add(mSelectedPostion, imagePath);

                        for (int idx = 0; idx < mTemplateItemList.size(); idx++) {
                            TemplateItem item = mTemplateItemList.get(idx);
                            for (int i = 0; i < item.getPhotoItemList().size(); i++) {
                                PhotoItem photoItem = item.getPhotoItemList().get(i);
                                photoItem.imagePath = mSelectedPhotoPaths.get(i);
                            }
                        }
                    }
                }
            } else {
                super.onBackPressed();
            }
        }
    }


    private void onKeyboardVisibilityChanged(boolean opened, int bottom) {
        // Log.d(TAG, "onKeyboardVisibilityChanged: "+ opened);

        if (mSticker != null) {

            if (opened) {
                Log.d(TAG, "onKeyboardVisibilityChanged:  " + mSticker.getMappedBound().bottom + " = " + bottom + " = " + (bottom - (mRootLayout.getBottom() - mStickerView.getBottom())));
                int bottomPoint = bottom - (mRootLayout.getBottom() - mStickerView.getBottom());
                if (mSticker.getMappedBound().bottom > bottomPoint) {
                    //originalBottomPoint = mSelectedText.getMappedBound().bottom;
                    originalBottomPoint = (int) mSticker.getMappedBound().bottom - (bottomPoint - 20);
                    mStickerView.moveUp(0, -originalBottomPoint);
                }
            } else {
                if (originalBottomPoint != 0) {
                    mStickerView.moveUp(0, originalBottomPoint);
                    originalBottomPoint = 0;
                }
            }
        }
    }


    @Override
    public void onKeyboardHeightChanged(int height, int orientation) {
        View view = findViewById(R.id.keyboard);
        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) view.getLayoutParams();
        params.height = height;
        view.setLayoutParams(params);
        if (height != 0)
            onKeyboardVisibilityChanged(true, view.getTop());
        else
            onKeyboardVisibilityChanged(false, view.getTop());
    }


    @Override
    public void onPause() {
        super.onPause();
        if (keyboardHeightProvider != null) {
            keyboardHeightProvider.setKeyboardHeightObserver(null);
        }

        if (mDeleteAlertDialog != null && mDeleteAlertDialog.isShowing()) {
            mDeleteAlertDialog.dismiss();
        }
    }

    @Override
    protected void onDestroy() {
        if (keyboardHeightProvider != null)
            keyboardHeightProvider.close();

        deleteRecursive(new File(Environment.getExternalStorageDirectory().getPath() + File.separator + getString(R.string.app_name) + File.separator + ".tmp"));
        super.onDestroy();

    }
}

