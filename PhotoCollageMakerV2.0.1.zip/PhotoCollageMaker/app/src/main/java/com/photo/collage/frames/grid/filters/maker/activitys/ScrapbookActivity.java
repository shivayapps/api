package com.photo.collage.frames.grid.filters.maker.activitys;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.Layout;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.background.eraser.remover.photo.layers.stickerview.Sticker;
import com.background.eraser.remover.photo.layers.stickerview.StickerView;
import com.background.eraser.remover.photo.layers.stickerview.TextSticker;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.transition.Transition;
import com.google.android.gms.ads.InterstitialAd;
import com.jcmore2.collage.CardView;
import com.jcmore2.collage.CollageView;
import com.jcmore2.collage.MultiTouchListener;
import com.photo.collage.frames.grid.filters.maker.comman.Constants;
import com.photo.collage.frames.grid.filters.maker.R;
import com.photo.collage.frames.grid.filters.maker.adepters.BackgroundAdepter;
import com.photo.collage.frames.grid.filters.maker.adepters.ColorAdepter;
import com.photo.collage.frames.grid.filters.maker.adepters.FontAdepter;
import com.photo.collage.frames.grid.filters.maker.adepters.ImageOptionAdepter;
import com.photo.collage.frames.grid.filters.maker.adepters.RatioAdepter;
import com.photo.collage.frames.grid.filters.maker.ads.InterstitialAdHelper;
import com.photo.collage.frames.grid.filters.maker.fragments.AddTextFragment;
import com.photo.collage.frames.grid.filters.maker.fragments.BottomDialogFragment;
import com.photo.collage.frames.grid.filters.maker.fragments.TextEditorDialogFragment;
import com.photo.collage.frames.grid.filters.maker.interfaces.KeyboardHeightObserver;
import com.photo.collage.frames.grid.filters.maker.model.OptionModel;
import com.photo.collage.frames.grid.filters.maker.model.PhotoModel;
import com.photo.collage.frames.grid.filters.maker.model.RatioModel;
import com.photo.collage.frames.grid.filters.maker.model.TextModel;
import com.photo.collage.frames.grid.filters.maker.models.CollageViewModel;
import com.photo.collage.frames.grid.filters.maker.moreframes.sqlite_database.AdsPrefs;
import com.photo.collage.frames.grid.filters.maker.utils.FontProvider;
import com.photo.collage.frames.grid.filters.maker.utils.KeyboardHeightProvider;
import com.yalantis.ucrop.UCrop;
import com.yalantis.ucrop.util.FileUtils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import dauroi.photoeditor.utils.PhotoUtils;

import static android.widget.Toast.LENGTH_SHORT;

public class ScrapbookActivity extends AppCompatActivity implements MultiTouchListener.OnTouchEvent,
        BackgroundAdepter.OnBackgroundImageClick, TextEditorDialogFragment.OnTextLayerCallback, KeyboardHeightObserver, InterstitialAdHelper.onInterstitialAdListener {

    //constant
    private static final String TAG = "ScrapbookActivity";
    private static final int HORIZONTAL = 1;
    private static final int VERTICAL = 2;
    private static final String SAMPLE_CROPPED_IMAGE_NAME = "SampleCrop";


    //object
    private Context mContext;
    private ArrayList<CollageViewModel> mCollageViews;
    private ArrayList<PhotoModel> mPhotoList;
    private ArrayList<RatioModel> mRatioList;
    private ArrayList<TextModel> mTextViewList;
    private BottomDialogFragment bottomSheetDialogFragment;
    private List<Bitmap> listRes = new ArrayList<>();
    private Map<String, Bitmap> mMapList = new HashMap<>();
    private PopupWindow mPopupWindow;
    private ArrayList<OptionModel> mOptionList;
    private View mSelectedView = null;
    private ImageOptionAdepter adepter;
    private ArrayList<Integer> mColors;
    private KeyboardHeightProvider keyboardHeightProvider;
    private ColorAdepter colorAdepter;
    private FontAdepter fontAdepter;


    //Widgets
    private ConstraintLayout mCollageContainer, mBottomMenu, mSubBottomBar, mTextBottomLayout, mRootLayout;
    private ImageButton imgBtnDone, imgBtnClose;
    private ImageView imgBtnBack;
    private CollageView collage;
    private RecyclerView mRatioRecyclerView, mBackgroundRecyclerView, mColorRecyclerView;
    private ImageView imgBackground;
    private TextView txtStyle, txtColor;
    private ProgressBar mProgressBar;
    private View mToolbar1;
    private View mToolbarText;
    private View mViewSelectedMenuBG;
    private View mViewSelectedMenuRatio;
    private View mViewSelectedMenuText;

    //var
    private String selectedRatio = "";
    private float mScale;
    private float mTranslateX, mTranslateY;
    private boolean isCropViewOpen, isRatioMenuOpen;
    private int mSelectedColor;
    private TextSticker mSticker;
    private StickerView mStickerView;
    private TextEditorDialogFragment fragment;
    private int imageType = 0;
    private int originalBottomPoint;
    private boolean isMultiClicked = true;


    //ads
    private boolean isInterstitialAdLoaded = false;
    private InterstitialAd interstitial;

    //Text code
    private AddTextFragment addTextFragment;

    public Boolean isFragmentLoaded = false;

    private ImageView mImgBtnBackText;
    private ImageView mBtnDoneText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scrapbook);

        addTextFragment = new AddTextFragment();

        mContext = ScrapbookActivity.this;

        deleteRecursive(new File(Environment.getExternalStorageDirectory().getPath() + File.separator + getString(R.string.app_name) + File.separator + ".tmp"));


        if (ContextCompat.checkSelfPermission(mContext, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            startActivity(new Intent(mContext, MainActivity.class));
            finish();
        }


        //Load ads
        if(!AdsPrefs.getBoolean(this, AdsPrefs.IS_SUBSCRIBED)){
            interstitial = InterstitialAdHelper.getInstance().load(mContext, this);
        }


        initView();

        initListener();

        initAction();

        imgBtnDone.setEnabled(false);
        imgBtnDone.setAlpha(0.5f);
    }

    @Override
    protected void onStart() {
        super.onStart();


        Log.d(TAG, "onStart: ");
        if (keyboardHeightProvider != null)
            keyboardHeightProvider.setKeyboardHeightObserver(this);

        if (Constants.photoModel != null) {
            if (imageType == 0) {
                try {
                    Bitmap bitmap = BitmapFactory.decodeFile(Constants.photoModel.getImagePath());

                    bitmap = getScaleBitmap(mCollageContainer, new BitmapDrawable(getResources(), bitmap));

                    ((CardView) mSelectedView).setImageBitmap(bitmap);
                    ((CardView) mSelectedView).setTag(Constants.photoModel.getImagePath());

                    CollageViewModel model = null;
                    int index = 0;
                    for (CollageViewModel viewModel : mCollageViews) {
                        if (viewModel.getView().equals(mSelectedView)) {
                            model = viewModel;
                            index = mCollageViews.indexOf(model);
                            break;
                        }
                    }

                    listRes.remove(index);
                    listRes.add(index, bitmap);

                    if (model != null) {
                        CardView cardView = model.getView();
                        cardView.getLayoutParams().width = (int) (bitmap.getWidth() * model.getChangeScale());
                        cardView.getLayoutParams().height = (int) (bitmap.getHeight() * model.getChangeScale());
                        cardView.requestLayout();
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            } else {
                Glide.with(ScrapbookActivity.this).load(Constants.photoModel.getImagePath()).override(1000).into(new CustomTarget<Drawable>() {
                    @Override
                    public void onResourceReady(@NonNull Drawable resource, @Nullable Transition<? super Drawable> transition) {
                        Log.d(TAG, "onResourceReady: ");
                        collage.setBackground(resource);
                        if (mPopupWindow != null && mPopupWindow.isShowing()) {
                            closePopupWindow();
                        }
                        for (int i = 0; i < collage.getListCards().size(); i++) {
                            CardView cardView = collage.getListCards().get(i);
                            cardView.setBackground(null);
                        }

                        mSelectedView = null;
                        mSubBottomBar.setVisibility(View.GONE);
                        imgBtnClose.setVisibility(View.GONE);
                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {
                        Log.d(TAG, "onLoadCleared: ");
                    }
                });
            }

            Constants.photoModel = null;
        }
    }

    private void initView() {
        mToolbar1 = findViewById(R.id.appBarLayout);
        mToolbarText = findViewById(R.id.toolbarLayout_text);
        mCollageContainer = findViewById(R.id.collageContainer);
        mRootLayout = findViewById(R.id.rootLayout);

        mBottomMenu = findViewById(R.id.cl_bottomMenu);
        mSubBottomBar = findViewById(R.id.subBottomMenu);
        mTextBottomLayout = findViewById(R.id.textLayout);

        imgBtnDone = findViewById(R.id.imgBtnDone);
        imgBtnBack = findViewById(R.id.imgBtnBack);
        imgBtnClose = findViewById(R.id.imgBtnSmallClose);


        imgBackground = findViewById(R.id.imgbg);

        mProgressBar = findViewById(R.id.progressBar2);

        collage = findViewById(R.id.collage);

        mRatioRecyclerView = findViewById(R.id.recyclerViewRatio);
        mBackgroundRecyclerView = findViewById(R.id.recyclerViewBackground);
        mColorRecyclerView = findViewById(R.id.colorRv);

        txtColor = findViewById(R.id.txtColor);
        txtStyle = findViewById(R.id.txtStyle);

        mStickerView = findViewById(R.id.stickerView);

        mImgBtnBackText = findViewById(R.id.imgBtnBackText);
        mBtnDoneText = findViewById(R.id.btnDoneText);

        mViewSelectedMenuBG = findViewById(R.id.viewSelectedMenuBG);
        mViewSelectedMenuRatio = findViewById(R.id.viewSelectedMenuRatio);
        mViewSelectedMenuText = findViewById(R.id.viewSelectedMenuText);
    }

    private void initListener() {
        mCollageContainer.setOnTouchListener((view, motionEvent) -> {

            if (mPopupWindow.isShowing())
                closePopupWindow();

            for (int i = 0; i < collage.getListCards().size(); i++) {
                CardView cardView = collage.getListCards().get(i);
                cardView.setBackground(null);
            }

            mSelectedView = null;

            return true;
        });

        imgBtnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mPopupWindow != null && mPopupWindow.isShowing()) {
                    closePopupWindow();
                }
                for (int i = 0; i < collage.getListCards().size(); i++) {
                    CardView cardView = collage.getListCards().get(i);
                    cardView.setBackground(null);
                }

                mSelectedView = null;
                mSubBottomBar.setVisibility(View.GONE);
                imgBtnClose.setVisibility(View.GONE);
            }
        });

        imgBtnDone.setOnClickListener(view -> {


            /*new AlertDialog.Builder(this)
                    .setMessage("Do you want to save?")
                    .setPositiveButton("OK", (dialog, which) -> {
                        mStickerView.setHandleStickerNull();
                        if (mPopupWindow.isShowing())
                            closePopupWindow();

                        for (int i = 0; i < collage.getListCards().size(); i++) {
                            CardView cardView = collage.getListCards().get(i);
                            cardView.setBackground(null);
                        }

                        closePopupWindow();
                        mSubBottomBar.setVisibility(View.GONE);
                        getSaveImageFilePath();

                    })
                    .setNegativeButton("Cancel", (dialog, which) -> {
                        dialog.dismiss();
                    })
                    .show();*/
            imgBtnDone.setEnabled(false);
            for (int i = 0; i < mBottomMenu.getChildCount(); i++) {
                View v = mBottomMenu.getChildAt(i);
                (((ConstraintLayout) v).getChildAt(0)).setAlpha(0.5f);
                (((ConstraintLayout) v).getChildAt(1)).setAlpha(0.5f);
                stopBottomMenuAnimation((((ConstraintLayout) v).getChildAt(1)), (((ConstraintLayout) v).getChildAt(0)), (((ConstraintLayout) v).getChildAt(2)));
            }

            Dialog saveDialog = new Dialog(this);
            saveDialog.setContentView(R.layout.dialog_save);
            saveDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            saveDialog.getWindow().setLayout(ConstraintLayout.LayoutParams.MATCH_PARENT, ConstraintLayout.LayoutParams.WRAP_CONTENT);
            TextView btnCancel = saveDialog.findViewById(R.id.btnCancel);
            TextView btnSave = saveDialog.findViewById(R.id.btnSave);
            btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    saveDialog.dismiss();
                }
            });

            btnSave.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    saveDialog.dismiss();
                    mStickerView.setHandleStickerNull();
                    if (mPopupWindow.isShowing())
                        closePopupWindow();
                    if(adepter!=null){
                        adepter.mSelectedItem = -1;
                        adepter.mSelectedLatItem = 10;
                        adepter.notifyDataSetChanged();
                    }

                    for (int i = 0; i < collage.getListCards().size(); i++) {
                        CardView cardView = collage.getListCards().get(i);
                        cardView.setBackground(null);
                    }

                    closePopupWindow();
                    mSubBottomBar.setVisibility(View.GONE);
                    getSaveImageFilePath();
                }
            });
            saveDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(DialogInterface dialog) {
                    imgBtnDone.setEnabled(true);
                }
            });
            if (!isFinishing()) {
                saveDialog.show();
            }

        });

       /* txtStyle.setOnClickListener(v -> {
            txtStyle.setBackgroundColor(Color.parseColor("#63A2D5"));
            txtColor.setBackgroundColor(ContextCompat.getColor(this, R.color.colorSubBottomBar));

            openFontMenu();
        });

        txtColor.setOnClickListener(v -> {
            txtColor.setBackgroundColor(Color.parseColor("#63A2D5"));
            txtStyle.setBackgroundColor(ContextCompat.getColor(this, R.color.colorSubBottomBar));

            openTextColorMenu();
        });*/

        imgBtnBack.setOnClickListener(v -> {
            onBackPressed();
        });
    }

    private void openFontMenu() {
        FontProvider provider = new FontProvider(getResources());
        fontAdepter = new FontAdepter(provider.getFontNames(), this, position -> {
            if (mSticker != null) {
                TextSticker sticker = (TextSticker) mSticker;
                sticker.setTypeface(Typeface.createFromAsset(getAssets(), Constants.textFontPath));
                sticker.setTypefacePath(Constants.textFontPath);
                mStickerView.invalidate();
            }
        }, "Aa");

        mColorRecyclerView.setAdapter(fontAdepter);
    }

    private void openTextColorMenu() {
        mColorRecyclerView.setVisibility(View.VISIBLE);
        mColorRecyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        mColorRecyclerView.setItemAnimator(new DefaultItemAnimator());
        ColorAdepter.setOnItemClickListener listener = new ColorAdepter.setOnItemClickListener() {
            @Override
            public void OnItemClicked(int color) {
                if (mSticker != null) {
                    TextSticker sticker = (TextSticker) mSticker;
                    sticker.setTextColor(color);
                    mStickerView.invalidate();
                }
            }
        };
        colorAdepter = new ColorAdepter(mColors, this, listener, false);
        mColorRecyclerView.setAdapter(colorAdepter);
    }

    private void openColorMenu() {
        mBackgroundRecyclerView.setVisibility(View.VISIBLE);
        mTextBottomLayout.setVisibility(View.INVISIBLE);
        mRatioRecyclerView.setVisibility(View.INVISIBLE);
        mBackgroundRecyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        mBackgroundRecyclerView.setItemAnimator(new DefaultItemAnimator());
        ColorAdepter.setOnItemClickListener listener = new ColorAdepter.setOnItemClickListener() {
            @Override
            public void OnItemClicked(int color) {

                if (color != -10) {/*
                    mSelectedBG = -1;
                    mFramePhotoLayout.setBackground(null);
                    mFramePhotoLayout.setBackgroundColor(color);*/
                    mSelectedColor = color;
                    collage.setBackgroundColor(color);

                } else {
                    imageType = 1;
                    chooseImageFromGallery();
                }
            }
        };

        ArrayList<Integer> mColor = new ArrayList<>(mColors);
        mColor.add(0, -10);
        ColorAdepter colorAdepter = new ColorAdepter(mColor, this, listener, true);
        mBackgroundRecyclerView.setAdapter(colorAdepter);
    }


    private int getScreenWidth() {

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int width = displayMetrics.widthPixels;
        return width;
    }

    private int getScreenHeight() {

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int height = displayMetrics.heightPixels;
        return height;
    }

    private void chooseImageFromGallery() {
        /*Intent galleryIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(galleryIntent, Constants.PICK_IMAGE_CODE);*/

        Intent intent = new Intent(ScrapbookActivity.this, GalleryActivity.class);
        intent.putExtra("type", "scrapbook");
        intent.putExtra("single", true);
        startActivity(intent);
    }

    private void changeAspectRatio() {
        if (mPhotoList.size() == 1) {
            for (CollageViewModel viewModel : mCollageViews) {
                // if (viewModel.getView().getScaleX() == 1 && viewModel.getChangeScale() == 0) {
                viewModel.setScale(.7f);
                if (viewModel.getView().getScaleX() != 1)
                    viewModel.setChangeScale(Math.abs(viewModel.getView().getScaleX()));
                // } else {
                  /*  if (viewModel.getChangeScale() != 0) {
                        if (viewModel.getView().getScaleX() != 1) {
                            viewModel.setChangeScale(Math.abs(viewModel.getView().getScaleX()));
                        }
                        viewModel.setScale(viewModel.getChangeScale());
                    } else {*/
                //    viewModel.setChangeScale(Math.max(Math.abs(viewModel.getView().getScaleX() - .7f),.25f));
                //  viewModel.setScale(Math.max(Math.abs(viewModel.getView().getScaleX() - .7f),.25f));
                //}
                //}
            }
            resizeOneImage();

        } else if (mPhotoList.size() == 2) {
            for (CollageViewModel viewModel : mCollageViews) {
                viewModel.setScale(.7f);
                if (viewModel.getView().getScaleX() != 1)
                    viewModel.setChangeScale(Math.abs(viewModel.getView().getScaleX()));
                /*else {
                    viewModel.setScale(Math.abs(viewModel.getView().getScaleX()));
                }*/
                viewModel.setScale(.7f);
            }
            resizeTwoImages();

        } else if (mPhotoList.size() == 3) {
            for (CollageViewModel viewModel : mCollageViews) {
                viewModel.setScale(.6f);
                if (viewModel.getView().getScaleX() != 1)
                    viewModel.setChangeScale(Math.abs(viewModel.getView().getScaleX()));
                /*if (viewModel.getView().getScaleX() == 1)
                else {
                    viewModel.setScale(Math.abs(viewModel.getView().getScaleX() ));
                }*/
            }
            resizeThreeImages(.6f, .6f);

        } else if (mPhotoList.size() == 4) {

            for (CollageViewModel viewModel : mCollageViews) {
                viewModel.setScale(.5f);
                if (viewModel.getView().getScaleX() != 1)
                    viewModel.setChangeScale(Math.abs(viewModel.getView().getScaleX()));
                /*if (viewModel.getView().getScaleX() == 1)
                else {
                    viewModel.setScale(Math.abs(viewModel.getView().getScaleX() - .5f));
                }*/
            }

            resizeFourImage(false);
        } else if (mPhotoList.size() == 5) {
            for (CollageViewModel viewModel : mCollageViews) {
                viewModel.setScale(.5f);
                if (viewModel.getView().getScaleX() != 1)
                    viewModel.setChangeScale(Math.abs(viewModel.getView().getScaleX()));
                /*if (viewModel.getView().getScaleX() == 1)
                else {
                    viewModel.setScale(Math.abs(viewModel.getView().getScaleX() - .5f));
                }*/
            }

            resizeFiveImage(.5f, .5f);
        } else if (mPhotoList.size() == 6) {
            for (CollageViewModel viewModel : mCollageViews) {
                viewModel.setScale(0.4f);
                if (viewModel.getView().getScaleX() != 1)
                    viewModel.setChangeScale(Math.abs(viewModel.getView().getScaleX()));
                /*if (viewModel.getView().getScaleX() == 1)
                else {
                    viewModel.setScale(Math.abs(viewModel.getView().getScaleX() - 0.4f));
                }*/
            }

            resizeSixImage(0.4f, 0.4f);
        } else if (mPhotoList.size() == 7) {
            for (CollageViewModel viewModel : mCollageViews) {
                viewModel.setScale(0.4f);
                if (viewModel.getView().getScaleX() != 1)
                    viewModel.setChangeScale(Math.abs(viewModel.getView().getScaleX()));
               /* if (viewModel.getView().getScaleX() == 1)
                else {
                    viewModel.setScale(Math.abs(viewModel.getView().getScaleX() - .5f));
                }*/
            }
            mCollageViews.get(6).setScale(0.35f);

            resizeSevenImage();
        } else if (mPhotoList.size() == 8) {
            for (CollageViewModel viewModel : mCollageViews) {
                viewModel.setScale(.4f);
                if (viewModel.getView().getScaleX() != 1)
                    viewModel.setChangeScale(Math.abs(viewModel.getView().getScaleX()));
                /*if (viewModel.getView().getScaleX() == 1)
                else {
                    viewModel.setScale(Math.abs(viewModel.getView().getScaleX() - .4f));
                }*/
            }
            mCollageViews.get(6).setScale(0.35f);
            mCollageViews.get(7).setScale(0.35f);
            resizeEightImage(false);
        }


    }

    private void initAction() {

        disableEnableControls(false, mBottomMenu);

        //init color list and fill it
        mColors = new ArrayList<>();
        //mColors.add(0, -10);
        mColors.clear();
        String[] allColors = getResources().getStringArray(R.array.colors);
        for (String allColor : allColors)
            mColors.add(Color.parseColor(allColor));


        mPhotoList = new ArrayList<>();
        mCollageViews = new ArrayList<>();
        mTextViewList = new ArrayList<>();

        mPhotoList.addAll(Constants.mSelectedImageList);

        keyboardHeightProvider = new KeyboardHeightProvider(this);

        mRootLayout.post(new Runnable() {
            @Override
            public void run() {
                if (keyboardHeightProvider != null)
                    keyboardHeightProvider.start();
            }
        });

        for (int i = 0; i < mBottomMenu.getChildCount(); i++) {
            View v = mBottomMenu.getChildAt(i);
            (((ConstraintLayout) v).getChildAt(0)).setAlpha(0.5f);
            (((ConstraintLayout) v).getChildAt(1)).setAlpha(0.5f);
        }

        addImages();

        setupBottomBar();

        setupRatio();

        initPopupWindow();

        mStickerView.setLocked(false);
        mStickerView.setConstrained(true);

        mStickerView.setOnStickerOperationListener(new StickerView.OnStickerOperationListener() {
            @Override
            public void onStickerAdded(@NonNull Sticker sticker) {
                mSticker = (TextSticker) sticker;
                if (colorAdepter != null)
                    colorAdepter.setLastSelectedItem(mSticker.getColor());
                if (fontAdepter != null)
                    fontAdepter.setSelectedItem(mSticker.getTypefacePath());

            }

            @Override
            public void onStickerClicked(@NonNull Sticker sticker) {

                mSticker = (TextSticker) sticker;

                if (mPopupWindow.isShowing())
                    closePopupWindow();

                for (int i = 0; i < collage.getListCards().size(); i++) {
                    CardView cardView = collage.getListCards().get(i);
                    cardView.setBackground(null);
                }
                /*if (colorAdepter != null)
                    colorAdepter.setLastSelectedItem(mSticker.getColor());

                if (fontAdepter != null)
                    fontAdepter.setSelectedItem(mSticker.getTypefacePath());
                mSelectedView = null;

                mSubBottomBar.setVisibility(View.VISIBLE);
                mColorRecyclerView.setVisibility(View.VISIBLE);
                mRatioRecyclerView.setVisibility(View.INVISIBLE);
                mBackgroundRecyclerView.setVisibility(View.INVISIBLE);
                imgBtnClose.setVisibility(View.VISIBLE);*/
                //mTextBottomLayout.setVisibility(View.VISIBLE);
            }

            @Override
            public void onStickerDeleted(@NonNull Sticker sticker) {
                if (mStickerView.getStickers().size() == 0) {
                    mSubBottomBar.setVisibility(View.GONE);
                    imgBtnClose.setVisibility(View.GONE);
                }
                if (colorAdepter != null)
                    colorAdepter.setLastSelectedItem(-2);
            }

            @Override
            public void onStickerDragFinished(@NonNull Sticker sticker) {

            }

            @Override
            public void onStickerTouchedDown(@NonNull Sticker sticker) {
               /* mSticker = (TextSticker) sticker;

                if (mPopupWindow.isShowing())
                    closePopupWindow();

                for (int i = 0; i < collage.getListCards().size(); i++) {
                    CardView cardView = collage.getListCards().get(i);
                    cardView.setBackground(null);
                }


                if (colorAdepter != null)
                    colorAdepter.setLastSelectedItem(mSticker.getColor());

                if (fontAdepter != null)
                    fontAdepter.setSelectedItem(mSticker.getTypefacePath());

                mSelectedView = null;
                mTextBottomLayout.setVisibility(View.VISIBLE);
                mSubBottomBar.setVisibility(View.VISIBLE);
                mRatioRecyclerView.setVisibility(View.INVISIBLE);
                mBackgroundRecyclerView.setVisibility(View.INVISIBLE);
                imgBtnClose.setVisibility(View.VISIBLE);*/
            }

            @Override
            public void onStickerZoomFinished(@NonNull Sticker sticker) {

            }

            @Override
            public void onStickerFlipped(@NonNull Sticker sticker) {

            }

            @Override
            public void onStickerDoubleTapped(@NonNull Sticker sticker) {
                /*if (sticker instanceof TextSticker) {
                    mSticker = (TextSticker) sticker;
                    TextSticker sticker1 = (TextSticker) mSticker;
                    String text = "";
                    if (!sticker1.isFirst()) {
                        text = sticker1.getText();
                    }

                    fragment = TextEditorDialogFragment.getInstance(text);
                    fragment.show(getSupportFragmentManager(), TextEditorDialogFragment.class.getName());
                }*/
            }

            @Override
            public void onStickerViewTouch() {
               /* mSubBottomBar.setVisibility(View.GONE);
                imgBtnClose.setVisibility(View.GONE);*/
            }

            @Override
            public void onStickerEditClicked(@NonNull Sticker sticker) {
                if (isMultiClicked) {
                    isMultiClicked = false;

                    mSubBottomBar.setVisibility(View.INVISIBLE);
                    mBackgroundRecyclerView.setVisibility(View.INVISIBLE);
                    mRatioRecyclerView.setVisibility(View.INVISIBLE);
                    mTextBottomLayout.setVisibility(View.INVISIBLE);

                    for (int i = 0; i < mBottomMenu.getChildCount(); i++) {
                        View v = mBottomMenu.getChildAt(i);
                        (((ConstraintLayout) v).getChildAt(0)).setAlpha(0.5f);
                        (((ConstraintLayout) v).getChildAt(1)).setAlpha(0.5f);
                    }

                    (((ConstraintLayout) findViewById(R.id.cl_text)).getChildAt(0)).setAlpha(1f);
                    (((ConstraintLayout) findViewById(R.id.cl_text)).getChildAt(1)).setAlpha(1f);
                    onclickText(1);

                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            isMultiClicked = true;
                        }
                    }, 400);
                }
            }
        });

        openColorMenu();

        openTextColorMenu();

        mRatioRecyclerView.setVisibility(View.INVISIBLE);

        imgBtnDone.setEnabled(false);
    }

    private void setupRatio() {
        //init RecyclerView
        mRatioRecyclerView.setLayoutManager(new LinearLayoutManager(mContext, RecyclerView.HORIZONTAL, false));
        mRatioRecyclerView.setItemAnimator(new DefaultItemAnimator());

        //get ratios
        getRatio();

        //init Adepter
        RatioAdepter ratioAdepter = new RatioAdepter(mContext, mRatioList, ratio -> {
            showRatioLayout(ratio);

        });

        mRatioRecyclerView.setAdapter(ratioAdepter);
    }

    private void initPopupWindow() {
        View view = LayoutInflater.from(mContext).inflate(R.layout.layout_popup_window, null);

        int width = getScreenWidth() - 50;
        mPopupWindow = new PopupWindow(
                view,
                width,
                ConstraintLayout.LayoutParams.WRAP_CONTENT
        );

        if (Build.VERSION.SDK_INT >= 21) {
            mPopupWindow.setElevation(5.0f);
        }

        RecyclerView recyclerView = view.findViewById(R.id.recyclerViewImageOption);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        mOptionList = new ArrayList<>();
        prepareImageOptions();

        adepter = new ImageOptionAdepter(mContext, mOptionList, model -> {
            if (mOptionList.size() > 2)
                handleOptionClick(model);
            else
                handleTextOptionClick(model);

        });
        recyclerView.setAdapter(adepter);
    }

    private void handleTextOptionClick(OptionModel model) {
        if (mSelectedView != null) {
            if (model.getId() == 1) {

                for (TextModel viewModel : mTextViewList) {

                    if (viewModel.getTextView().equals(mSelectedView)) {
                        mTextViewList.remove(viewModel);
                        collage.removeView(mSelectedView);
                        mSelectedView = null;
                        break;
                    }
                }

                //mPhotoList.remove(index);

                closePopupWindow();

            } else {
                addText(Constants.stickerText);
            }
        }
    }

    private AlertDialog mDeleteAlertDialog;

    private void handleOptionClick(OptionModel model) {

        if (mSelectedView != null) {
            if (model.getId() == 1) {

                int count = 0;

                for (CollageViewModel model1 : mCollageViews) {
                    if (model1.getView().getVisibility() == View.VISIBLE) {
                        count++;
                    }
                }

                int index = 0;

                if (count > 1) {
                    mDeleteAlertDialog = new AlertDialog.Builder(this)
                            .setMessage("Are you sure want to delete?")
                            .setPositiveButton("OK", (dialog, which) -> {
                                for (CollageViewModel viewModel : mCollageViews) {
                                    if (viewModel.getView().equals(mSelectedView)) {
                                    /*index = mCollageViews.indexOf(viewModel);
                                    mCollageViews.remove(viewModel);
                                    mPhotoList.remove(index);*/
                                        viewModel.getView().setVisibility(View.INVISIBLE);
                                        viewModel.getView().setEnabled(false);
                                        break;
                                    }
                                }

                                closePopupWindow();
                            })
                            .setNegativeButton("Cancel", (dialog, which) -> {
                                dialog.dismiss();
                            })
                            .show();
                } else {
                    Toast.makeText(mContext, "You need atleast one image", Toast.LENGTH_SHORT).show();
                }


                //mPhotoList.remove(index);


            } else if (model.getId() == 2) {
                imageType = 0;
                chooseImageFromGallery();

            } else if (model.getId() == 3) {

                openCropView();

            } else if (model.getId() == 4) {

                //mSelectedView.animate().rotationBy(-90).setDuration(50).start();

            } else if (model.getId() == 5) {

                mSelectedView.setPivotX(mSelectedView.getWidth() / 2);
                mSelectedView.setPivotY(mSelectedView.getHeight() / 2);

                mSelectedView.animate().rotationBy(90).setDuration(10).start();

            } else if (model.getId() == 6) {

                flipImage(HORIZONTAL);

            } else if (model.getId() == 7) {

                flipImage(VERTICAL);

            } else if (model.getId() == 8) {

                mScale = mSelectedView.getScaleX();

                mScale += 0.15f;

                if (mScale >= 1.5f) {
                    mScale = 1.5f;
                }

                mSelectedView.setScaleX(mScale);
                mSelectedView.setScaleY(mScale);

            } else if (model.getId() == 9) {

                mScale = mSelectedView.getScaleX();

                mScale -= 0.15f;

                if (mScale <= 0.25f) {
                    mScale = 0.25f;
                }

                mSelectedView.setScaleX(mScale);
                mSelectedView.setScaleY(mScale);

            } else if (model.getId() == 10) {

                mTranslateX = mSelectedView.getTranslationX();

                mTranslateX -= 8;

                mSelectedView.setTranslationX(mTranslateX);

            } else if (model.getId() == 11) {

                mTranslateX = mSelectedView.getTranslationX();

                mTranslateX += 8;

                mSelectedView.setTranslationX(mTranslateX);

            } else if (model.getId() == 12) {

                mTranslateY = mSelectedView.getTranslationY();

                mTranslateY -= 8;

                mSelectedView.setTranslationY(mTranslateY);

            } else if (model.getId() == 13) {

                mTranslateY = mSelectedView.getTranslationY();

                mTranslateY += 8;

                mSelectedView.setTranslationY(mTranslateY);
            }
        }
    }

    private void openCropView() {

        int index = 0;
        for (CollageViewModel viewModel : mCollageViews) {
            if (viewModel.getView().equals(mSelectedView)) {
                index = mCollageViews.indexOf(viewModel);
                break;
            }
        }


        /*findViewById(R.id.fragmentContainer).setVisibility(View.VISIBLE);
        //mPhotoList.get(index).getImagePath()
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        cropViewFragment = CropViewFragment.newInstance(String.valueOf(getImageContentUri(mContext, new File(mSelectedView.getTag().toString()))));
        transaction.add(R.id.fragmentContainer, cropViewFragment);
        transaction.addToBackStack("back");
        transaction.commit();*/

        //isCropViewOpen =

        startCrop(mSelectedView.getTag().toString());

        /*if (mPopupWindow.isShowing()) {
            closePopupWindow();
        }*/
    }

    public static Uri getImageContentUri(Context context, File imageFile) {
        String filePath = imageFile.getAbsolutePath();
        Cursor cursor = context.getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Images.Media._ID},
                MediaStore.Images.Media.DATA + "=? ",
                new String[]{filePath}, null);
        if (cursor != null && cursor.moveToFirst()) {
            int id = cursor.getInt(cursor.getColumnIndex(MediaStore.MediaColumns._ID));
            cursor.close();
            return Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "" + id);
        } else {
            if (imageFile.exists()) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DATA, filePath);
                return context.getContentResolver().insert(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            } else {
                return null;
            }
        }
    }

    private void prepareImageOptions() {
        mOptionList.clear();
        /*mOptionList.add(new OptionModel(1, R.drawable.ic_delete_black_24dp, "DELETE"));
        mOptionList.add(new OptionModel(2, R.drawable.ic_swap, "SWAP"));
        mOptionList.add(new OptionModel(3, R.drawable.ic_crop, "CROP"));
        mOptionList.add(new OptionModel(4, R.drawable.ic_rotate_left_black_24dp, "LEFT"));
        mOptionList.add(new OptionModel(5, R.drawable.ic_rotate_right_black_24dp, "RIGHT"));
        mOptionList.add(new OptionModel(6, R.drawable.ic_flip_horizontal, "HORIZONTAL"));
        mOptionList.add(new OptionModel(7, R.drawable.ic_flip_horizontal, "VERTICAL"));
        mOptionList.add(new OptionModel(8, R.drawable.ic_zoom_in, "ZOOM IN"));
        mOptionList.add(new OptionModel(9, R.drawable.ic_zoom_out, "ZOOM OUT"));
        mOptionList.add(new OptionModel(10, R.drawable.ic_arrow_left, "LEFT"));
        mOptionList.add(new OptionModel(11, R.drawable.ic_arrow_right, "RIGHT"));
        mOptionList.add(new OptionModel(12, R.drawable.ic_arrow_up, "UP"));
        mOptionList.add(new OptionModel(13, R.drawable.ic_arrow_dow, "DOWN"));*/


        mOptionList.add(new OptionModel(3, R.drawable.ic_sub_menu_crop, "Crop"));
        mOptionList.add(new OptionModel(2, R.drawable.ic_sub_menu_swap, "Swap"));
        mOptionList.add(new OptionModel(6, R.drawable.ic_sub_menu_horizontal, "Horizontal"));
        mOptionList.add(new OptionModel(7, R.drawable.ic_vertical, "Vertical"));
        mOptionList.add(new OptionModel(5, R.drawable.ic_horizontal, "Rotate"));
        //mOptionList.add(new OptionModel(5, R.drawable.ic_rotate_right_black_24dp, "RIGHT"));
        mOptionList.add(new OptionModel(8, R.drawable.ic_sub_menu_zoom, "Zoom In"));
        mOptionList.add(new OptionModel(9, R.drawable.ic_sub_menu_zoomout, "Zoom Out"));
        mOptionList.add(new OptionModel(10, R.drawable.ic_left, "Left"));
        mOptionList.add(new OptionModel(11, R.drawable.ic_right, "Right"));
        mOptionList.add(new OptionModel(12, R.drawable.ic_up, "Up"));
        mOptionList.add(new OptionModel(13, R.drawable.ic_down, "Down"));
        mOptionList.add(new OptionModel(1, R.drawable.ic_delete_new, "Delete"));
    }

    private void prepareTextOptions() {
        mOptionList.clear();
        mOptionList.add(new OptionModel(1, R.drawable.ic_delete_black_24dp, "DELETE"));
        mOptionList.add(new OptionModel(2, R.drawable.ic_edit, "EDIT"));

    }

    private void flipImage(int direction) {

        BitmapDrawable drawable = (BitmapDrawable) ((CardView) mSelectedView).getDrawable();

        Bitmap bitmap = drawable.getBitmap();

        switch (direction) {
            case HORIZONTAL:
                Matrix matrix = new Matrix();
                matrix.preScale(1.0f, -1.0f);
                Bitmap horizontal = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
                ((CardView) mSelectedView).setImageBitmap(horizontal);
                break;
            case VERTICAL:
                Matrix matrix1 = new Matrix();
                matrix1.preScale(-1.0f, 1.0f);
                Bitmap vertical = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix1, true);
                ((CardView) mSelectedView).setImageBitmap(vertical);
                break;
        }
    }

    private void getRatio() {
        mRatioList = new ArrayList<>();
        mRatioList.add(new RatioModel("Full", R.drawable.ic_ratio_frame_1));
        mRatioList.add(new RatioModel("1 : 1", R.drawable.ic_ratio_frame_1));
        mRatioList.add(new RatioModel("2 : 1", R.drawable.ic_ratio_frame_3));
        mRatioList.add(new RatioModel("3 : 2", R.drawable.ic_ratio_frame_4));
        mRatioList.add(new RatioModel("2 : 3", R.drawable.ic_ratio_frame_1));
        mRatioList.add(new RatioModel("4 : 3", R.drawable.ic_ratio_frame_6));
        mRatioList.add(new RatioModel("3 : 4", R.drawable.ic_ratio_frame_1));
        mRatioList.add(new RatioModel("16 : 9", R.drawable.ic_ratio_frame_8));
        mRatioList.add(new RatioModel("4 : 5", R.drawable.ic_ratio_frame_1));
        mRatioList.add(new RatioModel("5 : 4", R.drawable.ic_ratio_frame_10));
        mRatioList.add(new RatioModel("5 : 7", R.drawable.ic_ratio_frame_1));
        mRatioList.add(new RatioModel("9 : 16", R.drawable.ic_ratio_frame_1));
    }

    private void showRatioLayout(String ratio) {
        if (!ratio.toLowerCase().equals("full")) {
            String[] ratioArray = ratio.split(" ");

            int width = getScreenWidth();
            int height = mCollageContainer.getHeight();

            int outWidth = width;
            int outHeight = height;

            int ratioX = Integer.parseInt(ratioArray[0]);
            int ratioY = Integer.parseInt(ratioArray[ratioArray.length - 1]);

            Log.d(TAG, "showRatioLayout: " + ratioX + " : " + ratioY);

            float collageRatio = (float) ratioY / (float) ratioX;

            int h, w;
            if (ratioX > ratioY) {
                int temp = mCollageContainer.getWidth() / ratioX;
                h = temp * ratioY;
                w = mCollageContainer.getWidth();
            } else if (ratioX < ratioY) {
                int temp = mCollageContainer.getHeight() / ratioY;
                w = temp * ratioX;
                h = mCollageContainer.getHeight();
            } else {
                h = w = mCollageContainer.getWidth();

            }

            // outWidth = Math.round(height * collageRatio);

            outHeight = Math.round(width * collageRatio);
            //outHeight = Math

            Log.d(TAG, "showRatioLayout: " + collageRatio + " = " + width + " + " + outHeight);


            collage.getLayoutParams().width = w;
            collage.getLayoutParams().height = h;
            collage.requestLayout();

            mStickerView.getLayoutParams().width = w;
            mStickerView.getLayoutParams().height = h;
            mStickerView.requestLayout();

        } else {
            collage.getLayoutParams().width = mCollageContainer.getWidth();
            collage.getLayoutParams().height = mCollageContainer.getHeight();
            collage.requestLayout();

            mStickerView.getLayoutParams().width = mCollageContainer.getWidth();
            mStickerView.getLayoutParams().height = mCollageContainer.getHeight();
            mStickerView.requestLayout();
        }

        if (!selectedRatio.equals(ratio)) {


            collage.post(() -> {

                fullScreenRatioImageView();

                changeAspectRatio();

                textInCenter();
            });
        }

        selectedRatio = ratio;
    }

    /*private void showRatioLayout(String ratio) {
        if (!ratio.toLowerCase().equals("full")) {
            String[] ratioArray = ratio.split(" ");

            int width = getScreenWidth();
            int height = mCollageContainer.getHeight();

            int outWidth = width;
            int outHeight = height;

            int ratioX = Integer.parseInt(ratioArray[0]);
            int ratioY = Integer.parseInt(ratioArray[ratioArray.length - 1]);

            Log.d(TAG, "showRatioLayout: " + ratioX + " : " + ratioY);

            float collageRatio = (float) ratioY / (float) ratioX;


            // outWidth = Math.round(height * collageRatio);

            outHeight = Math.round(width * collageRatio);
            //outHeight = Math

            Log.d(TAG, "showRatioLayout: " + collageRatio + " = " + width + " + " + outHeight);

            collage.getLayoutParams().width = outWidth;
            collage.getLayoutParams().height = outHeight;
            collage.requestLayout();
        } else {
            collage.getLayoutParams().width = mCollageContainer.getWidth();
            collage.getLayoutParams().height = mCollageContainer.getHeight();
            collage.requestLayout();
        }

        if (!selectedRatio.equals(ratio)) {


            collage.post(() -> {

                fullScreenRatioImageView();

                changeAspectRatio();

                textInCenter();
            });
        }

        selectedRatio = ratio;
    }*/

    private void textInCenter() {

        /*ArrayList<Sticker> stickers = new ArrayList<>(mStickerView.getStickers());
        mStickerView.invalidate();
        for (Sticker sticker : stickers) {
            mStickerView.addSticker(sticker);
            mStickerView.centerAllSticker();
        }*/
        mStickerView.centerAllSticker();

        for (TextModel model : mTextViewList) {

            model.getTextView().setTranslationX(0);
            model.getTextView().setTranslationY(0);
        }

    }

    private void fullScreenRatioImageView() {

        for (int i = 0; i < mCollageViews.size(); i++) {

            CardView cardView = mCollageViews.get(i).getView();

            Point point = getWidthAndHeight(collage, listRes.get(i));

            cardView.getLayoutParams().width = (int) (point.x);
            cardView.getLayoutParams().height = (int) (point.y);
            cardView.requestLayout();

        }
    }

    private void setupBottomBar() {

        //Handle Click Event of Bottom Menu Item

        for (int i = 0; i < mBottomMenu.getChildCount(); i++) {
            View view = mBottomMenu.getChildAt(i);
            view.setOnClickListener(view1 -> {
                if (isMultiClicked) {
                    bottomMenuItemClick(view1);
                }
            });
        }
    }

    private void bottomMenuItemClick(View view) {
        for (int i = 0; i < mBottomMenu.getChildCount(); i++) {
            View v = mBottomMenu.getChildAt(i);
            (((ConstraintLayout) v).getChildAt(0)).setAlpha(0.5f);
            (((ConstraintLayout) v).getChildAt(1)).setAlpha(0.5f);

            stopBottomMenuAnimation((((ConstraintLayout) v).getChildAt(1)), (((ConstraintLayout) v).getChildAt(0)), (((ConstraintLayout) v).getChildAt(2)));

        }

        (((ConstraintLayout) view).getChildAt(0)).setAlpha(1f);
        (((ConstraintLayout) view).getChildAt(1)).setAlpha(1f);

        if (view.getTag().equals("background")) {
            //showBottomSheetDialog();
            startBottomMenuAnimation(findViewById(R.id.textView2), findViewById(R.id.imageView), mViewSelectedMenuBG);

            if (isFragmentLoaded) {
                removeFragment();
            }
            openColorMenu();
            mSubBottomBar.setVisibility(View.VISIBLE);
            mBackgroundRecyclerView.setVisibility(View.VISIBLE);
            mRatioRecyclerView.setVisibility(View.INVISIBLE);
            mTextBottomLayout.setVisibility(View.INVISIBLE);

            //imgBtnClose.setVisibility(View.VISIBLE);

        } else if (view.getTag().equals("ratio")) {
            startBottomMenuAnimation(findViewById(R.id.textView3), findViewById(R.id.imageView1), mViewSelectedMenuRatio);
            if (isFragmentLoaded) {
                removeFragment();
            }
            isRatioMenuOpen = true;
            if (mPopupWindow.isShowing())
                closePopupWindow();
            mSubBottomBar.setVisibility(View.VISIBLE);
            mBackgroundRecyclerView.setVisibility(View.INVISIBLE);
            mRatioRecyclerView.setVisibility(View.VISIBLE);
            mTextBottomLayout.setVisibility(View.INVISIBLE);

            //imgBtnClose.setVisibility(View.VISIBLE);

        } else {
            startBottomMenuAnimation(findViewById(R.id.textView4), findViewById(R.id.imageView2), mViewSelectedMenuText);
            if (mPopupWindow.isShowing()) {
                closePopupWindow();
            }
            //mSubBottomBar.setVisibility(View.VISIBLE);
            mBackgroundRecyclerView.setVisibility(View.INVISIBLE);
            mRatioRecyclerView.setVisibility(View.INVISIBLE);
            mSubBottomBar.setVisibility(View.INVISIBLE);
            //mTextBottomLayout.setVisibility(View.VISIBLE);

            if (!isFragmentLoaded) {
                initTextSticker();
            }
        }
    }

    //Bottom menu animation
    private void startBottomMenuAnimation(View textView, View btnAdd, View view) {
        view.animate().alpha(1f).setDuration(200);
        view.setVisibility(View.VISIBLE);
        btnAdd.animate().alpha(1f).translationY(-8f).scaleX(1.2f).scaleY(1.2f).setDuration(350);
        textView.animate().alpha(1f).translationY(-6f).setDuration(350);
    }

    private void stopBottomMenuAnimation(View textView, View btnAdd, View view) {
        view.animate().alpha(0.5f).setDuration(200);
        view.setVisibility(View.GONE);
        btnAdd.animate().alpha(0.5f).translationY(0f).scaleX(1f).scaleY(1f).setDuration(350);
        textView.animate().alpha(0.5f).translationY(0f).setDuration(350);
    }

    //Text Sticker
    private void initTextSticker() {
        if (!isFragmentLoaded) {
            onclickText(0);
        }
    }

    private void onclickText(int fromWhere) {
        mToolbarText.setVisibility(View.VISIBLE);
        mToolbar1.setVisibility(View.INVISIBLE);

        //findViewById(R.id.btnText).setEnabled(false);
        String defaultText = "";
        String defaultTypeface = "fonts/1.ttf";
        int defaultTextColor = Color.BLACK;
        try {
            if (fromWhere == 1) {
                defaultText = ((TextSticker) mSticker).getText();
                defaultTypeface = ((TextSticker) mSticker).getTypefacePath();
                defaultTextColor = ((TextSticker) mSticker).getColor();
                Constants.textStickerColor = defaultTextColor;
            } else {
                defaultText = "";
                defaultTypeface = "fonts/1.ttf";
                defaultTextColor = Color.BLACK;
                Constants.textStickerColor = defaultTextColor;
            }
        } catch (Exception e) {
            defaultText = "";
            defaultTypeface = "fonts/1.ttf";
            defaultTextColor = Color.BLACK;
            Constants.textStickerColor = defaultTextColor;
        }

        addTextFragment =
                new AddTextFragment().Companion.newInstance(defaultText, defaultTypeface, defaultTextColor);
        FragmentTransaction ft =
                getSupportFragmentManager().beginTransaction();
        ft.add(R.id.frmTextFragment, addTextFragment);
        ft.commit();
        isFragmentLoaded = true;

        mBtnDoneText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Constants.stickerText.length() != 0) {
                    removeFragment();
                    for (int i = 0; i < mBottomMenu.getChildCount(); i++) {
                        View v1 = mBottomMenu.getChildAt(i);
                        (((ConstraintLayout) v1).getChildAt(0)).setAlpha(0.5f);
                        (((ConstraintLayout) v1).getChildAt(1)).setAlpha(0.5f);
                        stopBottomMenuAnimation((((ConstraintLayout) v1).getChildAt(1)), (((ConstraintLayout) v1).getChildAt(0)), (((ConstraintLayout) v1).getChildAt(2)));
                    }
                    if (fromWhere == 1) {
                        replaceText(Constants.stickerText);
                    } else {
                        addText(Constants.stickerText);
                    }
                } else {
                    Toast.makeText(mContext, "Add some text", LENGTH_SHORT).show();
                }
            }
        });
        mImgBtnBackText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    public void removeFragment() {
        try {
            //findViewById(R.id.btnText).setEnabled(true);
            getSupportFragmentManager().beginTransaction()
                    .remove(addTextFragment)
                    .commitAllowingStateLoss();
            //imgColor!!.visibility = View.VISIBLE
            //mLinearUndoRedo!!.visibility = View.VISIBLE
            //mLblHeaderTextBrush!!.visibility = View.GONE
            //mImgBack!!.setImageResource(R.drawable.ic_back)
            mToolbarText.setVisibility(View.INVISIBLE);
            mToolbar1.setVisibility(View.VISIBLE);
            isFragmentLoaded = false;
            hideKeyboard(this);
            //mImgDone!!.alpha = 0.5f
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void hideKeyboard(Activity activity) {
        InputMethodManager imm =
                (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = activity.getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }


    @Override
    public void textChanged(@NonNull String text) {
        TextSticker sticker = (TextSticker) mSticker;
        if (sticker.isFirst()) {
            sticker.setFirst(false);
        }

        text = text.trim();

        if (text.equals("")) {
            text = "Hello";
            sticker.setFirst(true);
        }


        sticker.setText(text);
        sticker.resizeText();
        mStickerView.replace(sticker);
        mStickerView.invalidate();
    }

    private void addText(String myText) {

        /*EditTextDialog textDialog = null;

        TextModel textModel = null;

        for (TextModel view : mTextViewList) {
            if (mSelectedView != null && mSelectedView.equals(view.getTextView())) {
                textModel = view;
                break;
            }
        }

        if (mSelectedView != null && mSelectedView instanceof TextView) {
            textDialog = new EditTextDialog(textModel);
        } else {
            textDialog = new EditTextDialog(null);
        }

        textDialog.setListener(model -> {

            boolean isExist = false;
            for (TextModel viewmodel : mTextViewList) {
                if (model.getTextView().equals(viewmodel.getTextView())) {
                    isExist = true;
                    break;
                }
            }
            if (!isExist) {
                TextView textView = model.getTextView();
                MultiTouchListener multiTouchListener = new MultiTouchListener();
                multiTouchListener.setEvent(this);

                textView.setOnTouchListener(multiTouchListener);
                textView.setId(Integer.parseInt(collage.getChildCount() + "101"));
                collage.addView(textView);
                mTextViewList.add(model);

                ConstraintSet set = new ConstraintSet();

                set.clone(collage);

                set.connect(textView.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);
                set.connect(textView.getId(), ConstraintSet.LEFT, collage.getId(), ConstraintSet.LEFT, 0);
                set.connect(textView.getId(), ConstraintSet.RIGHT, collage.getId(), ConstraintSet.RIGHT, 0);
                set.connect(textView.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);

                set.applyTo(collage);
            }
        });

        textDialog.show(getSupportFragmentManager(), "EditTextDialog");*/
        //FontProvider provider = new FontProvider(getResources());
        FontProvider provider = new FontProvider(getResources());
        TextSticker sticker = new TextSticker(this);
        sticker.setText(myText);
        sticker.setTextColor(Constants.textStickerColor);
        sticker.setTextAlign(Layout.Alignment.ALIGN_CENTER);
        sticker.setTypeface(Typeface.createFromAsset(getAssets(), Constants.textFontPath));
        sticker.setTypefacePath(Constants.textFontPath);
        sticker.resizeText();
        sticker.setFirst(true);
        mSticker = sticker;
        mStickerView.addSticker(mSticker);
    }

    private void replaceText(String myText) {
        FontProvider provider = new FontProvider(getResources());
        TextSticker sticker = new TextSticker(this);

        if (sticker.isFirst()) {
            sticker.setFirst(false);
        }

        sticker.setText(myText);
        sticker.setTextColor(Constants.textStickerColor);
        sticker.setTypeface(Typeface.createFromAsset(getAssets(), Constants.textFontPath));
        sticker.setTypefacePath(Constants.textFontPath);
        sticker.resizeText();
        mSticker = sticker;
        mStickerView.replace(mSticker);
    }

    private void unSelectBottomMenuItem() {
        isRatioMenuOpen = false;
        mSubBottomBar.setVisibility(View.GONE);
        for (int i = 0; i < mBottomMenu.getChildCount(); i++) {
            View v = mBottomMenu.getChildAt(i);
            ((ImageView) ((ConstraintLayout) v).getChildAt(0)).setAlpha(0.5f);
            ((TextView) ((ConstraintLayout) v).getChildAt(1)).setAlpha(0.5f);
        }
    }

    private void showBottomSheetDialog() {
        bottomSheetDialogFragment = new BottomDialogFragment(this);
        bottomSheetDialogFragment.show(getSupportFragmentManager(), "background");
    }

    private void addImages() {
        collage.post(() -> {

            LoadImages();

        });
    }

    @SuppressLint("CheckResult")
    private void LoadImages() {


        Log.d(TAG, "LoadImages: 1 ");

        Handler handler = new Handler();

       /* handler.post(() -> {

        });*/

        handler.post(() -> {

            Log.d(TAG, "LoadImages: 2 ");
            final int[] count = {0};
            for (int i = 0; i < mPhotoList.size(); i++) {

                Log.d(TAG, "LoadImages: 3 " + mPhotoList.get(i).getImagePath());
                Glide.with(mContext).load(mPhotoList.get(i).getImagePath()).override(800).listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        Log.e(TAG, "onLoadFailed: " + e.toString());
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        Log.d(TAG, "onResourceReady: 1 ");
                        Bitmap bitmap = getScaleBitmap(mCollageContainer, resource);

                        mMapList.put(model.toString(), bitmap);

                        return false;
                    }
                }).into(new CustomTarget<Drawable>() {
                    @Override
                    public void onResourceReady(@NonNull Drawable resource, @Nullable Transition<? super Drawable> transition) {

                        Log.d(TAG, "onResourceReady: 2 ");
                        count[0]++;

                        //Log.d(TAG, "onResourceReady: " + count[0] + " _+ " + mPhotoList.size());

                        if (count[0] == mPhotoList.size()) {
                            // mBottomMenu.setEnabled(true);
                            disableEnableControls(true, mBottomMenu);
                            imgBtnDone.setEnabled(true);
                            imgBtnDone.setAlpha(1f);
                            runOnUiThread(() -> {
                                mProgressBar.setVisibility(View.GONE);

                                for (PhotoModel model1 : mPhotoList) {
                                    listRes.add(mMapList.get(model1.getImagePath()));
                                }

                                collage.createCollageBitmaps(listRes);

                                for (int i = 0; i < collage.getListCards().size(); i++) {
                                    CardView cardView = collage.getListCards().get(i);
                                    cardView.setBorder(getResources().getDimension(R.dimen._3sdp));
                                    cardView.setTag(mPhotoList.get(i).getImagePath());
                                    mCollageViews.add(new CollageViewModel(cardView));

                                }

                                Log.d(TAG, "onResourceReady: ");

                                switch (mCollageViews.size()) {
                                    case 1:
                                        for (CollageViewModel viewModel : mCollageViews) {
                                            viewModel.setScale(0.7f);
                                            viewModel.setChangeScale(viewModel.getScale());
                                        }
                                        resizeOneImage();
                                        break;
                                    case 2:
                                        for (CollageViewModel viewModel : mCollageViews) {
                                            viewModel.setScale(0.7f);
                                            viewModel.setChangeScale(viewModel.getScale());
                                        }
                                        resizeTwoImages();
                                        break;
                                    case 3:
                                        for (CollageViewModel viewModel : mCollageViews) {
                                            viewModel.setScale(0.6f);
                                            viewModel.setChangeScale(viewModel.getScale());
                                        }
                                        resizeThreeImages(0.6f, 0.6f);
                                        break;
                                    case 4:
                                        for (CollageViewModel viewModel : mCollageViews) {
                                            viewModel.setScale(0.5f);
                                            viewModel.setChangeScale(viewModel.getScale());
                                        }
                                        resizeFourImage(true);
                                        break;
                                    case 5:
                                        for (CollageViewModel viewModel : mCollageViews) {
                                            viewModel.setScale(0.5f);
                                            viewModel.setChangeScale(viewModel.getScale());
                                        }
                                        resizeFiveImage(0.5f, 0.5f);
                                        break;
                                    case 6:
                                        for (CollageViewModel viewModel : mCollageViews) {
                                            viewModel.setScale(0.4f);
                                            viewModel.setChangeScale(viewModel.getScale());
                                        }
                                        resizeSixImage(0.4f, 0.4f);
                                        break;

                                    case 7:
                                        for (CollageViewModel viewModel : mCollageViews) {
                                            viewModel.setScale(0.4f);
                                            viewModel.setChangeScale(viewModel.getScale());
                                        }
                                        mCollageViews.get(6).setScale(0.35f);
                                        resizeSevenImage();
                                        break;

                                    case 8:
                                        for (CollageViewModel viewModel : mCollageViews) {
                                            viewModel.setScale(0.4f);
                                            viewModel.setChangeScale(viewModel.getScale());

                                        }

                                        mCollageViews.get(6).setScale(0.35f);
                                        mCollageViews.get(7).setScale(0.35f);

                                        resizeEightImage(true);
                                        break;
                                }


                            });

                        }

                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {
                        Log.e(TAG, "onLoadFailed: place");
                    }
                });

            }
        });

    }

    private void disableEnableControls(boolean enable, ViewGroup vg) {
        for (int i = 0; i < vg.getChildCount(); i++) {
            View child = vg.getChildAt(i);
            child.setEnabled(enable);
            if (child instanceof ViewGroup) {
                disableEnableControls(enable, (ViewGroup) child);
            }
        }
    }

    private void resizeOneImage() {

        for (CollageViewModel model : mCollageViews) {
            model.getView().setTranslationX(0);
            model.getView().setTranslationY(0);
        }


        Log.d(TAG, "resizeOneImage: ");
        CardView collageView1 = mCollageViews.get(0).getView();
        ConstraintSet set = new ConstraintSet();

        set.clone(collage);

        set.connect(collageView1.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);
        set.connect(collageView1.getId(), ConstraintSet.LEFT, collage.getId(), ConstraintSet.LEFT, 0);
        set.connect(collageView1.getId(), ConstraintSet.RIGHT, collage.getId(), ConstraintSet.RIGHT, 0);
        set.connect(collageView1.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);

        set.applyTo(collage);

       /* Point point = getWidthAndHeight(collage,listRes.get(0));

        collageView1.getLayoutParams().width = point.x;
        collageView1.getLayoutParams().height = point.y;*/

        collageView1.setScaleX(mCollageViews.get(0).getScale());
        collageView1.setScaleY(mCollageViews.get(0).getScale());
        collageView1.setRotation(collageView1.getRotation() == 0 ? 350 : collageView1.getRotation());

        collageView1.post(() -> {

            int width = (int) (collageView1.getWidth() * collageView1.getScaleX());
            int height = (int) (collageView1.getHeight() * collageView1.getScaleY());
            collageView1.getLayoutParams().width = width;
            collageView1.getLayoutParams().height = height;
            collageView1.requestLayout();
            collageView1.setScaleX(1);
            collageView1.setScaleY(1);
        });

    }

    private void resizeTwoImages() {

        Log.d(TAG, "resizeTwoImages: ");

        for (CollageViewModel model : mCollageViews) {
            model.getView().setTranslationX(0);
            model.getView().setTranslationY(0);
        }

        CardView collageView1 = mCollageViews.get(0).getView();
        CardView collageView2 = mCollageViews.get(1).getView();

        ConstraintSet set = new ConstraintSet();


        set.clone(collage);


        Log.d(TAG, "resizeTwoImages: 1 " + collageView1.getTranslationX());
        Log.d(TAG, "resizeTwoImages: 2 " + collageView2.getTranslationY());


        set.connect(collageView1.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);
        set.connect(collageView1.getId(), ConstraintSet.START, collage.getId(), ConstraintSet.START, 0);


        set.connect(collageView2.getId(), ConstraintSet.END, collage.getId(), ConstraintSet.END, 0);
        set.connect(collageView2.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);
        set.applyTo(collage);


        collageView1.setScaleX(mCollageViews.get(0).getScale());
        collageView1.setScaleY(mCollageViews.get(0).getScale());
        collageView1.setRotation(collageView1.getRotation() == 0 ? 350 : collageView1.getRotation());

        collageView1.post(() -> {
            int width = (int) (collageView1.getWidth() * collageView1.getScaleX());
            int height = (int) (collageView1.getHeight() * collageView1.getScaleY());
            ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) collageView1.getLayoutParams();
            layoutParams.width = width;
            layoutParams.height = height;
            layoutParams.topMargin = 20;
            layoutParams.leftMargin = 70;
            collageView1.setLayoutParams(layoutParams);
            collageView1.setScaleX(1);
            collageView1.setScaleY(1);
        });


        collageView2.setScaleX(mCollageViews.get(1).getScale());
        collageView2.setScaleY(mCollageViews.get(1).getScale());
        collageView2.setRotation(collageView2.getRotation() == 0 ? 10 : collageView2.getRotation());

        collageView2.post(() -> {
            int width = (int) (collageView2.getWidth() * collageView2.getScaleX());
            int height = (int) (collageView2.getHeight() * collageView2.getScaleY());
            ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) collageView2.getLayoutParams();
            layoutParams.width = width;
            layoutParams.height = height;
            layoutParams.bottomMargin = 20;
            layoutParams.rightMargin = 70;
            collageView2.setLayoutParams(layoutParams);
            collageView2.setScaleX(1);
            collageView2.setScaleY(1);
        });


        Log.d(TAG, "resizeTwoImages: " + collageView1.getScaleX());
        Log.d(TAG, "resizeTwoImages: " + collageView2.getScaleX());


    }

    private void resizeThreeImages(float scaleX, float scaleY) {

        for (CollageViewModel model : mCollageViews) {
            model.getView().setTranslationX(0);
            model.getView().setTranslationY(0);
        }


        CardView collageView1 = mCollageViews.get(0).getView();
        CardView collageView2 = mCollageViews.get(1).getView();
        CardView collageView3 = mCollageViews.get(2).getView();

        ConstraintSet set = new ConstraintSet();


        set.clone(collage);


        set.connect(collageView1.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);
        set.connect(collageView1.getId(), ConstraintSet.START, collage.getId(), ConstraintSet.START, 0);


        set.connect(collageView2.getId(), ConstraintSet.END, collage.getId(), ConstraintSet.END, 0);
        set.connect(collageView2.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);

        set.connect(collageView3.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);
        set.connect(collageView3.getId(), ConstraintSet.START, collage.getId(), ConstraintSet.START, 0);
        set.connect(collageView3.getId(), ConstraintSet.END, collage.getId(), ConstraintSet.END, 0);
        set.connect(collageView3.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);

        set.applyTo(collage);

        scaleX = mCollageViews.get(0).getScale();
        scaleY = mCollageViews.get(0).getScale();

        collageView1.setScaleX(scaleX);
        collageView1.setScaleY(scaleY);
        //collageView1.setRotation(350);

        collageView1.post(() -> {

            int width = (int) (collageView1.getWidth() * collageView1.getScaleX());
            int height = (int) (collageView1.getHeight() * collageView1.getScaleY());
            collageView1.getLayoutParams().width = width;
            collageView1.getLayoutParams().height = height;
            collageView1.requestLayout();
            collageView1.setScaleX(1);
            collageView1.setScaleY(1);
        });


        scaleX = mCollageViews.get(1).getScale();
        scaleY = mCollageViews.get(1).getScale();

        collageView2.setScaleX(scaleX);
        collageView2.setScaleY(scaleY);
        //collageView2.setRotation(10);

        collageView2.post(() -> {
            int width = (int) (collageView2.getWidth() * collageView2.getScaleX());
            int height = (int) (collageView2.getHeight() * collageView2.getScaleY());
            collageView2.getLayoutParams().width = width;
            collageView2.getLayoutParams().height = height;
            collageView2.requestLayout();
            collageView2.setScaleX(1);
            collageView2.setScaleY(1);
        });


        scaleX = mCollageViews.get(2).getScale();
        scaleY = mCollageViews.get(2).getScale();

        collageView3.setScaleX(scaleX);
        collageView3.setScaleY(scaleY);
        // collageView3.setRotation(10);

        collageView3.post(() -> {
            int width = (int) (collageView3.getWidth() * collageView3.getScaleX());
            int height = (int) (collageView3.getHeight() * collageView3.getScaleY());
            collageView3.getLayoutParams().width = width;
            collageView3.getLayoutParams().height = height;
            collageView3.requestLayout();
            collageView3.setScaleX(1);
            collageView3.setScaleY(1);
        });

    }

    private void resizeFourImage(boolean isTranslate) {

        for (CollageViewModel model : mCollageViews) {
            model.getView().setTranslationX(0);
            model.getView().setTranslationY(0);
        }


        CardView collageView1 = mCollageViews.get(0).getView();
        CardView collageView2 = mCollageViews.get(1).getView();
        CardView collageView3 = mCollageViews.get(2).getView();
        CardView collageView4 = mCollageViews.get(3).getView();
        ConstraintSet set = new ConstraintSet();


        set.clone(collage);


        set.connect(collageView1.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);
        set.connect(collageView1.getId(), ConstraintSet.START, collage.getId(), ConstraintSet.START, 0);

        set.connect(collageView2.getId(), ConstraintSet.END, collage.getId(), ConstraintSet.END, 0);
        set.connect(collageView2.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);


        set.connect(collageView3.getId(), ConstraintSet.START, collage.getId(), ConstraintSet.START, 0);
        set.connect(collageView3.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);

        set.connect(collageView4.getId(), ConstraintSet.END, collage.getId(), ConstraintSet.END, 0);
        set.connect(collageView4.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);

        set.applyTo(collage);


        for (int i = 0; i < mCollageViews.size(); i++) {

            CardView view = mCollageViews.get(i).getView();

            float x = mCollageViews.get(i).getScale();
            float y = mCollageViews.get(i).getScale();

            view.setScaleX(x);
            view.setScaleY(y);


            if (i == 0) {
                view.setRotation(10);
            } else if (i == 1) {
                view.setRotation(350);
            } else if (i == 2) {
                view.setRotation(350);
            } else {
                view.setRotation(10);
            }

            int finalI = i;
            view.post(() -> {
                int width = (int) (view.getWidth() * view.getScaleX());
                int height = (int) (view.getHeight() * view.getScaleY());

                ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) view.getLayoutParams();
                layoutParams.width = width;
                layoutParams.height = height;
                if (finalI == 0) {
                    layoutParams.topMargin = 20;
                    layoutParams.leftMargin = 50;
                } else if (finalI == 1) {
                    layoutParams.rightMargin = 50;
                } else if (finalI == 2) {
                    layoutParams.bottomMargin = 20;
                    layoutParams.leftMargin = 50;
                } else if (finalI == 3) {
                    layoutParams.bottomMargin = 20;
                    layoutParams.rightMargin = 50;
                }
                view.setLayoutParams(layoutParams);
                view.setScaleX(1);
                view.setScaleY(1);
                if (isTranslate) {

                }

            });

        }


    }

    private void resizeFiveImage(float x, float y) {

        for (CollageViewModel model : mCollageViews) {
            model.getView().setTranslationX(0);
            model.getView().setTranslationY(0);
        }

        CardView collageView1 = mCollageViews.get(0).getView();
        CardView collageView2 = mCollageViews.get(1).getView();
        CardView collageView3 = mCollageViews.get(2).getView();
        CardView collageView4 = mCollageViews.get(3).getView();
        CardView collageView5 = mCollageViews.get(4).getView();
        ConstraintSet set = new ConstraintSet();


        set.clone(collage);


        set.connect(collageView1.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);
        set.connect(collageView1.getId(), ConstraintSet.START, collage.getId(), ConstraintSet.START, 0);


        set.connect(collageView2.getId(), ConstraintSet.END, collage.getId(), ConstraintSet.END, 0);
        set.connect(collageView2.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);


        set.connect(collageView3.getId(), ConstraintSet.START, collage.getId(), ConstraintSet.START, 0);
        set.connect(collageView3.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);

        set.connect(collageView4.getId(), ConstraintSet.END, collage.getId(), ConstraintSet.END, 0);
        set.connect(collageView4.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);


        set.connect(collageView5.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);
        set.connect(collageView5.getId(), ConstraintSet.START, collage.getId(), ConstraintSet.START, 0);
        set.connect(collageView5.getId(), ConstraintSet.END, collage.getId(), ConstraintSet.END, 0);
        set.connect(collageView5.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);


        set.applyTo(collage);

        for (int i = 0; i < mCollageViews.size(); i++) {

            CardView view = mCollageViews.get(i).getView();

            x = mCollageViews.get(i).getScale();
            y = mCollageViews.get(i).getScale();

            view.setScaleX(x);
            view.setScaleY(y);


            if (i == 0) {
                view.setRotation(10);
            } else if (i == 1 || i == 2) {
                view.setRotation(350);
            } else if (i == 3) {
                view.setRotation(10);
            }

            int finalI = i;
            view.post(() -> {
                int width = (int) (view.getWidth() * view.getScaleX());
                int height = (int) (view.getHeight() * view.getScaleY());
                ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) view.getLayoutParams();
                layoutParams.width = width;
                layoutParams.height = height;
                if (finalI == 0) {
                    layoutParams.topMargin = 20;
                    layoutParams.leftMargin = 40;
                } else if (finalI == 1) {
                    layoutParams.topMargin = 20;
                    layoutParams.rightMargin = 40;
                } else if (finalI == 2) {
                    layoutParams.bottomMargin = 20;
                    layoutParams.leftMargin = 40;
                } else if (finalI == 3) {
                    layoutParams.bottomMargin = 20;
                    layoutParams.rightMargin = 40;
                }


                view.setLayoutParams(layoutParams);
                view.setScaleX(1);
                view.setScaleY(1);
                /*if (finalI == 0) {
                    view.setTranslationX(-70);
                } else if (finalI == 1) {
                    view.setTranslationX(70);
                }*/
            });

        }

    }

    private void resizeSixImage(float x, float y) {

        for (CollageViewModel model : mCollageViews) {
            model.getView().setTranslationX(0);
            model.getView().setTranslationY(0);
        }


        CardView collageView1 = mCollageViews.get(0).getView();
        CardView collageView2 = mCollageViews.get(1).getView();
        CardView collageView3 = mCollageViews.get(2).getView();
        CardView collageView4 = mCollageViews.get(3).getView();
        CardView collageView5 = mCollageViews.get(4).getView();
        CardView collageView6 = mCollageViews.get(5).getView();
        ConstraintSet set = new ConstraintSet();


        set.clone(collage);


        set.connect(collageView1.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);
        set.connect(collageView1.getId(), ConstraintSet.START, collage.getId(), ConstraintSet.START, 0);


        set.connect(collageView2.getId(), ConstraintSet.START, collage.getId(), ConstraintSet.START, 0);
        set.connect(collageView2.getId(), ConstraintSet.END, collage.getId(), ConstraintSet.END, 0);
        set.connect(collageView2.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);


        set.connect(collageView3.getId(), ConstraintSet.RIGHT, collage.getId(), ConstraintSet.RIGHT, 0);
        set.connect(collageView3.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);

        set.connect(collageView4.getId(), ConstraintSet.LEFT, collage.getId(), ConstraintSet.LEFT, 0);
        set.connect(collageView4.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);


        set.connect(collageView5.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);
        set.connect(collageView5.getId(), ConstraintSet.LEFT, collage.getId(), ConstraintSet.LEFT, 0);
        set.connect(collageView5.getId(), ConstraintSet.RIGHT, collage.getId(), ConstraintSet.RIGHT, 0);

        set.connect(collageView6.getId(), ConstraintSet.RIGHT, collage.getId(), ConstraintSet.RIGHT, 0);
        set.connect(collageView6.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);


        set.applyTo(collage);

        for (int i = 0; i < mCollageViews.size(); i++) {

            CardView view = mCollageViews.get(i).getView();

            x = mCollageViews.get(i).getScale();
            y = mCollageViews.get(i).getScale();

            view.setScaleX(x);
            view.setScaleY(y);


            view.setRotation(10);


            int finalI = i;
            view.post(() -> {
                int width = (int) (view.getWidth() * view.getScaleX());
                int height = (int) (view.getHeight() * view.getScaleY());
                ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) view.getLayoutParams();
                layoutParams.width = width;
                layoutParams.height = height;
                if (finalI == 0) {
                    layoutParams.topMargin = 20;
                    layoutParams.leftMargin = 10;
                } else if (finalI == 1) {
                    layoutParams.topMargin = 10;
                    layoutParams.rightMargin = 40;
                } else if (finalI == 2) {
                    layoutParams.topMargin = 10;
                    layoutParams.rightMargin = 40;
                } else if (finalI == 3) {
                    layoutParams.bottomMargin = 10;
                    layoutParams.leftMargin = 10;
                } else if (finalI == 4) {
                    layoutParams.bottomMargin = 10;
                    layoutParams.rightMargin = 40;
                } else if (finalI == 5) {
                    layoutParams.bottomMargin = 10;
                    layoutParams.rightMargin = 40;
                }
                view.setLayoutParams(layoutParams);
                view.setScaleX(1);
                view.setScaleY(1);
                /*if (finalI == 0) {
                    view.setTranslationX(-70);
                } else if (finalI == 2) {
                    view.setTranslationX(70);
                } else if (finalI == 3) {
                    view.setTranslationX(-70);
                } else if (finalI == 5) {
                    view.setTranslationX(70);
                }*/
            });

        }

    }

    private void resizeSevenImage() {

        for (CollageViewModel model : mCollageViews) {
            model.getView().setTranslationX(0);
            model.getView().setTranslationY(0);
        }


        CardView collageView1 = mCollageViews.get(0).getView();
        CardView collageView2 = mCollageViews.get(1).getView();
        CardView collageView3 = mCollageViews.get(2).getView();
        CardView collageView4 = mCollageViews.get(3).getView();
        CardView collageView5 = mCollageViews.get(4).getView();
        CardView collageView6 = mCollageViews.get(5).getView();
        CardView collageView7 = mCollageViews.get(6).getView();
        ConstraintSet set = new ConstraintSet();


        set.clone(collage);


        /*set.connect(collageView1.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);
        set.connect(collageView1.getId(), ConstraintSet.START, collage.getId(), ConstraintSet.START, 0);


        set.connect(collageView2.getId(), ConstraintSet.START, collage.getId(), ConstraintSet.START, 0);
        set.connect(collageView2.getId(), ConstraintSet.END, collage.getId(), ConstraintSet.END, 0);
        set.connect(collageView2.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);


        set.connect(collageView3.getId(), ConstraintSet.RIGHT, collage.getId(), ConstraintSet.RIGHT, 0);
        set.connect(collageView3.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);

        set.connect(collageView4.getId(), ConstraintSet.LEFT, collage.getId(), ConstraintSet.LEFT, 0);
        set.connect(collageView4.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);


        set.connect(collageView5.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);
        set.connect(collageView5.getId(), ConstraintSet.LEFT, collage.getId(), ConstraintSet.LEFT, 0);
        set.connect(collageView5.getId(), ConstraintSet.RIGHT, collage.getId(), ConstraintSet.RIGHT, 0);

        set.connect(collageView6.getId(), ConstraintSet.RIGHT, collage.getId(), ConstraintSet.RIGHT, 0);
        set.connect(collageView6.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);

        set.connect(collageView7.getId(), ConstraintSet.RIGHT, collage.getId(), ConstraintSet.RIGHT, 0);
        set.connect(collageView7.getId(), ConstraintSet.LEFT, collage.getId(), ConstraintSet.LEFT, 0);
        set.connect(collageView7.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);
        set.connect(collageView7.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);

*/

        set.connect(collageView1.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);
        set.connect(collageView1.getId(), ConstraintSet.START, collage.getId(), ConstraintSet.START, 0);

        set.connect(collageView2.getId(), ConstraintSet.END, collage.getId(), ConstraintSet.END, 0);
        set.connect(collageView2.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);

        set.connect(collageView3.getId(), ConstraintSet.LEFT, collage.getId(), ConstraintSet.LEFT, 0);
        set.connect(collageView3.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);
        set.connect(collageView3.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);

        set.connect(collageView4.getId(), ConstraintSet.RIGHT, collage.getId(), ConstraintSet.RIGHT, 0);
        set.connect(collageView4.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);
        set.connect(collageView4.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);

        set.connect(collageView5.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);
        set.connect(collageView5.getId(), ConstraintSet.LEFT, collage.getId(), ConstraintSet.LEFT, 0);

        set.connect(collageView6.getId(), ConstraintSet.RIGHT, collage.getId(), ConstraintSet.RIGHT, 0);
        set.connect(collageView6.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);

        set.connect(collageView7.getId(), ConstraintSet.RIGHT, collage.getId(), ConstraintSet.RIGHT, 0);
        set.connect(collageView7.getId(), ConstraintSet.LEFT, collage.getId(), ConstraintSet.LEFT, 0);
        set.connect(collageView7.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);


        set.applyTo(collage);

/*        for (int i = 0; i < mCollageViews.size(); i++) {

            CardView view = mCollageViews.get(i).getView();

            x = mCollageViews.get(i).getScale();
            y = mCollageViews.get(i).getScale();

            view.setScaleX(x);
            view.setScaleY(y);


            if (i == 6) {
                view.setRotation(350);
            } else {
                view.setRotation(10);
            }

            int finalI = i;
            view.post(() -> {
                int width = (int) (view.getWidth() * view.getScaleX());
                int height = (int) (view.getHeight() * view.getScaleY());
                ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) view.getLayoutParams();
                layoutParams.width = width;
                layoutParams.height = height;
                if (finalI == 0) {
                    layoutParams.topMargin = 20;
                    layoutParams.leftMargin = 10;
                } else if (finalI == 1) {
                    layoutParams.topMargin = 10;
                    layoutParams.rightMargin = 40;
                } else if (finalI == 2) {
                    layoutParams.topMargin = 10;
                    layoutParams.rightMargin = 40;
                } else if (finalI == 3) {
                    layoutParams.bottomMargin = 10;
                    layoutParams.leftMargin = 10;
                } else if (finalI == 4) {
                    layoutParams.bottomMargin = 10;
                    layoutParams.rightMargin = 40;
                } else if (finalI == 5) {
                    layoutParams.bottomMargin = 10;
                    layoutParams.rightMargin = 40;
                }
                view.setLayoutParams(layoutParams);
                view.setScaleX(1);
                view.setScaleY(1);
               *//* if (finalI == 0) {
                    view.setTranslationX(-70);
                } else if (finalI == 2) {
                    view.setTranslationX(70);
                } else if (finalI == 3) {
                    view.setTranslationX(-70);
                } else if (finalI == 5) {
                    view.setTranslationX(70);
                } else if (finalI == 6) {
                    view.setTranslationX(30);
                }*//*
            });

        }*/

        for (int i = 0; i < mCollageViews.size(); i++) {

            CardView view = mCollageViews.get(i).getView();

            float x = mCollageViews.get(i).getScale();
            float y = mCollageViews.get(i).getScale();

            view.setScaleX(x);
            view.setScaleY(y);


            if (i % 2 == 0) {
                view.setRotation(350);
            } else {
                view.setRotation(10);
            }


            int finalI = i;
            view.post(() -> {
                int width = (int) (view.getWidth() * view.getScaleX());
                int height = (int) (view.getHeight() * view.getScaleY());
                ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) view.getLayoutParams();
                layoutParams.width = width;
                layoutParams.height = height;
                if (finalI == 0) {
                    layoutParams.topMargin = 10;
                    layoutParams.leftMargin = 20;
                } else if (finalI == 1) {
                    layoutParams.topMargin = 10;
                    layoutParams.rightMargin = 20;
                } else if (finalI == 2) {
                    layoutParams.leftMargin = 40;
                } else if (finalI == 3) {
                    layoutParams.rightMargin = 40;
                } else if (finalI == 4) {
                    layoutParams.bottomMargin = 10;
                    layoutParams.leftMargin = 60;
                } else if (finalI == 5) {
                    layoutParams.bottomMargin = 10;
                    layoutParams.rightMargin = 60;
                } else if (finalI == 6) {
                    view.setRotation(0);
                    layoutParams.topMargin = 20;
                }


                view.setLayoutParams(layoutParams);

                view.setScaleX(1);
                view.setScaleY(1);

            });
        }

    }

    private void resizeEightImage(boolean isTranslate) {

        for (CollageViewModel model : mCollageViews) {
            model.getView().setTranslationX(0);
            model.getView().setTranslationY(0);
        }

        CardView collageView1 = mCollageViews.get(0).getView();
        CardView collageView2 = mCollageViews.get(1).getView();
        CardView collageView3 = mCollageViews.get(2).getView();
        CardView collageView4 = mCollageViews.get(3).getView();
        CardView collageView5 = mCollageViews.get(4).getView();
        CardView collageView6 = mCollageViews.get(5).getView();
        CardView collageView7 = mCollageViews.get(6).getView();
        CardView collageView8 = mCollageViews.get(7).getView();
        ConstraintSet set = new ConstraintSet();


        set.clone(collage);


        set.connect(collageView1.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);
        set.connect(collageView1.getId(), ConstraintSet.START, collage.getId(), ConstraintSet.START, 0);


        set.connect(collageView2.getId(), ConstraintSet.START, collage.getId(), ConstraintSet.START, 0);
        set.connect(collageView2.getId(), ConstraintSet.END, collage.getId(), ConstraintSet.END, 0);
        set.connect(collageView2.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);


        set.connect(collageView3.getId(), ConstraintSet.RIGHT, collage.getId(), ConstraintSet.RIGHT, 0);
        set.connect(collageView3.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);

        set.connect(collageView4.getId(), ConstraintSet.LEFT, collage.getId(), ConstraintSet.LEFT, 0);
        set.connect(collageView4.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);


        set.connect(collageView5.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);
        set.connect(collageView5.getId(), ConstraintSet.LEFT, collage.getId(), ConstraintSet.LEFT, 0);
        set.connect(collageView5.getId(), ConstraintSet.RIGHT, collage.getId(), ConstraintSet.RIGHT, 0);

        set.connect(collageView6.getId(), ConstraintSet.RIGHT, collage.getId(), ConstraintSet.RIGHT, 0);
        set.connect(collageView6.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);

        set.connect(collageView7.getId(), ConstraintSet.END, collageView8.getId(), ConstraintSet.START, 0);
        set.connect(collageView7.getId(), ConstraintSet.START, collage.getId(), ConstraintSet.START, 0);
        set.connect(collageView7.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);
        set.connect(collageView7.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);
        set.setHorizontalBias(collageView7.getId(), 0.5f);

        set.connect(collageView8.getId(), ConstraintSet.START, collageView7.getId(), ConstraintSet.END, 0);
        set.connect(collageView8.getId(), ConstraintSet.END, collage.getId(), ConstraintSet.END, 0);
        set.connect(collageView8.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);
        set.connect(collageView8.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);
        set.setHorizontalBias(collageView8.getId(), 0.5f);

        /*set.connect(collageView1.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);
        set.connect(collageView1.getId(), ConstraintSet.START, collage.getId(), ConstraintSet.START, 0);

        set.connect(collageView2.getId(), ConstraintSet.END, collage.getId(), ConstraintSet.END, 0);
        set.connect(collageView2.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);

        set.connect(collageView3.getId(), ConstraintSet.LEFT, collage.getId(), ConstraintSet.LEFT, 0);
        set.connect(collageView3.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);
        set.connect(collageView3.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);

        set.connect(collageView4.getId(), ConstraintSet.RIGHT, collage.getId(), ConstraintSet.RIGHT, 0);
        set.connect(collageView4.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);
        set.connect(collageView4.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);

        set.connect(collageView5.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);
        set.connect(collageView5.getId(), ConstraintSet.LEFT, collage.getId(), ConstraintSet.LEFT, 0);

        set.connect(collageView6.getId(), ConstraintSet.RIGHT, collage.getId(), ConstraintSet.RIGHT, 0);
        set.connect(collageView6.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);

        set.connect(collageView7.getId(), ConstraintSet.END, collageView8.getId(), ConstraintSet.START, 0);
        set.connect(collageView7.getId(), ConstraintSet.START, collage.getId(), ConstraintSet.START, 0);
        set.connect(collageView7.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);
        set.connect(collageView7.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);
        set.setHorizontalBias(collageView7.getId(), 0.5f);

        set.connect(collageView8.getId(), ConstraintSet.START, collageView7.getId(), ConstraintSet.END, 0);
        set.connect(collageView8.getId(), ConstraintSet.END, collage.getId(), ConstraintSet.END, 0);
        set.connect(collageView8.getId(), ConstraintSet.TOP, collage.getId(), ConstraintSet.TOP, 0);
        set.connect(collageView8.getId(), ConstraintSet.BOTTOM, collage.getId(), ConstraintSet.BOTTOM, 0);
        set.setHorizontalBias(collageView8.getId(), 0.5f);*/

        set.applyTo(collage);

        for (int i = 0; i < mCollageViews.size(); i++) {

            CardView view = mCollageViews.get(i).getView();

            float x = mCollageViews.get(i).getScale();
            float y = mCollageViews.get(i).getScale();

            view.setScaleX(x);
            view.setScaleY(y);


            if ((i >= 0 && i <= 2) || i == 6) {
                view.setRotation(10);
            } else if ((i >= 3 && i <= 5) || i == 7) {
                view.setRotation(350);
            }

            int finalI = i;
            view.post(() -> {
                int width = (int) (view.getWidth() * view.getScaleX());
                int height = (int) (view.getHeight() * view.getScaleY());
                ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) view.getLayoutParams();
                layoutParams.width = width;
                layoutParams.height = height;
                if (finalI == 0) {
                    layoutParams.topMargin = 20;
                    layoutParams.leftMargin = 20;
                } else if (finalI == 1) {
                    layoutParams.topMargin = 10;
                    layoutParams.rightMargin = 40;
                } else if (finalI == 2) {
                    layoutParams.topMargin = 10;
                    layoutParams.rightMargin = 40;
                } else if (finalI == 3) {
                    layoutParams.bottomMargin = 10;
                    layoutParams.leftMargin = 20;
                } else if (finalI == 4) {
                    layoutParams.bottomMargin = 10;
                    layoutParams.rightMargin = 40;
                } else if (finalI == 5) {
                    layoutParams.bottomMargin = 10;
                    layoutParams.rightMargin = 40;
                }
                view.setLayoutParams(layoutParams);

                view.setScaleX(1);
                view.setScaleY(1);
                if (finalI == 0) {
                    view.setTranslationX(-70);
                } else if (finalI == 2) {
                    view.setTranslationX(70);
                } else if (finalI == 3) {
                    view.setTranslationX(-70);
                } else if (finalI == 5) {
                    view.setTranslationX(70);
                } else if (finalI == 6) {
                    view.setTranslationX(-25);
                } else if (finalI == 7) {
                    view.setTranslationX(35);
                }
            });

        }

        /*for (int i = 0; i < mCollageViews.size(); i++) {

            CardView view = mCollageViews.get(i).getView();

            float x = mCollageViews.get(i).getScale();
            float y = mCollageViews.get(i).getScale();

            view.setScaleX(x);
            view.setScaleY(y);


            if (i % 2 == 0) {
                view.setRotation(350);
            }else{
                view.setRotation(10);
            }

            *//*if ((i >= 0 && i <= 2) || i == 6) {
                view.setRotation(10);
            } else if ((i >= 3 && i <= 5) || i == 7) {
                view.setRotation(350);
            }*//*

            int finalI = i;
            view.post(() -> {
                int width = (int) (view.getWidth() * view.getScaleX());
                int height = (int) (view.getHeight() * view.getScaleY());
                ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) view.getLayoutParams();
                layoutParams.width = width;
                layoutParams.height = height;
                if (finalI == 0) {
                    layoutParams.topMargin = 20;
                    layoutParams.leftMargin = 20;
                } else if (finalI == 1) {
                    layoutParams.topMargin = 20;
                    layoutParams.rightMargin = 20;
                } else if (finalI == 2) {
                    layoutParams.leftMargin = 40;
                } else if (finalI == 3) {
                    layoutParams.rightMargin = 40;
                } else if (finalI == 4) {
                    layoutParams.bottomMargin = 10;
                    layoutParams.leftMargin = 60;
                } else if (finalI == 5) {
                    layoutParams.bottomMargin = 10;
                    layoutParams.rightMargin = 60;
                }


                view.setLayoutParams(layoutParams);

                view.setScaleX(1);
                view.setScaleY(1);
                *//*if (finalI == 0) {
                    view.setTranslationX(-70);
                } else if (finalI == 2) {
                    view.setTranslationX(70);
                } else if (finalI == 3) {
                    view.setTranslationX(-70);
                } else if (finalI == 5) {
                    view.setTranslationX(70);
                } else if (finalI == 6) {
                    view.setTranslationX(-25);
                } else if (finalI == 7) {
                    view.setTranslationX(35);
                }*//*
            });

        }*/
    }

    public static Bitmap getBitmapFromVectorDrawable(Context context, int drawableId) {
        Drawable drawable = ContextCompat.getDrawable(context, drawableId);
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            drawable = (DrawableCompat.wrap(drawable)).mutate();
        }

        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(),
                drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);

        return bitmap;
    }

    private Bitmap getScaleBitmap(View collageContainer, Drawable drawable) {


        final int actualHeight, actualWidth;
        final int imageViewHeight = collageContainer.getHeight(), imageViewWidth = collageContainer.getWidth();
        Log.d(TAG, "scaleBitmap: " + imageViewHeight);
        final int bitmapHeight = drawable.getIntrinsicHeight(), bitmapWidth = drawable.getIntrinsicWidth();
        if (imageViewHeight * bitmapWidth <= imageViewWidth * bitmapHeight) {
            actualWidth = bitmapWidth * imageViewHeight / bitmapHeight;
            actualHeight = imageViewHeight;
        } else {
            actualHeight = bitmapHeight * imageViewWidth / bitmapWidth;
            actualWidth = imageViewWidth;
        }

        Point point = new Point(actualWidth, actualHeight);
        Log.d(TAG, "run: " + point.x + " = " + point.y);
        BitmapDrawable bitmapDrawable = (BitmapDrawable) drawable;

        return Bitmap.createScaledBitmap(bitmapDrawable.getBitmap(), point.x, point.y, true);

    }

    private Point getWidthAndHeight(View collageContainer, Bitmap bitmap) {


        final int actualHeight, actualWidth;
        final int imageViewHeight = collageContainer.getHeight(), imageViewWidth = collageContainer.getWidth();
        Log.d(TAG, "scaleBitmap: " + imageViewHeight);
        final int bitmapHeight = bitmap.getHeight(), bitmapWidth = bitmap.getWidth();
        if (imageViewHeight * bitmapWidth <= imageViewWidth * bitmapHeight) {
            actualWidth = bitmapWidth * imageViewHeight / bitmapHeight;
            actualHeight = imageViewHeight;
        } else {
            actualHeight = bitmapHeight * imageViewWidth / bitmapWidth;
            actualWidth = imageViewWidth;
        }

        Point point = new Point(actualWidth, actualHeight);
        Log.d(TAG, "run: " + point.x + " = " + point.y);

        return point; //Bitmap.createScaledBitmap(bitmapDrawable.getBitmap(), point.x, point.y, true);

    }

    private void startCrop(String path) {
        try {
            String extension = path.substring(path.lastIndexOf("."));

            Calendar calendar = Calendar.getInstance();
            String destinationFileName = calendar.getTimeInMillis() + SAMPLE_CROPPED_IMAGE_NAME + extension;


            UCrop uCrop = UCrop.of(getImageContentUri(mContext, new File(path)), Uri.fromFile(new File(getCacheDir(), destinationFileName)));
            uCrop = advancedConfig(uCrop);

            uCrop.start(ScrapbookActivity.this);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    private UCrop advancedConfig(@NonNull UCrop uCrop) {
        UCrop.Options options = new UCrop.Options();

        options.setFreeStyleCropEnabled(true);

        return uCrop.withOptions(options);
    }

    @Override
    public void onTouchDown(View view) {

        unSelectBottomMenuItem();

        mSelectedView = view;

        Log.d(TAG, "onTouchDown: " + collage.getListCards().size());
        for (int i = 0; i < collage.getListCards().size(); i++) {
            CardView cardView = collage.getListCards().get(i);
            cardView.setBackground(null);
        }

        if (view instanceof CardView) {
            view.setBackgroundResource(R.drawable.bg_close_btn);

            /*if (mPopupWindow.isShowing())
                mPopupWindow.dismiss();*/

            prepareImageOptions();
            if (adepter != null)
                adepter.notifyDataSetChanged();

            mPopupWindow.setWidth(ConstraintLayout.LayoutParams.MATCH_PARENT);
            mPopupWindow.setHeight(ConstraintLayout.LayoutParams.WRAP_CONTENT);

            if (!mPopupWindow.isShowing()) {
                mPopupWindow.showAtLocation(mCollageContainer, Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM, 0,/* (int) (mBottomMenu.getHeight() * 1.8f)*/0);
                //imgBtnClose.setVisibility(View.VISIBLE);
            }

        } else {

            /*if (mPopupWindow.isShowing())
                mPopupWindow.dismiss();*/

            prepareTextOptions();


            if (adepter != null)
                adepter.notifyDataSetChanged();

            mPopupWindow.setWidth(ConstraintLayout.LayoutParams.MATCH_PARENT);
            mPopupWindow.setHeight(ConstraintLayout.LayoutParams.WRAP_CONTENT);

            if (!mPopupWindow.isShowing()) {
                mPopupWindow.showAtLocation(mCollageContainer, Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM, 0,/* (int) (mBottomMenu.getHeight() * 1.8f)*/0);
                //.setVisibility(View.VISIBLE);
            }
        }


        Log.d(TAG, "onTouchDown: " + mBottomMenu.getTop() + " + " + mBottomMenu.getHeight());


        Log.d(TAG, "onTouchDown: " + view.getTranslationX() + " = " + view.getTranslationY() + " = " + view.getScaleX() + " = " + view.getRotation());
    }

    @Override
    public void onBackgroundImageClick(String uri) {
        bottomSheetDialogFragment.dismiss();
        Glide.with(mContext).load(uri).into(imgBackground);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        switch (requestCode) {

            case Constants.PICK_IMAGE_CODE:

                if (resultCode == RESULT_OK) {
                    Log.d(TAG, "onActivityResult: " + imageType + " + " + data.getData());
                    if (imageType == 0) {
                        try {
                            Bitmap bitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(data.getData()));

                            bitmap = getScaleBitmap(mCollageContainer, new BitmapDrawable(getResources(), bitmap));

                            ((CardView) mSelectedView).setImageBitmap(bitmap);

                            CollageViewModel model = null;

                            for (CollageViewModel viewModel : mCollageViews) {
                                if (viewModel.getView().equals(mSelectedView)) {
                                    model = viewModel;
                                    break;
                                }
                            }

                            if (model != null) {
                                mSelectedView.getLayoutParams().width = (int) (bitmap.getWidth() * model.getChangeScale());
                                mSelectedView.getLayoutParams().height = (int) (bitmap.getHeight() * model.getChangeScale());
                                mSelectedView.requestLayout();
                            }

                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }

                    } else {
                        Glide.with(ScrapbookActivity.this).load(data.getData()).into(new CustomTarget<Drawable>() {
                            @Override
                            public void onResourceReady(@NonNull Drawable resource, @Nullable Transition<? super Drawable> transition) {
                                Log.d(TAG, "onResourceReady: background 1 ");
                                collage.setBackground(resource);
                            }

                            @Override
                            public void onLoadCleared(@Nullable Drawable placeholder) {
                                Log.d(TAG, "onLoadCleared: ");
                            }
                        });
                    }
                }
                break;
            case UCrop.REQUEST_CROP:
                if (resultCode == RESULT_OK) {

                    Log.d(TAG, "onActivityResult: " + data.getData());
                    handleCropResult(data);
                }
                break;

            default:
                super.onActivityResult(requestCode, resultCode, data);
        }
    }


    private void handleCropResult(@NonNull Intent result) {
        final Uri resultUri = UCrop.getOutput(result);
        if (resultUri != null) {

            if (mSelectedView != null) {

                String copyPath = Environment.getExternalStorageDirectory().getPath() + File.separator + getString(R.string.app_name) + File.separator + ".tmp" + File.separator + "IM_" + System.currentTimeMillis() + ".png";

                try {

                    try {
                        if (!new File(copyPath).getParentFile().exists()) {
                            new File(copyPath).getParentFile().mkdir();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    try {
                        if (!new File(copyPath).exists()) {
                            new File(copyPath).createNewFile();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    FileUtils.copyFile(resultUri.getPath(), copyPath);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (!new File(copyPath).exists()) {
                    return;
                }

                String imagePath = copyPath;

                Glide.with(mContext).load(imagePath).into(new CustomTarget<Drawable>() {
                    @Override
                    public void onResourceReady(@NonNull Drawable resource, @Nullable Transition<? super Drawable> transition) {


                        Bitmap bitmap = getScaleBitmap(mCollageContainer, resource);

                        if (bitmap != null && mSelectedView != null) {
                            ((CardView) mSelectedView).setImageBitmap(bitmap);
                            mSelectedView.setTag(imagePath);
                            Constants.mCropBitmap = null;

                            CollageViewModel model = null;

                            for (CollageViewModel viewModel : mCollageViews) {
                                if (viewModel.getView().equals(mSelectedView)) {
                                    model = viewModel;
                                    listRes.remove(mCollageViews.indexOf(model));
                                    listRes.add(mCollageViews.indexOf(model), bitmap);
                                    break;
                                }
                            }

                            for (PhotoModel model1 : mPhotoList) {
                                if (model1.getImagePath() == model.getView().getTag().toString()) {
                                    model1.setImagePath(imagePath);
                                    break;
                                }
                            }
                            model.getView().setTag(imagePath);

                            if (model != null) {
                                mSelectedView.getLayoutParams().width = (int) (bitmap.getWidth() * model.getChangeScale());
                                mSelectedView.getLayoutParams().height = (int) (bitmap.getHeight() * model.getChangeScale());
                                mSelectedView.requestLayout();
                            }
                        }
                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {

                    }
                });

            } else {
                Toast.makeText(mContext, "Please try again", LENGTH_SHORT).show();
            }

            //ResultActivity.startWithUri(SelectCropActivity.this, resultUri, UCrop.getInput(result), width, height);
        } else {
            Toast.makeText(ScrapbookActivity.this, "Error for crop image", LENGTH_SHORT).show();
        }
    }

    public void deleteRecursive(File fileOrDirectory) {
        try {
            if (fileOrDirectory != null && fileOrDirectory.isDirectory())
                for (File child : Objects.requireNonNull(fileOrDirectory.listFiles()))
                    deleteRecursive(child);
            assert fileOrDirectory != null;
            fileOrDirectory.delete();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Dialog discardDialog;

    @Override
    public void onBackPressed() {
        if (isFragmentLoaded) {
            removeFragment();
            for (int i = 0; i < mBottomMenu.getChildCount(); i++) {
                View v1 = mBottomMenu.getChildAt(i);
                (((ConstraintLayout) v1).getChildAt(0)).setAlpha(0.5f);
                (((ConstraintLayout) v1).getChildAt(1)).setAlpha(0.5f);
                stopBottomMenuAnimation((((ConstraintLayout) v1).getChildAt(1)), (((ConstraintLayout) v1).getChildAt(0)), (((ConstraintLayout) v1).getChildAt(2)));
            }
        } else {
            for (int i = 0; i < mBottomMenu.getChildCount(); i++) {
                View v1 = mBottomMenu.getChildAt(i);
                (((ConstraintLayout) v1).getChildAt(0)).setAlpha(0.5f);
                (((ConstraintLayout) v1).getChildAt(1)).setAlpha(0.5f);
                stopBottomMenuAnimation((((ConstraintLayout) v1).getChildAt(1)), (((ConstraintLayout) v1).getChildAt(0)), (((ConstraintLayout) v1).getChildAt(2)));
            }
            if (mPopupWindow.isShowing()) {
                //unSelectBottomMenuItem();
                closePopupWindow();
                for (int i = 0; i < collage.getListCards().size(); i++) {
                    CardView cardView = collage.getListCards().get(i);
                    cardView.setBackground(null);
                }

                mSelectedView = null;
            } else {

           /* if (isCropViewOpen) {
                super.onBackPressed();
                isCropViewOpen = false;
                if (Constants.mCropBitmap != null) {
                    Bitmap bitmap = getScaleBitmap(mCollageContainer, new BitmapDrawable(getResources(), Constants.mCropBitmap));
                    ((CardView) mSelectedView).setImageBitmap(bitmap);
                    Constants.mCropBitmap = null;

                    CollageViewModel model = null;

                    for (CollageViewModel viewModel : mCollageViews) {
                        if (viewModel.getView().equals(mSelectedView)) {
                            model = viewModel;
                            break;
                        }
                    }
                    if (model != null) {
                        mSelectedView.getLayoutParams().width = (int) (bitmap.getWidth() * model.getChangeScale());
                        mSelectedView.getLayoutParams().height = (int) (bitmap.getHeight() * model.getChangeScale());
                        mSelectedView.requestLayout();
                    }

                }
            } else*/
                if (mSubBottomBar.getVisibility() == View.VISIBLE) {
                    mSubBottomBar.setVisibility(View.GONE);
                    imgBtnClose.setVisibility(View.GONE);
                } else {

                /*new AlertDialog.Builder(this)
                        .setMessage("Are you sure want to discard?")
                        .setPositiveButton("OK", (dialog, which) -> {
                            super.onBackPressed();
                        })
                        .setNegativeButton("Cancel", (dialog, which) -> {
                            dialog.dismiss();
                        })
                        .show();*/

                    discardDialog = new Dialog(this);
                    discardDialog.setContentView(R.layout.dialog_discard);
                    discardDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                    discardDialog.getWindow().setLayout(ConstraintLayout.LayoutParams.MATCH_PARENT, ConstraintLayout.LayoutParams.WRAP_CONTENT);
                    TextView btnCancel = discardDialog.findViewById(R.id.btnCancel);
                    TextView btnDiscard = discardDialog.findViewById(R.id.btnDiscard);
                    btnCancel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            discardDialog.dismiss();
                        }
                    });

                    btnDiscard.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            discardDialog.dismiss();
                            Intent discardIntent = new Intent();
                            discardIntent.putExtra("finishData", "nulled");
                            setResult(Constants.SCRAPBOOK_IMAGE_DISCARD_REQUEST_CODE, discardIntent);
                            finish();
                        }
                    });
                    if (!isFinishing()) {
                        discardDialog.show();
                    }

                }

            }
        }
    }

    private void closePopupWindow() {
        mPopupWindow.dismiss();
        imgBtnClose.setVisibility(View.GONE);

    }

    private String getSaveImageFilePath() {
        File mediaStorageDir = new File(
                Environment.getExternalStorageDirectory().getAbsolutePath(), getString(R.string.app_name));
        // Create a storage directory if it does not exist
        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                Log.d(TAG, "Failed to create directory");
            }
        }

        // Create a media file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageName = "IMG_" + timeStamp + "_scrapbook.jpg";

        String selectedOutputPath = mediaStorageDir.getPath() + File.separator + imageName;
        Log.d(TAG, "selected camera path " + selectedOutputPath);

        mCollageContainer.setDrawingCacheEnabled(true);
        mCollageContainer.buildDrawingCache();
        Bitmap bitmap = Bitmap.createBitmap(mCollageContainer.getDrawingCache());

        bitmap = cropBitmap(bitmap, new Rect(collage.getLeft(), collage.getTop(), collage.getRight(), collage.getBottom()));

        int maxSize = 1080;

        int bWidth = bitmap.getWidth();
        int bHeight = bitmap.getHeight();

        /*if (bWidth > bHeight) {
            int imageHeight = (int) Math.abs(maxSize * ((float)bitmap.getWidth() / (float) bitmap.getHeight()));
            bitmap = Bitmap.createScaledBitmap(bitmap, maxSize, imageHeight, true);
        } else {
            int imageWidth = (int) Math.abs(maxSize * ((float)bitmap.getWidth() / (float) bitmap.getHeight()));
            bitmap = Bitmap.createScaledBitmap(bitmap, imageWidth, maxSize, true);
        }*/
        mCollageContainer.setDrawingCacheEnabled(false);
        mCollageContainer.destroyDrawingCache();

        OutputStream fOut = null;
        try {
            File file = new File(selectedOutputPath);
            fOut = new FileOutputStream(file);

            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
            fOut.flush();
            fOut.close();

            Constants.savedImageUri = Uri.fromFile(file);
            Constants.path = file.getAbsolutePath();
            PhotoUtils.addImageToGallery(file.getAbsolutePath(), mContext);
            Toast.makeText(mContext, "Image save at Photo Collage Maker", Toast.LENGTH_SHORT).show();

            if (!AdsPrefs.getBoolean(this, AdsPrefs.IS_SUBSCRIBED) && isInterstitialAdLoaded) {
                interstitial.show();
            } else {
                // perform your action
                startActivity(new Intent(ScrapbookActivity.this, ViewImageActivity.class));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return selectedOutputPath;
    }

    public Bitmap cropBitmap(Bitmap bitmap, Rect rect) {
        try {
            int w = rect.right - rect.left;
            int h = rect.bottom - rect.top;
            Bitmap ret = Bitmap.createBitmap(w, h, bitmap.getConfig());
            Canvas canvas = new Canvas(ret);
            canvas.drawBitmap(bitmap, -rect.left, -rect.top, null);
            return ret;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void onLoad() {
        isInterstitialAdLoaded = true;
    }

    @Override
    public void onFailed() {
        isInterstitialAdLoaded = false;
        //interstitial = InterstitialAdHelper.getInstance().load(mContext, this);
    }

    @Override
    public void onClosed() {
        isInterstitialAdLoaded = false;
        interstitial = InterstitialAdHelper.getInstance().load(mContext, this);

        // perform your action
        startActivity(new Intent(ScrapbookActivity.this, ViewImageActivity.class));
    }

    private void onKeyboardVisibilityChanged(boolean opened, int bottom) {
        // Log.d(TAG, "onKeyboardVisibilityChanged: "+ opened);

        if (mSticker != null) {

            if (opened) {
                Log.d(TAG, "onKeyboardVisibilityChanged:  " + mSticker.getMappedBound().bottom + " = " + bottom + " = " + (bottom - (mRootLayout.getBottom() - mStickerView.getBottom())));
                int bottomPoint = bottom - (mRootLayout.getBottom() - mStickerView.getBottom());
                if (mSticker.getMappedBound().bottom > bottomPoint) {
                    //originalBottomPoint = mSelectedText.getMappedBound().bottom;
                    originalBottomPoint = (int) mSticker.getMappedBound().bottom - (bottomPoint - 20);
                    mStickerView.moveUp(0, -originalBottomPoint);
                }
            } else {
                if (originalBottomPoint != 0) {
                    mStickerView.moveUp(0, originalBottomPoint);
                    originalBottomPoint = 0;
                }
            }
        }
    }

    @Override
    public void onKeyboardHeightChanged(int height, int orientation) {
        View view = findViewById(R.id.keyboard);
        ConstraintLayout.LayoutParams params = (ConstraintLayout.LayoutParams) view.getLayoutParams();
        params.height = height;
        view.setLayoutParams(params);
        if (height != 0)
            onKeyboardVisibilityChanged(true, view.getTop());
        else
            onKeyboardVisibilityChanged(false, view.getTop());
    }


    @Override
    public void onPause() {
        super.onPause();
        if (discardDialog != null && discardDialog.isShowing()) {
            discardDialog.dismiss();
        }
        if (mDeleteAlertDialog != null && mDeleteAlertDialog.isShowing()) {
            mDeleteAlertDialog.dismiss();
        }

        if (keyboardHeightProvider != null)
            keyboardHeightProvider.setKeyboardHeightObserver(null);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (keyboardHeightProvider != null)
            keyboardHeightProvider.close();

        deleteRecursive(new File(Environment.getExternalStorageDirectory().getPath() + File.separator + getString(R.string.app_name) + File.separator + ".tmp"));

        try {
            /*File file = getCacheDir();
            for (File file1 : file.listFiles()) {
                file1.delete();
            }*/
            deleteCache(mContext);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void deleteCache(Context context) {
        try {
            File dir = context.getCacheDir();
            deleteDir(dir);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean deleteDir(File dir) {
        if (dir != null && dir.isDirectory()) {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    Log.d(TAG, "deleteDir: false ");
                    return false;
                } else {
                    Log.d(TAG, "deleteDir: true");
                }
            }
            return dir.delete();
        } else if (dir != null && dir.isFile()) {
            return dir.delete();
        } else {
            return false;
        }
    }
}
