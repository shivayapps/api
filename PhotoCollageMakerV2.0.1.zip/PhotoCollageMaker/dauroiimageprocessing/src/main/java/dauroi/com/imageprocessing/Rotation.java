package dauroi.com.imageprocessing;

public enum Rotation {
	NORMAL, ROTATION_90, ROTATION_180, ROTATION_270
}
