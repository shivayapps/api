package com.jcmore2.collage;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;

import com.google.android.material.card.MaterialCardView;


public class MyCardView extends MaterialCardView {

    private CardView cardView;
    private MultiTouchListener mtl;
    private static final int PADDING = 12;
    private static final float STROKE_WIDTH = 12.0f;
    private Paint mBorderPaint;

    public MyCardView(Context context, CardView cardView) {
        super(context);
        this.cardView = cardView;

        init();
        initBorderPaint();
    }

    private void init() {
        setCardElevation(8f);
        setPadding(PADDING, PADDING, PADDING, PADDING);
        this.addView(cardView);
        mtl = new MultiTouchListener();
        this.setOnTouchListener(mtl);
        //mtl.setRandomPosition(this);
    }

    private void initBorderPaint() {
        mBorderPaint = new Paint();
        mBorderPaint.setAntiAlias(true);
        mBorderPaint.setStyle(Paint.Style.STROKE);
        mBorderPaint.setColor(Color.RED);
        mBorderPaint.setStrokeWidth(STROKE_WIDTH);

    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvas.drawRect(0, 0, getWidth(), getHeight(), mBorderPaint);
    }
}
