package com.jcmore2.collage;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.widget.ImageView;

/**
 * Card View is a Collage item
 *
 * @author Juan Carlos Moreno (jcmore2@gmail.com)
 */
public class CardView extends ImageView {

    private static int PADDING = 12;
    private static float STROKE_WIDTH = 12.0f;

    private Paint mBorderPaint, mShadowPaint;
    private MultiTouchListener mtl;
    private float mOffset = PADDING / 2;

    public CardView(Context context) {
        this(context, null);
        init(context);
    }

    public CardView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
        init(context);
        setPadding(PADDING, PADDING, PADDING, PADDING);
    }

    public CardView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(context);
        initBorderPaint();
    }

    @SuppressLint("ClickableViewAccessibility")
    private void init(Context context) {

        this.setScaleType(ScaleType.FIT_XY);
        mtl = new MultiTouchListener();
        mtl.setEvent((MultiTouchListener.OnTouchEvent) context);
        this.setOnTouchListener(mtl);
        //mtl.setPosition(this);

        /*setLayerType(LAYER_TYPE_SOFTWARE,null);*/
    }

    public void setBorder(float size) {
        PADDING = (int) size;
        STROKE_WIDTH = size;
        setPadding(PADDING, PADDING, PADDING, PADDING);
        mBorderPaint.setStrokeWidth(STROKE_WIDTH);
        invalidate();
    }

    private void initBorderPaint() {
        mBorderPaint = new Paint();
        mBorderPaint.setAntiAlias(true);
        mBorderPaint.setStyle(Paint.Style.STROKE);
        mBorderPaint.setColor(Color.WHITE);
        mBorderPaint.setStrokeWidth(STROKE_WIDTH);

    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        //draw border
        canvas.drawRect(PADDING, PADDING, getWidth() - PADDING, getHeight() - PADDING, mBorderPaint);

    }

    /**
     * Function use to block movement in Card
     */
    protected void setFixedItem() {

        mtl.isRotateEnabled = false;
        mtl.isScaleEnabled = false;
        mtl.isTranslateEnabled = false;
    }

}