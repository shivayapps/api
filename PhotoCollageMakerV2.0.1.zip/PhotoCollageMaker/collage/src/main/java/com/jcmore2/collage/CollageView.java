package com.jcmore2.collage;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;

import androidx.constraintlayout.widget.ConstraintLayout;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * 
 * Collage View is the parent view of a collage items.
 * 
 * @author Juan Carlos Moreno (jcmore2@gmail.com)
 * 
 */
public class CollageView extends ConstraintLayout {

	private Context mContext;

	private final int BG = Color.TRANSPARENT;

	private int collageWidth;
	private int collageHeight;

	private List<CardView> listCards = new ArrayList<>();
	private boolean isViewRefresh = false;
	private boolean isCollageFixed = false;

	private final Random random = new Random();

	public CollageView(Context context) {
		this(context, null);
		init(context);
	}

	public CollageView(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
		init(context);
	}

	public CollageView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init(context);
	}

	private void init(Context context) {
		mContext = context;
		this.setMotionEventSplittingEnabled(true);
		this.setBackgroundColor(BG);

	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {

		collageWidth = MeasureSpec.getSize(widthMeasureSpec);

		collageHeight = MeasureSpec.getSize(heightMeasureSpec);

		refreshViews();

		super.onMeasure(widthMeasureSpec, heightMeasureSpec);

	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
	}

	/**
	 * Function use to add Cards to internal list
	 * 
	 * @param card
	 */
	public void addViewToList(CardView card) {
		listCards.add(card);
	}

	/*public void addViewToList(ConstraintLayout card) {
		listCards.add(card);
		this.addView(card);
	}*/


	/**
	 * Function use to refresh Cards when Collage has measure
	 */
	private void refreshViews() {
		if (!listCards.isEmpty() && !isViewRefresh) {
			int i=0;
			for (CardView cardView : listCards) {

				Log.d("Log", "refreshViews: ");

				ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams(
						cardView.getDrawable().getIntrinsicWidth(), cardView
								.getDrawable().getIntrinsicHeight());

				cardView.setId(Integer.parseInt("10101" + i));
				i++;
/*
				RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
						cardView.getWidth(),cardView.getHeight());*/
				int left = random.nextInt(collageWidth) - collageWidth / 4;
				int top = random.nextInt(collageHeight) - collageHeight / 4;
				/*params.leftMargin = left;
				params.topMargin = top;
				params.rightMargin = -left;
				params.bottomMargin = -top;*/

				if (isCollageFixed)
					cardView.setFixedItem();

				this.addView(cardView,params);

			}
			isViewRefresh = true;
		}
	}

	/**
	 * Methos use to set Collage fixed (Cards cant move)
	 * 
	 * @param fixedCollage
	 */
	public void setFixedCollage(boolean fixedCollage) {
		isCollageFixed = fixedCollage;
	}

	/**
	 * Add Card from Bitmap
	 * 
	 * @param bm
	 */
	public void addCard(Bitmap bm) {

		CardView card = new CardView(mContext);
		card.setImageBitmap(bm);
		addViewToList(card);
	}

	/**
	 * Add Card from Drawable
	 * 
	 * @param drawable
	 */
	public void addCard(Drawable drawable) {

		CardView card = new CardView(mContext);
		card.setImageDrawable(drawable);
		addViewToList(card);
	}

	/**
	 * Add Card from resources
	 * 
	 * @param resId
	 */
	public void addCard(int resId) {

		CardView card = new CardView(mContext);
		card.setImageResource(resId);
		addViewToList(card);
	}

	/**
	 * Create a Collage from list of Bitmaps
	 * 
	 * @param bmList
	 *            List of bitmaps
	 */
	public void createCollageBitmaps(List<Bitmap> bmList) {
		for (Bitmap bm : bmList) {
			addCard(bm);
		}
		isViewRefresh = false;
		refreshViews();
	}

	/**
	 * Create a Collage from list of Drawables
	 * 
	 * @param drawableList
	 *            List of Drawables
	 */
	public void createCollageDrawables(List<Drawable> drawableList) {
		for (Drawable drawable : drawableList) {
			addCard(drawable);
		}
	}

	/**
	 * Create a Collage from list of Resources
	 * 
	 * @param resIdList
	 *            List of resources
	 */
	public void createCollageResources(List<Integer> resIdList) {

		for (Integer res : resIdList) {
			addCard(res.intValue());
		}
	}

	public List<CardView> getListCards() {
		return listCards;
	}
}