package com.scribble.animation.maker.video.effect.myadslibrary.kotlin.appid

enum class IdType {

    GOOGLE,

    FACEBOOK
}