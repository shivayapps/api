package com.codeboy.mediafacer;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Log;

import com.codeboy.mediafacer.mediaHolders.videoContent;
import com.codeboy.mediafacer.mediaHolders.videoFolderContent;
import com.sokolov.androidsizes.ISize;
import com.sokolov.androidsizes.SizeFromVideoFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

public class VideoGet {
    private static VideoGet videoGet;
    private final Context videoContext;
    public static final Uri externalContentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
    public static final Uri internalContentUri = MediaStore.Video.Media.INTERNAL_CONTENT_URI;
    private static Cursor cursor;

    private VideoGet(Context contx) {
        videoContext = contx.getApplicationContext();
    }

    static VideoGet getInstance(Context contx) {
        if (videoGet == null) {
            videoGet = new VideoGet(contx);
        }
        return videoGet;
    }

    @SuppressLint("InlinedApi")
    String[] Projections = {
            MediaStore.Video.Media.DATA,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.ALBUM,
            MediaStore.Video.Media.DATE_TAKEN,
            MediaStore.Video.Media.ARTIST};

    /**
     * Returns an Arraylist of {@link videoContent}
     */
    @SuppressLint("InlinedApi")
    public ArrayList<videoContent> getAllVideoContent(Uri contentLocation) {
        ArrayList<videoContent> allVideo = new ArrayList<>();
        cursor = videoContext.getContentResolver().query(contentLocation, Projections, null, null, "LOWER (" + MediaStore.Video.Media.DATE_TAKEN + ") DESC");//DESC ASC
        try {
            cursor.moveToFirst();
            do {
                videoContent videoContent = new videoContent();

                videoContent.setVideoName(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)));

                videoContent.setPath(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)));

                videoContent.setVideoDuration(cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)));

//                ISize size = new SizeFromVideoFile(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)));
//                videoContent.setDimension(size.width() + " x " + size.height());
//                Log.d("TAG", "getAllVideoContent: "+(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH))));

                videoContent.setVideoSize(cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)));

                int id = cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID));
                videoContent.setVideoId(id);

                int height = cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT));
                int width = cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH));

                videoContent.setDimension("" + width + " X " + height);
                Uri contentUri = Uri.withAppendedPath(contentLocation, String.valueOf(id));
                videoContent.setVideoUri(contentUri.toString());

                videoContent.setAlbum(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.ALBUM)));

                videoContent.setArtist(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.ARTIST)));


                allVideo.add(videoContent);
            } while (cursor.moveToNext());

            cursor.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return allVideo;
    }

    /**
     * Returns an Arraylist of {@link videoContent} in a specific folder
     */
    @SuppressLint("InlinedApi")
    public ArrayList<videoContent> getAllVideoContentByBucket_id(int bucket_id) {
        ArrayList<videoContent> videoContents = new ArrayList<>();
        cursor = videoContext.getContentResolver().query(externalContentUri, Projections,
                MediaStore.Video.Media.BUCKET_ID + " like ? ", new String[]{"%" + bucket_id + "%"}, "LOWER (" + MediaStore.Video.Media.DATE_TAKEN + ") DESC");//DESC
        try {
            cursor.moveToFirst();
            do {
                videoContent videoContent = new videoContent();

                videoContent.setVideoName(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)));

                videoContent.setPath(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)));

                videoContent.setVideoDuration(cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)));

                videoContent.setVideoSize(cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)));

                int id = cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID));
                videoContent.setVideoId(id);

                int resolutionTemp = cursor.getColumnIndex(MediaStore.Video.Media.RESOLUTION);
                videoContent.setDimension(String.valueOf(resolutionTemp));

                Uri contentUri = Uri.withAppendedPath(externalContentUri, String.valueOf(id));
                videoContent.setVideoUri(contentUri.toString());

                videoContent.setAlbum(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.ALBUM)));

                videoContent.setArtist(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.ARTIST)));

                videoContents.add(videoContent);
            } while (cursor.moveToNext());
            cursor.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return videoContents;
    }

    /**
     * Returns an Arraylist of {@link videoFolderContent} with each videoFolderContent having an Arraylist of all it videoContent
     */
    @SuppressLint("InlinedApi")
    public ArrayList<videoFolderContent> getAllVideoFolders(Uri contentLocation) {
        ArrayList<videoFolderContent> allVideoFolders = new ArrayList<>();
        ArrayList<String> videoPaths = new ArrayList<>();
        cursor = videoContext.getContentResolver().query(contentLocation, Projections,
                null, null, "LOWER (" + MediaStore.Video.Media.DATE_TAKEN + ") DESC");//DESC
        try {
            cursor.moveToFirst();
            do {
                videoFolderContent videoFolder = new videoFolderContent();
                videoContent videoContent = new videoContent();

                videoContent.setVideoName(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)));

                videoContent.setPath(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)));

                videoContent.setVideoDuration(cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)));

                videoContent.setVideoSize(cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)));

                int id = cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID));
                videoContent.setVideoId(id);

                Uri contentUri = Uri.withAppendedPath(contentLocation, String.valueOf(id));
                videoContent.setVideoUri(contentUri.toString());

                videoContent.setAlbum(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.ALBUM)));

                videoContent.setArtist(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.ARTIST)));

                String datapath = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA));


                File path = new File(datapath);
                File parent = new File(path.getParent());
                String parentName = parent.getName();
                if (!videoPaths.contains(parentName)) {
                    videoPaths.add(parentName);
                    videoFolder.setBucket_id(parentName);
                    videoFolder.setFolderName(parentName);
                    videoFolder.getVideoFiles().add(videoContent);
                    allVideoFolders.add(videoFolder);
                } else {
                    for (int i = 0; i < allVideoFolders.size(); i++) {
                        if (allVideoFolders.get(i).getBucket_id().equals(parentName)) {
                            allVideoFolders.get(i).getVideoFiles().add(videoContent);
                        }
                    }
                }
            } while (cursor.moveToNext());
            cursor.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return allVideoFolders;
    }

    public int getVideoWidthOrHeight(File file, String widthOrHeight) {
        MediaMetadataRetriever retriever = null;
        Bitmap bmp = null;
        FileInputStream inputStream = null;
        int mWidthHeight = 0;
        try {
            retriever = new MediaMetadataRetriever();
            inputStream = new FileInputStream(file.getAbsolutePath());
            retriever.setDataSource(inputStream.getFD());
            bmp = retriever.getFrameAtTime();
            if (widthOrHeight.equals("width")) {
                mWidthHeight = bmp.getWidth();
            } else {
                mWidthHeight = bmp.getHeight();
            }
        } catch (RuntimeException | IOException e) {
            e.printStackTrace();
        } finally {
            if (retriever != null) {
                retriever.release();
            }
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        return mWidthHeight;
    }
}
