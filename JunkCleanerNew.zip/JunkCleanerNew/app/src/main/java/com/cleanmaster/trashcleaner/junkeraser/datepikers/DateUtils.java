package com.cleanmaster.trashcleaner.junkeraser.datepikers;
import android.content.Context;
import android.text.format.DateFormat;
import android.text.format.Time;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

public class DateUtils {
    public static final TimeZone UTC_TIMEZONE = TimeZone.getTimeZone("UTC");

    public static final String NO_YEAR_DATE_FEB29TH = "--02-29";

    private static final SimpleDateFormat[] DATE_FORMATS = {
            CommonDateUtils.FULL_DATE_FORMAT,
            CommonDateUtils.DATE_AND_TIME_FORMAT,
            new SimpleDateFormat("yyyy-MM-dd'T'HH:mm'Z'", Locale.US),
            new SimpleDateFormat("yyyyMMdd", Locale.US),
            new SimpleDateFormat("yyyyMMdd'T'HHmmssSSS'Z'", Locale.US),
            new SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'", Locale.US),
            new SimpleDateFormat("yyyyMMdd'T'HHmm'Z'", Locale.US),
    };
    static {
        for (SimpleDateFormat format : DATE_FORMATS) {
            format.setLenient(true);
            format.setTimeZone(UTC_TIMEZONE);
        }
        CommonDateUtils.NO_YEAR_DATE_FORMAT.setTimeZone(UTC_TIMEZONE);
    }

    public static Calendar parseDate(String string, boolean mustContainYear) {
        ParsePosition parsePosition = new ParsePosition(0);
        Date date;
        if (!mustContainYear) {
            final boolean noYearParsed;

            if (NO_YEAR_DATE_FEB29TH.equals(string)) {
                return getUtcDate(0, Calendar.FEBRUARY, 29);
            } else {
                synchronized (CommonDateUtils.NO_YEAR_DATE_FORMAT) {
                    date = CommonDateUtils.NO_YEAR_DATE_FORMAT.parse(string, parsePosition);
                }
                noYearParsed = parsePosition.getIndex() == string.length();
            }
            if (noYearParsed) {
                return getUtcDate(date, true);
            }
        }
        for (int i = 0; i < DATE_FORMATS.length; i++) {
            SimpleDateFormat f = DATE_FORMATS[i];
            synchronized (f) {
                parsePosition.setIndex(0);
                date = f.parse(string, parsePosition);
                if (parsePosition.getIndex() == string.length()) {
                    return getUtcDate(date, false);
                }
            }
        }
        return null;
    }
    private static final Calendar getUtcDate(Date date, boolean noYear) {
        final Calendar calendar = Calendar.getInstance(UTC_TIMEZONE, Locale.US);
        calendar.setTime(date);
        if (noYear) {
            calendar.set(Calendar.YEAR, 0);
        }
        return calendar;
    }
    private static final Calendar getUtcDate(int year, int month, int dayOfMonth) {
        final Calendar calendar = Calendar.getInstance(UTC_TIMEZONE, Locale.US);
        calendar.clear();
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month);
        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
        return calendar;
    }
    public static boolean isYearSet(Calendar cal) {

        return cal.get(Calendar.YEAR) > 1;
    }

    public static String formatDate(Context context, String string) {
        return formatDate(context, string, true);
    }

    public static String formatDate(Context context, String string, boolean longForm) {
        if (string == null) {
            return null;
        }
        string = string.trim();
        if (string.length() == 0) {
            return string;
        }
        final Calendar cal = parseDate(string, false);
        if (cal == null) {
            return string;
        }
        final boolean isYearSet = isYearSet(cal);
        final java.text.DateFormat outFormat;
        if (!isYearSet) {
            outFormat = getLocalizedDateFormatWithoutYear(context);
        } else {
            outFormat =
                    longForm ? DateFormat.getLongDateFormat(context) :
                            DateFormat.getDateFormat(context);
        }
        synchronized (outFormat) {
            outFormat.setTimeZone(UTC_TIMEZONE);
            return outFormat.format(cal.getTime());
        }
    }
    public static boolean isMonthBeforeDay(Context context) {
        char[] dateFormatOrder = DateFormat.getDateFormatOrder(context);
        for (int i = 0; i < dateFormatOrder.length; i++) {
            if (dateFormatOrder[i] == 'd') {
                return false;
            }
            if (dateFormatOrder[i] == 'M') {
                return true;
            }
        }
        return false;
    }

    public static java.text.DateFormat getLocalizedDateFormatWithoutYear(Context context) {
        final String pattern = ((SimpleDateFormat) SimpleDateFormat.getDateInstance(
                java.text.DateFormat.LONG)).toPattern();

        final String yearPattern = pattern.contains(
                "de") ? "[^Mm]*[Yy]+[^Mm]*" : "[^DdMm]*[Yy]+[^DdMm]*";
        try {
            // Eliminate the substring in pattern that matches the format for that of year
            return new SimpleDateFormat(pattern.replaceAll(yearPattern, ""));
        } catch (IllegalArgumentException e) {
            return new SimpleDateFormat(
                    DateUtils.isMonthBeforeDay(context) ? "MMMM dd" : "dd MMMM");
        }
    }

    public static Date getNextAnnualDate(Calendar target) {
        final Calendar today = Calendar.getInstance();
        today.setTime(new Date());

        today.set(Calendar.HOUR_OF_DAY, 0);
        today.set(Calendar.MINUTE, 0);
        today.set(Calendar.SECOND, 0);
        today.set(Calendar.MILLISECOND, 0);
        final boolean isYearSet = isYearSet(target);
        final int targetYear = target.get(Calendar.YEAR);
        final int targetMonth = target.get(Calendar.MONTH);
        final int targetDay = target.get(Calendar.DAY_OF_MONTH);
        final boolean isFeb29 = (targetMonth == Calendar.FEBRUARY && targetDay == 29);
        final GregorianCalendar anniversary = new GregorianCalendar();

        anniversary.set(!isYearSet ? today.get(Calendar.YEAR) : targetYear,
                targetMonth, targetDay);

        if (!isYearSet) {
            int anniversaryYear = today.get(Calendar.YEAR);
            if (anniversary.before(today) ||
                    (isFeb29 && !anniversary.isLeapYear(anniversaryYear))) {

                do {
                    anniversaryYear +=1;
                } while (isFeb29 && !anniversary.isLeapYear(anniversaryYear));
                anniversary.set(anniversaryYear, targetMonth, targetDay);
            }
        }
        return anniversary.getTime();
    }

    public static int getDayDifference(Time time, long date1, long date2) {
        time.set(date1);
        int startDay = Time.getJulianDay(date1, time.gmtoff);
        time.set(date2);
        int currentDay = Time.getJulianDay(date2, time.gmtoff);
        return Math.abs(currentDay - startDay);
    }
}