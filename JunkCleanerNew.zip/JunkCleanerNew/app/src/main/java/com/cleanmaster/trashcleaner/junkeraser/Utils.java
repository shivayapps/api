package com.cleanmaster.trashcleaner.junkeraser;

import android.content.Context;
import android.content.pm.PackageManager;

import androidx.room.Room;

import com.cleanmaster.trashcleaner.junkeraser.database.ApplicationDatabase;


public class Utils {


    public static ApplicationDatabase getApplicationDatabase(Context context) {
        return Room.databaseBuilder(context, ApplicationDatabase.class, "application_db").allowMainThreadQueries().build();
    }

    public void disebledOpenAdsBasedOnFireBase(){
        /*if (mFirebaseRemoteConfig != null && mFirebaseRemoteConfig.getBoolean("appopen_resume")){
            AppOpenManager.getInstance().enableAppResume();
        }else {
            AppOpenManager.getInstance().disableAppResume();
        }*/
    }

    public static boolean appInstalledOrNot(Context context) {
        PackageManager pm = context.getPackageManager();
        try {
            pm.getPackageInfo("com.whatsapp", PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
        }
        return false;
    }
}
