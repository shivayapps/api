package com.cleanmaster.trashcleaner.junkeraser.utils

import android.Manifest
import android.app.Activity
import android.app.UiModeManager
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.cleanmaster.trashcleaner.junkeraser.model.MediaModel

class UtilsMethod(var context: Activity) {

    fun checkNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val notifications: Int =
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            notifications == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }

    }

    fun storagePermissionCheckVersionWise() : Boolean{
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            checkStorage10BelowPermission()
        }
    }
    fun setThemeActivity(){
        when(context.SharedPref().GetString(KEY_THEME,"default")){
            "default"->{
                val uiModeManager = context.getSystemService(AppCompatActivity.UI_MODE_SERVICE) as UiModeManager
                if (uiModeManager.nightMode == UiModeManager.MODE_NIGHT_YES) {
                    context.SharedPref().GetBoolean(KEY_THEME1,true)
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                } else {
                    context.SharedPref().GetBoolean(KEY_THEME1,false)
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                }
            }
            "light"->{
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }
            "dark"->{
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            }
        }
    }


    fun getNotificationPermission() {
        ActivityCompat.requestPermissions(context, arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQUEST_CODE)
    }

    fun getStorage10BelowPermission() {
        ActivityCompat.requestPermissions(context, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), REQUEST_CODE_STORAGE)
    }

    fun checkContactPermission(): Boolean {
        val readContact: Int = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS)
        val wriContact: Int = ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_CONTACTS)
        return readContact == PackageManager.PERMISSION_GRANTED && wriContact == PackageManager.PERMISSION_GRANTED
    }

    private fun checkStorage10BelowPermission(): Boolean {
        val readStorage: Int = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE)
        val wriStorage: Int = ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE)
        return readStorage == PackageManager.PERMISSION_GRANTED && wriStorage == PackageManager.PERMISSION_GRANTED
    }

   /* fun permissionSettingDialog() {
        val builder = AlertDialog.Builder(context, R.style.CustomAlertDialog).create()
        val selectItemDialogBinding: PermissionDialogBinding =
            PermissionDialogBinding.inflate(LayoutInflater.from(context))
        builder.setView(selectItemDialogBinding.root)
        builder.setCancelable(true)
        selectItemDialogBinding.tvNo.setOnClickListener {
            builder.dismiss()
        }
        selectItemDialogBinding.tvYes.setOnClickListener {
            builder.dismiss()
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            val uri = Uri.fromParts("package", context.packageName, null)
            intent.data = uri
            context.startActivityForResult(intent, settingRequestCode)
        }
        builder.show()
    }*/

    fun convertFileSize(sizeInBytes: Long): String? {
        val units = arrayOf("B", "KB", "MB", "GB")
        var size = sizeInBytes.toDouble()
        var index = 0
        while (size > 1024 && index < units.size - 1) {
            size /= 1024.0
            index++
        }
        return String.format("%.2f %s", size, units[index])
    }

    fun replaceCurrantString(currantString: String): String {
        return if (currantString.contains("'")) {
            currantString.replace("'", "(~)")
        } else {
            currantString
        }
    }
    fun replaceUpdateString(updateString: String): String {
        return if (updateString.contains("(~)")) {
            updateString.replace("(~)", "'")
        } else {
            updateString
        }
    }

    companion object {
        var settingRequestCode = 1004
        var REQUEST_CODE = 22
        var REQUEST_CODE_CONTACT = 22
        var REQUEST_CODE_STORAGE = 23
        var ISRESUME = false
        var IS_RESUME_FOR_FOLDER = false
        @JvmField
        var INTENT_KEY = "intent_key"
        var KEY_SET_NEXT_SCREEN = "set_next_screen"
        var VAL_SETTING = "val_setting"
        var VAL_PHOTO_FOLDER = "val_photo_folder"
        var KEY_NEXT_FOLDERS = "key_next_folder"
        var VAL_PHOTOS = "val_photos"
        var VAL_VIDEOS = "val_videos"
        var VAL_DOC = "val_doc"
        var VAL_CONTACT = "val_contact"
        var VAL_AUDIO = "val_audio"
        var VAL_SCAN = "val_scan"
        var VAL_PHOTO_FULL_RECOVERED = "val_photo_full_recovered"
        var VAL_CONTACT_RECOVERED = "val_contact_recovered"
        var VAL_DOC_RECOVERED = "val_doc_recovered"
        var VAL_AUDIO_RECOVERED = "val_audio_recovered"
        var VAL_DUPLICATE_RECOVERED = "val_duplicate_recovered"
        var FIRST_TIME_KEY = "first_time_key"
        var LANGUAGE_KEY = "language_key"
        @JvmField
        var INTENT_KEY_SECOND = "intent_key_second"
        var DELETE_KEY = "delete_key"
        var RESTORE_KEY = "restore_key"
        var RECYCLE_KEY = "recycle_key"
        var ARRAYLIST_KEY = "arraylist_key"
        @JvmField
        var POSITION_KEY = "position_key"
        var PATH_KEY = "path_key"
        var FOLDER_NAME_KEY = "folder_name_key"
        var DOCUMENT_TYPES_KEY = "document_types_key"
        var DOCUMENT_TYPES_TITLE_KEY = "document_types_title_key"
        var INTENT_STORAGE = "intent_storage"
        var INTENT_CONTACT = "intent_contact"
        var INTENT_PHOTO = "intent_photo"
        var INTENT_VIDEO = "intent_video"
        var MANAGE_EXTERNAL_REQUEST_CODE = 1005
        var selectMediaList :ArrayList<MediaModel> = ArrayList()
        var path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString()
        @JvmField
        var mediaModelArray : ArrayList<MediaModel> = ArrayList()

    }
}