package com.cleanmaster.trashcleaner.junkeraser.adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ads.module.open.AdconfigApplication;
import com.bumptech.glide.Glide;
import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.model.Apps;
import com.cleanmaster.trashcleaner.junkeraser.utils.ApkInfoExtractor;
import com.google.android.material.button.MaterialButton;

import java.io.File;
import java.text.DecimalFormat;
import java.util.List;

public class ApplicationAdapter extends RecyclerView.Adapter<ApplicationAdapter.Viewholder> {

    Activity context;
    OnclickcheckListener onclickcheckListener;
    List<Apps> appsList;
    boolean issystem = false;
    String applicationPackageName;

    public interface OnclickcheckListener {
        void onClick(int position);

        void onUninstallClick(int position, String packageName, boolean isSystem);
    }

    public ApplicationAdapter(Activity context, OnclickcheckListener onclickcheckListener, List<Apps> appsList, boolean issystem) {
        this.context = context;
        this.onclickcheckListener = onclickcheckListener;
        this.appsList = appsList;
        this.issystem = issystem;
    }

    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.application_list_item, parent, false);
        return new Viewholder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull Viewholder holder, @SuppressLint("RecyclerView") int position) {

        if (issystem) {
            holder.btn_Uninstall.setVisibility(View.GONE);
        } else {
            holder.btn_Uninstall.setVisibility(View.VISIBLE);
        }

        ApkInfoExtractor apkInfoExtractor = new ApkInfoExtractor(context);
        applicationPackageName = appsList.get(position).getApp_package();
        String applicationLabelName = apkInfoExtractor.GetAppName(applicationPackageName);
//        Drawable drawable = apkInfoExtractor.getAppIconByPackageName(applicationPackageName);
        holder.app_name.setText(applicationLabelName);

        final PackageManager pm = context.getPackageManager();
        ApplicationInfo applicationInfo = null;

        try {
            applicationInfo = pm.getApplicationInfo(applicationPackageName, 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        File file = null;
        if (applicationInfo != null) {
            file = new File(applicationInfo.publicSourceDir);
        }
        if (file != null) {
            holder.app_size.setText(formatSize(file.length()));
        }

        Glide.with(context)
                .load(apkInfoExtractor.getAppIconByPackageName(applicationPackageName))
                .into(holder.imgIconApp);

        holder.btn_Uninstall.setOnClickListener(v -> {
            onclickcheckListener.onUninstallClick(position, appsList.get(position).getApp_package(), issystem);
        });

        holder.btn_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AdconfigApplication.Companion.disabledOpenAds();
                Intent i = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                i.addCategory(Intent.CATEGORY_DEFAULT);
                i.setData(Uri.parse("package:" + appsList.get(position).getApp_package()));
                context.startActivity(i);
            }
        });
    }

    public static String formatSize(long j) {
        if (j <= 0) {
            return "";
        }
        double d = (double) j;
        int log10 = (int) (Math.log10(d) / Math.log10(1024.0d));
        return new DecimalFormat("#,##0.#").format(d / Math.pow(1024.0d, (double) log10)) + " " + new String[]{"B", "KB", "MB", "GB", "TB"}[log10];
    }

    @Override
    public int getItemCount() {
        return appsList.size();
    }

    public static class Viewholder extends RecyclerView.ViewHolder {
        TextView app_name, app_size;
        ImageView imgIconApp,btn_info;
        MaterialButton btn_Uninstall;
        FrameLayout native_ad1;

        public Viewholder(@NonNull View itemView) {
            super(itemView);

            app_name = itemView.findViewById(R.id.app_name);
            imgIconApp = itemView.findViewById(R.id.imgIconApp);
            app_size = itemView.findViewById(R.id.app_size);
            btn_Uninstall = itemView.findViewById(R.id.btn_Uninstall);
            btn_info = itemView.findViewById(R.id.btn_info);
            native_ad1 = itemView.findViewById(R.id.native_ad_PE_pkms_small);
        }
    }
}
