package com.cleanmaster.trashcleaner.junkeraser.utils

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.util.Log
import java.util.*


/* loaded from: classes.dex */
class AlarmUtils {
    var calendar: Calendar? = null

    //    lateinit var reminderDao: ReminderDao
    fun addReminder(
        context: Context,
        hour: Int,
        minute: Int,
        day: Int,
        year: Int,
        month: Int
    ) {
        calendar = Calendar.getInstance()
        calendar!!.set(year, month, day, hour, minute, 0)
        calendar!!.set(Calendar.SECOND, 0)
        val targetDate = calendar!!.time

//        var reminderDao = ReminderDatabase.getDatabase(context).getReminderDao()
//        reminderDao.updateDate(calendar!!.timeInMillis.toString() ,day,month,year,hour,minute, reminderModel.id!!)

        registerAlarm(context, targetDate.time)

        Log.d("TAG", "AlarmTime==>$targetDate")
//        showLog("PutInIntent==>", "Day is $day")
//        showLog("PutInIntent==>", "Month is $month")
//        showLog("PutInIntent==>", "Year is $year")
//        showLog("PutInIntent==>", "Hour is $hour")
//        showLog("PutInIntent==>", "Minute is $minute")

        //            Log.d("dasdasdas", "addReminder: id :  " + noteEntity.getId() + "  contants  :  " + noteEntity.getContent() + " reminder id : " + reminderId + " start date  " + noteEntity.getCreateDate() + " put date : " + noteEntity.getPutDate());
//        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager)[AlarmManager.RTC_WAKEUP, targetDate.time] =
//            PendingIntent.getBroadcast(context, reminderId, intent, PendingIntent.FLAG_IMMUTABLE)

//        val activity = PendingIntent.getBroadcast(
//            context,
//            reminderModel.reminderUniqueId!!,
//            intent,
//            PendingIntent.FLAG_IMMUTABLE
//        )
//        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).setAlarmClock(
//            AlarmClockInfo(targetDate.time, activity), activity
//        )
//        context.sendBroadcast(intent)
    }

    fun removeReminder(context: Context, uniqueReminderId: Int) {
        val broadcast = PendingIntent.getBroadcast(
            context,
            uniqueReminderId,
            Intent(context, AlarmReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        broadcast.cancel()
        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(broadcast)

    }

    private fun registerAlarm(context: Context, targetTime: Long) {

        val intent = Intent(context, AlarmReceiver::class.java)
//        intent.putExtra("id", reminderModel.reminderUniqueId)
//        intent.putExtra("reminderTitle", reminderModel.title)
//        intent.putExtra(Constants.REMINDER_UNIQUE_ID, reminderModel.reminderUniqueId.toString())
//        intent.putExtra(Constants.HOUR, reminderModel.hour)
//        intent.putExtra(Constants.MINUTE, reminderModel.minutes)
//        intent.putExtra(Constants.DAY, reminderModel.day)
//        intent.putExtra(Constants.MONTH, reminderModel.month)
//        intent.putExtra(Constants.YEAR, reminderModel.year)
//        intent.putExtra("json", jsonInString)
//        intent.type = reminderModel.reminderUniqueId.toString()
        intent.action = "alarm_action"

        val activity = PendingIntent.getActivity(
            context,
            10000,
            intent,
            PendingIntent.FLAG_IMMUTABLE
        )

        Log.e("TargetTime==>", "" + targetTime)

//        val pi = PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_ONE_SHOT)
//        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).set(AlarmManager.RTC_WAKEUP, targetTime, pi)

        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).setAlarmClock(
            AlarmManager.AlarmClockInfo(targetTime, activity),
            getAlarmIntent(context)
        )
//        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).setExact(AlarmManager.ELAPSED_REALTIME_WAKEUP,targetTime,activity)

    }

    fun unregisterAlarm(context: Context) {

//        try {
//            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
//                return
//            }
////            Thread.sleep(15000)
//            val ci = Intent(AlarmClock.ACTION_DISMISS_ALARM)
////            ci.data = i.getData()
//            var alarmIntent = PendingIntent.getActivity(context, reminderModel.reminderUniqueId!!.toInt(), ci, PendingIntent.FLAG_UPDATE_CURRENT)
//            (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).set(
//                AlarmManager.ELAPSED_REALTIME_WAKEUP,
//                SystemClock.elapsedRealtime(),
//                alarmIntent
//            )
//            Log.d("Dismissed:::::::::::)", "Alarm cancelled")
//        } catch (e: InterruptedException) {
//            e.printStackTrace()
//            Log.d("Exception::::(","$e")
//        }

        val alarmIntent: PendingIntent = getAlarmIntent(context)
        alarmIntent.cancel()

        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(
            PendingIntent.getBroadcast(
                context,
                10000,
                Intent(context, AlarmReceiver::class.java),
                PendingIntent.FLAG_IMMUTABLE
            )
        )

//        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(alarmIntent)
//        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(reminderModel.reminderUniqueId!!.toInt())
    }

    fun getAlarmIntent(
        context: Context,
    ): PendingIntent {
        Log.d("GetAlarmIntent:::", "get an alarm intent")

//        val gson = Gson()
//        val jsonInString = gson.toJson(reminderModel)
        val intent = Intent(context, AlarmReceiver::class.java)
//        intent.putExtra("id", reminderModel.reminderUniqueId)
//        intent.putExtra("reminderTitle", reminderModel.title)
//        intent.putExtra(Constants.REMINDER_UNIQUE_ID, reminderModel.reminderUniqueId.toString())
//        intent.putExtra(Constants.HOUR, reminderModel.hour)
//        intent.putExtra(Constants.MINUTE, reminderModel.minutes)
//        intent.putExtra(Constants.DAY, reminderModel.day)
//        intent.putExtra(Constants.MONTH, reminderModel.month)
//        intent.putExtra(Constants.YEAR, reminderModel.year)
//        intent.putExtra("json", jsonInString)
//        intent.type = reminderModel.reminderUniqueId.toString()
//        intent.action = Constants.ALARM_ACTION
//        log.e("AlarmInfoSent::::", "${intent.extras}")

        return PendingIntent.getBroadcast(
            context,
            10000,
            intent,
            PendingIntent.FLAG_IMMUTABLE
        )
    }
}