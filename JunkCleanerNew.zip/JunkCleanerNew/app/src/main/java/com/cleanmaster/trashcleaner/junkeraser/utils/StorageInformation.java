package com.cleanmaster.trashcleaner.junkeraser.utils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.usage.StorageStats;
import android.app.usage.StorageStatsManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.IPackageStatsObserver;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageStats;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Process;
import android.os.UserHandle;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.text.format.Formatter;
import android.util.Log;

import com.cleanmaster.trashcleaner.junkeraser.model.ModelSizeName;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class StorageInformation {

    public ArrayList<ModelSizeName> sizeNameArrayList = new ArrayList<>();
    long packageSize = 0;
    AppDetails cAppDetails;
    public ArrayList<AppDetails.PackageInfoStruct> res;
    public Context context;
    public long sum;

    public StorageInformation(Context context) {
        this.context = context;
    }

    public void getpackageSize() {
        cAppDetails = new AppDetails((Activity) context);
        res = cAppDetails.getPackages();
        if (res == null)
            return;
        for (int m = 0; m < res.size(); m++) {
            // Create object to access Package Manager
            PackageManager pm = context.getPackageManager();

            Method getPackageSizeInfo;
            try {

                if (Build.VERSION.SDK_INT >= 26) {

                    @SuppressLint("WrongConstant") final StorageStatsManager storageStatsManager = (StorageStatsManager) context.getSystemService(Context.STORAGE_STATS_SERVICE);
                    final StorageManager storageManager = (StorageManager) context.getSystemService(Context.STORAGE_SERVICE);
                    final List<StorageVolume> storageVolumes = storageManager.getStorageVolumes();
                    final UserHandle user = Process.myUserHandle();
                    for (StorageVolume storageVolume : storageVolumes) {
                        final String uuidStr = storageVolume.getUuid();
                        final UUID uuid = uuidStr == null ? StorageManager.UUID_DEFAULT : UUID.fromString(uuidStr);
                        try {
//                            Log.d("AppLog", "storage:" + uuid + " : " + storageVolume.getDescription(context) + " : " + storageVolume.getState());
//                            Log.d("AppLog", "getFreeBytes:" + Formatter.formatShortFileSize(context, storageStatsManager.getFreeBytes(uuid)));
//                            Log.d("AppLog", "getTotalBytes:" + Formatter.formatShortFileSize(context, storageStatsManager.getTotalBytes(uuid)));
                            final StorageStats storageStats = storageStatsManager.queryStatsForPackage(uuid, res.get(m).pname, user);
//                            Log.d("AppLog", "getCacheBytes:" + res.get(m).appname + "   " + res.get(m).pname + "........" + Formatter.formatShortFileSize(context, storageStats.getCacheBytes()));
                           /* Log.d("AppLog", "getAppBytes:" + Formatter.formatShortFileSize(context, storageStats.getAppBytes()) +
                                    " getCacheBytes:" + Formatter.formatShortFileSize(context, storageStats.getCacheBytes()) +
                                    " getDataBytes:" + Formatter.formatShortFileSize(context, storageStats.getDataBytes()));*/

                            ModelSizeName modelSizeName = new ModelSizeName();
                            modelSizeName.setAppname(res.get(m).appname);
                            modelSizeName.setPname(res.get(m).pname);
                            modelSizeName.setIcon(res.get(m).icon);
                            modelSizeName.setCacheSize(Formatter.formatShortFileSize(context, storageStats.getCacheBytes()));

                            sum = sum + storageStats.getCacheBytes();

                            sizeNameArrayList.add(modelSizeName);

                        } catch (PackageManager.NameNotFoundException | IOException e) {
                            e.printStackTrace();
                        }
                    }

                } else {
                    getPackageSizeInfo = pm.getClass().getMethod("getPackageSizeInfo", String.class, IPackageStatsObserver.class);
                    getPackageSizeInfo.invoke(pm, res.get(m).pname, new cachePackState()); //Call the inner class
                }

            } catch (SecurityException | NoSuchMethodException | IllegalArgumentException |
                     IllegalAccessException | InvocationTargetException e) {
                e.printStackTrace();
            }


        }
    }

    private class cachePackState extends IPackageStatsObserver.Stub {
        @Override
        public void onGetStatsCompleted(PackageStats pStats, boolean succeeded) {
            Log.w("Package Name", pStats.packageName + "");
            Log.i("Cache Size", pStats.cacheSize + "");
            Log.v("Data Size", pStats.dataSize + "");
            packageSize = pStats.dataSize + pStats.cacheSize;
            Log.v("Total Cache Size", " " + packageSize);
            Log.v("APK Size", pStats.codeSize + "");

        }
    }


    private boolean isSystemPackage(PackageInfo packageInfo) {
        return ((packageInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0);
    }

    public static boolean isNetworkConnected(Context context) {
        boolean connected = false;
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo nInfo = cm.getActiveNetworkInfo();
            connected = nInfo != null && nInfo.isAvailable() && nInfo.isConnected();
            return connected;
        } catch (Exception e) {
            Log.d("Connectivity Exception", e.getMessage());
        }
        return connected;
    }
}