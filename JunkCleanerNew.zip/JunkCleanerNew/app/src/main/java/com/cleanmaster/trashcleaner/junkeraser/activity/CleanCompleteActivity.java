package com.cleanmaster.trashcleaner.junkeraser.activity;

import static android.content.ContentValues.TAG;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.ads.module.adutills.AdLoaderClass;
import com.ads.module.adutills.NativeLoadWithShows;
import com.cleanmaster.trashcleaner.junkeraser.R;
import com.google.android.material.card.MaterialCardView;

public class CleanCompleteActivity extends BaseActivity {
    private SharedPreferences sharedPreferences;
    public int timecount = 24;
    int visible_counter =0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clean_complete);

        ImageView btn_back = findViewById(R.id.btn_back);
        btn_back.setOnClickListener(v -> onBackPressed());

        String total_clean_size = getIntent().getStringExtra("total_clean_size");

        TextView tvTotalSize = findViewById(R.id.tvTotalSize);
        TextView tvTotalSizeEmpty = findViewById(R.id.tvTotalSizeEmpty);
        tvTotalSize.setText(total_clean_size);
        tvTotalSizeEmpty.setText(total_clean_size);

        TextView btnCleanStorage = findViewById(R.id.btnCleanStorage);
        TextView btnCleanWhatsapp = findViewById(R.id.btnCleanWhatsapp);
        MaterialCardView cardWhatsapp = findViewById(R.id.cardWhatsapp);
        MaterialCardView cardStorage = findViewById(R.id.cardStorage);
        TextView tvRecomondedText = findViewById(R.id.tvRecomondedText);

        sharedPreferences = getSharedPreferences("preference_trash", MODE_PRIVATE);
        long currenttimeStorage = sharedPreferences.getLong("currenttime_storage", timecount);
        long currenttimeWhatsapp = sharedPreferences.getLong("currenttime_whatsapp", timecount);

        int storage = getHours(currenttimeStorage);
        int whatsapp = getHours(currenttimeWhatsapp);

        if (storage >= timecount) {
            visible_counter ++;
            cardStorage.setVisibility(View.VISIBLE);
        } else {
            visible_counter --;
            cardStorage.setVisibility(View.GONE);
        }

        if (whatsapp >= timecount) {
            visible_counter ++;
            cardWhatsapp.setVisibility(View.VISIBLE);
        } else {
            visible_counter --;
            cardWhatsapp.setVisibility(View.GONE);
        }

        if(visible_counter==-2){
            tvRecomondedText.setVisibility(View.GONE);
        }

        btnCleanStorage.setOnClickListener(v -> {
            SharedPreferences.Editor myEdit = sharedPreferences.edit();
            myEdit.putLong("currenttime_storage", System.currentTimeMillis());
            myEdit.apply();
            new AdLoaderClass().showInterstitialAdsFinish(CleanCompleteActivity.this,new Intent(CleanCompleteActivity.this, StorageCleanerActivity.class));
//            startActivity(new Intent(CleanCompleteActivity.this, StorageCleanerActivity.class));
            finish();
        });

        btnCleanWhatsapp.setOnClickListener(v -> {
            SharedPreferences.Editor myEdit = sharedPreferences.edit();
            myEdit.putLong("currenttime_whatsapp", System.currentTimeMillis());
            myEdit.apply();

            new AdLoaderClass().showInterstitialAdsFinish(CleanCompleteActivity.this,new Intent(CleanCompleteActivity.this, AppCleanLastFolderWiseDataActivity.class).putExtra("AppName", "WhatsApp"));
//            startActivity(new Intent(CleanCompleteActivity.this, AppCleanLastFolderWiseDataActivity.class).putExtra("AppName", "WhatsApp"));
            finish();
        });

        loadNativeAd();
    }

    private void loadNativeAd() {
        FrameLayout banner_layout = findViewById(R.id.native_ad_PE_pkms_small);
        new NativeLoadWithShows(CleanCompleteActivity.this).showNativeAdsShimmerEffects(CleanCompleteActivity.this,  banner_layout, 1);
        new NativeLoadWithShows(CleanCompleteActivity.this).showNativeBottomAlways(CleanCompleteActivity.this, banner_layout,null);
    }
    public int getHours(long time) {
        long millis = System.currentTimeMillis() - time;
        int hours = (int) (millis / (1000 * 60 * 60));
        Log.d(TAG, "getHours: " + hours);
        int mins = (int) ((millis / (1000 * 60)) % 60);
        return hours;
    }
}