package com.cleanmaster.trashcleaner.junkeraser.database;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "block_table")
public class BlockListModel {

    @PrimaryKey(autoGenerate = true)
    int id = 0;
    @ColumnInfo(name = "package_name")
    String package_name;
    @ColumnInfo(name = "status")
    String status;

    public BlockListModel(String package_name, String status) {
        this.package_name = package_name;
        this.status = status;
    }

    public String getPackage_name() {
        return this.package_name;
    }

    public void setPackage_name(String value) {
        this.package_name = value;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
