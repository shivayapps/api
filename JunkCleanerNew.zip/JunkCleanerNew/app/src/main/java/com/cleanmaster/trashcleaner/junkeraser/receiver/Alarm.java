package com.cleanmaster.trashcleaner.junkeraser.receiver;

import static android.content.Context.ALARM_SERVICE;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.BatteryManager;
import android.os.SystemClock;
import android.view.View;
import android.widget.RemoteViews;

import androidx.core.app.NotificationManagerCompat;
import androidx.room.Room;

import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.Utils;
import com.cleanmaster.trashcleaner.junkeraser.database.ApplicationDatabase;
import com.cleanmaster.trashcleaner.junkeraser.database.BatteryModel;

import java.text.SimpleDateFormat;
import java.util.Date;
public class Alarm extends BroadcastReceiver {
    Context context;
    private NotificationManagerCompat notificationManager;
    ApplicationDatabase applicationDatabase;
    SharedPreferences sharedPreferences;

    @Override
    public void onReceive(Context context, Intent intent) {
        this.context = context;
        //applicationDatabase = Room.databaseBuilder(context, ApplicationDatabase.class, "application_db").allowMainThreadQueries().build();
        applicationDatabase = Utils.getApplicationDatabase(context);
        notificationManager = NotificationManagerCompat.from(context);
        sharedPreferences = context.getSharedPreferences("intentData", Context.MODE_PRIVATE);

        stopAlert();
        startAlert();

        for (int i = 0; i < applicationDatabase.batteryDao().getAllBatteryList().size(); i++) {
            if (applicationDatabase.batteryDao().getAllBatteryList().size() >= 75) {
                applicationDatabase.batteryDao().deleteByUserId(applicationDatabase.batteryDao().getAllBatteryList().get(i).getId());
            }
        }

        int level = get_battery();
        String date = getDate();
        int minute = getminute();
        int hours = gethours();
        int sec = getsecound();


        if (hours <= 24 && level <= 100) {

            for (int i = 0; i < applicationDatabase.batteryDao().getAllBatteryList().size(); i++) {
                if (applicationDatabase.batteryDao().getAllBatteryList().get(i).getDate().equals(date)) {
                    if (applicationDatabase.batteryDao().getAllBatteryList().get(i).getHours() == hours) {
                        applicationDatabase.batteryDao().deleteByUserId(applicationDatabase.batteryDao().getAllBatteryList().get(i).getId());
                    }
                }
            }
            applicationDatabase.batteryDao().battery_insert(new BatteryModel(hours, level, date));
        }

        if (hours == 1) {
            if (sharedPreferences != null && sharedPreferences.getInt("phone_cooler", 99) == 1) {
                setminiNotification("Phone is OverHeating", "Your Phone is Getting too Hot, so It's required Cooling down", true);
            } else {
                setminiNotification("Phone is OverHeating", "Your Phone is Getting too Hot, so It's required Cooling down", true);
            }
        }

    }

    public void startAlert() {

        Intent intent = new Intent(context, Alarm.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 234, intent, PendingIntent.FLAG_IMMUTABLE);
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(ALARM_SERVICE);
        if (alarmManager != null) {
            long ALARM_TRIGGER_AT_TIME = SystemClock.elapsedRealtime();

            alarmManager.setRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, ALARM_TRIGGER_AT_TIME, 1000 * 60 * 10, pendingIntent);
//            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, 1000 * 20, 1000 * 20, pendingIntent);
        }
    }

    public void stopAlert() {
        Intent intent = new Intent(context, Alarm.class);
        PendingIntent sender = PendingIntent.getBroadcast(context, 234, intent, PendingIntent.FLAG_IMMUTABLE);
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(ALARM_SERVICE);
        if (alarmManager != null) {
            alarmManager.cancel(sender);
        }
    }

    public void setminiNotification(String t1, String t2, boolean isbuttonshow) {

        RemoteViews collapsedView = new RemoteViews(context.getPackageName(),
                R.layout.notification_collapsed);

        Intent clickIntent = new Intent(context, NotificationReceiver.class);
        PendingIntent clickPendingIntent = PendingIntent.getBroadcast(context,
                0, clickIntent, PendingIntent.FLAG_IMMUTABLE);

        collapsedView.setTextViewText(R.id.text_view_collapsed_1, t1);
        collapsedView.setTextViewText(R.id.text_view_collapsed_2, t2);
        if (isbuttonshow) {
            collapsedView.setViewVisibility(R.id.btn_clean, View.VISIBLE);
        } else {
            collapsedView.setViewVisibility(R.id.btn_clean, View.GONE);
        }
    }

    private int gethours() {
        Date date = new Date();
        SimpleDateFormat gethours = new SimpleDateFormat("HH");
        return Integer.parseInt(gethours.format(date));
    }

    private int getsecound() {
        Date date = new Date();
        SimpleDateFormat getsecound = new SimpleDateFormat("ss");
        return Integer.parseInt(getsecound.format(date));
    }

    private int getminute() {
        Date date = new Date();
        SimpleDateFormat getMinute = new SimpleDateFormat("mm");
        return Integer.parseInt(getMinute.format(date));
    }

    private String getDate() {
        Date date = new Date();
        SimpleDateFormat getdate = new SimpleDateFormat("dd:MM:yyyy");
        return getdate.format(date);
    }

    public int get_battery() {
        IntentFilter iFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = context.registerReceiver(null, iFilter);

        return batteryStatus != null ? batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) : -1;
    }
}