package com.cleanmaster.trashcleaner.junkeraser.utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;
import android.util.Pair;


import com.cleanmaster.trashcleaner.junkeraser.R;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Objects;

public class Util {

//    public ArrayList<ModelSizeName> sizeNameArrayList = new ArrayList<>();
    long packageSize = 0;
    AppDetails cAppDetails;
    public ArrayList<AppDetails.PackageInfoStruct> res;
    public Context context;
    public long sum;

    public Util(Context context) {
        this.context = context;
    }

//    public void getpackageSize() {
//        cAppDetails = new AppDetails((Activity) context);
//        res = cAppDetails.getPackages();
//        if (res == null)
//            return;
//        for (int m = 0; m < res.size(); m++) {
//            // Create object to access Package Manager
//            PackageManager pm = context.getPackageManager();
//
//            Method getPackageSizeInfo;
//            try {
//
//                if (Build.VERSION.SDK_INT >= 26) {
//
//                    @SuppressLint("WrongConstant") final StorageStatsManager storageStatsManager = (StorageStatsManager) context.getSystemService(Context.STORAGE_STATS_SERVICE);
//                    final StorageManager storageManager = (StorageManager) context.getSystemService(Context.STORAGE_SERVICE);
//                    final List<StorageVolume> storageVolumes = storageManager.getStorageVolumes();
//                    final UserHandle user = Process.myUserHandle();
//                    for (StorageVolume storageVolume : storageVolumes) {
//                        final String uuidStr = storageVolume.getUuid();
//                        final UUID uuid = uuidStr == null ? StorageManager.UUID_DEFAULT : UUID.fromString(uuidStr);
//                        try {
////                            Log.d("AppLog", "storage:" + uuid + " : " + storageVolume.getDescription(context) + " : " + storageVolume.getState());
////                            Log.d("AppLog", "getFreeBytes:" + Formatter.formatShortFileSize(context, storageStatsManager.getFreeBytes(uuid)));
////                            Log.d("AppLog", "getTotalBytes:" + Formatter.formatShortFileSize(context, storageStatsManager.getTotalBytes(uuid)));
//                            final StorageStats storageStats = storageStatsManager.queryStatsForPackage(uuid, res.get(m).pname, user);
////                            Log.d("AppLog", "getCacheBytes:" + res.get(m).appname + "   " + res.get(m).pname + "........" + Formatter.formatShortFileSize(context, storageStats.getCacheBytes()));
//                           /* Log.d("AppLog", "getAppBytes:" + Formatter.formatShortFileSize(context, storageStats.getAppBytes()) +
//                                    " getCacheBytes:" + Formatter.formatShortFileSize(context, storageStats.getCacheBytes()) +
//                                    " getDataBytes:" + Formatter.formatShortFileSize(context, storageStats.getDataBytes()));*/
//
//                            ModelSizeName modelSizeName = new ModelSizeName();
//                            modelSizeName.setAppname(res.get(m).appname);
//                            modelSizeName.setPname(res.get(m).pname);
//                            modelSizeName.setIcon(res.get(m).icon);
//                            modelSizeName.setCacheSize(Formatter.formatShortFileSize(context, storageStats.getCacheBytes()));
//
//                            sum = sum + storageStats.getCacheBytes();
//
//                            sizeNameArrayList.add(modelSizeName);
//
//                        } catch (PackageManager.NameNotFoundException | IOException e) {
//                            e.printStackTrace();
//                        }
//                    }
//
//                } else {
//                    getPackageSizeInfo = pm.getClass().getMethod("getPackageSizeInfo", String.class, IPackageStatsObserver.class);
//                    getPackageSizeInfo.invoke(pm, res.get(m).pname, new cachePackState()); //Call the inner class
//                }
//
//            } catch (SecurityException | NoSuchMethodException | IllegalArgumentException |
//                     IllegalAccessException | InvocationTargetException e) {
//                e.printStackTrace();
//            }
//
//
//        }
//    }

//    private class cachePackState extends IPackageStatsObserver.Stub {
//        @Override
//        public void onGetStatsCompleted(PackageStats pStats, boolean succeeded) {
//            Log.w("Package Name", pStats.packageName + "");
//            Log.i("Cache Size", pStats.cacheSize + "");
//            Log.v("Data Size", pStats.dataSize + "");
//            packageSize = pStats.dataSize + pStats.cacheSize;
//            Log.v("Total Cache Size", " " + packageSize);
//            Log.v("APK Size", pStats.codeSize + "");
//
//        }
//    }

    @SuppressLint("DefaultLocale")
    public static Pair<String, String> getDataSizeWithPrefix(Context context, double size) {
        String sizePrefix = context.getString(R.string.size_b);
        double finalSize = size;
        if (size >= 1024) {
            double sizeKb = size / 1024;
//            sizePrefix = "KB";
            sizePrefix = context.getString(R.string.size_kb);
            finalSize = sizeKb;
            if (sizeKb >= 1024) {
//                sizePrefix = "MB";
                double sizeMB = sizeKb / 1024;
                sizePrefix = context.getString(R.string.size_mb);
                finalSize = sizeMB;
                if (sizeMB >= 1024) {
                    double sizeGb = sizeMB / 1024;
//                    sizePrefix = "GB";
                    sizePrefix = context.getString(R.string.size_gb);
                    finalSize = sizeGb;
                }
            }
        }
        return new Pair<>(String.format(Locale.ENGLISH, "%.2f", finalSize), sizePrefix);
    }

    private boolean isSystemPackage(PackageInfo packageInfo) {
        return ((packageInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0);
    }

    public static class AllPackagesFilter implements FileFilter {
        @Override
        public boolean accept(File pathname) {
            String path = pathname.getPath();
            return (pathname.getAbsolutePath().endsWith(".apk") ||
                    pathname.getAbsolutePath().endsWith(".xapk"));
        }
    }

    public static class AllTempLogsFilter implements FileFilter {

        ArrayList<String> filters;

        public AllTempLogsFilter(ArrayList<String> filters) {
            this.filters = filters;
        }

        @Override
        public boolean accept(File pathname) {
            String path = pathname.getAbsolutePath();
            for (String filter : filters)
                if (path.toLowerCase().matches(filter.toLowerCase()) && !path.contains("Backup And Recovery"))
                    return true;
            return false;
        }
    }

    public static class AllEmptyFilter implements FileFilter {
        @Override
        public boolean accept(File pathname) {
            if (isDirectoryEmpty(pathname)) return true;
            return false;
        }
    }

    private static boolean isDirectoryEmpty(File directory) {
        if (directory.list() != null && directory.list() != null)
            return Objects.requireNonNull(directory.list()).length == 0;
        else return false;
    }

    public static class AllUninstalledFilter implements FileFilter {
        ArrayList<String> filterInstalled;

        public AllUninstalledFilter(ArrayList<String> filterInstalled) {
            this.filterInstalled = filterInstalled;
        }

        @Override
        public boolean accept(File pathname) {
            if (pathname.getParentFile() != null && pathname.getParentFile().getParentFile() != null) {
                if (pathname.getParentFile().getName().equals("data") && pathname.getParentFile().getParentFile().getName().equals("Android"))
                    if (!filterInstalled.contains(pathname.getName()) && !pathname.getName().equals(".nomedia"))
                        return true;
            }

            return false;
        }
    }

    public static boolean isNetworkConnected(Context context) {
        boolean connected = false;
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo nInfo = cm.getActiveNetworkInfo();
            connected = nInfo != null && nInfo.isAvailable() && nInfo.isConnected();
            return connected;
        } catch (Exception e) {
            Log.d("Connectivity Exception", e.getMessage());
        }
        return connected;
    }
}