package com.cleanmaster.trashcleaner.junkeraser.activity;

import static android.content.ContentValues.TAG;
import static com.cleanmaster.trashcleaner.junkeraser.activity.SystemInfoActivity.getAvailableInternalMemorySize;
import static com.cleanmaster.trashcleaner.junkeraser.activity.SystemInfoActivity.getTotalInternalMemorySize;

import androidx.annotation.RequiresApi;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StatFs;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.ads.module.adutills.NativeLoadWithShows;
import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.Utils;
import com.cleanmaster.trashcleaner.junkeraser.helper.LocaleHelper;
import com.cleanmaster.trashcleaner.junkeraser.model.ProgressItem;
import com.cleanmaster.trashcleaner.junkeraser.model.doumentContent;
import com.cleanmaster.trashcleaner.junkeraser.utils.CustomProgressBar;
import com.codeboy.mediafacer.AudioGet;
import com.codeboy.mediafacer.MediaFacer;
import com.codeboy.mediafacer.PictureGet;
import com.codeboy.mediafacer.VideoGet;
import com.codeboy.mediafacer.mediaHolders.audioContent;
import com.codeboy.mediafacer.mediaHolders.pictureContent;
import com.codeboy.mediafacer.mediaHolders.videoContent;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.concurrent.Executors;

import im.dacer.androidcharts.PieHelper;

public class StorageCleanerActivity extends BaseActivity {
    String[] imageExtensions = new String[]{".jpg", ".jpeg", ".png", ".gif", ".bmp"};
    File storageDirectory = Environment.getExternalStorageDirectory();

    File storageDirectoryDownload = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
    ArrayList<File> fileListdownload = new ArrayList<>();
    ArrayList<File> fileList = new ArrayList<>();
    public static ArrayList<pictureContent> allPhotos;
    public static ArrayList<videoContent> allVideo;
    public static ArrayList<audioContent> allAudio;
    public static ArrayList<doumentContent> allDocuments;
    public static ArrayList<doumentContent> largeFileDocuments = new ArrayList<>();

    ArrayList<PieHelper> donutSectionList = new ArrayList<>();

    public static ArrayList<doumentContent> allDownloads = new ArrayList<>();
    private long ImageSum, VideoSum, AudioSum, DocumentSum, ArchivesSum, DownloadSum;
    //    private DonutProgressView donutProgressView;
    private RelativeLayout progressbar;
    private String imageSize;
    private String videoSize;
    private String audioSize;
    private String documentsize;
    private String largesize;
    private String downloadsize;
    private float imagepercentage;
    private float videopercentage;
    private float audiopercentage;
    private float documentpercentage;
    private float largepercentage;
    private float archivepercentage;
    private float downloadpercentage;
    private float systemsize;
    private float systempercentage;
    private TextView tvImageSize;
    private TextView tvVideoSize;
    private TextView tvAudioSize;
    private TextView tvDocumentsSize;
    private TextView tvLargeFileSize;
    private TextView tvDownloadSize;
    private TextView tvSystemSize;
    private ImageView app_lottie;
    private TextView scanning_File;
//    private PieView pieView;

    private CustomProgressBar seekbar;
    private ArrayList<ProgressItem> progressItemList;
    private ProgressItem mProgressItem;
    private ProgressBar progressBarImage;
    private ProgressBar progressBarVideo;
    private ProgressBar progressBarAudio;
    private ProgressBar progressBarDocuments;
    private ProgressBar progressBarLargeFiles;
    private ProgressBar progressBarDownloads;

    @RequiresApi(api = Build.VERSION_CODES.R)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_storage_cleaner);

        ImageView btn_back = findViewById(R.id.btn_back);
        btn_back.setOnClickListener(v -> onBackPressed());

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                Uri uri = Uri.fromParts("package", getPackageName(), null);
                intent.setData(uri);
                startActivityForResult(intent, 1000);
            }
        }

        seekbar = findViewById(R.id.seekBar0);
        seekbar.getThumb().mutate().setAlpha(0);

        LinearLayout cardDownloads = findViewById(R.id.cardDownloads);
        LinearLayout cardAudio = findViewById(R.id.cardAudio);
        LinearLayout cardImages = findViewById(R.id.cardImages);
        LinearLayout cardVideo = findViewById(R.id.cardVideo);
        LinearLayout cardDocuments = findViewById(R.id.cardDocuments);
        LinearLayout cardLargeFiles = findViewById(R.id.cardLargeFiles);

        tvImageSize = findViewById(R.id.tvImageSize);
        tvVideoSize = findViewById(R.id.tvVideoSize);
        tvAudioSize = findViewById(R.id.tvAudioSize);
        tvDocumentsSize = findViewById(R.id.tvDocumentsSize);
        tvLargeFileSize = findViewById(R.id.tvLargeFileSize);
        tvDownloadSize = findViewById(R.id.tvDownloadSize);
        tvSystemSize = findViewById(R.id.tvSystemSize);
        scanning_File = findViewById(R.id.scanning_File);
        app_lottie = findViewById(R.id.app_lottie);
        progressbar = findViewById(R.id.progressbar);
        loadNative();

        Executors.newSingleThreadExecutor().execute(() -> {
            runOnUiThread(() -> progressbar.setVisibility(View.VISIBLE));

            float usedstorage = getTotalInternalMemorySize1() - getAvailableInternalMemorySize1();

            cardImages.setOnClickListener(v -> startActivity(new Intent(StorageCleanerActivity.this, pictureActivity.class)));
            cardVideo.setOnClickListener(v -> startActivity(new Intent(StorageCleanerActivity.this, videoActivity.class)));
            cardAudio.setOnClickListener(v -> startActivity(new Intent(StorageCleanerActivity.this, audioActivity.class)));
            cardDocuments.setOnClickListener(v -> startActivity(new Intent(StorageCleanerActivity.this, documentActivity.class)));
            cardLargeFiles.setOnClickListener(v -> startActivity(new Intent(StorageCleanerActivity.this, largeFileActivity.class)));
            cardDownloads.setOnClickListener(v -> startActivity(new Intent(StorageCleanerActivity.this, downloadFilesActivity.class)));

            getLargeFile();
            getDownloadFile();

            imageSize = convertFileSize(storageTotalImages());
            videoSize = convertFileSize(storageTotalVideo());
            audioSize = convertFileSize(storageTotalAudio());
            documentsize = convertFileSize(storageTotalDocument());
            largesize = convertFileSize(storageTotalArcgivesFile());
            downloadsize = convertFileSize(storageTotalDownload());

            long totalSum = ImageSum + VideoSum + AudioSum + DocumentSum + ArchivesSum + DownloadSum;

            imagepercentage = (ImageSum * 100) / totalSum;
            videopercentage = (VideoSum * 100) / totalSum;
            audiopercentage = (AudioSum * 100) / totalSum;
            documentpercentage = (DocumentSum * 100) / totalSum;
            archivepercentage = (ArchivesSum * 100) / totalSum;
            downloadpercentage = (DownloadSum * 100) / totalSum;

            progressBarImage = findViewById(R.id.progressBarImage);
            progressBarVideo = findViewById(R.id.progressBarVideo);
            progressBarAudio = findViewById(R.id.progressBarAudio);
            progressBarDocuments = findViewById(R.id.progressBarDocuments);
            progressBarLargeFiles = findViewById(R.id.progressBarLargeFiles);
            progressBarDownloads = findViewById(R.id.progressBarDownloads);

            progressBarImage.setProgress((int) imagepercentage);
            progressBarVideo.setProgress((int) videopercentage);
            progressBarAudio.setProgress((int) audiopercentage);
            progressBarDocuments.setProgress((int) documentpercentage);
            progressBarLargeFiles.setProgress((int) archivepercentage);
            progressBarDownloads.setProgress((int) downloadpercentage);

            initDataToSeekbar(imagepercentage, videopercentage, audiopercentage, documentpercentage, archivepercentage, downloadpercentage);

            runOnUiThread(() -> {
                scanning_File.setText(R.string.scanning_complete);
                app_lottie.setImageResource(R.drawable.ic_done_lottie);
                Handler handler = new Handler();
                handler.postDelayed(() -> progressbar.setVisibility(View.GONE), 2000);

                tvSystemSize.setText(" " + getAvailableInternalMemorySize() + "/" + getTotalInternalMemorySize() + "");

                tvImageSize.setText(imageSize);
                tvVideoSize.setText(videoSize);
                tvAudioSize.setText(audioSize);

                tvDocumentsSize.setText(documentsize);
                tvLargeFileSize.setText(largesize);
                tvDownloadSize.setText(downloadsize);
                Log.d(TAG, "onCreate: " + imageSize);

//                    fillInitialData(imagepercentage, videopercentage, audiopercentage, documentpercentage, archivepercentage, downloadpercentage);

            });
        });
    }

    public static float getAvailableInternalMemorySize1() {
        File path = Environment.getDataDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSizeLong();
        long availableBlocks = stat.getAvailableBlocksLong();
        return formatFileSize(availableBlocks * blockSize);
    }

    public static float getTotalInternalMemorySize1() {
        File path = Environment.getDataDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSizeLong();
        long totalBlocks = stat.getBlockCountLong();
        return formatFileSize(totalBlocks * blockSize);
    }

    public static float formatFileSize(long size) {
        String suffix = null;
        double value = size;
        if (size >= 1024) {
//            suffix = "KB";
            value = size / 1024.0;
            if (value >= 1024) {
//                suffix = "MB";
                value = value / 1024.0;
                /*if (value >= 1024) {
//                    suffix = "GB";
                    value = value / 1024.0;
                }*/
            }
        }
        return (float) value;
    }

    public long storageTotalImagesResume() {
        ImageSum = 0;
        if (allPhotos != null && allPhotos.size() > 0) {
            for (int i = 0; i < allPhotos.size(); i++) {
                ImageSum = ImageSum + allPhotos.get(i).getPictureSize();
            }
        }

        return ImageSum;
    }

    public long storageTotalVideoResume() {
        VideoSum = 0;
        if (allVideo != null && allVideo.size() > 0) {
            for (int i = 0; i < allVideo.size(); i++) {
                VideoSum = VideoSum + allVideo.get(i).getVideoSize();
            }
        }

        return VideoSum;
    }

    public long storageTotalAudioResume() {
        AudioSum = 0;
        if (allAudio != null && allAudio.size() > 0) {
            for (int i = 0; i < allAudio.size(); i++) {
                AudioSum = AudioSum + allAudio.get(i).getMusicSize();
            }
        }

        return AudioSum;
    }

    public long storageTotalDocumentResume() {
        DocumentSum = 0;
        if (allDocuments != null && allDocuments.size() > 0) {
            for (int i = 0; i < allDocuments.size(); i++) {
                DocumentSum = DocumentSum + allDocuments.get(i).getDocumentSize();
            }
        }

        return DocumentSum;
    }

    /*public long storageTotalLargeFileResume() {
        LargeSum = 0;
        if (largeFileDocuments != null && largeFileDocuments.size() > 0) {
            for (int i = 0; i < largeFileDocuments.size(); i++) {
                LargeSum = LargeSum + largeFileDocuments.get(i).getDocumentSize();
            }
        }
        return LargeSum;
    }*/

    public long storageTotalArchiveFileResume() {
        ArchivesSum = 0;
        if (largeFileDocuments != null && largeFileDocuments.size() > 0) {
            for (int i = 0; i < largeFileDocuments.size(); i++) {
                ArchivesSum = ArchivesSum + largeFileDocuments.get(i).getDocumentSize();
            }
        }

        return ArchivesSum;
    }

    public long storageTotalDownloadResume() {
        DownloadSum = 0;
        if (allDownloads != null && allDownloads.size() > 0) {
            for (int i = 0; i < allDownloads.size(); i++) {
                DownloadSum = DownloadSum + allDownloads.get(i).getDocumentSize();
            }
        }
        return DownloadSum;
    }

    public long storageTotalImages() {
        ImageSum = 0;
        allPhotos = MediaFacer
                .withPictureContex(StorageCleanerActivity.this)
                .getAllPictureContents(PictureGet.externalContentUri);

        for (int i = 0; i < allPhotos.size(); i++) {
            ImageSum = ImageSum + allPhotos.get(i).getPictureSize();
        }

        return ImageSum;
    }

    public long storageTotalVideo() {
        VideoSum = 0;
        allVideo = MediaFacer
                .withVideoContex(StorageCleanerActivity.this)
                .getAllVideoContent(VideoGet.externalContentUri);

        for (int i = 0; i < allVideo.size(); i++) {
            VideoSum = VideoSum + allVideo.get(i).getVideoSize();
        }

        return VideoSum;
    }

    public long storageTotalAudio() {
        AudioSum = 0;
        allAudio = MediaFacer
                .withAudioContex(StorageCleanerActivity.this)
                .getAllAudioContent(AudioGet.externalContentUri);

        for (int i = 0; i < allAudio.size(); i++) {
            AudioSum = AudioSum + allAudio.get(i).getMusicSize();
        }

        return AudioSum;
    }

    public long storageTotalDocument() {
        DocumentSum = 0;
        allDocuments = getAllDocuments();

        for (int i = 0; i < allDocuments.size(); i++) {
            DocumentSum = DocumentSum + allDocuments.get(i).getDocumentSize();
        }

        return DocumentSum;
    }

    /*public long storageTotalLargeFile() {
        LargeSum = 0;
        if (largeFileDocuments != null && largeFileDocuments.size() > 0) {
            for (int i = 0; i < largeFileDocuments.size(); i++) {
                LargeSum = LargeSum + largeFileDocuments.get(i).getDocumentSize();
            }
        }
        return LargeSum;
    }*/

    public long storageTotalArcgivesFile() {
        ArchivesSum = 0;
        if (largeFileDocuments != null && largeFileDocuments.size() > 0) {
            for (int i = 0; i < largeFileDocuments.size(); i++) {
                ArchivesSum = ArchivesSum + largeFileDocuments.get(i).getDocumentSize();
            }
        }
        return ArchivesSum;
    }

    public long storageTotalDownload() {
        DownloadSum = 0;
        if (allDownloads != null && allDownloads.size() > 0) {
            for (int i = 0; i < allDownloads.size(); i++) {
                DownloadSum = DownloadSum + allDownloads.get(i).getDocumentSize();
            }
        }
        return DownloadSum;
    }

    public static String convertFileSize(long sizeInBytes) {
        String[] units = {"B", "KB", "MB", "GB"};
        double size = sizeInBytes;
        int index = 0;
        while (size > 1024 && index < units.length - 1) {
            size /= 1024;
            index++;
        }
        return String.format("%.2f %s", size, units[index]);
    }

    private ArrayList<doumentContent> getAllDocuments() {
        ArrayList<doumentContent> doumentContentsList = new ArrayList<>();
        Uri uri = MediaStore.Files.getContentUri("external");
        String[] projection = new String[]{
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DISPLAY_NAME,
                MediaStore.Files.FileColumns.SIZE,
                MediaStore.Audio.Media.DATA,
                MediaStore.Files.FileColumns.MIME_TYPE
        };
        String selection = MediaStore.Files.FileColumns.MEDIA_TYPE + "=" + MediaStore.Files.FileColumns.MEDIA_TYPE_DOCUMENT;
        String sortOrder = MediaStore.Files.FileColumns.SIZE + " DESC";

        Cursor cursor = getContentResolver().query(uri, projection, selection, null, sortOrder);

        if (cursor != null) {
            while (cursor.moveToNext()) {

                doumentContent audioContent = new doumentContent();

                audioContent.setDocumentId(cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)));
                audioContent.setName(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)));
                String type = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE));
                audioContent.setDocumentSize(cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)));
                audioContent.setFilePath(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)));

                doumentContentsList.add(audioContent);
                // Do something with the id, name, and type of each document file
            }

            cursor.close();
        }
        return doumentContentsList;
    }

    public void getDownloadFile() {
        allDownloads.clear();
        traverseDirectoryDownload(storageDirectoryDownload);

        Collections.sort(fileListdownload, (file1, file2) -> {
            long size1 = file1.length();
            long size2 = file2.length();
            return Long.compare(size1, size2);
        });

        Collections.reverse(fileListdownload);

        for (int i = 0; i < fileListdownload.size(); i++) {
            doumentContent doumentContent = new doumentContent();
            doumentContent.setName(fileListdownload.get(i).getName());
            doumentContent.setFilePath(fileListdownload.get(i).getPath());
            doumentContent.setDocumentSize(fileListdownload.get(i).length());
            allDownloads.add(doumentContent);
        }
    }

    private void traverseDirectory(File directory) {
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    traverseDirectory(file);
                } else {
                    String extension = getFileExtension(file);
                    if (!Arrays.asList(imageExtensions).contains(extension)) {
                        fileList.add(file);
                    }
                }
            }
        }
    }

    private void traverseDirectoryDownload(File directory) {
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    // If it's a directory, recursively traverse it
                    traverseDirectory(file);
                } else {
                    fileListdownload.add(file);
                }
                //}
            }
        }
    }

    private String getFileExtension(File file) {
        String name = file.getName();
        int lastDot = name.lastIndexOf(".");
        if (lastDot > 0) {
            return name.substring(lastDot);
        }
        return "";
    }

    /*private void getArchiveFiles() {
        archivesDocuments.clear();
        // Directory where archived files are stored
//        File archiveDirectory = new File(Environment.getExternalStorageDirectory(), "ArchiveFolder");
        // Check if the directory exists
        if (storageDirectory.exists()) {
            // Get all files in the directory
            File[] files = storageDirectory.listFiles();

            if (files != null && files.length > 0) {
                List<File> archiveFiles = new ArrayList<>();

                // Filter files based on extensions
                for (File file : files) {
                    String extension = getFileExtension(file.getName());
                    if (extension.equalsIgnoreCase("zip") || extension.equalsIgnoreCase("rar") ||
                            extension.equalsIgnoreCase("tar")) {
                        archiveFiles.add(file);
                    }
                }

                if (archiveFiles.size() > 0) {
                    for (File file : archiveFiles) {
                        doumentContent doumentContent = new doumentContent();
                        doumentContent.setName(file.getName());
                        doumentContent.setFilePath(file.getPath());
                        doumentContent.setDocumentSize(file.length());
                        archivesDocuments.add(doumentContent);
                    }
                } else {
                    Log.d(TAG, "No archive files found in the directory.");
                }
            } else {
                Log.d(TAG, "No files found in the directory.");
            }
        } else {
            Log.d(TAG, "Archive directory does not exist.");
        }
    }*/

    public void getLargeFile() {
        largeFileDocuments.clear();
        traverseDirectory(storageDirectory);

        Collections.sort(fileList, (file1, file2) -> {
            long size1 = file1.length();
            long size2 = file2.length();
            return Long.compare(size1, size2);
        });

        Collections.reverse(fileList);

        for (int i = 0; i < fileList.size(); i++) {
            doumentContent doumentContent = new doumentContent();
            doumentContent.setName(fileList.get(i).getName());
            doumentContent.setFilePath(fileList.get(i).getPath());
            doumentContent.setDocumentSize(fileList.get(i).length());
            if (fileList.get(i).length() > 53000000) {
                largeFileDocuments.add(doumentContent);
            }
        }
    }

    private String getFileExtension(String fileName) {
        String extension = "";

        int dotIndex = fileName.lastIndexOf(".");
        if (dotIndex > 0 && dotIndex < fileName.length() - 1) {
            extension = fileName.substring(dotIndex + 1);
        }

        return extension;
    }

    @Override
    protected void onResume() {
        SharedPreferences sharedPrefs = getSharedPreferences("language", MODE_PRIVATE);
        String s1 = sharedPrefs.getString("selectedlanguage", "");
        LocaleHelper.setLocale(this, s1);

        if (allPhotos != null) {
            imageSize = convertFileSize(storageTotalImagesResume());
        }
        if (allVideo != null) {
            videoSize = convertFileSize(storageTotalVideoResume());
        }
        if (allAudio != null) {
            audioSize = convertFileSize(storageTotalAudioResume());
        }
        if (allDocuments != null) {
            documentsize = convertFileSize(storageTotalDocumentResume());
        }
        if (largeFileDocuments != null) {
            largesize = convertFileSize(storageTotalArchiveFileResume());
        }
        if (allDownloads != null) {
            downloadsize = convertFileSize(storageTotalDownloadResume());
        }

        tvImageSize.setText(imageSize);
        tvVideoSize.setText(videoSize);
        tvAudioSize.setText(audioSize);
        tvDocumentsSize.setText(documentsize);
        tvLargeFileSize.setText(largesize);
        tvDownloadSize.setText(downloadsize);

        new Utils().disebledOpenAdsBasedOnFireBase();

        super.onResume();
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleHelper.onAttach(base, "en"));
    }

    @Override
    protected void onPause() {
        super.onPause();

    }

    private void initDataToSeekbar(float image, float video, float audio, float documents, float largefiles, float downloads) {
        progressItemList = new ArrayList<>();

        // red span
        mProgressItem = new ProgressItem();
        mProgressItem.progressItemPercentage = image;
        mProgressItem.color = R.color.imagescolor;
        progressItemList.add(mProgressItem);

        mProgressItem = new ProgressItem();
        mProgressItem.progressItemPercentage = video;
        mProgressItem.color = R.color.videocolor;
        progressItemList.add(mProgressItem);
        // blue span
        mProgressItem = new ProgressItem();
        mProgressItem.progressItemPercentage = audio;
        mProgressItem.color = R.color.audiocolor;
        progressItemList.add(mProgressItem);
        // green span
        mProgressItem = new ProgressItem();
        mProgressItem.progressItemPercentage = documents;
        mProgressItem.color = R.color.documentcolor;
        progressItemList.add(mProgressItem);

        //white span
        mProgressItem = new ProgressItem();
        mProgressItem.progressItemPercentage = largefiles;
        mProgressItem.color = R.color.largecolor;
        progressItemList.add(mProgressItem);

        //white span
        mProgressItem = new ProgressItem();
        mProgressItem.progressItemPercentage = downloads;
        mProgressItem.color = R.color.downloadscolor;
        progressItemList.add(mProgressItem);

        seekbar.initData(progressItemList);
        seekbar.invalidate();
    }

    public void loadNative() {
        FrameLayout nativeAdPEPkmsSmall = findViewById(R.id.native_ad_PE_pkms_small);
        new NativeLoadWithShows(StorageCleanerActivity.this).showNativeAdsShimmerEffects(StorageCleanerActivity.this,  nativeAdPEPkmsSmall, 1);
        new NativeLoadWithShows(StorageCleanerActivity.this).showNativeBottomAlways(StorageCleanerActivity.this, nativeAdPEPkmsSmall,null);
//        new AdUtils().nativeAd(this,nativeAdPEPkmsSmall, true, 1);
    }
}