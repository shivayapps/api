package com.cleanmaster.trashcleaner.junkeraser.junckcleaner.interfaces;

public interface  SelectAll {
    void selectAll(boolean isSelectAll,String type);
}
