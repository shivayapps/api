package com.cleanmaster.trashcleaner.junkeraser.model

import androidx.annotation.ColorRes
import com.cleanmaster.trashcleaner.junkeraser.R

sealed class DataCategory(val name: String, @ColorRes val colorRes: Int)

object Image : DataCategory("black", R.color.process_image)
object Video : DataCategory("green", R.color.process_video)
object Audio : DataCategory("orange", R.color.process_audio)
object Docusmts : DataCategory("lightpink", R.color.process_document)
object Archives : DataCategory("yellow", R.color.process_archive)
object Download : DataCategory("yellow", R.color.process_download)
