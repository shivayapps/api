package com.cleanmaster.trashcleaner.junkeraser.database;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "charge_history")
public class ChargeHistoryModel {

    @PrimaryKey(autoGenerate = true)
    int id;
    @ColumnInfo(name = "full_charged")
    String full_charge_date;
    @ColumnInfo(name = "full_charge")
    String full_charge;
    @ColumnInfo(name = "start_time")
    String start_time;
    @ColumnInfo(name = "end_time")
    String end_time;
    @ColumnInfo(name = "charge_type")
    String charge_type;
    @ColumnInfo(name = "charge_duration")
    String charge_duration;
    @ColumnInfo(name = "charge_quantity")
    int quantity;
    @ColumnInfo(name = "charge_normal")
    int charge_normal;
    @ColumnInfo(name = "charge_healthy")
    int charge_healthy;
    @ColumnInfo(name = "charge_overcharged")
    int charge_overcharged;
    @ColumnInfo(name = "ispower")
    boolean ispower;
    @ColumnInfo(name = "isfullcharged")
    boolean isfullcharged;
    @ColumnInfo(name = "start_charging_level")
    int start_charging_level;

    public ChargeHistoryModel(String full_charge_date, String charge_type, String charge_duration, int quantity, int charge_normal, int charge_healthy, int charge_overcharged, boolean ispower) {
        this.full_charge_date = full_charge_date;
        this.charge_type = charge_type;
        this.charge_duration = charge_duration;
        this.quantity = quantity;
        this.charge_normal = charge_normal;
        this.charge_healthy = charge_healthy;
        this.charge_overcharged = charge_overcharged;
        this.ispower = ispower;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFull_charge_date() {
        return full_charge_date;
    }

    public void setFull_charge_date(String full_charge_date) {
        this.full_charge_date = full_charge_date;
    }

    public String getCharge_type() {
        return charge_type;
    }

    public void setCharge_type(String charge_type) {
        this.charge_type = charge_type;
    }

    public String getCharge_duration() {
        return charge_duration;
    }

    public void setCharge_duration(String charge_duration) {
        this.charge_duration = charge_duration;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getCharge_normal() {
        return charge_normal;
    }

    public void setCharge_normal(int charge_normal) {
        this.charge_normal = charge_normal;
    }

    public int getCharge_healthy() {
        return charge_healthy;
    }

    public void setCharge_healthy(int charge_healthy) {
        this.charge_healthy = charge_healthy;
    }

    public int getCharge_overcharged() {
        return charge_overcharged;
    }

    public void setCharge_overcharged(int charge_overcharged) {
        this.charge_overcharged = charge_overcharged;
    }

    public boolean isIspower() {
        return ispower;
    }

    public void setIspower(boolean ispower) {
        this.ispower = ispower;
    }

    public String getFull_charge() {
        return full_charge;
    }

    public void setFull_charge(String full_charge) {
        this.full_charge = full_charge;
    }

    public String getStart_time() {
        return start_time;
    }

    public void setStart_time(String start_time) {
        this.start_time = start_time;
    }

    public String getEnd_time() {
        return end_time;
    }

    public void setEnd_time(String end_time) {
        this.end_time = end_time;
    }

    public boolean isIsfullcharged() {
        return isfullcharged;
    }

    public void setIsfullcharged(boolean isfullcharged) {
        this.isfullcharged = isfullcharged;
    }

    public int getStart_charging_level() {
        return start_charging_level;
    }

    public void setStart_charging_level(int start_charging_level) {
        this.start_charging_level = start_charging_level;
    }
}
