package com.cleanmaster.trashcleaner.junkeraser.activity;

import static android.Manifest.permission.POST_NOTIFICATIONS;
import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
import static android.os.Build.VERSION.SDK_INT;

import static com.cleanmaster.trashcleaner.junkeraser.utils.RoundedImageView.TAG;

import android.app.AppOpsManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.WindowManager;

import androidx.core.content.ContextCompat;

import com.cleanmaster.trashcleaner.junkeraser.BuildConfig;
import com.cleanmaster.trashcleaner.junkeraser.R;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;

public class SplashActivity extends BaseActivity {
    private boolean isLanguageSet = false;
    public static FirebaseRemoteConfig mFirebaseRemoteConfig;
    private boolean isAppOpenSplash = false;
    private String InterSplas = "";

    public static int rewardelays = 3000;
    private Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);


        SharedPreferences sharedPref = getSharedPreferences("LanguageSet", MODE_PRIVATE);
        isLanguageSet = sharedPref.getBoolean("isLanguageSet", false);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        String jsn = BuildConfig.APPLICATION_ID+".json";
//        if(BuildConfig.DEBUG) jsn = "com.testing.json";

        splashAPICalling(StartMAin(),jsn, BuildConfig.VERSION_NAME);

//        new Handler().postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                StartMAin();
//            }
//        },2000);


//        loadAdAndShow();
    }

    public boolean permission() {
        int write;
        int read;
        int notification;
        if (SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notification = ContextCompat.checkSelfPermission(getApplicationContext(), POST_NOTIFICATIONS);
            return notification == PackageManager.PERMISSION_GRANTED && Environment.isExternalStorageManager() && isAccessGranted();
        } else if (SDK_INT <= Build.VERSION_CODES.Q) {
            write = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
            read = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);
            return write == PackageManager.PERMISSION_GRANTED && read == PackageManager.PERMISSION_GRANTED && isAccessGranted();
        } else return Environment.isExternalStorageManager() && isAccessGranted();
    }

    public boolean isAccessGranted() {
        AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
        int mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), getPackageName());

        return mode == AppOpsManager.MODE_ALLOWED;
    }

    /*private void loadAndShowOpenAppSplash() {
        if (mFirebaseRemoteConfig != null && mFirebaseRemoteConfig.getBoolean("app_open_splash")) {
            isAppOpenSplash = true;
            AppOpenManager.getInstance().setSplashAdId(BuildConfig.app_open_splash);
        } else if (mFirebaseRemoteConfig != null && mFirebaseRemoteConfig.getBoolean("intersitial_splash_1")) {
            InterSplas = BuildConfig.intersitial_splash_1;
        } else {
            InterSplas = "";
        }
        if (isAppOpenSplash) {
            AppOpenManager.getInstance().setSplashAdId(BuildConfig.app_open_splash);
        } else {
            AppOpenManager.getInstance().setSplashAdId("");
        }

        AperoAd.getInstance().loadAppOpenSplashSameTime(this, InterSplas, 30000, 3000, false, new AperoAdCallback() {
            @Override
            public void onAdSplashReady() {
                super.onAdSplashReady();
                Log.d(TAG, "onAdSplashReady: ");
                //App open ads ready
                AppOpenManager.getInstance().showAppOpenSplash(SplashActivity.this, new AdCallback() {
                    @Override
                    public void onAdClosed() {
                        super.onAdClosed();
                        StartMAin();
                    }

                    @Override
                    public void onNextAction() {
                        super.onNextAction();
                        StartMAin();
                        Log.d(TAG, "onNextAction: open");
                    }

                    @Override
                    public void onAdFailedToShow(@Nullable AdError adError) {
                        super.onAdFailedToShow(adError);
                        StartMAin();
                        Log.d(TAG, "onAdFailedToShow: open"+adError.getMessage());

                        AppOpenManager.getInstance().showAppOpenSplash(SplashActivity.this, new AdCallback() {
                            @Override
                            public void onAdClosed() {
                                super.onAdClosed();
                                StartMAin();
                                Log.d(TAG, "onAdClosed: open");
                            }

                            @Override
                            public void onNextAction() {
                                super.onNextAction();
                                StartMAin();
                                Log.d(TAG, "onNextAction: open");
                            }

                            @Override
                            public void onAdFailedToShow(@Nullable AdError adError) {
                                super.onAdFailedToShow(adError);
                                StartMAin();
                                Log.d(TAG, "onAdFailedToShow: open"+adError.getMessage());
                            }
                        });
                    }
                });
            }

            @Override
            public void onAdFailedToLoad(@Nullable ApAdError adError) {
                super.onAdFailedToLoad(adError);
                StartMAin();
                Log.d(TAG, "onAdFailedToLoad: inter");
            }

            @Override
            public void onNextAction() {
                super.onNextAction();
                StartMAin();
                Log.d(TAG, "onNextAction: inter");
            }

            @Override
            public void onInterstitialLoad(@Nullable ApInterstitialAd interstitialAd) {
                super.onInterstitialLoad(interstitialAd);
                Log.d(TAG, "onInterstitialLoad: inter");
                //App open ads failed, inter ads loaded
                AperoAd.getInstance().onShowSplash(SplashActivity.this, new AperoAdCallback() {
                    @Override
                    public void onNextAction() {
                        super.onNextAction();
                        Log.d(TAG, "onNextAction: inter");
                        StartMAin();
                    }
                });
            }
        });
    }*/

    public Intent StartMAin() {
        Log.e(TAG, "splashAPICalling:2 ");
        SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);
        boolean isFirstRun = sharedPref.getBoolean(getString(R.string.sharedpref_is_first_run), true);

        SharedPreferences startScreenPreference = getSharedPreferences("StartScreenPreference", MODE_PRIVATE);
        boolean isStartBtnClick = startScreenPreference.getBoolean("isStartBtnClick", false);

        if (isFirstRun && !isLanguageSet) {
            intent = new Intent(this, LanguageActivity.class).putExtra("isFromStart", true);
//            finish();
        } else if (!isStartBtnClick) {
            intent = new Intent(this, StartActivity.class);
//            finish();
        } else {
            intent = new Intent(this, DashBoardActivity.class);
//            finish();
        }
//       startActivity(intent);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
       return intent;
    }

    @Override
    protected void onPause() {
        super.onPause();
//        IronSource.onPause(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
//        IronSource.onResume(this);
    }


}