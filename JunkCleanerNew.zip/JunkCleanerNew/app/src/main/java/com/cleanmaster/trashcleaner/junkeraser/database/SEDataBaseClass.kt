package com.cleanmaster.trashcleaner.junkeraser.database

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import com.cleanmaster.trashcleaner.junkeraser.model.MediaModel
import com.cleanmaster.trashcleaner.junkeraser.utils.UtilsMethod

class SEDataBaseClass(var context: Context?, var activity: Activity) : SQLiteOpenHelper(
    context, "file_recovers_app1.db", null, 2
) {
    private val CREATE_TABLE2 =
        "create table " + TABLE_NAME2 + "(" + COL_ID + " integer primary key autoincrement," +
                COL_NAME + " text," +
                COL_ID_CONTACT + " text," +
                COL_CONTACT + " text);"

    private val CREATE_TABLE5 =
        ("create table " + TABLE_NAME5 + "(" + COL_ID + " integer primary key autoincrement," +
                COL_NAME + " text,"
                + COL_IMAGE_PATH + " text);")


    override fun onCreate(sqLiteDatabase: SQLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_TABLE2)
        sqLiteDatabase.execSQL(CREATE_TABLE5)
    }

    override fun onUpgrade(sqLiteDatabase: SQLiteDatabase, i: Int, i1: Int) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS $TABLE_NAME2")
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS $TABLE_NAME5")
        onCreate(sqLiteDatabase)
    }

    fun insertContact(contact: MediaModel) {
        val db = this.writableDatabase
//        val faceData = "select * from '" + TABLE_NAME2 + "' where " + COL_NAME + " = '" + UtilsMethod(activity).replaceCurrantString(contact.name) + "'"
//        val cursor = db.rawQuery(faceData, null)
//        return if (cursor.moveToFirst()) {
//            false
//        } else {
            val values = ContentValues()
            values.put(COL_NAME, UtilsMethod(activity).replaceCurrantString(contact.name))
            values.put(COL_CONTACT, UtilsMethod(activity).replaceCurrantString(contact.number))
            values.put(COL_ID_CONTACT, UtilsMethod(activity).replaceCurrantString(contact.id.toString()))
            db.insert(TABLE_NAME2, null, values)
//        }
    }

    fun deleteContact(id: Int) {
        val database = writableDatabase
        val deleteSql = "Delete From $TABLE_NAME2 where $COL_ID = $id"
        database.execSQL(deleteSql)
    }

    @get:SuppressLint("Range")
    val contactList: ArrayList<MediaModel>
        get() {
            val items = ArrayList<MediaModel>()
            val db = readableDatabase
            val query = "select * from $TABLE_NAME2 ORDER BY $COL_CONTACT DESC"
            val cursor = db.rawQuery(query, null)
            if (cursor != null && cursor.count > 0) {
                cursor.moveToFirst()
                do {
                    val item = MediaModel()
                    item.id = cursor.getInt(cursor.getColumnIndex(COL_ID))
                    item.name = UtilsMethod(activity).replaceUpdateString(cursor.getString(cursor.getColumnIndex(
                        COL_NAME
                    )))
                    item.number = UtilsMethod(activity).replaceUpdateString(cursor.getString(cursor.getColumnIndex(
                        COL_CONTACT
                    )))
                    items.add(item)
                } while (cursor.moveToNext())
            }
            return items
        }

    fun insertPathNameRecycle(path: String?, name: String?): Boolean {
        val db = this.writableDatabase
        val values = ContentValues()
        Log.d("asdasdad","path "+ path)
        values.put(COL_IMAGE_PATH, UtilsMethod(activity).replaceCurrantString(path.toString()))
        values.put(COL_NAME, UtilsMethod(activity).replaceCurrantString(name.toString()))
        db.insert(TABLE_NAME5, null, values)
        return true
    }

    @get:SuppressLint("Range")
    val imagePathRecycle: ArrayList<MediaModel>
        get() {
            val items = ArrayList<MediaModel>()
            val db = readableDatabase
            val query = "select * from $TABLE_NAME5"
            val cursor = db.rawQuery(query, null)
            if (cursor != null && cursor.count > 0) {
                cursor.moveToFirst()
                do {
                    val item = MediaModel()
                    Log.d("asdasdad","gets path "+ UtilsMethod(activity).replaceUpdateString(cursor.getString(cursor.getColumnIndex(
                        COL_IMAGE_PATH
                    ))))
                    item.id = cursor.getInt(cursor.getColumnIndex(COL_ID))
                    item.path = UtilsMethod(activity).replaceUpdateString(cursor.getString(cursor.getColumnIndex(
                        COL_IMAGE_PATH
                    )))
                    item.name = UtilsMethod(activity).replaceUpdateString(cursor.getString(cursor.getColumnIndex(
                        COL_NAME
                    )))
                    items.add(item)
                } while (cursor.moveToNext())
            }
            return items
        }

    fun deletePathRecycle(id: Int) {
        val database = writableDatabase
        val deleteSql = "Delete From $TABLE_NAME5 where $COL_ID = $id"
        database.execSQL(deleteSql)
    }
    companion object {
        private const val COL_ID = "id"
        private const val COL_NAME = "name"
        private const val COL_CONTACT = "contact_number"
        private const val TABLE_NAME2 = "create_contact_table"
        private const val COL_IMAGE_PATH = "image_paths"
        private const val TABLE_NAME5 = "recycle_path"
        private const val COL_ID_CONTACT = "contct_id"

    }
}