package com.cleanmaster.trashcleaner.junkeraser.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ads.module.adutills.AdUtils;
import com.ads.module.open.AdconfigApplication;
import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.Utils;
import com.cleanmaster.trashcleaner.junkeraser.adapter.ApplicationAdapter;
import com.cleanmaster.trashcleaner.junkeraser.helper.LocaleHelper;
import com.cleanmaster.trashcleaner.junkeraser.model.Apps;
import com.cleanmaster.trashcleaner.junkeraser.utils.ApkInfoExtractor;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;

public class ApplicationManager extends BaseActivity implements ApplicationAdapter.OnclickcheckListener {

    RecyclerView recyclerView_system, recyclerView_install;
    ImageView btn_back;
    List<Apps> stringList = new ArrayList<Apps>();
    List<Apps> system_apk = new ArrayList<Apps>();
    List<Apps> install_apk = new ArrayList<Apps>();
    ApplicationAdapter system_applicationAdapter, install_applicationAdapter;
    int position;
    boolean isSystem;
    RelativeLayout progressbar;
    private TextView scanning_File;
    private ImageView app_lottie;
    private TextView tvUserApps,tvSystemApps;
    private View viewUserApp;
    private View viewSystemApp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_application__manager);

        recyclerView_system = findViewById(R.id.recyclerView_system);
        recyclerView_install = findViewById(R.id.recyclerView_install);
        btn_back = findViewById(R.id.btn_back);
        progressbar = findViewById(R.id.progressbar);
        scanning_File = findViewById(R.id.scanning_File);
        app_lottie = findViewById(R.id.app_lottie);

        LinearLayout lluserApps = findViewById(R.id.lluserApps);
        LinearLayout llSystemApps = findViewById(R.id.llSystemApps);
        tvUserApps = findViewById(R.id.tvUserApps);
        tvSystemApps = findViewById(R.id.tvSystemApps);
        viewUserApp = findViewById(R.id.viewUserApp);
        viewSystemApp = findViewById(R.id.viewSystemApp);

        Executors.newSingleThreadExecutor().execute(() -> {
            runOnUiThread(() -> progressbar.setVisibility(View.VISIBLE));

            stringList.clear();
            stringList.addAll(new ApkInfoExtractor(this).GetAllSystemApkInfo());
            for (int i = 0; i < stringList.size(); i++) {
                if (stringList.get(i).isIssystem()) {
                    system_apk.add(stringList.get(i));
                } else {
                    install_apk.add(stringList.get(i));
                }
            }
//            new NativeLoadWithShows(ApplicationManager.this).loadNative3PriorityAds(ApplicationManager.this, true);
            runOnUiThread(() -> {
                scanning_File.setText(getResources().getString(R.string.scanning_complete));
                app_lottie.setImageResource(R.drawable.ic_done_lottie);
                Handler handler = new Handler();
                handler.postDelayed(() -> progressbar.setVisibility(View.GONE), 2000);
                recyclerView_install.setVisibility(View.VISIBLE);
                recyclerView_system.setVisibility(View.GONE);

                system_applicationAdapter = new ApplicationAdapter(ApplicationManager.this, ApplicationManager.this, system_apk, true);
                recyclerView_system.setLayoutManager(new LinearLayoutManager(ApplicationManager.this));
                recyclerView_system.setAdapter(system_applicationAdapter);

                install_applicationAdapter = new ApplicationAdapter(ApplicationManager.this, ApplicationManager.this, install_apk, false);
                recyclerView_install.setLayoutManager(new LinearLayoutManager(ApplicationManager.this));
                recyclerView_install.setAdapter(install_applicationAdapter);

                loadNative();
            });
        });
        btn_back.setOnClickListener(v -> onBackPressed());

        lluserApps.setOnClickListener(v -> {
            viewUserApp.setBackgroundColor(getResources().getColor(R.color.blue));
            viewSystemApp.setBackgroundColor(0);
            tvUserApps.setTextColor(getResources().getColor(R.color.blue));
            tvSystemApps.setTextColor(getResources().getColor(R.color.tab_unselected));
            recyclerView_install.setVisibility(View.VISIBLE);
            recyclerView_system.setVisibility(View.GONE);
        });

        llSystemApps.setOnClickListener(v -> {
            viewSystemApp.setBackgroundColor(getResources().getColor(R.color.blue));
            viewUserApp.setBackgroundColor(0);
            tvSystemApps.setTextColor(getResources().getColor(R.color.blue));
            tvUserApps.setTextColor(getResources().getColor(R.color.tab_unselected));

            recyclerView_install.setVisibility(View.GONE);
            recyclerView_system.setVisibility(View.VISIBLE);
        });
    }

    public void loadNative() {
        FrameLayout nativeAdPEPkmsSmall = findViewById(R.id.native_ad_PE_pkms_small);
        new AdUtils().loadMediumBanner(this, nativeAdPEPkmsSmall);
    }

    @Override
    public void onClick(int position) {

    }

    @Override
    public void onUninstallClick(int position, String pkgName, boolean isSystem) {
        this.position = position;
        this.isSystem = isSystem;
        AdconfigApplication.Companion.disabledOpenAds();
        Intent intent = new Intent("android.intent.action.UNINSTALL_PACKAGE");
        intent.setData(Uri.parse("package:" + pkgName));
        intent.putExtra("android.intent.extra.RETURN_RESULT", true);
        startActivityForResult(intent, 1);

        Log.d("dfdweewrerwere", "onUninstallApp: " + "package:" + pkgName);
    }

    private boolean appInstalledOrNot(String uri) {
        PackageManager pm = getPackageManager();
        try {
            pm.getPackageInfo(uri, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
        }
        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == -1) {

            if (isSystem) {
                if (!appInstalledOrNot(system_apk.get(position).getApp_package())) {
                    system_apk.remove(position);
                    system_applicationAdapter.notifyItemRemoved(position);
                    system_applicationAdapter.notifyItemRangeChanged(position, system_apk.size());
                    Toast.makeText(this, "Uninstall successfully", Toast.LENGTH_SHORT).show();
                }
            } else {
                if (!appInstalledOrNot(install_apk.get(position).getApp_package())) {
                    install_apk.remove(position);
                    install_applicationAdapter.notifyItemRemoved(position);
                    install_applicationAdapter.notifyItemRangeChanged(position, install_apk.size());
                    Toast.makeText(this, "Uninstall successfully", Toast.LENGTH_SHORT).show();
                }
            }

        }
    }

    @Override
    protected void onStart() {
        super.onStart();
    }


    @Override
    protected void onResume() {
        SharedPreferences sharedPrefs = getSharedPreferences("language", MODE_PRIVATE);
        String s1 = sharedPrefs.getString("selectedlanguage", "");
        LocaleHelper.setLocale(this, s1);
        new Utils().disebledOpenAdsBasedOnFireBase();
        super.onResume();
    }

    @Override
    protected void onPause() {

        super.onPause();

    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleHelper.onAttach(base, "en"));
    }
}