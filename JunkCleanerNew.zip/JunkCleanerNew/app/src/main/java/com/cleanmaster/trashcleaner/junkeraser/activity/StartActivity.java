package com.cleanmaster.trashcleaner.junkeraser.activity;

import static android.Manifest.permission.POST_NOTIFICATIONS;
import static android.os.Build.VERSION.SDK_INT;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.InsetDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.ads.module.adutills.NativeLoadWithShows;
import com.ads.module.adutills.SessionHelper;
import com.ads.module.open.AdconfigApplication;
import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.Utils;
import com.cleanmaster.trashcleaner.junkeraser.helper.LocaleHelper;

public class StartActivity extends BaseActivity {
    private static final int REQUEST_PERMISSION_SETTING = 500;
    TextView get_started;
    private AlertDialog alertDialog;
    private SharedPreferences StartScreenPreference;
    private int notification;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        StartScreenPreference = getSharedPreferences("StartScreenPreference", MODE_PRIVATE);

        SharedPreferences sp = getSharedPreferences("SettingScreen", MODE_PRIVATE);
        String themes = sp.getString("theme", "");

        switch (themes) {
            case "light":
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                break;
            case "dark":
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                break;
            case "dafault":
                switch (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) {
                    case Configuration.UI_MODE_NIGHT_YES:
                        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                        break;
                    case Configuration.UI_MODE_NIGHT_NO:
                        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                        break;
                }
                break;
        }

//        btn_privacy = findViewById(R.id.btn_privacy);
        get_started = findViewById(R.id.btn_id);

        loadNative();

       /* btn_privacy.setOnClickListener(view -> {
//            AppOpenManager.getInstance().disableAppResume();
            String url = "https://sites.google.com/view/cleaner-policy-sg/trang-ch%E1%BB%A7";
            CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
            builder.setToolbarColor(ContextCompat.getColor(this, R.color.white));
            CustomTabsIntent customTabsIntent = builder.build();
//            customTabsIntent.intent.setPackage("com.android.chrome");
            customTabsIntent.launchUrl(this, Uri.parse(url));

        });*/

        get_started.setOnClickListener(view -> {
            //if (permission()) {
//            isDeniedPErmission = permission_preference.getBoolean("isDeniedNotificationPermission", false);

            if (SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                notification = ContextCompat.checkSelfPermission(getApplicationContext(), POST_NOTIFICATIONS);
                if (notification != PackageManager.PERMISSION_GRANTED) {
                    //if (!isDeniedPErmission) {
                    AdconfigApplication.Companion.disabledOpenAds();
                    ActivityCompat.requestPermissions(StartActivity.this, new String[]{POST_NOTIFICATIONS}, 100);
                } else {
                    //showPermissionMAnualyDialog();
                    SharedPreferences.Editor myEdit1 = StartScreenPreference.edit();
                    myEdit1.putBoolean("isStartBtnClick", true);
                    myEdit1.apply();
                    startActivity(new Intent(this, DashBoardActivity.class));
                    finish();
                }

            } else {
                SharedPreferences.Editor myEdit1 = StartScreenPreference.edit();
                myEdit1.putBoolean("isStartBtnClick", true);
                myEdit1.apply();
                startActivity(new Intent(this, DashBoardActivity.class));
                finish();
            }
        });
    }

    public void loadNative() {
        FrameLayout frameLayout = findViewById(R.id.native_ad_PE_pkms_small);
        if (new SessionHelper(this).getStringData(SessionHelper.IS_GET_START_NATIVE_ON).equals("1")) {
            new NativeLoadWithShows(this).showNativeAdsShimmerEffects(this, frameLayout, 3);
            new NativeLoadWithShows(this).showNativeTopAlways(this, frameLayout,null);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("hello123456789", "start OnRsume");
        SharedPreferences sharedPref = getSharedPreferences("language", MODE_PRIVATE);
        String s1 = sharedPref.getString("selectedlanguage", "");
        LocaleHelper.setLocale(this, s1);
        new Utils().disebledOpenAdsBasedOnFireBase();

    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleHelper.onAttach(base, "en"));
    }

    @Override
    public void onBackPressed() {
        final View dialogView = getLayoutInflater().inflate(R.layout.dialog_exit, null);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        TextView buttonCancel = dialogView.findViewById(R.id.buttonCancel);
        TextView buttonOk = dialogView.findViewById(R.id.buttonOk);

        buttonCancel.setOnClickListener(view1 -> alertDialog.dismiss());

        buttonOk.setOnClickListener(view12 -> {
            alertDialog.dismiss();
            finishAffinity();
            System.exit(1);
        });

        builder.setView(dialogView);
        alertDialog = builder.create();

        InsetDrawable inset = new InsetDrawable(new ColorDrawable(Color.TRANSPARENT), 40);
        alertDialog.getWindow().setBackgroundDrawable(inset);
        alertDialog.show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 100) {
            if (grantResults.length > 0) {
                if (SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    boolean notification = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    if (notification) {
                        SharedPreferences.Editor myEdit1 = StartScreenPreference.edit();
                        myEdit1.putBoolean("isStartBtnClick", true);
                        myEdit1.apply();
                        startActivity(new Intent(this, DashBoardActivity.class));
                    } else {
                        SharedPreferences.Editor myEdit1 = StartScreenPreference.edit();
                        myEdit1.putBoolean("isStartBtnClick", true);
                        myEdit1.apply();
                        startActivity(new Intent(this, DashBoardActivity.class));

                        /*SharedPreferences.Editor myEdit = permission_preference.edit();
                        myEdit.putBoolean("isDeniedNotificationPermission", true);
                        myEdit.apply();*/
//                        showPermissionMAnualyDialog();
                    }
                }
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 500) {
            notification = ContextCompat.checkSelfPermission(getApplicationContext(), POST_NOTIFICATIONS);
            if (notification == PackageManager.PERMISSION_GRANTED) {
                SharedPreferences.Editor myEdit1 = StartScreenPreference.edit();
                myEdit1.putBoolean("isStartBtnClick", true);
                myEdit1.apply();
                startActivity(new Intent(this, DashBoardActivity.class));
            }
        }

    }

    public void showPermissionMAnualyDialog() {
        final View dialogView = getLayoutInflater().inflate(R.layout.dialog_permission_dont_allow, null);
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);

        TextView buttonCancel = dialogView.findViewById(R.id.buttonCancel);
        TextView buttonOk = dialogView.findViewById(R.id.buttonOk);

        buttonCancel.setOnClickListener(view1 -> alertDialog.dismiss());

        buttonOk.setOnClickListener(view12 -> {
            alertDialog.dismiss();
            AdconfigApplication.Companion.disabledOpenAds();
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            Uri uri = Uri.fromParts("package", getPackageName(), null);
            intent.setData(uri);
            startActivityForResult(intent, REQUEST_PERMISSION_SETTING);
        });

        builder.setView(dialogView);
        alertDialog = builder.create();

        InsetDrawable inset = new InsetDrawable(new ColorDrawable(Color.TRANSPARENT), 40);
        alertDialog.getWindow().setBackgroundDrawable(inset);
        alertDialog.show();
    }

}