package com.cleanmaster.trashcleaner.junkeraser.database;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {ApplicationModel.class, BlockListModel.class, BatteryModel.class, ChargeHistoryModel.class}, version = 1,exportSchema = false)
public abstract class ApplicationDatabase extends RoomDatabase {

    public abstract ApplicationDao applicationDao();
    public abstract BlockListDao blockListDao();
    public abstract BatteryDao batteryDao();
    public abstract ChargeHistoryDao chargeHistoryDao();


}
