package com.cleanmaster.trashcleaner.junkeraser.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.List;

public class GroupItem implements Parcelable {
    public static final Creator<GroupItem> CREATOR = new Creator<GroupItem>() {
        public GroupItem createFromParcel(Parcel parcel) {
            return new GroupItem(parcel);
        }

        public GroupItem[] newArray(int i) {
            return new GroupItem[i];
        }
    };
    public static final int TYPE_CACHE = 1;
    public static final int TYPE_FILE = 0;
    private boolean isCheck;
    private List<ChildItem> items = new ArrayList();
    private String title;
    private long total;
    private int type;

    public int describeContents() {
        return 0;
    }

    public GroupItem() {
    }

    protected GroupItem(Parcel parcel) {
        this.title = parcel.readString();
        this.total = parcel.readLong();
        this.isCheck = parcel.readByte() != 0;
        this.type = parcel.readInt();
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String str) {
        this.title = str;
    }

    public long getTotal() {
        return this.total;
    }

    public void setTotal(long j) {
        this.total = j;
    }

    public boolean isCheck() {
        return this.isCheck;
    }

    public void setIsCheck(boolean z) {
        this.isCheck = z;
    }

    public List<ChildItem> getItems() {
        return this.items;
    }

    public void setItems(List<ChildItem> list) {
        this.items = list;
    }

    public int getType() {
        return this.type;
    }

    public void setType(int i) {
        this.type = i;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.title);
        parcel.writeLong(this.total);
        parcel.writeByte(this.isCheck ? (byte) 1 : 0);
        parcel.writeInt(this.type);
    }
}
