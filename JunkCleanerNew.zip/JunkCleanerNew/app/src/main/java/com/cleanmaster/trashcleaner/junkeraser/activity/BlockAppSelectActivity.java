package com.cleanmaster.trashcleaner.junkeraser.activity;

import static com.cleanmaster.trashcleaner.junkeraser.activity.DashBoardActivity.applicationlist;

import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import com.ads.module.adutills.AdUtils;
import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.Utils;
import com.cleanmaster.trashcleaner.junkeraser.adapter.App_List_Adapter;
import com.cleanmaster.trashcleaner.junkeraser.database.ApplicationDatabase;
import com.cleanmaster.trashcleaner.junkeraser.database.ApplicationModel;
import com.cleanmaster.trashcleaner.junkeraser.database.BlockListModel;
import com.cleanmaster.trashcleaner.junkeraser.helper.LocaleHelper;

import java.util.List;


public class BlockAppSelectActivity extends BaseActivity implements App_List_Adapter.OnSwitchCheckChangeListener {
    ImageView btn_back;
    LinearLayout btn_close_all_notification;
    RecyclerView recyclerView;
    App_List_Adapter app_list_adapter;
    ImageView switch_close_all_notification;
    boolean isChecked = false;
    ApplicationDatabase applicationDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_block_app_select);

        //applicationDatabase = Room.databaseBuilder(this, ApplicationDatabase.class, "application_db").allowMainThreadQueries().build();
        applicationDatabase = Utils.getApplicationDatabase(this);

        btn_back = findViewById(R.id.btn_back);
        btn_close_all_notification = findViewById(R.id.btn_close_all_notification);
        switch_close_all_notification = findViewById(R.id.switch_close_all_notification);
        recyclerView = findViewById(R.id.recyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        app_list_adapter = new App_List_Adapter(this, applicationlist, this::onCheckChange);
        recyclerView.setAdapter(app_list_adapter);

        if (applicationDatabase.blockListDao() != null && applicationDatabase.blockListDao().getAllBlockList().size() != 0 && applicationDatabase.blockListDao().getAllBlockList().get(0).getStatus().equals("yes")) {
            set_switch(true);
            blockAll(true);
        } else {
            if (applicationDatabase.blockListDao().getAllBlockList().size() == 0) {
                applicationDatabase.blockListDao().block_insert(new BlockListModel("BLOCK_ALL", "no"));
            }
            set_switch(false);
        }

        btn_back.setOnClickListener(v -> onBackPressed());
        btn_close_all_notification.setOnClickListener(v -> switch_click());
        switch_close_all_notification.setOnClickListener(v -> switch_click());

        FrameLayout banner_layout = findViewById(R.id.frame_banner);
        new AdUtils().loadMediumBanner(this,banner_layout);

    }

    public void blockAll(boolean bool){
        applicationDatabase.applicationDao().blockAllUser(bool, !bool);
        app_list_adapter.setIsBlockAll(bool);
    }

    public void switch_click(){
        if (isChecked){
            if (applicationDatabase.blockListDao() != null && applicationDatabase.blockListDao().getAllBlockList().size() == 0) {
                applicationDatabase.blockListDao().block_insert(new BlockListModel("BLOCK_ALL", "no"));
                blockAll(false);
            } else {
                applicationDatabase.blockListDao().updateUsingID("no");
                blockAll(false);
            }
            set_switch(false);
        }else {
            if (applicationDatabase.blockListDao() != null && applicationDatabase.blockListDao().getAllBlockList().size() == 0) {
                applicationDatabase.blockListDao().block_insert(new BlockListModel("BLOCK_ALL", "yes"));
                blockAll(true);
            } else {
                applicationDatabase.blockListDao().updateUsingID("yes");
                blockAll(true);
            }
            set_switch(true);
        }
    }

    @Override
    public void onCheckChange(int position, Boolean isChecked, String pkg_name) {
        Log.d("dgfdswerwerewr", "onCheckChange: " + isChecked + "   " + pkg_name);

        if (isChecked) {
            if (applicationDatabase.blockListDao() != null && applicationDatabase.blockListDao().getAllBlockList().size() != 0 && applicationDatabase.blockListDao().getAllBlockList().get(0).getStatus().equals("yes")) {
                applicationDatabase.applicationDao().updateUsingID(pkg_name, true);
            } else {
                applicationDatabase.applicationDao().updateUsingID(pkg_name, true);
            }
        } else {
            if (applicationDatabase.blockListDao() != null && applicationDatabase.blockListDao().getAllBlockList().size() != 0 && applicationDatabase.blockListDao().getAllBlockList().get(0).getStatus().equals("yes")) {
                applicationDatabase.applicationDao().updateUsingID(pkg_name, false);
            } else {
                applicationDatabase.applicationDao().updateUsingID(pkg_name, false);
            }
        }
        NotificationManager nManager = ((NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE));
        nManager.cancelAll();

        List<ApplicationModel> list = applicationDatabase.applicationDao().getAllPositionList(true);
        if (list.size() == applicationDatabase.applicationDao().getAllappList().size()) {
            set_switch(true);
        } else if (list.size() < applicationDatabase.applicationDao().getAllappList().size()) {
            set_switch(false);
        } else {
         set_switch(false);
        }
    }

    public void set_switch(boolean bool){
        if (bool){
            applicationDatabase.blockListDao().getAllBlockList().get(0).getStatus().equals("yes");
            switch_close_all_notification.setImageResource(R.drawable.ic_baseline_toggle_on_24);
            this.isChecked = true;
        }else {
            applicationDatabase.blockListDao().getAllBlockList().get(0).getStatus().equals("no");
            switch_close_all_notification.setImageResource(R.drawable.ic_baseline_toggle_off_24);
            this.isChecked = false;
        }

    }

    @Override
    protected void onResume() {

        SharedPreferences sharedPrefs = getSharedPreferences("language", MODE_PRIVATE);
        String s1 = sharedPrefs.getString("selectedlanguage", "");
        LocaleHelper.setLocale(this, s1);
        new Utils().disebledOpenAdsBasedOnFireBase();
        super.onResume();
    }


    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleHelper.onAttach(base, "en"));
    }
}