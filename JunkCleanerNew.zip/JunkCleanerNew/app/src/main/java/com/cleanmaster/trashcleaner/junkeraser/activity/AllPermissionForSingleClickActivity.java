package com.cleanmaster.trashcleaner.junkeraser.activity;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
import static android.content.ContentValues.TAG;
import static android.os.Build.VERSION.SDK_INT;

import android.app.AppOpsManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.InsetDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.ads.module.adutills.NativeLoadWithShows;
import com.ads.module.adutills.SessionHelper;
import com.ads.module.open.AdconfigApplication;
import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.Utils;
import com.cleanmaster.trashcleaner.junkeraser.applock.activities.main.StartAppLock;
import com.cleanmaster.trashcleaner.junkeraser.helper.LocaleHelper;
import com.cleanmaster.trashcleaner.junkeraser.junckcleaner.activities.JunkActivity;

public class AllPermissionForSingleClickActivity extends BaseActivity {
    private static final int REQUEST_CODE = 10;
    private static final int REQUEST_PERMISSION_TRASHCLEANER = 1000;
    private static final int REQUEST_PERMISSION_STORAGECLEANER = 1005;
    private static final int REQUEST_PERMISSION_APPCLEANER = 1007;
    private static final int REQUEST_PERMISSION_SETTING = 500;
    private static final int REQUEST_PERMISSION_SETTING_STORAGE = 700;
    private static final int REQUEST_PERMISSION_SETTING_APP_CLEANER = 900;
    private boolean isOpenPermissionScreeen = false;
    private androidx.appcompat.app.AlertDialog alertDialog;
    private SharedPreferences permission_preference;
    private boolean isDeniedPErmission;
    private String storage_cleaner = "";
    private String trash_cleaner = "";
    private String app_cleaner = "";
    private String app_lock = "";
    private LinearLayout llStorage;
    private LinearLayout llNotification;
    private LinearLayout llUsageAccess;
    private UsagePermissionMonitor usagePermissionMonitor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission);

        //mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
//        Bundle bundle = new Bundle();
//        bundle.putString("permission_screen", "permission_screen_open");
//        mFirebaseAnalytics.logEvent("permission_screen_open", bundle);

        permission_preference = getSharedPreferences("permission_preference", MODE_PRIVATE);
        SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);
        boolean isFirstRun = sharedPref.getBoolean(getString(R.string.sharedpref_is_first_run), true);

        storage_cleaner = getIntent().getStringExtra("storage_cleaner");
        trash_cleaner = getIntent().getStringExtra("trash_cleaner");
        app_cleaner = getIntent().getStringExtra("app_cleaner");
        app_lock = getIntent().getStringExtra("app_lock");

        usagePermissionMonitor = new UsagePermissionMonitor(AllPermissionForSingleClickActivity.this);

        initView();

        isDeniedPErmission = permission_preference.getBoolean("isDeniedPErmission", false);

        llStorage = findViewById(R.id.llStorage);
        llNotification = findViewById(R.id.llNotification);
        llUsageAccess = findViewById(R.id.llUsageAccess);

        if (storage_cleaner != null && storage_cleaner.equals("StorageCleaner") || storage_cleaner != null && storage_cleaner.equals("DuplicateImage") || trash_cleaner != null && trash_cleaner.equals("TrashCleaner") || app_cleaner != null && app_cleaner.equals("AppCleaner")) {
            llStorage.setVisibility(View.VISIBLE);
            llNotification.setVisibility(View.GONE);
            llUsageAccess.setVisibility(View.GONE);
        } else if (app_lock != null && app_lock.equals("AppLock")) {
            llStorage.setVisibility(View.GONE);
            llNotification.setVisibility(View.GONE);
            llUsageAccess.setVisibility(View.VISIBLE);
        }

        loadNative();
    }

    public void loadNative() {
        FrameLayout frameLayout = findViewById(R.id.native_ad_PE_pkms_small);

        if (new SessionHelper(this).getStringData(SessionHelper.IS_PERMISSION_NATIVE_ON).equals("1")) {
            new NativeLoadWithShows(this).showNativeAdsShimmerEffects(this, findViewById(R.id.native_ad_PE_pkms_small), 3);
            new NativeLoadWithShows(this).showNativeTopAlways(this, findViewById(R.id.native_ad_PE_pkms_small),null);
        }
//        new AdUtils().nativeAd(this, frameLayout, true, 3);

    }
    private void initView() {
        TextView btnStart = findViewById(R.id.btnStart);

        btnStart.setOnClickListener(v -> {
            if (trash_cleaner != null && trash_cleaner.equals("TrashCleaner")) {
                llStorage.setVisibility(View.VISIBLE);
                llNotification.setVisibility(View.GONE);
                llUsageAccess.setVisibility(View.GONE);
                if (permissionForTrashClener()) {
                    if (SDK_INT >= Build.VERSION_CODES.R) {
                        if (!Environment.isExternalStorageManager()) {
                            if (new SessionHelper(this).getStringData(SessionHelper.IS_PERMISSSION_OPEN_AD).equals("0")) {
                                AdconfigApplication.Companion.disabledOpenAds();
                            }
                            isOpenPermissionScreeen = true;
                            Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                            Uri uri = Uri.fromParts("package", getPackageName(), null);
                            intent.setData(uri);
                            try {
                                startActivityForResult(intent, REQUEST_PERMISSION_TRASHCLEANER);
                            } catch (ActivityNotFoundException e) {
                                try {
                                    intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                                    startActivityForResult(intent, REQUEST_PERMISSION_TRASHCLEANER);
                                } catch (ActivityNotFoundException e1) {
                                    Intent i1 = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                            Uri.fromParts("package", getPackageName(), null));
                                    startActivityForResult(i1, REQUEST_PERMISSION_TRASHCLEANER);
                                }
                            }
                        } else {
                            startActivity(new Intent(AllPermissionForSingleClickActivity.this, JunkActivity.class));
                            finish();
                        }
                    } else {

                        startActivity(new Intent(AllPermissionForSingleClickActivity.this, JunkActivity.class));
                        finish();
                        //}
                    }
                } else {
                    isDeniedPErmission = permission_preference.getBoolean("isDeniedPErmission", false);
//                if (isDeniedPErmission) {
//                    showPermissionMAnualyDialog();
//                } else {
                    RequestPermissionDialog();
//                }
                }
            }

            if (storage_cleaner != null && storage_cleaner.equals("StorageCleaner") || storage_cleaner != null && storage_cleaner.equals("DuplicateImage")) {
                llStorage.setVisibility(View.VISIBLE);
                llNotification.setVisibility(View.GONE);
                llUsageAccess.setVisibility(View.GONE);
                if (permissionForStorageClener()) {
                    if (SDK_INT >= Build.VERSION_CODES.R) {
                        if (!Environment.isExternalStorageManager()) {
                            if (new SessionHelper(this).getStringData(SessionHelper.IS_PERMISSSION_OPEN_AD).equals("0")) {
                                AdconfigApplication.Companion.disabledOpenAds();
                            }
                            isOpenPermissionScreeen = true;
                            Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                            Uri uri = Uri.fromParts("package", getPackageName(), null);
                            intent.setData(uri);
                            try {
                                startActivityForResult(intent, REQUEST_PERMISSION_STORAGECLEANER);
                            } catch (ActivityNotFoundException e) {
                                try {
                                    intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                                    startActivityForResult(intent, REQUEST_PERMISSION_STORAGECLEANER);
                                } catch (ActivityNotFoundException e1) {
                                    Intent i1 = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                            Uri.fromParts("package", getPackageName(), null));
                                    startActivityForResult(i1, REQUEST_PERMISSION_STORAGECLEANER);
                                }
                            }
                        } else {
//                            AppOpenManager.getInstance().enableAppResume();
//                            aperoAdConfig.setIdAdResume(AppOpenManager.AD_UNIT_ID_TEST);
                            if (storage_cleaner.equals("StorageCleaner")) {
                                startActivity(new Intent(AllPermissionForSingleClickActivity.this, StorageCleanerActivity.class));
                                finish();
                            }
                        }
                    } else {
//                        AppOpenManager.getInstance().enableAppResume();
                        if (storage_cleaner.equals("StorageCleaner")) {
                            startActivity(new Intent(AllPermissionForSingleClickActivity.this, StorageCleanerActivity.class));
                            finish();
                        }
                    }
                } else {
                    isDeniedPErmission = permission_preference.getBoolean("isDeniedPErmission", false);
                    RequestPermissionDialogForStorageCleaner();
                }
            }

            if (app_cleaner != null && app_cleaner.equals("AppCleaner")) {
                llStorage.setVisibility(View.VISIBLE);
                llNotification.setVisibility(View.GONE);
                llUsageAccess.setVisibility(View.GONE);
                if (permissionForStorageClener()) {
                    if (SDK_INT >= Build.VERSION_CODES.R) {
                        if (!Environment.isExternalStorageManager()) {
                            if (new SessionHelper(this).getStringData(SessionHelper.IS_PERMISSSION_OPEN_AD).equals("0")) {
                                AdconfigApplication.Companion.disabledOpenAds();
                            }
                            isOpenPermissionScreeen = true;
                            Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                            Uri uri = Uri.fromParts("package", getPackageName(), null);
                            intent.setData(uri);
                            startActivityForResult(intent, REQUEST_PERMISSION_APPCLEANER);
                        } else {
//                            AppOpenManager.getInstance().enableAppResume();
//                            aperoAdConfig.setIdAdResume(AppOpenManager.AD_UNIT_ID_TEST);
                            if (Utils.appInstalledOrNot(AllPermissionForSingleClickActivity.this)) {
                                startActivity(new Intent(AllPermissionForSingleClickActivity.this, AppCleanLastFolderWiseDataActivity.class).putExtra("AppName", "WhatsApp"));
                                finish();
                            } else {
                                Toast.makeText(this, "WhatApp Not Installed", Toast.LENGTH_SHORT).show();
                            }
                        }
                    } else {
//                        AppOpenManager.getInstance().enableAppResume();
                        if (Utils.appInstalledOrNot(AllPermissionForSingleClickActivity.this)) {
                            startActivity(new Intent(AllPermissionForSingleClickActivity.this, AppCleanLastFolderWiseDataActivity.class).putExtra("AppName", "WhatsApp"));
                            finish();
                        } else {
                            Toast.makeText(this, "WhatApp Not Installed", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    isDeniedPErmission = permission_preference.getBoolean("isDeniedPErmission", false);
                    RequestPermissionDialogForAppCleaner();
                }
            }

            if (app_lock != null && app_lock.equals("AppLock")) {
                if (!isAccessGranted()) {
                    Log.e("hello123456789", "11111111111111");

                    if (new SessionHelper(this).getStringData(SessionHelper.IS_PERMISSSION_OPEN_AD).equals("0")) {
                        AdconfigApplication.Companion.disabledOpenAds();
                    }
                    isOpenPermissionScreeen = true;
                    Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
                    startActivityForResult(intent, 1001);
//                    usagePermissionMonitor.startListening();
                } else if (!Settings.canDrawOverlays(AllPermissionForSingleClickActivity.this)) {
                    Log.e("hello123456789", "22222222222");

                    if (new SessionHelper(this).getStringData(SessionHelper.IS_PERMISSSION_OPEN_AD).equals("0")) {
                        AdconfigApplication.Companion.disabledOpenAds();
                    }
                    Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                    startActivityForResult(intent, 1010);
                }
            }
        });
    }

    public boolean permissionForTrashClener() {
        int write;
        int read;
        if (SDK_INT <= Build.VERSION_CODES.Q) {
            write = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
            read = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);
            return write == PackageManager.PERMISSION_GRANTED && read == PackageManager.PERMISSION_GRANTED;
        } else return Environment.isExternalStorageManager();
    }

    public boolean permissionForStorageClener() {
        int write;
        int read;
        if (SDK_INT <= Build.VERSION_CODES.Q) {
            write = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
            read = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);
            return write == PackageManager.PERMISSION_GRANTED && read == PackageManager.PERMISSION_GRANTED;
        } else return Environment.isExternalStorageManager();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_PERMISSION_STORAGECLEANER) {
            if (grantResults.length > 0) {
                if (SDK_INT >= Build.VERSION_CODES.R) {
                    if (Environment.isExternalStorageManager()) {
                        if (storage_cleaner.equals("StorageCleaner")) {
                            startActivity(new Intent(AllPermissionForSingleClickActivity.this, StorageCleanerActivity.class));
                            finish();
                        }
                    }
                } else {
//                    int write = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
//                    int read = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);
                    boolean read = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean write = grantResults[1] == PackageManager.PERMISSION_GRANTED;
                    if (read && write) {
                        //if (write != PackageManager.PERMISSION_GRANTED && read != PackageManager.PERMISSION_GRANTED) {
                        if (storage_cleaner.equals("StorageCleaner")) {
                            startActivity(new Intent(AllPermissionForSingleClickActivity.this, StorageCleanerActivity.class));
                            finish();
                        }
                    } else {
                        SharedPreferences.Editor myEdit = permission_preference.edit();
                        myEdit.putBoolean("isDeniedPErmission", true);
                        myEdit.apply();
                        showPermissionMAnualyDialog(REQUEST_PERMISSION_SETTING_STORAGE);
                    }
                }/* else{
                    showPermissionMAnualyDialog(REQUEST_PERMISSION_SETTING);
                }*/

            }
        }
        if (requestCode == REQUEST_PERMISSION_APPCLEANER) {
            if (grantResults.length > 0) {
                if (SDK_INT >= Build.VERSION_CODES.R) {
                    if (Environment.isExternalStorageManager()) {
                        if (Utils.appInstalledOrNot(AllPermissionForSingleClickActivity.this)) {
                            startActivity(new Intent(AllPermissionForSingleClickActivity.this, AppCleanLastFolderWiseDataActivity.class).putExtra("AppName", "WhatsApp"));
                            finish();
                        } else {
                            Toast.makeText(this, "WhatApp Not Installed", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
//                    int write = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
//                    int read = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);
                    boolean read = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean write = grantResults[1] == PackageManager.PERMISSION_GRANTED;
                    if (read && write) {
                        //if (write != PackageManager.PERMISSION_GRANTED && read != PackageManager.PERMISSION_GRANTED) {
                        if (Utils.appInstalledOrNot(AllPermissionForSingleClickActivity.this)) {
                            startActivity(new Intent(AllPermissionForSingleClickActivity.this, AppCleanLastFolderWiseDataActivity.class).putExtra("AppName", "WhatsApp"));
                            finish();
                        } else {
                            Toast.makeText(this, "WhatApp Not Installed", Toast.LENGTH_SHORT).show();
                        }

                    } else {
                        SharedPreferences.Editor myEdit = permission_preference.edit();
                        myEdit.putBoolean("isDeniedPErmission", true);
                        myEdit.apply();
                        showPermissionMAnualyDialog(REQUEST_PERMISSION_SETTING_APP_CLEANER);
                    }
                }/* else{

                    showPermissionMAnualyDialog(REQUEST_PERMISSION_SETTING);
                }*/

            }
        }

        if (requestCode == REQUEST_PERMISSION_TRASHCLEANER) {
            if (grantResults.length > 0) {
                if (SDK_INT <= Build.VERSION_CODES.Q) {
                    boolean read = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean write = grantResults[1] == PackageManager.PERMISSION_GRANTED;
                    if (read && write) {
                        startActivity(new Intent(AllPermissionForSingleClickActivity.this, JunkActivity.class));
                        finish();
                    } else {
                        SharedPreferences.Editor myEdit = permission_preference.edit();
                        myEdit.putBoolean("isDeniedPErmission", true);
                        myEdit.apply();
                        showPermissionMAnualyDialog(REQUEST_PERMISSION_SETTING);
                    }
                } else {
                    if (!Environment.isExternalStorageManager()) {
                        if (new SessionHelper(this).getStringData(SessionHelper.IS_PERMISSSION_OPEN_AD).equals("0")) {
                            AdconfigApplication.Companion.disabledOpenAds();
                        }
                        isOpenPermissionScreeen = true;
                        Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                        Uri uri = Uri.fromParts("package", getPackageName(), null);
                        intent.setData(uri);
                        try {
                            startActivityForResult(intent, REQUEST_PERMISSION_TRASHCLEANER);
                        } catch (ActivityNotFoundException e) {
                            try {
                                intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                                startActivityForResult(intent, REQUEST_PERMISSION_TRASHCLEANER);
                            } catch (ActivityNotFoundException e1) {
                                Intent i1 = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                        Uri.fromParts("package", getPackageName(), null));
                                startActivityForResult(i1, REQUEST_PERMISSION_TRASHCLEANER);
                            }
                        }
                    }

                }
            }
        }

    }

    public void RequestPermissionDialog() {
        if (SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                if (new SessionHelper(this).getStringData(SessionHelper.IS_PERMISSSION_OPEN_AD).equals("0")) {
                    AdconfigApplication.Companion.disabledOpenAds();
                }
                isOpenPermissionScreeen = true;
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                Uri uri = Uri.fromParts("package", getPackageName(), null);
                intent.setData(uri);
                try {
                    startActivityForResult(intent, REQUEST_PERMISSION_TRASHCLEANER);
                } catch (ActivityNotFoundException e) {
                    try {
                        intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                        startActivityForResult(intent, REQUEST_PERMISSION_TRASHCLEANER);
                    } catch (ActivityNotFoundException e1) {
                        Intent i1 = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.fromParts("package", getPackageName(), null));
                        startActivityForResult(i1, REQUEST_PERMISSION_TRASHCLEANER);

                    }
                }
            } /*else if (!isAccessGranted()) {
//                AppOpenManager.getInstance().disableAppResume();
                isOpenPermissionScreeen = true;
                Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
                startActivityForResult(intent, 101);
            }*/
        } else {

            int write = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
            int read = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);

            if (write != PackageManager.PERMISSION_GRANTED && read != PackageManager.PERMISSION_GRANTED) {
                if (!isDeniedPErmission) {
                    ActivityCompat.requestPermissions(AllPermissionForSingleClickActivity.this, new String[]{WRITE_EXTERNAL_STORAGE, READ_EXTERNAL_STORAGE}, REQUEST_PERMISSION_TRASHCLEANER);
                } else {
                    showPermissionMAnualyDialog(REQUEST_PERMISSION_SETTING);
                }
            } /*else if (!isAccessGranted()) {
//                AppOpenManager.getInstance().disableAppResume();
                isOpenPermissionScreeen = true;
                Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
                startActivityForResult(intent, 101);
            }*/
        }
    }


    public void RequestPermissionDialogForStorageCleaner() {
        if (SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                if (new SessionHelper(this).getStringData(SessionHelper.IS_PERMISSSION_OPEN_AD).equals("0")) {
                    AdconfigApplication.Companion.disabledOpenAds();
                }
                isOpenPermissionScreeen = true;
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                Uri uri = Uri.fromParts("package", getPackageName(), null);
                intent.setData(uri);

                try {
                    startActivityForResult(intent, REQUEST_PERMISSION_STORAGECLEANER);
                } catch (ActivityNotFoundException e) {

                    try {
                        intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                        startActivityForResult(intent, REQUEST_PERMISSION_STORAGECLEANER);
                    } catch (ActivityNotFoundException e1) {
                        Intent i1 = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.fromParts("package", getPackageName(), null));
                        startActivityForResult(i1, REQUEST_PERMISSION_STORAGECLEANER);

                    }
                }
            }
        } else {
            int write = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
            int read = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);

            if (write != PackageManager.PERMISSION_GRANTED && read != PackageManager.PERMISSION_GRANTED) {
                if (!isDeniedPErmission) {
                    ActivityCompat.requestPermissions(AllPermissionForSingleClickActivity.this, new String[]{WRITE_EXTERNAL_STORAGE, READ_EXTERNAL_STORAGE}, REQUEST_PERMISSION_STORAGECLEANER);
                } else {
                    showPermissionMAnualyDialog(REQUEST_PERMISSION_SETTING_STORAGE);
                }
            }
        }
    }

    public void RequestPermissionDialogForAppCleaner() {
        if (SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                if (new SessionHelper(this).getStringData(SessionHelper.IS_PERMISSSION_OPEN_AD).equals("0")) {
                    AdconfigApplication.Companion.disabledOpenAds();
                }
                isOpenPermissionScreeen = true;
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                Uri uri = Uri.fromParts("package", getPackageName(), null);
                intent.setData(uri);

                try {
                    startActivityForResult(intent, REQUEST_PERMISSION_APPCLEANER);
                } catch (ActivityNotFoundException e) {
                    try {
                        intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                        startActivityForResult(intent, REQUEST_PERMISSION_APPCLEANER);
                    } catch (ActivityNotFoundException e1) {
                        Intent i1 = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.fromParts("package", getPackageName(), null));
                        startActivityForResult(i1, REQUEST_PERMISSION_APPCLEANER);
                    }
                }
            }
        } else {
            int write = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
            int read = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);

            if (write != PackageManager.PERMISSION_GRANTED && read != PackageManager.PERMISSION_GRANTED) {
                if (!isDeniedPErmission) {
                    ActivityCompat.requestPermissions(AllPermissionForSingleClickActivity.this, new String[]{WRITE_EXTERNAL_STORAGE, READ_EXTERNAL_STORAGE}, REQUEST_PERMISSION_APPCLEANER);
                } else {
                    showPermissionMAnualyDialog(REQUEST_PERMISSION_SETTING_STORAGE);
                }
            }
        }
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleHelper.onAttach(base, "en"));
    }

    public boolean isAccessGranted() {
        AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
        int mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), getPackageName());
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (requestCode == REQUEST_PERMISSION_TRASHCLEANER) {
            Log.d(TAG, "onActivityResult: back manage external");
            if (SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {

                    startActivity(new Intent(AllPermissionForSingleClickActivity.this, JunkActivity.class));
                    finish();
                }
            } else {
                if (!isAccessGranted()) {
                    Log.d(TAG, "onActivityResult: usage access open");

                    if (new SessionHelper(this).getStringData(SessionHelper.IS_PERMISSSION_OPEN_AD).equals("0")) {
                        AdconfigApplication.Companion.disabledOpenAds();
                    }
                    isOpenPermissionScreeen = true;
                    Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
                    startActivityForResult(intent, 101);
                    usagePermissionMonitor.startListening();
                } else {
                    Log.d(TAG, "onActivityResult: usage access open else");
                }
            }

        }
        if (requestCode == REQUEST_PERMISSION_STORAGECLEANER) {
            Log.d(TAG, "onActivityResult: back manage external");
            /*new Handler().postDelayed(new Runnable() {
                public void run() {
                    AppOpenManager.getInstance().enableAppResume();
                }
            }, 3000);*/
            if (SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    if (storage_cleaner.equals("StorageCleaner")) {
                        startActivity(new Intent(AllPermissionForSingleClickActivity.this, StorageCleanerActivity.class));
                        finish();
                    }
                }
            } else {
                int write = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
                int read = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);

                if (write != PackageManager.PERMISSION_GRANTED && read != PackageManager.PERMISSION_GRANTED) {
                    if (!isDeniedPErmission) {
                        ActivityCompat.requestPermissions(AllPermissionForSingleClickActivity.this, new String[]{WRITE_EXTERNAL_STORAGE, READ_EXTERNAL_STORAGE}, REQUEST_PERMISSION_STORAGECLEANER);
                    } else {
                        showPermissionMAnualyDialog(REQUEST_PERMISSION_SETTING_STORAGE);
                    }
                } else {
                    if (storage_cleaner.equals("StorageCleaner")) {
                        startActivity(new Intent(AllPermissionForSingleClickActivity.this, StorageCleanerActivity.class));
                        finish();
                    }
                }
            }
        } else if (requestCode == REQUEST_PERMISSION_APPCLEANER) {
            Log.d(TAG, "onActivityResult: back manage external");

            if (SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    if (Utils.appInstalledOrNot(AllPermissionForSingleClickActivity.this)) {
                        startActivity(new Intent(AllPermissionForSingleClickActivity.this, AppCleanLastFolderWiseDataActivity.class).putExtra("AppName", "WhatsApp"));
                        finish();
                    } else {
                        Toast.makeText(this, "WhatApp Not Installed", Toast.LENGTH_SHORT).show();
                    }
                }
            } else {
                int write = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
                int read = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);

                if (write != PackageManager.PERMISSION_GRANTED && read != PackageManager.PERMISSION_GRANTED) {
                    if (!isDeniedPErmission) {
                        ActivityCompat.requestPermissions(AllPermissionForSingleClickActivity.this, new String[]{WRITE_EXTERNAL_STORAGE, READ_EXTERNAL_STORAGE}, REQUEST_PERMISSION_APPCLEANER);
                    } else {
                        showPermissionMAnualyDialog(REQUEST_PERMISSION_SETTING_APP_CLEANER);
                    }
                } else {
                    if (Utils.appInstalledOrNot(AllPermissionForSingleClickActivity.this)) {
                        startActivity(new Intent(AllPermissionForSingleClickActivity.this, AppCleanLastFolderWiseDataActivity.class).putExtra("AppName", "WhatsApp"));
                        finish();
                    } else {
                        Toast.makeText(this, "WhatApp Not Installed", Toast.LENGTH_SHORT).show();
                    }
                }
            }

        } /*else if (requestCode == 101) {
            if (isAccessGranted()) {
                if (Utils.appInstalledOrNot(AllPermissionForSingleClickActivity.this)) {
                    startActivity(new Intent(AllPermissionForSingleClickActivity.this, AppCleanLastFolderWiseDataActivity.class).putExtra("AppName", "WhatsApp"));
                    finish();
                } else {
                    Toast.makeText(this, "WhatApp Not Installed", Toast.LENGTH_SHORT).show();
                }
            }
        }*/ else if (requestCode == 1001) {
            if (isAccessGranted() && !Settings.canDrawOverlays(AllPermissionForSingleClickActivity.this)) {
                Log.e("hello123456789", "3333333333");

                if (new SessionHelper(this).getStringData(SessionHelper.IS_PERMISSSION_OPEN_AD).equals("0")) {
                    AdconfigApplication.Companion.disabledOpenAds();
                }
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, 1010);
            }

        } else if (requestCode == 1010) {

            if (new SessionHelper(this).getStringData(SessionHelper.IS_PERMISSSION_OPEN_AD).equals("0")) {
                AdconfigApplication.Companion.disabledOpenAds();
            }
            if (Settings.canDrawOverlays(AllPermissionForSingleClickActivity.this)) {
                Log.e("hello123456789", "44444444444444");

//                new Myapplication().enabledOpenAds();
                startActivity(new Intent(AllPermissionForSingleClickActivity.this, StartAppLock.class));
                finish();

            }
        } else if (requestCode == REQUEST_PERMISSION_SETTING) {
            isDeniedPErmission = permission_preference.getBoolean("isDeniedPErmission", false);
            if (SDK_INT <= Build.VERSION_CODES.Q) {

                int write = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
                int read = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);

                if (write != PackageManager.PERMISSION_GRANTED && read != PackageManager.PERMISSION_GRANTED) {
                    if (!isDeniedPErmission) {
                        ActivityCompat.requestPermissions(AllPermissionForSingleClickActivity.this, new String[]{WRITE_EXTERNAL_STORAGE, READ_EXTERNAL_STORAGE}, REQUEST_PERMISSION_TRASHCLEANER);
                    } else {
                        showPermissionMAnualyDialog(REQUEST_PERMISSION_SETTING);
                    }
                } else {

                    if (new SessionHelper(this).getStringData(SessionHelper.IS_PERMISSSION_OPEN_AD).equals("0")) {
                        AdconfigApplication.Companion.disabledOpenAds();
                    }
                    isOpenPermissionScreeen = true;
                    Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
                    startActivityForResult(intent, 101);
                    usagePermissionMonitor.startListening();
                }
            }
        } else if (requestCode == REQUEST_PERMISSION_SETTING_STORAGE) {
            isDeniedPErmission = permission_preference.getBoolean("isDeniedPErmission", false);
            if (SDK_INT <= Build.VERSION_CODES.Q) {

                int write = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
                int read = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);

                if (write != PackageManager.PERMISSION_GRANTED && read != PackageManager.PERMISSION_GRANTED) {
                    if (!isDeniedPErmission) {
                        ActivityCompat.requestPermissions(AllPermissionForSingleClickActivity.this, new String[]{WRITE_EXTERNAL_STORAGE, READ_EXTERNAL_STORAGE}, REQUEST_PERMISSION_STORAGECLEANER);
                    } else {
                        showPermissionMAnualyDialog(REQUEST_PERMISSION_SETTING_STORAGE);
                    }
                } else {
                    if (storage_cleaner.equals("StorageCleaner")) {
                        startActivity(new Intent(AllPermissionForSingleClickActivity.this, StorageCleanerActivity.class));
                        finish();
                    }
                }
            }
        } else if (requestCode == REQUEST_PERMISSION_SETTING_APP_CLEANER) {
            isDeniedPErmission = permission_preference.getBoolean("isDeniedPErmission", false);
            if (SDK_INT <= Build.VERSION_CODES.Q) {

                int write = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
                int read = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);

                if (write != PackageManager.PERMISSION_GRANTED && read != PackageManager.PERMISSION_GRANTED) {
                    if (!isDeniedPErmission) {
                        ActivityCompat.requestPermissions(AllPermissionForSingleClickActivity.this, new String[]{WRITE_EXTERNAL_STORAGE, READ_EXTERNAL_STORAGE}, REQUEST_PERMISSION_APPCLEANER);
                    } else {
                        showPermissionMAnualyDialog(REQUEST_PERMISSION_SETTING_APP_CLEANER);
                    }
                } else {
//                    AppOpenManager.getInstance().enableAppResume();
                    if (Utils.appInstalledOrNot(AllPermissionForSingleClickActivity.this)) {
                        startActivity(new Intent(AllPermissionForSingleClickActivity.this, AppCleanLastFolderWiseDataActivity.class).putExtra("AppName", "WhatsApp"));
                        finish();
                    } else {
                        Toast.makeText(this, "WhatApp Not Installed", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        } else {
            Log.d(TAG, "onActivityResult: back usage access open else");
        }

    }


    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "onActivityResult: on start call");
//        AppOpenManager.getInstance().enableAppResume();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onActivityResult: resume call");
//        IronSource.onResume(this);

        SharedPreferences sharedPref = getSharedPreferences("language", MODE_PRIVATE);
        String s1 = sharedPref.getString("selectedlanguage", "");
        LocaleHelper.setLocale(this, s1);
        if (isAccessGranted()) {
            isOpenPermissionScreeen = false;
            //Added this
            new Utils().disebledOpenAdsBasedOnFireBase();

//            AppOpenManager.getInstance().enableAppResume();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
//        IronSource.onPause(this);

        Log.d(TAG, "onActivityResult: on pause call");
        if (isOpenPermissionScreeen) {
//            new Myapplication().disabledOpenAds();
        }
    }

    public void showPermissionMAnualyDialog(int REQUEST_CODE_PERMISSION) {
        final View dialogView = getLayoutInflater().inflate(R.layout.dialog_permission_dont_allow, null);
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);

        TextView buttonCancel = dialogView.findViewById(R.id.buttonCancel);
        TextView buttonOk = dialogView.findViewById(R.id.buttonOk);

        buttonCancel.setOnClickListener(view1 -> alertDialog.dismiss());

        buttonOk.setOnClickListener(view12 -> {
            alertDialog.dismiss();

            if (new SessionHelper(this).getStringData(SessionHelper.IS_PERMISSSION_OPEN_AD).equals("0")) {
                AdconfigApplication.Companion.disabledOpenAds();
            }
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            Uri uri = Uri.fromParts("package", getPackageName(), null);
            intent.setData(uri);
            startActivityForResult(intent, REQUEST_CODE_PERMISSION);
        });

        builder.setView(dialogView);
        alertDialog = builder.create();

        InsetDrawable inset = new InsetDrawable(new ColorDrawable(Color.TRANSPARENT), 40);
        alertDialog.getWindow().setBackgroundDrawable(inset);
        alertDialog.show();
    }


    public static class UsagePermissionMonitor {

        private final Context context;
        private final AppOpsManager appOpsManager;
        private final Handler handler;
        private boolean isListening;
        private Boolean lastValue;

        public UsagePermissionMonitor(Context context) {
            this.context = context;
            appOpsManager = (AppOpsManager) context.getSystemService(Context.APP_OPS_SERVICE);
            handler = new Handler();
        }

        public void startListening() {
            appOpsManager.startWatchingMode(AppOpsManager.OPSTR_GET_USAGE_STATS, context.getPackageName(), usageOpListener);
            isListening = true;
        }

        public void stopListening() {
            lastValue = null;
            isListening = false;
            appOpsManager.stopWatchingMode(usageOpListener);
            handler.removeCallbacks(checkUsagePermission);
        }

        private final AppOpsManager.OnOpChangedListener usageOpListener = new AppOpsManager.OnOpChangedListener() {
            @Override
            public void onOpChanged(String op, String packageName) {
                // Android sometimes sets packageName to null
                if (packageName == null || context.getPackageName().equals(packageName)) {
                    // Android actually notifies us of changes to ops other than the one we registered for, so filtering them out
                    if (AppOpsManager.OPSTR_GET_USAGE_STATS.equals(op)) {
                        // We're not in main thread, so post to main thread queue
                        handler.post(checkUsagePermission);
                    }
                }
            }
        };

        private final Runnable checkUsagePermission = new Runnable() {
            @Override
            public void run() {
                if (isListening) {
                    int mode = appOpsManager.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), context.getPackageName());
                    boolean enabled = mode == AppOpsManager.MODE_ALLOWED;

                    // Each change to the permission results in two callbacks instead of one.
                    // Filtering out the duplicates.
                    if (lastValue == null || lastValue != enabled) {
                        lastValue = enabled;

                        // TODO: Do something with the result
                        Log.i(UsagePermissionMonitor.class.getSimpleName(), "Usage permission changed: " + enabled);
                    }
                }
            }
        };

    }
}