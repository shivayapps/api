package com.cleanmaster.trashcleaner.junkeraser.model;

public class AlgorithmItem {
    private String algorithmName;

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    private String path;

    public AlgorithmItem(String countryName, String path) {
        algorithmName = countryName;
        this.path = path;
    }

    public String getAlgorithmName() {
        return algorithmName;
    }
}