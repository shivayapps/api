package com.cleanmaster.trashcleaner.junkeraser.receiver;

import static android.content.Context.BATTERY_SERVICE;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.BatteryManager;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.room.Room;

import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.Utils;
import com.cleanmaster.trashcleaner.junkeraser.database.ApplicationDatabase;
import com.cleanmaster.trashcleaner.junkeraser.database.ChargeHistoryModel;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class PowerMonitorReceiver extends BroadcastReceiver {
    private static final String TAG = "PowerMonitorReceiver.TAG";
    ApplicationDatabase applicationDatabase;
    Context context;
    SharedPreferences sharedPreferences;

    @Override
    public void onReceive(Context context, Intent intent) {
        this.context = context;
        String action = intent.getAction();
        Log.d("ffgfdgfgdf", "Battery has changed" + action);
        //applicationDatabase = Room.databaseBuilder(context, ApplicationDatabase.class, "application_db").allowMainThreadQueries().build();
        applicationDatabase = Utils.getApplicationDatabase(context);
        sharedPreferences = context.getSharedPreferences("intentData", Context.MODE_PRIVATE);

        if (applicationDatabase.chargeHistoryDao().getAllcharge_historyList().size() == 0) {
            applicationDatabase.chargeHistoryDao().charge_histoty_insert(new ChargeHistoryModel("No Record", "USB", "00:00", 0, 0, 0, 0, false));
        }

        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                switch (action) {
                    case (Intent.ACTION_BATTERY_CHANGED): {

                        Calendar calendar;
                        SimpleDateFormat dateFormat;
                        String current_date;
                        if (applicationDatabase.chargeHistoryDao().getAllcharge_historyList().size() == 0) {
                            applicationDatabase.chargeHistoryDao().charge_histoty_insert(new ChargeHistoryModel("No Record", "USB", "00:00", 0, 0, 0, 0, false));
                        }

                        Log.d("ffgfdgfgdf", "Battery has changed");

                        int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                        int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);

                        Date date = new Date();
                        SimpleDateFormat getdate = new SimpleDateFormat("hh:mm a");

                        dateFormat = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
                        calendar = Calendar.getInstance();
                        current_date = dateFormat.format(calendar.getTime());

                        if (level == 20) {
                            if (sharedPreferences != null && sharedPreferences.getInt("low_power", 99) == 1) {
                                setminiNotification("Battery is Low", level + "%" + "Remaining", false);
                            } else {

                            }
                        } else if (level == 15) {
                            if (sharedPreferences != null && sharedPreferences.getInt("low_power", 99) == 1) {
                                setminiNotification("Battery is Low", level + "%" + "Remaining", false);
                            } else {
                                setminiNotification("Battery is Low", level + "%" + "Remaining", false);
                            }
                        }

                        if (level == 100) {
                            if (sharedPreferences != null && sharedPreferences.getInt("full_charging", 99) == 1) {
                                setminiNotification("Battery is fully Charged", level + "%" + "Battery", false);
                            } else {
                                setminiNotification("Battery is fully Charged", level + "%" + "Battery", false);
                            }
                            if (!applicationDatabase.chargeHistoryDao().getAllcharge_historyList().get(0).isIsfullcharged()) {

                                int i = 100 - applicationDatabase.chargeHistoryDao().getAllcharge_historyList().get(0).getStart_charging_level();
                                update_insert_database(current_date, getdate.format(date), true, i);
                            }
                        }
                        break;
                    }
                    case (Intent.ACTION_POWER_CONNECTED): {
                        onConnected(context, intent);
                        break;
                    }
                    case (Intent.ACTION_POWER_DISCONNECTED): {
                        Log.d("ffgfdgfgdf", "Power disconnected");

                        try {
                            if (applicationDatabase.chargeHistoryDao().getAllcharge_historyList().get(0).getFull_charge() != null) {
                                update_insert_database(getChargeDuration(context), false, get_normal_charge(context), get_helthy_charge(), get_over_charge(), false);
                            }
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        break;
                    }
                    case (Intent.ACTION_BATTERY_LOW): {
                        Log.d("ffgfdgfgdf", "Battery low");
                        break;
                    }
                    case (Intent.ACTION_BATTERY_OKAY): {
                        Log.d("ffgfdgfgdf", "Battery Okay");
                        break;
                    }
                }
            }
        }, 1000);

    }

  /*  public void sendNotification(String t1, String t2) {

        Intent notificationIntent = new Intent(context, SplashActivity.class);
        notificationIntent.addCategory(Intent.CATEGORY_LAUNCHER);
        notificationIntent.setAction(Intent.ACTION_MAIN);
        notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        Myapplication myapplication = new Myapplication();
        PendingIntent resultIntent = PendingIntent.getActivity(myapplication.getApplication(), 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(myapplication.getApplication(),
                "default_notification_channel_id")
                .setSmallIcon(R.drawable.icon)
                .setContentTitle(t1)
                .setContentText(t2)
                .setContentIntent(resultIntent);
        NotificationManager mNotificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel notificationChannel = new
                    NotificationChannel("10001", "NOTIFICATION_CHANNEL_NAME", importance);
            mBuilder.setChannelId("10001");
            assert mNotificationManager != null;
            mNotificationManager.createNotificationChannel(notificationChannel);
        }
        assert mNotificationManager != null;
        mNotificationManager.notify((int) System.currentTimeMillis(),
                mBuilder.build());
    }*/

    public void setminiNotification(String t1, String t2, boolean isbuttonshow) {
        Log.d(TAG, "setminiNotification: ");

//        sendNotification(t1, t2);

        /*RemoteViews collapsedView = new RemoteViews(context.getPackageName(), R.layout.notification_collapsed);

        Intent clickIntent = new Intent(context, SplashActivity.class);
        PendingIntent clickPendingIntent;
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            clickPendingIntent = PendingIntent.getBroadcast(context,
                    0, clickIntent, PendingIntent.FLAG_MUTABLE);
        }else {
            clickPendingIntent = PendingIntent.getBroadcast(context,
                    0, clickIntent, PendingIntent.FLAG_IMMUTABLE);
        }

        collapsedView.setTextViewText(R.id.text_view_collapsed_1, t1);
        collapsedView.setTextViewText(R.id.text_view_collapsed_2, t2);

        Intent notificationIntent = new Intent(context, DashBoardActivity.class);
        notificationIntent.putExtra("NotificationMessage", "I am from Notification");
        notificationIntent.addCategory(Intent.CATEGORY_LAUNCHER);
        notificationIntent.setAction(Intent.ACTION_MAIN);
        notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent resultIntent = null;
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            resultIntent = PendingIntent.getActivity(context, 0, notificationIntent, PendingIntent.FLAG_MUTABLE);
        }else {
            resultIntent = PendingIntent.getActivity(context, 0, notificationIntent, 0);
        }
//        collapsedView.setOnClickPendingIntent(R.id.btn_clean, resultIntent);
        Notification notification = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.icon)
                .setCustomContentView(collapsedView)
                .setContentIntent(clickPendingIntent)
                .build();
        notificationManager.notify(1, notification);*/
    }

    public void onConnected(Context context, Intent intent) {
        Log.d("ffgfdgfgdf", "Power connected");

        int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        boolean isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL;

        String chargingType = "USB";

//        if (isCharging && chargingType != null) {
//            chargingType = "USB";
////            Toast.makeText(context, "Device is charging via: " + chargingType, Toast.LENGTH_SHORT).show();
//        } else {
//            chargingType = "AC";
////            Toast.makeText(context, "Device is charging.", Toast.LENGTH_SHORT).show();
//        }
        Date date = new Date();
        SimpleDateFormat gettime = new SimpleDateFormat("hh:mm a");
        String time = gettime.format(date);
        BatteryManager bm = (BatteryManager) context.getSystemService(BATTERY_SERVICE);
        int i = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);

        IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = context.registerReceiver(null, ifilter);

        int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);

        float currentBatteryLevel = ((level * 100) / (float) scale);

        Log.d(TAG, "onConnected: " + i);
        update_insert_database(chargingType, time, time, true, false, i);

    }

    public String getChargeDuration(Context context) throws ParseException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("hh:mm a");
        Date date = new Date();
        Date start_time=new Date();
        String strStartTime=applicationDatabase.chargeHistoryDao().getAllcharge_historyList().get(0).getStart_time();
        if(strStartTime!=null && !strStartTime.isEmpty())
            start_time = simpleDateFormat.parse(applicationDatabase.chargeHistoryDao().getAllcharge_historyList().get(0).getStart_time());

        Date end_time = simpleDateFormat.parse(simpleDateFormat.format(date));

        long difference = 0;
        if (start_time != null && end_time != null) {
            difference = end_time.getTime() - start_time.getTime();
        }

        long days = (int) (difference / (1000 * 60 * 60 * 24));
        long hours = (int) ((difference - (1000 * 60 * 60 * 24 * days)) / (1000 * 60 * 60));
        long min = (int) (difference - (1000 * 60 * 60 * 24 * days) - (1000 * 60 * 60 * hours)) / (1000 * 60);
        hours = (hours < 0 ? -hours : hours);

        String final_duration = hours + ":" + min;

//        Toast.makeText(context, "disconnect : " + final_duration + "   "+ simpleDateFormat.format(start_time) +  "    "+ simpleDateFormat.format(end_time), Toast.LENGTH_SHORT).show();

        return final_duration;
    }

    public int get_normal_charge(Context context) throws ParseException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("hh:mm a");
        Date date = new Date();
        Date start_time = simpleDateFormat.parse(applicationDatabase.chargeHistoryDao().getAllcharge_historyList().get(0).getFull_charge());
        Date end_time = simpleDateFormat.parse(simpleDateFormat.format(date));

        long difference = end_time.getTime() - start_time.getTime();
        long days = (int) (difference / (1000 * 60 * 60 * 24));
        long hours = (int) ((difference - (1000 * 60 * 60 * 24 * days)) / (1000 * 60 * 60));
        long min = (int) (difference - (1000 * 60 * 60 * 24 * days) - (1000 * 60 * 60 * hours)) / (1000 * 60);

//        Toast.makeText(context, "normal charge : " + applicationDatabase.chargeHistoryDao().getAllcharge_historyList().get(0).getCharge_normal() +"    "+ min, Toast.LENGTH_SHORT).show();
        int normal_charge = applicationDatabase.chargeHistoryDao().getAllcharge_historyList().get(0).getCharge_normal();
        if (min >= 30 && min <= 59 && hours == 0) {
            normal_charge += 1;
        }

        return normal_charge;
    }

    public int get_helthy_charge() throws ParseException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("hh:mm a");
        Date date = new Date();
        Date start_time = simpleDateFormat.parse(applicationDatabase.chargeHistoryDao().getAllcharge_historyList().get(0).getFull_charge());
        Date end_time = simpleDateFormat.parse(simpleDateFormat.format(date));

        long difference = end_time.getTime() - start_time.getTime();
        long days = (int) (difference / (1000 * 60 * 60 * 24));
        long hours = (int) ((difference - (1000 * 60 * 60 * 24 * days)) / (1000 * 60 * 60));
        long min = (int) (difference - (1000 * 60 * 60 * 24 * days) - (1000 * 60 * 60 * hours)) / (1000 * 60);

        int healthy_charge = applicationDatabase.chargeHistoryDao().getAllcharge_historyList().get(0).getCharge_healthy();
        if (hours >= 1 && hours < 2) {
            healthy_charge += 1;
        }

        return healthy_charge;
    }

    public int get_over_charge() throws ParseException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("hh:mm a");
        Date date = new Date();
        Date start_time = simpleDateFormat.parse(applicationDatabase.chargeHistoryDao().getAllcharge_historyList().get(0).getFull_charge());
        Date end_time = simpleDateFormat.parse(simpleDateFormat.format(date));

        long difference = end_time.getTime() - start_time.getTime();
        long days = (int) (difference / (1000 * 60 * 60 * 24));
        long hours = (int) ((difference - (1000 * 60 * 60 * 24 * days)) / (1000 * 60 * 60));
        long min = (int) (difference - (1000 * 60 * 60 * 24 * days) - (1000 * 60 * 60 * hours)) / (1000 * 60);


        int overCharge = applicationDatabase.chargeHistoryDao().getAllcharge_historyList().get(0).getCharge_overcharged();
        if (hours >= 2) {
            overCharge += 1;
        }

        return overCharge;
    }

    //if battery is changed
    public void update_insert_database(String full_charged, String full_charge, boolean isfullCharged, int start_battery_level) {

        Log.d("dfdfwerer", "update_insert_database: " + applicationDatabase.chargeHistoryDao().getAllcharge_historyList().size());

        if (applicationDatabase.chargeHistoryDao().getAllcharge_historyList().size() != 0) {

            applicationDatabase.chargeHistoryDao().updateUsingID(full_charged, full_charge, isfullCharged, start_battery_level);
        } else {
            applicationDatabase.chargeHistoryDao().charge_histoty_insert(new ChargeHistoryModel("No Record", "USB", "00:00", 0, 0, 0, 0, false));
        }
    }

    //if power connected
    public void update_insert_database(String chargeType, String chargeduration, String start_time, boolean ispower, boolean isfullCharged, int start_battery_level) {

        if (applicationDatabase.chargeHistoryDao().getAllcharge_historyList().size() != 0) {

            applicationDatabase.chargeHistoryDao().updateUsingID(chargeType, chargeduration, start_time, ispower, isfullCharged, start_battery_level);
        } else {
            applicationDatabase.chargeHistoryDao().charge_histoty_insert(new ChargeHistoryModel("No Record", "USB", "00:00", 0, 0, 0, 0, false));
        }
    }

    //if power disconnect
    public void update_insert_database(String chargeduration, boolean ispower, int normal_charged, int healthy_charged, int overCharged, boolean isfullcharged) {

        if (applicationDatabase.chargeHistoryDao().getAllcharge_historyList().size() != 0) {

            applicationDatabase.chargeHistoryDao().updateUsingID(chargeduration, ispower, normal_charged, healthy_charged, overCharged, isfullcharged);
        } else {
            applicationDatabase.chargeHistoryDao().charge_histoty_insert(new ChargeHistoryModel("No Record", "USB", "00:00", 0, 0, 0, 0, false));
        }
    }
}
