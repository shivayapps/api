package com.cleanmaster.trashcleaner.junkeraser.activity;

import static com.cleanmaster.trashcleaner.junkeraser.activity.StorageCleanerActivity.allPhotos;
import static com.cleanmaster.trashcleaner.junkeraser.utils.StorageInformation.isNetworkConnected;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.InsetDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.ads.module.adutills.ClickCallback;
import com.ads.module.adutills.RewardedAdClass;
import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.Utils;
import com.cleanmaster.trashcleaner.junkeraser.adapter.imageRecycleAdapter;
import com.cleanmaster.trashcleaner.junkeraser.helper.LocaleHelper;
import com.codeboy.mediafacer.mediaHolders.pictureContent;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class pictureActivity extends BaseActivity {
    public static int DELETE_REQUEST_CODE = 200;
    RecyclerView picture_recycler;

    private ArrayList<pictureContent> selectedImageList = new ArrayList<>();
    private imageRecycleAdapter pictureAdapter;
    private ImageView btnCleanStorage;
    long sum = 0;
    private boolean isSelectImage = false;
    private AlertDialog alertDialog;
    private ConstraintLayout emptyView;
    private ImageView imgAllSelect;
    RewardedAdClass rewardedAdClass;

    @SuppressWarnings("InvalidSetHasFixedSize")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_picture);


        TextView text_title = findViewById(R.id.text_title);
        text_title.setText(R.string.images);

        selectedImageList = new ArrayList<>();

        ImageView imgBack = findViewById(R.id.imgBack);
        imgBack.setOnClickListener(v -> onBackPressed());

        emptyView = findViewById(R.id.emptyView);
        picture_recycler = findViewById(R.id.picture_recycler);
        btnCleanStorage = findViewById(R.id.btnCleanStorage);
        imgAllSelect = findViewById(R.id.imgAllSelect);
        picture_recycler.hasFixedSize();
        picture_recycler.setHasFixedSize(true);
        picture_recycler.setItemViewCacheSize(20);
        picture_recycler.setDrawingCacheEnabled(true);
        picture_recycler.setDrawingCacheQuality(View.DRAWING_CACHE_QUALITY_HIGH);

        setUpAndDisplayPictures();

        btnCleanStorage.setOnClickListener(v -> showDeleteDialog(sum));

        imgAllSelect.setOnClickListener(v -> {
            if (!isSelectImage) {
                setAllSelect();
                imgAllSelect.setImageResource(R.drawable.ic_all_select);
                isSelectImage = true;
            } else {
                setAllUnSelect();
                imgAllSelect.setImageResource(R.drawable.ic_all_select);
                isSelectImage = false;
            }
        });

//        if (isNetworkAvailable(pictureActivity.this) && new SessionHelper(pictureActivity.this).getStringData(SessionHelper.REWARD_ADS_ID) != null) {
            rewardedAdClass = new RewardedAdClass(pictureActivity.this);
            rewardedAdClass.loadRewardedAd();
//        }
    }

    void setUpAndDisplayPictures() {
        imageRecycleAdapter.pictureActionListrener actionListener = new imageRecycleAdapter.pictureActionListrener() {

            @Override
            public void onPictureItemClicked(int position, ArrayList<pictureContent> arrayListimage) {
                allPhotos = arrayListimage;
                selectedImageList.clear();
                sum = 0;
                for (int i = 0; i < arrayListimage.size(); i++) {
                    if (arrayListimage.get(i).isSelected()) {
                        selectedImageList.add(arrayListimage.get(i));
                        sum = sum + arrayListimage.get(i).getPictureSize();
                    }
                }

//                btnCleanStorage.setText(getResources().getString(R.string.clean)+"("+  convertFileSize(sum) + ")");

                if (selectedImageList.size() > 0) {
                    btnCleanStorage.setVisibility(View.VISIBLE);
                } else {
                    btnCleanStorage.setVisibility(View.GONE);
                }

                if (selectedImageList.size() == allPhotos.size()) {
                    isSelectImage = true;
                    imgAllSelect.setImageResource(R.drawable.ic_all_unselect);
                } else {
                    isSelectImage = false;
                    imgAllSelect.setImageResource(R.drawable.ic_all_select);

                }
            }

        };
        if (allPhotos != null && allPhotos.size() > 0) {
            pictureAdapter = new imageRecycleAdapter(this, allPhotos, actionListener);
            picture_recycler.setAdapter(pictureAdapter);
        }

        if (allPhotos != null && allPhotos.size() > 0) {

            imgAllSelect.setVisibility(View.VISIBLE);
            emptyView.setVisibility(View.GONE);
            picture_recycler.setVisibility(View.VISIBLE);


        } else {

            imgAllSelect.setVisibility(View.GONE);
            emptyView.setVisibility(View.VISIBLE);
            picture_recycler.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 101 && resultCode == RESULT_OK) {
            boolean isChange = data.getBooleanExtra("isChange", false);
            int currentpos = data.getIntExtra("currentpos", 0);
            if (isChange) {
                pictureAdapter.notifyItemRemoved(currentpos);
            }
        }
    }


    public static String convertFileSize(long sizeInBytes) {
        String[] units = {"B", "KB", "MB", "GB"};
        double size = sizeInBytes;
        int index = 0;
        while (size > 1024 && index < units.length - 1) {
            size /= 1024;
            index++;
        }
        return String.format("%.2f %s", size, units[index]);
    }

    @SuppressLint("NotifyDataSetChanged")
    private void setAllSelect() {
        for (int i = 0; i < allPhotos.size(); i++) {
            if (!allPhotos.get(i).isSelected()) {
                allPhotos.get(i).setSelected(true);
            }
        }
        selectedImageList.clear();
        sum = 0;
        for (int i = 0; i < allPhotos.size(); i++) {
            if (allPhotos.get(i).isSelected()) {
                selectedImageList.add(allPhotos.get(i));
                sum = sum + allPhotos.get(i).getPictureSize();
            }
        }

//        btnCleanStorage.setText(getResources().getString(R.string.clean)+"("+  convertFileSize(sum) + ")");

        if (selectedImageList.size() > 0) {
            btnCleanStorage.setVisibility(View.VISIBLE);
        } else {
            btnCleanStorage.setVisibility(View.GONE);
        }

        pictureAdapter.notifyDataSetChanged();

    }

    @SuppressLint("NotifyDataSetChanged")
    private void setAllUnSelect() {
        if (allPhotos != null && allPhotos.size() > 0) {
            for (int i = 0; i < allPhotos.size(); i++) {
                if (allPhotos.get(i).isSelected()) {
                    allPhotos.get(i).setSelected(false);
                }
            }
            selectedImageList.clear();
            selectedImageList.size();
            btnCleanStorage.setVisibility(View.GONE);
            if (pictureAdapter != null) {
                pictureAdapter.notifyDataSetChanged();
            }
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        setAllUnSelect();
    }

    @Override
    protected void onResume() {

        SharedPreferences sharedPrefs = getSharedPreferences("language", MODE_PRIVATE);
        String s1 = sharedPrefs.getString("selectedlanguage", "");
        LocaleHelper.setLocale(this, s1);
        new Utils().disebledOpenAdsBasedOnFireBase();

        super.onResume();
    }


    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleHelper.onAttach(base, "en"));
    }

    public void deleteFileFromMediaStore(final ContentResolver contentResolver, final File file) {
        String canonicalPath;
        try {
            canonicalPath = file.getCanonicalPath();
        } catch (IOException e) {
            canonicalPath = file.getAbsolutePath();
        }
        final Uri uri = MediaStore.Files.getContentUri("external");
        final int result = contentResolver.delete(uri,
                MediaStore.Files.FileColumns.DATA + "=?", new String[]{canonicalPath});
        if (result == 0) {
            final String absolutePath = file.getAbsolutePath();
            if (!absolutePath.equals(canonicalPath)) {
                contentResolver.delete(uri,
                        MediaStore.Files.FileColumns.DATA + "=?", new String[]{absolutePath});
            }
        }
    }

    public void showSuccessDialog() {
        final View dialogView = getLayoutInflater().inflate(R.layout.dialog_clear_success, null);
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);

        TextView buttonOk = dialogView.findViewById(R.id.buttonOk);

        buttonOk.setOnClickListener(view12 -> {
            alertDialog.dismiss();
        });

        builder.setView(dialogView);
        alertDialog = builder.create();
        alertDialog.setCancelable(false);
        InsetDrawable inset = new InsetDrawable(new ColorDrawable(Color.TRANSPARENT), 40);
        alertDialog.getWindow().setBackgroundDrawable(inset);
        alertDialog.show();
    }

    private void cleanTrash() {
        for (int j = 0; j < selectedImageList.size(); j++) {
            String path = selectedImageList.get(j).getPicturePath();
            File file11 = new File(path);
            allPhotos.remove(selectedImageList.get(j));
            deleteFileFromMediaStore(getContentResolver(), file11);
//                    file11.delete();
        }
        pictureAdapter.notifyDataSetChanged();
        btnCleanStorage.setVisibility(View.GONE);
        showSuccessDialog();
    }

    public void showDeleteDialog(long totalsize) {
        final View dialogView = getLayoutInflater().inflate(R.layout.dialog_delete, null);
        AlertDialog.Builder builder = new AlertDialog.Builder(pictureActivity.this);

        TextView buttonCancel = dialogView.findViewById(R.id.buttonCancel);
        TextView buttonOk = dialogView.findViewById(R.id.buttonOk);
        TextView tvDescription = dialogView.findViewById(R.id.tvDescription);
        TextView tvAppname = dialogView.findViewById(R.id.tvAppname);
        tvAppname.setText(getResources().getString(R.string.delete) + "(" + convertFileSize(totalsize) + ")");
        tvDescription.setText(getString(R.string.are_you_sure_you_want_to_delete_these) + getResources().getString(R.string.images) + "?");
        buttonCancel.setOnClickListener(view1 -> alertDialog.dismiss());

        buttonOk.setOnClickListener(view12 -> {
            alertDialog.dismiss();
            rewardedAdClass.displayRewardAds(new ClickCallback() {
                @Override
                public void clickNext() {
                    cleanTrash();
                }
            });
        });

        builder.setView(dialogView);
        alertDialog = builder.create();

        InsetDrawable inset = new InsetDrawable(new ColorDrawable(Color.TRANSPARENT), 40);
        alertDialog.getWindow().setBackgroundDrawable(inset);
        alertDialog.show();
    }
}
