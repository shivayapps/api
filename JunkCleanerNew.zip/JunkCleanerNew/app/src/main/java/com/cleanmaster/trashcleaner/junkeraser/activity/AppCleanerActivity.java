package com.cleanmaster.trashcleaner.junkeraser.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.ads.module.adutills.NativeLoadWithShows;
import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.helper.LocaleHelper;
import com.google.android.material.button.MaterialButton;

public class AppCleanerActivity extends BaseActivity {
    boolean isWhatsappInstalled = false;
    boolean isChromeInstalled = false;
    boolean isYoutubeInstalled = false;
    boolean isInstagramInstalled = false;
    boolean isTelegramInstalled = false;
    boolean isFacebookInstalled = false;
    boolean isMessengerInstalled = false;
    boolean isTiktokInstalled = false;
    int sum = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_cleaner);
//

        ImageView btn_back = findViewById(R.id.btn_back);
        btn_back.setOnClickListener(v -> onBackPressed());

        MaterialButton btnWhstasppClean = findViewById(R.id.btnWhstasppClean);
        MaterialButton btnChromeClean = findViewById(R.id.btnChromeClean);
        MaterialButton btnYoutubeClean = findViewById(R.id.btnYoutubeClean);
        MaterialButton btnInstagramClean = findViewById(R.id.btnInstagramClean);
        MaterialButton btnFacebookClean = findViewById(R.id.btnFacebookClean);
        MaterialButton btnTelegramClean = findViewById(R.id.btnTelegramClean);
        MaterialButton btnMessangerClean = findViewById(R.id.btnMessangerClean);
        MaterialButton btnTiktokClean = findViewById(R.id.btnTiktokClean);
        ConstraintLayout progressbar = findViewById(R.id.progressbar);

        loadNative();

        if (appInstalledOrNot()) {

//            btnWhstasppClean.setBackgroundColor(getResources().getColor(R.color.color_enable));
            btnWhstasppClean.setEnabled(true);
            isWhatsappInstalled = true;
            sum = sum + 1;

        } else {
//            btnWhstasppClean.setBackgroundColor(getResources().getColor(R.color.color_diable));
//            btnWhstasppClean.setEnabled(false);
            btnWhstasppClean.setTextColor(getResources().getColor(R.color.color_diable_text));
        }

        Intent instagramIntent = getPackageManager().getLaunchIntentForPackage("com.instagram.android");
        if (instagramIntent != null) {

            btnInstagramClean.setEnabled(true);
//            btnInstagramClean.setBackgroundColor(getResources().getColor(R.color.color_enable));
            isInstagramInstalled = true;
            sum = sum + 1;
        } else {
            btnInstagramClean.setBackgroundColor(getResources().getColor(R.color.color_diable));
//            btnInstagramClean.setEnabled(false);
            btnInstagramClean.setTextColor(getResources().getColor(R.color.blue));
        }

        Intent telegramIntent = getPackageManager().getLaunchIntentForPackage("org.telegram.messenger");
        if (telegramIntent != null) {

            btnTelegramClean.setEnabled(true);
//            btnTelegramClean.setBackgroundColor(getResources().getColor(R.color.color_enable));
            isTelegramInstalled = true;
            sum = sum + 1;
        } else {
            btnTelegramClean.setBackgroundColor(getResources().getColor(R.color.color_diable));
//            btnTelegramClean.setEnabled(false);
            btnTelegramClean.setTextColor(getResources().getColor(R.color.blue));
        }

        Intent facebookIntent = getPackageManager().getLaunchIntentForPackage("com.facebook.katana");
        if (facebookIntent != null) {

            btnFacebookClean.setEnabled(true);
//            btnFacebookClean.setBackgroundColor(getResources().getColor(R.color.color_enable));
            isFacebookInstalled = true;
            sum = sum + 1;
        } else {
            btnFacebookClean.setBackgroundColor(getResources().getColor(R.color.color_diable));
//            btnFacebookClean.setEnabled(false);
            btnFacebookClean.setTextColor(getResources().getColor(R.color.blue));
        }

        Intent messengerIntent = getPackageManager().getLaunchIntentForPackage("com.facebook.orca");
        if (messengerIntent != null) {

            btnMessangerClean.setEnabled(true);
//            btnMessangerClean.setBackgroundColor(getResources().getColor(R.color.color_enable));
            isFacebookInstalled = true;
            sum = sum + 1;
        } else {
            btnMessangerClean.setBackgroundColor(getResources().getColor(R.color.color_diable));
//            btnMessangerClean.setEnabled(false);
            btnMessangerClean.setTextColor(getResources().getColor(R.color.blue));
        }

        Intent tiktokIntent = getPackageManager().getLaunchIntentForPackage("com.zhiliaoapp.musically");
        if (tiktokIntent != null) {

            btnTiktokClean.setEnabled(true);
//            btnTiktokClean.setBackgroundColor(getResources().getColor(R.color.color_enable));
            isTiktokInstalled = true;
            sum = sum + 1;
        } else {
            btnTiktokClean.setBackgroundColor(getResources().getColor(R.color.color_diable));
//            btnTiktokClean.setEnabled(false);
            btnTiktokClean.setTextColor(getResources().getColor(R.color.blue));
        }

        Intent chromeIntent = getPackageManager().getLaunchIntentForPackage("com.android.chrome");
        if (chromeIntent != null) {

            btnChromeClean.setEnabled(true);
//            btnChromeClean.setBackgroundColor(getResources().getColor(R.color.color_enable));
            isChromeInstalled = true;
            sum = sum + 1;
        } else {
            btnChromeClean.setBackgroundColor(getResources().getColor(R.color.color_diable));
//            btnChromeClean.setEnabled(false);
            btnChromeClean.setTextColor(getResources().getColor(R.color.blue));
        }

        Intent youtubeIntent = getPackageManager().getLaunchIntentForPackage("com.google.android.youtube");
        if (youtubeIntent != null) {

            btnYoutubeClean.setEnabled(true);
//            btnYoutubeClean.setBackgroundColor(getResources().getColor(R.color.color_enable));
            isYoutubeInstalled = true;
            sum = sum + 1;
        } else {
            btnYoutubeClean.setBackgroundColor(getResources().getColor(R.color.color_diable));
//            btnYoutubeClean.setEnabled(false);
            btnYoutubeClean.setTextColor(getResources().getColor(R.color.blue));
        }

        btnWhstasppClean.setOnClickListener(v -> {
            if (isWhatsappInstalled) {
                startActivity(new Intent(AppCleanerActivity.this, AppCleanLastFolderWiseDataActivity.class).putExtra("AppName", "WhatsApp"));
            } else {
                Toast.makeText(this, "WhatApp Not Installed", Toast.LENGTH_SHORT).show();
            }
        });
        btnChromeClean.setOnClickListener(v -> {
            if (isChromeInstalled) {
                startActivity(new Intent(AppCleanerActivity.this, AppCleanLastFolderWiseDataActivity.class).putExtra("AppName", "Chrome"));
            } else {
                Toast.makeText(this, "Chrome Not Installed", Toast.LENGTH_SHORT).show();
            }
        });
        btnYoutubeClean.setOnClickListener(v -> {
            if (isYoutubeInstalled) {
                startActivity(new Intent(AppCleanerActivity.this, AppCleanLastFolderWiseDataActivity.class).putExtra("AppName", "YouTube"));
            } else {
                Toast.makeText(this, "Youtube Not Installed", Toast.LENGTH_SHORT).show();
            }
        });

        btnInstagramClean.setOnClickListener(v -> {
            if (isInstagramInstalled) {
                startActivity(new Intent(AppCleanerActivity.this, AppCleanLastFolderWiseDataActivity.class).putExtra("AppName", "Instagram"));
            } else {
                Toast.makeText(this, "Instagram Not Installed", Toast.LENGTH_SHORT).show();
            }
        });

        btnFacebookClean.setOnClickListener(v -> {
            if (isFacebookInstalled) {
                startActivity(new Intent(AppCleanerActivity.this, AppCleanLastFolderWiseDataActivity.class).putExtra("AppName", "Facebook"));
            } else {
                Toast.makeText(this, "Facebook Not Installed", Toast.LENGTH_SHORT).show();
            }
        });
        btnTelegramClean.setOnClickListener(v -> {
            if (isTelegramInstalled) {
                startActivity(new Intent(AppCleanerActivity.this, AppCleanLastFolderWiseDataActivity.class).putExtra("AppName", "Telegram"));
            } else {
                Toast.makeText(this, "Telegram Not Installed", Toast.LENGTH_SHORT).show();
            }
        });

        btnMessangerClean.setOnClickListener(v -> {
            if (isMessengerInstalled) {
                startActivity(new Intent(AppCleanerActivity.this, AppCleanLastFolderWiseDataActivity.class).putExtra("AppName", "Messenger"));
            } else {
                Toast.makeText(this, "Messenger Not Installed", Toast.LENGTH_SHORT).show();
            }
        });

        btnTiktokClean.setOnClickListener(v -> {
            if (isTiktokInstalled) {
                startActivity(new Intent(AppCleanerActivity.this, AppCleanLastFolderWiseDataActivity.class).putExtra("AppName", "Tiktok"));
            } else {
                Toast.makeText(this, "Tiktok Not Installed", Toast.LENGTH_SHORT).show();
            }
        });

    }

    private boolean appInstalledOrNot() {
        PackageManager pm = getPackageManager();
        try {
            pm.getPackageInfo("com.whatsapp", PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
        }
        return false;
    }

    @Override
    protected void onResume() {

        SharedPreferences sharedPrefs = getSharedPreferences("language", MODE_PRIVATE);
        String s1 = sharedPrefs.getString("selectedlanguage", "");
        LocaleHelper.setLocale(this, s1);
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();

    }


    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleHelper.onAttach(base, "en"));
    }


    public void loadNative() {
        FrameLayout nativeAdPEPkmsSmall = findViewById(R.id.native_ad_PE_pkms_small);
        new NativeLoadWithShows(this).showNativeAdsShimmerEffects(this,  nativeAdPEPkmsSmall, 1);
        new NativeLoadWithShows(this).showNativeBottomAlways(this, nativeAdPEPkmsSmall, null);
//        new AdUtils().nativeAd(this,nativeAdPEPkmsSmall, true, 1);

    }
}