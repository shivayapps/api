package com.cleanmaster.trashcleaner.junkeraser.adapter;
import static android.content.ContentValues.TAG;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.model.doumentContent;

import java.util.ArrayList;

public class DownloadCacheRecycleAdapter extends RecyclerView.Adapter<DownloadCacheRecycleAdapter.pictureViewHolder> {
    private Context pictureActivity;
    private ArrayList<doumentContent> pictureList;
    private pictureActionListrener actionListener;

    public DownloadCacheRecycleAdapter(Context context, ArrayList<doumentContent> pictureList, pictureActionListrener actionListener) {
        this.pictureActivity = context;
        this.pictureList = pictureList;
        this.actionListener = actionListener;
        Log.d(TAG, "DownloadCacheRecycleAdapter: " + pictureList.size());
    }

    @NonNull
    @Override
    public pictureViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(pictureActivity);
        View itemView = inflater.inflate(R.layout.download_cache_item, null, false);
        return new pictureViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull pictureViewHolder holder, int position) {
        holder.setPosition(position);
        holder.Bind();
    }

    @Override
    public int getItemCount() {
        return pictureList.size();
    }

    public interface pictureActionListrener {
        void onPictureItemClicked(int position, ArrayList<doumentContent> arrayListimage);

        void onPictureItemLongClicked(int position);
    }

    class pictureViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnLongClickListener {
        ImageView picture, imgSelect;
        int position;
        private final TextView tvImageName;
        private final TextView tvSize;

        pictureViewHolder(@NonNull View itemView) {
            super(itemView);
            //instantiate views
            imgSelect = itemView.findViewById(R.id.imgSelect);
            picture = itemView.findViewById(R.id.picture);
            tvImageName = itemView.findViewById(R.id.tvImageName);
            tvSize = itemView.findViewById(R.id.tvSize);
            imgSelect.setOnClickListener(this);
            picture.setOnLongClickListener(this);
        }

        void setPosition(int position) {
            this.position = position;
        }

        void Bind() {
            doumentContent pic = pictureList.get(position);
            if (pic.isSelected()) {
                imgSelect.setImageResource(R.drawable.ic_check_square);
            } else {
                imgSelect.setImageResource(R.drawable.ic_uncheck_square);
            }

            tvImageName.setText(pic.getName());
            tvSize.setText(convertFileSize(pic.getDocumentSize()));

            Glide.with(pictureActivity)
                    .load(R.drawable.ic_apk_file)
                    .apply(new RequestOptions().centerCrop())
                    .into(picture);
        }

        @Override
        public void onClick(View v) {
//            setClickValues(position, mediaLists);
            if (pictureList.get(position).isSelected()) {
                pictureList.get(position).setSelected(false);
                imgSelect.setImageResource(R.drawable.ic_uncheck_square);
            } else {
                pictureList.get(position).setSelected(true);
//                setClickValues(position, mediaLists);
                imgSelect.setImageResource(R.drawable.ic_check_square);
            }
            actionListener.onPictureItemClicked(position, pictureList);
        }

        @Override
        public boolean onLongClick(View v) {
            actionListener.onPictureItemLongClicked(position);
            return false;
        }

    }


    public static String convertFileSize(long sizeInBytes) {
        String[] units = {"B", "KB", "MB", "GB"};
        double size = sizeInBytes;
        int index = 0;
        while (size > 1024 && index < units.length - 1) {
            size /= 1024;
            index++;
        }
        return String.format("%.2f %s", size, units[index]);
    }


    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }
}
