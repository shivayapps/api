package com.cleanmaster.trashcleaner.junkeraser.applock.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.annotation.NonNull;

import com.cleanmaster.trashcleaner.junkeraser.applock.base.AppConstants;
import com.cleanmaster.trashcleaner.junkeraser.applock.services.BackgroundManager;
import com.cleanmaster.trashcleaner.junkeraser.applock.services.LoadAppListService;
import com.cleanmaster.trashcleaner.junkeraser.applock.services.LockService;
import com.cleanmaster.trashcleaner.junkeraser.applock.utils.LogUtil;
import com.cleanmaster.trashcleaner.junkeraser.applock.utils.SpUtil;


public class BootBroadcastReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(@NonNull Context context, Intent intent) {
        LogUtil.i("Boot service....");
        //TODO: pie compatable done
        BackgroundManager.getInstance().init(context).startService(LoadAppListService.class);
        if (SpUtil.getInstance().getBoolean(AppConstants.LOCK_STATE, false)) {
            BackgroundManager.getInstance().init(context).startService(LockService.class);
            BackgroundManager.getInstance().init(context).startAlarmManager();
        }
    }
}
