package com.cleanmaster.trashcleaner.junkeraser.activity;

import static android.content.ContentValues.TAG;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.ads.module.adutills.NativeLoadWithShows;
import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.Utils;
import com.cleanmaster.trashcleaner.junkeraser.helper.LocaleHelper;
import com.cleanmaster.trashcleaner.junkeraser.model.doumentContent;
import com.codeboy.mediafacer.mediaHolders.audioContent;
import com.codeboy.mediafacer.mediaHolders.pictureContent;
import com.codeboy.mediafacer.mediaHolders.videoContent;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.concurrent.Executors;

public class AppCleanLastFolderWiseDataActivity extends BaseActivity {
    String[] imageExtensions = new String[]{".jpg", ".jpeg", ".png", ".gif", ".bmp"};
    String[] videoExtensions = new String[]{".mp4"};
    String[] databaseExtensions = new String[]{".crypt14"};
    String[] audioExtensions = new String[]{".mp3", ".opus", ".m4a"};
    String[] documentExtensions = new String[]{".pdf", ".doc", ".txt", ".xls"};
    public static ArrayList<File> fileListdownload = new ArrayList<>();
    public static ArrayList<pictureContent> pictureContentList = new ArrayList<>();
    public static ArrayList<File> databaseFileListdownload = new ArrayList<>();
    public static ArrayList<doumentContent> databaseContentList = new ArrayList<>();
    public static ArrayList<File> videoFileListdownload = new ArrayList<>();
    public static ArrayList<videoContent> videoContentList = new ArrayList<>();
    public static ArrayList<File> audioFileListdownload = new ArrayList<>();
    public static ArrayList<audioContent> audioContentList = new ArrayList<>();
    public static ArrayList<File> documentoFileListdownload = new ArrayList<>();
    public static ArrayList<doumentContent> documentContentList = new ArrayList<>();
    File storageDirectory = new File(Environment.getExternalStorageDirectory() + "/Android/media/com.whatsapp/WhatsApp");
    File storageDirectorybelow10 = new File(Environment.getExternalStorageDirectory() + "/WhatsApp");
    File instagramImagestorageDirectory = new File(Environment.getExternalStorageDirectory() + "/Pictures/Instagram/");
    File instagramVideostorageDirectory = new File(Environment.getExternalStorageDirectory() + "/Movies/Instagram/");
    File teligramImagestorageDirectory = new File(Environment.getExternalStorageDirectory() + "/Pictures/Telegram/");
    File teligramVideostorageDirectory = new File(Environment.getExternalStorageDirectory() + "/Movies/Telegram/");
    File teligramDocumenttorageDirectory = new File(Environment.getExternalStorageDirectory() + "/Download/Telegram/");
    File teligramAudioStorageDirectory = new File(Environment.getExternalStorageDirectory() + "/Music/Telegram/");
    File facebookImageStorageDirectory = new File(Environment.getExternalStorageDirectory() + "/DCIM/Facebook/");
    File messangerImagestorageDirectory = new File(Environment.getExternalStorageDirectory() + "/Pictures/Messenger/");
    File messangerVideotorageDirectory = new File(Environment.getExternalStorageDirectory() + "/Movies/Messenger/");
    File storageDirectoryChrome = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
    private TextView tvImageSize, tvVideoSize, tvAudioSize, tvDocumentsSize, tvBackupsSize;
    private long totalSum;
    private RelativeLayout progressbar;
    private TextView tvTotalClean;
    private View viewImage, viewVideo, viewAudio, viewDocument;
    ImageView app_lottie;
    private TextView scanning_File;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_clean_last_folder_wise_data);

        String AppName = getIntent().getStringExtra("AppName");
        TextView text_title = findViewById(R.id.text_title);
        text_title.setText(AppName);

        ImageView btn_back = findViewById(R.id.btn_back);
        btn_back.setOnClickListener(v -> onBackPressed());

        fileListdownload = new ArrayList<>();
        pictureContentList = new ArrayList<>();
        databaseFileListdownload = new ArrayList<>();
        videoFileListdownload = new ArrayList<>();
        audioFileListdownload = new ArrayList<>();
        documentoFileListdownload = new ArrayList<>();

        tvImageSize = findViewById(R.id.tvImageSize);
        tvVideoSize = findViewById(R.id.tvVideoSize);
        tvAudioSize = findViewById(R.id.tvAudioSize);
        tvDocumentsSize = findViewById(R.id.tvDocumentsSize);
        tvBackupsSize = findViewById(R.id.tvBackupsSize);
        tvTotalClean = findViewById(R.id.tvTotalClean);
        app_lottie = findViewById(R.id.app_lottie);
        viewImage = findViewById(R.id.viewImage);
        viewVideo = findViewById(R.id.viewVideo);
        viewAudio = findViewById(R.id.viewAudio);
        viewDocument = findViewById(R.id.viewDocument);
        scanning_File = findViewById(R.id.scanning_File);

        RelativeLayout rlImages = findViewById(R.id.rlImages);
        RelativeLayout rlVideo = findViewById(R.id.rlVideo);
        RelativeLayout rlAudio = findViewById(R.id.rlAudio);
        RelativeLayout rlDocument = findViewById(R.id.rlDocument);
        RelativeLayout rlBackup = findViewById(R.id.rlBackup);
        progressbar = findViewById(R.id.progressbar);

        Executors.newSingleThreadExecutor().execute(() -> {
            runOnUiThread(() -> {
                progressbar.setVisibility(View.VISIBLE);
            });

            fileListdownload.clear();
            pictureContentList.clear();
            videoFileListdownload.clear();
            videoContentList.clear();
            audioFileListdownload.clear();
            audioContentList.clear();
            documentoFileListdownload.clear();
            documentContentList.clear();
            databaseFileListdownload.clear();
            databaseContentList.clear();

            switch (AppName) {
                case "WhatsApp":

                    app_lottie.setImageResource(R.drawable.ic_whatapp);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        getImageFile(storageDirectory);
                        getVideoFile(storageDirectory);
                        getAudioFile(storageDirectory);
                        getDocumentFile(storageDirectory);
                        getDatabaseFile(storageDirectory);
                    } else {
                        getImageFile(storageDirectorybelow10);
                        getVideoFile(storageDirectorybelow10);
                        getAudioFile(storageDirectorybelow10);
                        getDocumentFile(storageDirectorybelow10);
                        getDatabaseFile(storageDirectorybelow10);
                    }

                    break;
                case "Chrome":
                    app_lottie.setImageResource(R.drawable.chrome);
                    getImageFile(storageDirectoryChrome);
                    getVideoFile(storageDirectoryChrome);
                    getAudioFile(storageDirectoryChrome);
                    getDocumentFile(storageDirectoryChrome);
                    getDatabaseFile(storageDirectoryChrome);
                    break;
                case "YouTube":
                    app_lottie.setImageResource(R.drawable.youtube);
                    break;
                case "Tiktok":
                    app_lottie.setImageResource(R.drawable.tiktok);
                    break;
                case "Instagram":
                    app_lottie.setImageResource(R.drawable.instagram);
                    getImageFile(instagramImagestorageDirectory);
                    getVideoFile(instagramVideostorageDirectory);

                    break;
                case "Facebook":
                    app_lottie.setImageResource(R.drawable.facebook);
                    getImageFile(facebookImageStorageDirectory);

                    break;
                case "Telegram":
                    app_lottie.setImageResource(R.drawable.telegram);
                    getImageFile(teligramImagestorageDirectory);
                    getVideoFile(teligramVideostorageDirectory);
                    getDocumentFile(teligramDocumenttorageDirectory);
                    getAudioFile(teligramAudioStorageDirectory);

                    break;
                case "Messenger":
                    app_lottie.setImageResource(R.drawable.messagner);
                    getImageFile(messangerImagestorageDirectory);
                    getVideoFile(messangerVideotorageDirectory);

                    break;
            }

            runOnUiThread(() -> {

                if(AppName.equals("Chrome")){

                }else if(AppName.equals("YouTube")){
                    rlImages.setVisibility(View.GONE);
                    viewImage.setVisibility(View.GONE);
                }else if(AppName.equals("Tiktok")){

                }else if(AppName.equals("Instagram")){
                    rlAudio.setVisibility(View.GONE);
                    viewAudio.setVisibility(View.GONE);
                    rlDocument.setVisibility(View.GONE);
                    viewDocument.setVisibility(View.GONE);
                    rlBackup.setVisibility(View.GONE);
                }else if(AppName.equals("Facebook")){
                    rlVideo.setVisibility(View.GONE);
                    viewVideo.setVisibility(View.GONE);
                    rlAudio.setVisibility(View.GONE);
                    viewAudio.setVisibility(View.GONE);
                    rlDocument.setVisibility(View.GONE);
                    viewDocument.setVisibility(View.GONE);
                    rlBackup.setVisibility(View.GONE);
                }else if(AppName.equals("Telegram")){
                    rlBackup.setVisibility(View.GONE);
                }else if(AppName.equals("Messenger")){
                    rlAudio.setVisibility(View.GONE);
                    viewAudio.setVisibility(View.GONE);
                    rlDocument.setVisibility(View.GONE);
                    viewDocument.setVisibility(View.GONE);
                    rlBackup.setVisibility(View.GONE);
                }

                scanning_File.setText("Scanning Complete");
                app_lottie.setImageResource(R.drawable.ic_done_lottie);
//                app_lottie.setAnimation(R.raw.success2);

//                app_lottie.loop(true);
//                app_lottie.playAnimation();

                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        progressbar.setVisibility(View.GONE);
                        FrameLayout adContainerView = findViewById(R.id.frame_banner);
                        new NativeLoadWithShows(AppCleanLastFolderWiseDataActivity.this).showNativeAdsShimmerEffects(AppCleanLastFolderWiseDataActivity.this,  adContainerView, 1);
                        new NativeLoadWithShows(AppCleanLastFolderWiseDataActivity.this).showNativeBottomAlways(AppCleanLastFolderWiseDataActivity.this, adContainerView,null);

                    }
                }, 3000);

                totalSum = storageTotalDocument() + videoStorageTotalDocument() + audioStorageTotalDocument() + backupStorageTotalDocument() + documentsStorageTotalDocument();
                Log.d(TAG, "onCreate: " + convertFileSize(totalSum));
                tvTotalClean.setText(convertFileSize(totalSum));
                tvImageSize.setText(convertFileSize(storageTotalDocument()));
                tvVideoSize.setText(convertFileSize(videoStorageTotalDocument()));
                tvAudioSize.setText(convertFileSize(audioStorageTotalDocument()));
                tvBackupsSize.setText(convertFileSize(backupStorageTotalDocument()));
                tvDocumentsSize.setText(convertFileSize(documentsStorageTotalDocument()));

            });
        });

        rlImages.setOnClickListener(v -> startActivity(new Intent(AppCleanLastFolderWiseDataActivity.this, AppCleanerImagesActivity.class)));
        rlVideo.setOnClickListener(v -> startActivity(new Intent(AppCleanLastFolderWiseDataActivity.this, AppCleanerVideoActivity.class)));
        rlAudio.setOnClickListener(v -> startActivity(new Intent(AppCleanLastFolderWiseDataActivity.this, AppCleanerAudioActivity.class)));
        rlDocument.setOnClickListener(v -> startActivity(new Intent(AppCleanLastFolderWiseDataActivity.this, AppCleanerDocumentActivity.class)));
        rlBackup.setOnClickListener(v -> startActivity(new Intent(AppCleanLastFolderWiseDataActivity.this, AppCleanerDatabaseActivity.class)));

        /*AdUtils adUtils = new AdUtils();
        FrameLayout frameLayout = findViewById(R.id.frame_banner);
        adUtils.bannerAd(this, frameLayout, "5", false, getAdSize(frameLayout));*/

    }

    public long storageTotalDocument() {
        long imageSum = 0;
        for (int i = 0; i < pictureContentList.size(); i++) {
            imageSum = imageSum + pictureContentList.get(i).getPictureSize();
        }

        return imageSum;
    }

    public long videoStorageTotalDocument() {
        long videoSum = 0;
        for (int i = 0; i < videoContentList.size(); i++) {
            videoSum = videoSum + videoContentList.get(i).getVideoSize();
        }

        return videoSum;
    }

    public long audioStorageTotalDocument() {
        long audioSum = 0;
        for (int i = 0; i < audioContentList.size(); i++) {
            audioSum = audioSum + audioContentList.get(i).getMusicSize();
        }

        return audioSum;
    }

    public long documentsStorageTotalDocument() {
        long documentSum = 0;
        for (int i = 0; i < documentContentList.size(); i++) {
            documentSum = documentSum + documentContentList.get(i).getDocumentSize();
        }

        return documentSum;
    }

    public long backupStorageTotalDocument() {
        long backupSum = 0;
        for (int i = 0; i < databaseFileListdownload.size(); i++) {
            backupSum = backupSum + databaseFileListdownload.get(i).length();
        }

        return backupSum;
    }

    @SuppressLint("DefaultLocale")
    public static String convertFileSize(long sizeInBytes) {
        String[] units = {"B", "KB", "MB", "GB"};
        double size = sizeInBytes;
        int index = 0;
        while (size > 1024 && index < units.length - 1) {
            size /= 1024;
            index++;
        }
        return String.format("%.2f %s", size, units[index]);
    }


    public void getImageFile(File storageDirectory) {
        fileListdownload.clear();
        pictureContentList.clear();
        traverseDirectoryDownload(storageDirectory);

        Collections.sort(fileListdownload, (file1, file2) -> {
            long size1 = file1.length();
            long size2 = file2.length();
            return Long.compare(size1, size2);
        });

        Collections.reverse(fileListdownload);

        for (int i = 0; i < fileListdownload.size(); i++) {
            pictureContent pictureContent = new pictureContent();
            pictureContent.setPictureName(fileListdownload.get(i).getName());
            pictureContent.setPicturePath(fileListdownload.get(i).getPath());
            pictureContent.setPictureSize(fileListdownload.get(i).length());
//            if (fileListdownload.get(i).length() > 53000000) {
            pictureContentList.add(pictureContent);
//            }
        }
    }

    public void getVideoFile(File storageDirectory) {
        videoFileListdownload.clear();
        videoContentList.clear();
        traverseDirectoryDownload(storageDirectory);

        Collections.sort(videoFileListdownload, (file1, file2) -> {
            long size1 = file1.length();
            long size2 = file2.length();
            return Long.compare(size1, size2);
        });

        Collections.reverse(videoFileListdownload);

        for (int i = 0; i < videoFileListdownload.size(); i++) {
            videoContent videoContent = new videoContent();
            videoContent.setVideoName(videoFileListdownload.get(i).getName());
            videoContent.setPath(videoFileListdownload.get(i).getPath());
            videoContent.setVideoSize(videoFileListdownload.get(i).length());
//            if (fileListdownload.get(i).length() > 53000000) {
            videoContentList.add(videoContent);
//            }
        }
    }

    public void getAudioFile(File storageDirectory) {
        audioFileListdownload.clear();
        audioContentList.clear();
        traverseDirectoryDownload(storageDirectory);

        Collections.sort(audioFileListdownload, (file1, file2) -> {
            long size1 = file1.length();
            long size2 = file2.length();
            return Long.compare(size1, size2);
        });

        Collections.reverse(audioFileListdownload);

        for (int i = 0; i < audioFileListdownload.size(); i++) {
            audioContent audioContent = new audioContent();
            audioContent.setName(audioFileListdownload.get(i).getName());
            audioContent.setFilePath(audioFileListdownload.get(i).getPath());
            audioContent.setMusicSize(audioFileListdownload.get(i).length());
//            if (fileListdownload.get(i).length() > 53000000) {
            audioContentList.add(audioContent);
//            }
        }
    }

    public void getDocumentFile(File storageDirectory) {
        documentoFileListdownload.clear();
        documentContentList.clear();
        traverseDirectoryDownload(storageDirectory);

        Collections.sort(documentoFileListdownload, (file1, file2) -> {
            long size1 = file1.length();
            long size2 = file2.length();
            return Long.compare(size1, size2);
        });

        Collections.reverse(documentoFileListdownload);

        for (int i = 0; i < documentoFileListdownload.size(); i++) {
            doumentContent doumentContent = new doumentContent();
            doumentContent.setName(documentoFileListdownload.get(i).getName());
            doumentContent.setFilePath(documentoFileListdownload.get(i).getPath());
            doumentContent.setDocumentSize(documentoFileListdownload.get(i).length());
//            if (fileListdownload.get(i).length() > 53000000) {
            documentContentList.add(doumentContent);
//            }
        }
    }

    public void getDatabaseFile(File storageDirectory) {
        databaseFileListdownload.clear();
        databaseContentList.clear();
        traverseDirectoryDownload(storageDirectory);

        Collections.sort(databaseFileListdownload, (file1, file2) -> {
            long size1 = file1.length();
            long size2 = file2.length();
            return Long.compare(size1, size2);
        });

        Collections.reverse(databaseFileListdownload);

        for (int i = 0; i < databaseFileListdownload.size(); i++) {
            doumentContent doumentContent = new doumentContent();
            doumentContent.setName(databaseFileListdownload.get(i).getName());
            doumentContent.setFilePath(databaseFileListdownload.get(i).getPath());
            doumentContent.setDocumentSize(databaseFileListdownload.get(i).length());
//            if (fileListdownload.get(i).length() > 53000000) {
            databaseContentList.add(doumentContent);
//            }
        }
    }

    private void traverseDirectoryDownload(File directory) {

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (file.isDirectory()) {
                        // If it's a directory, recursively traverse it
                        traverseDirectoryDownload(file);
                    } else {
                        // If it's a file, check if it's an image file or not
                        String extension = getFileExtension(file);
                        if (Arrays.asList(imageExtensions).contains(extension)) {
                            fileListdownload.add(file);
                            Log.d(TAG, "traverseDirectory image" + file.getPath());
                        } else if (Arrays.asList(videoExtensions).contains(extension)) {
                            videoFileListdownload.add(file);
                            Log.d(TAG, "traverseDirectory video " + file.getPath());
                        } else if (Arrays.asList(databaseExtensions).contains(extension)) {
                            databaseFileListdownload.add(file);
                            Log.d(TAG, "traverseDirectory database " + file.getPath());
                        } else if (Arrays.asList(audioExtensions).contains(extension)) {
                            audioFileListdownload.add(file);
                            Log.d(TAG, "traverseDirectory audio " + file.getPath());
                        } else if (Arrays.asList(documentExtensions).contains(extension)) {
                            documentoFileListdownload.add(file);
                            Log.d(TAG, "traverseDirectory document " + file.getPath());
                        }

                    }
                }
            }
        } else {
            Uri uri = MediaStore.Files.getContentUri("external");
            String[] projection2 = {MediaStore.Files.FileColumns.DATA};
            String selection = MediaStore.Files.FileColumns.DATA + " like?";
            String[] selectionArgs = new String[]{"%" + directory.getPath() + "%"};

            Cursor cursor = getContentResolver().query(uri, projection2, selection, selectionArgs, null);
            if (cursor != null) {
                while (cursor.moveToNext()) {

                    String path = cursor.getString(0);

                    String extension = getFileExtension(new File(path));
                    Log.d(TAG, "traverseDirectoryDownload: " + extension);
                    if (Arrays.asList(imageExtensions).contains(extension)) {
                        fileListdownload.add(new File(path));
                        Log.d(TAG, "traverseDirectory image" + new File(path).getPath());
                    } else if (Arrays.asList(videoExtensions).contains(extension)) {
                        videoFileListdownload.add(new File(path));
                        Log.d(TAG, "traverseDirectory video " + new File(path).getPath());
                    } else if (Arrays.asList(databaseExtensions).contains(extension)) {
                        databaseFileListdownload.add(new File(path));
                        Log.d(TAG, "traverseDirectory database " + new File(path).getPath());
                    } else if (Arrays.asList(audioExtensions).contains(extension)) {
                        audioFileListdownload.add(new File(path));
                        Log.d(TAG, "traverseDirectory audio " + new File(path).getPath());
                    } else if (Arrays.asList(documentExtensions).contains(extension)) {
                        documentoFileListdownload.add(new File(path));
                        Log.d(TAG, "traverseDirectory document " + new File(path).getPath());
                    }

                }
                cursor.close();
            }
        }

    }

    private String getFileExtension(File file) {
        String name = file.getName();
        int lastDot = name.lastIndexOf(".");
        if (lastDot > 0) {
            return name.substring(lastDot);
        }
        return "";
    }

    @Override
    protected void onResume() {

        SharedPreferences sharedPrefs = getSharedPreferences("language", MODE_PRIVATE);
        String s1 = sharedPrefs.getString("selectedlanguage", "");
        LocaleHelper.setLocale(this, s1);

        tvImageSize.setText(convertFileSize(storageTotalDocument()));
        tvVideoSize.setText(convertFileSize(videoStorageTotalDocument()));
        tvAudioSize.setText(convertFileSize(audioStorageTotalDocument()));
        tvBackupsSize.setText(convertFileSize(backupStorageTotalDocument()));
        tvDocumentsSize.setText(convertFileSize(documentsStorageTotalDocument()));
        new Utils().disebledOpenAdsBasedOnFireBase();
        super.onResume();
    }

    @Override
    protected void onPause() {

        super.onPause();

    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleHelper.onAttach(base, "en"));
    }

}