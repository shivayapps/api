package com.cleanmaster.trashcleaner.junkeraser.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import android.app.UiModeManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.InsetDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.ads.module.open.AdconfigApplication;
import com.cleanmaster.trashcleaner.junkeraser.BuildConfig;
import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.Utils;
import com.cleanmaster.trashcleaner.junkeraser.helper.LocaleHelper;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;

import java.util.Set;

public class SettingActivity extends BaseActivity {
    private SharedPreferences sharedPref;
    private LinearLayout llTheme, llLanguage;
    private ImageView imgSwitchNotificationAccess, imgwitchCloseNotification;
    private ImageView imgSwitchLowPower, imgSwitchChargeComplete;
    private LinearLayout llPrivavacyPolicy, llShareApp, llRateApp;
    private boolean isNotificationAccess = false;
    private boolean isCloseNotification = false;
    private boolean isLowPower = false;
    private boolean isChargingComplete = false;
    private AlertDialog alertDialog;
    private String theme;
    SharedPreferences sharedPreferences;
    boolean isRate4 = false;
    private ReviewManager reviewManager;
    ReviewInfo reviewInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        ImageView btn_back = findViewById(R.id.btn_back);
        btn_back.setOnClickListener(v -> onBackPressed());

        reviewManager = ReviewManagerFactory.create(getApplicationContext());

        getReviewInfo();

        llTheme = findViewById(R.id.llTheme);
        llLanguage = findViewById(R.id.llLanguage);
        llPrivavacyPolicy = findViewById(R.id.llPrivavacyPolicy);
        llShareApp = findViewById(R.id.llShareApp);
        llRateApp = findViewById(R.id.llRateApp);
        imgSwitchNotificationAccess = findViewById(R.id.imgSwitchNotificationAccess);
        imgwitchCloseNotification = findViewById(R.id.imgwitchCloseNotification);
        imgSwitchLowPower = findViewById(R.id.imgSwitchLowPower);
        imgSwitchChargeComplete = findViewById(R.id.imgSwitchChargeComplete);
        TextView tvVersionCode = findViewById(R.id.tvVersionCode);
        tvVersionCode.setText(BuildConfig.VERSION_NAME);
        sharedPreferences = getSharedPreferences("intentData", Context.MODE_PRIVATE);
        sharedPref = getSharedPreferences("SettingScreen", MODE_PRIVATE);

        llLanguage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(SettingActivity.this, LanguageActivity.class);
                startActivity(it);
                finish();
            }
        });

        llTheme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showClearCacheDialog(v);
            }
        });

        imgSwitchNotificationAccess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!isNotificationAccess) {
                    isNotificationAccess = true;
                    imgSwitchNotificationAccess.setImageResource(R.drawable.ic_baseline_toggle_on_24);
                    open_Notification_Access_Setting();
                } else {
                    open_Notification_Access_Setting();
                    isNotificationAccess = false;
                    imgSwitchNotificationAccess.setImageResource(R.drawable.ic_baseline_toggle_off_24);
                }
            }
        });

        imgwitchCloseNotification.setOnClickListener(v -> {
            if (!isCloseNotification) {
                isCloseNotification = true;
                imgwitchCloseNotification.setImageResource(R.drawable.ic_baseline_toggle_on_24);
            } else {
                isCloseNotification = false;
                imgwitchCloseNotification.setImageResource(R.drawable.ic_baseline_toggle_off_24);
            }
        });

        imgSwitchLowPower.setOnClickListener(v -> {
            if (!isLowPower) {
                isLowPower = true;
                imgSwitchLowPower.setImageResource(R.drawable.ic_baseline_toggle_on_24);
                sharedPreferences = getSharedPreferences("intentData", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor;
                editor = sharedPreferences.edit();
                editor.putInt("low_power", 1);
                editor.apply();
            } else {
                isLowPower = false;
                imgSwitchLowPower.setImageResource(R.drawable.ic_baseline_toggle_off_24);
                sharedPreferences = getSharedPreferences("intentData", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor;
                editor = sharedPreferences.edit();
                editor.putInt("low_power", 2);
                editor.apply();
            }
        });

        imgSwitchChargeComplete.setOnClickListener(v -> {
            if (!isChargingComplete) {
                isChargingComplete = true;
                imgSwitchChargeComplete.setImageResource(R.drawable.ic_baseline_toggle_on_24);
                sharedPreferences = getSharedPreferences("intentData", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor;
                editor = sharedPreferences.edit();
                editor.putInt("full_charging", 1);
                editor.apply();
            } else {
                isChargingComplete = false;
                imgSwitchChargeComplete.setImageResource(R.drawable.ic_baseline_toggle_off_24);
                sharedPreferences = getSharedPreferences("intentData", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor;
                editor = sharedPreferences.edit();
                editor.putInt("full_charging", 2);
                editor.apply();
            }
        });

        llShareApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AdconfigApplication.Companion.disabledOpenAds();
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT,
                        "Hey check out my app at: https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID);
                sendIntent.setType("text/plain");
                startActivity(sendIntent);
            }
        });
        llRateApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showRateUsDialog(v);
//                RatingDialog.showRateAppDialogNormal(getSupportFragmentManager(), SettingActivity.this, "https://play.google.com/store/apps/details?id=" + "");
            }
        });

        llPrivavacyPolicy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String url = getPrivacyPolicy();
                Uri uri = Uri.parse(url);
                try {
                    CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
                    builder.setToolbarColor(ContextCompat.getColor(SettingActivity.this, R.color.purple_500));
                    CustomTabsIntent customTabsIntent = builder.build();
                    AdconfigApplication.Companion.disabledOpenAds();
                    customTabsIntent.launchUrl(SettingActivity.this, uri);
                } catch (Exception e) {
                    AdconfigApplication.Companion.disabledOpenAds();
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(uri);
                    startActivity(intent);
                }
            }
        });

        if (sharedPreferences.getInt("low_power", 1) == 1) {
            isChargingComplete = true;
            imgSwitchLowPower.setImageResource(R.drawable.ic_baseline_toggle_on_24);
        } else {
            isChargingComplete = false;
            imgSwitchLowPower.setImageResource(R.drawable.ic_baseline_toggle_off_24);
        }

        if (sharedPreferences.getInt("full_charging", 1) == 1) {
            imgSwitchChargeComplete.setImageResource(R.drawable.ic_baseline_toggle_on_24);
        } else {
            imgSwitchChargeComplete.setImageResource(R.drawable.ic_baseline_toggle_off_24);
        }
    }

    private void showClearCacheDialog(View view) {
        ViewGroup viewGroup = view.findViewById(android.R.id.content);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_theme, viewGroup, false);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        RadioGroup radioGroup = dialogView.findViewById(R.id.radioGroup);
        RadioButton rbLight = dialogView.findViewById(R.id.rblight);
        RadioButton rbDark = dialogView.findViewById(R.id.rbdark);
        RadioButton rbDefault = dialogView.findViewById(R.id.rbdefault);

        TextView buttonCancel = dialogView.findViewById(R.id.buttonCancel);
        TextView buttonOk = dialogView.findViewById(R.id.buttonOk);

        String themess = sharedPref.getString("theme", "light");
        switch (themess) {
            case "light":
                rbLight.setChecked(true);
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                break;
            case "dark":
                rbDark.setChecked(true);
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                break;
            case "dafault":
                rbDefault.setChecked(true);

                UiModeManager uiModeManager = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
                if (uiModeManager.getNightMode() == UiModeManager.MODE_NIGHT_YES) {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                } else {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                }

                break;
        }

        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {

            if (checkedId == R.id.rblight) {
                theme = "light";
            } else if (checkedId == R.id.rbdark) {
                theme = "dark";
            } else if (checkedId == R.id.rbdefault) {
                theme = "dafault";
            }

        });

        buttonCancel.setOnClickListener(view1 -> alertDialog.dismiss());

        buttonOk.setOnClickListener(view12 -> {

            SharedPreferences.Editor myEdit = sharedPref.edit();
            myEdit.putString("theme", theme);
            myEdit.apply();

            String themes = sharedPref.getString("theme", "light");
            switch (themes) {
                case "light":
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                    break;
                case "dark":
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                    break;
                case "dafault":
                    UiModeManager uiModeManager = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
                    if (uiModeManager.getNightMode() == UiModeManager.MODE_NIGHT_YES) {
                        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                    } else {
                        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                    }
                    break;
            }

            Intent it = new Intent(this, SettingActivity.class);
            finish();
            overridePendingTransition(0, 0);
            startActivity(it);
            overridePendingTransition(0, 0);
            alertDialog.dismiss();
        });

        builder.setView(dialogView);
        alertDialog = builder.create();

        InsetDrawable inset = new InsetDrawable(new ColorDrawable(Color.TRANSPARENT), 40);
        alertDialog.getWindow().setBackgroundDrawable(inset);
        alertDialog.show();
    }

    @Override
    protected void onResume() {
        super.onResume();

        new Utils().disebledOpenAdsBasedOnFireBase();
        String themess = sharedPref.getString("theme", "light");
        switch (themess) {
            case "light":
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                break;
            case "dark":
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                break;
            case "dafault":
                UiModeManager uiModeManager = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
                if (uiModeManager.getNightMode() == UiModeManager.MODE_NIGHT_YES) {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                } else {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                }

                break;
        }

        if (isNotificationAccessGiven()) {
            imgSwitchNotificationAccess.setImageResource(R.drawable.ic_baseline_toggle_on_24);
        } else {
            imgSwitchNotificationAccess.setImageResource(R.drawable.ic_baseline_toggle_off_24);
        }

        SharedPreferences sharedPrefs = getSharedPreferences("language", MODE_PRIVATE);
        String s1 = sharedPrefs.getString("selectedlanguage", "");
        LocaleHelper.setLocale(this, s1);
    }


    @Override
    protected void onPause() {
        super.onPause();

    }

    private void showRateUsDialog(View view) {
        ViewGroup viewGroup = view.findViewById(android.R.id.content);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.rate_us_dialog, viewGroup, false);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        TextView buttonCancel = dialogView.findViewById(R.id.buttonCancel);
        TextView buttonOk = dialogView.findViewById(R.id.buttonOk);
        ImageView imgEmoji = dialogView.findViewById(R.id.imgEmoji);
        TextView tvFirstLine = dialogView.findViewById(R.id.tvFirstLine);
        TextView tvSecondLie = dialogView.findViewById(R.id.tvSecondLie);

        ImageView img0 = dialogView.findViewById(R.id.img0);
        ImageView img1 = dialogView.findViewById(R.id.img1);
        ImageView img2 = dialogView.findViewById(R.id.img2);
        ImageView img3 = dialogView.findViewById(R.id.img3);
        ImageView img4 = dialogView.findViewById(R.id.img4);

        tvFirstLine.setVisibility(View.VISIBLE);
        imgEmoji.setImageResource(R.drawable.rate0);
        buttonOk.setEnabled(false);
        img0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonOk.setEnabled(true);
//                buttonOk.setTextColor(ContextCompat.getColorStateList(SettingActivity.this, R.color.blue));
                buttonOk.setTextColor(getResources().getColor(R.color.blue));
                isRate4 = true;
                imgEmoji.setImageResource(R.drawable.rate1);
                tvFirstLine.setText(R.string.please_give_us_some_feedback_to_help_us_improve);
                tvSecondLie.setText(R.string.oh_we_re_sorry);

                img0.setImageResource(R.drawable.active_star);
                img1.setImageResource(R.drawable.empty_star);
                img2.setImageResource(R.drawable.empty_star);
                img3.setImageResource(R.drawable.empty_star);
                img4.setImageResource(R.drawable.empty_star);

            }
        });
        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonOk.setEnabled(true);
                buttonOk.setTextColor(getResources().getColor(R.color.blue));
                isRate4 = true;
                imgEmoji.setImageResource(R.drawable.rate2);
                tvFirstLine.setText(getResources().getString(R.string.please_give_us_some_feedback_to_help_us_improve));
                tvSecondLie.setText(R.string.oh_we_re_sorry);

                img0.setImageResource(R.drawable.active_star);
                img1.setImageResource(R.drawable.active_star);
                img2.setImageResource(R.drawable.empty_star);
                img3.setImageResource(R.drawable.empty_star);
                img4.setImageResource(R.drawable.empty_star);
            }
        });
        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonOk.setEnabled(true);
                buttonOk.setTextColor(getResources().getColor(R.color.blue));
                isRate4 = true;
                imgEmoji.setImageResource(R.drawable.rate3);
                tvFirstLine.setText(R.string.we_d_love_to_hear_your_feedback);
                tvSecondLie.setText(getResources().getString(R.string.what_a_pity));
                img0.setImageResource(R.drawable.active_star);
                img1.setImageResource(R.drawable.active_star);
                img2.setImageResource(R.drawable.active_star);
                img3.setImageResource(R.drawable.empty_star);
                img4.setImageResource(R.drawable.empty_star);
            }
        });
        img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonOk.setEnabled(true);
                buttonOk.setTextColor(getResources().getColor(R.color.blue));
                isRate4 = true;
                imgEmoji.setImageResource(R.drawable.rate4);
                tvFirstLine.setText(R.string.we_will_work_harder_to_make_you_more_satisfied);
                tvSecondLie.setText(R.string.thanks_for_your_rating);
                img0.setImageResource(R.drawable.active_star);
                img1.setImageResource(R.drawable.active_star);
                img2.setImageResource(R.drawable.active_star);
                img3.setImageResource(R.drawable.active_star);
                img4.setImageResource(R.drawable.empty_star);
            }
        });
        img4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonOk.setEnabled(true);
                buttonOk.setTextColor(getResources().getColor(R.color.blue));
                isRate4 = false;
                imgEmoji.setImageResource(R.drawable.rate5);
                tvFirstLine.setText(R.string.we_will_continue_to_work_hard_please_show_some_love_on_google_play);
                tvSecondLie.setText(R.string.thanks_a_million);
//                tvThirdLine.setText(R.string.your_satisfaction_makes_all_of_our_effort_worthwhile);
                img0.setImageResource(R.drawable.active_star);
                img1.setImageResource(R.drawable.active_star);
                img2.setImageResource(R.drawable.active_star);
                img3.setImageResource(R.drawable.active_star);
                img4.setImageResource(R.drawable.active_star);
            }
        });

        buttonCancel.setOnClickListener(view1 -> alertDialog.dismiss());

        buttonOk.setOnClickListener(view12 -> {

            if (isRate4) {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("message/rfc822");
//                i.putExtra(Intent.EXTRA_EMAIL, new String[]{new SessionHelper(this).getStringData(SessionHelper.REVIEW_EMAIL)});
                i.putExtra(Intent.EXTRA_SUBJECT, "Memory Cleaner FeedBack");
                i.putExtra(Intent.EXTRA_TEXT, "");
                i.setPackage("com.google.android.gm");
                try {
                    AdconfigApplication.Companion.disabledOpenAds();
                    startActivity(Intent.createChooser(i, "Send mail..."));
                } catch (android.content.ActivityNotFoundException ex) {
                    Toast.makeText(SettingActivity.this, "There are no email clients installed.", Toast.LENGTH_SHORT).show();
                }
            } else {
//                showRateApp();
//                startReviewFlow();
                AdconfigApplication.Companion.disabledOpenAds();
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName())));
            }

            alertDialog.dismiss();
        });

        builder.setView(dialogView);
        alertDialog = builder.create();

        InsetDrawable inset = new InsetDrawable(new ColorDrawable(Color.TRANSPARENT), 40);
        alertDialog.getWindow().setBackgroundDrawable(inset);
        alertDialog.show();
    }

    @Override
    public void onBackPressed() {
        Intent it = new Intent(SettingActivity.this, DashBoardActivity.class);
        startActivity(it);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        finish();
    }

    public void open_Notification_Access_Setting() {
        AdconfigApplication.Companion.disabledOpenAds();
        startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
    }

    private boolean isNotificationAccessGiven() {
        try {
            boolean enabled = false;
            Set<String> enabledListenerPackagesSet = NotificationManagerCompat.getEnabledListenerPackages(getApplicationContext());
            for (String string : enabledListenerPackagesSet)
                if (string.contains(getPackageName())) enabled = true;
            return enabled;
        } catch (Exception e) {
            Log.d("Error Line Number", Log.getStackTraceString(e));
        }
        return false;
    }

    private void getReviewInfo() {
        reviewManager = ReviewManagerFactory.create(getApplicationContext());
        Task<ReviewInfo> manager = reviewManager.requestReviewFlow();
        manager.addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                reviewInfo = task.getResult();
            } else {
                Toast.makeText(getApplicationContext(), "In App ReviewFlow failed to start", Toast.LENGTH_LONG).show();
            }
        });
    }

    public void startReviewFlow() {
        if (reviewInfo != null) {
            Task<Void> flow = reviewManager.launchReviewFlow(this, reviewInfo);
            flow.addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    Toast.makeText(getApplicationContext(), "In App Rating complete", Toast.LENGTH_LONG).show();
                }
            });
        } else {
            Toast.makeText(getApplicationContext(), "In App Rating failed", Toast.LENGTH_LONG).show();
        }
    }


    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleHelper.onAttach(base, "en"));
    }
}