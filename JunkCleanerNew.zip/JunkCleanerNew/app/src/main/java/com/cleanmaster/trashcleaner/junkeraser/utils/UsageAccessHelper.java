package com.cleanmaster.trashcleaner.junkeraser.utils;

import android.app.AppOpsManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.provider.Settings;
import android.widget.Toast;

public class UsageAccessHelper {
    private static final int REQUEST_USAGE_ACCESS = 1;

    // Method to check if usage access permission is granted
    public static boolean isUsageAccessGranted(Context context) {
        AppOpsManager appOps = (AppOpsManager) context.getSystemService(Context.APP_OPS_SERVICE);
        int mode;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            mode = appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(), context.getPackageName());
        } else {
            mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(), context.getPackageName());
        }
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    // Method to request usage access permission
    public static void requestUsageAccessPermission(Context context) {
        Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        if (intent.resolveActivity(context.getPackageManager()) != null) {
            context.startActivity(intent);
        } else {
            Toast.makeText(context, "Unable to open Usage Access settings", Toast.LENGTH_SHORT).show();
        }
    }

    // Method to handle permission result
    public static void handlePermissionResult(Context context, int requestCode) {
        if (requestCode == REQUEST_USAGE_ACCESS) {
            if (isUsageAccessGranted(context)) {
                Toast.makeText(context, "PErmission Recesived", Toast.LENGTH_SHORT).show();
                // Permission granted, perform required actions
                // For example, enable a feature that requires usage access permission
            } else {
                // Permission denied, show an error or take appropriate action
            }
        }
    }
}