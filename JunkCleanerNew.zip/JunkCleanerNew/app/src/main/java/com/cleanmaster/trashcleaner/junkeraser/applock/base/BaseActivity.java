package com.cleanmaster.trashcleaner.junkeraser.applock.base;

import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.cleanmaster.trashcleaner.junkeraser.Myapplication;
import com.cleanmaster.trashcleaner.junkeraser.R;

public abstract class BaseActivity extends AppCompatActivity {
    private TextView mCustomTitleTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

//        Myapplication myapplication = new Myapplication();
        Myapplication.Companion.getApplication().doForCreate(this);
        Log.e("hello123456789", "base doForCreate");
        setContentView(getLayoutId());

        initViews(savedInstanceState);
//        initToolBar();
        initData();
        initAction();
    }

    public abstract int getLayoutId();
    protected abstract void initViews(Bundle savedInstanceState);

    /*protected void initToolBar() {
        Toolbar mToolbar = findViewById(R.id.toolbar);
        if (mToolbar != null) {
            setSupportActionBar(mToolbar);
            getSupportActionBar().setTitle("");
            SystemBarHelper.immersiveStatusBar(this);
            SystemBarHelper.setHeightAndPadding(this, mToolbar);
            mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            });
            resetToolbar();
            getSupportActionBar().setDisplayShowCustomEnabled(true);
            getSupportActionBar().setElevation(0);
        }
    }*/

    public void resetToolbar() {
        if (mCustomTitleTextView == null) {
            mCustomTitleTextView = (TextView) getLayoutInflater().inflate(R.layout.layout_toolbar_title, null);
        }
        getSupportActionBar().setCustomView(mCustomTitleTextView, new ActionBar.LayoutParams(Gravity.CENTER));
        if (getTitle() != null) {
            mCustomTitleTextView = getSupportActionBar().getCustomView().findViewById(R.id.toolbar_title);
            mCustomTitleTextView.setText(getTitle());
        }
    }

    public void hiddenActionBar() {
        getSupportActionBar().hide();
    }

    protected abstract void initData();

    protected abstract void initAction();

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Myapplication.Companion.getApplication().doForFinish(this);
        Log.e("hello123456789", "base doForCreate");
    }

    public final void clear() {
        super.finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("IronBanner","onResume");
       /* if (new SessionHelper(this).getStringData(SessionHelper.IS_IRON_SOURCE_MEDEATION_ON) == "1" && new SessionHelper(this).getStringData(SessionHelper.IS_ADS_ON) == "1") {
            IronSource.onResume(this);
        }*/
    }

    @Override
    protected void onPause() {
        super.onPause();

        Log.e("IronBanner","onPause");
       /* if (new SessionHelper(this).getStringData(SessionHelper.IS_IRON_SOURCE_MEDEATION_ON) == "1" && new SessionHelper(this).getStringData(SessionHelper.IS_ADS_ON) == "1") {
            IronSource.onPause(this);
        }*/
    }
}
