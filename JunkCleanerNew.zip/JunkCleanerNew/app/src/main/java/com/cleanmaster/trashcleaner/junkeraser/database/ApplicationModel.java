package com.cleanmaster.trashcleaner.junkeraser.database;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "app_table")
public class ApplicationModel {

    @PrimaryKey(autoGenerate = true)
    int id = 0;
    @ColumnInfo(name = "apkPackage")
    String apkPackage;
    @ColumnInfo(name = "application_name")
    String application_name;
    @ColumnInfo(name = "count")
    int notification_count;
    @ColumnInfo(name = "isblock")
    boolean isblock;

    public ApplicationModel( String apkname,String application_name, int notification_count, boolean isblock) {
        this.apkPackage = apkname;
        this.application_name = application_name;
        this.notification_count = notification_count;
        this.isblock = isblock;
    }

    public ApplicationModel() {
    }

    public String getApplication_name() {
        return application_name;
    }

    public void setApplication_name(String application_name) {
        this.application_name = application_name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getApkPackage() {
        return apkPackage;
    }

    public void setApkPackage(String apkPackage) {
        this.apkPackage = apkPackage;
    }

    public int getNotification_count() {
        return notification_count;
    }
    public void setNotification_count(int notification_count) {
        this.notification_count = notification_count;
    }

    public boolean isIsblock() {
        return isblock;
    }

    public void setIsblock(boolean isblock) {
        this.isblock = isblock;
    }
}
