package com.recoverdata.deletedata.filerecover.utils

import android.content.Context
import android.util.Log
import android.view.View
import android.widget.Toast

fun Context.showToast(message: String, duration: Int = Toast.LENGTH_SHORT) {
    Toast.makeText(this, message, duration).show()
}

fun showLog(tag: String, text: String) {
    Log.e(tag, text)
}
fun View.doVisible() {
this.visibility = View.VISIBLE
}

fun View.doHide() {
    this.visibility = View.GONE
}

fun View.doInvisible() {
    this.visibility = View.INVISIBLE
}