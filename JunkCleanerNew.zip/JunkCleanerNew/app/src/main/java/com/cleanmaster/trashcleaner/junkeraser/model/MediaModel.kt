package com.cleanmaster.trashcleaner.junkeraser.model

data class MediaModel(var id : Int = null?:0,var name : String = null?:"",var number : String = null?:"",var path:String = null?:"",var isSelected: Boolean = null?:false) {
    constructor(FilePath: String) : this() {
            this.path = FilePath
    }
}
