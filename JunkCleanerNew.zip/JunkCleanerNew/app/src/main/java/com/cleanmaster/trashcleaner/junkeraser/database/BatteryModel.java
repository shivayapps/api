package com.cleanmaster.trashcleaner.junkeraser.database;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "battery_history")
public class BatteryModel {
    @PrimaryKey(autoGenerate = true)
    int id;
    @ColumnInfo(name = "hours")
    int hours;
    @ColumnInfo(name = "battery_level")
    int battery_level;
    @ColumnInfo(name = "date")
    String date;

    public BatteryModel(int hours, int battery_level, String date) {
        this.hours = hours;
        this.battery_level = battery_level;
        this.date = date;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getHours() {
        return hours;
    }

    public void setHours(int hours) {
        this.hours = hours;
    }

    public int getBattery_level() {
        return battery_level;
    }

    public void setBattery_level(int battery_level) {
        this.battery_level = battery_level;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
