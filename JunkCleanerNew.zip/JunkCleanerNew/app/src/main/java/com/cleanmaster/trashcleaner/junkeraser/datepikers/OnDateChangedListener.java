package com.cleanmaster.trashcleaner.junkeraser.datepikers;

public interface OnDateChangedListener {

    void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth);
}
