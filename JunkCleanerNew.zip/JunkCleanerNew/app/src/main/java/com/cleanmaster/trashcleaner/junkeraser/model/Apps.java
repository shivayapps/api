package com.cleanmaster.trashcleaner.junkeraser.model;

public class Apps {

    String app_package;
    String app_name;
    boolean issystem;

    public Apps(String app_package, String app_name, boolean issystem) {
        this.app_package = app_package;
        this.app_name = app_name;
        this.issystem = issystem;
    }

    public String getApp_package() {
        return app_package;
    }

    public void setApp_package(String app_package) {
        this.app_package = app_package;
    }

    public String getApp_name() {
        return app_name;
    }

    public void setApp_name(String app_name) {
        this.app_name = app_name;
    }

    public boolean isIssystem() {
        return issystem;
    }

    public void setIssystem(boolean issystem) {
        this.issystem = issystem;
    }
}