package com.cleanmaster.trashcleaner.junkeraser.adapter;

import android.app.Activity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.database.ApplicationModel;
import com.cleanmaster.trashcleaner.junkeraser.utils.ApkInfoExtractor;

import java.util.ArrayList;

public class App_List_Adapter extends RecyclerView.Adapter<App_List_Adapter.MyViewHolder> {


    OnSwitchCheckChangeListener onSwitchCheckChangeListener;
    Activity context;
    ArrayList<ApplicationModel> applicationModelArrayList;
    boolean isAllBlock = false;
    boolean isChecked;
    public App_List_Adapter(Activity context, ArrayList<ApplicationModel> applicationModelArrayList, OnSwitchCheckChangeListener onSwitchCheckChangeListener) {
        this.applicationModelArrayList = applicationModelArrayList;
        this.context = context;
        this.onSwitchCheckChangeListener = onSwitchCheckChangeListener;
    }

    public interface OnSwitchCheckChangeListener {
        void onCheckChange(int position, Boolean isChecked, String pkg_name);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.app_list_row, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, int position) {

        if (applicationModelArrayList.get(position).isIsblock()) {
            holder.status.setImageResource(R.drawable.ic_baseline_toggle_on_24);
        } else {
            holder.status.setImageResource(R.drawable.ic_baseline_toggle_off_24);
        }
        try {
            ApkInfoExtractor apkInfoExtractor = new ApkInfoExtractor(context);
            String applicationPackageName = applicationModelArrayList.get(position).getApkPackage();

            holder.app_name.setText(applicationModelArrayList.get(position).getApplication_name());
            Glide.with(context)
                    .load(apkInfoExtractor.getAppIconByPackageName(applicationPackageName))
                    .into(holder.app_icon);

            holder.itemView.setOnClickListener(v -> {
                if (applicationModelArrayList.get(position).isIsblock()) {
                    applicationModelArrayList.get(position).setIsblock(false);
                    holder.status.setImageResource(R.drawable.ic_baseline_toggle_off_24);
                    onSwitchCheckChangeListener.onCheckChange(position, applicationModelArrayList.get(position).isIsblock(), applicationModelArrayList.get(position).getApkPackage());
                } else {
                    applicationModelArrayList.get(position).setIsblock(true);
                    holder.status.setImageResource(R.drawable.ic_baseline_toggle_on_24);
                    onSwitchCheckChangeListener.onCheckChange(position, applicationModelArrayList.get(position).isIsblock(), applicationModelArrayList.get(position).getApkPackage());
                }
            });

//            List<BlockListModel> blockListModel = applicationDatabase.blockListDao().getAllBlockList();
//            if (blockListModel != null && blockListModel.get(0).getStatus().equals("ok") && holder.app_name.getText().equals(ApplicationLabelName)) {
//                Log.d("switch", blockListModel.get(0).getPackage_name());
//                holder.status.setChecked(true);
//            }

//            BlockList blockList2 = realm.where(BlockList.class).equalTo("package_name", ApplicationPackageName).findFirst();
//            if (blockList2 != null && blockList2.getStatus().equals("ok") && holder.app_name.getText().equals(ApplicationLabelName)) {
//                Log.d("switch", blockList2.getPackage_name());
//                holder.status.setChecked(true);
//            }
        } catch (Exception e) {
            Log.d("Error Line Number", Log.getStackTraceString(e));
        }
    }

    public void setIsBlockAll(boolean isAllBlock) {
        this.isAllBlock = isAllBlock;
        if (isAllBlock) {
            for (int i = 0; i < applicationModelArrayList.size(); i++) {
                applicationModelArrayList.get(i).setIsblock(true);
                notifyItemChanged(i);
            }
        } else {
            for (int i = 0; i < applicationModelArrayList.size(); i++) {
                applicationModelArrayList.get(i).setIsblock(false);
                notifyItemChanged(i);
            }
        }
    }

    @Override
    public int getItemCount() {
        return applicationModelArrayList.size();
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView app_name;
        public ImageView app_icon;
        public ImageView status;

        public MyViewHolder(View view) {
            super(view);
            app_name = view.findViewById(R.id.app_name);
            app_icon = view.findViewById(R.id.app_icon);
            status = view.findViewById(R.id.status);
        }
    }
}
