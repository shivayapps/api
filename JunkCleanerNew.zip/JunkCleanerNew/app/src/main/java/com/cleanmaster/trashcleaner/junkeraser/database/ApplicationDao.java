package com.cleanmaster.trashcleaner.junkeraser.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface ApplicationDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void application_insert(ApplicationModel model);

    @Query("DELETE FROM app_table")
    void application_deleteAll();

    @Query("UPDATE app_table SET count = 0 WHERE id = :id")
    void application_update_count(int id);

    @Query("SELECT * FROM app_table")
    List<ApplicationModel> getAllappList();

    @Query("SELECT * FROM app_table ORDER BY count Desc")
    List<ApplicationModel> getAllappListSortDesc();

    @Query("UPDATE app_table SET count = :updated_cound WHERE id = :id")
    void updateUsingID(int id, int updated_cound);
    @Query("UPDATE app_table SET isblock = :isblock WHERE apkPackage = :pkgname")
    void updateUsingID(String pkgname, boolean isblock);

    @Query("DELETE FROM app_table WHERE id = :userId")
    void deleteByUserId(int userId);

    @Query("SELECT * From app_table WHERE isblock = :isblock")
    List<ApplicationModel> getAllPositionList(boolean isblock);

    @Query("UPDATE app_table SET isblock = :isblock WHERE isblock = :notisblock")
    void blockAllUser(boolean isblock, boolean notisblock);
}
