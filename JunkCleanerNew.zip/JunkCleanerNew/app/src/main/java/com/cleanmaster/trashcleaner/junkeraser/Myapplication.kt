package com.cleanmaster.trashcleaner.junkeraser

import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.util.Log
import com.ads.module.open.AdconfigApplication
import com.cleanmaster.trashcleaner.junkeraser.applock.activities.lock.GestureUnlockActivity
import com.cleanmaster.trashcleaner.junkeraser.applock.base.BaseActivity
import com.cleanmaster.trashcleaner.junkeraser.applock.utils.SpUtil

class Myapplication : AdconfigApplication() {
    val CHANNEL_ID = "exampleChannel"


    override fun onCreate() {
        super.onCreate()

        instance = this
        createNotificationChannel()
        SpUtil.getInstance().init(instance)
        activityList = ArrayList()

    }


    companion object {
        var instance: Myapplication? = null
        var isLockScreenOpen = false
        fun getApplication(): Myapplication? {
            Log.e("hello123456789", "getApplication $instance")
            return instance
        }

        fun setIsLockScreenOpen(islock: Boolean) {
            Log.e("hello123456789", "getApplication $instance")
            isLockScreenOpen = islock
        }

        private var activityList: MutableList<BaseActivity>? = null
    }


    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Example Channel", NotificationManager.IMPORTANCE_HIGH
            )
            val manager = getSystemService(
                NotificationManager::class.java
            )
            manager.createNotificationChannel(channel)
        }
    }

    fun doForCreate(activity: BaseActivity) {
        Log.e("hello123456789", "myapp doForCreate")
        activityList!!.add(activity)
    }

    fun doForFinish(activity: BaseActivity) {
        Log.e("hello123456789", "myapp doForFinish")
        activityList!!.remove(activity)
    }

    fun clearAllActivity() {
        try {
            for (activity in activityList!!) {
                if (!clearAllWhiteList(activity)) activity.clear()
            }
            activityList!!.clear()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun clearAllWhiteList(activity: BaseActivity): Boolean {
        Log.e("hello123456789", "myapp clearAllWhiteList")
        return activity is GestureUnlockActivity
    }

}