package com.cleanmaster.trashcleaner.junkeraser.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.core.content.ContextCompat;
import androidx.core.view.ViewCompat;
import androidx.fragment.app.Fragment;
import androidx.room.Room;

import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.database.ApplicationDatabase;
import com.cleanmaster.trashcleaner.junkeraser.database.BatteryModel;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.formatter.IFillFormatter;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.interfaces.dataprovider.LineDataProvider;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.github.mikephil.charting.utils.Utils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class TestFragment2 extends Fragment {
    LineChart chart;
    LineDataSet set2;
    ApplicationDatabase applicationDatabase;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_test2, container, false);

        //applicationDatabase = Room.databaseBuilder(getActivity(), ApplicationDatabase.class, "application_db").allowMainThreadQueries().build();
        applicationDatabase = com.cleanmaster.trashcleaner.junkeraser.Utils.getApplicationDatabase(getActivity());
        chart = view.findViewById(R.id.chart1);
        initHistoryChart();
        return view;
    }

    public void initHistoryChart() {

        ArrayList<Entry> arrayList = new ArrayList<>();
        List<BatteryModel> batteryModelArrayList = new ArrayList<>();

        Log.d("rretertrtrw", "initHistoryChart: 11111111111111" + applicationDatabase.batteryDao().getAllBatteryList().size());
        Calendar calendar = Calendar.getInstance();
        calendar.add(5, -1);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd:MM:yyyy");

//        if (applicationDatabase.batteryDao().getAllBatteryList() != null) {
//
//            for (int i = 0; i < applicationDatabase.batteryDao().getAllBatteryList().size(); i++) {
////                Date date = new Date();
////                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd:MM:YY");
//                if (applicationDatabase.batteryDao().getAllBatteryList().get(i).getDate().equals(simpleDateFormat.format(calendar.getTime()))) {
//                    float val = applicationDatabase.batteryDao().getAllBatteryList().get(i).getBattery_level();
//                    arrayList.add(new Entry(applicationDatabase.batteryDao().getAllBatteryList().get(i).getHours(), val));
//                }
//            }
//        }

        batteryModelArrayList = applicationDatabase.batteryDao().getAllSortBatteryList(simpleDateFormat.format(calendar.getTime()));

        for (int i = 0; i < batteryModelArrayList.size(); i++) {
            arrayList.add(new Entry(batteryModelArrayList.get(i).getHours(), batteryModelArrayList.get(i).getBattery_level()));
        }

        Log.d("oppoii", "initHistoryChart: " + arrayList.size());
        LineDataSet lineDataSet = new LineDataSet(arrayList, "");
        this.set2 = lineDataSet;
        lineDataSet.setFillAlpha(100);
        this.set2.setColor(-6579542);
        this.set2.setLineWidth(1.0f);
        this.set2.setDrawValues(false);
        this.set2.setCircleColor(ContextCompat.getColor(getContext(), R.color.black));
        this.set2.setDrawFilled(true);
        this.set2.setFillColor(-9339154);
        this.set2.setFillFormatter(new IFillFormatter() {
            public float getFillLinePosition(ILineDataSet iLineDataSet, LineDataProvider lineDataProvider) {
                return chart.getAxisLeft().getAxisMinimum();
            }
        });
        if (Utils.getSDKInt() >= 18) {
            this.set2.setFillDrawable(ContextCompat.getDrawable(getContext(), R.drawable.fade_red));
        } else {
            this.set2.setFillColor(ViewCompat.MEASURED_STATE_MASK);
        }

        ArrayList arrayList2 = new ArrayList();
        arrayList2.add(set2);

        chart.setData(new LineData((List<ILineDataSet>) arrayList2));
        XAxis xAxis = this.chart.getXAxis();
        xAxis.setTextColor(ContextCompat.getColor(getContext(), R.color.textcolor));
        xAxis.setAxisMaximum(24.0f);
        xAxis.setAxisMinimum(0.0f);
        xAxis.setLabelCount(6);
        xAxis.setValueFormatter(new MyXaxisValueFormater(new String[]{"00:00", "", "", "", "04:00", "", "", "", "08:00", "", "", "", "12:00", "", "", "", "16:00", "", "", "", "20:00", "", "", "", "24:00"}));
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        this.chart.getXAxis().setDrawGridLines(false);
        YAxis axisLeft = this.chart.getAxisLeft();
        axisLeft.setTextColor(ContextCompat.getColor(getContext(), R.color.textcolor));
        axisLeft.setAxisMaximum(100.0f);
        axisLeft.setAxisMinimum(0.0f);
        axisLeft.setLabelCount(6);
        this.chart.getAxisRight().setEnabled(false);
        axisLeft.setValueFormatter(new MyXaxisValueFormater(new String[]{"", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "20%", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "40%", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "60%", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "80%", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "100%"}));
        axisLeft.enableGridDashedLine(10.0f, 10.0f, 0.0f);
        this.chart.setDescription((Description) null);
        this.chart.getXAxis().setDrawAxisLine(false);
        axisLeft.setDrawAxisLine(false);
        this.chart.getLegend().setEnabled(false);
        this.chart.setTouchEnabled(false);
    }

    public class MyXaxisValueFormater extends ValueFormatter implements IAxisValueFormatter {
        private String[] mValues;

        public MyXaxisValueFormater(String[] strArr) {
            this.mValues = strArr;
        }

        public String getFormattedValue(float f, AxisBase axisBase) {
            return this.mValues[(int) f];
        }
    }

    @Override
    public void onResume() {
        super.onResume();

    }
}