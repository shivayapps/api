package com.cleanmaster.trashcleaner.junkeraser.junckcleaner.activities

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.AsyncTask
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.util.Pair
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import com.ads.module.adutills.ClickCallback
import com.ads.module.adutills.NativeLoadWithShows
import com.ads.module.adutills.RewardedAdClass
import com.cleanmaster.trashcleaner.junkeraser.R
import com.cleanmaster.trashcleaner.junkeraser.activity.CleanCompleteActivity
import com.cleanmaster.trashcleaner.junkeraser.databinding.ActivityJunkBinding
import com.cleanmaster.trashcleaner.junkeraser.junckcleaner.adapters.EmptyFolderAdapter
import com.cleanmaster.trashcleaner.junkeraser.junckcleaner.adapters.JunkAdapter
import com.cleanmaster.trashcleaner.junkeraser.junckcleaner.interfaces.SelectAll
import com.cleanmaster.trashcleaner.junkeraser.junckcleaner.models.FileModel
import com.cleanmaster.trashcleaner.junkeraser.utils.Util
import java.io.File
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executor
import java.util.concurrent.Executors

class JunkActivity : AppCompatActivity(), SelectAll {

    var mTAG = "JunkActivity"

    private var imageviewBack1: ImageView? = null

    private var lottieTrash: ProgressBar? = null
    private var lottieLogtemp: ProgressBar? = null
    private var lottieUselessApks: ProgressBar? = null
    private var lottieEmptyFolder: ProgressBar? = null
    private var lottieUninstalled: ProgressBar? = null
//    private var lottieLoading: LottieAnimationView? = null

    private var apksExpended = false
    private var tempExpanded = false
    private var trashExpanded = false
    private var emptyExpanded = false
    private var uninstalledExpanded = false

    private var apksSelectedAll = true
    private var tempSelectedAll = true
    private var trashSelectedAll = true
    private var emptySelectedAll = true
    private var uninstalledSelectedAll = true
    var scanning = false
    var totalType = 0

    private var apksAdapter: JunkAdapter? = null
    private var tempAdapter: JunkAdapter? = null
    private var trashAdapter: JunkAdapter? = null
    private var emptyAdapter: EmptyFolderAdapter? = null
    private var uninstalledAdapter: JunkAdapter? = null
    var apksList: MutableList<FileModel> = ArrayList()
    var tempList: MutableList<FileModel> = ArrayList()
    var trashList: MutableList<FileModel> = ArrayList()
    var emptyList: MutableList<FileModel> = ArrayList()
    var uninstalledList: MutableList<FileModel> = ArrayList()
    var total: Double = 0.0
    var apkTotal: Double = 0.0
    var tempTotal: Double = 0.0
    var trashTotal: Double = 0.0
    var emptyTotal: Double = 0.0
    var uninstalledTotal: Double = 0.0
    var calendar: Calendar? = null

    private var getTempFiles: GetTempFiles? = null
    private var getApkFiles: GetApkFiles? = null
    private var getTrashFiles: GetTrashFiles? = null
    private var getEmptyFiles: GetEmptyFiles? = null
    private var getUninstalledFiles: GetUninstalledFiles? = null

    var apks: ArrayList<FileModel>? = null
    var tempLog: ArrayList<FileModel>? = null
    var trashCache: ArrayList<FileModel>? = null
    var emptyFolder: ArrayList<FileModel>? = null
    var uninstalledFolder: ArrayList<FileModel>? = null

    var filterTemps = ArrayList<String>()
    var filterTrash = ArrayList<String>()
    var filterInstalled = ArrayList<String>()
    var path = ""
    private var sharedPrefSetCleaner: SharedPreferences? = null
    var editor: SharedPreferences.Editor? = null
    var rewardedAdClass: RewardedAdClass? = null

    interface OnTaskCompleted {
        fun onTaskCompleted(type: Int)
    }

    private lateinit var binding: ActivityJunkBinding
    private var onTaskListner: OnTaskCompleted? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
        binding = ActivityJunkBinding.inflate(layoutInflater)
        setContentView(binding.root)

        imageviewBack1 = findViewById(R.id.imageView_back_1)
//        lottieLoading = findViewById(R.id.lottie_loading)
        lottieEmptyFolder = findViewById(R.id.lottie_empty_folder)
        lottieUninstalled = findViewById(R.id.lottie_uninstalled)
        lottieUselessApks = findViewById(R.id.lottie_useless_apks)
        lottieLogtemp = findViewById(R.id.lottie_logtemp)
        lottieTrash = findViewById(R.id.lottie_trash)

        sharedPrefSetCleaner = getSharedPreferences("Cleaners", MODE_PRIVATE)
        editor = sharedPrefSetCleaner!!.edit()

        path = Environment.getExternalStorageDirectory().toString()

        loadBanner()

        if (application != null) {
            val tempFiles: List<String> =
                ArrayList(listOf(*application!!.resources.getStringArray(R.array.generic_filter_files)))
            for (file in tempFiles) filterTemps.add(getRegexForFile(file))
        }

        if (application != null) {
            val trashFiles: List<String> =
                ArrayList(listOf(*application!!.resources.getStringArray(R.array.aggressive_filter_files)))
            for (file in trashFiles) filterTrash.add(getRegexForFile(file))
        }

        if (application != null) filterInstalled.addAll(getInstalledPackages(application!!.baseContext))
        calendar = Calendar.getInstance()

//        binding.clCalculated.visibility = View.GONE
//        binding.clCalculating.visibility = View.VISIBLE
        onTaskListner = object : OnTaskCompleted {
            override fun onTaskCompleted(type: Int) {
                Log.e(mTAG, "onTaskCompleted:$type")
                if (type == 2) {
                    Log.e(mTAG, "onTaskCompleted:apks")
                    apks?.forEach { apks ->
                        if (apks != null) {
                            apksList.add(apks)
                            apkTotal += apks.size.toFloat()
                        }
                    }
                    try {
                        Log.e(mTAG, "onTaskCompleted:setApksRecyclerView")
                        totalType += 1
                        setApksRecyclerView(apksList)
                        total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal
                        val size = com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(applicationContext, total)
                        setSizeAnimation(size)
//                        imagesDoneVisibility(true, 2)
//                        lottieVisibility(false, 2)
                        if (totalType >= 5) {
                            junkCalculating()
                            countJunkSize()
                        }
                    } catch (e: Exception) {
                        Log.e(mTAG, "getApks-Exception:$e")
                    }
                }
                if (type == 3) {
                    Log.e(mTAG, "onTaskCompleted:temps")
                    tempLog?.forEach { temps ->
                        if (temps != null) {
                            tempList.add(temps)
                            tempTotal += temps.size.toFloat()
                        }
                    }
                    try {
                        Log.e(mTAG, "onTaskCompleted:setTempRecyclerView")
                        totalType += 1
                        setTempRecyclerView(tempList)
                        total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal
                        val size =
                            com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(applicationContext, total)
                        setSizeAnimation(size)
//                        imagesDoneVisibility(true, 3)
//                        lottieVisibility(false, 3)
                        if (totalType >= 5) {
                            junkCalculating()
                            countJunkSize()
                        }
                    } catch (e: Exception) {
                        Log.e(mTAG, "getTempLog-Exception:$e")
                    }
                }
                if (type == 1) {
                    Log.e(mTAG, "onTaskCompleted:trash")
                    trashCache?.forEach { trash ->
                        if (trash != null) {
                            trashList.add(trash)
                            trashTotal += trash.size.toFloat()
                        }
                    }
                    try {
                        Log.e(mTAG, "onTaskCompleted:setTrashRecyclerView")
                        totalType += 1
                        setTrashRecyclerView(trashList)
                        total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal
                        val size =
                            com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(applicationContext, total)
                        setSizeAnimation(size)
//                        imagesDoneVisibility(true, 1)
//                        lottieVisibility(false, 1)
                        if (totalType >= 5) {
                            junkCalculating()
                            countJunkSize()
                        }
                    } catch (e: Exception) {
                        Log.e(mTAG, "getTrashCache-Exception:$e")
                    }
                }
                if (type == 4) {
                    Log.e(mTAG, "onTaskCompleted:empty")
                    emptyFolder?.forEach { empty ->
                        if (empty != null) {
                            emptyList.add(empty)
                            emptyTotal += empty.size.toFloat()
                        }
                    }
                    try {
                        Log.e(mTAG, "onTaskCompleted:setEmptyRecyclerView")
                        totalType += 1
                        setEmptyRecyclerView(emptyList)
                        total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal
                        val size =
                            com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(applicationContext, total)
                        setSizeAnimation(size)
//                        imagesDoneVisibility(true, 4)
//                        lottieVisibility(false, 4)
                        if (totalType >= 5) {
                            junkCalculating()
                            countJunkSize()
                        }
                    } catch (e: Exception) {
                        Log.e(mTAG, "getEmptyFolder-Exception:$e")
                    }

                }
                if (type == 5) {
                    Log.e(mTAG, "onTaskCompleted:uninstalled")
                    uninstalledFolder?.forEach { uninstalled ->
                        if (uninstalled != null) {
                            uninstalledList.add(uninstalled)
                            uninstalledTotal += uninstalled.size.toFloat()
                        }
                    }
                    try {
                        Log.e(mTAG, "onTaskCompleted:setUninstalledRecyclerView")
                        totalType += 1
                        setUninstalledRecyclerView(uninstalledList)
                        total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal
                        val size =
                            com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(applicationContext, total)
                        setSizeAnimation(size)
//                        imagesDoneVisibility(true, 5)
//                        lottieVisibility(false, 5)
                        if (totalType >= 5) {
                            junkCalculating()
                            countJunkSize()
                        }
                    } catch (e: Exception) {
                        Log.e(mTAG, "getUninstalled-Exception:$e")
                    }
                }
            }
        }

        runScanner()

        // recycler views visibilities settings
        binding.btnClean.setOnClickListener {
            showClearDialog(it)
        }


        imageviewBack1?.setOnClickListener {
            onBackPressed()
        }
        binding.imageViewApksUpDownClick.setOnClickListener(View.OnClickListener { v: View? ->
            if (!apksExpended) {
                binding.imageViewApksUpDown.rotation = 180f
                binding.recyclerViewApks.visibility = View.VISIBLE
                apksExpended = true
            } else {
                binding.imageViewApksUpDown.rotation = 0f
                binding.imageViewApksUpDown.setImageResource(R.drawable.ic_dropdown)
                binding.recyclerViewApks.visibility = View.GONE
                apksExpended = false
            }
        })
        binding.imageViewTempUpDownClick.setOnClickListener {
            if (!tempExpanded) {
                binding.imageViewTempUpDown.rotation = 180f
                binding.recyclerViewTemps.visibility = View.VISIBLE
                tempExpanded = true
            } else {
                binding.imageViewTempUpDown.rotation = 0f
                binding.recyclerViewTemps.visibility = View.GONE
                tempExpanded = false
            }
        }
        binding.imageViewTrashUpDownClick.setOnClickListener {
            if (!trashExpanded) {
                binding.imageViewTrashUpDown.rotation = 180f
                binding.recyclerViewTrash.visibility = View.VISIBLE
                trashExpanded = true
            } else {
                binding.imageViewTrashUpDown.rotation = 0f
                binding.recyclerViewTrash.visibility = View.GONE
                trashExpanded = false
            }
        }
        binding.imageViewEmptyUpDownClick.setOnClickListener {
            if (!emptyExpanded) {
                binding.imageViewEmptyUpDown.rotation = 180f
                binding.recyclerViewEmpty.visibility = View.VISIBLE
                emptyExpanded = true
            } else {
                binding.imageViewEmptyUpDown.rotation = 0f
                binding.recyclerViewEmpty.visibility = View.GONE
                emptyExpanded = false
            }
        }
        binding.imageViewUninstalledUpDownClick.setOnClickListener {
            if (!uninstalledExpanded) {
                binding.imageViewUninstalledUpDown.rotation = 180f
                binding.recyclerViewUninstalled.visibility = View.VISIBLE
                uninstalledExpanded = true
            } else {
                binding.imageViewUninstalledUpDown.rotation = 0f
                binding.recyclerViewUninstalled.visibility = View.GONE
                uninstalledExpanded = false
            }
        }


        rewardedAdClass = RewardedAdClass(this)
        rewardedAdClass?.loadRewardedAd()
    }


    fun showClearDialog(v: View?) {
//        buttonOk.setOnClickListener(view12 -> {
        /*if (total > 2000 && Util.isNetworkConnected(this@JunkActivity)) {
            rewardedAdClass!!.showRewardAdsDialog(v!!)
        } else*/
        if (total > 2000) {
            rewardedAdClass?.displayRewardAds(object : ClickCallback {
                override fun clickNext() {
                    cleanTrash()
                }
            })
        } else {
            Toast.makeText(this@JunkActivity, "Phone already clean", Toast.LENGTH_SHORT).show()
        }
    }

    fun cleanTrash() {
        binding.btnClean.visibility = View.GONE
        binding.progressbar.visibility = View.VISIBLE

        if (apksAdapter != null) apkTotal = apksAdapter?.allTotal!!
        if (tempAdapter != null) tempTotal = tempAdapter?.allTotal!!
        if (trashAdapter != null) trashTotal = trashAdapter?.allTotal!!
        if (emptyAdapter != null) emptyTotal = emptyAdapter?.allTotal!!
        if (uninstalledAdapter != null) uninstalledTotal = uninstalledAdapter?.allTotal!!
        total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal

        if (total == 0.0) {
            Toast.makeText(this@JunkActivity, "Phone already clean", Toast.LENGTH_SHORT).show()
            return
        }

        if (!scanning) {
//            binding.clBlur.visibility = View.VISIBLE
            binding.btnClean.alpha = 0.5f
            scanning = true

            if (apksAdapter != null) apksAdapter!!.clearFile()
            if (tempAdapter != null) tempAdapter!!.clearFile()
            if (trashAdapter != null) trashAdapter!!.clearFile()
            if (emptyAdapter != null) emptyAdapter!!.clearFile()
            if (uninstalledAdapter != null) uninstalledAdapter!!.clearFile()

            binding.btnClean.text = "Cleaning"
            cleanProgressAnimation()
        }
    }


    private fun getAllUninstalled(
        path: String,
        filterInstalled: ArrayList<String>
    ): List<FileModel> {
        val fold = File(path)
        val docList: MutableList<FileModel> = ArrayList()
        val mlist = fold.listFiles()
        val mFilelist = fold.listFiles(com.cleanmaster.trashcleaner.junkeraser.utils.Util.AllUninstalledFilter(filterInstalled))
        if (mlist != null) {
            for (f in mlist) {
                if (f.isDirectory && f.absolutePath.contains("Android")) {
                    if (!f.absolutePath.contains("Backup And Recovery")) {
                        val fList = getAllUninstalled(f.absolutePath, filterInstalled)
                        docList.addAll(fList)
                    }
                }
            }
            if (mFilelist != null) {
                for (f in mFilelist) {
                    if (f.name.isNotEmpty() || !f.absolutePath.contains("Backup And Recovery")) {
                        val doc = FileModel()
                        doc.name = f.name
                        doc.setSize(f.length())
                        doc.path = f.absolutePath
                        if (f.length() > 0) {
                            docList.add(doc)
                        }
                    }
                }
            }
        }
        return docList
    }

    private val emptyDocList: MutableList<FileModel> = ArrayList()
    private fun getAllEmptyNew(path: String): List<FileModel> {
        Log.e("Utils", "getAllEmptyNew:$path")
        val fold = File(path)
        val mlist = fold.listFiles()
        if (mlist != null && mlist.isNotEmpty()) {
            for (f in mlist) {
                if (f.isDirectory) {
                    if (!f.toString().startsWith("/storage/emulated/0/Android/data")
                        && !f.toString().startsWith("/storage/emulated/0/Android/obb")
                    ) {
                        getAllEmptyNew(f.absolutePath)
                    }
                }
            }
        } else {
            Log.e("Utils", "getAllEmptyNew:emptySize" + emptyDocList.size)
            Log.e("Utils", "getAllEmptyNew:fold:" + fold.path)
            if (fold.isDirectory) {
                if (!fold.toString().startsWith("/storage/emulated/0/Android/data")
                    && !fold.toString().startsWith("/storage/emulated/0/Android/obb")
                ) {
                    val doc = FileModel()
                    doc.name = fold.name
                    doc.setSize(fold.length())
                    doc.path = fold.absolutePath
                    if (fold.length() > 0) {
                        Log.e("Utils", "getAllEmptyNew:getPath_001:" + fold.path)
                        emptyDocList.add(doc)
                    }
                }
            }
        }
        return emptyDocList
    }

    private fun getAllTrash(path: String, trashFilters: ArrayList<String>): List<FileModel> {
        val fold = File(path)
        val docList: MutableList<FileModel> = ArrayList()
        val mlist = fold.listFiles()
        val mFilelist = fold.listFiles(com.cleanmaster.trashcleaner.junkeraser.utils.Util.AllTempLogsFilter(trashFilters))
        if (mlist != null) {
            for (f in mlist) {
                if (f.isDirectory) {
                    val fList = getAllTrash(f.absolutePath, trashFilters)
                    docList.addAll(fList)
                }
            }
            if (mFilelist != null) {
                for (f in mFilelist) {
                    if (f.name.isNotEmpty() || !f.absolutePath.contains("Backup And Recovery")) {
                        val doc = FileModel()
                        doc.name = f.name
                        doc.setSize(f.length())
                        doc.path = f.absolutePath
                        if (f.length() > 0) {
                            docList.add(doc)
                        }
                    }
                }
            }
        }
        return docList
    }

    private fun getAllTempLogs(path: String, tempFilters: ArrayList<String>): List<FileModel> {
        Log.e("Utils", "getAllTempLogs:$path")
        val fold = File(path)
        val docList: MutableList<FileModel> = ArrayList()
        val mlist = fold.listFiles()
        val mFilelist = fold.listFiles(com.cleanmaster.trashcleaner.junkeraser.utils.Util.AllTempLogsFilter(tempFilters))
        if (mlist != null) {
            Log.e("Utils", "getAllTempLogs:mlist:" + mlist.size)
            for (f in mlist) {
                if (f.isDirectory) {
                    val fList = getAllTempLogs(f.absolutePath, tempFilters)
                    docList.addAll(fList)
                }
            }
            if (mFilelist != null) {
                for (f in mFilelist) {
                    if (f.name.isNotEmpty() || !f.absolutePath.contains("Backup And Recovery")) {
                        val doc = FileModel()
                        doc.name = f.name
                        doc.setSize(f.length())
                        doc.path = f.absolutePath
                        if (f.length() > 0) {
                            docList.add(doc)
                        }
                    }
                }
            }
        }
        return docList
    }

    private fun getAllPackages(path: String): List<FileModel> {

        val fold = File(path)
        val docList: MutableList<FileModel> = ArrayList()
        val mlist = fold.listFiles()
        val mFilelist = fold.listFiles(com.cleanmaster.trashcleaner.junkeraser.utils.Util.AllPackagesFilter())

        if (mlist != null) {
            for (f in mlist) {
                if (f.isDirectory) {
                    val fList = getAllPackages(f.absolutePath)
                    docList.addAll(fList)
                }
            }
            if (mFilelist != null) {
                for (f in mFilelist) {
                    if (f.name.isNotEmpty() || !f.absolutePath.contains("Backup And Recovery")) {
                        val doc = FileModel()
                        doc.name = f.name
                        doc.setSize(f.length())
                        doc.path = f.absolutePath
                        if (f.length() > 0) {
                            docList.add(doc)
                        }
                    }
                }
            }
        }
        return docList
    }

    private fun getRegexForFolder(folder: String): String {
        return ".*(\\\\|/)$folder(\\\\|/|$).*"
    }

    private fun getRegexForFile(file: String): String {
        return ".+" + file.replace(".", "\\.") + "$"
    }

    private fun getInstalledPackages(context: Context): List<String> {
        val pm = context.packageManager
        val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val packagesString: MutableList<String> = ArrayList()
        for (packageInfo in packages) {
            packagesString.add(packageInfo.packageName)
        }
        return packagesString
    }

    private fun runScanner() {
        if (!scanning) {
            scanning = true

//            binding.clCalculated.visibility = View.GONE
//            binding.clCalculating.visibility = View.VISIBLE
//            imagesDoneVisibility(false, 1)
//            lottieVisibility(true, 1)
//            imagesDoneVisibility(false, 2)
//            lottieVisibility(true, 2)
//            imagesDoneVisibility(false, 3)
//            lottieVisibility(true, 3)
//            imagesDoneVisibility(false, 4)
//            lottieVisibility(true, 4)
//            imagesDoneVisibility(false, 5)
//            lottieVisibility(true, 5)

            getTempFiles = GetTempFiles(this@JunkActivity, onTaskListner)
            getApkFiles = GetApkFiles(this@JunkActivity, onTaskListner)
            getTrashFiles = GetTrashFiles(this@JunkActivity, onTaskListner)
            getEmptyFiles = GetEmptyFiles(this@JunkActivity, onTaskListner)
            getUninstalledFiles = GetUninstalledFiles(this@JunkActivity, onTaskListner)

            getTempFiles?.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)

            getApkFiles?.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)

            getTrashFiles?.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)

            getEmptyFiles?.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)

            getUninstalledFiles?.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)

        }
    }


    inner class GetTempFiles(
        var context: Activity,
        private var onTaskCompleted: OnTaskCompleted?
    ) : AsyncTask<String, String, String>() {

        override fun onPreExecute() {
            super.onPreExecute()
            binding.imageViewTempSelect.isVisible = false
            binding.lottieLogtemp.isVisible = true
        }

        @Deprecated("Deprecated in Java")
        protected override fun doInBackground(vararg strings: String): String? {
            Log.e(mTAG, "AsyncTask-doInBackground:3")
            try {
                tempLog = ArrayList(getAllTempLogs(path, filterTemps))
            } catch (e: Exception) {
                Log.e(mTAG, "AsyncTask-3:Exception:$e")
            }
            System.gc()
            return null
        }

        @Deprecated("Deprecated in Java")
        override fun onPostExecute(str: String?) {
            super.onPostExecute(str)
            Log.e(mTAG, "AsyncTask-onTaskCompleted:3")
            onTaskCompleted!!.onTaskCompleted(3)

            binding.imageViewTempSelect.isVisible = true
            binding.lottieLogtemp.isVisible = false
        }
    }

    inner class GetApkFiles(
        var context: Activity,
        private var onTaskCompleted: OnTaskCompleted?
    ) : AsyncTask<String, String, String>() {

        override fun onPreExecute() {
            super.onPreExecute()

            binding.lottieUselessApks.isVisible = true
            binding.imageViewApksSelect.isVisible = false
        }

        protected override fun doInBackground(vararg strings: String): String? {
            Log.e(mTAG, "AsyncTask-doInBackground:2")
            try {
                apks = ArrayList(getAllPackages(path))
            } catch (e: Exception) {
                Log.e(mTAG, "AsyncTask-2:Exception:$e")
            }
            System.gc()
            return null
        }

        override fun onPostExecute(str: String?) {
            super.onPostExecute(str)
            Log.e(mTAG, "AsyncTask-onTaskCompleted:2")
            onTaskCompleted!!.onTaskCompleted(2)
            binding.lottieUselessApks.isVisible = false
            binding.imageViewApksSelect.isVisible = true
        }
    }

    inner class GetTrashFiles(
        var context: Activity,
        private var onTaskCompleted: OnTaskCompleted?
    ) : AsyncTask<String, String, String>() {

        override fun onPreExecute() {
            super.onPreExecute()
            binding.lottieTrash.isVisible = true
            binding.imageViewTrashSelect.isVisible = false
        }

        protected override fun doInBackground(vararg strings: String): String? {
            Log.e(mTAG, "AsyncTask-doInBackground:1")
            try {
                trashCache = ArrayList(getAllTrash(path, filterTrash))
            } catch (e: Exception) {
                Log.e(mTAG, "AsyncTask-1:Exception:$e")
            }
            System.gc()
            return null
        }

        override fun onPostExecute(str: String?) {
            super.onPostExecute(str)
            Log.e(mTAG, "AsyncTask+onTaskCompleted:1")
            onTaskCompleted!!.onTaskCompleted(1)

            binding.lottieTrash.isVisible = false
            binding.imageViewTrashSelect.isVisible = true
        }
    }

    inner class GetEmptyFiles(
        var context: Activity,
        private var onTaskCompleted: OnTaskCompleted?
    ) : AsyncTask<String, String, String>() {

        override fun onPreExecute() {
            super.onPreExecute()
            binding.lottieEmptyFolder.isVisible = true
            binding.imageViewEmptySelect.isVisible = false
        }

        protected override fun doInBackground(vararg strings: String): String? {
            Log.e(mTAG, "AsyncTask+doInBackground:4")
            try {
                emptyDocList.clear()
                emptyFolder = ArrayList(getAllEmptyNew(path))
            } catch (e: Exception) {
                Log.e(mTAG, "AsyncTask+4:Exception:$e")
            }
            System.gc()
            return null
        }

        override fun onPostExecute(str: String?) {
            super.onPostExecute(str)
            Log.e(mTAG, "AsyncTask+onTaskCompleted:4")
            onTaskCompleted!!.onTaskCompleted(4)
            binding.lottieEmptyFolder.isVisible = false
            binding.imageViewEmptySelect.isVisible = true
        }
    }

    inner class GetUninstalledFiles(
        var context: Activity,
        var onTaskCompleted: OnTaskCompleted?
    ) : AsyncTask<String, String, String>() {

        override fun onPreExecute() {
            super.onPreExecute()

            binding.lottieUninstalled.isVisible = true
            binding.imageViewUninstalledSelect.isVisible = false
        }

        protected override fun doInBackground(vararg strings: String): String? {
            Log.e(mTAG, "AsyncTask+doInBackground:5")
            try {
                uninstalledFolder = ArrayList(getAllUninstalled(path, filterInstalled))
            } catch (e: Exception) {
                Log.e(mTAG, "AsyncTask+5:Exception:$e")
            }
            System.gc()
            return null
        }

        override fun onPostExecute(str: String?) {
            super.onPostExecute(str)
            Log.e(mTAG, "AsyncTask+onTaskCompleted:5")
            onTaskCompleted!!.onTaskCompleted(5)
            binding.lottieUninstalled.isVisible = false
            binding.imageViewUninstalledSelect.isVisible = true
        }
    }

    /*fun imagesDoneVisibility(visible: Boolean, num: Int) {
        if (visible) {
            when (num) {
                1 -> {
                    binding.imageViewTrash.visibility = View.VISIBLE
                }

                2 -> {
                    binding.imageViewUselessApks.visibility = View.VISIBLE
                }

                3 -> {
                    binding.imageViewTempFiles.visibility = View.VISIBLE
                }

                4 -> {
                    binding.imageViewEmptyFolder.visibility = View.VISIBLE
                }

                5 -> {
                    binding.imageViewUninstalled.visibility = View.VISIBLE
                }
            }
        } else {
            when (num) {
                1 -> {
                    binding.imageViewTrash.visibility = View.INVISIBLE
                }

                2 -> {
                    binding.imageViewUselessApks.visibility = View.INVISIBLE
                }

                3 -> {
                    binding.imageViewTempFiles.visibility = View.INVISIBLE
                }

                4 -> {
                    binding.imageViewEmptyFolder.visibility = View.INVISIBLE
                }

                5 -> {
                    binding.imageViewUninstalled.visibility = View.INVISIBLE
                }
            }
        }
    }*/

    /*fun lottieVisibility(visible: Boolean, num: Int) {
        if (visible) {
            when (num) {
                1 -> {
                    lottieTrash!!.visibility = View.VISIBLE
                }

                2 -> {
                    lottieUselessApks!!.visibility = View.VISIBLE
                }

                3 -> {
                    lottieLogtemp!!.visibility = View.VISIBLE
                }

                4 -> {
                    lottieEmptyFolder!!.visibility = View.VISIBLE
                }

                5 -> {
                    lottieUninstalled!!.visibility = View.VISIBLE
                }
            }
        } else {
            when (num) {
                1 -> {
                    lottieTrash!!.visibility = View.INVISIBLE
                }

                2 -> {
                    lottieUselessApks!!.visibility = View.INVISIBLE
                }

                3 -> {
                    lottieLogtemp!!.visibility = View.INVISIBLE
                }

                4 -> {
                    lottieEmptyFolder!!.visibility = View.INVISIBLE
                }

                5 -> {
                    lottieUninstalled!!.visibility = View.INVISIBLE
                }
            }
        }
    }*/

    @SuppressLint("SetTextI18n")
    fun setApksRecyclerView(list: List<FileModel>) {
        val lm1 = LinearLayoutManager(this)
        lm1.orientation = LinearLayoutManager.VERTICAL
        val list1: List<FileModel> = ArrayList(list)
        val list2: List<FileModel> = ArrayList(list)
        apksAdapter =
            JunkAdapter(
                this@JunkActivity,
                list1,
                list2,
                "apk",
                apkTotal
            )
        binding.recyclerViewApks.layoutManager = lm1
        binding.recyclerViewApks.adapter = apksAdapter
        apksAdapter!!.setSelectAll(this)
        apksAdapter!!.submitList(list)
        if (list.isEmpty()) {
            binding.imageViewApksSelect.setImageResource(R.drawable.ic_uncheck)
        } else {
            binding.imageViewApksSelect.setImageResource(R.drawable.ic_check)
        }
        apkTotal = apksAdapter!!.allTotal
        val size = com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(applicationContext, apkTotal)
        binding.textViewApksSize.text = "${size.first} ${size.second}"
        binding.imageViewApksSelect.setOnClickListener { v: View? ->
            Log.e("setRecyclerView", "imageViewApksSelect.apksSelectedAll:$apksSelectedAll")
            if (apksSelectedAll) {
                binding.imageViewApksSelect.setImageResource(R.drawable.ic_uncheck)
                apksAdapter!!.clearList()
                apksSelectedAll = false

                if (apksAdapter != null) apkTotal = apksAdapter?.allTotal!!
                if (tempAdapter != null) tempTotal = tempAdapter?.allTotal!!
                if (trashAdapter != null) trashTotal = trashAdapter?.allTotal!!
                if (emptyAdapter != null) emptyTotal = emptyAdapter?.allTotal!!
                if (uninstalledAdapter != null) uninstalledTotal = uninstalledAdapter?.allTotal!!
                total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal


//                total = apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal
                val size = com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(applicationContext, total)
                binding.btnClean.text = getString(R.string.clean) + "(" + String.format(
                    Locale.ENGLISH,
                    "%.2f",
                    size.first.toFloat()
                ) + size.second + ")"
            } else {
                apksSelectedAll = true
                apksAdapter!!.selectAll()
                binding.imageViewApksSelect.setImageResource(R.drawable.ic_check)
                total =
                    apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal
                val size = com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(applicationContext, total)
                binding.btnClean.text = getString(R.string.clean) + "(" + String.format(
                    Locale.ENGLISH,
                    "%.2f",
                    size.first.toFloat()
                ) + size.second + ")"
            }
        }
        if (apksList.isEmpty()) {
        } else {
            binding.clApksHead.visibility = View.VISIBLE
            binding.imageViewApksUpDown.visibility = View.VISIBLE
            binding.imageViewApksSelect.visibility = View.VISIBLE
            binding.imageViewApksUpDownClick.visibility = View.VISIBLE
            binding.textViewApksSize.visibility = View.VISIBLE
        }
    }

    @SuppressLint("SetTextI18n")
    fun setTempRecyclerView(list: List<FileModel>) {
        val lm1 = LinearLayoutManager(this)
        lm1.orientation = LinearLayoutManager.VERTICAL
        val list1: List<FileModel> = ArrayList(list)
        val list2: List<FileModel> = ArrayList(list)
        tempAdapter =
            JunkAdapter(
                this@JunkActivity,
                list1,
                list2,
                "temp",
                tempTotal
            )
        binding.recyclerViewTemps.layoutManager = lm1
        binding.recyclerViewTemps.adapter = tempAdapter
        tempAdapter!!.setSelectAll(this)
        tempAdapter!!.submitList(list)
        if (list.isNotEmpty()) {
            binding.imageViewTempSelect.setImageResource(R.drawable.ic_check)
        }
        tempTotal = tempAdapter!!.allTotal

        val size = com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(applicationContext, tempTotal)
        binding.textViewTempSize.text = "${size.first} ${size.second}"
        binding.imageViewTempSelect.setOnClickListener { v: View? ->
            Log.e("setRecyclerView", "imageViewTempSelect.tempSelectedAll:$tempSelectedAll")
            if (!tempSelectedAll) {
                tempSelectedAll = true
                binding.imageViewTempSelect.setImageResource(R.drawable.ic_check)
                tempAdapter!!.selectAll()
                total =
                    apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal
                val size = com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(applicationContext, total)
                binding.btnClean.text = getString(R.string.clean) + "(" + String.format(
                    Locale.ENGLISH,
                    "%.2f",
                    size.first.toFloat()
                ) + size.second + ")"

            } else {
                tempAdapter!!.clearList()
                tempSelectedAll = false
                binding.imageViewTempSelect.setImageResource(R.drawable.ic_uncheck)
                total =
                    apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal
                val size = com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(applicationContext, total)
                binding.btnClean.text = getString(R.string.clean) + "(" + String.format(
                    Locale.ENGLISH,
                    "%.2f",
                    size.first.toFloat()
                ) + size.second + ")"

            }
        }
        if (tempList.isNotEmpty()) {
            binding.clTempHead.visibility = View.VISIBLE
            binding.imageViewTempUpDown.visibility = View.VISIBLE
            binding.imageViewTempSelect.visibility = View.VISIBLE
            binding.imageViewTempUpDownClick.visibility = View.VISIBLE
            binding.textViewTempSize.visibility = View.VISIBLE
        }
    }

    @SuppressLint("SetTextI18n")
    fun setTrashRecyclerView(list: List<FileModel>) {
        val lm3 = LinearLayoutManager(this)
        lm3.orientation = LinearLayoutManager.VERTICAL
        val list1: List<FileModel> = ArrayList(list)
        val list2: List<FileModel> = ArrayList(list)
        trashAdapter =
            JunkAdapter(
                this@JunkActivity,
                list1,
                list2,
                "trash",
                trashTotal
            )
        binding.recyclerViewTrash.layoutManager = lm3
        binding.recyclerViewTrash.adapter = trashAdapter
        trashAdapter!!.setSelectAll(this)
        trashAdapter!!.submitList(list)
        if (list.isNotEmpty()) {
            binding.imageViewTempSelect.setImageResource(R.drawable.ic_check)
        }
        trashTotal = trashAdapter!!.allTotal
        val size = com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(applicationContext, trashTotal)
        binding.textViewTempSize.text = "${size.first} ${size.second}"
        binding.imageViewTrashSelect.setOnClickListener { v: View? ->
            Log.e("setRecyclerView", "imageViewTrashSelect.trashSelectedAll:$trashSelectedAll")
            if (!trashSelectedAll) {
                binding.imageViewTrashSelect.setImageResource(R.drawable.ic_check)
                trashAdapter!!.selectAll()
                trashSelectedAll = true
//                total=total+trashTotal
                total =
                    apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal
                val size = com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(applicationContext, total)
                binding.btnClean.text = getString(R.string.clean) + "(" + String.format(
                    Locale.ENGLISH,
                    "%.2f",
                    size.first.toFloat()
                ) + size.second + ")"

            } else {
                trashAdapter!!.clearList()
                trashSelectedAll = false
                binding.imageViewTrashSelect.setImageResource(R.drawable.ic_uncheck)
                total =
                    apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal
                val size = com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(applicationContext, total)
                binding.btnClean.text = getString(R.string.clean) + "(" + String.format(
                    Locale.ENGLISH,
                    "%.2f",
                    size.first.toFloat()
                ) + size.second + ")"
            }
        }
        if (trashList.isNotEmpty()) {
            binding.clTrashHead.visibility = View.VISIBLE
            binding.imageViewTrashUpDownClick.visibility = View.VISIBLE
            binding.imageViewTrashUpDown.visibility = View.VISIBLE
            binding.textViewTrashSize.visibility = View.VISIBLE
            binding.imageViewTrashSelect.visibility = View.VISIBLE
        }
    }

    @SuppressLint("SetTextI18n")
    fun setEmptyRecyclerView(list: List<FileModel>) {
        val lm3 = LinearLayoutManager(this)
        lm3.orientation = LinearLayoutManager.VERTICAL
        val list1: List<FileModel> = ArrayList(list)
        val list2: List<FileModel> = ArrayList(list)
        emptyAdapter =
            EmptyFolderAdapter(
                this@JunkActivity,
                list1,
                list2,
                "empty",
                emptyTotal
            )
        binding.recyclerViewEmpty.layoutManager = lm3
        binding.recyclerViewEmpty.adapter = emptyAdapter
        emptyAdapter!!.setSelectAll(this)
        emptyAdapter!!.submitList(list)
        if (list.isNotEmpty()) {
            binding.imageViewEmptySelect.setImageResource(R.drawable.ic_check)
        }
        emptyTotal = emptyAdapter!!.allTotal

        val size = com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(applicationContext, emptyTotal)
        binding.textViewEmptySize.text = "${size.first} ${size.second}"

        binding.imageViewEmptySelect.setOnClickListener {
            Log.e("setRecyclerView", "imageViewEmptySelect.emptySelectedAll:$emptySelectedAll")
            if (!emptySelectedAll) {
                binding.imageViewEmptySelect.setImageResource(R.drawable.ic_check)
                emptyAdapter!!.selectAll()
                emptySelectedAll = true
                total =
                    apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal
                val size = com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(applicationContext, total)
                binding.btnClean.text = getString(R.string.clean) + "(" + String.format(
                    Locale.ENGLISH,
                    "%.2f",
                    size.first.toFloat()
                ) + size.second + ")"
            } else {
                emptyAdapter!!.clearList()
                emptySelectedAll = false
                binding.imageViewEmptySelect.setImageResource(R.drawable.ic_uncheck)
                total =
                    apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal
                val size = com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(applicationContext, total)
                binding.btnClean.text = getString(R.string.clean) + "(" + String.format(
                    Locale.ENGLISH,
                    "%.2f",
                    size.first.toFloat()
                ) + size.second + ")"
            }
        }
        if (emptyList.isEmpty()) {
        } else {
            binding.clEmptyHead.visibility = View.VISIBLE
            binding.imageViewEmptyUpDownClick.visibility = View.VISIBLE
            binding.imageViewEmptyUpDown.visibility = View.VISIBLE
            binding.textViewEmptySize.visibility = View.VISIBLE
            binding.imageViewEmptySelect.visibility = View.VISIBLE
        }
    }

    @SuppressLint("SetTextI18n")
    fun setUninstalledRecyclerView(list: List<FileModel>) {
        val lm3 = LinearLayoutManager(this)
        lm3.orientation = LinearLayoutManager.VERTICAL
        val list1: List<FileModel> = ArrayList(list)
        val list2: List<FileModel> = ArrayList(list)
        uninstalledAdapter =
            JunkAdapter(
                this@JunkActivity,
                list1,
                list2,
                "uninstall",
                uninstalledTotal
            )
        binding.recyclerViewUninstalled.layoutManager = lm3
        binding.recyclerViewUninstalled.adapter = uninstalledAdapter
        uninstalledAdapter!!.setSelectAll(this)
        uninstalledAdapter!!.submitList(list)
        if (list.isNotEmpty()) {
            binding.imageViewUninstalledSelect.setImageResource(R.drawable.ic_check)
        }
        uninstalledTotal = uninstalledAdapter!!.allTotal

        val size = com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(applicationContext, uninstalledTotal)
        binding.textViewUninstalledSize.text = "${size.first} ${size.second}"
        binding.imageViewUninstalledSelect.setOnClickListener {
            Log.e(
                "setRecyclerView",
                "imageViewUninstalledSelect.uninstalledSelectedAll:$uninstalledSelectedAll"
            )
            if (!uninstalledSelectedAll) {
                binding.imageViewUninstalledSelect.setImageResource(R.drawable.ic_check)
                uninstalledAdapter!!.selectAll()
                uninstalledSelectedAll = true
                total =
                    apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal
                val size = com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(applicationContext, total)
                binding.btnClean.text = getString(R.string.clean) + "(" + String.format(
                    Locale.ENGLISH,
                    "%.2f",
                    size.first.toFloat()
                ) + size.second + ")"

            } else {
                uninstalledAdapter!!.clearList()
                uninstalledSelectedAll = false
                binding.imageViewUninstalledSelect.setImageResource(R.drawable.ic_uncheck)
                total =
                    apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal
                val size = com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(applicationContext, total)
                binding.btnClean.text = getString(R.string.clean) + "(" + String.format(
                    Locale.ENGLISH,
                    "%.2f",
                    size.first.toFloat()
                ) + size.second + ")"
            }
        }
        if (uninstalledList.isEmpty()) {
        } else {
            binding.clUninstalledHead.visibility = View.VISIBLE
            binding.imageViewUninstalledUpDownClick.visibility = View.VISIBLE
            binding.imageViewUninstalledUpDown.visibility = View.VISIBLE
            binding.textViewUninstalledSize.visibility = View.VISIBLE
            binding.imageViewUninstalledSelect.visibility = View.VISIBLE
        }
    }

    fun junkCalculating() {
        scanning = false
//        binding.clCalculating.visibility = View.INVISIBLE
//        binding.clCalculated.visibility = View.VISIBLE
        binding.textViewFilePath.visibility = View.GONE

//        binding.clBlur.visibility = View.GONE
        binding.btnClean.text = getString(R.string.clean)
        binding.btnClean.alpha = 1.0f

        countJunkSize()

        val executor: Executor = Executors.newSingleThreadExecutor()
        val handler = Handler(Looper.getMainLooper())
        val size = com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(
            applicationContext,
            apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal
        )
        executor.execute {
            handler.post {
                setSizeAnimation(size)
            }
        }

        if (total <= 0) scanningFinish(size)
    }

    private fun countJunkSize() {

        var junkTotal = 0.0
        for (apk in apksList) {
            junkTotal += apk.size
        }

        for (temp in tempList) {
            junkTotal += temp.size
        }

        for (trash in trashList) {
            junkTotal += trash.size
        }

        for (empty in emptyList) {
            junkTotal += empty.size
        }


        for (uninstall in uninstalledList) {
            junkTotal += uninstall.size
        }

        val size = com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(applicationContext, junkTotal)

        setSizeAnimation(size)

    }

    private fun cleanProgressAnimation() {
        scanning = false
        val size = com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(applicationContext, this.total)
        setSizeAnimation(size)
        scanningFinish(size)
    }

    @SuppressLint("DefaultLocale", "SetTextI18n")
    private fun setSizeAnimation(size: Pair<String, String>) {

        Handler(Looper.getMainLooper()).post {
            binding.textViewJunkSize.text = String.format(
                Locale.ENGLISH,
                "%.2f",
                size.first.toDouble()
            ) + size.second
            binding.btnClean.text = getString(R.string.clean) + "(" + String.format(
                Locale.ENGLISH,
                "%.2f",
                size.first.toFloat()
            ) + size.second + ")"
        }
    }

    override fun onBackPressed() {
        if (getTempFiles?.status == AsyncTask.Status.RUNNING) {
            getTempFiles?.cancel(true)
        }
        if (getApkFiles?.status == AsyncTask.Status.RUNNING) {
            getApkFiles?.cancel(true)
        }
        if (getTrashFiles?.status == AsyncTask.Status.RUNNING) {
            getTrashFiles?.cancel(true)
        }
        if (getEmptyFiles?.status == AsyncTask.Status.RUNNING) {
            getEmptyFiles?.cancel(true)
        }
        if (getUninstalledFiles?.status == AsyncTask.Status.RUNNING) {
            getUninstalledFiles?.cancel(true)
        }
        scanning = false
        super.onBackPressed()
    }


    @SuppressLint("SetTextI18n")
    override fun selectAll(isSelectAll: Boolean, type: String) {
        Log.e(mTAG, "selectAll-type:$type")

        if (apksAdapter != null) apkTotal = apksAdapter?.allTotal!!
        if (tempAdapter != null) tempTotal = tempAdapter?.allTotal!!
        if (trashAdapter != null) trashTotal = trashAdapter?.allTotal!!
        if (emptyAdapter != null) emptyTotal = emptyAdapter?.allTotal!!
        if (uninstalledAdapter != null) uninstalledTotal = uninstalledAdapter?.allTotal!!

        if (type.equals("apk", true)) {
            if (isSelectAll) {
                binding.imageViewApksSelect.setImageResource(R.drawable.ic_check)
                apksSelectedAll = true
            } else {
                apksSelectedAll = false
                binding.imageViewApksSelect.setImageResource(R.drawable.ic_uncheck)
            }
            total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal

            val size = com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(applicationContext, total)
            binding.btnClean.text = getString(R.string.clean) + "(" + String.format(
                Locale.ENGLISH,
                "%.2f",
                size.first.toFloat()
            ) + size.second + ")"

        } else if (type.equals("temp", true)) {
            if (isSelectAll) {
                binding.imageViewTempSelect.setImageResource(R.drawable.ic_check)
                tempSelectedAll = true
            } else {
                tempSelectedAll = false
                binding.imageViewTempSelect.setImageResource(R.drawable.ic_uncheck)
            }
            total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal

            val size = com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(applicationContext, total)
            binding.btnClean.text = getString(R.string.clean) + "(" + String.format(
                Locale.ENGLISH,
                "%.2f",
                size.first.toFloat()
            ) + size.second + ")"

        } else if (type.equals("trash", true)) {
            if (isSelectAll) {
                binding.imageViewTrashSelect.setImageResource(R.drawable.ic_check)
                trashSelectedAll = true
            } else {
                trashSelectedAll = false
                binding.imageViewTrashSelect.setImageResource(R.drawable.ic_uncheck)
            }
            total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal

            val size = com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(applicationContext, total)
            binding.btnClean.text = getString(R.string.clean) + "(" + String.format(
                Locale.ENGLISH,
                "%.2f",
                size.first.toFloat()
            ) + size.second + ")"

        } else if (type.equals("empty", true)) {
            if (isSelectAll) {
                binding.imageViewEmptySelect.setImageResource(R.drawable.ic_check)
                emptySelectedAll = true
            } else {
                emptySelectedAll = false
                binding.imageViewEmptySelect.setImageResource(R.drawable.ic_uncheck)
            }
            total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal

            val size = com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(applicationContext, total)
            binding.btnClean.text = getString(R.string.clean) + "(" + String.format(
                Locale.ENGLISH,
                "%.2f",
                size.first.toFloat()
            ) + size.second + ")"

        } else {
            if (isSelectAll) {
                binding.imageViewUninstalledSelect.setImageResource(R.drawable.ic_check)
                uninstalledSelectedAll = true
            } else {
                uninstalledSelectedAll = false
                binding.imageViewUninstalledSelect.setImageResource(R.drawable.ic_uncheck)
            }
            total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal

            val size = com.cleanmaster.trashcleaner.junkeraser.utils.Util.getDataSizeWithPrefix(
                applicationContext,
                apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal
            )
            binding.btnClean.text = getString(R.string.clean) + "(" + String.format(
                Locale.ENGLISH,
                "%.2f",
                size.first.toFloat()
            ) + size.second + ")"
        }
    }

    @SuppressLint("SetTextI18n")
    private fun scanningFinish(total: Pair<String, String>) {
        scanning = false
        val calendar = Calendar.getInstance()
        calendar.add(Calendar.MINUTE, 2)

        val cal = Calendar.getInstance()
        cal.time = Date()
        cal.add(Calendar.DAY_OF_MONTH, 1);
        editor?.putLong("date_and_time", cal.timeInMillis);
        editor?.putString("size", "" + total.first + " " + total.second);
        editor?.apply()

        /*Handler(Looper.myLooper()!!).postDelayed({
            Handler(Looper.myLooper()!!).postDelayed({
                startActivity(Intent(this@JunkActivity, CleanCompleteActivity::class.java))
                finish()
            }, 3000)
        }, 3000)*/

        Handler().postDelayed({
//            binding.imgLottie.setImageResource(R.drawable.ic_done_lottie)
            binding.frameDone.visibility = View.VISIBLE
            binding.frameCleaning.visibility = View.GONE
            binding.tvSize1.visibility = View.VISIBLE
            binding.scanningFile.text = resources.getString(R.string.clean_complete)
            binding.tvSize1.text = total.first + " " + total.second
            binding.btnClean.text = resources.getString(R.string.clean)
            val cal = Calendar.getInstance()
            cal.time = Date()
            cal.add(Calendar.DAY_OF_MONTH, 1)
            editor!!.putLong("date_and_time", cal.timeInMillis)
            editor!!.putString("size", "" + total.first + " " + total.second)
            editor!!.apply()
            Handler().postDelayed({
                startActivity(
                    Intent(this@JunkActivity, com.cleanmaster.trashcleaner.junkeraser.activity.CleanCompleteActivity::class.java).putExtra(
                        "total_clean_size",
                        total.first + " " + total.second
                    )
                )
                finish()
            }, 2000)
        }, 2000)

    }


    private fun loadBanner() {
        val banner_layout = findViewById<FrameLayout>(R.id.frame_banner)
        NativeLoadWithShows(this).showNativeAdsShimmerEffects(this, banner_layout, 1)
        NativeLoadWithShows(this).showNativeBottomAlways(this, banner_layout)
//        AdUtils().loadMediumBanner(this, banner_layout)
    }
}