package com.cleanmaster.trashcleaner.junkeraser.activity;

import static android.content.ContentValues.TAG;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.InsetDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.NotificationManagerCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.ads.module.adutills.AdUtils;
import com.ads.module.adutills.ClickCallback;
import com.ads.module.adutills.RewardedAdClass;
import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.Utils;
import com.cleanmaster.trashcleaner.junkeraser.adapter.History_List_Adapter2;
import com.cleanmaster.trashcleaner.junkeraser.database.ApplicationDatabase;
import com.cleanmaster.trashcleaner.junkeraser.database.ApplicationModel;
import com.cleanmaster.trashcleaner.junkeraser.database.BlockListModel;
import com.cleanmaster.trashcleaner.junkeraser.helper.LocaleHelper;
import com.cleanmaster.trashcleaner.junkeraser.model.Apps;
import com.cleanmaster.trashcleaner.junkeraser.utils.ApkInfoExtractor;
import com.google.android.material.card.MaterialCardView;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executors;

public class CleanNotification extends BaseActivity {

    ImageView btn_back, btn_setting;
    MaterialCardView btn_clean;
    RecyclerView history_recycler;
    RelativeLayout progressbar;
    String tracker;
    List<Apps> stringList = new ArrayList<>();
    ApplicationDatabase applicationDatabase;
    SwipeRefreshLayout swipeRefreshLayout;
    History_List_Adapter2 mAdapter;
    ArrayList<ApplicationModel> applicationModelList = new ArrayList<>();
    private ImageView app_lottie;
    private ConstraintLayout progressbarLoading;
    boolean is_cleanble = false;
    private TextView scanning_File;
    private androidx.appcompat.app.AlertDialog alertDialog;
    private static final int REQUEST_CODE_NOTIFICATION_ACCESS = 1;
    RewardedAdClass rewardedAdClass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clean_notification);

        //init
        btn_back = findViewById(R.id.btn_back);
        btn_setting = findViewById(R.id.btn_setting);
        history_recycler = findViewById(R.id.history_recycler);
        btn_clean = findViewById(R.id.btn_clean);
        progressbar = findViewById(R.id.progressbar);
        progressbarLoading = findViewById(R.id.progressbarLoading);
        swipeRefreshLayout = findViewById(R.id.swiperefresh);
        app_lottie = findViewById(R.id.app_lottie);
        scanning_File = findViewById(R.id.scanning_File);
        //db

        //applicationDatabase = Room.databaseBuilder(this, ApplicationDatabase.class, "application_db").allowMainThreadQueries().build();
        applicationDatabase = Utils.getApplicationDatabase(this);
        //permission
        Notification_permission_check();

        update();
        swipeRefreshLayout.setOnRefreshListener(() -> {
            update();
            history_recycler.setLayoutManager(new LinearLayoutManager(CleanNotification.this));
            mAdapter = new History_List_Adapter2(CleanNotification.this, applicationModelList);
            history_recycler.setAdapter(mAdapter);
            history_recycler.setNestedScrollingEnabled(false);
            swipeRefreshLayout.setRefreshing(false);
        });

        btn_back.setOnClickListener(v -> onBackPressed());
        btn_setting.setOnClickListener(v -> {
            startActivity(new Intent(CleanNotification.this, BlockAppSelectActivity.class).putExtra("new", "old_user"));
//            show_INTERSTIAL(CleanNotification.this, new Intent(CleanNotification.this, BlockAppSelectActivity.class).putExtra("new", "old_user"));
        });

        btn_clean.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               /* if (isNetworkConnected(CleanNotification.this) && mFirebaseRemoteConfig != null && mFirebaseRemoteConfig.getBoolean("ads_clean_rewards")) {
                    showRewardAdsDialog(v);
                } else if (!isNetworkConnected(CleanNotification.this)) {
                    cleanTrash();
                } else if (mFirebaseRemoteConfig != null && !mFirebaseRemoteConfig.getBoolean("ads_clean_rewards")) {
                    cleanTrash();
                }*/

                rewardedAdClass.displayRewardAds(new ClickCallback() {
                    @Override
                    public void clickNext() {
                        cleanTrash();
                    }
                });

            }
        });

        /*if (mFirebaseRemoteConfig != null && mFirebaseRemoteConfig.getBoolean("native_appcleaner")) {
            aperoNativeAdView = findViewById(R.id.aperoNativeAds);
            aperoNativeAdView.setVisibility(View.VISIBLE);
            loadNativeAdsFirstLanguageOpen();
        }*/


        rewardedAdClass = new RewardedAdClass(this);
        rewardedAdClass.loadRewardedAd();

        if (!isNotificationServiceEnabled()) {
            Intent intent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
            startActivityForResult(intent, REQUEST_CODE_NOTIFICATION_ACCESS);
        }
    }


    private boolean isNotificationServiceEnabled() {
        String notificationListenerString = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return notificationListenerString != null && notificationListenerString.contains(getPackageName());
    }

    private void update() {

        Executors.newSingleThreadExecutor().execute(() -> {
            runOnUiThread(() -> {
                progressbarLoading.setVisibility(View.VISIBLE);
                btn_clean.setVisibility(View.GONE);
            });

            get_FinalAppList();

            for (int i = 0; i < applicationDatabase.applicationDao().getAllappList().size(); i++) {
                if (applicationDatabase.applicationDao().getAllappList().get(i).getNotification_count() == 0) {
                    is_cleanble = false;
                } else {
                    is_cleanble = true;

                    break;
                }
            }

            runOnUiThread(() -> {

                progressbarLoading.setVisibility(View.GONE);
                if (is_cleanble) {
                    FrameLayout banner_layout = findViewById(R.id.frame_banner);
                    new AdUtils().loadMediumBanner(this,banner_layout);
                    btn_clean.setVisibility(View.VISIBLE);
                } else {
                    btn_clean.setVisibility(View.GONE);
                }
                history_recycler.setLayoutManager(new LinearLayoutManager(CleanNotification.this));
                mAdapter = new History_List_Adapter2(CleanNotification.this, applicationModelList);
                history_recycler.setAdapter(mAdapter);

                history_recycler.setNestedScrollingEnabled(false);

            });

        });

    }

    public void Notification_permission_check() {
        if (isNotificationAccessGiven()) {
        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Enable Notification Access")
                    .setMessage("Enable it otherwise Notification Blocker Will not Work")
                    .setPositiveButton("Settings", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
                        }
                    })
                    .setCancelable(false).show();
        }

    }

    private boolean isNotificationAccessGiven() {
        try {
            boolean enabled = false;
            Set<String> enabledListenerPackagesSet = NotificationManagerCompat.getEnabledListenerPackages(getApplicationContext());
            for (String string : enabledListenerPackagesSet)
                if (string.contains(getPackageName())) enabled = true;
            return enabled;
        } catch (Exception e) {
        }
        return false;
    }

    private void get_FinalAppList() {
        if (applicationDatabase.applicationDao().getAllappListSortDesc().size() == 0) {
            stringList.addAll(new ApkInfoExtractor(this).GetAllInstalledApkInfo());

            for (int i = 0; i < stringList.size(); i++) {
                ApplicationModel applicationModel = new ApplicationModel(stringList.get(i).getApp_package(), stringList.get(i).getApp_name(), 0, false);
                applicationDatabase.applicationDao().application_insert(applicationModel);
                applicationModelList.add(applicationModel);

            }
            if (applicationDatabase.blockListDao() != null || applicationDatabase.blockListDao().getAllBlockList().size() == 0) {
                applicationDatabase.blockListDao().block_insert(new BlockListModel("BLOCK_ALL", "no"));
            } else {
                applicationDatabase.blockListDao().updateUsingID("no");
            }
        } else {
            if (applicationModelList.size() == 0) {
                for (int i = 0; i < applicationDatabase.applicationDao().getAllappListSortDesc().size(); i++) {
                    applicationModelList.add(applicationDatabase.applicationDao().getAllappListSortDesc().get(i));
                }
            } else {
                applicationModelList.clear();
                for (int i = 0; i < applicationDatabase.applicationDao().getAllappListSortDesc().size(); i++) {
                    applicationModelList.add(applicationDatabase.applicationDao().getAllappListSortDesc().get(i));
                }
            }
        }
    }

/*    @Override
    public void onBackPressed() {
        if (new SessionHelper(this).getStringData(SessionHelper.START_APP_ID).equals("1111")) {
            show_INTERSTIAL(this, new Intent(this, MobileSecurity.class));
        }
        super.onBackPressed();
    }*/

/*    @Override
    protected void onResume() {
        update();
        history_recycler.setLayoutManager(new LinearLayoutManager(CleanNotification.this));
        mAdapter = new History_List_Adapter2(CleanNotification.this,applicationModelList);
        history_recycler.setAdapter(mAdapter);
        history_recycler.setNestedScrollingEnabled(false);
        swipeRefreshLayout.setRefreshing(false);
        super.onResume();
    }*/


    @Override
    protected void onStart() {
//        update();
        history_recycler.setLayoutManager(new LinearLayoutManager(CleanNotification.this));
        mAdapter = new History_List_Adapter2(CleanNotification.this, applicationModelList);
        history_recycler.setAdapter(mAdapter);
        history_recycler.setNestedScrollingEnabled(false);
        swipeRefreshLayout.setRefreshing(false);
        super.onStart();
    }

    @Override
    protected void onResume() {

        SharedPreferences sharedPrefs = getSharedPreferences("language", MODE_PRIVATE);
        String s1 = sharedPrefs.getString("selectedlanguage", "");
        LocaleHelper.setLocale(this, s1);
        new Utils().disebledOpenAdsBasedOnFireBase();
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleHelper.onAttach(base, "en"));
    }

    public void showSuccessDialog() {
        final View dialogView = getLayoutInflater().inflate(R.layout.dialog_clear_success, null);
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);

        TextView buttonOk = dialogView.findViewById(R.id.buttonOk);

        buttonOk.setOnClickListener(view12 -> {
            alertDialog.dismiss();
        });

        builder.setView(dialogView);
        alertDialog = builder.create();
        alertDialog.setCancelable(false);
        InsetDrawable inset = new InsetDrawable(new ColorDrawable(Color.TRANSPARENT), 40);
        alertDialog.getWindow().setBackgroundDrawable(inset);
        alertDialog.show();
    }

    private void cleanTrash() {

        Executors.newSingleThreadExecutor().execute(() -> {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    btn_clean.setVisibility(View.GONE);
                    progressbar.setVisibility(View.VISIBLE);
                }
            });

            for (int i = 0; i < applicationDatabase.applicationDao().getAllappList().size(); i++) {
                if (applicationDatabase.applicationDao().getAllappList().get(i).getNotification_count() == 0) {
                    is_cleanble = false;
                } else {
                    is_cleanble = true;

                    break;
                }
            }
            if (is_cleanble) {
                for (int i = 0; i < applicationDatabase.applicationDao().getAllappList().size(); i++) {
                    Log.d(TAG, "onClick: " + applicationDatabase.applicationDao().getAllappList().get(i).getId());
                    applicationDatabase.applicationDao().application_update_count(applicationDatabase.applicationDao().getAllappList().get(i).getId());
                    if (i == applicationDatabase.applicationDao().getAllappList().size() - 1) {
//                                startActivity(new Intent(CleanNotification.this, CleanResultActivity.class).putExtra("tracker", "notification_clear"));
//                        show_INTERSTIAL(CleanNotification.this, new Intent(this, CleanResultActivity.class).putExtra("tracker", "notification_clear"));
                    }
                }
            }

            runOnUiThread(new Runnable() {
                @Override
                public void run() {

                    if (!is_cleanble) {
                        Toast.makeText(CleanNotification.this, "All Notification Already Cleaned", Toast.LENGTH_SHORT).show();
                    }
                    scanning_File.setText(R.string.clean_complete);
                    app_lottie.setImageResource(R.drawable.ic_success);
//                    app_lottie.setAnimation(R.raw.success2);
//
//                    app_lottie.loop(true);
//                    app_lottie.playAnimation();
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            progressbar.setVisibility(View.GONE);
                            showSuccessDialog();

                        }
                    }, 3000);

                    update();
                    history_recycler.setLayoutManager(new LinearLayoutManager(CleanNotification.this));
                    mAdapter = new History_List_Adapter2(CleanNotification.this, applicationModelList);
                    history_recycler.setAdapter(mAdapter);
                    history_recycler.setNestedScrollingEnabled(false);
                }
            });
        });
    }
}