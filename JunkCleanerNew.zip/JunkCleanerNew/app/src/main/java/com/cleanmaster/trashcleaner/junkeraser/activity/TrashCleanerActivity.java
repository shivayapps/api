package com.cleanmaster.trashcleaner.junkeraser.activity;

import static android.content.ContentValues.TAG;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.InsetDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.TranslateAnimation;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ads.module.adutills.AdUtils;
import com.ads.module.adutills.ClickCallback;
import com.ads.module.adutills.RewardedAdClass;
import com.airbnb.lottie.LottieAnimationView;
import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.Utils;
import com.cleanmaster.trashcleaner.junkeraser.adapter.DownloadCacheRecycleAdapter;
import com.cleanmaster.trashcleaner.junkeraser.adapter.emptyfolderRecycleAdapter;
import com.cleanmaster.trashcleaner.junkeraser.helper.LocaleHelper;
import com.cleanmaster.trashcleaner.junkeraser.model.doumentContent;
import com.cleanmaster.trashcleaner.junkeraser.utils.StorageInformation;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Executors;

public class TrashCleanerActivity extends BaseActivity {
    File storageDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS); // Get the root storage directory
    File storageDirectorythumb = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES); // Get the root storage directory
    File storageDirectorytemp = new File(Environment.getExternalStorageDirectory() + "/");
    //    File storageDirectorytemp = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
    ArrayList<File> fileList = new ArrayList<>();
    private final ArrayList<doumentContent> selectedImageList = new ArrayList<>();
    private final ArrayList<doumentContent> selectedAPKList = new ArrayList<>();
    private final ArrayList<doumentContent> selectedLargeFilesList = new ArrayList<>();
    private final ArrayList<doumentContent> selectedEmptyFolderList = new ArrayList<>();
    //    private final ArrayList<doumentContent> selectedallTempTrashedThumList = new ArrayList<>();
    public static ArrayList<doumentContent> allDownloads = new ArrayList<>();
    //    public static ArrayList<doumentContent> allTempTrashedThumList = new ArrayList<>();
//    public static ArrayList<doumentContent> smallArrayList = new ArrayList<>();
    private RelativeLayout rlApkJunk, rlLargeFiles, rlDownloaded, rlEmptyFolder;
    private RecyclerView rvEmptyFolder, rvLargeFiles, rvDownloads, rvApkJunk;
    private ImageView ivApkJunk, ivLargeFiles, ivDownloded, ivEmptyFolder;
    private ImageView imgApkJunk, imgLargeFiles, imgDownloaded, imgEmptyFolder;
    boolean isCacheJunkSelected = false;
    private AlertDialog alertDialog;
    private StorageInformation storageInformation;
    private TextView tvApkJunkSize, tvDownloadSize, tvEmptyFolderSize;
    private String downloadsize, apksize, largesize, emptysize;
    private long sum, apksumcount, largesumcount, emptysumcount;
    private TextView btnCleanStorage;
    private boolean isSelectImage = false;
    private boolean isTempSelectImage = false;
    private boolean isEmptyFolderSelectImage = false;
    private DownloadCacheRecycleAdapter downloadCacheRecycleAdapter;
    private DownloadCacheRecycleAdapter largeFilesRecycleAdapter;
    private emptyfolderRecycleAdapter emptyFolderRecyclerviewAdapter;
    private DownloadCacheRecycleAdapter apkjunkRecyclerviewAdapter;
    RelativeLayout progressbar;
    private TextView tvLargeFileSize, tvTotalClean;
    private ProgressBar progressDownload, progressLargeFiles, progressApkJunk, progressEmptyFolder;
    private long totalBtnSize;
    public ArrayList<doumentContent> apkfileslist = new ArrayList<>();
    public ArrayList<doumentContent> emptyFoldersList = new ArrayList<>();
    ArrayList<doumentContent> largeFiles = new ArrayList<>();
    private ImageView app_lottie;
    private TextView scanning_File;
    private ConstraintLayout constraint;
    LottieAnimationView lottieView;
    RewardedAdClass rewardedAdClass;
    private Dialog dialog;
    @SuppressWarnings("InvalidSetHasFixedSize")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trash_cleaner);

        ImageView imgBack = findViewById(R.id.btn_back);
        imgBack.setOnClickListener(v -> onBackPressed());
        lottieView = findViewById(R.id.lottie_view);

        rlApkJunk = findViewById(R.id.rlApkJunk);
        rlLargeFiles = findViewById(R.id.rlLargeFiles);
        rlDownloaded = findViewById(R.id.rlDownloaded);
        rlEmptyFolder = findViewById(R.id.rlEmptyFolder);
        progressbar = findViewById(R.id.progressbar);
        constraint = findViewById(R.id.constraint);
        progressDownload = findViewById(R.id.progressDownload);
        progressLargeFiles = findViewById(R.id.progressLargeFiles);
        progressApkJunk = findViewById(R.id.progressApkJunk);
        progressEmptyFolder = findViewById(R.id.progressEmptyFolder);

        btnCleanStorage = findViewById(R.id.btnCleanStorage);
        SharedPreferences sharedPref = getSharedPreferences("SettingScreen", MODE_PRIVATE);

        String themess = sharedPref.getString("theme", "light");
        switch (themess) {
            case "light":
                lottieView.setAnimation(R.raw.junk_light);
                lottieView.playAnimation();
                break;
            case "dark":
                lottieView.setAnimation(R.raw.junk_dark);
                lottieView.playAnimation();
                break;
        }
        rvEmptyFolder = findViewById(R.id.rvEmptyFolder);
        rvLargeFiles = findViewById(R.id.rvLargeFiles);
        rvDownloads = findViewById(R.id.rvDownloads);
        rvApkJunk = findViewById(R.id.rvApkJunk);

        tvApkJunkSize = findViewById(R.id.tvApkJunkSize);
        tvEmptyFolderSize = findViewById(R.id.tvEmptyFolderSize);
        tvDownloadSize = findViewById(R.id.tvDownloadSize);
        tvLargeFileSize = findViewById(R.id.tvLargeFilesSize);
        tvTotalClean = findViewById(R.id.tvTotalClean);

        ivApkJunk = findViewById(R.id.ivApkJunk);
        ivLargeFiles = findViewById(R.id.ivLargeFiles);
        ivDownloded = findViewById(R.id.ivDownloded);
        ivEmptyFolder = findViewById(R.id.ivEmptyFolder);

        imgApkJunk = findViewById(R.id.imgApkJunk);
        imgLargeFiles = findViewById(R.id.imgLargeFiles);
        imgDownloaded = findViewById(R.id.imgDownloaded);
        imgEmptyFolder = findViewById(R.id.imgEmptyFolder);
        app_lottie = findViewById(R.id.app_lottie);
        scanning_File = findViewById(R.id.scanning_File);

        rvEmptyFolder.setLayoutManager(new LinearLayoutManager(TrashCleanerActivity.this));
        rvLargeFiles.setLayoutManager(new LinearLayoutManager(TrashCleanerActivity.this));
        rvDownloads.setLayoutManager(new LinearLayoutManager(TrashCleanerActivity.this));
        rvApkJunk.setLayoutManager(new LinearLayoutManager(TrashCleanerActivity.this));

        //Apk Files
        Executors.newSingleThreadExecutor().execute(() -> {
            runOnUiThread(() -> {
                btnCleanStorage.setVisibility(View.GONE);
                progressApkJunk.setVisibility(View.VISIBLE);
                imgApkJunk.setVisibility(View.GONE);
            });

            apkfileslist.addAll(getApkFiles(storageDirectorytemp));
            apksize = convertFileSize(storageTotalApk());
            runOnUiThread(() -> {
                progressApkJunk.setVisibility(View.GONE);
                imgApkJunk.setVisibility(View.VISIBLE);

                apkjunkRecyclerviewAdapter = new DownloadCacheRecycleAdapter(TrashCleanerActivity.this, apkfileslist, new DownloadCacheRecycleAdapter.pictureActionListrener() {

                    @Override
                    public void onPictureItemClicked(int position, ArrayList<doumentContent> arrayListimage) {
                        apkfileslist = arrayListimage;
                        selectedAPKList.clear();
                        apksumcount = 0;
                        for (int i = 0; i < arrayListimage.size(); i++) {
                            if (arrayListimage.get(i).isSelected()) {
                                selectedAPKList.add(arrayListimage.get(i));
                                apksumcount = apksumcount + arrayListimage.get(i).getDocumentSize();
                            }
                        }

                        totalBtnSize = sum + apksumcount + largesumcount + emptysumcount;
                        btnCleanStorage.setText(getResources().getString(R.string.clean) + "(" + convertFileSize(totalBtnSize) + ")");


                        if(arrayListimage.size()!= selectedAPKList.size()){
                            imgApkJunk.setImageResource(R.drawable.ic_uncheck_square);
                        }else {
                            imgApkJunk.setImageResource(R.drawable.ic_check_square);
                        }

                        if (totalBtnSize > 0) {
                            if (btnCleanStorage.getVisibility() != View.VISIBLE) {
                                btnCleanStorage.setVisibility(View.VISIBLE);
                                AnimUp();
                            }
                        } else {
                            btnCleanStorage.setVisibility(View.GONE);
                            AnimDown();
                        }

                        isSelectImage = selectedAPKList.size() == apkfileslist.size();
                    }

                    @Override
                    public void onPictureItemLongClicked(int position) {

                    }
                });
                tvApkJunkSize.setText(apksize);
                rvApkJunk.setAdapter(apkjunkRecyclerviewAdapter);
            });
        });

        //Downloaded Files
        Executors.newSingleThreadExecutor().execute(() -> {
            runOnUiThread(() -> {
                imgDownloaded.setVisibility(View.GONE);
                progressDownload.setVisibility(View.VISIBLE);
            });

            getDownloadFile();
            downloadsize = convertFileSize(storageTotalDownload());

            runOnUiThread(() -> {
                imgDownloaded.setVisibility(View.VISIBLE);
                progressDownload.setVisibility(View.GONE);

                downloadCacheRecycleAdapter = new DownloadCacheRecycleAdapter(TrashCleanerActivity.this, allDownloads, new DownloadCacheRecycleAdapter.pictureActionListrener() {
                    @Override
                    public void onPictureItemClicked(int position, ArrayList<doumentContent> arrayListimage) {
                        allDownloads = arrayListimage;
                        selectedImageList.clear();
                        sum = 0;
                        for (int i = 0; i < arrayListimage.size(); i++) {
                            if (arrayListimage.get(i).isSelected()) {
                                selectedImageList.add(arrayListimage.get(i));
                                sum = sum + arrayListimage.get(i).getDocumentSize();
                            }
                        }

                        totalBtnSize = sum + apksumcount + largesumcount + emptysumcount;
                        btnCleanStorage.setText(getResources().getString(R.string.clean) + "(" + convertFileSize(totalBtnSize) + ")");

                        if(arrayListimage.size()!= selectedImageList.size()){
                            imgDownloaded.setImageResource(R.drawable.ic_uncheck_square);
                        }else {
                            imgDownloaded.setImageResource(R.drawable.ic_check_square);
                        }


                        if (totalBtnSize > 0) {
                            if (btnCleanStorage.getVisibility() != View.VISIBLE) {
                                btnCleanStorage.setVisibility(View.VISIBLE);
                                AnimUp();
                            }
                        } else {
                            btnCleanStorage.setVisibility(View.GONE);
                            AnimDown();
                        }

                        isSelectImage = selectedImageList.size() == allDownloads.size();

                    }

                    @Override
                    public void onPictureItemLongClicked(int position) {

                    }
                });

                tvDownloadSize.setText(downloadsize);
                rvDownloads.setAdapter(downloadCacheRecycleAdapter);
            });
        });

        //Large Files
        Executors.newSingleThreadExecutor().execute(() -> {
            runOnUiThread(() -> {
                imgLargeFiles.setVisibility(View.GONE);
                progressLargeFiles.setVisibility(View.VISIBLE);
            });

            largeFiles = getLargeFiles(storageDirectorytemp, 10 * 1024 * 1024);
            largesize = convertFileSize(storageTotalLargeFile());

            runOnUiThread(() -> {
                imgLargeFiles.setVisibility(View.VISIBLE);
                progressLargeFiles.setVisibility(View.GONE);

                largeFilesRecycleAdapter = new DownloadCacheRecycleAdapter(TrashCleanerActivity.this, largeFiles, new DownloadCacheRecycleAdapter.pictureActionListrener() {
                    @Override
                    public void onPictureItemClicked(int position, ArrayList<doumentContent> arrayListimage) {
                        largeFiles = arrayListimage;
                        selectedLargeFilesList.clear();
                        largesumcount = 0;
                        for (int i = 0; i < arrayListimage.size(); i++) {
                            if (arrayListimage.get(i).isSelected()) {
                                selectedLargeFilesList.add(arrayListimage.get(i));
                                largesumcount = largesumcount + arrayListimage.get(i).getDocumentSize();
                            }
                        }

                        totalBtnSize = sum + apksumcount + largesumcount + emptysumcount;
                        btnCleanStorage.setText(getResources().getString(R.string.clean) + "(" + convertFileSize(totalBtnSize) + ")");



                        if(arrayListimage.size()!= selectedLargeFilesList.size()){
                            imgLargeFiles.setImageResource(R.drawable.ic_uncheck_square);
                        }else {
                            imgLargeFiles.setImageResource(R.drawable.ic_check_square);
                        }

                        if (totalBtnSize > 0) {
                            if (btnCleanStorage.getVisibility() != View.VISIBLE) {
                                btnCleanStorage.setVisibility(View.VISIBLE);
                                AnimUp();
                            }
                        } else {
                            btnCleanStorage.setVisibility(View.GONE);
                            AnimDown();
                        }
                    }

                    @Override
                    public void onPictureItemLongClicked(int position) {

                    }
                });

                rvLargeFiles.setAdapter(largeFilesRecycleAdapter);
                tvLargeFileSize.setText(largesize);
            });
        });

        //Empty Folder
        Executors.newSingleThreadExecutor().execute(() -> {
            runOnUiThread(() -> {
                imgEmptyFolder.setVisibility(View.GONE);
                progressEmptyFolder.setVisibility(View.VISIBLE);
            });

            getEmptyFolders(storageDirectorytemp);
            emptysize = convertFileSize(storageTotalEmptyFolder());

            runOnUiThread(() -> {

                imgEmptyFolder.setVisibility(View.VISIBLE);
                progressEmptyFolder.setVisibility(View.GONE);
                emptyFolderRecyclerviewAdapter = new emptyfolderRecycleAdapter(TrashCleanerActivity.this, emptyFoldersList, new emptyfolderRecycleAdapter.pictureActionListrener() {
                    @Override
                    public void onPictureItemClicked(int position, ArrayList<doumentContent> arrayListimage) {
                        emptyFoldersList = arrayListimage;
                        selectedEmptyFolderList.clear();
                        emptysumcount = 0;
                        for (int i = 0; i < arrayListimage.size(); i++) {
                            if (arrayListimage.get(i).isSelected()) {
                                selectedEmptyFolderList.add(arrayListimage.get(i));
                                emptysumcount = emptysumcount + arrayListimage.get(i).getDocumentSize();
                            }
                        }

                        totalBtnSize = sum + apksumcount + largesumcount + emptysumcount;
                        btnCleanStorage.setText(getResources().getString(R.string.clean) + "(" + convertFileSize(totalBtnSize) + ")");

                        if(arrayListimage.size()!= selectedEmptyFolderList.size()){
                            imgEmptyFolder.setImageResource(R.drawable.ic_uncheck_square);
                        }else {
                            imgEmptyFolder.setImageResource(R.drawable.ic_check_square);
                        }

                        if (totalBtnSize > 0) {
                            if (btnCleanStorage.getVisibility() != View.VISIBLE) {
                                btnCleanStorage.setVisibility(View.VISIBLE);
                                AnimUp();
                            }
                        } else {
                            btnCleanStorage.setVisibility(View.GONE);
                            AnimDown();
                        }
                    }

                });

                tvEmptyFolderSize.setText(emptysize);
                rvEmptyFolder.setAdapter(emptyFolderRecyclerviewAdapter);
                tvTotalClean.setText(convertFileSize(storageTotalDownload() + storageTotalApk() + storageTotalLargeFile() + storageTotalEmptyFolder()));
            });
        });

        rlApkJunk.setOnClickListener(v -> {
            if (rvApkJunk.getVisibility() == View.VISIBLE) {
                rvApkJunk.setVisibility(View.GONE);
                ivApkJunk.setImageResource(R.drawable.ic_dropdown);
            } else {
                rvApkJunk.setVisibility(View.VISIBLE);
                ivApkJunk.setImageResource(R.drawable.ic_up_arrow);
            }
        });

        rlEmptyFolder.setOnClickListener(v -> {
            if (rvEmptyFolder.getVisibility() == View.VISIBLE) {
                rvEmptyFolder.setVisibility(View.GONE);
                ivEmptyFolder.setImageResource(R.drawable.ic_dropdown);
            } else {
                rvEmptyFolder.setVisibility(View.VISIBLE);
                ivEmptyFolder.setImageResource(R.drawable.ic_up_arrow);
            }
        });

        rlLargeFiles.setOnClickListener(v -> {
            if (rvLargeFiles.getVisibility() == View.VISIBLE) {
                rvLargeFiles.setVisibility(View.GONE);
                ivLargeFiles.setImageResource(R.drawable.ic_dropdown);
            } else {
                rvLargeFiles.setVisibility(View.VISIBLE);
                ivLargeFiles.setImageResource(R.drawable.ic_up_arrow);
            }
        });

        rlDownloaded.setOnClickListener(v -> {
            if (rvDownloads.getVisibility() == View.VISIBLE) {
                rvDownloads.setVisibility(View.GONE);
                ivDownloded.setImageResource(R.drawable.ic_dropdown);
            } else {
                rvDownloads.setVisibility(View.VISIBLE);
                ivDownloded.setImageResource(R.drawable.ic_up_arrow);
            }
        });

        imgApkJunk.setOnClickListener(v -> {
//            showClearCacheDialog(v);
            if (!isCacheJunkSelected) {
                setAllApkFileSelect();
                imgApkJunk.setImageResource(R.drawable.ic_check_square);
                isCacheJunkSelected = true;
                if (totalBtnSize > 0) {
                    if (btnCleanStorage.getVisibility() != View.VISIBLE) {
                        btnCleanStorage.setVisibility(View.VISIBLE);
                        AnimUp();
                    }
                } else {
//                    AnimUp();
                    btnCleanStorage.setVisibility(View.GONE);
                }
            } else {
                setAllApkFileUnSelect();
                imgApkJunk.setImageResource(R.drawable.ic_uncheck_square);
                isCacheJunkSelected = false;

                if (totalBtnSize <= 0) {
                    btnCleanStorage.setVisibility(View.GONE);
                    AnimDown();
                }
            }
        });

        imgDownloaded.setOnClickListener(v -> {

            if (!isSelectImage) {
                setAllDownloadSelect();
                imgDownloaded.setImageResource(R.drawable.ic_check_square);
                isSelectImage = true;

                if (totalBtnSize > 0) {
                    if (btnCleanStorage.getVisibility() != View.VISIBLE) {
                        btnCleanStorage.setVisibility(View.VISIBLE);
                        AnimUp();
                    }
                } else {
//                    AnimUp();
                    btnCleanStorage.setVisibility(View.GONE);
                }

            } else {
                setAllDownloadUnSelect();
                imgDownloaded.setImageResource(R.drawable.ic_uncheck_square);
                isSelectImage = false;

                if (totalBtnSize <= 0) {
                    btnCleanStorage.setVisibility(View.GONE);
                    AnimDown();
                }
            }
        });

        imgLargeFiles.setOnClickListener(v -> {
            if (!isTempSelectImage) {
                setAllLargeFileSelect();
                imgLargeFiles.setImageResource(R.drawable.ic_check_square);
                isTempSelectImage = true;

                if (totalBtnSize > 0) {
                    if (btnCleanStorage.getVisibility() != View.VISIBLE) {
                        btnCleanStorage.setVisibility(View.VISIBLE);
                        AnimUp();
                    }
                } else {
//                    AnimUp();
                    btnCleanStorage.setVisibility(View.GONE);
                }

            } else {
                setAllLargeFileUnSelect();
                imgLargeFiles.setImageResource(R.drawable.ic_uncheck_square);
                isTempSelectImage = false;

                if (totalBtnSize <= 0) {
                    btnCleanStorage.setVisibility(View.GONE);
                    AnimDown();
                }

            }
        });

        imgEmptyFolder.setOnClickListener(v -> {

            if (!isEmptyFolderSelectImage) {
                setAllEmptyFolderSelect();
                imgEmptyFolder.setImageResource(R.drawable.ic_check_square);
                isEmptyFolderSelectImage = true;

                if (totalBtnSize > 0) {
                    if (btnCleanStorage.getVisibility() != View.VISIBLE) {
                        btnCleanStorage.setVisibility(View.VISIBLE);
                        AnimUp();
                    }
                } else {
//                    AnimUp();
                    btnCleanStorage.setVisibility(View.GONE);
                }
            } else {
                setAllEmptyFolderUnSelect();
                imgEmptyFolder.setImageResource(R.drawable.ic_uncheck_square);
                isEmptyFolderSelectImage = false;

                if (totalBtnSize <= 0) {
                    btnCleanStorage.setVisibility(View.GONE);
                    AnimDown();
                }
            }
        });

        btnCleanStorage.setOnClickListener(v -> {
            /*if (totalBtnSize > 2000 && isNetworkConnected(TrashCleanerActivity.this) && mFirebaseRemoteConfig != null && mFirebaseRemoteConfig.getBoolean("ads_clean_rewards")) {
                showRewardAdsDialog(v);
            } else if (totalBtnSize > 2000 && !isNetworkConnected(TrashCleanerActivity.this)) {
                cleanTrash();
            } else if (totalBtnSize > 2000 && mFirebaseRemoteConfig != null && !mFirebaseRemoteConfig.getBoolean("ads_clean_rewards")) {
                cleanTrash();
            } else {
                Toast.makeText(TrashCleanerActivity.this, "Phone already clean", Toast.LENGTH_SHORT).show();
            }*/
            if (totalBtnSize >= 0) {
//                showRewardAdsDialog(v);
                showClearDialog();
            }else {
                Toast.makeText(this, "Please select trash files", Toast.LENGTH_SHORT).show();
            }
        });

        loadBanner();

        rewardedAdClass = new RewardedAdClass(TrashCleanerActivity.this);
        rewardedAdClass.loadRewardedAd();

    }


    private void loadBanner() {
        FrameLayout banner_layout = findViewById(R.id.frame_banner);
        new AdUtils().loadMediumBanner(this,banner_layout);
    }
    private void showDeleteCacheDialog(View view, int pos) {
        ViewGroup viewGroup = view.findViewById(android.R.id.content);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_delete_cache, viewGroup, false);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        ImageView imgAppIcon = dialogView.findViewById(R.id.imgAppIcon);
        TextView tvAppname = dialogView.findViewById(R.id.tvAppname);
        TextView buttonCancel = dialogView.findViewById(R.id.buttonCancel);
        TextView buttonOk = dialogView.findViewById(R.id.buttonOk);
        TextView tvPackageName = dialogView.findViewById(R.id.tvPackageName);
        TextView tvCacheSize = dialogView.findViewById(R.id.tvCacheSize);

        tvAppname.setText(storageInformation.sizeNameArrayList.get(pos).getAppname());
        tvPackageName.setText(storageInformation.sizeNameArrayList.get(pos).getPname());
        tvCacheSize.setText(storageInformation.sizeNameArrayList.get(pos).getCacheSize());
        tvAppname.setText(storageInformation.sizeNameArrayList.get(pos).getAppname());
        imgAppIcon.setImageDrawable(storageInformation.sizeNameArrayList.get(pos).getIcon());

        buttonCancel.setOnClickListener(view1 -> alertDialog.dismiss());

        buttonOk.setOnClickListener(view12 -> {
//            new Myapplication().disabledOpenAds();
            Intent i = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.addCategory(Intent.CATEGORY_DEFAULT);
            i.setData(Uri.parse("package:" + storageInformation.sizeNameArrayList.get(pos).getPname()));
            startActivity(i);
            alertDialog.dismiss();
        });

        builder.setView(dialogView);
        alertDialog = builder.create();

        InsetDrawable inset = new InsetDrawable(new ColorDrawable(Color.TRANSPARENT), 40);
        alertDialog.getWindow().setBackgroundDrawable(inset);
        alertDialog.show();
    }

    private void showClearCacheDialog(View view) {
        ViewGroup viewGroup = view.findViewById(android.R.id.content);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_clear_cache, viewGroup, false);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        TextView buttonOk = dialogView.findViewById(R.id.buttonOk);

        buttonOk.setOnClickListener(view12 -> alertDialog.dismiss());

        builder.setView(dialogView);
        alertDialog = builder.create();

        InsetDrawable inset = new InsetDrawable(new ColorDrawable(Color.TRANSPARENT), 40);
        alertDialog.getWindow().setBackgroundDrawable(inset);
        alertDialog.show();
    }

    private void traverseDirectory(File directory) {
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    traverseDirectory(file);
                } else {
                    fileList.add(file);
                }
            }
        }
    }

    public void getDownloadFile() {
        allDownloads.clear();
        traverseDirectory(storageDirectory);

        Collections.sort(fileList, (file1, file2) -> {
            long size1 = file1.length();
            long size2 = file2.length();
            return Long.compare(size1, size2);
        });

        Collections.reverse(fileList);

        for (int i = 0; i < fileList.size(); i++) {
            doumentContent doumentContent = new doumentContent();
            doumentContent.setName(fileList.get(i).getName());
            doumentContent.setFilePath(fileList.get(i).getPath());
            doumentContent.setDocumentSize(fileList.get(i).length());
//            if(fileListdownload.get(i).length() > 53000000) {
            allDownloads.add(doumentContent);
//            }
        }
    }

    public long storageTotalDownload() {
        long downloadSum = 0;
        for (int i = 0; i < allDownloads.size(); i++) {
            downloadSum = downloadSum + allDownloads.get(i).getDocumentSize();
        }
        return downloadSum;
    }

    public long storageTotalEmptyFolder() {
        long emptySum = 0;
        for (int i = 0; i < emptyFoldersList.size(); i++) {
            emptySum = emptySum + emptyFoldersList.get(i).getDocumentSize();
        }
        return emptySum;
    }

    public long storageTotalApk() {
        long apkSum = 0;
        for (int i = 0; i < apkfileslist.size(); i++) {
            apkSum = apkSum + apkfileslist.get(i).getDocumentSize();
        }
        return apkSum;
    }

    public long storageTotalLargeFile() {
        long largeSum = 0;
        for (int i = 0; i < largeFiles.size(); i++) {
            largeSum = largeSum + largeFiles.get(i).getDocumentSize();
        }
        return largeSum;
    }

    public static String convertFileSize(long sizeInBytes) {
        String[] units = {"B", "KB", "MB", "GB"};
        double size = sizeInBytes;
        int index = 0;
        while (size > 1024 && index < units.length - 1) {
            size /= 1024;
            index++;
        }
        return String.format("%.2f %s", size, units[index]);
    }

    @SuppressLint("NotifyDataSetChanged")
    private void setAllDownloadSelect() {
        for (int i = 0; i < allDownloads.size(); i++) {
            if (!allDownloads.get(i).isSelected()) {
                allDownloads.get(i).setSelected(true);
            }
        }
        selectedImageList.clear();
        sum = 0;
        for (int i = 0; i < allDownloads.size(); i++) {
            if (allDownloads.get(i).isSelected()) {
                selectedImageList.add(allDownloads.get(i));
                sum = sum + allDownloads.get(i).getDocumentSize();
            }
        }
        totalBtnSize = sum + apksumcount + largesumcount + emptysumcount;
        btnCleanStorage.setText(getResources().getString(R.string.clean) + "(" + convertFileSize(totalBtnSize) + ")");
        downloadCacheRecycleAdapter.notifyDataSetChanged();
    }

    @SuppressLint("NotifyDataSetChanged")
    private void setAllDownloadUnSelect() {
        sum = 0;
        for (int i = 0; i < allDownloads.size(); i++) {
            if (allDownloads.get(i).isSelected()) {
                allDownloads.get(i).setSelected(false);
            }
        }
        selectedImageList.clear();

        totalBtnSize = sum + apksumcount + largesumcount + emptysumcount;
        btnCleanStorage.setText(getResources().getString(R.string.clean) + "(" + convertFileSize(totalBtnSize) + ")");
        downloadCacheRecycleAdapter.notifyDataSetChanged();
    }

    @SuppressLint("NotifyDataSetChanged")
    private void setAllApkFileSelect() {
        for (int i = 0; i < apkfileslist.size(); i++) {
            if (!apkfileslist.get(i).isSelected()) {
                apkfileslist.get(i).setSelected(true);
            }
        }
        selectedAPKList.clear();
        apksumcount = 0;
        for (int i = 0; i < apkfileslist.size(); i++) {
            if (apkfileslist.get(i).isSelected()) {
                selectedAPKList.add(apkfileslist.get(i));
                apksumcount = apksumcount + apkfileslist.get(i).getDocumentSize();
            }
        }

        totalBtnSize = sum + apksumcount + largesumcount + emptysumcount;
        btnCleanStorage.setText(getResources().getString(R.string.clean) + "(" + convertFileSize(totalBtnSize) + ")");

        apkjunkRecyclerviewAdapter.notifyDataSetChanged();
    }

    @SuppressLint("NotifyDataSetChanged")
    private void setAllApkFileUnSelect() {
        apksumcount = 0;
        for (int i = 0; i < apkfileslist.size(); i++) {
            if (apkfileslist.get(i).isSelected()) {
                apkfileslist.get(i).setSelected(false);
            }
        }
        selectedAPKList.clear();
        /*if (isSystemCacheSelected) {
            totalBtnSize = (long) (sum + tempSum + (randomSystemSize * 1000));
        } else {
            totalBtnSize = (sum + tempSum);
        }*/
        totalBtnSize = sum + apksumcount + largesumcount + emptysumcount;
        btnCleanStorage.setText(getResources().getString(R.string.clean) + "(" + convertFileSize(totalBtnSize) + ")");
        apkjunkRecyclerviewAdapter.notifyDataSetChanged();
    }


    @SuppressLint("NotifyDataSetChanged")
    private void setAllLargeFileSelect() {
        for (int i = 0; i < largeFiles.size(); i++) {
            if (!largeFiles.get(i).isSelected()) {
                largeFiles.get(i).setSelected(true);
            }
        }
        selectedLargeFilesList.clear();
        largesumcount = 0;
        for (int i = 0; i < largeFiles.size(); i++) {
            if (largeFiles.get(i).isSelected()) {
                selectedLargeFilesList.add(largeFiles.get(i));
                largesumcount = largesumcount + largeFiles.get(i).getDocumentSize();
            }
        }

        totalBtnSize = sum + apksumcount + largesumcount + emptysumcount;
        btnCleanStorage.setText(getResources().getString(R.string.clean) + "(" + convertFileSize(totalBtnSize) + ")");
        largeFilesRecycleAdapter.notifyDataSetChanged();
    }

    @SuppressLint("NotifyDataSetChanged")
    private void setAllLargeFileUnSelect() {
        largesumcount = 0;
        for (int i = 0; i < largeFiles.size(); i++) {
            if (largeFiles.get(i).isSelected()) {
                largeFiles.get(i).setSelected(false);
            }
        }
        selectedLargeFilesList.clear();

        /*if (isSystemCacheSelected) {
            totalBtnSize = (long) (sum + tempSum + (randomSystemSize * 1000));
        } else {
            totalBtnSize = (sum + tempSum);
        }*/
        totalBtnSize = sum + apksumcount + largesumcount + emptysumcount;
        btnCleanStorage.setText(getResources().getString(R.string.clean) + "(" + convertFileSize(totalBtnSize) + ")");
        largeFilesRecycleAdapter.notifyDataSetChanged();
    }

    @SuppressLint("NotifyDataSetChanged")
    private void setAllEmptyFolderSelect() {
        for (int i = 0; i < emptyFoldersList.size(); i++) {
            if (!emptyFoldersList.get(i).isSelected()) {
                emptyFoldersList.get(i).setSelected(true);
            }
        }
        selectedEmptyFolderList.clear();
        emptysumcount = 0;
        for (int i = 0; i < emptyFoldersList.size(); i++) {
            if (emptyFoldersList.get(i).isSelected()) {
                selectedEmptyFolderList.add(emptyFoldersList.get(i));
                emptysumcount = emptysumcount + emptyFoldersList.get(i).getDocumentSize();
            }
        }

        Log.d(TAG, "setAllEmptyFolderSelect: " + convertFileSize(emptysumcount));
        totalBtnSize = sum + apksumcount + largesumcount + emptysumcount;
        btnCleanStorage.setText(getResources().getString(R.string.clean) + "(" + convertFileSize(totalBtnSize) + ")");
        emptyFolderRecyclerviewAdapter.notifyDataSetChanged();
    }

    @SuppressLint("NotifyDataSetChanged")
    private void setAllEmptyFolderUnSelect() {
        emptysumcount = 0;
        for (int i = 0; i < emptyFoldersList.size(); i++) {
            if (emptyFoldersList.get(i).isSelected()) {
                emptyFoldersList.get(i).setSelected(false);
            }
        }
        selectedEmptyFolderList.clear();

        totalBtnSize = sum + apksumcount + largesumcount + emptysumcount;
        btnCleanStorage.setText(getResources().getString(R.string.clean) + "(" + convertFileSize(totalBtnSize) + ")");
        emptyFolderRecyclerviewAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onResume() {
        SharedPreferences sharedPrefs = getSharedPreferences("language", MODE_PRIVATE);
        String s1 = sharedPrefs.getString("selectedlanguage", "");
        LocaleHelper.setLocale(this, s1);

        new Utils().disebledOpenAdsBasedOnFireBase();
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleHelper.onAttach(base, "en"));
    }

    public void showClearDialog() {
        final View dialogView = getLayoutInflater().inflate(R.layout.dialog_clear_trash, null);
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);

        TextView buttonCancel = dialogView.findViewById(R.id.buttonCancel);
        TextView buttonOk = dialogView.findViewById(R.id.buttonOk);

        buttonCancel.setOnClickListener(view1 -> alertDialog.dismiss());

        buttonOk.setOnClickListener(view12 -> {
            btnCleanStorage.setVisibility(View.GONE);
            alertDialog.dismiss();
            /*if (isNetworkConnected(this) && new SessionHelper(this).getStringData(SessionHelper.REWARD_ADS_ID) != null) {
                rewardedAdClass.showRewardAdsDialog(view12);
            } else {
                cleanTrash();
            }*/
            rewardedAdClass.displayRewardAds(new ClickCallback() {
                @Override
                public void clickNext() {
                    cleanTrash();
                }
            });
            cleanTrash();
        });

        builder.setView(dialogView);
        alertDialog = builder.create();

        InsetDrawable inset = new InsetDrawable(new ColorDrawable(Color.TRANSPARENT), 40);
        alertDialog.getWindow().setBackgroundDrawable(inset);
        alertDialog.show();
    }

    public void showSuccessDialog() {
        final View dialogView = getLayoutInflater().inflate(R.layout.dialog_clear_success, null);
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);
        TextView buttonOk = dialogView.findViewById(R.id.buttonOk);

        buttonOk.setOnClickListener(view12 -> {
            alertDialog.dismiss();
            Intent it = new Intent(TrashCleanerActivity.this, CleanCompleteActivity.class);
            it.putExtra("total_clean_size", convertFileSize(totalBtnSize));
            startActivity(it);
            finish();
        });

        builder.setView(dialogView);
        alertDialog = builder.create();
        alertDialog.setCancelable(false);
        InsetDrawable inset = new InsetDrawable(new ColorDrawable(Color.TRANSPARENT), 40);
        alertDialog.getWindow().setBackgroundDrawable(inset);
        if (!TrashCleanerActivity.this.isFinishing()) {
            try {
                alertDialog.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static List<doumentContent> getApkFiles(File filepath) {
        List<doumentContent> apkFiles = new ArrayList<>();

        File[] files = filepath.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isFile() && file.getName().toLowerCase().endsWith(".apk")) {
                    doumentContent doumentContents = new doumentContent();
                    doumentContents.setName(file.getName());
                    doumentContents.setFilePath(file.getPath());
                    doumentContents.setDocumentSize(file.length());
                    apkFiles.add(doumentContents);
                    Log.d(TAG, "getApkFiles: " + file.getAbsolutePath());
                } else if (file.isDirectory()) {
                    apkFiles.addAll(getApkFiles(file));
                }
            }
        }
        return apkFiles;
    }

    public List<File> getEmptyFolders(File directory) {
        List<File> emptyFolders = new ArrayList<>();

        if (directory.isDirectory()) {
            File[] files = directory.listFiles();

            if (files != null) {
                for (File file : files) {
                    try {
                        if (file.isDirectory()) {
                            if (file.listFiles().length == 0) {
                                if (!file.getPath().contains(".")) {
                                    emptyFolders.add(file);
                                }
                            } else {
                                emptyFolders.addAll(getEmptyFolders(file));
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        Log.d(TAG, "getEmptyFolders: " + emptyFolders.size());
        for (int i = 0; i < emptyFolders.size(); i++) {
            Log.d(TAG, "getEmptyFolders: " + emptyFolders.get(i).length());
            doumentContent doumentContents = new doumentContent();
            doumentContents.setName(emptyFolders.get(i).getName());
            doumentContents.setFilePath(emptyFolders.get(i).getPath());
            doumentContents.setDocumentSize(emptyFolders.get(i).length());
            emptyFoldersList.add(doumentContents);
        }

        return emptyFolders;
    }

    public static ArrayList<doumentContent> getLargeFiles(File directoryPath, long sizeThreshold) {
        ArrayList<doumentContent> largeFiles = new ArrayList<>();

        File[] files = directoryPath.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isFile()) {
                    if (file.length() > sizeThreshold) {
                        Log.d(TAG, "getLargeFiles: " + file.getAbsolutePath());
                        doumentContent doumentContents = new doumentContent();
                        doumentContents.setName(file.getName());
                        doumentContents.setFilePath(file.getPath());
                        doumentContents.setDocumentSize(file.length());
                        largeFiles.add(doumentContents);
                    }
                } else if (file.isDirectory()) {
                    largeFiles.addAll(getLargeFiles(file, sizeThreshold));
                }
            }
        }

        return largeFiles;
    }

    public void cleanTrash() {
        Executors.newSingleThreadExecutor().execute(() -> {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Log.d(TAG, "run abc: ");
                    btnCleanStorage.setVisibility(View.GONE);
                    progressbar.setVisibility(View.VISIBLE);
                }
            });

            for (int j = 0; j < selectedImageList.size(); j++) {
                String path = selectedImageList.get(j).getFilePath();
                allDownloads.remove(selectedImageList.get(j));
                File file11 = new File(path);
                file11.delete();
            }

            for (int j = 0; j < selectedAPKList.size(); j++) {
                String path = selectedAPKList.get(j).getFilePath();
                apkfileslist.remove(selectedAPKList.get(j));
                File file11 = new File(path);
                file11.delete();
            }

            for (int j = 0; j < selectedLargeFilesList.size(); j++) {
                String path = selectedLargeFilesList.get(j).getFilePath();
                largeFiles.remove(selectedLargeFilesList.get(j));
                File file11 = new File(path);
                file11.delete();
            }

            for (int j = 0; j < selectedEmptyFolderList.size(); j++) {
                String path = selectedEmptyFolderList.get(j).getFilePath();
                emptyFoldersList.remove(selectedEmptyFolderList.get(j));
                File file11 = new File(path);
                file11.delete();
            }

            runOnUiThread(() -> {
                selectedImageList.clear();
                selectedAPKList.clear();
                selectedLargeFilesList.clear();
                selectedEmptyFolderList.clear();
                if (downloadCacheRecycleAdapter != null) {
                    downloadCacheRecycleAdapter.notifyDataSetChanged();
                }
                if (apkjunkRecyclerviewAdapter != null) {
                    apkjunkRecyclerviewAdapter.notifyDataSetChanged();
                }
                if (largeFilesRecycleAdapter != null) {
                    largeFilesRecycleAdapter.notifyDataSetChanged();
                }
                if (emptyFolderRecyclerviewAdapter != null) {
                    emptyFolderRecyclerviewAdapter.notifyDataSetChanged();
                }

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        scanning_File.setText(getResources().getString(R.string.clean_complete));
                        app_lottie.setImageResource(R.drawable.ic_done_lottie);
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                sum = 0;
                                apksumcount = 0;
                                largesumcount = 0;
                                emptysumcount = 0;
//                                progressbar.setVisibility(View.GONE);
                                scanning_File.setVisibility(View.GONE);
                                constraint.setVisibility(View.GONE);
                                showSuccessDialog();

                            }
                        }, 2000);
                    }
                }, 2000);

            });
        });
    }

    public void AnimUp() {
        TranslateAnimation animate = new TranslateAnimation(0, 0, btnCleanStorage.getHeight(), 0);
        animate.setDuration(700);
        animate.setFillAfter(true);
        btnCleanStorage.startAnimation(animate);
    }

    public void AnimDown() {
        TranslateAnimation animate = new TranslateAnimation(0, 0, 0, btnCleanStorage.getHeight());
        animate.setDuration(200);
        btnCleanStorage.startAnimation(animate);
    }

//    private void showRewardAdsDialog(View view) {
//        ViewGroup viewGroup = view.findViewById(android.R.id.content);
//        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_reward_ads, viewGroup, false);
//        AlertDialog.Builder builder = new AlertDialog.Builder(this);
//
//
//        TextView buttonOk = dialogView.findViewById(R.id.buttonOk);
//        ImageView imgClose = dialogView.findViewById(R.id.imgClose);
//
//
//        imgClose.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                alertDialog.dismiss();
//            }
//        });
//        buttonOk.setOnClickListener(view12 -> {
//
//            /*dialog = new Dialog(TrashCleanerActivity.this);
//            dialog.setContentView(R.layout.progress_dialog);
//            dialog.setCanceledOnTouchOutside(false);
//
//            dialog.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
//            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
//            dialog.show();
//
//            Handler handler = new Handler();
//            handler.postDelayed(new Runnable() {
//                @Override
//                public void run() {
//                    if (rewardAd != null && rewardAd.isReady()) {
//                        Log.e("ContentValues", "onFailedToShow on Dialogs");
//                        onFailedToShow();
//                    } else {
//                        Log.e("ContentValues", "loadRewardAds on Dialogs");
//                        loadRewardAds(true);
//                    }
//
//                }
//            }, rewardelays);*/
//
//            alertDialog.dismiss();
//            showClearDialog();
//
//
//        });
//
//        builder.setView(dialogView);
//        alertDialog = builder.create();
//
//        InsetDrawable inset = new InsetDrawable(new ColorDrawable(Color.TRANSPARENT), 40);
//        alertDialog.getWindow().setBackgroundDrawable(inset);
//        alertDialog.show();
//    }
}