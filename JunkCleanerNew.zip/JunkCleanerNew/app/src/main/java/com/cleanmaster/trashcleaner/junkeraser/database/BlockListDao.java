package com.cleanmaster.trashcleaner.junkeraser.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;


@Dao
public interface BlockListDao {

    @Insert
    void block_insert(BlockListModel model);


    @Update
    void block_update(BlockListModel model);


    @Delete
    void block_delete(BlockListModel model);


    @Query("DELETE FROM block_table")
    void block_deleteAll();

    @Query("SELECT * FROM block_table")
    List<BlockListModel> getAllBlockList();

    @Query("UPDATE block_table SET status = :updated_status WHERE id = 1")
    void updateUsingID( String updated_status);
}
