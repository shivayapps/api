package com.cleanmaster.trashcleaner.junkeraser.applock.activities.main;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.InsetDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.activity.videoActivity;
import com.cleanmaster.trashcleaner.junkeraser.applock.adapters.MainAdapter;
import com.cleanmaster.trashcleaner.junkeraser.applock.activities.setting.LockSettingActivity;
import com.cleanmaster.trashcleaner.junkeraser.applock.base.AppConstants;
import com.cleanmaster.trashcleaner.junkeraser.applock.base.BaseActivity;
import com.cleanmaster.trashcleaner.junkeraser.applock.db.CommLockInfoManager;
import com.cleanmaster.trashcleaner.junkeraser.applock.model.CommLockInfo;
import com.cleanmaster.trashcleaner.junkeraser.applock.mvp.contract.LockMainContract;
import com.cleanmaster.trashcleaner.junkeraser.applock.mvp.p.LockMainPresenter;
import com.cleanmaster.trashcleaner.junkeraser.applock.services.BackgroundManager;
import com.cleanmaster.trashcleaner.junkeraser.applock.services.LockService;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends BaseActivity implements LockMainContract.View, View.OnClickListener {
    private static final String SHARED_PREFS_KEY = "my_shared_prefs";
    private static final String DATA_KEY = "saved_data";
    private static final int RESULT_ACTION_IGNORE_BATTERY_OPTIMIZATION = 351;
    private static final String TAG = "MainActivity";
    private ImageView mBtnSetting;
    private LockMainPresenter mLockMainPresenter;
    private RecyclerView mRecyclerView;
    private MainAdapter mMainAdapter;
    private ImageView btn_back, btnSearch;
    private RelativeLayout rlProgressBar;
    private CommLockInfoManager mLockInfoManager;
    private TextView btnLock;
    private int ccounter = 0;
    List<CommLockInfo> selectedAppsList = new ArrayList<>();
    public static SharedPreferences sharedPreferences;
    private RelativeLayout top_layout;
    private RelativeLayout rlSearchLayout;
    private ImageView btnBackSearch;
    private ImageView imgClose;
    private EditText edtSearch;
    private AlertDialog alertDialog;

    @Override
    public int getLayoutId() {
        return R.layout.activity_main_app_lock;
    }

    @Override
    protected void initViews(Bundle savedInstanceState) {
        mBtnSetting = findViewById(R.id.btn_setting);
        btn_back = findViewById(R.id.btn_back);
        rlProgressBar = findViewById(R.id.rlProgressBar);
        btnLock = findViewById(R.id.btnLock);
        btnSearch = findViewById(R.id.btnSearch);
        top_layout = findViewById(R.id.top_layout);
        rlSearchLayout = findViewById(R.id.rlSearchLayout);
        btnBackSearch = findViewById(R.id.btnBackSearch);
        imgClose = findViewById(R.id.imgClose);
        edtSearch = findViewById(R.id.edtSearch);

        mLockMainPresenter = new LockMainPresenter(this, this);
        mLockMainPresenter.loadAppInfo(this);

        sharedPreferences = getSharedPreferences(SHARED_PREFS_KEY, MODE_PRIVATE);

        mLockInfoManager = new CommLockInfoManager(MainActivity.this);

        if (!Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, 0);
        }

        if (!retrieveData()) {
            btnLock.setVisibility(View.VISIBLE);
        } else {
            btnLock.setVisibility(View.GONE);
        }
        btnLock.setOnClickListener(v -> {
            saveData();
            new Handler().postDelayed(() -> {
                for (int i = 0; i < selectedAppsList.size(); i++) {
                    Log.d("Jayesh", "onClick: " + selectedAppsList.get(i).getPackageName());
                    mLockInfoManager.lockCommApplication(selectedAppsList.get(i).getPackageName());
                    mLockInfoManager.lockSystemApplication(selectedAppsList.get(i).getPackageName());
                }
                selectedAppsList.clear();
                mMainAdapter.notifyDataSetChanged();
                btnLock.setVisibility(View.GONE);
            }, 500);
        });

        btnSearch.setOnClickListener(v -> {
            top_layout.setVisibility(View.GONE);
            rlSearchLayout.setVisibility(View.VISIBLE);
        });
        btnBackSearch.setOnClickListener(v -> {
            mMainAdapter.filter("");
            top_layout.setVisibility(View.VISIBLE);
            rlSearchLayout.setVisibility(View.GONE);
        });
        imgClose.setOnClickListener(v -> {
            mMainAdapter.filter("");
        });
        edtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mMainAdapter.filter(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

    }

    @Override
    protected void initData() {
        PowerManager powerManager = (PowerManager) this.getSystemService(Context.POWER_SERVICE);
        if (powerManager != null && !powerManager.isIgnoringBatteryOptimizations(AppConstants.APP_PACKAGE_NAME)) {
            @SuppressLint("BatteryLife")
            Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            intent.setData(Uri.parse("package:" + AppConstants.APP_PACKAGE_NAME));
            startActivity(intent);
        }
        rlProgressBar.setVisibility(View.VISIBLE);
        if (!BackgroundManager.getInstance().init(this).isServiceRunning(LockService.class)) {
            BackgroundManager.getInstance().init(this).startService(LockService.class);
        }
        BackgroundManager.getInstance().init(this).startAlarmManager();
    }

    @Override
    protected void initAction() {
        mBtnSetting.setOnClickListener(this);
        btn_back.setOnClickListener(this);
       /* mDialogSearch.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                mLockMainPresenter.loadAppInfo(MainActivity.this);
            }
        });*/
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void loadAppInfoSuccess(@NonNull List<CommLockInfo> list) {
        mRecyclerView = findViewById(R.id.recycler_view);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));

        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).isSysApp()) {
                selectedAppsList.add(list.get(i));
                ccounter++;
            }
        }

        btnLock.setText(getString(R.string.lock) + ccounter + getString(R.string.apps));

        mMainAdapter = new MainAdapter(MainActivity.this, new MainAdapter.ItemClickListener() {
            @Override
            public void onClick(@NonNull CheckBox checkBox, @NonNull CommLockInfo info, int position) {
                if (checkBox.isChecked()) {
                    info.setLocked(true);
                    info.setSysApp(true);
                    ccounter = ccounter + 1;
                    selectedAppsList.add(list.get(position));
                    btnLock.setText(getString(R.string.lock) + ccounter + getString(R.string.apps));
                    Log.d("Jayesh", "onClick: ");
                    mLockInfoManager.lockCommApplication(info.getPackageName());
                    mLockInfoManager.lockSystemApplication(info.getPackageName());
                } else {

                    final View dialogView = getLayoutInflater().inflate(R.layout.dialog_ulockapp, null);
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    TextView buttonCancel = dialogView.findViewById(R.id.buttonCancel);
                    TextView buttonOk = dialogView.findViewById(R.id.buttonOk);
                    TextView tvDescription = dialogView.findViewById(R.id.tvDescription);
                    ImageView imgAppIcon = dialogView.findViewById(R.id.imgAppIcon);
                    TextView tvAppname = dialogView.findViewById(R.id.tvAppname);
                    tvAppname.setText(info.getAppName());
                    tvDescription.setText(getString(R.string.are_you_sure_you_want_to_unlock) + " \n" + info.getAppName() + "?");

                    PackageManager packageManager = getPackageManager();
                    ApplicationInfo appInfo = info.getAppInfo();
                    imgAppIcon.setImageDrawable(packageManager.getApplicationIcon(appInfo));

                    buttonCancel.setOnClickListener(view1 -> alertDialog.dismiss());

                    buttonOk.setOnClickListener(view12 -> {
                        alertDialog.dismiss();
                        info.setLocked(false);
                        info.setSysApp(false);
                        ccounter = ccounter - 1;
                        selectedAppsList.remove(list.get(position));
                        btnLock.setText(getString(R.string.lock) + ccounter + getString(R.string.apps));
                        mLockInfoManager.unlockCommApplication(info.getPackageName());
                        mLockInfoManager.unlockSystemCommApplication(info.getPackageName());
                        mMainAdapter.notifyItemChanged(position);
                    });

                    builder.setView(dialogView);
                    alertDialog = builder.create();

                    InsetDrawable inset = new InsetDrawable(new ColorDrawable(Color.TRANSPARENT), 40);
                    alertDialog.getWindow().setBackgroundDrawable(inset);
                    alertDialog.show();

                }
                Log.d(TAG, "loadAppInfoSuccess: " + list.size());
                mMainAdapter.notifyItemChanged(position);
            }
        });
        mRecyclerView.setAdapter(mMainAdapter);
        mMainAdapter.setLockInfos(list);
        rlProgressBar.setVisibility(View.GONE);
    }

    @Override
    public void onClick(@NonNull View view) {
        int id = view.getId();
        if (id == R.id.btn_setting) {
            startActivity(new Intent(this, LockSettingActivity.class));
        } else if (id == R.id.btn_back) {

            if (!retrieveData()) {
                saveData();
                for (int i = 0; i < selectedAppsList.size(); i++) {
                    Log.d(TAG, "onClick: " + selectedAppsList.get(i).getPackageName());
                    mLockInfoManager.unlockCommApplication(selectedAppsList.get(i).getPackageName());
                    mLockInfoManager.unlockSystemCommApplication(selectedAppsList.get(i).getPackageName());
                }
                selectedAppsList.clear();
                mMainAdapter.notifyDataSetChanged();
                finish();
            } else {
                finish();
            }
        }
    }

    private void saveData() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(DATA_KEY, true);
        editor.apply();
    }

    public static boolean retrieveData() {
        return sharedPreferences.getBoolean(DATA_KEY, false);
    }
}
