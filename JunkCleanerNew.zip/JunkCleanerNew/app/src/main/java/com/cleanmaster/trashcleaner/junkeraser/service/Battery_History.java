package com.cleanmaster.trashcleaner.junkeraser.service;

import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.BatteryManager;
import android.os.Handler;
import android.os.IBinder;
import android.view.View;
import android.widget.RemoteViews;

import androidx.room.Room;

import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.Utils;
import com.cleanmaster.trashcleaner.junkeraser.database.ApplicationDatabase;
import com.cleanmaster.trashcleaner.junkeraser.database.BatteryModel;
import com.cleanmaster.trashcleaner.junkeraser.receiver.NotificationReceiver;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Battery_History extends Service {
    ApplicationDatabase applicationDatabase;
    Context context;
    SharedPreferences sharedPreferences;

    @Override
    public IBinder onBind(Intent intent) {

        throw null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        context = getApplicationContext();
        //applicationDatabase = Room.databaseBuilder(getApplicationContext(), ApplicationDatabase.class, "application_db").allowMainThreadQueries().build();
        applicationDatabase = Utils.getApplicationDatabase(getApplicationContext());

        sharedPreferences = context.getSharedPreferences("intentData", Context.MODE_PRIVATE);
        update();


        return START_STICKY;
    }

    public void update() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                int level = get_battery();
                String date = getDate();
                int minute = getminute();
                int hours = gethours();
                int sec = getsecound();

                if (minute == 1) {

                    if (hours <= 24 && level <= 100) {
                        applicationDatabase.batteryDao().battery_insert(new BatteryModel(hours, level, date));
                    }
                }
                if (hours == 1 && minute == 1) {
                    if (sharedPreferences != null && sharedPreferences.getInt("phone_cooler", 99) == 1) {
                        setminiNotification("Phone is OverHeating", "Your Phone is Getting too Hot, so It's required Cooling down", true);
                    }else {
                        setminiNotification("Phone is OverHeating", "Your Phone is Getting too Hot, so It's required Cooling down", true);
                    }
                }

                update();
            }
        }, 60000);
    }

    public void setminiNotification(String t1, String t2, boolean isbuttonshow) {

        RemoteViews collapsedView = new RemoteViews(context.getPackageName(),
                R.layout.notification_collapsed);

        Intent clickIntent = new Intent(context, NotificationReceiver.class);
        PendingIntent clickPendingIntent = PendingIntent.getBroadcast(context,
                0, clickIntent, PendingIntent.FLAG_IMMUTABLE);

        collapsedView.setTextViewText(R.id.text_view_collapsed_1, t1);
        collapsedView.setTextViewText(R.id.text_view_collapsed_2, t2);
        if (isbuttonshow) {
            collapsedView.setViewVisibility(R.id.btn_clean, View.VISIBLE);
        } else {
            collapsedView.setViewVisibility(R.id.btn_clean, View.GONE);
        }

        /*Intent notificationIntent = new Intent(context, PhoneCooler.class);
        notificationIntent.putExtra("NotificationMessage", "I am from Notification");
        notificationIntent.addCategory(Intent.CATEGORY_LAUNCHER);
        notificationIntent.setAction(Intent.ACTION_MAIN);
        notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent resultIntent = PendingIntent.getActivity(context, 0, notificationIntent, 0);
        collapsedView.setOnClickPendingIntent(R.id.btn_clean, resultIntent);
        Notification notification = new NotificationCompat.Builder(context, CHANNEL_ID1)
                .setSmallIcon(R.drawable.icon)
                .setCustomContentView(collapsedView)
                .setAutoCancel(true)
                .build();
        notificationManager.notify(0, notification);*/
    }

    private int gethours() {
        Date date = new Date();
        SimpleDateFormat gethours = new SimpleDateFormat("HH");
        return Integer.parseInt(gethours.format(date));
    }

    private int getsecound() {
        Date date = new Date();
        SimpleDateFormat getsecound = new SimpleDateFormat("ss");
        return Integer.parseInt(getsecound.format(date));
    }

    private int getminute() {
        Date date = new Date();
        SimpleDateFormat getMinute = new SimpleDateFormat("mm");
        return Integer.parseInt(getMinute.format(date));
    }

    private String getDate() {
        Date date = new Date();
        SimpleDateFormat getdate = new SimpleDateFormat("dd:MM:yyyy");
        return getdate.format(date);
    }

    public int get_battery() {
        IntentFilter iFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = getApplicationContext().registerReceiver(null, iFilter);

        return batteryStatus != null ? batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) : -1;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();


    }


//    public void update_status() {
//        new Handler().postDelayed(new Runnable() {
//            @Override
//            public void run() {
//
//                if (applicationDatabase.batteryDao().getAllBatteryList().size() > 72) {
//                    applicationDatabase.batteryDao().deleteByUserId(applicationDatabase.batteryDao().getAllBatteryList().get(0).getId());
//                }
//
//                IntentFilter iFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
//                Intent batteryStatus = getApplicationContext().registerReceiver(null, iFilter);
//
//                int level = batteryStatus != null ? batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) : -1;
//
//                Date date = new Date();
//                SimpleDateFormat getdate = new SimpleDateFormat("hh:mm a");
//                SimpleDateFormat getminute = new SimpleDateFormat("mm");
//                SimpleDateFormat getsecound = new SimpleDateFormat("ss");
//
////                Log.d("oppoii", "run: " + getsecound.format(date));
////                applicationDatabase.batteryDao().battery_insert(new BatteryModel(level));
//
//                if (Integer.parseInt(getminute.format(date)) == 1) {
//
//                    applicationDatabase.batteryDao().battery_insert(new BatteryModel(level));
//                }
//                update_status();
//            }
//        }, 60000);
//    }
}


//
//public class Battery_History extends Service {
//
//    ApplicationDatabase applicationDatabase;
//    Context context;
//    private NotificationManagerCompat notificationManager;
//    SharedPreferences sharedPreferences;
//
//    @Override
//    public IBinder onBind(Intent intent) {
//
//
//        throw null;
//    }
//
//    @Override
//    public int onStartCommand(Intent intent, int flags, int startId) {
//
//        Log.d("klkouiuih", "onStartCommand: " + "yes i am service");
//        context = getApplicationContext();
//        notificationManager = NotificationManagerCompat.from(context);
//        applicationDatabase = Room.databaseBuilder(getApplicationContext(), ApplicationDatabase.class, "application_db").allowMainThreadQueries().build();
//
//        sharedPreferences = context.getSharedPreferences("intentData", Context.MODE_PRIVATE);
//        update();
//
//
//        return START_STICKY;
//    }
//
//    public void update() {
//        new Handler().postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                int level = get_battery();
//                String date = getDate();
//                int minute = getminute();
//                int hours = gethours();
//                int sec = getsecound();
//
//
//                if (minute == 1) {
//
//                        applicationDatabase.batteryDao().battery_insert(new BatteryModel(hours, level, date));
//                }
//                if (hours == 1 && minute == 1) {
//                    if (sharedPreferences != null && sharedPreferences.getInt("phone_cooler", 99) == 1) {
//                        setminiNotification("Phone is OverHeating", "Your Phone is Getting too Hot, so It's required Cooling down", true);
//                    }else {
//                        setminiNotification("Phone is OverHeating", "Your Phone is Getting too Hot, so It's required Cooling down", true);
//                    }
//                }
//
//                update();
//            }
//        }, 60000);
//    }
//
//    public void setminiNotification(String t1, String t2, boolean isbuttonshow) {
//
//        RemoteViews collapsedView = new RemoteViews(context.getPackageName(),
//                R.layout.notification_collapsed);
//
//        Intent clickIntent = new Intent(context, NotificationReceiver.class);
//        PendingIntent clickPendingIntent = PendingIntent.getBroadcast(context,
//                0, clickIntent, 0);
//
//        collapsedView.setTextViewText(R.id.text_view_collapsed_1, t1);
//        collapsedView.setTextViewText(R.id.text_view_collapsed_2, t2);
//        if (isbuttonshow) {
//            collapsedView.setViewVisibility(R.id.btn_clean, View.VISIBLE);
//        } else {
//            collapsedView.setViewVisibility(R.id.btn_clean, View.GONE);
//        }
//
//        Intent notificationIntent = new Intent(context, PhoneCooler.class);
//        notificationIntent.putExtra("NotificationMessage", "I am from Notification");
//        notificationIntent.addCategory(Intent.CATEGORY_LAUNCHER);
//        notificationIntent.setAction(Intent.ACTION_MAIN);
//        notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
//        PendingIntent resultIntent = PendingIntent.getActivity(context, 0, notificationIntent, 0);
//        collapsedView.setOnClickPendingIntent(R.id.btn_clean, resultIntent);
//        Notification notification = new NotificationCompat.Builder(context, CHANNEL_ID1)
//                .setSmallIcon(R.drawable.icon)
//                .setCustomContentView(collapsedView)
//                .setAutoCancel(true)
//                .build();
//        notificationManager.notify(0, notification);
//    }
//
//    private int gethours() {
//        Date date = new Date();
//        SimpleDateFormat gethours = new SimpleDateFormat("HH");
//        return Integer.parseInt(gethours.format(date));
//    }
//
//    private int getsecound() {
//        Date date = new Date();
//        SimpleDateFormat getsecound = new SimpleDateFormat("ss");
//        return Integer.parseInt(getsecound.format(date));
//    }
//
//    private int getminute() {
//        Date date = new Date();
//        SimpleDateFormat getMinute = new SimpleDateFormat("mm");
//        return Integer.parseInt(getMinute.format(date));
//    }
//
//    private String getDate() {
//        Date date = new Date();
//        SimpleDateFormat getdate = new SimpleDateFormat("dd:MM:yyyy");
//        return getdate.format(date);
//    }
//
//    public int get_battery() {
//        IntentFilter iFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
//        Intent batteryStatus = getApplicationContext().registerReceiver(null, iFilter);
//
//        return batteryStatus != null ? batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) : -1;
//    }
//
//    @Override
//    public void onDestroy() {
//        super.onDestroy();
//
//
//    }
//}