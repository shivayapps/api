package com.cleanmaster.trashcleaner.junkeraser.adapter;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.cleanmaster.trashcleaner.junkeraser.fragments.TestFragment;
import com.cleanmaster.trashcleaner.junkeraser.fragments.TestFragment2;
import com.cleanmaster.trashcleaner.junkeraser.fragments.TestFragment3;

public class ChartAdapter extends FragmentStatePagerAdapter {
    private static int NUM_ITEMS = 3;

    public int getItemPosition(Object obj) {
        return -2;
    }

    public ChartAdapter(FragmentManager fragmentManager) {
        super(fragmentManager);
        fragmentManager.popBackStack((String) null, 1);
    }

    public int getCount() {
        return NUM_ITEMS;
    }

    public Fragment getItem(int i) {
        if (i == 0) {
            return new TestFragment3();
        }
        if (i == 1) {
            return new TestFragment2();
        }
        if (i != 2) {
            return null;
        }
        return new TestFragment();
    }
}
