package com.cleanmaster.trashcleaner.junkeraser.applock.base;


public interface BasePresenter {
}
