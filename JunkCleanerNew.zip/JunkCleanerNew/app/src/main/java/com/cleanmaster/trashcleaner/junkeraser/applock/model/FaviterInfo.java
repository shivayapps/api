package com.cleanmaster.trashcleaner.junkeraser.applock.model;

import android.util.Log;


import com.cleanmaster.trashcleaner.junkeraser.Myapplication;

import org.litepal.crud.DataSupport;

public class FaviterInfo extends DataSupport {
    public String packageName;

    public FaviterInfo() {
        Log.e("hello123456789","FaviterInfo "+ Myapplication.Companion.getApplication());
    }

    public FaviterInfo(String packageName) {
        this.packageName = packageName;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }
}
