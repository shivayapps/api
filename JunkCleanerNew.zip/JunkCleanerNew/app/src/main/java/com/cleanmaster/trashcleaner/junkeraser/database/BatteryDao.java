package com.cleanmaster.trashcleaner.junkeraser.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface BatteryDao {

    @Insert
    void battery_insert(BatteryModel model);

    @Query("DELETE FROM battery_history")
    void battery_deleteAll();

    @Query("SELECT * FROM battery_history")
    List<BatteryModel> getAllBatteryList();

    @Query("DELETE FROM battery_history WHERE id = :id")
    void deleteByUserId(int id);

    @Query("SELECT * FROM battery_history WHERE date = :date")
    List<BatteryModel> getAllSortBatteryList(String date);
}
