package com.cleanmaster.trashcleaner.junkeraser.model;

public class ProgressItem {
 public int color;  
 public float progressItemPercentage;  
}  