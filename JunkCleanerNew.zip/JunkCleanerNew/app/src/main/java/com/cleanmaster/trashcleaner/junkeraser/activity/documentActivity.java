package com.cleanmaster.trashcleaner.junkeraser.activity;

import static com.cleanmaster.trashcleaner.junkeraser.activity.StorageCleanerActivity.allDocuments;
import static com.cleanmaster.trashcleaner.junkeraser.utils.StorageInformation.isNetworkConnected;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.InsetDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.ads.module.adutills.ClickCallback;
import com.ads.module.adutills.RewardedAdClass;
import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.Utils;
import com.cleanmaster.trashcleaner.junkeraser.adapter.documentRecycleAdapter;
import com.cleanmaster.trashcleaner.junkeraser.helper.LocaleHelper;
import com.cleanmaster.trashcleaner.junkeraser.model.AlgorithmItem;
import com.cleanmaster.trashcleaner.junkeraser.model.doumentContent;
import com.codeboy.mediafacer.MediaFacer;
import com.codeboy.mediafacer.mediaHolders.pictureFolderContent;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class documentActivity extends BaseActivity {
    public static int DELETE_REQUEST_CODE = 200;
    ArrayList<AlgorithmItem> algorithmItems = new ArrayList<>();
    //    public static ArrayList<doumentContent> allDocuments;
    RecyclerView picture_recycler;
    Spinner folderSelector;
    private ArrayList<Object> folders;
    private ArrayList<pictureFolderContent> pictureFolders;

    private ArrayList<doumentContent> selectedImageList = new ArrayList<>();
    private documentRecycleAdapter pictureAdapter;
    private ImageView btnCleanStorage;
    private ImageView imgAllSelect;
    long sum = 0;
    private boolean isSelectImage = false;
    private AlertDialog alertDialog;
    private ConstraintLayout emptyView;
    private Dialog dialog;
    private RewardedAdClass rewardedAdClass;

    @SuppressWarnings("InvalidSetHasFixedSize")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_picture);


        TextView text_title = findViewById(R.id.text_title);
        text_title.setText(R.string.documents);

        ImageView imgBack = findViewById(R.id.imgBack);
        imgBack.setOnClickListener(v -> onBackPressed());

        selectedImageList = new ArrayList<>();


        emptyView = findViewById(R.id.emptyView);
        picture_recycler = findViewById(R.id.picture_recycler);
        btnCleanStorage = findViewById(R.id.btnCleanStorage);
        imgAllSelect = findViewById(R.id.imgAllSelect);
        picture_recycler.hasFixedSize();
        picture_recycler.setHasFixedSize(true);
        picture_recycler.setItemViewCacheSize(20);
        picture_recycler.setDrawingCacheEnabled(true);
        picture_recycler.setDrawingCacheQuality(View.DRAWING_CACHE_QUALITY_HIGH);
//        picture_recycler.setLayoutManager(new GridLayoutManager(this, 3));


        pictureFolders = new ArrayList<>();
        pictureFolders.add(new pictureFolderContent("all", "All Images"));
        pictureFolders.addAll(MediaFacer.withPictureContex(this).getAllPictureFolders());

        folders = new ArrayList<>();
        for (int i = 0; i < pictureFolders.size(); i++) {
            folders.add(pictureFolders.get(i).getFolderName());
        }

        for (int i = 0; i < folders.size(); i++) {
            if (i == 0) {
                algorithmItems.add(new AlgorithmItem(pictureFolders.get(i).getFolderName(), ""));
            } else {
//                picturespath.add(pictureFolders.get(i).getPhotos().get(0).getPicturePath());
                algorithmItems.add(new AlgorithmItem(pictureFolders.get(i).getFolderName(), pictureFolders.get(i).getPhotos().get(0).getPhotoUri()));
            }
        }

//        allPhotos = MediaFacer.withPictureContex(videoActivity.this).getAllPictureContents(PictureGet.externalContentUri);
        setUpAndDisplayPictures();

//        setUpFolderSelector();

        btnCleanStorage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                /*if (isNetworkConnected(documentActivity.this) && mFirebaseRemoteConfig != null && mFirebaseRemoteConfig.getBoolean("ads_clean_rewards")) {
                    showRewardAdsDialog(v);
                } else if (!isNetworkConnected(documentActivity.this)) {
                    cleanTrash();
                } else if (mFirebaseRemoteConfig != null && !mFirebaseRemoteConfig.getBoolean("ads_clean_rewards")) {
                    cleanTrash();
                }*/

                showDeleteDialog(sum);

            }
        });

        imgAllSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isSelectImage) {
                    setAllSelect();
                    imgAllSelect.setImageResource(R.drawable.ic_all_unselect);
                    isSelectImage = true;
                } else {
                    setAllUnSelect();
                    imgAllSelect.setImageResource(R.drawable.ic_all_select);
                    isSelectImage = false;
                }
            }
        });


        rewardedAdClass = new RewardedAdClass(documentActivity.this);
        rewardedAdClass.loadRewardedAd();



    }


    void setUpAndDisplayPictures() {
        documentRecycleAdapter.pictureActionListrener actionListener = new documentRecycleAdapter.pictureActionListrener() {

            @Override
            public void onPictureItemClicked(int position, ArrayList<doumentContent> arrayListimage) {
                allDocuments = arrayListimage;
                selectedImageList.clear();
                sum = 0;
                for (int i = 0; i < arrayListimage.size(); i++) {
                    if (arrayListimage.get(i).isSelected()) {
                        selectedImageList.add(arrayListimage.get(i));
//                        Log.d(TAG, "onPictureItemClicked: "+selectedImageList.size());
                        sum = sum + arrayListimage.get(i).getDocumentSize();
//                        Log.d(TAG, "onPictureItemClicked size: "+convertFileSize(sum));
                    }
                }

//                btnCleanStorage.setText(getResources().getString(R.string.clean)+"(" + convertFileSize(sum) + ")");

                if (selectedImageList.size() > 0) {
                    btnCleanStorage.setVisibility(View.VISIBLE);
                } else {
                    btnCleanStorage.setVisibility(View.GONE);
                }


                if (selectedImageList.size() == allDocuments.size()) {
                    isSelectImage = true;
                    imgAllSelect.setImageResource(R.drawable.ic_all_unselect);
                } else {
                    isSelectImage = false;
                    imgAllSelect.setImageResource(R.drawable.ic_all_select);
                    /*if (arrayListimage.size() == selectedImageList.size()) {
                        isSelectImage = true;
                    } else {
                        isSelectImage = false;
                    }*/
                }
            }


        };


        if (allDocuments != null && allDocuments.size() > 0) {
            pictureAdapter = new documentRecycleAdapter(this, allDocuments, actionListener);
            picture_recycler.setAdapter(pictureAdapter);
        }

        if (allDocuments != null && allDocuments.size() > 0) {

            imgAllSelect.setVisibility(View.VISIBLE);
            emptyView.setVisibility(View.GONE);
            picture_recycler.setVisibility(View.VISIBLE);

           /* AdUtils adUtils = new AdUtils();
            FrameLayout frameLayout = findViewById(R.id.frame_banner);
            adUtils.bannerAd(this, frameLayout, "5", false, getAdSize(frameLayout));*/

        } else {
            imgAllSelect.setVisibility(View.GONE);
            emptyView.setVisibility(View.VISIBLE);
            picture_recycler.setVisibility(View.GONE);
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 101 && resultCode == RESULT_OK) {
            boolean isChange = data.getBooleanExtra("isChange", false);
            int currentpos = data.getIntExtra("currentpos", 0);
            if (isChange) {
                pictureAdapter.notifyItemRemoved(currentpos);
            }
        }
    }


    public static String convertFileSize(long sizeInBytes) {
        String[] units = {"B", "KB", "MB", "GB"};
        double size = sizeInBytes;
        int index = 0;
        while (size > 1024 && index < units.length - 1) {
            size /= 1024;
            index++;
        }
        return String.format("%.2f %s", size, units[index]);
    }


    @SuppressLint("NotifyDataSetChanged")
    private void setAllSelect() {
        for (int i = 0; i < allDocuments.size(); i++) {
            if (!allDocuments.get(i).isSelected()) {
                allDocuments.get(i).setSelected(true);
            }
        }
        selectedImageList.clear();
        sum = 0;
        for (int i = 0; i < allDocuments.size(); i++) {
            if (allDocuments.get(i).isSelected()) {
                selectedImageList.add(allDocuments.get(i));
                sum = sum + allDocuments.get(i).getDocumentSize();
            }
        }

//        btnCleanStorage.setText(getResources().getString(R.string.clean)+"( "+convertFileSize(sum) + ")");

        if (selectedImageList.size() > 0) {
            btnCleanStorage.setVisibility(View.VISIBLE);
        } else {
            btnCleanStorage.setVisibility(View.GONE);
        }

        if (pictureAdapter != null) {
            pictureAdapter.notifyDataSetChanged();
        }


    }

    @SuppressLint("NotifyDataSetChanged")
    private void setAllUnSelect() {
        if (allDocuments != null && allDocuments.size() > 0) {
            for (int i = 0; i < allDocuments.size(); i++) {
                if (allDocuments.get(i).isSelected()) {
                    allDocuments.get(i).setSelected(false);
                }
            }
            selectedImageList.clear();
            selectedImageList.size();
            btnCleanStorage.setVisibility(View.GONE);
            if (pictureAdapter != null) {
                pictureAdapter.notifyDataSetChanged();
            }

        }
    }


    private Uri getContentUriIdAudio(Uri imageUri) {
        String[] projections = {MediaStore.MediaColumns._ID};
        Cursor cursor = getContentResolver().query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projections,
                MediaStore.MediaColumns.DATA + "=?",
                new String[]{imageUri.getPath()}, null);
        long id = 0;
        if (cursor != null) {
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                id = cursor.getLong(cursor.getColumnIndexOrThrow(BaseColumns._ID));
            }
        }
        cursor.close();
        return Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, String.valueOf((int) id));
    }

    private Uri getContentUriId1(Uri imageUri) {
        String[] projections = {MediaStore.MediaColumns._ID};
        Cursor cursor = getContentResolver().query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projections,
                MediaStore.MediaColumns.DATA + "=?",
                new String[]{imageUri.getPath()}, null);
        long id = 0;
        if (cursor != null) {
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                id = cursor.getLong(cursor.getColumnIndexOrThrow(BaseColumns._ID));
            }
        }
        cursor.close();
        return Uri.withAppendedPath(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, String.valueOf((int) id));
    }

    private Uri getContentUriId(Uri imageUri) {
        String[] projections = {MediaStore.MediaColumns._ID};
        Cursor cursor = getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projections,
                MediaStore.MediaColumns.DATA + "=?",
                new String[]{imageUri.getPath()}, null);
        long id = 0;
        if (cursor != null) {
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                id = cursor.getLong(cursor.getColumnIndexOrThrow(BaseColumns._ID));
            }
        }
        cursor.close();
        return Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, String.valueOf((int) id));
    }

    public int deleteAPI28(Uri uri, Context context) {
        ContentResolver resolver = context.getContentResolver();
        return resolver.delete(uri, null, null);
    }

    @RequiresApi(api = Build.VERSION_CODES.R)
    private void deleteAPI30(Uri imageUri) throws IntentSender.SendIntentException {
        ContentResolver contentResolver = getContentResolver();
        // API 30
        List<Uri> uriList = new ArrayList<>();
        Collections.addAll(uriList, imageUri);
        PendingIntent pendingIntent = MediaStore.createDeleteRequest(contentResolver, uriList);
        startIntentSenderForResult(pendingIntent.getIntentSender(), DELETE_REQUEST_CODE, null, 0, 0, 0, null);
    }

    private ArrayList<doumentContent> getAllDocuments() {
        ArrayList<doumentContent> doumentContentsList = new ArrayList<>();
        Uri uri = MediaStore.Files.getContentUri("external");
        String[] projection = new String[]{
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DISPLAY_NAME,
                MediaStore.Files.FileColumns.SIZE,
                MediaStore.Audio.Media.DATA,
                MediaStore.Files.FileColumns.MIME_TYPE
        };
        String selection = MediaStore.Files.FileColumns.MEDIA_TYPE + "=" + MediaStore.Files.FileColumns.MEDIA_TYPE_DOCUMENT;
        String sortOrder = MediaStore.Files.FileColumns.SIZE + " DESC";

        Cursor cursor = getContentResolver().query(uri, projection, selection, null, sortOrder);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                doumentContent audioContent = new doumentContent();
                audioContent.setDocumentId(cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)));
                audioContent.setName(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)));
                String type = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE));
                audioContent.setDocumentSize(cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)));
                audioContent.setFilePath(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)));
                doumentContentsList.add(audioContent);
                // Do something with the id, name, and type of each document file
            }

            cursor.close();
        }
        return doumentContentsList;
    }

    @Override
    protected void onResume() {

        SharedPreferences sharedPrefs = getSharedPreferences("language", MODE_PRIVATE);
        String s1 = sharedPrefs.getString("selectedlanguage", "");
        LocaleHelper.setLocale(this, s1);
        new Utils().disebledOpenAdsBasedOnFireBase();

        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleHelper.onAttach(base, "en"));
    }

    public void deleteFileFromMediaStore(final ContentResolver contentResolver, final File file) {
        String canonicalPath;
        try {
            canonicalPath = file.getCanonicalPath();
        } catch (IOException e) {
            canonicalPath = file.getAbsolutePath();
        }
        final Uri uri = MediaStore.Files.getContentUri("external");
        final int result = contentResolver.delete(uri,
                MediaStore.Files.FileColumns.DATA + "=?", new String[]{canonicalPath});
        if (result == 0) {
            final String absolutePath = file.getAbsolutePath();
            if (!absolutePath.equals(canonicalPath)) {
                contentResolver.delete(uri, MediaStore.Files.FileColumns.DATA + "=?", new String[]{absolutePath});
            }
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        setAllUnSelect();
    }

    public void showSuccessDialog() {
        final View dialogView = getLayoutInflater().inflate(R.layout.dialog_clear_success, null);
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);

        TextView buttonOk = dialogView.findViewById(R.id.buttonOk);

        buttonOk.setOnClickListener(view12 -> {
            alertDialog.dismiss();
        });

        builder.setView(dialogView);
        alertDialog = builder.create();
        alertDialog.setCancelable(false);
        InsetDrawable inset = new InsetDrawable(new ColorDrawable(Color.TRANSPARENT), 40);
        alertDialog.getWindow().setBackgroundDrawable(inset);
        alertDialog.show();
    }

    private void cleanTrash() {
        for (int j = 0; j < selectedImageList.size(); j++) {
            String path = selectedImageList.get(j).getFilePath();
            File file11 = new File(path);
            allDocuments.remove(selectedImageList.get(j));
            deleteFileFromMediaStore(getContentResolver(), file11);
        }

        pictureAdapter.notifyDataSetChanged();
        btnCleanStorage.setVisibility(View.GONE);
        showSuccessDialog();
    }

    public void showDeleteDialog(long totalsize) {
        final View dialogView = getLayoutInflater().inflate(R.layout.dialog_delete, null);
        AlertDialog.Builder builder = new AlertDialog.Builder(documentActivity.this);

        TextView buttonCancel = dialogView.findViewById(R.id.buttonCancel);
        TextView buttonOk = dialogView.findViewById(R.id.buttonOk);
        TextView tvDescription = dialogView.findViewById(R.id.tvDescription);
        TextView tvAppname = dialogView.findViewById(R.id.tvAppname);
        tvAppname.setText(getResources().getString(R.string.delete) + "(" + convertFileSize(totalsize) + ")");
        tvDescription.setText(getString(R.string.are_you_sure_you_want_to_delete_these) + getResources().getString(R.string.documents) + "?");
        buttonCancel.setOnClickListener(view1 -> alertDialog.dismiss());

        buttonOk.setOnClickListener(view12 -> {
            alertDialog.dismiss();
            rewardedAdClass.displayRewardAds(new ClickCallback() {
                @Override
                public void clickNext() {
                    cleanTrash();
                }
            });
        });

        builder.setView(dialogView);
        alertDialog = builder.create();

        InsetDrawable inset = new InsetDrawable(new ColorDrawable(Color.TRANSPARENT), 40);
        alertDialog.getWindow().setBackgroundDrawable(inset);
        alertDialog.show();
    }

}
