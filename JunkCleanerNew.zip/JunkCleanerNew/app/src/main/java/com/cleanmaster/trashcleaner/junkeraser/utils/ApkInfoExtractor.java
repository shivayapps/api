package com.cleanmaster.trashcleaner.junkeraser.utils;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.util.Log;

import androidx.core.content.ContextCompat;

import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.model.Apps;

import java.util.ArrayList;
import java.util.List;

public class ApkInfoExtractor {

    Context context1;

    public ApkInfoExtractor(Context context2) {
        context1 = context2;
    }

    public List<Apps> GetAllInstalledApkInfo() {
        List<Apps> list = new ArrayList<>();
        List<PackageInfo> pmInfo;

        pmInfo = context1.getPackageManager().getInstalledPackages(0);
        for (int i = 0; i < pmInfo.size(); i++) {
            PackageInfo packageInfo = pmInfo.get(i);
            if ((packageInfo.applicationInfo.flags & 1) != 1) {

                String packageName = packageInfo.applicationInfo.packageName;
                if (!packageName.equalsIgnoreCase(context1.getPackageName())) {
                    list.add(new Apps(packageName, GetAppName(packageName), false));
                }
            }
        }
        return list;
    }



    public List<Apps> GetAllSystemApkInfo() {

        List<Apps> ApkPackageName = new ArrayList<>();

        Intent intent = new Intent(Intent.ACTION_MAIN, null);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);

        List<ResolveInfo> resolveInfoList = context1.getPackageManager().queryIntentActivities(intent, 0);
        for (ResolveInfo resolveInfo : resolveInfoList) {
            ActivityInfo activityInfo = resolveInfo.activityInfo;
            if (isSystemPackage(resolveInfo)) {
                ApkPackageName.add(new Apps(activityInfo.applicationInfo.packageName, activityInfo.applicationInfo.loadLabel(context1.getPackageManager()).toString(), true));
            }else {
                ApkPackageName.add(new Apps(activityInfo.applicationInfo.packageName,  activityInfo.applicationInfo.loadLabel(context1.getPackageManager()).toString(), false));
            }
        }

        return ApkPackageName;
    }
    public boolean isSystemPackage(ResolveInfo resolveInfo) {

        return ((resolveInfo.activityInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0);
    }

    public Drawable getAppIconByPackageName(String ApkTempPackageName) {

        Drawable drawable;

        try {
            drawable = context1.getPackageManager().getApplicationIcon(ApkTempPackageName);

        } catch (PackageManager.NameNotFoundException e) {

            e.printStackTrace();

            drawable = ContextCompat.getDrawable(context1, R.mipmap.ic_launcher);
            Log.d("Error Line Number", Log.getStackTraceString(e));
        }
        return drawable;
    }

    public String GetAppName(String ApkPackageName) {

        String Name = "";

        ApplicationInfo applicationInfo;

        PackageManager packageManager = context1.getPackageManager();

        try {

            applicationInfo = packageManager.getApplicationInfo(ApkPackageName, 0);

            if (applicationInfo != null) {

                Name = (String) packageManager.getApplicationLabel(applicationInfo);
            }

        } catch (PackageManager.NameNotFoundException e) {

            e.printStackTrace();
        }
        return Name;
    }
}
