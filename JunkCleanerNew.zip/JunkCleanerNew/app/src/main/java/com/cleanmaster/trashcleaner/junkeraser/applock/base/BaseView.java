package com.cleanmaster.trashcleaner.junkeraser.applock.base;


public interface BaseView<T extends BasePresenter> {
}
