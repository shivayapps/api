package com.cleanmaster.trashcleaner.junkeraser.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.database.ApplicationModel;
import com.cleanmaster.trashcleaner.junkeraser.utils.ApkInfoExtractor;

import java.util.ArrayList;

public class History_List_Adapter2 extends RecyclerView.Adapter<History_List_Adapter2.ViewHolder> {
    Activity context;
    ArrayList<ApplicationModel> applicationModelArrayList;

    public History_List_Adapter2(Activity context, ArrayList<ApplicationModel> applicationModelArrayList) {
        this.context = context;
        this.applicationModelArrayList = applicationModelArrayList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context).inflate(R.layout.history_list, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        /*if (index % 5 == 0) {
            holder.ad_item.setVisibility(View.VISIBLE);
            AdUtils.nativeAd(context, holder.native_ad1, true, true);
        }else {
            holder.ad_item.setVisibility(View.GONE);
        }*/

        ApkInfoExtractor apkInfoExtractor = new ApkInfoExtractor(context);
        final String ApplicationPackageName = applicationModelArrayList.get(position).getApkPackage();

        holder.history_name.setText(apkInfoExtractor.GetAppName(ApplicationPackageName));

        holder.history_count.setText(applicationModelArrayList.get(position).getNotification_count() + " Time Block");

        Glide.with(context)
                .load(apkInfoExtractor.getAppIconByPackageName(ApplicationPackageName))
                .apply(new RequestOptions().override(100, 100))
                .into(holder.history_app_icon);

    }

    @Override
    public int getItemCount() {
        return applicationModelArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView history_name, history_count;
        public ImageView history_app_icon;
        FrameLayout native_ad1;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            history_name = itemView.findViewById(R.id.history_name);
            history_count = itemView.findViewById(R.id.history_number);
            history_app_icon = itemView.findViewById(R.id.history_app_icon);
            native_ad1 = itemView.findViewById(R.id.native_ad_PE_pkms_small);
        }
    }
}
