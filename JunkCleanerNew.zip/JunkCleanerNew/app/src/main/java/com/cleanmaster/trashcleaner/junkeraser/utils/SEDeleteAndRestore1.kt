package com.cleanmaster.trashcleaner.junkeraser.utils

import android.app.Activity
import android.content.ContentResolver
import android.content.Context
import android.content.IntentSender
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.BaseColumns
import android.provider.MediaStore
import android.text.TextUtils
import androidx.annotation.RequiresApi
import com.cleanmaster.trashcleaner.junkeraser.model.MediaModel
import com.cleanmaster.trashcleaner.junkeraser.database.SEDataBaseClass
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.lang.Boolean
import java.nio.channels.FileChannel
import kotlin.Exception
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Throwable
import kotlin.Throws
import kotlin.arrayOf
import kotlin.plus

object SEDeleteAndRestore1 {
    var delete = 0
    const val DELETE_REQUEST_CODE = 22
    var file1: File? = null
    var uri: Uri? = null
    var secureDataBaseClass: SEDataBaseClass? = null
    var pathLists = ArrayList<MediaModel>()
    @JvmStatic

    fun moveFileOtherFolder(
        pathss: String,
        event: String?,
        file: File,
        mediaLists: ArrayList<MediaModel>,
        position: Int,
        context: Context,
        activity: Activity,
        full: String
    ) {
        val ext: String
        secureDataBaseClass = SEDataBaseClass(context, activity)
        ext = try {
            file.name.substring(file.name.lastIndexOf("."))
        } catch (e: Exception) {
            ".zip"
        }
        val path1 =
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString()
        when (event) {
            "hide" -> {
                val directory = file.parent
                secureDataBaseClass!!.insertPathNameRecycle(directory, file.name)
                if (ext == ".mp4" || ext == ".webm" || ext == ".mkv" || ext == ".3gp") {
                    copyPastFile(File(pathss), mediaLists[position].path, pathss + "/" + file.name, context, activity, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, position, mediaLists, full)
                } else if (ext == ".jpg" || ext == ".jpeg" || ext == ".png" || ext == ".webp" || ext == ".heic") {
                    copyPastFile(File(pathss), mediaLists[position].path, pathss + "/" + file.name, context, activity, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, position, mediaLists, full)
                } else if (ext == ".m4a" || ext == ".aac" || ext == ".mp3" || ext == ".ota" || ext == ".ogg" || ext == ".amr"|| ext == ".opus") {
                    copyPastFile(File(pathss), mediaLists[position].path, pathss + "/" + file.name, context, activity, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, position, mediaLists, full)
                } else {
                    copyPastFile(File(pathss), mediaLists[position].path, pathss + "/" + file.name, context, activity, MediaStore.Files.getContentUri("external"), position, mediaLists, full)
                }
            }

            "un" -> {
                var desPath: String? = null
                var id = 0
                pathLists = secureDataBaseClass!!.imagePathRecycle
                var i = 0
                while (i < pathLists.size) {
                    if (pathLists[i].name == file.name) {
                        desPath = pathLists[i].path
                        id = pathLists[i].id
                        break
                    }
                    i++
                }
                if (TextUtils.isEmpty(desPath)) {
                    when (ext) {
                        ".mp4", ".webm", ".mkv", ".3gp" -> {
                            copyPastFile(
                                File("$path1/Secure Folder/video"),
                                mediaLists[position].path,
                                path1 + "/Secure Folder/video" + "/" + file.name,
                                context,
                                activity,
                                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                                position,
                                mediaLists,
                                full
                            )
                        }
                        ".jpg", ".jpeg", ".png", ".webp", ".heic" -> {
                            copyPastFile(
                                File("$path1/Secure Folder/photos"),
                                mediaLists[position].path,
                                path1 + "/FileRecoveryData/photos" + "/" + file.name,
                                context,
                                activity,
                                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                                position,
                                mediaLists,
                                full
                            )
                        }
                        ".m4a", ".aac", ".mp3", ".ota", ".ogg", ".amr",".opus" -> {
                            copyPastFile(
                                File("$path1/Secure Folder/audio"),
                                mediaLists[position].path,
                                path1 + "/FileRecoveryData/audio" + "/" + file.name,
                                context,
                                activity,
                                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                                position,
                                mediaLists,
                                full
                            )
                        }
                        else -> {
                            copyPastFile(
                                File("$path1/Secure Folder/File_all_file"),
                                mediaLists[position].path,
                                path1 + "/FileRecoveryData/File_all_file" + "/" + file.name,
                                context,
                                activity,
                                MediaStore.Files.getContentUri("external"),
                                position,
                                mediaLists,
                                full
                            )
                        }
                    }
                } else {
                    when (ext) {
                        ".mp4", ".webm", ".mkv", ".3gp" -> {
                            copyPastFile(
                                File("$path1/FileRecoveryData/video"),
                                mediaLists[position].path,
                                desPath + "/" + file.name,
                                context,
                                activity,
                                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                                position,
                                mediaLists,
                                full
                            )
                        }
                        ".jpg", ".jpeg", ".png", ".webp", ".heic" -> {
                            copyPastFile(
                                File("$path1/FileRecoveryData/photos"),
                                mediaLists[position].path,
                                desPath + "/" + file.name,
                                context,
                                activity,
                                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                                position,
                                mediaLists,
                                full
                            )
                        }
                        ".m4a", ".aac", ".mp3", ".ota", ".ogg", ".amr",".opus" -> {
                            copyPastFile(
                                File("$path1/FileRecoveryData/audio"),
                                mediaLists[position].path,
                                desPath + "/" + file.name,
                                context,
                                activity,
                                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                                position,
                                mediaLists,
                                full
                            )
                        }
                        else -> {
                            copyPastFile(
                                File("$path1/FileRecoveryData/File_all_file"),
                                mediaLists[position].path,
                                desPath + "/" + file.name,
                                context,
                                activity,
                                MediaStore.Files.getContentUri("external"),
                                position,
                                mediaLists,
                                full
                            )
                        }
                    }
                    secureDataBaseClass!!.deletePathRecycle(id)
                }
            }

//            "recycles" -> {
//                val directory1 = file.parent
//                secureDataBaseClass!!.insertPathNameRecycle(directory1, file.name)
//                if (ext == ".mp4" || ext == ".webm" || ext == ".mkv" || ext == ".3gp") {
//                    copyPastFile(
//                        File(pathss),
//                        mediaLists[position].path,
//                        pathss + "/" + file.name,
//                        context,
//                        activity,
//                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
//                        position,
//                        mediaLists,
//                        full
//                    )
//                } else if (ext == ".jpg" || ext == ".jpeg" || ext == ".png" || ext == ".webp" || ext == ".heic") {
//                    copyPastFile(
//                        File(pathss),
//                        mediaLists[position].path,
//                        pathss + "/" + file.name,
//                        context,
//                        activity,
//                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
//                        position,
//                        mediaLists,
//                        full
//                    )
//                } else if (ext == ".m4a" || ext == ".aac" || ext == ".mp3" || ext == ".ota" || ext == ".ogg" || ext == ".amr") {
//                    copyPastFile(
//                        File(pathss),
//                        mediaLists[position].path,
//                        pathss + "/" + file.name,
//                        context,
//                        activity,
//                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
//                        position,
//                        mediaLists,
//                        full
//                    )
//                } else {
//                    copyPastFile(
//                        File(pathss),
//                        mediaLists[position].path,
//                        pathss + "/" + file.name,
//                        context,
//                        activity,
//                        MediaStore.Files.getContentUri("external"),
//                        position,
//                        mediaLists,
//                        full
//                    )
//                }
//            }
//
//            "restore" -> {
//                var desPath1: String? = null
//                var id1 = 0
//                pathLists = secureDataBaseClass!!.imagePathRecycle
//                var i = 0
//                while (i < pathLists.size) {
//                    if (pathLists[i].name == file.name) {
//                        desPath1 = pathLists[i].path
//                        id1 = pathLists[i].id
//                        break
//                    }
//                    i++
//                }
//                if (TextUtils.isEmpty(desPath1)) {
//                    when (ext) {
//                        ".mp4", ".webm", ".mkv", ".3gp" -> {
//                            copyPastFile(
//                                File("$path1/Secure Folder/video"),
//                                mediaLists[position].path,
//                                path1 + "/Secure Folder/video" + "/" + file.name,
//                                context,
//                                activity,
//                                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
//                                position,
//                                mediaLists,
//                                full
//                            )
//                        }
//                        ".jpg", ".jpeg", ".png", ".webp", ".heic" -> {
//                            copyPastFile(
//                                File("$path1/Secure Folder/photos"),
//                                mediaLists[position].path,
//                                path1 + "/Secure Folder/photos" + "/" + file.name,
//                                context,
//                                activity,
//                                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
//                                position,
//                                mediaLists,
//                                full
//                            )
//                        }
//                        ".m4a", ".aac", ".mp3", ".ota", ".ogg", ".amr" -> {
//                            copyPastFile(
//                                File("$path1/Secure Folder/audio"),
//                                mediaLists[position].path,
//                                path1 + "/Secure Folder/audio" + "/" + file.name,
//                                context,
//                                activity,
//                                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
//                                position,
//                                mediaLists,
//                                full
//                            )
//                        }
//                        else -> {
//                            copyPastFile(
//                                File("$path1/Secure Folder/File_all_file"),
//                                mediaLists[position].path,
//                                path1 + "/Secure Folder/File_all_file" + "/" + file.name,
//                                context,
//                                activity,
//                                MediaStore.Files.getContentUri("external"),
//                                position,
//                                mediaLists,
//                                full
//                            )
//                        }
//                    }
//                } else {
//                    if (ext == ".mp4" || ext == ".webm" || ext == ".mkv" || ext == ".3gp") {
//                        copyPastFile(
//                            File("$path1/Secure Folder/video"),
//                            mediaLists[position].path,
//                            desPath1 + "/" + file.name,
//                            context,
//                            activity,
//                            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
//                            position,
//                            mediaLists,
//                            full
//                        )
//                    } else if (ext == ".jpg" || ext == ".jpeg" || ext == ".png" || ext == ".webp" || ext == ".heic") {
//                        copyPastFile(
//                            File("$path1/Secure Folder/photos"),
//                            mediaLists[position].path,
//                            desPath1 + "/" + file.name,
//                            context,
//                            activity,
//                            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
//                            position,
//                            mediaLists,
//                            full
//                        )
//                    } else if (ext == ".m4a" || ext == ".aac" || ext == ".mp3" || ext == ".ota" || ext == ".ogg" || ext == ".amr") {
//                        copyPastFile(
//                            File("$path1/Secure Folder/audio"),
//                            mediaLists[position].path,
//                            desPath1 + "/" + file.name,
//                            context,
//                            activity,
//                            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
//                            position,
//                            mediaLists,
//                            full
//                        )
//                    } else {
//                        copyPastFile(
//                            File("$path1/Secure Folder/File_all_file"),
//                            mediaLists[position].path,
//                            desPath1 + "/" + file.name,
//                            context,
//                            activity,
//                            MediaStore.Files.getContentUri("external"),
//                            position,
//                            mediaLists,
//                            full
//                        )
//                    }
//                    secureDataBaseClass!!.deletePathRecycle(id1)
//                }
//            }
        }
    }


    fun moveFileOtherFolder1(
        pathss: String,
        event: String?,
        file: File,
        mediaLists: ArrayList<MediaModel>,
        position: Int,
        context: Context,
        activity: Activity,
        full: String
    ) {
        val ext: String
        ext = try {
            file.name.substring(file.name.lastIndexOf("."))
        } catch (e: Exception) {
            ".zip"
        }
        val path1 =
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString()
        when (event) {
            "hide" -> {
                val directory = file.parent

                if (ext == ".mp4" || ext == ".webm" || ext == ".mkv" || ext == ".3gp") {
                    copyPastFile(
                        File(pathss),
                        mediaLists[position].path,
                        pathss + "/" + file.name,
                        context,
                        activity,
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        position,
                        mediaLists,
                        full
                    )
                } else if (ext == ".jpg" || ext == ".jpeg" || ext == ".png" || ext == ".webp" || ext == ".heic") {
                    copyPastFile(
                        File(pathss),
                        mediaLists[position].path,
                        pathss + "/" + file.name,
                        context,
                        activity,
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        position,
                        mediaLists,
                        full
                    )
                } else if (ext == ".m4a" || ext == ".aac" || ext == ".mp3" || ext == ".ota" || ext == ".ogg" || ext == ".amr") {
                    copyPastFile(
                        File(pathss),
                        mediaLists[position].path,
                        pathss + "/" + file.name,
                        context,
                        activity,
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        position,
                        mediaLists,
                        full
                    )
                } else {
                    copyPastFile(
                        File(pathss),
                        mediaLists[position].path,
                        pathss + "/" + file.name,
                        context,
                        activity,
                        MediaStore.Files.getContentUri("external"),
                        position,
                        mediaLists,
                        full
                    )
                }
            }
        }


    }

    private fun copyPastFile(
        derCreate: File,
        path: String?,
        dec: String,
        context: Context,
        activity: Activity,
        uri: Uri,
        position: Int,
        arrayList: ArrayList<MediaModel>,
        full: String
    ) {
        file1 = derCreate
        if (!file1!!.exists()) {
            file1!!.mkdirs()
        }
        val sourceLocation = File(path)
        val targetLocation = File(dec)
        try {
            U(sourceLocation, targetLocation, context, activity, uri, position, arrayList, full)
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    @Throws(IOException::class)
    fun U(
        file: File,
        file2: File,
        context: Context,
        activity: Activity?,
        uri1: Uri,
        position: Int,
        arrayList: ArrayList<MediaModel>?,
        full: String
    ) {
        val fileChannel: FileChannel?
        val fileChannel2: FileChannel?
        if (!file2.parentFile.exists()) {
            file2.parentFile.mkdirs()
        }
        if (Boolean.valueOf(file.renameTo(file2))) {
            if (!file.path.contains("'")) {
                val contentResolver = context.contentResolver
                val v = StringBuilder("_data='")
                v.append(file.path)
                v.append("'")
                val e = contentResolver.delete(uri1, v.toString(), null)
                if (e == 1) {
                    if (full == "fulls") {
                    } else {
                    }
                } else {
                    val ss = file.delete()
                    if (ss == true) {
                    } else {
                    }
                }
            }
            fileChannel2 = null
            fileChannel = null
        } else {
            if (!file2.exists()) {
                file2.createNewFile()
            }
            fileChannel2 = FileInputStream(file).channel
            fileChannel = FileOutputStream(file2).channel
            try {
                fileChannel.transferFrom(fileChannel2, 0, fileChannel2.size())
                fileChannel2.close()
                val ss = file.delete()
                if (ss) {
                } else {
                    deleteAllFiles(file.path, context)
                }
            } catch (unused: Throwable) {
                return
            }
        }
        MediaScannerConnection.scanFile(context, arrayOf(file2.path), null, d(activity))
        fileChannel2?.close()
        fileChannel?.close()
    }

    @JvmStatic
    fun deleteFileFromMediaStore(contentResolver: ContentResolver?, file: File, context: Context) {
        deleteAllFiles(file.path, context)
    }

    private fun deleteAllFiles(path: String, context: Context) {
        val uri: Uri
        val file = File(path)
        val ss = file.delete()
        if (ss == false) {
            val ext = file.name.substring(file.name.lastIndexOf("."))
            uri = if (ext == ".mp4" || ext == ".webm" || ext == ".mkv" || ext == "3gp") {
                getContentVideoUriId(Uri.parse(path), context)
            } else if (ext == ".jpg" || ext == ".jpeg" || ext == ".png" || ext == "webp" || ext == "heic") {
                getContentImageUriId(Uri.parse(path), context)
            } else if (ext == ".m4a" || ext == ".aac" || ext == ".mp3" || ext == "ota" || ext == "ogg") {
                getContentAudioUriId(Uri.parse(path), context)
            } else {
                getContentFileUriId(Uri.parse(path), context)
            }
            val d = context.applicationContext.deleteFile(file.name)
            if (d == true) {
            } else {
                var deleted2 = false
                try {
                    deleted2 = file.canonicalFile.delete()
                } catch (e: IOException) {
                    val deleted3 = context.applicationContext.deleteFile(file.name)
                    e.printStackTrace()
                }
                if (!deleted2) {
                }
                try {
                    deleteAPI28(uri, context)
                } catch (e: Exception) {
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            deleteAPI30(path, context)
                        } else {
                            deleteAPI28(uri, context)
                        }
                    } catch (e1: IntentSender.SendIntentException) {
                        e1.printStackTrace()
                    }
                }
            }
        }
    }

    private fun getContentVideoUriId(imageUri: Uri, context: Context): Uri {
        val projections = arrayOf(MediaStore.MediaColumns._ID)
        val cursor = context.contentResolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            projections,
            MediaStore.MediaColumns.DATA + "=?", arrayOf(imageUri.path), null
        )
        var id: Long = 0
        if (cursor != null) {
            if (cursor.count > 0) {
                cursor.moveToFirst()
                id = cursor.getLong(cursor.getColumnIndexOrThrow(BaseColumns._ID))
            }
        }
        cursor!!.close()
        return Uri.withAppendedPath(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            id.toInt().toString()
        )
    }

    private fun getContentAudioUriId(imageUri: Uri, context: Context): Uri {
        val projections = arrayOf(MediaStore.MediaColumns._ID)
        val cursor = context.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projections,
            MediaStore.MediaColumns.DATA + "=?", arrayOf(imageUri.path), null
        )
        var id: Long = 0
        if (cursor != null) {
            if (cursor.count > 0) {
                cursor.moveToFirst()
                id = cursor.getLong(cursor.getColumnIndexOrThrow(BaseColumns._ID))
            }
        }
        cursor!!.close()
        return Uri.withAppendedPath(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            id.toInt().toString()
        )
    }

    private fun getContentFileUriId(imageUri: Uri, context: Context): Uri {
        val projections = arrayOf(MediaStore.MediaColumns._ID)
        val cursor = context.contentResolver.query(
            MediaStore.Files.getContentUri("external"),
            projections,
            MediaStore.MediaColumns.DATA + "=?", arrayOf(imageUri.path), null
        )
        var id: Long = 0
        if (cursor != null) {
            if (cursor.count > 0) {
                cursor.moveToFirst()
                id = cursor.getLong(cursor.getColumnIndexOrThrow(BaseColumns._ID))
            }
        }
        cursor!!.close()
        return Uri.withAppendedPath(
            MediaStore.Files.getContentUri("external"),
            id.toInt().toString()
        )
    }

    private fun getContentImageUriId(imageUri: Uri, context: Context): Uri {
        val projections = arrayOf(MediaStore.MediaColumns._ID)
        val cursor = context.contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            projections,
            MediaStore.MediaColumns.DATA + "=?", arrayOf(imageUri.path), null
        )
        var id: Long = 0
        if (cursor != null) {
            if (cursor.count > 0) {
                cursor.moveToFirst()
                id = cursor.getLong(cursor.getColumnIndexOrThrow(BaseColumns._ID))
            }
        }
        cursor!!.close()
        return Uri.withAppendedPath(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            id.toInt().toString()
        )
    }

    fun deleteAPI28(uri: Uri?, context: Context): Int {
        val resolver = context.contentResolver
        return resolver.delete(uri!!, null, null)
    }

    @RequiresApi(api = Build.VERSION_CODES.R)
    @Throws(IntentSender.SendIntentException::class)
    private fun deleteAPI30(path: String, context: Context) {
        val uri = getContentFileUriId(Uri.parse(path), context)
        context.contentResolver.delete(uri, null, null)
    }

    class d(showPhotoActivity: Activity?) : MediaScannerConnection.OnScanCompletedListener {
        override fun onScanCompleted(str: String, uri: Uri) {}
    }
}