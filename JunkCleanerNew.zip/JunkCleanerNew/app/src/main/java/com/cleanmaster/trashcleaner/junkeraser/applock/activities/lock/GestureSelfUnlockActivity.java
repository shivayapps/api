package com.cleanmaster.trashcleaner.junkeraser.applock.activities.lock;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.applock.activities.main.MainActivity;
import com.cleanmaster.trashcleaner.junkeraser.applock.activities.setting.LockSettingActivity;
import com.cleanmaster.trashcleaner.junkeraser.applock.base.AppConstants;
import com.cleanmaster.trashcleaner.junkeraser.applock.base.BaseActivity;
import com.cleanmaster.trashcleaner.junkeraser.applock.db.CommLockInfoManager;
import com.cleanmaster.trashcleaner.junkeraser.applock.utils.LockPatternUtils;
import com.cleanmaster.trashcleaner.junkeraser.applock.widget.LockPatternView;
import com.cleanmaster.trashcleaner.junkeraser.applock.widget.LockPatternViewPattern;
import java.util.List;

public class GestureSelfUnlockActivity extends BaseActivity {
    private LockPatternView mLockPatternView;
    private LockPatternUtils mLockPatternUtils;
    private int mFailedPatternAttemptsSinceLastTimeout = 0;
    private String actionFrom;
    private String pkgName;
    private CommLockInfoManager mManager;

    @NonNull
    private final Runnable mClearPatternRunnable = new Runnable() {
        public void run() {
            mLockPatternView.clearPattern();
        }
    };

    @Override
    public int getLayoutId() {
        return R.layout.activity_gesture_self_unlock;
    }

    @Override
    protected void initViews(Bundle savedInstanceState) {
        mLockPatternView = findViewById(R.id.unlock_lock_view);
        ImageView btn_back = findViewById(R.id.btn_back);
        btn_back.setOnClickListener(v -> onBackPressed());
    }

    @Override
    protected void initData() {
        mManager = new CommLockInfoManager(this);
        pkgName = getIntent().getStringExtra(AppConstants.LOCK_PACKAGE_NAME);
        actionFrom = getIntent().getStringExtra(AppConstants.LOCK_FROM);
        initLockPatternView();
    }

    private void initLockPatternView() {
        mLockPatternUtils = new LockPatternUtils(this);
        LockPatternViewPattern mPatternViewPattern = new LockPatternViewPattern(mLockPatternView);
        mPatternViewPattern.setPatternListener(new LockPatternViewPattern.onPatternListener() {
            @Override
            public void onPatternDetected(@NonNull List<LockPatternView.Cell> pattern) {
                if (mLockPatternUtils.checkPattern(pattern)) {
                    mLockPatternView.setDisplayMode(LockPatternView.DisplayMode.Correct);
                    switch (actionFrom) {
                        case AppConstants.LOCK_FROM_LOCK_MAIN_ACITVITY:
                            Intent intent = new Intent(GestureSelfUnlockActivity.this, MainActivity.class);
                            startActivity(intent);
                            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                            finish();
                            break;
                        case AppConstants.LOCK_FROM_FINISH:
                            mManager.unlockCommApplication(pkgName);
                            finish();
                            break;
                        case AppConstants.LOCK_FROM_SETTING:
                            startActivity(new Intent(GestureSelfUnlockActivity.this, LockSettingActivity.class));
                            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                            finish();
                            break;
                        case AppConstants.LOCK_FROM_UNLOCK:
                            mManager.setIsUnLockThisApp(pkgName, true);
                            mManager.unlockCommApplication(pkgName);
                            sendBroadcast(new Intent(GestureUnlockActivity.FINISH_UNLOCK_THIS_APP));
                            finish();
                            break;
                    }
                } else {
                    mLockPatternView.setDisplayMode(LockPatternView.DisplayMode.Wrong);
                    if (pattern.size() >= LockPatternUtils.MIN_PATTERN_REGISTER_FAIL) {
                        mFailedPatternAttemptsSinceLastTimeout++;
                    }

                    if (mFailedPatternAttemptsSinceLastTimeout < LockPatternUtils.FAILED_ATTEMPTS_BEFORE_TIMEOUT) {
                        mLockPatternView.postDelayed(mClearPatternRunnable, 500);
                    }
                }
            }
        });
        mLockPatternView.setOnPatternListener(mPatternViewPattern);
        mLockPatternView.setTactileFeedbackEnabled(true);
    }

    @Override
    protected void initAction() {

    }


}
