package com.cleanmaster.trashcleaner.junkeraser.model;

import android.graphics.drawable.Drawable;

public class ChildItem {
    public static final int TYPE_APKS = 0;
    public static final int TYPE_CACHE = 1;
    public static final int TYPE_DOWNLOAD_FILE = 2;
    public static final int TYPE_LARGE_FILES = 3;
    private boolean isCheck;
    private String mApplicationName;
    private long mCacheSize;
    private Drawable mIcon;
    private String mPackageName;
    private String path;
    private int type;

    public ChildItem(String str, String str2, Drawable drawable, long j, int i, String str3, boolean z) {
        this.mCacheSize = j;
        this.mPackageName = str;
        this.mApplicationName = str2;
        this.mIcon = drawable;
        this.type = i;
        this.isCheck = z;
        this.path = str3;
    }

    public Drawable getApplicationIcon() {
        return this.mIcon;
    }

    public String getApplicationName() {
        return this.mApplicationName;
    }

    public long getCacheSize() {
        return this.mCacheSize;
    }

    public String getPackageName() {
        return this.mPackageName;
    }

    public int getType() {
        return this.type;
    }

    public void setType(int i) {
        this.type = i;
    }

    public boolean isCheck() {
        return this.isCheck;
    }

    public void setIsCheck(boolean z) {
        this.isCheck = z;
    }

    public String getPath() {
        return this.path;
    }

    public void setPath(String str) {
        this.path = str;
    }
}
