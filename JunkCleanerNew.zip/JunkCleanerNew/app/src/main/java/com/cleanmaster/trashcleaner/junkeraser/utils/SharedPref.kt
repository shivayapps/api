package com.cleanmaster.trashcleaner.junkeraser.utils

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.content.SharedPreferences.Editor

fun Context.SharedPref() : SharedPreferences{
    val MAIN_PREF = "Main_Preference"
   var obj :SharedPreferences = getSharedPreferences(MAIN_PREF, 0)
//   var editor: SharedPreferences.Editor = obj.edit()
    return  obj
}

 fun SharedPreferences.putString(key : String , value : String){
    var editor: Editor = edit()
    editor.apply {
        putString(key, value)
        applyChanges()
    }
}

 fun SharedPreferences.putInt(key : String , value : Int){
    var editor: Editor = edit()
    editor.apply {
        putInt(key, value)
        applyChanges()
    }
}

 fun SharedPreferences.putBoolean(key : String , value : Boolean){
    var editor: Editor = edit()
    editor.apply {
        putBoolean(key, value)
        applyChanges()
    }
}

 @SuppressLint("SuspiciousIndentation")
 fun SharedPreferences.clear(){
    var editor: Editor = edit()
        editor.apply {
        clear()
        applyChanges()
    }
}

 fun SharedPreferences.removeKey(key : String){
    var editor: Editor = edit()
    editor.apply {
        remove(key)
        applyChanges()
    }
}

 fun SharedPreferences.GetString(key : String , defaultValue: String = "") : String?{
   return getString(key , defaultValue)
}

 fun SharedPreferences.GetInt(key : String , defaultValue: Int = 0) : Int?{
    return getInt(key , defaultValue)
}

 fun SharedPreferences.GetBoolean(key : String , defaultValue: Boolean = false) : Boolean{
    return getBoolean(key , defaultValue)
}

 fun Editor.applyChanges(){
    apply()
    commit()
}

class SharedPref(context: Context) {

    lateinit var shareObj: SharedPreferences;
    lateinit var editor: SharedPreferences.Editor
    lateinit var context: Context;

    init {
        this.context = context;
        val MAIN_PREF = "Main_Preference"
        shareObj = context.getSharedPreferences(MAIN_PREF, 0)
        editor = shareObj.edit()
    }

    fun putString(k: String, v: String): Boolean {
        if (shareObj != null && editor != null) {
            editor.putString(k, v);
            editor.apply()
            return editor.commit()
        } else {
//            Util.DebugToast(context, context.resources.getString(R.string.null_pref_edit))
            return false;
        }
    }

    fun getString(k: String): String? {
        if (shareObj != null) {
            return shareObj.getString(k, "")
        } else {
//            Util.DebugToast(context, context.resources.getString(R.string.null_pref_edit))
            return ""
        }
    }

    fun putInteger(k: String, v: Int): Boolean {
        if (shareObj != null && editor != null) {
            editor.putInt(k, v);
            editor.apply()
            return editor.commit()
        } else {
//            Util.DebugToast(context, context.resources.getString(R.string.null_pref_edit))
            return false;
        }
    }

    fun getInteger(k: String): Int {
        if (shareObj != null) {
            return shareObj.getInt(k, 0)
        } else {
//            Util.DebugToast(context, context.resources.getString(R.string.null_pref_edit))
            return 0
        }
    }

    fun putBoolean(k: String, v: Boolean): Boolean {
        if (shareObj != null && editor != null) {
            editor.putBoolean(k, v);
            editor.apply()
            return editor.commit()
        } else {
//            Util.DebugToast(context, context.resources.getString(R.string.null_pref_edit))
            return false;
        }
    }

    fun getBoolean(k: String, defaultValue: Boolean = false): Boolean {
        if (shareObj != null) {
            return shareObj.getBoolean(k, defaultValue)
        } else {
//            Util.DebugToast(context, context.resources.getString(R.string.null_pref_edit))
            return defaultValue
        }
    }

    fun putStringArray(k : String ,array: ArrayList<String>) {

        if (shareObj != null) {
            // Convert the ArrayList to a Set<String>
            val set: Set<String> = HashSet(array)
            // Store the Set<String> in shared preferences
            editor.putStringSet(k, set);
            editor.apply();
        }
    }
    fun getStringArray(k : String) : ArrayList<String>{

        var array : ArrayList<String> = ArrayList()
        if (shareObj != null) {
            // Convert the ArrayList to a Set<String>
            val set: Set<String> = shareObj.getStringSet(k,HashSet(array))!!
            // Convert the Set<String> to an ArrayList<String>
            array = ArrayList(set)
        }
        return array
    }


    // ********** clear prefrences **********//
    fun clearPreferences() {
        editor.clear()
        editor.apply()
    }


    fun removeKey(s: String) {
        editor.remove(s);
        editor.apply()
        editor.commit()
    }

}
const val KEY_IS_SELECT_LANGUAGE = "key_is_select_language"
const val KEY_IS_ALLOW_NOTIFICATION = "key_is_allow_notification"
const val KEY_IS_ALLOW_STORAGE = "key_is_allow_storage"
const val KEY_IS_ALLOW_CONTACT = "key_is_allow_contact"
const val KEY_IS_LIST = "key_is_list"
const val KEY_IS_LIST_DUPLICATE = "key_is_list_duplicate"
const val KEY_IS_LIST_AUDIO = "key_is_list_audio"
const val KEY_IS_LIST_DOCUMENT = "key_is_list_document"
const val KEY_LANGUAGE = "key_language"
const val KEY_THEME = "key_theme"
const val KEY_THEME1 = "key_theme1"
const val KEY_GRID_SPAN = "key_grid_span"
const val KEY_DATE_SELECTION = "key_date_selection"
const val KEY_SIZE_SELECTION = "key_size_selection"
const val KEY_DATE_CUSTOM_LONG = "key_date_custom_long"
const val KEY_SENSITIVITY = "key_sensitivity"