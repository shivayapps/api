package com.cleanmaster.trashcleaner.junkeraser.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.BatteryManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.room.Room;
import androidx.viewpager.widget.ViewPager;

import com.ads.module.adutills.AdUtils;
import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.Utils;
import com.cleanmaster.trashcleaner.junkeraser.adapter.ChartAdapter;
import com.cleanmaster.trashcleaner.junkeraser.database.ApplicationDatabase;
import com.cleanmaster.trashcleaner.junkeraser.helper.LocaleHelper;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.MPPointF;
import com.google.android.material.tabs.TabLayout;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class BatteryUsageActivity extends BaseActivity {
    ImageView btn_back;
    ChartAdapter adapterViewPager;
    public Context context;
    private TabLayout indicator;
    TextView tvDate;
    private ViewPager vpPager;
    ApplicationDatabase applicationDatabase;
    TextView tvStatus, tvPower, tvLevel, tvHelth, tvTemp, tvVoltage,tvAvailable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_battery_usage);

        //applicationDatabase = Room.databaseBuilder(BatteryUsageActivity.this, ApplicationDatabase.class, "application_db").allowMainThreadQueries().build();
        applicationDatabase = Utils.getApplicationDatabase(this);

        btn_back = findViewById(R.id.btn_back);
        tvStatus = findViewById(R.id.tvStatus);
        tvPower = findViewById(R.id.tvPower);
        tvVoltage = findViewById(R.id.tvVoltage);
        tvHelth = findViewById(R.id.tvHelth);
        tvTemp = findViewById(R.id.tvTemp);
        tvLevel = findViewById(R.id.tvLevel);
        tvAvailable = findViewById(R.id.tvAvailable);
        tvDate = findViewById(R.id.tvDate);
        vpPager = findViewById(R.id.viewPager);

        indicator = findViewById(R.id.indicator);
        indicator.setupWithViewPager(vpPager, true);

        intEvent();
        intData();

        ChartAdapter chartAdapter = new ChartAdapter(getSupportFragmentManager());
        adapterViewPager = chartAdapter;
        vpPager.setAdapter(chartAdapter);
        vpPager.setCurrentItem(2);

        btn_back.setOnClickListener(v -> onBackPressed());

        BatteryBroadcastReceiver batteryBroadcastReceiver = new BatteryBroadcastReceiver();
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        registerReceiver(batteryBroadcastReceiver, filter);



        TextView tvDayCount = findViewById(R.id.tvDayCount);
        BatteryManager batteryManager = (BatteryManager) getSystemService(Context.BATTERY_SERVICE);
//
        int batteryLevel = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
//
        double batteryremainging = ((batteryLevel) * 14.4) / 60;
        String s = String.valueOf(batteryremainging);
        String hourss = s.substring(0, s.indexOf('.'));
        double it = batteryremainging - Integer.parseInt(hourss);
        double minutess = (it * 60 * 100) / 100;
        String minutes = String.valueOf(minutess).substring(0, s.indexOf('.'));
//
        tvDayCount.setText(hourss + " h " + minutes.replace(".", "") + " min");

        loadBanner();
    }

    public void intEvent() {
        viewPagerListenItem();
    }

    public void viewPagerListenItem() {
        tvDate.setText(DateFormat.getDateInstance().format(Calendar.getInstance().getTime()));
        vpPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            public void onPageScrollStateChanged(int i) {
            }

            public void onPageScrolled(int i, float f, int i2) {
            }

            public void onPageSelected(int i) {
                if (i == 0) {
                    Calendar instance = Calendar.getInstance();
                    instance.add(5, -2);
                    tvDate.setText(DateFormat.getDateInstance().format(instance.getTime()));
                }
                if (i == 1) {
                    Calendar instance2 = Calendar.getInstance();
                    instance2.add(5, -1);
                    tvDate.setText(DateFormat.getDateInstance().format(instance2.getTime()));
                }
                if (i == 2) {
                    tvDate.setText(DateFormat.getDateInstance().format(Calendar.getInstance().getTime()));
                }
            }
        });
    }

    public void intData() {
        if (applicationDatabase.chargeHistoryDao().getAllcharge_historyList() != null && applicationDatabase.chargeHistoryDao().getAllcharge_historyList().size() > 0) {

            setData();
        }
    }

    private void setData() {
        float f;
        ArrayList arrayList = new ArrayList();
        Math.round((float) applicationDatabase.chargeHistoryDao().getAllcharge_historyList().get(0).getCharge_normal());
        float chargeNormal = (float) applicationDatabase.chargeHistoryDao().getAllcharge_historyList().get(0).getCharge_normal();
        float chargeHealthy = (float) applicationDatabase.chargeHistoryDao().getAllcharge_historyList().get(0).getCharge_healthy();
        float chargeOver = (float) applicationDatabase.chargeHistoryDao().getAllcharge_historyList().get(0).getCharge_overcharged();
        if (chargeNormal == 0.0f && chargeHealthy == 0.0f && chargeOver == 0.0f) {
            arrayList.add(new PieEntry(40.0f, 0));
            arrayList.add(new PieEntry(1.0f, 1));
            arrayList.add(new PieEntry(1.0f, 2));
            f = chargeNormal;
        } else {
            f = chargeNormal < chargeHealthy ? chargeHealthy : chargeNormal;
            if (f < chargeOver) {
                f = chargeOver;
            }
        }
        float f2 = f / 40.0f;
        if (chargeNormal <= f2) {
            arrayList.add(new PieEntry(f2, 0));
        } else {
            arrayList.add(new PieEntry(chargeNormal, 0));
        }
        if (chargeHealthy <= f2) {
            arrayList.add(new PieEntry(f2, 0));
        } else {
            arrayList.add(new PieEntry(chargeHealthy, 0));
        }
        if (chargeOver <= f2) {
            arrayList.add(new PieEntry(f2, 0));
        } else {
            arrayList.add(new PieEntry(chargeOver, 0));
        }
        PieDataSet pieDataSet = new PieDataSet(arrayList, "");
        pieDataSet.setDrawIcons(false);
        pieDataSet.setSliceSpace(3.0f);
        pieDataSet.setIconsOffset(new MPPointF(0.0f, 40.0f));
        pieDataSet.setSelectionShift(5.0f);
        ArrayList arrayList2 = new ArrayList();
        arrayList2.add(ContextCompat.getColor(BatteryUsageActivity.this, R.color.color_normal));
        arrayList2.add(ContextCompat.getColor(BatteryUsageActivity.this, R.color.color_healthy));
        arrayList2.add(ContextCompat.getColor(BatteryUsageActivity.this, R.color.color_over));
        pieDataSet.setColors((List<Integer>) arrayList2);
        pieDataSet.setXValuePosition(PieDataSet.ValuePosition.OUTSIDE_SLICE);
        PieData pieData = new PieData(pieDataSet);
        pieData.setValueTextSize(11.0f);
        pieData.setValueTextColor(-1);
        pieData.setDrawValues(false);

    }

    public class BatteryBroadcastReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            int batteryHealth = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, -1);
            int batteryVoltage = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
            int batteryTemperature = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
            int percentage = (level * 100) / scale;
            boolean isCharging = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1) == BatteryManager.BATTERY_STATUS_CHARGING;

            BatteryManager mBatteryManager = (BatteryManager) context.getSystemService(Context.BATTERY_SERVICE);
            Integer capacity = mBatteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
            Log.d("Jayesh", "onReceive: "+capacity);
            tvLevel.setText(""+percentage + "%");
            tvAvailable.setText(""+percentage + "%");
//            simpleProgressBar.setProgress(percentage);
            if (isCharging) {
                tvStatus.setText(R.string.charging);
                tvPower.setText(R.string.plugged);
            } else {
                tvStatus.setText(R.string.discharging);
                tvPower.setText(R.string.unplugged);
            }
            tvHelth.setText(""+batteryHealth);
            tvVoltage.setText(""+batteryVoltage+"mv");
            tvTemp.setText(batteryTemperature / 10.0 + "°C");


            switch (batteryHealth) {
                case BatteryManager.BATTERY_HEALTH_COLD:
                    tvHelth.setText(R.string.cold);
                    break;
                case BatteryManager.BATTERY_HEALTH_DEAD:
                    tvHelth.setText(R.string.dead);
                    break;
                case BatteryManager.BATTERY_HEALTH_GOOD:
                    tvHelth.setText(R.string.good);
                    break;
                case BatteryManager.BATTERY_HEALTH_OVERHEAT:
                    tvHelth.setText(R.string.overheat);
                    break;
                case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE:
                    tvHelth.setText(R.string.over_voltage);
                    break;
                case BatteryManager.BATTERY_HEALTH_UNKNOWN:
                    tvHelth.setText(R.string.unknown);
                    break;
                case BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE:
                    tvHelth.setText(R.string.unspecified_failure);
                    break;
            }

        }

        private String getChargingType(int chargingStatus) {
            switch (chargingStatus) {
                case BatteryManager.BATTERY_PLUGGED_AC:
                    return "AC charging";
                case BatteryManager.BATTERY_PLUGGED_USB:
                    return "USB charging";
                case BatteryManager.BATTERY_PLUGGED_WIRELESS:
                    return "Wireless charging";
                default:
                    return "Not charging";
            }
        }
    }

    @Override
    protected void onResume() {

        SharedPreferences sharedPrefs = getSharedPreferences("language", MODE_PRIVATE);
        String s1 = sharedPrefs.getString("selectedlanguage", "");
        LocaleHelper.setLocale(this, s1);
        new Utils().disebledOpenAdsBasedOnFireBase();
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleHelper.onAttach(base, "en"));
    }

    private void loadBanner() {
        FrameLayout banner_layout = findViewById(R.id.frame_banner);
        new AdUtils().loadMediumBanner(this,banner_layout);
    }
}