package com.cleanmaster.trashcleaner.junkeraser.activity;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
import static android.os.Build.VERSION.SDK_INT;

import static com.cleanmaster.trashcleaner.junkeraser.activity.SystemInfoActivity.getAvailableInternalMemorySize;
import static com.cleanmaster.trashcleaner.junkeraser.activity.SystemInfoActivity.getTotalInternalMemorySize;

import android.Manifest;
import android.app.AlarmManager;
import android.app.AppOpsManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.UiModeManager;
import android.bluetooth.BluetoothAdapter;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.InsetDrawable;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.location.LocationManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.room.Room;

import com.ads.module.adutills.AdLoaderClass;
import com.ads.module.adutills.AdUtils;
import com.ads.module.adutills.NativeLoadWithShows;
import com.ads.module.adutills.SessionHelper;
import com.ads.module.open.AdconfigApplication;
import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.Utils;
import com.cleanmaster.trashcleaner.junkeraser.applock.activities.main.StartAppLock;
import com.cleanmaster.trashcleaner.junkeraser.database.ApplicationDatabase;
import com.cleanmaster.trashcleaner.junkeraser.database.ApplicationModel;
import com.cleanmaster.trashcleaner.junkeraser.database.BatteryModel;
import com.cleanmaster.trashcleaner.junkeraser.database.BlockListModel;
import com.cleanmaster.trashcleaner.junkeraser.helper.LocaleHelper;
import com.cleanmaster.trashcleaner.junkeraser.junckcleaner.activities.JunkActivity;
import com.cleanmaster.trashcleaner.junkeraser.model.Apps;
import com.cleanmaster.trashcleaner.junkeraser.model.ProgressItem;
import com.cleanmaster.trashcleaner.junkeraser.receiver.Alarm;
import com.cleanmaster.trashcleaner.junkeraser.receiver.PowerMonitorReceiver;
import com.cleanmaster.trashcleaner.junkeraser.utils.AlarmUtils;
import com.cleanmaster.trashcleaner.junkeraser.utils.ApkInfoExtractor;
import com.cleanmaster.trashcleaner.junkeraser.utils.CustomProgressBar;
import com.cleanmaster.trashcleaner.junkeraser.utils.UsageAccessHelper;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.card.MaterialCardView;
import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.Executors;

public class DashBoardActivity extends BaseActivity {
    private static final int REQUEST_PERMISSIONS = 1;
    private static final int REQUEST_USAGE_ACCESS = 1;
    private ImageView img_sound, img_bluthooth, img_airplane, img_gps, img_rotate;
    private AudioManager audioManager;
    private LocationManager locationManager;
    private BluetoothAdapter bluetoothAdapter;
    int ON_DO_NOT_DISTURB_CALLBACK_CODE = 4300;
    public static final int PERMISSION_ASK = 1001;
    BroadcastReceiver receiver;
    ApplicationDatabase applicationDatabase;

    private boolean isFlashOn;
    public static ArrayList<ApplicationModel> applicationlist = new ArrayList<>();
    public static List<Apps> appList = new ArrayList<>();
    private CameraManager mCameraManager;
    private String mCameraId;
    private AlertDialog alertDialog;
    private ImageView img_flash;
    private ReviewManager reviewManager;
    ReviewInfo reviewInfo;
    private SharedPreferences sharedpreferences;
    private SharedPreferences sharedPref;
    private CustomProgressBar seekbar;
    private ArrayList<ProgressItem> progressItemList = new ArrayList<>();
    private ProgressItem mProgressItem;
    private ProgressBar progressBarImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash_board);

        getReviewInfo();

        sharedPref = getSharedPreferences("SettingScreen", MODE_PRIVATE);
        sharedpreferences = getSharedPreferences("myPreference", Context.MODE_PRIVATE);

        ImageView btnSetting = findViewById(R.id.btnSetting);
        btnSetting.setOnClickListener(v -> {
            Intent it = new Intent(DashBoardActivity.this, SettingActivity.class);
            startActivity(it);
            finish();
        });

        mCameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            mCameraId = mCameraManager.getCameraIdList()[0];
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }

        //applicationDatabase = Room.databaseBuilder(this, ApplicationDatabase.class, "application_db").allowMainThreadQueries().build();
        applicationDatabase = Utils.getApplicationDatabase(this);
        loaddata();

        loadBanner();
        img_sound = findViewById(R.id.img_sound);
        img_flash = findViewById(R.id.img_flash);
        img_bluthooth = findViewById(R.id.img_bluthooth);
        img_airplane = findViewById(R.id.img_airplane);
        img_gps = findViewById(R.id.img_gps);
        img_rotate = findViewById(R.id.img_rotate);
        MaterialCardView cardSystemInfo = findViewById(R.id.cardSystemInfo);
        LinearLayout cardAppManager = findViewById(R.id.cardAppManager);
        LinearLayout cardBatteryUsage = findViewById(R.id.cardBatteryUsage);
        MaterialCardView cardCleanNotification = findViewById(R.id.cardCleanNotification);
        LinearLayout cardStorageCleaner = findViewById(R.id.cardStorageCleaner);
        LinearLayout cardTrashCleaner = findViewById(R.id.cardTrashCleaner);
        LinearLayout cardWhatsAppCleaner = findViewById(R.id.cardWhatsAppCleaner);
        LinearLayout cardAppLocker = findViewById(R.id.cardAppLocker);
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        img_sound.setOnClickListener(v -> requestMutePermissions());

        img_flash.setOnClickListener(v -> {
            if (!isFlashOn) {
                isFlashOn = true;
                switchFlashLight(true);
                img_flash.setImageResource(R.drawable.ic_flash_on);
                img_flash.setBackground(getResources().getDrawable(R.drawable.ic_bg_round_selected));
//                img_flash.setColorFilter(ContextCompat.getColor(DashBoardActivity.this, R.color.selected_icon_color), android.graphics.PorterDuff.Mode.SRC_IN);
            } else {
                isFlashOn = false;
                switchFlashLight(false);
                img_flash.setImageResource(R.drawable.ic_flash_off);
                img_flash.setBackground(getResources().getDrawable(R.drawable.ic_bg_round_unselected));
//                img_flash.setColorFilter(ContextCompat.getColor(DashBoardActivity.this, R.color.textcolor), android.graphics.PorterDuff.Mode.SRC_IN);
            }
        });

        img_bluthooth.setOnClickListener(v -> {

            AdconfigApplication.Companion.disabledOpenAds();
            Intent intentOpenBluetoothSettings = new Intent();
            intentOpenBluetoothSettings.setAction(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS);
            startActivityForResult(intentOpenBluetoothSettings, 0);
        });

        img_airplane.setOnClickListener(v -> {
            AdconfigApplication.Companion.disabledOpenAds();
            Intent intent = new Intent("android.settings.AIRPLANE_MODE_SETTINGS");
            startActivity(intent);
        });

        img_gps.setOnClickListener(v -> {
            AdconfigApplication.Companion.disabledOpenAds();
            Intent intent2 = new Intent("android.settings.LOCATION_SOURCE_SETTINGS");
            startActivity(intent2);
        });

        img_rotate.setOnClickListener(v -> {
            if (!Settings.System.canWrite(DashBoardActivity.this)) {
                openAndroidPermissionsMenu(DashBoardActivity.this);
            } else if (isAutoRotateModeOn(DashBoardActivity.this)) {
                Settings.System.putInt(getContentResolver(), "accelerometer_rotation", 0);
            } else {
                Settings.System.putInt(getContentResolver(), "accelerometer_rotation", 1);
            }
        });

        cardSystemInfo.setOnClickListener(v -> {
            startActivity(new Intent(DashBoardActivity.this, SystemInfoActivity.class));
        });

        cardAppManager.setOnClickListener(v -> {
            new AdLoaderClass().showInterstitialAds(DashBoardActivity.this, new Intent(DashBoardActivity.this, ApplicationManager.class));
//            startActivity(new Intent(DashBoardActivity.this, ApplicationManager.class));
        });

        cardBatteryUsage.setOnClickListener(v -> {
            startActivity(new Intent(DashBoardActivity.this, BatteryUsageActivity.class));
        });

        cardCleanNotification.setOnClickListener(v -> {

            if (isNotificationAccessGiven()) {
                new AdLoaderClass().showInterstitialAds(DashBoardActivity.this, new Intent(this, CleanNotification.class).putExtra("new", "new_user"));
//                startActivity(new Intent(this, CleanNotification.class).putExtra("new", "new_user"));
            } else {
                open_Notification_Access_Setting();
            }

            /*if (isNotificationAccessGiven()) {
                startActivity(new Intent(DashBoardActivity.this, CleanNotification.class).putExtra("new", "old_user"));
            } else {
                startActivity(new Intent(DashBoardActivity.this, NotiJunk.class));
            }*/
        });

        cardStorageCleaner.setOnClickListener(v -> {

            storagePermission("storage_cleaner", "StorageCleaner");

        });

        cardWhatsAppCleaner.setOnClickListener(v -> {

            storagePermissionAppCleaner();
        });

        cardTrashCleaner.setOnClickListener(v -> {

            if (SDK_INT <= Build.VERSION_CODES.Q) {
                int write = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
                int read = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);

                if (write != PackageManager.PERMISSION_GRANTED && read != PackageManager.PERMISSION_GRANTED) {
                    startActivity(new Intent(DashBoardActivity.this, AllPermissionForSingleClickActivity.class).putExtra("trash_cleaner", "TrashCleaner"));
                } else {
                    new AdLoaderClass().showInterstitialAds(DashBoardActivity.this, new Intent(DashBoardActivity.this, JunkActivity.class));
//                    startActivity(new Intent(DashBoardActivity.this, JunkActivity.class));
                }
            }

            if (SDK_INT >= Build.VERSION_CODES.R) {
                if (!Environment.isExternalStorageManager()) {
                    startActivity(new Intent(DashBoardActivity.this, AllPermissionForSingleClickActivity.class).putExtra("trash_cleaner", "TrashCleaner"));
                } else {
                    new AdLoaderClass().showInterstitialAds(DashBoardActivity.this, new Intent(DashBoardActivity.this, JunkActivity.class));
//                    startActivity(new Intent(DashBoardActivity.this, JunkActivity.class));
                }
            }
        });

        PowerMonitorReceiver powerMonitorReceiver = new

                PowerMonitorReceiver();

        receiver = powerMonitorReceiver;

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_BATTERY_CHANGED);
        intentFilter.addAction(Intent.ACTION_POWER_CONNECTED);
        intentFilter.addAction(Intent.ACTION_POWER_DISCONNECTED);

        registerReceiver(receiver, intentFilter);

        startAlert();

        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);

        AlarmUtils utils = new AlarmUtils();
        utils.addReminder(this, hour, minute, day, year, month);

        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.R) {
            int level = get_battery();
            String date = getDate();
            int hours = gethours();

            if (hours <= 24 && level <= 100) {

                for (int i = 0; i < applicationDatabase.batteryDao().getAllBatteryList().size(); i++) {
                    if (applicationDatabase.batteryDao().getAllBatteryList().get(i).getDate().equals(date)) {
                        if (applicationDatabase.batteryDao().getAllBatteryList().get(i).getHours() == hours) {
                            applicationDatabase.batteryDao().deleteByUserId(applicationDatabase.batteryDao().getAllBatteryList().get(i).getId());
                        }
                    }
                }
                applicationDatabase.batteryDao().battery_insert(new BatteryModel(hours, level, date));
            }
        }

        /*cardLargeFiles.setOnClickListener(v -> {
//            new AdLoaderClass().showInterstitialAds(DashBoardActivity.this, new Intent(DashBoardActivity.this, largeFileActivity.class));
            startActivity(new Intent(DashBoardActivity.this, largeFileActivity.class));
        });

        cardDuplicates.setOnClickListener(v -> {
//            startActivity(new Intent(DashBoardActivity.this, ScanActivity.class).putExtra(Constants.SCAN_TYPE, Constants.Type.IMAGE) );
            storagePermission("storage_cleaner", "DuplicateImage");
        });*/

        cardAppLocker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                checkPermissions();

                /*if (Build.VERSION.SDK_INT >= 21) {
                    if ((Build.MANUFACTURER + " " + Build.MODEL).toLowerCase().contains("Sony".toLowerCase())) {
                        if (needPermissionForBlocking(getApplicationContext())) {
                            hasPermissionToUsageAccess();
                            return;
                        }
                        return;
                    }
                    hasPermissionToUsageAccess();
                }*/

                if (!isAccessGranted() || !Settings.canDrawOverlays(DashBoardActivity.this)) {
                    startActivity(new Intent(DashBoardActivity.this, AllPermissionForSingleClickActivity.class).putExtra("app_lock", "AppLock"));
                } else if (!Settings.canDrawOverlays(DashBoardActivity.this)) {
                    startActivity(new Intent(DashBoardActivity.this, AllPermissionForSingleClickActivity.class).putExtra("app_lock", "AppLock"));
                } else if (isAccessGranted() && Settings.canDrawOverlays(DashBoardActivity.this)) {
                    new AdLoaderClass().showInterstitialAds(DashBoardActivity.this, new Intent(DashBoardActivity.this, StartAppLock.class));
//                    startActivity(new Intent(DashBoardActivity.this, StartAppLock.class));
                }
//                startActivity(new Intent(DashBoardActivity.this, com.cleaner.phonecleaner.cleanmaster.applock.activities.main.SplashActivity.class));
//                finish();
            }
        });

        TextView tvBatteryPercentageProgress = findViewById(R.id.tvBatteryPercentageProgress);
        TextView tvStoragePercentage = findViewById(R.id.tvStoragePercentage);
        TextView tvSystemSize = findViewById(R.id.tvSystemSize);
        TextView tvDayCount = findViewById(R.id.tvDayCount);
        TextView tvBatteryPercentage = findViewById(R.id.tvBatteryPercentage);
        BatteryManager batteryManager = (BatteryManager) getSystemService(Context.BATTERY_SERVICE);
//
        int batteryLevel = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
//
        double batteryremainging = ((batteryLevel) * 14.4) / 60;
        String s = String.valueOf(batteryremainging);

        String hourss = s.substring(0, s.indexOf('.'));

        double it = batteryremainging - Integer.parseInt(hourss);
        double minutess = (it * 60 * 100) / 100;
        String minutes = String.valueOf(minutess).substring(0, s.indexOf('.'));

        tvBatteryPercentage.setText("" + batteryLevel + "%");
        tvBatteryPercentageProgress.setText("" + batteryLevel + "%");
        tvDayCount.setText(hourss + " h " + minutes.replace(".", "") + getString(R.string.m_estimated_battery));

        tvSystemSize.setText(" " + getAvailableInternalMemorySize() + " " + getString(R.string.useds) + getTotalInternalMemorySize() + " " + getString(R.string.total));

        tvStoragePercentage.setText("" + getUsedStoragePercentage() + "%");

        seekbar = findViewById(R.id.seekBar0);
        seekbar.getThumb().mutate().setAlpha(0);

        mProgressItem = new ProgressItem();
        mProgressItem.progressItemPercentage = (100 - batteryLevel);
        mProgressItem.color = R.color.transparent;
        progressItemList.add(mProgressItem);

        mProgressItem = new ProgressItem();
        mProgressItem.progressItemPercentage = batteryLevel;
        mProgressItem.color = R.color.blue;
        progressItemList.add(mProgressItem);

        seekbar.initData(progressItemList);
        seekbar.invalidate();

    }


    private void loadBanner() {
        if (new SessionHelper(DashBoardActivity.this).getStringData(SessionHelper.IS_HOME_NATIVE_ON).equals("1")){

            FrameLayout banner_layout = findViewById(R.id.frame_native);
            new NativeLoadWithShows(this).showNativeAdsShimmerEffects(this, banner_layout, 3);
            new NativeLoadWithShows(this).showNativeTopAlways(this, banner_layout,findViewById(R.id.frame));
        }else {
            findViewById(R.id.frame).setVisibility(View.GONE);
            FrameLayout banner_layout = findViewById(R.id.frame_banner);
            new AdUtils().loadMediumBanner(this, banner_layout);
        }
    }

    public static boolean needPermissionForBlocking(Context context) {
        return ((AppOpsManager) context.getSystemService(Context.APP_OPS_SERVICE)).checkOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), context.getPackageName()) == 0;
    }

    private boolean hasPermissionToUsageAccess() {
        final AppOpsManager appOpsManager = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
        if (appOpsManager.checkOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), getPackageName()) == 0) {
            return true;
        }
        appOpsManager.startWatchingMode("android:get_usage_stats", getApplicationContext().getPackageName(), new AppOpsManager.OnOpChangedListener() {
            @Override
            public void onOpChanged(String op, String packageName) {
                if (appOpsManager.checkOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), getPackageName()) != 0) {
                    return;
                }
                appOpsManager.stopWatchingMode(this);
                if ("xiaomi".equals(Build.MANUFACTURER.toLowerCase(Locale.ROOT))) {
                    return;
                }
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, 0);
            }
        });
        requestAccessPermission();
        return false;
    }

    private void requestAccessPermission() {
        try {
            startActivity(new Intent("android.settings.USAGE_ACCESS_SETTINGS"));
            new Handler(Looper.myLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(DashBoardActivity.this, "received", Toast.LENGTH_SHORT).show();
                }
            }, 1200L);
        } catch (Exception unused) {
        }
    }

    private void requestOverlaayAccessPermission() {
        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
        startActivityForResult(intent, 0);
    }

    private void requestMutePermissions() {
        try {
            requestForDoNotDisturbPermissionOrSetDoNotDisturbForApi23AndUp();
        } catch (SecurityException unused) {
        }
    }

    private void soundModeAction() {
        try {
            int ringerMode = audioManager.getRingerMode();
            if (ringerMode == 0) {
                img_sound.setImageResource(R.drawable.ic_speaker);

                audioManager.setRingerMode(2);
            } else if (ringerMode == 1) {
                img_sound.setImageResource(R.drawable.ic_mute);
                audioManager.setRingerMode(0);
            } else if (ringerMode == 2) {
                img_sound.setImageResource(R.drawable.ic_vibrate);
                audioManager.setRingerMode(1);
            }
        } catch (Exception unused) {
        }
    }

    public static void openAndroidPermissionsMenu(Context context) {
        try {

            AdconfigApplication.Companion.disabledOpenAds();
            context.startActivity(new Intent("android.settings.action.MANAGE_WRITE_SETTINGS", Uri.parse("package:" + context.getPackageName())));
//            context.startActivity(new Intent(context, PermissionActivity.class));
        } catch (Exception unused) {
        }
    }

    private boolean isAutoRotateModeOn(Context context2) {
        return Settings.System.getInt(context2.getContentResolver(), "accelerometer_rotation", 0) != 0;
    }

    private ContentObserver rotateObserver = new ContentObserver(new Handler()) {
        public void onChange(boolean z) {
            updateAutoRotateImage();
        }
    };

    public void updateAutoRotateImage() {
        try {
            if (isAutoRotateModeOn(this)) {
                this.img_rotate.setBackground(getResources().getDrawable(R.drawable.ic_bg_round_selected));
//                img_rotate.setColorFilter(ContextCompat.getColor(DashBoardActivity.this, R.color.selected_icon_color), android.graphics.PorterDuff.Mode.SRC_IN);
            } else {
                this.img_rotate.setBackground(getResources().getDrawable(R.drawable.ic_bg_round_unselected));
//                img_rotate.setColorFilter(ContextCompat.getColor(DashBoardActivity.this, R.color.textcolor), android.graphics.PorterDuff.Mode.SRC_IN);
            }
        } catch (Exception unused) {
        }
    }

    public void updateLocationImage() {
        try {
            boolean gps_enabled = locationManager.isProviderEnabled("gps");
            boolean isProviderEnabled = locationManager.isProviderEnabled("network");
            if (gps_enabled || isProviderEnabled) {
                img_gps.setBackground(getResources().getDrawable(R.drawable.ic_bg_round_selected));
//                img_gps.setColorFilter(ContextCompat.getColor(DashBoardActivity.this, R.color.selected_icon_color), android.graphics.PorterDuff.Mode.SRC_IN);
            } else {
                img_gps.setBackground(getResources().getDrawable(R.drawable.ic_bg_round_unselected));
//                img_gps.setColorFilter(ContextCompat.getColor(DashBoardActivity.this, R.color.textcolor), android.graphics.PorterDuff.Mode.SRC_IN);
            }
        } catch (Exception unused) {
        }
    }

    public void updateBluetoothImage() {
        BluetoothAdapter bluetoothAdapter2 = this.bluetoothAdapter;
        if (bluetoothAdapter2 == null || !bluetoothAdapter2.isEnabled()) {
            img_bluthooth.setBackground(getResources().getDrawable(R.drawable.ic_bg_round_unselected));
//            img_bluthooth.setColorFilter(ContextCompat.getColor(DashBoardActivity.this, R.color.textcolor), android.graphics.PorterDuff.Mode.SRC_IN);
        } else {
            img_bluthooth.setBackground(getResources().getDrawable(R.drawable.ic_bg_round_selected));
//            img_bluthooth.setColorFilter(ContextCompat.getColor(DashBoardActivity.this, R.color.selected_icon_color), android.graphics.PorterDuff.Mode.SRC_IN);
        }
    }

    public void updateAirplaneImage() {
        try {
            if (isAirplaneModeOn(DashBoardActivity.this)) {
                img_airplane.setBackground(getResources().getDrawable(R.drawable.ic_bg_round_selected));
//                img_airplane.setColorFilter(ContextCompat.getColor(DashBoardActivity.this, R.color.selected_icon_color), android.graphics.PorterDuff.Mode.SRC_IN);
            } else {
                img_airplane.setBackground(getResources().getDrawable(R.drawable.ic_bg_round_unselected));
//                img_airplane.setColorFilter(ContextCompat.getColor(DashBoardActivity.this, R.color.textcolor), android.graphics.PorterDuff.Mode.SRC_IN);
            }
        } catch (Exception unused) {
        }
    }

    public static boolean isAirplaneModeOn(Context context) {
        return Settings.Global.getInt(context.getContentResolver(),
                Settings.Global.AIRPLANE_MODE_ON, 0) != 0;
    }

    private BroadcastReceiver DeviceChangeReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals("android.bluetooth.adapter.action.STATE_CHANGED")) {
                updateBluetoothImage();
            }
            if (intent.getAction().equals("android.media.RINGER_MODE_CHANGED")) {
                soundModeStatus();
            }
            if (intent.getAction().equals("android.location.PROVIDERS_CHANGED")) {
                updateLocationImage();
            }
            if (intent.getAction().equals("android.intent.action.AIRPLANE_MODE")) {
                updateAirplaneImage();
            }
        }
    };

    public void ResRecevie() {
        registerReceiver(this.DeviceChangeReceiver, new IntentFilter("android.bluetooth.adapter.action.STATE_CHANGED"));
        registerReceiver(this.DeviceChangeReceiver, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
        registerReceiver(this.DeviceChangeReceiver, new IntentFilter("android.location.PROVIDERS_CHANGED"));
        registerReceiver(this.DeviceChangeReceiver, new IntentFilter("android.intent.action.AIRPLANE_MODE"));
        registerReceiver(this.DeviceChangeReceiver, new IntentFilter("android.media.RINGER_MODE_CHANGED"));
        getContentResolver().registerContentObserver(Settings.System.getUriFor("accelerometer_rotation"), true, this.rotateObserver);

        updateBluetoothImage();
        updateLocationImage();

        updateAirplaneImage();
    }

    public void onPause() {
        super.onPause();

        Log.e("IronBanner", "onPause dash");
        stopRes();
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    public void soundModeStatus() {
        int ringerMode = this.audioManager.getRingerMode();
        if (ringerMode == 0) {
            img_sound.setImageResource(R.drawable.ic_mute);
        } else if (ringerMode == 1) {
            img_sound.setImageResource(R.drawable.ic_vibrate);
        } else if (ringerMode == 2) {
            img_sound.setImageResource(R.drawable.ic_speaker);
        }
    }

    public void stopRes() {
        unregisterReceiver(this.DeviceChangeReceiver);
        getContentResolver().unregisterContentObserver(this.rotateObserver);
    }

    @RequiresApi(api = Build.VERSION_CODES.S)
    private boolean isBluetoothPermissionGranted() {
        boolean granted = false;
        int bluetoothGranted = checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT);

        if (bluetoothGranted == PackageManager.PERMISSION_GRANTED) {
            granted = true;
        }

        return granted;
    }

    @RequiresApi(api = Build.VERSION_CODES.S)
    private void askForBluetoothPermissions() {
        String[] permissions = new String[]{Manifest.permission.BLUETOOTH_CONNECT
        };
        requestPermissions(permissions, PERMISSION_ASK);
    }

    /*@Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == PERMISSION_ASK) {
            // all requested permissions were granted
            // perform your task here
            // permissions not granted
            // DO NOT PERFORM THE TASK, it will fail/crash
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }*/

    private void requestForDoNotDisturbPermissionOrSetDoNotDisturbForApi23AndUp() {
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager.isNotificationPolicyAccessGranted()) {
            soundModeAction();
        } else {
            AdconfigApplication.Companion.disabledOpenAds();
            try {
                Intent intent = new Intent(
                        Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS);
                startActivityForResult(intent,ON_DO_NOT_DISTURB_CALLBACK_CODE);
            } catch(ActivityNotFoundException e) {
            }
        }
    }

    @Override
    public void onResume() {

        String themess = sharedPref.getString("theme", "light");
        switch (themess) {
            case "light":
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                break;
            case "dark":
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                break;
            case "dafault":
                UiModeManager uiModeManager = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
                if (uiModeManager.getNightMode() == UiModeManager.MODE_NIGHT_YES) {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                } else {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                }
                break;
        }

        if (isAirplaneModeOn(DashBoardActivity.this)) {
            img_airplane.setBackground(getResources().getDrawable(R.drawable.ic_bg_round_selected));
//            img_airplane.setColorFilter(ContextCompat.getColor(DashBoardActivity.this, R.color.selected_icon_color), android.graphics.PorterDuff.Mode.SRC_IN);
        } else {
            img_airplane.setBackground(getResources().getDrawable(R.drawable.ic_bg_round_unselected));
//            img_airplane.setColorFilter(ContextCompat.getColor(DashBoardActivity.this, R.color.textcolor), android.graphics.PorterDuff.Mode.SRC_IN);
        }

        SharedPreferences sharedPrefs = getSharedPreferences("language", MODE_PRIVATE);
        String s1 = sharedPrefs.getString("selectedlanguage", "");
        LocaleHelper.setLocale(this, s1);

        ResRecevie();
        super.onResume();
        new Utils().disebledOpenAdsBasedOnFireBase();

        Log.e("IronBanner", "onResume dash");
    }


    private int gethours() {
        Date date = new Date();
        SimpleDateFormat gethours = new SimpleDateFormat("HH");
        return Integer.parseInt(gethours.format(date));
    }

    private String getDate() {
        Date date = new Date();
        SimpleDateFormat getdate = new SimpleDateFormat("dd:MM:yyyy");
        return getdate.format(date);
    }

    public int get_battery() {
        IntentFilter iFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = registerReceiver(null, iFilter);

        return batteryStatus != null ? batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) : -1;
    }

    public void startAlert() {
        Intent intent = new Intent(this, Alarm.class);
        PendingIntent pendingIntent;
        if (Build.VERSION.SDK_INT >= 31) {
            pendingIntent = PendingIntent.getBroadcast(this, 234, intent, PendingIntent.FLAG_IMMUTABLE);
        } else {
            pendingIntent = PendingIntent.getBroadcast(this, 234, intent, PendingIntent.FLAG_IMMUTABLE);
        }

        AlarmManager alarmManager = (AlarmManager) this.getSystemService(ALARM_SERVICE);
        if (alarmManager != null) {
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, 1000 * 20, 1000 * 20, pendingIntent);
        }
    }

    public void stopAlert() {
        Intent intent = new Intent(this, Alarm.class);
        PendingIntent sender = null;
        if (Build.VERSION.SDK_INT >= 31) {
            sender = PendingIntent.getBroadcast(this, 234, intent, PendingIntent.FLAG_IMMUTABLE);
        } else {
            sender = PendingIntent.getBroadcast(this, 234, intent, PendingIntent.FLAG_IMMUTABLE);

        }

        AlarmManager alarmManager = (AlarmManager) this.getSystemService(ALARM_SERVICE);
        if (alarmManager != null) {
            alarmManager.cancel(sender);
        }
    }

    private boolean isNotificationAccessGiven() {
        try {
            boolean enabled = false;
            Set<String> enabledListenerPackagesSet = NotificationManagerCompat.getEnabledListenerPackages(getApplicationContext());
            for (String string : enabledListenerPackagesSet)
                if (string.contains(getPackageName())) enabled = true;
            return enabled;
        } catch (Exception e) {
            Log.d("Error Line Number", Log.getStackTraceString(e));
        }
        return true;
    }

    public void loaddata() {
        Executors.newSingleThreadExecutor().execute(() -> {
            appList.addAll(new ApkInfoExtractor(DashBoardActivity.this).GetAllInstalledApkInfo());
            get_FinalAppList();
            getApplicationList();

        });

    }

    private void getApplicationList() {
        applicationlist.clear();
        for (int i = 0; i < applicationDatabase.applicationDao().getAllappList().size(); i++) {
            ApplicationModel applicationModel = applicationDatabase.applicationDao().getAllappList().get(i);
            applicationlist.add(applicationModel);
        }
    }

    private void get_FinalAppList() {
        applicationlist.clear();
        if (applicationDatabase.applicationDao().getAllappList().size() == 0) {
            for (int i = 0; i < appList.size(); i++) {
                Log.d("fsdfsfwer", "get_FinalAppList: " + appList.get(i));
                ApplicationModel applicationModel = new ApplicationModel(appList.get(i).getApp_package(), appList.get(i).getApp_name(), 0, false);
                applicationDatabase.applicationDao().application_insert(applicationModel);
            }
            if (applicationDatabase.blockListDao() != null && applicationDatabase.blockListDao().getAllBlockList().size() == 0) {
                applicationDatabase.blockListDao().block_insert(new BlockListModel("BLOCK_ALL", "no"));
            } else {
                applicationDatabase.blockListDao().updateUsingID("no");
            }
        } else {
            if (appList.size() == 0) {
                for (int i = 0; i < applicationDatabase.applicationDao().getAllappListSortDesc().size(); i++) {
                    applicationlist.add(applicationDatabase.applicationDao().getAllappListSortDesc().get(i));
                }
            } else {
                applicationlist.clear();
                for (int i = 0; i < applicationDatabase.applicationDao().getAllappListSortDesc().size(); i++) {
                    applicationlist.add(applicationDatabase.applicationDao().getAllappListSortDesc().get(i));
                }
            }
        }
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleHelper.onAttach(base, "en"));
    }

    public void switchFlashLight(boolean status) {
        try {
            mCameraManager.setTorchMode(mCameraId, status);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onBackPressed() {
        /*if (getReviewCounter() != 0) {
            //tag 0 for exit rating dialog && tag 1 for setting rating dialog
            new Myapplication().disabledOpenAds();
            openRateDialog(0);
        } else {*/
        showExitDialog();
        //}
    }

    int ratecount = 0;

    private void getReviewInfo() {
        reviewManager = ReviewManagerFactory.create(getApplicationContext());
        Task<ReviewInfo> manager = reviewManager.requestReviewFlow();
        manager.addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                reviewInfo = task.getResult();
            }
        });
    }

    public void startReviewFlow() {
        if (reviewInfo != null) {
            Task<Void> flow = reviewManager.launchReviewFlow(this, reviewInfo);
            flow.addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
//                    Toast.makeText(getApplicationContext(), "In App Rating complete", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName())));

                    SharedPreferences.Editor editor = sharedpreferences.edit();
                    editor.putBoolean("isRateComplete", true);
                    editor.apply();
                }
            });
        } else {
            Toast.makeText(getApplicationContext(), "In App Rating failed", Toast.LENGTH_LONG).show();
        }
    }

    public void showExitDialog() {
        final View dialogView = getLayoutInflater().inflate(R.layout.dialog_exit, null);
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);

        TextView buttonCancel = dialogView.findViewById(R.id.buttonCancel);
        TextView buttonOk = dialogView.findViewById(R.id.buttonOk);

        buttonCancel.setOnClickListener(view1 -> alertDialog.dismiss());

        buttonOk.setOnClickListener(view12 -> {
            alertDialog.dismiss();
            finishAffinity();
        });

        builder.setView(dialogView);
        alertDialog = builder.create();

        InsetDrawable inset = new InsetDrawable(new ColorDrawable(Color.TRANSPARENT), 40);
        alertDialog.getWindow().setBackgroundDrawable(inset);
        alertDialog.show();
    }

    /*@Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 101) {
            Toast.makeText(this, "", Toast.LENGTH_SHORT).show();
        }
    }*/

    public boolean isAccessGranted() {
        AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
        int mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), getPackageName());
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    public void storagePermission(String key, String value) {
        if (SDK_INT <= Build.VERSION_CODES.Q) {
            int write = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
            int read = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);

            if (write != PackageManager.PERMISSION_GRANTED && read != PackageManager.PERMISSION_GRANTED) {
                startActivity(new Intent(DashBoardActivity.this, AllPermissionForSingleClickActivity.class).putExtra(key, value));
            } else {
                if (value.equals("StorageCleaner")) {
                    new AdLoaderClass().showInterstitialAds(DashBoardActivity.this, new Intent(DashBoardActivity.this, StorageCleanerActivity.class));
//                    startActivity(new Intent(DashBoardActivity.this, StorageCleanerActivity.class));
                }
            }
        }

        if (SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                startActivity(new Intent(DashBoardActivity.this, AllPermissionForSingleClickActivity.class).putExtra(key, value));
            } else {
                if (value.equals("StorageCleaner")) {
                    new AdLoaderClass().showInterstitialAds(DashBoardActivity.this, new Intent(DashBoardActivity.this, StorageCleanerActivity.class));
//                    startActivity(new Intent(DashBoardActivity.this, StorageCleanerActivity.class));
                }
            }
        }
    }

    public void storagePermissionAppCleaner() {
        if (SDK_INT <= Build.VERSION_CODES.Q) {
            int write = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
            int read = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);

            if (write != PackageManager.PERMISSION_GRANTED && read != PackageManager.PERMISSION_GRANTED) {
                startActivity(new Intent(DashBoardActivity.this, AllPermissionForSingleClickActivity.class).putExtra("app_cleaner", "AppCleaner"));
            } else {
                if (Utils.appInstalledOrNot(DashBoardActivity.this)) {
                    new AdLoaderClass().showInterstitialAds(DashBoardActivity.this, new Intent(DashBoardActivity.this, AppCleanLastFolderWiseDataActivity.class).putExtra("AppName", "WhatsApp"));
//                    startActivity(new Intent(DashBoardActivity.this, AppCleanerActivity.class).putExtra("AppName", "WhatsApp"));
                } else {
                    Toast.makeText(this, "WhatApp Not Installed", Toast.LENGTH_SHORT).show();
                }
            }
        }

        if (SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                new AdLoaderClass().showInterstitialAds(DashBoardActivity.this, new Intent(DashBoardActivity.this, AllPermissionForSingleClickActivity.class).putExtra("app_cleaner", "AppCleaner"));
//                startActivity(new Intent(DashBoardActivity.this, AllPermissionForSingleClickActivity.class).putExtra("app_cleaner", "AppCleaner"));
            } else {
                if (Utils.appInstalledOrNot(DashBoardActivity.this)) {
                    new AdLoaderClass().showInterstitialAds(DashBoardActivity.this, new Intent(DashBoardActivity.this, AppCleanLastFolderWiseDataActivity.class).putExtra("AppName", "WhatsApp"));
//                    startActivity(new Intent(DashBoardActivity.this, AppCleanerActivity.class).putExtra("AppName", "WhatsApp"));
                } else {
                    Toast.makeText(this, "WhatApp Not Installed", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_PERMISSIONS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (UsageAccessHelper.isUsageAccessGranted(this)) {
                    Toast.makeText(this, "receieved", Toast.LENGTH_SHORT).show();
                    // Permission granted, perform required actions
                    // For example, enable a feature that requires usage access permission
                } else {
                    // Permission revoked, show an error or take appropriate action
                }
            } else {
                // Permission denied, show an error or take appropriate action
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_USAGE_ACCESS) {
            Toast.makeText(this, "receieved", Toast.LENGTH_SHORT).show();
            UsageAccessHelper.handlePermissionResult(this, requestCode);
        }

        if (requestCode == 101) {
            if (isNotificationAccessGiven()) {
                startActivity(new Intent(DashBoardActivity.this, CleanNotification.class).putExtra("new", "old_user"));
            }
        }
    }

    private void checkPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.PACKAGE_USAGE_STATS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.PACKAGE_USAGE_STATS},
                    REQUEST_PERMISSIONS);
        } else {
            // Permission already granted
            if (UsageAccessHelper.isUsageAccessGranted(this)) {
                //Permission granted, perform required actions
                //For example, enable a feature that requires usage access permission
            } else {
                //Permission revoked, show an error or take appropriate action
            }
        }
    }

    public void open_Notification_Access_Setting() {
//        new Myapplication().disabledOpenAds();
        startActivityForResult(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"), 101);
    }

    public static int getUsedStoragePercentage() {
        File path = Environment.getExternalStorageDirectory();
        StatFs stat = new StatFs(path.getPath());

        long blockSize = stat.getBlockSizeLong();
        long totalBlocks = stat.getBlockCountLong();
        long availableBlocks = stat.getAvailableBlocksLong();

        long usedBlocks = totalBlocks - availableBlocks;
        long usedSpace = usedBlocks * blockSize;

        int usedStoragePercentage = Math.round((float) usedSpace / (float) (totalBlocks * blockSize) * 100.0f);

        return usedStoragePercentage;
    }
}