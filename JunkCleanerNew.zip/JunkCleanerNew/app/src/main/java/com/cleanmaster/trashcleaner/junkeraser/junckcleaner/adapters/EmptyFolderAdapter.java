package com.cleanmaster.trashcleaner.junkeraser.junckcleaner.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.junckcleaner.interfaces.SelectAll;
import com.cleanmaster.trashcleaner.junkeraser.junckcleaner.models.FileModel;
import com.cleanmaster.trashcleaner.junkeraser.utils.Util;

import java.io.File;
import java.util.List;

public class EmptyFolderAdapter extends ListAdapter<FileModel, EmptyFolderAdapter.FileHolder> {
    Context context;
    View view;
    FileHolder holder;
    String type;

    SelectAll selectAll;
    double total = 0f;

    List<FileModel> killingApps;
    List<FileModel> adapterApps;

    public EmptyFolderAdapter(Context context, List<FileModel> killingApps, List<FileModel> adapterApps, String type, double total) {
        super(DIFF_CALLBACK);
        this.context = context;
        this.killingApps = killingApps;
        this.adapterApps = adapterApps;
        this.type = type;
        this.total = total;
    }

    public double getAllTotal() {
        double appTotal = 0f;
        for (FileModel app : killingApps) {
            appTotal += app.getSize();
        }
        return appTotal;
    }

    public double getTotal() {
        return total;
    }

    public static final DiffUtil.ItemCallback<FileModel> DIFF_CALLBACK = new DiffUtil.ItemCallback<FileModel>() {
        @Override
        public boolean areItemsTheSame(@NonNull FileModel oldItem, @NonNull FileModel newItem) {
            return oldItem.equals(newItem);
        }

        @SuppressLint("DiffUtilEquals")
        @Override
        public boolean areContentsTheSame(@NonNull FileModel oldItem, @NonNull FileModel newItem) {
            return oldItem.equals(newItem);
        }
    };


    public void setAdapterApps(List<FileModel> adapterApps) {
        this.adapterApps = adapterApps;
    }

    public void setKillingApps(List<FileModel> killingApps) {
        this.killingApps = killingApps;
    }

    public List<FileModel> getKillingApps() {
        return killingApps;
    }

    public void clearFile() {
//        Log.e("JunkAdapter1", "clearFile-->"+type);
        for (FileModel fileModel : killingApps) {
            File file = new File(fileModel.getPath());
            try {
                if (file.exists()) {
                    if (file.delete()) {
//                        Log.e("JunkAdapter1", "clearFile-done:" + file.getPath());
                    } else {
//                        Log.e("JunkAdapter1", "clearFile-error:" + file.getPath());
                    }
                }
            } catch (Exception e) {
//                Log.e("JunkAdapter1", "clearFile-type:" + type);
//                Log.e("JunkAdapter1", "clearFile-Exception:" + e);
            }
        }
//        Log.e("JunkAdapter1", "clearFile-->exit");
    }

    @NonNull
    @Override
    public FileHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_item_1, parent, false);
        holder = new FileHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull FileHolder holder, int position) {
        holder.textView_app_name.setText(getItem(position).getPath());
        holder.textView_app_path.setText(getItem(position).getPath());
        holder.textView_app_name.setSelected(true);
        holder.textView_app_path.setSelected(true);
        holder.picture.setImageResource(R.drawable.ic_folder);
        holder.checkbox.setChecked(killingApps.contains(getItem(position)));
        Pair<String, String> size = Util.getDataSizeWithPrefix(context, (float) getItem(position).getSize());
        holder.textView_size.setText(size.first + " " + size.second);

        holder.itemView.setOnClickListener(v -> {
            if (killingApps.contains(getItem(position))) {
                killingApps.remove(getItem(position));
                total = total - getItem(position).getSize();
                selectAll.selectAll(false, type);
                holder.checkbox.setChecked(false);
            } else {
                holder.checkbox.setChecked(true);
                killingApps.add(getItem(position));
                total = total + getItem(position).getSize();
                if (killingApps.size() == getCurrentList().size()) {
                    selectAll.selectAll(true, type);
                } else {
                    selectAll.selectAll(false, type);
                }
            }
            notifyItemChanged(position);
        });

    }

    public void selectAll() {
        if (!killingApps.isEmpty()) {
            killingApps.clear();
        }

        killingApps.addAll(adapterApps);
        notifyDataSetChanged();

    }

    public void clearList() {
        if (!killingApps.isEmpty()) {
            killingApps.clear();
        }
        notifyDataSetChanged();
    }


    static class FileHolder extends RecyclerView.ViewHolder {
        ImageView picture;
        CheckBox checkbox;
        TextView textView_app_name, textView_app_path, textView_size;

        public FileHolder(@NonNull View itemView) {
            super(itemView);
            checkbox = itemView.findViewById(R.id.checkbox);
            textView_app_name = itemView.findViewById(R.id.textView_app_name);
            textView_app_path = itemView.findViewById(R.id.textView_app_path);
            textView_size = itemView.findViewById(R.id.textView_size);
            picture = itemView.findViewById(R.id.picture);

        }
    }

    public void setSelectAll(SelectAll selectAll) {
        this.selectAll = selectAll;
    }

}
