package com.cleanmaster.trashcleaner.junkeraser.activity;

import static android.content.ContentValues.TAG;
import static java.util.jar.Pack200.Packer.ERROR;

import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.telephony.PhoneStateListener;
import android.telephony.ServiceState;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.helper.LocaleHelper;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.text.DecimalFormat;
import java.util.Enumeration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SystemInfoActivity extends BaseActivity {
    public static int icon;
    public static String operator = "";
    TelephonyManager telephonyManager;
    LinearLayout ll_internal, ll_external, ll_ram, ll_system, ll_battery, ll_device_l, ll_opertor, ll_cpu, ll_network;
    ImageView back;
    TextView tv_avi, tv_toi, tv_ave, tv_toe, tv_avr, tv_tor, tv_id, tv_base, tv_me, tv_user, tv_sdk, tv_valtage, tv_status, tv_health, tv_temp, device_name, model_name, brand_name, product_code, imei_no, type, host, fingerprint, network_type, ip_address, mac_address, cpu_info, max_frequency, opretor, country, roaming, service_state;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    IntentFilter intentfilter;
    int batteryVol;
    float fullVoltage;
    int deviceHealth;
    String staussss;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_system_info);

        ll_system = findViewById(R.id.ll_system);
        ll_internal = findViewById(R.id.ll_internal);
        ll_external = findViewById(R.id.ll_external);
        ll_ram = findViewById(R.id.ll_ram);
        tv_avi = findViewById(R.id.tv_avi);
        tv_toi = findViewById(R.id.tv_toi);
        tv_ave = findViewById(R.id.tv_ave);
        tv_toe = findViewById(R.id.tv_toe);
        tv_avr = findViewById(R.id.tv_avr);
        tv_tor = findViewById(R.id.tv_tor);
        tv_sdk = findViewById(R.id.tv_sdk);
        tv_id = findViewById(R.id.tv_id);
        tv_base = findViewById(R.id.tv_base);
        tv_me = findViewById(R.id.tv_me);
        tv_user = findViewById(R.id.tv_user);
        cpu_info = findViewById(R.id.cpu_info);
        ll_battery = findViewById(R.id.ll_battery);
        tv_health = findViewById(R.id.tv_health);
        tv_valtage = findViewById(R.id.tv_voltage);
        tv_temp = findViewById(R.id.tv_temp);
        tv_status = findViewById(R.id.tv_status);
        ll_device_l = findViewById(R.id.ll_device_s);
        max_frequency = findViewById(R.id.max_frequency);
        opretor = findViewById(R.id.opretor);
        device_name = findViewById(R.id.device_name);
        model_name = findViewById(R.id.model_name);
        brand_name = findViewById(R.id.brand_name);
        product_code = findViewById(R.id.product);
        type = findViewById(R.id.type);
        host = findViewById(R.id.host);
        fingerprint = findViewById(R.id.fingerprint);
        imei_no = findViewById(R.id.imei_no);
        country = findViewById(R.id.country);
        roaming = findViewById(R.id.roaming);
        ll_opertor = findViewById(R.id.ll_opretor);
        service_state = findViewById(R.id.service_state);
        ll_cpu = findViewById(R.id.ll_cpu);
        sharedPreferences = getSharedPreferences("images", MODE_PRIVATE);
        ll_network = findViewById(R.id.ll_network);
        network_type = findViewById(R.id.network_type);
        ip_address = findViewById(R.id.ip_address);
        mac_address = findViewById(R.id.mac_address);

        editor = sharedPreferences.edit();

        back = findViewById(R.id.btn_back);

        back.setOnClickListener(v -> {
            onBackPressed();
        });

//network
        ll_network.setVisibility(View.GONE);
//cpu
        ll_cpu.setVisibility(View.VISIBLE);
        cpu_info.setText(

                ReadCPUinfo());
        String cpuMaxFreq = "";
        RandomAccessFile reader = null;
        try {
            reader = new RandomAccessFile("/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq", "r");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        try {
            if (reader != null) {
                cpuMaxFreq = reader.readLine();
                reader.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        max_frequency.setText(cpuMaxFreq);

        //operator
        ll_opertor.setVisibility(View.VISIBLE);
        telephonyManager = (TelephonyManager)

                getSystemService(Context.TELEPHONY_SERVICE);

        opretor.setText("" + telephonyManager.getNetworkOperatorName());
        String countryCodeValue = telephonyManager.getNetworkCountryIso();
        country.setText(countryCodeValue);
        if (telephonyManager.isNetworkRoaming() == true) {
            roaming.setText("Roaming");
        } else {
            roaming.setText("Not Roaming");
        }
        telephonyManager.listen(new PhoneStateListener() {

            @Override
            public void onServiceStateChanged(ServiceState serviceState) {
                super.onServiceStateChanged(serviceState);
                String phonestate;

                switch (serviceState.getState()) {
                    case ServiceState.STATE_EMERGENCY_ONLY:
                        phonestate = "STATE_EMERGENCY_ONLY";
                        service_state.setText(phonestate);
                        break;
                    case ServiceState.STATE_IN_SERVICE:
                        phonestate = "STATE_IN_SERVICE";
                        service_state.setText(phonestate);
                        break;
                    case ServiceState.STATE_OUT_OF_SERVICE:
                        phonestate = "STATE_OUT_OF_SERVICE";
                        service_state.setText(phonestate);
                        break;
                    case ServiceState.STATE_POWER_OFF:
                        phonestate = "STATE_POWER_OFF";
                        service_state.setText(phonestate);
                        break;
                    default:
                        phonestate = "Unknown";
                        service_state.setText(phonestate);
                        break;
                }
            }
        }, PhoneStateListener.LISTEN_SERVICE_STATE);


        //device
        ll_device_l.setVisibility(View.VISIBLE);
        device_name.setText(Build.BRAND);
        model_name.setText(Build.SERIAL);
        brand_name.setText(Build.BRAND);
        product_code.setText(Build.VERSION.RELEASE);
        imei_no.setText(Build.BOARD);
        type.setText(Build.TYPE);
        host.setText(Build.HOST);
        fingerprint.setText(Build.FINGERPRINT);

        //battry
        ll_battery.setVisibility(View.VISIBLE);
        intentfilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);

        registerReceiver(broadcastreceiver, intentfilter);

        //system
        ll_system.setVisibility(View.VISIBLE);
        tv_user.setText(Build.USER + "");
        tv_sdk.setText(Build.VERSION.SDK + "");
        tv_base.setText(Build.VERSION_CODES.BASE + "");
        tv_id.setText(Build.ID + "");
        tv_me.setText(Build.MANUFACTURER + "");

        //internal
        ll_internal.setVisibility(View.VISIBLE);
        tv_avi.setText(getAvailableInternalMemorySize());
        tv_toi.setText(getTotalInternalMemorySize());

        //external

//        if (isMemoryCardAvailable()) {

        Log.d(TAG, "isExternalStorageAvailable internal: " + getAvailableInternalStorage());
        Log.d(TAG, "isExternalStorageAvailable external: " + getAvailableExternalStorage());

        ll_external.setVisibility(View.GONE);
        tv_ave.setText(
                getAvailableExternalMemorySize());
        tv_toe.setText(
                getTotalExternalMemorySize());


        //ram
        ll_ram.setVisibility(View.VISIBLE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ActivityManager activityManager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        activityManager.getMemoryInfo(mi);
        double availableMegs = mi.availMem / 0x100000L;
//        tv_avr.setText(apapa(String.valueOf(availableMegs)));
        tv_avr.setText(formatFileSize(getAvailableRAM(SystemInfoActivity.this)));
        tv_tor.setText(getTotalRAM());

        //value
        ll_internal.setVisibility(View.VISIBLE);
//        ll_external.setVisibility(View.VISIBLE);
        ll_ram.setVisibility(View.VISIBLE);
        tv_avi.setText(getAvailableInternalMemorySize());
        tv_toi.setText(getTotalInternalMemorySize());
//        tv_ave.setText(getAvailableExternalMemorySize());
//        tv_toe.setText(getTotalExternalMemorySize());
        ActivityManager.MemoryInfo mi1 = new ActivityManager.MemoryInfo();
        ActivityManager activityManager1 = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        activityManager1.getMemoryInfo(mi1);
        double availableMegs1 = mi1.availMem / 0x100000L;
//        tv_avr.setText(apapa(String.valueOf(availableMegs1)));
//        tv_tor.setText(getTotalRAM());

    }

    private BroadcastReceiver broadcastreceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            batteryVol = (int) (intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0));
            fullVoltage = (float) (batteryVol * 0.001);
            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            float batteryPct = level * 100 / (float) scale;
            int temp = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0);
            deviceHealth = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, 0);
            if (deviceHealth == BatteryManager.BATTERY_HEALTH_COLD) {
                staussss = "Cold";
            }
            if (deviceHealth == BatteryManager.BATTERY_HEALTH_DEAD) {
                staussss = "Dead";
            }
            if (deviceHealth == BatteryManager.BATTERY_HEALTH_GOOD) {
                staussss = "Good";
            }
            if (deviceHealth == BatteryManager.BATTERY_HEALTH_OVERHEAT) {
                staussss = "OverHeat";
            }
            if (deviceHealth == BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE) {
                staussss = "Over voltage";
            }
            if (deviceHealth == BatteryManager.BATTERY_HEALTH_UNKNOWN) {
                staussss = "Unknown";
            }
            if (deviceHealth == BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE) {
                staussss = "Unspecified Failure";
            }
            tv_health.setText(staussss);
            tv_status.setText(batteryPct + "%");
            tv_valtage.setText(fullVoltage + " volt");
            tv_temp.setText(batteryTemperature(SystemInfoActivity.this));
        }
    };

    public static String batteryTemperature(Context context) {
        Intent intent = context.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        float temp = ((float) intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)) / 10;
        return temp + " C";
    }

    private String ReadCPUinfo() {
        ProcessBuilder cmd;
        String result = "";

        try {
            String[] args = {"/system/bin/cat", "/proc/cpuinfo"};
            cmd = new ProcessBuilder(args);

            Process process = cmd.start();
            InputStream in = process.getInputStream();
            byte[] re = new byte[1024];
            while (in.read(re) != -1) {
                System.out.println(new String(re));
                result = result + new String(re);
            }
            in.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return result;
    }

    public static String getNetworkClass(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = cm.getActiveNetworkInfo();
        if (info == null || !info.isConnected())
            return "-"; // not connected
        if (info.getType() == ConnectivityManager.TYPE_WIFI)
            return "WIFI";
        if (info.getType() == ConnectivityManager.TYPE_MOBILE) {
            int networkType = info.getSubtype();
            switch (networkType) {
                case TelephonyManager.NETWORK_TYPE_GPRS:
                case TelephonyManager.NETWORK_TYPE_EDGE:
                case TelephonyManager.NETWORK_TYPE_CDMA:
                case TelephonyManager.NETWORK_TYPE_1xRTT:
                case TelephonyManager.NETWORK_TYPE_IDEN:     // api< 8: replace by 11
                case TelephonyManager.NETWORK_TYPE_GSM:      // api<25: replace by 16
                    return "2G";
                case TelephonyManager.NETWORK_TYPE_UMTS:
                case TelephonyManager.NETWORK_TYPE_EVDO_0:
                case TelephonyManager.NETWORK_TYPE_EVDO_A:
                case TelephonyManager.NETWORK_TYPE_HSDPA:
                case TelephonyManager.NETWORK_TYPE_HSUPA:
                case TelephonyManager.NETWORK_TYPE_HSPA:
                case TelephonyManager.NETWORK_TYPE_EVDO_B:   // api< 9: replace by 12
                case TelephonyManager.NETWORK_TYPE_EHRPD:    // api<11: replace by 14
                case TelephonyManager.NETWORK_TYPE_HSPAP:    // api<13: replace by 15
                case TelephonyManager.NETWORK_TYPE_TD_SCDMA: // api<25: replace by 17
                    return "3G";
                case TelephonyManager.NETWORK_TYPE_LTE:      // api<11: replace by 13
                case TelephonyManager.NETWORK_TYPE_IWLAN:    // api<25: replace by 18
                case 19: // LTE_CA
                    return "4G";
                case TelephonyManager.NETWORK_TYPE_NR:       // api<29: replace by 20
                    return "5G";
                default:
                    return "?";
            }
        }
        return "?";
    }

    public static String getLocalIpAddress() {
        try {
            for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements(); ) {
                NetworkInterface intf = en.nextElement();
                for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements(); ) {
                    InetAddress inetAddress = enumIpAddr.nextElement();
                    if (!inetAddress.isLoopbackAddress() && inetAddress instanceof Inet4Address) {
                        return inetAddress.getHostAddress();
                    }
                }
            }
        } catch (SocketException ex) {
            ex.printStackTrace();
        }
        return null;
    }


    public static boolean externalMemoryAvailable() {
        return Environment.getExternalStorageState().equals(
                Environment.MEDIA_MOUNTED);
    }

    public static String getAvailableInternalMemorySize() {
        File path = Environment.getDataDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSizeLong();
        long availableBlocks = stat.getAvailableBlocksLong();
        return formatFileSize(availableBlocks * blockSize);
    }

    public static String getTotalInternalMemorySize() {
        File path = Environment.getDataDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSizeLong();
        long totalBlocks = stat.getBlockCountLong();
        return formatFileSize(totalBlocks * blockSize);
    }

    public static String getAvailableExternalMemorySize() {
        if (externalMemoryAvailable()) {
            File path = Environment.getExternalStorageDirectory();
            StatFs stat = new StatFs(path.getPath());
            long blockSize = stat.getBlockSizeLong();
            long availableBlocks = stat.getAvailableBlocksLong();
            return formatFileSize(availableBlocks * blockSize);
        } else {
            return ERROR;
        }
    }

    public static String getTotalExternalMemorySize() {
        if (externalMemoryAvailable()) {
            File path = Environment.getExternalStorageDirectory();
            StatFs stat = new StatFs(path.getPath());
            long blockSize = stat.getBlockSizeLong();
            long totalBlocks = stat.getBlockCountLong();
            return formatFileSize(totalBlocks * blockSize);
        } else {
            return ERROR;
        }
    }


    public String getTotalRAM() {
        RandomAccessFile reader = null;
        String load = null;
        DecimalFormat twoDecimalForm = new DecimalFormat("#.##");
        double totRam = 0;
        String lastValue = "";
        try {
            reader = new RandomAccessFile("/proc/meminfo", "r");
            if (reader != null) {
                load = reader.readLine();

                // Get the Number value from the string
                Pattern p = Pattern.compile("(\\d+)");
                Matcher m = p.matcher(load);
                String value = "";
                while (m.find()) {
                    value = m.group(1);
                    // System.out.println("Ram : " + value);
                }
                reader.close();
                totRam = Double.parseDouble(value);
            }
            // totRam = totRam / 1024;

            double mb = totRam / 1024.0;
            double gb = totRam / 1048576.0;
            double tb = totRam / 1073741824.0;

            if (tb > 1) {
                lastValue = twoDecimalForm.format(tb).concat(" TB");
            } else if (gb > 1) {
                lastValue = twoDecimalForm.format(gb).concat(" GB");
            } else if (mb > 1) {
                lastValue = twoDecimalForm.format(mb).concat(" MB");
            } else {
                lastValue = twoDecimalForm.format(totRam).concat(" KB");
            }


        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            // Streams.close(reader);
        }

        return lastValue;
    }


/*    @Override
    public void onBackPressed() {
        if (new SessionHelper(this).getStringData(SessionHelper.START_APP_ID).equals("1111")) {
//            new AdMobLoaderClass().showInterstitialOnBackAds(this);
        }
        super.onBackPressed();
    }*/

    public static long getAvailableInternalStorage() {
        File path = Environment.getDataDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSizeLong();
        long availableBlocks = stat.getAvailableBlocksLong();
        return availableBlocks * blockSize;
    }

    public static long getAvailableExternalStorage() {
        if (isExternalStorageAvailable()) {
            File path = Environment.getExternalStorageDirectory();
            StatFs stat = new StatFs(path.getPath());
            long blockSize = stat.getBlockSizeLong();
            long availableBlocks = stat.getAvailableBlocksLong();
            return availableBlocks * blockSize;
        } else {
            return -1; // External storage is not available
        }
    }


    public static boolean isExternalStorageAvailable() {
        String state = Environment.getExternalStorageState();


        return Environment.MEDIA_MOUNTED.equals(state);
    }

    public static boolean isMemoryCardAvailable() {
        String state = Environment.getExternalStorageState();
        return Environment.MEDIA_MOUNTED.equals(state) || Environment.MEDIA_MOUNTED_READ_ONLY.equals(state);
    }

    public static long getAvailableRAM(Context context) {
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ActivityManager activityManager = (ActivityManager) context.getSystemService(ACTIVITY_SERVICE);
        activityManager.getMemoryInfo(mi);
        return mi.availMem;
    }

    public static String formatFileSize(long size) {
        String suffix = null;
        double value = size;
        if (size >= 1024) {
            suffix = "KB";
            value = size / 1024.0;
            if (value >= 1024) {
                suffix = "MB";
                value = value / 1024.0;
                if (value >= 1024) {
                    suffix = "GB";
                    value = value / 1024.0;
                }
            }
        }
        return String.format("%.2f %s", value, suffix);
    }

    @Override
    protected void onResume() {

        SharedPreferences sharedPrefs = getSharedPreferences("language", MODE_PRIVATE);
        String s1 = sharedPrefs.getString("selectedlanguage", "");
        LocaleHelper.setLocale(this, s1);
//        new Utils().disebledOpenAdsBasedOnFireBase();
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleHelper.onAttach(base, "en"));
    }

}