package com.cleanmaster.trashcleaner.junkeraser.service;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.IBinder;
import android.os.Process;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;

import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationManagerCompat;
import androidx.room.Room;

import com.cleanmaster.trashcleaner.junkeraser.Utils;
import com.cleanmaster.trashcleaner.junkeraser.database.ApplicationDatabase;
import com.cleanmaster.trashcleaner.junkeraser.database.ApplicationModel;
import com.cleanmaster.trashcleaner.junkeraser.database.BlockListModel;
import com.cleanmaster.trashcleaner.junkeraser.utils.ApkInfoExtractor;

import java.util.List;
import java.util.Set;


public class Block_All_Notification extends NotificationListenerService {

    private static final String TAG = "NotifiCollectorMonitor";

    BlockListModel blockList;
    ApplicationDatabase applicationDatabase;
    private boolean isCalled = false;

    public Block_All_Notification() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        return super.onBind(intent);
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        Log.d("fsdfsfwer", sbn.getPackageName() + "11111111    " + sbn.getUid());

        //ApplicationDatabase applicationDatabase = Room.databaseBuilder(this, ApplicationDatabase.class, "application_db").allowMainThreadQueries().build();
        ApplicationDatabase applicationDatabase = Utils.getApplicationDatabase(this);

        if (applicationDatabase.blockListDao() != null && applicationDatabase.blockListDao().getAllBlockList().size() != 0 && applicationDatabase.blockListDao().getAllBlockList().get(0).getStatus().equals("yes")) {
            cancelAllNotifications();
        } else if (applicationDatabase.blockListDao() != null && applicationDatabase.blockListDao().getAllBlockList().size() != 0 && applicationDatabase.blockListDao().getAllBlockList().get(0).getStatus().equals("no")) {
            List<ApplicationModel> applicationModelslist = applicationDatabase.applicationDao().getAllappList();
            if (applicationModelslist != null) {
                for (int i = 0; i < applicationModelslist.size(); i++) {
                    if (applicationModelslist.get(i).getApkPackage().equals(sbn.getPackageName())) {
                        if (!applicationModelslist.get(i).isIsblock()) {
                        } else if (applicationModelslist.get(i).isIsblock()) {
                            cancelNotification(sbn.getKey());
                        } else {
                        }
                    }
                }
            }
        } else {
            List<ApplicationModel> applicationModelslist = applicationDatabase.applicationDao().getAllappList();
            if (applicationModelslist != null) {
                for (int i = 0; i < applicationModelslist.size(); i++) {
                    if (applicationModelslist.get(i).getApkPackage().equals(sbn.getPackageName())) {
                        if (!applicationModelslist.get(i).isIsblock()) {
                            Log.d("fsdfsfwer", "no cancel");
                        } else if (applicationModelslist.get(i).isIsblock()) {
                            Log.d("fsdfsfwer", "close all notification");
                            cancelNotification(sbn.getKey());
                        } else {
                            Log.d("fsdfsfwer", "Found Some Error");
                        }
                    } else {
                        Log.d("fsdfsfwer", "Found Some Error");
                    }
                }
            }
        }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {

        if (!isCalled) {
            isCalled = true;
            Log.d("fsdfsfwer111111", sbn.getPackageName() + "222222222");
            //ApplicationDatabase applicationDatabase = Room.databaseBuilder(this, ApplicationDatabase.class, "application_db").allowMainThreadQueries().build();
            ApplicationDatabase applicationDatabase = Utils.getApplicationDatabase(this);

            List<ApplicationModel> applicationlist = applicationDatabase.applicationDao().getAllappList();

            if (applicationlist != null) {

                for (int i = 0; i < applicationlist.size(); i++) {
                    if (applicationlist.get(i).getApkPackage().equals(sbn.getPackageName())) {
//                    if (applicationlist.get(i).isIsblock()){
                        int id = applicationlist.get(i).getId();
                        Log.d(TAG, "onNotificationRemoved: " + applicationlist.get(i).getNotification_count());


                        if (applicationlist.get(i).isIsblock()) {
                            applicationDatabase.applicationDao().updateUsingID(id, applicationlist.get(i).getNotification_count() + 1);
                        }
//
//                    }
                    }
                }
//            applicationlist.setNotification_count((Integer.parseInt(applicationlist.getNotification_count()) + 1) + "");
            } else {
                ApkInfoExtractor apkInfoExtractor = new ApkInfoExtractor(getApplicationContext());

                applicationDatabase.applicationDao().application_insert(new ApplicationModel(sbn.getPackageName(), apkInfoExtractor.GetAppName(sbn.getPackageName()), 1, false));
            }
        } else {
            isCalled = false;
        }
    }

    @Override
    public void onCreate() {
        Log.d("fsdfsfwer111111", "oncreate");
        super.onCreate();
        //applicationDatabase = Room.databaseBuilder(this, ApplicationDatabase.class, "application_db").allowMainThreadQueries().build();
        applicationDatabase = Utils.getApplicationDatabase(this);
        try {
            ensureCollectorRunning();
            if (isnotificationserviceenable(getApplicationContext())) {
                toggleNotificationListenerService();
            }

        } catch (Exception e) {
            Log.d("Error Line Number", Log.getStackTraceString(e));
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d("fsdfsfwer", "On Start Commoand");
        try {
            ensureCollectorRunning();
            if (isnotificationserviceenable(getApplicationContext())) {
                toggleNotificationListenerService();
            }
        } catch (Exception e) {
            Log.d("Error Line Number", Log.getStackTraceString(e));
        }
        return START_STICKY;

    }


    //check for service is runnng
    private void ensureCollectorRunning() {
        try {
            ComponentName collectorComponent = new ComponentName(this, Block_All_Notification.class);
            Log.v(TAG, "ensureCollectorRunning collectorComponent: " + collectorComponent);
            ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            boolean collectorRunning = false;
            List<ActivityManager.RunningServiceInfo> runningServices = manager.getRunningServices(Integer.MAX_VALUE);
            if (runningServices == null) {
                Log.w(TAG, "ensureCollectorRunning() runningServices is NULL");
                return;
            }
            for (ActivityManager.RunningServiceInfo service : runningServices) {
                if (service.service.equals(collectorComponent)) {
                    Log.w(TAG, "ensureCollectorRunning service - pid: " + service.pid + ", currentPID: " + Process.myPid() + ", clientPackage: " + service.clientPackage + ", clientCount: " + service.clientCount
                            + ", clientLabel: " + ((service.clientLabel == 0) ? "0" : "(" + getResources().getString(service.clientLabel) + ")"));
                    if (service.pid == Process.myPid() /*&& service.clientCount > 0 && !TextUtils.isEmpty(service.clientPackage)*/) {
                        collectorRunning = true;
                    }
                }
            }
            if (collectorRunning) {
                Log.d(TAG, "ensureCollectorRunning: collector is running");
                return;
            }
            Log.d(TAG, "ensureCollectorRunning: collector not running, reviving...");
            toggleNotificationListenerService();
            tryReconnectService();
        } catch (Exception e) {
            Log.d("Error Line Number", Log.getStackTraceString(e));
        }
    }

    private void toggleNotificationListenerService() {
        Log.d(TAG, "toggleNotificationListenerService() called");
        try {
            ComponentName thisComponent = new ComponentName(this, Block_All_Notification.class);
            PackageManager pm = getPackageManager();
            pm.setComponentEnabledSetting(thisComponent, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
            pm.setComponentEnabledSetting(thisComponent, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
        } catch (Exception e) {
            Log.d("Error Line Number", Log.getStackTraceString(e));
        }

    }

    private static boolean isnotificationserviceenable(Context context) {
        try {
            Set<String> packaageNames = NotificationManagerCompat.getEnabledListenerPackages(context);
            if (packaageNames.contains(context.getPackageName())) {
                return true;
            }
        } catch (Exception e) {
            Log.d("Error Line Number", Log.getStackTraceString(e));
        }
        return false;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        /*if (realm!=null){
            realm.close();
        }*/
    }

    public void tryReconnectService() {
        toggleNotificationListenerService();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            ComponentName componentName = new ComponentName(getApplicationContext(), Block_All_Notification.class);

            //It say to Notification Manager RE-BIND your service to listen notifications again inmediatelly!
            requestRebind(componentName);
        }
    }
}
