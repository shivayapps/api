package com.cleanmaster.trashcleaner.junkeraser.activity;


import static com.cleanmaster.trashcleaner.junkeraser.activity.AppCleanLastFolderWiseDataActivity.documentContentList;
import static com.cleanmaster.trashcleaner.junkeraser.utils.StorageInformation.isNetworkConnected;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.InsetDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.ads.module.adutills.AdUtils;
import com.ads.module.adutills.ClickCallback;
import com.ads.module.adutills.RewardedAdClass;
import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.Utils;
import com.cleanmaster.trashcleaner.junkeraser.adapter.documentRecycleAdapter;
import com.cleanmaster.trashcleaner.junkeraser.helper.LocaleHelper;
import com.cleanmaster.trashcleaner.junkeraser.model.AlgorithmItem;
import com.cleanmaster.trashcleaner.junkeraser.model.doumentContent;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class AppCleanerDocumentActivity extends BaseActivity {
    public static int DELETE_REQUEST_CODE = 200;
    ArrayList<AlgorithmItem> algorithmItems = new ArrayList<>();
    RecyclerView picture_recycler;
    Spinner folderSelector;

    private ArrayList<doumentContent> selectedImageList = new ArrayList<>();
    private documentRecycleAdapter pictureAdapter;
    private ImageView btnCleanStorage;
    long sum = 0;
    private boolean isSelectImage = false;
    private ConstraintLayout emptyView;
    private AlertDialog alertDialog;
    private Dialog dialog;
    private ImageView imgAllSelect;
    private RewardedAdClass rewardedAdClass;

    @SuppressWarnings("InvalidSetHasFixedSize")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_picture);
//


        TextView text_title = findViewById(R.id.text_title);
        text_title.setText(getResources().getString(R.string.documents));

        ImageView imgBack = findViewById(R.id.imgBack);
        imgBack.setOnClickListener(v -> onBackPressed());

//        findViewById(R.id.imgCast).setOnClickListener(v -> startActivity(new Intent("android.settings.CAST_SETTINGS")));

        emptyView = findViewById(R.id.emptyView);
        picture_recycler = findViewById(R.id.picture_recycler);
        btnCleanStorage = findViewById(R.id.btnCleanStorage);
        imgAllSelect = findViewById(R.id.imgAllSelect);
        picture_recycler.hasFixedSize();
        picture_recycler.setHasFixedSize(true);
        picture_recycler.setItemViewCacheSize(20);
        picture_recycler.setDrawingCacheEnabled(true);
        picture_recycler.setDrawingCacheQuality(View.DRAWING_CACHE_QUALITY_HIGH);

        setUpAndDisplayPictures();

        btnCleanStorage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                showDeleteDialog(sum);

                /*if (isNetworkConnected(AppCleanerDocumentActivity.this) && mFirebaseRemoteConfig != null && mFirebaseRemoteConfig.getBoolean("ads_clean_rewards")) {
//                    showRewardAdsDialog(v);
                } else if (!isNetworkConnected(AppCleanerDocumentActivity.this)) {
                    cleanTrash();
                } else if (mFirebaseRemoteConfig != null && !mFirebaseRemoteConfig.getBoolean("ads_clean_rewards")) {
                    cleanTrash();
                }*/

            }
        });

        imgAllSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isSelectImage) {
                    setAllSelect();
                    imgAllSelect.setImageResource(R.drawable.ic_all_unselect);
//                    binding.toolbar.ivSelectAll.setColorFilter(getResources().getColor(R.color.theme_color));
                    isSelectImage = true;
                } else {
                    setAllUnSelect();
                    imgAllSelect.setImageResource(R.drawable.ic_all_select);
//                    binding.toolbar.ivSelectAll.setColorFilter(getResources().getColor(R.color.text_color_bold));
                    isSelectImage = false;
                }
            }
        });

        rewardedAdClass = new RewardedAdClass(AppCleanerDocumentActivity.this);
        rewardedAdClass.loadRewardedAd();


    }


    void setUpAndDisplayPictures() {
        documentRecycleAdapter.pictureActionListrener actionListener = new documentRecycleAdapter.pictureActionListrener() {

            @Override
            public void onPictureItemClicked(int position, ArrayList<doumentContent> arrayListimage) {
                documentContentList = arrayListimage;
                selectedImageList.clear();
                sum = 0;
                for (int i = 0; i < arrayListimage.size(); i++) {
                    if (arrayListimage.get(i).isSelected()) {
                        selectedImageList.add(arrayListimage.get(i));
//                        Log.d(TAG, "onPictureItemClicked: "+selectedImageList.size());
                        sum = sum + arrayListimage.get(i).getDocumentSize();
//                        Log.d(TAG, "onPictureItemClicked size: "+convertFileSize(sum));
                    }
                }

//                btnCleanStorage.setText(getResources().getString(R.string.clean)+"(" + convertFileSize(sum) + ")");

                if (selectedImageList.size() > 0) {
                    btnCleanStorage.setVisibility(View.VISIBLE);
                } else {
                    btnCleanStorage.setVisibility(View.GONE);
                }

                if (selectedImageList.size() == documentContentList.size()) {
                    imgAllSelect.setImageResource(R.drawable.ic_all_unselect);
                    isSelectImage = true;
                } else {
                    imgAllSelect.setImageResource(R.drawable.ic_all_select);
                    isSelectImage = false;
                    /*if (arrayListimage.size() == selectedImageList.size()) {
                        isSelectImage = true;
                    } else {
                        isSelectImage = false;
                    }*/
                }
            }

        };
        pictureAdapter = new documentRecycleAdapter(this, documentContentList, actionListener);
        picture_recycler.setAdapter(pictureAdapter);

        if (documentContentList.size() > 0) {
            emptyView.setVisibility(View.GONE);
            picture_recycler.setVisibility(View.VISIBLE);
            imgAllSelect.setVisibility(View.VISIBLE);

            FrameLayout adContainerView = findViewById(R.id.frame_banner);
            new AdUtils().loadMediumBanner(this,adContainerView);

        } else {
            emptyView.setVisibility(View.VISIBLE);
            picture_recycler.setVisibility(View.GONE);
            imgAllSelect.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 101 && resultCode == RESULT_OK) {
            boolean isChange = data.getBooleanExtra("isChange", false);
            int currentpos = data.getIntExtra("currentpos", 0);
            if (isChange) {
                pictureAdapter.notifyItemRemoved(currentpos);
            }
        }
    }


    public static String convertFileSize(long sizeInBytes) {
        String[] units = {"B", "KB", "MB", "GB"};
        double size = sizeInBytes;
        int index = 0;
        while (size > 1024 && index < units.length - 1) {
            size /= 1024;
            index++;
        }
        return String.format("%.2f %s", size, units[index]);
    }


    @SuppressLint("NotifyDataSetChanged")
    private void setAllSelect() {
        for (int i = 0; i < documentContentList.size(); i++) {
            if (!documentContentList.get(i).isSelected()) {
                documentContentList.get(i).setSelected(true);
            }
        }
        selectedImageList.clear();
        sum = 0;
        for (int i = 0; i < documentContentList.size(); i++) {
            if (documentContentList.get(i).isSelected()) {
                selectedImageList.add(documentContentList.get(i));
                sum = sum + documentContentList.get(i).getDocumentSize();
            }
        }

//        btnCleanStorage.setText(getResources().getString(R.string.clean)+"("+  convertFileSize(sum) + ")");

        if (selectedImageList.size() > 0) {
            btnCleanStorage.setVisibility(View.VISIBLE);
        } else {
            btnCleanStorage.setVisibility(View.GONE);
        }
        pictureAdapter.notifyDataSetChanged();
    }

    @SuppressLint("NotifyDataSetChanged")
    private void setAllUnSelect() {
        if(documentContentList!=null && documentContentList.size()>0) {
            for (int i = 0; i < documentContentList.size(); i++) {
                if (documentContentList.get(i).isSelected()) {
                    documentContentList.get(i).setSelected(false);
                }
            }
            selectedImageList.clear();
            selectedImageList.size();
            btnCleanStorage.setVisibility(View.GONE);
            if (pictureAdapter != null) {
                pictureAdapter.notifyDataSetChanged();
            }
        }

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        setAllUnSelect();
    }

    @Override
    protected void onResume() {

        SharedPreferences sharedPrefs = getSharedPreferences("language", MODE_PRIVATE);
        String s1 = sharedPrefs.getString("selectedlanguage", "");
        LocaleHelper.setLocale(this, s1);
        new Utils().disebledOpenAdsBasedOnFireBase();
        super.onResume();
    }

    @Override
    protected void onPause() {

        super.onPause();

    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleHelper.onAttach(base, "en"));
    }

    public void deleteFileFromMediaStore(final ContentResolver contentResolver, final File file) {


        boolean isDeleted = file.delete();

        if (!isDeleted) {
            String canonicalPath;
            try {
                canonicalPath = file.getCanonicalPath();
            } catch (IOException e) {
                canonicalPath = file.getAbsolutePath();
            }
            final Uri uri = MediaStore.Files.getContentUri("external");
            final int result = contentResolver.delete(uri,
                    MediaStore.Files.FileColumns.DATA + "=?", new String[]{canonicalPath});
            if (result == 0) {
                final String absolutePath = file.getAbsolutePath();
                if (!absolutePath.equals(canonicalPath)) {
                    contentResolver.delete(uri, MediaStore.Files.FileColumns.DATA + "=?", new String[]{absolutePath});
                }
            }
        }
    }

    public void showSuccessDialog() {
        final View dialogView = getLayoutInflater().inflate(R.layout.dialog_clear_success, null);
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);

        TextView buttonOk = dialogView.findViewById(R.id.buttonOk);

        buttonOk.setOnClickListener(view12 -> {
            alertDialog.dismiss();
        });

        builder.setView(dialogView);
        alertDialog = builder.create();
        alertDialog.setCancelable(false);
        InsetDrawable inset = new InsetDrawable(new ColorDrawable(Color.TRANSPARENT), 40);
        alertDialog.getWindow().setBackgroundDrawable(inset);
        alertDialog.show();
    }

    private void cleanTrash() {
        for (int j = 0; j < selectedImageList.size(); j++) {
            String path = selectedImageList.get(j).getFilePath();
            File file11 = new File(path);
            documentContentList.remove(selectedImageList.get(j));
            deleteFileFromMediaStore(getContentResolver(),file11);

        }
        pictureAdapter.notifyDataSetChanged();
//                setUpAndDisplayPictures();
        btnCleanStorage.setVisibility(View.GONE);
        showSuccessDialog();
    }
    public void showDeleteDialog(long totalsize) {
        final View dialogView = getLayoutInflater().inflate(R.layout.dialog_delete, null);
        AlertDialog.Builder builder = new AlertDialog.Builder(AppCleanerDocumentActivity.this);

        TextView buttonCancel = dialogView.findViewById(R.id.buttonCancel);
        TextView buttonOk = dialogView.findViewById(R.id.buttonOk);
        TextView tvDescription = dialogView.findViewById(R.id.tvDescription);
        TextView tvAppname = dialogView.findViewById(R.id.tvAppname);
        tvAppname.setText(getResources().getString(R.string.delete) + "(" + convertFileSize(totalsize) + ")");
        tvDescription.setText(getString(R.string.are_you_sure_you_want_to_delete_these) + getResources().getString(R.string.documents) + "?");
        buttonCancel.setOnClickListener(view1 -> alertDialog.dismiss());

        buttonOk.setOnClickListener(view12 -> {
            alertDialog.dismiss();
            rewardedAdClass.displayRewardAds(new ClickCallback() {
                @Override
                public void clickNext() {
                    cleanTrash();
                }
            });
        });

        builder.setView(dialogView);
        alertDialog = builder.create();

        InsetDrawable inset = new InsetDrawable(new ColorDrawable(Color.TRANSPARENT), 40);
        alertDialog.getWindow().setBackgroundDrawable(inset);
        alertDialog.show();
    }

}
