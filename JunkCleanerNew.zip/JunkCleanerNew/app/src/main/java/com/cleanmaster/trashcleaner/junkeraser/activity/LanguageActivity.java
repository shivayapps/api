package com.cleanmaster.trashcleaner.junkeraser.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.InsetDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import com.ads.module.adutills.NativeLoadWithShows;
import com.ads.module.adutills.SessionHelper;
import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.Utils;
import com.cleanmaster.trashcleaner.junkeraser.databinding.ActivityLanguageBinding;
import com.cleanmaster.trashcleaner.junkeraser.helper.LocaleHelper;

public class LanguageActivity extends BaseActivity {
    private ActivityLanguageBinding binding;
    private String str = "en";
    private SharedPreferences sharedPref;
    private SharedPreferences sharedPrefsetlanguage;
    private boolean isLanguageSet;
    private AlertDialog alertDialog;
    private boolean isFromStart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLanguageBinding.inflate(getLayoutInflater());

        View view = binding.getRoot();
        setContentView(view);

//        configMediationProvider();


        isFromStart = getIntent().getBooleanExtra("isFromStart", false);

        sharedPref = getSharedPreferences("language", MODE_PRIVATE);

        sharedPrefsetlanguage = getSharedPreferences("LanguageSet", MODE_PRIVATE);
        isLanguageSet = sharedPrefsetlanguage.getBoolean("isLanguageSet", false);

        if (!isLanguageSet) {
            binding.imgBack.setVisibility(View.GONE);
        } else {
            binding.imgBack.setVisibility(View.VISIBLE);
        }

        binding.imgBack.setOnClickListener(v -> onBackPressed());

        loadNative();
        /*if(isFromStart) {
            if (mFirebaseRemoteConfig != null && mFirebaseRemoteConfig.getBoolean("native_language") && mFirebaseRemoteConfig.getBoolean("native_language_high")) {
                loadNativeAdsFirstLanguageOpen();
            } else if (mFirebaseRemoteConfig != null && mFirebaseRemoteConfig.getBoolean("native_language") || mFirebaseRemoteConfig != null && mFirebaseRemoteConfig.getBoolean("native_language_high")) {
                loadNativeAdsFirstLanguageOpenLowPriority();
            } else {
                aperoNativeAdView.setVisibility(View.GONE);
            }
        }else {
            aperoNativeAdView.setVisibility(View.GONE);
        }*/

        String s1 = sharedPref.getString("selectedlanguage", "en");
        str = s1;
        switch (s1) {
            case "en":
                binding.imgradio1.setChecked(true);
                break;
            case "es":
                binding.imgradio2.setChecked(true);
                break;
            case "de":
                binding.imgradio3.setChecked(true);
                break;
            case "fr":
                binding.imgradio4.setChecked(true);
                break;
            case "ru":
                binding.imgradio5.setChecked(true);
                break;
            case "hi":
                binding.imgradio6.setChecked(true);
                break;
            case "fil":
                binding.imgradio7.setChecked(true);
                break;
            case "zh":
                binding.imgradio8.setChecked(true);
                break;
            case "it":
                binding.imgradio9.setChecked(true);
                break;
            case "in":
                binding.imgradio10.setChecked(true);
                break;
        }

        binding.imgDone.setOnClickListener(v -> {


            updateViews(str);

            SharedPreferences.Editor myEdit = sharedPref.edit();
            myEdit.putString("selectedlanguage", str);
            myEdit.apply();

            SharedPreferences sharedPref2 = getPreferences(Context.MODE_PRIVATE);
            SharedPreferences.Editor myEdit2 = sharedPref2.edit();
            myEdit2.putBoolean(getString(R.string.sharedpref_is_first_run), false);
            myEdit2.apply();

            if (!isLanguageSet) {
                SharedPreferences.Editor myEdit1 = sharedPrefsetlanguage.edit();
                myEdit1.putBoolean("isLanguageSet", true);
                myEdit1.apply();
                Intent it = new Intent(this, StartActivity.class);
                startActivity(it);
                finish();
            } else {

                onBackPressed();
               /* Intent it = new Intent(this, LanguageActivity.class);
                finish();
                overridePendingTransition(0, 0);
                startActivity(it);
                overridePendingTransition(0, 0);*/
            }
//            overridePendingTransition(0, 0);
        });
        binding.rlEnglish.setOnClickListener(v -> {
            str = "en";
            binding.imgradio1.setChecked(true);
            binding.imgradio2.setChecked(false);
            binding.imgradio3.setChecked(false);
            binding.imgradio4.setChecked(false);
            binding.imgradio5.setChecked(false);
            binding.imgradio6.setChecked(false);
            binding.imgradio7.setChecked(false);
            binding.imgradio8.setChecked(false);
            binding.imgradio9.setChecked(false);
            binding.imgradio10.setChecked(false);
//            updateViews("en", binding.imgradio1);
        });
        binding.rlSpanish.setOnClickListener(v -> {
            binding.imgradio1.setChecked(false);
            binding.imgradio2.setChecked(true);
            binding.imgradio3.setChecked(false);
            binding.imgradio4.setChecked(false);
            binding.imgradio5.setChecked(false);
            binding.imgradio6.setChecked(false);
            binding.imgradio7.setChecked(false);
            binding.imgradio8.setChecked(false);
            binding.imgradio9.setChecked(false);
            binding.imgradio10.setChecked(false);
            str = "es";
        });
        binding.rlGerman.setOnClickListener(v -> {
            binding.imgradio1.setChecked(false);
            binding.imgradio2.setChecked(false);
            binding.imgradio3.setChecked(true);
            binding.imgradio4.setChecked(false);
            binding.imgradio5.setChecked(false);
            binding.imgradio6.setChecked(false);
            binding.imgradio7.setChecked(false);
            binding.imgradio8.setChecked(false);
            binding.imgradio9.setChecked(false);
            binding.imgradio10.setChecked(false);
            str = "de";
        });
        binding.rlFrench.setOnClickListener(v -> {
            binding.imgradio1.setChecked(false);
            binding.imgradio2.setChecked(false);
            binding.imgradio3.setChecked(false);
            binding.imgradio4.setChecked(true);
            binding.imgradio5.setChecked(false);
            binding.imgradio6.setChecked(false);
            binding.imgradio7.setChecked(false);
            binding.imgradio8.setChecked(false);
            binding.imgradio9.setChecked(false);
            binding.imgradio10.setChecked(false);
            str = "fr";
        });
        binding.rlRussian.setOnClickListener(v -> {
            binding.imgradio1.setChecked(false);
            binding.imgradio2.setChecked(false);
            binding.imgradio3.setChecked(false);
            binding.imgradio4.setChecked(false);
            binding.imgradio5.setChecked(true);
            binding.imgradio6.setChecked(false);
            binding.imgradio7.setChecked(false);
            binding.imgradio8.setChecked(false);
            binding.imgradio9.setChecked(false);
            binding.imgradio10.setChecked(false);
            str = "ru";
        });
        binding.rlHindi.setOnClickListener(v -> {
            binding.imgradio1.setChecked(false);
            binding.imgradio2.setChecked(false);
            binding.imgradio3.setChecked(false);
            binding.imgradio4.setChecked(false);
            binding.imgradio5.setChecked(false);
            binding.imgradio6.setChecked(true);
            binding.imgradio7.setChecked(false);
            binding.imgradio8.setChecked(false);
            binding.imgradio9.setChecked(false);
            binding.imgradio10.setChecked(false);
            str = "hi";
        });
        binding.rlFilipino.setOnClickListener(v -> {
            binding.imgradio1.setChecked(false);
            binding.imgradio2.setChecked(false);
            binding.imgradio3.setChecked(false);
            binding.imgradio4.setChecked(false);
            binding.imgradio5.setChecked(false);
            binding.imgradio6.setChecked(false);
            binding.imgradio7.setChecked(true);
            binding.imgradio8.setChecked(false);
            binding.imgradio9.setChecked(false);
            binding.imgradio10.setChecked(false);
            str = "fil";
        });
        binding.rlChinese.setOnClickListener(v -> {
            binding.imgradio1.setChecked(false);
            binding.imgradio2.setChecked(false);
            binding.imgradio3.setChecked(false);
            binding.imgradio4.setChecked(false);
            binding.imgradio5.setChecked(false);
            binding.imgradio6.setChecked(false);
            binding.imgradio7.setChecked(false);
            binding.imgradio8.setChecked(true);
            binding.imgradio9.setChecked(false);
            binding.imgradio10.setChecked(false);
            str = "zh";
        });
        binding.rlItalian.setOnClickListener(v -> {
            binding.imgradio1.setChecked(false);
            binding.imgradio2.setChecked(false);
            binding.imgradio3.setChecked(false);
            binding.imgradio4.setChecked(false);
            binding.imgradio5.setChecked(false);
            binding.imgradio6.setChecked(false);
            binding.imgradio7.setChecked(false);
            binding.imgradio8.setChecked(false);
            binding.imgradio9.setChecked(true);
            binding.imgradio10.setChecked(false);
            str = "it";
        });
        binding.rlTurkish.setOnClickListener(v -> {
            binding.imgradio1.setChecked(false);
            binding.imgradio2.setChecked(false);
            binding.imgradio3.setChecked(false);
            binding.imgradio4.setChecked(false);
            binding.imgradio5.setChecked(false);
            binding.imgradio6.setChecked(false);
            binding.imgradio7.setChecked(false);
            binding.imgradio8.setChecked(false);
            binding.imgradio9.setChecked(false);
            binding.imgradio10.setChecked(true);
            str = "in";
        });
    }

    public void loadNative() {
//        new AdUtils().nativeAd(this, binding.nativeAdPEPkmsSmall, true, 2);
        if (new SessionHelper(this).getStringData(SessionHelper.IS_LANGUAGE_NATIVE_ON).equals("1") && isFromStart) {
            new NativeLoadWithShows(this).showNativeAdsShimmerEffects(this, binding.nativeAdPEPkmsSmall, 2);
            new NativeLoadWithShows(this).showNativeBigAlways(this, binding.nativeAdPEPkmsSmall,null);
        }
    }
    private void updateViews(String languageCode) {
        LocaleHelper.setLocale(this, languageCode);
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleHelper.onAttach(base, "en"));
    }

    @Override
    public void onBackPressed() {
        if (!isLanguageSet || isFromStart) {

            final View dialogView = getLayoutInflater().inflate(R.layout.dialog_exit, null);
            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            TextView buttonCancel = dialogView.findViewById(R.id.buttonCancel);
            TextView buttonOk = dialogView.findViewById(R.id.buttonOk);

            buttonCancel.setOnClickListener(view1 -> alertDialog.dismiss());

            buttonOk.setOnClickListener(view12 -> {
                alertDialog.dismiss();
                finishAffinity();
                System.exit(1);
            });

            builder.setView(dialogView);
            alertDialog = builder.create();
            InsetDrawable inset = new InsetDrawable(new ColorDrawable(Color.TRANSPARENT), 40);
            alertDialog.getWindow().setBackgroundDrawable(inset);
            alertDialog.show();

        } else {
            Intent it = new Intent(LanguageActivity.this, SettingActivity.class);
            startActivity(it);
            finish();
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();

        SharedPreferences sharedPrefs = getSharedPreferences("language", MODE_PRIVATE);
        String s1 = sharedPrefs.getString("selectedlanguage", "");
        LocaleHelper.setLocale(this, s1);
    }


   /* private void configMediationProvider() {
        if (AperoAd.getInstance().getMediationProvider() == AperoAdConfig.PROVIDER_ADMOB) {
            idNative = BuildConfig.native_language;
            layoutNativeCustom = com.ads.control.R.layout.custom_native_admob_small;
        } else {
            idNative = getString(R.string.applovin_test_native);
            layoutNativeCustom = com.ads.control.R.layout.custom_native_max_medium;
        }
    }*/


    @Override
    protected void onResume() {

        new Utils().disebledOpenAdsBasedOnFireBase();
        super.onResume();
    }
}