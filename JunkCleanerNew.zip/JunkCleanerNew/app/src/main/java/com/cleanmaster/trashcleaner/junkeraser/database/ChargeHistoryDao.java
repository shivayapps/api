package com.cleanmaster.trashcleaner.junkeraser.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ChargeHistoryDao {


    @Insert
    void charge_histoty_insert(ChargeHistoryModel model);

    @Query("DELETE FROM charge_history")
    void charge_history_deleteAll();

    @Query("SELECT * FROM charge_history")
    List<ChargeHistoryModel> getAllcharge_historyList();

    @Query("UPDATE charge_history SET charge_duration = :chargeduration, ispower = :ispower, charge_normal = :normal_charged, charge_healthy = :healthy_charged, charge_overcharged = :overCharged, isfullcharged = :isfullCharged WHERE id = 1")
    void updateUsingID(String chargeduration, boolean ispower, int normal_charged, int healthy_charged, int overCharged, boolean isfullCharged);

    @Query("UPDATE charge_history SET charge_type = :chargeType, charge_duration = :chargeduration, start_time = :start_time, ispower = :ispower, isfullcharged = :isfullCharged, start_charging_level = :start_battery_level WHERE id = 1")
    void updateUsingID(String chargeType, String chargeduration, String start_time, boolean ispower, boolean isfullCharged, int start_battery_level);

    @Query("UPDATE charge_history SET full_charged = :full_charged, full_charge = :full_charge, isfullcharged = :isfullCharged, start_charging_level = :start_battery_level WHERE id = 1")
    void updateUsingID(String full_charged, String full_charge, boolean isfullCharged, int start_battery_level);

//    @Query("UPDATE charge_history SET full_charged = :full_charge_date, full_charge = :full_charge, start_time = :start_time, end_time = :end_time, charge_type = :charge_type, charge_duration = :charge_duration, quantity = :quantity, charge_normal = :charge_normal, charge_healthy = :charge_healthy, charge_overcharged = :charge_overcharged, ispower = :ispower, isfullcharged = :isfullcharged, start_charging_level = :start_charging_level WHERE id = 1")
//    void updateUsingID(String full_charge_date, String full_charge, String start_time, String end_time, String charge_type, String charge_duration, int quantity, int charge_normal, int charge_healthy, int charge_overcharged, boolean ispower, boolean isfullcharged, int start_charging_level);

    @Update
    void charge_history_update(ChargeHistoryModel model);
}
