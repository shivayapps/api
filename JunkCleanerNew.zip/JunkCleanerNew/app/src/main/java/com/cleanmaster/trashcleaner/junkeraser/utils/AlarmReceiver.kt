package com.cleanmaster.trashcleaner.junkeraser.utils

import android.content.BroadcastReceiver
import android.content.ContentValues.TAG
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.util.Log
import androidx.room.Room.databaseBuilder
import com.cleanmaster.trashcleaner.junkeraser.database.ApplicationDatabase
import com.cleanmaster.trashcleaner.junkeraser.database.BatteryModel
import java.text.SimpleDateFormat
import java.util.*


/* loaded from: classes.dex */
class AlarmReceiver : BroadcastReceiver() {
    val ALARM_ACTION = "alarm_action"
    var applicationDatabase: com.cleanmaster.trashcleaner.junkeraser.database.ApplicationDatabase? = null

    override fun onReceive(context: Context, intent: Intent) {

//        Toast.makeText(context, "Broadcast Received", Toast.LENGTH_SHORT).show()
        Log.e(
            "Broadcast_Received==>",
            "------------------------------Received------------------------------"
        )

//        if (ALARM_ACTION == intent.action /*|| "android.intent.action.BOOT_COMPLETED" == intent.action || "android.intent.action.PACKAGE_REPLACED" == intent.action && intent.dataString == context.packageName || "android.intent.intent.action.TIME_SET" == intent.action || "android.intent.action.TIMEZONE_CHANGED" == intent.action*/) {
//            val gson = Gson()
//            val uniqueId = intent.getStringExtra(Constants.REMINDER_UNIQUE_ID)
        Log.d(TAG, "onReceive: ${intent.extras}")

        val calendar = Calendar.getInstance()
        val hour = calendar[Calendar.HOUR_OF_DAY]
        val minute = calendar[Calendar.MINUTE]
        val day = calendar[Calendar.DAY_OF_MONTH]
        val year = calendar[Calendar.YEAR]
        val month = calendar[Calendar.MONTH]

        AlarmUtils().addReminder(context, hour+1, minute, day, year, month)
//        log.e("AlarmInfoReceived::::", "repeat")

        applicationDatabase = databaseBuilder<com.cleanmaster.trashcleaner.junkeraser.database.ApplicationDatabase>(
            context,
            com.cleanmaster.trashcleaner.junkeraser.database.ApplicationDatabase::class.java, "application_db"
        ).allowMainThreadQueries().build()

        if (applicationDatabase?.batteryDao()?.allBatteryList != null) {
            for (i in applicationDatabase?.batteryDao()?.allBatteryList?.indices!!) {
                if (applicationDatabase?.batteryDao()?.allBatteryList?.size!! >= 75) {
                    if (applicationDatabase?.batteryDao()?.allBatteryList?.size!! > i) {
                        applicationDatabase?.batteryDao()
                            ?.deleteByUserId(applicationDatabase!!.batteryDao().allBatteryList[i].id)
                    }
                }
            }
        }

        val level: Int = get_battery(context)
        val date: String = getDate().toString()
        val minutes: Int = getminute()
        val hours: Int = gethours()

        if (hours <= 24 && level <= 100) {
            if (applicationDatabase?.batteryDao()?.allBatteryList != null) {
                for (i in applicationDatabase?.batteryDao()?.allBatteryList?.indices!!) {
                    if (applicationDatabase?.batteryDao()?.allBatteryList?.size!! > i) {
                        if (applicationDatabase?.batteryDao()?.allBatteryList!![i].date == date) {
                            if (applicationDatabase?.batteryDao()?.allBatteryList!![i].hours == hours) {
                                applicationDatabase?.batteryDao()?.deleteByUserId(applicationDatabase!!.batteryDao().allBatteryList[i].id)
                            }
                        }
                    }
                }
            }
            applicationDatabase!!.batteryDao().battery_insert(BatteryModel(hours, level, date))
        }

    }


    private fun gethours(): Int {
        val date = Date()
        val gethours = SimpleDateFormat("HH")
        return gethours.format(date).toInt()
    }

    private fun getsecound(): Int {
        val date = Date()
        val getsecound = SimpleDateFormat("ss")
        return getsecound.format(date).toInt()
    }

    private fun getminute(): Int {
        val date = Date()
        val getMinute = SimpleDateFormat("mm")
        return getMinute.format(date).toInt()
    }

    private fun getDate(): String? {
        val date = Date()
        val getdate = SimpleDateFormat("dd:MM:yyyy")
        return getdate.format(date)
    }

    fun get_battery(context: Context): Int {
        val iFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val batteryStatus: Intent? = context.registerReceiver(null, iFilter)
        if (batteryStatus != null)
            return batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1

        else return -1
    }
}