package com.cleanmaster.trashcleaner.junkeraser.model;

import android.os.Parcel;
import android.os.Parcelable;

public class LargeFileModel implements Parcelable {

    String path;
    Double size;
    boolean isSelected;

    public LargeFileModel(String path, Double size, boolean isSelected) {
        this.path = path;
        this.size = size;
        this.isSelected = isSelected;
    }

    protected LargeFileModel(Parcel in) {
        path = in.readString();
        if (in.readByte() == 0) {
            size = null;
        } else {
            size = in.readDouble();
        }
        isSelected = in.readByte() != 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(path);
        if (size == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeDouble(size);
        }
        dest.writeByte((byte) (isSelected ? 1 : 0));
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<LargeFileModel> CREATOR = new Creator<LargeFileModel>() {
        @Override
        public LargeFileModel createFromParcel(Parcel in) {
            return new LargeFileModel(in);
        }

        @Override
        public LargeFileModel[] newArray(int size) {
            return new LargeFileModel[size];
        }
    };

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public Double getSize() {
        return size;
    }

    public void setSize(Double size) {
        this.size = size;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }
}
