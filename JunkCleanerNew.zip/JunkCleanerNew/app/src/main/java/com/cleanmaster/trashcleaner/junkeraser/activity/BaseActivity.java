package com.cleanmaster.trashcleaner.junkeraser.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.app.UiModeManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.ads.module.adutills.BaseActivityPermission;


public class BaseActivity extends BaseActivityPermission {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View decor = getWindow().getDecorView();
//        decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
//        decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
//        getWindow().setStatusBarColor(getResources().getColor(R.color.statusbar_color));

        SharedPreferences sharedPref = getSharedPreferences("SettingScreen", MODE_PRIVATE);

        String themess = sharedPref.getString("theme", "light");
        switch (themess) {
            case "light":
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
                break;
            case "dark":
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
                break;
            case "dafault":
                UiModeManager uiModeManager = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
                if (uiModeManager.getNightMode() == UiModeManager.MODE_NIGHT_YES) {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                    decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
                } else {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                    decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
                }

                break;
        }

       /* if (new SessionHelper(this).getStringData(SessionHelper.IS_IRON_SOURCE_MEDEATION_ON) == "1" && new SessionHelper(this).getStringData(SessionHelper.IS_ADS_ON) == "1"){
            IronSource.init(this, new SessionHelper(this).getStringData(SessionHelper.IRON_SOURCE_APP_ID));
            IronSourceInteretisls().loadIronSourceInterestial();
            IronSource.shouldTrackNetworkState(this, true);
        }*/
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("IronBanner","onResume");
       /* if (new SessionHelper(this).getStringData(SessionHelper.IS_IRON_SOURCE_MEDEATION_ON) == "1" && new SessionHelper(this).getStringData(SessionHelper.IS_ADS_ON) == "1") {
            IronSource.onResume(this);
        }*/
    }

    @Override
    protected void onPause() {
        super.onPause();

        Log.e("IronBanner","onPause");
       /* if (new SessionHelper(this).getStringData(SessionHelper.IS_IRON_SOURCE_MEDEATION_ON) == "1" && new SessionHelper(this).getStringData(SessionHelper.IS_ADS_ON) == "1") {
            IronSource.onPause(this);
        }*/
    }
}