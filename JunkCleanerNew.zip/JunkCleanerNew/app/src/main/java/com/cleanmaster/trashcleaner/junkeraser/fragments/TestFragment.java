
package com.cleanmaster.trashcleaner.junkeraser.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.core.content.ContextCompat;
import androidx.core.view.ViewCompat;
import androidx.fragment.app.Fragment;
import androidx.room.Room;

import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.database.ApplicationDatabase;
import com.cleanmaster.trashcleaner.junkeraser.database.BatteryModel;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.github.mikephil.charting.utils.Utils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TestFragment extends Fragment {
    LineChart chart;
    LineDataSet set2;
    ApplicationDatabase applicationDatabase;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_test, container, false);
        chart = view.findViewById(R.id.chart1);
        initHistoryChart();
        return view;
    }

    public void initHistoryChart() {
        ArrayList<Entry> arrayList = new ArrayList<>();
        List<BatteryModel> batteryModelArrayList;

        //applicationDatabase = Room.databaseBuilder(requireActivity(), ApplicationDatabase.class, "application_db").allowMainThreadQueries().build();
        applicationDatabase = com.cleanmaster.trashcleaner.junkeraser.Utils.getApplicationDatabase(requireActivity());

//        if (applicationDatabase.batteryDao().getAllBatteryList() != null) {
//            for (int i = 0; i < applicationDatabase.batteryDao().getAllBatteryList().size(); i++) {
//                Date date = new Date();
//                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd:MM:YY");
//                if (applicationDatabase.batteryDao().getAllBatteryList().get(i).getDate().equals(simpleDateFormat.format(date))) {
//                    float val = applicationDatabase.batteryDao().getAllBatteryList().get(i).getBattery_level();
//                    arrayList.add(new Entry(applicationDatabase.batteryDao().getAllBatteryList().get(i).getHours(), val));
//                }
//            }
//        }
        Date date = new Date();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd:MM:yyyy");
        batteryModelArrayList = applicationDatabase.batteryDao().getAllSortBatteryList(simpleDateFormat.format(date));

        for (int i = 0; i < batteryModelArrayList.size(); i++) {
            arrayList.add(new Entry(batteryModelArrayList.get(i).getHours(), batteryModelArrayList.get(i).getBattery_level()));
        }
            Log.d("oppoii", "initHistoryChart: " + arrayList.size());
            LineDataSet lineDataSet = new LineDataSet(arrayList, "");
            set2 = lineDataSet;
            lineDataSet.setFillAlpha(100);
            set2.setColor(-6579542);
            set2.setLineWidth(1.0f);
            set2.setDrawValues(false);
            set2.setCircleColor(ContextCompat.getColor(getContext(), R.color.black));
            set2.setDrawFilled(true);
            set2.setFillColor(-9339154);
            this.set2.setFillFormatter((iLineDataSet, lineDataProvider) -> chart.getAxisLeft().getAxisMinimum());
            if (Utils.getSDKInt() >= 18) {
                this.set2.setFillDrawable(ContextCompat.getDrawable(getContext(), R.drawable.fade_red));
            } else {
                this.set2.setFillColor(ViewCompat.MEASURED_STATE_MASK);
            }

            ArrayList arrayList2 = new ArrayList();
            arrayList2.add(set2);

            chart.setData(new LineData((List<ILineDataSet>) arrayList2));
            XAxis xAxis = this.chart.getXAxis();
            xAxis.setTextColor(ContextCompat.getColor(getContext(), R.color.textcolor));
            xAxis.setAxisMaximum(24.0f);
            xAxis.setAxisMinimum(0.0f);
            xAxis.setLabelCount(6);
            xAxis.setValueFormatter(new MyXaxisValueFormater(new String[]{"00:00", "", "", "", "04:00", "", "", "", "08:00", "", "", "", "12:00", "", "", "", "16:00", "", "", "", "20:00", "", "", "", "24:00"}));
            xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
            this.chart.getXAxis().setDrawGridLines(false);
            YAxis axisLeft = this.chart.getAxisLeft();
            axisLeft.setTextColor(ContextCompat.getColor(getContext(), R.color.textcolor));
            axisLeft.setAxisMaximum(100.0f);
            axisLeft.setAxisMinimum(0.0f);
            axisLeft.setLabelCount(6);
            this.chart.getAxisRight().setEnabled(false);
            axisLeft.setValueFormatter(new MyXaxisValueFormater(new String[]{"", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "20%", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "40%", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "60%", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "80%", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "100%"}));
            axisLeft.enableGridDashedLine(10.0f, 10.0f, 0.0f);
            this.chart.setDescription((Description) null);
            this.chart.getXAxis().setDrawAxisLine(false);
            axisLeft.setDrawAxisLine(false);
            this.chart.getLegend().setEnabled(false);
            this.chart.setTouchEnabled(false);

        }

        public static class MyXaxisValueFormater extends ValueFormatter implements IAxisValueFormatter {
            private final String[] mValues;

            public MyXaxisValueFormater(String[] strArr) {
                this.mValues = strArr;
            }

            public String getFormattedValue(float f, AxisBase axisBase) {
                return this.mValues[(int) f];
            }
        }

        @Override
        public void onResume () {
            super.onResume();

        }
    }