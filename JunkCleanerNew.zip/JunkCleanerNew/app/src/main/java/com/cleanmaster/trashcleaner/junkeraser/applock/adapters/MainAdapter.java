package com.cleanmaster.trashcleaner.junkeraser.applock.adapters;

import static com.cleanmaster.trashcleaner.junkeraser.applock.activities.main.MainActivity.retrieveData;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.cleanmaster.trashcleaner.junkeraser.R;
import com.cleanmaster.trashcleaner.junkeraser.applock.db.CommLockInfoManager;
import com.cleanmaster.trashcleaner.junkeraser.applock.model.CommLockInfo;

import java.util.ArrayList;
import java.util.List;

public class MainAdapter extends RecyclerView.Adapter<MainAdapter.MainViewHolder> {
    @NonNull
    private final List<CommLockInfo> mLockInfos = new ArrayList<>();
    private final List<CommLockInfo> filterlist = new ArrayList<>();
    private final PackageManager packageManager;
    private final CommLockInfoManager mLockInfoManager;
    ItemClickListener itemClickListener;
    Context mContext;

    public MainAdapter(Context mContext, ItemClickListener itemClickListener) {
        this.mContext = mContext;
        packageManager = mContext.getPackageManager();
        mLockInfoManager = new CommLockInfoManager(mContext);
        this.itemClickListener = itemClickListener;
    }

    public void filter(String query) {
        filterlist.clear();
        if (query.isEmpty()) {
            filterlist.addAll(mLockInfos);
        } else {
            for (CommLockInfo item : mLockInfos) {
                if (item.getAppName().toLowerCase().contains(query.toLowerCase())) {
                    filterlist.add(item);
                }
            }
        }
        notifyDataSetChanged();
    }

    public void setLockInfos(@NonNull List<CommLockInfo> lockInfos) {
        mLockInfos.clear();
        mLockInfos.addAll(lockInfos);
        notifyDataSetChanged();
        filter("");
    }

    @NonNull
    @Override
    public MainViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_main_list, parent, false);
        return new MainViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final MainViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        final CommLockInfo lockInfo = filterlist.get(position);
        if (!retrieveData()) {
            if (lockInfo.isSysApp()) {
                holder.mSwitchCompat.setButtonDrawable(null);
                holder.mSwitchCompat.setBackground(mContext.getResources().getDrawable(R.drawable.ic_check_square));
            } else {
                holder.mSwitchCompat.setButtonDrawable(null);
                holder.mSwitchCompat.setBackground(mContext.getResources().getDrawable(R.drawable.ic_unlock));
//                holder.mSwitchCompat.setButtonTintList(ColorStateList.valueOf(mContext.getResources().getColor(R.color.text_color)));
            }
        } else {
            holder.mSwitchCompat.setBackground(null);
            holder.mSwitchCompat.setButtonDrawable(R.drawable.ic_checkbox_selector);
            if (lockInfo.isLocked()) {
                holder.mSwitchCompat.setButtonTintList(ColorStateList.valueOf(mContext.getResources().getColor(R.color.textcolor)));
            } else {
                holder.mSwitchCompat.setButtonTintList(ColorStateList.valueOf(mContext.getResources().getColor(R.color.subtextcolor)));
            }
        }

        initData(holder.mAppName, holder.mSwitchCompat, holder.mAppIcon, lockInfo);
        holder.mSwitchCompat.setOnClickListener(view -> {
            itemClickListener.onClick(holder.mSwitchCompat, lockInfo, position);
//                changeItemLockStatus(holder.mSwitchCompat, lockInfo, position);
        });
    }

    private void initData(TextView tvAppName, CheckBox switchCompat, ImageView mAppIcon, CommLockInfo lockInfo) {
        tvAppName.setText(packageManager.getApplicationLabel(lockInfo.getAppInfo()));
        switchCompat.setChecked(lockInfo.isLocked());
        ApplicationInfo appInfo = lockInfo.getAppInfo();
        mAppIcon.setImageDrawable(packageManager.getApplicationIcon(appInfo));
    }

    public void changeItemLockStatus(@NonNull CheckBox checkBox, @NonNull CommLockInfo info, int position) {
        if (checkBox.isChecked()) {
            info.setLocked(true);
            mLockInfoManager.lockCommApplication(info.getPackageName());
        } else {
            info.setLocked(false);
            mLockInfoManager.unlockCommApplication(info.getPackageName());
        }
        notifyItemChanged(position);
    }

    @Override
    public int getItemCount() {
        return filterlist.size();
    }

    public static class MainViewHolder extends RecyclerView.ViewHolder {
        private final ImageView mAppIcon;
        private final TextView mAppName;
        private final CheckBox mSwitchCompat;

        public MainViewHolder(@NonNull View itemView) {
            super(itemView);
            mAppIcon = itemView.findViewById(R.id.app_icon);
            mAppName = itemView.findViewById(R.id.app_name);
            mSwitchCompat = itemView.findViewById(R.id.switch_compat);
        }
    }

    public interface ItemClickListener {
        void onClick(@NonNull CheckBox checkBox, @NonNull CommLockInfo info, int position);
    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }
}
