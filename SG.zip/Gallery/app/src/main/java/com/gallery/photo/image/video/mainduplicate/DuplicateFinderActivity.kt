package com.gallery.photo.image.video.mainduplicate

import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import android.text.format.Formatter
import android.util.Log
import android.view.View
import com.adconfig.adsutil.admob.BannerAdHelper
import com.adconfig.adsutil.admob.NativeAdHelper
import com.adconfig.adsutil.admob.NativeLayoutType
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.base.BaseActivity
import com.gallery.photo.image.video.databinding.ActivityDuplicateFinderBinding
import com.gallery.photo.image.video.extension.beGone
import com.gallery.photo.image.video.extension.beVisible
import com.gallery.photo.image.video.extension.getParentFolder
import com.gallery.photo.image.video.extension.md5
import com.gallery.photo.image.video.mainduplicate.activity.scanningactivities.ScanningDuplicateActivity
import com.gallery.photo.image.video.model.AlbumData
import com.gallery.photo.image.video.model.PictureData
import com.gallery.photo.image.video.utils.AdCache
import com.gallery.photo.image.video.utils.Preferences
import com.gallery.photo.image.video.utils.TYPE_GIFS
import com.gallery.photo.image.video.utils.TYPE_IMAGES
import com.gallery.photo.image.video.utils.TYPE_VIDEOS
import com.gallery.photo.image.video.utils.photoExtensions
import com.gallery.photo.image.video.utils.rawExtensions
import com.gallery.photo.image.video.utils.videoExtensions
import com.google.android.gms.ads.AdView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch
import java.io.File

class DuplicateFinderActivity : BaseActivity(), View.OnClickListener {

    var duplicatePhotoData: Map<String, List<PictureData>> = emptyMap()
    var duplicateVideoData: Map<String, List<PictureData>> = emptyMap()
    var photoAlbumList: ArrayList<AlbumData> = ArrayList()
    var videoAlbumList: ArrayList<AlbumData> = ArrayList()

    var isDuplicatePhotoRunning = true
    var isDuplicateVideoRunning = true

    var allPhotos = ArrayList<PictureData>()
    var allVideo = ArrayList<PictureData>()

    var totalSize: Long = 0L
    var totalphotoCounter: Float = 0F
    var totalvideoCounter: Float = 0F
    var photoCounter: Float = 0F
    var videoCounter: Float = 0F


    lateinit var mBinding: ActivityDuplicateFinderBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = ActivityDuplicateFinderBinding.inflate(layoutInflater)
        setContentView(mBinding.root)

        initActions()
        loadAds()

//        getImages()
//        getVideos()

        mBinding.imgBack.setOnClickListener {
            onBackPressed()
        }
    }

    fun initActions() {
        mBinding.llScanImages.setOnClickListener(this)
        mBinding.llScanAudio.setOnClickListener(this)
        mBinding.llScanVideo.setOnClickListener(this)
        mBinding.llScanDocument.setOnClickListener(this)
        mBinding.llScanOther.setOnClickListener(this)
    }

    private fun loadAds() {
        NativeAdHelper(
            this,
            mBinding.layoutBanner.mFLAd,
            mBinding.llAdPlace,
            NativeLayoutType.NativeBig,
            getString(R.string.native_finder)
        ).loadAd();
    }

    private fun getImages() {
        Log.e("JunkScanActivity", "getImages")
        val mCursor: Cursor?
        val folderList: MutableList<String> = ArrayList<String>()

        try {
            val BUCKET_DISPLAY_NAME: String
            BUCKET_DISPLAY_NAME = MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
            val projection = arrayOf(
                MediaStore.Images.Media.DATA,
                BUCKET_DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_MODIFIED,
                MediaStore.MediaColumns.DATE_TAKEN,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.SIZE,
            )

            val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            } else {
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            }

            val selection = getSelectionQuery()
            val selectionArgs = getSelectionArgsQuery().toTypedArray()

            mCursor = contentResolver?.query(
                uri,  // Uri
                projection,  // Projection
                selection,
                selectionArgs,
                MediaStore.MediaColumns.DATE_MODIFIED + " DESC"
            )
            if (mCursor != null) {
                mCursor.moveToFirst()
                while (!mCursor.isAfterLast) {
                    //2sec
                    val path = mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))
                    val title =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME))
                    var bucketPath = ""
                    bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
                    var bucketName =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(BUCKET_DISPLAY_NAME))
                    if (bucketName == null) bucketName = path.getParentFolder()

                    val fileSizeLength =
                        mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))


                    if (!folderList.contains(bucketPath) && !bucketName.isNullOrEmpty()) {
                        var d =
                            mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED))
                        d *= 1000
                        var dt =
                            mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))
                        dt *= 1000
                        if (dt == 0L)
                            dt = d

                        val pictureData =
                            PictureData(path, title, bucketName, d, dt, fileSizeLength, false)
                        allPhotos.add(pictureData)

                    }
                    mCursor.moveToNext()
                }
                mCursor.close()
            } else Log.e("JunkScanActivity.001", "getImages.mCursor.null::")
        } catch (e: Exception) {
            Log.e("JunkScanActivity.001", "getImages.Exception::$e")
        }
        totalphotoCounter+=allPhotos.size
        scanPhoto()
    }

    private fun getVideos() {
        Log.e("JunkScanActivity", "getVideos")
        var title: String
        var path: String
        val duration: Int
        val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else MediaStore.Video.Media.EXTERNAL_CONTENT_URI

        val projection = arrayOf(
            MediaStore.Video.VideoColumns.DATA,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.VideoColumns.SIZE,
            MediaStore.Video.VideoColumns.DURATION,
            MediaStore.Video.VideoColumns.DATE_MODIFIED,
            MediaStore.Video.VideoColumns.DATE_TAKEN,
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
        )

        val folderList: MutableList<String> = ArrayList<String>()

        try {
            val selection = getSelectionQuery()
            val selectionArgs = getSelectionArgsQuery().toTypedArray()

            val cursor = contentResolver?.query(
                uri,
                projection,
                selection,
                selectionArgs,
                MediaStore.Video.VideoColumns.DATE_MODIFIED + " DESC"
            )

            if (cursor != null) {
                duration = cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DURATION)
                cursor.moveToFirst()
                while (!cursor.isAfterLast) {
                    path =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA))
                    title =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME))
                    var bucketName =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME))
                    if (bucketName == null) bucketName = path.getParentFolder()

                    var bucketPath = ""
                    bucketPath = path.substring(0, path.lastIndexOf(title) - 1)

                    if (!folderList.contains(bucketPath)) {
                        var d =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DATE_MODIFIED))
                        d *= 1000
                        val fileSizeLength =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
                        var dt =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))

                        dt *= 1000
                        if (dt == 0L)
                            dt = d

                        val pictureData = PictureData(
                            path,
                            title,
                            bucketName,
                            d,
                            dt,
                            fileSizeLength,
                            true,
                            cursor.getLong(duration)
                        )
                        pictureData.isVideo = true
                        allVideo.add(pictureData)
                    }
                    cursor.moveToNext()
                }
                cursor.close()
            } else
                Log.e("JunkScanActivity.001", "getVideos.mCursor.null::")
        } catch (exp: java.lang.Exception) {
            Log.e("JunkScanActivity.001", "Exception.getVideos::$exp")
            exp.printStackTrace()
        }
        totalvideoCounter+=allVideo.size
        scanVideo()
    }

    private fun scanPhoto() {
        val albums = ArrayList<AlbumData>()
        CoroutineScope(Dispatchers.IO).launch {
            val photoData: ArrayList<PictureData> = ArrayList()
            allPhotos.map { photo ->
                async(Dispatchers.IO) {
                    // Minimize object creation
                    val bucketMd5 = try {
                        File(photo.filePath).md5()
                    } catch (e: Exception) {
                        ""
                    }
                    photo.bucketPath = bucketMd5
                    photoCounter++
                    updatePhotoPercentage()
                    photo
                }
            }.awaitAll().let {
                photoData.addAll(it)
            }
            Log.e("scanPhoto", "duplicate:photoData:${photoData.size}")
            val groupedPhotoData: Map<String, List<PictureData>> = photoData.groupBy { it.bucketPath }
            Log.e("scanPhoto", "duplicate:groupedPhotoData:${groupedPhotoData.size}")

            duplicatePhotoData = groupedPhotoData.filter { (_, list) ->
                list.size > 1
            }
            Log.e("scanPhoto", "duplicate:multiPhotoGroups:${duplicatePhotoData.size}")
            val bucketKeys: Set<String> = duplicatePhotoData.keys
            val listFolderkeys = java.util.ArrayList(bucketKeys)

            Log.e("scanPhoto", "listPhotoFolderkeys:${listFolderkeys.size}==>${listFolderkeys}")
            for (index in listFolderkeys.indices) {
                val list = duplicatePhotoData[listFolderkeys[index]]
                list?.let {
                    val bucketData = AlbumData()//.toClass(listFolderkeys[index], "Set ${index + 1}", "", MEDIA_ITEM_TYPE_HEADER_ID, fileSize = it.size.toLong())
                    bucketData.title = "Set ${index + 1}"
                    bucketData.isCustomAlbum = true
                    bucketData.pictureData = it as ArrayList<PictureData>
//                    pictures.addAll(it)
                    albums.add(bucketData)
                    Log.e("scanPhoto", "duplicate photo set:${index}==>${it.size}")
                }
            }
            Log.e("scanPhoto", "duplicatePhotoData==>${albums.size}")
            photoAlbumList = albums

//            val totalFileSize: Long = albums.sumOf { it.fileSize }
            val totalFileSize = albums.sumOf { album ->
                album.pictureData.sumOf { picture ->
                    picture.fileSize
                }
            }
            totalSize += totalFileSize
            val size = Formatter.formatShortFileSize(this@DuplicateFinderActivity, totalFileSize)
            runOnUiThread {
                isDuplicatePhotoRunning = false
                Log.e("scanPhoto", "isDuplicatePhotoRunning==>$isDuplicatePhotoRunning")
                mBinding.tvSubTitleDuplicatePhoto.setText(getString(R.string.n_sets_be_cleaned, bucketKeys.size))
                mBinding.tvDuplicatePhotoSize.setText(size)
                mBinding.arrowDuplicatePhoto.beVisible()
                mBinding.progressDuplicatePhoto.beGone()
                updateFinalResult()
            }
        }
    }

    private fun scanVideo() {
        val albums = ArrayList<AlbumData>()
        CoroutineScope(Dispatchers.IO).launch {
            val photoData: ArrayList<PictureData> = ArrayList()
            allVideo.map { photo ->
                async(Dispatchers.IO) {
                    // Minimize object creation
                    val bucketMd5 = try {
                        File(photo.filePath).md5()
                    } catch (e: Exception) {
                        ""
                    }
                    photo.bucketPath = bucketMd5
                    videoCounter++
                    updateVideoPercentage()
                    photo
                }
            }.awaitAll().let {
                photoData.addAll(it)
            }
            Log.e("scanVideo", "duplicate:videoData:${photoData.size}")
            val groupedPhotoData: Map<String, List<PictureData>> = photoData.groupBy { it.bucketPath }
            Log.e("scanVideo", "duplicate:groupedVideoData:${groupedPhotoData.size}")

            duplicateVideoData = groupedPhotoData.filter { (_, list) ->
                list.size > 1
            }
            Log.e("scanVideo", "duplicate:multiVideoGroups:${duplicateVideoData.size}")
            val bucketKeys: Set<String> = duplicateVideoData.keys
            val listFolderkeys = java.util.ArrayList(bucketKeys)

            Log.e("scanVideo", "listVideoFolderkeys:${listFolderkeys.size}==>${listFolderkeys}")
            for (index in listFolderkeys.indices) {
                val list = duplicateVideoData[listFolderkeys[index]]
                list?.let {
                    val bucketData = AlbumData()//.toClass(listFolderkeys[index], "Set ${index + 1}", "", MEDIA_ITEM_TYPE_HEADER_ID, fileSize = it.size.toLong())
                    bucketData.title = "Set ${index + 1}"
                    bucketData.isCustomAlbum = true
                    bucketData.pictureData = it as ArrayList<PictureData>
//                    pictures.addAll(it)
                    albums.add(bucketData)
                    Log.e("scanVideo", "duplicate video set:${index}==>${it.size}")
                }
            }
            Log.e("scanVideo", "duplicateVideoData==>${albums.size}")
            videoAlbumList = albums

//            val totalFileSize: Long = albums.sumOf { it.fileSize }
            val totalFileSize = albums.sumOf { album ->
                album.pictureData.sumOf { picture ->
                    picture.fileSize
                }
            }

            totalSize += totalFileSize
            val size = Formatter.formatShortFileSize(this@DuplicateFinderActivity, totalFileSize)
            runOnUiThread {
                isDuplicateVideoRunning = false
                Log.e("scanVideo", "isDuplicateVideoRunning==>$isDuplicateVideoRunning")
                mBinding.tvSubTitleDuplicateVideo.setText(getString(R.string.n_sets_be_cleaned, bucketKeys.size))
                mBinding.tvDuplicateVideoSize.setText(size)
                mBinding.arrowDuplicateVideo.beVisible()
                mBinding.progressDuplicateVideo.beGone()
                updateFinalResult()
            }
        }

    }

    private fun updatePhotoPercentage() {
        runOnUiThread {
            val percent: Float = (photoCounter / totalphotoCounter) * 100
//            Log.e("JunkScanActivity", "updatePhotoPercentage:${percent},${totalphotoCounter},${photoCounter}")
            mBinding.tvDuplicatePhotoSize.setText("${percent.toInt()}%")
        }
    }
    private fun updateVideoPercentage() {
        runOnUiThread {
            val percent: Float = (videoCounter / totalvideoCounter) * 100
//            Log.e("JunkScanActivity", "updateVideoPercentage:${percent},${totalvideoCounter},${videoCounter}")
            mBinding.tvDuplicateVideoSize.setText("${percent.toInt()}%")
        }
    }

    private fun updateFinalResult() {

    }

    private fun getSelectionQuery(): String {
        val query = StringBuilder()
//        if (filterMedia and TYPE_IMAGES != 0) {
        photoExtensions.forEach {
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }
        query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")

        rawExtensions.forEach {
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }
        query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//        }

//        if (filterMedia and TYPE_VIDEOS != 0) {
        videoExtensions.forEach {
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }
//        }

//        if (filterMedia and TYPE_GIFS != 0) {
        query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//        }


        return query.toString().trim().removeSuffix("OR")
    }

    private fun getSelectionArgsQuery(): ArrayList<String> {
        val args = ArrayList<String>()
//        if (filterMedia and TYPE_IMAGES != 0) {
        photoExtensions.forEach {
            args.add("%$it")
        }
        args.add("%.jpg")
        args.add("%.jpeg")
        rawExtensions.forEach {
            args.add("%$it")
        }
        args.add("%.svg")
//        }
//        if (filterMedia and TYPE_VIDEOS != 0) {
        videoExtensions.forEach {
            args.add("%$it")
        }
//        }

//        if (filterMedia and TYPE_GIFS != 0) {
        args.add("%.gif")
//        }

        return args
    }

    override fun onClick(view: View) {

        when (view.id) {
            R.id.llScanImages -> {
                var intent = Intent(this, ScanningDuplicateActivity::class.java)
                intent.putExtra("IsCheckType", "Image")
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
            }

            R.id.llScanAudio -> {
                var intent = Intent(this, ScanningDuplicateActivity::class.java)
                intent.putExtra("IsCheckType", "Audio")
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
            }

            R.id.llScanVideo -> {
                var intent = Intent(this, ScanningDuplicateActivity::class.java)
                intent.putExtra("IsCheckType", "Video")
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
            }

            R.id.llScanDocument -> {
                var intent = Intent(this, ScanningDuplicateActivity::class.java)
                intent.putExtra("IsCheckType", "Document")
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
            }

            R.id.llScanOther -> {
                var intent = Intent(this, ScanningDuplicateActivity::class.java)
                intent.putExtra("IsCheckType", "Other")
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
            }
        }
    }
}