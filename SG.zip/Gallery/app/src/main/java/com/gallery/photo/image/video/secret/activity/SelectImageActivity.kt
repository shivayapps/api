package com.gallery.photo.image.video.secret.activity

import android.app.Activity
import android.database.Cursor
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.AdapterView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.base.BaseNoThemeActivity
import com.gallery.photo.image.video.databinding.ActivitySelectImageBinding
import com.gallery.photo.image.video.dialog.ConfirmationDialog
import com.gallery.photo.image.video.extension.getParentFolder
import com.gallery.photo.image.video.extension.openPath
import com.gallery.photo.image.video.extension.toast
import com.gallery.photo.image.video.model.AlbumData
import com.gallery.photo.image.video.model.PictureData
import com.gallery.photo.image.video.secret.adapter.SelectAlbumAdapter
import com.gallery.photo.image.video.secret.adapter.SelectImageAdapter
import com.gallery.photo.image.video.secret.adapter.SelectImageListAdapter
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.Preferences
import com.gallery.photo.image.video.utils.TYPE_GIFS
import com.gallery.photo.image.video.utils.TYPE_IMAGES
import com.gallery.photo.image.video.utils.TYPE_VIDEOS
import com.gallery.photo.image.video.utils.Utils
import com.gallery.photo.image.video.utils.ensureBackgroundThread
import com.gallery.photo.image.video.utils.photoExtensions
import com.gallery.photo.image.video.utils.rawExtensions
import com.gallery.photo.image.video.utils.videoExtensions
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import vi.imagestopdf.CreatePDFListener
import vi.imagestopdf.PDFEngine
import java.io.File
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Locale

class SelectImageActivity : BaseNoThemeActivity() {

    lateinit var binding: ActivitySelectImageBinding
    lateinit var preferences: Preferences
    var albumList: ArrayList<AlbumData> = ArrayList()
    val allImages: ArrayList<PictureData> = ArrayList()
    val selectedImageList: ArrayList<PictureData> = ArrayList()
    var spinnerAdapter: SelectAlbumAdapter? = null
    var pictures = ArrayList<Any>()
    var pictureAdapter: SelectImageAdapter? = null
    var selectImageAdapter: SelectImageListAdapter? = null
    var selectAlbumPath: String = ""
    var spinnerPos = -1
    var openType = 0
    var includeVideo = true
    lateinit var dropdownAnimation: Animation

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySelectImageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        intView()
        intListener()
        setRvLayoutManager()
        loadBanner()
    }

    private fun intView() {

        binding.loutBottomSelect.visibility = View.GONE
        openType = intent.getIntExtra(Constant.EXTRA_SELECT_TYPE, 0)
        includeVideo = intent.getBooleanExtra(Constant.EXTRA_INCLUDE_VIDEO, true)

        if (openType == Constant.SELECT_TYPE_CRATE_ALBUM) {
            selectAlbumPath = intent.getStringExtra(Constant.EXTRA_ALBUM_PATH) ?: ""
        }

        if (openType == Constant.SELECT_TYPE_HIDE) {
            binding.btDone.text = getString(R.string.hide)
        }

        preferences = Preferences(this)
        dropdownAnimation = AnimationUtils.loadAnimation(this, R.anim.dropdown_animation)
        getData()
        setSelectAdapter()
    }

    private fun loadBanner() {
//        val isFirstSession=preferences.splashCounter==1
//        val adId=if(isFirstSession) getString(R.string.b_selectImageActivity) else getString(R.string.b_selectImageActivity2)
//        BannerAdHelper.showBanner(context = this, view = binding.layoutBanner.mFLAd,adId)
    }

    private fun setSelectAdapter() {
        selectImageAdapter = SelectImageListAdapter(this, selectedImageList, deleteListener = {
            selectedImageList.removeAt(it)
            selectImageAdapter?.notifyDataSetChanged()
            pictureAdapter?.notifyDataSetChanged()
            checkSelectionEmpty()
        })
        binding.rvSelect.adapter = selectImageAdapter
    }

    private fun checkSelectionEmpty() {
        binding.loutBottomSelect.visibility =
            if (selectedImageList.isEmpty()) View.GONE else View.VISIBLE
        binding.tvImageSelect.text = "${selectedImageList.size} ${getString(R.string.selected)}"
    }

    var isSpinnerOpen = false
    var rotationAngle = 0f

    private fun intListener() {
        binding.icBack.setOnClickListener { finish() }
        binding.icDelete.setOnClickListener {
            val confirmationDialog = ConfirmationDialog(
                this,
                getString(R.string.clear_all),
                getString(R.string.clear_all_msg),
                getString(R.string.yes),
                positiveBtnClickListener = {
                    selectedImageList.clear()
                    selectImageAdapter?.notifyDataSetChanged()
                    pictureAdapter?.notifyDataSetChanged()
                    checkSelectionEmpty()
                },
                false,
                getString(R.string.no)
            )
            confirmationDialog.show()
        }

        binding.btDone.setOnClickListener {
            if (selectedImageList.isNotEmpty()) {
                if (openType == Constant.SELECT_TYPE_CRATE_ALBUM) {
                    val file = File(selectAlbumPath)
                    if (!file.exists())
                        file.mkdirs()

                    Utils.copyFiles(
                        this,
                        selectAlbumPath,
                        selectedImageList,
                        selectedImageList.size,
                        copyListener = {
                            preferences.refreshMedia = true
                            Toast.makeText(
                                this,
                                getString(R.string.import_successfully),
                                Toast.LENGTH_SHORT
                            ).show()
                            finish()
                        }
                    )
                } else if (openType == Constant.SELECT_TYPE_CRATE_PDF) {
                    pdfImages()
                } else if (openType == Constant.SELECT_TYPE_HIDE) {
                    hidePhoto()
                }
            }
        }
        binding.spinner.viewTreeObserver?.addOnWindowFocusChangeListener { hasFocus -> //This updates the arrow icon up/down depending on Spinner opening/closing
            Log.e("spinnerTag", "addOnWindowFocusChangeListener $hasFocus ")
            if (hasFocus) {
                // spinner close
                rotationAngle = if (rotationAngle == 0f) 180f else 0f
                binding.ivDropDown.animate().rotation(rotationAngle).setDuration(500).start()
            } else {
                // spinner open
                rotationAngle = if (rotationAngle == 0f) 180f else 0f
                binding.ivDropDown.animate().rotation(rotationAngle).setDuration(500).start()
            }
        }
        binding.spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                Log.e("spinnerTag", "onItemSelected")
                if (position != -1)
                    binding.txtItemSpinner.text = albumList[position].title

                if (spinnerPos != position)
                    setImageAdapter(position)
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                Log.e("spinnerTag", "onNothingSelected")
            }

        }
    }

    private fun pdfImages() {
//        Constant.selectedImageList = ArrayList()
//        Constant.selectedImageList.addAll(selectedImageList)

        if (selectedImageList.size == 0) {
            toast(getString(R.string.PleaseSelectImage))
        } else {
            ensureBackgroundThread {

                val uris = ArrayList<File>()
                for (i in selectedImageList.indices) {
                    if (selectedImageList[i] is PictureData) {
                        val model = selectedImageList[i] as PictureData
//                            val uri = FileProvider.getUriForFile(
//                                mActivity!!,
//                                mActivity?.packageName + ".provider",
//                                File(model.filePath)
//                            )
                            uris.add(File(model.filePath))
                    }
                }
                runOnUiThread {
                    var filename = System.currentTimeMillis().toString()
                    val quality = 80
                    PDFEngine.getInstance().createPDF(this, uris, object : CreatePDFListener {
                        override fun onPDFGenerated(pdfFile: File?, numOfImages: Int) {

                            if (pdfFile != null) {
                                if (pdfFile.exists()) {
                                    try {
                                        MediaScannerConnection.scanFile(
                                            this@SelectImageActivity, arrayOf(pdfFile.absolutePath),
                                            null, null
                                        )
                                    } catch (e: Exception) {
                                    }
                                    Log.d("TAG", "onPDFGenerated:  Pdf file -->" + pdfFile!!.absolutePath)
                                    Log.d("TAG", "onPDFGenerated:  numberofPages -->" + numOfImages)
                                    toast("Your pdf is saved at ${pdfFile.absolutePath}")

                                    openPath(pdfFile.absolutePath, true)
                                }
                            }
                        }
                    }, filename, false, quality, true)
                }
            }
        }
        setResult(Activity.RESULT_OK)
        finish()
    }

    private fun hidePhoto() {
        Constant.selectedImageList = ArrayList()
        Constant.selectedImageList.addAll(selectedImageList)
        setResult(Activity.RESULT_OK)
        finish()
    }

    private fun setImageAdapter(position: Int) {
        pictures.clear()
        pictures.addAll(albumList[position].folderImageList)
        pictureAdapter = SelectImageAdapter(this, pictures,
            selectedImageList,
            clickListener = {
//                val pictureData = pictures[it] as PictureData
//                if (pictureData.isCheckboxVisible) {
//                    pictureData.isSelected = !pictureData.isSelected
//                    pictureAdapter?.notifyItemChanged(it)
////                    setSelectedFile()
//                }

                if (pictures[it] is PictureData) {
                    val pictureData = pictures[it] as PictureData
                    pictureData.isSelected = !pictureData.isSelected
                    if (selectedImageList.contains(pictureData)) {
                        selectedImageList.remove(pictureData)
                    } else {
                        selectedImageList.add(pictureData)
                    }
                    pictureAdapter?.notifyItemChanged(it)
                    selectImageAdapter?.notifyDataSetChanged()
                    checkSelectionEmpty()
                }
            },
            headerSelectListener = {
                if (pictures[it] is AlbumData) {
                    val albumData = pictures[it] as AlbumData
                    val isSelectAll = !albumData.isSelected
                    albumData.isSelected = isSelectAll
                    var pos = it + 1
                    while (pos < pictures.size) {
                        if (pictures[pos] is PictureData) {
                            val model = pictures[pos] as PictureData
                            model.isSelected = isSelectAll
                            pos++
                            if (isSelectAll) {
                                if (!selectedImageList.contains(model)) {
                                    selectedImageList.add(model)
                                }
                            } else {
                                if (selectedImageList.contains(model)) {
                                    selectedImageList.remove(model)
                                }
                            }
                        } else if (pictures[pos] is AlbumData) {
                            break
                        }
                    }
                    selectImageAdapter?.notifyDataSetChanged()
                    pictureAdapter?.notifyDataSetChanged()
                    checkSelectionEmpty()
                }
            })

        binding.pictureRecycler.adapter = pictureAdapter
    }

    fun setSelectedFile() {

    }

    fun setRvLayoutManager() {
        val gridCount = preferences.getGridCount()
        val gridLayoutManager =
            GridLayoutManager(this, gridCount, RecyclerView.VERTICAL, false)
        binding.pictureRecycler.layoutManager = gridLayoutManager
        gridLayoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                if (position >= 0 && position < pictures.size) {
                    return if (pictureAdapter!!.getItemViewType(position) === pictureAdapter!!.ITEM_HEADER_TYPE) {
                        gridCount
                    } else 1
                } else {
                    return 1
                }
            }
        }
    }

    private fun setData() {
        binding.progressBar.visibility = View.GONE
        setEmptyData()
        checkSelectionEmpty()

        if (albumList.isNotEmpty()) {
            spinnerAdapter = SelectAlbumAdapter(this, albumList)
            binding.spinner.adapter = spinnerAdapter
            binding.spinner.setSelection(0)
//            setImageAdapter(0)
        }
    }

    private fun setEmptyData() {
        if (albumList != null && albumList.size != 0) {
            binding.pictureRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
        } else {
            binding.pictureRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
        }
    }

    private fun getData() {
        binding.progressBar.visibility = View.VISIBLE
        Observable.fromCallable<Boolean> {

            getImages()
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { throwable: Throwable? ->
                runOnUiThread {
                    setFilterData()
                }
            }
            .subscribe { result: Boolean? ->
                runOnUiThread {
                    setFilterData()
                }
            }
    }

    fun setFilterData() {
        binding.progressBar.visibility = View.VISIBLE
        Observable.fromCallable {
            sortAlbumMain()
            sortPhotos()
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread { setDataList() }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread { setDataList() }
            }
    }

    private fun setDataList() {
        Observable.fromCallable {
            setList()
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread { setData() }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread { setData() }
            }
    }

    private fun setList() {

        if (allImages.isNotEmpty()) {
            val albumData = AlbumData()
            albumData.title = "All"
            albumData.pictureData = allImages
            albumList.add(0, albumData)
        }
        val format = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)

        if (albumList.isNotEmpty()) {
            for (a in albumList.indices) {

                val dateWisePictures = LinkedHashMap<String, ArrayList<PictureData>>()
                val picturesList: ArrayList<Any> = ArrayList()
                for (pictureData in albumList[a].pictureData) {
                    val strDate = format.format(pictureData.date)
                    var imagesData1: ArrayList<PictureData> = ArrayList()
                    if (dateWisePictures.containsKey(strDate)) {
                        val list: ArrayList<PictureData>? = dateWisePictures[strDate]
                        if (!list.isNullOrEmpty())
                            imagesData1.addAll(list)
                    } else {
                        imagesData1 = ArrayList()
                    }
                    imagesData1.add(pictureData)
                    dateWisePictures[strDate] = imagesData1

                }
                val keys: Set<String> = dateWisePictures.keys
                val listKeys = ArrayList(keys)

                for (i in listKeys.indices) {
                    val imagesData = dateWisePictures[listKeys[i]]
                    if (imagesData != null && imagesData.size != 0) {
                        val bucketData = AlbumData(listKeys[i], imagesData)
                        picturesList.add(bucketData)
                        picturesList.addAll(imagesData)
                    }
                }

                albumList[a].folderImageList = picturesList
            }
        }

    }

    private fun sortAlbumMain() {
        val sortType = preferences.getSortType()
        val sortOrder = preferences.getSortOrder()

        albumList.sortWith(Comparator { p1, p2 ->
            if (sortType == Constant.SORT_NAME) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.title.compareTo(p2.title, true)
                else
                    p2.title.compareTo(p1.title, true)
            } else if (sortType == Constant.SORT_PATH) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.folderPath.compareTo(p2.folderPath, true)
                else
                    p2.folderPath.compareTo(p1.folderPath, true)
            } else if (sortType == Constant.SORT_SIZE) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.fileSize.compareTo(p2.fileSize)
                else
                    p2.fileSize.compareTo(p1.fileSize)
            } else if (sortType == Constant.SORT_LAST_MODIFIED) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.date.compareTo(p2.date)
                else
                    p2.date.compareTo(p1.date)
            } else if (sortType == Constant.SORT_DATE_TAKEN) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.date.compareTo(p2.date)
                else
                    p2.date.compareTo(p1.date)
            } else
                p2.date.compareTo(p1.date)
        })
    }

    private fun sortPhotos() {
        val sortType = preferences.getSortType()
        val sortOrder = preferences.getSortOrder()

        for (albumData in albumList) {
            Collections.sort(albumData.pictureData, Comparator { p1, p2 ->
                if (sortType == Constant.SORT_NAME) {
                    if (sortOrder == Constant.ORDER_ASCENDING)
                        p1.fileName.compareTo(p2.fileName, true)
                    else
                        p2.fileName.compareTo(p1.fileName, true)
                } else if (sortType == Constant.SORT_PATH) {
                    if (sortOrder == Constant.ORDER_ASCENDING)
                        p1.filePath.compareTo(p2.filePath, true)
                    else
                        p2.filePath.compareTo(p1.filePath, true)
                } else if (sortType == Constant.SORT_SIZE) {
                    if (sortOrder == Constant.ORDER_ASCENDING)
                        p1.fileSize.compareTo(p2.fileSize)
                    else
                        p2.fileSize.compareTo(p1.fileSize)
                } else if (sortType == Constant.SORT_LAST_MODIFIED) {
                    if (sortOrder == Constant.ORDER_ASCENDING)
                        p1.date.compareTo(p2.date)
                    else
                        p2.date.compareTo(p1.date)
                } else if (sortType == Constant.SORT_DATE_TAKEN) {
                    if (sortOrder == Constant.ORDER_ASCENDING)
                        p1.dateTaken.compareTo(p2.dateTaken)
                    else
                        p2.dateTaken.compareTo(p1.dateTaken)
                } else
                    p2.date.compareTo(p1.date)
            })


        }
    }

    var albumWisePictures = LinkedHashMap<String, ArrayList<PictureData>>()
    private fun getImages() {
        albumList.clear()
        albumWisePictures.clear()

        val folderList: MutableList<String> = ArrayList()
//        val favList: ArrayList<String> = ArrayList()
//        favList.addAll(preferences.getFavoriteList())
//        albumCount = 0
        val mCursor: Cursor?
        try {
            val BUCKET_DISPLAY_NAME: String = MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
            val projection = arrayOf(
                MediaStore.Images.Media.DATA,
                BUCKET_DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_MODIFIED,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_TAKEN,
                MediaStore.MediaColumns.SIZE
            )
            val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            } else {
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            }
            val filterMedia = preferences?.getFilterMedia()!!
            val selection = getSelectionQuery(filterMedia)
            val selectionArgs = getSelectionArgsQuery(filterMedia).toTypedArray()
            mCursor = contentResolver.query(
                uri,  // Uri
                projection,  // Projection
                selection, selectionArgs,
                MediaStore.MediaColumns.DATE_MODIFIED + " DESC"
            )
            if (mCursor != null) {
                mCursor.moveToFirst()
                mCursor.moveToFirst()
                while (!mCursor.isAfterLast) {
                    //2sec
                    val path =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))
                    val title =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME))
                    val bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
                    if (!folderList.contains(bucketPath)) {

                        var bucketName =
                            mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME))
                        if (bucketName == null) bucketName = path.getParentFolder()

                        if (bucketName != null && bucketName.isNotEmpty()) {
                            var d =
                                mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED))
                            d *= 1000
                            val fileSizeLength =
                                mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
                            var dt =
                                mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))
                            dt *= 1000
                            if (dt == 0L)
                                dt = d
                            val pictureData =
                                PictureData(path, title, bucketName, d, dt, fileSizeLength, false)
//                            pictureData.isFavorite = favList.contains(path)
                            pictureData.bucketPath = bucketPath
                            pictureData.isCheckboxVisible = true

                            var imagesData2: ArrayList<PictureData> = ArrayList()
                            if (albumWisePictures.containsKey(bucketPath)) {
                                val list: ArrayList<PictureData>? = albumWisePictures[bucketPath]
                                if (!list.isNullOrEmpty())
                                    imagesData2.addAll(list)
                            } else {
                                imagesData2 = ArrayList()
                            }
                            imagesData2.add(pictureData)
                            allImages.add(pictureData)
                            albumWisePictures[bucketPath] = imagesData2
                        }
                    }
                    mCursor.moveToNext()
                }
                mCursor.close()
            }
        } catch (e: Exception) {
            Log.e("printStackTrace", "printStackTrace:$e")
        }
        getVideos()
    }

    private fun getVideos() {
        if(includeVideo) {
            var title: String
            var path: String
            val duration: Int
            val folderList: MutableList<String> = ArrayList<String>()
            val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            } else MediaStore.Video.Media.EXTERNAL_CONTENT_URI

            val projection = arrayOf(
                MediaStore.Video.VideoColumns.DATA,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.VideoColumns.SIZE,
                MediaStore.Video.VideoColumns.DURATION,
                MediaStore.Video.VideoColumns.DATE_MODIFIED,
                MediaStore.Video.VideoColumns.DATE_TAKEN,
                MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
            )
            try {
                val filterMedia = preferences?.getFilterMedia()!!
                val selection = getSelectionQuery(filterMedia)
                val selectionArgs = getSelectionArgsQuery(filterMedia).toTypedArray()

                val cursor = contentResolver.query(
                    uri,
                    projection,
                    selection, selectionArgs,
                    MediaStore.Video.VideoColumns.DATE_MODIFIED + " DESC"
                )
                if (cursor != null) {
                    duration = cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DURATION)
                    cursor.moveToFirst()
                    while (!cursor.isAfterLast) {
                        path =
                            cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA))
                        title =
                            cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME))

                        var bucketName =
                            cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME))
                        if (bucketName == null) bucketName = path.getParentFolder()

                        val bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
                        if (!folderList.contains(bucketPath)) {
                            var d =
                                cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DATE_MODIFIED))
                            d *= 1000
                            var dt =
                                cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))
                            dt *= 1000
                            if (dt == 0L)
                                dt = d
                            val fileSizeLength =
                                cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
//                        val pictureData = PictureData()
                            val pictureData = PictureData(
                                path,
                                title,
                                bucketName,
                                d,
                                dt,
                                fileSizeLength,
                                true,
                                cursor.getLong(duration)
                            )
                            pictureData.isVideo = true
//                        pictureData.isFavorite = favList.contains(path)
                            pictureData.bucketPath = bucketPath
                            pictureData.isCheckboxVisible = true

                            val imagesData2: ArrayList<PictureData> = ArrayList()
                            if (albumWisePictures.containsKey(bucketPath)) {
                                val list2: ArrayList<PictureData>? = albumWisePictures[bucketPath]
                                if (list2 != null)
                                    imagesData2.addAll(list2)
                            }
                            imagesData2.add(pictureData)
                            allImages.add(pictureData)
                            albumWisePictures[bucketPath] = imagesData2
                        }
                        cursor.moveToNext()
                    }
                    cursor.close()
                }
            } catch (exp: Exception) {
                exp.printStackTrace()
            }
        }


        val folderKeys: Set<String> = albumWisePictures.keys
        val listFolderkeys = java.util.ArrayList(folderKeys)
        for (i in listFolderkeys.indices) {
            val imagesData: java.util.ArrayList<PictureData> = ArrayList()
            val list = albumWisePictures[listFolderkeys[i]]
            if (list != null)
                imagesData.addAll(list)

            if (imagesData.size != 0 && imagesData[0].folderName.isNotEmpty()) {
                val albumData = AlbumData()
//                albumCount++
                albumData.title = imagesData[0].folderName
                albumData.pictureData = imagesData
                val folderPath = listFolderkeys[i]
                albumData.folderPath = folderPath
                val file = File(folderPath)
                albumData.date = file.lastModified()
                albumData.fileSize = file.length()
                albumData.isCheckboxVisible = true
                albumList.add(albumData)
//                albumBackupList.add(albumData)
            }
        }
    }


    private fun getSelectionQuery(filterMedia: Int): String {
        val query = StringBuilder()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")

            rawExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }

//        if (filterMedia and TYPE_RAWS != 0) {
//            rawExtensions.forEach {
//                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//            }
//        }

//        if (filterMedia and TYPE_SVGS != 0) {
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//        }
//        if (filterMedia and TYPE_PORTRAITS != 0) {
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
        }


        if (filterMedia and TYPE_GIFS != 0) {
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }


        return query.toString().trim().removeSuffix("OR")
    }

    private fun getSelectionArgsQuery(filterMedia: Int): ArrayList<String> {
        val args = ArrayList<String>()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.jpg")
            args.add("%.jpeg")
            rawExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.svg")
        }

//        if (filterMedia and TYPE_RAWS != 0) {
//            rawExtensions.forEach {
//                args.add("%$it")
//            }
//        }
//
//        if (filterMedia and TYPE_SVGS != 0) {
//            args.add("%.svg")
//        }
//        if (filterMedia and TYPE_PORTRAITS != 0) {
//            args.add("%.jpg")
//            args.add("%.jpeg")
//        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                args.add("%$it")
            }
        }

        if (filterMedia and TYPE_GIFS != 0) {
            args.add("%.gif")
        }


        return args
    }

}