package com.gallery.photo.image.video.jobs

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.Looper
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.gallery.photo.image.video.R

import org.json.JSONObject
import java.text.DecimalFormat

class MyWorker(context: Context, workerParams: WorkerParameters) : Worker(context, workerParams) {

    private var resultStatus: Result? = null

    override fun doWork(): Result {
        val strData = inputData.getString(EXTRA_CITY)
        return getCurrentWeather(strData)
    }

    private fun getCurrentWeather(strData: String?): Result {
        Log.d(TAG, "getCurrentWeather: Mulai.....")
        Looper.prepare()
//        showNotification("MyWorker","MyWorker Success")

        resultStatus = Result.success()
        return resultStatus as Result
    }

//    private fun showNotification(title: String, description: String?) {
//        val notificationManager =
//            applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
//        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
//            .setSmallIcon(R.drawable.baseline_notifications_24)
//            .setContentTitle(title)
//            .setContentText(description)
//            .setPriority(NotificationCompat.PRIORITY_HIGH)
//            .setDefaults(NotificationCompat.DEFAULT_ALL)
//
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            val channel = NotificationChannel(
//                CHANNEL_ID,
//                CHANNEL_NAME,
//                NotificationManager.IMPORTANCE_HIGH
//            )
//            notification.setChannelId(CHANNEL_ID)
//            notificationManager.createNotificationChannel(channel)
//        }
//        notificationManager.notify(NOTIFICATION_ID, notification.build())
//    }

    companion object {
        private val TAG = MyWorker::class.java.simpleName

        //        const val APP_ID = "654ff8e7ce5e3a90b2e954ad1e3a175a"
        const val EXTRA_CITY = "city"
        const val NOTIFICATION_ID = 1
        const val CHANNEL_ID = "channel_01"
        const val CHANNEL_NAME = "dicoding channel"
    }
}