plugins {
    alias(libs.plugins.android)
    alias(libs.plugins.kotlinAndroid)
    alias(libs.plugins.ksp)
    alias(libs.plugins.kotlinSerialization)
    alias(libs.plugins.parcelize)
    id("kotlin-kapt")
    id("com.google.gms.google-services")
    id("com.google.firebase.crashlytics")
    id("com.onesignal.androidsdk.onesignal-gradle-plugin")
}

android {
    namespace = "com.explorefile.filemanager"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.explorefile.filemanager"
        minSdk = 21
        targetSdk = 34
        versionCode = 27
        versionName = "2.7"
        multiDexEnabled = true
        vectorDrawables.useSupportLibrary = true
        ksp {
            arg("room.schemaLocation", "$projectDir/schemas")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )

            resValue("string", "ads_application_id", "ca-app-pub-2750800778809761~5821901570")
            resValue("string","b_fileType","ca-app-pub-2750800778809761/8256493228")
            resValue("string","b_main","ca-app-pub-2750800778809761/9206081840")
            resValue("string","native_all","ca-app-pub-2750800778809761/9353421501")
            resValue("string","open_all","ca-app-pub-2750800778809761/1021852955")
            resValue("string","inter_all","ca-app-pub-2750800778809761/2812594851")
        }

        debug {
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )

            resValue("string", "ads_application_id", "ca-app-pub-3940256099942544~3347511713")
            resValue("string","b_fileType","ca-app-pub-3940256099942544/9214589741")
            resValue("string","b_main","ca-app-pub-3940256099942544/9214589741")
            resValue("string","native_all","ca-app-pub-3940256099942544/2247696110")
            resValue("string","open_all","ca-app-pub-3940256099942544/9257395921")
            resValue("string","inter_all","ca-app-pub-3940256099942544/1033173712")
        }
    }

    buildFeatures {
        viewBinding = true
        dataBinding = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    api(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    api(libs.material)

    implementation(libs.androidx.swiperefreshlayout)
    implementation(libs.roottools)
    implementation(libs.rootshell)
    implementation(libs.gestureviews)
    implementation(libs.zip4j)
    implementation(libs.lottie)
    implementation(libs.androidx.constraintlayout)

    implementation(libs.androidx.fragment.ktx)

    api(libs.joda.time)
    api(libs.recyclerview.fastScroller)
    api(libs.rtl.viewpager)
    api(libs.gson)
    api(libs.glide)

    implementation("commons-io:commons-io:2.15.0")

    implementation(platform("com.google.firebase:firebase-bom:31.0.1"))
//    implementation 'com.google.firebase:firebase-perf'
    implementation("com.google.firebase:firebase-crashlytics")
    implementation("com.google.firebase:firebase-analytics")
    implementation("com.google.firebase:firebase-analytics-ktx")
    implementation("com.google.firebase:firebase-messaging")
    implementation("com.google.firebase:firebase-config")

//    implementation("com.google.firebase:firebase-crashlytics:18.5.0")
//    implementation("com.google.firebase:firebase-analytics:21.4.0")
//    implementation("com.google.firebase:firebase-messaging:23.3.0")
    ksp(libs.glide.compiler)

    api(libs.bundles.room)
    ksp(libs.androidx.room.compiler)
    implementation("androidx.multidex:multidex:2.0.0")
    implementation("com.onesignal:OneSignal:4.7.2")

    implementation("com.google.android.gms:play-services-ads:23.0.0")
    implementation(project(":ads"))
}