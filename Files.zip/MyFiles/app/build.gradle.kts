plugins {
    alias(libs.plugins.android)
    alias(libs.plugins.kotlinAndroid)
    alias(libs.plugins.ksp)
    alias(libs.plugins.kotlinSerialization)
    alias(libs.plugins.parcelize)
    id("com.google.gms.google-services")
    id("com.google.firebase.crashlytics")
    id("com.onesignal.androidsdk.onesignal-gradle-plugin")
//    `maven-publish`
}

android {
    namespace = "com.explorefile.filemanager"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.explorefile.filemanager"
        minSdk = 21
        targetSdk = 34
        versionCode = 26
        versionName = "2.6"
        multiDexEnabled = true
        vectorDrawables.useSupportLibrary = true
        ksp {
            arg("room.schemaLocation", "$projectDir/schemas")
        }
        resValue("string", "ads_application_id", "ca-app-pub-3940256099942544~3347511713")
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }

        debug {
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    api(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    api(libs.material)

    implementation(libs.androidx.swiperefreshlayout)
    implementation(libs.roottools)
    implementation(libs.rootshell)
    implementation(libs.gestureviews)
    implementation(libs.zip4j)
    implementation(libs.lottie)
    implementation(libs.androidx.constraintlayout)

    api(libs.joda.time)
    api(libs.recyclerView.fastScroller)
    api(libs.rtl.viewpager)
    api(libs.gson)
    api(libs.glide)

    implementation(platform("com.google.firebase:firebase-bom:31.0.1"))
//    implementation 'com.google.firebase:firebase-perf'
    implementation("com.google.firebase:firebase-crashlytics")
    implementation("com.google.firebase:firebase-analytics")
    implementation("com.google.firebase:firebase-analytics-ktx")
    implementation("com.google.firebase:firebase-messaging")
    implementation("com.google.firebase:firebase-config")

//    implementation("com.google.firebase:firebase-crashlytics:18.5.0")
//    implementation("com.google.firebase:firebase-analytics:21.4.0")
//    implementation("com.google.firebase:firebase-messaging:23.3.0")
    ksp(libs.glide.compiler)

    api(libs.bundles.room)
    ksp(libs.androidx.room.compiler)
    implementation("androidx.multidex:multidex:2.0.0")
    implementation("com.onesignal:OneSignal:4.7.2")

//    implementation("com.ads.module:adsconfig:1.1.0")
    implementation(project(":ads"))
}