package com.explorefile.filemanager.dialogs

import android.view.LayoutInflater
import android.view.WindowManager
import androidx.appcompat.app.AlertDialog
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.BaseActivity
import com.explorefile.filemanager.adapters.RenameAdapter
import com.explorefile.filemanager.databinding.DialogRenameBinding
import com.explorefile.filemanager.extensions.baseConfig
import com.explorefile.filemanager.extensions.getAlertDialogBuilder
import com.explorefile.filemanager.extensions.getProperBackgroundColor
import com.explorefile.filemanager.extensions.getProperPrimaryColor
import com.explorefile.filemanager.extensions.getProperTextColor
import com.explorefile.filemanager.extensions.onPageChangeListener
import com.explorefile.filemanager.extensions.onTabSelectionChanged
import com.explorefile.filemanager.extensions.setupDialogStuff
import com.explorefile.filemanager.helpers.RENAME_PATTERN
import com.explorefile.filemanager.helpers.RENAME_SIMPLE
import com.explorefile.filemanager.views.MyViewPager

class RenameDialog(
    val activity: BaseActivity,
    val paths: ArrayList<String>,
    val useMediaFileExtension: Boolean,
    val callback: () -> Unit
) {
    var dialog: AlertDialog? = null
    val view = DialogRenameBinding.inflate(LayoutInflater.from(activity), null, false)
    var tabsAdapter: RenameAdapter
    var viewPager: MyViewPager

    init {
        view.apply {
            viewPager = dialogTabViewPager
            tabsAdapter = RenameAdapter(activity, paths)
            viewPager.adapter = tabsAdapter
            viewPager.onPageChangeListener {
                dialogTabLayout.getTabAt(it)!!.select()
            }
            viewPager.currentItem = activity.baseConfig.lastRenameUsed

            dialogTabLayout.setBackgroundColor(root.context.getProperBackgroundColor())


            val textColor = root.context.getProperTextColor()
            dialogTabLayout.setTabTextColors(textColor, textColor)
            dialogTabLayout.setSelectedTabIndicatorColor(root.context.getProperPrimaryColor())


            dialogTabLayout.onTabSelectionChanged(tabSelectedAction = {
                viewPager.currentItem = when {
                    it.text.toString().equals(
                        root.context.resources.getString(R.string.simple_renaming),
                        true
                    ) -> RENAME_SIMPLE

                    else -> RENAME_PATTERN
                }
            })
        }

        activity.getAlertDialogBuilder()
            .apply {
                activity.setupDialogStuff(view.root, this) { alertDialog ->
                    dialog = alertDialog
                    alertDialog.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM)
                    view.txtOk.setOnClickListener {
                        tabsAdapter.dialogConfirmed(useMediaFileExtension, viewPager.currentItem) {
                            dismissDialog()
                            if (it) {
                                activity.baseConfig.lastRenameUsed = viewPager.currentItem
                                callback()
                            }
                        }
                    }

                    view.txtCancel.setOnClickListener {
                        dismissDialog()
                    }
                }
            }
    }

    private fun dismissDialog() {
        dialog?.dismiss()
    }
}
