package com.explorefile.filemanager.filecleaner

import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import com.adconfig.adsutil.admob.BannerAdHelper
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.BaseActivity
import com.explorefile.filemanager.databinding.ActivityStorageAnalysisBinding
import com.explorefile.filemanager.extensions.getProperBackgroundColor
import com.explorefile.filemanager.extensions.viewBinding
import com.explorefile.filemanager.filecleaner.viewmodel.StorageAnalysisVM
import com.explorefile.filemanager.helpers.AdCache
import com.explorefile.filemanager.helpers.NavigationIcon
import com.google.android.gms.ads.AdView


class StorageAnalysisActivity : BaseActivity(), View.OnClickListener {

    private val binding by viewBinding(ActivityStorageAnalysisBinding::inflate)

    private val storageAnalysisVM: StorageAnalysisVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        binding.analyzeToolbar.title= getString(R.string.storage_analysis)
        binding.apply {
            vm = storageAnalysisVM
            lifecycleOwner = this@StorageAnalysisActivity
            layoutItemScanResult.apply {
                vm = storageAnalysisVM
                activity = this@StorageAnalysisActivity
                lifecycleOwner = this@StorageAnalysisActivity
            }

        }.also {
            setContentView(it.root)
        }
        initAds()
    }

    var mAdView: AdView? = null
    var isAdLoaded = false
    private fun initAds() {
        val adId =getString(R.string.b_fileType)
        BannerAdHelper.showBanner(this,
            binding.frameAds,
            binding.frameAds,
            adId,
            AdCache.bannerFileType,
            { isLoaded, adView, message ->
                mAdView = adView
                AdCache.bannerFileType = adView
                isAdLoaded = isLoaded
            })
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }

    override fun onResume() {
        super.onResume()
        mAdView?.resume()
        setupToolbar(
            binding.analyzeToolbar,
            NavigationIcon.Arrow
        )
        updateTopBarColors(binding.analyzeToolbar, getProperBackgroundColor())
    }

    override fun onStart() {
        super.onStart()
        storageAnalysisVM.startScanStorage()
    }

    override fun onDestroy() {
        super.onDestroy()
        storageAnalysisVM.stopScanStorageIfNeed()
    }

    override fun onClick(v: View?) {

    }

}