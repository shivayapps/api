package com.explorefile.filemanager.filecleaner.entity

import java.io.File
import java.nio.file.Files
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicLong


data class FileScanResult(
    val fileQueue: ConcurrentLinkedQueue<File> = ConcurrentLinkedQueue(),
    val queueSize: AtomicLong = AtomicLong(0)
) {
    fun offerFileAndAddFileSize(file: File) {
        fileQueue.offer(file)
        queueSize.getAndAdd(Files.size(file.toPath()))
    }
}
