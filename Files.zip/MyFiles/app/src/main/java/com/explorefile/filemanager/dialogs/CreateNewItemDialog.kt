package com.explorefile.filemanager.dialogs

import android.view.View
import androidx.appcompat.app.AlertDialog
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.BaseActivity
import com.explorefile.filemanager.databinding.DialogCreateNewBinding
import com.explorefile.filemanager.extensions.createAndroidSAFDirectory
import com.explorefile.filemanager.extensions.getAlertDialogBuilder
import com.explorefile.filemanager.extensions.getDocumentFile
import com.explorefile.filemanager.extensions.getDoesFilePathExist
import com.explorefile.filemanager.extensions.getFilenameFromPath
import com.explorefile.filemanager.extensions.getParentPath
import com.explorefile.filemanager.extensions.internalStoragePath
import com.explorefile.filemanager.extensions.isAValidFilename
import com.explorefile.filemanager.extensions.isRestrictedSAFOnlyRoot
import com.explorefile.filemanager.extensions.needsStupidWritePermissions
import com.explorefile.filemanager.extensions.setupDialogStuff
import com.explorefile.filemanager.extensions.showErrorToast
import com.explorefile.filemanager.extensions.showKeyboard
import com.explorefile.filemanager.extensions.toast
import com.explorefile.filemanager.extensions.value
import com.explorefile.filemanager.helpers.RootHelpers
import com.explorefile.filemanager.helpers.isRPlus
import java.io.File

class CreateNewItemDialog(
    val activity: BaseActivity,
    val path: String,
    val callback: (success: Boolean) -> Unit
) {
    private val binding = DialogCreateNewBinding.inflate(activity.layoutInflater)

    init {
        activity.getAlertDialogBuilder()
            .apply {
                activity.setupDialogStuff(binding.root, this) { alertDialog ->
                    alertDialog.showKeyboard(binding.itemTitle)
                    binding.txtOk.setOnClickListener(View.OnClickListener {
                            val name = binding.itemTitle.value
                            if (name.isEmpty()) {
                                activity.toast(R.string.empty_name)
                            } else if (name.isAValidFilename()) {
                                val newPath = "$path/$name"
                                if (activity.getDoesFilePathExist(newPath)) {
                                    activity.toast(R.string.name_taken)
                                    return@OnClickListener
                                }
                                createDirectory(newPath, alertDialog) {
                                    callback(it)
                                }
                            } else {
                                activity.toast(R.string.invalid_name)
                            }
                        })

                    binding.txtCancel.setOnClickListener {
                        alertDialog.dismiss()
                    }
                }
            }
    }

    private fun createDirectory(
        path: String,
        alertDialog: AlertDialog,
        callback: (Boolean) -> Unit
    ) {
        when {
            isRPlus() || path.startsWith(activity.internalStoragePath, true) -> {
                if (activity.isRestrictedSAFOnlyRoot(path)) {
                    activity.handleAndroidSAFDialog(path) {
                        if (!it) {
                            callback(false)
                            return@handleAndroidSAFDialog
                        }
                        if (activity.createAndroidSAFDirectory(path)) {
                            success(alertDialog)
                        } else {
                            val error = String.format(
                                activity.getString(R.string.could_not_create_folder),
                                path
                            )
                            activity.showErrorToast(error)
                            callback(false)
                        }
                    }
                } else {
                    if (File(path).mkdirs()) {
                        success(alertDialog)
                    }
                }
            }

            activity.needsStupidWritePermissions(path) -> activity.handleSAFDialog(path) {
                if (!it) {
                    return@handleSAFDialog
                }

                val documentFile = activity.getDocumentFile(path.getParentPath())
                if (documentFile == null) {
                    val error =
                        String.format(activity.getString(R.string.could_not_create_folder), path)
                    activity.showErrorToast(error)
                    callback(false)
                    return@handleSAFDialog
                }
                documentFile.createDirectory(path.getFilenameFromPath())
                success(alertDialog)
            }

            else -> {
                RootHelpers(activity).createFileFolder(path, false) {
                    if (it) {
                        success(alertDialog)
                    } else {
                        callback(false)
                    }
                }
            }
        }
    }

    private fun success(alertDialog: AlertDialog) {
        alertDialog.dismiss()
        callback(true)
    }
}
