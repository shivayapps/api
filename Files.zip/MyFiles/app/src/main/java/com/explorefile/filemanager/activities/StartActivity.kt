package com.explorefile.filemanager.activities

import android.content.Intent
import android.os.Bundle
import com.adconfig.adsutil.admob.NativeAdHelper
import com.adconfig.adsutil.admob.NativeLayoutType
import com.explorefile.filemanager.databinding.ActivityStartBinding
import com.explorefile.filemanager.extensions.getProperBackgroundColor
import com.explorefile.filemanager.extensions.getProperTextColor
import com.explorefile.filemanager.extensions.viewBinding
import com.explorefile.filemanager.helpers.FIRST_TIME_KEY
import com.explorefile.filemanager.helpers.INTENT_KEY

class StartActivity : BaseActivity() {

    val binding by viewBinding(ActivityStartBinding::inflate)

    override fun onCreate(savedInstanceState: Bundle?) {
        isMaterialActivity = true
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.txtGetStart.setOnClickListener {
            startActivity(
                Intent(this, LanguageActivity::class.java).putExtra(
                    INTENT_KEY,
                    FIRST_TIME_KEY
                )
            )
            finish()
        }

//        if (SessionHelper(this).getStringData(SessionHelper.IS_GET_START_NATIVE_ON) == "1") {
//            NativeLoadWithShows(this).showNativeAdsShimmerEffects(this, binding.frameAds, 1)
//            NativeLoadWithShows(this).showNativeTopAlways(this, binding.frameAds)
//        } else if(SessionHelper(this).getStringData(SessionHelper.IS_GET_START_NATIVE_ON) == "0"){
//            AdUtils().loadMediumBanner(this, binding.frameAds)
//        }
//        NativeAdHelper(this,binding.frameAds, NativeLayoutType.NativeButtonTop).loadAd()
    }

    override fun onResume() {
        super.onResume()

        updateStatusbarColor(getProperBackgroundColor())

        arrayOf(
            binding.txtFile,
            binding.txtInfo
        ).forEach {
            it.setTextColor(getProperTextColor())
        }

    }
}