package com.explorefile.filemanager.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.adconfig.adsutil.openad.OpenAdHelper
import com.adconfig.adsutil.openad.OpenAdHelper.isShowOpenAd
import com.explorefile.filemanager.App.Companion.isAppIsRunning
import com.explorefile.filemanager.BuildConfig
import com.explorefile.filemanager.R
import com.explorefile.filemanager.databinding.ActivitySplashBinding
import com.explorefile.filemanager.extensions.addBit
import com.explorefile.filemanager.extensions.baseConfig
import com.explorefile.filemanager.extensions.config
import com.explorefile.filemanager.extensions.getContrastColor
import com.explorefile.filemanager.extensions.getProperBackgroundColor
import com.explorefile.filemanager.extensions.getProperTextColor
import com.explorefile.filemanager.extensions.isUsingSystemDarkTheme
import com.explorefile.filemanager.extensions.removeBit
import com.explorefile.filemanager.extensions.viewBinding
import com.explorefile.filemanager.helpers.DARK_GREY

class SplashActivity : AppCompatActivity() {
    val binding by viewBinding(ActivitySplashBinding::inflate)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        isAppIsRunning = false

//        if (isAppIsRunning) {
//            AdconfigApplication.adConfigFinishAffinity()
//        } else {
//            isAppIsRunning = true
//        }

        binding.layoutMain.setBackgroundColor(getProperBackgroundColor())
        updateStatusbarColor(getProperBackgroundColor())

//        splashAPICalling(
//            getIntentForOpenActivityAfterSplash(), "com.explorefile.filemanager.json",
//            BuildConfig.VERSION_NAME
//        )
//        OpenAdHelper.loadOpenAd(this) {
            Log.i("ADCONFIG_OpenAdHelper", "SplashActivity:loadOpenAd")
            isShowOpenAd {
                Log.i("ADCONFIG_OpenAdHelper", "SplashActivity:isShowOpenAd")
                startActivity(getIntentForOpenActivityAfterSplash())
                finish()
            }
//        }
        binding.textView.setTextColor(getProperTextColor())
    }

    private fun getIntentForOpenActivityAfterSplash(): Intent {
        return if (!config.isGetStarted) {
            Intent(this, StartActivity::class.java)
        } else {
            if (config.appRunCount == 0) {
                Intent(this, PermissionActivity::class.java)
            } else {
                if (intent.action == Intent.ACTION_VIEW && intent.data != null) {
                    Intent(this, MainActivity::class.java).apply {
                        action = Intent.ACTION_VIEW
                        data = intent.data
                    }
                } else {
                    Intent(this, MainActivity::class.java)
                }
            }
        }
    }

    private fun updateStatusbarColor(color: Int) {
        window.statusBarColor = color

        if (color.getContrastColor() == DARK_GREY) {
            window.decorView.systemUiVisibility =
                window.decorView.systemUiVisibility.addBit(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)
        } else {
            window.decorView.systemUiVisibility =
                window.decorView.systemUiVisibility.removeBit(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)
        }
    }

}
