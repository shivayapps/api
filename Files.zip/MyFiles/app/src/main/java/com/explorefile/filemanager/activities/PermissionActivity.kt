package com.explorefile.filemanager.activities

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import com.adconfig.adsutil.admob.NativeAdHelper
import com.adconfig.adsutil.admob.NativeLayoutType
import com.adconfig.adsutil.openad.OpenAdHelper
import com.adconfig.adsutil.openad.OpenAdHelper.isShowOpenAd

import com.explorefile.filemanager.App
import com.explorefile.filemanager.R
import com.explorefile.filemanager.databinding.ActivityPermissionBinding
import com.explorefile.filemanager.extensions.getProperBackgroundColor
import com.explorefile.filemanager.extensions.getProperTextColor
import com.explorefile.filemanager.extensions.showErrorToast
import com.explorefile.filemanager.extensions.toast
import com.explorefile.filemanager.extensions.viewBinding
import com.explorefile.filemanager.helpers.PERMISSION_WRITE_STORAGE
import com.explorefile.filemanager.helpers.isRPlus

class PermissionActivity : BaseActivity() {

    val binding by viewBinding(ActivityPermissionBinding::inflate)
    private val MANAGE_STORAGE_RC = 201

    override fun onBackPressed() {
        finishAffinity()
        //AdconfigApplication.adConfigFinishAffinity()
        App.isAppIsRunning = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        isMaterialActivity = true
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.txtGetPermission.setOnClickListener {
            tryInitFileManager()
        }

//        if (SessionHelper(this).getStringData(SessionHelper.IS_PERMISSION_NATIVE_ON) == "1") {
//            NativeLoadWithShows(this).showNativeAdsShimmerEffects(this, binding.frameAds, 1)
//            NativeLoadWithShows(this).showNativeTopAlways(this, binding.frameAds)
//        } else if (SessionHelper(this).getStringData(SessionHelper.IS_PERMISSION_NATIVE_ON) == "0") {
//            AdUtils().loadMediumBanner(this, binding.frameAds)
//        }

//        NativeAdHelper(this,binding.frameAds, NativeLayoutType.NativeButtonTop).loadAd()

    }

    private fun tryInitFileManager() {
        handleStoragePermission {
            if (it) {
//                OpenAdHelper.loadOpenAd(this) {
                    isShowOpenAd {
                        startActivity(
                            Intent(
                                this@PermissionActivity,
                                MainActivity::class.java
                            ).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        )
                        finish()
                    }
//                }
//                opedAdDismissCallback = object : OpedAdDismissCallback {
//                    override fun callBackCalled() {
//                        opedAdDismissCallback=null
//                        startActivity(Intent(this@PermissionActivity, MainActivity::class.java))
//                        finish()
//                    }
//                }
            } else {
                toast(R.string.no_storage_permissions)
            }
        }
    }

    @SuppressLint("InlinedApi")
    private fun handleStoragePermission(callback: (granted: Boolean) -> Unit) {
        actionOnPermission = null
        if (hasStoragePermission()) {
            callback(true)
        } else {
            if (isRPlus()) {
                isAskingPermissions = true
                actionOnPermission = callback
                try {
                    val intent =
                        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                    intent.addCategory("android.intent.category.DEFAULT")
                    intent.data = Uri.parse("package:$packageName")
//                    if (isPermissionOpen()){
                        App.disabledOpenAds()
//                    }
                    startActivityForResult(intent, MANAGE_STORAGE_RC)
                } catch (e: Exception) {
                    showErrorToast(e)
                    val intent = Intent()
                    intent.action = Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION
                    App.disabledOpenAds()
                    startActivityForResult(intent, MANAGE_STORAGE_RC)
                }
            } else {
                handlePermission(PERMISSION_WRITE_STORAGE, callback)
            }
        }
    }

    @SuppressLint("NewApi")
    override fun onActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
        super.onActivityResult(requestCode, resultCode, resultData)
        isAskingPermissions = false
        if (requestCode == MANAGE_STORAGE_RC && isRPlus()) {
            actionOnPermission?.invoke(Environment.isExternalStorageManager())
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatusbarColor(getProperBackgroundColor())
        arrayOf(
            binding.txtPermission,
            binding.txtInfo
        ).forEach {
            it.setTextColor(getProperTextColor())
        }
    }

}