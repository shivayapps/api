package com.adconfig.adsutil

import com.google.android.gms.ads.interstitial.InterstitialAd

object Config {

    var mInterstitialAd: InterstitialAd? = null

    var isLibraryInitialized = false
    var IS_DEBUG = false
    var isAdsEnable = true

    var isOpenAdEnable: Boolean = true
    var admobInterClick: Int = 3
    var admobInterstitialAdId: String = ""
    var admobAppOpenId: String = ""
    var admobBannerId: String = ""
    var admobNativeId: String = ""
    var admobRewardId: String = ""
}