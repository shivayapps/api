package com.adconfig.adsutil.admob

import com.adconfig.adsutil.Config

object AdmobIdUtils {

    fun processAdId(id: String, type: AdmobAds): String {
        return when (type) {
            AdmobAds.BANNER ->
                if (Config.IS_DEBUG)
                    AdmobTestIds.Banner
                else
                    id

            AdmobAds.NATIVE ->
                if (Config.IS_DEBUG)
                    AdmobTestIds.Native_Advanced
                else
                    id

            AdmobAds.INTERSTITIAL ->
                if (Config.IS_DEBUG)
                    AdmobTestIds.Interstitial
                else
                    id

            AdmobAds.INTERSTITIAL_REWARD ->
                if (Config.IS_DEBUG)
                    AdmobTestIds.Rewarded_Interstitial
                else
                    id

            AdmobAds.APP_OPEN ->
                if (Config.IS_DEBUG)
                    AdmobTestIds.App_Open
                else
                    id

            AdmobAds.REWARD ->
                if (Config.IS_DEBUG)
                    AdmobTestIds.Rewarded
                else
                    id
        }
    }


}

enum class AdmobAds {
    BANNER,
    NATIVE,
    REWARD,
    INTERSTITIAL,
    INTERSTITIAL_REWARD,
    APP_OPEN
}

enum class NativeLayoutType {
    NativeBanner,
    NativeMedium,
    NativeButtonTop,
    NativeButtonBottom,
    NativeBig,
    NativeAppStore,
    NativeWeb,
    NativeCustom
}