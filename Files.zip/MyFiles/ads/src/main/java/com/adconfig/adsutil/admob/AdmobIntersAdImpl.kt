package com.adconfig.adsutil.admob

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.adconfig.adsutil.Config
import com.adconfig.adsutil.abstract.IntersAd
import com.adconfig.adsutil.utils.AdsError

class AdmobIntersAdImpl : IntersAd() {

//    override val TAG = "AdmobInters"

    override fun destroy(){
        Config.mInterstitialAd=null
    }

    override fun show(activity: Activity) {
        Log.i("ADCONFIG_InterAd", "show")
        if (Config.mInterstitialAd == null) {
            Log.i("ADCONFIG_InterAd", "mInterstitialAd.null")

            loadInters(activity) { isLoaded,message, interstitial ->
                if(isLoaded) {
                    Config.mInterstitialAd = interstitial
                    Config.mInterstitialAd?.fullScreenContentCallback = fullScreenContentCallback
                    Config.mInterstitialAd?.show(activity)
                } else {
//                    adsListener.onAdDismissed()
                    adsListener.onAdFailedToShow(AdsError(0,message))
//                    fullScreenContentCallback.onAdDismissedFullScreenContent()
                }
            }

        } else {
            Config.mInterstitialAd?.show(activity)
            Config.mInterstitialAd?.fullScreenContentCallback = fullScreenContentCallback
        }
    }

    override fun load(context: Context) {
        Log.i("ADCONFIG_InterAd", "load")
        if (Config.mInterstitialAd == null) {
            loadInters(context) { isLoaded,message, interstitial ->
                if(isLoaded) {
                    Config.mInterstitialAd = interstitial
                } else {
                    adsListener.onAdFailedToShow(AdsError(0,message))
                }
            }
        }
    }

    private val fullScreenContentCallback = object : FullScreenContentCallback() {
        override fun onAdClicked() {
            super.onAdClicked()
            adsListener.onAdClicked()
        }

        override fun onAdDismissedFullScreenContent() {
            super.onAdDismissedFullScreenContent()
            adsListener.onAdDismissed()
        }

        override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
            super.onAdFailedToShowFullScreenContent(p0)
            adsListener.onAdFailedToShow(AdsError(p0.code, p0.message))
        }

        override fun onAdImpression() {
            super.onAdImpression()
            adsListener.onAdImpression()
        }

        override fun onAdShowedFullScreenContent() {
            super.onAdShowedFullScreenContent()
            adsListener.onAdShowed()
        }
    }

    private fun getAdRequest(): AdRequest {
        return AdRequest
            .Builder()
            .setHttpTimeoutMillis(3000)
            .build()
    }

    private fun loadInters(
        context: Context,
        onLoaded: (isLoaded: Boolean,message: String, interstitial: InterstitialAd?) -> Unit
    ) {
        Log.i("ADCONFIG_InterAd", "loadInters")
        val interAdId =
            AdmobIdUtils.processAdId(
                Config.admobInterstitialAdId,
                AdmobAds.INTERSTITIAL
            )

        InterstitialAd.load(
            context,
            interAdId,
            getAdRequest(),
            object : InterstitialAdLoadCallback() {
                override fun onAdFailedToLoad(p0: LoadAdError) {
                    super.onAdFailedToLoad(p0)
                    Log.i("ADCONFIG_InterAd", "onAdFailedToLoad:" + p0.message)
                    onLoaded.invoke(false, "${p0.code}\n${p0.message}\n${p0.responseInfo}",null)
                }

                override fun onAdLoaded(p0: InterstitialAd) {
                    Log.i("ADCONFIG_InterAd", "onAdLoaded")
                    onLoaded.invoke(true,"Success", p0)
                }
            }
        )
    }
}