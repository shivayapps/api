pluginManagement {
    repositories {
        gradlePluginPortal()
        google()
        mavenCentral()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven { setUrl("https://jitpack.io") }
//        maven {
//            url = uri("https://gitlab.com/api/v4/projects/49072224/packages/maven")
//
//            credentials(HttpHeaderCredentials::class) {
//                name = "Private-Token"
//                value = "glpat-iXRhwh4xmQ2ASPbVxbMx"
//            }
//
//            authentication {
//                create<HttpHeaderAuthentication>("header")
//            }
//        }
    }
}
rootProject.name = "My-Files"
enableFeaturePreview("TYPESAFE_PROJECT_ACCESSORS")
include(":app")
include(":ads")
