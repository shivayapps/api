/*
 * Copyright 2016 jiajunhui
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package com.jiajunhui.xapp.medialoader.bean;


public class VideoItem extends BaseItem {

    private long duration;
    public boolean checked;

    public VideoItem(int anInt, String displayName, String oripath, String newpath, long size, long duration, String mimeType) {
            this.id = anInt;
            this.displayName = displayName;
            this.path = oripath;
            this.newPath = newpath;
            this.size = size;
            this.duration = duration;
            this.mimeType = mimeType;
    }

    public VideoItem(int id, String displayName, String path, long size,  long duration,String mimeType) {
        super(id, displayName, path, size, duration, mimeType);
        this.duration = duration;
    }

    public VideoItem(int id, String displayName, String path, long size, long modified, long duration,String mimeType) {
        super(id, displayName, path, size, modified, mimeType);
        this.duration = duration;
    }

    public VideoItem() {

    }

    public long getDuration() {
        return duration;
    }

    public void setDuration(long duration) {
        this.duration = duration;
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }


    public static final String TABLE_NAME = "tabVideo";

    public static final String COLUMN_ID = "id";
    public static final String COLUMN_DNAME = "displayName";
    public static final String COLUMN_ORIPATH = "oripath";
    public static final String COLUMN_NEWPATH = "newpath";
    public static final String COLUMN_SIZE = "filesize";
    public static final String COLUMN_MIMETYPE = "mimeType";
    public static final String COLUMN_CLOUD_FILE_ID = "cloud_file_id";
    public static final String COLUMN_TRASH = "trash";

    // Create table SQL query
    public static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_DNAME + " TEXT,"
                    + COLUMN_ORIPATH + " TEXT,"
                    + COLUMN_NEWPATH + " TEXT,"
                    + COLUMN_SIZE + " LONG DEFAULT 0,"
                    + COLUMN_MIMETYPE + " TEXT,"
                    + COLUMN_CLOUD_FILE_ID + " TEXT DEFAULT null1,"
                    + COLUMN_TRASH + " INTEGER DEFAULT 0"
                    + ")";

}
