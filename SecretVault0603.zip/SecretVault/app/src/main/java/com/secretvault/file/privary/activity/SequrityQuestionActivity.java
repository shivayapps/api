package com.secretvault.file.privary.activity;

import android.accounts.AccountManager;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import com.secretvault.file.privary.R;
import com.secretvault.file.privary.db.DatabaseHelper;
import com.secretvault.file.privary.db.UserItem;
import com.secretvault.file.privary.utils.Connectivity;
import com.secretvault.file.privary.utils.PreferenceHelper;
import com.secretvault.file.privary.views.CustomTextView;
import com.google.api.client.extensions.android.http.AndroidHttp;
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.DriveScopes;

import java.util.Arrays;

public class SequrityQuestionActivity extends Activity implements View.OnClickListener {

    private static final String TAG = "SequrityQuestionActivity";
    private static final int REQUEST_ACCOUNT_PICKER = 0;
    public Drive service;
    Spinner spinnerQuestionList;
    EditText etAnswer;
    String questionValue;
    CustomTextView btn_submit;
    CustomTextView tv_question;
    DatabaseHelper databaseHelper;
    Context mContext;
    String QType = "";
    TextView txt_resetEmail;
    private GoogleAccountCredential credential;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_security_queation);
        mContext = SequrityQuestionActivity.this;
        QType = getIntent().getStringExtra("QType");
        Init();
    }

    private void Init() {
        databaseHelper = new DatabaseHelper(mContext);
        btn_submit = findViewById(R.id.btn_submit);
        etAnswer = findViewById(R.id.et_answer);
        spinnerQuestionList = findViewById(R.id.spinner_question);
        tv_question = findViewById(R.id.tv_question);

        if (QType.equalsIgnoreCase("Set")) {
            spinnerQuestionList.setVisibility(View.VISIBLE);
            tv_question.setVisibility(View.GONE);
        } else {
            spinnerQuestionList.setVisibility(View.GONE);
            tv_question.setVisibility(View.VISIBLE);
            String squestion = databaseHelper.getUser(1).getSquestion();
            tv_question.setText(squestion);
        }
        String[] stringQuestionList = getResources().getStringArray(R.array.array_question);
        final String[] stringQuestionvalue = getResources().getStringArray(R.array.array_question);
        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(mContext, R.layout.spinner_item, stringQuestionList);
        spinnerArrayAdapter.setDropDownViewResource(R.layout.spinner_item_dropdown);
        spinnerQuestionList.setAdapter(spinnerArrayAdapter);
        spinnerQuestionList.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                questionValue = stringQuestionvalue[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        btn_submit.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("LongLogTag")
            @Override
            public void onClick(View v) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                if (!etAnswer.getText().toString().isEmpty()) {
                    if (QType.equalsIgnoreCase("Set")) {
                        /*String pin = getIntent().getStringExtra("pin");
                        databaseHelper.insertUser(pin, questionValue, etAnswer.getText().toString());*/
                        if (Connectivity.isConnectedFast(mContext)) {
                            DatabaseHelper databaseHelper = new DatabaseHelper(getApplicationContext());
                            String pin = getIntent().getStringExtra("pin");
                            databaseHelper.insertUser(pin, questionValue, etAnswer.getText().toString());
                            UserItem userItem = databaseHelper.getUserData();
                            Log.e(TAG, "onClick: userItem====> " + userItem);
//                            if (userItem.getEmail() == null) {
                            googleLogIn();
                            /*}else {
                                Intent i = new Intent(SequrityQuestionActivity.this, FirstActivity.class);
                                startActivityForResult(i, 1);
                                setResult(RESULT_OK);
                                finish();
                            }*/
                        } else {
                            AlertDialog.Builder builder = new AlertDialog.Builder(getApplicationContext());
                            builder.setTitle(getString(R.string.internet_title));
                            builder.setMessage(getString(R.string.internet_message));
                            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    String pin = getIntent().getStringExtra("pin");
                                    databaseHelper.insertUser(pin, questionValue, etAnswer.getText().toString());

                                    Toast.makeText(getApplicationContext(), "Please start internet and restart app.", Toast.LENGTH_LONG).show();
                                    finish();
                                }
                            });
                            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    String pin = getIntent().getStringExtra("pin");
                                    databaseHelper.insertUser(pin, questionValue, etAnswer.getText().toString());
                                    finish();
                                }
                            });
                            AlertDialog alertDialog = builder.create();
                            alertDialog.show();
                        }
                        /*Intent i = new Intent(SequrityQuestionActivity.this, FirstActivity.class);
                        startActivityForResult(i, 1);
                        setResult(RESULT_OK);
                        finish();*/
                    } else {
                        String answer = databaseHelper.getUser(1).getAnswer();
                        if (etAnswer.getText().toString().trim().equalsIgnoreCase(answer)) {
                            Intent intent = new Intent(mContext, PinActivity.class);
                            intent.putExtra("NewPin", true);
                            startActivityForResult(intent, 204);
                        } else {
                            txt_resetEmail.setVisibility(View.VISIBLE);
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.msg_wrong_answer), Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.msg_answer), Toast.LENGTH_SHORT).show();
                }
            }
        });

        txt_resetEmail = findViewById(R.id.txt_resetEmail);
        txt_resetEmail.setOnClickListener(this);

    }

    @SuppressLint("LongLogTag")
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == 204) {
                setResult(RESULT_OK);
                finish();
            }
        }

        try {
            switch (requestCode) {
                case REQUEST_ACCOUNT_PICKER:
                    if (resultCode == RESULT_OK && data != null && data.getExtras() != null) {
                        String accountName = data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME);
                        PreferenceHelper.setValue(mContext, PreferenceHelper.AccountName, accountName);
                        if (accountName != null) {
                            credential.setSelectedAccountName(accountName);
                            String pin = getIntent().getStringExtra("pin");
                            databaseHelper.insertUser(pin, questionValue, etAnswer.getText().toString(), accountName);

                            Intent i = new Intent(SequrityQuestionActivity.this, DashboardActivity.class);
                            startActivityForResult(i, 1);
                            setResult(RESULT_OK);
                            finish();
                        }
                    }
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean isValidEmail(CharSequence target) {
        return (!TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches());
    }

    @SuppressLint("LongLogTag")
    private void googleLogIn() {
        if (Connectivity.isConnectedFast(mContext)) {
            credential = GoogleAccountCredential.usingOAuth2(this, Arrays.asList(DriveScopes.DRIVE_FILE));
            String accountName = PreferenceHelper.getValue(mContext, PreferenceHelper.AccountName, "");
            if (accountName.length() > 0) {
                if (isValidEmail(accountName)) {
                    credential.setSelectedAccountName(accountName);


                    service = getDriveService(credential);
                    if (service != null) {
                        Log.e(TAG, "googleLogIn: service not` null");
//                        CreateDirectoryTask g = new CreateDirectoryTask();
//                        g.execute();
                    } else {
                        Log.e(TAG, "googleLogIn: service null");
                    }


                    DatabaseHelper databaseHelper = new DatabaseHelper(getApplicationContext());
                    UserItem userItem = databaseHelper.getUserData();
                    Log.e(TAG, "googleLogIn: pwd==> "
                            + databaseHelper.getUserData().getPwd()
                            + " getSquestion()==> "
                            + databaseHelper.getUserData().getSquestion()
                            + " getAnswer()==> "
                            + databaseHelper.getUserData().getAnswer()
                            + " getEmail()==> "
                            + databaseHelper.getUserData().getEmail()
                            + " getForgotPin()==> "
                            + databaseHelper.getUserData().getForgotPin()
                    );
                    if (userItem.getEmail() == null) {
                        databaseHelper.updateUserEmail(accountName);
                        Intent i = new Intent(SequrityQuestionActivity.this, DashboardActivity.class);
                        startActivityForResult(i, 1);
                        setResult(RESULT_OK);
                        finish();
                    } else {
                        String pin = getIntent().getStringExtra("pin");
                        int i1 = databaseHelper.updateUserPinSecurityQue(pin, questionValue, etAnswer.getText().toString());
                        Log.e(TAG, "googleLogIn: pwd==> " + i1 + " ==> "
                                + databaseHelper.getUserData().getPwd()
                                + " getSquestion()==> "
                                + databaseHelper.getUserData().getSquestion()
                                + " getAnswer()==> "
                                + databaseHelper.getUserData().getAnswer()
                                + " getEmail()==> "
                                + databaseHelper.getUserData().getEmail()
                                + " getForgotPin()==> "
                                + databaseHelper.getUserData().getForgotPin()
                        );
                        Intent i = new Intent(SequrityQuestionActivity.this, DashboardActivity.class);
                        startActivityForResult(i, 1);
                        setResult(RESULT_OK);
                        finish();
                    }
                } else {
                    pickAccount();
                }
            } else {
                pickAccount();
            }
        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle(getString(R.string.internet_title));
            builder.setMessage(getString(R.string.internet_message));
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    String pin = getIntent().getStringExtra("pin");
                    databaseHelper.insertUser(pin, questionValue, etAnswer.getText().toString());

                    Toast.makeText(getApplicationContext(), "Please start internet and restart app.", Toast.LENGTH_LONG).show();
                    finish();
                }
            });
            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    String pin = getIntent().getStringExtra("pin");
                    databaseHelper.insertUser(pin, questionValue, etAnswer.getText().toString());
                    finish();
                }
            });
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }
    }

    private Drive getDriveService(GoogleAccountCredential credential) {
        return new Drive.Builder(AndroidHttp.newCompatibleTransport(), new GsonFactory(), credential).setApplicationName(getString(R.string.app_name)).build();
    }

    private void pickAccount() {
        startActivityForResult(credential.newChooseAccountIntent(), REQUEST_ACCOUNT_PICKER);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.txt_resetEmail:
                Intent intent = new Intent(getApplicationContext(), ResetPinByEmail.class);
                startActivity(intent);
                break;
        }
    }

    @SuppressLint("LongLogTag")
    public class CreateDirectoryTask extends AsyncTask<Void, Void, Void> {
        ProgressDialog pd2;

        public CreateDirectoryTask() {
            pd2 = new ProgressDialog(SequrityQuestionActivity.this);
            pd2.setTitle("Connectd to server");
            pd2.setMessage("Please wait....");
            pd2.setCancelable(false);
            pd2.setIndeterminate(true);
            pd2.show();
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            Log.e(TAG, "doInBackground:111 ");

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            Log.e(TAG, "doInBackground:===22 ");
            pd2.dismiss();
//            new CloudBackupActivity.updateProgressTask().execute();
        }
    }
}
