package com.secretvault.file.privary.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import com.secretvault.file.privary.R;
import com.secretvault.file.privary.adapters.ViewPagerAdapter;
import com.secretvault.file.privary.fragments.BookMarkFragment;
import com.secretvault.file.privary.fragments.StiteListFragment;
import com.secretvault.file.privary.utils.Utils;
import com.secretvault.file.privary.views.CustomTextView;
import com.google.android.material.tabs.TabLayout;

public class PrivateBrowserActivity extends AppCompatActivity implements View.OnClickListener {

    public LinearLayout lin_toolbar, lin_searchview;
    public TabLayout tabLayout;
    LinearLayout rootLayout, lin_bgview;
    Context mContext;
    ImageView icClose2, ivSearch, ivClear;
    EditText actvSearch;
    MenuItem prevMenuItem;
    boolean isOpened = false;
    private ViewPager viewPager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_private_browser);
        mContext = PrivateBrowserActivity.this;
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            //actionBar.setDisplayHomeAsUpEnabled(true);
            //actionBar.setHomeAsUpIndicator(R.drawable.ic_arrow_back);
            //actionBar.setDisplayShowTitleEnabled(true);
            CustomTextView tv_tital = findViewById(R.id.tv_tital);
            tv_tital.setText(R.string.tital_private_browser);
            ImageView iv_back = findViewById(R.id.iv_back);
            iv_back.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onBackPressed();
                }
            });
            findViewById(R.id.iv_option).setVisibility(View.GONE);

        }
        Init();
    }

    private void Init() {
        rootLayout = findViewById(R.id.rootLayout);
        lin_toolbar = findViewById(R.id.lin_toolbar);
        lin_searchview = findViewById(R.id.lin_searchview);
        lin_bgview = findViewById(R.id.lin_bgview);
        tabLayout = findViewById(R.id.tabLayout);
        viewPager = findViewById(R.id.viewpager);

        tabLayout.addTab(tabLayout.newTab().setText("Most Visited"));
        tabLayout.addTab(tabLayout.newTab().setText("Bookmarks"));
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);


        icClose2 = findViewById(R.id.icClose2);
        ivSearch = findViewById(R.id.ivSearch);
        ivClear = findViewById(R.id.ivClear);
        actvSearch = findViewById(R.id.actvSearch);

        setupViewPager(viewPager);
        actvSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                icClose2.setVisibility(View.VISIBLE);
                ivSearch.setVisibility(View.GONE);
                ivClear.setVisibility(View.GONE);

            }
        });
        actvSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                String query = actvSearch.getText().toString().trim();
                Log.e("TAG", "onEditorAction:acti   onId " + actionId);
                if (actionId == EditorInfo.IME_ACTION_GO) {
                    Log.e("TAG", "onEditorAction: Go ");
                    goSearch();
                }

                return true;
            }
        });


        actvSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (actvSearch.getText().length() == 0) {
                    icClose2.setVisibility(View.VISIBLE);
                    ivClear.setVisibility(View.GONE);
                    ivSearch.setVisibility(View.GONE);
                } else if (actvSearch.getText().length() > 0) {
                    ivClear.setVisibility(View.VISIBLE);
                    ivSearch.setVisibility(View.VISIBLE);
                    icClose2.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        icClose2.setOnClickListener(this);
        ivSearch.setOnClickListener(this);
        ivClear.setOnClickListener(this);

//        setListnerToRootView();
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                if (prevMenuItem != null) {
                    prevMenuItem.setChecked(false);
                } else {
                }
                TabLayout.Tab tab = tabLayout.getTabAt(position);
                tab.select();

                Log.d("page", "onPageSelected: " + position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    private void setupViewPager(ViewPager viewPager) {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new StiteListFragment());
        adapter.addFragment(new BookMarkFragment());
        viewPager.setAdapter(adapter);
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        Log.e("UCSafe", "PrivateBrowserActivity:onUserLeaveHint");
    }

    @Override
    public void onUserInteraction() {
        super.onUserInteraction();
        Log.e("UCSafe", "PrivateBrowserActivity:onUserInteraction");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("UCSafe", "PrivateBrowserActivity:onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.e("UCSafe", "PrivateBrowserActivity:onPause");
    }
    @Override
    protected void onStop() {
        super.onStop();
        Log.e("UCSafe", "PrivateBrowserActivity:onStop");
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
        Log.e("UCSafe", "PrivateBrowserActivity:onKeyDown:"+keyCode);
        if(keyCode == KeyEvent.KEYCODE_HOME)
        {
            Log.e("UCSafe", "PrivateBrowserActivity:Home button pressed!");
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.ivClear:
                actvSearch.setText("");
                break;
            case R.id.icClose2:
                actvSearch.setText("");
                hideSoftKeyboard();
                break;
            case R.id.ivSearch:
                goSearch();
                break;
        }
    }

    public void goSearch() {
        if (actvSearch.getText().length() > 0) {
            if (Utils.isNetworkAvailable(mContext)) {
                lin_bgview.setVisibility(View.GONE);
                lin_toolbar.setVisibility(View.VISIBLE);
                Intent intent = new Intent(mContext, WebActivity.class);
                intent.putExtra("Query", "https://www.google.com/search?q=" + actvSearch.getText().toString());
                startActivity(intent);
                actvSearch.setText("");
            }
        }
    }

    public void goSearch2(String query) {
        lin_bgview.setVisibility(View.GONE);
        lin_toolbar.setVisibility(View.VISIBLE);
        Intent intent = new Intent(mContext, WebActivity.class);
        intent.putExtra("Query", query);
        startActivity(intent);
        actvSearch.setText("");
    }

    public void setListnerToRootView() {
        final View activityRootView = getWindow().getDecorView().findViewById(android.R.id.content);
        activityRootView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {

                int heightDiff = activityRootView.getRootView().getHeight() - activityRootView.getHeight();
                if (heightDiff > 100) { // 99% of the time the height diff will be due to a keyboard.
                    lin_bgview.setVisibility(View.VISIBLE);
                    lin_toolbar.setVisibility(View.GONE);
                    if (isOpened == false) {
                        //Do two things, make the view top visible and the editText smaller
                    }
                    isOpened = true;
                } else if (isOpened == true) {
                    icClose2.setVisibility(View.GONE);
                    ivClear.setVisibility(View.GONE);
                    ivSearch.setVisibility(View.GONE);
                    actvSearch.setText("");
                    lin_bgview.setVisibility(View.GONE);
                    lin_toolbar.setVisibility(View.VISIBLE);
                    isOpened = false;
                }
            }
        });
    }

    public void hideSoftKeyboard() {
        if (getCurrentFocus() != null) {
            InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home: {
                onBackPressed();
                return true;
            }
            default: {
                return false;
            }
        }
    }


}
