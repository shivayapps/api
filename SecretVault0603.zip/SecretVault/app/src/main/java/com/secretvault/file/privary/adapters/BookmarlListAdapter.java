package com.secretvault.file.privary.adapters;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.secretvault.file.privary.R;
import com.secretvault.file.privary.model.BookmarkModel;

import java.util.ArrayList;
import java.util.List;

public class BookmarlListAdapter extends RecyclerView.Adapter<BookmarlListAdapter.ViewHolder> {

    Activity act;
    List<BookmarkModel> arrAppList = new ArrayList<>();
    OnItemClickListner listener;
    OnItemLongClickListner onItemLongClickListner;

    public BookmarlListAdapter(Activity activity, List<BookmarkModel> arrayList, OnItemClickListner listener) {
        this.act = activity;
        this.arrAppList = arrayList;
        this.listener = listener;
    }

    public void setOnItemLongClickListner(OnItemLongClickListner onItemLongClickListner) {
        this.onItemLongClickListner = onItemLongClickListner;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View v = LayoutInflater.from(act).inflate(R.layout.list_bookmark, viewGroup, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        BookmarkModel data = arrAppList.get(position);
//        holder.ivAppIcon.setImageResource(data.getImage());
        holder.tv_tital.setText(data.getPass_title());
//        holder.tv_tital.setTextColor(Util.getThemeColor(act, R.attr.textColor1));
        holder.tv_url.setText(data.getPass_content());

        holder.lin_root.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onItemClick(position);
                }
            }
        });


    }


    public void removeAt(int position) {
        arrAppList.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, arrAppList.size());
    }

    public List<BookmarkModel> getAllItems(){
        return arrAppList;
    }


    @Override
    public int getItemCount() {
        return arrAppList.size();
    }

    public interface OnItemLongClickListner {

        void onItemLongClick(int position);


    }

    class ViewHolder extends RecyclerView.ViewHolder {
        ImageView iv_icon;
        TextView tv_tital;
        TextView tv_url;
        LinearLayout lin_root;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            iv_icon = itemView.findViewById(R.id.iv_icon);
            tv_tital = itemView.findViewById(R.id.tv_tital);
            tv_url = itemView.findViewById(R.id.tv_url);
            lin_root = itemView.findViewById(R.id.lin_root);

            lin_root.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    if (onItemLongClickListner != null)
                        onItemLongClickListner.onItemLongClick(getAdapterPosition());
                    return false;
                }
            });
        }
    }
}
