package com.secretvault.file.privary.activity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;

import com.secretvault.file.privary.MainActivity;
import com.secretvault.file.privary.R;
import com.secretvault.file.privary.ads.AdmobAdManager;
import com.secretvault.file.privary.db.DatabaseHelper;
import com.secretvault.file.privary.db.UserItem;
import com.secretvault.file.privary.hiddencamera.CameraConfig;
import com.secretvault.file.privary.hiddencamera.CameraError;
import com.secretvault.file.privary.hiddencamera.HiddenCameraActivity;
import com.secretvault.file.privary.hiddencamera.HiddenCameraUtils;
import com.secretvault.file.privary.hiddencamera.config.CameraFacing;
import com.secretvault.file.privary.hiddencamera.config.CameraImageFormat;
import com.secretvault.file.privary.hiddencamera.config.CameraResolution;
import com.secretvault.file.privary.hiddencamera.config.CameraRotation;
import com.secretvault.file.privary.utils.PreferenceHelper;
import com.secretvault.file.privary.utils.Utils;
import com.secretvault.file.privary.views.CustomTextView;
import com.google.android.gms.ads.MobileAds;
import com.hardik.clickshrinkeffect.ClickShrinkEffect;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import me.aflak.libraries.callback.FingerprintSecureCallback;
import me.aflak.libraries.utils.FingerprintToken;
import me.aflak.libraries.view.Fingerprint;

public class PinActivity extends HiddenCameraActivity implements View.OnClickListener, FingerprintSecureCallback {
    public static final int CAMERA_PIC_REQUEST = 1111;
    private static final int REQ_CODE_CAMERA_PERMISSION = 1253;
    TextView tv_1, tv_2, tv_3, tv_4, tv_5, tv_6, tv_7, tv_8, tv_9, tv_0;
    CustomTextView tv_fingerprint;
    ImageView iv_pin1, iv_pin2, iv_pin3, iv_pin4;
    ImageView iv_doen, iv_cam;
//    CustomTextView tv_forgotpwd;
    String pinNo = "";
    String oldPin = "";
    DatabaseHelper databaseHelper;
    Context mContext;
    boolean NewPin = false;
    boolean ChangePin = false;
    Vibrator vibrator;
    CustomTextView tv_pinhint;
    ImageView iv_more;
    private CameraConfig mCameraConfig;
    private Boolean isFromBackground=false;

    public static void createImageDir() {
        File myDirectory = new File(Utils.hideImage);
        if (!myDirectory.exists()) {
            myDirectory.mkdir();
            Log.e("TAG", "createImageDir: mkdir");
        } else {
        }

        File myPwd = new File(Utils.worngPwd);
        if (!myPwd.exists()) {
            myPwd.mkdirs();
        } else {
        }
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pin);
        mContext = PinActivity.this;
        MobileAds.initialize(this, getString(R.string.APP_ID));

        Intent intent=getIntent();
        if(intent.hasExtra("isFromBackground")) {
            isFromBackground=intent.getBooleanExtra("isFromBackground",false);
        }

        if (checkPermission()) {
            Init();
        } else {
            Get_CameraAndStorage_Permission();
        }

    }

    private void Init() {
        if (getIntent().getExtras() != null) {
            NewPin = getIntent().getBooleanExtra("NewPin", false);
            ChangePin = getIntent().getBooleanExtra("ChangePin", false);
        }
        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        createImageDir();
        databaseHelper = new DatabaseHelper(mContext);
        pinNo = "";
        UserItem userItem = databaseHelper.getUser(1);
        oldPin = userItem.getPwd();
        iv_pin1 = findViewById(R.id.iv_pin1);
        iv_pin2 = findViewById(R.id.iv_pin2);
        iv_pin3 = findViewById(R.id.iv_pin3);
        iv_pin4 = findViewById(R.id.iv_pin4);
        tv_pinhint = findViewById(R.id.tv_pinhint);
        tv_fingerprint = findViewById(R.id.tv_fingerprint);
        tv_1 = findViewById(R.id.tv_1);
        tv_2 = findViewById(R.id.tv_2);
        tv_3 = findViewById(R.id.tv_3);
        tv_4 = findViewById(R.id.tv_4);
        tv_5 = findViewById(R.id.tv_5);
        tv_6 = findViewById(R.id.tv_6);
        tv_7 = findViewById(R.id.tv_7);
        tv_8 = findViewById(R.id.tv_8);
        tv_9 = findViewById(R.id.tv_9);
        tv_0 = findViewById(R.id.tv_0);
        iv_more = findViewById(R.id.iv_more);

        iv_doen = findViewById(R.id.iv_done);
        iv_cam = findViewById(R.id.iv_cam);
        if (NewPin) {
            iv_cam.setVisibility(View.INVISIBLE);
            tv_pinhint.setText("Please enter your new password");
        } else if (ChangePin) {
            iv_cam.setVisibility(View.INVISIBLE);
            tv_pinhint.setText("Please enter your old password");
        } else {
            tv_pinhint.setText("Please enter your password");
            if (oldPin.equalsIgnoreCase("")) {
                iv_cam.setVisibility(View.INVISIBLE);
            } else {
                iv_cam.setVisibility(View.VISIBLE);
            }

            new AdmobAdManager(mContext).loadInterstitialAd(
                    PinActivity.this,
                    getString(R.string.INTERSTITIAL_ID)
            );
        }

        chekFingerPrint();
        tv_0.setOnClickListener(this);
        tv_1.setOnClickListener(this);
        tv_2.setOnClickListener(this);
        tv_3.setOnClickListener(this);
        tv_4.setOnClickListener(this);
        tv_5.setOnClickListener(this);
        tv_6.setOnClickListener(this);
        tv_7.setOnClickListener(this);
        tv_8.setOnClickListener(this);
        tv_9.setOnClickListener(this);
        tv_0.setOnClickListener(this);


        iv_doen.setOnClickListener(this);
        iv_cam.setOnClickListener(this);

        new ClickShrinkEffect(tv_0);
        new ClickShrinkEffect(tv_1);
        new ClickShrinkEffect(tv_2);
        new ClickShrinkEffect(tv_3);
        new ClickShrinkEffect(tv_4);
        new ClickShrinkEffect(tv_5);
        new ClickShrinkEffect(tv_6);
        new ClickShrinkEffect(tv_7);
        new ClickShrinkEffect(tv_8);
        new ClickShrinkEffect(tv_9);
        new ClickShrinkEffect(iv_doen);
        new ClickShrinkEffect(iv_cam);

        mCameraConfig = new CameraConfig()
                .getBuilder(this)
                .setCameraFacing(CameraFacing.FRONT_FACING_CAMERA)
                .setCameraResolution(CameraResolution.LOW_RESOLUTION)
                .setImageFormat(CameraImageFormat.FORMAT_PNG)
                .setImageRotation(CameraRotation.ROTATION_270)
                .build();
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera(mCameraConfig);
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQ_CODE_CAMERA_PERMISSION);
        }

        iv_more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popup = new PopupMenu(PinActivity.this, v);

                popup.getMenuInflater().inflate(R.menu.poupup_menu, popup.getMenu());
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    public boolean onMenuItemClick(MenuItem item) {
                        stopCamera();
                        Intent intent = new Intent(mContext, SequrityQuestionActivity.class);
                        intent.putExtra("QType", "Forgot");
                        startActivityForResult(intent, 203);

                        return true;
                    }
                });
                popup.show();
            }
        });
    }

    private void chekFingerPrint() {
        Fingerprint fingerprint = findViewById(R.id.activity_view_example_fingerprint);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!NewPin) {
                if (!ChangePin) {
                    FingerprintManager fingerprintManager = null;
                    fingerprintManager = (FingerprintManager) getSystemService(Context.FINGERPRINT_SERVICE);
                    if (fingerprintManager != null) {
                        if (!fingerprintManager.isHardwareDetected()) {
                            tv_fingerprint.setVisibility(View.GONE);
                        } else if (!fingerprintManager.hasEnrolledFingerprints()) {
                            tv_fingerprint.setVisibility(View.GONE);
                        } else {
                            if (PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.isFingerprint, false)) {
                                fingerprint.callback(this, "KeyName2").circleScanningColor(android.R.color.black).fingerprintScanningColor(R.color.colorAccent).authenticate();
                                tv_fingerprint.setVisibility(View.VISIBLE);
                            } else {
                                tv_fingerprint.setVisibility(View.GONE);
                            }
                        }
                    } else {
                        tv_fingerprint.setVisibility(View.GONE);
                        PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.isFingerprint, false);
                    }
                }
            }
        } else {
            PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.isFingerprint, false);
            tv_fingerprint.setVisibility(View.GONE);
        }

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_1:
                pinNo = pinNo + "1";
                setPinText();
                break;
            case R.id.tv_2:
                pinNo = pinNo + "2";
                setPinText();
                break;
            case R.id.tv_3:
                pinNo = pinNo + "3";
                setPinText();
                break;
            case R.id.tv_4:
                pinNo = pinNo + "4";
                setPinText();
                break;
            case R.id.tv_5:
                pinNo = pinNo + "5";
                setPinText();
                break;
            case R.id.tv_6:
                pinNo = pinNo + "6";
                setPinText();
                break;
            case R.id.tv_7:
                pinNo = pinNo + "7";
                setPinText();
                break;
            case R.id.tv_8:
                pinNo = pinNo + "8";
                setPinText();
                break;
            case R.id.tv_9:
                pinNo = pinNo + "9";
                setPinText();
                break;
            case R.id.tv_0:
                pinNo = pinNo + "0";
                setPinText();
                break;
            case R.id.iv_done:
                backButtonClick();
                break;
            case R.id.iv_cam:
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_PIC_REQUEST);
                break;

        }
        setVibrator();
    }

    public void setVibrator() {
        if (PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.VIBRATOR, true)) {
            if (Build.VERSION.SDK_INT >= 26) {
                vibrator.vibrate(VibrationEffect.createOneShot(100, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                vibrator.vibrate(100);
            }
        }
    }

    private void donePin() {
        checkPin();
    }

    private void checkPin() {
        if (NewPin || oldPin.equalsIgnoreCase("")) {
            if (pinNo.length() >= 4) {
                Intent intent = new Intent(mContext, ConfirmPinActivity.class);
                intent.putExtra("pin", pinNo);
                intent.putExtra("NewPin", NewPin);
                startActivityForResult(intent, 201);
            } else {
                Toast.makeText(getApplicationContext(), "Enter minimum 4 digit", Toast.LENGTH_SHORT).show();
            }
        } else {
            if (oldPin.equalsIgnoreCase(pinNo)) {
                if (ChangePin) {
                    Intent intent = getIntent();
                    overridePendingTransition(0, 0);
                    intent.putExtra("NewPin", true);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                    finish();
                    overridePendingTransition(0, 0);
                    startActivity(intent);
                } else {
                    /*if(isFromBackground) {
                        finish();
                    } else {
                    }*/

                    Intent intent = new Intent(mContext, DashboardActivity.class);
                    startActivity(intent);
                    finish();
                }
            } else {
                pinNo = "";
                setPinText();
                if (!ChangePin)
                    iv_more.setVisibility(View.VISIBLE);
                if (PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.Intruder_selfie, true))
                    takePicture();
                Toast.makeText(getApplicationContext(), getResources().getString(R.string.wrong_pwd), Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void backButtonClick() {
        if (pinNo.length() > 0) {
            pinNo = pinNo.substring(0, pinNo.length() - 1);
            setPinText();
        } else {
        }
    }

    public void setPinText() {
        if (pinNo.length() == 1) {
            iv_pin1.setImageResource(R.drawable.icon_round1);
            iv_pin2.setImageResource(R.drawable.icon_round);
            iv_pin3.setImageResource(R.drawable.icon_round);
            iv_pin4.setImageResource(R.drawable.icon_round);
        } else if (pinNo.length() == 2) {
            iv_pin1.setImageResource(R.drawable.icon_round1);
            iv_pin2.setImageResource(R.drawable.icon_round1);
            iv_pin3.setImageResource(R.drawable.icon_round);
            iv_pin4.setImageResource(R.drawable.icon_round);
        } else if (pinNo.length() == 3) {
            iv_pin1.setImageResource(R.drawable.icon_round1);
            iv_pin2.setImageResource(R.drawable.icon_round1);
            iv_pin3.setImageResource(R.drawable.icon_round1);
            iv_pin4.setImageResource(R.drawable.icon_round);
        } else if (pinNo.length() == 4) {
            iv_pin1.setImageResource(R.drawable.icon_round1);
            iv_pin2.setImageResource(R.drawable.icon_round1);
            iv_pin3.setImageResource(R.drawable.icon_round1);
            iv_pin4.setImageResource(R.drawable.icon_round1);
            donePin();
        } else {
            pinNo = "";
            iv_pin1.setImageResource(R.drawable.icon_round);
            iv_pin2.setImageResource(R.drawable.icon_round);
            iv_pin3.setImageResource(R.drawable.icon_round);
            iv_pin4.setImageResource(R.drawable.icon_round);
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == 201 || requestCode == 203) {
                setResult(RESULT_OK);
                finish();
            }

            if (requestCode == CAMERA_PIC_REQUEST) {
                if (data != null) {
                    Bitmap image = (Bitmap) data.getExtras().get("data");
                    saveImage(image);
                }
            }
        }

    }

    private void saveImage(Bitmap finalBitmap) {
        File myDir = new File(Utils.nohideImage);
        myDir.mkdirs();

        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String fname = "IMG_" + timeStamp + ".jpg.bin";
        String fname2 = "IMG_" + timeStamp + ".jpg";

        File file = new File(myDir, fname);
        if (file.exists()) file.delete();
        try {
            FileOutputStream out = new FileOutputStream(file);
            finalBitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
            out.flush();
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        File file1 = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "DCMI");
        file1.mkdirs();
        String oriPath = file1.getAbsolutePath() + "/" + fname2;

        databaseHelper.insertImage(fname2, oriPath, file.getAbsolutePath(), file.length(), "image/jpg");
    }

    public boolean checkPermission() {
        List<String> permissionsNeeded = new ArrayList<String>();
        final List<String> permissionsList = new ArrayList<String>();
        if (!addPermission(permissionsList, Manifest.permission.WRITE_EXTERNAL_STORAGE))
            permissionsNeeded.add("write storage");
        if (!addPermission(permissionsList, Manifest.permission.READ_EXTERNAL_STORAGE))
            permissionsNeeded.add("Read storage");
        if (!addPermission(permissionsList, Manifest.permission.CAMERA))
            permissionsNeeded.add("Cmera");
        return permissionsList.size() == 0;
    }

    private void Get_CameraAndStorage_Permission() {
        List<String> permissionsNeeded = new ArrayList<String>();
        final List<String> permissionsList = new ArrayList<String>();
        if (!addPermission(permissionsList, Manifest.permission.WRITE_EXTERNAL_STORAGE))
            permissionsNeeded.add("Write storage");
        if (!addPermission(permissionsList, Manifest.permission.READ_EXTERNAL_STORAGE))
            permissionsNeeded.add("Read storage");
        if (!addPermission(permissionsList, Manifest.permission.CAMERA))
            permissionsNeeded.add("Camera");

        if (permissionsList.size() > 0) {
            if (permissionsNeeded.size() > 0) {
                for (int i = 0; i < 1; i++)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionsList.toArray(new String[permissionsList.size()]), MainActivity.REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
                    }
                return;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(permissionsList.toArray(new String[permissionsList.size()]), MainActivity.REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
            }
            return;
        }
    }

    private boolean addPermission(List<String> permissionsList, String permission) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsList.add(permission);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    return shouldShowRequestPermissionRationale(permission);
                }
            }
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length > 0) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (requestCode == MainActivity.REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS) {
                    Init();
                }
            }
        }
    }

    @Override
    public void onImageCapture(@NonNull File imageFile) {
        Log.e("TAG", "onImageCapture: " + imageFile.getAbsolutePath());
    }

    @Override
    public void onCameraError(int errorCode) {
        switch (errorCode) {
            case CameraError.ERROR_CAMERA_OPEN_FAILED:
                //Camera open failed. Probably because another application
                //is using the camera
                //Toast.makeText(this, R.string.error_cannot_open, Toast.LENGTH_LONG).show();
                break;
            case CameraError.ERROR_IMAGE_WRITE_FAILED:
                //Image write failed. Please check if you have provided WRITE_EXTERNAL_STORAGE permission
                Toast.makeText(this, R.string.error_cannot_write, Toast.LENGTH_LONG).show();
                break;
            case CameraError.ERROR_CAMERA_PERMISSION_NOT_AVAILABLE:
                //camera permission is not available
                //Ask for the camera permission before initializing it.
                Toast.makeText(this, R.string.error_cannot_get_permission, Toast.LENGTH_LONG).show();
                break;
            case CameraError.ERROR_DOES_NOT_HAVE_OVERDRAW_PERMISSION:
                //Display information dialog to the user with steps to grant "Draw over other app"
                //permission for the app.
                HiddenCameraUtils.openDrawOverPermissionSetting(this);
                break;
            case CameraError.ERROR_DOES_NOT_HAVE_FRONT_CAMERA:
                Toast.makeText(this, R.string.error_not_having_camera, Toast.LENGTH_LONG).show();
                break;
        }
    }


    @Override
    public void onAuthenticationSucceeded() {
        if (!NewPin && !ChangePin) {
            /*if(isFromBackground) {
                finish();
            } else {
            }*/

            Intent intent = new Intent(getApplicationContext(), DashboardActivity.class);
            startActivity(intent);
            finish();
        }
    }

    @Override
    public void onAuthenticationFailed() {

    }

    @Override
    public void onNewFingerprintEnrolled(FingerprintToken token) {
//        PasswordDialog.initialize(this, token)
//                .title(R.string.password_title)
//                .message(R.string.password_message)
//                .callback(this)
//                .passwordType(PasswordDialog.PASSWORD_TYPE_TEXT)
//                .show();
    }

    @Override
    public void onAuthenticationError(int errorCode, String error) {
    }
}
