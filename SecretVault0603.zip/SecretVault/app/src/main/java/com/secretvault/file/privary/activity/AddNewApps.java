package com.secretvault.file.privary.activity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.secretvault.file.privary.R;
import com.secretvault.file.privary.model.AppDataModel;
import com.secretvault.file.privary.utils.PreferenceHelper;
import com.google.android.material.textfield.TextInputEditText;
import com.secretvault.file.privary.views.CustomTextView;

import java.util.LinkedHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AddNewApps extends AppCompatActivity implements View.OnClickListener {
    Button btn_add;
    Context mContext;
    TextInputEditText et_url, et_tital;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_apps);
        mContext = AddNewApps.this;

        CustomTextView tv_tital = findViewById(R.id.tv_tital);
        tv_tital.setText("Add New Website");
        ImageView iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        findViewById(R.id.iv_option).setVisibility(View.GONE);

        Init();
    }

    private void Init() {
        et_tital = findViewById(R.id.et_tital);
        et_url = findViewById(R.id.et_url);
        btn_add = findViewById(R.id.btn_add);
        btn_add.setOnClickListener(this);
        findViewById(R.id.iv_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_add:
                String url = et_url.getText().toString().toLowerCase().trim();
                if (et_tital.getText().toString().trim().isEmpty() || et_tital.length() == 0 || et_tital.equals("") || et_tital == null) {
                    Toast.makeText(getApplicationContext(), "Enter website title", Toast.LENGTH_SHORT).show();
                } else {
                    if (isValidUrl(url)) {
                        hideSoftInput(btn_add);
                        LinkedHashMap<String, AppDataModel> dataMap = PreferenceHelper.getAppDataMap(mContext);
                        if (dataMap.containsKey(url)) {
                            Toast.makeText(getApplicationContext(), "Repeated URL", Toast.LENGTH_SHORT).show();
                        } else {
                            if (url.contains("https://") || url.contains("http://"))
                                dataMap.put(url, new AppDataModel("ic_web", url, et_tital.getText().toString().trim()));
                            else
                                dataMap.put("https://"+url, new AppDataModel("ic_web", "https://"+url, et_tital.getText().toString().trim()));

                            PreferenceHelper.saveAppData(mContext, dataMap);
                            Toast.makeText(getApplicationContext(), "Add new url successfully.", Toast.LENGTH_SHORT).show();
                            setResult(RESULT_OK);
                            finish();
                        }
                        Log.e("TAG", "onClick: true");
                    } else {
                        Toast.makeText(getApplicationContext(), "Enter valid website url", Toast.LENGTH_SHORT).show();
                        Log.e("TAG", "onClick: false");
                    }
                }
                break;
            default:
                break;
        }
    }


    private void hideSoftInput(final Button view) {
        view.clearFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        assert imm != null;
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    private boolean isValidUrl(String url) {
        Pattern p = Patterns.WEB_URL;
        Matcher m = p.matcher(url.toLowerCase());
        //        if (URLUtil.isValidUrl(url))
        return m.matches();

    }

}
