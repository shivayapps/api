package com.secretvault.file.privary.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.secretvault.file.privary.R;
import com.secretvault.file.privary.activity.AddNewApps;
import com.secretvault.file.privary.activity.PrivateBrowserActivity;
import com.secretvault.file.privary.activity.WebActivity;
import com.secretvault.file.privary.adapters.AppAdapter;
import com.secretvault.file.privary.model.AppDataModel;
import com.secretvault.file.privary.utils.PreferenceHelper;
import com.secretvault.file.privary.utils.Utils;

import java.util.ArrayList;

public class StiteListFragment extends Fragment implements View.OnClickListener, View.OnLongClickListener {

    LinearLayout lin_tool_top, lin_tool_bottom;

    private RecyclerView siteGird;
    public AppAdapter appAdapter;
    public ArrayList<AppDataModel> appList;


    View view;
    Context mContext;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_site_list, container, false);
        mContext = getActivity();

        Init();
        return view;
    }

    private void Init() {
        lin_tool_top = view.findViewById(R.id.lin_tool_top);
        lin_tool_bottom = view.findViewById(R.id.lin_tool_bottom);


        siteGird = view.findViewById(R.id.site_grid);
        siteGird.setLayoutManager(new GridLayoutManager(mContext, 3));

        appList = new ArrayList<>();
        appList = PreferenceHelper.getAppData(mContext);

        appList.add(new AppDataModel("ic_plus", "", "Add"));
        appAdapter = new AppAdapter(getActivity(), appList, this, this);
        siteGird.setAdapter(appAdapter);

        lin_tool_bottom.setOnClickListener(this);

    }

    @Override
    public boolean getUserVisibleHint() {
        PrivateBrowserActivity privateBrowserActivity = (PrivateBrowserActivity) getActivity();
        privateBrowserActivity.lin_searchview.setVisibility(View.VISIBLE);

        return super.getUserVisibleHint();
    }

    private boolean isClickEvent = true;
    @Override
    public void onClick(View v) {
        int pos;
        switch (v.getId()) {
            case R.id.ivAppIcon:
            case R.id.lin_approot:
                if (isClickEvent) {
                    pos = (int) v.getTag();
                    if (pos == appList.size() - 1) {
                        startActivityForResult(new Intent(mContext, AddNewApps.class), 223);
                    } else {
                        if (!appList.get(pos).getUrl().equals("")) {
                            goSearch2(appList.get(pos).getUrl());
                        }
                    }
                }
                break;
            case R.id.lin_tool_bottom:
                lin_tool_top.setVisibility(View.GONE);
                lin_tool_bottom.setVisibility(View.GONE);
                PrivateBrowserActivity privateBrowserActivity = (PrivateBrowserActivity) getActivity();

                privateBrowserActivity.lin_toolbar.setVisibility(View.VISIBLE);
                privateBrowserActivity.lin_searchview.setVisibility(View.VISIBLE);
                privateBrowserActivity.tabLayout.setVisibility(View.VISIBLE);


                isClickEvent = true;
                AppAdapter.isLongPress = false;
                appAdapter.addLast();
                break;
        }
    }


    @Override
    public boolean onLongClick(View v) {
        switch (v.getId()) {
            case R.id.lin_approot:
//                lin_news.setAlpha(0.3f);
                isClickEvent = false;
                lin_tool_top.setVisibility(View.VISIBLE);
                lin_tool_bottom.setVisibility(View.VISIBLE);
                PrivateBrowserActivity privateBrowserActivity = (PrivateBrowserActivity) getActivity();
                privateBrowserActivity.lin_searchview.setVisibility(View.GONE);
                privateBrowserActivity.lin_toolbar.setVisibility(View.GONE);
                privateBrowserActivity.tabLayout.setVisibility(View.GONE);
                AppAdapter.isLongPress = true;
                appAdapter.removeLast();
                break;
        }
        return false;
    }

    public void goSearch2(String query) {
        if(Utils.isNetworkAvailable(mContext)) {
            Intent intent = new Intent(mContext, WebActivity.class);
            intent.putExtra("Query", query);
            startActivity(intent);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == 223) {
                appList = new ArrayList<>();
                appList = PreferenceHelper.getAppData(mContext);
                appList.add(new AppDataModel("ic_plus", "", "Add"));
                appAdapter = new AppAdapter(getActivity(), appList, this, this);
                siteGird.setAdapter(appAdapter);

            }
        }
    }
}
