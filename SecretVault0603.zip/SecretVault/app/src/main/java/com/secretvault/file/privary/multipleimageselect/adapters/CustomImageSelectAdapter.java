package com.secretvault.file.privary.multipleimageselect.adapters;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.secretvault.file.privary.R;
import com.jiajunhui.xapp.medialoader.bean.PhotoItem;

import java.util.ArrayList;


public class CustomImageSelectAdapter extends CustomGenericAdapter<PhotoItem> {
    public CustomImageSelectAdapter(Context context, ArrayList<PhotoItem> images) {
        super(context, images);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;

        if (convertView == null) {
            convertView = layoutInflater.inflate(R.layout.grid_view_item_image_select, null);

            viewHolder = new ViewHolder();
            viewHolder.imageView = convertView.findViewById(R.id.image_view_image_select);
            viewHolder.frm_chek = convertView.findViewById(R.id.frm_chek);

            convertView.setTag(viewHolder);

        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        viewHolder.imageView.getLayoutParams().width = size;
        viewHolder.imageView.getLayoutParams().height = size;

        viewHolder.frm_chek.getLayoutParams().width = size;
        viewHolder.frm_chek.getLayoutParams().height = size;

        if (arrayList.get(position).isChecked()) {
            viewHolder.frm_chek.setVisibility(View.VISIBLE);

//            ((FrameLayout) convertView).setBackgroundColor(context.getResources().getColor(R.color.black_trans80));
//            ((FrameLayout) convertView).setForeground(context.getResources().getDrawable(R.drawable.ic_done_white));

        } else {
            viewHolder.frm_chek.setVisibility(View.GONE);
//            ((FrameLayout) convertView).setForeground(null);
        }

        Glide.with(context)
                .load(arrayList.get(position).getPath())
                .placeholder(R.drawable.image_placeholder).into(viewHolder.imageView);

        return convertView;
    }

    private static class ViewHolder {
        public ImageView imageView;
//        public View view;
        FrameLayout frm_chek;
    }
}
