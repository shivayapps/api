package com.secretvault.file.privary.fragments;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.secretvault.file.privary.R;
import com.secretvault.file.privary.activity.FullScreenViewActivity;
import com.secretvault.file.privary.adapters.ImageListAdapter;
import com.secretvault.file.privary.adapters.OnItemClickListner;
import com.secretvault.file.privary.ads.AdEventListener;
import com.secretvault.file.privary.ads.AdmobAdManager;
import com.secretvault.file.privary.db.DatabaseHelper;
import com.secretvault.file.privary.utils.ItemOffsetDecoration;
import com.secretvault.file.privary.utils.Utils;
import com.secretvault.file.privary.views.CustomTextView;
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential;
import com.google.api.services.drive.Drive;
import com.jiajunhui.xapp.medialoader.bean.PhotoItem;
import com.shreyaspatil.MaterialDialog.BottomSheetMaterialDialog;

import java.io.File;
import java.util.ArrayList;

import static com.secretvault.file.privary.multipleimageselect.Constants.isGridlayout;

public class TrashPhotoVaultFragment extends Fragment implements OnItemClickListner {
    public Drive service;
    Context mContext;

    RecyclerView recycler_photolist;
    View view;
    LinearLayout lin_nodata;
    ImageListAdapter imageListAdapter;
    DatabaseHelper databaseHelper;
    ArrayList<PhotoItem> imagesList = new ArrayList<>();
    boolean isSelectedMode = false;
    Dialog dialogTimer;
    boolean isbackup = false;
    private ActionBar actionBar;
    private ActionMode actionMode;
    private int countSelected;
    private GoogleAccountCredential credential;
    GridLayoutManager gridLayoutManager;
    private ActionMode.Callback callback = new ActionMode.Callback() {
        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            MenuInflater menuInflater = mode.getMenuInflater();
            menuInflater.inflate(R.menu.menu_trash, menu);
            actionMode = mode;
            countSelected = 0;
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            int i = item.getItemId();
            if (i == R.id.action_delete) {
                DeletePotos(getActivity());
                return true;
            } else if (i == R.id.action_recover) {
                RecoverImage(getActivity());
                return true;
            }
            return false;
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {
            if (countSelected > 0) {
                deselectAll();
            }
            actionMode = null;
        }
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_photo_trash, container, false);
        mContext = getActivity();
        actionBar = ((AppCompatActivity) getActivity()).getSupportActionBar();

        if (actionBar != null) {
            //actionBar.setDisplayHomeAsUpEnabled(true);
            //actionBar.setHomeAsUpIndicator(R.drawable.ic_arrow_back);
            //actionBar.setDisplayShowTitleEnabled(true);

            ImageView iv_back = getActivity().findViewById(R.id.iv_back);
            iv_back.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    getActivity().onBackPressed();
                }
            });
            getActivity().findViewById(R.id.iv_option).setVisibility(View.GONE);

            CustomTextView tv_tital   = getActivity().findViewById(R.id.tv_tital);
            tv_tital.setText(R.string.tital_hide_photos_trash);
        }
        databaseHelper = new DatabaseHelper(mContext);
        Init();
        return view;
    }

    public void Init() {

        lin_nodata = view.findViewById(R.id.lin_nodata);
        recycler_photolist = view.findViewById(R.id.recycler_photolist);

        int no = isGridlayout ? 3 : 1;
        gridLayoutManager = new GridLayoutManager(mContext, no);
        recycler_photolist.setHasFixedSize(true);
        recycler_photolist.setLayoutManager(gridLayoutManager);
        //ItemOffsetDecoration itemDecoration = new ItemOffsetDecoration(mContext, R.dimen.item_space);
        //recycler_photolist.addItemDecoration(itemDecoration);

        imagesList = databaseHelper.getTrashImages();
        imageListAdapter = new ImageListAdapter(mContext, imagesList);
        if (imagesList.size() > 0) {
            recycler_photolist.setVisibility(View.VISIBLE);
            lin_nodata.setVisibility(View.GONE);
        } else {
            recycler_photolist.setVisibility(View.GONE);
            lin_nodata.setVisibility(View.VISIBLE);
        }

        RelativeLayout frameLayout = view.findViewById(R.id.fl_adplaceholder);
        AdmobAdManager admobAdManager = new AdmobAdManager(mContext);
        admobAdManager.loadAdaptiveBanner(mContext,  frameLayout, getString(R.string.BANNER_ID),new AdEventListener() {
            @Override
            public void onAdLoaded() {
                frameLayout.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {

            }

            @Override
            public void onLoadError(String errorCode) {
                frameLayout.setVisibility(View.GONE);
            }
        });
        imageListAdapter.setItemClickEvent(this);
        imageListAdapter.setImageResize(Utils.getImageResize(mContext, recycler_photolist));
        recycler_photolist.setAdapter(imageListAdapter);
    }


    @Override
    public void onItemClick(int position) {
        if (isSelectedMode) {
            if (actionMode == null) {
                actionMode = getActivity().startActionMode(callback);
            }
            toggleSelection(position);
            actionMode.setTitle(countSelected + " " + getString(R.string.selected));
            if (countSelected == 0) {
                actionMode.finish();
                isSelectedMode = false;
            }
        } else {
            Intent intent = new Intent(mContext, FullScreenViewActivity.class);
            intent.putExtra("postion", position);
            intent.putExtra("photoItems", imagesList);
            startActivity(intent);
        }
    }

    @Override
    public void onItemLongClick(int position) {
        isSelectedMode = true;
        if (actionMode == null) {
            actionMode = getActivity().startActionMode(callback);
        }
        toggleSelection(position);
        actionMode.setTitle(countSelected + " " + getString(R.string.selected));
        if (countSelected == 0) {
            actionMode.finish();
            isSelectedMode = false;
        }
    }

    private void toggleSelection(int position) {
        imagesList.get(position).checked = !imagesList.get(position).isChecked();
        if (imagesList.get(position).checked) {
            countSelected++;
        } else {
            countSelected--;
        }
        imageListAdapter.notifyDataSetChanged();
    }

    private void deselectAll() {
        for (int i = 0, l = imagesList.size(); i < l; i++) {
            imagesList.get(i).checked = false;
        }
        isSelectedMode = false;

        countSelected = 0;
        imageListAdapter.notifyDataSetChanged();
    }

    private ArrayList<PhotoItem> getSelected() {
        ArrayList<PhotoItem> selectedImages = new ArrayList<>();
        for (int i = 0, l = imagesList.size(); i < l; i++) {
            if (imagesList.get(i).isChecked()) {
                selectedImages.add(imagesList.get(i));
            }
        }
        return selectedImages;
    }


    public void DeletePotos(final Activity act) {
         BottomSheetMaterialDialog mBottomSheetDialog = new BottomSheetMaterialDialog.Builder((AppCompatActivity) getActivity())
                .setTitle("Delete permanetly ?")
                .setMessage("Are you sure want to delete selected file permanetly ?")
                .setCancelable(false)
                .setPositiveButton("Delete", R.drawable.ic_delete_black, new BottomSheetMaterialDialog.OnClickListener() {
                    @Override
                    public void onClick(com.shreyaspatil.MaterialDialog.interfaces.DialogInterface dialogInterface, int which) {
                        new DeleteImageTask().execute();
                        dialogInterface.dismiss();

                    }

                })
                .setNegativeButton("Cancel", R.drawable.ic_close_black_24dp, new BottomSheetMaterialDialog.OnClickListener() {
                    @Override
                    public void onClick(com.shreyaspatil.MaterialDialog.interfaces.DialogInterface dialogInterface, int which) {
                        dialogInterface.dismiss();
                    }

                })
                .build();
         mBottomSheetDialog.show();
    }

    public void RecoverImage(final Activity act) {
        AlertDialog alertDialog = new AlertDialog.Builder(act).create();
        alertDialog.setTitle("Recover to Album");
        ArrayList<PhotoItem> selected = getSelected();
        alertDialog.setMessage("Recover selected " + selected.size() + " photos to Album?");
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        new RecoverImageTask().execute();
                        dialog.dismiss();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Cancel",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }


    public class DeleteImageTask extends AsyncTask<String, Integer, String> {
        ProgressDialog pd;

        public DeleteImageTask() {
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(getActivity());
            pd.setTitle("Delete to Album");
            pd.setMessage("Please wait....");
            pd.setCancelable(false);
            pd.setIndeterminate(true);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            ArrayList<PhotoItem> selected = getSelected();
            for (int i = 0; i < selected.size(); i++) {
                if (!selected.get(i).getCouldId().equalsIgnoreCase("null1")) {
                    databaseHelper.deletePhotoTrash(selected.get(i).getId());
                }else {
                    File file = new File(selected.get(i).getNewPath());
                    if(file.exists())
                        file.delete();
                    databaseHelper.deletePhotoItem(selected.get(i));
                }
               imagesList.remove(selected.get(i));
            }
            return "null";
        }
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            imageListAdapter.notifyDataSetChanged();
            Toast.makeText(mContext, "Delete to Album successfully", Toast.LENGTH_SHORT).show();
            if (actionMode != null)
                actionMode.finish();
            countSelected = 0;

            Init();
        }
    }


    public class RecoverImageTask extends AsyncTask<String, Integer, String> {
        ProgressDialog pd;
        public RecoverImageTask() {
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(getActivity());
            pd.setTitle("Recover to Album");
            pd.setMessage("Please wait....");
            pd.setCancelable(false);
            pd.setIndeterminate(true);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            ArrayList<PhotoItem> selected = getSelected();
            for (int i = 0; i < selected.size(); i++) {
                databaseHelper.reCoverPhoto(selected.get(i).getId());
                imagesList.remove(selected.get(i));
            }
            return "null";
        }
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            imageListAdapter.notifyDataSetChanged();
            Toast.makeText(mContext, "Recover to Album successfully", Toast.LENGTH_SHORT).show();
            if (actionMode != null)
                actionMode.finish();
            countSelected = 0;
            Init();
        }
    }

}
