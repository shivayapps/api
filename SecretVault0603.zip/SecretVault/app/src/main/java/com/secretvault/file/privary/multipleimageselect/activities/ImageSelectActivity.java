package com.secretvault.file.privary.multipleimageselect.activities;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.ContentObserver;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Process;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.widget.Toolbar;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.LoadAdError;
import com.secretvault.file.privary.R;
import com.secretvault.file.privary.ads.AdmobAdManager;
import com.secretvault.file.privary.multipleimageselect.Constants;
import com.secretvault.file.privary.multipleimageselect.adapters.CustomImageSelectAdapter;
import com.secretvault.file.privary.multipleimageselect.adapters.CustomImageSelectAdapter1;
import com.secretvault.file.privary.views.CustomTextView;
import com.jiajunhui.xapp.medialoader.bean.PhotoItem;
import com.jiajunhui.xapp.medialoader.bean.VideoItem;

import java.util.ArrayList;

public class ImageSelectActivity extends HelperActivity {
    Intent mIntent;
    int selectType = 0;
    private ArrayList<PhotoItem> photoItems = new ArrayList<>();
    private ArrayList<VideoItem> videoItems = new ArrayList<>();
    private String album;
    private TextView errorDisplay;
    private ProgressBar progressBar;
    private GridView gridView;
    private CustomImageSelectAdapter imageAdapter;
    private CustomImageSelectAdapter1 videoAdapter;
    private ActionBar actionBar;
    private ActionMode actionMode;
    private int countSelected;
    private ContentObserver observer;
    private Handler handler;
    private Thread thread;
    private ActionMode.Callback callback = new ActionMode.Callback() {
        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            MenuInflater menuInflater = mode.getMenuInflater();
            menuInflater.inflate(R.menu.menu_contextual_action_bar, menu);
            actionMode = mode;
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            int i = item.getItemId();
            if (i == R.id.menu_item_add_image) {
                sendIntent();
                return true;
            }
            return false;
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {
            if (selectType == 1) {
                if (countSelected > 0) {
                    deselectAll();
                }
            } else {
                if (countSelected > 0) {
                    deselectAll2();
                }
            }
            actionMode = null;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_select);
        setView(findViewById(R.id.layout_image_select));

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        actionBar = getSupportActionBar();
        if (actionBar != null) {
            //actionBar.setDisplayHomeAsUpEnabled(true);
            //actionBar.setHomeAsUpIndicator(R.drawable.ic_arrow_back);
            //actionBar.setDisplayShowTitleEnabled(true);
//            actionBar.setTitle(R.string.image_view);
            CustomTextView tv_tital = findViewById(R.id.tv_tital);
            tv_tital.setText(R.string.image_view);
            ImageView iv_back = findViewById(R.id.iv_back);
            iv_back.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onBackPressed();
                }
            });
            findViewById(R.id.iv_option).setVisibility(View.GONE);

        }

        mIntent = getIntent();
        if (mIntent == null) {
            finish();
        }
        album = mIntent.getStringExtra(Constants.INTENT_EXTRA_ALBUM);
        selectType = mIntent.getIntExtra(Constants.INTENT_EXTRA_SELECT_TYPE, 1);

        toolbar.setTitle(album);
        errorDisplay = findViewById(R.id.text_view_error);
        errorDisplay.setVisibility(View.INVISIBLE);

        progressBar = findViewById(R.id.progress_bar_image_select);
        gridView = findViewById(R.id.grid_view_image_select);
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (selectType == 1) {
                    if (actionMode == null) {
                        actionMode = ImageSelectActivity.this.startActionMode(callback);
                    }
                    toggleSelection(position);
                    actionMode.setTitle(countSelected + " " + getString(R.string.selected));
                    if (countSelected == 0) {
                        actionMode.finish();
                    }
                } else {
                    if (actionMode == null) {
                        actionMode = ImageSelectActivity.this.startActionMode(callback);
                    }
                    toggleSelection2(position);
                    actionMode.setTitle(countSelected + " " + getString(R.string.selected));
                    if (countSelected == 0) {
                        actionMode.finish();
                    }
                }
            }
        });
    }

    @SuppressLint("HandlerLeak")
    @Override
    protected void onStart() {
        super.onStart();

        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case Constants.PERMISSION_GRANTED: {
                        loadImages();
                        break;
                    }

                    case Constants.FETCH_STARTED: {
                        progressBar.setVisibility(View.VISIBLE);
                        gridView.setVisibility(View.INVISIBLE);
                        break;
                    }

                    case Constants.FETCH_COMPLETED: {
                        if (selectType == 1) {
                            if (imageAdapter == null) {
                                imageAdapter = new CustomImageSelectAdapter(getApplicationContext(), photoItems);
                                gridView.setAdapter(imageAdapter);

                                progressBar.setVisibility(View.INVISIBLE);
                                gridView.setVisibility(View.VISIBLE);
                                orientationBasedUI(getResources().getConfiguration().orientation);

                            } else {
                                imageAdapter.notifyDataSetChanged();

                                if (actionMode != null) {
                                    countSelected = msg.arg1;
                                    actionMode.setTitle(countSelected + " " + getString(R.string.selected));
                                }
                            }
                        } else {
                            if (videoAdapter == null) {
                                videoAdapter = new CustomImageSelectAdapter1(getApplicationContext(), videoItems);
                                gridView.setAdapter(videoAdapter);

                                progressBar.setVisibility(View.INVISIBLE);
                                gridView.setVisibility(View.VISIBLE);
                                orientationBasedUI(getResources().getConfiguration().orientation);

                            } else {
                                videoAdapter.notifyDataSetChanged();

                                if (actionMode != null) {
                                    countSelected = msg.arg1;
                                    actionMode.setTitle(countSelected + " " + getString(R.string.selected));
                                }
                            }
                        }
                        break;
                    }

                    case Constants.ERROR: {
                        progressBar.setVisibility(View.INVISIBLE);
                        errorDisplay.setVisibility(View.VISIBLE);
                        break;
                    }

                    default: {
                        super.handleMessage(msg);
                    }
                }
            }
        };
        observer = new ContentObserver(handler) {
            @Override
            public void onChange(boolean selfChange) {
                loadImages();
            }
        };
        getContentResolver().registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, false, observer);

        checkPermission();
    }

    @Override
    protected void onStop() {
        super.onStop();

        stopThread();

        getContentResolver().unregisterContentObserver(observer);
        observer = null;

        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
            handler = null;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (actionBar != null) {
            actionBar.setHomeAsUpIndicator(null);
        }
        if (selectType == 1) {
            photoItems = null;
            if (imageAdapter != null) {
                imageAdapter.releaseResources();
            }
        } else {
            videoItems = null;
            if (videoAdapter != null) {
                videoAdapter.releaseResources();
            }
        }
        gridView.setOnItemClickListener(null);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        orientationBasedUI(newConfig.orientation);
    }

    private void orientationBasedUI(int orientation) {
        final WindowManager windowManager = (WindowManager) getApplicationContext().getSystemService(Context.WINDOW_SERVICE);
        final DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        if (selectType == 1) {
            if (imageAdapter != null) {
                int size = orientation == Configuration.ORIENTATION_PORTRAIT ? metrics.widthPixels / 3 : metrics.widthPixels / 5;
                imageAdapter.setLayoutParams(size);
            }
        } else {
            if (videoAdapter != null) {
                int size = orientation == Configuration.ORIENTATION_PORTRAIT ? metrics.widthPixels / 3 : metrics.widthPixels / 5;
                videoAdapter.setLayoutParams(size);
            }
        }

        gridView.setNumColumns(orientation == Configuration.ORIENTATION_PORTRAIT ? 3 : 5);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_selectall, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home: {
                onBackPressed();
                return true;
            }
            case R.id.action_select_all:
                if (selectType == 1) {
                    if (photoItems.size() > 0) {
                        selectAll();

                    }
                } else {
                    if (videoItems.size() > 0) {
                        selectAll2();

                    }
                }


                return true;
            default: {
                return false;
            }
        }
    }

    private void toggleSelection(int position) {
        photoItems.get(position).checked = !photoItems.get(position).isChecked();
        if (photoItems.get(position).checked) {
            countSelected++;
        } else {
            countSelected--;
        }
        imageAdapter.notifyDataSetChanged();
    }

    private void toggleSelection2(int position) {
        videoItems.get(position).checked = !videoItems.get(position).isChecked();
        if (videoItems.get(position).checked) {
            countSelected++;
        } else {
            countSelected--;
        }
        videoAdapter.notifyDataSetChanged();
    }

    private void deselectAll() {
        for (int i = 0, l = photoItems.size(); i < l; i++) {
            photoItems.get(i).checked = false;
        }
        countSelected = 0;
        imageAdapter.notifyDataSetChanged();
    }

    private void selectAll() {
        for (int i = 0, l = photoItems.size(); i < l; i++) {
            photoItems.get(i).checked = true;
        }

        imageAdapter.notifyDataSetChanged();
        countSelected = photoItems.size();
        if (actionMode == null) {
            actionMode = ImageSelectActivity.this.startActionMode(callback);
        }
        actionMode.setTitle(countSelected + " " + getString(R.string.selected));
    }

    private void deselectAll2() {
        for (int i = 0, l = videoItems.size(); i < l; i++) {
            videoItems.get(i).checked = false;
        }
        countSelected = 0;
        videoAdapter.notifyDataSetChanged();
    }

    private void selectAll2() {
        for (int i = 0, l = videoItems.size(); i < l; i++) {
            videoItems.get(i).checked = true;
        }

        videoAdapter.notifyDataSetChanged();
        countSelected = videoItems.size();
        if (actionMode == null) {
            actionMode = ImageSelectActivity.this.startActionMode(callback);
        }
        actionMode.setTitle(countSelected + " " + getString(R.string.selected));
    }

    private ArrayList<PhotoItem> getSelected() {
        ArrayList<PhotoItem> selectedImages = new ArrayList<>();
        for (int i = 0, l = photoItems.size(); i < l; i++) {
            if (photoItems.get(i).isChecked()) {
                selectedImages.add(photoItems.get(i));
            }
        }
        return selectedImages;
    }

    private ArrayList<VideoItem> getSelected2() {
        ArrayList<VideoItem> selectedImages = new ArrayList<>();
        for (int i = 0, l = videoItems.size(); i < l; i++) {
            if (videoItems.get(i).isChecked()) {
                selectedImages.add(videoItems.get(i));
            }
        }
        return selectedImages;
    }

    private void sendIntent() {
        if (selectType == 1) {
            Intent intent = new Intent();
//        intent.putParcelableArrayListExtra(Constants.INTENT_EXTRA_IMAGES, getSelected());
            intent.putExtra(Constants.INTENT_EXTRA_IMAGES, getSelected());
            setResult(RESULT_OK, intent);
        } else {
            Intent intent = new Intent();
//        intent.putParcelableArrayListExtra(Constants.INTENT_EXTRA_IMAGES, getSelected());
            intent.putExtra(Constants.INTENT_EXTRA_VIDEOS, getSelected2());
            setResult(RESULT_OK, intent);
        }
        showInterstitialAd();
    }

    private void showInterstitialAd() {
        Log.e(
                "AdsManager",
                "getInterstitial_id_001:" + getString(R.string.INTERSTITIAL_ID)
        );
        AdmobAdManager admobAdManager = new AdmobAdManager(this);
        if (admobAdManager.getInterstitialAd() != null) {
            if (admobAdManager.getInterstitialAd().isLoaded()) {
                admobAdManager.showProgress();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        admobAdManager.dismissProgress();
                        admobAdManager.getInterstitialAd().show();
                    }
                },1000);
                admobAdManager.getInterstitialAd().setAdListener(new AdListener() {

                    public void onAdClosed() {
                        super.onAdClosed();
                        admobAdManager.dismissProgress();
                        //App.setShowedInterstitialTime()
                        admobAdManager.loadInterstitialAd(
                                ImageSelectActivity.this,
                                getString(R.string.INTERSTITIAL_ID)
                        );
                        finish();
                    }

                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        super.onAdFailedToLoad(loadAdError);
                        Log.e("AdsManager", "LoadAdError:$loadAdError");
                        admobAdManager.dismissProgress();
                        finish();
                    }
                });
            } else {
                Log.e("AdsManager", "loadInterstitialAd:001");
                admobAdManager.dismissProgress();
                admobAdManager.loadInterstitialAd(this, getString(R.string.INTERSTITIAL_ID));
                finish();
            }
        } else {
            Log.e("AdsManager", "loadInterstitialAd:002");
            admobAdManager.dismissProgress();
            admobAdManager.loadInterstitialAd(this, getString(R.string.INTERSTITIAL_ID));
            finish();
        }
    }

    private void loadImages() {
        startThread(new ImageLoaderRunnable());
    }

    private void startThread(Runnable runnable) {
        stopThread();
        thread = new Thread(runnable);
        thread.start();
    }

    private void stopThread() {
        if (thread == null || !thread.isAlive()) {
            return;
        }

        thread.interrupt();
        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void sendMessage(int what) {
        sendMessage(what, 0);
    }

    private void sendMessage(int what, int arg1) {
        if (handler == null) {
            return;
        }
        Message message = handler.obtainMessage();
        message.what = what;
        message.arg1 = arg1;
        message.sendToTarget();
    }

    @Override
    protected void permissionGranted() {
        sendMessage(Constants.PERMISSION_GRANTED);
    }

    @Override
    protected void hideViews() {
        progressBar.setVisibility(View.INVISIBLE);
        gridView.setVisibility(View.INVISIBLE);
    }

    private class ImageLoaderRunnable implements Runnable {
        @Override
        public void run() {
            android.os.Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);
            if (selectType == 1) {
                if (imageAdapter == null) {
                    sendMessage(Constants.FETCH_STARTED);
                }
                if (photoItems == null) {
                    photoItems = new ArrayList<>();
                }
                photoItems = (ArrayList<PhotoItem>) mIntent.getSerializableExtra("ListData");
            } else {
                if (videoAdapter == null) {
                    sendMessage(Constants.FETCH_STARTED);
                }
                if (videoItems == null) {
                    videoItems = new ArrayList<>();
                }
                videoItems = (ArrayList<VideoItem>) mIntent.getSerializableExtra("ListData");
            }
            sendMessage(Constants.FETCH_COMPLETED);
        }
    }
}
