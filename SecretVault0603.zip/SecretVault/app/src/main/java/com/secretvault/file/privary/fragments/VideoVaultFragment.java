package com.secretvault.file.privary.fragments;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.secretvault.file.privary.R;
import com.secretvault.file.privary.activity.PlayerActivity;
import com.secretvault.file.privary.activity.TrashActivity;
import com.secretvault.file.privary.adapters.OnItemClickListner;
import com.secretvault.file.privary.adapters.VideoListAdapter;
import com.secretvault.file.privary.ads.AdEventListener;
import com.secretvault.file.privary.ads.AdmobAdManager;
import com.secretvault.file.privary.db.DatabaseHelper;
import com.secretvault.file.privary.multipleimageselect.Constants;
import com.secretvault.file.privary.multipleimageselect.activities.AlbumSelectActivity;
import com.secretvault.file.privary.utils.GoogleDriveHelper;
import com.secretvault.file.privary.utils.ItemOffsetDecoration;
import com.secretvault.file.privary.utils.PreferenceHelper;
import com.secretvault.file.privary.utils.Utils;
import com.secretvault.file.privary.views.CustomTextView;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;
import com.google.api.client.extensions.android.http.AndroidHttp;
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.DriveScopes;
import com.jiajunhui.xapp.medialoader.bean.VideoItem;
import com.shreyaspatil.MaterialDialog.BottomSheetMaterialDialog;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

import ru.bartwell.exfilepicker.ExFilePicker;

import static android.app.Activity.RESULT_OK;
import static com.secretvault.file.privary.multipleimageselect.Constants.isGridlayout;

public class VideoVaultFragment extends Fragment implements View.OnClickListener, OnItemClickListner {
    public Drive service;
    Context mContext;
    FloatingActionButton iv_photo;
    RecyclerView recycler_photolist;
    LinearLayout lin_nodata;
    View view;
    VideoListAdapter imageListAdapter;
    DatabaseHelper databaseHelper;
    ArrayList<VideoItem> videoList = new ArrayList<>();
    boolean isSelectedMode = false;
    GridLayoutManager gridLayoutManager;
    boolean isbackup = false;
    private ActionBar actionBar;
    private ActionMode actionMode;
    private int countSelected;
    private GoogleAccountCredential credential;
    private ActionMode.Callback callback = new ActionMode.Callback() {
        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            MenuInflater menuInflater = mode.getMenuInflater();
            menuInflater.inflate(R.menu.menu_unhide, menu);
            actionMode = mode;
            countSelected = 0;
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            int i = item.getItemId();
            if (i == R.id.action_unhide) {
                dialogUnhideFile(getActivity());
                return true;
            } else if (i == R.id.action_delete) {
                dialogDeleteVideoView(getActivity());
                return true;
            }
            return false;
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {
            if (countSelected > 0) {
                deselectAll();
            }
            actionMode = null;
        }
    };

    public void addImageToGallery(final Context context, final String filePath, String mimetype) {
        ContentValues values = new ContentValues();

        values.put(MediaStore.MediaColumns.DATE_TAKEN, System.currentTimeMillis());
        values.put(MediaStore.MediaColumns.MIME_TYPE, mimetype);
        values.put(MediaStore.MediaColumns.DATA, filePath);

        context.getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
        MediaScannerConnection.scanFile(context,
                new String[]{filePath}, null,
                new MediaScannerConnection.OnScanCompletedListener() {
                    public void onScanCompleted(String path, Uri uri) {
                    }
                });

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_photo_vaulat, container, false);
        mContext = getActivity();
        actionBar = ((AppCompatActivity) getActivity()).getSupportActionBar();


        if (actionBar != null) {
            //actionBar.setDisplayHomeAsUpEnabled(true);
            //actionBar.setHomeAsUpIndicator(R.drawable.ic_arrow_back);
            //actionBar.setDisplayShowTitleEnabled(true);
            CustomTextView tv_tital = getActivity().findViewById(R.id.tv_tital);
            tv_tital.setText(R.string.tital_hide_videos);
            ImageView iv_back = getActivity().findViewById(R.id.iv_back);
            iv_back.setOnClickListener(this);
            ImageView iv_option = getActivity().findViewById(R.id.iv_option);
            iv_option.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    PopupMenu popupMenu=new PopupMenu(getActivity(),iv_option);
                    popupMenu.inflate(R.menu.menu_recover);

                    MenuItem menuItem = popupMenu.getMenu().findItem(R.id.action_list_to_grid);
                    String text = isGridlayout ? "Grid to list" : " List to grid";
                    menuItem.setTitle(text);

                    popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                        @Override
                        public boolean onMenuItemClick(MenuItem item) {
                            switch (item.getItemId()) {
                                case R.id.action_open_recover:
                                    Intent intent = new Intent(mContext, TrashActivity.class);
                                    intent.putExtra("Type", "trashvideos");
                                    startActivityForResult(intent, 120);
                                    return true;
                                case R.id.action_sort:
                                    dialogSort();
                                    return true;
                                case R.id.action_select_all:
                                    if (videoList.size() > 0) {
                                        isSelectedMode = true;
                                        if (actionMode == null) {
                                            actionMode = getActivity().startActionMode(callback);
                                        }
                                        selectAll();
                                        actionMode.setTitle(countSelected + " " + getString(R.string.selected));
                                    } else {
                                        Toast.makeText(mContext, mContext.getResources().getString(R.string.no_file), Toast.LENGTH_SHORT).show();
                                    }
                                    return true;
                                case R.id.action_list_to_grid: {
                                    if (gridLayoutManager.getSpanCount() == 1) {
                                        gridLayoutManager.setSpanCount(3);
                                        imageListAdapter.setSpanCount(3);
                                        isGridlayout = true;
                                    } else {
                                        gridLayoutManager.setSpanCount(1);
                                        imageListAdapter.setSpanCount(1);
                                        isGridlayout = false;
                                    }

                                    String text = isGridlayout ? "Grid to list" : " List to grid";
                                    item.setTitle(text);

                                    imageListAdapter = new VideoListAdapter(mContext, videoList);
                                    imageListAdapter.setItemClickEvent(VideoVaultFragment.this);
                                    imageListAdapter.setImageResize(Utils.getImageResize(mContext, recycler_photolist));
                                    recycler_photolist.setAdapter(imageListAdapter);
                                    return true;
                                }
                            }
                            return false;
                        }
                    });

                    popupMenu.show();
                }
            });
        }

        /*if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_arrow_back);

            actionBar.setDisplayShowTitleEnabled(true);
//            actionBar.setTitle(R.string.tital_hide_videos);
            CustomTextView tv_tital   = getActivity().findViewById(R.id.tv_tital);
            tv_tital.setText(R.string.tital_hide_videos);
        }*/
        databaseHelper = new DatabaseHelper(mContext);
        createImageDir();
        setHasOptionsMenu(true);
        Init();
        return view;
    }

    public void Init() {
        iv_photo = view.findViewById(R.id.iv_photo);
        iv_photo.setOnClickListener(this);
        lin_nodata = view.findViewById(R.id.lin_nodata);
        recycler_photolist = view.findViewById(R.id.recycler_photolist);
        int no = isGridlayout ? 3 : 1;
        gridLayoutManager = new GridLayoutManager(mContext, no);
        recycler_photolist.setLayoutManager(gridLayoutManager);
        ItemOffsetDecoration itemDecoration = new ItemOffsetDecoration(mContext, R.dimen.item_space);
        recycler_photolist.addItemDecoration(itemDecoration);
        videoList = databaseHelper.getAllVideos();

        imageListAdapter = new VideoListAdapter(mContext, videoList);
        imageListAdapter.setItemClickEvent(this);
        imageListAdapter.setImageResize(Utils.getImageResize(mContext, recycler_photolist));
        recycler_photolist.setAdapter(imageListAdapter);

        if (videoList.size() > 0) {
            recycler_photolist.setVisibility(View.VISIBLE);
            lin_nodata.setVisibility(View.GONE);
        } else {
            recycler_photolist.setVisibility(View.GONE);
            lin_nodata.setVisibility(View.VISIBLE);
        }

        RelativeLayout frameLayout = view.findViewById(R.id.fl_adplaceholder);
        AdmobAdManager admobAdManager = new AdmobAdManager(mContext);
        admobAdManager.loadAdaptiveBanner(mContext,  frameLayout, getString(R.string.BANNER_ID),new AdEventListener() {
            @Override
            public void onAdLoaded() {
                frameLayout.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {

            }

            @Override
            public void onLoadError(String errorCode) {
                frameLayout.setVisibility(View.GONE);
            }
        });
    }

    public void unHideFile() {
        ArrayList<VideoItem> selected = getSelected();
        for (int i = 0; i < selected.size(); i++) {
            File file = new File(selected.get(i).getNewPath());
            File targetLocation = new File(selected.get(i).getPath());
            File file1 = new File(targetLocation.getParent());
            if (!file1.exists()) {
                file1.mkdirs();
            }
            if (file.renameTo(targetLocation)) {
                databaseHelper.deleteVideoItem(selected.get(i));
                addImageToGallery(mContext, targetLocation.getAbsolutePath(), selected.get(i).getMimeType());
            }
        }
        if (actionMode != null)
            actionMode.finish();
        countSelected = 0;
        Init();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_back:
                getActivity().onBackPressed();
                break;
            case R.id.iv_photo: {
                Intent intent = new Intent(mContext, AlbumSelectActivity.class);
                intent.putExtra(Constants.INTENT_EXTRA_LIMIT, 10);
                intent.putExtra(Constants.INTENT_EXTRA_SELECT_TYPE, 2);
                startActivityForResult(intent, Constants.REQUEST_CODE_VIDEO);
            }
            break;

            default:
                break;
        }
    }

    @Override
    public void onItemClick(int position) {
        if (isSelectedMode) {
            if (actionMode == null) {
                actionMode = getActivity().startActionMode(callback);
            }
            toggleSelection(position);
            actionMode.setTitle(countSelected + " " + getString(R.string.selected));

            if (countSelected == 0) {
                actionMode.finish();
                isSelectedMode = false;
            }
        } else {
            Intent intent = new Intent(mContext, PlayerActivity.class);
            intent.putExtra("filepath", videoList.get(position).getNewPath());
            startActivity(intent);
        }

    }

    @Override
    public void onItemLongClick(int position) {
        isSelectedMode = true;
        if (actionMode == null) {
            actionMode = getActivity().startActionMode(callback);
        }
        toggleSelection(position);
        actionMode.setTitle(countSelected + " " + getString(R.string.selected));

        if (countSelected == 0) {
            actionMode.finish();
            isSelectedMode = false;
        }
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        //inflater.inflate(R.menu.menu_recover, menu);
        super.onCreateOptionsMenu(menu, inflater);

    }
    @Override
    public void onPrepareOptionsMenu(@NonNull Menu menu) {
        super.onPrepareOptionsMenu(menu);
        //MenuItem menuItem = menu.findItem(R.id.action_list_to_grid);
        //String text = isGridlayout ? "Grid to list" : " List to grid";
        //menuItem.setTitle(text);

    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_open_recover:
                Intent intent = new Intent(mContext, TrashActivity.class);
                intent.putExtra("Type", "trashvideos");
                startActivityForResult(intent, 120);
                return true;
            case R.id.action_sort:
                dialogSort();
                return true;
            case R.id.action_select_all:
                if (videoList.size() > 0) {
                    isSelectedMode = true;
                    if (actionMode == null) {
                        actionMode = getActivity().startActionMode(callback);
                    }
                    selectAll();
                    actionMode.setTitle(countSelected + " " + getString(R.string.selected));
                } else {
                    Toast.makeText(mContext, mContext.getResources().getString(R.string.no_file), Toast.LENGTH_SHORT).show();
                }
                return true;
            case R.id.action_list_to_grid: {
                    if (gridLayoutManager.getSpanCount() == 1) {
                        gridLayoutManager.setSpanCount(3);
                        imageListAdapter.setSpanCount(3);
                        isGridlayout = true;
                    } else {
                        gridLayoutManager.setSpanCount(1);
                        imageListAdapter.setSpanCount(1);
                        isGridlayout = false;
                    }

                String text = isGridlayout ? "Grid to list" : " List to grid";
                item.setTitle(text);

                imageListAdapter = new VideoListAdapter(mContext, videoList);
                imageListAdapter.setItemClickEvent(this);
                imageListAdapter.setImageResize(Utils.getImageResize(mContext, recycler_photolist));
                recycler_photolist.setAdapter(imageListAdapter);
                return true;
            }
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void dialogSort() {
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(getActivity(), R.style.BottomSheetDialogTheme);
        View dialogView = View.inflate(getActivity(), R.layout.layout_dialog_sort, null);
        MaterialButton button_negative = dialogView.findViewById(R.id.button_negative);
        MaterialButton button_positive = dialogView.findViewById(R.id.button_positive);
        TextView title = dialogView.findViewById(R.id.textView_title);
        TextView textView_message = dialogView.findViewById(R.id.textView_message);
        title.setText("Sort data");
        textView_message.setText("");
        RadioGroup radioGroup = dialogView.findViewById(R.id.radioGroup);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            button_negative.setIcon(getActivity().getDrawable(R.drawable.ic_close_black_24dp));
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            button_positive.setIcon(getActivity().getDrawable(R.drawable.ic_sort_black_24dp));
        }
        button_negative.setText("Cancel");
        button_positive.setText("Sort");
        button_negative.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetDialog.dismiss();
            }
        });

        button_positive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedId = radioGroup.getCheckedRadioButtonId();
                RadioButton radioButton = dialogView.findViewById(selectedId);
                sortData(radioButton);
                bottomSheetDialog.dismiss();
            }
        });
        bottomSheetDialog.setContentView(dialogView);
        bottomSheetDialog.show();
    }

    public void sortData(RadioButton radioButton) {
        Log.e("UCSafe","Video_sortData:"+radioButton.getText());
        //ExFilePicker.SortingType sortingType = ExFilePicker.SortingType.NAME_ASC;

        switch (radioButton.getId()) {
            case R.id.rb_name_aes:
                Collections.sort(videoList, new Comparator<VideoItem>() {
                    @Override
                    public int compare(VideoItem lhs, VideoItem rhs) {
                        return lhs.getDisplayName().compareTo(rhs.getDisplayName());
                    }
                });
                imageListAdapter.setData(videoList);
                break;
            case R.id.rb_name_des:
                Collections.sort(videoList, new Comparator<VideoItem>() {
                    @Override
                    public int compare(VideoItem lhs, VideoItem rhs) {
                        return lhs.getDisplayName().compareTo(rhs.getDisplayName());
                    }
                });
                Collections.reverse(videoList);
                imageListAdapter.setData(videoList);
                break;
            case R.id.rb_size_aes:

                Collections.sort(videoList, new Comparator<VideoItem>() {
                    @Override
                    public int compare(VideoItem o1, VideoItem o2) {
                        return Integer.valueOf((int) (new File(o1.getNewPath()).length() / 1000)).compareTo(Integer.valueOf((int) (new File(o2.getNewPath()).length() / 1000)));
                    }
                });
                imageListAdapter.setData(videoList);
                break;
            case R.id.rb_size_des:
                Collections.sort(videoList, new Comparator<VideoItem>() {
                    @Override
                    public int compare(VideoItem o1, VideoItem o2) {
                        return Integer.valueOf((int) (new File(o1.getNewPath()).length() / 1000)).compareTo(Integer.valueOf((int) (new File(o2.getNewPath()).length() / 1000)));
                    }
                });
                Collections.reverse(videoList);
                imageListAdapter.setData(videoList);
                break;
            case R.id.rb_date_aes:
                Collections.sort(videoList, new Comparator<VideoItem>() {
                    @Override
                    public int compare(VideoItem o1, VideoItem o2) {
                        return Integer.valueOf((int) (new File(o1.getNewPath()).lastModified() / 1000)).compareTo(Integer.valueOf((int) (new File(o2.getNewPath()).lastModified() / 1000)));
                    }
                });
                imageListAdapter.setData(videoList);
                break;
            case R.id.rb_date_des:
                Collections.sort(videoList, new Comparator<VideoItem>() {
                    @Override
                    public int compare(VideoItem o1, VideoItem o2) {
                        return Integer.valueOf((int) (new File(o1.getNewPath()).lastModified() / 1000)).compareTo(Integer.valueOf((int) (new File(o2.getNewPath()).lastModified() / 1000)));
                    }
                });
                Collections.reverse(videoList);
                imageListAdapter.setData(videoList);
                break;
        }
        imageListAdapter.notifyDataSetChanged();
    }

    private void toggleSelection(int position) {
        videoList.get(position).checked = !videoList.get(position).isChecked();
        if (videoList.get(position).checked) {
            countSelected++;
        } else {
            countSelected--;
        }
        imageListAdapter.notifyDataSetChanged();
    }

    private void deselectAll() {
        for (int i = 0, l = videoList.size(); i < l; i++) {
            videoList.get(i).checked = false;
        }
        isSelectedMode = false;
        countSelected = 0;
        imageListAdapter.notifyDataSetChanged();
    }

    private void selectAll() {
        for (int i = 0, l = videoList.size(); i < l; i++) {
            videoList.get(i).checked = true;
        }
        isSelectedMode = true;
        countSelected = videoList.size();
        imageListAdapter.notifyDataSetChanged();
    }

    private ArrayList<VideoItem> getSelected() {
        ArrayList<VideoItem> selectedImages = new ArrayList<>();
        for (int i = 0, l = videoList.size(); i < l; i++) {
            if (videoList.get(i).isChecked()) {
                selectedImages.add(videoList.get(i));
            }
        }
        return selectedImages;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            if (requestCode == Constants.REQUEST_CODE_VIDEO) {
                ArrayList<VideoItem> images = (ArrayList<VideoItem>) data.getSerializableExtra(Constants.INTENT_EXTRA_VIDEOS);
                for (int i = 0; i < images.size(); i++) {
                    Log.e("TAG", "onActivityResult: " + images.get(i).getPath());
                    hideFile(images.get(i));
                }
                Init();
            }
        }
        if (requestCode == 120) {
            Init();
        }
    }

    private void hideFile(VideoItem mediaFile) {
        File file = new File(mediaFile.getPath());
        String fileName = file.getName();
        String oriPath = file.getAbsolutePath();

        File targetLocation = new File(Utils.nohideVideo + fileName + ".bin");
        if (file.renameTo(targetLocation)) {
            RemoveAllForPaths(file, mContext);
            databaseHelper.insertVideo(fileName, oriPath, targetLocation.getAbsolutePath(), mediaFile.getSize(), mediaFile.getDuration(), mediaFile.getMimeType());
        } else {
        }

    }

    public void RemoveAllForPaths(File file, Context context) {
        final String where = MediaStore.MediaColumns.DATA + "=?";
        final String[] selectionArgs = new String[]{
                file.getAbsolutePath()
        };
        final ContentResolver contentResolver = mContext.getContentResolver();
        final Uri filesUri = MediaStore.Files.getContentUri("external");
        contentResolver.delete(filesUri, where, selectionArgs);
        if (file.exists()) {
            contentResolver.delete(filesUri, where, selectionArgs);
        }
    }

    public void createImageDir() {
        File myDirectory = new File(Utils.nohideVideo);
        if (!myDirectory.exists()) {
            myDirectory.mkdirs();
            Log.e("TAG", "createImageDir: mkdir");
        } else {
        }
    }

    public void dialogUnhideFile(final Activity act) {
        BottomSheetMaterialDialog mBottomSheetDialog = new BottomSheetMaterialDialog.Builder((AppCompatActivity) act)
                .setTitle("Unhide Videos?")
                .setMessage("Are you sure want to restore(unhide) selected videos?")
                .setCancelable(false)
                .setPositiveButton("Unhide", R.drawable.ic_eye_black_24dp, new BottomSheetMaterialDialog.OnClickListener() {
                    @Override
                    public void onClick(com.shreyaspatil.MaterialDialog.interfaces.DialogInterface dialogInterface, int which) {
                        unHideFile();
                        dialogInterface.dismiss();
                    }
                })
                .setNegativeButton("Cancel", R.drawable.ic_close_black_24dp, new BottomSheetMaterialDialog.OnClickListener() {
                    @Override
                    public void onClick(com.shreyaspatil.MaterialDialog.interfaces.DialogInterface dialogInterface, int which) {
                        dialogInterface.dismiss();
                    }
                })
                .build();
        mBottomSheetDialog.show();
    }

    public void dialogDeleteVideoView(final Activity act) {
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(act, R.style.BottomSheetDialogTheme);
        View dialogView = View.inflate(act, R.layout.layout_alert_dialog_delete, null);
        MaterialButton button_negative = dialogView.findViewById(R.id.button_negative);
        MaterialButton button_positive = dialogView.findViewById(R.id.button_positive);
        TextView title = dialogView.findViewById(R.id.textView_title);
        TextView textView_message = dialogView.findViewById(R.id.textView_message);
        LinearLayout lin_careful = dialogView.findViewById(R.id.lin_careful);
        CheckBox chk_trash = dialogView.findViewById(R.id.chk_trash);
        CheckBox chk_cloud = dialogView.findViewById(R.id.chk_cloud);
        ArrayList<VideoItem> selected = getSelected();
        for (int i = 0; i < selected.size(); i++) {
            String cid = selected.get(i).getCouldId();
            if (cid.equalsIgnoreCase("null1")) {
            } else {
                isbackup = true;
                break;
            }
        }

        title.setText("Delete videos?");
        title.setVisibility(View.VISIBLE);
        textView_message.setText("Delete the selected " + selected.size() + " videos?");
        if (isbackup)
            chk_cloud.setVisibility(View.VISIBLE);
        else
            chk_cloud.setVisibility(View.GONE);

        chk_trash.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    lin_careful.setVisibility(View.GONE);
                } else {
                    if (isbackup) {
                        if (chk_cloud.isChecked())
                            lin_careful.setVisibility(View.GONE);
                        else
                            lin_careful.setVisibility(View.VISIBLE);
                    } else {
                        lin_careful.setVisibility(View.VISIBLE);
                    }
                }
            }
        });

        chk_cloud.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    lin_careful.setVisibility(View.GONE);
                } else {
                    if (isbackup) {
                        if (chk_trash.isChecked())
                            lin_careful.setVisibility(View.GONE);
                        else
                            lin_careful.setVisibility(View.VISIBLE);
                    } else {
                        lin_careful.setVisibility(View.VISIBLE);
                    }
                }
            }
        });
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            button_negative.setIcon(act.getDrawable(R.drawable.ic_close_black_24dp));
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            button_positive.setIcon(act.getDrawable(R.drawable.ic_delete_black));
        }
        button_negative.setText("Cancel");
        button_positive.setText("Delete");
        button_negative.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (actionMode != null)
                    actionMode.finish();
                countSelected = 0;
                bottomSheetDialog.dismiss();
            }
        });

        button_positive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getGoogleService();
                deletVideo(chk_trash.isChecked(), chk_cloud.isChecked());
                bottomSheetDialog.dismiss();
            }
        });
        bottomSheetDialog.setContentView(dialogView);
        bottomSheetDialog.show();
    }

    private void getGoogleService() {
        if (Utils.isNetworkAvailable(mContext)) {
            credential = GoogleAccountCredential.usingOAuth2(mContext, Arrays.asList(DriveScopes.DRIVE_FILE));
            String accountName = PreferenceHelper.getValue(mContext, PreferenceHelper.AccountName, "");
            if (accountName.length() > 0) {
                credential.setSelectedAccountName(accountName);
                service = getDriveService(credential);
            } else {
            }

        } else {

        }
    }

    private Drive getDriveService(GoogleAccountCredential credential) {
        return new Drive.Builder(AndroidHttp.newCompatibleTransport(), new GsonFactory(), credential).setApplicationName(getString(R.string.app_name)).build();
    }

    private void deletVideo(boolean isCheckedTrash, boolean isCheckCloud) {
        new DeleteCloudFileTask(isCheckedTrash, isCheckCloud).execute();
    }

    public class DeleteCloudFileTask extends AsyncTask<String, String, String> {
        ProgressDialog pd;
        boolean isCheckedTrash;
        boolean isCheckCloud;

        public DeleteCloudFileTask(boolean isCheckedTrash, boolean isCheckCloud) {
            this.isCheckedTrash = isCheckedTrash;
            this.isCheckCloud = isCheckCloud;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(getActivity());
            pd.setTitle("Connectd to server");
            pd.setMessage("Please wait....");
            pd.setCancelable(false);
            pd.setIndeterminate(true);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            ArrayList<VideoItem> selected = getSelected();
            for (int i = 0; i < selected.size(); i++) {
                File file = new File(selected.get(i).getNewPath());
                File targetLocation = new File(selected.get(i).getPath());
                File file1 = new File(targetLocation.getParent());
                if (!file1.exists()) {
                    file1.mkdirs();
                }
                if (isCheckedTrash) {
                    databaseHelper.movewTrathVideo(selected.get(i).getId());
                }
                if (isCheckCloud) {
                    if (!selected.get(i).getCouldId().equalsIgnoreCase("null1")) {
                        GoogleDriveHelper.deleteFile(service, selected.get(i).getCouldId());
                    }
                }
                if (!isCheckedTrash && !isCheckCloud) {
                    if (!selected.get(i).getCouldId().equalsIgnoreCase("null1")) {
                        GoogleDriveHelper.deleteFile(service, selected.get(i).getCouldId());
                    }
                }
                videoList.remove(selected.get(i));
            }
            return "null";
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            imageListAdapter.notifyDataSetChanged();
            Toast.makeText(mContext, "Delete files successfully", Toast.LENGTH_SHORT).show();
            if (actionMode != null)
                actionMode.finish();
            countSelected = 0;
        }
    }


}
