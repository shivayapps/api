package com.secretvault.file.privary.adapters;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.secretvault.file.privary.R;
import com.secretvault.file.privary.utils.StorageUtil;
import com.secretvault.file.privary.views.CustomTextView;
import com.jiajunhui.xapp.medialoader.bean.PhotoItem;

import java.io.File;
import java.util.ArrayList;

import static com.secretvault.file.privary.multipleimageselect.Constants.isGridlayout;

public class ImageListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    public OnItemClickListner onItemClickListner;
    public int spanCount = 1;
    Context mContext;
    int mImageResize;
    private ArrayList<PhotoItem> mediaFiles = new ArrayList<>();

    public ImageListAdapter(Context mcContext, ArrayList<PhotoItem> mediaFiles) {
        this.mediaFiles = mediaFiles;
        this.mContext = mcContext;
    }

    public void setData(ArrayList<PhotoItem> mediaFiles) {
        this.mediaFiles = mediaFiles;
        notifyDataSetChanged();
    }

    public void setSpanCount(int spanCount) {
        this.spanCount = spanCount;
    }

    public void setItemClickEvent(OnItemClickListner onItemClickListner) {
        this.onItemClickListner = onItemClickListner;
    }
    public void setImageResize(int imageSize) {
        this.mImageResize = imageSize;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (!isGridlayout) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_file_adapter, parent, false);
            return new ViewHolderList(view);
        } else {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_image_adapter, parent, false);
            return new ViewHolderGrid(view);
        }
    }
    boolean isSelected = false;
    @Override
    public int getItemViewType(int position) {
        return isGridlayout ? 0 : 1;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (getItemViewType(position) == 0) {
            ViewHolderGrid viewHolderGrid = (ViewHolderGrid) holder;

            File mediaFile = new File(mediaFiles.get(position).getNewPath());
            if (mediaFile.exists()) {
                RequestOptions options = new RequestOptions()
                        .centerCrop()
                        .override(mImageResize, mImageResize)
                        .placeholder(R.drawable.ic_placeholder);

                String parth = mediaFile.getAbsolutePath();
                File targetLocation = new File(parth);
                viewHolderGrid.media_thumbnail.setVisibility(View.VISIBLE);
                Glide.with(mContext)
                        .load(Uri.fromFile(targetLocation))
                        .apply(options)
                        .into(viewHolderGrid.media_thumbnail);
                viewHolderGrid.tv_filename.setText(mediaFiles.get(position).getDisplayName());
                viewHolderGrid.tv_size.setText(StorageUtil.convertStorage(targetLocation.length()));
                viewHolderGrid.tv_filename.setVisibility(View.GONE);
                viewHolderGrid.tv_size.setVisibility(View.GONE);

                viewHolderGrid.iv_chek.getLayoutParams().height = mImageResize;
                viewHolderGrid.iv_chek.getLayoutParams().width = mImageResize;
                viewHolderGrid.iv_chek.requestLayout();
                if (mediaFiles.get(position).checked) {
                    viewHolderGrid.iv_chek.setVisibility(View.VISIBLE);
                } else {
                    viewHolderGrid.iv_chek.setVisibility(View.INVISIBLE);
                }
                viewHolderGrid.iv_chek.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (onItemClickListner != null) {
                            onItemClickListner.onItemClick(position);
                        }
                    }
                });
                viewHolderGrid.frm_root.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (onItemClickListner != null) {
                            onItemClickListner.onItemClick(position);
                        }
                    }
                });
                viewHolderGrid.iv_chek.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        if (onItemClickListner != null) {
                            onItemClickListner.onItemLongClick(position);
                        }
                        return false;
                    }
                });
                viewHolderGrid.frm_root.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        if (onItemClickListner != null) {
                            onItemClickListner.onItemLongClick(position);
                        }
                        return false;
                    }
                });

            }
        } else if(getItemViewType(position) == 1){
            ViewHolderList viewHolderList = (ViewHolderList) holder;

            File mediaFile = new File(mediaFiles.get(position).getNewPath());
            if (mediaFile.exists()) {
                RequestOptions options = new RequestOptions()
                        .placeholder(R.drawable.ic_placeholder);

                String parth = mediaFile.getAbsolutePath();
                File targetLocation = new File(parth);
                viewHolderList.media_thumbnail.setVisibility(View.VISIBLE);
                Glide.with(mContext)
                        .load(Uri.fromFile(targetLocation))
                        .apply(options)
                        .into(viewHolderList.media_thumbnail);
                viewHolderList.tv_filename.setText(mediaFiles.get(position).getDisplayName());
                viewHolderList.tv_size.setText(StorageUtil.convertStorage(targetLocation.length()));
                viewHolderList.tv_filename.setVisibility(View.VISIBLE);
                viewHolderList.tv_size.setVisibility(View.VISIBLE);

                if (mediaFiles.get(position).checked) {
                    viewHolderList.iv_chek.setVisibility(View.VISIBLE);
                    viewHolderList.iv_chek.setImageResource(R.drawable.ic_check_box_black_24dp);
                } else {
                    viewHolderList.iv_chek.setImageResource(R.drawable.ic_check_box_outline_blank_black_24dp);
                    if (isSelected)
                        viewHolderList.iv_chek.setVisibility(View.VISIBLE);
                    else
                        viewHolderList.iv_chek.setVisibility(View.INVISIBLE);
                }

                viewHolderList.iv_chek.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (onItemClickListner != null) {
                            onItemClickListner.onItemClick(position);
                        }
                    }
                });
                viewHolderList.frm_root.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (onItemClickListner != null) {
                            onItemClickListner.onItemClick(position);
                        }
                    }
                });
                viewHolderList.iv_chek.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        if (onItemClickListner != null) {
                            onItemClickListner.onItemLongClick(position);
                            isSelected =true;
                        }
                        return false;
                    }
                });
                viewHolderList.frm_root.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        if (onItemClickListner != null) {
                            onItemClickListner.onItemLongClick(position);
                            isSelected= true;
                        }
                        return false;
                    }
                });

            }
        }
    }

    @Override
    public int getItemCount() {
        return mediaFiles.size();
    }

    public class ViewHolderGrid extends RecyclerView.ViewHolder {
        LinearLayout frm_root;
        ImageView media_thumbnail, iv_chek;
        CustomTextView tv_filename, tv_size;

        ViewHolderGrid(View view) {
            super(view);
            media_thumbnail = view.findViewById(R.id.media_thumbnail);
            tv_filename = view.findViewById(R.id.tv_filename);
            tv_size = view.findViewById(R.id.tv_size);
            frm_root = view.findViewById(R.id.frm_root);
            iv_chek = view.findViewById(R.id.iv_chek);
        }
    }

    public class ViewHolderList extends RecyclerView.ViewHolder {
        LinearLayout frm_root;
        ImageView media_thumbnail, iv_chek;
        CustomTextView tv_filename, tv_size;

        ViewHolderList(View view) {
            super(view);
            media_thumbnail = view.findViewById(R.id.media_thumbnail);
            tv_filename = view.findViewById(R.id.tv_filename);
            tv_size = view.findViewById(R.id.tv_size);
            frm_root = view.findViewById(R.id.frm_root);
            iv_chek = view.findViewById(R.id.iv_chek);
        }
    }
}
