package com.secretvault.file.privary.activity;

import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.secretvault.file.privary.R;
import com.secretvault.file.privary.ads.AdmobAdManager;
import com.secretvault.file.privary.utils.Utils;
import com.secretvault.file.privary.views.CustomTextView;
import com.secretvault.file.privary.progress.RoundedHorizontalProgressBar;

import java.io.File;

public class PlayerActivity extends AppCompatActivity implements View.OnClickListener {


    VideoView videoView;
    Activity activity;
    File file;
    Handler handler = new Handler();
    private TextView reachTime, totalTime;
    private ImageView playBtn;
    private RoundedHorizontalProgressBar mProgressBar;
    private ActionBar actionBar;

    private void setProgress() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                int reach = videoView.getCurrentPosition();
                int progress = ((reach * 100) / videoView.getDuration());
                reachTime.setText(Utils.stringForTime(videoView.getCurrentPosition()));
                mProgressBar.setProgress(progress);
                if (videoView.isPlaying()) {
                    playBtn.setImageDrawable(getResources().getDrawable(R.drawable.pause));
                } else {
                    playBtn.setImageDrawable(getResources().getDrawable(R.drawable.play));
                }
                setProgress();
            }
        }, 1000);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_view);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        activity = this;

        AdmobAdManager admobAdManager = new AdmobAdManager(activity);
        admobAdManager.loadFullScreenAdd(this, getString(R.string.INTERSTITIAL_ID));

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        actionBar = getSupportActionBar();
        if (actionBar != null) {
            //actionBar.setDisplayHomeAsUpEnabled(true);
            //actionBar.setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_36dp);
            //actionBar.setDisplayShowTitleEnabled(true);
        }
        ImageView iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        findViewById(R.id.iv_option).setVisibility(View.GONE);

        file = new File(getIntent().getStringExtra("filepath"));
        CustomTextView tv_tital = findViewById(R.id.tv_tital);
        tv_tital.setText(file.getName());


        reachTime = findViewById(R.id.reach_time);
        reachTime.setText(Utils.stringForTime(0));
        totalTime = findViewById(R.id.total_time);
        totalTime.setText(Utils.stringForTime(0));
        playBtn = findViewById(R.id.play_btn);
        playBtn.setOnClickListener(this);

        mProgressBar = findViewById(R.id.progressBar);
        mProgressBar.setProgress(0);
        mProgressBar.setMax(100);

        videoView = findViewById(R.id.videoView);

        videoView.setVideoPath(file.toString());
        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer1) {
                playVideo();
                mediaPlayer1.setLooping(true);
                totalTime.setText(Utils.stringForTime(videoView.getDuration()));
                setProgress();
            }
        });
    }


    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        Log.e("UCSafe", "PlayerActivity:onUserLeaveHint");
    }

    @Override
    public void onUserInteraction() {
        super.onUserInteraction();
        Log.e("UCSafe", "PlayerActivity:onUserInteraction");
    }
    @Override
    protected void onStop() {
        super.onStop();
        Log.e("UCSafe", "PlayerActivity:onStop");
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
        Log.e("UCSafe", "PlayerActivity:onKeyDown:"+keyCode);
        if(keyCode == KeyEvent.KEYCODE_HOME)
        {
            Log.e("UCSafe", "PlayerActivity:Home button pressed!");
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.play_btn:
                if (videoView.isPlaying()) {
                    pauseVideo();
                } else {
                    playVideo();
                }
                break;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home: {
                onBackPressed();
                return true;
            }
            default: {
                return false;
            }
        }
    }


    @Override
    protected void onPause() {
        pauseVideo();
        Log.e("UCSafe", "PlayerActivity:onPause");
        handler.removeCallbacksAndMessages(handler);
        super.onPause();
    }

    private void playVideo() {
        if (videoView != null && playBtn != null) {
            videoView.start();
            playBtn.setImageDrawable(getResources().getDrawable(R.drawable.pause));
        }
    }

    private void pauseVideo() {
        if (videoView != null && playBtn != null) {
            videoView.pause();
            playBtn.setImageDrawable(getResources().getDrawable(R.drawable.play));
        }
    }

    @Override
    protected void onResume() {
        playVideo();
        super.onResume();
        Log.e("UCSafe", "PlayerActivity:onResume");
    }

    private boolean checkFileConverted(File file) {
        return file.exists();
    }

}
