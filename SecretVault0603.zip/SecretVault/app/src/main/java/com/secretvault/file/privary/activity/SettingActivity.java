package com.secretvault.file.privary.activity;

import android.accounts.AccountManager;
import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.content.res.ColorStateList;
import android.graphics.drawable.Icon;
import android.hardware.fingerprint.FingerprintManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.secretvault.file.privary.BuildConfig;
import com.secretvault.file.privary.R;
import com.secretvault.file.privary.adapters.SpinnerAdapter;
import com.secretvault.file.privary.db.DatabaseHelper;
import com.secretvault.file.privary.db.UserItem;
import com.secretvault.file.privary.utils.AppIconNameChanger;
import com.secretvault.file.privary.utils.Connectivity;
import com.secretvault.file.privary.utils.MyDeviceAdminPolicyManager;
import com.secretvault.file.privary.utils.PreferenceHelper;
import com.secretvault.file.privary.views.CustomTextView;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential;
import com.google.api.services.drive.DriveScopes;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SettingActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = "SettingActivity";
    private static final int REQUEST_ACCOUNT_PICKER = 0;
    List<String> disableAllNames;
    Spinner mySpinner;
    Context mContext;
    String[] textArray = {"Vault Files Photos Videos", "Calender", "Music", "Clock"};
    Integer[] imageArray = {R.drawable.ic_appicon, R.drawable.appicon_2,
            R.drawable.appicon_3, R.drawable.appicon_4};
    LinearLayout lin_addshortcut, lin_pinchange, lin_vibrator, lin_break_alerts, lin_antilost, lin_dadmin, lin_fprint, lin_emailVerification,lin_share,lin_rate,lin_policy;
    Switch swi_vibreator, swi_breck, swi_dadmin, swi_fprint;
    MyDeviceAdminPolicyManager policyManager;
    CustomTextView customTxt_email;
    private String oldPackageName = "com.secretvault.file.privary.activity.PinActivity_icon1";
    private GoogleAccountCredential credential;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        mContext = SettingActivity.this;

        disableAllNames = new ArrayList<String>();
        disableAllNames.add("com.secretvault.file.privary.activity.PinActivity_icon1");
        disableAllNames.add("com.secretvault.file.privary.activity.PinActivity_icon2");
        disableAllNames.add("com.secretvault.file.privary.activity.PinActivity_icon3");
        disableAllNames.add("com.secretvault.file.privary.activity.PinActivity_icon4");

        Toolbar toolbar = findViewById(R.id.toolbar);
        ImageView iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(this);
        findViewById(R.id.iv_option).setVisibility(View.GONE);

        setSupportActionBar(toolbar);

        CustomTextView tv_tital = findViewById(R.id.tv_tital);
        tv_tital.setText(R.string.tital_setting);

        policyManager = new MyDeviceAdminPolicyManager(this);
        Init();
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        Log.e("UCSafe", "SettingActivity:onUserLeaveHint");
    }

    @Override
    public void onUserInteraction() {
        super.onUserInteraction();
        Log.e("UCSafe", "SettingActivity:onUserInteraction");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("UCSafe", "SettingActivity:onResume");
    }
    @Override
    protected void onPause() {
        super.onPause();
        Log.e("UCSafe", "SettingActivity:onPause");
    }
    @Override
    protected void onStop() {
        super.onStop();
        Log.e("UCSafe", "SettingActivity:onStop");
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
        Log.e("UCSafe", "SettingActivity:onKeyDown:"+keyCode);
        if(keyCode == KeyEvent.KEYCODE_HOME)
        {
            Log.e("UCSafe", "SettingActivity:Home button pressed!");
        }
        return super.onKeyDown(keyCode, event);
    }

    private void Init() {
        mySpinner = findViewById(R.id.mySpinner);
        lin_addshortcut = findViewById(R.id.lin_addshortcut);
        lin_pinchange = findViewById(R.id.lin_pinchange);
        lin_vibrator = findViewById(R.id.lin_vibrator);
        lin_break_alerts = findViewById(R.id.lin_break_alerts);
        lin_emailVerification = findViewById(R.id.lin_emailVerification);
        swi_vibreator = findViewById(R.id.swi_vibreator);
        swi_breck = findViewById(R.id.swi_breck);
        swi_dadmin = findViewById(R.id.swi_dadmin);
        swi_fprint = findViewById(R.id.swi_fprint);

        lin_antilost = findViewById(R.id.lin_antilost);
        lin_dadmin = findViewById(R.id.lin_dadmin);
        lin_fprint = findViewById(R.id.lin_fprint);
        lin_share = findViewById(R.id.lin_share);
        lin_rate = findViewById(R.id.lin_rate);
        lin_policy = findViewById(R.id.lin_policy);

        boolean a = PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.VIBRATOR, true);
        swi_vibreator.setChecked(a);
        boolean b = PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.Intruder_selfie, true);
        swi_breck.setChecked(b);
        swi_dadmin.setChecked(policyManager.isAdminActive());

        SpinnerAdapter adapter = new SpinnerAdapter(this, R.layout.spinner_value_layout, textArray, imageArray);
        mySpinner.setAdapter(adapter);
        int index = PreferenceHelper.getIntValue(mContext, PreferenceHelper.ICON_INDEX, 0);
        mySpinner.setSelection(index);
        mySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String newPackage = disableAllNames.get(position);
                if (!newPackage.equalsIgnoreCase("") && !newPackage.equalsIgnoreCase(oldPackageName)) {
                    List<String> disableNames = new ArrayList<>(disableAllNames);
                    disableNames.remove(newPackage);
                    setAppIcon(newPackage, disableNames, position);
                    oldPackageName = newPackage;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            FingerprintManager fingerprintManager = null;
            fingerprintManager = (FingerprintManager) getSystemService(Context.FINGERPRINT_SERVICE);
            if (fingerprintManager != null) {
                if (!fingerprintManager.isHardwareDetected()) {
                    Log.e("TAG", "Init: not ok 1 ");
                    swi_fprint.setChecked(false);
                    PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.isFingerprint, false);
                    // Device doesn't support fingerprint authentication
                } else if (!fingerprintManager.hasEnrolledFingerprints()) {
                    Log.e("TAG", "Init: not ok 3 ");
                    swi_fprint.setChecked(false);
                    PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.isFingerprint, false);
                    // User hasn't enrolled any fingerprints to authenticate with
                } else {
                    // Everything is ready for fingerprint authentication
                    Log.e("TAG", "Init: ok ");
                    if (PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.isFingerprint, true))
                        swi_fprint.setChecked(true);
                    else
                        swi_fprint.setChecked(false);
                }
            } else {
                PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.isFingerprint, false);
                lin_fprint.setVisibility(View.GONE);
            }
        } else {
            PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.isFingerprint, false);
            lin_fprint.setVisibility(View.GONE);
        }

        lin_addshortcut.setOnClickListener(this);
        lin_pinchange.setOnClickListener(this);
        lin_break_alerts.setOnClickListener(this);
        lin_vibrator.setOnClickListener(this);
        lin_emailVerification.setOnClickListener(this);

        lin_antilost.setOnClickListener(this);
        lin_dadmin.setOnClickListener(this);
        lin_fprint.setOnClickListener(this);
        lin_policy.setOnClickListener(this);
        lin_share.setOnClickListener(this);
        lin_rate.setOnClickListener(this);

        swi_vibreator.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.VIBRATOR, true);
                    swi_vibreator.setChecked(true);
                } else {
                    PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.VIBRATOR, false);
                    swi_vibreator.setChecked(false);
                }
            }
        });
        swi_breck.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if (isChecked) {
                    PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.Intruder_selfie, true);
                    swi_breck.setChecked(true);
                } else {
                    PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.Intruder_selfie, false);
                    swi_breck.setChecked(false);
                }
            }
        });

        swi_dadmin.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    if (!policyManager.isAdminActive()) {
                        Intent activateDeviceAdmin = new Intent(
                                DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                        activateDeviceAdmin.putExtra(
                                DevicePolicyManager.EXTRA_DEVICE_ADMIN,
                                policyManager.getAdminComponent());
                        activateDeviceAdmin
                                .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                                        "After activating admin, you will be able to block application uninstallation.");
                        startActivityForResult(activateDeviceAdmin,
                                MyDeviceAdminPolicyManager.DPM_ACTIVATION_REQUEST_CODE);
                    }
                } else {
                    policyManager.disableAdmin();
                    swi_dadmin.setChecked(false);
                }

            }
        });
        swi_fprint.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if (isChecked) {
                    PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.isFingerprint, true);
                    swi_fprint.setChecked(true);
                } else {
                    PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.isFingerprint, false);
                    swi_fprint.setChecked(false);
                }
            }
        });

        CustomTextView cTxt_verifyOrNot = findViewById(R.id.cTxt_verifyOrNot);
        customTxt_email = findViewById(R.id.customTxt_email);
        DatabaseHelper databaseHelper = new DatabaseHelper(getApplicationContext());
        UserItem userItem = databaseHelper.getUserData();
        if (userItem.getEmail() != null) {
            customTxt_email.setText(userItem.getEmail());
            cTxt_verifyOrNot.setText("Verifyed");
            cTxt_verifyOrNot.setBackground(getResources().getDrawable(R.drawable.rounded_progress_bar_horizontal));
        } else {
            customTxt_email.setText("Security Email ");
            cTxt_verifyOrNot.setText(" ");
            cTxt_verifyOrNot.setBackground(getResources().getDrawable(R.drawable.rounded_progress_bar_horizontal));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                cTxt_verifyOrNot.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.red)));
            }
            cTxt_verifyOrNot.setPadding(2, 0, 2, 0);
            cTxt_verifyOrNot.setWidth(15);
            cTxt_verifyOrNot.setHeight(15);
        }
    }

    public void setAppIcon(String activeName, List<String> disableNames, int iconIndex) {
        new AppIconNameChanger.Builder(SettingActivity.this)
                .activeName(activeName)
                .disableNames(disableNames)
                .packageName(BuildConfig.APPLICATION_ID)
                .build()
                .setNow();
        Toast.makeText(mContext, "App icon changed successfully, please find " + textArray[iconIndex], Toast.LENGTH_LONG).show();
        PreferenceHelper.setIntValue(mContext, PreferenceHelper.ICON_INDEX, iconIndex);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_back:
                onBackPressed();
                break;
            case R.id.lin_policy:
                //InternalBrowserActivity
                startActivity(new Intent(mContext, InternalBrowserActivity.class));
                //startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.privacy_policy))));
                break;
            case R.id.lin_share:
                Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                String shareBody = "Download the File vault app from play store https://play.google.com/store/apps/details?id=" + getPackageName();
                sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, getString(R.string.app_name));
                sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
                startActivity(Intent.createChooser(sharingIntent, "Share via"));
                break;
            case R.id.lin_rate:
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getPackageName())));
                } catch (ActivityNotFoundException e) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
                }
                break;
            case R.id.lin_addshortcut:
                if (!PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.IS_ICON_CREATED, false)) {
                    addShortcut();
                    Toast.makeText(getApplicationContext(), "Add Camera successfully", Toast.LENGTH_SHORT).show();
                    PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.IS_ICON_CREATED, true);
                }
                break;
            case R.id.lin_pinchange:
                Intent intent = new Intent(mContext, PinActivity.class);
                intent.putExtra("ChangePin", true);
                startActivityForResult(intent, 205);

                break;
            case R.id.lin_vibrator:
                if (!PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.VIBRATOR, false)) {
                    PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.VIBRATOR, true);
                    swi_vibreator.setChecked(true);
                } else {
                    PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.VIBRATOR, false);
                    swi_vibreator.setChecked(false);
                }
                break;
            case R.id.lin_break_alerts:
                if (!PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.Intruder_selfie, false)) {
                    PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.Intruder_selfie, true);
                    swi_breck.setChecked(true);
                } else {
                    PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.Intruder_selfie, false);
                    swi_breck.setChecked(false);
                }
                break;

            case R.id.lin_antilost:
                dialogAntiLost();
                break;
            case R.id.lin_dadmin:
                if (!policyManager.isAdminActive()) {
                    Intent activateDeviceAdmin = new Intent(
                            DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                    activateDeviceAdmin.putExtra(
                            DevicePolicyManager.EXTRA_DEVICE_ADMIN,
                            policyManager.getAdminComponent());
                    activateDeviceAdmin
                            .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                                    "After activating admin, you will be able to block application uninstallation.");
                    startActivityForResult(activateDeviceAdmin,
                            MyDeviceAdminPolicyManager.DPM_ACTIVATION_REQUEST_CODE);
                } else {
                    policyManager.disableAdmin();
                    swi_dadmin.setChecked(false);
                }
                break;
            case R.id.lin_fprint:
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                    FingerprintManager fingerprintManager = null;
                    fingerprintManager = (FingerprintManager) getSystemService(Context.FINGERPRINT_SERVICE);
                    if (!fingerprintManager.isHardwareDetected()) {
                        if (PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.isFingerprint, true))
                            swi_fprint.setChecked(false);
                        else
                            swi_fprint.setChecked(true);

                        PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.isFingerprint, swi_fprint.isChecked());
                    } else if (!fingerprintManager.hasEnrolledFingerprints()) {
                        Log.e("TAG", "Init: not ok 3 ");
                        Toast.makeText(getApplicationContext(), "Please add your fingerprint lock from device setting", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(android.provider.Settings.ACTION_SECURITY_SETTINGS));
                    } else {
                        if (PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.isFingerprint, true))
                            swi_fprint.setChecked(false);
                        else
                            swi_fprint.setChecked(true);

                        PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.isFingerprint, swi_fprint.isChecked());
                    }

                } else {
                    lin_fprint.setVisibility(View.GONE);
                    PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.isFingerprint, false);
                }
                break;
            case R.id.lin_emailVerification:
                /*Intent intent1 = new Intent(mContext, EmailVerifiyActivity.class);
//                intent1.putExtra("pin", pinNo);
                intent1.putExtra("QType", "Set");
                intent1.putExtra("Activity", "SettingActivity");
                startActivityForResult(intent1, 202);*/
                googleLogIn();
                break;
            default:
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        if (resultCode == Activity.RESULT_OK && requestCode == MyDeviceAdminPolicyManager.DPM_ACTIVATION_REQUEST_CODE) {
            swi_dadmin.setChecked(true);
            // handle code for successfull enable of admin
        } else if (requestCode == REQUEST_ACCOUNT_PICKER) {
            if (resultCode == RESULT_OK && data != null && data.getExtras() != null) {
                String accountName = data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME);
                PreferenceHelper.setValue(mContext, PreferenceHelper.AccountName, accountName);
                if (accountName != null) {
                    credential.setSelectedAccountName(accountName);
                    DatabaseHelper databaseHelper = new DatabaseHelper(getApplicationContext());
                    databaseHelper.updateUserEmail(accountName);
                    customTxt_email.setText(databaseHelper.getUserData().getEmail());
                    Toast.makeText(mContext, "Change email successfully..!", Toast.LENGTH_SHORT).show();
                }
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private void dialogAntiLost() {
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this, R.style.BottomSheetDialogTheme);
        View dialogView = View.inflate(this, R.layout.layout_anti_dialog, null);
        MaterialButton button_negative = dialogView.findViewById(R.id.button_negative);
        MaterialButton button_positive = dialogView.findViewById(R.id.button_positive);
        TextView title = dialogView.findViewById(R.id.textView_title);
        title.setText("File Anti-Lost Notes");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            button_negative.setIcon(getDrawable(R.drawable.ic_close_black_24dp));
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            button_positive.setIcon(getDrawable(R.drawable.ic_backup_black_24dp));
        }
        button_negative.setText("Cancel");
        button_positive.setText("Backup");
        button_negative.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetDialog.dismiss();
            }
        });

        button_positive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(mContext, CloudBackupActivity.class), 120);
                bottomSheetDialog.dismiss();
            }
        });
        bottomSheetDialog.setContentView(dialogView);
        bottomSheetDialog.show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home: {
                onBackPressed();
                return true;
            }
            default: {
                return false;
            }
        }
    }

    private void addShortcut() {
        Intent shortcutIntent1 = new Intent(getApplicationContext(), CameraShortcutActivity.class);
        shortcutIntent1.setAction(Intent.ACTION_MAIN);
        shortcutIntent1.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N_MR1) {
            ShortcutInfo shortcut = null;
            ShortcutManager shortcutManager = getSystemService(ShortcutManager.class);
            shortcut = new ShortcutInfo.Builder(mContext, "id1")
                    .setShortLabel("Camara")
                    .setLongLabel("Open Camera")
                    .setIcon(Icon.createWithResource(mContext, R.drawable.ic_shortcut))
                    .setIntent(shortcutIntent1)
                    .build();
            shortcutManager.setDynamicShortcuts(Arrays.asList(shortcut));
        } else {
            Intent addIntent = new Intent();
            addIntent.putExtra(Intent.EXTRA_SHORTCUT_INTENT, shortcutIntent1);
            addIntent.putExtra(Intent.EXTRA_SHORTCUT_NAME, "Camera");
            addIntent.putExtra(Intent.EXTRA_SHORTCUT_ICON_RESOURCE, Intent.ShortcutIconResource.fromContext(getApplicationContext(), R.drawable.ic_shortcut));
            addIntent.setAction("com.android.launcher.action.INSTALL_SHORTCUT");
            addIntent.putExtra("duplicate", false);  //may it's already there so don't duplicate
            getApplicationContext().sendBroadcast(addIntent);
        }
    }

    public boolean isValidEmail(CharSequence target) {
        return (!TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches());
    }

    private void googleLogIn() {
        if (Connectivity.isConnectedFast(mContext)) {
            credential = GoogleAccountCredential.usingOAuth2(this, Arrays.asList(DriveScopes.DRIVE_FILE));
            String accountName = PreferenceHelper.getValue(mContext, PreferenceHelper.AccountName, "");
            if (accountName.length() > 0) {
                Log.e(TAG, "ac name accountName " + accountName);
                if (isValidEmail(accountName)) {
                    credential.setSelectedAccountName(accountName);
                    pickAccount();
                } else {
                    pickAccount();
                }
            } else {
                pickAccount();
            }
        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle(getString(R.string.internet_title));
            builder.setMessage(getString(R.string.internet_message));
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Toast.makeText(getApplicationContext(), "Please start internet and restart app.", Toast.LENGTH_LONG).show();
//                    finish();
                }
            });
            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
//                    finish();
                }
            });
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }
    }

    private void pickAccount() {
        startActivityForResult(credential.newChooseAccountIntent(), REQUEST_ACCOUNT_PICKER);
    }

}
