package com.secretvault.file.privary;


import androidx.core.content.FileProvider;

/**
 * Used to give other apps access to sdcard content when files are tapped in the list view, see manifest file.
 */
public class GenericFileProvider extends FileProvider {

}
