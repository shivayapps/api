package com.secretvault.file.privary.activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.ActionMode;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.secretvault.file.privary.R;
import com.secretvault.file.privary.adapters.OnItemClickListner;
import com.secretvault.file.privary.model.IntruderSelfieModel;
import com.secretvault.file.privary.utils.ItemOffsetDecoration;
import com.secretvault.file.privary.utils.Utils;
import com.secretvault.file.privary.views.CustomTextView;
import com.shreyaspatil.MaterialDialog.BottomSheetMaterialDialog;

import org.apache.commons.io.comparator.LastModifiedFileComparator;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class IntruderActivity extends AppCompatActivity implements OnItemClickListner {
    public ActionBar actionBar;
    RecyclerView recyclerview;
    GridLayoutManager gridLayoutManager;
    IntruderListAdapter imageGalleryAdapter;
    ArrayList<IntruderSelfieModel> arrayList = new ArrayList<>();
    LinearLayout noItemFound;
    boolean isSelectedMode = false;
    Context mContext;
    private ActionMode actionMode;
    private int countSelected;
    private ActionMode.Callback callback = new ActionMode.Callback() {
        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            MenuInflater menuInflater = mode.getMenuInflater();
            menuInflater.inflate(R.menu.menu_unhide, menu);
            MenuItem action_unhide = menu.findItem(R.id.action_unhide);
            action_unhide.setVisible(false);
            actionMode = mode;
            countSelected = 0;
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            int i = item.getItemId();
            if (i == R.id.action_unhide) {
//                unHideFile();
                return true;
            } else if (i == R.id.action_delete) {
                DeletePhoto(IntruderActivity.this);
                return true;
            }
            return false;
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {
            if (countSelected > 0) {
                deselectAll();
            }
            actionMode = null;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intruder_selfie);

        mContext = IntruderActivity.this;
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        actionBar = getSupportActionBar();

        if (actionBar != null) {
            CustomTextView tv_tital = findViewById(R.id.tv_tital);
            tv_tital.setText(R.string.tital_intruder_selfie);
            ImageView iv_back = findViewById(R.id.iv_back);
            iv_back.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onBackPressed();
                }
            });
            findViewById(R.id.iv_option).setVisibility(View.GONE);

            //actionBar.setDisplayHomeAsUpEnabled(true);
            //actionBar.setHomeAsUpIndicator(R.drawable.ic_arrow_back);
            //actionBar.setDisplayShowTitleEnabled(true);
            //actionBar.setTitle(R.string.tital_intruder_selfie);
        }

        Init();
    }

    public void Init() {
        noItemFound = findViewById(R.id.lin_noItemFound);
        recyclerview = findViewById(R.id.recyclerview_mywork);
        gridLayoutManager = new GridLayoutManager(this, 2);
        recyclerview.setLayoutManager(gridLayoutManager);
        ItemOffsetDecoration itemDecoration = new ItemOffsetDecoration(mContext, R.dimen.item_space);
        recyclerview.addItemDecoration(itemDecoration);
        getImageData();
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        Log.e("UCSafe", "IntruderActivity:onUserLeaveHint");
    }

    @Override
    public void onUserInteraction() {
        super.onUserInteraction();
        Log.e("UCSafe", "IntruderActivity:onUserInteraction");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("UCSafe", "IntruderActivity:onResume");
    }
    @Override
    protected void onPause() {
        super.onPause();
        Log.e("UCSafe", "IntruderActivity:onPause");
    }
    @Override
    protected void onStop() {
        super.onStop();
        Log.e("UCSafe", "IntruderActivity:onStop");
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
        Log.e("UCSafe", "IntruderActivity:onKeyDown:"+keyCode);
        if(keyCode == KeyEvent.KEYCODE_HOME)
        {
            Log.e("UCSafe", "IntruderActivity:Home button pressed!");
        }
        return super.onKeyDown(keyCode, event);
    }
    public void getImageData() {
        arrayList = new ArrayList<IntruderSelfieModel>();// list of file paths
        File[] listFile;
        File file = new File(Utils.worngPwd);
        if (file.isDirectory()) {
            listFile = file.listFiles();

            Arrays.sort(listFile, LastModifiedFileComparator.LASTMODIFIED_COMPARATOR);
            for (int i = 0; i < listFile.length; i++) {
                arrayList.add(new IntruderSelfieModel(false, listFile[i].getAbsolutePath()));
            }
        }

        if (arrayList.size() == 0) {
            noItemFound.setVisibility(View.VISIBLE);
        } else {
            Collections.reverse(arrayList);

            imageGalleryAdapter = new IntruderListAdapter(IntruderActivity.this, arrayList);
            imageGalleryAdapter.setItemClickEvent(this);

            recyclerview.setAdapter(imageGalleryAdapter);
        }
    }

    @Override
    public void onItemClick(int position) {

        if (isSelectedMode) {
            if (actionMode == null) {
                actionMode = startActionMode(callback);
            }
            toggleSelection(position);
            actionMode.setTitle(countSelected + " " + getString(R.string.selected));
            if (countSelected == 0) {
                actionMode.finish();
                isSelectedMode = false;
            }
        } else {
            Intent intent = new Intent(mContext, IntruderFullViewActivity.class);
            intent.putExtra("postion", position);
            intent.putExtra("photoItems", arrayList);
            startActivity(intent);
        }

    }

    @Override
    public void onItemLongClick(int position) {
        isSelectedMode = true;
        if (actionMode == null) {
            actionMode = startActionMode(callback);
        }
        toggleSelection(position);
        actionMode.setTitle(countSelected + " " + getString(R.string.selected));
        if (countSelected == 0) {
            actionMode.finish();
            isSelectedMode = false;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home: {
                onBackPressed();
                return true;
            }
            default: {
                return false;
            }
        }
    }

    private void toggleSelection(int position) {
        arrayList.get(position).checked = !arrayList.get(position).isChecked();
        if (arrayList.get(position).checked) {
            countSelected++;
        } else {
            countSelected--;
        }
        imageGalleryAdapter.notifyDataSetChanged();
    }

    public void DeletePhoto(final Activity act) {
        BottomSheetMaterialDialog mBottomSheetDialog = new BottomSheetMaterialDialog.Builder(IntruderActivity.this)
                .setTitle("Delete permanetly ?")
                .setMessage("Are you sure want to delete selected file permanetly ?")
                .setCancelable(false)
                .setPositiveButton("Delete", R.drawable.ic_delete_black, new BottomSheetMaterialDialog.OnClickListener() {
                    @Override
                    public void onClick(com.shreyaspatil.MaterialDialog.interfaces.DialogInterface dialogInterface, int which) {
                        new DeleteImageTask().execute();
                        dialogInterface.dismiss();

                    }

                })
                .setNegativeButton("Cancel", R.drawable.ic_close_black_24dp, new BottomSheetMaterialDialog.OnClickListener() {
                    @Override
                    public void onClick(com.shreyaspatil.MaterialDialog.interfaces.DialogInterface dialogInterface, int which) {
                        dialogInterface.dismiss();
                    }

                })
                .build();
        mBottomSheetDialog.show();
    }


    private void deselectAll() {
        for (int i = 0, l = arrayList.size(); i < l; i++) {
            arrayList.get(i).checked = false;
        }
        isSelectedMode = false;

        countSelected = 0;
        imageGalleryAdapter.notifyDataSetChanged();
    }

    private ArrayList<IntruderSelfieModel> getSelected() {
        ArrayList<IntruderSelfieModel> selectedImages = new ArrayList<>();
        for (int i = 0, l = arrayList.size(); i < l; i++) {
            if (arrayList.get(i).checked) {
                selectedImages.add(arrayList.get(i));
            }
        }
        return selectedImages;
    }


    public class DeleteImageTask extends AsyncTask<String, Integer, String> {
        ProgressDialog pd;

        public DeleteImageTask() {
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(IntruderActivity.this);
            pd.setTitle("Delete to intruder selfie");
            pd.setMessage("Please wait....");
            pd.setCancelable(false);
            pd.setIndeterminate(true);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            ArrayList<IntruderSelfieModel> selected = getSelected();
            for (int i = 0; i < selected.size(); i++) {

                File file = new File(selected.get(i).path);
                if (file.exists())
                    file.delete();

            }
            return "null";
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            imageGalleryAdapter.notifyDataSetChanged();
            Toast.makeText(mContext, "Delete intruder selfie successfully", Toast.LENGTH_SHORT).show();
            if (actionMode != null)
                actionMode.finish();
            countSelected = 0;

            Init();
        }
    }


    public class IntruderListAdapter extends RecyclerView.Adapter<IntruderListAdapter.ViewHolder> {
        public OnItemClickListner onItemClickListner;
        Context mContext;
        int mImageResize;
//        private ArrayList<IntruderSelfieModel> mediaFiles = new ArrayList<>();

        public IntruderListAdapter(Context mcContext, ArrayList<IntruderSelfieModel> mediaFiles) {
//            this.mediaFiles = mediaFiles;
            this.mContext = mcContext;
        }

        public void setItemClickEvent(OnItemClickListner onItemClickListner) {
            this.onItemClickListner = onItemClickListner;
        }

        public void setImageResize(int imageSize) {
            this.mImageResize = imageSize;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_mycollageimage, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull final ViewHolder holder, final int position) {
            File mediaFile = new File(arrayList.get(position).path);
            if (mediaFile.exists()) {
                RequestOptions options = new RequestOptions()
                        .centerCrop()
                        .override(mImageResize, mImageResize)
                        .placeholder(R.drawable.ic_placeholder);

                String parth = mediaFile.getAbsolutePath();
                File targetLocation = new File(parth);
                holder.gallery_image.setVisibility(View.VISIBLE);
                Glide.with(mContext)
                        .load(Uri.fromFile(targetLocation))
                        .apply(options)
                        .into(holder.gallery_image);


//                holder.frm_chek.getLayoutParams().height = mImageResize;
//                holder.frm_chek.getLayoutParams().width = mImageResize;
//                holder.frm_chek.requestLayout();
                if (arrayList.get(position).checked) {
                    holder.frm_chek.setVisibility(View.VISIBLE);
                } else {
                    holder.frm_chek.setVisibility(View.GONE);
                }

                holder.frm_chek.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (onItemClickListner != null) {
                            onItemClickListner.onItemClick(position);
                        }
                    }
                });
                holder.frm_root.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (onItemClickListner != null) {
                            onItemClickListner.onItemClick(position);
                        }
                    }
                });
                holder.frm_chek.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        if (onItemClickListner != null) {
                            onItemClickListner.onItemLongClick(position);
                        }
                        return false;
                    }
                });
                holder.frm_root.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        if (onItemClickListner != null) {
                            onItemClickListner.onItemLongClick(position);
                        }
                        return false;
                    }
                });

            }
        }


        @Override
        public int getItemCount() {
            return arrayList.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            FrameLayout frm_root, frm_chek;
            private ImageView gallery_image;

            ViewHolder(View view) {
                super(view);
                gallery_image = view.findViewById(R.id.gallery_image);
                frm_root = view.findViewById(R.id.frm_root);
                frm_chek = view.findViewById(R.id.frm_chek);
            }
        }
    }

}
