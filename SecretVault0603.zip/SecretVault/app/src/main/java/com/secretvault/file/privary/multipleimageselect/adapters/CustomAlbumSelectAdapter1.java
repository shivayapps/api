package com.secretvault.file.privary.multipleimageselect.adapters;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.secretvault.file.privary.R;
import com.secretvault.file.privary.views.CustomTextView;
import com.jiajunhui.xapp.medialoader.bean.VideoFolder;

import java.util.ArrayList;


public class CustomAlbumSelectAdapter1 extends CustomGenericAdapter<VideoFolder> {
    public CustomAlbumSelectAdapter1(Context context, ArrayList<VideoFolder> albums) {
        super(context, albums);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;

        if (convertView == null) {
            convertView = layoutInflater.inflate(R.layout.grid_view_item_album_select, null);

            viewHolder = new ViewHolder();
            viewHolder.imageView =  convertView.findViewById(R.id.image_view_album_image);
            viewHolder.textView =  convertView.findViewById(R.id.text_view_album_name);

            convertView.setTag(viewHolder);

        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        viewHolder.imageView.getLayoutParams().width = size;
        viewHolder.imageView.getLayoutParams().height = size;

        viewHolder.textView.setText(arrayList.get(position).getName());
        Glide.with(context)
                .load(arrayList.get(position).getItems().get(0).getPath())
                .placeholder(R.drawable.image_placeholder).centerCrop().into(viewHolder.imageView);

        return convertView;
    }

    private static class ViewHolder {
        public ImageView imageView;
        public CustomTextView textView;
    }
}
