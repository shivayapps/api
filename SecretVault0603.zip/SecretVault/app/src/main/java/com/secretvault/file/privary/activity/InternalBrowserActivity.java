package com.secretvault.file.privary.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.secretvault.file.privary.R;
import com.secretvault.file.privary.multipleimageselect.Image;
import com.secretvault.file.privary.utils.Utils;

public class InternalBrowserActivity extends AppCompatActivity {

    WebView browser;
    ImageView ic_back;
    TextView header_txt,tv_try_again;
    ProgressBar pbar;
    RelativeLayout lay_noInternet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_internal_browser);

        findViewById(R.id.iv_option).setVisibility(View.GONE);

        pbar=findViewById(R.id.pbar);
        tv_try_again=findViewById(R.id.tv_try_again);
        lay_noInternet=findViewById(R.id.lay_noInternet);
        browser=findViewById(R.id.browser);
        header_txt = (TextView) findViewById(R.id.tv_tital);
        header_txt.setText("Privacy Policy");
        ic_back=findViewById(R.id.iv_back);

        if (Utils.isNetworkAvailable(InternalBrowserActivity.this)) {
            lay_noInternet.setVisibility(View.GONE);
        }else {
            lay_noInternet.setVisibility(View.VISIBLE);
        }

        ic_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        tv_try_again.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Utils.isNetworkAvailable(InternalBrowserActivity.this)) {
                    onResume();
                }else {
                    lay_noInternet.setVisibility(View.GONE);

                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            lay_noInternet.setVisibility(View.VISIBLE);
                        }
                    }, 200);
                }

            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (Utils.isNetworkAvailable(InternalBrowserActivity.this)) {
            browser.setWebViewClient(new WebViewClient() {
                @Override
                public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    view.loadUrl(url);
                    return false;
                }

                @Override
                public void onPageStarted(WebView view, String url, Bitmap favicon) {
                    super.onPageStarted(view, url, favicon);
                    pbar.setVisibility(View.VISIBLE);
                    lay_noInternet.setVisibility(View.GONE);
                }

                public void onLoadResource (WebView view, String url) {
                }

                @Override
                public void onPageFinished(WebView view, String url) {
                    pbar.setVisibility(View.GONE);
                }

                @Override
                public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                    super.onReceivedError(view, request, error);
                    lay_noInternet.setVisibility(View.VISIBLE);
                }
            });
            browser.getSettings().setJavaScriptEnabled(true);
            browser.getSettings().setLoadsImagesAutomatically(true);
            browser.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
            browser.scrollTo(0,0);
            browser.loadUrl(getString(R.string.privacy_policy));
        }else
            lay_noInternet.setVisibility(View.VISIBLE);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}