package com.secretvault.file.privary.ads;

public interface AdEventListener {

    void onAdLoaded();

    void onAdClosed();

    void onLoadError(String errorCode);
}
