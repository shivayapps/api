package com.secretvault.file.privary.multipleimageselect.activities;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Process;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.widget.Toolbar;

import com.secretvault.file.privary.R;
import com.secretvault.file.privary.multipleimageselect.Constants;
import com.secretvault.file.privary.multipleimageselect.adapters.CustomAlbumSelectAdapter;
import com.secretvault.file.privary.multipleimageselect.adapters.CustomAlbumSelectAdapter1;
import com.secretvault.file.privary.views.CustomTextView;
import com.jiajunhui.xapp.medialoader.MediaLoader;
import com.jiajunhui.xapp.medialoader.bean.PhotoFolder;
import com.jiajunhui.xapp.medialoader.bean.PhotoResult;
import com.jiajunhui.xapp.medialoader.bean.VideoFolder;
import com.jiajunhui.xapp.medialoader.bean.VideoResult;
import com.jiajunhui.xapp.medialoader.callback.OnPhotoLoaderCallBack;
import com.jiajunhui.xapp.medialoader.callback.OnVideoLoaderCallBack;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


public class AlbumSelectActivity extends HelperActivity {
    int selectType = 0;
    private ArrayList<PhotoFolder> photoFolders = new ArrayList<>();
    private ArrayList<VideoFolder> videoFolders = new ArrayList<>();
    private TextView errorDisplay;
    private ProgressBar progressBar;
    private GridView gridView;
    private CustomAlbumSelectAdapter imageAdapter;
    private CustomAlbumSelectAdapter1 videoAdapter;
    private ActionBar actionBar;
    private ContentObserver observer;
    private Handler handler;
    private Thread thread;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_album_select);
        setView(findViewById(R.id.layout_album_select));

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ImageView iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        findViewById(R.id.iv_option).setVisibility(View.GONE);

        Intent intent = getIntent();
        if (intent == null) {
            finish();
        }
        Constants.limit = intent.getIntExtra(Constants.INTENT_EXTRA_LIMIT, Constants.DEFAULT_LIMIT);
        selectType = intent.getIntExtra(Constants.INTENT_EXTRA_SELECT_TYPE, 1);

        actionBar = getSupportActionBar();
        if (actionBar != null) {
            /*
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_arrow_back);
            actionBar.setDisplayShowTitleEnabled(true);
            */
            CustomTextView tv_tital = findViewById(R.id.tv_tital);
            if (selectType == 1)
                tv_tital.setText(R.string.album_view);
            else
                tv_tital.setText(R.string.album_videos);


        }


        errorDisplay = findViewById(R.id.text_view_error);
        errorDisplay.setVisibility(View.INVISIBLE);

        progressBar = findViewById(R.id.progress_bar_album_select);
        gridView = findViewById(R.id.grid_view_album_select);
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (selectType == 1) {
                    Intent intent = new Intent(getApplicationContext(), ImageSelectActivity.class);
                    intent.putExtra(Constants.INTENT_EXTRA_SELECT_TYPE, 1);
                    intent.putExtra(Constants.INTENT_EXTRA_ALBUM, photoFolders.get(position).getName());
                    intent.putExtra("ListData", (Serializable) photoFolders.get(position).getItems());
                    startActivityForResult(intent, Constants.REQUEST_CODE_IMAGE);
                } else {
                    Intent intent = new Intent(getApplicationContext(), ImageSelectActivity.class);
                    intent.putExtra(Constants.INTENT_EXTRA_SELECT_TYPE, 2);
                    intent.putExtra(Constants.INTENT_EXTRA_ALBUM, videoFolders.get(position).getName());
                    intent.putExtra("ListData", (Serializable) videoFolders.get(position).getItems());
                    startActivityForResult(intent, Constants.REQUEST_CODE_VIDEO);
                }
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case Constants.PERMISSION_GRANTED: {
                        loadAlbums();
                        break;
                    }
                    case Constants.FETCH_STARTED: {
                        progressBar.setVisibility(View.VISIBLE);
                        gridView.setVisibility(View.INVISIBLE);
                        break;
                    }
                    case Constants.FETCH_COMPLETED: {
                        if (selectType == 1) {
                            if (imageAdapter == null) {
                                imageAdapter = new CustomAlbumSelectAdapter(getApplicationContext(), photoFolders);
                                gridView.setAdapter(imageAdapter);

                                progressBar.setVisibility(View.INVISIBLE);
                                gridView.setVisibility(View.VISIBLE);
                                orientationBasedUI(getResources().getConfiguration().orientation);
                            } else {
                                imageAdapter.notifyDataSetChanged();
                            }
                        } else {
                            if (videoAdapter == null) {
                                videoAdapter = new CustomAlbumSelectAdapter1(getApplicationContext(), videoFolders);
                                gridView.setAdapter(videoAdapter);

                                progressBar.setVisibility(View.INVISIBLE);
                                gridView.setVisibility(View.VISIBLE);
                                orientationBasedUI(getResources().getConfiguration().orientation);
                            } else {
                                videoAdapter.notifyDataSetChanged();
                            }
                        }
                        break;
                    }

                    case Constants.ERROR: {
                        progressBar.setVisibility(View.INVISIBLE);
                        errorDisplay.setVisibility(View.VISIBLE);
                        break;
                    }

                    default: {
                        super.handleMessage(msg);
                    }
                }
            }
        };
        observer = new ContentObserver(handler) {
            @Override
            public void onChange(boolean selfChange, Uri uri) {
                loadAlbums();
            }
        };
        getContentResolver().registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, false, observer);
        checkPermission();
    }

    @Override
    protected void onStop() {
        super.onStop();
        stopThread();
        getContentResolver().unregisterContentObserver(observer);
        observer = null;
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
            handler = null;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (actionBar != null) {
            actionBar.setHomeAsUpIndicator(null);
        }
        photoFolders = null;
        photoFolders = null;
        if (selectType == 1) {
            if (imageAdapter != null) {
                imageAdapter.releaseResources();
            }
        } else {
            if (videoAdapter != null) {
                videoAdapter.releaseResources();
            }
        }
        gridView.setOnItemClickListener(null);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        orientationBasedUI(newConfig.orientation);
    }

    private void orientationBasedUI(int orientation) {
        final WindowManager windowManager = (WindowManager) getApplicationContext().getSystemService(Context.WINDOW_SERVICE);
        final DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        if (selectType == 1) {
            if (imageAdapter != null) {
                int size = orientation == Configuration.ORIENTATION_PORTRAIT ? metrics.widthPixels / 2 : metrics.widthPixels / 4;
                imageAdapter.setLayoutParams(size);
            }
        } else {
            if (videoAdapter != null) {
                int size = orientation == Configuration.ORIENTATION_PORTRAIT ? metrics.widthPixels / 2 : metrics.widthPixels / 4;
                videoAdapter.setLayoutParams(size);
            }
        }
        gridView.setNumColumns(orientation == Configuration.ORIENTATION_PORTRAIT ? 2 : 4);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        setResult(RESULT_CANCELED);
        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constants.REQUEST_CODE_IMAGE
                && resultCode == RESULT_OK
                && data != null) {
            setResult(RESULT_OK, data);
            finish();
        } else if (requestCode == Constants.REQUEST_CODE_VIDEO
                && resultCode == RESULT_OK
                && data != null) {
            setResult(RESULT_OK, data);
            finish();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home: {
                onBackPressed();
                return true;
            }
            default: {
                return false;
            }
        }
    }

    private void loadAlbums() {
        startThread(new AlbumLoaderRunnable());
    }

    private void startThread(Runnable runnable) {
        stopThread();
        thread = new Thread(runnable);
        thread.start();
    }

    private void stopThread() {
        if (thread == null || !thread.isAlive()) {
            return;
        }
        thread.interrupt();
        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void sendMessage(int what) {
        if (handler == null) {
            return;
        }

        Message message = handler.obtainMessage();
        message.what = what;
        message.sendToTarget();
    }

    @Override
    protected void permissionGranted() {
        Message message = handler.obtainMessage();
        message.what = Constants.PERMISSION_GRANTED;
        message.sendToTarget();
    }

    @Override
    protected void hideViews() {
        progressBar.setVisibility(View.INVISIBLE);
        gridView.setVisibility(View.INVISIBLE);
    }

    private class AlbumLoaderRunnable implements Runnable {
        @Override
        public void run() {
            android.os.Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);
            if (selectType == 1) {
                if (imageAdapter == null) {
                    sendMessage(Constants.FETCH_STARTED);
                }

                photoFolders = new ArrayList<>();
                MediaLoader.getLoader().loadPhotos(AlbumSelectActivity.this, new OnPhotoLoaderCallBack() {
                    @Override
                    public void onResult(PhotoResult result) {
                        List<PhotoFolder> daata = result.getFolders();
                        for (int i = 0; i < daata.size(); i++) {
                            if (daata.get(i).getItems().size() > 0)
                                photoFolders.add(daata.get(i));
                        }
                        sendMessage(Constants.FETCH_COMPLETED);

                    }
                });
            } else if (selectType == 2) {
                videoFolders = new ArrayList<>();
                MediaLoader.getLoader().loadVideos(AlbumSelectActivity.this, new OnVideoLoaderCallBack() {
                    @Override
                    public void onResult(VideoResult result) {
                        List<VideoFolder> daata = result.getFolders();
                        videoFolders.addAll(daata);
                        Log.e("TAG", "onResult: " + result.getFolders().size());
                        for (int i = 0; i < daata.size(); i++) {
                            Log.e("TAG", "onResult:== " + daata.get(i).getName() + " == " + daata.get(i).getItems().size());
                        }
                        sendMessage(Constants.FETCH_COMPLETED);
                    }
                });

            }
        }
    }
}
