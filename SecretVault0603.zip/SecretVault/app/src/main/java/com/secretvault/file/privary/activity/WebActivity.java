package com.secretvault.file.privary.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.secretvault.file.privary.R;
import com.secretvault.file.privary.db.DatabaseHelper;
import com.secretvault.file.privary.utils.Utils;
import com.secretvault.file.privary.views.NestedWebView;

public class WebActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String HTTP = "http://";
    private static final String HTTPS = "https://";
    Context mContext;
    NestedWebView webView;
    ProgressBar progressBar;
    TextView tv_tital;
    EditText actvSearch;
    LinearLayout lin_tital, lin_etital;
    ImageView icClose2, ivSearch, ivClear;
    ImageView iv_bookmark, ic_backward,iv_home;
    CardView card_tital;
    boolean isOpened = false;
    DatabaseHelper databaseHelper;
    private static final String MOBILE_USER_AGENT = "Mozilla/5.0 (Linux; U; Android 4.4; en-us; Nexus 4 Build/JOP24G) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30";



    ImageView ic_goforward;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web);
        mContext = WebActivity.this;
        databaseHelper = new DatabaseHelper(mContext);
        Init();
    }

    private void Init() {
        lin_tital = findViewById(R.id.lin_tital);
        card_tital = findViewById(R.id.card_tital);
        lin_etital = findViewById(R.id.lin_etital);
//        lin_bgview = findViewById(R.id.lin_bgview);
        tv_tital = findViewById(R.id.tv_tital);
        actvSearch = findViewById(R.id.actvSearch);
        icClose2 = findViewById(R.id.icClose2);
        ivSearch = findViewById(R.id.ivSearch);
        ivClear = findViewById(R.id.ivClear);
        iv_bookmark = findViewById(R.id.iv_bookmark);
        ic_goforward = findViewById(R.id.ic_goforward);
        ic_backward = findViewById(R.id.ic_backward);
        iv_home = findViewById(R.id.iv_home);
        webView = findViewById(R.id.webview);

        progressBar = findViewById(R.id.pbLoader);
        lin_tital.setOnClickListener(this);

        actvSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                icClose2.setVisibility(View.VISIBLE);

            }
        });
        actvSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                String query = actvSearch.getText().toString().trim();
                Log.e("TAG", "onEditorAction:acti   onId " + actionId);
                if (actionId == EditorInfo.IME_ACTION_GO) {
                    Log.e("TAG", "onEditorAction: Go ");
                    goSearch();
                }

                return true;
            }
        });
        actvSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (actvSearch.getText().length() == 0) {
                    icClose2.setVisibility(View.VISIBLE);
                    ivClear.setVisibility(View.GONE);
                    ivSearch.setVisibility(View.GONE);
                } else if (actvSearch.getText().length() > 0) {
                    ivClear.setVisibility(View.VISIBLE);
                    ivSearch.setVisibility(View.VISIBLE);
                    icClose2.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        lin_tital.setOnClickListener(this);
        card_tital.setOnClickListener(this);
        tv_tital.setOnClickListener(this);
        icClose2.setOnClickListener(this);
        ivSearch.setOnClickListener(this);
        ivClear.setOnClickListener(this);
        iv_bookmark.setOnClickListener(this);
        ic_backward.setOnClickListener(this);
        iv_home.setOnClickListener(this);
        ic_goforward.setOnClickListener(this);
        setListnerToRootView();
        initWeb();
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        Log.e("UCSafe", "WebActivity:onUserLeaveHint");
    }

    @Override
    public void onUserInteraction() {
        super.onUserInteraction();
        Log.e("UCSafe", "WebActivity:onUserInteraction");
    }
    @Override
    protected void onStop() {
        super.onStop();
        Log.e("UCSafe", "WebActivity:onStop");
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
        Log.e("UCSafe", "WebActivity:onKeyDown:"+keyCode);
        if(keyCode == KeyEvent.KEYCODE_HOME)
        {
            Log.e("UCSafe", "WebActivity:Home button pressed!");
        }
        return super.onKeyDown(keyCode, event);
    }

    private void initWeb() {
        webView.setWebViewClient(new MkWebViewClient());
        webView.setWebChromeClient(new MkWebChromeClient());

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
//        settings.setUserAgentString(settings.getUserAgentString() + " mkBrowser/" + getVerName(mContext));
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setAllowFileAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setDefaultTextEncodingName("utf-8");
        settings.setDomStorageEnabled(true);
        settings.setUserAgentString(MOBILE_USER_AGENT);
        settings.setPluginState(WebSettings.PluginState.ON);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        String Query = getIntent().getStringExtra("Query");
        if (Utils.isNetworkAvailable(mContext))
            webView.loadUrl(Query);

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.card_tital:
            case R.id.lin_tital:
            case R.id.tv_tital:
                lin_etital.setVisibility(View.VISIBLE);
//                lin_bgview.setVisibility(View.VISIBLE);
                break;
            case R.id.ivClear:
                actvSearch.setText("");
                break;
            case R.id.icClose2:
//                lin_bgview.setVisibility(View.GONE);
                lin_tital.setVisibility(View.VISIBLE);
                lin_etital.setVisibility(View.GONE);
                break;
            case R.id.ivSearch:
                goSearch();
                break;
            case R.id.iv_bookmark:

                databaseHelper = new DatabaseHelper(mContext);
                if (databaseHelper.isExist(webView.getUrl().trim())) {
                    Toast.makeText(this, "Entry already exist in bookmarks.", Toast.LENGTH_SHORT).show();
                } else {
                    databaseHelper.addBookmark(webView.getTitle(), webView.getUrl().trim(), "encrypted_userName", "encrypted_userPW", "01");
                    Toast.makeText(this, R.string.lable_bookmark_saved, Toast.LENGTH_SHORT).show();
                    iv_bookmark.setImageResource(R.drawable.ic_bookmark_black_24dp);
                }
                databaseHelper.close();

                break;
            case R.id.ic_backward:
                webView.goBack();
                break;
            case R.id.ic_goforward:
                webView.goForward();
                break;
            case R.id.iv_home:
                finish();
                break;
        }
    }

    public void goSearch() {

        if (actvSearch.getText().length() > 0) {
            if (Utils.isNetworkAvailable(mContext)) {
                webView.loadUrl("https://www.google.com/search?q=" + actvSearch.getText().toString());
                lin_tital.setVisibility(View.VISIBLE);
                lin_etital.setVisibility(View.GONE);
//                lin_bgview.setVisibility(View.GONE);
            }
        }
    }


    public void setListnerToRootView() {
        final View activityRootView = getWindow().getDecorView().findViewById(android.R.id.content);
        activityRootView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {

                int heightDiff = activityRootView.getRootView().getHeight() - activityRootView.getHeight();
                if (heightDiff > 100) { // 99% of the time the height diff will be due to a keyboard.
//                    lin_bgview.setVisibility(View.VISIBLE);
                    lin_etital.setVisibility(View.VISIBLE);
                    if (isOpened == false) {
                    }
                    isOpened = true;
                } else if (isOpened == true) {
//                    lin_bgview.setVisibility(View.GONE);
                    lin_etital.setVisibility(View.GONE);
                    isOpened = false;
                }
            }
        });

    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();

        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.e("UCSafe", "WebActivity:onPause");
        try {
            webView.getClass().getMethod("onPause").invoke(webView);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("UCSafe", "WebActivity:onResume");
        try {
            webView.getClass().getMethod("onResume").invoke(webView);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private class MkWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            if (url == null) {
                return true;
            }
            if (url.startsWith(HTTP) || url.startsWith(HTTPS)) {
                if (Utils.isNetworkAvailable(mContext)) {
                    view.loadUrl(url);
                }
                return true;
            }
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
                return true;
            } catch (Exception e) {
                return true;
            }
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
            progressBar.setProgress(0);
            progressBar.setVisibility(View.VISIBLE);
            tv_tital.setText("Loading...");
            //            webIcon.setImageResource(R.drawable.internet);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            progressBar.setVisibility(View.GONE);
            setTitle(webView.getTitle());
            tv_tital.setText(webView.getTitle());
            lin_etital.setVisibility(View.GONE);
            lin_tital.setVisibility(View.VISIBLE);
            actvSearch.setText(url);
            databaseHelper = new DatabaseHelper(mContext);
            if (databaseHelper.isExist(webView.getUrl().trim())) {
                iv_bookmark.setImageResource(R.drawable.ic_bookmark_black_24dp);
            } else {
                iv_bookmark.setImageResource(R.drawable.ic_bookmark_border_black_24dp);
            }
            databaseHelper.close();
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            super.onReceivedError(view, request, error);
            Log.e("TAG", "onReceivedError: " + error + " >>> " + request);
        }
    }

    private class MkWebChromeClient extends WebChromeClient {
        private final static int WEB_PROGRESS_MAX = 100;

        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            super.onProgressChanged(view, newProgress);
            progressBar.setProgress(newProgress);
            if (newProgress > 0) {
                if (newProgress == WEB_PROGRESS_MAX) {
                    progressBar.setVisibility(View.GONE);
                } else {
                    progressBar.setVisibility(View.VISIBLE);
                }
            }
        }

        @Override
        public void onReceivedIcon(WebView view, Bitmap icon) {
            super.onReceivedIcon(view, icon);
//            webIcon.setImageBitmap(icon);
        }

        @Override
        public void onReceivedTitle(WebView view, String title) {
            super.onReceivedTitle(view, title);
            setTitle(title);
            tv_tital.setText(title);
        }
    }

}
