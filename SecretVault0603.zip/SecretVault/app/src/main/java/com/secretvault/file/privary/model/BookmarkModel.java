package com.secretvault.file.privary.model;

public class BookmarkModel {

    String pass_id;
    String pass_title;
    String pass_content;
    String pass_icon;
    String pass_attachment;
    String pass_creation;

    public String getPass_id() {
        return pass_id;
    }

    public void setPass_id(String pass_id) {
        this.pass_id = pass_id;
    }

    public String getPass_title() {
        return pass_title;
    }

    public void setPass_title(String pass_title) {
        this.pass_title = pass_title;
    }

    public String getPass_content() {
        return pass_content;
    }

    public void setPass_content(String pass_content) {
        this.pass_content = pass_content;
    }

    public String getPass_icon() {
        return pass_icon;
    }

    public void setPass_icon(String pass_icon) {
        this.pass_icon = pass_icon;
    }

    public String getPass_attachment() {
        return pass_attachment;
    }

    public void setPass_attachment(String pass_attachment) {
        this.pass_attachment = pass_attachment;
    }

    public String getPass_creation() {
        return pass_creation;
    }

    public void setPass_creation(String pass_creation) {
        this.pass_creation = pass_creation;
    }


    public static final String TABLE_BOOKMARKS_PASS = "BOOKMARKS_PASS";
    public static final String COLUMN_PASS_ID = "_id";
    public static final String COLUMN_PASS_TITLE = "TITLE";
    public static final String COLUMN_PASS_CONTENT = "CONTENT";
    public static final String COLUMN_PASS_ICON = "ICON";
    public static final String COLUMN_PASS_ATTACH = "ATTACHMENT";
    public static final String COLUMN_PASS_CREATION = "CREATION";


    public static final String CREATE_PASS_BOOKMARK = "CREATE TABLE "
            + TABLE_BOOKMARKS_PASS
            + " ("
            + " " + COLUMN_PASS_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + " " + COLUMN_PASS_TITLE + " TEXT,"
            + " " + COLUMN_PASS_CONTENT + " TEXT UNIQUE,"
            + " " + COLUMN_PASS_ICON + " TEXT,"
            + " " + COLUMN_PASS_ATTACH + " TEXT,"
            + " " + COLUMN_PASS_CREATION + " TEXT"
            + ")";

}
