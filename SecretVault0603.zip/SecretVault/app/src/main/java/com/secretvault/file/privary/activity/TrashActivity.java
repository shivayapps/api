package com.secretvault.file.privary.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

import com.secretvault.file.privary.R;
import com.secretvault.file.privary.fragments.TrashFileVaultFragment;
import com.secretvault.file.privary.fragments.TrashPhotoVaultFragment;
import com.secretvault.file.privary.fragments.TrashVideoVaultFragment;

public class TrashActivity extends AppCompatActivity {

    String Type = "trashphotos";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trash);
        Type = getIntent().getStringExtra("Type");

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ImageView iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        findViewById(R.id.iv_option).setVisibility(View.GONE);

        Init();

    }

    public void Init() {
        Fragment androidFragment = new TrashPhotoVaultFragment();
        if (Type.equalsIgnoreCase("trashphotos")) {
            androidFragment = new TrashPhotoVaultFragment();
            currentFragment = "TrashPhotoVaultFragment";
        } else if (Type.equalsIgnoreCase("trashvideos")) {
            androidFragment = new TrashVideoVaultFragment();
            currentFragment = "VideoVaultFragment";
        } else if (Type.equalsIgnoreCase("trashfiles")) {
            androidFragment = new TrashFileVaultFragment();
            currentFragment = "FilesVaultFragment";
        }
        replaceFragment(androidFragment);
    }

    String currentFragment = "";
    FragmentManager fragmentManager;

    public void replaceFragment(Fragment destFragment) {
        fragmentManager = this.getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.dynamic_fragment_frame_layout, destFragment);
        fragmentTransaction.commit();
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        Log.e("UCSafe", "TrashActivity:onUserLeaveHint");
    }

    @Override
    public void onUserInteraction() {
        super.onUserInteraction();
        Log.e("UCSafe", "TrashActivity:onUserInteraction");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("UCSafe", "TrashActivity:onResume");
    }
    @Override
    protected void onPause() {
        super.onPause();
        Log.e("UCSafe", "TrashActivity:onPause");
    }
    @Override
    protected void onStop() {
        super.onStop();
        Log.e("UCSafe", "TrashActivity:onStop");
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
        Log.e("UCSafe", "TrashActivity:onKeyDown:"+keyCode);
        if(keyCode == KeyEvent.KEYCODE_HOME)
        {
            Log.e("UCSafe", "TrashActivity:Home button pressed!");
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home: {
                onBackPressed();
                return true;
            }
            default: {
                return false;
            }
        }
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_OK);
        switch (currentFragment) {
            case "TrashPhotoVaultFragment":
                Log.e("TAG", "onBackPressed:PhotoVaultFragment ");
                setResult(RESULT_OK);
                finish();
                return;
            case "VideoVaultFragment":
                Log.e("TAG", "onBackPressed:VideoVaultFragment ");
                setResult(RESULT_OK);
                finish();
                return;
            case "FilesVaultFragment":
                Log.e("TAG", "onBackPressed:VideoVaultFragment ");
                setResult(RESULT_OK);
                finish();
                return;
            default:
                break;
        }
    }
}
