package com.secretvault.file.privary.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.util.Log;

import com.secretvault.file.privary.model.AppDataModel;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.LinkedHashMap;


public class PreferenceHelper {


    public static final String pref_pin_lenth = "pin_lenth";
    public static final String pref_pin = "pin";
    public static final String VIBRATOR = "VIBRATOR";
    public static final String Intruder_selfie = "Intruder_selfie";
    public static final String isRatting = "isRatting";

    public static String PREF_NAME = "vault";
    public static SharedPreferences AppPreference;
    public static String isFirstTime = "isFirstTime";
    public static String AccountName = "AccountName";

    public static String prf_chk_photos_bk = "prf_chk_photos_bk";
    public static String prf_chk_videos_bk = "prf_chk_videos_bk";
    public static String prf_chk_files_bk = "prf_chk_files_bk";
    public static String prf_chk_donot_bk = "prf_chk_donot_bk";

    public static String prf_chk_photos_rs = "prf_chk_photos_rs";
    public static String prf_chk_videos_rs = "prf_chk_videos_rs";
    public static String prf_chk_files_rs = "prf_chk_files_rs";
    public static String prf_chk_donot_rs = "prf_chk_donot_rs";
    public static String ICON_INDEX = "ICON_INDEX";
    public static String IS_ICON_CREATED = "IS_ICON_CREATED";
    public static final String isFingerprint = "isFingerprint";

    public static String getValue(Context context, String key, String defaultValue) {
        AppPreference = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String str = AppPreference.getString(key, defaultValue);
        return str;
    }

    public static void setValue(Context context, String key, String value) {
        AppPreference = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        Editor editor = AppPreference.edit();
        editor.putString(key, value);
        editor.commit();
    }

    public static int getIntValue(Context context, String key, int defaultValue) {
        AppPreference = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);

        int str = AppPreference.getInt(key, defaultValue);
        return str;
    }

    public static void setIntValue(Context context, String key, int value) {
        AppPreference = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        Editor editor = AppPreference.edit();
        editor.putInt(key, value);
        editor.commit();
    }

    public static boolean getBooleanValue(Context context, String key, boolean defaultValue) {
        AppPreference = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);

        boolean str = AppPreference.getBoolean(key, defaultValue);
        return str;
    }

    public static void setBooleanValue(Context context, String key, boolean value) {
        AppPreference = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        Editor editor = AppPreference.edit();
        editor.putBoolean(key, value);
        editor.commit();
    }


    public static long getLongValue(Context context, String key, long defaultValue) {
        AppPreference = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);

        long str = AppPreference.getLong(key, defaultValue);
        return str;
    }

    public static void setLongValue(Context context, String key, long value) {
        AppPreference = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        Editor editor = AppPreference.edit();
        editor.putLong(key, value);
        editor.commit();
    }

    public static boolean contains(Context context, String key) {
        AppPreference = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return AppPreference.contains(key);
    }

    public static void clearPreference(Context context) {
        AppPreference = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        AppPreference.edit().clear().commit();
    }

    public static void saveToUserDefaults(Context context, String key,
                                          String value) {

        Log.d("Utils", "Saving:" + key + ":" + value);
        SharedPreferences preferences = context.getSharedPreferences(
                PREF_NAME, Context.MODE_PRIVATE);
        Editor editor = preferences.edit();
        editor.putString(key, value);
        editor.commit();

    }

    public static String getFromUserDefaults(Context context, String key) {
        Log.d("Utils", "Get:" + key);
        SharedPreferences preferences = context.getSharedPreferences(
                PREF_NAME, Context.MODE_PRIVATE);
        return preferences.getString(key, "");
    }
    public static final String pref_AppData = "pref_AppData";
    public static LinkedHashMap<String, AppDataModel> getAppDataMap(Context context) {
        String jsonStroing = getFromUserDefaults(context, pref_AppData);
        Gson gson = new Gson();
        Type type = new TypeToken<LinkedHashMap<String, AppDataModel>>() {}.getType();
        LinkedHashMap<String, AppDataModel> fromJson = gson.fromJson(jsonStroing, type);
        return fromJson;
    }
    public static ArrayList<AppDataModel> getAppData(Context context) {
        ArrayList<AppDataModel> appDataModels = new ArrayList<>();
        String jsonStroing = getFromUserDefaults(context, pref_AppData);
        Gson gson = new Gson();
        Type type = new TypeToken<LinkedHashMap<String, AppDataModel>>() {
        }.getType();
        if (!jsonStroing.isEmpty()) {
            LinkedHashMap<String, AppDataModel> fromJson = gson.fromJson(jsonStroing, type);

            if (fromJson.size() > 0) {
                appDataModels = new ArrayList<>(fromJson.values());
            }
        }
        return appDataModels;
    }


    public static void saveAppData(Context context, LinkedHashMap<String, AppDataModel> hMap) {
        Gson gson = new Gson();
        Type type = new TypeToken<LinkedHashMap<String, AppDataModel>>() {
        }.getType();
        String json = gson.toJson(hMap, type);
        saveToUserDefaults(context, pref_AppData, json);
        System.out.println(json);
        Log.e("JSON", " >>> " + json);

    }
}
