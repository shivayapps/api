package com.secretvault.file.privary.activity;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.secretvault.file.privary.R;
import com.secretvault.file.privary.db.DatabaseHelper;
import com.secretvault.file.privary.db.UserItem;
import com.secretvault.file.privary.utils.Connectivity;
import com.secretvault.file.privary.utils.CryptLib;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.DataAsyncHttpResponseHandler;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

import javax.crypto.NoSuchPaddingException;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.ByteArrayEntity;

public class ResetPinByEmail extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = "ResetPinByEmail";
    EditText edit_SecurityCode;
    LinearLayout linear_nextBtn, linear_securityQueBtn;
    int con = 0;
    int sendFailedCon = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_pin_by_email);

        init();
    }

    private String createPassCode(int len) {
        // A strong password has Cap_chars, Lower_chars,
        // numeric value and symbols. So we are using all of
        // them to generate our password
        String Capital_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String Small_chars = "abcdefghijklmnopqrstuvwxyz";
        String numbers = "0123456789";
//        String symbols = "!@#$%^&*_=+-/.?<>)";


        String values = Capital_chars + Small_chars +
                numbers /*+ symbols*/;

        // Using random method
        Random rndm_method = new Random();

        char[] password = new char[len];

        for (int i = 0; i < len; i++) {
            // Use of charAt() method : to get character value
            // Use of nextInt() as it is scanning the value as int
            password[i] = values.charAt(rndm_method.nextInt(values.length()));
        }
        return String.valueOf(password);
    }

    private void sendMail() {
        DatabaseHelper databaseHelper = new DatabaseHelper(getApplicationContext());
        UserItem userItem = databaseHelper.getUserData();
        if (userItem != null) {
            if (userItem.getEmail() != null) {
                if (userItem.getForgotPin() != null) {
                    if (Connectivity.isConnectedFast(getApplicationContext())) {
                        String appName = getResources().getString(R.string.app_name);
                        String email = userItem.getEmail();
                        String passcode = userItem.getForgotPin();

                        AsyncHttpClient client = new AsyncHttpClient();

                        JSONObject jsonObject = new JSONObject();
                        try {
                            jsonObject.put("app_name", appName);
                            jsonObject.put("email", email);
                            jsonObject.put("passcode", passcode);

                            Log.e(TAG, "appName: " + appName);
                            Log.e(TAG, "email: " + email);
                            Log.e(TAG, "passcode: " + passcode);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        String key = "v1TIfn4PSbHae2Ng";
                        String cipherText = null;
                        try {
                            CryptLib cryptLib = new CryptLib();
                            cipherText = cryptLib.encryptPlainTextWithRandomIV(jsonObject.toString(), key);
                        } catch (NoSuchAlgorithmException e) {
                            e.printStackTrace();
                        } catch (NoSuchPaddingException e) {
                            e.printStackTrace();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        ByteArrayEntity be = new ByteArrayEntity(cipherText.getBytes());

                        client.post(getApplicationContext(), "http://jkrdevelopers.com/vaghani/email_v2/api/forgot_password", be, "text/plain", new DataAsyncHttpResponseHandler() {
                            @Override
                            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                                try {
                                    String str = new String(responseBody);
                                    CryptLib cryptLib = new CryptLib();
                                    String decryptedString = cryptLib.decryptCipherTextWithRandomIV(str, key);
                                    JSONObject jsonObject1 = new JSONObject(decryptedString);

                                    Log.e(TAG, "onSuccess: " + jsonObject1.get("ResponseCode") + " ====> " + jsonObject1.get("ResponseMsg"));
                                    if (jsonObject1.get("ResponseCode").equals(0)) {
                                        sendFailedCon++;
                                        if (sendFailedCon >= 2) {
                                            onBackPressed();
//                                            Toast.makeText(ResetPinByEmail.this, "Server Down, Please again after one hour.", Toast.LENGTH_SHORT).show();
                                            Toast.makeText(ResetPinByEmail.this, "Service Temporarily Unavailable, Please Retry after one hours.", Toast.LENGTH_SHORT).show();
                                        } else {
                                            sendMail();
                                        }
                                    }
                                } catch (UnsupportedEncodingException e) {
                                    Log.e(TAG, "UnsupportedEncodingException: " + e.getMessage());
                                    e.printStackTrace();
                                } catch (NoSuchPaddingException e) {
                                    Log.e(TAG, "NoSuchPaddingException: " + e.getMessage());
                                    e.printStackTrace();
                                } catch (NoSuchAlgorithmException e) {
                                    Log.e(TAG, "NoSuchAlgorithmException: " + e.getMessage());
                                    e.printStackTrace();
                                } catch (Exception e) {
                                    Log.e(TAG, "Exception: " + e.getMessage());
                                    e.printStackTrace();
                                }
                            }

                            @Override
                            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                                Log.e(TAG, "onFailure: " + statusCode);
                                Log.e(TAG, "onFailure: " + error.getMessage());
                            }
                        });
                    } else {
                        AlertDialog.Builder builder = new AlertDialog.Builder(this);
                        builder.setTitle(getString(R.string.internet_title));
                        builder.setMessage(getString(R.string.internet_message));
                        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(getApplicationContext(), "Please start internet and restart app.", Toast.LENGTH_LONG).show();
                                finish();
                            }
                        });
                        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        });
                        AlertDialog alertDialog = builder.create();
                        alertDialog.show();
                    }
                } else {
                    String passcode = createPassCode(6);
                    databaseHelper.updateUserForgotPin(passcode);
                    sendMail();
                }
            }
        }
    }

    private void init() {
        ImageView img_back = findViewById(R.id.img_back);
        img_back.setOnClickListener(this);

        TextView txt_email = findViewById(R.id.txt_email);
        DatabaseHelper databaseHelper = new DatabaseHelper(getApplicationContext());
        UserItem userItem = databaseHelper.getUser(1);
        String email = userItem.getEmail();

        email = email.replaceAll("(\\w{1,2})(\\w+)(\\w{1})(@.*)", "$1****$3$4");
        txt_email.setText(getResources().getString(R.string.emailText, email));

        edit_SecurityCode = findViewById(R.id.edit_SecurityCode);
        linear_nextBtn = findViewById(R.id.linear_nextBtn);
        linear_nextBtn.setOnClickListener(this);
        linear_securityQueBtn = findViewById(R.id.linear_securityQueBtn);
        linear_securityQueBtn.setOnClickListener(this);
        linear_securityQueBtn.setVisibility(View.GONE);

        String passcode = createPassCode(6);
        if (passcode != null) {
            databaseHelper.updateUserForgotPin(passcode);
            sendMail();
        } else {
            init();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.img_back:
                onBackPressed();
                break;
            case R.id.linear_nextBtn:
                InputMethodManager imm = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(v.getWindowToken(), 0);

                DatabaseHelper databaseHelper = new DatabaseHelper(getApplicationContext());
                UserItem userItem = databaseHelper.getUserData();
                if (userItem.getForgotPin().contentEquals(edit_SecurityCode.getText())) {
                    databaseHelper.updatePIN("");
                    Intent intent = new Intent(getApplicationContext(), PinActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    con++;
                    if (con >= 2) {
                        linear_securityQueBtn.setVisibility(View.VISIBLE);
                        final Animation myAnim = AnimationUtils.loadAnimation(this, R.anim.shake);
                        linear_securityQueBtn.startAnimation(myAnim);
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                myAnim.cancel();
                            }
                        }, 1000);
                    }
                    Toast.makeText(this, "Wrong Security Code, please try again.", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.linear_securityQueBtn:
                onBackPressed();
                break;
        }
    }
}