package com.secretvault.file.privary.db;

public class UserItem {

    public static final String TABLE_NAME = "tabUser";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_PWD = "passwrod";
    public static final String COLUMN_SQUESTION = "squestion";
    public static final String COLUMN_ANSWER = "answer";
    public static final String COLUMN_EMAIL = "email";
    public static final String COLUMN_FORGOT_PIN = "forgot_pin";

    // Create table SQL query
    public static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_PWD + " TEXT,"
                    + COLUMN_SQUESTION + " TEXT,"
                    + COLUMN_ANSWER + " TEXT,"
                    + COLUMN_EMAIL + " TEXT,"
                    + COLUMN_FORGOT_PIN + " TEXT"
                    + ")";


    public static final String ADDCOLUMN1 = "ALTER TABLE " + UserItem.TABLE_NAME + " ADD COLUMN " + UserItem.COLUMN_EMAIL + " TEXT";
    public static final String ADDCOLUMN2 = "ALTER TABLE " + UserItem.TABLE_NAME + " ADD COLUMN " + UserItem.COLUMN_FORGOT_PIN + " TEXT";

    public int id;
    public String pwd;
    public String squestion;
    public String answer;
    public String email;
    public String forgotPin;

    public UserItem() {

    }

    public UserItem(int id, String pwd, String squestion, String answer, String email, String forgotPin) {
        this.id = id;
        this.pwd = pwd;
        this.squestion = squestion;
        this.answer = answer;
        this.email = email;
        this.forgotPin = forgotPin;
    }

    public UserItem(int id, String pwd, String squestion, String answer) {
        this.id = id;
        this.pwd = pwd;
        this.squestion = squestion;
        this.answer = answer;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getSquestion() {
        return squestion;
    }

    public void setSquestion(String squestion) {
        this.squestion = squestion;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getForgotPin() {
        return forgotPin;
    }

    public void setForgotPin(String forgotPin) {
        this.forgotPin = forgotPin;
    }

    @Override
    public String toString() {
        return "UserItem{" +
                "id=" + id +
                ", pwd='" + pwd + '\'' +
                ", squestion='" + squestion + '\'' +
                ", answer='" + answer + '\'' +
                ", email='" + email + '\'' +
                ", forgotPin='" + forgotPin + '\'' +
                '}';
    }
}
