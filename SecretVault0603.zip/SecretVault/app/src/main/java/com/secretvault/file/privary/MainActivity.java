package com.secretvault.file.privary;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.secretvault.file.privary.db.DatabaseHelper;
import com.secretvault.file.privary.fragments.FilesVaultFragment;
import com.secretvault.file.privary.fragments.PhotoVaultFragment;
import com.secretvault.file.privary.fragments.VideoVaultFragment;
import com.secretvault.file.privary.utils.Utils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public static final int REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS = 124;
    DatabaseHelper db;
    String Type = "photos";
    String currentFragment = "";
    FragmentManager fragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Type = getIntent().getStringExtra("Type");

        toolbar = findViewById(R.id.toolbar);

        if (checkPermission()) {
            Init();
        } else {
            Get_CameraAndStorage_Permission();
        }
        setToolbarData(true);
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        Log.e("UCSafe", "MainActivity:onUserLeaveHint");
    }

    @Override
    public void onUserInteraction() {
        super.onUserInteraction();
        Log.e("UCSafe", "MainActivity:onUserInteraction");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("UCSafe", "MainActivity:onResume");
    }
    @Override
    protected void onPause() {
        super.onPause();
        Log.e("UCSafe", "MainActivity:onPause");
    }
    @Override
    protected void onStop() {
        super.onStop();
        Log.e("UCSafe", "MainActivity:onStop");
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
        Log.e("UCSafe", "MainActivity:onKeyDown:"+keyCode);
        if(keyCode == KeyEvent.KEYCODE_HOME)
        {
            Log.e("UCSafe", "MainActivity:Home button pressed!");
        }
        return super.onKeyDown(keyCode, event);
    }

    public void Init() {
        createImageDir();
        db = new DatabaseHelper(this);
        Fragment androidFragment = new VideoVaultFragment();
        if (Type.equalsIgnoreCase("Photos")) {
            androidFragment = new PhotoVaultFragment();
            currentFragment = "PhotoVaultFragment";
        } else if (Type.equalsIgnoreCase("Videos")) {
            androidFragment = new VideoVaultFragment();
            currentFragment = "VideoVaultFragment";
        } else if (Type.equalsIgnoreCase("Files")) {
            androidFragment = new FilesVaultFragment();
            currentFragment = "FilesVaultFragment";
        }
        replaceFragment(androidFragment);
    }

    public void replaceFragment(Fragment destFragment) {
        fragmentManager = this.getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.dynamic_fragment_frame_layout, destFragment);
        fragmentTransaction.commit();

    }

    public boolean checkPermission() {
        List<String> permissionsNeeded = new ArrayList<String>();
        final List<String> permissionsList = new ArrayList<String>();
        if (!addPermission(permissionsList, Manifest.permission.WRITE_EXTERNAL_STORAGE))
            permissionsNeeded.add("write storage");
        if (!addPermission(permissionsList, Manifest.permission.READ_EXTERNAL_STORAGE))
            permissionsNeeded.add("Read storage");
        if (!addPermission(permissionsList, Manifest.permission.CAMERA))
            permissionsNeeded.add("Cmera");
        return permissionsList.size() == 0;
    }

    private void Get_CameraAndStorage_Permission() {
        List<String> permissionsNeeded = new ArrayList<String>();
        final List<String> permissionsList = new ArrayList<String>();
        if (!addPermission(permissionsList, Manifest.permission.WRITE_EXTERNAL_STORAGE))
            permissionsNeeded.add("Write storage");
        if (!addPermission(permissionsList, Manifest.permission.READ_EXTERNAL_STORAGE))
            permissionsNeeded.add("Read storage");
        if (!addPermission(permissionsList, Manifest.permission.CAMERA))
            permissionsNeeded.add("Camera");

        if (permissionsList.size() > 0) {
            if (permissionsNeeded.size() > 0) {
                for (int i = 0; i < 1; i++)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionsList.toArray(new String[permissionsList.size()]), REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
                    }
                return;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(permissionsList.toArray(new String[permissionsList.size()]), REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
            }
            return;
        }
    }

    private boolean addPermission(List<String> permissionsList, String permission) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsList.add(permission);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    return shouldShowRequestPermissionRationale(permission);
                }
            }
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length > 0) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (requestCode == REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS) {
                    Init();
                }
            }
        }
    }

    public void createImageDir() {
        File myDirectory = new File(Utils.hideImage);
        if (!myDirectory.exists()) {
            myDirectory.mkdirs();
            Log.e("TAG", "createImageDir: mkdir");
        } else {
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home: {
                onBackPressed();
                return true;
            }
            default: {
                return false;
            }
        }
    }

    Toolbar toolbar;

    public void setToolbarData(boolean isBack) {
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_OK);
        switch (currentFragment) {
            case "PhotoVaultFragment":
                Log.e("TAG", "onBackPressed:PhotoVaultFragment ");
                setResult(RESULT_OK);
                finish();
                return;
            case "VideoVaultFragment":
                Log.e("TAG", "onBackPressed:VideoVaultFragment ");
                setResult(RESULT_OK);
                finish();
                return;
            case "FilesVaultFragment":
                Log.e("TAG", "onBackPressed:VideoVaultFragment ");
                setResult(RESULT_OK);
                finish();
                return;
            default:
                break;
        }
    }

}
