package com.secretvault.file.privary.adapters;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.secretvault.file.privary.R;
import com.secretvault.file.privary.model.AppDataModel;
import com.secretvault.file.privary.utils.PreferenceHelper;

import java.util.ArrayList;
import java.util.LinkedHashMap;

public class AppAdapter extends RecyclerView.Adapter<AppAdapter.ViewHolder> {

    public static boolean isLongPress = false;
    Activity act;
    ArrayList<AppDataModel> arrAppList;
    View.OnClickListener onClick;
    View.OnLongClickListener longlistener;

    public AppAdapter(Activity activity, ArrayList<AppDataModel> arrayList, View.OnClickListener listener, View.OnLongClickListener longlistener) {
        this.act = activity;
        this.arrAppList = arrayList;
        this.onClick = listener;
        this.longlistener = longlistener;
        isLongPress = false;
    }

    public void removeLast() {
        if (isLongPress) {
            arrAppList.remove(arrAppList.size() - 1);
            notifyDataSetChanged();
        }
    }

    public void addLast() {
        if (!isLongPress) {
            arrAppList.add(arrAppList.size(), new AppDataModel("ic_plus", "", "Add"));
            notifyDataSetChanged();
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View v = LayoutInflater.from(act).inflate(R.layout.layout_app_item, viewGroup, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AppDataModel data = arrAppList.get(position);

        holder.ivAppIcon.setImageResource(getResourseId(act,data.getImage()));
        holder.tvAppTitle.setText(data.getTitle());

        holder.lin_approot.setTag(position);
        holder.lin_approot.setOnClickListener(onClick);
        holder.lin_approot.setOnLongClickListener(longlistener);

//        holder.tvAppTitle.setTextColor(Util.getThemeColor(act, R.attr.textColor1));


        if (isLongPress) {
            Animation shake = AnimationUtils.loadAnimation(act, R.anim.shake);
            holder.lin_approot.setAnimation(shake);
            holder.iv_delete.setVisibility(View.VISIBLE);
        } else {
            holder.iv_delete.setVisibility(View.GONE);
        }

        holder.iv_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                LinkedHashMap<String, AppDataModel> dataMap = PreferenceHelper.getAppDataMap(act);
                Log.e("TAG", "onClick: " + arrAppList.get(position).getUrl() );
                if (dataMap.containsKey(arrAppList.get(position).getUrl())) {

                    dataMap.remove(arrAppList.get(position).getUrl());
                    PreferenceHelper.saveAppData(act, dataMap);
                    arrAppList.remove(arrAppList.get(position));
                    Log.e("TAG", "onClick:== " + dataMap.size() );
                    notifyDataSetChanged();
                }else {
                    Log.e("TAG", "onClick:== >>>>>>" );
                }
            }
        });
    }



    @Override
    public int getItemCount() {
        return arrAppList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivAppIcon;
        ImageView iv_delete;
        TextView tvAppTitle;
        LinearLayout lin_approot;
//        CardView cvApp;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivAppIcon = itemView.findViewById(R.id.ivAppIcon);
            iv_delete = itemView.findViewById(R.id.iv_delete);
            tvAppTitle = itemView.findViewById(R.id.tvAppTitle);
            lin_approot = itemView.findViewById(R.id.lin_approot);
        }
    }

    public static int getResourseId(Context context, String pVariableName) throws RuntimeException {
        try {
            return context.getResources().getIdentifier(pVariableName,  "drawable", context.getPackageName());
        } catch (Exception e) {
            throw new RuntimeException("Error getting Resource ID.", e);
        }
    }

}
