package com.secretvault.file.privary.utils;

import android.app.Activity;
import android.app.Application;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.core.app.ActivityCompat;

import com.secretvault.file.privary.activity.PinActivity;

public class MyLifecycleHandler implements Application.ActivityLifecycleCallbacks {

    private int resumed;
    private int paused;
    private int started;
    private int stopped;
    private boolean isFromBackground=false;

    public void startHome(Activity activity) {

        //Log.e("UCSafe", "getLocalClassName:"+activity.getLocalClassName());
        Intent intent=new Intent(activity, PinActivity.class);
        intent.putExtra("isFromBackground",true);
        //intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        //intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        //intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        ActivityCompat.startActivity(activity,intent,null);
        activity.startActivity(intent);
    }

    @Override
    public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
        //Log.e("UCSafe", "Application:onActivityCreated");
    }

    @Override
    public void onActivityDestroyed(Activity activity) {
        //Log.e("UCSafe", "Application:onActivityDestroyed");
    }

    @Override
    public void onActivityResumed(Activity activity) {
        //Log.e("UCSafe", "onActivityResumed:getLocalClassName:"+activity.getLocalClassName());
        ++resumed;

        if(!activity.getLocalClassName().equalsIgnoreCase("activity.ResetPinByEmail") || !activity.getLocalClassName().equalsIgnoreCase("activity.PinActivity")) {
            isFromBackground=false;
        }
        if(isFromBackground) {
            isFromBackground=false;
            startHome(activity);
            //if(!activity.getLocalClassName().equalsIgnoreCase("activity.ResetPinByEmail") || !activity.getLocalClassName().equalsIgnoreCase("activity.PinActivity")) { }
        }
        //Log.e("UCSafe", "Application:onActivityResumed: resumed:"+resumed+" paused :"+paused);
    }

    @Override
    public void onActivityPaused(Activity activity) {
        ++paused;
        //Log.e("UCSafe", "Application:onActivityPaused: resumed:"+resumed+" paused :"+paused);
        //android.util.Log.w("test", "application is in foreground: " + (resumed > paused));
        if(resumed<paused) {
            isFromBackground=true;
            //System.exit(0);
            //ActivityCompat.finishAffinity(activity);
            //activity.finish();
        } else {
            isFromBackground=false;
        }
    }

    @Override
    public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
        //Log.e("UCSafe", "Application:onActivitySaveInstanceState");
    }

    @Override
    public void onActivityStarted(Activity activity) {
        ++started;
    }

    @Override
    public void onActivityStopped(Activity activity) {
        ++stopped;
        if(started==stopped) {
            //activity.finish();
            isFromBackground=true;
        } else {
            isFromBackground=false;
        }
        //android.util.Log.e("UCSafe", "Application:onActivityStopped: stopped:"+stopped+" started :"+started);
        //android.util.Log.e("UCSafe", "application is visible: " + (started > stopped));
    }

}