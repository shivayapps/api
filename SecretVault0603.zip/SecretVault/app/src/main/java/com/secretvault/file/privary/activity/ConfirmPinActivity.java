package com.secretvault.file.privary.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.secretvault.file.privary.R;
import com.secretvault.file.privary.db.DatabaseHelper;
import com.secretvault.file.privary.utils.PreferenceHelper;

public class ConfirmPinActivity extends AppCompatActivity implements View.OnClickListener {
    TextView tv_1, tv_2, tv_3, tv_4, tv_5, tv_6, tv_7, tv_8, tv_9, tv_0;
    TextView tv_pinhint;
    ImageView iv_doen, iv_cam;
    String pinNo = "";
    String pin = "";
    Context mContext;
    boolean NewPin = false;
    Vibrator vibrator;
    ImageView iv_pin1, iv_pin2, iv_pin3, iv_pin4;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pin);
        mContext = ConfirmPinActivity.this;
        pin = getIntent().getStringExtra("pin");

        pinNo = "";
        Init();
    }

    private void Init() {
        if (getIntent().getExtras() != null) {
            Log.e("TAG", "Init: in not null " + NewPin);
            NewPin = getIntent().getBooleanExtra("NewPin", false);
        }
        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        Log.e("TAG", "Init: NewPin " + NewPin);
        tv_pinhint = findViewById(R.id.tv_pinhint);
        iv_pin1 = findViewById(R.id.iv_pin1);
        iv_pin2 = findViewById(R.id.iv_pin2);
        iv_pin3 = findViewById(R.id.iv_pin3);
        iv_pin4 = findViewById(R.id.iv_pin4);
        tv_1 = findViewById(R.id.tv_1);
        tv_2 = findViewById(R.id.tv_2);
        tv_3 = findViewById(R.id.tv_3);
        tv_4 = findViewById(R.id.tv_4);
        tv_5 = findViewById(R.id.tv_5);
        tv_6 = findViewById(R.id.tv_6);
        tv_7 = findViewById(R.id.tv_7);
        tv_8 = findViewById(R.id.tv_8);
        tv_9 = findViewById(R.id.tv_9);
        tv_0 = findViewById(R.id.tv_0);
        iv_doen = findViewById(R.id.iv_done);
        iv_cam = findViewById(R.id.iv_cam);
        iv_cam.setVisibility(View.INVISIBLE);
        findViewById(R.id.iv_more).setVisibility(View.INVISIBLE);
        tv_pinhint.setText("Please confirm the password");
        tv_0.setOnClickListener(this);
        tv_1.setOnClickListener(this);
        tv_2.setOnClickListener(this);
        tv_3.setOnClickListener(this);
        tv_4.setOnClickListener(this);
        tv_5.setOnClickListener(this);
        tv_6.setOnClickListener(this);
        tv_7.setOnClickListener(this);
        tv_8.setOnClickListener(this);
        tv_9.setOnClickListener(this);
        tv_0.setOnClickListener(this);

        iv_doen.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_1:
                pinNo = pinNo + "1";
                setPinText();
                break;
            case R.id.tv_2:
                pinNo = pinNo + "2";
                setPinText();
                break;
            case R.id.tv_3:
                pinNo = pinNo + "3";
                setPinText();
                break;
            case R.id.tv_4:
                pinNo = pinNo + "4";
                setPinText();
                break;
            case R.id.tv_5:
                pinNo = pinNo + "5";
                setPinText();
                break;
            case R.id.tv_6:
                pinNo = pinNo + "6";
                setPinText();
                break;
            case R.id.tv_7:
                pinNo = pinNo + "7";
                setPinText();
                break;
            case R.id.tv_8:
                pinNo = pinNo + "8";
                setPinText();
                break;
            case R.id.tv_9:
                pinNo = pinNo + "9";
                setPinText();
                break;
            case R.id.tv_0:
                pinNo = pinNo + "0";
                setPinText();
                break;
            case R.id.iv_done:
                backButtonClick();
                break;
        }
        setVibrator();
    }

    public void setVibrator() {
        if (PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.VIBRATOR, true)) {
            if (Build.VERSION.SDK_INT >= 26) {
                vibrator.vibrate(VibrationEffect.createOneShot(100, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                vibrator.vibrate(100);
            }
        }
    }

    private void donePin() {
        if (pin.equalsIgnoreCase(pinNo)) {
            if (NewPin) {
                DatabaseHelper databaseHelper = new DatabaseHelper(mContext);
                databaseHelper.updatePIN(pinNo);
                Toast.makeText(mContext, "Password Change Successfully", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(ConfirmPinActivity.this, DashboardActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i);
                setResult(RESULT_OK);
                finish();
            } else {
                Intent intent = new Intent(mContext, SequrityQuestionActivity.class);
                intent.putExtra("pin", pinNo);
                intent.putExtra("QType", "Set");
                intent.putExtra("Activity", "FirstActivity");
                startActivityForResult(intent, 202);
            }
        } else {
            pinNo = "";
            setPinText();
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.pin_not_matach), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == 202) {
                setResult(RESULT_OK);
                finish();
            }
        }
    }

    private void backButtonClick() {
        if (pinNo.length() > 0) {
            pinNo = pinNo.substring(0, pinNo.length() - 1);
            setPinText();
        } else {

        }
    }

    public void setPinText() {
        if (pinNo.length() == 1) {
            iv_pin1.setImageResource(R.drawable.icon_round1);
            iv_pin2.setImageResource(R.drawable.icon_round);
            iv_pin3.setImageResource(R.drawable.icon_round);
            iv_pin4.setImageResource(R.drawable.icon_round);
        } else if (pinNo.length() == 2) {
            iv_pin1.setImageResource(R.drawable.icon_round1);
            iv_pin2.setImageResource(R.drawable.icon_round1);
            iv_pin3.setImageResource(R.drawable.icon_round);
            iv_pin4.setImageResource(R.drawable.icon_round);
        } else if (pinNo.length() == 3) {
            iv_pin1.setImageResource(R.drawable.icon_round1);
            iv_pin2.setImageResource(R.drawable.icon_round1);
            iv_pin3.setImageResource(R.drawable.icon_round1);
            iv_pin4.setImageResource(R.drawable.icon_round);
        } else if (pinNo.length() == 4) {
            iv_pin1.setImageResource(R.drawable.icon_round1);
            iv_pin2.setImageResource(R.drawable.icon_round1);
            iv_pin3.setImageResource(R.drawable.icon_round1);
            iv_pin4.setImageResource(R.drawable.icon_round1);
            donePin();
        } else {
            pinNo = "";
            iv_pin1.setImageResource(R.drawable.icon_round);
            iv_pin2.setImageResource(R.drawable.icon_round);
            iv_pin3.setImageResource(R.drawable.icon_round);
            iv_pin4.setImageResource(R.drawable.icon_round);
        }
    }
}
