package com.secretvault.file.privary.model;

import java.io.Serializable;

public class IntruderSelfieModel  implements Serializable {
    public boolean checked;
    public String path;

    public IntruderSelfieModel(boolean checked, String path) {
        this.checked = checked;
        this.path = path;
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    @Override
    public String toString() {
        return "IntruderSelfieModel{" +
                "checked=" + checked +
                ", path='" + path + '\'' +
                '}';
    }
}
