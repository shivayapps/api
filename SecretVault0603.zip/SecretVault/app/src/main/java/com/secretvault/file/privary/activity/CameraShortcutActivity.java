package com.secretvault.file.privary.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Environment;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.secretvault.file.privary.db.DatabaseHelper;
import com.secretvault.file.privary.utils.Utils;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import static com.secretvault.file.privary.activity.PinActivity.CAMERA_PIC_REQUEST;

public class CameraShortcutActivity extends AppCompatActivity {
DatabaseHelper databaseHelper;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        databaseHelper = new DatabaseHelper(this);
        Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(cameraIntent, CAMERA_PIC_REQUEST);
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_PIC_REQUEST) {
            if (data != null) {
                Bitmap image = (Bitmap) data.getExtras().get("data");
                saveImage(databaseHelper,image);
                finish();
            }else {
                finish();
            }
        }
    }
    public static void saveImage(DatabaseHelper databaseHelper,Bitmap finalBitmap) {
        File myDir = new File(Utils.nohideImage);
        myDir.mkdirs();

        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String fname = "IMG_" + timeStamp + ".jpg.bin";
        String fname2 = "IMG_" + timeStamp + ".jpg";

        File file = new File(myDir, fname);
        if (file.exists()) file.delete();
        try {
            FileOutputStream out = new FileOutputStream(file);
            finalBitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
            out.flush();
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        File file1 = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "DCMI");
        file1.mkdirs();
        String oriPath = file1.getAbsolutePath() + "/" + fname2;

        databaseHelper.insertImage(fname2, oriPath, file.getAbsolutePath(), file.length(), "image/jpg");

    }



}
