package com.secretvault.file.privary;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.secretvault.file.privary.ads.AdmobAdManager;
import com.secretvault.file.privary.ads.AdEventListener;

public class CustomProgress {

   public static CustomProgress customProgress = null;
   private Dialog mDialog;

   public static CustomProgress getInstance() {
       if (customProgress == null) {
           customProgress = new CustomProgress();
       }
       return customProgress;
   }

   public void showProgress(Context context, String tital,String message) {
       mDialog = new Dialog(context);
       mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
       mDialog.setContentView(R.layout.prograss_bar_dialog);
       TextView tv_tital = mDialog.findViewById(R.id.tv_tital);
       TextView tv_msg = mDialog.findViewById(R.id.tv_msg);
       tv_tital.setText("" + tital);
       tv_msg.setText("" + message);
       FrameLayout addbar = mDialog.findViewById(R.id.fl_adplaceholder);

       AdmobAdManager admobAdManager = new AdmobAdManager(context);
       admobAdManager.loadNativeAd(context, context.getString(R.string.NATIVE_ID), addbar, true ,new AdEventListener() {
           @Override
           public void onAdLoaded() {
               addbar.setVisibility(View.VISIBLE);
           }

           @Override
           public void onAdClosed() {

           }

           @Override
           public void onLoadError(String errorCode) {
               addbar.setVisibility(View.GONE);
           }
       });


       // you can change or add this line according to your need
//       mProgressBar.setIndeterminate(true);
       mDialog.setCancelable(false);
       mDialog.setCanceledOnTouchOutside(false);
       mDialog.show();
   }

   public void hideProgress() {
       if (mDialog != null) {
           mDialog.dismiss();
           mDialog = null;
       }
   }

    public boolean isShowDialog() {
        if (mDialog != null) {
//            mDialog.dismiss();
           return mDialog.isShowing();
        }
        return false;
    }
}
