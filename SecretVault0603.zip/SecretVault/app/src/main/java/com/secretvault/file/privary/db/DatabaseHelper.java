package com.secretvault.file.privary.db;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.secretvault.file.privary.model.BookmarkModel;
import com.secretvault.file.privary.utils.Utils;
import com.jiajunhui.xapp.medialoader.bean.PhotoItem;
import com.jiajunhui.xapp.medialoader.bean.VideoItem;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "UcSafe.db";
    private static final int DATABASE_VERSION = 2;
    //    public static SQLiteDatabase db;
    private SQLiteDatabase database;

    public DatabaseHelper(Context context) {
//        super(context, Utils.hideImage + "/" + DATABASE_NAME, null, DATABASE_VERSION);
//        super(context, Utils.hideImage + "/" + DATABASE_NAME, null, DATABASE_VERSION);
        super(new DatabaseContext(context), DATABASE_NAME, null, DATABASE_VERSION);
    }

    public static boolean checkDataBase(Context mContext) {
        File databasePath = mContext.getDatabasePath(Utils.hideImage + "/" + DATABASE_NAME);
        return databasePath.exists();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
//        this.db = db;
        db.execSQL(PhotoItem.CREATE_TABLE);
        db.execSQL(VideoItem.CREATE_TABLE);
        db.execSQL(FileItem.CREATE_TABLE);
        db.execSQL(UserItem.CREATE_TABLE);
        db.execSQL(BookmarkModel.CREATE_PASS_BOOKMARK);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (/*oldVersion <= 2 &&*/ newVersion == 2) {
            db.execSQL(UserItem.ADDCOLUMN1);
            db.execSQL(UserItem.ADDCOLUMN2);
        } else {
            db.execSQL("DROP TABLE IF EXISTS " + PhotoItem.TABLE_NAME);
            db.execSQL("DROP TABLE IF EXISTS " + VideoItem.TABLE_NAME);
            db.execSQL("DROP TABLE IF EXISTS " + FileItem.TABLE_NAME);
            db.execSQL("DROP TABLE IF EXISTS " + UserItem.TABLE_NAME);
            db.execSQL("DROP TABLE IF EXISTS " + BookmarkModel.TABLE_BOOKMARKS_PASS);
            onCreate(db);
        }
    }

    //=================== tab user =======================
    public long insertUser(String pwd, String squestion, String answer) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserItem.COLUMN_PWD, pwd);
        values.put(UserItem.COLUMN_SQUESTION, squestion);
        values.put(UserItem.COLUMN_ANSWER, answer);
        long id = db.insert(UserItem.TABLE_NAME, null, values);
        db.close();
        return id;
    }

    public long insertUser(String pwd, String squestion, String answer, String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserItem.COLUMN_PWD, pwd);
        values.put(UserItem.COLUMN_SQUESTION, squestion);
        values.put(UserItem.COLUMN_ANSWER, answer);
        values.put(UserItem.COLUMN_EMAIL, email);
        long id = db.insert(UserItem.TABLE_NAME, null, values);
        db.close();
        return id;
    }

    public int updateUserEmail(String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserItem.COLUMN_EMAIL, email);
        return db.update(
                UserItem.TABLE_NAME,
                values,
                UserItem.COLUMN_ID + "=?",
                new String[]{String.valueOf(1)});
    }

    public UserItem getUser(long id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(UserItem.TABLE_NAME,
                new String[]{
                        UserItem.COLUMN_ID,
                        UserItem.COLUMN_PWD,
                        UserItem.COLUMN_SQUESTION,
                        UserItem.COLUMN_ANSWER,
                        UserItem.COLUMN_EMAIL,
                        UserItem.COLUMN_FORGOT_PIN
                }, UserItem.COLUMN_ID + "=?",
                new String[]{String.valueOf(id)}, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();
        UserItem note = new UserItem(0, "", "", "", "", "");
        if (cursor.getCount() > 0) {
            note = new UserItem(
                    cursor.getInt(cursor.getColumnIndex(UserItem.COLUMN_ID)),
                    cursor.getString(cursor.getColumnIndex(UserItem.COLUMN_PWD)),
                    cursor.getString(cursor.getColumnIndex(UserItem.COLUMN_SQUESTION)),
                    cursor.getString(cursor.getColumnIndex(UserItem.COLUMN_ANSWER)),
                    cursor.getString(cursor.getColumnIndex(UserItem.COLUMN_EMAIL)),
                    cursor.getString(cursor.getColumnIndex(UserItem.COLUMN_FORGOT_PIN)));
        }
        cursor.close();
        return note;
    }

    public int updatePIN(String pin) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserItem.COLUMN_PWD, pin);
        // updating row
        return db.update(UserItem.TABLE_NAME, values, UserItem.COLUMN_ID + " = ?", new String[]{String.valueOf(1)});
    }

    public UserItem getUserData() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(UserItem.TABLE_NAME,
                new String[]{
                        UserItem.COLUMN_ID,
                        UserItem.COLUMN_PWD,
                        UserItem.COLUMN_SQUESTION,
                        UserItem.COLUMN_ANSWER,
                        UserItem.COLUMN_EMAIL,
                        UserItem.COLUMN_FORGOT_PIN
                },
                null, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();
        UserItem note = new UserItem(0, "", "", "", "", "");
        if (cursor.getCount() > 0) {
            note = new UserItem(
                    cursor.getInt(cursor.getColumnIndex(UserItem.COLUMN_ID)),
                    cursor.getString(cursor.getColumnIndex(UserItem.COLUMN_PWD)),
                    cursor.getString(cursor.getColumnIndex(UserItem.COLUMN_SQUESTION)),
                    cursor.getString(cursor.getColumnIndex(UserItem.COLUMN_ANSWER)),
                    cursor.getString(cursor.getColumnIndex(UserItem.COLUMN_EMAIL)),
                    cursor.getString(cursor.getColumnIndex(UserItem.COLUMN_FORGOT_PIN)));
        }
        cursor.close();
        return note;
    }

    public int updateUserForgotPin(String forgotPin) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserItem.COLUMN_FORGOT_PIN, forgotPin);
        // updating row
        return db.update(UserItem.TABLE_NAME, values, UserItem.COLUMN_ID + " = ?", new String[]{String.valueOf(1)});
    }

    public int updateUserPinSecurityQue(String pin, String questionValue, String ans) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserItem.COLUMN_PWD, pin);
        values.put(UserItem.COLUMN_SQUESTION, questionValue);
        values.put(UserItem.COLUMN_ANSWER, ans);
        // updating row
        return db.update(UserItem.TABLE_NAME, values, UserItem.COLUMN_ID + " = ?", new String[]{String.valueOf(1)});
    }

    //============= tab Image============
    public long insertImage(String displayName, String oripath, String newpath, long size, String mimeType) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(PhotoItem.COLUMN_DNAME, displayName);
        values.put(PhotoItem.COLUMN_ORIPATH, oripath);
        values.put(PhotoItem.COLUMN_NEWPATH, newpath);
        values.put(PhotoItem.COLUMN_SIZE, size);
        values.put(PhotoItem.COLUMN_MIMETYPE, mimeType);
        values.put(PhotoItem.COLUMN_CLOUD_FILE_ID, "null1");
        values.put(PhotoItem.COLUMN_TRASH, 0);
        long id = db.insert(PhotoItem.TABLE_NAME, null, values);
        db.close();
        return id;
    }

    public PhotoItem getImages(long id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(PhotoItem.TABLE_NAME,
                new String[]{PhotoItem.COLUMN_ID, PhotoItem.COLUMN_DNAME, PhotoItem.COLUMN_ORIPATH, PhotoItem.COLUMN_NEWPATH, PhotoItem.COLUMN_SIZE, PhotoItem.COLUMN_MIMETYPE, PhotoItem.COLUMN_CLOUD_FILE_ID, PhotoItem.COLUMN_TRASH}, PhotoItem.COLUMN_ID + "=?",
                new String[]{String.valueOf(id)}, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();
        PhotoItem note = new PhotoItem(
                cursor.getInt(cursor.getColumnIndex(PhotoItem.COLUMN_ID)),
                cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_DNAME)),
                cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_ORIPATH)),
                cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_NEWPATH)),
                cursor.getLong(cursor.getColumnIndex(PhotoItem.COLUMN_SIZE)),
                cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_MIMETYPE)),
                cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_CLOUD_FILE_ID)),
                cursor.getInt(cursor.getColumnIndex(PhotoItem.COLUMN_TRASH)));
        cursor.close();
        return note;
    }

    public ArrayList<PhotoItem> getAllImages() {
        ArrayList<PhotoItem> notes = new ArrayList<>();
        String[] columns = new String[]{PhotoItem.COLUMN_ID, PhotoItem.COLUMN_DNAME, PhotoItem.COLUMN_ORIPATH, PhotoItem.COLUMN_NEWPATH, PhotoItem.COLUMN_SIZE, PhotoItem.COLUMN_MIMETYPE, PhotoItem.COLUMN_CLOUD_FILE_ID, PhotoItem.COLUMN_TRASH};
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(PhotoItem.TABLE_NAME, columns, PhotoItem.COLUMN_TRASH + "=?", new String[]{"0"}, null, null, null);
        if (cursor.getCount() > 0) {
            if (cursor.moveToFirst()) {
                do {
                    PhotoItem note = new PhotoItem();
                    note.setId(cursor.getInt(cursor.getColumnIndex(PhotoItem.COLUMN_ID)));
                    note.setDisplayName(cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_DNAME)));
                    note.setPath(cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_ORIPATH)));
                    note.setNewPath(cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_NEWPATH)));
                    note.setSize(cursor.getLong(cursor.getColumnIndex(PhotoItem.COLUMN_SIZE)));
                    note.setMimeType(cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_MIMETYPE)));
                    note.setCouldId(cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_CLOUD_FILE_ID)));
                    note.setIsTrash(cursor.getInt(cursor.getColumnIndex(PhotoItem.COLUMN_TRASH)));

                    notes.add(note);
                } while (cursor.moveToNext());
            }
        }
        db.close();
        return notes;
    }

    public ArrayList<PhotoItem> getTrashImages() {
        ArrayList<PhotoItem> notes = new ArrayList<>();
        String selectQuery = "SELECT  * FROM " + PhotoItem.TABLE_NAME + " ORDER BY " + PhotoItem.COLUMN_ID + " DESC";
        String[] columns = new String[]{PhotoItem.COLUMN_ID, PhotoItem.COLUMN_DNAME, PhotoItem.COLUMN_ORIPATH, PhotoItem.COLUMN_NEWPATH, PhotoItem.COLUMN_SIZE, PhotoItem.COLUMN_MIMETYPE, PhotoItem.COLUMN_CLOUD_FILE_ID, PhotoItem.COLUMN_TRASH};

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(PhotoItem.TABLE_NAME, columns, PhotoItem.COLUMN_TRASH + "=?", new String[]{"1"}, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                PhotoItem note = new PhotoItem();
                note.setId(cursor.getInt(cursor.getColumnIndex(PhotoItem.COLUMN_ID)));
                note.setDisplayName(cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_DNAME)));
                note.setPath(cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_ORIPATH)));
                note.setNewPath(cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_NEWPATH)));
                note.setSize(cursor.getLong(cursor.getColumnIndex(PhotoItem.COLUMN_SIZE)));
                note.setMimeType(cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_MIMETYPE)));
                note.setCouldId(cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_CLOUD_FILE_ID)));
                note.setIsTrash(cursor.getInt(cursor.getColumnIndex(PhotoItem.COLUMN_TRASH)));

                notes.add(note);
            } while (cursor.moveToNext());
        }
        db.close();
        return notes;
    }

    public ArrayList<PhotoItem> getBackupImages() {
        ArrayList<PhotoItem> notes = new ArrayList<>();
        String[] columns = new String[]{PhotoItem.COLUMN_ID, PhotoItem.COLUMN_DNAME, PhotoItem.COLUMN_ORIPATH, PhotoItem.COLUMN_NEWPATH, PhotoItem.COLUMN_SIZE, PhotoItem.COLUMN_MIMETYPE, PhotoItem.COLUMN_CLOUD_FILE_ID, PhotoItem.COLUMN_TRASH};
        SQLiteDatabase db = this.getWritableDatabase();
//        Cursor findEntry = db.query("sku_table", columns, "owner=? and price=?", new String[] { owner, price }, null, null, null);
        Cursor cursor = db.query(PhotoItem.TABLE_NAME, columns, PhotoItem.COLUMN_CLOUD_FILE_ID + "=?", new String[]{"null1"}, null, null, null);
        Log.e("TAG", "getBackupImages: " + cursor.getCount());
        if (cursor.moveToFirst()) {
            do {
                PhotoItem note = new PhotoItem();
                note.setId(cursor.getInt(cursor.getColumnIndex(PhotoItem.COLUMN_ID)));
                note.setDisplayName(cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_DNAME)));
                note.setPath(cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_ORIPATH)));
                note.setNewPath(cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_NEWPATH)));
                note.setSize(cursor.getLong(cursor.getColumnIndex(PhotoItem.COLUMN_SIZE)));
                note.setMimeType(cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_MIMETYPE)));
                note.setCouldId(cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_CLOUD_FILE_ID)));
                note.setIsTrash(cursor.getInt(cursor.getColumnIndex(PhotoItem.COLUMN_TRASH)));

                notes.add(note);
            } while (cursor.moveToNext());
        }
        db.close();
        return notes;
    }

    public ArrayList<PhotoItem> getRestoreImages() {
        ArrayList<PhotoItem> notes = new ArrayList<>();
        String selectQuery = "SELECT  * FROM " + PhotoItem.TABLE_NAME + " ORDER BY " + PhotoItem.COLUMN_ID + " DESC";
        String[] columns = new String[]{PhotoItem.COLUMN_ID, PhotoItem.COLUMN_DNAME, PhotoItem.COLUMN_ORIPATH, PhotoItem.COLUMN_NEWPATH, PhotoItem.COLUMN_SIZE, PhotoItem.COLUMN_MIMETYPE, PhotoItem.COLUMN_CLOUD_FILE_ID, PhotoItem.COLUMN_TRASH};

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(PhotoItem.TABLE_NAME, columns, PhotoItem.COLUMN_TRASH + "=?", new String[]{"2"}, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                PhotoItem note = new PhotoItem();
                note.setId(cursor.getInt(cursor.getColumnIndex(PhotoItem.COLUMN_ID)));
                note.setDisplayName(cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_DNAME)));
                note.setPath(cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_ORIPATH)));
                note.setNewPath(cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_NEWPATH)));
                note.setSize(cursor.getLong(cursor.getColumnIndex(PhotoItem.COLUMN_SIZE)));
                note.setMimeType(cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_MIMETYPE)));
                note.setCouldId(cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_CLOUD_FILE_ID)));
                note.setIsTrash(cursor.getInt(cursor.getColumnIndex(PhotoItem.COLUMN_TRASH)));

                notes.add(note);
            } while (cursor.moveToNext());
        }
        db.close();
        return notes;
    }

    public int getNotesCount() {
        String countQuery = "SELECT  * FROM " + PhotoItem.TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int count = cursor.getCount();
        cursor.close();
        return count;
    }

    public int updateImgCloudID(int id, String couldfileide) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(PhotoItem.COLUMN_CLOUD_FILE_ID, couldfileide);
        return db.update(PhotoItem.TABLE_NAME, values, PhotoItem.COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public int movewTrathPhoto(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(PhotoItem.COLUMN_TRASH, 1);
        return db.update(PhotoItem.TABLE_NAME, values, PhotoItem.COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public int reCoverPhoto(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(PhotoItem.COLUMN_TRASH, 0);
        return db.update(PhotoItem.TABLE_NAME, values, PhotoItem.COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public int deletePhotoTrash(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(PhotoItem.COLUMN_TRASH, 2);
        return db.update(PhotoItem.TABLE_NAME, values, PhotoItem.COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public void deletePhotoItem(PhotoItem note) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(PhotoItem.TABLE_NAME, PhotoItem.COLUMN_ID + " = ?", new String[]{String.valueOf(note.getId())});
        db.close();
    }

    //=================== tabVideos=====================
    public long insertVideo(String displayName, String oripath, String newpath, long size, long duration, String mimeType) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(VideoItem.COLUMN_DNAME, displayName);
        values.put(VideoItem.COLUMN_ORIPATH, oripath);
        values.put(VideoItem.COLUMN_NEWPATH, newpath);
        values.put(VideoItem.COLUMN_SIZE, size);
        values.put(VideoItem.COLUMN_MIMETYPE, mimeType);
        values.put(VideoItem.COLUMN_CLOUD_FILE_ID, "null1");
        values.put(VideoItem.COLUMN_TRASH, 0);

        long id = db.insert(VideoItem.TABLE_NAME, null, values);
        db.close();
        return id;
    }

    public ArrayList<VideoItem> getAllVideos() {
        ArrayList<VideoItem> notes = new ArrayList<>();
        String[] columns = new String[]{VideoItem.COLUMN_ID, VideoItem.COLUMN_DNAME, VideoItem.COLUMN_ORIPATH, VideoItem.COLUMN_NEWPATH, VideoItem.COLUMN_SIZE, VideoItem.COLUMN_MIMETYPE, VideoItem.COLUMN_CLOUD_FILE_ID, VideoItem.COLUMN_TRASH};
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(VideoItem.TABLE_NAME, columns, VideoItem.COLUMN_TRASH + "=?", new String[]{"0"}, null, null, null);
        if (cursor.getCount() > 0) {
            if (cursor.moveToFirst()) {
                do {
                    VideoItem note = new VideoItem();
                    note.setId(cursor.getInt(cursor.getColumnIndex(VideoItem.COLUMN_ID)));
                    note.setDisplayName(cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_DNAME)));
                    note.setPath(cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_ORIPATH)));
                    note.setNewPath(cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_NEWPATH)));
                    note.setSize(cursor.getLong(cursor.getColumnIndex(VideoItem.COLUMN_SIZE)));
                    note.setMimeType(cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_MIMETYPE)));
                    note.setCouldId(cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_CLOUD_FILE_ID)));
                    note.setIsTrash(cursor.getInt(cursor.getColumnIndex(VideoItem.COLUMN_TRASH)));

                    notes.add(note);
                } while (cursor.moveToNext());
            }
        }
        db.close();
        return notes;
    }

    public ArrayList<VideoItem> getBackupVideos() {
        ArrayList<VideoItem> notes = new ArrayList<>();
        String[] columns = new String[]{VideoItem.COLUMN_ID, VideoItem.COLUMN_DNAME, VideoItem.COLUMN_ORIPATH, VideoItem.COLUMN_NEWPATH, VideoItem.COLUMN_SIZE, VideoItem.COLUMN_MIMETYPE, VideoItem.COLUMN_CLOUD_FILE_ID, VideoItem.COLUMN_TRASH};
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(VideoItem.TABLE_NAME, columns, VideoItem.COLUMN_CLOUD_FILE_ID + "=?", new String[]{"null1"}, null, null, null);
        Log.e("TAG", "getBackupImages: " + cursor.getCount());
        if (cursor.moveToFirst()) {
            do {
                VideoItem note = new VideoItem();
                note.setId(cursor.getInt(cursor.getColumnIndex(VideoItem.COLUMN_ID)));
                note.setDisplayName(cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_DNAME)));
                note.setPath(cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_ORIPATH)));
                note.setNewPath(cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_NEWPATH)));
                note.setSize(cursor.getLong(cursor.getColumnIndex(VideoItem.COLUMN_SIZE)));
                note.setMimeType(cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_MIMETYPE)));
                note.setCouldId(cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_CLOUD_FILE_ID)));
                note.setIsTrash(cursor.getInt(cursor.getColumnIndex(VideoItem.COLUMN_TRASH)));

                notes.add(note);
            } while (cursor.moveToNext());
        }
        db.close();
        return notes;
    }

    public ArrayList<VideoItem> getTrashVideo() {
        ArrayList<VideoItem> notes = new ArrayList<>();
        String selectQuery = "SELECT  * FROM " + VideoItem.TABLE_NAME + " ORDER BY " + VideoItem.COLUMN_ID + " DESC";
        String[] columns = new String[]{VideoItem.COLUMN_ID, VideoItem.COLUMN_DNAME, VideoItem.COLUMN_ORIPATH, VideoItem.COLUMN_NEWPATH, VideoItem.COLUMN_SIZE, VideoItem.COLUMN_MIMETYPE, VideoItem.COLUMN_CLOUD_FILE_ID, VideoItem.COLUMN_TRASH};

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(VideoItem.TABLE_NAME, columns, VideoItem.COLUMN_TRASH + "=?", new String[]{"1"}, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                VideoItem note = new VideoItem();
                note.setId(cursor.getInt(cursor.getColumnIndex(VideoItem.COLUMN_ID)));
                note.setDisplayName(cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_DNAME)));
                note.setPath(cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_ORIPATH)));
                note.setNewPath(cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_NEWPATH)));
                note.setSize(cursor.getLong(cursor.getColumnIndex(VideoItem.COLUMN_SIZE)));
                note.setMimeType(cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_MIMETYPE)));
                note.setCouldId(cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_CLOUD_FILE_ID)));
                note.setIsTrash(cursor.getInt(cursor.getColumnIndex(VideoItem.COLUMN_TRASH)));

                notes.add(note);
            } while (cursor.moveToNext());
        }
        db.close();
        return notes;
    }

    public ArrayList<VideoItem> getRestoreVideo() {
        ArrayList<VideoItem> notes = new ArrayList<>();
        String selectQuery = "SELECT  * FROM " + VideoItem.TABLE_NAME + " ORDER BY " + VideoItem.COLUMN_ID + " DESC";
        String[] columns = new String[]{VideoItem.COLUMN_ID, VideoItem.COLUMN_DNAME, VideoItem.COLUMN_ORIPATH, VideoItem.COLUMN_NEWPATH, VideoItem.COLUMN_SIZE, VideoItem.COLUMN_MIMETYPE, VideoItem.COLUMN_CLOUD_FILE_ID, VideoItem.COLUMN_TRASH};

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(VideoItem.TABLE_NAME, columns, VideoItem.COLUMN_TRASH + "=?", new String[]{"2"}, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                VideoItem note = new VideoItem();
                note.setId(cursor.getInt(cursor.getColumnIndex(VideoItem.COLUMN_ID)));
                note.setDisplayName(cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_DNAME)));
                note.setPath(cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_ORIPATH)));
                note.setNewPath(cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_NEWPATH)));
                note.setSize(cursor.getLong(cursor.getColumnIndex(VideoItem.COLUMN_SIZE)));
                note.setMimeType(cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_MIMETYPE)));
                note.setCouldId(cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_CLOUD_FILE_ID)));
                note.setIsTrash(cursor.getInt(cursor.getColumnIndex(VideoItem.COLUMN_TRASH)));

                notes.add(note);
            } while (cursor.moveToNext());
        }
        db.close();
        return notes;
    }


    public int updateVideoCloudID(int id, String couldfileide) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(VideoItem.COLUMN_CLOUD_FILE_ID, couldfileide);
        return db.update(VideoItem.TABLE_NAME, values, VideoItem.COLUMN_ID + " = ?", new String[]{String.valueOf(id)});

    }

    public int movewTrathVideo(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(VideoItem.COLUMN_TRASH, 1);
        return db.update(VideoItem.TABLE_NAME, values, VideoItem.COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public int reCoverVideo(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(VideoItem.COLUMN_TRASH, 0);
        return db.update(VideoItem.TABLE_NAME, values, VideoItem.COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public int deleteVideoTrash(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(VideoItem.COLUMN_TRASH, 2);
        return db.update(VideoItem.TABLE_NAME, values, VideoItem.COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public void deleteVideoItem(VideoItem note) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(VideoItem.TABLE_NAME, VideoItem.COLUMN_ID + " = ?", new String[]{String.valueOf(note.getId())});
        db.close();
    }

    //================= for tab file
    public long insertFile(String displayName, String oripath, String newpath, long size, String mimeType) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(FileItem.COLUMN_DNAME, displayName);
        values.put(FileItem.COLUMN_ORIPATH, oripath);
        values.put(FileItem.COLUMN_NEWPATH, newpath);
        values.put(FileItem.COLUMN_SIZE, size);
        values.put(FileItem.COLUMN_CLOUD_FILE_ID, "null1");
        values.put(FileItem.COLUMN_TRASH, 0);

        values.put(FileItem.COLUMN_MIMETYPE, mimeType);
        long id = db.insert(FileItem.TABLE_NAME, null, values);

        db.close();
        return id;
    }

    public FileItem getFiles(long id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(FileItem.TABLE_NAME,
                new String[]{FileItem.COLUMN_ID, FileItem.COLUMN_DNAME, FileItem.COLUMN_ORIPATH, FileItem.COLUMN_NEWPATH, FileItem.COLUMN_SIZE, FileItem.COLUMN_MIMETYPE}, FileItem.COLUMN_ID + "=?",
                new String[]{String.valueOf(id)}, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();
        FileItem note = new FileItem(
                cursor.getInt(cursor.getColumnIndex(FileItem.COLUMN_ID)),
                cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_DNAME)),
                cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_ORIPATH)),
                cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_NEWPATH)),
                cursor.getLong(cursor.getColumnIndex(FileItem.COLUMN_SIZE)),
                cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_MIMETYPE)));
        cursor.close();
        return note;
    }

    public ArrayList<FileItem> getAllFiles() {
        ArrayList<FileItem> notes = new ArrayList<>();
        String[] columns = new String[]{FileItem.COLUMN_ID, FileItem.COLUMN_DNAME, FileItem.COLUMN_ORIPATH, FileItem.COLUMN_NEWPATH, FileItem.COLUMN_SIZE, FileItem.COLUMN_MIMETYPE, FileItem.COLUMN_CLOUD_FILE_ID, FileItem.COLUMN_TRASH};
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(FileItem.TABLE_NAME, columns, FileItem.COLUMN_TRASH + "=?", new String[]{"0"}, null, null, null);
        if (cursor.getCount() > 0) {
            if (cursor.moveToFirst()) {
                do {
                    FileItem note = new FileItem();
                    note.setId(cursor.getInt(cursor.getColumnIndex(FileItem.COLUMN_ID)));
                    note.setDisplayName(cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_DNAME)));
                    note.setPath(cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_ORIPATH)));
                    note.setNewPath(cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_NEWPATH)));
                    note.setSize(cursor.getLong(cursor.getColumnIndex(FileItem.COLUMN_SIZE)));
                    note.setMimeType(cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_MIMETYPE)));
                    note.setCouldId(cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_CLOUD_FILE_ID)));
                    note.setIsTrash(cursor.getInt(cursor.getColumnIndex(FileItem.COLUMN_TRASH)));

                    notes.add(note);
                } while (cursor.moveToNext());
            }
        }
        db.close();
        return notes;
    }

    public ArrayList<FileItem> getTrashFiels() {
        ArrayList<FileItem> notes = new ArrayList<>();
        String selectQuery = "SELECT  * FROM " + FileItem.TABLE_NAME + " ORDER BY " + FileItem.COLUMN_ID + " DESC";
        String[] columns = new String[]{FileItem.COLUMN_ID, FileItem.COLUMN_DNAME, FileItem.COLUMN_ORIPATH, FileItem.COLUMN_NEWPATH, FileItem.COLUMN_SIZE, FileItem.COLUMN_MIMETYPE, FileItem.COLUMN_CLOUD_FILE_ID, FileItem.COLUMN_TRASH};

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(FileItem.TABLE_NAME, columns, FileItem.COLUMN_TRASH + "=?", new String[]{"1"}, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                FileItem note = new FileItem();
                note.setId(cursor.getInt(cursor.getColumnIndex(FileItem.COLUMN_ID)));
                note.setDisplayName(cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_DNAME)));
                note.setPath(cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_ORIPATH)));
                note.setNewPath(cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_NEWPATH)));
                note.setSize(cursor.getLong(cursor.getColumnIndex(FileItem.COLUMN_SIZE)));
                note.setMimeType(cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_MIMETYPE)));
                note.setCouldId(cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_CLOUD_FILE_ID)));
                note.setIsTrash(cursor.getInt(cursor.getColumnIndex(FileItem.COLUMN_TRASH)));

                notes.add(note);
            } while (cursor.moveToNext());
        }
        db.close();
        return notes;
    }

    public ArrayList<FileItem> getBackupFiels() {
        ArrayList<FileItem> notes = new ArrayList<>();
        String[] columns = new String[]{FileItem.COLUMN_ID, FileItem.COLUMN_DNAME, FileItem.COLUMN_ORIPATH, FileItem.COLUMN_NEWPATH, FileItem.COLUMN_SIZE, FileItem.COLUMN_MIMETYPE, FileItem.COLUMN_CLOUD_FILE_ID, FileItem.COLUMN_TRASH};
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(FileItem.TABLE_NAME, columns, FileItem.COLUMN_CLOUD_FILE_ID + "=?", new String[]{"null1"}, null, null, null);
        Log.e("TAG", "getBackupImages: " + cursor.getCount());
        if (cursor.moveToFirst()) {
            do {
                FileItem note = new FileItem();
                note.setId(cursor.getInt(cursor.getColumnIndex(FileItem.COLUMN_ID)));
                note.setDisplayName(cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_DNAME)));
                note.setPath(cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_ORIPATH)));
                note.setNewPath(cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_NEWPATH)));
                note.setSize(cursor.getLong(cursor.getColumnIndex(FileItem.COLUMN_SIZE)));
                note.setMimeType(cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_MIMETYPE)));
                note.setCouldId(cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_CLOUD_FILE_ID)));
                note.setIsTrash(cursor.getInt(cursor.getColumnIndex(FileItem.COLUMN_TRASH)));

                notes.add(note);
            } while (cursor.moveToNext());
        }
        db.close();
        return notes;
    }

    public ArrayList<FileItem> getRestoreFile() {
        ArrayList<FileItem> notes = new ArrayList<>();
        String selectQuery = "SELECT  * FROM " + FileItem.TABLE_NAME + " ORDER BY " + FileItem.COLUMN_ID + " DESC";
        String[] columns = new String[]{FileItem.COLUMN_ID, FileItem.COLUMN_DNAME, FileItem.COLUMN_ORIPATH, FileItem.COLUMN_NEWPATH, FileItem.COLUMN_SIZE, FileItem.COLUMN_MIMETYPE, FileItem.COLUMN_CLOUD_FILE_ID, FileItem.COLUMN_TRASH};

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(FileItem.TABLE_NAME, columns, FileItem.COLUMN_TRASH + "=?", new String[]{"2"}, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                FileItem note = new FileItem();
                note.setId(cursor.getInt(cursor.getColumnIndex(FileItem.COLUMN_ID)));
                note.setDisplayName(cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_DNAME)));
                note.setPath(cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_ORIPATH)));
                note.setNewPath(cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_NEWPATH)));
                note.setSize(cursor.getLong(cursor.getColumnIndex(FileItem.COLUMN_SIZE)));
                note.setMimeType(cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_MIMETYPE)));
                note.setCouldId(cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_CLOUD_FILE_ID)));
                note.setIsTrash(cursor.getInt(cursor.getColumnIndex(FileItem.COLUMN_TRASH)));

                notes.add(note);
            } while (cursor.moveToNext());
        }
        db.close();
        return notes;
    }

    public int updateFileCloudID(int id, String couldfileide) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(FileItem.COLUMN_CLOUD_FILE_ID, couldfileide);
        return db.update(FileItem.TABLE_NAME, values, FileItem.COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public int movewTrathFile(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(FileItem.COLUMN_TRASH, 1);
        return db.update(FileItem.TABLE_NAME, values, FileItem.COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public int reCoverFile(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(FileItem.COLUMN_TRASH, 0);
        return db.update(FileItem.TABLE_NAME, values, FileItem.COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public int deleteFileTrash(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(FileItem.COLUMN_TRASH, 2);
        return db.update(FileItem.TABLE_NAME, values, FileItem.COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public void deleteFileItem(FileItem note) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(FileItem.TABLE_NAME, FileItem.COLUMN_ID + " = ?",
                new String[]{String.valueOf(note.getId())});
        db.close();
    }

    //==============\
    public List<BookmarkModel> listBookmark() {
        List<BookmarkModel> list = new ArrayList<>();

        String[] columns = new String[]{BookmarkModel.COLUMN_PASS_ID,
                BookmarkModel.COLUMN_PASS_TITLE,
                BookmarkModel.COLUMN_PASS_CONTENT,
                BookmarkModel.COLUMN_PASS_ICON,
                BookmarkModel.COLUMN_PASS_ATTACH,
                BookmarkModel.COLUMN_PASS_CREATION};
        SQLiteDatabase db = this.getWritableDatabase();
        String orderBy = BookmarkModel.COLUMN_PASS_CREATION + "," + BookmarkModel.COLUMN_PASS_TITLE + " COLLATE NOCASE ASC;";
        Cursor cursor = db.query(BookmarkModel.TABLE_BOOKMARKS_PASS,
                columns,
                null,
                null,
                null,
                null,
                orderBy);
        if (cursor == null) {
            return list;
        }

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list.add(getBookmarkRecord(cursor));
            cursor.moveToNext();
        }
        cursor.close();

        return list;
    }

    private BookmarkModel getBookmarkRecord(Cursor cursor) {
        BookmarkModel record = new BookmarkModel();
        record.setPass_id(cursor.getString(0));
        record.setPass_title(cursor.getString(1));
        record.setPass_content(cursor.getString(2));
        record.setPass_icon(cursor.getString(3));
        record.setPass_attachment(cursor.getString(4));
        record.setPass_creation(cursor.getString(5));
        return record;
    }

    //delete data
    public void delete(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + BookmarkModel.TABLE_BOOKMARKS_PASS + " WHERE " + BookmarkModel.COLUMN_PASS_ID + "=" + id);
    }

    public void deleteAllBookmarks() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(BookmarkModel.TABLE_BOOKMARKS_PASS, null, null);
    }

    public void addBookmark(String pass_title, String pass_content, String pass_icon, String pass_attachment, String pass_creation) {

        if (!isExist(pass_content)) {
//            database.execSQL("INSERT INTO pass (pass_title, pass_content, pass_icon, pass_attachment, pass_creation) VALUES('" + pass_title + "','" + pass_content + "','" + pass_icon + "','" + pass_attachment + "','" + pass_creation + "')");
            SQLiteDatabase db = this.getWritableDatabase();
            if (pass_title == null
                    || pass_title.trim().isEmpty()
                    || pass_content == null
                    || pass_content.trim().isEmpty()
                    || pass_icon == null
                    || pass_icon.trim().isEmpty()
                    || pass_attachment == null
                    || pass_attachment.trim().isEmpty()
                    || pass_creation == null
                    || pass_creation.trim().isEmpty()) {
                return;
            }

            ContentValues values = new ContentValues();
            values.put(BookmarkModel.COLUMN_PASS_TITLE, pass_title.trim());
            values.put(BookmarkModel.COLUMN_PASS_CONTENT, pass_content.trim());
            values.put(BookmarkModel.COLUMN_PASS_ICON, pass_icon);
            values.put(BookmarkModel.COLUMN_PASS_ATTACH, pass_attachment);
            values.put(BookmarkModel.COLUMN_PASS_CREATION, pass_creation);
            db.insert(BookmarkModel.TABLE_BOOKMARKS_PASS, null, values);
        }
    }

    public boolean isExist(String pass_content) {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT " + BookmarkModel.COLUMN_PASS_TITLE + " FROM " + BookmarkModel.TABLE_BOOKMARKS_PASS + " WHERE " + BookmarkModel.COLUMN_PASS_CONTENT + "='" + pass_content + "' LIMIT 1";
        @SuppressLint("Recycle") Cursor row = db.rawQuery(query, null);
        return row.moveToFirst();
    }

}