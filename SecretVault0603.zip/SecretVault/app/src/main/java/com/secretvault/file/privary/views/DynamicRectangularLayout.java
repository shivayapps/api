package com.secretvault.file.privary.views;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.LinearLayout;

public class DynamicRectangularLayout  extends LinearLayout {
 
    public DynamicRectangularLayout(Context context) {
        super(context);
    }
 
 
    public DynamicRectangularLayout(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }
 
    public DynamicRectangularLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
 
 
 // Here note that the height is width/2
//
//    @Override public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
//        super.onMeasure(widthMeasureSpec, (widthMeasureSpec/2));
//       int size = MeasureSpec.getSize(widthMeasureSpec);
//        setMeasuredDimension(size, (size/2));
//    }


    @Override
    public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, widthMeasureSpec);
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int height = MeasureSpec.getSize(heightMeasureSpec);
        int size = width > height ? height : width;
//        setMeasuredDimension(size, size);
        setMeasuredDimension(width, width);
    }
}
 