package com.secretvault.file.privary.adapters;

public interface OnItemClickListner {

    void onItemClick(int position);

    void onItemLongClick(int position);

}
