package com.secretvault.file.privary;

import android.app.Application;
import android.content.Context;


import androidx.multidex.MultiDex;

import com.secretvault.file.privary.model.WebSite;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.secretvault.file.privary.utils.MyLifecycleHandler;

import java.util.ArrayList;
import java.util.List;


public class EasyApplication extends Application {

    public static Context context;
    private static EasyApplication mInstance;

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
        context = base;
        mInstance = this;
    }

    public static synchronized EasyApplication getInstance() {
        return mInstance;
    }
    @Override
    public void onCreate() {
        super.onCreate();
        FirebaseAnalytics.getInstance(this);
        registerActivityLifecycleCallbacks(new MyLifecycleHandler());
    }

    public static Context getContext() {
        return context;
    }
    public List<WebSite> initDB() {
        List<WebSite> webSites = new ArrayList<>();


        webSites.add(new WebSite(null, "Google", "www.google.com"));
        webSites.add(new WebSite(null, "Youtube", "youtube.com"));
        webSites.add(new WebSite(null, "Facebook", "facebook.com"));
        webSites.add(new WebSite(null, "Instagram", "instagram.com"));
        webSites.add(new WebSite(null, "Amazon", "amazon.com"));
        webSites.add(new WebSite(null, "Just dial", "www.justdial.com"));
        webSites.add(new WebSite(null, "Flipkart", "flipkart.com"));

        return webSites;
    }

}
