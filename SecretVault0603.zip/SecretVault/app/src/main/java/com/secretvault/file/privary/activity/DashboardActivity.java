package com.secretvault.file.privary.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.material.snackbar.Snackbar;
import com.secretvault.file.privary.MainActivity;
import com.secretvault.file.privary.R;
import com.secretvault.file.privary.ads.AdmobAdManager;
import com.secretvault.file.privary.ads.AdEventListener;
import com.secretvault.file.privary.db.DatabaseHelper;
import com.secretvault.file.privary.db.UserItem;
import com.secretvault.file.privary.model.AppDataModel;
import com.secretvault.file.privary.utils.Connectivity;
import com.secretvault.file.privary.utils.PreferenceHelper;
import com.secretvault.file.privary.utils.Utils;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential;
import com.google.api.services.drive.DriveScopes;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public class DashboardActivity extends AppCompatActivity {

    private static final String TAG = "DashboardActivity";
    private static final int REQUEST_ACCOUNT_PICKER = 0;

    Context mContext;
    LinearLayout card_photos,card_videos,card_files,card_browser,card_cloud,card_intruder;
    ImageView iv_setting;
    DatabaseHelper databaseHelper;
    private GoogleAccountCredential credential;

    String[] arrAppIcons1 = new String[]{"ic_google1", "ic_youtube",
            "ic_facebook",
            "ic_instagram", "ic_amazon",
            "ic_flipcart", "ic_jd"};
    String[] arrAppTitle = new String[]{"Google", "YouTube",
            "Facebook",
            "Instagram", "Amazon",
            "Flipkart", "Just dial"};
    String[] arrAppLinks = new String[]{"https://www.google.com", "https://youtube.com",
            "https://facebook.com",
            "https://instagram.com", "https://amazon.com",
            "https://flipkart.com", "https://www.justdial.com"};

    public static int clickCount=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext=DashboardActivity.this;

        setContentView(R.layout.activity_dashboard);

        PinActivity.createImageDir();
        databaseHelper = new DatabaseHelper(mContext);
        RemoConfigntialize();
        createImageDir();

        showInterstitialAd(null);

        card_photos=findViewById(R.id.card_photos);
        card_videos=findViewById(R.id.card_videos);
        card_files=findViewById(R.id.card_files);
        card_browser=findViewById(R.id.card_browser);
        card_cloud=findViewById(R.id.card_cloud);
        card_intruder=findViewById(R.id.card_intruder);
        iv_setting=findViewById(R.id.iv_setting);


        iv_setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickCount++;
                Intent intent=new Intent(mContext, SettingActivity.class);
                if(clickCount==3) {
                    clickCount=0;
                    showInterstitialAd(intent);
                } else {
                    startActivity(intent);
                }

            }
        });
        card_photos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickCount++;
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.putExtra("Type", "Photos");
                //startActivityForResult(intent, 120);
                if(clickCount==3) {
                    clickCount=0;
                    showInterstitialAd(intent);
                } else {
                    startActivity(intent);
                }
            }
        });
        card_videos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickCount++;
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.putExtra("Type", "Videos");
                //startActivityForResult(intent, 120);
                if(clickCount==3) {
                    clickCount=0;
                    showInterstitialAd(intent);
                } else {
                    startActivity(intent);
                }
            }
        });
        card_files.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickCount++;
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.putExtra("Type", "Files");
                //startActivityForResult(intent, 120);
                if(clickCount==3) {
                    clickCount=0;
                    showInterstitialAd(intent);
                } else {
                    startActivity(intent);
                }
            }
        });
        card_browser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickCount++;
                Intent intent=new Intent(mContext, PrivateBrowserActivity.class);
                //startActivityForResult(intent, 120);
                if(clickCount==3) {
                    clickCount=0;
                    showInterstitialAd(intent);
                } else {
                    startActivity(intent);
                }
            }
        });
        card_cloud.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickCount++;
                Intent intent=new Intent(mContext, CloudBackupActivity.class);
                if(clickCount==3) {
                    clickCount=0;
                    showInterstitialAd(intent);
                } else {
                    startActivity(intent);
                }
            }
        });
        card_intruder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickCount++;
                Intent intent=new Intent(mContext, IntruderActivity.class);
                if(clickCount==3) {
                    clickCount=0;
                    showInterstitialAd(intent);
                } else {
                    startActivity(intent);
                }
            }
        });

        init();

        DatabaseHelper databaseHelper = new DatabaseHelper(getApplicationContext());
        UserItem userItem = databaseHelper.getUserData();
        Log.e(TAG, "onClick: userItem====> " + userItem.toString());
        if (userItem.getEmail() == null) {
            googleLogIn();
        }

        if (PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.isFirstTime, true)) {
            LinkedHashMap<String, AppDataModel> appList = new LinkedHashMap<>();
            for (int i = 0; i < arrAppTitle.length; i++) {
                appList.put(arrAppLinks[i], new AppDataModel(arrAppIcons1[i], arrAppLinks[i], arrAppTitle[i]));
            }
            PreferenceHelper.saveAppData(getApplicationContext(), appList);
            PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.isFirstTime, false);
        }
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        Log.e("UCSafe", "DashboardActivity:onUserLeaveHint");
    }

    @Override
    public void onUserInteraction() {
        super.onUserInteraction();
        Log.e("UCSafe", "DashboardActivity:onUserInteraction");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("UCSafe", "DashboardActivity:onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.e("UCSafe", "DashboardActivity:onPause");
    }
    @Override
    protected void onStop() {
        super.onStop();
        Log.e("UCSafe", "DashboardActivity:onStop");
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
        Log.e("UCSafe", "DashboardActivity:onKeyDown:"+keyCode);
        if(keyCode == KeyEvent.KEYCODE_HOME)
        {
            Log.e("UCSafe", "DashboardActivity:Home button pressed!");
        }
        return super.onKeyDown(keyCode, event);
    }

    private void init() {
        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);

        AdmobAdManager admobAdManager = new AdmobAdManager(mContext);
        admobAdManager.loadNativeAd(mContext, getString(R.string.NATIVE_ID), frameLayout, false ,new AdEventListener() {
            @Override
            public void onAdLoaded() {
                frameLayout.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {

            }

            @Override
            public void onLoadError(String errorCode) {
                frameLayout.setVisibility(View.GONE);
            }
        });
    }

    private void googleLogIn() {
        if (Connectivity.isConnectedFast(mContext)) {
            credential = GoogleAccountCredential.usingOAuth2(this, Arrays.asList(DriveScopes.DRIVE_FILE));
            String accountName = PreferenceHelper.getValue(mContext, PreferenceHelper.AccountName, "");
            if (accountName.length() > 0) {
                Log.e(TAG, "ac name accountName " + accountName);
                if (isValidEmail(accountName)) {
                    Log.e(TAG, "googleLogIn: accountName==> " + accountName);
                    credential.setSelectedAccountName(accountName);
                    Log.e(TAG, "googleLogIn: credential==> " + credential.getSelectedAccount());


                    DatabaseHelper databaseHelper = new DatabaseHelper(getApplicationContext());
                    UserItem userItem = databaseHelper.getUserData();
                    if (userItem.getEmail() == null) {
                        databaseHelper.updateUserEmail(accountName);
                    }
                } else {
                    pickAccount();
                }
            } else {
                pickAccount();
            }
        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle(getString(R.string.internet_title));
            builder.setMessage(getString(R.string.internet_message));
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Toast.makeText(getApplicationContext(), "Please start internet and restart app.", Toast.LENGTH_LONG).show();
                    finish();
                }
            });
            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            });
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }
    }

    public boolean isValidEmail(CharSequence target) {
        return (!TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches());
    }

    private void pickAccount() {
        startActivityForResult(credential.newChooseAccountIntent(), REQUEST_ACCOUNT_PICKER);
    }

    public void createImageDir() {
        File myDirectory = new File(Utils.nohideFile);
        if (!myDirectory.exists()) {
            myDirectory.mkdirs();
            Log.e("TAG", "createImageDir: mkdir");
        } else {
        }
        File myDirectory1 = new File(Utils.nohideVideo);
        if (!myDirectory1.exists()) {
            myDirectory1.mkdirs();
            Log.e("TAG", "createImageDir: mkdir");
        } else {
        }
        File myDirectory2 = new File(Utils.nohideImage);
        if (!myDirectory2.exists()) {
            myDirectory2.mkdirs();
            Log.e("TAG", "createImageDir: mkdir");
        } else {
        }

    }

    @Override
    public void onBackPressed() {
        if (PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.isRatting, false)) {
            Intent startMain = new Intent(Intent.ACTION_MAIN);
            startMain.addCategory(Intent.CATEGORY_HOME);
            startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(startMain);
            finish();
        } else {
            RateMe();
        }
    }

    private void showInterstitialAd(Intent intent) {
        Log.e(
                "AdsManager",
                "getInterstitial_id_001:" + getString(R.string.INTERSTITIAL_ID)
        );
        AdmobAdManager admobAdManager = new AdmobAdManager(this);
        if (admobAdManager.getInterstitialAd() != null) {
            admobAdManager.showProgress();
            if (admobAdManager.getInterstitialAd().isLoaded()) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        admobAdManager.dismissProgress();
                        admobAdManager.getInterstitialAd().show();
                    }
                },1000);
                admobAdManager.getInterstitialAd().setAdListener(new AdListener() {

                    public void onAdClosed() {
                        super.onAdClosed();
                        admobAdManager.dismissProgress();
                        //App.setShowedInterstitialTime()
                        admobAdManager.loadInterstitialAd(
                                DashboardActivity.this,
                                getString(R.string.INTERSTITIAL_ID)
                        );
                        //navigateToMainScreen()
                        if(intent!=null) {
                            startActivity(intent);
                        }
                    }

                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        super.onAdFailedToLoad(loadAdError);
                        Log.e("AdsManager", "LoadAdError:$loadAdError");
                        admobAdManager.dismissProgress();
                        //navigateToMainScreen()
                        if(intent!=null) {
                            startActivity(intent);
                        }
                    }
                });
            } else {
                Log.e("AdsManager", "loadInterstitialAd:001");
                admobAdManager.dismissProgress();
                admobAdManager.loadInterstitialAd(this, getString(R.string.INTERSTITIAL_ID));
                //navigateToMainScreen()
                if(intent!=null) {
                    startActivity(intent);
                }
            }
        } else {
            Log.e("AdsManager", "loadInterstitialAd:002");
            admobAdManager.dismissProgress();
            admobAdManager.loadInterstitialAd(this, getString(R.string.INTERSTITIAL_ID));
            //navigateToMainScreen()
            if(intent!=null) {
                startActivity(intent);
            }
        }
    }

    boolean bug=false;
    String feedback="";
    private void RateMe() {
        final View dialogView = View.inflate(mContext, R.layout.dialog_say_thanks, null);
        final android.app.AlertDialog.Builder mAlertDialog = new android.app.AlertDialog.Builder(mContext)
                .setView(dialogView)
                .setCancelable(true);

        final android.app.AlertDialog mAlertDialog1 = mAlertDialog.create();
        mAlertDialog1.setCancelable(true);
        mAlertDialog1.setCanceledOnTouchOutside(true);

        TextView buttonPositive = (TextView) dialogView.findViewById(R.id.btn_rate_now);
        TextView buttonNegative = (TextView) dialogView.findViewById(R.id.btn_later);
        RatingBar rating_bar = (RatingBar) dialogView.findViewById(R.id.rating_bar);
        LinearLayout lay_feedback = (LinearLayout) dialogView.findViewById(R.id.lay_feedback);
        EditText txtfeedback = (EditText) dialogView.findViewById(R.id.txtfeedback);


        buttonPositive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(bug) {
                    feedback=txtfeedback.getText().toString().trim();
                    reportBug(mContext,"Feedback/Suggestion",feedback,rating_bar.getRating());
                    mAlertDialog1.dismiss();
                } else {
                    if (rating_bar.getRating() >= 1 && rating_bar.getRating() < 4) {
                        bug=true;
                        lay_feedback.setVisibility(View.VISIBLE);
                    } else if (rating_bar.getRating() >= 4 && rating_bar.getRating() <= 5) {
                        PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.isRatting, true);
                        showRate(mContext);
                        mAlertDialog1.dismiss();
                    } else if (rating_bar.getRating() == 0.0f) {
                        Snackbar.make(dialogView, mContext.getString(R.string.rate_app_zero_star_error), Snackbar.LENGTH_SHORT).show();
                    } else {
                        PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.isRatting, true);
                        showRate(mContext);
                        mAlertDialog1.dismiss();
                    }
                }
            }
        });
        buttonNegative.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.isRatting, false);
                Intent startMain = new Intent(Intent.ACTION_MAIN);
                startMain.addCategory(Intent.CATEGORY_HOME);
                startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(startMain);
                finish();
            }
        });
        mAlertDialog1.show();

        /*try {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(DashboardActivity.this);
            alertDialogBuilder
                    .setTitle(R.string.rate_dialog_title)
                    .setMessage(R.string.rate_dialog_message)
                    .setPositiveButton(R.string.rate_dialog_ok, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.isRatting, true);
                    try {
                        String url1 = "market://details?id=" + getPackageName();
                        Intent i1 = new Intent(Intent.ACTION_VIEW);
                        i1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        i1.setData(Uri.parse(url1));
                        startActivity(i1);
                        dialog.dismiss();
                    } catch (Exception w) {

                    }
                }
            }).setNegativeButton(R.string.rate_dialog_no, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.isRatting, false);
                    Intent startMain = new Intent(Intent.ACTION_MAIN);
                    startMain.addCategory(Intent.CATEGORY_HOME);
                    startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(startMain);
                    finish();
                    dialog.dismiss();
                }
            });
                    //.show();

        }
        catch (Exception e) {
        }*/
    }

    public static void reportBug(Context context, String subject, String errorMessage, float ratingValue) {

        // Get App Version
        PackageInfo pInfo = null;
        try {
            pInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        String version = pInfo.versionName;

        // Device Name
        String deviceName = Build.MANUFACTURER + " " + Build.MODEL;

        // OS Version
        String osVersion = Build.VERSION.RELEASE;
        int osAPI = Build.VERSION.SDK_INT;

        // Get Country Name
        String country = "";
        try {
            TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            String countryCode = "";
            if (tm != null) {
                countryCode = tm.getNetworkCountryIso();
            }
            Locale loc = new Locale("", countryCode);
            country = loc.getDisplayCountry();
        } catch (Exception e) {
            e.printStackTrace();
        }

        HashMap<String, Boolean> mapPermission = new HashMap<>();

        //Intent email = new Intent(Intent.ACTION_SENDTO, Uri.fromParts("mailto", "mahendra@jksol.com", null));
        //email.putExtra(Intent.EXTRA_SUBJECT, subject);

        Iterator<Map.Entry<String, Boolean>> mIterator = mapPermission.entrySet().iterator();
        String mExtraText = "";
        while (mIterator.hasNext()) {
            Map.Entry<String, Boolean> mEntry = mIterator.next();
            if (mEntry.getKey().trim().length() > 0) {
                mExtraText += (mEntry.getKey() + " : "
                        + (mEntry.getValue() ? "YES" : "NO") + "\n");
            }
        }
        String body="Your message: "+errorMessage+
                "\n\nRating :"+ratingValue+
                "\nDevice Information - "+context.getResources().getString(R.string.app_name)+
                "\nVersion : "+version+
                "\nDevice Name : "+deviceName+
                "\nAndroid API : "+osAPI+
                "\nAndroid Version : "+osVersion+
                "\nCountry : "+country;
                //"\nExtraText : "+mExtraText;


        subject = subject+" "+context.getResources().getString(R.string.app_name);
        //StringBuilder builder = new StringBuilder("mailto:" + Uri.encode(context.getResources().getString(R.string.feedback)));

        /*if (!subject.isEmpty()) {
            builder.append("?subject="+Uri.encode(Uri.encode(subject)));
            builder.append("&body=" + Uri.encode(Uri.encode(body)));
        }*/

        //email.putExtra(Intent.EXTRA_TEXT, body);
        try {
            //context.startActivity(Intent.createChooser(email, context.getString(R.string.email_choose_from_client)));

            context.startActivity(
                    Intent.createChooser(
                            new Intent(
                                    Intent.ACTION_SENDTO,
                                    Uri.parse(
                                            "mailto:" + context.getResources().getString(R.string.feedback)
                                                    + "?cc=&subject=" + Uri.encode(subject).toString()
                                                    + "&body=" + Uri.encode(body.replace("\n", "<br />"))
                                    )
                            ), context.getString(R.string.email_choose_from_client)
                    )
            );

        } catch (ActivityNotFoundException ex) {

        }
    }

    public void showRate(Context mContext) {

        try {
            mContext.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + mContext.getPackageName())));
        } catch (ActivityNotFoundException e) {
            mContext.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + mContext.getPackageName())));
        }
    }

    public void RemoConfigntialize() {
        final FirebaseRemoteConfig mFirebaseRemoteConfig = FirebaseRemoteConfig.getInstance();
        FirebaseRemoteConfigSettings configSettings = new FirebaseRemoteConfigSettings.Builder()
                .setMinimumFetchIntervalInSeconds(3600)
                .build();
        mFirebaseRemoteConfig.setConfigSettingsAsync(configSettings);
        //---defult value
        mFirebaseRemoteConfig.setDefaultsAsync(R.xml.remote_config_defaults);
        //-0----print
        mFirebaseRemoteConfig.fetchAndActivate()
                .addOnCompleteListener(this, new OnCompleteListener<Boolean>() {
                    @Override
                    public void onComplete(@NonNull Task<Boolean> task) {
                        if (task.isSuccessful()) {
                            boolean updated = task.getResult();
                            Log.d("TAG", "Config params updated: " + updated);
                        } else {
                        }
                        Utils.flicker_api_key = mFirebaseRemoteConfig.getString("flicker_api_key");
                        String welcomeMessage = mFirebaseRemoteConfig.getString("flicker_api_key");
                        Utils.IMAGE_COMMON_URL = "https://api.flickr.com/services/rest/?method=flickr.photosets.getPhotos&api_key=" + Utils.flicker_api_key + "&nojsoncallback=1&extras=description%2C+url_o%2C+url_m&per_page=500&page=1&format=json&photoset_id=";
                        Log.e("TAG", "onComplete: " + welcomeMessage);
                        Log.e("TAG", "onComplete:IMAGE_COMMON_URL " + Utils.IMAGE_COMMON_URL);

                    }
                });

    }
}