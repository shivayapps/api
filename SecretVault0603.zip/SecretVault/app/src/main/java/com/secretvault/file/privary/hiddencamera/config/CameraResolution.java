package com.secretvault.file.privary.hiddencamera.config;


import androidx.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@SuppressWarnings("WeakerAccess")
public final class CameraResolution {

    public static final int HIGH_RESOLUTION = 2006;

    public static final int MEDIUM_RESOLUTION = 7895;

    public static final int LOW_RESOLUTION = 7821;

    private CameraResolution() {
        throw new RuntimeException("Cannot initiate CameraResolution.");
    }

    @Retention(RetentionPolicy.SOURCE)
    @IntDef({HIGH_RESOLUTION, MEDIUM_RESOLUTION, LOW_RESOLUTION})
    public @interface SupportedResolution {
    }
}
