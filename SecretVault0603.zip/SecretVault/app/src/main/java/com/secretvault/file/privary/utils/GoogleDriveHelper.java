package com.secretvault.file.privary.utils;

import android.util.Log;

import com.google.api.client.googleapis.extensions.android.gms.auth.UserRecoverableAuthIOException;
import com.google.api.client.http.InputStreamContent;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.model.File;
import com.google.api.services.drive.model.FileList;
import com.google.api.services.drive.model.ParentReference;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class GoogleDriveHelper {

    public static File getOrCreateFolder(Drive service, String folderName, String parentId)
            throws UserRecoverableAuthIOException {
        File result = null;
        // check if the folder exists already
        try {
            String query = "mimeType='application/vnd.google-apps.folder' and trashed=false and title='" + folderName
                    + "'";
            // add parent param to the query if needed
            if (parentId != null) {
                query = query + " and '" + parentId + "' in parents";
            }
            Log.e("TAG", "getOrCreateFolder: " + query );
            Drive.Files.List request = service.files().list().setQ(query);
            FileList files = request.execute();
            if (files.getItems().size() == 0) {
                // File's metadata.
                File body = new File();
                if (parentId != null) {
                    ParentReference parent = new ParentReference();
                    parent.setId(parentId);
                    java.util.List<ParentReference> parents = new ArrayList<ParentReference>();
                    parents.add(parent);
                    body.setParents(parents);
                }
                body.setTitle(folderName);
                body.setMimeType("application/vnd.google-apps.folder");
                result = service.files().insert(body).execute();
            } else {
                result = files.getItems().get(0);
            }
        } catch (UserRecoverableAuthIOException ue) {
            throw ue;
        } catch (Exception e) {
            Log.e("TAG", "Exception while trying to getOrCreateFolder, folderName: "
                    + folderName + " parentId:"
                    + parentId + " exception:" + e.getMessage());
        }
        Log.e("TAG", "getOrCreateFolder: " + result.getId() + " >> " + result.getTitle());
        return result;
    }

    //==================================
    public static File createOrUpdateFileFromFile(Drive service, String localPath, String parentId, String fileMime) {
        File result = null;
        try {
            java.io.File localFile = new java.io.File(localPath);
            String fileName = localFile.getName();


            // check if given file exists
            String query = "trashed=false and title='"+  new String[]{ fileName } + "' and '" + parentId + "' in parents";

            Drive.Files.List request = service.files().list().setQ(query);
            FileList files = request.execute();
            if (files.getItems().size() == 0) {
                Log.e("TAG", "createOrUpdateFileFromFile:  files.getItems().size() == 00" );
                // file doesnt exist - create a new one
                File body = new File();
                // set parent
                ParentReference parent = new ParentReference();
                parent.setId(parentId);
                java.util.List<ParentReference> parents = new ArrayList<ParentReference>();
                parents.add(parent);
                body.setParents(parents);
                // set properties
                body.setTitle(fileName);
                body.setMimeType(fileMime);
                // push content
                InputStream in = null;
                try {
                    in = new BufferedInputStream(new FileInputStream(localFile));
                    InputStreamContent content =
                            new InputStreamContent(fileMime, in);
                    Drive.Files.Insert insertRequest = service.files().insert(body, content);
                    insertRequest.getMediaHttpUploader().setDirectUploadEnabled(true);
                    result = insertRequest.execute();
                } finally {
                    if (in != null) {
                        in.close();
                    }
                }
            } else {
                // file exists, update it if the one on the server has different
                // size
                File remoteFile = files.getItems().get(0);
                if (localFile.length() != remoteFile.getFileSize().longValue()) {
                    Log.e("TAG", "Performing update of file: " + localPath);
                    InputStream in = null;
                    try {
                        in = new BufferedInputStream(new FileInputStream(localFile));
                        InputStreamContent content =
                                new InputStreamContent(fileMime, in);
                        Drive.Files.Update updateRequest = service.files().update(remoteFile.getId(), remoteFile, content);
                        updateRequest.getMediaHttpUploader().setDirectUploadEnabled(true);
                        result = updateRequest.execute();
                    } finally {
                        if (in != null) {
                            in.close();
                        }
                    }
                } else {
                    result = remoteFile;
                    Log.e("TAG", "Skipping update of file because size is the same:" + localPath);
                }
            }

        } catch (Exception e) {
            Log.e("TAG", "createOrUpdateFileFromFile: "  + e.getMessage() );
            Log.e("TAG", "Exception while trying to createOrUpdateFile, localPath:" +
                    localPath + " parentId:"
                    + parentId + " exception:" + e.getMessage());
        }
        Log.e("TAG", "createOrUpdateFileFromFile: " + result.getId());
        return result;
    }

    public static List<File> retrieveAllFiles(Drive service,String parentId) throws IOException {
        List<File> result = new ArrayList<File>();
        String query = "mimeType='*/*' and trashed=false";
        // add parent param to the query if needed
        if (parentId != null) {
            query = query + " and '" + parentId + "' in parents";
        }
        Drive.Files.List request = service.files().list().setQ(query);

        do {
            try {
                FileList files = request.execute();
                result.addAll(files.getItems());
                request.setPageToken(files.getNextPageToken());
            } catch (IOException e) {
                System.out.println("An error occurred: " + e);
                request.setPageToken(null);
            }
        } while (request.getPageToken() != null &&
                request.getPageToken().length() > 0);

        return result;
    }

    public static void deleteFile(Drive service, String fileId) {
        try {
            service.files().delete(fileId).execute();
        } catch (IOException e) {
            System.out.println("An error occurred: " + e);
        }
    }




}
