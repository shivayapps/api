package com.secretvault.file.privary.adapters;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.secretvault.file.privary.R;
import com.secretvault.file.privary.db.FileItem;
import com.secretvault.file.privary.utils.StorageUtil;
import com.secretvault.file.privary.views.CustomTextView;

import java.io.File;
import java.util.ArrayList;

import ru.bartwell.exfilepicker.utils.Utils;

public class FileListAdapter extends RecyclerView.Adapter<FileListAdapter.ViewHolder> {
    public OnItemClickListner onItemClickListner;
    Context mContext;
    //    int mImageResize;
    private ArrayList<FileItem> mediaFiles = new ArrayList<>();

    boolean isSelected = false;
    public FileListAdapter(Context mcContext, ArrayList<FileItem> mediaFiles) {
        this.mediaFiles = mediaFiles;
        this.mContext = mcContext;

    }

    public static  int getFileIcon(String extention) {
        switch (extention) {
            case "apkbin":
            case "apk":
                return R.drawable.ice_apk;
            case "pdf":
            case "pdfbin":
                return R.drawable.ice_pdf;
            case "doc":
            case "docx":
            case "docbin":
            case "docxbin":
                return R.drawable.ice_doc;
            case "ppt":
            case "pptbin":
            case "pptx":
            case "pptxbin":
                return R.drawable.ice_ppt;
            case "xls":
            case "xlsbin":
            case "xlsx":
            case "xlsxbin":
                return R.drawable.ice_xle;
            case "txt":
            case "txtbin":
            case "csv":
            case "csvbin":
            case "rtf":
            case "rtfbin":
            case "odt":
            case "odtbin":
                return R.drawable.ice_txt;
            case "png":
            case "pngbin":
                return R.drawable.ice_png;
            case "jpg":
            case "jpgbin":
            case "svg":
            case "svgbin":
            case "bmp":
            case "bmpbin":
                return R.drawable.ice_jpg;
            case "gif":
            case "gifbin":
                return R.drawable.ice_gif;
            case "mp4":
            case "mp4bin":
            case "3gp":
            case "3gpbin":
            case "3gpp":
            case "3gppbin":
            case "3gpp2":
            case "3gpp2bin":
            case "mpeg":
            case "mpegpng":
            case "mkv":
            case "mkvpng":
            case "mov":
            case "movpng":
                return R.drawable.ice_video;
            case "aac":
            case "aacbin":
            case "flac":
            case "flacbin":
            case "m4a":
            case "m4abin":
            case "mp3":
            case "mp3bin":
            case "oga":
            case "ogabin":
            case "wav":
            case "wavbin":
            case "wma":
            case "wmabin":
                return R.drawable.ice_mp3;
            case "html":
            case "htmlbin":
            case "html5":
            case "html5bin":
            case "htm":
            case "htmbin":
            case "css":
            case "cssbin":
            case "asp":
            case "aspbin":
                return R.drawable.ice_html;
            case "zip":
            case "zipbin":
            case "rar":
            case "rarbin":
            case "rar4":
            case "rar4bin":
                return R.drawable.ice_zip;
            default:
                return R.drawable.ice_other;
        }
    }

    public void setItemClickEvent(OnItemClickListner onItemClickListner) {
        this.onItemClickListner = onItemClickListner;
    }

    public void setImageResize(int imageSize) {
//        this.mImageResize = imageSize;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_file_adapter, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int position) {
        File mediaFile = new File(mediaFiles.get(position).getNewPath());
        if (mediaFile.exists()) {
            String fname = mediaFile.getName().substring(0, mediaFile.getName().length() - 4);
            String extention2 = Utils.getFileExtension(mediaFile.getName());
            String extention1 = Utils.getFileExtension(fname);
            String extention = extention1 + extention2;

            RequestOptions options = new RequestOptions().placeholder(getFileIcon(extention));

            String parth = mediaFile.getAbsolutePath();
            File targetLocation = new File(parth);
            holder.media_thumbnail.setVisibility(View.VISIBLE);
            Glide.with(mContext)
                    .load(Uri.fromFile(targetLocation))
                    .apply(options)
                    .into(holder.media_thumbnail);

            holder.tv_filename.setText(mediaFiles.get(position).getDisplayName());
            holder.tv_size.setText(StorageUtil.convertStorage(targetLocation.length()));

            if (mediaFiles.get(position).checked) {
                holder.iv_chek.setVisibility(View.VISIBLE);
                holder.iv_chek.setImageResource(R.drawable.ic_check_box_black_24dp);
            } else {
                holder.iv_chek.setImageResource(R.drawable.ic_check_box_outline_blank_black_24dp);
                if (isSelected)
                    holder.iv_chek.setVisibility(View.VISIBLE);
                else
                    holder.iv_chek.setVisibility(View.INVISIBLE);
            }
            holder.iv_chek.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (onItemClickListner != null) {
                        onItemClickListner.onItemClick(position);
                    }

                }
            });
            holder.frm_root.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (onItemClickListner != null) {
                        onItemClickListner.onItemClick(position);
                    }
                }
            });

            holder.iv_chek.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    if (onItemClickListner != null) {
                        onItemClickListner.onItemLongClick(position);
                    }
                    isSelected=true;
                    return false;
                }
            });
            holder.frm_root.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    if (onItemClickListner != null) {
                        onItemClickListner.onItemLongClick(position);
                    }
                    isSelected=true;
                    return false;
                }
            });
        }
    }



    @Override
    public int getItemCount() {
        return mediaFiles.size();
    }

    public void setData(ArrayList<FileItem> videoList) {
        this.mediaFiles = videoList;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout frm_root;
        ImageView iv_chek;
        CustomTextView tv_filename;
        CustomTextView tv_size;
        private ImageView media_thumbnail;

        ViewHolder(View view) {
            super(view);
            media_thumbnail = view.findViewById(R.id.media_thumbnail);
            frm_root = view.findViewById(R.id.frm_root);
            iv_chek = view.findViewById(R.id.iv_chek);
            tv_filename = view.findViewById(R.id.tv_filename);
            tv_size = view.findViewById(R.id.tv_size);
        }
    }
}
