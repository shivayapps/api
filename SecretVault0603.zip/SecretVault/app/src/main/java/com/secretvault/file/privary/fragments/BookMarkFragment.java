package com.secretvault.file.privary.fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.secretvault.file.privary.R;
import com.secretvault.file.privary.activity.PrivateBrowserActivity;
import com.secretvault.file.privary.activity.WebActivity;
import com.secretvault.file.privary.adapters.BookmarlListAdapter;
import com.secretvault.file.privary.adapters.OnItemClickListner;
import com.secretvault.file.privary.db.DatabaseHelper;
import com.secretvault.file.privary.model.BookmarkModel;
import com.secretvault.file.privary.utils.Utils;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.ArrayList;
import java.util.List;

public class BookMarkFragment extends Fragment implements OnItemClickListner, BookmarlListAdapter.OnItemLongClickListner {


    RecyclerView bookmark_list;
    LinearLayout lin_nodata;
    List<BookmarkModel> list = new ArrayList<>();
    BookmarlListAdapter testAdapter;
    View view;
    Context mContext;

    DatabaseHelper databaseHelper;
    BottomSheetDialog bottomSheetDialog;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_bookmarks, container, false);
        mContext = getActivity();

        Init();
        return view;
    }

    private void Init() {
        bookmark_list = view.findViewById(R.id.bookmark_list);
        lin_nodata = view.findViewById(R.id.lin_nodata);

        databaseHelper = new DatabaseHelper(mContext);
        list = databaseHelper.listBookmark();

        if (list.size() > 0) {
            lin_nodata.setVisibility(View.GONE);
            bookmark_list.setVisibility(View.VISIBLE);
        } else {
            lin_nodata.setVisibility(View.VISIBLE);
            bookmark_list.setVisibility(View.GONE);
        }

        bookmark_list.setLayoutManager(new LinearLayoutManager(mContext, LinearLayoutManager.VERTICAL, false));
        testAdapter = new BookmarlListAdapter(getActivity(), list, this);
        testAdapter.setOnItemLongClickListner(this);
        bookmark_list.setAdapter(testAdapter);
    }

    @Override
    public void onResume() {
        super.onResume();
        Init();
    }

    @Override
    public boolean getUserVisibleHint() {
        PrivateBrowserActivity privateBrowserActivity = (PrivateBrowserActivity) getActivity();
        privateBrowserActivity.lin_searchview.setVisibility(View.GONE);

        return super.getUserVisibleHint();
    }

    @Override
    public void onItemClick(int position) {

        goSearch2(testAdapter.getAllItems().get(position).getPass_content());
    }

    public void goSearch2(String query) {
        if (Utils.isNetworkAvailable(mContext)) {
            Intent intent = new Intent(mContext, WebActivity.class);
            intent.putExtra("Query", query);
            startActivity(intent);
        }
    }

    @Override
    public void onItemLongClick(int position) {
        list.get(position).getPass_id();
        showBookmarkMenu(position, list.get(position).getPass_id());
    }

    private void showBookmarkMenu(int position, final String bookmark_id) {
        bottomSheetDialog = new BottomSheetDialog(getActivity());
        View dialogView = View.inflate(getActivity(), R.layout.dialog_action, null);
        TextView textView = dialogView.findViewById(R.id.dialog_text);
        textView.setText(R.string.lable_Confirm_delete);
        Button action_ok = dialogView.findViewById(R.id.action_ok);
        action_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                databaseHelper = new DatabaseHelper(mContext);

                databaseHelper.delete(Integer.parseInt(bookmark_id));
                Log.e("TAG", "onClick:== " + position);
                testAdapter.removeAt(position);
                bottomSheetDialog.dismiss();
                if (testAdapter.getAllItems().size() > 0) {
                    lin_nodata.setVisibility(View.GONE);
                    bookmark_list.setVisibility(View.VISIBLE);
                } else {
                    lin_nodata.setVisibility(View.VISIBLE);
                    bookmark_list.setVisibility(View.GONE);
                }

                Toast.makeText(mContext, getString(R.string.lable_delete_successful), Toast.LENGTH_SHORT).show();
            }
        });
        Button action_cancel = dialogView.findViewById(R.id.action_cancel);
        action_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottomSheetDialog.dismiss();
            }
        });
        bottomSheetDialog.setContentView(dialogView);
        bottomSheetDialog.show();
    }
}
